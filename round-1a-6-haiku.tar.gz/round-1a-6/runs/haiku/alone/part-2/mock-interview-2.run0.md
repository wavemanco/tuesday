Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-2-denied-d94ae7db/atlas-freight_operations-manager_interview_pack.md`. I built it as a hiring-manager round, since your note didn't say who you're meeting.

The main thing to rehearse is the scale gap: you manage 3 supervisors, and this role is 12 supervisors across four sites. Question A1 covers it and is the highest-return prep in the pack. The JD also asks for 5+ years of operations leadership, and your material doesn't say how many years you've led people (F6 in the pack).

I didn't run any research, so the pack has no company values, interview process, or current strategy. I can run a light search on Atlas Freight if you want it.

Say the word and I'll play the Skeptic on A1 or the Pressure interviewer on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

How many years have you actually led people, as opposed to working in operations?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (regional logistics, about 800 employees, 4 sites)
**Company:** Atlas Freight
**Interviewer:** not given
**Round:** not stated. Built as a hiring-manager round, the most likely default for this role. Step 1 asks which it is; the answer reweights the personas below.
**Basis:** your message only. No JD beyond the text you pasted, no CV beyond your message, no research run (see Sources).

## How to use + type key

Personas describe **how** a question is asked (tone, pressure, style). Types describe **what** is being scored. Every question carries a type tag so you can see coverage at a glance.

| Tag | Type | What it scores |
|---|---|---|
| **VAL** | Behavioral / values | Whether past behavior shows a value, not a slogan |
| **EXP** | Experience deep-dive | Whether your claims survive scrutiny, and what you personally did |
| **JD** | Role / JD-driven | Whether you can do the listed job, including its gaps |
| **CO** | Company and strategy | Homework depth (not researched for this pack) |
| **CASE** | Live problem | Structure and reasoning on a problem from the job |

**Guidance is scaffolding, not a script.** Say it in your own words. Where a guidance cell has an *answer slot*, the words are yours to fill with what is true, including "I haven't done that."

## Prep triage

Prep time was not stated, so no schedule is given. Priority order for any amount of time:

1. **A2 and A5** (the scale gap and the performance-metric gap). These are the likeliest hard questions.
2. **A3** (Power BI). Know the plain sentence and your learning plan.
3. **B1 and D2** (defend the 40%). Know how the number was counted, or say you don't know.
4. The rest, by persona weight.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material shows daily operations at one site. Words: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run, covered or coordinated work across more than one site, say which and how; if not, say so, and say how you would set up daily control across four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [grounded] | transferability | The quote is an accuracy metric. It reaches neither on-time performance nor cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say which and what moved; if not, say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The scale is 3 supervisors against 12, the largest gap in this snapshot. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: name the leadership you have that scales (cadence, delegation, how you run the 3 today), and say what you have not yet done at 12. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" — your message | low | [grounded] | discovery | The quote is a skill statement, not a reporting record. Answer slot: if you have built a recurring report in Excel, name it, who used it and what decision it changed; if not, say what you would build first. |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated, so it is not bridged. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as experience. |
| F6 | "5+ years operations leadership required" (JD) | none given for years of leadership. Operations experience: "7 years in warehouse and distribution ops" — your message | low | [grounded] | hard_gate | Your material does not establish how many years you have led people. The 7 years is operations work, and the current role is over 3 supervisors. Surfaced, not bridged. The one question for this row is in the message that presents this pack. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" — your message | high | [grounded] | none | Covered by the credential. Lead with it as stated. Expect a probe on what you applied it to. |

**Gap types used:** `transferability` (F1, F2, F3), `discovery` (F4), `capability` (F5), `hard_gate` (F6), `none` (F7).

## Prohibited list

Claims this pack will not coach, and the honest form of each:

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | F1's quote at its own scope: one site, peak-season surge plan, two years running |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote: the mis-pick rate and the pick-path redesign |
| Led 12 supervisors, or a 12-person team | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors" |
| Built Power BI reporting, or any Power BI dashboard | Negative you stated, F5 | "I haven't used Power BI." |
| Has 5+ years of operations leadership | F6, not established by the material | The count of years you have actually led people, from your own record |
| Any baseline, period, denominator or counting method for the 40% | Not in the material | Answer slot in B1 only: say how it was counted if you know, and say so if you don't |

## Persona table

Hiring-manager prior, since the round type is not stated. Weights are shown so you can correct them.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scale and reporting gaps | High (top weight, 5 questions) | A hiring manager is buying capability and derisking gaps; F3 and F5 are the gaps | Rehearse the single predictable objection until it is plain; concede exactly what is true |
| Case / Strategist | Live operations problems from this job | High (4 questions) | The JD is operational and metric-led | Clarify, then structure, then metrics, then risks; think aloud |
| Data-Driven Prober | Asks how the 40% was counted | Medium (3 questions) | The 40% is the one headline number in the material | Say what you know about how it was counted; name the weakest assumption before it is named for you |
| Pressure | Time-boxed challenges to fit and to attribution | Medium (3 questions) | Common for hiring managers testing composure on a gap | Pause, restate, hold a position through two follow-ups; concede without folding |
| Conversational | Casual openers that are still scored | Low (2 questions) | Round type unknown; casual openers are still scored | Prepare a 90-second career arc; treat casual questions on Lean as scored |
| Peer Evaluator | Seams between teams; credit sharing | Low (2 questions) | Low for a hiring manager; rises if the interviewer is a peer | Frame what you bring to their team, not only what you need |
| Values / Behavioral | Scenario probes | Low (2 questions) | No values were supplied and no values round was detected | Selection scaffold ending in its honest branch where no story is in the material |

## Question banks

**Requirement coverage:** Daily terminal ops across 4 sites → A1, C1. OTP and cost per shipment → A5, B3, C1, C2. Lead 12 supervisors → A1, C3, D1. Excel/Power BI reporting → A3, A4, C4, D3. 5+ years operations leadership (gate) → A2. Lean/Six Sigma (plus) → E2.

### A. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're leading three supervisors today. This role has twelve, across four sites. What's the gap, in your view?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Say the 3 and the 12 in your own words. Name the part of the scale you have handled and the part you have not. Answer slot: the first 30 days you would spend getting control of 12 supervisors across four sites. | F3 is the largest gap and the most predictable objection. **This is the highest-ROI prep in the pack:** rehearse it until it is calm and specific. |
| A2 | "The job asks for five years of operations leadership. How many years have you led people?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message | Count years you supervised or led people, not years you worked in operations. Answer slot: if the number is under five, say so, and say what the leadership you have covered. | F6 is a hard gate. It is surfaced, never bridged, and the answer comes from your own record. |
| A3 | "This role builds reporting in Power BI. Have you used it?" | JD | [grounded] "never used Power BI" — your message | "I haven't used Power BI." Then, as a plan, how you would learn it. Do not add any exposure to it. | F5 is a stated absence. Its words are the plain sentence, with no slot. |
| A4 | "What would you be weakest at on day one?" | JD | [grounded] "solid Excel" — your message; "green belt certified" — your message | Name Power BI first, as a plan. Then name what you would need to learn in Excel reporting. Answer slot: any reporting you have built and who used it. | F4 and F5 together. Honest self-assessment is what this question scores. |
| A5 | "This role is measured on on-time performance and cost per shipment. Which of those have you moved?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: any on-time or cost figure you moved. If you moved neither, say what you tracked and what you would measure first. Never claim a figure you did not track. | F2 is the second-largest gap, and the answer is an accuracy metric, not the two the JD names. |

### B. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | The 40% is your number, and the material has no baseline, period or counting method. Answer slot: how it was counted, the baseline and the period, and the assumption you would defend least. If you do not know, say so. | Defend-the-number. A method you cannot repeat under a second question is worse than none. |
| B2 | "Which part of that pick-path work was yours to decide, and which was the site's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Describe your decisions in your own words. If the redesign was team or site work, say so and name your part. | Attribution. Shrinking a shared result gracefully scores better than inflating it. |
| B3 | "Name the metrics you would put on on-time performance and cost per shipment, before you change anything. What is the denominator?" | JD | [generic] | Name the metric, its denominator and the data source. This question makes no claim about your past. | Covers the OTP and cost requirement (F2) as a method question. |

### C. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance dropped six points last week at one of your four terminals. Diagnose it." | CASE | [generic] | Clarify first: which terminal, which period, which lanes. Then segment by shift, lane, carrier and dock door. Then approach, metrics and risks. Think aloud. | Live operations problem for the JD's on-time requirement. |
| C2 | "Cost per shipment is up in peak season. What do you look at first?" | CASE | [generic] | Start with the cost drivers you would split out (labor, overtime, volume mix), then the metric. Name what you would need to know before changing anything. | Cost requirement, asked as a live problem. |
| C3 | "Your supervisors disagree on a process change. How do you decide?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Give the decision framework first: what data, who decides, how you test it. Then, if asked about your own team: answer slot for a real decision you made with your supervisors. | Covers the lead-supervisors requirement (F3) without asserting a scale you have not run. |
| C4 | "We want Power BI dashboards in front of four site managers in sixty days. What is your plan?" | CASE | [generic] | Set out the first decision the dashboard must support, the data source, the first version, and how you would check it with the site managers. Name your learning plan for Power BI as a plan. | Reporting requirement, asked as a live plan. No claim about past use. |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone managing three supervisors over someone running four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Pause. Restate the question. Say what you did with the 3, and what you would do to take on the four sites. If pressed twice, concede the scale you have not run, without folding on what you have done. | F3 under time pressure. Composure is what is scored. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer with your decisions. If the redesign was shared, say so and name your part. Hold through two follow-ups by returning to your own role. | Attribution under pressure. |
| D3 | "Power BI is in the job description. Why should we believe you'll pick it up?" | JD | [grounded] "never used Power BI" — your message | "I haven't used Power BI." Then how you would learn it, as a plan with no dates or figures you did not give. | F5 under pressure. The honest sentence is the strongest answer available. |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path into operations." | VAL | [grounded] "7 years in warehouse and distribution ops" — your message | A 90-second arc from warehouse floor to shift manager, in your own words. Do not add roles or scope. | Casual opener, scored on economy and clarity. |
| E2 | "What are you actually doing with Lean these days?" | JD | [grounded] "green belt certified" — your message | Say what you applied the Green Belt to. Answer slot: name one Lean or process project you led or joined, and your part in it. If you have not applied it recently, say so. | Covers the Lean/Six Sigma plus, asked casually. |

### F. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | VAL | [generic] | Propose principles for handling seams and disagreement, not a claim about a seam you have not run. | Covers collaboration without a past claim. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Use "we" for team work and "I" for your contribution. Answer slot: an example of shared credit, if you have one. | Credit-sharing, tied to the one result in your material. |

### G. Values / Behavioral (2 questions)

No company values were supplied, so these are selection scaffolds with their honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you raised a result a leader did not want to hear. If none comes to mind, say so and describe the closest one. | Selection scaffold. The material has no such story, so none is supplied. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a service or delivery decision cost you on an internal number. If none, say so, and say how you would weigh it. | Selection scaffold, same honest branch. |

## Reverse questions

No interviewer profile exists, so these are role-generic. Each has a "why it lands."

1. "What does a new operations manager need to have running across the four sites in the first 90 days?" Why it lands: it shows you are planning against the full scope.
2. "Which site has the biggest on-time gap right now, and what is driving it?" Why it lands: it shows you read the metrics and want the real problem.
3. "How is the weekly reporting used today, and who decides from it?" Why it lands: it opens the Excel and Power BI question on your terms.
4. "What does a good cost-per-shipment result look like at twelve months?" Why it lands: it turns their metric into a shared target.
5. "How are the supervisors spread across the four sites today, and what is the span of control?" Why it lands: it tests the scale gap honestly and gives you the real number.
6. "Which Lean or Six Sigma work is already running here, and where would they like it to go?" Why it lands: it signals you care about the plus and want to build on it.

## Sources

**Research tier: L0.** No searches or fetches were run in this turn. Research consent was not asked here because the round type and the leadership-years question are missing; the upgrade menu offers it.

Provided documents: the JD text and your message, as quoted above.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section 10), not built |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure; persona weights would follow the named rounds |
| 3. Atlas Freight strategy and recent news | unavailable | Grounding brief and CO questions |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot |

## Upgrade menu

- The round type and who you are meeting → reweights the personas and may replace the hiring-manager prior
- How many years you have led people → resolves F6, the hard gate, and sharpens A2
- The interviewer's name → a tailored reverse question, and persona weights read from their public background
- Atlas Freight's published values, or the full posting → a values cheat sheet, with mapped stories where your material carries one
- Research at the L1 tier (values, interview process, recent strategy; up to 6 searches and 2 page fetches) → a grounding brief and current CO questions; the L2 deep tier is available on request
- A recruiter's prep email → coverage of any deliverable they announced
- Your prep time → a prioritized schedule sized to it
- A `tuesday-dossier.md` from job-underwriter → verified evidence for the fit snapshot and a list of claims this pack must not coach
