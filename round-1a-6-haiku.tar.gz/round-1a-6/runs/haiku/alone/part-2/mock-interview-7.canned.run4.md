Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-canned-a82a9d89/46797440-379f-427e-abba-0ef6e82b979f/scratchpad/saltmarsh_live_operations_producer_interview_pack.md, and I've sent it to you to open.

What changed my plan:
- **The loop is known.** Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager: a live-incident tabletop during a live event, then a values conversation. The pack's run order is built on that. The split of minutes is my suggestion, since they don't publish one.
- **The biggest risk is the monetization gap you named.** The pack's highest-ROI prep is S1: say plainly that you haven't worked on a game with in-app purchases, then give a plan for learning it, not a past.
- **The 3+ years live-service gate isn't shown met by your material.** The pack asks you for the count rather than bridging it.
- **Research was thin.** A news search turned up Project Larkspur (September 2026), which moves both titles to one shared events calendar and a single live-ops group. I could only see that in a search snippet, not the page. The interviewer read is also one search snippet, from a talk page I couldn't open, on a domain I couldn't verify. Treat both as unconfirmed.

Two things would help me tighten the pack:
1. Is Tobias your hiring manager, and is this the tabletop-then-values round?
2. Is the puzzle title live-service, and for how many of your four years was it?

Other options:
- Drill: I can play the Skeptic on S1, the question the pack names as highest-ROI.
- Dossier: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- Word: I can convert the pack to a Word document once you've finished editing it in markdown.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be **hiring manager**, from Saltmarsh's interviewing page, which says the loop's 60-minute interview is with the hiring manager. Please confirm (see the questions in the message).

## How to use this pack

- **Personas** = how a question is asked. **Types** = what it scores.
- Type key: **VAL** behavioral/values · **EXP** work-experience deep-dive · **JD** role requirement · **CO** company/strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Lines that say "if…, say so" are **answer slots**: the honest answer is either branch, in your own words. Never prepare the practice a slot names.

### The 60-minute run (my timing, not Saltmarsh's; the company does not publish a split)

| Minutes | Segment | Use |
|---|---|---|
| 0–5 | Introductions, your 90-second arc | K1 |
| 5–25 | Outage Hour: live-incident tabletop | C2, then C1 or C5 as follow-ups |
| 25–50 | Values conversation, with Skeptic probes woven in | V1–V3, S1, S2, S4 |
| 50–57 | Your questions | Reverse questions RQ1–RQ3 |
| 57–60 | Close | Thank, confirm next step |

The company's page describes the loop as "a live-incident tabletop on a simulated outage during a live event, then a values conversation." Expect the tabletop first.

## The fit snapshot

Requirements are quoted from the job description you sent. Your evidence is quoted from your own message, nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not two titles' live-events calendars. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned calendars for more than one title, say which and how the two differed; if you planned only the one, say so and how you would approach a second. |
| F2 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I presented the monthly retention numbers to the studio head." Adds no practice. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. F2 touches KPIs without showing whether it reaches them. Answer slot: if you set the KPIs for a review, say what they were; if you only reported figures others set, say so and say what you would define first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Do not add who signed off releases unless you did. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these teams on an update. The stated "Never led a team" limits any claim to direct leadership (see the prohibited list). Answer slot: name the teams you did work with on a release and what you coordinated; if none beyond QA, say so and say how you would coordinate four disciplines without direct authority. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [grounded] | hard_gate | Your material does not establish that the puzzle title is live-service, so this gate is not shown met. The closest sentence is "I ran the weekly content-drop calendar for our main title for the last two years", which is two years. No bridge. The gate is surfaced, and the question about it is in the message. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote reaches the requirement directly. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on cadence. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | transferability | A checklist is written work for another team; it is not evidence of written communication in general. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you have a written sample you can point to, name it; if not, say what you would share. |
| F9 | Monetization, in-app purchases (not a JD line; role-family prose) | "Never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. |

Gap types follow the routing rule in the skill: a gate the material does not show met is `hard_gate`; a quote that reaches the requirement in other terms is `presentation`; adjacent work is `transferability`; silence is `discovery`; a negative you stated is `capability`.

## Reading the interviewer

Public footprint only, and thin.

- **Career pattern:** Head of Live Operations at Saltmarsh. A search result describes him as previously a QA lead at a console studio, in connection with a GDC 2026 talk, "Patch Notes Are a Promise". I could not open the talk page, and its domain is unverified, so treat this as unconfirmed.
- **Recurring theme, if the talk checks out:** a live team is judged by how often its patch notes describe what actually shipped. That matches the company's "Ship the Patch Not the Promise" value.
- **Practical implications:**
  1. The release checklist (F4) is the strongest artifact in your material for this interviewer. Describe what it does, not its effect.
  2. Use "what shipped" as vocabulary, quoting F4, but do not claim a release outcome you cannot name.
  3. There is no shared career jump, so no mirror opportunity is offered.

## Persona table

Relationship prior: hiring manager (Case/Strategist and Skeptic). Adjustments: the company's loop names a tabletop and a values conversation; the JD names retention and KPIs; the company's news (Project Larkspur) suggests a shared calendar and a single live-ops group, which adds a coordination angle.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 5 | Outage Hour tabletop on a live event | Highest: the loop's first segment is a live-incident tabletop | Clarify before structuring: scope, what players see, roll back or hotfix, what you say and when |
| Skeptic | 4 | "Why you, with no in-app purchases and no team lead?" | High: F5, F6 and F9 are the visible gaps | Plain acknowledgment, a plan for the gap, hold once, concede the specific part |
| Values/Behavioral | 4 | Values conversation after the tabletop | High: the loop names a values conversation; three values are published | Map each value to a quoted sentence, or give a selection scaffold ending in its honest branch |
| Data-Driven Prober | 3 | Retention numbers and KPI definitions | Medium: the JD names retention and post-event KPIs; F2 and F3 are the thin points | Say how the number was counted, if you know; name the weakest assumption before it is asked |
| Pressure | 2 | Interruption on the presentation | Low to medium: a time-boxed interview | Pause, restate, hold through two follow-ups |
| Conversational | 2 | Opener and close | Low to medium: casual questions are scored | A prepared 90-second arc; treat casual questions about the JD as scored |
| Peer | 2 | Seam with design and art leads | Low: a hiring manager rarely sets the seams as a probe | Propose the seam in writing and ask the other team to correct it |

## Question banks

Question counts: Case 5, Skeptic 4, Values 4, Prober 3, Pressure 2, Conversational 2, Peer 2. Total 22.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two weeks before a live event, a major update slips. What do you need to know before you touch the calendar?" | CASE | [generic] | Clarify first: what players were promised and where, what is built versus hoped, which teams are blocked, what moving costs. Name the principle: when the calendar and the players disagree, the players win. Then say what you would decide and who you would tell. | A live calendar problem from the JD's calendar line. No claim about your past. |
| C2 | "It is event day. A reward is failing for part of the player base. Walk me through the first 30 minutes." | CASE | [generic] | Structure: confirm the scope, contain, decide roll back versus hotfix, decide what players hear and when. Say only what you would announce as built, not as promised. Do not commit to a fix time you do not own. | The company's interview is a live-incident tabletop during a live event. This is the format. |
| C3 | "The role plans live events for two titles. How do you decide which title gets a given slot?" | CASE | [generic] | Criteria: player need from retention data, engineering capacity, risk to each title, what the other team is shipping. Name who owns the decision. | JD line "two of our mobile titles". Reaches F1's gap without naming it. |
| C4 | "How would you judge whether a live event was worth repeating?" | CASE | [generic] | Define the KPI before launch, name a retention guardrail, and say what would count as not worth repeating. | JD line on the post-event review and its KPIs. F3 is the gap; the answer is a method, not a past. |
| C5 | "On a live update, art, engineering and community all need to move at once. Who do you bring in first?" | CASE | [generic] | Sequence: who can block the update, who is on the critical path, who owns player messaging. | JD coordination line. F5 is a discovery gap, so the answer is a plan. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your last four years had no in-app purchases. What would you need to learn first to run live events on a title that has them?" | JD | [grounded] "Never worked on a game with in-app purchases"; [grounded] "4 years as an associate producer at a puzzle-game studio" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan: which monetization decisions you would sit in on first, and what you would ask. Hold through two follow-ups by returning to the acknowledgment, not by adding experience. Concede specifically: monetization judgment is what you would learn first. Never say the puzzle work was monetized. | **Highest ROI in this pack.** It tests the gap you stated, and it cannot be bluffed. The JD does not mention monetization, so this is a probe of your gap, not a JD line. |
| S2 | "The JD asks for three years of live-service production. Which of your four years were on a live title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Count from your own sentences: four years at the studio, two years running the content-drop calendar. Answer slot: if the title was live for longer, say so and how you know; if you cannot say it was live-service for the whole time, say the two years plainly. | Gate F6. The gate is not shown met; the honest answer is the count. |
| S3 | "Your checklist is used by QA. Who signs off a release, and where did you sit in that?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if you made the sign-off call, say so and on what basis; if QA signed off and you wrote the checklist, say so and stay with what you wrote. Do not claim you managed the release with QA. | F4 is the inflation check: "wrote" is the claim, not "managed". |
| S4 | "You have never led a team. This role coordinates four disciplines. Why would that work?" | JD | [grounded] "Never led a team"; [grounded] "Wrote the release checklist our QA team still uses" | Plain acknowledgment: "I haven't led a team." Then how you would coordinate without direct authority: decision rights on the calendar, and what you would settle in writing. A plan, not a past. Hold once; concede that direct leadership is the part you have not done. | F5 and the stated negative. A plan is allowed; a past is not. |

### Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Value: Players Before Plans. Selection scaffold: pick a time a player-facing number or complaint changed what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers went to the studio head. Say what was decided, if anything, and what you did not decide. | No candidate sentence carries a calendar decision. The honest branch is required. |
| V2 | "When did you hold something back because it wasn't ready to announce?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Value: Ship the Patch Not the Promise. Selection scaffold: a release you checked against the checklist before it was announced. If the checklist stopped something, say what it caught. If you have no such time, say so. Do not say the checklist stopped a release unless you can say it did. | The quote supports the checklist's existence and use, not a held release. |
| V3 | "Tell me about something you left better for the next team." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Value: Leave the Build Greener. Mapped story: the checklist you wrote, still in use by QA. Beats: you wrote it; QA still uses it. Do not claim its effect on defects unless you measured it. If you did not, say so. | Mapped story: the quote carries the artifact and its persistence. |
| V4 | "Tell me about a time you delivered an unpopular truth to a team that wanted a different answer." | VAL | [generic] for the question; [grounded] "Presented the monthly retention numbers to the studio head" for the nearest story | Selection scaffold: a named stake, a moment you did not soften it, and where it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers presented to the studio head, and what you can and cannot say about how that landed. | A values stem from the persona list. The nearest story is the only candidate sentence; no outcome is supplied. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know of the definition, in your own words. Answer slot: if you know the window and the definition, say it; if you do not, say you do not know how it was counted in detail and what you would check. Name the weakest assumption you know of before they ask. | Defend-the-number slot for F2. |
| D2 | "Which of those retention numbers did you choose, and which were given to you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you chose the cut, say which and why; if it was given to you, say so. | Attribution check on F2. |
| D3 | "Our post-event review owns its KPIs. Have you run one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you have reviewed a live event's KPIs, say which; if you have only presented monthly retention, say so and how you would set the review's KPIs first. | F3 is a discovery gap; F2 is the only KPI-adjacent sentence. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You have sixty seconds. Why should we hire a puzzle-studio producer for this?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, then restate. Lead with that sentence. Hold through two follow-ups: the calendar is the relevant work, and the gaps are named. Concede specifically on monetization and team leadership. | Composure test. The hold is on what the quote carries, nothing more. |
| P2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: which part was yours: the presentation, the cut, or the movement. Say you presented it, and say what you cannot separate. Do not claim the movement. | Counterpart to D1. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the studio and the years, the calendar, the release checklist, the retention presentation. Stay with the quoted sentences. | Opener. Also the answer to the JD's content-calendar line (F7). |
| K2 | "What about live ops are you most curious about?" | JD | [generic] | Name the calendar-and-player tension (Players Before Plans) and ask how they decide it. Do not claim knowledge you do not have. | Casual register, but scored. |

### Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and art each want the same slot. How do you handle that?" | CASE | [generic] | Seam principle: agree the calendar's criteria before the argument starts. Do not claim you have settled one. | Peer probe on the coordination line. |
| E2 | "Where does your job end and engineering's start on a live update?" | JD | [generic] | Propose the seam in writing and ask engineering to correct it. | Peer probe; no past claim. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C1, C3 (F1 gap in S2 and the message's question) |
| "coordinate design, art, engineering and community teams on each update" | C5, E1, S4 |
| "own the post-event review and the KPIs it reports" | C4, D3, D2 |
| "manage the release checklist with QA" | S3, V2, V3 |
| "3+ years producing live-service games or apps" | S2 |
| "experience running a content calendar" | K1 |
| "comfortable with player-retention metrics" | D1, D2, P2 |
| "clear written communication" | none, and why: a spoken interview does not score writing directly. F8 is the only evidence and is low confidence. |

Not in the JD but likely to be raised: monetization and in-app purchases, covered by S1.

## Values / principles cheat sheet

The company's values page names three values. This loop has a values conversation, so this section applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | V1: selection scaffold. The nearest sentence is "Presented the monthly retention numbers to the studio head" (F2). Honest branch: if there was no such time, say so plainly. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | V2: selection scaffold, nearest sentence F4. Honest branch: if there was no such time, say so plainly. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | V3: mapped story on F4, "Wrote the release checklist our QA team still uses". |

## Reverse questions

Hiring-manager round, no interviewer profile beyond the public talk, so no path-tied question is strong enough to lead with. Each question has a "why it lands."

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "The talk describes patch notes as a promise. What do you check before a live event that the rest of the team might miss?" | Shows you read the public talk, and the answer tells you what the tabletop will press on. |
| RQ2 | "Project Larkspur moves both titles onto one events calendar from February. How is the owner of that calendar being set up?" | Shows you read the company's news, and asks about the job you would be doing. |
| RQ3 | "How is the release checklist set up with QA today, and where does it hurt?" | Your strongest artifact is the checklist, so this question is one you can answer from experience. It also gets you the current state. |
| RQ4 | "What does a good first 90 days look like in this role?" | A standard question that signals you are planning. |
| RQ5 | "What did the last live event that went badly teach the team?" | Shows you care about the post-event review, and the answer tells you how the team handles blame. |
| RQ6 | "How does the Outage Hour compare with what the team actually does on a live event day?" | A hiring-manager question. It checks whether the tabletop matches the real job. |

## Prohibited claims

The claims this pack will not coach, and why. Built locally from the fit snapshot. These bind every answer slot, bridge and question above.

| Not coached | Basis | Honest form |
|---|---|---|
| "I planned live events for two titles." | Inflated form of F1: the JD says two titles; your material says one title's content-drop calendar. | F1's quote at its own scope. Pack observation: your material says one title. |
| "I led a team." / "I led the design, art, engineering and community teams on updates." | Sourced: your stated "Never led a team." Also an inflated form of F5. | Plain acknowledgment: "I haven't led a team." |
| "I owned the post-event KPIs." / "I owned the retention numbers." | Inflated form of F2: you presented the numbers. | F2's quote at its own scope. |
| "I have three years of live-service production." | Inflated form of the F6 gate. | Pack observation: your material does not establish that the puzzle title is live-service. S2 asks for the count. |
| "I managed the release process with QA." | Inflated form of F4: your sentence is "wrote". | F4's quote at its own scope. |
| "I have worked with in-app purchases." | Sourced: your stated negative. | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Sources

Provided documents: your message, including the job description text, your background and the gaps you named.

Research tier: L1 — searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values quoted by name from the company page |
| 2. Saltmarsh Games interview process | yes | Loop structure: 60-minute Outage Hour with the hiring manager, then a values conversation. No take-home. Sets the run order above |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur (September 2026), from a search result; not opened. Moved RQ2 and the monetization note |
| 4. Tobias Wrenfield + company | yes | Interviewer read: one public talk, from a search result; the talk page itself was not opened |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

Searches and fetches:
- Search: "Saltmarsh Games values" → saltmarshgames.com/values (fetched)
- Search: "Saltmarsh Games interview process live operations producer" → saltmarshgames.com/careers/interviewing (fetched)
- Search: "Saltmarsh Games mobile studio strategy news" → saltmarshgames.com/news/project-larkspur (search snippet only)
- Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" → talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; domain unverified)

No dossier was consumed.

## Upgrade menu

- Tobias's talk page, if you open it for me → confirms or drops the interviewer read.
- Your CV or résumé → F rows gain a quoted sentence for each requirement; F5 and F8 are the most likely to upgrade.
- The recruiter's note or the agenda split → replaces my 60-minute timing with theirs.
- Whether the puzzle title was live-service, and for how long → resolves the F6 gate and tightens S2.
- L2 deep research (strategy brief, Larkspur coverage, Tobias's writing) → adds a grounding brief and sharper CO questions.
- Your prep time before Friday → adds a prioritized triage section.
