Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-denied-cf5e32db/208b0938-5ca6-4baf-9a50-3b56981d111f/scratchpad/Saltmarsh_Games_live-operations-producer_interview_pack.md. I built it with flat persona weights, since your note doesn't say whether Tobias is your future manager or a peer. Web search was refused in this session, so nothing about Saltmarsh Games, its values, its interview process or Tobias is verified. The pack runs on your note alone.

The pack's biggest risk is B2, "why should we hire you over someone who has led a team?" Your note says you've never led a team, and the JD's "coordinate design, art, engineering and community teams" will make that the likely objection. Say the word and I'll run B2 as a drill.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a peer, or someone else? And is Friday's session the only round, or is there a recruiter note about a take-home or presentation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not stated (manager, peer or other).
**Round:** one 60-minute session, Friday. Format not stated.
**Version:** first pack, no regeneration.

## How to use + type key

Personas are how a question is asked: the tone, the pressure, the follow-up style. Types are what the question scores. Every question carries a type tag, and every guidance cell is scaffolding for a spoken answer, not a script.

- **EXP**: work-experience deep-dive. Tests whether what you did survives scrutiny.
- **JD**: role and job-description driven. Tests whether you can do the listed job, including its gaps.
- **CASE**: live hypothetical problem from the role, reasoned out loud.
- **CO**: company and strategy knowledge. Not in this pack, because company research did not run (see Sources).
- **VAL**: values and behavioural. Not in this pack, because no values round was detected (see Persona table).

## Fit snapshot

Each row sets one JD requirement against what your own message says. Quotes are your words, exactly as you wrote them, or the JD's words, exactly as supplied. Confidence grades your evidence. Provenance grades what this pack wrote about it. Gap type says what kind of gap, if any, the row shows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "Ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title, not two, so the bridge stops at one: "Ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever planned more than one title's calendar, say which and how; if you planned one, say so and say how you would add a second. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordinating those four teams on an update. Answer slot: say which of them you worked with on a drop and what you needed from each; if you did not, say so and say how you would set that coordination up. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The quote reaches the KPI-reporting half, not the post-event review, and the material shows no review. Answer slot: if you ran a review after an event or drop, say what it covered and what it reported; if you did not, say so and say what you would measure first. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I presented the monthly retention numbers to the studio head." No figure was given, so no defend-the-number slot is raised. The material does not show how the figures were counted. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Verified in your words: "I wrote the release checklist our QA team still uses." The checklist is the inspectable artifact; a redacted copy would move this row to high. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Years and studio are specific. The material does not show the title was live-service in the JD's sense. Answer slot: say how the puzzle title stayed live after launch, in your own words; if it was not live-service in that sense, say so and say what you did produce. The three-year line is a length-of-experience requirement, not a gate. |
| F7 | "experience running a content calendar" — JD | "Ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote already reaches the requirement in role terms. A redacted copy of the calendar would move this row to high. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist in use shows written instructions working for QA. Written updates and post-event reports are not shown. The answer slot under F3 covers the written report. |

No row is a gate. The JD states no location, schedule, authorisation or credential requirement, so no gate question is asked.

## Prohibited claims

These claims are not coached anywhere in this pack. Each entry says why it is listed and what to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1: your sentence names one title | "Ran the weekly content-drop calendar for our main title for the last two years." Limit, in this pack's analysis: the material says one title, not two. |
| Owned the post-event review and the KPIs it reports | Inflated form of F3: your sentence says you presented retention numbers | "Presented the monthly retention numbers to the studio head." Limit, in this pack's analysis: the material shows no post-event review. |
| Retention numbers changed a studio decision | Outcome you did not state | "Presented the monthly retention numbers to the studio head." |
| Ran a live-service title | Inflated form of F6: your sentence names a puzzle-game studio | "4 years as an associate producer at a puzzle-game studio." Limit, in this pack's analysis: the material does not show live-service. |
| Led a team | Your own stated negative. Plain acknowledgment, source: your message | "Never led a team." |
| Worked on a game with in-app purchases | Your own stated negative. Plain acknowledgment, source: your message | "Never worked on a game with in-app purchases." |

## Question banks

Personas are weighted flat, because the relationship is unknown: each carries three questions. Provenance comes first in each row. Rationale refers to your history only by fit-snapshot row ID.

### A. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" | Tell the cadence and the two years in your own words: what went on the calendar and how far ahead it was set. Answer slot: the JD's two-title line makes a scope probe likely. If you planned for more than one title, say which and how. If you planned one, say so and say how you would take on a second. | F7 is the content-calendar evidence and the likeliest first probe. EXP because it tests what you actually did; F1 is where the scope probe lands. |
| A2 | "What does a post-event review look like, and have you run one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | This is an open prompt, so you choose the instance. If you ran a review after an event or drop, say what it covered and what it reported, using the monthly retention numbers you presented as the nearest thing your material carries. Answer slot: if you did not run one, say so plainly, then say what you would measure first and who it would go to. Never describe a review you did not run. | The JD owns this review and F3 is the thin bridge, so the honest branch must be ready before the probe. JD because it scores a stated responsibility. |
| A3 | "Walk me through the release checklist you wrote, and what QA does with it." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say what the checklist covers, in your words, and how it sits between you and QA. If you changed it because of a specific release, say which and why; if you have not changed it, say so. | F5 is the evidence. The JD asks you to manage the release checklist with QA, so a probe here is expected. The checklist is an artifact you can point to. |

### B. Pressure / Stress Interviewer (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The studio head sees the retention numbers every month. How much of that number was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Pause, then restate: "I presented the monthly retention numbers to the studio head." Hold through two follow-ups: say what presenting covered and what you produced, and no more. Then concede plainly what you do not know about how the figures were counted, without giving up what you did present. | F4 is the retention evidence and the pressure is on attribution. The honest answer is precise, not bigger. |
| B2 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" | Pause, then restate. Open with the plain acknowledgment: "I haven't led a team." Then give the nearest thing your material carries, in your own words: the content calendar you ran for two years and the checklist QA still uses. Hold through two follow-ups. Concede plainly that coordinating four teams on an update is the part you still have to prove. | Highest-ROI prep in this pack. Leadership is the objection the JD and your note make most likely, and F2 is where it lands. Hold, then concede, is the only structure that survives a second follow-up. |
| B3 | "Sixty seconds: what does QA do with your checklist?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Restate, then answer from the quote: QA still uses it. Say what you know it is used for. If you do not know how QA uses it day to day, say so and offer to find out. Hold the one claim the quote carries; add nothing about what QA does with it. | Time-boxed pressure on the one artifact in the material. The hold stays at "still uses". |

### C. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A content drop is set for three weeks out, and design, art, engineering and community each want a different date. How do you plan it?" | CASE | [generic] Raising source: JD line "coordinate design, art, engineering and community teams on each update" | Clarify first: what the drop contains, what each team needs and by when, what QA must sign off, and what the community has been told. Structure the plan around the release date, then say what you would decide yourself and what you would escalate. Make no claim about your past. | A live problem from F2's requirement. The guidance makes no claim about you. |
| C2 | "Player retention on one title drops eight percent in the four weeks after an event. What do you look at first?" | CASE | [generic] | Clarify: which cohort, and what changed besides the event, such as a release, an outage or a pricing change. Split new from returning players, check whether the drop sits only in the event cohort, and name the weakest assumption you are making about the data. Say what you would not conclude yet. | The JD's retention line, asked as a problem. The weakest-assumption move is the metrics rubric. |
| C3 | "Two titles share one QA team and run different release schedules. How do you sequence a drop across both?" | CASE | [generic] Raising source: JD line "Plan and run the live-events calendar for two of our mobile titles" | Clarify the constraints: QA capacity, each title's release schedule, and any shared events. Propose a sequence, say what gives way first when the two collide, and say what you would need to confirm with QA. Make no claim about your past. | The scope probe from F1, asked as a problem so the honest answer is judgment rather than a record. |

### D. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role needs three years producing live-service games or apps. Which of that do you have, and which don't you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Ran the weekly content-drop calendar for our main title for the last two years" | Say the four years and the puzzle studio, and the two years of the content calendar, in those words. Then the honest limit: your material does not show that the title was live-service in the JD's sense. Answer slot: say how the puzzle title stayed live after launch, in your own words; if it was not live-service in that sense, say so and say what you did produce. | F6 is the likeliest skeptic line. The bridge is a stated limit, not a relabel of the years. |
| D2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say how you would learn the monetisation side, as a plan and never as a past. Claim no monetisation work. | Your own stated absence. No JD line raises monetisation, so this is a generic probe for a mobile studio, asked in open form. |
| D3 | "Where would you be weakest on day one?" | JD | [grounded] "Never led a team" | Name the gap in your own words: "I haven't led a team." Then give a first-30-days plan, said as a plan: meet each of the four teams on the next update, and ask each what it needs before a date is set. Never describe a past version of that plan. | Skeptic stem. The weakest-day-one answer is the coordination line in F2, not leadership framing. |

### E. Conversational / Rapport Builder (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in this order: the puzzle studio, the content calendar, the checklist, the retention numbers. Stop at the edge of what each quote states. | A casual opener that is still scored. The arc is your quotes in sequence. |
| E2 | "What are you playing right now, and what would you change about how it runs live?" | JD | [generic] | Name a real game you have played recently and one thing about its live running you would test first. If you have not played anything recently, say so. Do not invent a play history. | A casual question on the JD's live-operations topic, scored as content. |
| E3 | "How do you like to work with design and art on a drop?" | JD | [generic] Raising source: JD line "coordinate design, art, engineering and community teams on each update" | Say how you have actually worked with design and art on a drop, if you have, in your own words. If you have not, say that, and say how you would set up the first conversation. | An open prompt on F2's requirement. The honest branch is ready before the probe. |

### P. Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our design and art leads sit beside yours. Where is the seam, and what happens when you disagree about a drop?" | JD | [generic] Raising source: JD line "coordinate design, art, engineering and community teams on each update" | Propose seam principles, not a map you have not seen: who decides scope, who decides the date, who escalates. For the disagreement, pick one about a date or scope if you have one. If none comes to mind, say so, then say how you would handle one. | A peer seam probe. The honest branch is an answer slot, since your material carries no such disagreement. |
| P2 | "What would you need from our community team to run a drop well?" | JD | [generic] Raising source: JD line "community teams" | Name what you would need: what the community has been told and when, and what feedback they bring back. Then say what you would bring to their side and how you would keep it going. | Reciprocity framing. Makes no claim about your past. |
| P3 | "When a drop depends on four teams, how do you handle credit?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say which parts you wrote and which were QA's, in those terms. Hold only your share: you wrote the checklist, and QA still uses it. Do not claim the release itself. | A peer credit probe answered from the one artifact the material carries. |

## Persona table

| Persona | Looks like | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads the CV line by line, asks for denominators and counting methods | Flat, depth 3. Relationship unknown, and the CV-style lines invite a denominator probe. | Say what you can and cannot say about how each number was counted. Name the weakest assumption before they do. |
| Pressure / Stress | Interrupts, time-boxes, questions motive | Flat, depth 3. Leadership is the likeliest pressure line, so the most rehearsal goes here. | Pause, restate, hold through two follow-ups, then concede the specific gap. |
| Case / Strategist | Live problems from the role: plan a drop, diagnose a drop in retention | Flat, depth 3. The JD asks for coordination and metrics, which are case-shaped. | Clarify, then objective, approach, metrics and risks. Think aloud. |
| Skeptic | Quiet, persistent probing of the gaps | Flat, depth 3. Your note names two absences and the JD's live-service line is open. | Rehearse the leadership and live-service objections until they are plain. Bridges stay within what you stated. |
| Conversational / Rapport | Friendly, unstructured openers | Flat, depth 3. Casual questions on the JD topics are still scored. | A 90-second arc for the journey question. Treat casual JD questions as scored. |
| Peer Evaluator | Seams between teams, credit, disagreement | Flat, depth 3. The JD's coordination line makes a peer-style question plausible. | Propose seam principles. Keep credit to your own share. |
| Values / Behavioral | Scenario probes tied to published values | Not included. No loop source established a values round and no published values were read, so no VAL questions are written. | Not applicable in this pack. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, C3 |
| Coordinate design, art, engineering and community teams on each update | C1, E3, P1, P2 |
| Own the post-event review and the KPIs it reports | A2, B1 |
| Manage the release checklist with QA | A3, B3 |
| 3+ years producing live-service games or apps | D1 |
| Experience running a content calendar | A1, E1 |
| Comfortable with player-retention metrics | B1, C2 |
| Clear written communication | A2 (the written post-event report); no other question covers it |

## Reverse questions

Each has a one-line "why it lands." No interviewer profile was available, so none is tied to Tobias's career path.

1. "What does a successful post-event review look like here, and who reads it?" Why it lands: it shows you think the review is the owner's job, and it tells you what they expect from the KPIs.
2. "Which two titles does the calendar cover, and how do their release schedules differ?" Why it lands: it tests the scope line in F1 against the real job, and it shows you read the JD closely.
3. "How is QA involved before a drop goes out?" Why it lands: it ties the release checklist to the actual process, and the answer tells you how much the checklist matters here.
4. "What would the first ninety days look like for someone taking this on?" Why it lands: it asks for the job as they see it, and it prepares you for D3.
5. "Which retention number does the studio head look at first?" Why it lands: it connects F4 to what the business actually watches.
6. Reciprocity, because the relationship may be peer: "What could a new producer do in their first month that would genuinely help your team?" Why it lands: it turns the peer conversation toward what you bring.

## Sources

Provided documents: your note, which holds the JD text and your background. Your background is quoted as your message throughout.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section dropped). Query "Saltmarsh Games values" refused. |
| 2. Saltmarsh Games interview process, Live Operations Producer | unavailable | Loop structure, and whether a values round exists. Query "Saltmarsh Games interview process Live Operations Producer" refused. |
| 3. Saltmarsh Games strategy and recent news | unavailable | CO bank (no CO questions written). Query "Saltmarsh Games mobile studio strategy news" refused. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, and a reverse question tied to his path. Query "Tobias Wrenfield Saltmarsh Games Head of Live Operations" refused. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

Every search this session was refused by the host's permission setting. Nothing about Saltmarsh Games, its values, its loop, its strategy or Tobias Wrenfield is verified here. Those facts are absent, not assumed, and this pack does not state them.

## Upgrade menu

- Tobias's relationship to you (future manager, peer or other) → persona weights recomputed from flat, and a reverse question tied to his path.
- Saltmarsh's published values page, pasted → a values cheat sheet, and VAL questions with mapped stories. A values round is not detected until a loop source shows one.
- Saltmarsh's interview process, from the recruiter or a candidate guide → the real loop structure, and persona weights that follow the named rounds.
- Tobias's public profile or talks, pasted → the interviewer read, and a reverse question on his career path.
- Web search enabled for this session → the L1 research pass runs on values, interview process, strategy and Tobias's public footprint. A deeper pass, up to six more searches and two more fetches, takes several more minutes; say if you want it.
- A redacted copy of the release checklist → F5 moves from medium to high.
- A redacted copy of the content calendar → F1 and F7 move to high.
- The puzzle title's live-service status, and any post-event numbers you reported → F6 and the A2 answer slot.
- A recruiter's note on any take-home or presentation → a graded-deliverable section.
- A tuesday-dossier.md from an earlier session → verified evidence for the fit snapshot, and prohibited claims checked against the source.
