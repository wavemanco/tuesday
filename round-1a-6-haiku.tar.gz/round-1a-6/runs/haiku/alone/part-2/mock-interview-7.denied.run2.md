Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-denied-9ff32e95/a42a75bd-2f7c-448f-8cad-5cae94ea274a/scratchpad/Saltmarsh_Games_Live-Operations-Producer_interview_pack.md`.

Web search was not permitted in this session, so I could not check Saltmarsh's values, its interview process, or anything about Tobias. The values section therefore uses only the job description's own priorities, and I have not stated anything about the company that I could not verify. I built the pack for a hiring-manager round, since your note didn't say who you're meeting.

The pack's main findings:

- **Biggest gap:** the job says you will "own the post-event review and the KPIs it reports". Your material says you presented the monthly retention numbers. That is the question most likely to come up, so it has the deepest rehearsal (B1).
- **Two titles and four teams:** your calendar ran for one title, and your material doesn't show coordination with design, art or engineering. Both have honest answer slots (B2, B3).
- **Leadership and in-app purchases:** you named both gaps yourself. The pack gives you plain statements and a learning plan for each, and does not coach a past you didn't have (B4).
- **Interview plan:** section 11 of the pack lays out the 60 minutes block by block.

The pack will not coach any claim that you planned for two titles, owned the KPIs, led people or worked on monetization. The list is in section 5.

Would you like me to play the Skeptic on B1, the question the pack names as its highest-return prep? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or a peer on the team? The answer changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_Live-Operations-Producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Role: Live Operations Producer. Company: Saltmarsh Games (mobile, about 350 people). Interviewer: Tobias Wrenfield, Head of Live Operations. Length: 60 minutes, Friday. Relationship: assumed hiring-manager round (see Assumptions). Research: web search was not permitted this session, so nothing about Saltmarsh or Tobias is verified (see Sources).

## 1. Title block

Built on the job description and background you pasted. No regeneration yet.

## 2. How to use, and the type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: rehearse the beats, then say it in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment. Not used here: no published values were found. |
| EXP | Deep-dive on your own experience. Does what you did survive a follow-up? |
| JD | Can you do the listed job, gaps included? |
| CO | Company and strategy knowledge. Not used here: no research ran. |
| CASE | A live problem from the role, reasoned aloud. |

## 3. Assumptions

- Round: a hiring-manager interview. Tobias's title suggests this, but you have not told me, so persona weights are a prior.
- No deliverable (take-home, presentation) is declared. If one is, the pack needs a section for it.
- Your background is taken only from your message. Nothing was checked against a CV or a document.

## 4. Fit snapshot

Requirement quotes come from the job description you pasted. Evidence quotes come from your message. Everything the pack says about your past uses only these quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | presentation | Your material gives four years, two of them running the content-drop calendar, and says nothing about live-service in those words. Bridge, in your words: "For four years I was an associate producer at a puzzle-game studio, and for two of them I ran the weekly content-drop calendar for our main title." Answer slot: if the title's live-service status is a point they will press, say how it ran (a weekly drop cadence is your fact); if you are unsure how they will read it, say the cadence, not the label. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. The quote reaches the requirement directly. Lead with it in your words. Expect a probe on it. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [grounded] | transferability | Your material shows one title, not two, and a content-drop calendar rather than a live-events calendar. Bridge, at its own scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across more than one title, say what it was; if not, say so plainly, then say what you would carry from one calendar to two. |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Nothing in your material shows coordination with design, art, engineering or community. The QA checklist is adjacent, not the same. Answer slot: name the teams you coordinated with on an update, in your own words, and how it worked. If you mainly worked with QA, say so. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | transferability | Presenting numbers is not owning the KPIs or the review. Bridge, at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: say which numbers you chose, if any, and which you were given; if you did not set them, say so, and say which KPI you would own first. |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap. The quote reaches the requirement, and it is a named, current artifact. Lead with it. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Your material shows you presented retention monthly to the studio head. It does not show how the figure was counted. Bridge, reworded from the quote only: "I presented the monthly retention numbers to the studio head every month." Answer slot: if you know how the figure was counted, say so; if not, say you presented it and did not own the method. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote is writing, reaching the requirement in other terms. Bridge, reworded only: "I wrote the release checklist our QA team still uses." Do not add a document you did not write. |
| F9 | "3+ years producing live-service games or apps" and people leadership, flagged by you | "Never led a team" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't led a team." Then how you would learn it, said as a plan, never as a past. No slot, no claim of managing people. |
| F10 | Monetization, from the mobile titles' in-app purchase model, flagged by you (not in the job description) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan. |

Notes on the table: F9 and F10 are the two gaps you asked me to address. F9's requirement is not in the job description; it is the implied people side of coordinating four teams. F10's requirement is not in the job description either; it is a gap you named.

Gate check: the 3+ years live-service requirement is the only gate in the job description. The material shows four years and a weekly drop, so it reads as met. It is routed as presentation (F1), not hard_gate.

## 5. Prohibited claims

These will not be coached. Each one is an inflated or absent form of something above.

| Not coached | Basis | Honest form |
|---|---|---|
| "I planned the calendar for two titles" | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title." |
| "I owned the post-event review and its KPIs" | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." |
| "I coordinated design, art, engineering and community on updates" | Not in material; F4 is discovery | The answer slot in F4 only |
| "I have led or managed people" | Negative you stated, F9 | "I haven't led a team." |
| "I have worked on monetization or in-app purchases" | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." |
| "I can explain how the retention figure is counted" | Not in material; F7 | Answer slot in F7 only |

## 6. Interviewer read

Not included. No interviewer profile was found, because the search was refused. The persona weights below are the hiring-manager prior, not adjusted for Tobias.

## 7. Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on the calendar and a retention drop | High (40%). A hiring manager buys capability and reads for live problems on the real roadmap. | Structure first: what you check, in what order, and whom you pull in. Do not claim past cases. |
| Skeptic | Probes on the gaps: two titles, owning KPIs, four teams | High (30%). The gaps are visible in your message, so a hiring manager will test them. | Hold on your quote, then concede what it does not reach. |
| Data-Driven Prober | Asks how a figure was counted | Medium (20%). Retention is the one metric you presented, so it is the likeliest probe. | Say what you know, then say what you did not own. |
| Conversational | Rapport, motivation, the work you enjoy | Lower (10%). Scored less in a hiring-manager round, but it sets the tone. | Be specific about the calendar you ran. |

Pressure and Values personas are left out: this is not a skip-level round, and no values were found.

## 8. Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "One of your titles had a content drop that missed its retention target. Walk me through your first week on it." | CASE | [generic] | Structure: which metric and which cohort, what you check first (timing, funnel, what changed), who you bring in from design, art, engineering, community and QA, and what you hold back. Make no claim about your past. | Live problem from the post-event review and KPI line. [generic] because it is a pattern, not a fact about this studio. |
| A2 | "Plan the next six weeks of updates for one of our titles. What goes on the calendar, and who signs off on what?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Lay out the calendar in steps, with the dependencies: content, art, engineering, QA sign-off, community. Say where your own calendar work applies and where you would expect to learn. If you have done a step before, say so, in your words. | F2 is the evidence. The question asks for reasoning, not a record. |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns the post-event review and the KPIs it reports. You presented retention numbers. What did you decide about which numbers got reported?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Hold on the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or changed what was reported, say which and why; if the numbers were set for you, say so plainly and name the KPI you would own first. Hold through two follow-ups by returning to the quote. | F5 is the largest gap between the job and your material. The question assumes a decision you may not have made, so the second branch must be honest. |
| B2 | "You've run one title's calendar. Two titles is a different job. What breaks first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Name the first thing you expect to break, in your own view, then what you would do about it. Do not say you have run two. Answer slot: if you have planned across more than one title, say what it was; if not, say so. | F3 is the one-title quote. The premise is the job's, and the answer may say it is new. |
| B3 | "Four teams sign off on each update. Which of them have you coordinated with, and how did it work?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | The truthful version is the QA checklist, in those words. Answer slot: name the teams you coordinated with, in your own words; if QA was the main one, say so, and say how you would bring in the other three. | F4 is discovery. The second branch lets the premise be false. |
| B4 | "You haven't worked on a game with in-app purchases. How would you get up to speed?" | JD | [grounded] "I haven't worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: which people you would talk to, what you would read, what you would ask in the first month. No slot. | F10 is the candidate's stated absence. A plan is allowed; a past is not. |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your retention figures. How were they counted, and which part would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you know the definition, cohort and window, say them in your words. If you do not, say "I presented them; I didn't own the method," then name the part you would check first. Never invent a method. | Defend-the-number on the one metric you presented. F7 is the evidence. |
| C2 | "Which decision on that calendar was yours? Name one you would now change." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Name one decision that was yours, in your words, and what you would change. If the calendar decisions were mostly set by others, say so and name the part that was yours. | Attribution. Open prompt, with the calendar as its theme. |
| C3 | "You wrote the release checklist QA still uses. What did you put on it, and what did you take from QA?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say what you wrote and what changed since. Answer slot: if you took items from QA, say which; if you wrote it alone, say that. | F6 is the one clean quote. This probes attribution, which is the honest form. |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What do you like most about running a live title after it launches?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Speak from the calendar you ran: the weekly rhythm and what you learned from it. Keep it short and specific. | Rapport, and a chance to be specific about real work. |

## 9. Reverse questions

Each one has a reason it lands.

1. "How is the live-events calendar set today: who proposes an update, who approves it, and where do disagreements get settled?" Why it lands: it shows you are thinking about the process across four teams.
2. "For the two titles, what does a healthy month look like on the KPIs the post-event review reports?" Why it lands: it frames KPI ownership as a question, not a claim.
3. "Who owns the release checklist today, and how has it changed since QA's last revision?" Why it lands: it tests whether they want you to own it.
4. "Which monetization decisions on these titles are settled and which are still open?" Why it lands: it shows you know the gap and want to learn it.
5. "What would make you say the first ninety days went well?" Why it lands: it gets the success criteria in their words.

No reciprocity question: the interviewer is not a peer. None is tied to Tobias's own path, because no profile was found.

## 10. Values alignment

Not established. No Saltmarsh values were found, so there is no values map. The job description's own priorities are: coordination across four teams, retention KPIs, a content calendar, and written communication. These are the job's priorities, not the company's published values. Paste the values page and I will build the map from your quotes.

## 11. 60-minute interview plan

| Minutes | What | Where |
|---|---|---|
| 0 to 5 | Introductions, and your two-sentence walk-through of the content-drop calendar | D1 |
| 5 to 20 | The live problem: the retention drop and your first week | A1 |
| 20 to 35 | The three job probes: KPIs, two titles, four teams | B1, B2, B3 |
| 35 to 45 | Metric and attribution probes | C1, C2, C3 |
| 45 to 52 | Your gaps, said plainly, with a plan | B4, F9 (leadership) |
| 52 to 60 | Your questions (pick three from section 9), then close | Section 9 |

The buffer is inside the last block. If they run long on the case, drop C2.

## 12. Sources

Searches sent (all refused, because web search permission was not granted this session):

- `Saltmarsh Games mobile studio values`: refused
- `Saltmarsh Games live operations producer interview`: refused
- `Tobias Wrenfield Head of Live Operations Saltmarsh Games`: refused

Provided documents: the job description and the background in your message. No dossier was consumed.

Research tier: L1, searches 0 of 6 (3 sent, all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | The values cheat sheet (section 10) would have mapped values to your quotes. Section 10 is therefore the JD's priorities only. |
| 2. Saltmarsh interview process, production | unavailable | Loop structure. Persona weights are the hiring-manager prior. |
| 3. Saltmarsh strategy and recent news | unavailable | The CO questions. No call was sent, and no strategy brief was given. |
| 4. Tobias Wrenfield with Saltmarsh | unavailable | The interviewer read and a tailored reverse question. |
| 5. Representative JD | skipped | The job description you pasted fixes the fit snapshot. |

## 13. Upgrade menu

- Round type and relationship (one question in the message) → tuned persona weights, and whether a take-home or presentation applies.
- Saltmarsh's published values, pasted → the values cheat sheet, and VAL questions with mapped stories.
- Web search permitted, or a pasted strategy brief → verified company context and CO questions.
- Tobias's public profile or talks, pasted → an interviewer read and a reverse question tied to Tobias's own path.
- Deeper research, offered once: a strategy brief, Tobias's talks and writing, loop reports for this role family, and recent company news. Caps: 6 more searches and 2 more fetches. Time cost: a few minutes if permitted.
- The interview's loop structure, if you know it → persona weights per round.
