Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-3-denied-aaaf53cb/250693bc-b656-4a17-9795-7e764ce206ed/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it on a generic final round with an unknown interviewer, since you haven't shared a job description, a CV, or who you're meeting.

Two things limit it:

- **Web search was refused in this session**, so the pack has no Stripe values, no current strategy, and no confirmed interview structure. I didn't fill those from memory. Once search is allowed, I can build them in.
- **Nothing about your past is in it yet.** Every answer is a scaffold you fill in, not a story I wrote for you.

If you rehearse only one thing, make it B1: "Which part of this role would you be weakest at on day one?" It's the most direct version of the fit test a final round runs, and you're the only one who can name your real weakest area.

I can also run a live drill on any question, with the interviewer's follow-ups reacting to what you say. And I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you want a Word version of the pack, say so and I'll convert it.

Who is the final round with, and what's their relationship to the role (hiring manager, peer, senior leader, cross-functional partner)? Is it one session or several?

Could you paste the job description and your CV, or a few lines on your background? If you'd rather not, I'll keep going without them and the pack stays generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Interviewer: not named. Round: final, relationship not stated.

Built on: a generic final round with an unknown interviewer, no job description, no CV or background notes, and no web research (search permission was refused in this session). Everything about the candidate's past is therefore an answer slot or a selection scaffold, not a story. Company values, loop structure and current strategy are absent, not guessed.

## How to use this pack

Personas describe how a question will arrive. Types describe what is being scored.

- CASE: a live problem from the role, solved aloud.
- JD: a requirement the role is expected to meet.
- EXP: a question about what you actually did.
- VAL: a question about how you behave, asked as a story prompt.
- CO: company and strategy knowledge. None in this pack, because research did not run.

The guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

No job description and no background were supplied, so no requirement is quoted and no evidence is quoted. The requirements below are role-family prose from this skill's own knowledge of product operations roles. They are not quotes from Stripe.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running a cross-functional operating cadence, such as planning, reviews and priorities (role family) | none given | none | [generic] | discovery | Answer slot: describe one operating rhythm you set up or ran. Say what you did and what you did not do. If you have not run one, say so and say how you would learn to. |
| F2 | Using metrics to make operational decisions, and checking the data before trusting it (role family) | none given | none | [generic] | discovery | Answer slot: name one decision you made from a metric, and the assumption you checked first. If none, say so and say how you would set up the check. |
| F3 | Designing or changing a process, and seeing whether it held (role family) | none given | none | [generic] | discovery | Answer slot: name one process you changed and how you knew it worked. If you never measured it, say so. |
| F4 | Working across product, finance, sales and support on a shared decision (role family) | none given | none | [generic] | discovery | Answer slot: name one decision that needed two or more of those teams and what your part in it was. If there was no such decision, say so. |
| F5 | Running a launch or rollout, including the cases where it slips (role family) | none given | none | [generic] | discovery | Answer slot: name one rollout you were part of, what slipped, and what you did in the first 48 hours. If none, say so and describe how you would run one. |

Gate rows: none. No JD was supplied, so no requirement is known to be a gate.

## Persona weights

| Persona | Weight and questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Top, 4 | Live problems on launches, metrics and tooling | High. A final round for an operations role usually tests how you reason on a live problem | Clarify, then structure, then answer. Think aloud. Name one premise you would challenge |
| Skeptic | 3 | Quiet probing of the gap and the motivation | Medium-high. Finals test whether the story survives a second look | Rehearse the one predictable objection until it is calm. Concede specifically |
| Data-Driven Prober | 3 | Asks for how a number was counted | Medium. Depends on whether you bring numbers | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know |
| Values / Behavioral | 3 | Story prompts about process and judgement | Medium. Stripe's published values are not in this pack, so the questions are generic | Story-shaped answers, with "we" for context and "I" for your part |
| Conversational | 2 | A casual opener that is still scored | Medium. Often the first two minutes | A 90-second arc you can say without notes |
| Pressure | 2 | Time-boxed challenge to a position | Low-medium. More common in senior finals | Hold the position through two follow-ups. Concede only what is actually uncertain |

Weights are flat because the relationship is unknown. A hiring manager would tilt toward Case and Skeptic. A peer would tilt toward Prober and a seam question.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch slipped three weeks, and finance is asking why. What do you do in the first 48 hours?" | CASE | [generic] | Clarify what slipped and which dependency caused it. Name the owner of each dependency. Find out what finance actually needs: a date, a cost or a decision. Then give options, a decision owner and one message. About 90 seconds | Live rollout problem, the most likely case in this role. Carries no claim about you |
| A2 | "A key metric dropped 20 percent week over week. Walk me through the diagnosis." | CASE | [generic] | Clarify the metric definition first. Check whether instrumentation or the data pipeline changed. Segment by region, plan or channel. Separate real change from measurement change. Then recommend one action. Weakest-assumption move: say which data assumption you would test before trusting the chart | Metric diagnosis is the standard operations case. Carries no claim about you |
| A3 | "You have one quarter and a small tooling budget. What do you build first, and what do you drop?" | CASE | [generic] | Criteria before choices: how often the pain happens, who is blocked, what delay costs, and how reversible the fix is. Pick one. Name what you would drop and why | Tests prioritization under constraint. Carries no claim about you |
| A4 | "A new process was rolled out, and three weeks later nobody uses it. What now?" | CASE | [generic] | Separate three possible causes: the design, the adoption path, or the incentive. Talk to two or three users before changing anything. Decide what to keep, what to change and what to stop | Adoption failure is common in operations work. Carries no claim about you |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed a process decision against resistance. How did it end?" | VAL | [generic] | Selection scaffold: pick a time you held a process decision against pushback. It needs a named stake, what you did, and how it ended, including if it went badly. If no such time comes to mind, say so plainly, then give the nearest thing you have and how you would handle it | Open prompt on judgement under pushback. The guidance makes no claim about your past |
| C2 | "Describe a process you changed that people still use. How did you know it worked?" | EXP | [generic] | Selection scaffold: name the process, your part in it, and how you checked it. Answer slot: if you measured it, say what you counted. If you did not measure it, say so | Tests whether a process change was yours and whether it was checked. The guidance makes no claim about your past |
| C3 | "Tell me about a rollout you got wrong." | VAL | [generic] | Selection scaffold: pick a real miss. Say what you expected, what happened, what you changed afterwards, and what you would do next time. Do not pick a miss you turned into a win | Tests honest self-assessment under a behavioral frame. The guidance makes no claim about your past |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI prep in this pack. Name the weakest area honestly. Then say how you would close it in the first 30 days. Hold the answer through two follow-ups by returning to the same area. Concede the specific gap, not the whole candidacy. Answer slot: you must name the area yourself; the pack cannot name it without your background | Final-round interviewers test fit, and this question is the most direct form of that test. Without your CV the objection cannot be targeted, so you are the source of the answer |
| B2 | "Why this role, and why now?" | JD | [generic] | Give one reason tied to something specific the role does, and one reason from your own work. Do not praise the company without a specific reason. If you have a reason for leaving your current role, give the reason in your own words | Motivation is probed in every final. The guidance makes no claim about your past |
| B3 | "Why operations rather than product management?" | JD | [generic] | State the reason from your own path, in one sentence. If you have not thought about it, say that and then say what you would want to learn | Tests whether the move is a choice or a retreat. The guidance makes no claim about your past |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How would you measure success in this role's first quarter?" | JD | [generic] | Name two or three measures, the inputs behind each, and the denominator for any rate. Weakest-assumption move: name the assumption behind the measure you would defend least, before the interviewer does | Tests whether you can define success, not only recite a metric. The guidance makes no claim about your past |
| P2 | "Pick a number you are proud of from your past work. Walk me through how it was counted." | EXP | [generic] | Answer slot: say which number you chose, how it was counted, which part was yours, and which assumption you would defend least. If you do not know how it was counted, say so plainly. Do not reconstruct a method you cannot repeat under a second question | Numbers are where probers go. The guidance makes no claim about your past |
| P3 | "What number would you check before presenting it to leadership?" | CASE | [generic] | Pick one number from your work or from a hypothetical. Say what would make it misleading. Say what you would check first | Tests whether you distrust your own data. The guidance makes no claim about your past |
| P4 | "What is a metric that looks good and misleads?" | CASE | [generic] | Give one general example, and say how you would catch it. If you have a real example, use it in your own words. If you do not, do not invent one | Tests metric judgement. The guidance makes no claim about your past |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, the through-line, the move to this role. Say only what you will stand behind. Rehearse it aloud until it runs in about 90 seconds | Casual openers are scored. The guidance makes no claim about your past |
| D2 | "What have you been reading or working on lately that's relevant to this work?" | JD | [generic] | Name one real thing and say what you took from it. If nothing comes to mind, say so rather than improvising a source | Tests genuine interest, asked casually. The guidance makes no claim about your past |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Give one reason. Restate the question in your own words. Hold the reason through two follow-ups. Concede a specific uncertainty if there is one, never the whole candidacy | Composure under a time box. The guidance makes no claim about your past |
| E2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Pick one result. Say what was yours and what was the team's. Hold the split through two follow-ups. Concede where the credit was shared, without folding on your own part | Tests attribution under pressure. The guidance makes no claim about your past |

## Reverse questions

No interviewer profile exists, so these are role-generic. Each one signals that you prepared for this role, not only for this company.

1. "What does success look like for this role at six months?" Why it lands: it turns a final into a planning conversation.
2. "Which decision does this role most often move, and who makes the call?" Why it lands: it shows you understand where ops sits relative to product and finance.
3. "What is the hardest tradeoff the team is working through right now?" Why it lands: it asks for the live problem without assuming you know it.
4. "What did the last person in this role do that you most want more of?" Why it lands: it reveals what the team values in practice.
5. "What happens after this round, and is there a deliverable or a second conversation?" Why it lands: it shows you are planning your own next step, not only waiting.

## Prohibited claims

Built locally, because no dossier was supplied and no background was given. Each entry is a claim candidates reach for under pressure in operations rounds. None is a quote from you, so none is a finding about your history.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the process end to end" | Generic pressure claim in ops rounds. No quote from you supports it | Answer slot F3: name the part of the process that was yours, in your own words |
| "I built the metric framework" | Generic pressure claim in ops rounds. No quote from you supports it | Answer slot F2: name the metric you actually used, or say you did not set one |
| "I have run a launch at this company's scale" | Generic. No scale was given | Say the scale you actually ran, in your own words |

## Sources

- Provided documents: the user's message only. No job description, CV, interviewer profile, recruiter note or dossier.
- Searches: "Stripe company values principles" (refused, permission not granted). "Stripe Product Operations Manager interview process final round" (refused, permission not granted).
- Fetches: none.

Research tier: L1, searches 0 of 6, fetches 0 of 2. The host refused search.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10. Dropped, since no published values are in hand |
| 2. Stripe interview process, product operations | unavailable | Loop structure, persona weights. Flat weights used instead |
| 3. Stripe strategy and recent news | unavailable | Company and strategy questions (CO type). None written |
| 4. Interviewer name and Stripe | n/a | No name given, so no query could be formed |
| 5. Representative Product Operations Manager JD | unavailable | JD-tagged questions and the requirement-coverage table. Role-family requirements used instead, labeled [generic] |

## Upgrade menu

- The job description → fit snapshot rows become quoted requirements, the requirement-coverage table appears, and JD-tagged questions are tied to the posting's own words
- Your CV or background notes → each fit snapshot row gets a quoted evidence cell, and selection scaffolds become story-mapped answers
- The round format and who you are meeting → persona weights are set to that relationship, and reverse questions are tailored
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Search permission → the values cheat sheet, the company and strategy questions and the representative JD can be built
- The recruiter's prep email → any pre-declared deliverable or focus area gets its own section
- Prep time available → a prioritized schedule for the time you have
