I'll load the interview-prep skill, since this is a recruiter screen.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-13-denied-d5b9253d/9b57b603-9703-479a-ab73-ae03032ecb4a/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It covers the fit gaps, prohibited claims, question banks, reverse questions and sources.

The short version for Thursday:

- **Pay:** "I'm looking for around £42,000." Then stop. If she asks about your current salary, decline without a figure.
- **Hybrid:** "Two days at Avonmouth is fine. I live in north Bristol. I wouldn't want more than three."
- **Why you're moving:** "Our Bristol office is closing next year. The only offer I've had is relocating to Reading, which I don't want to do." Then stop.
- **Biggest objection (production and QA):** you've never scheduled production or worked with QA. Name that first, then your closest real work (depot scheduling and supplier chasing), then how you'd learn it. Don't claim the production or QA work.
- **SAP:** "I haven't used SAP. We run our own in-house stock system." Don't call the in-house system an ERP.
- **Stock result:** say the third-off figure once, then say what you personally built and what the team did. Have an honest split ready.

I didn't run any web research on Quillmoor. The search permission was refused, so everything above comes from your message, the advert and your background.

Your notice period isn't in what you gave me, and it's the one number she'll certainly ask for.

Would you like me to play Hannah's pressure questions as a live rehearsal? The production and QA objection gets the most practice time.

Do you want me to save a `tuesday-dossier.md` recording these gaps, so you can carry them into later sessions?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** 30-minute phone screen with Hannah Lowther, Talent Partner (recruiter). Thursday, 2pm. She will call the mobile number on your application.
**Her agenda (her words):** salary expectations, notice period, how the hybrid pattern would work, what's prompting a move. Then the team and next steps.

## 1. How to use + type key

- **Personas** = how a question is asked. **Types** = what is being scored.
- **VAL**: behavioural / values alignment
- **EXP**: work-experience deep-dive (does your CV survive scrutiny)
- **JD**: role and job-description driven (can you do the listed job, gaps included)
- **CO**: company and strategy knowledge (not scored in this screen, so no questions here)
- **CASE**: live problem (not used in a recruiter screen)

Pay, notice and location questions are not a scored type. They are tagged JD here, the nearest fit, because they test the role's stated terms.

Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

## 2. Prep triage

No prep time was stated, so this is the full pack. In order:

1. Salary and notice period: have the figures ready and say them once, clearly. (A1, A3, C1)
2. The closing-office reason: one clean sentence in your own words. (A5, B4)
3. The production and QA gap: the most likely objection to you. Rehearse it aloud until it is short. (B1)
4. The SAP gap and the weekly dispatch report. (B2, C2)

Everything else is insurance.

## 3. Fit snapshot

Confidence: high, medium, low, none. Provenance: [grounded], [inferred] or [generic]. Gap type: one of none, presentation, transferability, discovery, capability, hard_gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your CV) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling and not QA. Bridge: "I schedule deliveries across three depots, so I'm used to fitting timings between sites." Answer slot: describe one clash between two parties who wanted different things and what you did about it. Say plainly that you have not scheduled production or worked alongside QA. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your CV) | high | [grounded] | none | Direct match. Lead with the quote. Expect a probe on how you chase. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" and "discrepancies fell by about a third over a year" (your CV) | high | [grounded] | none | Direct match, but a result with credit attached, so expect an attribution probe (see B3 and P3). |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [generic] | discovery | No evidence in the material. Answer slot: have you produced a regular report that others acted on? If so, what did it track? If not, say so and say how you would learn the dispatch measures. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your CV) | medium | [grounded] | presentation | The spreadsheet work is real, but the level is not stated. Name the functions you used in the rebuild, if any. If it was a simple build, say so. Do not inflate it. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP. We run our own in-house stock system." (your message) | high | [grounded] | capability | A gap that wording cannot close, and you have said so. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn SAP, said as a plan. Do not call the in-house system an ERP. |
| F7 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your CV) | high | [grounded] | none | Met. |
| F8 | "two days a week at our Avonmouth site" (advert) | "2 days is fine, but I wouldn't want more than three" and "I live in north Bristol" (your message) | high | [grounded] | none | Met within your limit. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advertised band. |
| F10 | Notice period (not in the advert; she will ask) | none given | none | [generic] | hard_gate | The material does not settle this. The question that matters is what your notice period is. See the questions at the end of this message. |

**Routing note:** F4 and F10 are the two rows with no quote behind them. They are answer slots, not claims.

## 4. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. The pack does not coach any of them.

| # | Claim not to make | Basis | Honest form |
|---|---|---|---|
| P1 | Any SAP or ERP experience | "Never used SAP" (your message) | "I haven't used SAP." |
| P2 | Production scheduling, a manufacturing line, or working with QA | Your CV covers depot deliveries and suppliers | "I schedule deliveries and chase suppliers. I haven't scheduled production." |
| P3 | That you alone cut discrepancies by a third | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | "I rebuilt the spreadsheet, and discrepancies fell about a third over the year." Then say what your share was and what others did. |
| P4 | Experience producing weekly on-time dispatch reporting | No quote in the material | No claim. Use the F4 answer slot. |
| P5 | Your current salary | Not given | "I'd rather not share my current figure. I'm looking for around £42,000." |
| P6 | Any reason for leaving beyond the one you gave | "Our Bristol office is closing next year... the only offer is relocating to Reading, which I don't want" (your message) | Your own words, unchanged. Do not add a family, commuting or lifestyle reason unless it is true and you choose to give it. |

## 5. Question banks

Persona weights for a recruiter screen: **Screener** (the recruiter checking pay, notice, hybrid and motivation) is high, and her stated agenda drives the first 15 minutes. **Pressure** (follow-ups on Reading, on the figure, on SAP) is medium-high. **Skeptic** (JD probes passed on from the hiring team) is medium.

### Persona A: Screener (high weight)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD (nearest) | [grounded]: "I'm hoping for £42,000" (your message) | "I'm looking for around £42,000." Then stop. | The figure sits in the middle of the advert's band. A short answer with no justification is the cleanest. Any follow-up gets the same words again. |
| A2 | "What's your notice period?" | JD (nearest) | [generic]: no quote. Answer slot. | "My notice period is [your figure]." Then the earliest start date that follows from it. | This is the gap she will ask about. Say the real figure. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded]: "2 days is fine, but I wouldn't want more than three" and "I live in north Bristol" (your message) | "Two days at Avonmouth is fine. I live in north Bristol. I wouldn't want more than three." | Your stated limit is the answer. Do not offer a fourth day. |
| A4 | "What's prompting the move?" | JD (nearest) | [grounded]: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | "Our Bristol office is closing next year. The only offer I've had is relocating to Reading, which I don't want to do." Then stop. | The shortest true version of your reason, in your words. Adding detail invites a follow-up you have not prepared for. |
| A5 | "Walk me through your background." | EXP | [grounded]: "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip" (your CV) | Open with the four years. Then the depots. Then the supplier chasing. Keep it to 90 seconds. | The strongest direct matches come first. |
| A6 | "Tell me about improving stock accuracy." | JD | [grounded]: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your CV) | "I rebuilt our stock-count spreadsheet. Over the year, discrepancies fell by about a third." Then say what you specifically built and what the team did. | This is F3. Say the result once, then your part. |

### Persona B: Pressure (medium-high weight)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production and QA, and you've not worked in either. Why should we consider you?" | JD | [grounded]: "I schedule deliveries for our three depots"; "I chase suppliers when orders slip" (your CV) | "The supplier side of production planning is what I do: I schedule deliveries across three depots and chase suppliers when orders slip. I haven't scheduled production or worked alongside QA. I'd want to learn how planning and QA set a production slot, and I'd start by shadowing that meeting." | The single most likely objection to you, so this gets the deepest rehearsal. Name the gap first, then the closest real work, then the plan. Do not claim the production or QA work (P2). Rehearse it aloud until it is under 90 seconds. |
| B2 | "SAP is a plus. You don't have it. How would you manage?" | JD | [grounded]: "Never used SAP. We run our own in-house stock system." (your message) | "I haven't used SAP. We run our own in-house stock system. I'd expect to learn the stock and purchasing screens quickly, and I'd ask for training in the first weeks." | Keep the answer a plan, not a past. Do not call the in-house system an ERP (P1). |
| B3 | "How much of the one-third drop was actually you?" | EXP | [grounded]: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your CV) | Name what you built, then what others did with it. "I rebuilt the spreadsheet. I can't split the drop exactly, but the team used it through the year." Use your own honest split. | This is the attribution probe. The answer has to be honest, even if your share is smaller than the headline. |
| B4 | "Would you move to Reading?" | JD | [grounded]: "which I don't want" (your message) | "No. That's why I'm looking." | Short and true. Do not explain further unless asked. |

### Persona C: Skeptic (medium weight)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your current salary?" | JD (nearest) | No candidate quote. Decline. | "I'd rather not share my current figure. I'm looking for around £42,000." | You are not required to answer. Decline without a figure (P5). |
| C2 | "Have you produced a weekly report that others acted on?" | JD | [generic]: no quote. Answer slot. | If yes: describe the report and what it tracked. If no: "I haven't produced a regular report of that kind. Here's what I'd track first: on-time dispatch by week, and the reasons for misses." | This is F4. Say honestly which branch you are on. |

## 6. Reverse questions

Use two or three of these. Ask them after she covers the team and next steps.

| ID | Question | Why it lands |
|---|---|---|
| R1 | "How is the weekly on-time dispatch figure reviewed, and who acts on it?" | Shows you think about the metric the role owns, and tells you whether the report leads to action or sits on a shelf. |
| R2 | "Which systems does the team use for production planning and stock, and where does SAP come in day to day?" | Tests the SAP gap directly and shows where any training would happen. |
| R3 | "When planning, the warehouse and QA disagree about a production slot, how is that usually settled?" | Probes the production and QA gap in terms she can answer, and shows you know that gap matters. |
| R4 | "Are the two office days fixed, or agreed with the manager?" | Checks the hybrid pattern against your stated limit of three days. |
| R5 | "What's the timeline from here, and who would I meet next?" | Gets the next steps in concrete terms, without repeating what she has already said. |

## 7. Sources

- **Provided documents:** the recruiter's LinkedIn message (pasted), the advert (pasted), your background (pasted).
- **Research tier:** L0 in effect. A web search for Quillmoor Diagnostics was attempted and the host refused the permission, so no search ran.
- **Target accounting:**
  - Company values, loop structure and current strategy: unavailable (search permission refused).
  - Representative JD: skipped (the advert was supplied).
  - Interviewer footprint: n/a (no interviewer profile supplied beyond her name and role).

## 8. Upgrade menu

- A web search on Quillmoor (once search is approved) → a check on their production and QA set-up and any recent Avonmouth news, which could sharpen B1 and R3.
- Your notice period → A2 becomes a stated answer, not a slot.
- The recruiter's prep email, if she sends one → coverage of any pre-declared deliverable.
- Hannah's public profile text, if you paste it → a reverse question tied to her career path.
