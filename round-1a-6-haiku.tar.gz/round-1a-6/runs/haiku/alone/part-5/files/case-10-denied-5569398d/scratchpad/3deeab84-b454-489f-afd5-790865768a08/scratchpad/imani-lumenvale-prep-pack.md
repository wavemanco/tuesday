# Interview prep pack: Imani, Customer Support Specialist, Lumenvale Software

**Built on:** the job-ad summary and background you gave me. No company research was run, so nothing here describes Lumenvale's tools, values or process. Tier L0 (provided material only).

## 1. Fit snapshot

| Requirement (job ad) | Your evidence (quoted) | Gap type | Confidence | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" [provided] | none | high | State it directly. |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" [provided] | tool | high | "I haven't used Zendesk. I use Freshdesk every day, and I expect the core ideas, such as tickets, queues and macros, to carry over. I'd learn its specifics quickly." |
| Clear written communication | "answering around 60 calls and emails a day" [provided, partial: the email volume is the only written evidence] | evidence | medium | Answer slot: describe one written reply you wrote and why it worked. |
| Confidence handling escalations | No quoted sentence about escalations. "trained four new starters on our refunds process last year" [provided, related but not an escalation] | evidence | low | Answer slot: use a real escalation you handled, with what you checked first and who you passed it to. |
| No software-company experience (not in the ad, but likely to come up) | "I've never worked for a software company" [provided] | domain | high | "I haven't worked in software. What I bring is the customer side of a service people depend on, handled at volume." |

## 2. Prohibited claims

These are not to be coached, suggested or implied in any answer:
- Any Zendesk experience, including "familiar with Zendesk". Basis: your background lists Freshdesk only.
- Any software or SaaS product knowledge or experience. Basis: "I've never worked for a software company."
- Any escalation you did not personally handle or own. Basis: no escalation sentence in your material.
- Any ticket volume above "around 60 calls and emails a day". Basis: your stated figure.
- Any training beyond "four new starters on our refunds process". Basis: your stated figure.

## 3. Interviewer read

No interviewer profile was provided. The team lead's name, role and background are unknown, so this section is generic.

## 4. Persona weights

- **Support team lead** (about 60%): a chat round with the person who would manage you is likely to test practical fit: process, escalations, tools.
- **Skeptic** (about 25%): the Zendesk and software gaps are the obvious places to probe.
- **Written-communication evaluator** (about 15%): the round is text-only, so your written replies are the evidence.

## 5. Question banks

**Team lead (process and tools)**

1. *Walk me through how you handle a ticket from first message to close.* Type: process. Provenance: [provided] "I use Freshdesk every day." Guidance: intake, triage, first reply, follow-up, close. Keep to steps you actually take.
2. *Tell me about an escalation you handled. What did you check before escalating?* Type: escalation. Provenance: [generic] no escalation sentence in your material; answer from your own experience. Guidance: a real case, what you checked, who you escalated to, what you told the customer.
3. *You trained four new starters on refunds. How did you do it?* Type: teaching. Provenance: [provided] "trained four new starters on our refunds process last year." Guidance: method, what you covered, how you checked understanding. Do not claim outcomes you don't know.
4. *What tools have you used, and how do you learn a new one?* Type: tooling. Provenance: [provided] "I use Freshdesk every day." Guidance: describe Freshdesk specifically. On Zendesk, say you haven't used it and describe how you'd learn it in your first week.

**Skeptic (gap probing; deepest rehearsal here)**

5. *Our team uses Zendesk, and you haven't used it. Why should we hire you?* Type: objection, the highest-return item in this pack. Provenance: [provided] "I use Freshdesk every day." Guidance: hold, then concede. Acknowledge the gap plainly, then bridge: daily Freshdesk use, the shared ticket concepts, and a concrete first-week plan (docs, a sandbox if offered). Do not say the gap is "no problem."
6. *You've never worked for a software company. What makes you think you'd adapt?* Type: domain gap. Provenance: [provided] "I've never worked for a software company." Guidance: concede, then name what transfers: volume handling, customer communication, process knowledge. Do not claim software knowledge.

**Written-communication evaluator (the chat itself)**

7. *A customer writes that their order is late and they are angry. Reply to them here.* Type: written communication. Provenance: [generic] no candidate sentence; answer slot. Guidance: acknowledge, state one specific next action, give only a timeframe you can commit to, and invent no policy.

## 6. Reverse questions

Asked of the interviewer, about the role. Each lands because it shows you are thinking about the job.

- *What does a typical escalation look like here, and who owns it once it leaves support?* Why it lands: shows you understand escalations are where the job gets hard.
- *Which ticketing tool does the team use, and how are new starters trained on it?* Why it lands: it turns the Zendesk gap into a question about onboarding.
- *What does a good first 30 days look like in this role?* Why it lands: it signals that you plan to ramp up quickly.

## 7. Telegram-specific notes

- Keep replies short and structured, since the format is chat and your written replies are being assessed.
- Ask for time if you need it, rather than replying in a hurry.
- If the round includes a live written task, draft in a notes app and paste, so you can check spelling and tone.
- Save the transcript of the interview.
- Do not send ID, bank or tax details in chat, at any stage.

## 8. Upgrade menu

- **Full job-ad text:** I can check each requirement against the exact wording and tighten the fit snapshot.
- **Verification results:** if you find the company's official site or the careers page listing, paste what they say and I'll update the pack.
- **Deeper research (L2, optional):** company values, the tools it uses, and recent org context. This costs more time.
- **Interviewer details:** the team lead's name and title, if you can confirm them publicly.
- **A written sample:** an anonymised reply you wrote, so I can check the written-communication answers against it.
