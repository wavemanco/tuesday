# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager. Relationship: office manager; whether they would be your line manager is not stated.
**Built on:** the ad as you summarised it, the invite text you pasted, and your background message. No job description or CV was pasted, so the pack is shorter than a usual session pack and sized for a 30-minute call.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **EXP**: what you actually did
- **JD**: the listed duties and tools
- **CASE**: a live problem from the job
- **VAL**: values (not detected here, so none included)
- **CO**: company knowledge (no research run, so none included)

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: answer it from your own experience, in your own words.

## Fit snapshot

Requirements are your summary of the ad, so they are not quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (ad, as summarised) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words say the appointment book for four physios. Say it in those terms: "I ran the appointment book for four physios." |
| F2 | Booking travel (ad, as summarised) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what, for whom, and how you handled a change. If not, say so plainly and say how you would learn the booking tools. |
| F3 | Preparing documents in Word (ad, as summarised) | "good with Word" — your message | medium | [grounded] | none | Self-rated. Lead with the quote's own terms: "I'm good with Word." Expect a probe to test it. |
| F4 | Excel (ad, as summarised) | "okay with Excel" — your message | low | [grounded] | discovery | Your words are "okay with Excel". Answer slot: if you have built formulas or a table for a task, name them. If not, say so plainly and say what you would learn first. |
| F5 | Processing supplier invoices (ad, as summarised) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing payment is adjacent to processing, not the same work. Say: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say which and how. If you only chased payment, say so and say how you would learn the processing steps. |
| F6 | Remote working (job title) | none given | none | [grounded] | discovery | Answer slot: if you have worked remotely with a calendar and document tools, say how. If not, say so plainly and say how you would structure your day. |

## Prohibited claims

Not coached, and why. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for four physios | Inflated form of F1: your material says the appointment book | "I ran the appointment book for four physios." |
| Processed supplier invoices | Inflated form of F5: your material says you chased unpaid invoices | "I chased unpaid invoices." |
| Expert in Excel | Inflated form of F4: your material says "okay" | "I'm okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Office manager (prober) | Asks for your daily work in specifics, and what you did yourself | High. A 30-minute call with the person who runs admin tests day-to-day tasks | Describe what you did in your quote's terms. Say where your experience stops |
| Skeptic on gaps | Goes straight to the duties you have not shown (invoices, travel) | Medium-high. F2, F4 and F5 are the gaps the ad leaves open | Name the limit once, then say how you would learn it. Do not stretch the quote to cover it |

## Question banks

### Office manager (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" — your message | Story-mapped on F1: the appointment book, the four physios. Tell it in your own words. Answer slot: if you set the rules for how the book was booked, say what they were. If the physios set their own, say so plainly and describe how you kept the book | F1 is your strongest calendar evidence and the likeliest place to be probed; EXP tests what you did |
| A2 | "Have you booked travel for anyone?" | JD | [generic] | Answer slot: if you have, say what, for whom, and how you handled a change. If not, say so plainly and say how you would learn the booking tools | F2 is a discovery gap; the answer should be ready before the probe |
| A3 | "A senior colleague's flight is cancelled the morning of a meeting abroad. What do you do?" | CASE | [generic] | Structure it: check alternative flights and times, tell the colleague first, rebook, and confirm the meeting. The question needs no claim about your past | A live problem from the travel duty; asked as a decision, not a record |
| A4 | "What have you used Word for?" | JD | [grounded] "good with Word" — your message | Name the documents you produced in your own terms. Answer slot: if you used templates or styles, say so. If not, say so plainly | F3 is your strongest tool evidence; the question asks you to choose the instance |
| A5 | "How would you describe your Excel level?" | JD | [grounded] "okay with Excel" — your message | Say "okay" truthfully and name the most complex thing you have done, if anything. Answer slot: if you built formulas or a table, name them. If not, say what you would learn first | F4 is low confidence; this is the honest version of the answer |

### Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's your experience with supplier invoices?" | JD | [grounded] "chased unpaid invoices" — your message | **Highest-ROI prep in this pack.** Start with the quote: "I chased unpaid invoices." Then say what chasing involved, in your words. Answer slot: if you entered, matched or approved invoices, say which and how. If you only chased payment, say so plainly and say how you would learn the processing steps. Hold through two follow-ups by returning to the quote, not by adding to it | F5 is the largest gap against the ad's duties, so expect this in some form. The honest answer is a limit, and the limit is what gets tested |
| B2 | "Which part of this job would you be least confident in on day one?" | JD | [generic] | Name the gap in one sentence (travel or invoices, from F2 and F5), then say how you would close it in the first two weeks | A self-assessment probe; the answer must match the fit snapshot |
| B3 | "Two people book the same meeting room at the same time. What do you do?" | CASE | [generic] | Structure: check the booking order, talk to both, decide by a stated rule, and record it. No claim about your past | A live calendar problem from the first duty in the ad |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical first month look like, and which tasks would I start with?" | Shows you want the real split of calendars, travel and invoices |
| R2 | "Roughly how much of the week is travel booking, and how much is invoices?" | Sizes the gaps before you claim them |
| R3 | "Who would I work with day to day, and who would I report to?" | Tests the reporting line with the office manager |
| R4 | "Is this call the only stage, or is there a next step?" | Process question; sets how much prep time you need |
| R5 | "Which calendar, travel and document tools does the team use?" | Lets you rehearse Word and Excel against real tools |

## Sources

- **Provided documents:** the invite text, the ad as you summarised it, and your background message. No job description or CV was pasted.
- **Research tier:** L0. No search or fetch was sent in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet. Not run at L0 |
| 2. Interview process for the role | unavailable | Loop structure and persona weights. Not run at L0 |
| 3. Company strategy and recent news | unavailable | Company knowledge (CO) questions. Not run at L0 |
| 4. Interviewer name and background | n/a | No name was given, so there is no query to form |
| 5. Representative job description | unavailable | Would turn the ad summary into quoted requirements. Not run at L0 |

## Upgrade menu

- The full ad text → the duties become quoted requirements, and the summary rows become `[grounded]` rows
- Your CV → more quoted evidence for F2 and F6
- The interviewer's name → persona weights and a tailored reverse question
- `tuesday-dossier.md`, if you have one → its verified evidence in place of the quotes here
