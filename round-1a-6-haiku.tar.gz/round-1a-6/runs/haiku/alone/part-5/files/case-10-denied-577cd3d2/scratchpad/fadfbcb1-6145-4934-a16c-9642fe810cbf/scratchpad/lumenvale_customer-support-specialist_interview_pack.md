# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** support team lead (name not given). Relationship not yet known; this pack assumes a hiring-manager-style round.
**Built on:** your message (CV summary, the job ad's requirements as you gave them). No company research was run (research tier L0).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = can you do the listed job; **EXP** = do your past claims hold up under detail; **VAL** = behaviour against published values; **CO** = company knowledge; **CASE** = live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Prep triage

No prep time was stated, so this is the default order:

1. Freshdesk and Zendesk-equivalence answers (A1, A2): the ad's tooling requirement is the most likely first probe.
2. Escalation handling (A3): the one requirement your material does not show. Build an honest example from your real escalations.
3. Refunds training (A4): your strongest concrete story for the "clear communication" requirement.
4. Reverse questions (section 9).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message (job ad) | "3 years as a customer service advisor at an energy supplier" — your message | high | [grounded] | none | Direct match on length and function. Lead with the years and the function. |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message (job ad) | "I use Freshdesk every day" — your message | medium | [grounded] | transferability | Freshdesk is a similar ticketing tool, but you have not used Zendesk. Say so plainly: "I haven't used Zendesk; I use Freshdesk every day." Then name what you do in it. |
| F3 | "clear written communication" — your message (job ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Volume shows a lot of written work; it does not show clarity. Answer slot: describe one written reply that had to be clear, and how you checked it had worked. If you have no such example, say what you do to keep replies clear. |
| F4 | "confidence handling escalations" — your message (job ad) | "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Training on refunds is not escalation handling. Answer slot: describe an escalation you handled, what you decided, and what happened. If you have not handled one, say so and describe how you would handle one. |
| F5 | Software-company background — not in the job ad; likely to be probed | "I've never worked for a software company" — your message | none | [grounded] | capability | This is a stated negative. Do not claim software or product experience. Words: "I haven't worked for a software company. My support work has been in energy." |

## Persona table

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the Zendesk gap and the escalation gap | High: the ad lists both, and the chat format makes short answers easy to test | Answer the gap first, then the nearest real experience |
| Prober | Asks for detail on the 60-a-day figure and on your share of it | High: this figure is the most quotable line in your background | Give your own share, in your own words |
| Warm-practical | Asks about the refunds training and how you work with new colleagues | Medium: common in team-lead rounds | Tell one concrete training story with its result |

## Question banks

Provenance comes first in each row. The candidate's own sentences follow the provenance label.

### Bank A: Team lead (weighted highest)

| ID | Type | Persona | Provenance | Question | Guidance | Rationale |
|---|---|---|---|---|---|---|
| A1 | JD | Skeptic | [grounded] "I use Freshdesk every day" — your message | "The ad asks for Zendesk or a similar tool. What have you done in your ticketing system?" | Name two or three things you did in Freshdesk (replies, status changes, refunds). Say you have not used Zendesk, then stop. Do not describe Zendesk features you have not used. | The ad names Zendesk, and you have not used it. The honest answer is the gap plus your real daily use. |
| A2 | EXP | Prober | [grounded] "answering around 60 calls and emails a day" — your message | "Sixty calls and emails a day: what was your part of that?" | Give your own share: which channel, which queue, what you resolved yourself and what you passed on. | The number is quotable. It must be shown as your part of a team's volume only if that is true. |
| A3 | JD | Skeptic | [inferred] selection scaffold: pick a time you handled an escalation; no escalation is in your material | "Tell me about an escalation you handled. What did you decide?" | Pick a real escalation. Say what you decided, why, and the result. If you have no escalation you handled, use the nearest case you passed up and say what you would do. Honest branch: "I haven't handled a formal escalation. Here is how I would handle one." | The ad requires confidence with escalations, and your material is silent on them. |
| A4 | JD | Warm-practical | [grounded] "I trained four new starters on our refunds process last year" — your message | "You trained new starters on refunds. How did you do it?" | Describe the steps you took, what the new starters got wrong first, and how you checked they had it. Keep to what you personally did. | This is your strongest concrete story for clear communication and for working with colleagues. |
| A5 | CASE | Skeptic | [generic] no candidate sentence carries this; selection scaffold | "A customer writes that they were charged twice and is angry. Write your reply." | Write a short reply: acknowledge, state what you will check, give a time, and do not promise a refund you cannot give. Read it back for tone. | The ad asks for clear written communication. A live written task tests it directly. |

## Prohibited claims

These are claims this pack will not coach, and why.

| Claim | Basis | Honest form |
|---|---|---|
| Any software-company or product-company experience | Your message: "I've never worked for a software company." | "I haven't worked for a software company. My support work has been in energy." |
| Any use of Zendesk | Not in your material. | "I haven't used Zendesk. I use Freshdesk every day." |
| Escalation-handling experience beyond what you did | Not in your material. | Answer slot at A3. |
| Team size, volume shares or results you did not give | Not in your material. | Use only the figures you have stated. |

## Reading the interviewer

Public footprint is not available (no name given, no research run). Persona weights use round-type priors only.

## Reverse questions

Each one has a reason it lands.

1. "Which ticketing tool does the team use, and how are escalations routed within it?" Lands because it shows you know the ad's tooling requirement and want the real workflow.
2. "How many contacts does an agent typically handle in a day?" Lands because it lets you compare with your 60-a-day background on the same terms.
3. "What does the first month look like for a new starter, and who trains them on policy?" Lands because you have trained new starters and can speak to that.
4. "What does a good written reply look like here, and how is quality checked?" Lands because the ad asks for clear written communication.
5. "What would make someone successful in this role after six months?" Lands because it asks the team lead to state the bar in their own words.

## Sources

- Provided documents: your message (CV summary, job-ad requirements as you gave them).
- Research: none run. Research tier L0. No searches or fetches were made.
- Target accounting: company research, role-family loop reports, interviewer profile: not run (L0).

## Upgrade menu

- The job ad's full text → the requirements in the fit snapshot become quoted from the ad, rather than from your summary
- The team lead's name → persona weights from their public footprint, and a tailored reverse question
- Your Freshdesk or escalation examples in more detail → A1 and A3 guidance becomes story-mapped rather than scaffolded
