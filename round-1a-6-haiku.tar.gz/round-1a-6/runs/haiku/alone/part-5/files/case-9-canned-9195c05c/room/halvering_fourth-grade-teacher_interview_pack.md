# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Organization:** Halvering Elementary School, Orrinsford Community School District
- **Format:** 45-minute panel, Thursday (likely Thursday, December 3, 2026; confirm the date with HR)
- **Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not yet known)
- **Gate:** Valid Illinois Professional Educator License with an elementary endorsement (met, per your CV)
- **Built from:** the HR invite and your CV, as you shared them. No job description, no research run (tier L0), no interviewer profile.

## How to use this pack

- **Personas** describe how a question arrives: the Principal asks as the decision-maker; the team members ask as the people who will work beside you.
- **Types** describe what is being scored:
  - **VAL**: values and behavior, meaning what you did and why
  - **EXP**: your experience, meaning whether your claims hold up under a closer look
  - **JD**: can you do the job as it will be asked of you
  - **CO**: company and strategy knowledge (not covered; research was not run)
  - **CASE**: a live problem from the role, answered in the moment
- **Guidance is scaffolding, not a script.** Every suggested line uses only what you told me. Where you have no sentence for a point, the guidance asks you to say what is true for you, and it says so.

## Prep triage

Prep time was not stated, so no schedule is built. The order below is a suggestion:

1. Rehearse **A2** out loud until your answer is calm and specific. It is the most likely hard question.
2. Rehearse **A1** and **A3** with the honest branches.
3. Read the **Prohibited claims** section so you know which phrases to avoid.
4. Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (your message) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it plainly: "I hold an Illinois PEL with an Elementary Education endorsement for grades 1–6, active through June 30, 2029." |
| F2 | Fourth-grade teaching, implied by the role title "Fourth Grade Teacher position" (your message) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | high | [grounded] | capability | Your stated absence, in your words: "I've never taught fourth grade." Your material does not show any fourth-grade experience, so the pack does not claim any. The adjacent work is the third-grade years: "Six years teaching third grade." How you would learn fourth-grade content is a plan, not a past. |
| F3 | Serving as a team lead, implied by the panel's make-up of a grade-level team (your message) | "I've never been a team lead" (your message) | high | [grounded] | capability | Your stated absence, in your words: "I've never been a team lead." Do not describe any role as team leadership. The nearest sentence is F4. |
| F4 | Leading a shared change with colleagues, [generic] requirement for a grade-level team role (no JD supplied) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Your material says you led your grade level's move, not the district's, and not a team you were in charge of. Keep the words at that scope: "I led our grade level's move to a new reading curriculum in 2024." Which decisions were yours is an answer slot (see B1). |
| F5 | Reading instruction, [generic] requirement (no JD supplied) | "I've run the after-school reading club for the last two years" (your CV) | high | [grounded] | none | No gap. Keep to what you ran: "I've run the after-school reading club for the last two years." |
| F6 | Family communication, [generic] requirement (no JD supplied) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Keep to the sentence. What the emails contain and how you follow up is an answer slot (B3). |

Requirements from the invite are quoted in F1 only. The other rows are [generic] role-family requirements, which raise no answer slots of their own.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Principal (Evaluator) | Asks about fit, the fourth-grade gap, and leadership, and scores the room | High: the principal holds the decision, and F2 and F3 are the two gaps the invite already puts in front of the panel | Hold-then-concede on F2 and F3: state the fact once, plan once, and do not defend it a third time |
| Fourth-grade team member (Prober) | Asks about practice: how you did the curriculum move, how you ran the club, what the weekly email contains | High: team members ask about the work they can picture, and your CV has three concrete practices to probe | Keep each answer to the sentence you wrote, and say so plainly where you have no more detail |
| Second team member (Warm) | Asks about your classroom, your values, and how you work with others | Medium: round-type prior for a second team member on a panel; no profile was given | Answer with the third-grade and reading-club sentences, which are yours and specific |

Weights: the Principal bank is weighted highest (depth 4–5), the Prober bank next (3), and the Warm bank lightest (2), following the panel's make-up. These are round-type priors, since there is no interviewer profile.

## Question banks

Each row: ID, question, type, provenance (label, then the sentence the guidance rests on), guidance, and rationale.

### Principal (weight 4–5)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | What would your first month with a fourth-grade class look like? | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Begin with the third-grade sentence, then move to the fourth-grade plan. Say what you would check first: what the students arrive knowing, and which fourth-grade content you would learn before the first unit. Frame the plan as future work ("I would…"), not as past experience. Speakable in about 90 seconds. | The fourth-grade gap (F2) is the first thing the principal will test. A plan answers it without claiming experience. |
| A2 | You haven't taught fourth grade. Why should we take that risk? | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI prep.** Hold the position: "I haven't taught fourth grade, and six years of third grade is what I bring." Hold through two follow-ups without arguing. Concede specifically on the second follow-up: "I'd be learning the fourth-grade content in the first term, and here is how I would do it." Never say you can teach fourth grade as though you have. | This is the most predictable objection to your candidacy, aimed at F2, the biggest gap. A held position you can stand behind, plus a specific concession, beats a defensive answer. |
| A3 | Tell me about a time you led colleagues toward a shared goal. | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | Open prompt. The nearest story your material carries is the 2024 curriculum move, at its own scope: the move you led, at your grade level. Say what you did, what the grade level decided together, and what you did not control. Where your own part is not clear, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry. Do not call the move team leadership. | Tests F3 and F4 together. The principal wants to see the move's scope stated honestly, not stretched into a role you have not held. |
| A4 | How would you get two colleagues on board with a plan you proposed? | CASE | [generic] hypothetical; asks nothing about your past | Answer as a plan: name what you would share first (the data or the sample work), ask for the colleagues' concerns before proposing changes, and say how you would decide if you disagreed. Use no past event. | Panel rooms often test collaboration this way. A hypothetical keeps you clear of the team-lead gap. |
| A5 | What does a strong reading block look like in your classroom? | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what you ran in the club, in your own words, then the classroom version. Where you have no measure of how students did, say so: "I don't have a measure of growth from the club." Do not invent the structure of a reading block you did not run. | Reading instruction is a core role expectation, and your club is the most direct evidence. |

### Fourth-grade team member (Prober, weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Walk us through how the 2024 reading curriculum move happened. | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Give the sequence: what prompted the move, who was involved, what you did first. Answer slot: if any step was yours alone, say which and how you decided; if the decision was shared, say so; if the decision was not yours, say so plainly and stay with the part you did. Do not add decisions, meetings or results you did not state. | A team member will probe the one leadership-like item on the CV. Precision about attribution is what they are testing. |
| B2 | How do you plan with a grade-level team that already has its pacing set? | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use the curriculum move as your only example of planning with a team. State what you would do first on a team with set pacing: learn the calendar, then raise changes through the team. Do not claim fourth-grade planning experience. | The fourth-grade team will ask about the work they actually do together. |
| B3 | You write a weekly email to families. What goes in it, and how do you follow up with families who don't reply? | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe what the email contains in your own words. Answer slot on follow-up: if you followed up with families who did not reply, say how; if you did not, say so plainly. | Tests a claim on the CV about practice, not just existence. |
| B4 | How did students in the reading club progress over the two years? | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked progress, say what you counted and what it could not show; if you did not track it, say so plainly: "I didn't track progress systematically." Do not supply results. | A premised outcome the CV does not state. A figure would raise a defend-the-number probe, and none is given. |
| B5 | How do you give feedback to a colleague whose approach differs from yours? | VAL | [generic] role-family question; no candidate sentence | Scaffold: pick a time you disagreed with a colleague about practice; name what you said, what you heard back, and what you changed. If no such time comes to mind, say so plainly and describe how you would start the conversation. | Team members weigh collegiality heavily; this is a general prompt without a premise. |

### Warm team member (weight 2)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | What did six years in third grade teach you that you'd bring to fourth? | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Name one or two things from third grade in your own words, and say how they would carry over. Do not claim fourth-grade results. | A warm question about the experience you do have; it gives you a positive opening. |
| C2 | Tell me about a time a student made real progress with you. | VAL | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Open prompt. The nearest story is the reading club. Say what the student was working on and what you did. If you cannot name a student's progress without a figure, say what you observed. If no such time comes to mind, say so plainly and give the nearest thing your material carries. | A common warm-panel prompt. Keep to what you saw and did, not to outcomes you did not record. |

### Unassigned to a single persona (any panel member)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | A student in your class is reading two years below grade level. What is your first step? | CASE | [generic] hypothetical; asks nothing about your past | Plan out loud: first check assessment data and what the student has already read; second, observe the reading to find the skill gap; third, plan a small-group intervention and track it. | A live problem from the role; uses no past event. |
| D2 | What does a good first ten minutes of a reading lesson look like? | JD | [generic] role-family question | Speak from your reading-club and classroom experience, and frame any unfamiliar parts as plans. | A reading lesson is a standard JD expectation and a short, checkable answer. |
| D3 | How do you adapt a lesson when half the class is below grade level? | JD | [generic] role-family question | Describe the adaptations you have used, quoting only what you ran, and say which you would try in fourth grade. | Differentiation is a common JD requirement; a plan answer is the honest form. |
| D4 | Why this school, and why fourth grade now? | VAL | [generic] general motivation question; no candidate sentence | Use your own reasons. The pack does not supply them. If you are unsure, say what draws you to the role and to this team. | Panels nearly always ask this, and the answer should be yours, not supplied. |

Session total: 18 questions. The CO bank is empty because research was not run.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Illinois PEL with elementary endorsement (gate) | none: met on your CV; a question is not needed |
| Fourth-grade teaching (F2) | A1, A2, A4, D1 |
| Team leadership and collaboration (F3, F4) | A3, A4, B1, B2, B5 |
| Reading instruction (F5) | A5, C2, D2, D3 |
| Family communication (F6) | B3 |
| Job description requirements | none: no JD was supplied, so no JD-tagged requirements were checked |

## Reverse questions

Each question has a line on why it lands.

1. "What does the first term look like for a new fourth-grade teacher here?" Why it lands: it shows you are planning for onboarding, not only for the interview.
2. "How does the grade-level team plan together, such as weekly meetings or shared assessments?" Why it lands: it shows you care how the work happens, and it gives you a question about your own future.
3. "What would make the first six months a success, from your point of view?" Why it lands: it asks for the success criteria the principal holds.
4. "Which part of the reading program does the team most want to strengthen next?" Why it lands: it links back to the curriculum move, so you sound like you are already thinking about their next step.
5. "What could a new person do in the first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel, and it shows you want to contribute.

## Prohibited claims

These claims are not to be coached, because your material does not support them. Each entry gives its basis and its honest form.

| Claim | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Sourced: your message, "I've never taught fourth grade" | "I've never taught fourth grade." Plus the plan for learning it. |
| Any team-lead role or title | Sourced: your message, "I've never been a team lead" | "I've never been a team lead." Describe the curriculum move at its own scope. |
| "I led the district's reading curriculum" or any wider scope than your grade level | Inflated form of your CV sentence, "I led our grade level's move to a new reading curriculum in 2024" | "I led our grade level's move to a new reading curriculum in 2024." |
| "I ran the reading program" | Inflated form of your CV sentence, "I've run the after-school reading club for the last two years" | "I've run the after-school reading club for the last two years." |
| Any outcome figure for the club or the curriculum move | Not stated in your material | "I don't have a measure of that." |
| Any pay figure, salary history, or range | Not given, and not asked for in this panel | Decline or redirect, with no figure: "I'd rather focus on the role's responsibilities." |

## Sources

- **Provided documents:** the HR invite (your message); your CV as summarized in your message.
- **Research:** none run. Research tier **L0**.
- **Target accounting:**
  - Company research: skipped (L0)
  - Representative job description: skipped (L0)
  - Interviewer profile: skipped (no profile requested; names given only)
  - Values and strategy: skipped (L0)

## Upgrade menu

- The job description → turns the [generic] rows into [grounded] rows, and adds JD-tagged questions for each listed requirement
- HR's note on the panel's focus or any task, such as a lesson demo → a build section for that deliverable
- Public profile of Principal Dolores Vantongeren → personalized persona weights and a tailored reverse question
- Research at tier L1 → company values and current strategy questions (VAL and CO)
- `tuesday-dossier.md` from a later session → carries the gaps this prep exposed into future rounds
