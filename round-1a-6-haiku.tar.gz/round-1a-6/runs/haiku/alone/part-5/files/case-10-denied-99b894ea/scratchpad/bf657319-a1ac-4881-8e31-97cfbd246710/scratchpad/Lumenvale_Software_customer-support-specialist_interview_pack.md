# Lumenvale Software: Customer Support Specialist (remote), interview prep for Imani

**Interviewer:** support team lead, name not given. Relationship: the invite places you with the team lead, so the round is treated as a hiring-manager round.
**Format:** text chat. Your interview is a text chat with the support team lead, so your written replies are the main evidence in the room.
**Assumption:** built on your summary of the ad, not the full posting, and on a chat-only round. The upgrade menu says what changes this.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** **JD** role and requirements · **EXP** your past work, tested for accuracy · **CASE** a live problem from the job · **CO** company knowledge (none here, research did not run) · **VAL** published values (none here).
- Guidance is scaffolding, not a script. Aim for about 90 to 120 seconds spoken, or the equivalent in a chat reply.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | presentation | Your material reaches the requirement in other terms: "For three years I was a customer service advisor at an energy supplier." Say the role title and the years in those words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool and the quote says you use it daily. Lead with that. Do not claim Zendesk. Answer slot for A1: how you would get up to speed on their tool. |
| F3 | "clear written communication" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show a written sample. In this chat your replies are the evidence. Answer slot: if something you wrote was acted on by a customer or colleague, say what it was, in your own words; if not, say so and write the reply in the chat. |
| F4 | "confidence handling escalations" (your summary of the ad) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Training on refunds is adjacent work. It does not reach escalations. Answer slot for A3: if you have passed a problem to someone above you, say what it was and what you decided, in your own words; if not, say so and describe how you would decide. |

Fit-snapshot rules applied: each quote is exact and its source is named. Requirement quotes come from your summary, because the full ad was not pasted.

## Prohibited claims

Claims this pack will not coach, each with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". Limit as the pack's observation: your material shows Freshdesk, not Zendesk. |
| Handled escalations | Inflated form of F4 | F4's quote at its own scope. Limit as the pack's observation: your material shows training, not escalation work. |
| Wrote or owned the refunds process | Inflated form of F4 | "I trained four new starters on our refunds process last year". |
| Software or SaaS support experience | Negative you stated | Plain acknowledgment: "I've never worked for a software company." No slot needed. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no software company, no Zendesk, no escalation record | **Top weight (5 questions).** A team lead hiring for a tool and product they run will test fit against exactly these gaps | Acknowledge the plain negative first, then bridge with quoted evidence only; hold the plan, not a past |
| Case / Strategist | Live support scenarios you answer in the chat | **High (4).** The round is text, so a live reply is the most natural test | Clarify the facts first, then write the reply; keep it short |
| Data-Driven Prober | Asks how your "around 60" a day was counted | **Mid (3).** Your volume figure is the one number in your material a team lead will check | Defend the figure in your own words; say plainly what you do not know |
| Pressure | Pushes on the software gap and on refunds outcomes | **Mid (3).** The chat format makes composure visible even without a face-to-face | Hold a position through two follow-ups, then concede specifically |
| Conversational | Opens with "tell me about yourself" and "how did you find us" | **Low (2).** Casual openers are still scored | Use a ready 90-second arc |

Weights are relationship priors (team lead, hiring-manager round), with the chat format raising Case. Session total is 17 questions, one under the usual range, because the material is thin.

## Question banks

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for Zendesk or a similar ticketing tool. How would you get up to speed on ours?" | JD | [grounded] "I use Freshdesk every day" (your message) | Name Freshdesk and that you use it daily. Then name one thing you would learn first in their tool and how you would learn it. Answer slot: none about Zendesk itself. | F2 is the evidence; the question is the ad's own line. |
| A2 | "You haven't worked for a software company. What would you expect to be different about supporting our product?" | JD | [grounded] "I've never worked for a software company." (your message) | **Highest-ROI prep in this pack.** Say "I haven't worked for a software company." Then say what you expect to differ, as a plan: how you would learn the product, from its help content and from its tickets. Hold through two follow-ups by returning to the plan. Concede the learning curve specifically. | The objection is the most predictable one: it sits exactly where your material is thinnest. |
| A3 | "Tell me about a time you had to escalate a customer problem." | JD | [generic] | Open prompt, so pick a real instance. Selection scaffold: a time a problem went beyond what you could resolve yourself, with a named stake, what you did, and where it went. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the refunds training) and how you would handle an escalation. | The ad names escalations (F4), and your material does not show escalation work, so the honest branch is the one to rehearse. |
| A4 | "What do you look for before you pass a ticket on?" | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | Describe your own rule for handing over a ticket, in your own words. If you have no rule you use, say so and describe what you would check first. Answer slot: the training did not show handover practice. | Asks for your method, not a claim about a past. |
| A5 | "How would you know your reply had been clear to a customer?" | JD | [generic] | Name one signal you would watch for: a follow-up question, a reopened ticket, or a reply that resolved the issue. No claim about past results. | Tests the written-communication requirement (F3) without assuming a sample exists. |

### Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes in chat: their order is three weeks late and they want a refund now. Reply to them." | CASE | [generic] | Clarify the order status and the policy first. Then write a short reply: acknowledge the specific delay, say what you can do now, and give one next step with a time. Do not promise what policy does not allow. | A live problem from the role. No claim about your past. |
| C2 | "You have a ticket you cannot resolve within the hour. How do you escalate it?" | CASE | [generic] | Name what the next person needs: a summary, what the customer was told, and what you have already checked. Say what you tell the customer and when. | Live handover problem; tests the escalation requirement (F4) as a decision. |
| C3 | "Reply to this in the chat: 'You charged me twice and nobody has answered for a week.'" | CASE | [generic] | Write it live. Name the specific fact (the double charge and the week), say what you are doing next and when, and do not grovel. Keep it to a few sentences. | The chat is the written-communication test (F3). |
| C4 | "What does a good support reply look like to you, in a minute?" | JD | [generic] | Give three features: it answers the question first, it says what happens next, and it uses the customer's own facts. Keep the reply short. | Opens the written-communication requirement as a question about judgment. |

### Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Our customers are often right and our policies are often wrong. Which one do you side with?" | JD | [generic] | Hold a position: the customer's problem is real, and policy exists for a reason. Concede specifically where you would check with the team lead before deciding. | Pressure on judgment, not on facts. |
| S2 | "Sixty seconds: why should we hire someone with no software background over someone who has supported a software product?" | JD | [grounded] "I've never worked for a software company." (your message); [grounded] "answering around 60 calls and emails a day" (your message) | Acknowledge: "I haven't worked for a software company." Hold on the volume you handle daily and on the tool you already use. Concede the product learning curve directly. Hold through two follow-ups before conceding anything. | Pressure version of A2, with the volume figure as the position you hold. |
| S3 | "That refunds training: how many of those four starters got it right first time?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you tracked how they did, say what you saw. If you did not track it, say so, and say how you would check it now. Do not supply a number. | The outcome is not in your material, so the answer is the honest branch, not a figure. |

### Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You said you handle around 60 contacts a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Repeat "around 60 calls and emails a day" as your own words. Answer slot: how you counted it, what it depended on, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | Defend-the-number slot the figure raises. |
| P2 | "How do you decide when a contact needs passing to someone else?" | JD | [grounded] "answering around 60 calls and emails a day" (your message) | Describe your decision rule in your own words. If you have no explicit rule, describe what you actually do. Do not invent a threshold. | Asks for your method, not a claim. |
| P3 | "Walk me through the refunds process you trained on, step by step." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you can describe the steps you taught, do so in your own words. If the steps were set by someone else, say that and describe your part in teaching them. | The process is in your quote; its steps are not, so the honest branch must be ready. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | A 90-second arc: your current role, what you do daily in Freshdesk, and the refunds training you gave. Stop there. | Biography is scored even when casual. |
| R2 | "How did you hear about us?" | EXP | [grounded] "applied for a remote Customer Support Specialist job at Lumenvale Software through their careers page" (your message) | One honest sentence: you applied through the careers page for the Customer Support Specialist role. | Short, factual, and easy to get wrong if you embellish. |

### Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| 2+ years in customer support | R1, S2, P2 | Covered through F1 |
| Zendesk or a similar ticketing tool | A1 | Freshdesk only; no Zendesk claim |
| Clear written communication | A5, C3, C4 | No written sample in material; chat is the test |
| Confidence handling escalations | A3, C2, A4 | Honest branch is the rehearsal; training is adjacent |
| Software company (not in your summary of the ad) | A2, S2 | Stated negative; plain acknowledgment only |

## Reverse questions

Five, each with why it lands. The team lead is the interviewer, so none is a reciprocity question, and no interviewer profile was available to tie one to their path.

1. "Is the chat the only stage before an offer, or is there a call or video step?" Why it lands: it sets how much to prepare for live speaking versus written tests.
2. "Which tools does the support team use day to day, and how are tickets handed over between tiers?" Why it lands: it tests the tool fit in A1 and A4 and shows you are thinking about the job.
3. "How does the team handle an escalation once it leaves first-line support?" Why it lands: it connects to the escalation requirement and to A3.
4. "What would a good first month look like for this role?" Why it lands: it asks for priorities, not a rehearsed answer.
5. "How do you measure a good week on this team?" Why it lands: it signals you want the criteria before you start.

## Sources

Research tier: L1 (searches 0 of 6, fetches 0 of 2). Both calls were refused by the host, so no search results came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet (section 10): not built. Refused query: "Lumenvale Software company values" |
| 2. Lumenvale Software interview process, customer support | unavailable | Loop structure and persona weights: kept at relationship priors. Refused query: "Lumenvale Software customer support specialist interview process" |
| 3. Lumenvale strategy / recent news | skipped | Would have moved the CO bank; no CO questions were built |
| 4. Interviewer name and Lumenvale | n/a | No name was given, so there was no query to form |
| 5. Representative customer support specialist JD | skipped | Your summary of the ad fixed the fit snapshot |

Provided documents: your message, including the invite text and your summary of the ad. No dossier was present.

## Upgrade menu

- Full ad text → the four requirement rows become quotes from the posting, and the coverage table is rechecked against it
- Your CV → the rows that name your background become sentences you can point to on paper
- Round details (chat only, or chat then a call) → persona weights reweighted for the actual loop
- The team lead's name, if the invite or ad gives one → one reverse question tied to their path
- Search access, or your own paste of Lumenvale's careers or values page → the values cheat sheet and current-company grounding (targets 1 and 2 above)
- A `tuesday-dossier.md` would add the gap records from this prep to a file you can carry forward
