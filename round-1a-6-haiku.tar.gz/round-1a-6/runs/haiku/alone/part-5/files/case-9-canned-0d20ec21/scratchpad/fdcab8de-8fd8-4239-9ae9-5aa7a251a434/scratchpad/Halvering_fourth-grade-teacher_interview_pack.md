# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Company:** Halvering Elementary School, Orrinsford Community School District
**Format:** 45-minute panel. Principal Dolores Vantongeren (manager-type) and two members of the fourth-grade team (peers).
**Built on:** the invite and your background note. No job description was supplied and no research was run, so this pack uses only what you gave me (research tier L0, see Sources).

## How to use this pack

Personas are how a question is asked. Types are what is being scored:

- **VAL**: behavioral, past behavior in a team or classroom setting
- **EXP**: your past work, checked for what you actually did
- **JD**: the role's own requirements, including its gaps
- **CO**: company knowledge (none rehearsed here, no research was run)
- **CASE**: a live classroom or team problem, no claim about your past

Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on your material. Say it plainly. Note the endorsement covers grades 1 to 6, and have the document ready. No answer slot. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | none | [grounded] | capability | Your material has no fourth-grade teaching, and you stated that. Words: "I've never taught fourth grade." Adjacent work, at its own scope: six years of third grade. How you would get to fourth-grade content is a plan, never a past. |
| F3 | Leading a grade-level team (role-family, [generic]; not in the invite) | "I've never been a team lead" (your message) | none | [grounded] | capability | You stated the absence. Words: "I've never been a team lead." Then a plan for how you would learn team leadership. Do not claim any team-lead role. |
| F4 | Reading instruction (role-family, [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Two lines reach reading instruction in role-relevant terms. Say them in their own words. The pack's observation: the material shows a move you led and a club you ran, not any curriculum choice you made alone. |
| F5 | Shaping a grade-level decision with colleagues (role-family, [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | The quote carries adjacent work, a move you led at grade level, and does not reach team leadership. Its words stay at its scope: "I led our grade level's move to a new reading curriculum in 2024." Any wider step (who decided, how the team agreed) is an answer slot, below. |
| F6 | Family communication (role-family, [generic]) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Reaches the requirement. Say it in those words. No answer slot. |

Gap types follow the six-type routing in the skill's conventions. Confidence grades your evidence; Provenance grades what this pack wrote about it.

## Prohibited claims

Not coached anywhere in this pack. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience of any kind | Negative you stated (F2) | "I've never taught fourth grade." Plain acknowledgment. No slot asks you to add to it. |
| Being or having been a team lead | Negative you stated (F3) | "I've never been a team lead." Plain acknowledgment, then your plan. |
| Choosing or designing the reading curriculum | Inflated form of F4 | The 2024 quote at its own scope. The pack's observation: the material says a move you led, not a choice you made. |
| Reading-club results, such as score gains | Inflated form of the club quote. No outcome was given. | The club quote at its own scope. If you tracked anything, say what you tracked in your own words. If you did not, say so. |

## Persona weights

The panel blends the two relationships present: a manager-type (principal) and two peers (team).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probes your two gaps: fourth grade and team leadership | High. The principal owns the hire, and both gaps are visible on your own material. Weight 5, so 5 questions. | Concede the stated gap in your words, then the adjacent work at its own scope, then a plan. Hold through two follow-ups. |
| Peer Evaluator | Team members test planning, shared decisions and what you would need from them | High. Two members from the grade you would join. Weight 4, so 4 questions. | Reciprocity: what you would bring to their team, not only what you need. |
| Case / Strategist | A classroom or team scenario, such as a struggling reading group or a parent email | Mid. Teacher panels often include one scenario. Weight 3, so 3 questions. | Clarify, then diagnose, then plan, then check. Ask about the school's assessments before you propose anything. |
| Values / Behavioral | STAR-style stories. No published values were detected, so this is a generic prior. | Mid. Panels commonly ask one or two behavioral questions. Weight 3, so 3 questions. | Use "I" for what you did. Where your material holds no story for a question, say so and give the nearest thing it does carry. |
| Conversational | A friendly opener and a close | Low. Weight 2, so 2 questions. Casual questions are still scored. | A 90-second arc with one specific. |
| Pressure | A time-boxed challenge on a gap | Low. Weight 2, so 2 questions. | Hold, then concede the specific limit. Never fold on the core claim. |

## Question banks

### A. Skeptic (principal), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we take that risk?" | JD | [grounded] "I've never taught fourth grade" (your message) | Say it in your words: "I've never taught fourth grade." Then the adjacent work at its own scope: six years teaching third grade. Then the plan: the first things you would do in your first two weeks, such as reading the fourth-grade standards and the team's current unit plans. Hold through two follow-ups by returning to the third-grade years, not by adding fourth-grade experience. | This is the highest-ROI prep in the pack. The principal's most likely objection is the largest gap (F2), and a rehearsed, non-defensive answer changes the interview. |
| A2 | "What do you know about the fourth-grade year already?" | JD | [grounded] "I've never taught fourth grade" (your message) | Name what you know from your third-grade work that carries forward, using only what you actually taught. Answer slot: if you have looked at the fourth-grade standards, say which parts; if you have not, say so and say how you would close that gap. | Tests whether you know your content gap, not whether you can bluff it. |
| A3 | "Team leads set the direction for a grade. Have you ever been the one who decided?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Open with the stated fact: "I've never been a team lead." Then the move you led, at its own scope. Answer slot: if you set the timeline or made the call, say so and how; if the team or the district decided, say so and say what you did. | F3 and F5. The question presumes a decision-making role; the second branch allows that there was none. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message) | Lead with the fourth-grade content in your words. Then the one or two things you would do first. Name no second weakness that you did not state. | A calibrated-candor question. A plain, specific answer scores better than a broad one. |
| A5 | "Why should we choose you over someone who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Concede directly: "I haven't taught fourth grade." Then make the case you actually have: six years of elementary teaching and the reading move you led. Do not claim to be stronger than a fourth-grade teacher. | A pressure form of A1. Conceding first and then making your case is what the principal is watching for. |

### B. Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from us in the first month?" | VAL | [generic] | Ask about the team's current plan first. Then name what you would bring: "I write a weekly email to families" (your CV) and the reading work from F4. | Reciprocity. Peers score what a hire adds to their load, not only what the hire needs. |
| B2 | "We share a reading program across the grade. What have you done with a shared program?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say the move at its own scope. Answer slot: if you made any shared decision in it, say which and how; if the decisions were made by others, say so and describe your part. | F4 and F5. Peers test whether the reading work was shared or solo. |
| B3 | "We plan units together every week. How would you fit into planning?" | JD | [grounded] "I've never taught fourth grade" (your message) | Say the fourth-grade gap in your words. Then how you would join planning: what you would contribute from third-grade reading work and what you would ask the team to show you first. | Team collaboration is a [generic] requirement. The gap is stated, so the answer leads with it. |
| B4 | "Tell me about a time you disagreed with a colleague about a plan. How did it end?" | VAL | [generic] | Open prompt. Pick a time you disagreed with a colleague over a plan. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reading-curriculum move, and how you dealt with colleagues in it, only if that is what happened. | Peers probe disagreement style. The prompt supplies no event; the answer must come from you. |

### C. Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your fourth graders read at very uneven levels. Walk us through your first three weeks." | CASE | [generic] | Clarify first: which reading assessments the school uses and what the team already does. Then diagnose, group, plan and check. Describe reading approaches only where you have used them. | A live problem from the role. It asks about no past, so it presupposes nothing about you. |
| C2 | "A parent emails that their child's reading is slipping. How do you respond?" | CASE | [grounded] "I write a weekly email to families" (your CV) | Structure: acknowledge, gather facts from the child's records, involve the team, set a follow-up. Your weekly family email is the only family-communication evidence you have; say how you would use that habit. Do not describe a parent conference you have not had. | F6. The scenario is the principal's; the one thing you can point to is the email habit. |
| C3 | "Week six, half the class isn't responding to a new reading approach. What do you do?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Clarify what "not responding" means, check the data you have, and bring it to the team. Answer slot: if you saw a similar problem in the 2024 move, say what you saw and what you did; if you did not, say so and reason from the steps. | F4 and F5. The second branch allows that the 2024 move had no such problem. |

### D. Values / Behavioral (principal and team), weight 3

No published values were detected, so these are generic behavioral prompts.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a student who was struggling started to improve." | VAL | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Open prompt. If a student in the club or your class improved, tell it with "I" for what you did and "we" for the context. If none comes to mind, say so plainly, then give the nearest thing the club carries. | The club is the one place your material shows sustained reading support. |
| D2 | "Tell me about a time you had to explain a hard decision to families." | VAL | [grounded] "I write a weekly email to families" (your CV) | Open prompt. If a weekly email carried a hard message, use it. If not, say so and describe the nearest case you handled directly. | F6. The email is a steady practice, not a crisis story; say so if that is what it was. |
| D3 | "Tell me about a time you asked for feedback and changed what you did." | VAL | [generic] | Open prompt. Pick the clearest instance you have: what the feedback was, who gave it, and what changed. If none comes to mind, say so plainly, then give the nearest one. | A generic behavioral prompt with no claim about your past. |

### E. Conversational, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: Joliet, six years of third grade, the 2024 reading move, the club, the family email. Answer slot: say why you are applying for fourth grade in your own words. | Casual openers are still scored. The arc must be one you can tell without notes. |
| E2 | "What's the part of your week you most look forward to?" | VAL | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer with the club and one specific moment from it, in your words. | A casual question that tests whether you have a real, specific answer. |

### F. Pressure, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why are you right for this team?" | VAL | [grounded] "I've never taught fourth grade" (your message) | Hold: name the fourth-grade gap in one sentence, then your strongest case in 30 seconds. Concede the gap specifically if pressed. Never claim fourth-grade experience. | A time-boxed opener. The hold-then-concede structure is what is scored. |
| F2 | "Why would this team trust a candidate with no team-lead experience to decide anything?" | VAL | [grounded] "I've never been a team lead" (your message) | Hold through two follow-ups. Concede the specific limit: "I haven't been a team lead." Then the evidence you have, the 2024 move at its own scope. Do not fold to claim team leadership. | F3 under pressure. The held position is the one you stated; do not strengthen it. |

## Requirement coverage

No job description was supplied, so the invite's own requirements and the role-family requirements are the list.

| Requirement | Questions | Notes |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | none, and why | Met and stated (F1). A panel may confirm it without asking. |
| Teaching fourth grade (invite: "Fourth Grade Teacher") | A1, A2, A4, B3, F1 | The largest gap. |
| Leading or deciding with a grade team (role-family) | A3, B2, F2 | Team leadership is your stated gap. |
| Collaborating on a grade team (role-family) | B1, B3, B4 | |
| Reading instruction (role-family) | C1, C3, D1 | |
| Family communication (role-family) | C2, D2 | |
| Behavioral stories (panel format) | D1, D2, D3, E1 | |

## Reverse questions

Each question is one you can ask the panel. Each has a one-line reason it lands.

1. "What does a new teacher's first month on this team usually look like?" Why it lands: it shows you are planning for the job, not just interviewing for it.
2. "What is the fourth-grade team's reading plan for this year?" Why it lands: it lets you show your reading background without claiming more than you have.
3. "What would a new teacher on this team be expected to bring in the first month?" (reciprocity, peer) Why it lands: it turns the peers' question back to them and shows you are thinking about their load.
4. "How does the team decide on shared units and assessments?" Why it lands: it tests the team-lead gap from the other side and shows how decisions are made.
5. "What would success look like for this role at the end of the first year?" Why it lands: it asks the principal what she is measuring, which is the question she is answering.
6. "How do families usually hear about what is happening in class?" Why it lands: it connects to your weekly family email, which is your strongest family-communication evidence.

## Sources

- **Provided material:** the invite (45-minute panel, Thursday, principal and two fourth-grade team members, PEL requirement) and your background note (your CV and your message).
- **Research tier: L0.** Provided documents only. No searches or page fetches were run. The research tier was not chosen with you in this session.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values (Halvering or Orrinsford) | unavailable | Would have produced a values cheat sheet (section not included, since no values were detected). |
| 2. Interview process, teacher panels in the district | unavailable | Would have set the panel's persona weights more precisely. |
| 3. Company strategy and recent news | unavailable | Would have added company-knowledge (CO) questions. |
| 4. Principal Dolores Vantongeren's public footprint | unavailable | Would have produced an interviewer read and one reverse question tied to her career path. |
| 5. Representative Fourth Grade Teacher job description | unavailable | Would have turned the role-family rows into `[inferred]` requirements with quotes. |

## Upgrade menu

- The job description text → the role-family rows (F3 to F6) become quoted `[grounded]` requirements, and questions in banks B and C get tighter.
- Research at L1 (values, interview process, strategy, the principal's public footprint) → a values cheat sheet if the district publishes values, a persona read for the principal, and CO questions.
- The principal's public profile or published writing → an interviewer read and a reverse question tied to her path.
- Your recollection of how the 2024 reading move was decided (only what you want to share) → sharper answers to A3, B2 and C3.
- `tuesday-dossier.md`, if you have one from an earlier engagement → verified evidence and any prohibited-claim list it holds would bind every answer here.
