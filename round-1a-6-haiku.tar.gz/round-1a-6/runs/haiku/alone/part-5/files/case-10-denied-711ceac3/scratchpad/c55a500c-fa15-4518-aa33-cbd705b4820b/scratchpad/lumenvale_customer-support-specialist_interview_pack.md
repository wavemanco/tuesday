# Lumenvale Software: Customer Support Specialist (remote), interview prep for Imani

Interviewer: support team lead (name not given). Relationship assumed: hiring-manager-style round. Requirements come from your summary of the ad, not the ad's full text.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = a stated job requirement. **EXP** = your past work, tested for accuracy. **CASE** = a live problem from the role. **CO** = company knowledge (not included: no research run yet). **VAL** = values (not included: no values round detected).
- The guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds.

## Persona weights

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no software background, no Zendesk named, no escalation example | 5 questions. A hiring-manager round leans Case plus Skeptic, and your summary has two visible gaps | Rehearse the software-background objection until it is routine. Build bridges only from what you stated |
| Case / Strategist | Live support scenarios from the role: refunds, a bug spike, an angry customer | 4 questions. Support team leads usually test handling in the moment | Clarify, then decide what you can resolve, then say what the customer hears and when. Think aloud |
| Data-Driven Prober | Asks how your 60-a-day figure and your training results were counted | 3 questions. You gave one headline figure and one training outcome | Say how you know each figure, or say plainly that it is an estimate |
| Conversational | Opens with "walk me through your background" and casual tool questions | 3 questions, plus the reverse-question slot | Keep a 90-second background arc. Treat casual tool questions as scored |
| Pressure | Time-boxed challenge on the no-software-background point | 2 questions. Low weight; this is a delivery risk, not a content one | Pause, restate, hold two follow-ups, then concede the specific limit |

Values, Peer and Skip-level personas carry no questions: no values round was detected, and no peer or senior round is named.

## Requirement coverage

| Requirement (source) | Fit rows | Questions |
|---|---|---|
| 2+ years in customer support (your message) | F1 | D1 (JD) |
| Zendesk or a similar ticketing tool (your message) | F2 | A2 (JD), C3 |
| Clear written communication (your message) | F3 | B4 (JD) |
| Confidence handling escalations (your message) | F4 | A3 (JD), B1, B3 |
| Software-company background (not listed; your message) | F5 | A1, A5, E1 |

No requirement is uncovered.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | high | [grounded] | presentation | Your material says customer service, not customer support, over three years. Say it as the quote does: "I have three years as a customer service advisor at an energy supplier." Do not stretch the sector. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | none | Freshdesk is a similar ticketing tool, so the requirement is reached. Name the tool plainly. The material names Freshdesk, not Zendesk. Answer slot: if you have used Zendesk, say when and what you did in it; if you have not, say that you use Freshdesk every day, and say how you would learn Zendesk, as a plan. |
| F3 | "clear written communication" (your message) | none given | none | [grounded] | discovery | Your material does not show written communication. Your message is clear, but that is not evidence about your work. Answer slot: describe a written reply to a customer that had to be right first time, what it needed to say and how you checked it. If none comes to mind, say so plainly, then give the nearest thing your material carries. |
| F4 | "confidence handling escalations" (your message) | "I trained four new starters on our refunds process last year" (your message) | low | [grounded] | transferability | Training on refunds is adjacent to escalations, not the same work. Words: "I trained four new starters on our refunds process last year." Do not stretch it into escalation handling. Answer slot: if any escalation came through refunds and you decided it, say what you decided; if none did, say so plainly. |
| F5 | Software-company background (not listed; your message) | "I've never worked for a software company" (your message) | high | [grounded] | capability | A gap you stated. Words: "I haven't worked for a software company." Then the work that carries over, in the quotes of F1 and F2. No claim that the gap is smaller than it is. |
| F6 | Handling volume (not listed; your message) | "answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | A headline figure, not a listed requirement. It is yours to defend (see C1). The word "around" is yours; keep it. |

Gap types follow the routing rule. Confidence follows the evidence. "Discovery" marks silence, not an absence.

## Prohibited claims

Built locally from the fit snapshot. Each entry is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| "I handled escalations" | Inflated form of F4 | F4's quote at its own scope. Your material does not show escalation handling. |
| "I have used Zendesk" | Inflated form of F2 | F2's quote. Freshdesk is the tool you name. |
| "I ran the refunds training" or "I ran onboarding for new starters" | Inflated form of F4 | "I trained four new starters on our refunds process last year." |
| "I cleared the queue" or "I resolved most of my 60 a day" | Inflated form of F6 | "answering around 60 calls and emails a day." |
| "I have no software experience, so I'd be worse at this" | Stated negative, F5 | The plain acknowledgment "I haven't worked for a software company." Nothing added about how well you would do. |

## Question banks

### A. Skeptic (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. Why should we trust a support hire without that?" | JD | [grounded] "I've never worked for a software company" (your message); "answering around 60 calls and emails a day" (your message); "I use Freshdesk every day" (your message) | Begin with the plain acknowledgment: "I haven't worked for a software company." Then the work that carries over, in the quotes' own words: answering around 60 calls and emails a day, and using Freshdesk every day. Hold through two follow-ups by returning to those quotes and to what you would do in week one, said as a plan. | F5 is the stated gap and the most likely objection. Rehearse this one hardest. |
| A2 | "Your ad names Zendesk. What's your experience with it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you have used Zendesk, say when and what you did in it, in your own words; if you have not, say "I use Freshdesk every day," and describe how you would learn Zendesk in your first two weeks, as a plan. | F2 reaches the requirement by another tool. The named tool is the interviewer's own line, so the probe is likely. |
| A3 | "Tell me about an escalation you handled. What did you decide before passing it on?" | JD | [generic]; nearest thing: [grounded] "I trained four new starters on our refunds process last year" (your message) | Selection scaffold: pick a time a customer's problem needed a decision above your own authority. Say what you decided before passing it on, who you passed it to, and what the customer heard. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the refunds training, without stretching it into escalations. | F4 is adjacent, not a match. This is the open-prompt form, with its honest branch built in. |
| A4 | "What's drawing you to this role, and why now?" | JD | [generic] | Give your own reason in your own words. Do not guess what the role offers, and do not invent a reason for leaving your current job. | A Skeptic's motivation probe. No quote carries a reason, so none is supplied. |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | Name the product first, in those words: you have not worked for a software company. Then say how you would close that in the first month, as a plan. Do not volunteer a second weakness you were not asked about. | A weakest-assumption move on the one gap you stated. |

### B. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer's refund hasn't arrived after two weeks and they're threatening a chargeback. Walk me through your first three moves." | CASE | [generic] | Clarify first: the order, the payment route, and what the refund policy and timeline say. Then decide what you can resolve yourself and what goes up. Say what the customer hears and when. Think aloud. | A live refunds problem from the role. It asks about no past work, so it needs no claim. |
| B2 | "Twenty tickets in an hour mention the same login error, after a release. What do you do?" | CASE | [generic] | Confirm the pattern with two or three examples. Check for a known issue. Tell customers the same accurate thing. Escalate with reproduction steps and counts, then update the status for customers. | A pattern-spotting case that tests escalation judgement without any claim about your past. |
| B3 | "A customer asks for a manager and says they'll post a review. What do you say?" | CASE | [generic] | Acknowledge first. Do not promise what you cannot deliver. Decide whether you can resolve it. If it goes up, say what happens next and roughly when. | Tests confidence with escalations (F4's requirement), as a decision rather than a record. |
| B4 | "Write me a reply to a customer whose export failed. Two lines, please." | JD | [generic] | First line: acknowledge the failure. Second line: what you are doing and when they will hear back. No jargon. Write it out; do not describe it. | The only direct test of written communication, where F3 has no evidence. |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You answer around 60 calls and emails a day. How was that counted, and what is it sensitive to?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you counted, say how; if it is a rough estimate, say so, since "around" is your word. Name the assumption you would defend least. Say which part of the 60 was yours alone. If you cannot say how it was counted, say that. | F6 is a headline figure, so it gets the defend-the-number slots. No method is supplied. |
| C2 | "You trained four new starters on refunds. How did you judge they were ready?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you judged readiness by something you checked, say what. If there was no check, say so plainly and say what you would check first. | F4 is your strongest adjacent evidence, and a prober asks how its outcome was measured. |
| C3 | "You use Freshdesk every day. What have you configured in it yourself?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you configured anything, say what and why; if you only used it, say so plainly. | The Zendesk requirement reaches you through Freshdesk, so the probe lands on this tool. |

### D. Conversational / Rapport (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | JD | [grounded] "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | A 90-second arc. Beats: the three years, the energy supplier, the work the quote describes, Freshdesk daily, the refunds training, and why you are applying here. Add no outcomes the quotes do not state. | Covers the 2+ years requirement (F1). Scored casually. |
| D2 | "What are you playing with in support tools these days?" | JD | [grounded] "I use Freshdesk every day" (your message) | Name Freshdesk and say what you use it for, in the quote's terms. Name no tool you do not use. | A casual register on a JD-tagged topic, so it is scored. |
| D3 | "What's the hardest customer conversation you've had recently?" | EXP | [generic]; nearest thing: [grounded] "answering around 60 calls and emails a day" (your message) | Open prompt: pick one conversation. Say what made it hard, what you did, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the volume of calls and emails. | An open prompt. The honest branch is built in. |
| D4 | "What do you enjoy about customer support?" | JD | [generic] | Answer in your own words. Name one part of the work you would like more of, honestly. | Reason consistency in a rapport register. |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've never worked for a software company and you're asking for a support job. Sixty seconds: convince me." | JD | [grounded] "I've never worked for a software company" (your message); "answering around 60 calls and emails a day" (your message) | Pause and restate the question in one line. Begin with "I haven't worked for a software company." Then the work that carries over, in the quote's words. Hold through two follow-ups. Concede the specific limit: the product is new to you. Never fold on the work you did. | F5 under time pressure. Scores composure, and the hold-then-concede structure is the rehearsal. |
| E2 | "You say you trained people. How do you know they learned it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked how they did, say how. If you did not check, say so plainly and say what you would check. | Probes F4's outcome. The second branch allows that no check existed. |

## Reverse questions

Each one has a reason it lands. Ask the ones that fit the conversation.

1. "What does a new starter's first two weeks look like here?" Why it lands: shows you are planning the start, not only the interview.
2. "How do escalations move from support to the product team, and how long does a typical one take?" Why it lands: escalation handling is the requirement your material says least about.
3. "What does the team lead look for most in a written reply?" Why it lands: a direct test of clear written communication.
4. "What would make someone in this role clearly good after 90 days?" Why it lands: shows you want to be measured against the right thing.
5. "Which tools does the team use day to day, and how much of the work happens in them?" Why it lands: the ad names Zendesk, so this tells you whether Freshdesk is close enough to matter.

## Sources

- Provided documents: your message (the invite's wording, quoted from your message; your summary of the job ad; your background).
- Searches: none run. Research tier: L0, pending your answer to question 3.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have moved the values cheat sheet, which is dropped as no values round was detected |
| 2. `Lumenvale Software interview process customer support` | unavailable | Would have moved the loop structure and the persona weights |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have moved the grounding brief and any CO questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The upgrade menu says what a name would unlock |
| 5. Representative customer support specialist JD | unavailable | Would have turned the requirement rows into grounded rows. The ad's full text is the faster route |

## Upgrade menu

- The full job ad text → the four requirement rows, currently from your summary, become quoted from the ad.
- The team lead's name → persona weights and a tailored reverse question, from their public footprint.
- Light company research (answer question 3) → the values cheat sheet and the interview process, so the bank can sound current.
- A tuesday-dossier.md, if you have one → verified evidence and the gaps to carry forward.
- Describing one written reply you sent to a customer, in your own words → F3 gains a quote and A-level guidance on it.
