# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interview:** 30-minute video call with the office manager.
**Assumption:** the office manager is your hiring manager for this role. Built only from your message and the ad as you summarised it. No research was run.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **Motivation:** why this role, why now
- **Competency:** can you do the work
- **Logistics:** practical fit for remote admin
- **Scenario:** how you would handle a live problem
- **Behavioral:** what you have done before

The guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot

The ad requirements are your summary, not quoted text, so they carry no quotation marks. Evidence in quotation marks is your own sentences, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Manage calendars (your summary of the ad) | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Appointment-book work for four people is your closest match. Keep the words as you said them. Answer slot: a probe on calendar clashes is likely. If you resolved one, say what you did. If you did not, say so. |
| F2 | Book travel (your summary of the ad) | none given | none | [generic] | discovery | Your material says nothing about travel. Answer slot: if you have booked travel for anyone, say how. If not, say so, and say how you would learn the booking tools. |
| F3 | Prepare documents in Word (your summary of the ad) | "I'm good with Word" — your message | medium | [grounded] | none | No gap. A bare "good" invites a probe, so have one concrete Word task ready. |
| F4 | Prepare documents in Excel (your summary of the ad) | "okay with Excel" — your message | low | [grounded] | capability | Say "okay" and do not upgrade it. Answer slot: name the Excel tasks you have done. If they are only basics, say that. |
| F5 | Process supplier invoices (your summary of the ad) | "chased unpaid invoices" — your message | low | [grounded] | transferability | Chasing unpaid invoices means money owed to the clinic. Supplier invoices are money the company owes. Name that difference before they ask. |

## Prohibited claims

Claims this pack will not coach, and why:

- **Travel booking experience.** No source in your material. Honest form: "I haven't booked travel for anyone."
- **Processing supplier invoices.** Chasing unpaid invoices is the other direction. Honest form: "I chased unpaid invoices, which were owed to the clinic."
- **Advanced Excel.** Your stated level is "okay". Honest form: "I'm okay with Excel, and here is what I've done in it."
- **Designing or running the clinic's booking system.** You ran the appointment book. Honest form: "I ran the appointment book for four physios."
- **Any finance, audit or accounting qualification or experience.** None is in your material.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: travel, supplier invoices, Excel, why this move | Highest. A hiring manager for an admin role will check the three requirements you cannot show | Rehearse the most likely objection until it is routine. Bridge only from what you stated, and name the limit plainly |
| Conversational | Friendly opener, then a scored question | Medium. Casual questions about calendars and Word are still scored | A 90-second arc for "tell me about yourself" |
| Case / Strategist | A live calendar or travel problem | Medium. A 30-minute call often includes one practical scenario | Clarify, then steps, then what you would check |
| Pressure | Interrupts, questions how much was really you | Low. Less common in a 30-minute admin screen | Pause, restate what you ran, hold |

Depth follows weight: Skeptic gets 5 questions, Conversational 3, Case 2, Pressure 1.

## Question banks

### Skeptic (5)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Competency | "I don't see travel booking or supplier invoices in your background. How would you handle those in your first month?" | [grounded] "chased unpaid invoices" — your message. Travel: none given | If it is true, say first that you have not booked travel or processed supplier invoices. Then give the closest thing you have done, in your words, and the difference. Then say what you would learn first. | The most likely objection, and the highest-return prep in this pack |
| B2 | Competency | "You say you're okay with Excel. What would you build in it?" | [grounded] "okay with Excel" — your message | Name the Excel tasks you actually did, and keep the word "okay". If you have only done basic lists or sums, say so. | The ad asks for Excel documents, and "okay" will be probed |
| B3 | Motivation | "You've worked at a clinic front desk. Why move to remote admin?" | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Answer slot: give your reason in your own words. Your material does not say why, so do not supply one. | Motivation consistency is scored |
| B4 | Competency | "How many people's calendars have you managed at once?" | [grounded] "I ran the appointment book for four physios" — your message | Say four physios and the scope of the book. Nothing more. | Scale is the first thing an interviewer checks |
| B5 | Scenario | "How do you keep a remote working day organised?" | none given | Answer slot: describe what you actually do. If you have no remote-work habit yet, say that and describe how you would set one up. | Remote fit is part of the role |

### Conversational (3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Behavioral | "Tell me a bit about yourself." | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word" — your message | A 90-second arc in that order. Stop after Word. | Rapport openers are scored |
| C2 | Motivation | "What do you enjoy about organising other people's diaries?" | none given | Answer slot: say what you actually enjoy, in one or two sentences. | Genuine interest is scored |
| C3 | Scenario | "How do you usually prioritise a busy inbox?" | none given | Answer slot: describe your real method. If you do not have one, say what you would try first. | Communication economy is scored |

### Case / Strategist (2)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Scenario | "Two people need the same meeting room at the same time, and a supplier invoice is overdue. What do you do first?" | [grounded] "I ran the appointment book for four physios" — your message | Clarify who needs what, and by when. Then the steps in order. If you have resolved a clash before, say what you did. | Clarify before you structure |
| D2 | Scenario | "A traveller's flight changes the night before. Walk me through it." | none given | Selection scaffold: think of a time you handled a change at short notice. If you have none, say how you would find the rebooking options and who you would tell. | Travel is a stated duty with no evidence |

### Pressure (1)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | Behavioral | "How much of that appointment book was you, rather than the clinic's system?" | [grounded] "I ran the appointment book for four physios" — your message | Pause, then restate what you ran. Hold that position. Do not claim you designed the system. | Composure is scored, not content |

## Reverse questions

Ask at least one of these. Each one is about the role, not the invite.

1. "What does a typical week look like in this role, and how much of it is calendar work?" Why it lands: it shows you are planning the job, not just applying for it.
2. "Which tools do you use for travel booking and supplier invoices?" Why it lands: the answer tells you what to practise before day one.
3. "What would the first month look like, and who would I work with?" Why it lands: it shows you are thinking about the work, not the salary.
4. "What does success look like at three months?" Why it lands: it gives you the measure they will use.
5. "What happens after this call, and what is the next step in the process?" Why it lands: it is a process question, and it prepares you for the next stage.

## Sources

- Provided documents: your message (the ad as you summarised it, and your background) and the invite email as you pasted it.
- Research: none run. The invite's warning signs mean no search was sent.
- Target accounting: research tier L0 (provided documents only). Company research, interviewer profile and role-family report: all skipped.

## Upgrade menu

- The full ad text → the ad's own words become quoted requirements, and the requirement rows become grounded
- Your CV → more evidence rows, so fewer answer slots
- The office manager's name, from the company's own website or careers page → persona weights and a tailored reverse question
- How much prep time you have → a prep order sized to that time
