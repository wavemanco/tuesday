# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Built on:** the advert, Hannah's LinkedIn message, and your notes (no CV pasted, so the evidence is your own sentences).
**Research tier:** L1 requested by default, but both searches were refused (see Sources), so this pack is built from your material only.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the job's terms), EXP (what you actually did), CASE, VAL, CO.
- Guidance is scaffolding, not a script. Where a line is in quotation marks, it is your own sentence. Say it in those words.
- Logistics answers (pay, notice, hybrid, reason for leaving) are yours. Use the wording given. Do not add figures, reasons or flexibility you have not stated.

## Prep triage

In order, for a 30-minute call:

1. **Write your notice period on paper.** Your material does not state it, and it is the one logistics answer with nothing in the pack to draw on (C2).
2. **Say C3, C4 and C5 aloud, in the pack's wording.** These are the four things Hannah said she will cover.
3. **Rehearse the SAP answer (S2, P1).** Concede the gap plainly, then return to what you do have. Do not defend a skill you do not have.
4. **Work out the weakest assumption behind "about a third" (S5).** Say it in your own words before she asks.

Everything else is insurance.

**Phone-call checklist**

- Phone charged, on a quiet line, in a quiet room. She rings the mobile on the application.
- Keep the advert and your application open, with a pen and paper.
- Have your notice period, the £42,000 figure, the hybrid answer and the Reading answer in front of you.
- Do not give your current salary. If asked: "I'd rather focus on the range for this role."
- Ask two or three of the reverse questions (R1 to R5). Note the next step and any date she gives.
- Commit to nothing beyond the next step on the call.
- If anything changes, message Hannah on LinkedIn, as she asked.

**Requirement coverage**

| Requirement (advert) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | C1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | S1, F3 |
| Track supplier deliveries and chase late orders | C1, P1, F2 |
| Keep stock records accurate | S5, F4 |
| Report weekly on on-time dispatch | S4, R2, F6 |
| Confident with Excel | D1, F5 |
| ERP experience (SAP or similar), a plus | S2, P1, F7 |
| Hybrid: two days a week at Avonmouth | C4, F8 |
| £38,000 to £44,000 | C3 |

## The fit snapshot

Columns: confidence, provenance, gap type, bridge language. Each gap type follows the evidence cell, not my sense of the row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | high | [grounded] | none | The quote reaches the requirement. Say it as written. |
| F2 | "Track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | presentation | The quote already reaches this in other terms. Your sentence says "chase suppliers when orders slip". Say it in those words. Do not add specifics. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning or QA. Stay at delivery scheduling. Any wider step is an answer slot (S1). |
| F4 | "Keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say the two sentences as written. The figure raises a defend-the-number slot (S5). |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [grounded] | transferability | Your material shows spreadsheet work. It does not name Excel or a level. Stay with the spreadsheet you rebuilt. Any claim about Excel skill is an answer slot (D1). |
| F6 | "Report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material is silent on dispatch reporting. Words are an answer slot (S4). |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never used SAP." Do not present the in-house stock system as ERP experience. |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | The quote reaches the requirement. Say it as written. |

**Observation, not words for you:** the material shows no production, planning or QA coordination, no SAP or ERP use, and no dispatch reporting. Those are the three places she is most likely to probe.

## Prohibited claims

Claims this pack will not coach, and why. Each is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "I run production schedules between planning, the warehouse and QA" | Inflated form of F3 | "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling. |
| "I cut stock discrepancies by a third" | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not say what drove the fall beyond the rebuild. |
| "I'm an Excel expert" | Inflated form of F5 | "I rebuilt our stock-count spreadsheet." |
| "I have SAP or ERP experience" | Negative you stated, F7 | "I've never used SAP." Plain acknowledgment, sourced to your message. |

## Persona table

Recruiter screen priors are conversational plus a light skeptic. Weights are shown with reasons. No interviewer profile exists, so there is no interviewer read.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (weight 5) | Her agenda: pay, notice, hybrid, reason for leaving, then team and next steps | High. She has listed the agenda herself. | Say each logistics answer once, in the wording given. Then stop. |
| Skeptic (weight 3) | Probes on production side, SAP, QA, dispatch reporting | High. F3, F6 and F7 are the gaps the material shows. | Answer slots for the silent rows. Plain acknowledgment for SAP. |
| Pressure (weight 2) | Pushes on the SAP gap, or on whether the closure is the real reason | Moderate. A screen rarely pushes hard, but the SAP gap invites it. | Hold through two follow-ups, then concede the gap specifically. |
| Data-driven prober (weight 2) | Asks how "about a third" was counted, or what Excel you use | Low to moderate. Screens rarely go this deep. | Name the weakest assumption before she does. Say plainly what you do not know. |
| Case, values, peer | Live problems, values stories, seam questions | Low. A recruiter screen does not score these. No bank written. | None. |

**Count note:** the session total is 13 questions. The usual floor is 18, but a 30-minute screen cannot rehearse that many. The pack is not padded.

## Question banks

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds. Role and years, then the depots, then supplier chasing. Each beat is a clause your sentences state. Then stop. Do not add the stock spreadsheet unless she asks. | F1 and F2 are the evidence here. |
| C2 | "What's your notice period?" | JD | none given: notice period not in your material | Give your actual notice period in one sentence. This is an instruction, not a figure. Write it on paper before the call. | Recruiter logistics. No stated figure to draw on. |
| C3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say "I'm hoping for £42,000." Then stop. If asked about flexibility: "I'd like to hear the band for this role first." Do not say why this figure, whether it is firm, or what you earn now. | The advert gives £38,000 to £44,000. Pay is one of her four topics. |
| C4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say that, in those words. Do not offer other office days. Do not add a commute time. | F8. Hybrid is one of her four topics. |
| C5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it plainly. The closure is the reason. Reading is the only offer, and you don't want to relocate. Do not criticise the employer. | Reason for leaving is one of her four topics. Keep it non-negative. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role coordinates production between planning, the warehouse and QA. What's your experience of that side?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot. Say what you have done with cross-team scheduling, using your depot deliveries as the nearest thing. If you have coordinated with planning, the warehouse or QA, say which. If you have not, say so plainly and say how you would learn the production side. | F3. The question presupposes the advert's line, which is a raising source. Your material does not carry production scheduling. |
| S2 | "Have you used SAP or any ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I've never used SAP." Then say how you would learn it, as a plan, not as past experience. | F7. The advert calls ERP "a plus", so this is a lower-stakes gap, but it will be asked. |
| S3 | "Have you worked alongside a QA team?" | JD | none given | Answer slot. If you have worked with QA on stock or dispatch, say so in your own words. If not, say so plainly. | Silent in your material, and the advert names QA. Discovery. |
| S4 | "On-time dispatch is reported weekly. Have you produced that kind of report?" | JD | none given | Answer slot. If you have reported on delivery timeliness, name the measure. If not, say so and say what you would report first. | F6. Silent in your material. |
| S5 | "Your figure says discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slot. Say how the count was made, and name the assumption you would defend least, in your own words. If you do not know how the baseline was measured, say so. Do not invent a method. | F4. Headline figure, so it is a probe target. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You've never used SAP. Why should we move you forward?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold: anchor in delivery scheduling and supplier chasing, in those words. Concede after two follow-ups: "I haven't used SAP." Do not defend an ERP skill you do not have. | F7 under pressure. Hold the core; concede the gap. |
| P2 | "Is the closure really the reason, or is it the job?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold: "The closure is the reason. The only offer is relocating to Reading, which I don't want." Do not escalate or add a second reason. | Motive probe. Stay with what you said. |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How confident are you with Excel? What do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Start with the spreadsheet you rebuilt. Answer slot: name the Excel features you used, if you can. If you are stronger on some than others, say so. | F5. The advert says "confident with Excel", and your material does not name a level. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does coordination between planning, the warehouse and QA look like week to week?" | Shows you read the advert and want the real shape of the role. |
| R2 | "How is on-time dispatch measured now, and who reads the weekly report?" | Turns S4 into a question you can answer later. |
| R3 | "Is the Avonmouth pattern set by the team or by the site?" | Finds the real office rhythm before you agree to anything. |
| R4 | "What does the team look like, and what happens between this call and the next step?" | She has said she will tell you about the team and next steps. Ask when she gets there. |
| R5 | "Is a systems change planned, and would this role involve SAP or another ERP?" | Tests the SAP gap on your terms, before she raises it. |

## Sources

- **Provided documents:** the advert text; Hannah Lowther's LinkedIn message; your notes on your background, pay, hybrid and reason for leaving.
- **Research:** two searches attempted, both refused (permission not granted), so the pack is built from your material only.
  - "Quillmoor Diagnostics": refused
  - "Quillmoor Diagnostics values Avonmouth Bristol": refused
- **Target accounting**

Research tier: L1 requested, 0 of 6 searches run, 0 of 2 fetches run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet. Not needed: no values-style round was detected. |
| 2. `{company} interview process {role family}` | unavailable | Loop structure. Not needed for a recruiter screen. |
| 3. `{company} strategy` / recent news | skipped | Would feed only the company-knowledge bank. The screen does not ask about strategy, and the advert covers the role. |
| 4. `{interviewer name} {company}` | unavailable | Hannah Lowther's public footprint: would have moved the interviewer read and one tailored reverse question. |
| 5. representative `{role title}` JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Search access → Quillmoor's values, recent news and the interview process, and a grounded company reverse question. Deep research (L2) is offered once and not run: up to 6 further searches and 2 further fetches, a few minutes.
- Your notice period → written into C2 as your own sentence, not as a blank.
- Hannah's prep email, if she sends one → coverage of any process details or deliverables she names.
- A `tuesday-dossier.md` recording this pack's gaps → carried into later rounds without rebuilding the fit snapshot.
