Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-9-canned-59db97a8/0ba26c85-b779-4dfb-9cbb-81bd551554bd/scratchpad/Halvering_Elementary_fourth-grade-teacher_interview_pack.md`. I built it from your invite, your résumé summary and your message, with no job description and no web research. Requirements beyond the licence are labeled `[generic]`.

The pack's main point: your licence requirement is met. The real exposure is the fourth-grade gap (A2 and C1). Rehearse the hold-then-concede answer there before anything else. Your curriculum-move leadership (A3, C2) is your strongest evidence, and the pack keeps it to exactly what you told me you did.

One thing outside the pack: you included your Social Security number in your message. A school interview doesn't need it, so don't send it in emails, forms or the interview. I left it out of the pack and didn't use it.

Could you answer these so I can tighten the pack:
1. Do you have the job description text? If so, paste it. If not, I'll proceed without it.
2. Did HR or the recruiter say what the panel will focus on, or ask for a demo lesson or written piece?
3. May I run a light web check on Halvering and the district's current reading program? It would add grounding for "why this school" and the reading questions.

Drill and dossier offers: I can run a live mock round where I play the skeptic on A2, or save a `tuesday-dossier.md` recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Format:** 45-minute panel interview, Thursday. Principal Dolores Vantongeren plus two fourth-grade team members.
**Built from:** the invite, your résumé summary, and your message. No job description and no web research were available, so requirements beyond the licence are labeled `[generic]`.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** values and behavior; **EXP** what you personally did; **JD** the listed job; **CO** the school and its context; **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, in about 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met. Say it plainly: "I hold an Illinois PEL with an elementary endorsement, active through June 2029." |
| F2 | Teach fourth grade (invite: "Fourth Grade Teacher position") | "I've never taught fourth grade" (your message); adjacent: "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | capability | Words: "I haven't taught fourth grade." Bridge from the adjacent work at its own scope: "I've taught six years of third grade." Any wider claim is an answer slot: what you would do to learn the fourth-grade standards. |
| F3 | Work with a fourth-grade team (invite: "two members of our fourth-grade team") | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | That quote is grade-level work at third grade. Words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: how you would plan with a team that already has its own fourth-grade plan. |
| F4 | Team leadership `[generic]` | "I've never been a team lead" (your message) | none given | [grounded] | capability | Words: "I haven't been a team lead." Then the leadership you have done, at its own scope: the curriculum move in F3. Never a claim of a lead role. |
| F5 | Reading instruction `[generic]` | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | The quote already reaches reading instruction in its own terms. Lead with it as written, and name what the club did as you ran it. |
| F6 | Family communication `[generic]` | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Describe the email as you wrote it. |

## Prohibited claims

What this pack will not coach, and why.

- **"I have taught fourth grade" or "I've taught fourth-grade students."** Sourced: F2's stated absence. Honest form: "I've taught six years of third grade, and I haven't taught fourth grade."
- **"I've been a team lead" or "I've led a team."** Sourced: F4's stated absence. Honest form: the curriculum move, described as you led it.
- **"I designed or chose the reading curriculum."** Your CV says you led the move to it, not that you selected it. Honest form: "I led our grade level's move to it." If you did choose it, say so, and say what you decided.
- **Any figure on reading growth, club attendance or families reached.** Your material gives none. Honest form: an answer slot, and only counts you actually have.
- **Claims about this school's current reading program or district strategy.** Not researched. Honest form: "From what I've read, and I may be behind, ..." or a question to the panel.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Principal (evaluator) | Hiring fit, readiness, the fourth-grade gap | High. She runs the panel and the invite names her first. Weight 4 to 5. | Rehearse A1 to A5 aloud, with the hold-then-concede on A2. |
| Grade-team peers | Classroom practice, planning together, reading block | High. They will be doing the work with you. Weight 3 to 4. | Rehearse B1 to B5. Describe collaboration in specific terms you actually used. |
| Skeptic (inside the principal's questions) | "Why should we bet on a third-grade teacher?" | Very likely. The fourth-grade gap is the most visible thing on your application. Weight 2 to 3. | Hold, then concede, per C1. |
| Pressure (follow-up probing of a claim) | "Which part was actually yours?" | Likely if you describe the curriculum move in broad terms. Weight 2. | Rehearse C2. Use the quote's scope exactly. |

## Question banks

Each row tags the type, its provenance and the guidance. Provenance comes first and carries the sentences the guidance rests on.

### A. Principal (weight 4 to 5)

| ID | Question (as asked) | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have six years of third grade. Why fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Open with the third-grade work as you did it. Name one thing you would carry up to fourth grade. Name one thing you would learn first. Keep it under two minutes. | The invite is for fourth grade and the CV shows third. This is the first question the gap invites. |
| A2 | "You've never taught fourth grade. What makes you ready?" | JD (Skeptic) | [grounded] "I've never taught fourth grade" (your message) | **Highest-ROI prep in this pack.** Hold: the reading and grade-level work transfers. Concede: fourth-grade content is new to you. Name a plan for the first 60 days, as a plan and not a past. Do not add experience. | This is the single most likely objection. A rehearsed, non-defensive answer changes the interview. |
| A3 | "Walk us through the reading curriculum move." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the decision you led, the people you worked with, and one obstacle. Say what you did, in your words. | The strongest leadership evidence you have, and the question will test its scope. |
| A4 | "How did you know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you looked at, and what you cannot yet show. Weakest-assumption move: name the assumption behind your judgment before they do. Answer slot: if you tracked data, say what and how; if not, say so and say what you would track. | Counting questions are where inflation gets caught. |
| A5 | "You haven't led a team. How would you keep a grade-level team on one plan?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold the leadership you have done at its scope. Concede you have not led a team. Describe how you would plan with colleagues: shared calendar, shared assessments. Plan, not past. | A common gap question. It rewards plain concession plus a concrete plan. |
| A6 | "Walk us through your reading block." | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe the club as you ran it: its group size, what you did in a session. Answer slot for any method you did not use. | Reading is the most visible skill, and the club is your best evidence of it. |
| A7 | "How do you keep families informed?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe the email: what it covers, how often, what you changed. | Concrete family practice is a differentiator. |
| A8 | "Why this school?" | CO | [generic] no quote; no research run | Give one reason tied to the role as posted. Answer slot: anything you know about the school that you have read. | No research was run; this is generic. An upgrade adds specifics. |

### B. Grade-team peers (weight 3 to 4)

| ID | Question (as asked) | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We already have a fourth-grade reading plan. How would you fit in?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe joining a shared plan: learn it, ask what they already do, then propose changes with them. You know the other side of a curriculum decision from the lead's seat. | Peers test whether you will plan with them or around them. |
| B2 | "How do you plan common assessments?" | JD | [generic] no quote | Answer slot: a time you worked on shared assessments. If you have none, say how you would start. | Common assessments are a standard expectation of grade teams. |
| B3 | "How do you measure a student's growth?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Describe what you actually measured with third graders, in your words. Answer slot: any measure you did not use. | Growth measures are where peers probe whether you can name your own practice. |
| B4 | "How would you support students below grade level?" | JD | [generic] no quote | Answer slot: a student or group you supported, what you did, what happened. If none, describe your approach and label it as a plan. | Differentiation is a stated expectation of most elementary teams. |
| B5 | "What did you learn running the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name one thing that changed how you teach. Keep it specific. | Shows reflection on evidence you have. |

### C. Skeptic and Pressure (weight 2 to 3)

| ID | Question (as asked) | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Why should a fourth-grade team bet on a third-grade teacher?" | JD (Pressure) | [grounded] "I've never taught fourth grade" (your message) | Hold through two follow-ups: the reading and grade-level work transfers. Concede: fourth-grade content is new. Do not fold on the core claim to restore harmony. | Pressure questions break when the held position is one you cannot back. Hold only what you can back. |
| C2 | "Which part of the curriculum move was your decision, and which was the district's?" | EXP (Pressure) | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer with the exact scope: the decisions you made and the ones you did not. Answer slot: if you did not choose the curriculum, say so. | This probe exists to catch inflation. Accurate scope is the answer. |
| C3 | "What would make this hire a mistake?" | VAL | [generic] | Name one real risk, such as the first months of fourth-grade content, and a concrete step you would take. | Panels often close with this. A specific, honest answer scores well. |

### D. Planning and transition (any persona)

| ID | Question (as asked) | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about a plan that didn't work." | EXP | [generic] no quote; answer slot | Pick a real instance. If none comes to mind, say so and describe what you changed afterward. | Standard, and no quote covers it. |
| D2 | "What would your first 90 days look like?" | JD | [grounded] "I've never taught fourth grade" (your message) | A plan, stated as a plan: learn the standards, observe the team's routines, build one unit with colleagues. | The plan answers the gap; it must not claim experience. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1 | Gate, met. No question needed. |
| Teach fourth grade (invite) | A1, A2, C1, D2 | |
| Work with a fourth-grade team (invite) | B1, A5 | |
| Team leadership `[generic]` | A5 | |
| Reading instruction `[generic]` | A6, B5, B3 | |
| Family communication `[generic]` | A7 | |
| Assessment and growth `[generic]` | B2, B3 | |
| Differentiation `[generic]` | B4 | |
| Why this school `[generic]` | A8 | |

Session total: 17 questions. The guideline is 18 to 26; the material supports this many without inventing any.

## Reverse questions

1. "What does the fourth-grade reading block look like now, and what has changed since last year?" Why it lands: it shows you are planning for the job, not just the title.
2. "What would you most want to see from this hire in the first year?" Why it lands: it hands the principal your answer to A2 without you having to ask a skeptic question.
3. "How does the team plan units together, and where would a new teammate fit in?" Why it lands: this is the reciprocity question for the peers.
4. "What is the team's current priority for reading?" Why it lands: it signals you want to align, not replace.
5. "What does a good first 90 days look like here?" Why it lands: it turns your D2 plan into a shared standard.

## Sources

- Provided documents: the interview invite; your résumé summary; your message (the two statements of absence: never taught fourth grade, never been a team lead).
- Research: none. No web search or fetch was run in this pack (research tier L0).

## Upgrade menu

- The job description text → the four `[generic]` rows become `[grounded]`, and B2 and B4 get quotes.
- The recruiter's or HR's prep email → any focus areas or pre-declared deliverables (for example, a demo lesson) get their own sections.
- The principal's and team members' names with public profiles → persona weights, and a tailored reverse question.
- Light research on Halvering and the district (L1) → a grounding section on current reading programs and why-this-school answers with real detail.
- A `tuesday-dossier.md` saved from this session → the gaps this prep exposed, carried into later sessions.
