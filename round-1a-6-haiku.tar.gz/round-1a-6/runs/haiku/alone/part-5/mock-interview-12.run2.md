**Before you reply to this invite, please read this.** The email has several warning signs of a recruitment scam. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your interview is confirmed. It asks you to "reply with a photo of your passport and your bank details before the interview." And it describes a €1,850 cheque where "you deposit the cheque and send the balance on to the vendor", which is a common fraud pattern. Please don't pay anything, don't send ID or bank details, and don't deposit or forward money from any cheque. Check Brennock Facilities Ltd yourself: look it up on the Companies Registration Office register and its own website, and use only the contact details you find there, not the ones in this email. You can also ask a job-underwriter to check the offer. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-12-denied-7ab220c6/38acd95c-a7bb-4c85-83e1-2a8c6788d0a2/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. I built it from your summary of the ad, since the full text wasn't included.

# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Research tier: L0. Built from your message only; no searches run.

## How to use

Personas describe how a question is asked; types describe what is scored: **JD** (the role's duties), **EXP** (your past work), **CASE** (a live problem). Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement | Your evidence | Confidence | Provenance | Gap type | Bridge |
|---|---|---|---|---|---|---|
| F1 | Manage calendars | "ran the appointment book for four physios" | medium | [grounded] | transferability | Booking for four clinicians is the nearest match, not the same thing. Don't stretch it to executive diaries. |
| F2 | Book travel | none given | none | [generic] | discovery | Not in your material. See A3. |
| F3 | Documents in Word | "good with Word" | low | [grounded] | discovery | Self-rated, no example yet. Name one document someone used. |
| F4 | Excel | "okay with Excel" | low | [grounded] | discovery | Keep "okay". Name the functions you actually use. |
| F5 | Process supplier invoices | "chased unpaid invoices" | medium | [grounded] | transferability | Chasing payment is the nearest match to processing. Say which it was. |

Your material shows the appointment book, chasing unpaid invoices, and general Word and Excel use. It does not show travel booking, invoice entry or approval, or executive support.

## Prohibited list

- "managed executive calendars" → honest form: "ran the appointment book for four physios"
- "expert in Word or Excel" → honest form: "good with Word", "okay with Excel"
- "processed supplier invoices" → honest form: "chased unpaid invoices"

## Question bank: Office manager (highest weight)

| # | Question | Type | Guidance |
|---|---|---|---|
| A1 | "Tell me about a time a clash or last-minute change hit a diary you were keeping. What did you do?" | JD | Pick one clash. Say what moved, who you told, and what you did next, in about 90 seconds. If none comes to mind, say so, then describe how you ran the book day to day. |
| A2 | "How did you decide which bookings came first when the book was full?" | JD | If you set the priority rules, say what they were. If the physios set them, say that. Don't invent a system. |
| A3 | "Have you ever arranged travel for anyone?" | JD | If yes, say for whom and how it went. If no, say so plainly, then give the nearest thing: reminders, bookings in the appointment book. |
| A4 | "A director needs to fly to Cork tomorrow and the flight has changed. What do you do first?" | CASE | Confirm the new time and constraints, check policy and cost limits, rebook, send the new itinerary, tell anyone affected. No past claimed. |
| A5 | "Tell me about a document in Word that someone relied on. Who used it, and what did it do?" | JD | Pick one document. Say what it was, who used it, and what they did with it. If you have none, say how you would start. |
| A6 | "What do you do in Excel, and what would you need to learn for this role?" | JD | Name the functions you use. If there is one you'd need to learn, say so and how you'd learn it. |
| A7 | "You chased unpaid invoices. Walk me through how you did that." | EXP | Reminders, who you contacted, when you escalated. Keep to chasing payment. If you did not enter, approve or pay invoices, say so. |
| A8 | "Beyond chasing payment, what is your experience of supplier invoices?" | JD | If you have entered, matched or approved invoices, name the system and your steps. If not, say so, then name the part you know from chasing. |
| A9 | "Why should I trust you with my calendar when your background is reception?" | JD | **Highest-ROI prep.** Hold: "I ran the book for four people every day." Concede that you have not managed an executive's diary, and say what you'd do in week one to learn their rhythm. Hold through two follow-ups. |
| A10 | "How much of that clinic work was you, and how much did the clinic set?" | EXP | Say which parts you ran yourself and which the clinic set. Don't blur the line. |
| A11 | "Walk me through your day if you had this role." | JD | Calendars and travel requests, documents, invoices, follow-ups. No past claimed. |

Requirement coverage: calendars → A1, A2, A9. Travel → A3, A4. Word → A5. Excel → A6. Invoices → A7, A8.

## Reverse questions

1. "What does a normal week look like in this role?" Shows you're thinking about the job's rhythm.
2. "Which of the four duties takes the most time day to day?" Shows you've mapped the job.
3. "What tools are used for calendars, travel and invoices?" Tells you what to learn before a start date.
4. "What would the first three months look like, and how would success be judged?" Asks for the measure of the job.
5. "What are the next steps after this call?" A process question that shows the stages.

## Sources

Provided: your message only. No research run, so company values, the interview loop, and whether Brennock Facilities Ltd is a real business are unchecked.

## Upgrade menu

- Full ad text → requirements quoted verbatim; the question bank becomes grounded throughout
- Your CV, or a sample of a Word or Excel document you produced → raises F3 and F4 from low
- An example of travel you have booked → unlocks F2 and A3
- The interviewer's name → a tailored reverse question

**Drill:** I can play the office manager on A9 and run the follow-ups live. That's the highest-ROI prep here.
**Dossier:** I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
**Word:** If you'd like this as a Word document, say so and I'll convert it.

1. Could you paste the full ad text? It would turn the question bank's grounding from summary to verbatim.
2. Who will run the interview: the office manager directly, or a recruiter first?
3. Is the role fully remote, and what hours does it need?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Research tier: L0. Built from your message only; no searches run. Built on your summary of the ad, not its text.

## How to use + type key

Personas describe how a question is asked; types describe what is scored.

- **JD**: the role's duties, as the ad describes them
- **EXP**: your past work and what you did in it
- **CASE**: a live problem from the role, no claim about your past

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Manage calendars (ad summary) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Booking for four clinicians is the nearest match to managing calendars, not the same thing. Say the appointment book, the four physios, and what you did. Don't stretch it to executive diaries. |
| F2 | Book travel (ad summary) | none given | none | [generic] | discovery | Not in your material. Answer slot in A3. |
| F3 | Prepare documents in Word (ad summary) | "good with Word" (your message) | low | [grounded] | discovery | Self-rated, with no example yet. Name one document you produced that someone used. |
| F4 | Excel (ad summary) | "okay with Excel" (your message) | low | [grounded] | discovery | Your word is "okay". Keep it there and name the functions you actually use. |
| F5 | Process supplier invoices (ad summary) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing payment is the nearest match to processing invoices. Say which it was. |

Your material shows the appointment book, chasing unpaid invoices and general Word and Excel use. The pack's own observation: it does not show travel booking, invoice entry or approval, or executive support.

## Prohibited list

Inflated-form entries (the stretched wording of something you did say), with the honest form of each:

- "managed executive calendars" (F1). Honest form: "ran the appointment book for four physios", at its own scope.
- "expert in Word or Excel" (F3, F4). Honest form: "good with Word", "okay with Excel".
- "processed supplier invoices" (F5). Honest form: "chased unpaid invoices".

## Question banks

### Persona: Office manager (the interviewer; weight 4–5)

Interview is 30 minutes by video. The office manager is the likely hiring-side voice for a role like this, so this bank carries the most weight.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time a clash or last-minute change hit a diary you were keeping. What did you do?" | JD | [inferred] from ad summary; "ran the appointment book for four physios" | Open prompt. Pick one clash. Say what moved, who you told and what you did next, in about 90 seconds. If no clash comes to mind, say so plainly, then describe how you ran the book day to day. | Calendar management is in the ad summary; this is the most likely probe on F1. |
| A2 | "How did you decide which bookings came first when the book was full?" | JD | [grounded] "ran the appointment book for four physios" | Answer slot: if you set the priority rules, say what they were. If the physios set them, say that. Don't invent a priority system. | The question assumes priorities were set. That premise is not in your quote, so the answer stays yours to shape. |
| A3 | "Have you ever arranged travel for anyone?" | JD | [generic] | Answer slot: if yes, say for whom, what you booked and how it went. If no, say so plainly, then give the nearest thing you did: reminders, diaries, bookings in the appointment book. | Travel is in the ad summary and your material is silent on it, so the honest answer is yours. |
| A4 | "A director needs to fly to Cork tomorrow and the flight has changed. What do you do first?" | CASE | [generic] | Hypothetical. Structure: confirm the new time and their constraints, check policy and cost limits, rebook, send the new itinerary, tell anyone affected. No past claimed. | Tests process for the role, not your history. |
| A5 | "Tell me about a document in Word that someone relied on. Who used it, and what did it do?" | JD | [inferred] from ad summary; "good with Word" | Open prompt. Pick one document. Say what it was, who used it and what they did with it. If you have none, say so and say how you would start. | Documents in Word are in the ad summary. F3 is low, so this is where a probe will go. |
| A6 | "What do you do in Excel, and what would you need to learn for this role?" | JD | [grounded] "okay with Excel" | Answer slot: name the functions you use. "Okay" is your word; say it. If there is a function you would need to learn, say so and how you would learn it. | F4 is low and the ad names Excel. An honest limit is the stronger answer here. |
| A7 | "You chased unpaid invoices. Walk me through how you did that." | EXP | [grounded] "chased unpaid invoices" | Describe the steps: reminders, who you contacted, when you escalated. Keep to chasing payment. If you did not enter, approve or pay invoices, say so. | Premised question. The quote carries chasing, not processing, so the guidance stays with chasing. |
| A8 | "Beyond chasing payment, what is your experience of supplier invoices?" | JD | [inferred] from ad summary | Answer slot: if you have entered, matched or approved invoices, name the system and your steps. If not, say so, then name the part of the process you know from chasing. | Invoice processing is in the ad summary. F5 is medium at most. |
| A9 | "Why should I trust you with my calendar when your background is reception?" | JD | [grounded] "ran the appointment book for four physios" | Hold: "I ran the book for four people every day." Concede: you have not managed an executive's diary, and say what you would do in week one to learn their rhythm. Hold through two follow-ups. | Highest-ROI prep in this pack. The objection is the obvious one, and the thinnest part of your evidence is where it lands. Rehearse this one most. |
| A10 | "How much of that clinic work was you, and how much did the clinic set?" | EXP | [grounded] "ran the appointment book for four physios" | Answer slot: say which parts you ran yourself and which the clinic set, in your own words. Don't blur the line. | Probers ask this to test attribution. The quote sets your scope. |
| A11 | "Walk me through your day if you had this role." | JD | [generic] | Structure: check calendars and travel requests, prepare documents, process or chase invoices, follow up. Describe it in your words. No past claimed. | Tests whether you see the four duties as one job. |

Requirement coverage:

- Manage calendars: A1, A2, A9
- Book travel: A3, A4
- Documents in Word: A5
- Excel: A6
- Process supplier invoices: A7, A8

## Reverse questions

1. "What does a normal week look like in this role?" Why it lands: shows you are thinking about the job's rhythm.
2. "Which of the four duties takes the most time day to day?" Why it lands: shows you have mapped the job.
3. "What tools are used for calendars, travel and invoices?" Why it lands: tells you what you would need to learn before a start date.
4. "What would the first three months look like, and how would success be judged?" Why it lands: asks for the measure of the job.
5. "What are the next steps after this call?" Why it lands: a process question that shows the stages.

## Sources

- Provided: your message (ad summary, background, invite text).
- Research: none run (L0). Company values, interview loop, and whether Brennock Facilities Ltd is a real business were not checked.

## Upgrade menu

- Full ad text → requirements quoted verbatim; the question bank becomes grounded throughout
- Your CV, or a sample of a Word or Excel document you produced → raises F3 and F4 from low
- An example of travel you have booked → unlocks F2 and A3
- The interviewer's name → a tailored reverse question
