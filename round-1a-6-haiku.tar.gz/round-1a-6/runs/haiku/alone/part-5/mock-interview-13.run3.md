Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-5/rooms/case-13-denied-be72013b/quillmoor_operations-coordinator_interview_pack.md`. It covers the fit gaps, a salary and notice script, the hybrid and "why moving" answers, seven reverse questions for Hannah, and a short check before Thursday. I built it from your message, the advert and your background only. I didn't run any research.

The main points:

- **Pay:** say "£42,000, which sits within the range in your advert," then ask about the band. Don't give your current salary.
- **Why moving:** "Our Bristol office is closing next year. The only offer I've had is relocating to Reading, which I don't want to do." Don't add anything to it.
- **Gaps to be ready for:** the SAP gap (say "never used SAP" and give your plan to learn it), and the production planning and QA coordination the role asks for, which your material doesn't show.
- **The invite:** nothing about it looks like a scam. It's a LinkedIn message and a phone call from the recruiter. Before Thursday, check the posting on Quillmoor's careers page and confirm Hannah's role there. If you call back, use the switchboard number from the company's website.

I haven't invented your notice period or current pay. They're marked as gaps in the file.

Offers, if you want them:
- I can play the Recruiter in a live rehearsal, starting with the pay and "why moving" questions.
- I can save a `tuesday-dossier.md` recording these gaps for later sessions.
- I can convert the pack to a Word document.

Questions, so I can tighten the pack:
1. How confident are you in Excel? Do you use formulas, lookups or pivot tables?
2. What's your notice period, as written in your contract?
3. Have you had any contact with production planning, QA or warehouse work, even indirectly?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep: Operations Coordinator at Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm. Hannah Lowther (Talent Partner) will call Sam's mobile.
**Her agenda (from her message):** salary expectations, notice period, how the hybrid pattern would work, reason for moving; then the team and next steps.
**Built from:** the LinkedIn message, the advert, and Sam's background as Sam described it. No research was run and no dossier was present.

## How to use this pack

- **Personas** describe how a question is asked. This is a recruiter screen, so there is one persona: the Recruiter.
- **Types** describe what is being scored: **Pay** (salary and notice), **Terms** (hybrid and location), **Motivation** (why moving), **Fit** (requirement against experience), **Next** (process and closing).
- Guidance is scaffolding, not a script. Say it in your own words, and only the parts that are true.

## Fit snapshot

Confidence is one of high, medium, low or none. Provenance is one of [grounded], [inferred] or [generic]. Gap type is one of none, transferability, discovery, capability or presentation.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling, not production scheduling, and nothing about QA. Stay with what you did: "I schedule deliveries for our three depots." Answer slot: if you have worked with planning, the warehouse or QA in any way, say how; if not, say so plainly. |
| F2 | "Track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | none | Direct match. Say it as you wrote it: "I chase suppliers when orders slip." |
| F3 | "Keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" (your message) | high | [grounded] | none | Direct match, with a number. Keep the scope exact: you rebuilt the sheet, and the drop in discrepancies took a year. |
| F4 | "Report weekly on on-time dispatch" (advert) | none given | none | [inferred] | discovery | Nothing in your material covers dispatch reporting. Answer slot: have you produced regular reports on delivery or dispatch performance? If yes, say what you measured. If not, say how you would start. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Met. Say the years and the title. |
| F6 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | discovery | The spreadsheet rebuild is evidence, but your level is not stated. Gap to fill: which Excel features you use (formulas, lookups, pivot tables). |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP"; "we run our own in-house stock system" (your message) | none | [grounded] | capability | A gap you have named. Words: "I've never used SAP. We ran our own in-house stock system." Then how you would learn it, as a plan, never as experience. Do not call the in-house system an ERP. |
| F8 | Hybrid, two days a week at Avonmouth (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Direct match. Your limit is three days. |
| F9 | Salary £38,000 to £44,000 (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advertised range. |

## Prohibited claims

Built locally from the fit snapshot. None of the guidance below may assert these.

- **SAP or ERP experience.** You have none. Honest form: "Never used SAP," then your plan to learn.
- **Owning production scheduling or QA coordination.** Your material covers deliveries and suppliers. Honest form: the delivery work, named as delivery work.
- **Weekly on-time dispatch reporting as a past duty.** Not in your material. Honest form: the answer slot in F4.
- **The one-third drop as yours alone.** You rebuilt the sheet, and the year's result may depend on others too. Honest form: "after I rebuilt the sheet, discrepancies fell by about a third over a year."
- **A notice period or current salary.** Neither was given. Do not invent either. See the gaps below.
- **Reading as the only option.** Honest form: "the only offer I've had."
- **A reason beyond the one you gave.** Do not add "I'd have looked anyway" or similar.

## Question bank: Recruiter (weight 100%)

Counter-strategy for this persona: state the fact in your words, then stop and let her move the conversation on.

| ID | Type | Likely question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Pay | "What are your salary expectations?" | "I'm hoping for £42,000" (your message) | "I'm hoping for £42,000, which sits within the range in your advert." Then ask her about the band (Reverse R7). Do not explain the figure. | Pay is the first item on her list. A firm, short answer avoids a negotiation you have not planned. |
| A2 | Pay | "What's your notice period?" | none given | Answer slot. Gap to fill: your notice period as written in your contract. Say it plainly, then stop. | This is needed for her process, and you have not given it yet. |
| A3 | Terms | "How do you feel about two days a week at Avonmouth?" | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | "Two days at Avonmouth is fine. I'd want to keep it to three at most." | Your limit is stated, so say it once and clearly. |
| A4 | Terms | "How would you get to Avonmouth?" | none given | Answer slot. Gap to fill: your usual method and rough time from north Bristol. Give it as fact, not as an estimate you have not checked. | Commute is a likely follow-up to the hybrid question. |
| A5 | Motivation | "What's prompting the move?" | "our Bristol office is closing next year" and "the only offer is relocating to Reading, which I don't want" (your message) | "Our Bristol office is closing next year. The only offer I've had is relocating to Reading, which I don't want to do." Keep it whole. If she asks a follow-up, repeat those words. | Her question asks for a reason, and you have given one. Keep it factual and do not add to it. |
| A6 | Fit | "The role lists SAP or similar. What's your experience?" | "Never used SAP"; "we run our own in-house stock system" (your message) | "I've never used SAP. We ran our own in-house stock system." Then your plan: "I'd learn SAP in the first weeks, starting with stock and delivery screens." Only say the plan if you would do it. | The gap is named in the advert, so she may probe it. |
| A7 | Fit | "Tell me about any production planning or QA work you've done." | "I schedule deliveries for our three depots" (your message) | Answer slot. If none: "I haven't coordinated production planning or QA. What I do is schedule deliveries for three depots and chase suppliers when orders slip." If some: say what, when and your part. | The role asks for planning and QA coordination. Your material does not show it. |
| A8 | Fit | "Tell me about the stock-count spreadsheet you rebuilt." | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" (your message) | "I rebuilt our stock-count spreadsheet. Over a year, discrepancies fell by about a third." Say what you changed in the sheet, in your own words, if asked. | This is your strongest Excel and accuracy evidence. Name the sheet and the result. |

**Highest-return prep:** A5 and A1. Both come early, both are where a recruiter screen tends to end, and both have a fixed answer you can say in under thirty seconds.

## Hybrid and salary script (summary)

- **Pay:** state £42,000, say it is within the advertised range, then ask about the band. Do not give your current salary. If asked for it, say you would rather talk about the role's range.
- **Notice:** give the figure from your contract (gap to fill).
- **Hybrid:** two days is fine. Three is the most you want.
- **Reason:** the office closes next year; the only offer is Reading, which you do not want.

## Reverse questions

| ID | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like across planning, the warehouse and QA?" | Shows you understand the role's span and tests how much of it is yours. |
| R2 | "Which two days would the Avonmouth pattern usually be, and is it fixed?" | Confirms the hybrid arrangement in practice, not in the advert. |
| R3 | "Is SAP in use here now, and what would I be expected to learn first?" | Tests the ERP gap directly and shows you have a plan. |
| R4 | "How is on-time dispatch measured and reported today?" | Clarifies the weekly report, which you have not done before. |
| R5 | "What does the process look like after this call, and what's the timeline?" | Closes on next steps, which is what she will cover last. |
| R6 | "How big is the team, and who would I report to?" | Asks for the team information she said she would give. |
| R7 | "Is the salary band the range in the advert?" | Makes the pay conversation concrete, and lets you answer on the band rather than on guesses. |

## Before Thursday

- **Confirm the call.** Check the posting on Quillmoor's own careers page, and confirm Hannah Lowther's role on the company's site or LinkedIn profile. If anything does not match, ask her to send the details through the careers page.
- **Answer from the company switchboard, not a number she sends you**, if you want to call back. Use the company's website to find it.

## Sources

- Provided: the LinkedIn message from Hannah Lowther; the advert; Sam's background (as stated in this conversation).
- Research: none run. The pack is built on the inputs above only.
- Dossier: none present.
- Target accounting: research tier L0. No search or fetch was run. Interviewer footprint (Hannah Lowther): not researched, so the interviewer read is omitted. Company research: not run. Representative JD: not needed, since the advert was supplied.

## Upgrade menu

- Your notice period, from your contract → the exact answer for A2.
- Your usual commute to Avonmouth → a ready answer for A4.
- Your Excel level (formulas, lookups, pivot tables) → sharpens F6 and A8.
- Any planning, QA or warehouse contact, even indirect → resolves the F1 answer slot and A7.
- Any dispatch or delivery reporting you have done → resolves F4.
- Company research at the default tier → checks Quillmoor's current strategy and the role's loop, which this pack does not cover.
