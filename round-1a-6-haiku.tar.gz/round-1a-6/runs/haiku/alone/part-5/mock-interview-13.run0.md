Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-5/rooms/case-13-denied-fa8c7c49/quillmoor-diagnostics_operations-coordinator_interview_pack.md`.

The pack is built on the advert and your message only. A web search for Quillmoor was refused by the session's permission setting, so it has nothing on their values, interview process or recent news, and it says so.

Three things to know before Thursday:

- **Notice period:** you didn't give one, so the pack doesn't supply a figure. Check your contract and have the number ready.
- **Most likely hard question:** "How does your experience carry over to production scheduling across planning, the warehouse and QA?" Your material shows deliveries across three depots, not production scheduling. The pack gives the held position (what you did, at its real scope) and the concession (the production side is new to you), with follow-ups.
- **Pay and location:** these get your own words only. For pay, that is "I'm hoping for £42,000." For location, "two days at Avonmouth is fine, but I wouldn't want more than three." The pack doesn't suggest flexing either, or going to Reading.

I'd like to offer you a few things:

- I can play the skeptic on the production-scheduling question, to rehearse it live.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, hybrid (two days a week at Avonmouth, Bristol)
**Company:** Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Relationship: recruiter screen, 30 minutes by phone, Thursday 2pm. She will call the mobile number on your application.
**What changed:** first pack, nothing to regenerate.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** EXP = your past, checked for accuracy. JD = can you do the listed job. CASE = a live problem from the role. VAL and CO are not used: no published values were read and no company research ran (see Sources).
- **Guidance is scaffolding, not a script.** Say things in your own words. Where a Provenance cell quotes your words, keep to them.
- **Answer slots** are instructions for the interview. Where a slot says "say what you did", answer from your own experience. If the true answer is "I didn't", say that.

## The fit snapshot

Each requirement from the advert is set against your message. Your message is the only candidate evidence in this pack, and no CV was provided, so every confidence band is capped at medium unless it is your own stated constraint.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say the quote as written. Expect a probe on dates, since nothing inspectable backs it yet. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | transferability | Your material shows scheduling deliveries across three depots, not production schedules, and nothing about planning or QA. Say the quote at its own scope. Answer slot: if you coordinated anything with planning, the warehouse or QA, say what it was; if not, say so, and say which part you would learn first. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Say "chase suppliers when orders slip" as written. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. The one-third figure is a headline claim, so expect a probe on how it was counted (see C1 and C2). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your message says nothing about a dispatch report. Answer slot: if you produced a regular report on delivery timing, say what counted as on time; if you did not, say so and name the measure you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The quote names a spreadsheet, not Excel, and says nothing about which functions you used. Bridge only with the quote. Answer slot: name what you did in it. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | high for the stated negative, medium for the in-house system | [grounded] | transferability | Words: "I haven't used SAP. We run our own in-house stock system." The first is your own negative. The in-house system is adjacent work, not ERP experience, and should be described as such. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own stated constraint, so high confidence. The pattern is met by your statement. Say the quote as written. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your own stated expectation. The pack adds nothing to it and asks nothing about it. |

## Prohibited claims

Built locally from the fit snapshot, since no dossier is present. These are the claims a candidate reaches for under pressure. None of the banks below asserts, softens or implies them.

| # | Claim | Kind | Basis | Honest form |
|---|---|---|---|---|
| P1 | "I have ERP or SAP experience" | inflated form | "Never used SAP" (your message) | "I haven't used SAP. We run our own in-house stock system." |
| P2 | "I coordinated production schedules across planning, the warehouse and QA" | inflated form | "I schedule deliveries for our three depots" (your message) | The quote at its own scope. Observation in analysis: your material shows deliveries, not production scheduling. |
| P3 | "I designed or led the stock-count system" | inflated form | "I rebuilt our stock-count spreadsheet" (your message) | "I rebuilt our stock-count spreadsheet." |
| P4 | "I'm advanced or expert in Excel" | inflated form | "I rebuilt our stock-count spreadsheet" (your message) | The quote at its own scope, plus the answer slot in F6. |
| P5 | "The one-third drop was mine alone" | inflated form | "discrepancies fell by about a third over a year" (your message) | "I rebuilt our stock-count spreadsheet." Who else contributed is an answer slot, not a claim. |
| P6 | A current salary, or any range, floor or counter-offer you have not given | built locally | "I'm hoping for £42,000" (your message) | "I'd rather focus on the range for this role." |
| P7 | A notice period you have not given | built locally | Your message gives none | "Give your actual notice period." |
| P8 | Flexibility beyond three days, or willingness to relocate | built locally | "I wouldn't want more than three" and "which I don't want" (your message) | Your words as written, with nothing added. |

## Personas and weights

**Relationship prior:** a recruiter screen leans conversational, with a light skeptic. The recruiter named four logistics topics (pay, notice, hybrid pattern, reason for leaving), and each one is a scored check in a friendly register.

**Weights:** Conversational 5 questions, Skeptic 4, Data-Driven Prober 4, Pressure 3, Case 2. Total 18.

**Interviewer signals:** none. You gave no interviewer profile, and Hannah is a recruiter, so there is no career pattern to read.

**Loop:** unknown. No loop source was read, so no values round is detected and no archetype is assumed. Persona weights rest on the relationship prior alone.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Pay, notice, hybrid and reason asked in order, with a warm opener | High. Hannah named these four topics, so they will be asked | Say each logistics answer in your own words, once, and stop |
| Skeptic | "You've never used SAP" and "how do you cover production scheduling?" | High for the production and SAP gaps, since the advert names both. This is the likeliest hard question | Hold the quote, then concede the gap plainly |
| Data-Driven Prober | The one-third figure from your CV | Medium. A screen is light, but a headline number draws a probe | Defend the number: how it was counted, and which part was yours |
| Pressure | A short challenge on SAP or on whether you are ready for the scope | Low to medium. A recruiter rarely pressures, but a hiring manager might later | Hold through two follow-ups, then concede the specific limit |
| Case / Strategist | A "three days late" supplier problem | Low for a recruiter screen, more likely in a later round | Clarify before you structure |

## Question banks

Ordered by weight. The most important question is **B2**. It is the single most predictable objection: the advert asks for production scheduling across planning, the warehouse and QA, and your material shows scheduling deliveries. Rehearse B2 until it is dull.

### Conversational / Rapport (weight 5)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, and how you got to this role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Open with the quoted role and how long you did it. Then one sentence on the day-to-day, using the second quote. Stop there and let her ask. Add no scope or title beyond these. | The biography opener is scored for economy. F1 and F3 supply everything it can say. |
| A2 | "What are your salary expectations?" | JD (pay) | [grounded] "I'm hoping for £42,000" (your message) | "I'm hoping for £42,000." Stop. If she asks about the advertised band, say the same figure again: "I'm hoping for £42,000." If she asks what you earn now: "I'd rather focus on the range for this role." Add no range, floor or reason. | A logistics slot. Your figure is the whole answer, and nothing else in the pack challenges or extends it. The advert's band is £38,000–£44,000. |
| A3 | "What's your notice period?" | JD (notice) | [grounded] your message gives no notice period, so this slot is an instruction, not a figure | "Give your actual notice period, in weeks or months, as your contract states it." Then stop. | You have not given a notice period, so the pack supplies none. This is the one logistics answer to know before Thursday. |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD (location) | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say your words as written: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Add nothing about the journey. If asked for the limit, repeat "more than three." | A logistics slot and a stated constraint, so it stays exactly as you said it. A follow-up gets your words again, not a new answer. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say it in your words: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Then, if you can, one sentence on what you are looking for. Answer slot: the pack does not supply that sentence. | A logistics slot: she named the reason as a topic, and your stated reason is the whole answer. Nothing asks why Reading was ruled out. |

### Skeptic (weight 4)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role mentions SAP or a similar ERP. What's your experience there?" | JD | [grounded] "Never used SAP" and "we run our own in-house stock system" (your message) | "I haven't used SAP. We run our own in-house stock system." That first sentence is your own negative, so it can be said plainly. Answer slot: if the in-house system taught you anything about stock records, say what, in your words. Do not say you have used an ERP. | The advert asks for it as a plus. Your material supports a negative for SAP and an adjacent in-house system, and the honest answer is that pair. |
| B2 | "Your work is scheduling deliveries across three depots. This role coordinates production schedules between planning, the warehouse and QA. How does your experience carry over?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); "Coordinate production schedules between planning, the warehouse and QA" (advert) | **Deepest rehearsal.** Open with the quote, at its own scope: deliveries, three depots, chasing suppliers when orders slip. Hold: "That's scheduling across several sites, and chasing suppliers when orders slip." Probe likely: "Did you ever work with planning or QA?" Answer slot: if you did, say what it was; if not, say so plainly and name the part of production scheduling you would learn first. Probe two: "So what's different?" Hold the quote, name the difference in your own words, and do not claim the overlap is bigger than it is. Concede: production scheduling is a different job and would take time to learn. | Highest-ROI prep. This objection is almost certain, and the pack rehearses three levels of it. The held position is the quote, and the concession is the production side. |
| B3 | "The advert asks for a weekly report on on-time dispatch. Have you produced one?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you produced a regular report on delivery timing, say what counted as on time and what you did with it. If you did not, say so plainly and name the measure you would report first. Name no figure or format you did not use. | A mid-list advert item that no quote of yours speaks to. That is silence, so the slot stays open rather than filled. |
| B4 | "How confident are you in Excel, and what do you actually build in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | "I rebuilt our stock-count spreadsheet." Then answer slot: name the functions you used, in your own words. If you used formulas or lookups, name them. If you did not, say what the sheet did. Do not call yourself advanced unless you would show it. | The advert says Excel, and your quote says spreadsheet. The bridge is presentation of that quote, not a claim about Excel skill. |

### Data-Driven Prober (weight 4)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Answer slot: say how it was counted, in your own words, and what it compares. Then name the assumption behind it you would defend least, before she does. If you do not know exactly how the figure was counted, say so. The pack supplies no method, baseline or period. | A headline CV figure, so it gets the defend-the-number slot. The weakest-assumption move turns a gotcha into a credibility gain. |
| C2 | "Which part of that drop was yours, and which was the team's?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Hold the part you did: you rebuilt the spreadsheet. Answer slot: if others changed how counts were done, say so. If you ran the counts yourself, say so. Do not credit the whole change to yourself. | An attribution probe. Honest attribution is what it scores, and inflating the claim is what it catches. |
| C3 | "Walk me through how you scheduled deliveries across the three depots." | EXP | [grounded] "I schedule deliveries for our three depots" (your message) | Tell the story from the quote: what you scheduled, for which three depots. Answer slot: if you decided which delivery went first, say how you decided; if someone else set that, say who. | A prober wants the method. The method is an answer slot, not something the pack supplies. |
| C4 | "When a supplier order slips, how do you know, and what do you do first?" | JD | [grounded] "chase suppliers when orders slip" (your message); "track supplier deliveries and chase late orders" (advert) | Story beats from the quote: the slip, then the chase. Answer slot: how you learned that an order had slipped, in your own words. If a system flagged it, say so. If you noticed it yourself, say that. | The "how you know" is a further beat the quote does not carry, so it is an answer slot. |

### Pressure / Stress (weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never used SAP over someone who has?" | JD | [grounded] "Never used SAP" (your message) | Hold: "I haven't used SAP. We run our own in-house stock system, and the stock-count work I did is on that side of it." Hold through two follow-ups. Concede the specific limit: learning SAP would take time. Do not claim ERP experience to win the exchange. | The pressure version of B1. It rehearses the hold-then-concede structure. |
| D2 | "Four years at one wholesaler. Is this a step up or a step sideways?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Hold: "It's the same kind of job, in a different sector, and the sector is what I'd need to learn." Hold through two follow-ups. Concede what is real: the sector and the production side are new to you. | A stress question on your background. It tests composure, not content. |
| D3 | "The role works closely with QA. What would you need to learn first?" | JD | [grounded] "Coordinate production schedules between planning, the warehouse and QA" (advert) | Answer slot: name one thing you would learn first, in your own words, and why it comes first. Do not name a QA process you have not worked with. If the answer is that QA sets the rules, say you would learn them from QA. | The concession drill for B2's production side, asked under pressure. |

### Case / Strategist (weight 2)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A key supplier's delivery is three days late and the production schedule can't move. Walk me through what you do first." | CASE | [grounded] "track supplier deliveries and chase late orders" (advert). The method is [generic]. | Clarify first: which order, what depends on it, who needs to know. Then confirm the impact with planning and the warehouse, chase the supplier, and set a revised date for the schedule. Think aloud and take one check at a time. | The advert's job in one scenario. Your material covers chasing, not production planning, so the method is a generic one and the question asks nothing about your past. |
| E2 | "Your stock records and the physical count disagree. How would you find out why?" | CASE | [grounded] "keep stock records accurate" (advert). The method is [generic]. | Clarify the count's date and who counted. Compare the record and the count item by item, find where the gap starts, then fix the cause rather than the single line. | A live problem from the advert. It presupposes nothing about you. |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B2, D3 |
| Track supplier deliveries and chase late orders | C4, E1 |
| Keep stock records accurate | C1, E2 |
| Report weekly on on-time dispatch | B3 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B1, D1 |
| Hybrid, two days a week at Avonmouth | A4 |
| Pay, £38,000–£44,000 | A2 |
| Notice period (not in the advert, asked by the recruiter) | A3 |
| Reason for leaving (asked by the recruiter) | A5 |

## Reverse questions

Five questions to ask Hannah, each with why it lands. None of them asks her to check anything about the role's terms for you; they are for you to learn.

1. **"Who would I work alongside day to day, between planning, the warehouse and QA?"** Why it lands: it shows you are already thinking about the seam B2 is about.
2. **"How is on-time dispatch measured today, and what does the weekly report look like?"** Why it lands: it shows you read the advert closely, and it gives you the answer to B3 from the other side.
3. **"Which systems do planning and stock run on day to day?"** Why it lands: it tests the SAP plus directly, and her answer tells you whether the in-house system you know carries over.
4. **"How is the Avonmouth pattern set, by team or by role?"** Why it lands: it confirms how the two days will work without you asking about the journey, which is a topic you have already answered.
5. **"What happens after this call, and roughly when?"** Why it lands: she named next steps as a topic, so asking shows you were listening.

## Sources

- **Provided documents:** the advert text (Operations Coordinator, Quillmoor Diagnostics), and your message, covering the recruiter's note, your background, your position on pay, location and the reason for leaving.
- **Research tier:** L0. One web search was attempted and refused by the session's permission setting, so no search or fetch ran. Nothing in this pack about Quillmoor's values, interview process, strategy or recent news is established.
- **Search sent:** "Quillmoor Diagnostics diagnostic test manufacturer Avonmouth Bristol", refused, not retried.
- **Target accounting:** 1 company values: unavailable. 2 interview process: unavailable. 3 strategy or news: unavailable. 4 interviewer footprint: n/a, since the contact is a recruiter with no profile. 5 representative JD: skipped, since the advert was supplied.
- **Dossier:** none present.
- **Not included, by rule:** prep triage (no prep time stated), values cheat sheet (no values round detected), grounding brief (no deeper research run), interviewer read (no profile), graded deliverables (none declared), delivery coaching (no assessment provided).

## Upgrade menu

- **Your notice period** → fills A3 with your own figure. Without it, that slot stays an instruction.
- **Your CV** → quotes a document in place of your message, so F1 to F4 can rest on something checkable, and C1 gets a number you can point to.
- **Permission for one web search on Quillmoor's values and recent news, or a pasted values page** → company-knowledge questions and a values check. Without it, the pack has none.
- **Any test or exercise the recruiter has mentioned** → coverage for a pre-declared deliverable, if one exists.
- **The hiring manager's name, if the process moves on** → persona weights from their public footprint.
- **A deeper research pass** → up to 6 more searches and 2 more fetches, several more minutes. Want it?
