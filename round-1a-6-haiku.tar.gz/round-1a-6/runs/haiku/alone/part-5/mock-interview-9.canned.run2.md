Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-9-canned-2b59def9/5b557499-52e7-4e12-b127-42f58530a026/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it on the assumption that the principal is your hiring manager and the two team members are peers.

Your message included your Social Security number. The prep doesn't need it, so I haven't used or repeated it. Don't give it to anyone during the hiring process unless they have a verified need.

Your biggest gap is the fourth-grade experience. Question A1 is the one to rehearse first: "You've never taught fourth grade. Why should we hire you?" The pack has you acknowledge that plainly, then point to your six years of third grade, without stretching that into fourth-grade work.

Say the word and I'll play the Skeptic on A1 in a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who would be your direct supervisor on this panel: Principal Vantongeren, or one of the team members? The answer changes how the question banks are weighted.

Do you have the full job posting? If not, the pack works without it, and the posting would sharpen the fourth-grade questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · 45-minute panel · Principal Dolores Vantongeren and two fourth-grade team members · Thursday

Built at research tier L0 (your invite and CV only; no searches run). Assumption: the panel is the principal as hiring manager plus two peers on the team.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **VAL** values, **EXP** your experience, **JD** the job's requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and stop where your own experience stops.
- Answer slots (sentences ending in "say so plainly") are instructions for the interview. Use the branch that is true for you.

## Prep triage

Prep time was not stated, so no schedule is set. The single most important item is question A1 and A2: the fourth-grade gap. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | No gap. Say it as written: your license is active through June 30, 2029, with the elementary endorsement. Have the license on hand. |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV; "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | capability | The stated absence is yours, so the words are yours: "I haven't taught fourth grade. For six years I taught third grade at a public elementary school in Joliet." Then a plan for learning fourth-grade content, said as a plan and never as a past. Never describe fourth-grade work you have not done. |
| F3 | Grade-level team collaboration — [generic], role-family requirement, no source quote | "I've never been a team lead" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | low | [grounded] | capability | The stated absence is "I've never been a team lead." The adjacent work stays at its scope: you led one grade-level move, the reading curriculum in 2024. Do not stretch it into a leadership role. |
| F4 | Reading instruction — [generic], role-family requirement, no source quote | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years" — your CV | medium | [generic] | none | The quote reaches reading instruction directly. Keep to its scope: a grade-level curriculum move and two years of an after-school club. |
| F5 | Family communication — [generic], role-family requirement, no source quote | "I write a weekly email to families" — your CV | medium | [generic] | none | The quote reaches the requirement. Say what you do with it, in your words. Your material does not show what the emails contain or how families respond; if asked, say so and describe what you would do. |

Observation, not words for you: your material shows a grade-level reading move and a club. It does not show a school-wide decision, or any fourth-grade planning.

## Prohibited claims

Not coached in this pack, because your material does not carry them.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Inflated form of F2 and stated negative | "I've never taught fourth grade," plus the third-grade quote at its own scope. No slot asks for fourth-grade work. |
| Team lead experience | Stated negative, F3 | "I've never been a team lead." Plain acknowledgment, with no slot. |
| A school-wide reading program you led | Inflated form of F4 | "I led our grade level's move to a new reading curriculum in 2024." Your material says grade level, not school. |

## Persona table

The panel is a blend: the principal is a hiring manager, and the two team members are peers.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal, and one peer on the fourth-grade gap | "You've never taught fourth grade" and "never been a team lead" | High, weight 5. F2 and F3 are the largest gaps and the invite is for a fourth-grade role | Acknowledge plainly, bridge at your own scope, hold through two follow-ups |
| Case / Strategist | Principal | A live problem with a new student or a new reading routine | Medium, weight 3. Hiring managers buy capability | Clarify, then your reading experience |
| Peer Evaluator | Team members | "What would you need from me," "how do you handle disagreement" | Medium, weight 3. A panel with two peers tests partnership | Reciprocity: what you bring the team, not only what you need |
| Data-Driven Prober | One peer | "How did you judge it was working" | Lower, weight 2. Your material has no figures, so probes target the reading move and the club | Say what you tracked, and if nothing, say so |
| Conversational / Rapport | Principal, opener | "Tell us about yourself" | Lower, weight 2. The opener is scored | A 90-second arc |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. Why should we hire you for this position?" | JD | [grounded] "I've never taught fourth grade" — your CV | The highest-ROI rehearsal in this pack. Acknowledge plainly: "I haven't taught fourth grade." Then the third-grade base at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if you have had hands-on contact with fourth-grade work, say when and what; if not, say so plainly and go to your plan for learning it. Hold through two follow-ups by returning to the third-grade base | F2 is the position's central gap, and this probe is the one most likely to arrive in some form |
| A2 | "What part of fourth grade would you be weakest at on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Name one specific area, and say what you would do in the first month to learn it. Do not claim knowledge you lack. Answer slot: if any fourth-grade material or standard is familiar from your third-grade work, say which; if none is, say so | Skeptic stem about F2; asks for a plan, not a past |
| A3 | "You've never been a team lead. What would you do if a colleague disagreed with a team decision?" | JD | [grounded] "I've never been a team lead" — your CV; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Acknowledge plainly. Then the curriculum move, at its scope: say what you led and how you brought colleagues along, in your own words. Answer slot: if a disagreement came up during that move, say what it was and how it was settled; if none did, say so | F3 is a stated absence; this question tests whether you can speak to it honestly |
| A4 | "What is drawing you to a fourth-grade role at this point?" | EXP | [generic] | Give the real reason in your own words, tied to fourth grade specifically. If you are not sure yet, say what you would most want to learn, and that you are still forming it | Motivation probe. The material gives no reason, so the answer must come from you |

### B. Case / Strategist — principal (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A new student joins your class reading two years below level in week three. What do you do first?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Clarify first: what the reading assessment shows and what the student has already been given. Then the approach, drawing on the curriculum move at its scope. Answer slot: if you have used the curriculum with a struggling reader, say what happened; if not, say so and describe your plan | F4 is the reading evidence this live problem tests |
| B2 | "Walk us through how you would start the year with a grade-level team you have just joined." | CASE | [generic] | Structure: what you would learn about the team's plans first, what you would bring, how you would agree on shared work. Make no claim about this team | The live problem for the team you would join; it presupposes nothing about your past |
| B3 | "How would you keep families informed about a new fourth-grade reading routine?" | JD | [grounded] "I write a weekly email to families" — your CV | Start from the weekly email. Say what you would include for a new routine and how families would reply or ask questions. Answer slot: if you have seen how families respond to a change, say what you saw; if not, say so | F5 is the family-communication evidence; the rest is a plan |

### C. Peer Evaluator and Data-Driven Prober — team members (weight 3 and 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We share a reading block. How would you divide the work with us?" | JD | [generic] | Name the seam: which parts you would own and what you would need from the team. Propose a principle, not a split you cannot know yet | Peer seam question; asks for a principle, not a past |
| C2 | "How do you handle disagreement with a colleague about a unit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Tell a disagreement story only if one happened, at the curriculum move's scope. Answer slot: if a disagreement came up on that move, say how you handled it; if none did, say so and describe how you would approach one | Tests peer-style disagreement; this is the one story your material offers |
| C3 | "How did you judge whether the 2024 reading move was working, if you did?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say what you tracked and how often. Answer slot: if you tracked nothing formal, say so plainly and say what you would track next | Data-driven probe; the material shows no measure, so the honest branch must be ready |
| C4 | "Walk us through the after-school reading club: how it ran, and how you would know it worked." | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Describe how the club runs week to week, in your own words. Answer slot: if you counted attendance or reading results, say which and how; if you did not, say so | Club is your strongest reading evidence; the figure question is answered only from your own counting |

### D. Conversational / Rapport — opener (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | A 90-second arc: your license and endorsement, six years of third grade, the 2024 reading move, the club, the family emails. Stop at the point where your material stops | The opener is scored; it sets up A1 by stating the third-grade base first |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Illinois PEL with elementary endorsement (invite) | — none, and why | Stated as met (F1). Have the license on hand; no question needed |
| Fourth-grade position (invite) | A1, A2, A4 | Central gap F2 |
| Grade-level team collaboration ([generic]) | A3, C1, C2 | F3 is a stated absence |
| Reading instruction ([generic]) | B1, C3, C4 | F4 |
| Family communication ([generic]) | B3 | F5 |

## Reverse questions

1. "What does a typical week look like for the fourth-grade team?" Why it lands: shows you are planning for the work, not only the title.
2. "How are units planned across the grade, and who sets them?" Why it lands: tests how much room a new teacher has.
3. "What would you most want the new teacher to have figured out by October?" Why it lands: the principal can answer with real expectations.
4. "What has changed in the reading program since last year?" Why it lands: shows you care about the current program, not an old one.
5. Peers: "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, and it turns the seam question into a joint one.
6. Principal: "What would make this role a success in the first year?" Why it lands: gives the principal a chance to name the gap they most want closed.

## Sources

- Provided: your invite text, and your CV as pasted in your message.
- Research tier: L0. No search or fetch was run in this turn.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary values` | unavailable | Values cheat sheet, section 10; not run at L0 |
| 2. `Orrinsford interview process fourth grade teacher` | unavailable | Loop structure; persona weights follow the panel shape already given |
| 3. `Halvering Elementary news` | unavailable | Grounding brief; not run at L0 |
| 4. `Dolores Vantongeren Halvering` | unavailable | Interviewer read and persona weights for the principal; not run at L0 |
| 5. representative `Fourth Grade Teacher` job posting, Illinois | unavailable | Would turn the requirements in F2 through F5 into `[inferred]` requirement lines; not run at L0 |

## Upgrade menu

- The full job posting → the requirements in F2 to F5 become quoted, and questions A2 and B3 sharpen
- Which panel member would you report to → persona weights per member, and a sharper peer or principal split
- Research at L1, which is six searches and two fetches, offered once → company values, interview process, and a grounding brief on the school
- The principal's public footprint, if you want it researched → an interviewer read and a tailored reverse question
- `tuesday-dossier.md` → one line on what it would add: a record of this prep's gaps, carried into later sessions
