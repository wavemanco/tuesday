Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Hold off on sending any documents, bank details or ID until you've checked the invite with the company through contact details you find yourself, on its website or careers page, not through this chat, its numbers or its links. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-10-denied-626871b8/1a25dccf-2619-4483-bfae-9e3f2ebd9d19/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. It covers a fit snapshot against the ad, the claims to avoid overstating, three question banks (Skeptic, Case, Conversational), five reverse questions and the research accounting. I built it without searching, so it doesn't cover Lumenvale's values or interview process.

Say the word and I'll play the Skeptic on A1, the question the pack names as the highest-value prep: "Why support at a software company, given you've never worked for one?"
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the team lead you'll be talking to your future manager, or a peer on the team? The answer changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** support team lead (name not given). Round: text chat. Relationship not yet confirmed, so weights use the round-type prior.

## How to use

Personas describe **how** a question is asked. Types describe **what** it is scoring. Guidance is scaffolding, not a script: rehearse the beats in your own words, and only say what you actually did.

| Tag | Name | Meaning |
|---|---|---|
| VAL | Values / behavioural | Whether past behaviour shows the company's values |
| EXP | Experience deep-dive | Whether your CV claims hold up under questions |
| JD | Role / job-ad driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | How much you know about Lumenvale |
| CASE | Live problem | How you structure a support problem as it happens |

## Fit snapshot

Requirements marked "your summary" are paraphrased from your own description of the ad. They are not the ad's exact words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | The years are covered by your own words: "I have 3 years as a customer service advisor at an energy supplier." Say the job title and sector as they are; the role is customer-facing, not a software support role. |
| F2 | Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is the same category the ad names. Say you use it every day, in those words. Do not claim Zendesk. |
| F3 | Clear written communication (your summary of the ad) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training people shows explaining skill, but the material does not show whether it was written. Answer slot: if you wrote something a customer or colleague acted on, say what it was; if not, say how you would write a reply to an upset customer. |
| F4 | Confidence handling escalations (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show an escalation you handled. Answer slot: if any escalation was yours to decide or pass on, say what you did and why; if none was, say so and say how you would approach the first one. |
| F5 | Software-company experience (not in the ad; your own message) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked for a software company." Then how you would learn their product, said as a plan, never as a past. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Not in your material; the ad asks for it | "I use Freshdesk every day." If asked about Zendesk, say what you use now and how you would learn it |
| Software-company experience | Negative you stated (F5) | "I've never worked for a software company." No slot beyond the learning plan |
| Handling or running escalation processes | Inflated form of F4 | F4's answer slot only |
| Resolution rates or satisfaction scores | Not in your material | The volume you stated: "around 60 calls and emails a day" |
| Designing the refunds process | Inflated form of your training line | "I trained four new starters on our refunds process last year." |

## Persona weights

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | High (top) | Your software-company gap and the escalation gap are the two obvious probes; a team lead will ask about both | Rehearse A1 until it is plain; hold your answer through a follow-up |
| Case / Strategist | Medium | A support team lead usually tests live problems from the queue | Clarify, then structure: acknowledge, check facts, decide or escalate, follow up |
| Conversational | Medium-low | Chat openers are friendly but still scored, especially on written clarity | Keep a 90-second version of your background ready |

Depth: Skeptic 4 questions, Case 3, Conversational 2.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why support at a software company, given you've never worked for one?" | JD | [grounded] "I've never worked for a software company" (your message) | Say it plainly: "I haven't worked for a software company." Then the transferable part, in your words: three years of answering customers. Then one concrete plan for learning their product in the first weeks. | F5 is the most predictable objection; rehearse until it is boring |
| A2 | "Your experience is in energy. Which part of this role would you be weakest at on day one?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message) | Name product knowledge as the weak point, since no quote covers it. If a ticketing tool comes up, say what you use daily. Answer slot: the ad's escalation requirement (F4) may come up here too; use F4's branch. | F2 and F4 are where a day-one probe lands |
| A3 | "Tell me about an escalation you handled. What did you decide, and what did you pass on?" | EXP | [grounded] no quote; your material shows no escalation | Answer slot: if an escalation was yours to decide or pass on, tell it in your own words. If the cases you dealt with were passed on, say so and say what you did first. | F4 is a discovery gap; do not invent an escalation |
| A4 | "Refunds is the process you trained others on. Where did you have to decide something outside the script?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Describe what you taught. Answer slot: if a decision outside the script was yours, say what and why; if the process was not yours to change, say that. | Tests whether the training line is what you did or what you watched |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: they were charged twice. What is your first reply, and when do you escalate?" | CASE | [generic] | Acknowledge, confirm the facts, check the refund route, decide what you can, escalate what you cannot, and say when they will hear back. | Live problem; F4 is in play here |
| B2 | "Walk me through how you would triage a queue of 60 tickets on a Monday morning." | CASE | [grounded] "answering around 60 calls and emails a day" (your message) | Use the volume you stated as your scale. Sort by urgency and by what blocks the customer, then work down. | Gives you a real scale to reason from |
| B3 | "A customer asks for a feature we don't have. Reply to them in writing now." | CASE | [generic] | Write a short reply: thank them, say what is and is not possible, and offer the next step. Keep it plain. | F3's written-communication gap is tested directly; the chat itself is the medium |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about your journey into customer service." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | A 90-second arc: three years, energy supplier, daily Freshdesk, then training others. | Opener; sets the tone for the chat |
| C2 | "What are you playing with in ticketing tools these days?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say Freshdesk, daily. Any other tool is a plan to learn, not a past. | F2 is the strongest tool-related line you have |

## Reverse questions

1. "Will there be a call or video stage after this chat?" Why it lands: tells you what to prepare for next.
2. "How many tickets does a typical person in this role handle each day?" Why it lands: lets you compare with the 60 a day you already handle.
3. "Which ticketing tool does the team use day to day?" Why it lands: shows whether your Freshdesk experience carries over.
4. "How are escalations handled: who decides, and how quickly do they move?" Why it lands: answers F4 with their real process.
5. "What does onboarding look like in the first few weeks?" Why it lands: shows what the ramp plan in A1 needs to cover.

## Sources

- Provided documents: your message (the invite text) and your description of the job ad and your background.
- No searches or page fetches were run.

Research tier: L0, provided documents only (searches 0 of 0, fetches 0 of 0).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | A values cheat sheet; not run at this tier |
| 2. Lumenvale interview process | unavailable | Loop structure; persona weights would follow the stated rounds |
| 3. Lumenvale strategy / recent news | unavailable | Company knowledge bank (CO) |
| 4. Interviewer name and profile | n/a | No interviewer name was given; the invite names a talent-team sender, not the interviewer |
| 5. Representative job ad | skipped | Your description of the ad fixes the fit snapshot |

## Upgrade menu

- Full job-ad text, pasted → the four requirements become exact quotes, and the paraphrased rows get their sources.
- The team lead's name → persona weights from their public footprint, and a tailored reverse question.
- Lumenvale's careers page text, pasted → a values cheat sheet and company grounding.
- Research at L1 → company values and interview process, if you want them searched.
- Your `tuesday-dossier.md` → verified evidence and sharper prohibited claims carried into this pack.
