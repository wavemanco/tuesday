I've built the pack and saved it to `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-13-denied-5fafb1a0/c18811b5-fff7-414a-9509-a57c57c1470c/scratchpad/quillmoor_recruiter_screen_pack.md`. I didn't run any web research, so everything comes from the advert, Hannah's message and what you told me.

**Before Thursday**
- Check the LinkedIn thread for the date. "Thursday" has no date attached.
- Make sure the mobile number on your application is the right one and is switched on.
- Confirm Hannah Lowther is a Quillmoor contact on their careers page or through the posting you applied on, not only on LinkedIn. The message has no payment or bank requests, so it reads as ordinary scheduling.

**Where you fit**
- **Meets the brief:** 4 years of logistics coordination, chasing suppliers, and the stock-count work that brought discrepancies down by about a third.
- **Gaps:** no production scheduling or QA exposure, no SAP, and no evidence of weekly on-time dispatch reporting. Don't claim any of these.
- **Pay:** your £42,000 sits in the upper half of the £38,000–£44,000 range.

**Likely questions and how to handle them**
- **Salary:** say "£42,000" once and stop. If she asks what you earn now, decline without giving a figure.
- **Notice period:** I don't have it, so you'll need to give the contract figure.
- **Hybrid:** say two days is fine and three is the most you'd want.
- **Why leaving:** say the office is closing and the only offer is relocating to Reading, which you don't want. Add nothing.
- **Biggest risk:** "building supplies, not diagnostics, and no SAP." Concede both plainly, then bridge to scheduling across three depots, chasing suppliers, and the stock-count result. Rehearse this one most.
- **Dispatch reporting:** if you haven't done weekly on-time reporting, say so and say how you'd learn it. Don't stretch.

**Reverse questions to ask:** what the weekly dispatch report looks like today; which stock or ERP system the team uses and whether SAP is planned; and what the next steps are and who you'd report to.

**Upgrade menu**
- Your notice period, which unlocks a real answer to her notice question.
- The Excel functions you've actually used (lookups, pivots, formulas), so the Excel claim is accurate.
- Whether you've ever produced a weekly or KPI report.
- Any team or manager details, which would sharpen the reverse questions.
- The date of the call.

I can run a live rehearsal of the "building supplies, not diagnostics" question with Hannah playing the interviewer and give feedback on your answer. I can also add a dossier file so later prep builds on this one. Say if you want either.

Answer these three so I can tighten the pack:
1. What is your notice period?
2. Which Excel functions have you used in the stock-count spreadsheet?
3. Have you ever produced a weekly or on-time report?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_recruiter_screen_pack.md -----
# Recruiter Screen Prep: Operations Coordinator, Quillmoor Diagnostics

**Candidate:** Sam · **Recruiter:** Hannah Lowther, Talent Partner · **Format:** 30-min phone call, Thursday 2pm, on the mobile number from the application
**Research tier:** L0 (provided documents only). No external research was run. Company facts below come only from the advert and Hannah's message; anything else is marked `[generic]`.

## Verify before the call

- **Which Thursday.** Hannah's message says "Thursday at 2pm" with no date. Check the LinkedIn thread for the date.
- **The number she calls.** She said she will ring the mobile on your application. Make sure that number is current and that your phone is on.
- **Who she is.** The invite itself is an ordinary scheduling message: no fee, no equipment, no bank or ID details. Still, confirm Hannah Lowther is listed as a Quillmoor contact on the company's careers page or through the job posting you applied through, rather than only on LinkedIn.

## Fit snapshot

Quotes are from Sam's own material. Gap-and-bridge language is written for Sam to say only where it is true.

| Requirement (advert) | Sam's evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | High | None | Meets. Say it plainly. |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots and chase suppliers when orders slip." | Medium | Domain | "I've scheduled deliveries across three depots, not production runs, and I haven't worked alongside QA. What I do bring is coordinating several moving parts against dates." |
| Track supplier deliveries and chase late orders | "I chase suppliers when orders slip." | High | None | Meets. Give one concrete example only if Sam has one. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." | High | None | Meets. Keep "about a third" and "over a year" exactly. |
| Report weekly on on-time dispatch | Not in Sam's material. | Unknown | Evidence | Answer slot. See the upgrade menu. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet." | Medium | Evidence (depth) | Only claim the Excel depth Sam can show. Confirm the functions Sam has actually used. |
| ERP (SAP or similar) a plus | "Never used SAP — we run our own in-house stock system." | High (as a gap) | Experience | "I haven't used SAP. Our stock system was in-house, and I used it day to day to keep counts accurate." |

**Salary fit:** advert £38,000–£44,000. Sam's figure is £42,000, which sits in the upper half of the range.

## Prohibited claims

Sam should not say any of the following, because the material does not support them:

1. Any SAP or ERP experience.
2. Production scheduling, manufacturing or QA experience.
3. Any weekly dispatch or on-time reporting, unless Sam confirms it.
4. That the discrepancy drop was entirely Sam's doing. The material says "rebuilt" and "fell by about a third"; keep it at that.
5. Any knowledge of Quillmoor, its products or its sites beyond the advert.

## Interviewer read

Not applicable. No interviewer profile was provided. Persona weighting uses recruiter-screen priors: pay, notice, location, motivation, then basic fit.

## Question banks

### Persona: Recruiter screen (weight: high on logistics, pay, notice, location)

**Q1. Salary expectations.** `question_type: logistics/pay`
- **Provenance:** Sam's own statement: "I'm hoping for £42,000."
- **Guidance:** Say the figure once, in those words. Stop. Don't justify it. If she asks a follow-up, repeat "£42,000" and say nothing more. If she asks what Sam earns now, decline without giving a figure.
- **Rationale:** Pay is the first item on her agenda. A clean, unexplained number is the strongest position.

**Q2. Notice period.** `question_type: logistics/availability`
- **Provenance:** Not in the material. This is an answer slot. Sam fills in the real notice period before the call.
- **Guidance:** State the notice period as it is in the contract. Don't round it down.
- **Rationale:** She listed it explicitly. The material has no figure, so the answer must come from Sam.

**Q3. How the hybrid pattern would work.** `question_type: logistics/location`
- **Provenance:** Sam's own statement: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- **Guidance:** Say it as written. If she asks about the commute, Sam should check the real journey time before the call and give only that number.
- **Rationale:** The advert says two days. Sam's limit of three leaves room without making a demand.

**Q4. What is prompting the move.** `question_type: motivation`
- **Provenance:** Sam's own statement: "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."
- **Guidance:** Give the reason as written: office closing, and the only offer is relocation. Don't add more. Don't criticise the company that's closing.
- **Rationale:** She asked why Sam is leaving. The honest answer is also a clean one.

**Q5. The most likely objection: "Your experience is building supplies, not diagnostics, and you haven't used SAP."** `question_type: fit/objection` `[highest-ROI prep]`
- **Provenance:** Sam's own statements: "4 years as a logistics coordinator at a building-supplies wholesaler" and "Never used SAP — we run our own in-house stock system."
- **Guidance:** Concede both facts first, then bridge. Example: "That's right: building supplies, not diagnostics, and no SAP. What I do have is four years of scheduling deliveries across three depots and chasing suppliers when orders slip, plus the stock-count work that cut discrepancies by about a third."
- **Rationale:** This is the objection most likely to end the call. Rehearse the concession and the bridge until they come out evenly.

**Q6. "How would you handle weekly on-time dispatch reporting?"** `question_type: fit/evidence` `[answer slot]`
- **Provenance:** Not in the material. Answer slot.
- **Guidance:** If Sam has produced this kind of report, describe exactly what was done. If not, say so and say what Sam would need in order to learn it.
- **Rationale:** This is a stated requirement with no evidence behind it. An honest "not yet, here is how I'd learn it" beats a stretched claim.

### Persona: Recruiter screen, after questions

**Q7. "Anything else you'd like us to know?"** `question_type: close`
- **Provenance:** Sam's own material: the stock-count result is the strongest closing fact.
- **Guidance:** One sentence: the stock-count work, discrepancies down about a third over a year. Then stop.
- **Rationale:** It's the only quantified result in the material. Use it once.

## Reverse questions

Ask two or three, not all of these.

1. **What does the weekly on-time dispatch report look like today?** Why it lands: it's the requirement Sam has no evidence for, so the answer shows exactly what the job expects.
2. **Which stock or ERP system does the team use, and is SAP in place now or planned?** Why it lands: it tests the gap in Q5 directly and shows whether training is expected.
3. **What are the next steps, and who would Sam be reporting to?** Why it lands: it's routine and gets the process into the open.

## Upgrade menu

- **Notice period** (Q2): the contract figure unlocks a real answer.
- **Excel depth** (fit snapshot): the functions Sam has actually used, such as lookups, pivots or formulas, so the Excel claim is accurate.
- **Dispatch reporting** (Q6): whether Sam has ever produced a weekly or KPI report.
- **Team and manager details**: unlocks a team-specific reverse question.
- **Date of the call** (verify section): confirms which Thursday.
