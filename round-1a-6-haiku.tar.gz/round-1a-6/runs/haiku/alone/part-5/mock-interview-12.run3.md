**Before you prepare anything, check this invite.** It asks you to pay money and send sensitive details before any job is confirmed. Your message says it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and to "deposit the cheque and send the balance on to the vendor". Real employers don't charge candidates for interviews or equipment, and depositing a cheque and forwarding part of it is a common fraud pattern. Don't pay, don't send ID or bank details, and don't deposit or forward any cheque. If you want to check the company, look it up through an independent source such as the Companies Registration Office (if it's Irish) and contact it using details you find yourself, not the ones in this email. You can also ask a job-underwriter to review the invite before you reply.

The pack below is built from your message only, with no web research. I assumed a 30-minute screening call with a non-technical office manager. It's useful for interview practice whether or not this company is genuine.

## Fit snapshot

| Requirement (ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | High | Partial: tool not stated | Bridge: "I scheduled for four people at once and handled conflicts daily." Name the calendar software you have used, if any. |
| Booking travel | None in your material | Low | Missing evidence | Don't claim it. Use an answer slot: "I haven't booked business travel. Here's how I'd learn quickly." |
| Word documents | "good with Word" | Medium | Self-rated | Show one real example of a document you produced. |
| Excel | "okay with Excel" | Medium | Self-rated | Name a specific thing you've done in Excel. If nothing comes to mind, say "basic" and don't inflate it. |
| Supplier invoices | "chased unpaid invoices" | Medium | Partial: chasing is not processing | Bridge: "I chased unpaid invoices. I haven't processed supplier invoices from start to finish." |

## Persona weights

- **Office manager (primary):** practical, checks daily-task fit and reliability. Weight high.
- **Hiring-side panel/HR (assumed absent):** weight low, since the invite lists only the office manager.

## Question banks

**Provenance: "ran the appointment book for four physios"**
1. *Walk me through your receptionist role.* Lead with the appointment book for four physios and the invoice chasing. Keep it to what you did, not what the team did.

**Provenance: "chased unpaid invoices"**
2. *How have you handled supplier or client invoices?* Say you chased unpaid ones. Don't say you processed or posted invoices unless you did.

**Provenance: "good with Word" / "okay with Excel"**
3. *How comfortable are you with Word and Excel?* Give one concrete example per tool. If you're only "okay" at Excel, say so.

**Answer slot (no quote): travel booking**
4. *Have you booked travel for a team?* Honest branch: say you haven't, then describe how you'd learn it (the airline or booking tool's guidance, a checklist, asking the office manager).

**Most likely objection: "You have no admin experience beyond reception."** *Highest-ROI prep in this pack.* Rehearse a two-sentence answer: what you've done that overlaps (scheduling, invoices, documents), then what you haven't done yet and how you'd close the gap.

**Pressure: "How much of the appointment system was yours?"** Answer with the truth: you ran it day to day for four physios. Don't claim you designed it unless you did.

## Reverse questions

- *What does a typical week look like in this role?* Why it lands: shows you want the real workload.
- *Which tools does the team use for calendars and invoices?* Why it lands: lets you raise any gap before it's assumed.
- *How is success measured after the first three months?* Why it lands: signals you think in outcomes.

## Upgrade menu

- **Full job description:** would sharpen the fit snapshot.
- **More background on your past roles:** any admin, bookkeeping or travel tasks you've done, even informally.
- **Interviewer name or public profile:** would let me tailor the questions.
- **Interview format details:** whether it's a screen, a skills test, or a panel.

**Drill offer:** I can run a live practice interview with you as the office manager, if you want.
**Dossier offer:** I can produce a `tuesday-dossier.md` with this pack's feedback if you'd like to keep it.

**Questions:**
1. Did you apply through a job board or the company's own website? That changes which details to verify.
2. Does the ad state a salary or contract type?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.