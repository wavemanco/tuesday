Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it describes a €1,850 cheque where "you deposit the cheque and send the balance on to the vendor." Asking for a fee or equipment payment, a cheque deposit, or bank and ID details before an offer are known scam patterns, and this job is very likely a scam. Hold all of it until you've checked the invite with Brennock Facilities Ltd, using a phone number or address from its own website or careers page, not anything in the email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-5-rooms-case-12-denied-1d280a97/f81eb566-2efc-4aa9-84d1-7b418c2effbf/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md`. I built it for a 30-minute call with the office manager, using your summary of the ad and your background. I didn't run any research, so the company-values and interview-process sections are not in it.

The pack's top priority is question A1, "Which part of this job would you be weakest at on day one?" Your material doesn't show travel booking or supplier invoice processing, so that's where the interviewer will press.

Say the word and I'll play the Skeptic on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the full job-ad text? My requirement rows quote your summary, and the exact wording would let them quote the ad directly.

Do you want me to research Brennock's published values and interview process? That means a search, and the results would go into the pack's Sources section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Round: 30-minute video call, as the invite describes it.
Built on: your message (your background, and the job duties as you summarised them). No full job-ad text, and no research.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioural/values · **EXP** your own experience · **JD** the listed duties · **CO** company knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are the duties from your summary of the ad, quoted as you gave them. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad, as you summarised it | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in those words: "ran the appointment book for four physios." Don't stretch it to calendars you did not keep. |
| F2 | "booking travel" — ad, as you summarised it | none given | none | [grounded] | discovery | Your material is silent on travel booking. Answer slot: if you have booked travel for someone, say what it involved; if you have not, say so plainly and say how you would learn the booking tool. |
| F3 | "preparing documents in Word and Excel" — ad, as you summarised it | "good with Word" and "okay with Excel" — your message | medium | [grounded] | presentation | Say "good with Word, okay with Excel" in those words. Excel is the weaker half; don't upgrade "okay." |
| F4 | "processing supplier invoices" — ad, as you summarised it | "chased unpaid invoices" — your message | low | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices, not the same step. Say "I chased unpaid invoices" and do not claim the processing step. Answer slot: if you entered, matched or approved supplier invoices in any system, say which; if you did not, say so. |
| F5 | "Remote" — the role title in the invite | none given | none | [grounded] | discovery | Your material is silent on working without someone in the room. Answer slot: if you have worked without someone beside you, say how you kept to a schedule; if you have not, say so and say how you would set up your day. |

Pack observation (analysis, not words for you): your material shows the appointment book and the invoice chasing. It does not show travel booking, supplier invoice processing or remote working.

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F4: "chased unpaid invoices" widened to the ad's duty | "I chased unpaid invoices," at its own scope. The limit is the pack's observation: your material shows chasing, not processing. Slot A1 and D3 stay inside the chasing. |
| Expert in Excel | Inflated form of F3: "okay with Excel" widened | "Okay with Excel," in your words. No upgrade of the word. |

## Personas and weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the gaps one at a time: travel booking, invoice processing, Excel | High. The ad's duties and your sentences part company at exactly those points, and an office manager hiring for them will test the gap. | Rehearse A1 until it is boring. Stay with your own sentences; say the limit plainly. | 5 |
| Case/Strategist | A live calendar, travel or invoice problem | Medium. Admin roles often get a scenario in place of a story. | Clarify who needs what by when; order the work; say what you would do first. | 4 |
| Conversational | A friendly opener and a casual question about the job | High. A 30-minute call usually opens this way, and casual questions are scored. | A 90-second arc built from your own sentences. | 4 |
| Pressure | A sharp follow-up on the missing job title | Low to medium. This is an office-manager call, not a stress round; kept at 4 because the missing title is the obvious hit. | Hold the quoted sentence through two follow-ups, then concede specifically. | 4 |

Highest-ROI prep: **A1**. The gap it names is the one most likely to come up in some form.

## Question banks

Question types are listed per row. Persona depth follows weight.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" | Name the duties your material is silent on or only adjacent to: booking travel and processing supplier invoices. Say which you would learn first and how. Keep the invoice work to the chasing you did, in those words. | The Skeptic's stem, aimed at F2 and F4. Highest-ROI prep. |
| A2 | "Walk me through the appointment book you ran for four physios." | EXP | [grounded] "ran the appointment book for four physios" | Tell it from that sentence: what the book held and who used it, in your own words. Answer slot: the calendar duty makes a probe on how you handled other people's diaries likely. If you made a specific call on clashing bookings, say which and why; if you did not, say so plainly and describe how the book ran. | F1 is the nearest evidence for managing calendars. EXP because it tests what was yours. |
| A3 | "Have you ever booked travel for someone else? What did it involve?" | JD | [grounded] requirement "booking travel" (ad, as you summarised it) | Your material says nothing about travel booking, so there is no story to tell. Answer slot: if you have booked travel for someone, say what it involved and which tool you used; if you have not, say so plainly and say how you would learn the team's booking tool. | F2 has no evidence cell. The honest branch has to be ready before the probe arrives. |
| A4 | "You said you're okay with Excel. What have you built in it?" | JD | [grounded] "okay with Excel" | Keep "okay." Answer slot: if you have built a sheet, name it and what it did; if you have not, say you are comfortable with basic use and name the first thing you would learn. | F3's Excel half is the weakest-evidenced part of the requirement, and a Skeptic reads "okay" as the signal. |
| A5 | "Talk me through how you'd process a supplier invoice from receipt to payment." | JD | [generic] | No claim about your past. Structure it: check the invoice against the order or contract, confirm receipt, code it, get it approved, pay on terms, record it. Say which steps you have done yourself and which you would learn from the team. If you have done none, say that. | Processing supplier invoices is the ad's line and the widest gap in F4. The question asks for a process, not a story. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two directors both need the boardroom at 10 tomorrow. What do you do?" | CASE | [generic] | Clarify who has priority and whether either can move. Offer the other slot first, confirm with both, record the change. Say which you would do first. | A live calendar problem drawn from the managing-calendars duty. No claim about your past. |
| B2 | "A travel booking and a supplier invoice are both due this afternoon. What's your order?" | CASE | [generic] | Ask what is due, to whom and when. Order by the cost of a miss and say why. Name who you would tell about the one you cannot finish. | Two duties from the ad at once; tests prioritising. |
| B3 | "A booking tool you've never used won't let you save an itinerary. What now?" | CASE | [generic] | Check the tool's help or the team's guide, ask a colleague, test on a dummy booking, and record the workaround. | A live version of the travel gap in F2, asked without requiring you to claim the tool. |
| B4 | "What's the first Word or Excel document you'd prepare in your first week, and why?" | CASE | [generic] | Ask what is needed and by whom; name the document type and why. Do not promise skill you have not shown. | Tests Word and Excel use as a plan, not as a claim. |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc in this order: the clinic and your two years; the appointment book for four physios; the unpaid invoices you chased; Word and Excel. Each beat is a clause from your own sentences. | The opener is scored even though it sounds casual. Your sentences give the arc; nothing is added. |
| C2 | "What's the part of admin work you enjoy most?" | JD | [generic] | Name one part you actually like, briefly, and link it to a duty in the ad. Pick the honest one, not the one that sounds best. | A rapport question that still shows fit. |
| C3 | "What have you been using Word for lately?" | JD | [grounded] "good with Word" | Name one document type you have made in Word, in your words. Answer slot: if you cannot name a recent one, describe the Word work you have done and when. | Word is the stronger half of F3. A casual question here tests whether "good with" holds up. |
| C4 | "What does a normal week look like in this role?" | JD | [generic] | Answer in two sentences, then say what you would do first. Do not guess at the team's workload. | Rapport question on the remote and duty mix. A casual question about the job is scored. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone with an admin title?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Hold: two years of front-desk work where the appointment book and the invoices sat with you. Through two follow-ups, return to that sentence. Then concede specifically: you do not have an admin title, and say what you would do to close that in the first month. Never fold on the core claim. | Pressure stem aimed at the title gap. Hold, then concede. |
| D2 | "That's a receptionist's job. What's different about this one?" | JD | [grounded] "ran the appointment book for four physios" | Hold the scope of that sentence: the book was yours to keep for four people. Concede the difference the ad adds (travel, supplier invoices, Excel) and say which you would learn first. | The same title probe in another form. The hold stays at the sentence's own scope. |
| D3 | "Chasing unpaid invoices isn't processing them. Why isn't that a gap?" | JD | [grounded] "chased unpaid invoices" | Agree the difference in one clause: chasing is the money side, processing is the entry and approval side. Hold the sentence as you said it. Say what you did do with invoices, in those words. Where processing is concerned, say it is not in your material and name how you would learn it. | The sharpest form of F4. The hold is on your words, not on a claim the material does not carry. |
| D4 | "How do you keep your own schedule when nobody is in the room?" | JD | [generic] requirement "Remote" (the role title in the invite) | Answer slot: if you have worked without someone beside you, say how you kept to a schedule; if you have not, say so and say how you would set up your day. | Remote working is in the title and nothing you wrote covers it. The pressure is in the open question. |

Requirement coverage:

| Requirement | Questions |
|---|---|
| managing calendars | A2, B1 |
| booking travel | A3, B2, B3 |
| preparing documents in Word and Excel | A4, B4, C3 |
| processing supplier invoices | A1, A5, B2, D3 |
| remote working (the title) | C4, D4 |

## Reverse questions

Each has a "why it lands."

1. **"What does the first month look like for this role?"** Why it lands: shows you are planning for the job, not just the interview.
2. **"Which of the duties takes up most of the week?"** Why it lands: tells you where to focus your prep.
3. **"How is travel booked today, through a tool or by hand?"** Why it lands: names the tool you would need to learn, so you can prepare for it.
4. **"How are supplier invoices approved, and who signs off?"** Why it lands: lets you learn the process before you describe it.
5. **"How does the office manager prefer updates when someone works remotely?"** Why it lands: shows you have thought about the remote part of the title.
6. **"What would make someone in this role a strong hire after six months?"** Why it lands: asks for the success criteria in the interviewer's own words.

## Sources

Research tier: L0. No searches or fetches were sent; research consent has not been given.

Documents provided: your message, with your background and your summary of the job ad.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities values` | unavailable | A values cheat sheet, section 10, if the company publishes values. Not run. |
| 2. `Brennock Facilities interview process, administrative assistant` | unavailable | Loop structure. The round is taken from the invite as stated. Not run. |
| 3. `Brennock Facilities strategy` / recent news | unavailable | Company scale and location. Not run. |
| 4. `{interviewer name} Brennock Facilities` | n/a | No interviewer name was given, so there is no query to form. |
| 5. representative `Remote Administrative Assistant` JD | unavailable | A full ad would turn the requirement rows into exact quotes. Not run. |

## Upgrade menu

- The full job-ad text → the requirement cells become exact quotes; F1 to F5 keep their evidence.
- A sentence you have written about booking travel, if you have one → fills A3's slot and moves F2 off "none given."
- Research consent → rows 1 to 3 above, plus a values cheat sheet if the company publishes values.
- The interviewer's name, if the invite gives one → a tailored reverse question and persona weights from the public record.
- A `tuesday-dossier.md` → would carry the gaps this prep found into later sessions.
