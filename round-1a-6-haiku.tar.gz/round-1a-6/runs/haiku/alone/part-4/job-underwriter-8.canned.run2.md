**Decision: no-go. Don't send anything, and don't pay anything.** Your instinct to ask first was right.

## Why

The problems are in the process, not just the posting. A legitimate employer doesn't do any of these:

- **Asks for your IBAN, PPS number and passport photo before any interview or written offer.** Payroll details come after a credible written offer, through a proper HR system. Don't send them over Telegram.
- **Asks you to pay €349 for equipment.** An employer doesn't charge its staff for a laptop or headset. A "refund with your first wages" promise is only as good as the sender.
- **Sends you a €2,850 cheque to deposit, then asks you to pass most of it on to a third party.** This is the classic overpayment pattern. The cheque looks cleared within a day or two, but the bank reverses it later when it bounces, and the money you've sent on is gone. You'd be covering the loss.
- **Hires entirely through Telegram** with no calls, video, or verifiable company contact. The one contact you have is a personal Telegram handle and a generic email address.

Whoever is behind these messages, the steps they're asking you to take are ones where you lose money, so the answer is no.

## What I could not verify

I did no research, so I haven't checked whether Velloway Logistics exists. Research tier: L0, no searches. You can check this yourself:

- Search the company's name on the Irish CRO register (cro.ie) if it's an Irish company. Also check the address and directors against its own website, not against anything the recruiter sends you.
- Find a contact through the company's official website, never through the recruiter's messages.

Even if the company turns out to be real, the process above is the problem. A real company that handles hiring this way would still be asking for money and bank details up front.

## Your fit

On the work itself, your background is strong: three years of Zendesk ticket handling, training new starters, and maintaining an Excel tracker are all relevant to order processing and operations roles. Use that on legitimate listings.

On pay, the posting's numbers don't reach your €30k floor on its own. At €26/hour, you'd need about 22 hours a week, every week, to reach €30k before commission. The posting says "up to" and doesn't state a guaranteed base, so ask about that in any real interview.

## What to do now

1. **Don't send the IBAN, PPS number, passport photo, or any money**, to this recruiter or to the "equipment partner."
2. **If you've already sent any details**, contact your bank now to flag the account and ask about protective steps. Also report the messages to the Gardaí, and to Telegram via its report function.
3. **Don't deposit the cheque** if one arrives. Take it to your bank and tell them what happened.
4. **Find real openings** on established job boards or the company's own careers page. Apply through those channels.

Your background is worth a real job. This one isn't it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.