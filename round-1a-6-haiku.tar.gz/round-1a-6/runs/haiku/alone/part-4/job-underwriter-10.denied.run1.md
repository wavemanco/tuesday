**Decision: `conditional_go`.** Worth applying: yes. Legit: I can't confirm Fernquay exists as described from here. Web search was refused, so the employer check didn't run. Nothing in the posting or the WhatsApp message is a warning sign.

**Fit ledger**
- hard_gate: R1 `direct`; R2 `unclear` (pay band and equity against your floor)
- must_have: R3, R4, R6 `direct`; R5 `adjacent` (research with consumers, not school owners)
- important: R7 `adjacent` (end-to-end flow ownership); R8 `unclear` (no design peers)
- preferred: R9 `adjacent` (travel booking, not paddle-sport schools)

R5 — consumer usability work, not owner interviews; R8 — you've never been the only designer; R2 — pay and equity untested against your floor.

**Opportunity ledger:** RR1 (`medium`) keeps this at conditional rather than go, because the employer is unverified. RR3 (`low`) is the sole-designer setup. RR2 is unstated equity terms, an unknown rather than a risk. PS1 is a positive signal: the posting states pay, location, and both leaders by name.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay band and equity against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the conditions are (a) Fernquay is confirmed as a live employer through its own website or careers page (RR1); (b) the call gives a concrete answer on how design decisions and critique work with no design peers (RR3); (c) equity terms are clear before any offer is accepted (RR2).

**Role reality** `[grounded]` from the posting: booking flow end to end, research with school owners, six people, two engineers, hybrid two days in Galway, €52k–€60k plus 0.5–1% equity. `[inferred]`: a first-designer role usually means you set the design practice as well as ship it. Market calibration: not run, since search was refused; any pay judgement is unverified.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| R1 | hard_gate | direct | high | none | Galway hybrid, two days a week | You moved back to Galway last year (stated) |
| R2 | hard_gate | unclear | low | hard-gate | Pay and equity against your floor | No floor given |
| R3 | must_have | direct | medium | none | 3+ years product design | Four years, Dublin travel-booking (CV-only) |
| R4 | must_have | direct | medium | none | Strong Figma | Daily use (CV-only; no portfolio seen) |
| R5 | must_have | adjacent | medium | transferability | Runs own user research | Monthly usability sessions with customers; none with business owners |
| R6 | must_have | direct | medium | none | Works directly with engineers | Squad of four engineers |
| R7 | important | adjacent | medium | transferability | Owns a flow end to end | Redesigned checkout flow |
| R8 | important | unclear | low | capability | Works without design peers | Never the only designer |
| R9 | preferred | adjacent | medium | transferability | Booking domain | Travel booking |

**Gap recovery queue**
- R5: describe one research session you ran with a non-consumer user, even a partner or a trade buyer. Closes with evidence.
- R8: describe one design decision you made without a peer to critique it, and how you checked it. Closes with evidence.
- R2: state your pay floor and equity position. Closes the hard gate.

**Opportunity risk register**
- **RR1** — `risk_signal`, `severity: medium`, status `unresolved`. Source: "We are six people in Galway making booking software". Hypothesis: the employer may be too new to have a footprint, the posting may be stale, or it may not be a live hiring employer. `[generic]`: a pattern for small companies, not a finding about this one. Question: "Can you point me to this role on your careers page, and who would I interview with?" Decision rule: verify the employer and posting before investing application effort.
- **RR3** — `risk_signal`, `severity: low`, status `unresolved`. Source: "You would be our first designer". Hypothesis: you may have no design peers for critique or direction. `[inferred]` from the posting. Question: "Who reviews design work day to day, and what happens to design when the first designer is hired?"
- **RR2** — `unknown`, status `unresolved`. Source: "0.5–1% equity". Question: "What vesting schedule and option terms apply, and is the equity negotiable?"
- **PS1** — `positive_signal`. Source: the posting names salary, location, the co-founder and the CTO. Transparent terms raise confidence in the opportunity.

**Routine, not a risk:** the WhatsApp message arranges a video call with the invite sent by email. Scheduling by chat for an interview held elsewhere is routine, so it has no register entry. Advice: check that the invite comes from a Fernquay address before joining, and share bank or ID details only after a written offer, through the employer's own portal.

**Application plan**
- Lead with the checkout redesign and the monthly usability sessions. Say "usability sessions with customers", not "research with school owners". You haven't done the latter.
- Before the call, prepare a 2-minute account of your checkout work: the problem, your research, and what changed.
- Ask on the call: how design decisions get made with no design peers; what success looks like at 90 days; equity vesting and options; and whether Ronan is the day-to-day contact.
- Pay and equity: decide your floor before the call; it decides whether this passes the hard gate.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Both search calls were refused by permission; no page was fetched |
| 2. Role-family sweep (scope, title, pay) | unavailable | Same refusal |
| 3. Hiring manager's public footprint | unavailable | Same refusal; Ronan Kehoe is named |

Searches counted as sent: 2. Both refused, so no source was used.

If you allow web search, I can run targets 1–3 and update RR1 and the pay calibration.

Would you like me to save this as a `tuesday-dossier.md` so the findings carry into later rounds?

**Upgrade menu**
- Your pay floor and equity position: resolves R2 and the hard-gate check.
- A portfolio or the checkout case study link: confirms R3, R4 and R7 beyond CV claims.
- The live posting URL or Fernquay's careers page: resolves RR1.
- Web search permission: runs the three research targets.

1. What's your minimum acceptable base salary, and is equity negotiable for you?
2. Do you have the live posting URL or Fernquay's careers page, and the email domain the invite came from?
3. Can you share your portfolio or the checkout case study link, so I can check the Figma and research claims?

Answer any, all, or none; say "skip" for any you'd rather not answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.