**Conditional go: verify the offer through a contact you find yourself before you accept. Status: `conditional_go`.**

**Is it normal?** Yes, after a written offer. Payroll needs your bank details and PPS number, and Irish employers commonly ask for a passport or ID check for right-to-work. Your rule is sound before an offer, or for anyone who asks by email before you've seen a credible offer. Here the order is the usual one: offer first, then a portal link. What to check is where the link goes, whether the offer is genuine, and how your passport is handled.

**Fit ledger.**
- `hard_gate`: unclear: R10 (hybrid, two days a week in Limerick), R11 (pay)
- `must_have`: direct: R1, R3, R4, R6, R8 · unclear: R2
- `important`: adjacent: R5 · unclear: R7, R9

**Opportunity ledger.** Credible offer on the terms as written, but the employer's existence is not yet checked. The offer is inside the posted band (RR4 is positive). One standing entry caps the decision (RR1).
- **Hard gates:** none failed. Unconfirmed: R10 and R11. Candidate constraints were not given, so checks against your floor and location are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the offer with Marrowgate through a number or address you find on their own website, not from the email; (2) confirm any portal link is on that same domain before you enter anything; (3) confirm you can do two days a week in Limerick and that €40,000 meets your floor.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a Limerick housing association, 240 staff | `[grounded]` JD |
| Scope | Monthly payroll for 240 staff, starters and leavers, pension changes, monthly payroll-to-GL reconciliation, staff queries | `[grounded]` JD |
| Pay | Posted €38,000–€42,000; offer €40,000 | `[grounded]` JD and offer |
| Contract | Offer states permanent | `[grounded]` offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Working pattern | Hybrid, two days a week in Limerick | `[grounded]` JD and offer |
| Scope read | A standard single-employer payroll role; the step up from your current work is volume and cadence (monthly, 240 staff, against fortnightly, 90) | `[inferred]` from the duties against your background |
| Market calibration | Not run. Web search was not permitted this session, so no role-family band is available | — |
| Unknowns | Pension scheme and how changes are processed; whether the post has any reporting-line authority beyond Declan Garvagh; who the named HR contact is | — |
| Contradictions | None between the JD and the offer | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated, no artifact yet. A length requirement, so graded on fit, not treated as a gate | `[grounded]` your statement | payslip or run sample would raise to high |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Not stated whether your hotel-group payroll ran under Irish rules | — | G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use; pivot tables and XLOOKUP, stated | `[grounded]` your statement | a workbook sample would raise to high |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated | `[grounded]` your statement | certificate copy would raise to high |
| R5 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Same processing steps as your fortnightly run. Limit: monthly cadence and roughly 2.7 times the headcount | `[inferred]` from your background against the duty | G3 |
| R6 | Starters and leavers | must_have | direct | medium | none | Stated | `[grounded]` your statement | — |
| R7 | Pension changes | important | unclear | low | discovery | You have never processed these; your manager did. Whether you observed the inputs is not established | `[grounded]` your statement | G2 |
| R8 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Three years, stated | `[grounded]` your statement | — |
| R9 | Answering staff payroll queries | important | unclear | low | discovery | Not stated in your background | — | G4 |
| R10 | Hybrid, two days a week in Limerick | hard_gate | unclear | low | hard_gate | You attended two in-person interviews at the office, but have not confirmed you can commit to the schedule | — | G5 |
| R11 | Pay €38k–€42k | hard_gate | unclear | low | hard_gate | Offer €40,000 is inside the posted band; your floor is not given | `[grounded]` JD and offer | G6 |

**Gap recovery queue**
- **G1 (R2, discovery):** Irish statutory knowledge is unproven. Closed by evidence that your payroll ran under PAYE, PRSI and USC rules: a payslip sample, the software used, or any Revenue submission experience.
- **G2 (R7, discovery):** You have not processed pension changes. Closure path: pension-provider employer-portal training, or an explicit question to Declan Garvagh about how changes are processed. Do not present pension work as your experience.
- **G3 (R5, transferability):** Bridge: same steps, different cadence and volume. Limit: monthly processing of 240 staff. Strengthener: a checklist from your run process.
- **G4 (R9, discovery):** Staff query handling is not evidenced. Closed by examples of answering queries in your current role, or an honest "not yet" for the interview.
- **G5 (R10, hard_gate):** Surfaced, not a workaround hunt. Confirm you can attend two days a week.
- **G6 (R11, hard_gate):** Surfaced. Your floor is needed to check the offer.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer existence not verified | risk_signal | medium | "people@marrowgatehousing.ie" | Standing entry. Reasons, none ranked likely: the company is too new or small to be found; the posting is stale; the company is not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Does Marrowgate's own website list this post, and does its switchboard confirm the offer? | unresolved; caps the decision at `conditional_go` |
| RR2 | Sender is a team mailbox with no named HR contact | unknown | — | "Marrowgate Housing People Team" | Possibly standard practice | `[inferred]` from the signature | Who is your named contact for onboarding? | unresolved |
| RR3 | Two in-person interviews at the office; manager named in the offer | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | Employer has a physical presence and a named reporting line | `[grounded]` your account and the offer | — | noted |
| RR4 | Offer is inside the posted band, and the contract is stated as permanent | positive_signal | — | "€40,000 a year"; "the permanent post" | Terms match the advertisement | `[grounded]` JD and offer | — | noted |
| RR5 | Pension scheme not described | unknown | — | none in the JD | The pension scheme and its change process are unknown | — | How are pension changes processed, and who owns them? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate's switchboard and careers page through your own search. Confirm the offer and that Declan Garvagh is the manager. Do not use the email's contact details | RR1 | `[generic]` standard verification practice | yours to do |
| A2 | Check that the sender domain matches their official site exactly, and that any portal link is on that same domain | RR1 | `[generic]` standard verification practice | yours to do |
| A3 | Give bank and PPS details only through the portal. For the passport, ask what is kept, where, and for how long, and check their data-protection notice. Bring the original on day one | Routine steps. Advice, not a condition | `[generic]` standard practice | yours to do |
| A4 | Confirm the two-day Limerick schedule and your pay floor before you accept | R10, R11 | `[grounded]` hard gates | yours to do |
| A5 | Accept only after A1 and A2 pass. Five working days is the window; ask for a short extension if you need one | Decision timing | `[grounded]` offer | yours to do |
| A6 | Position with what is evidenced: fortnightly-to-monthly bridge, reconciliation, starters and leavers. Describe pensions as observed, not run | R5, R7 | `[grounded]` rows above | proposed; no resume text is changed without your approval |

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | Web search was not permitted this session, so the posting, the company and the sender domain are not checked |
| 2 | Role-family sweep: title, scope, pay | unavailable | As above. No market band is available |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | As above |

Verified: R1, R3, R4, R6, R8 as you stated them, medium, with no artifact yet. R2, R7 and R9 are unverified.

**Upgrade menu**
- A payroll-run sample or redacted payslip: raises R1, R6 and R8 to high, and is the best evidence for R2 if it shows Irish deductions.
- Your Payroll Technician certificate copy: raises R4 to high.
- A workbook sample showing pivots or XLOOKUP: raises R3 to high.
- Search permission: lets the company check, the role band and the hiring-manager footprint run, which would settle RR1.

Tuesday-dossier.md can carry this assessment into mock-interview prep if you want it.

1. **R2, G1:** Was your payroll run under Irish PAYE, PRSI and USC rules, and which software did you use?
2. **R10, G5:** Can you commit to two days a week in the Limerick office?
3. **RR1:** Did you apply through their careers page or a job board, and do you have that link?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.