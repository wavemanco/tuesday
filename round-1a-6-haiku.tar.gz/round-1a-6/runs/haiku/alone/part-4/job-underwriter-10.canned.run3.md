**Short answer:** Yes, it's worth pursuing, and I found nothing that suggests it isn't real. You've already applied, so the next step is the 45-minute call. Your main gap is that you've never been the only designer, and the call is a good place to test that.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

**Decision snapshot** `[grounded]` unless marked
- **Decision:** conditional_go
- **Candidate fit:** strong on craft and process; the gap is in working alone as a designer
- **Opportunity:** small, early-stage, plausibly real; a few things still unverified
- **Hard gates:** none failed. Hybrid with two days in Galway fits where you live. Pay (€52–60k) is stated, but I haven't checked it against market rates.

**Fit, requirement by requirement**
- **3+ years product design:** meets it. You have 4 years. `[grounded]`
- **Strong Figma:** meets it, daily use. `[grounded]`
- **Run your own user research:** largely meets it. You ran monthly usability sessions with customers. The gap is that school owners are a different segment from travel-booking customers, so this is transferable, not proven. `[inferred]`
- **Happy working with engineers:** meets it. You worked in a squad with four engineers. `[grounded]`
- **Own the booking flow end to end:** partial. You redesigned checkout, which is one part of a booking flow. `[grounded]`
- **First and only designer:** the real gap. You have never worked without a design peer, so setting up design practice, making decisions alone, and hiring or briefing others would all be new. `[grounded]`

**Legitimacy checks**
- **The company:** a search turned up a company page at fernquay.example/about describing booking software for sea-kayak, surf and sailing schools, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle. That matches the posting. `[grounded]`
- **Ronan:** a public profile lists him as co-founder and CEO, and before that as product lead at a Galway travel-software company for five years. The profile is consistent with what he wrote to you. `[grounded]`
- **Saoirse:** the company page names her as a co-founder, and Ronan's message calls her CTO. Those can both be true, but it's worth confirming her title on the call. `[inferred]`
- **The WhatsApp message:** a co-founder reaching out this way is common at very small companies, and this one refers to your case study and says the invite is by email. Nothing in it is a red flag by itself. The one routine check is to confirm the invite comes from the company's own email domain (the one on its website) and that the video link goes to a normal meeting service.
- **Not verified:** the live posting and the careers page (I didn't fetch them), the company's funding or size beyond the six people it states, and whether the €52–60k band matches market rates. I didn't search for compensation.

**Application plan**
- Lead with the checkout redesign and the monthly usability sessions as proof you can run research and ship with engineers.
- On the call, ask how design decisions get made today, who reviews them, and what "first designer" means in practice. Your answers to those questions will show whether the role fits.
- Be specific about the gap. Say you haven't been the only designer, and describe how you'd build a design process with two engineers.

**Upgrade menu** (what would firm up this assessment)
- The live posting or careers page: confirms the role is current.
- The invite email's sender address: confirms it comes from the company's domain.
- A pay-band check: tells you whether €52–60k is fair for this seniority.

**Questions**
1. What's your minimum for salary, and is the equity an issue for you?
2. Would you want help preparing for the 45-minute call? If so, the mock-interview skill can run a rehearsal.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.