## Decision snapshot

**Decision: `conditional_go`.** The role fits your evidence well on the stated requirements. The company is thinly documented and not yet checked against a register, and the pay and equity terms need your own numbers before you commit time.

- **Fit ledger:** Requirements 1–4 are met on your stated evidence. The main gap is sole-designer ownership, which is a capability gap, not a credential gap.
- **Hard gates:** Location and hybrid schedule are met (you live in Galway; two office days a week). Salary is **unknown against your floor**: you haven't told me your minimum. Equity is not a substitute for salary and has no stated value.
- **Opportunity:** One source describes a company matching the posting. No company-register record was found. No live posting link or careers page was provided or located.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | yes | Fetched `https://fernquay.example/about`: Kelproster booking software for sea-kayak, surf and sailing schools; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle. Careers page not located, so posting liveness is unverified. Found via the query "Fernquay Galway booking software sea kayak surf schools". |
| 2 | Role-family sweep (market pay and scope) | skipped | Not run within this L1 pass. Market calibration is therefore unavailable; any band I gave would be model memory, which I don't use. |
| 3 | Hiring manager's public footprint | yes | Search snippet only, not fetched. Query "Ronan Kehoe Fernquay co-founder" returned his LinkedIn profile: co-founder and CEO at Fernquay; previously product lead at a Galway travel-software company for five years. |

**Not-attributable check:** Partly established. The about page ties the name, product, location and size to one entity. The Companies Registration Office search returned nothing, which is inconclusive, not a negative finding.

## Role reality

- **Scope [inferred from posting]:** You would be the first and only designer, owning the booking flow end to end, running school-owner research, and shipping with two engineers. This is a broader, less supported scope than your last role, which had a team of designers and a squad of four engineers.
- **Product and domain:** Sea-kayak and surf schools are B2B, with school owners as the buyers. Your background is consumer travel booking. The transfer is partial.
- **Stated pay:** €52,000–€60,000 plus 0.5–1% equity [grounded, from the posting]. Unknown against your floor, which I need from you.
- **Culture signals** (dog in the office, informal, "messy real project" over a polished deck) are the posting's own description, not evidence about how the company operates.

## Evidence map (condensed)

| Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|
| 3+ years product design | must-have | met | high | none | 4 years at a Dublin travel-booking company (your statement; CV needed to raise confidence) |
| Strong Figma | must-have | met | medium | none | Daily use (your statement); a portfolio link would raise this to high |
| Own user research | must-have | partial | medium | transferability | Monthly usability sessions with customers; no B2B school-owner research yet |
| Works directly with engineers | must-have | met | high | none | Squad of four engineers |
| Own booking flow end to end, as first designer | implied | partial | low | capability | Checkout redesign shows ownership, but inside a larger design team |
| Domain fit (small-business booking) | preferred | partial | low | transferability | Travel booking, consumer-facing; this employer sells B2B |
| Galway location, hybrid two days a week | hard_gate | met | high | none | You moved back to Galway last year |
| Salary €52k–€60k | hard_gate | unknown | — | unknown | Your floor not yet stated |

## Opportunity risk register

1. **Thin company footprint** — `severity: medium`, `confirmed`. Only one page describes the company. Standing entry: caps a `go` at `conditional_go` until verified.
2. **Unverified claims on the about page** — `severity: low`. The "funded by its customers" line has no independent source.
3. **Posting not linked to a live careers page** — `severity: low`. You can't yet confirm it's current.
4. **Equity uncertainty** — `severity: low`. 0.5–1% has no stated vesting, strike price or cap table. Treat it as unvalued.

**Scam indicators:** None found. The WhatsApp message asks only for a call and says an invite was emailed. It does not request money, bank details, ID or equipment. Scheduling by chat is routine. The one thing to check is that the emailed invite comes from the company's own domain.

## Application plan

1. **Verify the sender.** Check the invite email's domain against the company's domain from the about page, and confirm the posting's contact address matches it. Keep all scheduling in writing and don't share ID, bank or tax details before a written offer.
2. **Check the company register.** Search the CRO register at cro.ie for Fernquay (or the exact registered name, which may differ) and note the registration date, directors and status. I couldn't check this with search.
3. **Prepare for the 45-minute call** with Ronan and Saoirse. Lead with the checkout redesign and the usability sessions as your verified stories. For the sole-designer question, describe a real decision you drove inside the squad, not a claim to have owned the whole product.
4. **Ask about the unknowns on the call:** the scope of the first year, what research exists so far, what the current design process is, and the equity terms.
5. **Your pay floor** determines whether the salary gate passes. Confirm your number before going further.

Say so if you'd like mock-interview to rehearse the call, which is its job rather than this assessment's.

## What would change the decision

- **To `go`:** Confirmed company registration, a live posting or careers page matching the description, and salary at or above your floor.
- **To `no_go`:** Salary below your floor, or the company not verifiable as a real hiring entity.

## Questions (up to three)

1. **[gap: salary]** What is your minimum acceptable base salary? This decides whether the salary gate passes.
2. **[gap: portfolio]** Do you have a portfolio or the checkout case study link? It would raise the Figma and research rows from medium to high confidence.
3. **[gap: role]** Have you ever made design calls on a product with no other designer, even partially? Even a small, unpolished example helps with the sole-designer gap.

Response mode: answer as many or as few as you like; "skip" is a valid answer.

## Dossier offer

If you'd like, I can save this assessment as `tuesday-dossier.md` so it carries into later turns and future applications.

## Upgrade menu

- **Salary floor** → checks the hard gate properly (you can answer now).
- **Portfolio or case study link** → raises confidence on the design-skill rows.
- **CV** → confirms the experience claims at higher confidence.
- **Live posting or careers page link** → confirms the role is current.
- **Companies Registration Office record** → closes the attribution gap.
- **Market salary band for this seniority** → would calibrate pay; I didn't run it this pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.