**Yes, apply, once the posting checks out.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3 · unclear: R4 (Salary and mileage against your floor)
- `must_have`: direct: R5, R8, R10, R12 · adjacent: R7 (Holding your own caseload), R9 (Leg-ulcer care) · unclear: R6 (Written records), R11 (Continence care), R13 (Care planning), R14 (End-of-life visits)
- `preferred`: absent: R15 (Doppler assessment)

R7 is a real bridge from your home visits, and its limit is named. R9 is the nearest evidence to leg-ulcer care, not the same thing. R6, R11, R13 and R14 are silent in your CV, so they are questions, not gaps. R15 is preferred and has a closure path.

**Opportunity ledger.** The employer exists as described (RR4), and the pay band is stated and covers the middle of the market range (RR3). The posting is not confirmed live (RR1), and caseload ownership is undefined (RR2). No red flags.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Salary and mileage against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live with the employer (RR1); (2) your pay floor sits at or below £31,050 (R4); (3) the caseload terms hold up in conversation (RR2). The Doppler gap is preferred, not a condition.
- **What would change this:** the posting not being live, or a pay floor above the bottom of the range, would move this to `hold_pending_answers`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; 410 staff, four locality hubs | `[grounded]` company About page (search result) |
| Mandate | Adult district nursing for housebound adults at home; a small caseload of your own with a senior community nurse behind you | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | A 2026 survey sample of Band 5 community staff nurses in England: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage, 24% had a pool or lease car. A survey, not an official scale | `[generic]` role-family sweep; the posting's range is `[grounded]` |
| Unknowns | Caseload size at start; supervision model; mileage rate and whether it applies to pool cars; whether Doppler training is funded; EPR system; whether the post is still open | — |
| Contradictions | None found between the JD and what search returned. The careers page address the About page implies did not load | `[grounded]` fetch attempt |

The posted range covers the survey's middle half. Its bottom sits below the lower quartile, so expect the lower end to be possible at offer.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration, Adult | hard_gate | direct | medium | none | CV states Adult RN, registration active, revalidation March 2028; not checked against the register | `[grounded]` your CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated full category B; stated, not checked | `[grounded]` your CV | You check your driving record |
| R3 | Halifax location | hard_gate | direct | medium | none | You live in Halifax; posting location is Halifax | `[grounded]` JD and CV | none |
| R4 | Salary and mileage against your floor | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the check is unknown | `[grounded]` JD | Q1 |
| R5 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R6 | Clear, timely written records (EPR) | must_have | unclear | low | discovery | CV is silent on the record system or documentation | `[grounded]` CV silence | Q3 |
| R7 | Holding and managing your own caseload | must_have | adjacent | medium | transferability | Home visits in discharge-to-assess; no caseload held. Limit: no owned caseload | `[inferred]` from JD wording against CV | Gap G1 |
| R8 | Wound care, pressure and surgical | must_have | direct | medium | none | CV states both | `[grounded]` CV | none |
| R9 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care in general; no leg-ulcer work named. Limit: leg-ulcer specifics not exercised | `[inferred]` from CV | Gap G3 |
| R10 | Catheter care | must_have | direct | medium | none | CV states it | `[grounded]` CV | none |
| R11 | Continence care | must_have | unclear | low | discovery | Continence not named; catheter care is the nearest | `[grounded]` CV silence | Upgrade menu |
| R12 | Insulin administration | must_have | direct | medium | none | CV states it | `[grounded]` CV | none |
| R13 | Care planning | must_have | unclear | low | discovery | CV silent; discharge planning may count | `[grounded]` CV silence | Gap G5 |
| R14 | End-of-life visits | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | Gap G5 |
| R15 | Doppler assessment for leg ulcers | preferred | absent | none | capability | CV states none. Training would be the closure path | `[grounded]` CV; `[generic]` that it is usually trained | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R7, must_have) | transferability | Home visits after discharge, with no caseload held | Stated as a core duty of the post; the objection most likely to come up | Planning a patient's care from first visit to discharge, with a senior nurse at a distance; running your own visit list | A care plan you wrote, a visit log, an audit line | `[inferred]` bridge from CV; `[generic]` that caseload ownership is the usual step-up objection |
| G2 | Written records and EPR (R6, must_have) | discovery | The CV does not name the record system or documentation standard | Stated as a must-have; affects the first months | Any electronic record you have used; documentation audit or handover notes | A record sample with identifiers removed | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R9, must_have) | transferability | Wound care generally; no leg-ulcer work | Named in the JD's core work | Any venous or mixed leg-ulcer dressing or review you have seen | A dressing plan or training record | `[inferred]` from CV |
| G4 | Doppler assessment (R15, preferred) | capability | None stated | Preferred only | Any vascular assessment training | Training certificate, or an employer-funded course | `[grounded]` CV; `[generic]` on training |
| G5 | Care planning and end-of-life (R13, R14, must_have) | discovery | Silent in CV | Core to the role, and both are unclear | Discharge plans you wrote; any family or end-of-life conversation you led | A care plan | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | risk_signal | low | "Current vacancies are listed on our careers page" | The post may be filled or stale; the careers address I tried did not load | `[inferred]` from the About page against a failed fetch | Is this Band 5 post still open, and what does the interview process look like? | unresolved |
| RR2 | Caseload ownership undefined | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | Support may be thinner than the wording suggests, or the caseload may start small | `[inferred]` from JD wording against its silence on size | What size is the caseload at the start, and how is it supported week to week? | unresolved |
| RR3 | Mileage terms unstated | unknown | — | "plus mileage" beside "pool cars are provided" | Mileage may apply only to your own car, which would change real pay | `[inferred]` from the two travel terms | Is mileage paid on your own car only, and at what rate? | unresolved |
| RR4 | Employer established | positive_signal | — | "Calderbrook Community Health CIC" | The employer exists as described | `[grounded]` About page | — | noted |

No request is made of you in the posting or in any message, so no severe entry applies.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Check your NMC register entry and your driving record before applying | R1, R2 are stated, not checked | `[grounded]` gate rows | your action |
| E2 | CV: lead community evidence with your discharge-to-assess home visits, in your own words. No new claims, and no leg-ulcer or EPR claims added | R7, R9 | `[grounded]` your CV | resume_edits_pending_approval |
| A1 | Before you apply, confirm the post is open through the employer's own contact route, and ask RR1 and RR3 | RR1, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are stated, not verified.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers community staff nurse Band 5 vacancy"; the About page (calderbrookhealth.example/about) confirms the entity. Fetch of calderbrookhealth.example/careers returned no page, so the posting is not confirmed live. Moved: the employer-established entry (RR4) and the posting check (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse Halifax district nursing salary 2026"; the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration in role reality |
| 3. Hiring manager's public footprint | unavailable | Rhiannon Mabbott is named as the contact, not confirmed as the hiring manager; the budget went to targets 1 and 2 first. Would have moved the scope read |

## Upgrade menu

- A link to the live posting, or confirmation from the employer → RR1 closes.
- Your pay floor → R4 closes, and the decision can move to `go`.
- A record or documentation sample with identifiers removed → R6 to `medium`.
- A leg-ulcer dressing or review example → R9 to `medium`.
- Details of any vascular or Doppler training → R15 is already minor; this would move it to a closure path.
- A deeper research pass on Calderbrook Community Health (leadership, NHS contract history, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can write this assessment out as a `tuesday-dossier.md` file to keep.

**Questions**, tagged to their rows:

Q1 (R4): Is your pay floor at or below £31,050? If it is higher, which figure is it, and does mileage count toward it?
Q2 (G1, R7): Have you ever planned a patient's care from first visit to discharge without a senior nurse on the visit? What did you decide, and what happened?
Q3 (G2, R6): Which electronic record system have you used, and how did you write up home visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.