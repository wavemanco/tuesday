**Yes, it's worth applying for, as a conditional go.** On the evidence, your registration, licence, experience and core clinical skills meet the essential criteria. The real gap is owning a caseload, which the post itself scaffolds with senior support. The advert's details are consistent with an established employer, but I could not find the posting itself on the company's site, so check that before you invest in the application.

## Decision snapshot

**Status: `conditional_go`.** Apply, on the conditions in the last line below.

**Fit ledger**
- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R7; adjacent: R5 (leg-ulcer wound care), R6 (continence care), R8 (care planning), R10 (own caseload), R11 (home visits); unclear: R4 (clear, timely written records)
- `important`: unclear: R12 (electronic patient record); absent: R9 (end-of-life visits)
- `preferred`: absent: R13 (Doppler assessment)

R10 is the one to watch: caseload ownership is adjacent, at `medium` confidence, and the advert names it directly.

**Opportunity ledger.** Sound, with one unverified item. The employer is attributable (RR4 is not triggered), pay sits inside the 2026 survey's typical range, and there are no red flags or payment requests. The posting itself is not confirmed live (RR1).

**Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. Both gates are stated by you and not checked by me: check your NMC register entry and your driving record yourself.

**Severe red flags:** none found.

**What would change this:** conditions for go:
1. RR1: the post is confirmed open on Calderbrook's own careers page, or by their team.
2. R10: in interview, the senior-nurse support and the caseload's size and phasing are confirmed.
3. Your pay floor and mileage or pool-car arrangement are checked against the posting (the constraint check is still open).
4. Your own statement of R5, R6 and R10 stays as adjacent: no caseload or leg-ulcer claims in the application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Calderdale: adult community nursing, therapy and rehabilitation under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` company about page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, electronic records; a small caseload with a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 a year, plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Wardround 2026 survey of Band 5 community staff nurses (n=1,240): median £34,300, interquartile range £32,400–£36,600. The advert's range sits around that median. 61% of respondents were paid mileage; 24% had a pool or lease car | `[generic]` role-family sweep, this month |
| Unknowns | Caseload size and phasing; the support model; the electronic record system; whether Doppler training is provided; out-of-hours expectations; when mileage is claimed against a pool car | — |
| Contradictions | None found, but the posting is not confirmed on the company's site | `[grounded]` absence on the careers page |

The public speaker listing for the Team Lead (see Evidence status) suggests the team has run Doppler training for staff new to community work; that is an inference about the employer and is labeled `[inferred]` in R13.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | high | none | Stated: registration active, revalidation due March 2028. Not checked by me | `[grounded]` your CV | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Stated: full licence, category B. Not checked by me | `[grounded]` your CV | Check your licence status |
| R3 | One year or more post-registration experience | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Your CV does not describe your records; discharge-to-assess visits imply documentation | `[inferred]` from the role of the visits | Be ready to describe your documentation |
| R5 | Wound care, including leg ulcers | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds (direct); leg ulcers not stated | `[grounded]` CV; `[inferred]` adjacency | See G2 |
| R6 | Catheter and continence care | must_have | adjacent | medium | transferability | Catheter care is direct; continence is not stated | `[grounded]` CV; `[inferred]` adjacency | See G2 |
| R7 | Insulin administration | must_have | direct | high | none | Stated | `[grounded]` your CV | none |
| R8 | Care planning | must_have | adjacent | low | discovery | Discharge planning is implied, not stated | `[inferred]` | Describe the planning you did |
| R9 | End-of-life visits | important | absent | none | capability | Nothing in the CV | `[grounded]` absence | See G1 |
| R10 | Own small caseload, with senior support | must_have | adjacent | medium | transferability | Home visits are direct; holding a caseload is not stated | `[grounded]` CV; `[inferred]` | See G1 |
| R11 | Home visiting to housebound adults | must_have | adjacent | medium | transferability | Home visits for the first week after discharge (direct); housebound long-term not stated | `[grounded]` CV | none |
| R12 | Electronic patient record | important | unclear | low | discovery | Not stated | `[grounded]` absence | Ask what system you used |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not stated; desirable, not essential | `[grounded]` absence; training `[inferred]` | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and end-of-life (R10, R9) | transferability / capability | Home visits are direct; holding a list or end-of-life work is not stated | The advert names both as core duties | Any patient list you followed over weeks in discharge-to-assess; any end-of-life care on the ward | A handover record or a service description | `[inferred]` |
| G2 | Leg ulcers, continence (R5, R6) | transferability | Pressure and surgical wounds, and catheters, are direct; leg ulcers and continence are not stated | Both are listed core tasks | Any continence assessment or dressing regime you ran | A wound-care protocol you followed | `[inferred]` |
| G3 | Doppler (R13) | capability | Absent | Desirable only | Any vascular assessment training | A training certificate, if you hold one | `[generic]` that employers of this kind often train it in post |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team" | The advert may be stale or aggregated, or the post may be filled | `[inferred]`: no careers page found at the address the company's site points to | Is this post open now, and who would I interview with? | unresolved |
| RR2 | Supported caseload | positive_signal | — | "supported by a senior community nurse" | The first months are scaffolded, which is the usual model | `[grounded]` advert | How are caseloads phased for a new starter? | noted |
| RR3 | Pool car and mileage | unknown | — | "pool cars are provided" and "plus mileage" | Mileage may be paid only on your own car | `[grounded]` advert | When is a pool car used, and when is mileage claimed? | unresolved |

RR4 (employer not established) is not triggered: the company's about page establishes the entity and its size.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line, proposed: "Completed home visits in the first week after discharge (18 months, discharge-to-assess team), including wound care, catheter care and insulin administration." | Uses the home-visit record without claiming a caseload | `[grounded]` your CV | `resume_edits_pending_approval` |
| A1 | Confirm the post is open on Calderbrook's own careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask at the informal chat how caseloads are phased and whether Doppler training is provided | See RR2, R13 | `[grounded]` RR2; training `[inferred]` | pending your approval |
| A3 | Use the Team Lead's public speaking record (nurse-led leg-ulcer clinics, Doppler training for new community staff) only as a question about her team, not as a claim about you | Public professional footprint only | `[grounded]` speaker listing | pending your approval |

## Evidence status

Verified: R1, R2, R3, R7 claims, stated by you, not yet checked against the registers. R4 to R13 are unverified; they stay as the adjacency and gap calls above until you confirm them.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health vacancies Community Staff Nurse Band 5"; read the about page (calderbrookhealth.example/about). The careers page at calderbrookhealth.example/careers returned no page, so the posting is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary NHS 2026", which returned the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a speaker listing (communitynursingforum.example/speakers/rhiannon-mabbott). Used only for the application plan's framing (A3) |

## Upgrade menu

- A live posting link, or a screenshot of the Calderbrook careers page, closes RR1.
- Any end-of-life, leg-ulcer or continence work or handover record moves R9, R5 and R6.
- A caseload or discharge-to-assess handover record would raise R10 to `high`.
- Your pay floor and a pool-car preference let the constraint checks run.
- A deeper pass on the company (funding, leadership changes, staff reports) at L2: up to 5 more searches and 2 more fetches. Say the word and it runs.

Dossier: I can write this assessment to a `tuesday-dossier.md` file if you want to keep it.

1. Is the advert from Calderbrook's own careers page or from a job board? If the latter, can you find the page on their site? (RR1)
2. In discharge-to-assess, did you follow a list of patients over several weeks, or work with any end-of-life patients? (R10, R9)
3. What is your lowest acceptable salary, and does a pool car suit you, or do you need to use your own? (constraint checks)

Answer in text for any of these, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.