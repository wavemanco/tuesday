# Decision: no_go on these terms. Send nothing, pay nothing, and don't deposit the cheque.

**Fit ledger (your background against the posting's stated requirements)**
- **Strong:** customer service at volume (about 60 Zendesk tickets a day), trained two new starters, keeps a weekly Excel tracker. These match attention to detail, spreadsheets, and the training-heavy role. [grounded: your background; inferred match to the posting]
- **Unknown:** a quiet place to work. Only you can confirm that.
- **Unknown:** remote order-processing experience. The posting asks for none, so this is not a gap.

**Hard gate: pay floor of €30,000 a year, not met on the posting's own terms.** [grounded, by arithmetic] At €26 an hour, €30,000 needs about 22 hours a week every week, before commission. The posting's range is 15–30 hours, which works out to about €20,300–€40,600 at the full rate. The posting does not state a fixed salary, so the realistic figure is lower than the top of that range.

**Red flags (quoted, high severity)**
- "Please pay €349 by bank transfer to our equipment partner": a demand to pay for equipment.
- "Lodge it to your account… transfer the rest to our equipment partner": a demand to move money out of a cheque before it has cleared.
- "send your IBAN, your PPS number and a clear photo of your passport" before any interview.
- The whole process, including the offer, runs through Telegram chat.
- The cheque figures don't add up. You were first told to pay €349 and be refunded later, then told to forward €2,500 from a cheque. Either way, your own money goes out.

These are the requests to check with the company itself. Find Velloway's website through a search, not through the Telegram handle or the email address in the messages, and ask them directly whether they are recruiting you and whether they ask for money or bank details during hiring.

**Why the cheque step matters:** banks often make a deposited cheque's funds available within days, but a fake cheque can be found weeks later. By then the money you sent out is gone, and you may owe the shortfall. This is the general pattern, not a judgment about the sender.

**Do now**
- Don't send your IBAN, PPS number, or passport photo. I haven't repeated your IBAN here, and you don't need to share it for this assessment.
- Don't pay or transfer anything, and don't deposit the cheque if one arrives.
- If you have already sent any details, call your bank using the number on your card, tell them, and ask them to watch the account. Then report it to the Gardaí.

**Research tier: L0, no searches.** I haven't checked whether Velloway Logistics exists, so this assessment rests on the posting and messages alone.

**Upgrade menu:** a link to a live posting, Velloway's own careers page and registered company details, and a written offer from a company email domain. Any of these would let me check whether the employer exists. I can run a short L1 check (up to 5 searches and 2 page fetches) if you want that.

I can also draft a dossier of your background and the requirements you match, which you could use with any legitimate employer.

1. Did you send anything to @VellowayHiring yet, such as your IBAN, PPS number, or passport photo?
2. Is there a quiet place at home where you'd work? That is the one requirement still unconfirmed.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.