**Short answer:** Duinvaart is worth applying to once you've checked one thing: whether you can work three office days a week in Rotterdam. Kroonhaven isn't worth an application now, because it asks for three years of planning experience and fluent Dutch, and you have neither.

Research was blocked: web search permission was refused, so neither employer could be checked and no salary band is available. Both verdicts rest on the posting text and your background.

## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Decision snapshot.** Worth applying to once one question is answered. Status: `hold_pending_answers`.

**Fit ledger.**
- `hard_gate` — unclear: R8 (three office days a week in Rotterdam)
- `must_have` — direct: R1, R2, R3
- `important` — direct: R4a, R5, R6 · adjacent: R4b (temperature compliance)
- `preferred` — adjacent: R7 (Dutch a plus)

R1–R3 — your years, SQL and Power BI match directly; R4b — the one gap with no evidence behind it; R8 — the gate that decides the status.

**Opportunity ledger.** Clearly scoped: on-time and temperature metrics are named (RR3). Two things are unknown: whether the role decides route changes or only works alongside depot managers (RR2), and whether the employer exists as described (RR1).

- **Hard gates:** none failed; unconfirmed: R8 (three office days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a yes on the Rotterdam commute moves it to `conditional_go`, on the condition that the posting is confirmed on the employer's own site (RR1). A no makes it `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, refrigerated fleet, Rotterdam | `[grounded]` JD; existence unverified |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Scope read | An analyst role with defined metrics and a depot-manager audience; route decision rights not stated | `[inferred]` from "work with depot managers on" |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Market calibration | Not run (search refused) | — |
| Unknowns | Route-change authority; salary; whether temperature data is already in-house | — |
| Contradictions | None visible in the posting | `[grounded]` JD |

**Evidence map** (your background is self-report: `medium` is the ceiling until it's inspected)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` background | none |
| R2 | Strong SQL | must_have | direct | medium | none | SQL daily | `[grounded]` background | none |
| R3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily | `[grounded]` background | none |
| R4a | Track on-time delivery | important | direct | medium | none | Owned the on-time dashboard depot managers use | `[grounded]` background | none |
| R4b | Track temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | No cold-chain or temperature data in your background; threshold monitoring is the nearest | `[inferred]` | Q2 below |
| R5 | Weekly dashboards in Power BI | important | direct | medium | none | Built the depot-facing dashboard | `[grounded]` background | none |
| R6 | Work with depot managers on route changes | important | direct | medium | presentation | Ran the weekly route-performance review; the route-change outcome isn't stated | `[grounded]` background | E1 below |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your statement | State the limit |
| R8 | Hybrid, three office days a week in Rotterdam | hard_gate | unclear | none | hard_gate | No statement of your location or commute yet | — | Q1 below |

**Gap recovery queue**
- **R4b** (transferability): Closing path is a question about any temperature, cold-chain or alert work (Q2). Without it, present the threshold-monitoring link as adjacent, never as cold-chain experience.
- **R8** (hard gate): Only you can settle this (Q1).

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Research couldn't run, so nothing is established either way | `[generic]` | Is this role open on your careers site, and who is the hiring manager? | unresolved |
| RR2 | Route-change authority not stated | unknown | — | "work with depot managers on route changes" | The role may influence route changes rather than decide them | `[inferred]` from "work with" | Which route decisions does this role make itself, and which stay with depot managers? | unresolved |
| RR3 | Metrics named | positive_signal | — | "on-time delivery and temperature compliance" | Success is measurable | `[grounded]` JD | What targets are set today for on-time and temperature compliance? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Duinvaart's own careers page before writing an application | RR1 | `[generic]` | proposed |
| E1 | If you have one, add the outcome of a route change you were part of to the route-review bullet. Don't add one that didn't happen | R6 | `[grounded]` background | pending your approval |
| I1 | Ask RR2 at interview | RR2 | `[grounded]` register | proposed |

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

**Decision snapshot.** Not worth your time right now. Status: `no_go`.

**Fit ledger.**
- `hard_gate` — unclear: R1 (on-site in Utrecht)
- `must_have` — adjacent: R3 (own the 13-week plan), R4 (run the weekly S&OP), R7 (fluent Dutch) · unclear: R6 (advanced Excel) · absent: R2 (3+ years FMCG planning), R5 (SAP IBP or similar)

R2 and R5 — the two must-haves with no evidence; R3, R4, R7 — adjacent, with limits named; R6 — unknown, and it doesn't change the call.

**Opportunity ledger.** The scope is clear and well defined (RR2). The employer is unverified (RR1), but that doesn't drive the verdict.

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to be different:** three years of FMCG planning, or a planning system you've used. Neither closes quickly, so this is `no_go` for this application.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, chilled ready meals, Utrecht | `[grounded]` JD; existence unverified |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP | `[grounded]` JD |
| Scope read | A planner-owned plan with a fixed meeting cadence; authority over production capacity not stated | `[inferred]` |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Market calibration | Not run (search refused) | — |
| Unknowns | Salary; reporting line; capacity decision rights | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location isn't stated | — | Q1 below |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | medium | capability | You've never worked in planning; the nearest is route-performance analysis, which isn't planning | `[grounded]` your statement | none |
| R3 | Own the 13-week supply plan; balance capacity against forecast | must_have | adjacent | low | transferability | Parcel volume analysis is adjacent; no capacity or forecast ownership is stated | `[inferred]` | State the limit |
| R4 | Run the weekly S&OP | must_have | adjacent | medium | transferability | You ran a weekly route-performance review; that's a recurring cross-functional meeting, not S&OP | `[inferred]` | State the limit |
| R5 | SAP IBP or a similar planning system | must_have | absent | medium | capability | No planning-system use stated | `[grounded]` background | none |
| R6 | Advanced Excel | must_have | unclear | low | discovery | Not stated in your background | — | Doesn't move the call |
| R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; fluency is needed to run an S&OP meeting | `[grounded]` your statement | State the limit |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Kroonhaven Foods, Utrecht" | Research couldn't run | `[generic]` | Is this role open on your careers site, and who is the hiring manager? | unresolved |
| RR2 | Clear ownership of the plan and the S&OP | positive_signal | — | "Own the 13-week supply plan" | Scope is well defined | `[grounded]` JD | Who sets production capacity limits, and how often does the plan change? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A2 | Don't spend an application on this one now | R2, R5 absent | `[inferred]` | proposed |
| A3 | Look at planning-adjacent role families where the entry bar is closer to your work, such as demand or logistics analyst roles in FMCG | Your strongest evidence is analytical | `[generic]` pattern; no employer named | proposed |

## Evidence status

Verified: none yet. Everything above is your self-report, not confirmed in this conversation.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two employer searches (Duinvaart, Kroonhaven) were refused. Would have settled RR1 for both postings |
| 2. Role-family sweep | unavailable | Two salary and scope searches were refused. Would have set the market calibration lines |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu
- **Approve web search in this session** → I re-run the two employer checks and the role-family sweep. That settles RR1 for both postings and adds a salary band.
- **Your location and commute** → R1 (Utrecht) and R8 (Rotterdam) resolve. Posting 1 moves to `conditional_go` or `no_go`.
- **Any temperature, cold-chain or alert work** → R4b moves toward `direct`.
- **Links to the live postings** → RR1 closes for both, and I can check the wording against the text you pasted.
- **Your Excel level** → R6 for posting 2. This doesn't change `no_go`.

I can also write this up as a `tuesday-dossier.md` you can keep and bring back to later sessions.

Questions:

Q1 (R8 and R1, both postings): Where are you based, and could you commute to Rotterdam three office days a week, or to Utrecht on-site? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R4b, posting 1): Have you worked with temperature data, cold-chain compliance or threshold alerts, even for parcels, sensors or depot checks? If so, what did you own, and what reports or definitions can you point to? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.