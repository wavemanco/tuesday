**Decision: no-go on this opportunity as offered.** Your fit for the work is strong. The role's terms are the problem, and it should not be taken up through this channel.

**Decision snapshot**
- **Fit (Ciara):** strong on the stated requirements. Strongest on customer service and ticket volume, training others, and spreadsheets. Written English and a quiet workspace are stated, not verified.
- **Opportunity:** no-go. Three red flags are unresolved, and the pay floor is not met on the posted terms.
- **Hard gates:** pay floor failed on the posted terms (see mismatch below). Other gates (schedule, remote work) are met on paper.
- **Confidence:** the red flags rest on the messages you pasted, so they are `confirmed` as stated, not as established facts about who sent them.

**Role reality**
- Remote order processing, 15–30 hours a week, €26/hour plus commission (commission amount not stated).
- Pay check: €26 × 15 h × 52 = €20,280; × 30 h × 52 = €40,560. Your €30,000 floor needs about 22 hours a week at base rate, and the commission is unknown. `[grounded]` from the posting's own figures.
- Hiring is entirely by Telegram, with no call or video interview, and the sequence asks for sensitive data before any written offer.

**Evidence map (fit side)**

| # | Priority | Fit | Requirement | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | must-have | met | Attention to detail | Ticket handling at ~60/day, weekly tracker | medium (stated) |
| 2 | must-have | met | Spreadsheets | Keeps team's weekly Excel tracker | medium (stated) |
| 3 | must-have | met | Good written English | Stated; not verified | low (stated) |
| 4 | must-have | unknown | Quiet place to work | Not stated | none |
| 5 | hard_gate | partial | Pay ≥ €30,000/yr | Posted terms give €20k–€40k before commission | `[grounded]` |
| 6 | preferred | met | Training others | Trained two new starters | medium (stated) |

**Opportunity risk register**

| Class | Severity | Finding |
|---|---|---|
| red_flag | high | Asked to pay €349 to an "equipment partner" by bank transfer before any work, refunded later. Unsolicited payment demands for equipment are a standard sign of a job scam. |
| red_flag | high | Asked to lodge a €2,850 cheque, keep €350, and transfer the rest to a third party. Depositing a cheque and sending money on before it clears is the classic overpayment shape. |
| red_flag | high | Asked for IBAN, PPS number and passport photo before the interview and before any written offer. |
| red_flag | high | Whole process by Telegram, no verifiable employer contact. |
| mismatch | medium | Posted pay does not reach your €30,000 floor at the stated hours without high commission. |
| failed attribution | medium | Not verified that Velloway Logistics exists as described. Research was not run in this pass. Capped at conditional_go until verified. The contact is a generic email domain, which does not prove or disprove anything, but the company's own site should show the same address. |

**Application plan**
1. **Do not send** your IBAN, PPS number or passport, and do not pay the €349.
2. **Do not lodge the cheque** if one arrives, and do not transfer any of its money. Take it to your bank instead.
3. If you have already sent any details, contact your bank now to flag the account, and report the approach to the Gardaí. If a PPS number was shared, tell the Department of Social Protection.
4. Verify the company independently: find Velloway Logistics through its own website or a registry search, not through the Telegram account. If the company's careers page lists this role, apply through the contact details on that site.
5. For real remote customer-service or operations roles, lead with what you can show: ~60 Zendesk tickets a day, two starters trained, and the team tracker. Keep to those facts and do not add claims about English or accuracy beyond what you can support.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Not run in this pass; the decision rests on the posting and messages you pasted |
| 2. Role-family sweep | skipped | Not run; the pay comparison uses only the posting's own figures |
| 3. Hiring manager footprint | n/a | No name was given |

Research tier: L0 — no searches.

**Upgrade menu:** a check of the company's registration and its live website would confirm whether the employer exists as described. It would not change the decision on the messages' terms.

**Questions**
1. Have you already sent any details, money, or a cheque to this contact?
2. Where did you find the listing: the jobs site's own page, or a link you can share?

Dossier offer: I can produce a `tuesday-dossier.md` summary of this assessment for your records.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.