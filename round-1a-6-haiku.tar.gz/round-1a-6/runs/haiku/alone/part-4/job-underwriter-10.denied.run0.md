**Worth taking the call, on conditions. I can't confirm the company is legitimate from here.** Nothing you've shared asks you for money, a deposit, or bank or ID details, and the WhatsApp scheduling is routine. Status: `conditional_go`.

## Decision snapshot

**Status: `conditional_go`.** Your evidence fits most of the posting. The open items are working as the only designer and the company itself, which I could not check.

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2 (salary at or above your floor)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (own the booking flow end to end)
- `important`: unclear: R8 (work as the only designer)

**Opportunity ledger.** No severe signals. The employer is not established (RR1), and equity terms and design decision rights are unknown (RR2, RR3). The posting states pay and scope plainly (RR4).

- **Hard gates:** direct: R1 (Galway-based, two office days a week); unconfirmed: R2 (salary at or above your floor; you haven't given me one)
- **Severe red flags:** none found
- **What would change this:** conditions for `conditional_go`:
  1. The company checks out through sources you find yourself: its own site lists this role, it is registered (cro.ie), and the invite and the co-founder's email come from company addresses.
  2. The call answers RR2 and RR3 acceptably.
  3. Your salary floor is at or below €52,000.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting, self-described; not established |
| Mandate | First designer: own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week in Galway | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A one-designer role at a six-person company, with no design peers named | `[inferred]` from "first designer" against team size |
| Market calibration | Not run. Research was refused (see Evidence status), and I won't estimate a band from memory | — |
| Unknowns | Equity form and vesting; design decision rights; your salary floor; whether the company is registered | — |
| Contradictions | None between the posting and the WhatsApp message | `[grounded]` |

The WhatsApp message takes no register entry. Scheduling a video call by chat, with the invite sent by email, is a routine step.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in Galway; can do two office days a week | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your background | none |
| R2 | Salary at or above your floor (€52k–€60k) | hard_gate | unclear | low | hard_gate | No floor given | `[grounded]` posting | tell me your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` CV | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no portfolio artifact yet | `[grounded]` CV | a portfolio link would raise this |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; your participants were travel customers, not school owners | `[grounded]` CV | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one segment of a booking flow in a different domain | `[inferred]` from CV | G2 |
| R7 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` CV | none |
| R8 | Works as the only designer, with no design peers | important | unclear | low | transferability | You have never been the only designer anywhere | `[grounded]` your statement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Only designer (R8) | transferability | Always had design peers to check your work | The posting says you'd be the first designer, so review and decisions fall to you | A project you drove alone from brief to release, even a freelance or side one | `[grounded]` posting and your statement |
| G2 | End-to-end booking flow (R6) | transferability | Checkout work only, with no evidence of the whole flow | This is the core of the job | A case study covering more of the flow, or your share of search or availability work | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies this size; not a claim about this one | Can you point me at this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unspecified | unknown | — | "plus 0.5–1% equity" | Equity could be options or shares with a vesting cliff, and 0.5–1% of a small company may be worth little without the share count | `[inferred]` from the posting's silence | What is the total share count, the vesting schedule, and is it options or shares? | unresolved |
| RR3 | Design decision rights undefined | unknown | — | "You would be our first designer" | There may be no design reviewer, so decisions default to the founders | `[inferred]` from the posting's silence on who reviews design | Who signs off on design decisions, and what happens when design and engineering disagree? | unresolved |
| RR4 | Pay, scope and outcomes stated plainly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay and scope are named, which is more than many postings do | `[grounded]` posting | What would you judge this role on in its first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, find the company yourself: its website, a registration check at cro.ie, and LinkedIn for Ronan Kehoe and Saoirse. Use your own search, not links from the message. | RR1 | `[generic]` standard check | advice |
| P2 | Check the calendar invite's sender address against the company domain you found in P1 | RR1 | `[generic]` standard check | advice |
| P3 | Bring the checkout case study as it is, warts and all. The posting values "one messy real project" over a polished deck. | posting | `[grounded]` posting | pending your approval |
| P4 | Describe your work as "redesigned the checkout flow" and "ran monthly usability sessions." Don't say you owned the booking flow end to end unless you did. | R5, R6 | `[grounded]` CV | pending your approval |
| P5 | On the call, ask RR2 and RR3 word for word. For rehearsing the 45 minutes, the mock-interview skill is the right tool. | register doubles as interview prep | `[grounded]` register | advice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked that the company exists as described and that the role is live on its own careers page. Web search was refused in this session, and I did not retry. |
| 2. Role-family sweep | unavailable | Would have set the €52k–€60k band against product-designer norms in Ireland. Same refusal. |
| 3. Hiring manager's public footprint (Ronan Kehoe) | unavailable | Would have checked his public professional footprint. Same refusal. |

Your observation that there is little about the company online is the only evidence I have on its footprint.

If you want, I can save this assessment as `tuesday-dossier.md`.

## Upgrade menu

- Web search permission for this session: runs targets 1–3, which would settle whether the company exists, whether the role is live, and what the salary band is.
- Your salary floor: closes R2.
- A portfolio link or checkout work sample: raises R4 and strengthens R6.
- The invite's sender address or the careers-page URL: settles or sharpens RR1.
- Deeper diligence on the company (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches): say the word and I'll run it.

1. What is your salary floor, and is anything else a fixed line for you, such as contract type or start date? (R2)
2. Have you ever shipped a design decision with no one to check it? How did it go? (G1, R8)
3. Who sent the calendar invite, and from which email address? (RR1)

Answer in prose, or skip any of these; skipping is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.