**Worth taking the call — `conditional_go`.** Nothing in the posting or the WhatsApp message asks you for money, deposits or bank details, and the call is a normal next step. Your fit is strong on the requirements you can evidence (R2, R3, R5, R7). The open question is whether Fernquay is what it says, and I could not check that: search permission was denied this session, so the company is unverified (RR1). Your biggest fit risk is the "first designer" part, since you have never worked without a design team (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person booking-software company in Galway for sea-kayak and surf schools, with two engineers | `[grounded]` posting; `[inferred]` from the posting, unverified |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe; CTO Saoirse joins the call | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two days a week in the Galway office, otherwise remote | `[grounded]` posting |
| Scope read | Three roles in one title (designer, researcher, and a ship-with-engineers role). Bundled, and at this size usually junior-priced | `[inferred]` from the duty list |
| Pay | €52,000–€60,000 plus 0.5–1% equity, both stated | `[grounded]` posting |
| Market calibration | Not run. Search was unavailable, so I have no sourced band for this title, seniority or city, and I won't quote one from memory | — |
| Unknowns | Whether the company is registered and live; whether you'd have design review or decision rights; equity class, vesting and strike price; whether the salary is fixed | — |
| Contradictions | None found in what you provided. Not checked against the employer's own site (see Evidence status) | — |

## Decision snapshot

**Worth pursuing: take the call and verify the company first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4a, R5, R7 · unclear: R4b (owning the flow end to end)
- `important` — adjacent: R6 (school-owner research calls) · unclear: R8 (working as the only designer)

R4a — the checkout redesign is close to a booking flow; R4b — end-to-end ownership is unshown (`unclear`); R6 — customer usability sessions are not B2B operator interviews (`adjacent`); R8 — your evidence is all from squads, not solo work (`unclear`).

**Opportunity ledger.** Mostly clear, with one unverified base. The posting is specific and states pay and equity (RR7). It says it wants a real project over a deck (RR6). The company itself is unestablished (RR1), the design scope may be bundled and solo (RR2, RR3), and the salary and equity terms are unknown (RR4, RR5).

- **Hard gates:** none failed; Galway hybrid met (R1 `direct`); candidate constraints not given — checks against salary, contract type and work authorization unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The company verifies: a registered company matching the name, a domain that matches the invite, and the role live on its own careers page (RR1).
  2. The solo-designer scope is concrete on the call: who reviews design, what ships, and what research budget and tools you get (RR2, RR3).
  3. Pay and equity hold up when you ask about them (RR4, RR5).

**What would change this:** a company that can't be found on the register, or a role that isn't on its own site, would move this to `hold_pending_answers` until resolved.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway hybrid, two days a week on site | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your statement | confirm the two-day pattern suits you |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years as product designer at a Dublin travel-booking company. CV claim, not yet checked | `[grounded]` your statement | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily Figma use. No file to show yet | `[grounded]` your statement | share a Figma file of the checkout work (see upgrade menu) |
| R4a | Design a booking flow | must_have | direct | medium | none | You redesigned the travel-booking checkout flow | `[grounded]` your statement; Ronan says they've seen the case study | lead with the checkout case study |
| R4b | Own the booking flow end to end | must_have | unclear | low | discovery | Redesign work is shown; whether you owned discovery through to ship is not | `[inferred]` from the checkout claim against the "end to end" wording | ask on the call (Q3 below covers this area) |
| R5 | Has run their own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your statement | none |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Your research was with travel customers, not B2B operators | `[inferred]` from the segment difference | name the transfer: interview technique carries over, the audience doesn't |
| R7 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your statement | none |
| R8 | Works as the only designer | important | unclear | low | discovery | You've never been the only designer. No evidence either way for solo working | `[grounded]` your statement; the posting's "first designer" | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership (R4b, must_have) | discovery | Checkout redesign is shown; discovery and shipping ownership is not | The posting's core ask is "own the booking flow end to end" | Any project where you set the brief, ran research and handed off | A short write-up of one project showing your role at each stage | `[inferred]` from the CV against the posting |
| G2 | Solo working (R8, important) | discovery | Squad-based; no solo work | A first-designer role gives no design peers | Freelance, side or volunteer work done alone | Any solo project, even small | `[inferred]` |
| G3 | School-owner research (R6, important) | transferability | Customer usability work, travel domain | Research calls with school owners are a named duty | Interviews with any small-business owners | An interview guide or research summary from any segment | `[inferred]` |

The question each gap implies is in the closing block, tagged with its row id.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. A thin footprint is common for companies this size | `[generic]` pattern for companies of this size; not a claim about this company. Search was unavailable, so this is unverified | Which company is registered to employ this role, and where is the live posting on your own careers site? | unresolved |
| RR2 | Responsibility without a team | risk_signal | medium | "You would be our first designer" | You may be the only designer, with no design review and unclear decision rights | `[inferred]` from "first designer" against no team or review process named | Who reviews design work, who decides what ships, and what research budget and tools do I get? | unresolved |
| RR3 | Bundled roles | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | Designer, researcher and product-owner duties may be folded into one junior-priced title | `[inferred]` from the duty list | Which of these three roles are you hiring for, and how would you split my time across them? | unresolved |
| RR4 | Salary range, calibration not run | unknown | — | "Salary €52,000–€60,000" | The range may be the real budget or an opening offer. Without a search I can't say whether it matches the market | `[grounded]` posting figure; band not established | Is this range the approved budget for the role, and does it depend on experience? | unresolved |
| RR5 | Equity unvalued | unknown | — | "plus 0.5–1% equity" | Value depends on class, vesting, strike price and the company's valuation, none of which are stated | `[grounded]` posting figure | What share class is this, what's the vesting schedule and cliff, and what's the strike price? | unresolved |
| RR6 | Asks for real work over a deck | positive_signal | — | "we would rather see one messy real project than a polished deck" | They value real work, so your checkout case study fits what they asked for | `[grounded]` posting | Which real project would you like me to walk through? | noted |
| RR7 | Pay and equity stated; CTO in process | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" and CTO Saoirse on the call | Stating pay early and bringing in the CTO suggests a process with some structure | `[grounded]` posting and WhatsApp message | What does the hiring process look like after this call? | noted |

**Routine, no entry.** The WhatsApp message is scheduling for a video interview, and it says the invite comes by email. That is routine for a small company and takes no register entry. It asks for nothing else.

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Search the Companies Registration Office (CRO) register for the company name; check that Ronan Kehoe and Saoirse appear as officers or directors | Establishes that the company exists | `[generic]` CRO is Ireland's public company register | pending your approval |
| A2 | Check the invite's sender domain against the company domain you find on its own website; use only contact details you find there | Confirms the invite is from the company | `[grounded]` RR1 | pending your approval |
| A3 | Ask Ronan for the live role on their careers page if you can't find it | Closes RR1 | `[grounded]` RR1 | pending your approval |
| A4 | Prepare one messy real project (the checkout case study works) and a clear account of how you'd work alone | Answers RR6 and covers R8 and G1 | `[grounded]` gap queue | pending your approval |
| A5 | Ask RR2, RR3, RR4 and RR5 on the call, verbatim | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A6 | Don't claim solo or sole-designer work you haven't done. Describe the squad and the checkout work accurately | Keeps the CV honest on R8 | `[grounded]` R8 | pending your approval |

If an offer arrives, enter any bank, tax or ID details only in the employer's own portal, at the address its own website gives. For rehearsing the 45-minute call, `mock-interview` is the sibling skill for that.

## Evidence status

Verified: none yet. Everything above rests on your statements and the posting.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

I ran three searches and all three were refused with a permission error. I did not retry. Those three are counted above because they were sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked the company exists, its stage and size, and that the posting is live. Feeds RR1 and the failed-attribution check |
| 2. Role-family sweep | unavailable | Would have set the title, scope and salary band for this seniority. Feeds RR4 and the market calibration |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, so this target applies, but search is needed to look at it. Would have fed the scope read and which story to lead with |

## Upgrade menu

- Permission to use web search → L1 targets 1–3 run: company registration, live posting, the role-family salary band, and Ronan's public footprint. The most useful single step.
- The company's registered name, or a link to the role on its own site → RR1 closes or stays open.
- A Figma file or screenshots from the checkout project → R3 rises to `high`, and R4a rises with it.
- The salary and equity answers → RR4 and RR5 close, and the figures can be set against the market band.
- A deeper diligence pass on Fernquay (funding, leadership, news, past hiring; up to 5 more searches and 2 more fetches) — say the word and it runs once search is allowed.

I can write this up as `tuesday-dossier.md` so the verification questions and call prep carry into a later session.

**Questions**

1. (RR1) Do you have the company's registered name, or a link to the role on its own careers site?
2. (hard gates) Are there constraints you want checked against this role, such as a salary floor, contract type or work authorization? You haven't given any, so those checks are unknown.
3. (R8, R4b) Has any of your design work been done without a team around you, even a side or freelance project, and have you ever owned a project from discovery through to shipping?

Answer any of these, or say "skip", and I'll treat silence as an answer. Each one is optional.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.