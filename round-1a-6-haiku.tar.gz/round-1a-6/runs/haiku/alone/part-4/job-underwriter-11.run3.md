**Duinvaart (Operations Analyst, Rotterdam): worth applying, once the posting is confirmed.** Status: `conditional_go`.
**Kroonhaven (Supply Planner, Utrecht): not worth your time as written.** Status: `no_go`.

## Decision snapshot

**Duinvaart: `conditional_go`.** Your SQL, Power BI and depot-manager work line up closely with this role, and the posting shows no red flags. I could not confirm the company exists, so apply only after you find the listing on Duinvaart's own careers page.

- **Fit ledger (Duinvaart):**
  - `must_have` direct: D1, D2, D3. Adjacent or unclear: D4.
  - `important` direct: D5.
  - `preferred` adjacent: D6.
- **Hard gates:** none failed; unconfirmed: D7 (Rotterdam office, three days a week). Candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the listing and the employer are confirmed on Duinvaart's own site; (2) the Rotterdam commute works for you; (3) your cold-chain exposure is framed honestly (see D4).

**Kroonhaven: `no_go`.** Three must-haves are absent from your background: FMCG planning years (K1), SAP IBP (K2), and fluent Dutch (K3). Your strengths don't close those, so this posting is a weak target as written, whatever your fit on the other rows.

- **Fit ledger (Kroonhaven):**
  - `must_have` absent: K1, K2, K3.
  - `must_have` direct or adjacent: Advanced Excel (K4, unclear, not stated in your CV).
  - `hard_gate` unconfirmed: K5 (on-site Utrecht).
- **Hard gates:** none failed; unconfirmed: K5 (On-site Utrecht). Candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found. This is a fit verdict, not an opportunity verdict.
- **What would change it:** a planning role where you can show a real planning track record, or a Kroonhaven posting that drops IBP and fluent Dutch.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Cold-chain logistics, Rotterdam | FMCG food producer, Utrecht | `[grounded]` posting text |
| Scope | Track delivery and temperature compliance, build dashboards, work with depot managers | Own a 13-week supply plan, balance capacity against forecast, run S&OP | `[grounded]` postings |
| Scope read | Ordinary for an analyst title | Ordinary for a planner title | `[generic]` role-family pattern |
| Market calibration | Not checked: salary not stated | Not checked: salary not stated | Research unavailable |
| Unknowns | Employer existence, salary, decision rights | Salary, team size, hiring manager | — |
| Contradictions | None found in the text provided | None found in the text provided | `[grounded]` posting text |

## Evidence map

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| D1 | 2+ years logistics or operations analysis | must_have | direct | high | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your CV |
| D2 | Strong SQL | must_have | direct | high | none | Daily SQL use | `[grounded]` your CV |
| D3 | Power BI dashboards, on-time delivery | must_have | direct | high | none | You built the on-time dashboard depot managers use | `[grounded]` your CV |
| D4 | Temperature compliance across refrigerated fleet | must_have | unclear | low | capability | No cold-chain or temperature-monitoring evidence stated | `[grounded]` absence in your CV |
| D5 | Work with depot managers on route changes | important | direct | high | none | You ran the weekly route-performance review | `[grounded]` your CV |
| D6 | Dutch | preferred | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your statement |
| D7 | Rotterdam office, three days a week | hard_gate | unclear | — | none | Your commute and constraints are unknown | `[grounded]` posting |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply or demand planning in FMCG | must_have | absent | high | capability | You have never worked in planning | `[grounded]` your statement |
| K2 | SAP IBP or similar planning system | must_have | absent | high | capability | Not stated | `[grounded]` your CV |
| K3 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your statement |
| K4 | Advanced Excel | must_have | unclear | low | discovery | Not stated in your CV | `[grounded]` absence in your CV |
| K5 | On-site in Utrecht | hard_gate | unclear | — | none | Your commute and constraints are unknown | `[grounded]` posting |

## Gap recovery queue

- **D4 (temperature compliance):** a gap in capability. It would close with any cold-chain or temperature-monitoring exposure, even from a short project or a supplier you worked with.
- **K1 and K2 (planning years and IBP):** not closable from your current record. Don't invest effort here.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me to the live role on your own careers site, and who would I interview with? | unresolved |
| DR2 | Temperature compliance is a named outcome, with no stated tooling | unknown | — | "track … temperature compliance across our refrigerated fleet" | The role may own the temperature-monitoring data, or it may only report on it | `[inferred]` from the scope language | Which temperature data sources does this role use, and who owns them? | unresolved |
| DR3 | Salary not stated | unknown | — | none in posting | Not checked; research unavailable | — | What is the budgeted salary for this role? | unresolved |

Kroonhaven has the same standing entry (employer not established, `medium`), unverified for the same reason. Its salary is also unstated.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your on-time delivery dashboard and route-review work in the first bullets of your Duinvaart CV | D3, D5 | `[grounded]` your CV | pending your approval |
| E2 | Describe your temperature exposure honestly, or leave it out. Don't claim cold-chain experience you don't have | D4 | `[grounded]` absence | pending your approval |
| A1 | Find the Duinvaart listing on its own careers site before applying | DR1 | `[generic]` | pending your approval |
| A2 | Don't apply to Kroonhaven as written. If you want, target supply-chain analyst roles that don't require planning years or IBP | K1, K2, K3 | `[grounded]` | pending your approval |

Nothing here goes out without your approval. Don't describe your Dutch as fluent, and don't claim planning experience.

## Evidence status

Verified: none yet. Your statements are leads, not confirmed evidence.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

Research calls were refused: the WebSearch permission was not granted, so no results came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked that Duinvaart and Kroonhaven exist and that the postings are live (DR1) |
| 2. Role-family sweep | unavailable | Would have set the salary band for both roles (DR3) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Access to web search would let me check both employers and set salary bands. Without it, DR1 and DR3 stay open.
- A link to each live posting, from the employer's own careers page, would settle DR1 for both.
- Any cold-chain or temperature exposure would move D4 from `unclear` to `adjacent` or `direct`.
- A deeper pass on both employers (funding, leadership, staff reports, up to 5 more searches and 2 more fetches) is available on request.

## Dossier

If you'd like, I can save this analysis as `tuesday-dossier.md` so you can pick it up later.

**Questions**

1. Can you commute to Rotterdam three days a week, and to Utrecht on-site? (D7, K5)
2. Have you had any cold-chain, temperature-monitoring or supplier-quality exposure, even a short project? (D4)
3. Would you consider supply-chain analyst roles that don't require planning years, or is planning the only path you want? (K1, K2)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.