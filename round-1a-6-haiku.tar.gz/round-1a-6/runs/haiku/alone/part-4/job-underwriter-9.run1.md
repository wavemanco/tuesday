**Decision snapshot**

- **Decision: `conditional_go`.** The role is credible and the fit is strong on the core of the job. It is capped at conditional because I could not verify that Marrowgate Housing exists as described (see R1).
- **Fit ledger, by priority:**
  - *Must-have, Met:* 2+ years running payroll (3 years, 90 staff, `[grounded]` from your CV). Strong Excel (daily use, pivots, XLOOKUP, `[grounded]`). Payroll qualification (Payroll Technician certificate 2024, `[grounded]`). Monthly payroll-to-ledger reconciliation (done at your current role, `[grounded]`).
  - *Must-have, Unknown:* working knowledge of Irish PAYE, PRSI and USC. Your certificate may cover this, but your CV doesn't say so.
  - *Preferred or implied, Partial:* scale (240 staff against your 90, `[inferred]` as a stretch). Staff payroll queries: not stated.
  - *Preferred or implied, Gap:* pension changes. You have never done them yourself.
- **Hard gates:**
  - Two days a week in the Limerick office: **unknown.** Your commute or home location isn't stated.
  - €40,000 against your own floor: **unknown.** It sits inside the advertised €38,000–€42,000 band.
  - Start date after notice: **unknown.** Your notice period isn't stated.

**Your direct question: is the bank, PPS and passport request normal?**

Yes, for a hire at this stage. The sequence you were given is the normal one: interviews, then a written offer, then payroll and identity details through the employer's onboarding portal, then original ID checked in person on day one.

- **PPS number:** the employer needs it to run PAYE payroll and report to Revenue. `[generic]`
- **Bank details:** needed to pay your salary. `[generic]`
- **Passport:** a standard identity and right-to-work document. Employers often ask to see the original, and a scan may be kept on file. `[generic]`. Check the exact right-to-work rules for your situation (Irish or EU citizen, or otherwise) with the employer or an official source. I could not verify these details, as explained below.

Your instinct is right about the *risk pattern*, though. These details are safe to give only to the verified employer, and only through a channel you have checked. So before you enter anything:

1. **Check the email domain.** Confirm `marrowgatehousing.ie` matches the domain on their official website. Use a website you find yourself, not a link in the email.
2. **Reply to accept, but phone or email a contact you found independently** (the switchboard on their website) to confirm the offer and the portal. Don't reply only to the address that sent the offer.
3. **Check the portal link.** It should sit on their own domain and be the same one HR names when you call. Don't enter details through a link that arrives by chat, text or an unexpected message.
4. **Don't send bank details, PPS or a passport scan as plain email attachments.** Use the portal.
5. **Ask what is retained and why** (for example, whether a passport copy is kept after the day-one check). A reasonable employer will answer clearly.

Your own list of what needs checking is fine, but it doesn't make this offer suspicious. The details themselves are routine.

**Role reality**

- Scope: monthly payroll for 240 staff, starters, leavers, pension changes, monthly GL reconciliation, staff queries. Reports to Declan Garvagh, Finance Manager. Hybrid, two days a week in Limerick. Permanent.
- Market calibration: the €40,000 offer is inside the advertised band. I could not check the band against market data, so this is `[generic]` only.
- Contradictions: none between the advert and the offer. The offer doesn't mention pension scheme details, which the duties do.

**Evidence map (summary)**

| # | Priority | Fit | Requirement | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | Must-have | Met | 2+ yrs payroll | 3 yrs fortnightly payroll, 90 staff | high (CV) |
| 2 | Must-have | Met | Payroll qualification | Payroll Technician cert, 2024 | high (certificate) |
| 3 | Must-have | Met | Strong Excel | Daily use, pivots, XLOOKUP | medium (self-stated) |
| 4 | Must-have | Unknown | Irish PAYE/PRSI/USC | Not stated | none yet |
| 5 | Must-have | Met | Payroll-to-GL reconciliation | Monthly, your current role | high (CV) |
| 6 | Preferred | Partial | Scale (240 staff) | 90 staff; `[inferred]` stretch | medium |
| 7 | Preferred | Gap | Pension changes | Never done; manager handled | none |
| 8 | Preferred | Unknown | Staff payroll queries | Not stated | none yet |

**Gap recovery queue** (no questions here; the questions are below)

- **G1 (pension changes, gap, capability):** closes with any pension-related work you did touch, such as deduction files, auto-enrolment, or reconciling pension lines. If you did none, the honest framing is "learning this", not "experienced".
- **G2 (PAYE/PRSI/USC, unknown):** closes with a CV line, certificate module, or a worked example.
- **G3 (scale, partial):** closes with any evidence of handling higher volume or more complex starters and leavers.

**Reframing caution:** don't claim pension experience you don't have. Describe the adjacent work you did do accurately.

**Opportunity risk register**

- **R1 (failed attribution, `severity: medium`, standing):** I could not confirm that Marrowgate Housing exists as described. Possible explanations, none ranked as likely: a new or small employer, a stale posting, or a recruiter-style posting. This caps the decision at `conditional_go` until verified. It is not a finding against the employer.
- **R2 (pay, low):** inside the advertised band; your own floor is unknown.
- **R3 (onboarding data request):** routine after a credible written offer. Handled by the checks above, not recorded as a red flag.

**Application plan**

1. Verify the employer through a contact you find independently, then reply to accept within five working days. Counting from today (Thu 26 Nov), that is about Thu 3 Dec, but check from the date you received it.
2. Ask HR for the pension scheme details and the start date.
3. Enter bank, PPS and passport details only through the verified portal.
4. Before day one, prepare to show the original passport.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search was refused by the host's permissions; no company facts were checked |
| 2. Role-family sweep (pay and scope) | unavailable | Same refusal |
| 3. Hiring manager's public footprint | unavailable | Same refusal; only run with consent |

The refused searches count toward the budget. Nothing outside this message has been verified.

**Upgrade menu**

- A live link to the posting, or the company's careers page, would resolve R1.
- Web search access would allow the company check and the pay-band check.
- A CV line on Irish PAYE/PRSI/USC would move the unknown must-have to met.

I can also save this as `tuesday-dossier.md` if you want it to carry into interview prep.

**Questions**

1. Have you used PAYE, PRSI and USC day to day? Your certificate modules or hotel payroll rates would count. (Answer in prose, or skip.)
2. Can you do two days a week in Limerick? Where do you live, and what is the commute?
3. Did you touch any pension admin, such as deduction files, auto-enrolment, or pension lines on payslips, even if your manager made the changes?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.