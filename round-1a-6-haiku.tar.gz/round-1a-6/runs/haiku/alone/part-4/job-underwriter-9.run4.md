## Decision snapshot

**Yes, asking for bank details, PPS number and a passport scan after a written offer is routine onboarding, and it does not count against this job.** Status: `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (Limerick, two days a week), R3 (salary €40,000); candidate constraints not given — checks against them unknown.
- **Fit ledger.**
  - `hard_gate`: unclear: R1, R2, R3
  - `must_have`: direct: R4, R5, R6, R8 · unclear: R7 · adjacent: R9
  - `important`: direct: R10 · unclear: R11

  R7 — Irish statutory knowledge is unproven (G1); R9 — pension changes, a limit to name (G2); R1–R3 — checks against your constraints, not evidence gaps.
- **Opportunity ledger.** RR2 reads positive: a written offer naming role, pay and manager, after two in-person interviews at their office. RR3 is unknown on who approves the payroll run. RR1 caps the status: I could not verify that Marrowgate exists as described, because web search was refused in this session.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate verified on its own website (RR1); (2) R1–R3 confirmed by you; (3) R7 answered in interview (G1).
- **What would change this:** a `go` if RR1 verifies and R7 is evidenced. A `no_go` if you lack right to work in Ireland without sponsorship, or the location or pay fails your own limits.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a Limerick housing association | `[grounded]` posting and offer; existence not verified (research refused) |
| Mandate | Monthly payroll for 240 staff; starters, leavers, pension changes; monthly payroll-to-GL reconciliation; staff queries | `[grounded]` posting |
| Pay | Offer €40,000 permanent, within the posting's €38–42k | `[grounded]` posting and offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Routine onboarding | Bank, PPS and passport details after a written offer naming role and pay are the usual steps; right-to-work checks commonly need the original passport | `[generic]` pattern, not a claim about this employer |
| Scope read | One payroll post carrying the full run for 240 staff, about 2.7 times your 90, plus reconciliation | `[inferred]` from headcount against duties |
| Market calibration | Unavailable: the salary search was refused, so the €38–42k band is not checked against role-family norms | — |
| Unknowns | Payroll system; who approves the run; whether pensions are run in-house or by a provider; contract hours | — |
| Contradictions | None between the posting and the offer | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (offer's check) | hard_gate | unclear | none | hard_gate | You have not stated your status; the offer's check is routine, but you must confirm it yourself | `[inferred]` from offer | Q3 |
| R2 | Limerick office, two days a week | hard_gate | unclear | none | hard_gate | Your location and limits were not given | `[grounded]` posting | Q3 |
| R3 | Salary €40,000, permanent | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` offer | Q3 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; self-report, no artifact | `[grounded]` your background | none |
| R5 | Starters and leavers | must_have | direct | medium | none | Covered in your background; self-report | `[grounded]` your background | none |
| R6 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Covered in your background; self-report | `[grounded]` your background | none |
| R7 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Not stated whether the hotel payroll was Irish or whether the certificate covered these deductions | `[inferred]` that a certificate may or may not cover Irish law | G1 / Q1 |
| R8 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024; certificate not shown | `[grounded]` your background | none |
| R9 | Pension changes | must_have | adjacent | low | transferability | Starters and leavers are the link; you have not processed pension changes (your manager did) | `[grounded]` your statement; `[inferred]` adjacency | G2 / Q2 |
| R10 | Strong Excel | important | direct | medium | none | Pivot tables and XLOOKUP, used daily; self-report | `[grounded]` your background | none |
| R11 | Answering staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` silence | Ask in interview how queries are routed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory deductions (R7, must_have) | discovery | Three years of payroll and a 2024 certificate; Irish PAYE, PRSI and USC not mentioned | A must-have; if you have it, R7 moves to direct | Revenue submissions for the hotel payroll; USC or PRSI rate changes you applied; certificate modules on Irish deductions | Certificate syllabus; a sanitized calculation sheet | `[grounded]` background; `[inferred]` that the certificate may cover it |
| G2 | Pension changes (R9, must_have) | transferability | Starters and leavers, which link to pension enrolment and leaver deductions; no pension changes done | The main fit limit for this post | Any work touching enrolment, opt-outs or leaver deductions, even as a checker | A sanitized example of a leaver deduction you calculated | `[grounded]` your statement; `[generic]` that pension changes are a distinct skill |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing People Team", people@marrowgatehousing.ie | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Most small employers are simply small. | `[generic]` pattern; research refused, so nothing about this employer was checked | "Can you point me to this vacancy on Marrowgate's own careers page, and who would I be interviewing with?" | unresolved |
| RR2 | Written offer with pay, role and manager; two in-person interviews at the office | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000" | Terms and contact are concrete; the process has been in person | `[grounded]` offer and your account of interviews | "What does the first month look like, and who approves the monthly run?" | noted |
| RR3 | Authority and system over the monthly run not stated | unknown | — | "Run the monthly payroll for our 240 staff" | The role may run the full cycle and reconciliation without a named approver or system support | `[inferred]` from duties against silence on approval | "Who signs off the monthly run and the reconciliation, and which payroll system is used?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate's careers page yourself, and enter bank, PPS and passport details only in the portal it links to, never through a link in the email | Routine step, and the sender is not yet verified | `[generic]` advice | advice |
| A2 | Before accepting, ask the People Team: payroll system, who approves the run, and whether pensions are run in-house or by a provider | RR3, R9 | `[grounded]` register | proposed, pending your approval |
| A3 | In interview, answer R7 with what you actually know about Irish deductions, and no more | G1 | `[grounded]` R7 | proposed, pending your approval |
| A4 | Describe pensions as: "I have not processed pension changes; I've run starters and leavers and would learn the pension side" | R9 | `[grounded]` R9 | proposed, pending your approval |
| A5 | Use the five working days to verify the employer before accepting | RR1 | `[grounded]` offer | advice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on the employer and the vacancy were refused by the host, so nothing was checked. Would have confirmed the employer exists, the posting is live, and the sender domain and portal match its own site. |
| 2. Role-family sweep | unavailable | One salary search was refused. Would have set €38–42k against role-family norms. |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh), but no search was sent because research calls were refused. Would have shown his public professional role. |

## Upgrade menu

- Marrowgate's careers page link to this vacancy, found by you → RR1 closes or stays open.
- Web search allowed → the employer check and salary band run, and RR1 and the market calibration are filled.
- Certificate syllabus showing Irish statutory content → R7 moves toward `medium`.
- A sanitized example of a pension or leaver deduction you worked on → R9 moves toward `direct`.
- Your right-to-work status, location and pay floor → R1–R3 resolve to met or failed.

I can also save this underwriting as `tuesday-dossier.md`, so the verification questions carry into your interview prep.

**Questions**

- **G1 (R7):** Was the hotel group's payroll run under Irish PAYE, PRSI and USC, with Revenue submissions, and did your certificate cover those deductions?
- **G2 (R9):** Have you ever touched pension enrolment, opt-outs or leaver deductions, even as a checker?
- **Q3 (R1–R3):** Do you have the right to work in Ireland without sponsorship, and do Limerick two days a week and €40,000 fit your limits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.