**Status: `conditional_go`.** Yes, apply. On the CV, the essential criteria look met: active NMC registration, a full UK licence, more than a year post-registration, and wound, catheter and insulin care. The gaps are a caseload you have never held, leg-ulcer care, and Doppler, which is desirable rather than essential. The posting's live status is also unconfirmed.

**Fit ledger.**
- `hard_gate`: direct: R1, R2, R14 · unclear: R13 (Pay, £31,050–£37,800 plus mileage)
- `must_have`: direct: R3, R5a, R6a, R7 · adjacent: R5b (Leg-ulcer care), R10 (Home visits to housebound adults) · unclear: R4 (Clear, timely written records), R6b (Continence care), R8 (Care planning), R9 (End-of-life visits)
- `important`: adjacent: R11 (Holding a small caseload of own)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R5b and R10 are adjacent, with the limits named in the map. R11 is adjacent: visits are the nearest work, but you have not held a caseload.

**Opportunity ledger.** The employer is established: Calderbrook Community Health is a CIC running adult community nursing in Calderdale under an NHS contract, with 410 staff (`[grounded]` company About page). The open question is whether this advert is still live (RR1). The pay band sits around the 2026 Band 5 community median (RR3 covers mileage). No red flags. No requests for money, deposits or bank details.

**Hard gates:** none failed (R1 `direct`, R2 `direct`, R14 `direct`); unconfirmed: R13 (Pay, £31,050–£37,800 plus mileage); candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**What would change this:** the conditions for `conditional_go` are:
1. The post is confirmed open (RR1).
2. Caseload size and support are confirmed in the informal chat (R11).
3. Your pay floor sits within the band (R13).

Failing any of these moves it to `hold_pending_answers`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax: adult community nursing under an NHS contract, 410 staff | `[grounded]` company About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence, end-of-life, insulin, care planning; a small personal caseload with senior support | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse, England, 2026: median £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (n=1,240), searched this session |
| Pay position | The advert's £31,050–£37,800 spans that interquartile range | `[grounded]` advert, `[generic]` survey |
| Unknowns | Caseload size; mileage rate; whether Doppler training is provided; whether the post is still open | — |
| Contradictions | None found. The About page says current vacancies are on the careers page, but that page did not load and no listing came up in search | `[grounded]` About page; `[inferred]` from the failed fetch |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Stated on CV as active; the register entry is yours to check | `[grounded]` CV | Check the NMC register yourself before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated, category B; not checked here | `[grounded]` CV | Confirm the licence is full and current |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years on an acute ward | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on documentation; discharge visits imply records | `[inferred]` from the visit role | Q2 |
| R5a | Wound care incl. pressure ulcers, surgical wounds | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care carries over; no leg-ulcer work stated | `[inferred]` from R5a | Q1 |
| R6a | Catheter care | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Q1 |
| R7 | Insulin administration | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | unclear | low | discovery | Discharge planning is plausible but unstated | `[inferred]` | Q2 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Q1 |
| R10 | Home visits to housebound adults | must_have | adjacent | medium | transferability | Home visits in the first week after discharge; no long-term housebound caseload | `[grounded]` CV | Positioning, A1 |
| R11 | Small caseload of own, with senior support | important | adjacent | medium | transferability | Never held own caseload; discharge visits are the nearest work | `[grounded]` candidate statement | Q2 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done; closure path is training, which the Team Lead has spoken about | `[grounded]` candidate statement; `[grounded]` forum speaker page | A3 |
| R13 | Pay £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | No pay floor given, so the fit cannot be checked | `[grounded]` advert | Q3 |
| R14 | Lives in Halifax (role is in Halifax) | hard_gate | direct | high | none | Your own statement of location | `[grounded]` candidate statement | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer, continence, end-of-life (R5b, R6b, R9) | discovery / transferability | Wound and catheter care are stated; these three are not | Essential criteria in the advert | Compression bandaging, leg-ulcer dressings, catheter-and-continence assessments, palliative or end-of-life care on the ward | Any training record, a care plan, or a reference from a senior nurse | `[grounded]` CV silence |
| G2 | Caseload and care planning (R11, R8) | transferability | Visits only; no own list | Essential criteria in the advert | Named patient lists in discharge visits, planning visit order, follow-up plans | A sample care plan or handover note, anonymised | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status unconfirmed | unknown | — | "Current vacancies are listed on our careers page" (About page) | The post may have closed or been filled, or the advert may be out of date | `[inferred]` from the failed careers fetch | Is this post still open, and is this advert the current version? | unresolved |
| RR2 | Mileage terms unstated | unknown | — | "plus mileage" | Mileage rate and any cap are not known; pool cars are provided | `[grounded]` advert | What is the mileage rate, and is there a cap? | unresolved |

No `severity: high` entries.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with wound care, catheter care, insulin and home visits after discharge | R5a, R6a, R7, R10 | `[grounded]` CV | resume_edits_pending_approval |
| A2 | Check your NMC register entry and driving licence status before applying | R1, R2 | `[generic]` standard pre-application check | pending your approval |
| A3 | Ask Rhiannon Mabbott, through the advert's contact route: caseload size and support, whether Doppler training is provided, mileage terms, and whether the post is open | R11, R12, RR1, RR2 | `[grounded]` advert; `[grounded]` forum page | pending your approval |
| A4 | Don't claim leg-ulcer, continence, end-of-life or caseload experience unless it is true | R5b, R6b, R9, R11 | reframing audit | pending your approval |

Approval covers the CV edit (A1), the check and questions (A2, A3), and the claims guard (A4) above. Nothing is finalised until you approve it.

**Evidence status**

Verified: R1, R2, R3, R5a, R6a, R7, R10, R11, R12, R14 claims. R1 and R2 are the candidate's own statements, not checked, and their fits stay `direct` on that basis. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" (calderbrookhealth.example/about), and "Calderbrook Community Health vacancies Community Staff Nurse Band 5" (same page only); fetched calderbrookhealth.example/careers, which returned no page. Employer established; posting live status unconfirmed → RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary £31,050 £37,800", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the speaker page at communitynursingforum.example/speakers/rhiannon-mabbott. Confirms the role and the Doppler-training topic → R12 |

A dossier can be written to `tuesday-dossier.md` for later use if you want one; say the word.

**Upgrade menu**
- A chronological example of your documentation, anonymised → R4 moves from `low` towards `medium`.
- Any leg-ulcer dressing, compression or continence assessment experience, even from training → R5b and R6b.
- Your pay floor → R13 closes.
- The live advert link or a careers listing → RR1 closes.
- A deeper research pass on Calderbrook (leadership changes, staff reviews, other vacancies; up to 5 more searches and 2 more fetches): say the word and it runs.

Three questions, each answerable in text, by pasting a transcript, attaching a document, dropping a link, or saying skip:

1. G1 (R5b, R6b, R9): Have you dressed leg ulcers, managed continence problems, or taken part in end-of-life care, on the ward or on discharge visits? Give what you did, not what the team did.
2. G2 (R11, R8): In the discharge-to-assess role, did you have a named list of patients you were responsible for, and how did you plan and record visits?
3. R13: What is your pay floor, and is mileage essential to you?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.