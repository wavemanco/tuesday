**Decision: no-go. Don't send the IBAN, PPS number or passport photo, and don't pay the €349.** Nothing you've described needs a further check to reach this decision, and you haven't sent anything yet, so you can stop here.

**Why this isn't a legitimate offer**

- **Your money and documents are requested before any real offer.** They want your IBAN, PPS number and passport before even a chat interview. A real employer asks for bank and tax details only after a written contract.
- **You're asked to pay for your own job.** A €349 "equipment partner" payment with a promise of refund is a standard pre-payment tactic. Legitimate employers supply their own equipment.
- **The cheque is the most dangerous part.** You'd deposit €2,850, keep €350, and send €2,500 onward to the "equipment partner." Banks usually make funds from a deposited cheque available quickly, but the cheque can be returned as fraudulent days or weeks later. You would then owe the bank the full amount, and the transfer you already made would be gone. Moving money for someone else like this can also expose you to criminal liability as a money mule.
- **The process is Telegram-only**, with no call, video or verifiable company contact, and it moved from "screening" to "hired" in a few messages.
- **The pay is vague.** "Up to €26/hour plus commission on every order" with no defined base, hours or contract doesn't give you enough to judge the offer, and your €30,000 floor isn't what the posting describes.
- **The contact is a generic mailbox** (velloway.hr@postmail.example), not a company domain you can check.

I haven't searched for Velloway Logistics. The decision doesn't depend on it: even if the company is real, these requests are the problem.

**If you want to be safe**

- Don't reply to @VellowayHiring, don't deposit the cheque, and don't send any money or documents.
- If you've already shared your passport, PPS number or IBAN, tell your bank now and ask them to watch the account. Report the approach to the Gardaí, and ask your bank whether you should change anything.

**Your background fits legitimate roles.** Three years of Zendesk ticket work, training new starters and keeping a team tracker in Excel are the kind of evidence customer-operations and support-coordinator employers look for. If you'd like, I can help you find and check real postings, or tailor your CV for them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.