**Short answer: yes, it's normal onboarding, but only inside the employer's own portal.** Asking for bank details, your PPS number and an ID check after a written offer that names the role and pay is routine. Your rule applies to requests made before an offer, or by chat, and this one is neither. The safe way to do it is to reach the portal from the employer's own website, not from the email, and to avoid sending your passport as an email attachment.

**Status: `conditional_go`.** Accept only once you've confirmed the offer and the portal through Marrowgate's own website. Web search was declined in this session, so I could not check the employer or the market pay band, and I did not retry.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in the Limerick office)
- `must_have` — direct: R2, R5, R7 · adjacent: R4 (Monthly payroll for 240 staff) · unclear: R3 (Working knowledge of Irish PAYE, PRSI and USC), R6 (Pension changes)
- `important` — direct: R8, R9 · unclear: R10 (Answer staff payroll queries)

R2 (3 years running payroll), R5 and R7 (starters, leavers, payroll-to-ledger reconciliation), R8 (Excel) and R9 (Payroll Technician certificate) are the rows the evidence backs. R4 is a scale bridge from 90 staff to 240. R3, R6 and R10 need your answer before you accept.

**Opportunity ledger.** The stated €40,000 sits inside the advertised €38,000–€42,000 band (RR2), and the two in-person interviews at the office are a positive signal (RR3). The employer is not yet verified (RR1), which caps the status at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in the Limerick office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the portal confirmed through its own website (RR1); (2) R3 confirmed, meaning you have run PAYE, PRSI and USC yourself; (3) R6 scoped honestly, since you have not processed pension changes.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll, starters and leavers, pension changes, monthly payroll-to-GL reconciliation, staff queries | `[grounded]` job ad |
| Pay | €40,000 in the offer, inside the €38,000–€42,000 advertised band | `[grounded]` offer and job ad |
| Working pattern | Permanent, hybrid, two days a week in the Limerick office | `[grounded]` offer |
| Market calibration | Not run: web search was declined | — |
| Unknowns | Whether the offer and portal are genuinely the employer's; the scope of pension work; the team size behind 240 staff | — |
| Contradictions | None between the job ad and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | Your location is not stated; the interviews were in person at the office | `[grounded]` offer; your location not given | Confirm the commute works |
| R2 | 2+ years running payroll | must_have | direct | high | none | Three years of fortnightly payroll for 90 staff | `[grounded]` your CV, stated | none |
| R3 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | medium | discovery | Fortnightly payroll in Ireland implies these, but your message does not say you ran them | `[inferred]` from the payroll role | Question 1 |
| R4 | Monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran 90 staff; the same process scales, but volume and team size differ | `[inferred]` from your stated headcount | none |
| R5 | Starters and leavers | must_have | direct | high | none | Stated in your background | `[grounded]` your CV, stated | none |
| R6 | Pension changes | must_have | unclear | low | discovery | You have never processed these; your manager did | `[grounded]` your message | Question 2 |
| R7 | Monthly payroll-to-GL reconciliation | must_have | direct | high | none | Stated in your background | `[grounded]` your CV, stated | none |
| R8 | Strong Excel | important | direct | high | none | Daily use of pivots and XLOOKUP | `[grounded]` your CV, stated | none |
| R9 | Payroll qualification or working towards one | important | direct | high | none | Payroll Technician certificate, 2024 | `[grounded]` your CV, stated | none |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Not in your CV or message | `[grounded]` silence in your background | Question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R3) | discovery | Your payroll background suggests familiarity, but the specific returns are not stated | A must-have; the interviewers will likely probe it | Revenue ROS submissions, P30 or P35 reconciliations, year-end returns | A payslip sample or a checklist you used | `[inferred]` that this will be probed |
| G2 | Pension changes (R6) | discovery | You have not processed these directly | A must-have; probably asked about in interview | Checking deductions against a scheme schedule; reviewing a pension provider file | A scheme contribution report you reviewed | `[generic]` that pension work is commonly probed for this title |
| G3 | Staff payroll queries (R10) | discovery | Not in your CV or message | An important role duty | Answering payslip or tax-code queries in your hotel role | A query log or template reply | `[grounded]` silence in your background |

The gap queue holds no questions. The questions for G1, G2 and G3 are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The check did not run: web search was declined, so the employer is unverified rather than shown to be in doubt | `[inferred]` from the declined search | Can you point me to the live posting on your careers page, and confirm the People Team contact and portal address on your website? | unresolved |
| RR2 | Stated pay within the advertised band | positive_signal | — | "€40,000 a year" | The pay offered matches the posting | `[grounded]` offer and job ad | Is the €40,000 salary fixed for this role, or can it be reviewed? | noted |
| RR3 | In-person interviews at the employer's office | positive_signal | — | "two interviews in person at their office" | The interview process was run at a real location, which supports the offer | `[grounded]` your message | Who else is on the payroll team, and what does the 240-staff payroll run through? | noted |

The onboarding requests (bank details, PPS number, passport scan) are routine after a written offer that names the role and pay, so they have no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate's website yourself, not through the email, and check the careers page and People Team contact | Confirms the offer and the portal | `[generic]` standard check | proposed |
| A2 | Call the People Team on the number from their website to confirm the offer | Verifies the employer independently | `[generic]` standard check | proposed |
| A3 | Enter bank, PPS and ID details only in the portal reached from the employer's website; do not email a passport scan | Keeps personal data in the employer's own system | `[generic]` standard practice | proposed |
| A4 | Ask what they keep of your passport after the right-to-work check, and for how long | Data minimisation; a right-to-work check normally needs only sight of the document | `[generic]` Irish practice | proposed |
| A5 | Confirm your PAYE, PRSI and USC experience before you accept | Closes R3 | `[inferred]` from G1 | proposed |

## Evidence status

Verified: none yet. Your claims are stated, not documented.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed the employer and the live posting (RR1). Three searches were sent and declined; no search ran |
| 2. Role-family sweep | unavailable | Would have set the market pay band for this title. Not sent after the declines |
| 3. Hiring manager's public footprint | unavailable | Would have checked Declan Garvagh's public professional role. A name was given, but no search ran |

## Dossier offer

I can write this up as a `tuesday-dossier.md` you can keep and bring to mock-interview later.

## Upgrade menu

- A certificate copy or a sample Revenue ROS submission → R3 and R9 to `high`.
- A check of Marrowgate's website and careers page → RR1 closes or is confirmed.
- Web search, once permitted → the market pay band and a check on Declan Garvagh's public role.

## Questions

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Have you personally run PAYE, PRSI and USC through a live payroll, including Revenue submissions, or did someone else do that part?

G2 — Have you ever processed a pension change, or checked pension deductions against a scheme schedule, even if your manager signed it off?

G3 — Have you answered staff payroll queries directly, such as payslip or tax-code questions?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.