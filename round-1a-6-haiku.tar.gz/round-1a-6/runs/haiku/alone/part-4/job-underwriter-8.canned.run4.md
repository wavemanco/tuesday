**Decision: no_go. Don't send anything else to this sender, and don't deposit the cheque.**

**Snapshot**
- **Opportunity:** No-go as described. The hiring process has the hallmarks of a fake-cheque scheme, and the money flows run from you to them.
- **Fit (Ciara):** Strong on the stated skills. Three years of Zendesk ticket volume, training two new starters, and an Excel tracker map directly onto the requirements. Fit is high on capability, and the opportunity still fails.
- **Hard gates:** Pay is a mismatch. "Up to €26/hr" at 15–30 hours a week is roughly €20k–€40k a year before commission, and the posting doesn't state a base salary, so it can't be checked against your €30,000 floor.
- **Research tier:** L0, no searches run. Everything about the company is unverified.

**Why this is a no-go (red flags, from the posting and messages)**
1. **Pay to work:** You're asked to pay €349 for equipment, with a refund promised later.
2. **Cheque overpayment:** You'd deposit a €2,850 cheque, keep €350, and send the rest to "their equipment partner." Cheques can take days to show as cleared but still bounce later, leaving you short the money you transferred out.
3. **Sensitive details before any real offer:** IBAN, PPS number and passport photo requested before a chat interview.
4. **Hired entirely by chat:** No calls, no video, no named person, and an "interview" that was a chat exchange. Employers can run remote hiring this way, but this combination with items 1–3 is the pattern that matters.
5. **Unverifiable contact:** The only contact is a Telegram handle and a generic email address.

**What to do now**
- **Don't send your IBAN, PPS number, or passport photo, and don't pay the €349.** Ignore any further requests to "lodge" a cheque.
- **If you've already sent details**, contact your bank and ask them to flag the account and watch for unusual activity. Consider reporting to the Gardaí, and for PPS exposure, check your records with the Department of Social Protection.
- **If you want to check the company yourself**, look up Velloway Logistics in the Companies Registration Office (CRO) and on its own website, and use only contact details from the website, not from the messages.
- **If you want a legitimate remote order-processing job**, your background fits well. Apply through an established job board or the employer's own careers page, and expect a written contract and a payroll setup that doesn't involve paying the employer.

**Upgrade menu**
- If you want me to check Velloway (up to 5 searches and 2 page fetches), I can search its registration and online footprint. That would confirm whether the company exists as described.
- A link to the original job listing would let me check whether it's still live on the jobs site.

**Questions**
1. Have you already sent anything, such as your IBAN, PPS number, passport photo, or any money?
2. Do you want me to run the Velloway check described above?

*Research-consent note: no research has been run, and I haven't contacted anyone.*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.