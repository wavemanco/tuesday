**Yes, worth applying for, on three conditions. Status: `conditional_go`.** Your two stated gates (NMC registration and a full UK licence) are met as you described them, and the role's must-haves are mostly direct or adjacent to what you've done. Three things need checking before you commit: the posting itself, leg-ulcer work, and written records.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5, R7 · adjacent: R4 (leg-ulcer care), R8 (care planning) · unclear: R6 (continence care), R11 (clear, timely written records)
- `important` — unclear: R9 (end-of-life visits) · adjacent: R10 (own caseload)
- `preferred` — absent: R12 (Doppler assessment)

R4 — pressure-ulcer and surgical-wound work carries over; leg-ulcer work is not yet shown. R11 — records practice is not evidenced either way. R12 — no Doppler experience, a training route is needed.

**Opportunity ledger.** The role is defined on its own terms: pay band, a named contact, senior support and pool cars are all stated (RR3). Two things are unconfirmed: the posting is not yet verified live on the employer's careers page (RR1), and out-of-hours and on-call expectations are not stated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed on Calderbrook's careers page (RR1); (2) R6 and R11 are answered in discovery, with evidence if you have it; (3) the leg-ulcer bridge (R4) is framed as adjacent, never as direct experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults in their own homes; small personal caseload with senior community nurse support | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Across England, community staff nurse Band 5 median basic pay £34,300, interquartile range £32,400–£36,600 (n=1,240); 61% of respondents paid mileage. The advert's lower end sits below that interquartile range; the midpoint sits near the median. This is a pattern, not this employer's offer (RR4) | `[generic]` Wardround 2026 pay guide |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team; per a 2025 forum profile she has spoken on leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker profile; Rhiannon is named as contact, not confirmed as hiring manager |
| Unknowns | Caseload size; on-call and out-of-hours; end-of-life visit scope; whether the posting is still open | — |
| Contradictions | None between advert and employer's About page; the posting itself could not be confirmed on the careers page | `[grounded]` research |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated by you as active; not checked against the register | `[grounded]` your CV | Check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as category B, full; not checked | `[grounded]` your CV | Check your licence record |
| R3 | At least one year post-registration | must_have | direct | high | none | Five years as staff nurse | `[grounded]` your CV | none |
| R4 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care is direct; no leg-ulcer work is stated. Limit: leg ulcers not exercised | `[inferred]` bridge from wound work you described | G1 |
| R5 | Catheter care | must_have | direct | high | none | Catheter care stated | `[grounded]` your CV | none |
| R6 | Continence care | must_have | unclear | low | discovery | Your CV covers catheter care but not continence | `[grounded]` CV silence | G2 |
| R7 | Insulin administration | must_have | direct | high | none | Insulin administration stated | `[grounded]` your CV | none |
| R8 | Care planning | must_have | adjacent | medium | transferability | Discharge-to-assess visits involve planning for patients at home; not named as care planning | `[inferred]` from discharge-to-assess role | E2 |
| R9 | End-of-life visits | important | unclear | low | discovery | Not stated in your CV | `[grounded]` CV silence | Question held to next turn |
| R10 | Own caseload with senior support | important | adjacent | medium | transferability | Autonomous home visiting carries over; you have never held a caseload. Limit: no caseload management | `[grounded]` your statement | G5 |
| R11 | Clear, timely written records (electronic record) | must_have | unclear | low | discovery | Not stated; the electronic record is not named in your CV | `[grounded]` CV silence | G3 |
| R12 | Doppler assessment (desirable) | preferred | absent | high | capability | You have never done one | `[grounded]` your statement | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4, must_have) | transferability | Pressure-ulcer and surgical-wound work; no leg-ulcer work | Leg ulcers lead the advert's list; a bridge narrows the likeliest objection | Any leg-ulcer dressing or assessment, even supervised; a wound-care reflection | `[inferred]` bridge; `[generic]` that leg ulcers are a likely probe |
| G2 | Continence care (R6, must_have) | discovery | Catheter care only | Named alongside catheter care in the must-have list | Continence assessment, pad or bowel programme, a patient you supported | `[grounded]` CV silence |
| G3 | Written records (R11, must_have) | discovery | Silent on records and the electronic system | The advert asks for clear, timely records explicitly | A sanitised record entry, or a description of your documentation routine | `[grounded]` CV silence |
| G5 | Own caseload (R10, important) | transferability | Autonomous home visits; no caseload | The role is built on a caseload | Any patient list you managed, or a discharge-visit schedule | `[inferred]` |
| G6 | Doppler (R12, preferred) | capability | None | Preferred only; a closure route exists | A training plan; Rhiannon's forum talk suggests the team runs Doppler training for staff new to community work | `[grounded]` forum profile; `[generic]` on training routes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The posting may have closed, or the careers page may list it under another title | `[grounded]` research: careers address did not resolve | Is this Community Staff Nurse post still open, and when does it close? | unresolved |
| RR2 | On-call and out-of-hours not stated | unknown | — | (not stated in advert) | Community roles often include on-call; the advert is silent | `[generic]` pattern for district nursing | Is there an on-call or out-of-hours rota for this post, and how is it shared? | unresolved |
| RR3 | Role defined; pay, contact, support stated | positive_signal | — | "supported by a senior community nurse" | The role has clear structure and a named route in | `[grounded]` advert | How many caseload patients would I expect at the start? | noted |
| RR4 | Lower end of pay range below survey range | risk_signal | low | "£31,050–£37,800 a year plus mileage" | The entry point may be the bottom of the band | `[generic]` survey; `[grounded]` advert | Where in the band would a nurse with five years' post-registration experience start? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reword wound experience so pressure-ulcer and surgical-wound work is listed as wound assessment and care, with no leg-ulcer claim: "Assessed and dressed pressure ulcers and surgical wounds on an acute medical ward" | Keeps R4 honest; no new fact added | `[grounded]` your CV | pending your approval |
| E2 | If accurate, add your discharge-to-assess home visits as care planning for patients in their own homes — please confirm the wording matches what you did | R8 | `[inferred]` | pending your approval |
| A1 | Confirm the posting on Calderbrook's own careers page before applying | RR1 | `[grounded]` research | pending your approval |
| A2 | Check your NMC register entry and driving licence record yourself | R1, R2 are stated, not checked | `[grounded]` advert gates | pending your approval |
| A3 | Ask Rhiannon whether the team's Doppler training is open to staff new to community work | R12 | `[grounded]` forum profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched calderbrookhealth.example/about. The careers page at calderbrookhealth.example/careers did not resolve, so the posting is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 Halifax district nursing salary", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration (RR4) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned her speaker profile (communitynursingforum.example/speakers/rhiannon-mabbott). Public professional footprint only; feeds the Doppler question (A3) |

## Upgrade menu

- Confirming the posting on the careers page → RR1 closes.
- An example of leg-ulcer work, even supervised → R4 moves toward direct.
- A continence example → R6 moves from unclear.
- A sanitised record entry or a documentation routine → R11 moves from unclear.
- Any caseload or patient list you have managed, even informally → R10 moves from adjacent.
- The Doppler training route, if the team offers one → R12 moves from absent to closure path.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches, covering leadership changes, team size and staff reports) — say the word and it runs.

If you want it, I can save this as a `tuesday-dossier.md` so the analysis carries into later sessions.

**Questions**

R4 — Have you dressed, assessed or supervised leg-ulcer care in hospital or at home, even briefly? If so, what did you do, and under whose supervision?

R6 — Have you managed continence care for patients (assessment, pads, bowel or bladder programmes)? What was your part?

R11 — How did you record care on the ward or on discharge visits, and how quickly were notes usually written up?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.