**Yes, asking for bank, PPS and passport details after a written offer is routine onboarding in Ireland, not a red flag.** The requests are routine because they come after a written offer that names the role and the pay, and they arrive through the employer's own onboarding portal. Your old rule was about giving these details to someone before any offer, or through an unsolicited message. Overall: `conditional_go`.

Research note: web search was not granted in this session (both searches were refused), so I could not check that Marrowgate Housing exists or look up market pay. Everything below is from what you've shared.

## Decision snapshot

- **Status:** `conditional_go`. Apply and accept only if the two conditions below hold.
- **Fit ledger:**
  - `hard_gate`: R3 (`direct`, the €40k offer is inside the posted band); R1 and R2 (`unclear`, neither your right-to-work status nor your location for the two office days is in what you've shared).
  - `must_have`: R4 (`direct`); R6 (`direct`); R5 (`adjacent`, Irish PAYE/PRSI/USC implied by payroll work, not named).
  - `important`: R7, R9, R10 (`direct`); R8 (`adjacent`, monthly payroll for 240 staff against your fortnightly payroll for 90); R12 (`unclear`); R11 (`absent`, pension changes).
- **Hard gates:** none failed. `unconfirmed: R1 (right to work in Ireland), R2 (hybrid, two days a week in Limerick)`. `met: R3 `direct``. Your own non-negotiables were not given, so checks against them are unknown.
- **Severe red flags:** none found. The onboarding requests are routine and get no register entry.
- **Opportunity ledger:** positive: a written offer with role, pay, reporting line and a named People Team, after two in-person interviews (R-register P1). Open: the standing "employer not established" entry (RR1, `severity: medium`), which research could not clear.
- **What would change this:** the conditions are (1) the offer and portal link come from the People Team contact and domain you dealt with at interview, and (2) you learn the pension-change scope and training before or early in the role.

## Role reality

- **Role:** Payroll Administrator, permanent, €40,000 offered, reporting to Declan Garvagh (Finance Manager), hybrid with two days a week in Limerick. The posting describes monthly payroll for 240 staff, starters and leavers, pension changes, monthly payroll-to-ledger reconciliation, and staff payroll queries. `[grounded]` from your materials.
- **Scope read:** the duties are full-cycle, and pension changes are a real part of the job. `[inferred]` from the posting's list.
- **Market calibration:** not run; no search was available. `[generic]` only.
- **Unknowns:** start date, probation, whether pension work comes with training, and what the portal asks for beyond the three items.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement |
|---|---|---|---|---|---|
| R1 | hard_gate | unclear | low | gate | Right to work in Ireland (not stated in your materials) |
| R2 | hard_gate | unclear | low | gate | Hybrid, two days a week in Limerick (your location not given) |
| R3 | hard_gate | direct | high | — | Pay band €38k–€42k; offer €40k `[grounded]` |
| R4 | must_have | direct | medium | — | 2+ years running payroll (3 years, 90 staff, hotel group) |
| R5 | must_have | adjacent | medium | none | Working knowledge of Irish PAYE, PRSI, USC (implied, not named) |
| R6 | must_have | direct | medium | — | Strong Excel (pivot tables, XLOOKUP, daily use; not tested) |
| R7 | important | direct | medium | — | Payroll qualification (Payroll Technician certificate, 2024) |
| R8 | important | adjacent | medium | scale and cadence | Monthly payroll for 240 staff (you ran fortnightly for 90) |
| R9 | important | direct | medium | — | Starters and leavers |
| R10 | important | direct | medium | — | Monthly payroll-to-ledger reconciliation |
| R11 | important | absent | — | capability | Pension changes (your manager handled these) |
| R12 | important | unclear | low | — | Answering staff payroll queries (not stated) |

Confidence is `medium` where the claim rests on your CV alone, as the convention requires; `high` is for R3, which is checked against the posting's own figures.

## Gap recovery queue

- **R11 (pension changes, `absent`):** the gap is that you have not run these yourself. It closes with a clear answer on scope and training, or with experience you can name. Address it honestly in interview; do not claim it.
- **R8 (scale and cadence, `adjacent`):** a move from fortnightly to monthly and from 90 to 240 staff is a stretch in volume, not in method. It closes with any example of high-volume or monthly processing.
- **R5 (Irish rules, `adjacent`):** if your hotel group ran PAYE/PRSI/USC payroll, naming that would move this to `direct`.
- **R1 and R2 (gates):** you know these; they're not in your materials.

## Opportunity risk register

**RR1 (standing): Employer not established from attributable sources**
- `class: risk_signal`, `severity: medium`, `status: unresolved`
- `source_quote`: "Marrowgate Housing, a housing association in Limerick"
- `hypothesis`: web search could not attribute the employer. The footprint may be thin, the posting may be stale, or the entity may not match the description. `[generic]` pattern, not a claim about this employer. Your two in-person interviews at their office are your own evidence against the worst reading. `[inferred]`.
- `verification_question`: "Can you confirm this role is on your careers site, and that the People Team contact who sent the offer is the same one I interviewed with?"
- `decision_rule`: verify before accepting. This caps the status at `conditional_go`.

**Routine steps (no register entry):** bank details, PPS number and a passport scan after a written offer with the role and pay stated. These are not entries and not conditions. The advice is:
- Enter details only in the portal, reached from the employer's own website, not a link you were sent separately.
- Do not send bank details, PPS or passport by email.
- Ask what the passport scan is used for, who sees it, and how long it is kept.
- Bring the original passport on day one, as they asked.
- Ask for your written statement of terms.

## Application plan

- **Lead with:** three years of fortnightly payroll for 90 staff, starters and leavers, and the monthly payroll-to-ledger reconciliation (R4, R9, R10).
- **Be specific about the gaps:** say you have not run pension changes, and that you can learn the process from their pension provider's documented procedure. Do not say you have pension experience.
- **Pay:** €40k is in the band. Whether to negotiate depends on your own floor, which you haven't given.
- **Proposed language, pending your approval:** none. I'm not drafting CV wording until you confirm it, per the approval rule.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Web search permission not granted; 2 searches refused |
| 2 | Role-family sweep (scope, title, pay) | unavailable | Same |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | Same |

L2 was not offered, since L1 has not run.

## Dossier offer

If you want, I can write these findings to a `tuesday-dossier.md` file you can carry into the next stage.

## Upgrade menu

- Enabling web search would let me check the employer and the market pay band (RR1, and the calibration line).
- Your non-negotiables (minimum pay, office days, start date) would close the hard-gate checks.
- A description of the pension work, or a training plan from them, would move R11.
- Irish payroll detail from your hotel group would move R5 to `direct`.

## Questions

1. Did the offer come from the same People Team address you dealt with during the interviews, and does the portal link lead to a page on the domain their own website gives?
2. What are your own non-negotiables: minimum pay, how many office days you can manage, start and notice constraints, and right-to-work status?
3. Did your hotel group's payroll run under Irish PAYE, PRSI and USC rules, and did you touch any pension deductions even as a reviewer?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.