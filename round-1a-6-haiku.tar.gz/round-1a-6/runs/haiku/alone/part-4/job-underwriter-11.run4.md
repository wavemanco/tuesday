**Decision snapshot**

- **Job 1, Operations Analyst, Duinvaart (Rotterdam): `conditional_go`.** Your stated experience matches most of the core duties. Two things are unresolved: whether you can work the three in-office days in Rotterdam, and whether you have the right to work in the Netherlands. The posting also withholds pay.
- **Job 2, Supply Planner, Kroonhaven (Utrecht): `no_go`.** Three must-have requirements are absent from your background: 3+ years of planning, SAP IBP or a similar system, and fluent Dutch. Advanced Excel is unknown.
- **Hard gates:** Job 1 has one open gate, Rotterdam hybrid attendance (your location is not stated). Job 2's on-site Utrecht requirement is also unknown.

**Research tier: L1, searches 3 of 5, fetches 0 of 2.** The three searches were refused: web search permission was not granted, so no company facts are verified and all company claims below rest on the posting alone.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page (both employers) | unavailable | Web search not permitted; neither employer's existence or live posting is confirmed |
| 2 | Role-family sweep (pay and scope norms) | unavailable | Same refusal; no market data |
| 3 | Hiring manager's public footprint | n/a | No name was given |

## Job 1: Operations Analyst, Duinvaart

**Role reality.** Tracking on-time delivery and temperature compliance across a refrigerated fleet, weekly Power BI dashboards, and route-change work with depot managers. The posting is largely the job you already do, with a cold-chain layer added. No pay is stated. The posting itself is the only source for these facts.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap type | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | 2+ yrs logistics or ops analysis | strong | medium | none | 4 yrs as ops analyst, parcel carrier (stated) |
| 2 | must | Strong SQL | strong | medium | none | Daily SQL use (stated) |
| 3 | must | Power BI or Tableau | strong | medium | none | Daily Power BI (stated) |
| 4 | must | Track on-time delivery | strong | medium | none | Owned the depot on-time dashboard (stated) |
| 5 | must | Weekly dashboards | strong | medium | presentation | Weekly route-performance review (stated) |
| 6 | must | Work with depot managers on route changes | strong | medium | none | Ran route-performance review used by depot managers (stated) |
| 7 | must | Temperature compliance, refrigerated fleet | gap | — | capability | No temperature or cold-chain work stated |
| 8 | preferred | Dutch | partial | medium | capability | Conversational, not fluent (stated) |
| 9 | hard_gate | Rotterdam office, 3 days/week | unknown | — | hard-gate | Your location and commute are not stated |

All "medium" confidence comes from your CV account alone. A reference or a work sample would raise it.

**Gap recovery queue**
- Row 7 (cold chain): the gap is real and partly transferable. Route and on-time work carries over, but temperature data does not. Closing it needs evidence of any temperature, excursion or compliance exposure, however small.
- Row 8 (Dutch): depot managers are likely to use Dutch day to day. "Plus" means this is not a gate, but it is a practical cost.
- Row 9 (location): a hard gate with no evidence either way. Amsterdam to Rotterdam is a commute, not a relocation, but it is your call.

**Opportunity risk register**
- *Pay withheld* (medium, unverified): the posting gives no salary, so fit against your floor cannot be checked.
- *Employer not verified* (medium, standing): existence and posting status could not be checked, which caps this at `conditional_go`.
- *Cold-chain depth* (low–medium): the posting's wording ("temperature compliance") may mean a specialist expectation. The posting does not clarify this.

**Positive signals:** the core duties map closely to work you have done, and the posting describes a role your experience already covers.

**Application plan**
1. Lead the CV with the depot on-time dashboard and the route-performance review. Those are your strongest stated matches.
2. Describe temperature work as new, not as experience. Use a line like: "New to cold-chain; the on-time and route-performance work transfers directly." Do not claim cold-chain experience you do not have.
3. On Dutch, say what is true: conversational, and improving if that is accurate. Do not write "fluent" or "working proficiency" unless it is.
4. Before applying, ask for the pay range. If the posting does not give one, ask the recruiter.

## Job 2: Supply Planner, Kroonhaven

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap type | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | 3+ yrs FMCG supply or demand planning | gap | — | capability | Never worked in planning (stated) |
| 2 | must | Own a 13-week supply plan; balance capacity vs forecast | gap | — | capability | No planning ownership. Nearest: route-capacity analysis [inferred] |
| 3 | must | Advanced Excel | unknown | — | discovery | Not stated |
| 4 | must | SAP IBP or similar | gap | — | capability | None stated |
| 5 | must | Fluent Dutch | gap | — | capability | Conversational (stated) |
| 6 | implied | Run weekly S&OP meeting | partial | low | transferability | Ran a weekly review with cross-functional users [inferred] |
| 7 | hard_gate | On-site Utrecht | unknown | — | hard-gate | Location not stated |

**Verdict: `no_go` on current evidence.** Rows 1, 2 and 4 are must-haves with no evidence, and row 5 is a must-have you cannot yet meet. What would have to differ: documented planning or demand-forecasting experience in FMCG, plus planning-system exposure. Advanced Excel alone would not change the verdict.

**Why I'd spend little time here:** the role is a planning job with three missing must-haves, and the time is better spent on roles that match your evidence. If you want to test the planning direction, look for demand or S&OP analyst roles that do not require IBP.

## Evidence limits
- Everything you stated is CV-only, so it is a lead and not verified evidence.
- No employer or market facts are verified. The pay and scope "market calibration" is not run.

**Upgrade menu** (each input and what it unlocks)
- *Web search permission:* verifies that both employers exist and their postings are live (closes the standing risk), and runs the pay-band check.
- *Pay floor:* checks Job 1's withheld pay against your minimum.
- *Any temperature or cold-chain data exposure:* raises Job 1 row 7 from gap to partial.
- *Advanced Excel evidence (e.g., Power Query, models):* closes Job 2 row 3.
- *An anonymized dashboard sample:* raises the Power BI rows from medium to high confidence.

I can also save this assessment as `tuesday-dossier.md` so it carries across your applications.

**Questions**
1. Can you work from Rotterdam three days a week, and do you have the right to work in the Netherlands?
2. Did any of your parcel work involve temperature or cold-chain data, or forecasting or capacity planning, even informally?
3. What is your pay floor? Duinvaart does not state pay.

Reply to each with an answer, or "skip" or "not sure". A skip is a valid answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.