**Decision: conditional_go.** Apply, after checking three things below. Nothing I found suggests the company is not real, and the WhatsApp message is not a warning sign by itself.

**Legitimacy**
- Research tier: L1, searches 2 of 5, fetches 1 of 2; user links read 0.
- Target 1, company site: yes. The About page at fernquay.example says Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools, has six people based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers. That matches the posting. I did not find the posting on a careers page, so it is not yet confirmed as live.
- Target 2, role-family sweep: skipped. I have no sourced market figures, so the salary and equity read below is generic.
- Target 3, hiring-manager footprint: yes. A search result for Ronan Kehoe lists him as co-founder and CEO, previously product lead for five years at a Galway travel-software company. The posting calls him co-founder, so the titles differ slightly. The search result is a single snippet, not a full profile.
- Failed attribution: not triggered. The employer can be identified as described.
- A co-founder reaching out on WhatsApp after an application is a common channel for small Irish startups. A calendar invite with a video link is normal. Real warning signs would be a request for money, equipment, or bank or ID details before a written offer, or hiring entirely through chat. None of these appear here.

**Fit** (`[inferred]` from your stated background against the posting)

| Requirement | Fit | Evidence |
|---|---|---|
| 3+ years product design | Strong | 4 years, Dublin travel-booking company |
| Strong Figma | Strong | Daily use |
| Own user research | Strong | Ran monthly customer usability sessions |
| Works directly with engineers | Strong | Four-engineer squad |
| Booking flow end to end | Partial | You redesigned checkout, which is adjacent; you did not own the whole flow |
| Only designer | Gap | Never worked as the sole designer; this is a capability gap, not a credential gap |
| Research with school owners | Partial | Your research was with consumers; this is a small B2B audience |

**Risks to weigh**
- Solo-designer role: you would set direction and process with no design peer. That is a real change from your last four years.
- Stated pay is €52,000–€60,000 plus 0.5–1% equity. Whether that is market-normal is `[generic]` until I have a sourced comparison. Equity at this stage is usually illiquid, so treat it as a bonus, not as pay.
- Hybrid at two days a week in Galway fits your location.

**Plan**
1. Before any call, confirm the role is listed on the company's own site or a job board you can find yourself, and check that the invite comes from the company's email domain.
2. On the 45-minute call, ask about runway, what the team has decided about design so far, and what "first designer" means for scope and decisions.
3. Bring the checkout case study and one usability-research example. Lead with research and engineer collaboration, and be direct that you have not been the only designer before.
4. Don't share bank, tax or ID details, and don't pay for anything, until a written offer arrives.

**What would change this**
- The role is not on the company's site or any job board: hold.
- Anyone asks for money, equipment, or bank or ID details before an offer: stop and treat that as a red flag.
- Runway is short, or the team has no clear plan for a designer: lower the decision to hold.

**Next**
I can write a dossier file (`tuesday-dossier.md`) with this assessment if you want one.

Upgrade menu:
- A link to the live posting, or the company's careers page: confirms the role is current.
- The invite's sender address or the recruiter's email domain: confirms the contact is from the company.
- Your pay floor and whether equity matters to you: lets me say whether the offer fits.
- A sourced salary sweep for this role: replaces the `[generic]` pay read with something checkable.

Questions:
1. Where did you find the posting, and is it on fernquay's own careers page?
2. What is your minimum acceptable pay, and how much do you weigh equity?
3. Do you know how long the company's funding runway is?

Reply with answers, or "skip" on any.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.