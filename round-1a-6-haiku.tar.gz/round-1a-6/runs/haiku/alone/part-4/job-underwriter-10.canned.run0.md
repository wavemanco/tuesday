**Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0**

## Decision snapshot

**Decision: `conditional_go`.** The company and posting check out on public sources. Your fit is strong on most requirements, with one real gap (never being the only designer). Three things need confirming before you commit.

- **Fit:** Strong on 3+ years, Figma, and working with engineers. Partial on running research and owning a booking flow end to end. Gap on being the first or only designer.
- **Hard gates:** Location and hybrid pattern match your move back to Galway. Salary floor is unknown to me, so the €52,000–€60,000 range is unchecked against it.
- **Opportunity:** The posting matches the company's own careers page. The company exists as described. No red flags met the threshold.

## Role reality

- **Organization [grounded]:** Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, based in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers (fernquay.example/about).
- **Posting [grounded]:** The careers page lists the same role, pay, hybrid pattern and application route as your JD. It asks applicants to send one real project to jobs@fernquay.example.
- **Hiring manager [grounded]:** Ronan's public LinkedIn lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years.
- **Contradiction to confirm:** The WhatsApp message calls Saoirse "our CTO", while the About page names her as a co-founder. Both can be true, but it's worth confirming her title when you speak.
- **Scope [inferred]:** "First designer" with two engineers means you'd set up design practice, not join one. Expect little or no design mentorship.
- **Market calibration:** Not run. The role-family sweep was not done, so I have no market figure for this seniority and pay band.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | strong | high | none | 3+ years product design | 4 years at a Dublin travel-booking company (CV) |
| 2 | must-have | strong | medium | none | Strong Figma | Daily use stated; portfolio would confirm |
| 3 | must-have | partial | medium | transferability | Has run own user research | Monthly customer usability sessions, but with consumers, not B2B school owners |
| 4 | must-have | strong | high | none | Works directly with engineers | Four-engineer squad (CV) |
| 5 | implied | partial | medium | transferability | Owns booking flow end to end | Redesigned checkout; ownership beyond checkout unstated |
| 6 | implied | gap | low | capability | First or only designer | Never been the only designer (your own note) |
| 7 | context | partial | low | transferability | Sea-kayak / surf domain | No vertical experience; general booking-flow work |
| 8 | hard_gate | strong | high | none | Galway hybrid, 2 days/week | Moved back to Galway last year |
| 9 | hard_gate | unknown | unknown | unknown | Salary €52k–€60k vs your floor | Floor not provided |

## Opportunity risk register

- **Early-stage pay and equity [inferred]:** Six people, funded by customers, with equity of 0.5–1%. Check the vesting schedule, cliff, and whether the equity is options or shares before weighing it. **Severity: medium.**
- **Scale and runway [inferred]:** Founded 2023; I did not check funding or runway (L2 not run). **Severity: medium.**
- **Interview-invite check [advice, not a finding]:** Confirm the emailed invite comes from a fernquay.example address before joining the video call. Scheduling by WhatsApp is routine, so this is only a check.

## Application plan

- **Lead with:** the checkout redesign, plus the monthly customer research as your research evidence.
- **Name the gap yourself:** you haven't been the only designer. Present it as a question you've thought about, with examples of working without a design lead.
- **Prepare for the call:** ask Saoirse how design decisions get made and what the engineering process looks like.
- **Proposed CV wording** is held for your approval and not finalized.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Fernquay Galway booking software sea kayak surf schools", "Fernquay product designer job Galway careers". Pages: fernquay.example/about (fetched); fernquay.example/careers/product-designer (search snippet only, not fetched) |
| 2 | Role-family sweep (scope, title, pay) | skipped | Not run; no market figure is given |
| 3 | Hiring manager's public footprint | yes | Query: "Ronan Kehoe Fernquay co-founder". Page: linkedin.example/in/ronan-kehoe (search snippet) |

## Questions

1. Is €52,000 your floor, or do you need more? This decides the pay row.
2. Did the interview invite come from a fernquay.example address? Check the sender before you join.
3. Have you ever set up design work or run research without a design lead above you? Even a small example helps the gap row.

Response mode: answer each question, or say "skip" and I'll mark it unknown.

**Dossier offer:** I can write up this assessment as a `tuesday-dossier.md` file for later use, if you'd like.

**Upgrade menu:**
- Your checkout case study or portfolio (would firm up Figma and research rows).
- Salary floor and equity terms in writing (would settle the hard-gate and risk rows).
- Funding and news check on Fernquay: up to 5 more searches and 2 more fetches. Offered once; say yes if you want it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.