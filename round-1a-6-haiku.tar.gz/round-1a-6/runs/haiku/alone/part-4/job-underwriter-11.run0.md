**Decision snapshot**

**Job 1, Operations Analyst, Duinvaart: yes, it's worth applying to, on conditions. Status: `conditional_go`.**

- **Fit ledger.**
  - `hard_gate`: unclear: J1-R9 (hybrid, three days a week in the Rotterdam office)
  - `must_have`: direct: J1-R1 (2+ years in operations analysis), J1-R2 (strong SQL), J1-R3 (Power BI or Tableau)
  - `important`: direct: J1-R4 (weekly Power BI dashboards), J1-R6 (on-time delivery tracking); adjacent: J1-R5 (depot managers on route changes); unclear: J1-R7 (temperature compliance)
  - `preferred`: adjacent: J1-R8 (Dutch, conversational)

  J1-R5: you ran the route review, but nothing says you changed routes. J1-R7: no temperature evidence. J1-R8: conversational, below fluent.
- **Hard gates:** none failed; unconfirmed: J1-R9 (hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** The posting is clear about outcomes (J1-RR2, positive). Salary and team are missing (J1-RR3, J1-RR4). The employer could not be verified (J1-RR1), which caps the status at `conditional_go`.
- **Severe red flags:** none found.
- **What would change this.** Conditions for go: (1) your location makes the three-day Rotterdam office workable; (2) the posting is confirmed live on Duinvaart's own careers page; (3) you describe the temperature-compliance gap as a gap, not as experience. If the office days are unworkable, this becomes `no_go`.

**Job 2, Supply Planner, Kroonhaven: not worth your application time now. Status: `no_go`.**

- **Fit ledger.**
  - `hard_gate`: unclear: J2-R7 (on-site in Utrecht)
  - `must_have`: absent: J2-R1 (3+ years FMCG planning), J2-R3 (balancing capacity against forecast), J2-R5 (SAP IBP or similar); unclear: J2-R4 (advanced Excel); adjacent: J2-R2 (running a weekly review), J2-R6 (Dutch, conversational against fluent)
- **Hard gates:** none failed; unconfirmed: J2-R7 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** The scope is clear (J2-RR3, positive). Salary is missing (J2-RR2). The employer is unverified (J2-RR1).
- **Severe red flags:** none found.
- **Why `no_go`.** Three must-haves are absent with no evidence, and you have never worked in planning. A realistic closure in the short term doesn't exist.
- **What would have to differ.** Real FMCG planning or forecasting experience, or a planning-adjacent role you can point to.

---

**Research tier: L1 — searches 4 of 5, fetches 0 of 2**

Every search call was refused by the host's permission check. I did not try to work around that. The results below rely only on your input and the posting text.

**Role reality**

*Job 1*

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | One analyst with a dashboard and depot-facing remit | `[inferred]` from the listed duties |
| Market calibration | Not established: the salary search was refused. No band is given, and none is drawn from memory | — |
| Unknowns | Salary, team size, reporting line, fleet size, whether temperature data already exists | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

*Job 2*

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` JD |
| Mandate | Own the 13-week supply plan for one chilled range; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Working pattern | On-site, Utrecht | `[grounded]` JD |
| Scope read | One range, but a full planning remit | `[inferred]` from the listed duties |
| Market calibration | Not established: the salary search was refused | — |
| Unknowns | Salary, team, the planning system in use, forecast ownership | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

**Evidence map**

*Job 1*

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| J1-R1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background | None |
| J1-R2 | Strong SQL | must_have | direct | medium | none | Daily use, as you describe it | `[grounded]` your background | A sanitized query would raise to high |
| J1-R3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | A dashboard screenshot would raise to high |
| J1-R4 | Weekly dashboards in Power BI | important | direct | medium | none | The on-time dashboard that depot managers use | `[grounded]` your background | Same artifact as J1-R3 |
| J1-R5 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review. Limit: nothing says you changed routes | `[grounded]` your background; `[inferred]` the transfer | See J1-G2 |
| J1-R6 | Track on-time delivery | important | direct | medium | none | Your current core work | `[grounded]` your background | None |
| J1-R7 | Track temperature compliance across a refrigerated fleet | important | unclear | none | discovery | No temperature or cold-chain evidence given | — | See J1-G1 |
| J1-R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational. Below fluent | `[grounded]` your background | State it accurately |
| J1-R9 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | Your location and commute are not in the inputs | — | Question 1 |

*Job 2*

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| J2-R1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning | `[grounded]` your statement | See J2-G1 |
| J2-R2 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly review. Limit: its content was route performance, not supply | `[grounded]` your background | None |
| J2-R3 | Balance production capacity against forecast | must_have | absent | none | capability | No capacity or forecast work described | `[grounded]` your background | None |
| J2-R4 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned in your background | — | Question 3 |
| J2-R5 | SAP IBP or similar planning system | must_have | absent | none | capability | None described | `[grounded]` your background | None |
| J2-R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, below the stated bar | `[grounded]` your background | None |
| J2-R7 | On-site, Utrecht | hard_gate | unclear | none | hard_gate | Your location is not in the inputs | — | Question 1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| J1-G1 | Temperature compliance (J1-R7) | discovery | No temperature, excursion or cold-storage work in your background | An important duty with no evidence. It could be the one that separates you from other applicants | Any temperature, excursion or storage metric you have tracked, reported or acted on, even in a side project | A sample report, a metric definition, or a note on what you would monitor | `[inferred]` that this is the likeliest objection |
| J1-G2 | Route changes (J1-R5) | transferability | You ran the review; you don't say you changed routes | Limits how far the depot-manager story can go | Route decisions you influenced or recommended, even informally | A review deck or a note on a route decision | `[grounded]` your background |
| J2-G1 | FMCG planning (J2-R1) | capability | None | A must-have with no evidence | None realistic in the short term | Not applicable | `[grounded]` your statement |

**Opportunity risk register**

*Job 1*

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| J1-RR1 | Employer not verified | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Search was refused, so this is not a finding that the employer is missing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| J1-RR2 | Outcomes measurable | positive_signal | — | "Track on-time delivery and temperature compliance" | The role has defined metrics | `[grounded]` JD | Which of these two metrics has the most data today? | noted |
| J1-RR3 | Salary withheld | unknown | — | Not stated | The figure may be low, or simply unpublished | `[inferred]` from the missing figure | What is the salary for this role? | unresolved |
| J1-RR4 | Team and reporting line unstated | unknown | — | Not stated | The role may be solo or part of a team | `[inferred]` from silence | Who would I report to, and who else works on dashboards? | unresolved |

*Job 2*

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| J2-RR1 | Employer not verified | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as J1-RR1 | `[generic]` pattern for companies of this size | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| J2-RR2 | Salary withheld | unknown | — | Not stated | Same as J1-RR3 | `[inferred]` from the missing figure | What is the salary for this role? | unresolved |
| J2-RR3 | Scope clearly defined | positive_signal | — | "Own the 13-week supply plan" | The role has a clear boundary | `[grounded]` JD | — | noted |

**Application plan**

*Job 1*

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| J1-A1 | Confirm your location and whether three office days a week in Rotterdam works | J1-R9 is a hard gate and could flip the decision | `[grounded]` J1-R9 | Before applying |
| J1-A2 | Find the posting on Duinvaart's own careers page, and use only contact details from there | J1-RR1 | `[generic]` verification practice | Before applying |
| J1-E1 | Lead with the on-time dashboard depot managers use and the route-performance review, stated as your work, not as route decisions | J1-R4, J1-R5, J1-R6 | `[grounded]` your background | Pending your approval |
| J1-E2 | State temperature compliance as no experience, and name what you would learn first | J1-R7 | `[grounded]` J1-G1 | Pending your approval |
| J1-W1 | A sanitized dashboard screenshot and a sanitized SQL query | Raises J1-R2, J1-R3, J1-R4 to high | `[grounded]` J1 evidence map | Pending your approval |

*Job 2*

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| J2-A1 | Don't spend application effort on this role now | J2-R1, J2-R3, J2-R5 are absent | `[grounded]` J2 evidence map | Recommendation |
| J2-A2 | If you apply anyway, be ready for a screen on planning years, and don't claim planning work | Honest framing only | `[grounded]` J2-R1 | Pending your approval |

**Evidence status**

Verified: none yet. Everything about your background is your own statement, not yet checked against documents. Unverified leads: none. Rejected inferences: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (Duinvaart, Kroonhaven) | unavailable | Both company searches were refused. Would have moved J1-RR1 and J2-RR1 |
| 2. Role-family sweep (salary and scope) | unavailable | Two searches were refused. Would have set the market calibration for both roles |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**

- Search access granted: targets 1 and 2 run, and the employer and salary entries can move.
- Your current city or postcode: closes J1-R9 and J2-R7.
- A sanitized dashboard or query: raises J1-R2 to J1-R4 to high.
- Any temperature or cold-storage metric you have touched: closes J1-G1.
- Any forecasting or capacity work, even in Excel: could reopen Job 2.
- A salary figure, from the posting or the recruiter: closes J1-RR3 and J2-RR2.

Dossier offer: I can save this assessment as `tuesday-dossier.md` if you want a copy for later.

1. Where are you based now, and could you work three days a week in the Rotterdam office? (J1-R9)
2. Have you ever tracked, reported or acted on temperature data or cold-storage compliance, even in a side project or earlier role? (J1-G1)
3. Have you done any forecasting or capacity planning, even informally or in Excel? (J2-R4)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.