**Decision snapshot: `conditional_go`.** Your fit looks strong on the stated requirements. Whether the company is real and what the equity is worth are still unverified. Take the call, but don't send documents, money or bank details until the checks below are done.

- **Fit:** Strong on the stated requirements. Gap is in the implied requirements, not the listed ones.
- **Opportunity:** Unverified. The company's existence could not be checked (see the risk register).
- **Hard gates:** Location and hybrid schedule meet (you live in Galway). Salary floor and equity value are unknown to me. Neither is a failure yet.

Research tier: L1, searches 3 of 5, fetches 0 of 2. All three searches were refused permission, so nothing external was checked.

**Role reality** [grounded] unless marked
- Six-person Galway startup making booking software for sea-kayak and surf schools. First designer hire. Reports most closely to co-founder Ronan. Works alongside two engineers. CTO is Saoirse.
- Scope: own the booking flow end to end, run research calls with school owners, ship with engineers.
- Pay: €52,000–€60,000 base, plus 0.5–1% equity. No vesting, strike price, or valuation stated.
- Market calibration: not available. I could not run the role-family search. Any sense of whether €52–60k is normal for this seniority in Galway would be `[generic]` from memory, so I have left it out.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ years product design | Meets | Medium | None | 4 years at a Dublin travel-booking company (CV) |
| 2 | Must-have | Strong Figma | Meets | Medium | None | Daily use (CV) |
| 3 | Must-have | Has run own user research | Meets, transferable | Medium | Discovery | Monthly customer usability sessions. Not school-owner interviews, but the same method |
| 4 | Must-have | Works directly with engineers | Meets | Medium | None | Squad of four engineers (CV) |
| 5 | Implied | Owns a booking flow end to end | Partial | Medium | Capability | Redesigned checkout, which is a part of booking. Not the whole flow |
| 6 | Implied | Works as the only designer | Not evidenced | Low | Capability | Never been the only designer anywhere (your statement) |
| 7 | Hard gate | Galway office, 2 days a week | Meets | High | None | You moved back to Galway last year |
| 8 | Hard gate | Salary floor | Unknown | n/a | Unknown | Your floor is not in what you gave me |

**Gap recovery queue**
- **Row 5, end-to-end ownership.** Closes with a concrete example of owning a flow beyond checkout, such as onboarding or rebooking, with your own decisions and outcomes.
- **Row 6, sole designer.** Closes with a description of how you would set your own process without a design team: critique, decision records, and who reviews your work. Be plain that this is new to you.
- **Row 8, salary floor.** Closes when you state your floor. Compare it to the posted band.

**Opportunity risk register**
1. **Company existence unverified. Severity: medium (standing).** Possible reasons, none ranked as likely: the company is too new or small to be well known; the posting is stale; or it is not a hiring employer. This caps the decision at `conditional_go` until verified. Resolve it by checking the live posting link, the company's own website and careers page, and the email domain on Ronan's invite. The domain should match the company's website.
2. **Equity terms undisclosed. Severity: medium.** [grounded] 0.5–1% with no vesting, strike, share count, or valuation. Its value cannot be judged.
3. **Sole designer in a six-person company. Severity: medium.** [inferred] Little design peer review and a broad scope. This matches the gap in row 6.

Not a risk entry: the WhatsApp contact. Scheduling by chat is routine for small teams, and the actual invite came by email. The only check is the email domain in item 1.

No red flags. Nothing asks you to pay, deposit, or give bank or ID details.

**Application plan**
- For the 45-minute call, lead with the checkout redesign and the monthly usability sessions. These are your strongest verified-by-you evidence.
- Say plainly that you have never been the only designer. Do not reframe squad work as ownership.
- If you want help rehearsing the call, `mock-interview` is the sibling skill for that.
- Before you agree to anything, ask about vesting, the strike price, and the share count.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| L1-1 Company site and careers page | unavailable | Search permission not granted |
| L1-2 Role-family salary and scope sweep | unavailable | Search permission not granted |
| L1-3 Hiring manager's public footprint | n/a | No public footprint requested; Ronan's name only |

Quick checks you can run yourself without search: open the company's website and confirm it matches the posting, and check the sender's email domain.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later use.

**Upgrade menu**
- Allow searches (up to 5) and page fetches (up to 2). This would check the company's site, careers page, and funding, which would settle the existence question.
- Allow one role-family search. This would test €52–60k against Irish product designer pay at your seniority.
- Share a link to the live posting, if you have one.

**Questions**
1. Can you share the live posting link, and the email domain on Ronan's invite?
2. Did the equity offer come with vesting, a strike price, or a share count?
3. Who would you report to, and does anyone review design decisions besides Ronan?

Answer any, all, or none. A skip is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.