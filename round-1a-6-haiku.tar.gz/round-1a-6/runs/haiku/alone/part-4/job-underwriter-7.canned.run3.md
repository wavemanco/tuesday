## Decision snapshot

**Decision: `conditional_go`.** You meet all three essential requirements on your own account. The gaps are a desirable skill (Doppler), the one thing you have never done (holding a caseload), and several community-specific duties you haven't described. The employer is unverified, and that caps the decision at conditional.

- **Hard gates:** none failed. Three met as stated: NMC Adult registration (active), full UK driving licence, and more than one year post-registration. All three are your stated claims and unchecked. Confirm them on the NMC register and against your licence.
- **Fit ledger:** strong on wound care, catheter care, insulin and home visiting. Partial on care planning and written records. Absent or unevidenced on caseload ownership, continence, end-of-life, leg-ulcer assessment and Doppler.
- **Opportunity:** no red flags in the posting or the contact route. The employer's existence and the live posting are unverified (standing `medium` risk, see below).

*Research tier: L0, no searches run in this pass. The company check is in the upgrade menu.*

## Role reality

- **Role:** Community Staff Nurse, Band 5, district nursing for housebound adults at home. Own small caseload with senior nurse support. Electronic patient record. Pool car provided. `[grounded]` (JD)
- **Scope read:** a caseload-holding role from day one, with autonomous home visits. Your discharge-to-assess work is the closest match. `[inferred]`
- **Pay:** £31,050–£37,800 plus mileage, stated in the posting `[grounded]`. Your floor isn't known, so the comparison is open. Band 5 norms aren't checked here, so no market calibration line. `[generic]` only if you want one from research.
- **Contradictions:** none inside the advert. The employer is not yet verified against any outside source.

## Evidence map

| # | Priority | Requirement | Evidence (your CV) | Fit | Confidence | Gap type |
|---|---|---|---|---|---|---|
| 1 | must-have | Current NMC Adult registration | Active, revalidation due Mar 2028 | met | high (check register) | none |
| 2 | must-have | Full UK driving licence | Full licence, category B | met | medium (stated, unchecked) | none |
| 3 | must-have | 1+ year post-registration | Five years as staff nurse | met | high | none |
| 4 | must-have | Clear, timely written records | Not described | partial | low | discovery |
| 5 | core duty | Wound care incl. leg ulcers | Pressure ulcers, surgical wounds; leg ulcers not stated | partial | medium | discovery |
| 6 | core duty | Catheter and continence care | Catheter care stated; continence not stated | partial | medium | discovery |
| 7 | core duty | Insulin administration | Stated | met | high | none |
| 8 | core duty | End-of-life visits | Not stated | unknown | low | discovery |
| 9 | core duty | Care planning | Implied by discharge-to-assess; not stated | partial | low | discovery |
| 10 | core duty | Own caseload | Never held one | gap | — | capability |
| 11 | core duty | Home visiting, autonomous | 18 months' home visits post-discharge | met (transferable) | medium | transferability |
| 12 | core duty | Electronic patient record | EPR system not named | unknown | low | discovery |
| 13 | desirable | Doppler assessment | Never done | gap | — | capability |

## Gap recovery queue

- **Row 10, caseload ownership:** the main real gap. Closed by describing how you ran your discharge-to-assess visits (caseload size, prioritising, handover) and by the senior-nurse support the role offers.
- **Row 13, Doppler:** a capability gap, desirable only. Closed by checking whether the employer funds or expects training. Do not claim it.
- **Rows 6, 8, 9, 5:** discovery gaps. You may already have these experiences under other names. Closed by describing them, not by new credentials.
- **Row 4 and row 12:** closed by naming your EPR and describing your record-writing.

## Opportunity risk register

| Class | Severity | Entry |
|---|---|---|
| failed attribution | medium | Employer not yet verified as existing as described. Possible reasons, none ranked: too new or small, stale posting, or not a live hiring employer. Caps `go` at `conditional_go`. Resolve with the live posting link, the company's careers page, or the recruiter's email domain. |
| mismatch | low | Pay range stated; your floor unknown. |

No red flags. The contact route (an informal chat with a named Team Lead) is a normal step and not a concern.

## Application plan

- **Lead with:** home-visit competence from discharge-to-assess, then wound care, catheter care and insulin. Say plainly that you haven't held a caseload, then describe what you did independently.
- **Don't claim:** Doppler, leg-ulcer assessment, continence or end-of-life experience until you confirm them.
- **Before applying:** verify the employer (see the risk register), then use the informal chat to ask about caseload size, Doppler training, and EPR.
- **Proposed CV language** is held as `resume_edits_pending_approval`. Nothing gets written into an application until you approve it.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0; not run in this pass |
| 2. Role-family sweep (scope, title, pay) | skipped | L0; not run in this pass |
| 3. Hiring manager footprint | n/a | No hiring manager named |

## Dossier offer

If you'd like, I can produce a `tuesday-dossier.md` file that keeps this assessment for later sessions.

## Upgrade menu

- **Company verification (L1):** confirms whether Calderbrook exists as described and whether the posting is live. Up to 5 searches and 2 page fetches.
- **Role-family sweep (L1):** checks Band 5 community norms and the pay band.
- **Pasted posting link or careers page:** lets me check the posting's consistency directly.
- **Your EPR system and any leg-ulcer or continence experience:** raises rows 5, 6 and 12.

## Questions

1. Have you done any continence assessment, end-of-life visits or care planning with patient goals? These could close rows 6, 8 and 9. *(Response modes: answer, "skip", or "not sure".)*
2. Which EPR system did you use, and have you done any leg-ulcer assessment such as compression or ABPI, even without Doppler? *(Response modes: answer, "skip", or "not sure".)*
3. Do you have a salary floor, and would mileage affect the offer for you? *(Response modes: answer, "skip", or "not sure".)*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.