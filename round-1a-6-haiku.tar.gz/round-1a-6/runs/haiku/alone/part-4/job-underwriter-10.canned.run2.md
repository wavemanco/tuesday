**Decision snapshot: `conditional_go`.** Apply. The company checks out on its own site, and your background matches most of the requirements. The condition is one check on the interview invite, below.

- **Fit (candidate ledger):** strong on 3+ years of product design, Figma, running your own research, and working with engineers. Partial on owning the booking flow end to end. Gap on having been the only designer anywhere, which is the central question for a first-designer role.
- **Hard gates:** none failed. Location fits (Galway, two days in office). Your pay floor and any other non-negotiables weren't given, so pay is unknown.
- **Opportunity ledger:** the entity exists as described and the posting is consistent across the JD, careers page and about page. Risks are a six-person, customer-funded company hiring its first designer, and equity terms that are unknown.

**Role reality**
- **Company:** Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, based in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers" (fernquay.example/about) [grounded]. No outside funding is mentioned, so runway is a question to ask [inferred].
- **Co-founder:** Ronan Kehoe is listed as co-founder and CEO, previously product lead for five years at a Galway travel-software company (public LinkedIn profile) [grounded]. His background is close to yours, so expect product-judgement questions.
- **Scope:** first design hire, owning the booking flow, running research calls with school owners, shipping with two engineers (careers page and JD agree) [grounded].
- **Compensation:** stated €52,000–€60,000 plus 0.5–1% equity [grounded]. Market calibration: Tillerby 2026 Ireland (n=520) gives a median base of €57,000 and an interquartile range of €51,500–€62,000 for product designers with 3–5 years [generic]. The posted band sits around the median. Equity is not calibrated.
- **Contradictions:** none found between the JD, careers page and about page.

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | must | strong | 3+ years product design | 4 years at a Dublin travel-booking company (CV) | medium (CV-only) | none |
| 2 | must | strong | Strong Figma | Daily use (CV) | medium | none |
| 3 | must | strong | Has run own user research | Monthly usability sessions with customers; checkout redesign (CV) | medium | transfer to B2B research (see #7) |
| 4 | must | strong | Works directly with engineers | Squad with four engineers (CV) | medium | none |
| 5 | must | partial | Owns booking flow end to end | Redesigned checkout, a part of the flow; not sole owner (CV) | medium | capability |
| 6 | preferred | gap | Comfortable as first/only designer | Never the only designer anywhere (your statement) | — | capability |
| 7 | preferred | partial | Research with school owners (small B2B) | Customer research at a consumer travel company | low | transferability |
| 8 | hard_gate | strong | Location: Galway, hybrid | You live in Galway | high | none |
| 9 | hard_gate | unknown | Pay | Posted €52–60k; your floor not given | — | unknown |
| 10 | implied | partial | Domain: outdoor-activity booking | Travel booking transfers, not outdoor-specific | low | transferability |

**Gap recovery queue** (no questions here; the questions are below)
- **G1 (row 6):** what closes it is a project where you set direction with no design lead to check with. Smaller examples count, if you can describe your own decisions.
- **G2 (row 7):** what closes it is a research plan or summary from customer interviews with a small-business or B2B audience.
- **G3 (row 9):** not a fit gap. It needs your pay floor.

**Risk register**
- **R1, medium:** small, customer-funded company hiring its first designer. Runway and budget continuity are unknown [inferred]. Ask on the call how design is funded and what happens if revenue dips.
- **R2, medium:** equity at 0.5–1% with no stated terms. Ask for vesting, cap table and strike terms before weighing it.
- **R3, low:** the first contact came by WhatsApp, but the careers page says applications go to jobs@fernquay.example, and you were told the invite would come by email. Scheduling by chat is common, so this is not a red flag in itself. Check that the calendar invite comes from a fernquay address and that the video link points there before joining. If the invite doesn't come from the company domain, reply to jobs@fernquay.example and confirm the call with them directly.
- **R4, low:** Ronan says "we loved the checkout case study." Confirm which case study he means and whether you sent one. If you didn't, reply to clear it up before the call.

**Application plan** (positioning drafted for your approval, not yet sent)
- Lead with the checkout redesign and the monthly research sessions. Frame these as shipped work with a squad, not as solo ownership.
- On being the first designer, be exact: "I've worked in a four-engineer squad and run research myself. I haven't yet owned a design function alone, and here's how I'd approach that." Do not claim you have been the only designer.
- On the call, ask: what "first designer" means for decision rights in the first 90 days, how design is funded, and the equity terms.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Queries "Fernquay Galway booking software…" and "Fernquay product designer Galway careers"; pages fernquay.example/about and fernquay.example/careers/product-designer |
| 2. Role-family sweep | yes | Tillerby 2026 Ireland design salary report (search above) |
| 3. Hiring manager footprint | yes | Query "Ronan Kehoe Fernquay co-founder"; public LinkedIn profile only |

Research tier: L1 — searches 4 of 5, fetches 2 of 2.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` for later interview prep with the mock-interview skill, if you want it. No pressure.

**Upgrade menu**
- **L2 deeper diligence (optional):** funding and leadership changes, hiring patterns, public candidate reports. Up to 5 more searches and 2 more fetches.
- **Your checkout case study or portfolio:** lets me check the claims in rows 1–5 against actual work.
- **Pay floor and equity preferences:** closes row 9 and sets how R2 matters.

**Questions** (answer in prose, or skip any; skipping is an answer)
1. Did you send Fernquay a checkout case study, and if so, which one? (R4)
2. What is your base-pay floor, and how much do equity terms matter to you? (row 9, R2)
3. Should I run the L2 deeper diligence, up to 5 more searches and 2 more fetches? (upgrade menu)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.