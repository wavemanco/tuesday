**Decision snapshot: `conditional_go`**

- **Fit:** strong on the core craft requirements. Hard gates: none failed on what you've told me. Pay (€52–60k) and hybrid Galway work both look compatible with you, though I don't know your salary floor.
- **Opportunity:** the role is legitimate-looking but unverified. The company check failed (see below), which caps this at `conditional_go` until verified.
- **Your call:** taking the 45-minute call is reasonable. Verify the company before sharing anything beyond CV and portfolio.

**Research tier: L1 — searches 1 of 5, fetches 0 of 2**

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search was not granted in this session, so no company check ran. |
| 2 | Role-family sweep (scope and pay for this seniority) | unavailable | Same cause. |
| 3 | Hiring manager's public footprint (Ronan Kehoe) | unavailable | Same cause. |

Nothing below about Fernquay is researched. Company facts are not established. Pay comparisons are not established.

**Role reality**

- **Role:** Product Designer, first design hire at a six-person company. Owns the booking flow end to end, runs research calls with school owners, ships with two engineers. Works most closely with co-founder Ronan Kehoe. CTO is Saoirse.
- **Stated pay:** €52–60k plus 0.5–1% equity. The posting's figure is grounded. Whether it's market-normal is not established, since no market sweep ran.
- **Contradiction to note:** "first designer" with end-to-end ownership of the booking flow usually means generalist scope with no design peers or review. That is an inference from the posting, labeled `[inferred]`.

**Evidence map** (from what you've told me; self-reported, CV-level)

| Requirement | Priority | Fit | Gap | Note |
|---|---|---|---|---|
| 3+ years product design | must-have | met | none | 4 years, Dublin travel-booking company. |
| Strong Figma | must-have | met | none | Daily use. |
| Has run own user research | must-have | partial | transferability | Monthly usability sessions with consumers. Their research is with school owners (small B2B operators). Same method, different audience. |
| Works directly with engineers | must-have | met | none | Squad of four engineers. |
| Owns a booking flow end to end | must-have | partial | transferability | Redesigned a checkout flow. Booking is a wider scope than one checkout. |
| Works without design peers | implied | unmet | capability | Never the only designer. Real, not hard-gated. |
| Sea-kayak/surf domain | preferred | unknown | discovery | No stated experience. Booking-domain experience likely transfers. |
| Hybrid, Galway two days a week | structural | met | none | You moved back to Galway last year. |

**Gap recovery queue** (no questions here; the questions are below)

- **Only-designer capability:** would close with a concrete example of running a practice alone, or a plan for getting design review without peers.
- **Booking-flow scope:** would close with a booking-flow project beyond checkout.
- **B2B research:** would close with any interview or research experience with business owners, or a plan for it.

**Opportunity risk register**

- **Company unverified (`severity: medium`, standing):** I could not confirm Fernquay exists as described. Possible reasons include: the company is new or small, the posting is stale, or it is not a real hiring employer. This caps the decision at `conditional_go` until checked.
- **Scope/support (`severity: medium`, `[inferred]`):** a first designer with a broad remit and no design lead. Ask what design support, budget and tooling exist.
- **Equity (`severity: low`, `[generic]`):** 0.5–1% at this stage is common, but its value depends on the cap table, which you should ask about.

**Legitimacy**

Nothing you've shared matches the patterns that matter: no fee, deposit, bank or ID request before an offer, and no hiring decided over chat. A WhatsApp message from a co-founder after an email application is normal in small Irish companies. The one check that matters is whether the email invite came from the same domain as the company's real site. Before the call, I'd do this:

1. Find the company's own website and check that the posting appears there.
2. Search the Companies Registration Office (CRO) register for "Fernquay" and check the director names against Ronan Kehoe and Saoirse.
3. Check the calendar invite's sender domain against the company's website.
4. Don't send bank, tax or ID details until there's a written offer, and don't pay anything for equipment or a "training" fee.

**Application plan** (as far as the evidence goes)

- **Lead with:** the checkout redesign, framed as an end-to-end flow problem, and your monthly usability sessions with customers. Keep your own numbers and outcomes only if you can verify them.
- **Pre-empt:** be ready to explain how you'd work without design peers. Don't overclaim on booking scope.
- **Prep for the call:** Ronan will likely probe your research method and how you'd work alone. Saoirse will likely ask about engineering handoff. The sibling skill mock-interview can rehearse this call.

**Dossier offer:** I can produce a `tuesday-dossier.md` file summarizing this assessment for later sessions if you want one.

**Upgrade menu** (what would change the analysis)

- A link to the live posting or the company's careers page. This would let me run the company check.
- The CRO record or the company's registered name.
- Your salary floor and whether equity is negotiable.
- The checkout case study, if you can share it. It would raise your evidence on booking-flow ownership from stated to verifiable.

**Questions**

1. Where did you first see this posting, and was it on their site or a job board? Your answer decides whether the company check starts from a live link.
2. What is your salary floor, and would you consider the equity range too low to count?
3. Would you be comfortable as the only designer with no design lead reviewing your work? If not, what would make it work?

You can answer these one at a time or all together.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.