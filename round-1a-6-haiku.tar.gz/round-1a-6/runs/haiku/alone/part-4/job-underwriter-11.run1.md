## Summary

**Job 1, Duinvaart Cold Chain (Operations Analyst): worth your time. Apply.** Your background matches most of the posting. The main gaps are cold-chain specifics and a Rotterdam schedule I can't check yet.

**Job 2, Kroonhaven Foods (Supply Planner): not worth your time right now.** The posting asks for three years of FMCG planning, SAP IBP or a similar system, and fluent Dutch. You have none of the planning experience and only conversational Dutch. I'd spend your effort on Job 1 and similar roles.

Research note: the web search was refused permission this session, so I couldn't check either company's website, the live postings, or pay ranges. The Research tier line below records that. Everything about the employers rests on the two postings you pasted.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

---

## Job 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Decision snapshot: `conditional_go`.** Apply, once the posting is confirmed on the company's own careers page and the Rotterdam schedule is confirmed as workable.

- **Fit ledger.**
  - `hard_gate`: unclear: R1.
  - `must_have`: direct: R2, R3, R4. Adjacent: R5.
  - `important`: direct: R6.
  - `preferred`: adjacent: R7.
  - R5 (`medium`) is adjacent, with the cold-chain limit named. R1 is unconfirmed until you tell me whether three office days in Rotterdam works.
- **Opportunity ledger.** Clear and specific: the duties and outcomes are concrete, and the posting names the depot-manager relationship. No pay is stated (RR1). The posting itself raises no red flags. The employer has not been checked against any source outside the posting (RR2).
- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam schedule is workable for you; (2) the posting is live on Duinvaart's own site; (3) you can truthfully talk about temperature compliance (see R5), or you frame it as the gap it is.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid: three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A standard analyst role with reporting and stakeholder duties; not unusually broad | `[inferred]` from the listed duties |
| Market calibration | Not run; no pay band, since the search was refused | — |
| Unknowns | Pay; team size; whether temperature data already comes from vehicle sensors or manual checks | — |
| Contradictions | None in the posting | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | high | hard_gate | Schedule term; your constraint isn't in the material | `[grounded]` posting | You confirm it works |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-report | `[grounded]` your background | None |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use; self-report, no artifact yet | `[grounded]` your background | Have a query sample ready |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily use of Power BI; self-report | `[grounded]` your background | None |
| R5 | Tracking temperature compliance across a refrigerated fleet | must_have | adjacent | low | transferability | You tracked on-time delivery, not temperature; no cold-chain data in the material | `[inferred]` from the duty against your listed work | Question G1 |
| R6 | Weekly dashboards, and working with depot managers on route changes | important | direct | medium | presentation | You built the on-time dashboard depot managers use and ran the weekly route review; the CV should say so plainly | `[grounded]` your background | E1 |
| R7 | Dutch a plus | preferred | adjacent | medium | capability | Conversational; not fluent. Real, but not the level a Dutch-speaking team will expect | `[grounded]` your self-report | None |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5, must_have) | transferability | Nothing in the material on temperature data, sensors or refrigerated vehicles | A must-have duty; closing it narrows the most likely objection | Any delivery-exception or SLA reporting that touched temperature or product condition; any work with vehicle telematics | A sample report or dashboard screenshot (sanitized) | `[inferred]` that this is the likeliest objection |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (none in posting) | The posting may withhold pay until interview | `[inferred]` from the posting | What is the budgeted salary for this role? | unresolved |
| RR2 | Employer not verified this run | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale, or the company may be smaller than it reads. The search was refused, so this is an unverified gap, not a finding against them | `[generic]` pattern for small employers; not a claim about this one | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the on-time delivery dashboard and the route-review work into an outcome bullet, with figures only if you can state them truthfully | see R6 | `[grounded]` your background | pending your approval |
| A1 | Check the posting on Duinvaart's own careers page, and note the contact name | see RR2 | `[generic]` | for you to do |
| A2 | Prepare a question for interview: how temperature compliance is measured today, whether by sensor data or manual checks | see R5, RR1 | `[inferred]` | pending your approval |
| A3 | Don't claim temperature or cold-chain experience you don't have; say "I haven't worked with temperature data yet, and here is how I'd learn it" | Reframing audit | `[generic]` | pending your approval |

### Evidence status

Verified: none yet. Your background is self-report, which the spec caps at `medium`.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused permission. Would have confirmed the company exists as described and the posting is live (RR2) |
| 2. Role-family sweep | unavailable | Search refused permission. Would have set the pay band and the scope norm for this title |
| 3. Hiring manager's footprint | n/a | No name was given |

---

## Job 2: Supply Planner, Kroonhaven Foods, Utrecht

**Decision snapshot: `no_go`** on the current profile. The posting is coherent. The gap is structural: three must-haves sit in planning experience you don't have, and that can't be closed by wording.

- **Fit ledger.**
  - `hard_gate`: unclear: R1.
  - `must_have`: absent: R2, R3, R5. Adjacent: R4, R6 (partly).
  - `important`: unclear: R7.
- **Opportunity ledger.** Coherent. The pay isn't stated (RR1). The posting asks for a level of planning the candidate can't show, and that's a fit problem, not a posting problem (no red flags).
- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning experience you haven't told me about, such as production or demand planning, supply scheduling, or forecast ownership, even as a side task. Fluent Dutch would also change the picture, though that won't happen soon.

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | high | hard_gate | Your location constraint isn't in the material | `[grounded]` posting | You confirm it works |
| R2a | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | No planning role in your background | `[grounded]` your background | Question G2 |
| R2b | Operational analysis that informs planning decisions | must_have | adjacent | medium | transferability | Your route-performance review and on-time analysis inform operational decisions; this is not planning | `[inferred]` | None |
| R3 | Advanced Excel | must_have | unclear | low | discovery | Excel isn't in your listed tools | `[grounded]` your background | Question G3 |
| R4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system in your background | `[grounded]` your background | None |
| R5 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review; S&OP covers supply and demand, which your work doesn't | `[inferred]` | None |
| R6 | Balance production capacity against forecast | must_have | absent | none | capability | No production or capacity work in your background | `[grounded]` your background | None |
| R7 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational; not fluent | `[grounded]` your self-report | None |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (none in posting) | The posting may withhold pay until interview | `[inferred]` | What is the budgeted salary for this role? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| D1 | Don't apply now; put your time into Job 1 | Multiple must-haves with no realistic closure | `[inferred]` from R2a, R4, R6, R7 | pending your approval |
| D2 | Consider logistics or transport planning roles, which may ask for less FMCG and less Dutch | Closer to what you've done | `[generic]` role-family pattern | for you to explore |

### Evidence status

Verified: none yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused permission |
| 2. Role-family sweep | unavailable | Search refused permission |
| 3. Hiring manager's footprint | n/a | No name was given |

---

## Upgrade menu

- A sample report, dashboard screenshot, or query (sanitized) → R3, R4 and R6 move from `medium` toward `high`.
- Any temperature, cold-chain or telematics experience → R5 closes or narrows.
- Your constraints on Rotterdam and Utrecht schedules → R1 (both jobs) closes.
- Search permission for this session → the employer checks (RR2) and the pay band (RR1) can run.
- Any planning experience you've had, even as a side task → Job 2 is reconsidered.

Would you like a dossier file saved for either job, so you can come back to it later?

---

1. Is three office days a week in Rotterdam workable for you? (Job 1, R1, a hard gate.)
2. Have you ever worked with temperature data, cold-chain reporting, or refrigerated vehicles? (Job 1, G1.)
3. Have you done any forecasting, capacity planning, or production scheduling, even as a side task? (Job 2, R2a.)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.