Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-1-denied-1decce88/9f8fbfb6-4263-438d-8e18-deeccbe64990/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md, and I've attached it here too. I built it for a peer conversation, since you described Dan as a peer. Web search was refused in this session, so the pack rests only on your material: nothing about Northwind's values, interview process or current strategy has been checked, and the strategy questions use your research note.

The pack has 19 questions across six persona banks, weighted toward a Data-Driven Prober and a Peer Evaluator, with a fit snapshot, a prohibited-claims list and reverse questions. The highest-ROI prep is the quota objection (D1): he runs sales strategy, and Priya has no quota or sales-ops experience. She should say so plainly, then explain that her volume targets were company-level numbers. The second most likely probe is the ~$400M ARR figure (A1 and E2), so she should be ready to say how it was counted and which part was hers.

I'm going only on what you've shared, and I can get this wrong. Priya's answers should describe what she actually did, in her own words.

Would you like me to run a drill? I can play Dan as the Prober on A1 and push back on the attribution.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for carrying into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:
1. Can you paste the full JD text? The highlights are enough for this pack, but the full posting would turn the requirement quotes into verbatim text and show any location, pay or work-authorization gate.
2. Did the recruiter name a deliverable, such as a presentation or case, or any focus areas for this conversation? If so, I'll add a graded-deliverable section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, both reporting to the same VP. **Format:** one 60-minute conversation.

Built on your material only. Web search was refused in this session (see Sources), so nothing about Northwind's values, interview process or current strategy has been checked against the web.

Sections left out by design: prep triage (prep time not given), graded deliverables (none declared yet), values cheat sheet (no values-style round detected), delivery coaching (no assessment provided).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL behavioral and values; EXP work-experience deep-dive; JD role and JD-driven; CO company and strategy; CASE live problem.
- Guidance is scaffolding, not a script. Each guidance cell is speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview with two honest branches. Answer whichever branch is true for you. It is not a question to me.

## Fit snapshot

Requirements come from your JD highlights, which are highlights and not the full posting. Evidence quotes are your own sentences, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message), "9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Your material says product strategy and ops, and a store-surface change you proposed. It does not say a go-to-market plan you owned. Bridge at product scope: "I proposed a store-surface change." Answer slot: if you set any go-to-market step for a launch, say which and how you decided it; if you did not, say so and describe the product-side strategy work instead. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Your material is silent on this motion. Answer slot: name the funnel stage you would examine first for a new line and the number that would show whitespace there. If you have run a land-adopt-expand-renew analysis, say which stage it covered and what it showed. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | No gap, but a self-report with nothing inspected behind it, so expect a live probe. Lead with an analysis you ran, not the adjective. Upgrade: a query or workbook you built, if you can show it. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Your material says a partner-level revenue model that was used in negotiations. It does not say a partner motion you designed. Bridge at model scope: "I built a partner-level revenue model, and it was used in carrier negotiations." Answer slot: if you designed any part of how partners were engaged or paid, say which; if the model was the extent of it, say so. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Reword only: "I set annual volume targets with cross-org consensus." Add no meeting, number or objection. The probe on how consensus was reached is answer slot A2. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [grounded] | transferability | Your material says daily use, which is use and not building or launching an AI product. Bridge at use scope only: "I use AI tools daily." Answer slot: if you have built, priced or launched an AI feature, say what it was and your part in it; if not, say so and give your approach to Compass. |
| F7 | Likely probe: quota or sales ops (your message; not a JD line) | "No classic sales-ops or quota-setting experience." (your message) | none | [grounded] | capability | A gap you stated, so the words come from you: "I haven't set quota or run sales ops." Bridge at target scope only: "I set annual volume targets with cross-org consensus." Do not stretch the volume target into quota. |
| F8 | "B2B data-infrastructure SaaS" (your research note; company context, not a JD line) | none given | none | [grounded] | discovery | Your material is silent on selling to enterprise data buyers. Answer slot: if you have sold to or planned for enterprise data buyers, say who and what you did; if not, say so and name what from your carrier work carries over. |

No gate rows: the highlights name none, and your material says nothing about one. The full posting may name a location, pay or work-authorization term; if it does, that enters the snapshot as a gate row.

## Prohibited claims

Each entry has its basis and its honest form. These are not to be coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have set quota or run sales ops." | Negative you stated (F7) | "I haven't set quota or run sales ops." Then volume-target scope only |
| "I owned the go-to-market strategy for a product line." | Inflated form of F1 | "I proposed a store-surface change." Limit as analysis: your material says product strategy, not a go-to-market plan you owned |
| "I drove the ~$400M ARR." | Inflated form of "credited with" in your quote | "proposed a store-surface change credited with a ~$400M ARR uplift," with "credited" kept |
| "I designed partner motions and led carrier negotiations." | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations" |
| "I built or launched AI products." | Inflated form of F6 | "I use AI tools daily." |
| "My SQL and Tableau work drove decisions." | Inflated form of F3 | The analysis you actually ran, at its real scope |
| "Our volume targets were quotas." | Inflated form of F5 and F7 | "annual volume targets" |

## Reading the interviewer

**Career pattern, from your profile note:** pricing and monetization roles, with one early-stage-startup chapter. **Self-described:** "relentlessly data-driven."

Practical implications:
- Expect every number you give to be probed for its inputs and denominators. Know the weakest assumption behind each one before he names it.
- His native language is pricing, packaging and unit economics. Describe your revenue model in its mechanics, not only its outcome.
- The startup chapter means he may test scrappiness and skepticism about big-company pace. Answer with what you did, not with the size of the company.
- Mirror opportunity: monetization vocabulary is shared. No professional jump of his matches yours, so none is offered as a shared-jump line.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Line-by-line probing of CV figures; follow-ups two levels deep | High, top weight (5 questions). Self-described data-driven, a peer relationship, and the $400M figure and volume targets are the magnets | Name the weakest assumption first; say plainly which numbers were yours |
| Peer Evaluator | Seam questions, credit and disagreement probes | High (4 questions). Peer relationship prior; he is pricing what the hire adds to his work | Offer seam principles, not a map of his team; reciprocity |
| Case / Strategist (pricing-tilted) | Live problems on pricing, packaging and partner motion | Medium (3 questions). Pricing career tilts case toward packaging and unit economics; a single conversation may hold one live problem | Clarify, then objective, segmentation, approach, metrics, risks; name the pricing lever early |
| Skeptic | Consumer-to-B2B transfer and quota gaps | Medium (3 questions). The gaps in F1, F2, F7 and F8 are where a peer would press; the startup chapter raises scrappiness probes | Rehearse the one predictable objection until it is calm; concede the quota gap plainly |
| Pressure / Stress | Interruptions and time-boxing on the headline claim | Low-medium (2 questions). A peer rarely pressures, but the $400M claim can trigger it | Pause, restate, hold the quoted position through two follow-ups |
| Conversational / Rapport | Open arc and casual questions on the JD's plus items | Low (2 questions). Opener that is still scored | Prepare a 90-second arc; treat the AI question as scored |

Values and behavioral persona: not weighted. No loop source documents a values-style round, and your message establishes the loop as one conversation with Dan.

## Question banks

### Bank A: Data-Driven Prober (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted, and how much of it was yours." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Open with the change itself, in those words. Then the defend-the-number slots in your own words. Answer slot: how the figure was counted, if you know; if you do not, say so and name who holds the method. Name the weakest assumption you know of before he does. Answer slot: which part of the uplift was yours to decide, and which part was credited to you by others; if you cannot separate them, say so plainly. Hold "proposed," never "drove" or "led." | The headline metric and the first place a prober goes. EXP because it tests attribution. F1 and F7 say nothing about counting method, so the guidance cannot supply one. |
| A2 | "Walk me through the annual volume targets you set, and which assumption behind them you would defend least." | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Say what a target measured, who agreed to it, and the assumption you would defend least, in your words. Answer slot: the method behind the target, if you can describe it; if you did not build the method yourself, say so. Be precise that a volume target is a company-level number and not a rep quota. | This is his home ground, and the closest thing you have to quota-setting. F5 and F7 both point here. |
| A3 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision. What was the grain of the data?" | JD | [grounded] "skilled in SQL/Tableau" (your message); [grounded] "run independent analysis in SQL and Tableau" (JD highlights) | Open prompt. Pick one analysis, name the table, the grain and the filter that mattered. Describe the query, not the adjectives. Answer slot: if no analysis you ran changed a decision, say so plainly and give the nearest one at its real scope. | The JD names SQL and Tableau directly, and F3 is medium confidence, so a prober tests whether "skilled" survives a live question. |
| A4 | "Which assumption in the partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the one input whose source you would re-check, before he asks. Answer slot: which parts of the model you built yourself; if others changed it, say what they changed. Hold "used in," and do not turn it into "led the negotiations." | The partner model is the strongest partner-motion evidence (F4), and his monetization lens will go straight to its inputs. |
| A5 | "For a new product line, which land-adopt-expand-renew number would you watch first, and how would you know it is real?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | This is a plan, not a past: name one stage, the metric, and the check that it is not an artifact of how it was counted. Answer slot: if you have run a land-adopt-expand-renew analysis, say which stage it covered and what it showed; if not, say so and give your plan as a plan. | A JD line asked as a test of analysis under a named motion. F2 is a discovery gap, so the honest answer is a plan. |

### Bank B: Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between sales strategy and your GTM work, and what happens when we disagree about a number?" | JD | [generic] seam principle; [grounded] "set annual volume targets with cross-org consensus" (your message) | Give seam principles: who sets the target, who owns the forecast, who settles the number when two views differ. Use the consensus you reached as the one story: the targets, and the agreement across orgs they produced. Answer slot: if the consensus came with a disagreement, say what it was and how it closed; if it did not, say so and say what you would do first. | A peer probes the seam. The volume-target quote is the only cross-org evidence in the material. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say what you proposed, and keep "credited with" as the scope of the credit. Answer slot: name any other person or team whose work carried the change past the proposal; if the work was yours alone, say so. | A peer reads a large credit as turf. Keeping the sentence's scope is the defense. |
| B3 | "What would you need from my team to launch the first new line well?" | JD | [generic] reciprocity pattern; [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Ask for principles: pricing and packaging inputs, sales-motion data, partner terms. Do not describe his team's process. Answer slot: if you have handed a model to another team, say what they needed from you; if not, say so and name the first input you would ask for. | Reciprocity is what a peer weighs, since the hire adds to or lightens his load. The model is your monetization evidence. |
| B4 | "Tell me about a time you disagreed with a peer, and how it ended." | JD | [grounded] "strong cross-functional influence" (JD highlights) | Open prompt. Pick a disagreement with an equal where a number was at stake, where you were willing to be wrong, and where the working relationship survived. Answer slot: if no such time comes to mind, say so plainly, then give the nearest one you can name, at its real scope. | The JD's influence line is the raising source. A peer tests disagreement style with equals. |

### Bank C: Case / Strategist, pricing-tilted (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A platform vendor is bundling its suite into the accounts your data-infrastructure customers already use. What do you do in the first 90 days?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify first, then objective, segmentation, approach, metrics, risks. Challenge one premise. Pricing angle: bundle price against standalone price, and what each does to unit economics. Partner angle: the terms the bundle sets for partners. If you want an example from your own work, the nearest is the model you built, quoted: "built a partner-level revenue model used in carrier negotiations." Use it as a tool, not as a claim that you solved a bundle. | The competitive threat from your note, asked as a live problem. The question makes no claim about you, so the guidance makes none either. |
| C2 | "Northwind has three stated priorities: enterprise expansion, Compass, and profitability. Which one does a new GTM line serve, and which does it cost?" | CO | [grounded] "enterprise expansion" (your research note); "an AI copilot launch ('Compass')" (your research note); "reaching profitability" (your research note) | Pick one priority and make the trade explicit: what the line gives up on the other two. Profitability is a unit-economics question, which is his ground. Check the wording of the priorities against Northwind's current materials before you say them aloud. | Company-altitude question. CO is grounded only in your note, since web research was refused, so it is not current. |
| C3 | "How would you price or package Compass so it does not cannibalize the core data-infrastructure base?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note); "AI experience a plus" (JD highlights) | Clarify whether the copilot is an add-on or inside the platform. Sketch two packaging options with their trade-off. Name the metric that would show cannibalization. Answer slot: if you have priced or packaged an AI feature, say what it was and which part you decided; if not, say so and stay with the packaging logic. | His native language is pricing and packaging, and the AI plus item is asked casually. |

### Bank D: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have no classic sales-ops or quota experience. Why would your volume targets hold up with a sales team?" | JD | [grounded] "No classic sales-ops or quota-setting experience." (your message); [grounded] "set annual volume targets with cross-org consensus" (your message) | **Highest-ROI prep in this pack.** Plain acknowledgment first: "I haven't set quota or run sales ops." Then bridge at target scope: "I set annual volume targets with cross-org consensus." Name the difference before he does: volume targets are company-level numbers, not rep quotas. Hold through two follow-ups by returning to what the targets were. Then concede the quota part plainly, without folding on the targets. | He runs sales strategy, and the JD's GTM ownership sits next to quota design. This is the most predictable objection, and the deepest rehearsal goes here. |
| D2 | "Your last nine years were at a consumer-tech company. What in that transfers to a B2B data-infrastructure buyer?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Bridge at the quotes' scope: product strategy and ops on one side, a revenue model used in carrier negotiations on the other. Answer slot: if you have sold to or planned for enterprise data buyers, say who and what you did; if not, say so, and name what in the carrier work carries over. | This is F8, and the transferability gap in F1. A skeptic asks this as a flat question. |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights); [grounded] "No classic sales-ops or quota-setting experience." (your message) | Pick the honest answer: the land-adopt-expand-renew funnel and quota design are where your material is thinnest. Name it, then give a 30-day plan. Answer slot: name the stage you know least and how you would close that gap in 30 days. | Calibrated candor over bluffing a competency that the interviewer owns. |

### Bank E: Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); [grounded] "set annual volume targets with cross-org consensus" (your message) | Pause, then restate the question in your own words. Lead with the two quotes. Hold the position through two follow-ups. Hold-then-concede: after the second follow-up, concede the quota gap plainly (D1). Do not claim knowledge of any internal candidate. | A stress interviewer tests composure. The position held is quoted, and the concession is the one F7 supports. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed it, and I was credited with the uplift." Hold through two follow-ups. Answer slot: which part was yours to decide. Concede only what you cannot account for, specifically. Never move to "drove." | Pressure version of A1. The claim has to survive a second follow-up. |

### Bank F: Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | A 90-second arc: consulting, then product strategy and ops, then the partner model and the volume targets. Close on the reason for this line of work, in your own words. Answer slot: if you are not sure of the reason, say so, and say what you are looking for. | Casual register, still scored. Every beat is one of your quoted sentences. |
| F-2 | "What are you actually playing with in AI tools these days?" | JD | [grounded] "uses AI tools daily" (your message); [grounded] "AI experience a plus" (JD highlights) | Name one specific workflow you use, in your own words. Do not convert use into building. Answer slot: if you have built or shipped anything with AI, name it and your part; if not, say that. | The JD's plus item, asked casually. The honest answer is use, and use is what it is. |

Question count: 19 across six banks (5, 4, 3, 3, 2, 2).

### Requirement coverage

| JD requirement or probe (source) | Questions |
|---|---|
| "own GTM strategy for two new product lines" (JD highlights) | C1, C2, D3 |
| "identify whitespace across land/adopt/expand/renew" (JD highlights) | A5, D3 |
| "run independent analysis in SQL and Tableau" (JD highlights) | A3 |
| "partner-motion design experience required" (JD highlights) | A4, B3, C1 |
| "strong cross-functional influence" (JD highlights) | B1, B4, E1 |
| "AI experience a plus" (JD highlights) | C3, F-2 |
| "enterprise expansion" (your research note; not a JD line) | C2 |
| The ~$400M ARR figure (your message) | A1, B2, E2 |
| Volume targets and the quota probe (your message) | A2, D1 |
| B2B data-infrastructure buyers (your research note) | D2 |

## Reverse questions

Five or more, each with why it lands. R1 ties to his own path; R2 is the reciprocity question a peer calls for.

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "What did your pricing work teach you that carried into sales strategy, and what did you have to relearn?" | Ties to his own path (pricing spine, startup chapter). It turns a probe into a peer conversation and shows you researched him, not only the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question that a peer conversation calls for, and it turns the hire into a contribution. |
| R3 | "Where does sales strategy's view of a new product line end and product's begin?" | A seam question. The answer shows decision rights, which is the peer-level exchange you want. |
| R4 | "Who owns the pricing decision for Compass, and where does your team sit in it?" | Pricing is his native ground. The answer shows where his team has leverage. |
| R5 | "Which of the three priorities (enterprise expansion, Compass, or profitability) will this role's first-year numbers be judged against?" | Tests altitude, and the answer sharpens C2. The priorities come from your note, so check their wording before you repeat them. |
| R6 | "When a new line's motion misses its volume target, which lever do you pull first: price, packaging or the sales motion?" | Puts his lens on a live problem and shows you think in levers. |

## Sources

- **Provided documents:** your message (candidate background, JD highlights, interviewer profile, research note).
- **Research tier:** L1, searches 4 of 6, all refused; fetches 0 of 2. Web search permission was not granted in this session, so no result came back and nothing from the web is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have fixed the values section and the values-style check. Query "Northwind Data values operating principles": refused |
| 2. Northwind Data interview process, Senior GTM | unavailable | Would have checked the loop. Your message already establishes it as one conversation with Dan. Query "Northwind Data interview process Senior GTM strategy": refused |
| 3. Northwind Data strategy or recent news | unavailable | Would have made the CO bank current. The bank rests on your research note only. Query "Northwind Data Compass AI copilot launch": refused |
| 4. Dan Kovac, Northwind Data | unavailable | Would have added public talks and writing to the interviewer read. The read rests on your profile summary only. Query "Dan Kovac Director of Sales Strategy Northwind Data": refused |
| 5. Representative Senior GTM JD | skipped | The JD highlights you supplied fix the requirements, so no representative posting was needed |

## Upgrade menu

- The full JD text → the six requirement quotes become verbatim rather than highlights, and any location, pay or work-authorization gate enters the fit snapshot.
- The recruiter's note on any deliverable or focus areas → a graded-deliverable section, and the bank weights shift to match.
- Web search permission granted in a later session → values, process, current strategy and his public footprint get checked, the CO bank becomes current, and the interviewer read gains his talks and writing.
- Days until the conversation → a prioritized prep schedule.
- A SQL or Tableau piece you built and can show → F3 rises to high, and A3 gets an artifact to walk through.
- A tuesday-dossier.md from an earlier engagement, if you have one → its verified evidence and prohibited claims replace the local list.
