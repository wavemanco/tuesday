Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-4-denied-cae5c17d/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, using the dossier you carried. Company research was refused by the search permission, so there's no Quartzline values, loop or strategy material in it.

The core of Thursday is the objection the underwriter named: "You've never held the PM title or owned a roadmap." Open with the plain acknowledgment, then your integration work at its own scope, then a ramp stated as a plan. Don't add a figure or a decision you can't defend, and concede the roadmap gap specifically rather than folding.

Two things to know:
- The dossier is 104 days old. If the posting has changed, the requirement quotes need checking.
- The dossier doesn't grade R2 (shipped products), R3 (API docs and schemas) or R4 (stakeholders). The pack reads those itself and marks them as its own reading.

Say the word and I'll play the Skeptic on A1. I can also write a `tuesday-dossier.md` carrying this prep's gaps for the next session, and I can convert the pack to Word.

Does the 45 minutes include a case, a written exercise or a presentation, or is it a conversation only?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs, Quartzline

Hiring-manager round, 45 minutes, Thursday. Interviewer not named. Built from the underwriting dossier (`tuesday-dossier.md`, job-underwriter, decision `conditional_go`, generated 2026-08-14). No recruiter guidance and no interviewer profile were available, so there are no graded deliverables and no interviewer read.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (the listed requirements), **EXP** (what you actually did), **CASE** (a live problem), **CO** (company knowledge, none in this pack). Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", the answer is yours to give in your own words, and either branch it names is an honest answer.

## Prep triage

Prep time is not stated, so this is the full pack, in this order:

1. **A1**, the objection the underwriter named. Rehearse it aloud until the acknowledgment and the bridge come in one breath, then take the two follow-ups.
2. The **prohibited list** below, cold. Know the one-sentence acknowledgment for each item.
3. **B1**, the adoption case. Practise the clarify step before the structure.
4. **C1**, defending the 30+ integrations figure.
5. **D1**, your 90-second arc.

Everything else is insurance.

## Fit snapshot

Requirement lines are the dossier's `role_profile` text (dossier R1 to R5, and its responsibilities). Evidence is quoted from the dossier's `verified_candidate_evidence`, labelled V1 to V3 here in list order. The dossier grades R1 and R5 and the roadmap sub-claim, but is silent on R2, R3 and R4; those rows are this pack's reading and their provenance says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | low | [grounded] | transferability | Say V1 at its own scope: integration delivery for clients. The limit is the pack's observation: the material shows integration delivery, not product management. The plain acknowledgment, sourced to the dossier's prohibited claims: "I haven't held the product manager title." |
| F2 | "Shipped API or platform products" (dossier R2; not graded in the dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | low | [inferred] | discovery | The go-live stage is the nearest evidence, and it is integration go-live, not a product you shipped. Answer slot: if any of that work was a product you can describe as shipped, name it and what its users did with it; if each one was integration delivery for a client, say so. |
| F3 | "Technical fluency: API docs, schemas" (dossier R3; not graded in the dossier) | "Wrote the internal integration playbook her team uses" (dossier V2) | low | [inferred] | discovery | The playbook is integration guidance; the material does not show schema or reference-doc work. Answer slot: if the playbook or your integration work involved API reference docs or schemas, name what you wrote or read; if not, say so and say how you would close the gap. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier R4; not graded in the dossier) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | medium | [grounded] | discovery | Both quotes touch customers and product, and neither shows whether sales or engineering were in them. Answer slot: name who you worked with on the engineering and sales sides, in your own words; if none of it was sales-facing, say so. V3 carries an expected probe. |
| F5 | "Agile delivery experience" (dossier R5) | none given | low | [grounded] | discovery | Clarify strategy (dossier R5). The question is the requirement's own wording. Answer slot: if you can name a sprint or planning cadence you ran on integration work, say it in your own words; if you never worked that way, say so, and say what you would want to confirm about how this team defines agile delivery. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier responsibilities; dossier R1 sub-claim) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | none | [grounded] | capability | Stated absence, sourced to the dossier's acknowledge_gap area on roadmap and prioritization authority: "I haven't owned a product roadmap." No answer slot. V3 at its own scope: you ran roadmap-input sessions that fed product. The pack's observation: that is input to a roadmap, not ownership of one. |

Note, not a candidate requirement: the dossier lists decision authority versus the two squad leads as unverified. It is covered by A3 and reverse question 1.

## Prohibited claims

Built from the dossier's `prohibited_claims` and the fit snapshot. Each entry names its basis and its honest form. None of these may be asserted, softened or implied in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | sourced: dossier prohibited_claims | "I haven't held the product manager title." Then V1 at its own scope (F1). |
| "Having owned a product roadmap" | sourced: dossier prohibited_claims and the acknowledge_gap area | "I haven't owned a product roadmap." Then V3 at its own scope (F6). |
| "Having set prioritization for an engineering squad" | sourced: dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Then V3 at its own scope: input to product, not prioritization. |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic). The dossier's named objection raises the Skeptic. No loop source establishes this company's loop, so no values-style round is assumed and the weights are flat within the prior; that is said plainly here.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Why hire you into a PM role?"; "why now?" | High | Hiring-manager prior; the dossier's named objection sits here; it is the decision's own condition | Acknowledge, bridge at V1's scope, hold then concede the roadmap gap specifically |
| Case/Strategist | A live roadmap problem: an adoption stall, a breaking change | High | The hiring manager is buying capability on their own roadmap; adoption and roadmap are named responsibilities | Clarify before structure; name the decision owner before the option |
| Data-Driven Prober | Counts and attribution on V1's 30+, V2's use, the adoption number | Medium | V1's headline figure is the probe target; no adoption baseline exists in the dossier | Defend-the-number answer slots; name the weakest assumption you would defend least |
| Conversational | "Walk me through the journey"; "what are you working with in APIs" | Medium | The 45-minute opener is where rapport questions land, and they are scored | A 90-second arc from V1 to V3; no title added |
| Pressure | Interrupts on the PM objection; "how much of it was actually you" | Low | No stress signal in the material; the PM objection can land as pressure | Pause, restate, hold through two follow-ups |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); the premise's negatives are sourced to the dossier's prohibited claims and the roadmap acknowledge_gap area | The highest-ROI rehearsal in this pack. Open with the acknowledgment in one sentence: "I haven't held the product manager title, and I haven't owned a product roadmap." Then V1 at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Name the limit as your own observation: that was integration delivery, not product management. Then a ramp, said as a plan and never as a past: what you would do on the roadmap first, and what you would need from the two squad leads. Hold through two follow-ups by returning to the integration work. Concede the roadmap gap specifically; never fold to "I can run the roadmap." Add no figure, partner or decision. | The underwriter named this as the likeliest objection (dossier likely_interviewer_objections). It is also the decision's own condition: the bridge stays adjacent and is never presented as PM experience (F1, F6). |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap area, owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas) | Name the roadmap and prioritization authority first, plainly: "Owning the roadmap and setting its priorities is the part I haven't done." Then the next weakest, F5: how agile delivery runs inside a product org, and what you would want to confirm. Stop at two. Do not add a third to look humble. | A Skeptic stem built from the role's own requirements. The honest answer is the weak-area list the underwriter already graded, so it cannot drift. |
| A3 | "I don't see decision rights over two engineering squads in your background — how would you handle that in this role?" | JD | [generic] | Answer slot: if you have directed work across two engineering squads, say how, in your own words. If you have not, say so, and say how you would settle decision rights with the two squad leads in the first weeks. | The raising source is the JD line "Write specs and drive delivery with two engineering squads". The squad-authority question is unverified, so the pack asks it rather than answering it. |
| A4 | "Integration delivery and product ownership are different jobs. Why do you want the second one?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer from the closest step you have taken, in your own words: the roadmap-input sessions put client evidence in front of product (V3). Say it is the closest you have come, not that you have crossed into the role. Your reason for wanting the roadmap is not in the material, so it is yours to say. | Motivation-consistency probe. It sits on V3, the one roadmap-adjacent entry, at its own scope. |
| A5 | "Why this move, and why now?" | EXP | [generic] | Answer slot: the reason for the move is not in your material, so there is no quote to build it on. Give your reason in your own words and keep it to what you did. If the reason is not clear to you yet, say that. | The Skeptic's "why now" probe. The material is silent on motivation, so the pack supplies no reason. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has stalled over the last two quarters. Where would you start?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Clarify first: what counts as adopted, and is there a baseline? The dossier records none, so say so. Then segment partners by where they stop, using the stages V1 names: scoping, requirements, architecture, UAT, go-live. Form one hypothesis per stage. Ask for the metric before naming a fix. Finish by naming the one thing you would check first. | The hiring manager's live problem on their own roadmap. Adoption is a named responsibility with no baseline, so the clarify step is the honest move. |
| B2 | "How would you run agile delivery across two engineering squads?" | JD | [generic] | Clarify strategy, using the requirement's own wording (F5). Answer slot: if you have run sprints or a planning cadence on integration work, name it in your own words. If you have never worked that way, say so, and say what you would want to confirm about how this team defines agile delivery before changing anything. | Covers R5 and the squad delivery responsibility. The probe is the requirement's wording; no past practice is supplied. |
| B3 | "A partner asks for a breaking change to an API two squads depend on. What do you do this week?" | CASE | [generic] | Clarify the partner's need and what the contract promises. Then say who decides: the squad leads or you, which is the open question for them. Then the options: versioning, a deprecation window, a staged rollout. Name the decision owner before the option. | Tests decision rights (A3) inside a live problem. No claim about your past. |
| B4 | "Walk me through how you'd build a two-quarter roadmap for the partner-facing platform." | JD | [generic] | Give a structure, not a list: the two or three partner problems you would bet on, the evidence you would need for each (the adoption baseline first), and what you would leave out and why. Say you would test assumptions with partners rather than assume them. Do not describe a roadmap you have owned. | Covers the roadmap responsibility (F6) without asserting ownership. The pull is to answer from ownership you do not have. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ integrations. How did you count them, and what counted as one?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend the number in your own words: how the count was kept. Answer slot: name the assumption behind the 30+ that you would defend least. If the count was not kept as a record, say so. If some of the 30+ were shared delivery, say which part was yours. | The headline figure on the dossier's strongest entry, so a Prober's first target. The assumption is yours to name; the pack does not supply one. |
| C2 | "Who uses the integration playbook, and how do you know?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Say who uses it and the one way you would know. Answer slot: if you have a usage or outcome record for it, name it; if you do not, say so. The playbook itself is the inspectable artifact. | V2 is high confidence with an inspectable artifact (dossier). A Prober asks for the outcome, and the candidate should not claim one. |
| C3 | "What adoption number would you use to judge partner API success, and what is its weakest assumption?" | JD | [inferred] derived from the dossier risk: adoption metrics are named as a responsibility with no current baseline | Propose one metric in plain terms, then name its weakest assumption in your own words. Say you do not yet know the current baseline. Quote no baseline, because the dossier has none. | Adoption metrics are a named responsibility with no baseline. The Prober asks for the denominator. |
| C4 | "Which of your API integrations reached go-live, and which stages were yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Pick one integration you can describe end to end, and state in your own words which stages you led. Answer slot: if you led all of them, say so and why; if some stages were run by others, name which. Do not claim a stage you did not run. | The nearest evidence for R2, which the dossier does not grade (F2). Covers the requirement through integration go-live rather than a product. |
| C5 | "Walk me through how client evidence got from those sessions to product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Describe the mechanism the quote states: what the sessions were, how often (quarterly), and what went to product. Answer slot: if a product decision changed because of that evidence, name which one and how you know; if you cannot point to one, say so. | V3 is medium confidence and the dossier expects a probe on it. The seam, what the input actually did, gets the rehearsal. |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Ninety seconds, three beats in order from the quotes: the integration work (V1), the playbook (V2), the roadmap-input sessions (V3). Then one sentence on the move, using your own reason from A5. Add no title, date or figure that the quotes do not carry. | Rapport openers are scored. The arc should carry the bridge without tilting toward a PM role. |
| D2 | "What are you actually working with in APIs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Answer from what you did: the integration work and the playbook. Answer slot: name the API formats, docs or schemas you have worked with, in your own words. If your work was delivery rather than schema design, say so, and say how you would get fluent in the platform's schemas. | The casual form of R3, technical fluency, which the dossier does not grade (F3). Casual register is still scored. |
| D3 | "What does a good week look like for you?" | EXP | [generic] | Answer with the week's work in plain terms, in your own words, and keep it to what you did. No pitch; a short, accurate answer is the scoring here. | A rapport question that needs no claim; it tests economy. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's run a roadmap for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); the title acknowledgment is sourced to the dossier's prohibited claims | Pause, then restate the question in your words. Answer with the acknowledgment and V1 at its own scope; the case is the integration work, not the title. Hold through two follow-ups by returning to V1 and the ramp plan. Concede specifically: "On roadmap ownership, I would need to ramp." Never fold to "I can run the roadmap." | The pressure version of A1's bridge, with hold-then-concede structure. |
| E2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: say which of the stages in V1 you did yourself and which were shared. Do not claim a share you cannot name. | Attribution pressure on the headline figure. The honest answer is the stage list in your own words. |

### Coverage

| Requirement or responsibility | Questions |
|---|---|
| R1, 3+ years product management | A1, A2, E1 (limit in F1) |
| R2, shipped API or platform products | C4 |
| R3, technical fluency: API docs, schemas | D2 |
| R4, stakeholder management | A3, B3, C5 |
| R5, agile delivery experience | B2 |
| Own the roadmap for the partner-facing platform | A1, A2, B4, C3 |
| Define and track adoption metrics | B1, C3 |
| Run discovery with integration partners | B1 |
| Write specs and drive delivery with two squads | A3, B2, B3 |

Session total: 19 questions across five personas.

## Reverse questions

Ask these, in this order. Lead with the first if the interviewer asks whether you have questions.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it tests the decision-authority unknown the dossier records, and it tells you whether the role is the one you think it is.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the dossier names adoption as a responsibility with no baseline; you need that number before you accept.
3. **"What would a strong first 90 days look like for someone coming in from integration delivery?"** Why it lands: it turns the bridge into a ramp plan the interviewer has to answer, and shows you know where the limit is.
4. **"Where do the two squads and partner-facing needs most often disagree on API changes, and who settles it?"** Why it lands: it probes the seam and the decision owner without assuming either.
5. **"Which current squad commitment is most at risk this quarter?"** Why it lands: it asks about delivery reality for a role that is named to drive delivery.

No interviewer profile exists, so no reverse question ties to their career path. A name would allow one.

## Sources

- **Provided:** `tuesday-dossier.md`, job-underwriter, dossier_version 1.1, generated 2026-08-14. Consumed sections: `role_profile` (satisfies the JD tier), `handoff_to_mock_interview` (verified evidence V1 to V3, uncertain areas, likely objection, risks, employer questions, prohibited claims). `decision` read as context only. Not in the dossier: `evidence_map` and `risk_register` detail, so R2 to R4 are not graded here.
- **Dossier age:** generated 104 days before today (2026-11-26). If the posting has changed since, the requirement quotes and the fit snapshot need re-checking.
- **Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**
- Queries sent, all refused by the host's search permission, not retried:
  - "Quartzline company values": refused
  - "Quartzline interview process product manager": refused
  - "Quartzline platform APIs partners news": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Refused. Would have moved the values cheat sheet, which applies only if a values-style round is detected. No loop source establishes one, so no cheat sheet is included. |
| 2. Quartzline interview process, product manager | unavailable | Refused. Would have moved the loop structure and persona weights. Weights here rest on the hiring-manager prior, not this company's documented loop. |
| 3. Quartzline strategy / recent news | unavailable | Refused. Would have moved the CO bank. No CO question is in this pack. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative product manager JD | skipped | The dossier's `role_profile` fixes the requirement lines. |

No loop source was found, so the archetype fallback applies: this is the generic archetype, which assumes no values-style round.

## Upgrade menu

- The hiring manager's name → persona weights from their public footprint, and a tailored reverse question.
- Search permission granted, or Quartzline's values page and interview-process page pasted → a values cheat sheet if a values round is documented, the loop structure, and a CO bank for the current strategy.
- The current posting text → confirms the requirement quotes; the dossier is 104 days old.
- A list or record of the 30+ integrations → C1 and C4 would rest on a count you can point to.
- A refreshed dossier with R2 to R4 graded by the underwriter → F2 to F4 would move from this pack's reading to the underwriter's grading.
