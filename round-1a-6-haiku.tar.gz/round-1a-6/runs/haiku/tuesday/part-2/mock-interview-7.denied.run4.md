Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-7-denied-68d82afc/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has no company research. It rests on your JD and your background only.

The biggest prep item is the two-title question. Your calendar experience covers one main title, so expect "why should we trust you with two?" (question B1). Practice the hold, and be ready to say plainly what you haven't run. The pack also lists two gaps you stated yourself, leading a team and in-app purchases, with a plain line for each.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your hiring manager, or is someone else in the room? The answer reweights every bank.
Did the recruiter mention focus areas, or a deliverable such as a take-home or a presentation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer, interview prep pack

Role: Live Operations Producer, Saltmarsh Games (mobile studio, about 350 people)
Interview: 60 minutes, Friday, with Tobias Wrenfield, Head of Live Operations
Relationship: not stated. Built as a hiring-manager round, which is an assumption (see the persona table).
Research: none returned. Every web search was refused in this session. The pack rests on your JD and your background.

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: a stated requirement of the role
- **CO**: company and strategy knowledge (none built; no research returned)
- **CASE**: a live problem from the role, asked as a decision

The guidance is scaffolding, not a script. Answer slots are instructions for the interview. They are not questions to you, and they ask for no reply here.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your message says one title, and content drops rather than live events. Keep the words at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two titles make a probe on a second title likely. If you planned or shared a calendar across more than one title, say which and what you decided; if you did not, say so and stay with the one title. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message, touches QA only) | low | [inferred] | discovery | Your material is silent on coordinating design, art, engineering or community. Answer slot: if you coordinated any of those teams on an update, say which and what each needed from you; if you did not, say so plainly and say how you would start. If leading comes up, your words: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning KPIs and a review. Keep the words at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs those were, say which and why; if someone else set them, say so. If you ran a review after an event, say what it covered; if not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap, but a checklist with no inspected copy behind it, so expect a probe. Say it in the quote's terms: "I wrote the release checklist, and QA still uses it." |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years clears the length requirement. Your message does not call the puzzle game live-service; the nearest sentence is the content drops. Words: "4 years as an associate producer at a puzzle-game studio." Add no genre or title count you did not state. Answer slot: the JD's live-service line makes a probe likely. If the associate role carried producing duties on a live title, say which; if not, say what your role did. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Your strongest row. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on how that calendar was built; the answer slot sits in A1. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; reword only it: "I presented the monthly retention numbers to the studio head." Your material gives no figure and no method, so add neither. Answer slot: if you worked a retention number out yourself, say how it was counted, in your own words; if you only presented numbers you were given, say so plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | A written artifact that a QA team still uses reaches the requirement. It is one artifact, so the interview will test the rest live. |
| F9 | [generic] In-app purchase monetisation on a live-events calendar; a role-family pattern, not a JD line | "Never led a team, and never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Stated absence, and no JD line raises it, so it gets no answer slot. Words, if it comes up: "I haven't worked on a game with in-app purchases." |

## 3. Persona table

Weights below are a hiring-manager prior. Tobias Wrenfield's title suggests the role, not the relationship, and no interviewer footprint was read, so no interviewer signal adjusts them. Depth follows weight: top personas get 5 questions, mid-weight 3, low-weight 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | Live problems on the two-title calendar and the post-event review | High. A hiring-manager prior; the JD's first and third lines are plans, not records | Clarify, then structure: objective, segments, approach, metrics, risks | 5 (A) |
| Skeptic | The two-title gap, team coordination, leading, in-app purchases | High. F1, F2 and F9 are the largest gaps, and the JD asks for two titles | Hold the honest scope, name the gap plainly, bridge with a plan | 5 (B) |
| Data-Driven Prober | Retention numbers, KPI choice, how a number was counted | Medium-high. F3 and F7 are the only metric evidence, and it has no figure in it | Say what you know of the counting; say plainly what you do not | 3 (C) |
| Pressure | "Why you over someone who has led a team"; "how much of that was you" | Medium. A composure test for someone moving up from associate level | Pause, restate, hold two follow-ups, concede specifically | 3 (D) |
| Conversational | An opening walk-through; a casual question about live operations | Low-medium. The biography is scored even when it is asked casually | A 90-second arc, using only sentences you gave | 2 (E) |
| Values/Behavioral | Not weighted. No loop source names a values round, and no archetype fallback is assumed | Zero weight for now. A values round would change this | None built | 0 |
| Peer Evaluator | Not weighted. The relationship is assumed to be a hiring manager | Zero weight for now | None built | 0 |

## 4. Question banks

Session total: 18 questions. Provenance sits before the guidance because the sentences a row may draw on are fixed first.

### Bank A: Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The two titles' live calendars are yours from next month. Walk me through your first two weeks." | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify first: what each title's calendar holds now, what QA signs off, who the four teams are. Then objective, approach, metrics, risks. Say which decision you would take in week one. Makes no claim about your past. | A live problem on the JD's first line. Generic in pattern, so it asserts nothing about your history. |
| A2 | "A live event is nine days out, and design wants a change the release checklist does not cover. What do you do?" | CASE | [grounded] "manage the release checklist with QA" (JD) | Structure: what the change touches, what QA must re-check, who decides, whether the event slips. Say the first decision you would make. Makes no claim about your past. | Tests coordination with QA and design under time pressure. |
| A3 | "Sketch the post-event review for an event that missed its retention target. What do you look at first?" | CASE | [grounded] "own the post-event review and the KPIs it reports" (JD) | Clarify the target's definition and its baseline before any cause. Then segments, the event's mechanics, timing, and what goes in the report and to whom. Name the one metric you would not yet trust, and why. | The JD's third line as a live problem. |
| A4 | "Which KPIs would you report on every event, and which would you drop?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name three KPIs, say what each tells you about an event, and say which you would drop and why. Speak to the decisions the numbers drive. Makes no claim about your past. | KPI judgment at the role's altitude; the answer is reasoning, not history. |
| A5 | "Your studio runs two titles on one calendar. How do you stop them colliding?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name the shared resources: QA, art, engineering, community. Propose one calendar owner, freeze windows and a rule for conflicts. Say what you would check first. Makes no claim about your past. | Scales the calendar to two titles without asserting you have run two. |

### Bank B: Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran one title's calendar. Why should we trust you with two?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Then say, as a plan, what you would check first on a second title. Answer slot: if you have run or shared a calendar across more than one title, say which, in your own words; if you have not, say so plainly. Hold through two follow-ups by returning to the one title you ran. Concede plainly that a second title is untested, if it is. Never add a second title to the story. | **The highest-ROI prep in this pack.** It will come in some form, and F1 is where it lands. A non-defensive hold changes the interview. The JD scores the first requirement. |
| B2 | "Describe one update where you had to coordinate other teams. Which teams, and what did each need from you?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Open prompt. Answer slot: if you coordinated any of those teams on an update, pick one, name each team and what it needed from you; if you did not, say so plainly and name the nearest thing your material carries: the release checklist QA still uses. Say "I haven't led a team" only if leading comes up. | Checks F2, the requirement with the least evidence. The honest answer is the one a probe rewards. |
| B3 | "Walk me through how a release gets from the checklist to live. Who signs off, and where do you sit?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message); [grounded] "manage the release checklist with QA" (JD) | Story from the quote: "I wrote the release checklist, and QA still uses it." Answer slot: if you ran or signed off any stage of the release, say which; if QA owned the sign-off, say so and say what you did with the checklist. Do not describe a sign-off you did not run. | Tests whether "manage" is yours. F4 has no gap, but the probe is likely. |
| B4 | "Tell me about a time numbers you reported went the wrong way." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Story map from the quote's beats only: the monthly presentation to the studio head. Answer slot: if a number you presented turned out wrong or was questioned, say what happened and what was yours in it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the monthly presentation, in those words. | The JD's KPI line raises the theme. This is an open prompt, so it supplies no event. |
| B5 | "What's the gap between your background and this role, in your own words? How long before you are at full speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" (your message) | Name the two gaps in your own words: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Then say how you would close each, as a plan. Give no time estimate you cannot back; say what you would check in the first month. | Your two stated negatives are the Skeptic's easiest probes. A plain acknowledgment with a plan beats a bluff. |

### Bank C: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you worked a retention number out yourself, say how it was counted, in your own words, and the assumption you would defend least. If you only presented numbers you were given, say so plainly, and say who set the method if you know. The pack supplies no method. | F7. The question's premise is the quote's presentation only. The slot admits the number was not yours to count. |
| C2 | "Which assumption behind the retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | If you did not set the method, say so first. Then say what you checked, if anything, before you presented the figures. If you checked nothing, say so. | F7. No figure was given, so the honest branch carries the answer. |
| C3 | "Tell me about a content drop you measured afterwards, and what you compared it against." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Story map from the quote: the weekly drops on the main title over two years, in those words. Answer slot: if you measured any drop afterwards, name what you compared it with. If you did not, say so, and say what the calendar's record does show. | F6. An open prompt on the JD's KPI theme; it supplies no event. |

### Bank D: Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause, then restate: the JD's verb is "coordinate". Hold: "I haven't led a team." Then the coordination you can describe, in your own words, from the release checklist and the calendar. Hold through two follow-ups. Concede specifically what a lead carries that you have not had. Never fold on the calendar. | A composure test on the gap you stated, which a Pressure interviewer will find. |
| D2 | "That checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: "I wrote the release checklist, and QA still uses it." Answer slot: if others edited or agreed it, name who and what they changed; if you wrote it alone, say so. Hold through two follow-ups. Never widen "wrote" into "owned the process." | F4, a headline line. An attribution test. |
| D3 | "Two years on one calendar: how much of its shape was yours, and how much was set above you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold: "I ran the weekly content-drop calendar for our main title." Answer slot: if priorities were set above you, say which, and what you still decided. If none were, say so. Concede plainly where your share was narrower than the title. | F6. Honesty under pressure, rehearsed. |

### Bank E: Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc, in order: the puzzle studio, the content-drop calendar, the checklist, the retention presentation. Say why live operations on mobile, in your own words. No motive is supplied here. | A casual opener is still scored. The arc uses only sentences you gave. |
| E2 | "What are you playing on your phone, and what does its event calendar do well?" | JD | [generic] | Name one game you play and one thing its calendar does well, in your own words. Do not describe a title's content you have not checked. Ask one question back about its cadence. | Light touch on the JD's mobile focus. The answer is judgment, not a claim about your history. |

## 5. Reverse questions

No interviewer profile was read, so none is tied to Tobias's own path.

1. "What does success on the two calendars look like at six months?" Why it lands: it shows what the bar is before you are measured against it.
2. "Who owns the post-event review today, and what does it feed?" Why it lands: it tests the JD's own line and shows you read it.
3. "How do design, art, engineering and community get to a calendar decision now?" Why it lands: it shows you plan to coordinate, not to lead.
4. "Where does the release checklist sit with QA today, and who maintains it?" Why it lands: it checks F4 against the current process.
5. "What is the hardest call this role makes in a normal month?" Why it lands: the answer shows the real trade-offs, which you can then speak to.
6. "What would you like the first 90 days to have changed?" Why it lands: it closes by asking for a plan, not a past.

Requirement coverage (each JD line to its question IDs):

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A5, B1 |
| coordinate design, art, engineering and community teams on each update | A2, B2 |
| own the post-event review and the KPIs it reports | A3, A4, B4 |
| manage the release checklist with QA | A2, B3, D2 |
| 3+ years producing live-service games or apps | B5, E1 |
| experience running a content calendar | C3, D3 |
| comfortable with player-retention metrics | C1, C2 |
| clear written communication | D2, none further; F8 has no gap, and D2 tests it |

## 6. Prohibited claims

Each entry names its basis and its honest form. Nothing in the banks, the reverse questions or the drill asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two mobile titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Analysis, not words for you: the material says one title and content drops. |
| Owned the post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote: "Presented the monthly retention numbers to the studio head." Analysis: presenting is not stated as owning. |
| Produced live-service games for four years | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." Analysis: live-service is not named in the material. |
| Led a team | Negative you stated (F9) | Plain acknowledgment: "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated (F9) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## 7. Sources

- Provided documents: the JD text and your background message.
- Searches sent: four. All four were refused by the session's permissions, so none returned a result. They are listed here as refused, and I did not retry them.
  - "Saltmarsh Games values" (refused)
  - "Saltmarsh Games interview process live operations producer" (refused)
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations" (refused)
  - "Saltmarsh Games mobile studio news" (refused)
- Research tier: L1, searches 4 of 6, fetches 0 of 2; user links read 0.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, section 10: not built. No values in hand, and no values-style round detected. |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure: no loop source. Persona weights are the hiring-manager prior, not a documented loop. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Grounding brief and CO bank: not built. CASE questions are generic, not tied to current strategy. |
| 4. `Tobias Wrenfield` with company | unavailable | Interviewer read: absent. The reverse question tied to his path: absent. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## 8. Upgrade menu

- Web search allowed for targets 1 to 4 → the values cheat sheet, the loop structure, a grounding brief on current strategy, and a reverse question tied to Tobias's career path.
- Whether Tobias is your hiring manager, and any focus areas or deliverable the recruiter named → the persona weights are recomputed, and any named deliverable gets its own build section.
- Whether you have run or shared a calendar across more than one title → F1 and B1 move from a plain answer slot to grounded material.
- Who wrote the release checklist, and who signed off releases → D2 and B3 get a sourced answer.
- Whether you coordinated any of the four teams on an update, in your own words → F2 moves from discovery, and B2 gets a story.
- Whether you worked out a retention figure yourself → C1 and C2 get the honest form they need.
- A CV or a link to a title you worked on → F5 and the live-service claim get verified evidence.
- A `tuesday-dossier.md`, if you have one → its verified evidence and prohibited claims would sharpen the banks.
