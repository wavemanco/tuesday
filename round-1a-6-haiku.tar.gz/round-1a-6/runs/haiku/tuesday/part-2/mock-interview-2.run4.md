Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md` (path above). I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so nothing about Atlas Freight comes from outside your posting. The pack's Sources section lists what didn't run.

The pack's main finding is that your evidence is strongest on the floor and thinnest on scale and reporting:

- **Biggest gap:** the posting wants four sites and twelve supervisors, and your material shows a shift manager role over three supervisors. Question S1 is the one to rehearse most. Hold the three-supervisor scope as it is, name what you'd put in place first, and concede the scale gap plainly.
- **Power BI:** you said you've never used it. The pack gives you one plain line for that ("I've never used Power BI.") and a plan for learning it, nothing more.
- **The 40% mis-pick reduction** is your only headline number, so expect probes on how it was counted and how much of the pick-path redesign was yours. Practise saying what you did, not what the team did.

Say the word and I'll play the Skeptic on S1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

Built for a hiring-manager round. That is an assumption: your note didn't say who you're meeting or how many sessions there are. The round type is still open (see the question in the message that presents this pack).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words.

Type key:
- **VAL**: behavioral / values. None written: no values-style round is detected for this company.
- **EXP**: experience deep-dive. Whether what you did survives a probe.
- **JD**: the role's listed requirements.
- **CO**: company and strategy. None written: company research did not run (see Sources).
- **CASE**: a live problem from the role.

"Answer slot" lines are instructions for the interview. They ask nothing here. Where a slot says "say so", the honest answer is a real option, not a failure.

## Fit snapshot

Requirements are quoted from your posting. Your evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows a shift manager role over three supervisors, with no site count. Say what you run now as it is. Answer slot: if any of your work covered more than one site, say which, and what your part was; if none did, say so, and say how you would take on four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is an accuracy measure, not on-time or cost per shipment. Bridge at its own scope: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say what it was and what moved it; if you did not, say so, and say the link you would check first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says three supervisors. Answer slot: if your leadership has covered more than three supervisors, say how many and over what; if not, say so, and describe how you would organise twelve. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid Excel" is a skill claim. It doesn't show reporting built in Excel, so the bridge should not stretch it. Answer slot: if you built regular reports in Excel, say what they tracked and who used them; if you used Excel for analysis but not regular reporting, say that. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past, for example the first report you would rebuild in it. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | A length of experience is not a gate, so this row is graded like the others. Your material shows seven years in operations and a current leadership role, but not when the leadership began. Answer slot: say when you first led people in operations and what that covered; if it has been under five years, say so, and say what the seven years covered. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap; the quote reaches the requirement. Limit: the certificate has not been inspected, so expect a probe on what you applied it to. Words: "green belt certified." |

## Prohibited claims

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: your material shows a shift manager role over three supervisors, with no site count. |
| Led twelve supervisors | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" |
| Drove on-time performance and cost-per-shipment down | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." The pack's observation: the material names an accuracy measure only. |
| Designed the peak-season surge plan | Inflated form of your "ran" | "ran the site's peak-season surge plan two years running" |
| Built Excel reporting for operations | Inflated form of F4 | "solid Excel," at its own scope. The pack's observation: reporting built is not in the material. |
| Built reporting in Power BI | Negative you stated, F5 | "I've never used Power BI." No answer slot. |

## Persona table

No interviewer profile exists, so weights come from the hiring-manager prior and the posting. No loop source established this company's process, so the weights are a pattern, not this company's documented loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the requirements your material doesn't reach: four sites, twelve supervisors, Power BI, five years of leadership | High. Three of the posting's requirements sit above your quotes (F1, F3, F5), and a hiring manager buying capability looks there first. | Hold the three-supervisor scope as it is, name the first thing you would put in place, and concede the gap specifically. |
| Case / Strategist | Live problems on the four terminals: on-time slipping, cost per shipment rising | High. The first two requirements are operational, and a hiring manager tests judgment with a live problem. | Clarify, state the objective, split the problem, pick an approach, name the measure, and say the risk. |
| Data-Driven Prober | Asks how the 40% was counted and what it is sensitive to | Medium to high. The 40% is the only headline metric in your material, and headline numbers draw probes. | Say what was counted, name the assumption you would defend least before they do, and say plainly what you don't know. |
| Pressure / Stress | Time-boxed challenges on how much of the result was yours | Medium. Thin areas invite "how much was actually you." | Hold the quoted claim through two follow-ups, then concede the specific part that is not yours. |
| Conversational | A warm opener and a "walk me through" | High at a screen, low at a hiring-manager round. | Use a 90-second arc built only from your own sentences. |
| Peer Evaluator | Seam and credit questions | Low for a hiring manager. Rises if the round is a peer. | Reciprocity framing: what you bring their team, not only what you need. |

## Question banks

### Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A terminal's on-time performance has slipped for three weeks. What do you do in the first week?" | CASE | [generic] | Clarify what slipped and against which target. Split the miss by shift, lane and carrier before you act. Name one action and the measure that would show it working. No claim about your past. | The JD's on-time line raises it. Generic because it is a pattern for the problem, not this employer's data. |
| C2 | "Cost per shipment is rising across four sites. Where do you start?" | CASE | [generic] | Break cost per shipment into its parts, find which part moved first, and say what you would need from the site leads before deciding. No claim about your past. | The JD's cost-per-shipment line raises it. |
| C3 | "You would lead twelve supervisors across four sites. What is your first month?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | This is a plan, not history. Start from what you run now: say what you would set up first for the twelve, what you would leave alone for now, and one check on the four sites in week one. Answer slot: if you have led more than three supervisors, say so and how; if not, say so, and do not claim the twelve. | F1 and F3 are the requirements this tests. The plan is the answer; the guidance claims no experience of twelve. |
| C4 | "Which Lean tool would you reach for on a site where on-time is slipping, and what would you measure first?" | JD | [grounded] "green belt certified" (your message) | Name one tool and the waste it targets, the first measure, and how you would check it over two weeks. Then the honest branch: say what you have applied the green belt to. If you have not applied it yet, say so and describe the first use. | F7 and the JD's Lean/Six Sigma line. |

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You run three supervisors today. What changes at twelve, across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold: say the three-supervisor scope as it is, then name the one thing you would put in place first for twelve across four sites, as a plan. Follow-up 1 ("what would you do with an underperforming site?"): return to what you would set up first. Follow-up 2 ("why should we bet on you?"): concede the scale gap specifically, then say what you would do to close it. Answer slot: if you have run anything across more than one site, say which and what your part was; if not, say so, and do not claim it. | F1 and F3 are the two requirements above your quotes, and a Skeptic finds the scale gap first. Deepest rehearsal because no quote answers it. |
| S2 | "The role builds reporting in Power BI. Have you?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I've never used Power BI." Then a plan: how you would learn it, and the first report you would rebuild in it. No claim about Power BI work. | F5. The negative is one you stated, so it can be said as is. |
| S3 | "Five years of operations leadership is required. Where is yours?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Give the seven years as your message states them, then the leadership piece. Answer slot: say when you first led people in operations and what it covered; if it has been under five years, say so and say what the seven years covered. | F6. Low confidence, so the answer is the slot, not a stronger claim. |
| S4 | "Why this role, and why now?" | Skeptic | [generic] | Give your own reason in your own words, and tie it to the scope of the role that is true for you. No claim about your history. | The material says nothing about your reason, so the answer is yours to give. |

### Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number: say what was counted and how you counted it, in your own words. Then name the assumption behind the figure that you would defend least, before they do. Answer slot: if you redesigned the pick path yourself, say which steps; if the redesign was someone else's, say what you did within it, or say you were not involved. | F2. The figure is the claim; the method is yours to state, not supplied here. |
| P2 | "What is that figure sensitive to?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the factor you think moved the figure most, in your own words. If you did not measure what moved it, say so. | Defend-the-number follow-up; the pack names no factor for you. |
| P3 | "The role is measured on on-time performance and cost per shipment. What have you measured that moved either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name what you tracked and what moved it. Answer slot: if you tracked on-time or cost per shipment, say what and what moved it; if you did not, say the mis-pick measure is the nearest you have, and say what you would check first. | F2. The probe lands on the gap between an accuracy measure and the two the JD names. |
| P4 | "Show me how you would build the daily terminal report in Excel." | JD | [grounded] "solid Excel" (your message) | Walk through the report's columns, where its data comes from, and how often it refreshes. Answer slot: if you have built regular Excel reporting, say what it tracked and who used it; if you used Excel for analysis but not regular reports, say so. | F4. The JD names the report, and the quote doesn't show one built. |

### Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede: say which part of the redesign was yours, in your own words, and hold it through two follow-ups. Concede specifically where credit was shared. Never fold to "it was all me." Answer slot: if the redesign was yours in part, say which steps; if not, say so, and say what you did within it. | F2. The probe tests attribution, and the honest answer is the rehearsal. |
| X2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "green belt certified" (your message) | Pause, restate the question, then answer in sixty seconds from what you hold: the seven years, the current role, the green belt. Hold it. Answer slot: if you have led at more than three supervisors or across more than one site, say so; if not, concede the scale plainly. | F1, F3, F6. The material does not show four sites or twelve supervisors, so that words are a slot. |

### Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | A 90-second arc in that order: the seven years, the current role, the surge plan, the green belt. Use your own words and add no step. | The four sentences are the spine; the arc adds no claim. |
| V2 | "What are you playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Answer with what you apply now. If the answer is only the certificate, say so, and name the one tool you would try first. | F7 and the JD's Lean/Six Sigma line. Casual, but scored. |

### Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between operations and the teams that depend on it, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not facts about these teams: who decides, how disagreements are escalated, what you would share each week. Do not claim a dispute happened. | Peer-style seam probe; no premise about this company. |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you name the others who did the work. If your material has an example, give it in your own words; if not, say so and give the rule you use. | Peer credit probe. |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own daily terminal operations across 4 sites | S1, C3 |
| Drive on-time performance and cost-per-shipment down | C1, C2, P3 |
| Lead a team of 12 supervisors | S1, C3, X2 |
| Build reporting in Excel/Power BI | P4, S2 |
| 5+ years operations leadership required | S3 |
| Lean/Six Sigma a plus | C4, V2 |
| Headline metric: 40% mis-pick reduction | P1, P2, X1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does on-time performance look like across the four sites today, and which one is furthest from target?" | It shows you read the job's own measure first. |
| "How is reporting built now across the sites, and who owns the Power BI work, if anyone?" | It tests what you would inherit and what the Power BI gap would touch. |
| "What did the last peak season's surge plan get right, and what would you change?" | It links to your own surge plan without claiming it was yours to design. |
| "What would make the first 90 days a success for this role?" | The answer gives you the scoring criteria. |
| "How many supervisors would report to the twelve, and how are the four sites split between them?" | It checks the scale you would be taking on. |

No interviewer profile exists, so no reverse question ties to an interviewer's path. A reciprocity question is added only if the round turns out to be a peer round (see the upgrade menu).

## Sources

Provided documents: your message, which quotes the posting and gives your background. No CV file was provided, so every evidence quote comes from your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2. All three searches were refused by a permission error from the session; none was retried.

Queries sent, all refused:
- "Atlas Freight values regional logistics"
- "Atlas Freight interview process operations manager"
- "Atlas Freight logistics news strategy 2026"

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. Not written: no values-style round is detected without a loop source. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure. Persona weights are the hiring-manager prior, not this company's loop. |
| 3. Atlas Freight strategy / recent news | unavailable | CO questions. None written, so the pack has no strategy-grounded question. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative operations manager JD | skipped | Your posting fixes the fit snapshot and the JD-tagged questions. |

Nothing about Atlas Freight in this pack comes from outside your posting and your message. Its values, interview process and current strategy are not established.

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Your recruiter's note on focus areas or the process → coverage of any stated focus, and the loop structure, which research could not establish
- Atlas Freight's values page, pasted → a values cheat sheet, if a values-style round is named
- Whether the round is your future manager or a peer → persona weights recomputed; for a peer, a reciprocity question and the peer questions move up
- How many years you have led people in operations, and when that began → F6 moves from discovery to a stated fact, and S3 gets a firm answer
- Your green belt certificate or project record → F7 moves from medium to high, because the artifact can be inspected
- The surge plan's figures, in your own words → the defend-the-number questions get your numbers to rehearse
- Hours you have before the interview → a prep-triage section, prioritized to that time
- A deeper research pass, if web search is enabled for this session: up to 6 more searches and 2 more fetches, several more minutes. It would add a strategy brief for the CO questions.
