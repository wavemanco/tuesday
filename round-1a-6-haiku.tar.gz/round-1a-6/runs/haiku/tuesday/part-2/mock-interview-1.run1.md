Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-1-denied-fff74852/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer round, since you described Dan as a peer. Web search was refused in this session, so the research rests on your research note and the material you gave me. The Sources section lists the three refused searches.

The pack has 21 questions across seven interviewer personas, weighted for Dan's profile. The Data-Driven Prober carries the most weight, then the Peer Evaluator, with the pricing background tilting the case questions. Every question has a type, answer guidance, and a rationale, and the fit snapshot quotes your background only where it is in your notes.

Three things to know before you rehearse:

- **Highest-ROI prep:** the ~$400M uplift. Dan is data-driven, so he will ask how it was counted and how much was yours. The wording you gave is "credited with," and the pack holds you to that. Questions A1, B2 and E1 cover it.
- **Quota-setting is the clearest gap.** Your notes say you have no classic sales-ops or quota-setting experience, and Dan's domain is sales strategy. D1 and E2 cover it, and the pack says to name the gap and give a plan, not claim quota work.
- **Partner-motion design is a required JD line.** Your revenue model is adjacent, not the same thing. B1, D2 and F4 cover it.

Dan's pricing and monetization career and his "relentlessly data-driven" profile line up with the persona weights. The reverse-question bank has six questions, including one tied to his startup chapter.

Is the full JD text available? The highlights don't show any location, travel or work-authorization terms. If the full posting has one, paste that line and I'll add the gate row.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy (peer, same VP)
**Round:** single 60-minute conversation
**Candidate:** Priya

## How to use, and the type key

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script. Say it in your own words, and stop where the scaffold stops.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values fit: whether past behavior shows a published value, or the behavior the interviewer's persona looks for |
| EXP | Your own experience: whether the claims on your record survive scrutiny and say exactly what you did |
| JD | The listed requirements: can you do the job as posted, including the gaps |
| CO | Company and strategy knowledge: whether you think at Northwind's altitude |
| CASE | A live problem from the role, worked out loud |

Dan sets the order. This map shows which bank you are in at each point, so no question surprises you.

| Minutes | Likely bank | Question IDs |
|---|---|---|
| 0 to 5 | Opening and biography | F1, F2 |
| 5 to 20 | Your record, tested | A1, A2, A5, B2, E1 if pressed |
| 20 to 40 | Strategy and live problems | C1, C2, C3, A3, B4 |
| 40 to 52 | Seams, gaps and disagreement | B1, B3, A4, D1, D2, D3, E2 |
| 52 to 60 | Your questions | R1 to R6 |

## Fit snapshot

The requirements are quoted from the JD highlights you supplied. The evidence is quoted from the coach's notes, which are your background as you gave it. The notes are not a CV, so every row is medium or lower until an artifact is named (see the upgrade menu).

No gate row: the highlights name no location, travel, schedule or work-authorization term. The one question at the end asks about that.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | The notes show a revenue model built and used in negotiations. They do not show a go-to-market for a product line. Say the model in those words. Answer slot: if you owned any part of a product line's go-to-market, name the part and how you decided it; if you did not, say so plainly and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | low | [inferred] | discovery | Setting volume targets is adjacent to finding whitespace, and the notes do not show you looked for it. Answer slot: if you have identified under-served volume across land, adopt, expand or renew, say where and how you found it; if you have not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | none | The quote reaches the requirement in role-relevant terms. "Skilled" is a self-assessment with no artifact named, so expect a probe. Name the tools, not the adjective. Answer slot: if you have run an analysis yourself in either tool, name it; if not, say so. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Partner economics are adjacent to designing a partner motion. The notes show a model, not a motion you designed. Answer slot: if you designed how partners came into a sale or a launch, say how; if the model was as far as your partner work went, say that and what the model fed. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | The quote reaches cross-org influence in other terms. Use the notes' words: set targets with cross-org consensus. Add no stakeholder reaction the notes do not describe. Answer slot: if there was a disagreement you had to resolve, say what it was and how it landed; if there was none, say so in your own words. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (the coach's notes) | low | [inferred] | transferability | Daily use of AI tools is adjacent to AI experience in building or launching it. The requirement is a plus, not a gate. Say what you use the tools for, in your words. Do not describe building AI features unless you did. |
| F7 | [generic] Quota and sales-capacity target setting, expected of a sales-strategy peer; no JD line | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | capability | The absence is stated in your notes, so the plain words are the notes' own: "No classic sales-ops or quota-setting experience." Say them in your own words. Then a plan, as a plan: what you would check first to set a target, and who you would ask. Never claim quota work. |
| F8 | [generic] A stated revenue result for a GTM role; no JD line | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No gap: a credited figure is on the notes. Keep the wording as credited: you proposed the change, and the uplift is credited to it. Expect a defend-the-number probe; the counting method is yours to state, or to say you do not know it. |
| F9 | [generic] Pace of a smaller, faster B2B company, from the interviewer's startup chapter (the coach's notes) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Large-company product strategy transfers in scope; pace is not shown by the notes. Answer slot: if you made one fast decision inside a large company, describe it in your words; if none comes to mind, say so and say how you would set your first 30 days. |

Seven rules the table follows: confidence, provenance and gap type each hold one token; the evidence column holds only the notes' own sentences; requirements are quoted from the highlights only; gap language sits in its own column; a gap row carries words from its source or an answer slot; gap types follow the evidence cell; bridges are spoken aloud, so each clause stays inside its quote's scope.

## Prohibited claims

Built here from the fit snapshot, because no dossier was supplied. These are the claims a candidate reaches for under pressure. Nothing in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion | Inflated form of F4 (the JD asks for partner-motion design) | The quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The pack's own observation: the notes say a model, not a motion. |
| Drove the ~$400M ARR uplift | Inflated form of F8 | "proposed a store-surface change credited with a ~$400M ARR uplift". The pack's observation: "credited" is the attribution, and the notes do not say you led the build or its measurement. |
| Set quotas or owned sales targets | Inflated form of F5 and F7 | "set annual volume targets with cross-org consensus". The pack's observation: volume targets, not quotas. |
| Built the analyses that ran the business in SQL and Tableau | Inflated form of F3 | "skilled in SQL/Tableau" |
| Built AI products | Inflated form of F6 | "uses AI tools daily" |

## Grounding brief

Learn-the-vocabulary section, from the research note you supplied. Use these terms as the interviewer's. The note is undated, so its freshness is not established; check it before relying on the framing.

| Term | Source | How it reaches the pack |
|---|---|---|
| "enterprise expansion" | research note | C3, R4 |
| "AI copilot launch ('Compass')" | research note | B4, R4 |
| "reaching profitability" | research note | C3 |
| "bundling by a much larger platform vendor" | research note | C2, R5 |

## Reading the interviewer

**Career pattern (the coach's notes):** a pricing and monetization spine, with one early-stage-startup chapter.

**Self-description (the coach's notes):** "relentlessly data-driven".

| Implication | What it means for this round |
|---|---|
| Prober up | Every figure you give will be taken back to its assumptions. Know the weakest assumption of each number before he asks. |
| Pricing tilt | Case questions will reach for pricing, packaging and unit economics. That is his native ground, so answer in those terms. |
| Startup chapter | Builder stories land with him. Expect scrappiness probes about big-company pace (D3, F9). |
| Shared domain | Monetization is a shared professional domain: your partner revenue model is a monetization artifact. Fair game, once it is your own words. |

**Shared jump:** none. His startup chapter and your move from consulting and consumer tech do not share a career jump, so no reverse question is built on one.

## Persona table

Relationship priors for a peer set Peer Evaluator and Data-Driven Prober as dominant. His profile and the pricing spine move the Prober up to the top weight, and the pricing spine tilts the case questions up.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions (weight) |
|---|---|---|---|---|
| Data-Driven Prober | Reads the record line by line; asks for inputs, denominators and validation | High: his self-description and the peer prior both point here | Know how each figure was counted, and say plainly when you do not know; name the weakest assumption first | A1 to A5 (5, top weight) |
| Peer Evaluator | Seam-splitting between teams; what he needs from you; credit and disagreement | High: the peer prior; the two teams sit side by side | Reciprocity: what you bring his team; propose seam principles, not a seam you have not seen | B1 to B4 (4) |
| Case/Strategist | Live problems from the role: whitespace, bundling, expansion | Medium: pricing spine tilts case questions to his ground | Clarify, then structure in his terms; challenge one premise | C1 to C3 (3) |
| Skeptic | Quiet probing of the gaps: quota, partner design, big-company pace | Medium: F4 and F7 are the gaps a peer will see; the startup chapter adds the pace probe | Rehearse the one predictable objection until it is plain; calibrated candor over bluffing a competency | D1 to D3 (3) |
| Pressure | Interrupts and time-boxes on the $400M figure or the quota gap | Low to medium: likely only where a figure or gap is pressed | Pause, restate, hold the quoted position through two follow-ups, then concede precisely | E1, E2 (2) |
| Conversational | Friendly opener; hot JD topics asked casually | Low: an opener, but scored as casual | A 90-second arc from your own quotes; treat the AI question as scored | F1, F2 (2) |
| Values/Behavioral | Open behavioral prompts; no published values round detected | Low: no values round is detected and no values page is in hand | Selection scaffold ending in its honest branch | G1, G2 (2) |

## Question banks

### Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C1 (JD, CASE); F1 for the record |
| identify whitespace across land/adopt/expand/renew | A3 (JD, CASE); C3 (JD, CO); F2 |
| run independent analysis in SQL and Tableau | A4 (EXP, JD); F3 |
| partner-motion design experience required | B1 (JD); D2 (JD); F4 |
| strong cross-functional influence | B3 (JD); F5 |
| AI experience a plus | F2 (JD, casual); B4 (CO); F6 |
| Quota-setting (role-family, no JD line) | D1 (JD); E2 (JD); F7 |
| Headline metric (no JD line) | A1; B2; E1; F8 |

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with what you proposed, in those words. Then how the uplift is credited to it, in your words. Answer slot: if you know how it was counted, name the counting method and the input it is most sensitive to; if you do not know, say so plainly. Name the assumption you would defend least before he does. Do not say you drove the change or its measurement unless you did. | F8 is the figure's row. A data-driven peer tests the one headline number first, and "credited with" is the wording most likely to be stretched. This is the highest-ROI prep in the pack. |
| A2 | "Which input to that partner revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name what the model was for, in those words. Answer slot: name the input you would defend least, what it is sensitive to, and which inputs were yours to set. If you did not set them, or do not know how they were sourced, say so. | F1 and F4 both rest on this model, so a prober walks to its inputs. Naming the weakest assumption turns a gotcha into a credibility gain. |
| A3 | "How would you size the whitespace across land, adopt, expand and renew for a new product line? What do you check first?" | JD, CASE | [generic] live problem; no claim about your past | Clarify the buyer and the denominator first. Define the four motions as stages with an entry and an exit. Pick one measure per stage and name the assumption you would test first. Use the unit of value for the pricing angle. | Covers the whitespace requirement, where F2 is a discovery gap. A prober scores the denominator. Generic because it asks about a problem, not your past. |
| A4 | "Tell me about an analysis you built yourself in SQL or Tableau that changed a decision. How did you check it?" | EXP | [inferred] "skilled in SQL/Tableau" | Pick one analysis you actually ran. Give the question, the data and the check. Answer slot: if none changed a decision, say so and give the nearest one you did run. The quote is low confidence, so state the tools, not the adjective. | Open prompt: the theme comes from the JD's SQL and Tableau line. F3 is low confidence, so the pack coaches it as a clarify note and does not assert it. |
| A5 | "The annual volume targets you set: what were they measured against?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the targets, the orgs and how consensus was reached, in those words. Answer slot: what the targets were measured against, and whether that measurement was yours to set. If you did not track it, say so plainly. Keep them as volume targets; they are not quotas. | F5 is medium confidence; a prober asks for the denominator of any target. The guidance keeps volume targets separate from quota. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner motion design is required for this role. Where would you draw the seam between a partner motion and direct sales, and what happens when we disagree?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Offer seam principles, not a seam you have not seen. Frame reciprocity: what you bring his team. Answer slot: if you have designed how partners came into a motion, describe your part; if the model was as far as your partner work went, say that and what it fed. Then one disagreement you resolved, if you have one; if not, say so. | F4 is the partner requirement; the seam is where a peer tests it. Reciprocity is the peer signal the Peer Evaluator scores. |
| B2 | "How do you handle credit when a result spans teams? Take the store-surface change as the example you know best." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name what you proposed, and who else owned the change, in those words. Do not present the team's work as yours. Answer slot: if credit was contested, say how it was settled; if it was not, say so. | F8 is the figure a peer will test for credit. A peer probes whether credit is shared honestly. |
| B3 | "You set volume targets with other orgs. Who pushed back, and how did it land?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Start with the consensus, in those words. Answer slot: who pushed back, what they argued, and how it resolved. If no one pushed back, say so and describe the process in your own words. | F5 is the cross-functional influence requirement. A peer tests disagreement with equals. |
| B4 | "Compass is the AI copilot launch. Where would you start the GTM plan, and what would you need from us?" | CO | [grounded] research note: "AI copilot launch ('Compass')" | Ask about the launch's first buyer segment as a question, not a fact. Ask what the emerging-products team has committed. Do not describe a Compass plan as if you had seen it. | F6 is the AI plus, asked here as strategy. Shows you know the launch Northwind is making. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the GTM plan for a new product line in our space. What do you need to know first?" | JD, CASE | [generic] live problem; no claim about your past | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud. Challenge one premise respectfully. Pricing angle: how the line gets priced into existing contracts. | Covers the own-GTM requirement. Generic because it is a live problem. |
| C2 | "A much larger platform vendor could bundle a comparable capability into its suite. How would you price and position against that?" | CO, CASE | [grounded] research note: "bundling by a much larger platform vendor" | Clarify whether the bundle is a price, a feature or a distribution change. Ask for Northwind's current price point rather than assuming one. Propose an option that does not match the bundle on price. Name what you would measure first. | The bundling threat is the competitive frame in the research note. Pricing is his native ground. |
| C3 | "Northwind is pushing enterprise expansion and profitability. Which whitespace would you chase first, and what would you need to believe about payback?" | CO, JD | [grounded] research note: "enterprise expansion" and "reaching profitability" | Pick one segment by expansion potential against payback. State the belief about payback as a belief. Use land, adopt, expand and renew as stages. | Covers the whitespace requirement at the strategy altitude. The research note is undated, so check its freshness. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see quota-setting or sales-ops in your background. How would you set targets for a sales team you have not run?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | Say the absence in your own words. Then the plan, as a plan: what you would check first, who you would ask, and what the volume-target work taught you. Never claim quota work. | F7 is the capability gap. A skeptic probes the one absence closest to his own work. |
| D2 | "Partner-motion design is required for this role. Where does your experience stop?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the model and what it was for, at its own scope. Answer slot: where your partner work stopped, in your words, and the first thing you would do to learn partner-motion design. Do not describe a motion as designed. | F4 is a transferability gap. A skeptic asks where the edges are. |
| D3 | "You came from a large consumer-tech company. How quickly would you work at the pace of a 3,000-person B2B company?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Name what changes in pace and what stays. Answer slot: one fast decision you made inside a large company, if you have one, in your words; if not, say how you would set your first 30 days. | F9 is the pace gap. His startup chapter makes a scrappiness probe likely. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change." Hold through two follow-ups. Concede precisely: the credit is an attribution, and the share that is yours is the part you cannot size from here, if that is true. Answer slot: if you know your share, say it; if you do not, say that. Never fold on the proposal itself. | The pressure version of A1 and B2, and the same highest-ROI figure. Hold then concede. |
| E2 | "Sixty seconds: why should we trust a strategist with no quota experience to set our targets?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | Pause. Hold the nearest real thing: volume targets, set with cross-org consensus, in those words. Concede: no quota-setting. Then how you would close that gap in 30 days, as a plan. Never say you have set quotas. | F7 and F5 together. A pressure question tests whether you hold a true position without inflating it. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: the two chapters in those words, then one sentence on why this role. Answer slot: the reason you want this role must be yours; the notes do not give it. | A rapport opener is still scored. Pre-scripted arc from your own quotes. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Name the tools and one task you use them for, in your words. Do not call it building AI features. | F6 is the AI plus, asked casually. The quote is low confidence, so it is coached as a note. |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt from a persona stem; no claim about your past | Pick a time you told a senior person something they did not want to hear: a named stake, the moment you said it, and how it resolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | No values round is detected and no values page is in hand, so this is the persona's behavioral bar, not a published value. Low weight. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] open prompt from a persona stem; no claim about your past | Same scaffold: a named stake, the moment, the resolution. If none comes to mind, say so plainly and give the nearest thing your material does carry. | Same reason as G1. |

## Reverse questions

Six, with a reciprocity question for a peer and one tied to his own path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came through pricing and monetization and spent a stretch at an early-stage startup. Which pricing call from that stretch do you still apply at scale?" | Ties to his own path (pricing spine and startup chapter), turns the interview into a peer conversation, and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer weighs heavily as a preparation signal. |
| R3 | "Where do sales strategy and the emerging-products work currently disagree about the seam?" | Surfaces the friction the partner motion would have to cross, and shows you expect a seam. |
| R4 | "How is the Compass launch expected to change the enterprise expansion motion?" | Uses Northwind's own stated priorities, and shows you know the agenda. |
| R5 | "When the bundling threat shows up in deals, what does the team do today?" | Tests what the bundle threat means in practice, and sharpens C2. |
| R6 | "How will you and the VP measure whether the two new product lines are working in year one?" | Asks for the success measure, which sets what owning the GTM means here. |

## Sources

**Provided material:** the JD highlights (six requirements, quoted in the fit snapshot); the coach's notes (candidate background, Dan's career pattern and self-description); the research note (three priorities and the bundling threat). No dossier. No user links were read.

**Searches and fetches sent:**

- "Northwind Data values operating principles": refused.
- "Northwind Data interview process Senior GTM Strategy Lead": refused.
- "Dan Kovac Director of Sales Strategy Northwind Data": refused.

Web search permission was not granted in this session. The three searches were refused and were not retried. No fetches were sent.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet. Its condition is not met (no values round is detected and no values page is in hand), so nothing in the pack depends on it. Search refused. |
| 2. Northwind Data interview process, Senior GTM Strategy Lead | unavailable | Loop structure. No loop source establishes the loop, so persona weights rest on the peer prior and Dan's profile, not on a documented process. Search refused. |
| 3. Northwind Data strategy / recent news | skipped | The research note you supplied fixes the three priorities and the bundling threat (C2, C3, B4, grounding brief). Its date is not given, so its freshness is not established; the upgrade menu asks for it. |
| 4. Dan Kovac, Northwind Data | unavailable | Interviewer footprint beyond the coach's notes. Search refused. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The full JD text → checks location, travel, schedule and work-authorization terms, which the highlights do not show, and gives each fit row its full wording.
- Your CV → turns the coach's-notes quotes into "your CV" quotes, so each row rests on your own sentences.
- The partner revenue model, or the store-surface readout, as an inspectable artifact → raises F1, F4 and F8 from medium to high confidence and sets the counting method for A1 and E1.
- Your date on the research note → confirms the C2, C3 and B4 framing is under six months old; if it is older, those cells become [generic].
- Dan's public talks or posts → recurring themes become likely questions and reverse-question material; needs search, which was refused here.
- Permission for web search → values and process targets 1 and 2, plus Dan's footprint in target 4.
- Recruiter guidance on focus areas → coverage of any deliverable the recruiter names.
- A tuesday-dossier.md → records the gaps this prep exposes for the next session.
