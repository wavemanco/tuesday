Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-8-canned-1579f286/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds on 5 December, since you have a date and a format for each.

Three things to know before you open it:

- **The headline objection is end-to-end ownership.** The JD asks you to own the complaints process across branches and the contact centre. Your material shows one branch's log, and you have never worked in a contact centre or presented above regional level. B1 (round 2) is the deepest rehearsal in the pack. Its answer holds to what you actually did, and it says so plainly if you did not own more.
- **Round 3's values scoring will run into your spreadsheet.** "Neighbours, Not Numbers" sits against the sentence you would most likely lead with, "I built the monthly complaints spreadsheet our regional manager uses." C2 is written for that.
- **The 20-minute escalation case (C5) is generic.** It tests structure, not your history, so it does not depend on anything you have said about yourself.

I did no web research. The values, the process and the strategy came from what you pasted, so the sources section lists them as provided. The pack also lists what it could not establish from your material, such as whether the log had regulatory timescales.

Say the word and I'll play the Skeptic on B1 as a drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you want the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Loop of three rounds, 5 December 2026. Round 1: recruiter, 30 minutes. Round 2: Head of Member Services (your future manager), 45 minutes, mostly behavioural. Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case, scored against the four published values. Interviewer names are not yet assigned, so no interviewer read is included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioural / values | Whether past behaviour shows Ashgrove's published values |
| EXP | Experience deep-dive | Whether your claims survive scrutiny, and what you did yourself |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Whether you know the 2026 strategy and can think at its level |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Where a question asks about something your material does not show, the guidance is an answer slot: an instruction to answer from your own experience, with a second branch for when the thing never happened. Use the second branch honestly.

## Fit snapshot

Shared across all three rounds. Evidence is quoted from your message. Nothing here is a claim you have not made yourself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your words are retail banking and branch supervisor. Say those, not "customer operations", which is the JD's phrase. "For six years I worked in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe, because your material says "formal" but not which rules or timescales applied. Lead with the log in your own terms. |
| F3 | "Own the complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote carries one branch's log, and no more. Say that and stop there. Answer slot: if you owned any step beyond the log, say which and how you decided; if you did not, say so and stay with the log you ran. |
| F4 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | The quote reaches monthly complaints reporting. Keep "spreadsheet" as your word. Expect a probe on what it counts. |
| F5 | "report monthly on ... resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked resolution times. Answer slot: if it did, say what it showed and how it was counted; if it did not, say so and say what you would add first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your quote says tellers, not supervisors. Say tellers. Answer slot: if you coached anyone above teller level on escalations, say how; if you did not, say so and say what you would do first. |
| F7 | "Work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silent in your material. Answer slot: if you worked with a digital team on any journey, say what it was; if you did not, say so and say how you would start. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't presented to anyone above regional level." Then your plan for learning it, said as a plan and never as a past. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your sentence says spreadsheet, not Excel. Name the tool only if you can say it was Excel. |
| F10 | "Never worked in a contact centre" (your message) against the JD's "the contact centre" in F3 | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't worked in a contact centre." Then the branch-side work in your own quoted words, with no claim that it is contact-centre work. |

No requirement in the JD is a gate. Every item is experience or skill, graded here as fit rather than as a gate.

Analysis, not words for you: your material shows the branch log and the escalation script. It does not show work across branches, work with a contact centre, or work with a digital team. The pack will not describe any of those as yours.

## Grounding brief

Vocabulary from the 2026 strategy brief you summarised (published July 2026, sent by the recruiter). Use these terms so you sound current.

- Digital channels: the brief moves 40% of member service to them by 2028. Say "digital channels", not "online".
- Branch network: eight branches consolidate into five hubs over 2027. Say "hubs".
- Small-business lending: launches Q1 2027.
- Competition: app-only banks are the main pressure.

Provenance for each: [grounded] the brief, as you summarised it. You have not given me the brief's wording, so do not quote it.

## Persona weights by round

**Round 1, recruiter screen (30 min).** Relationship prior: conversational, with a light skeptic. Weight: conversational 5, skeptic 2. Reasoning: this round is logistics and knockout checks in a friendly register. The risk is treating it as unscored.

**Round 2, Head of Member Services (45 min, future manager, mostly behavioural).** Relationship prior: hiring manager, meaning case and skeptic. Adjusted by "mostly behavioural": values/behavioural moves up, case moves down. Weight: skeptic 4, values/behavioural 2, prober 2, case 1. Reasoning: the manager is buying the headline gap, end-to-end ownership, and will test it with behavioural probes.

**Round 3, panel of two branch managers (60 min, 20-minute case, values scored).** Relationship prior: a panel blends the top two personas of each member's relationship. Branch managers are peers, so peer evaluator and prober; the values scoring and the case sit above both. Weight: values/behavioural 4, case 2, peer evaluator 2, pressure 1. Reasoning: the panel is the values round, and the case is where structure is scored.

## Values cheat sheet

Round 3 is a values-style round. It is named in the recruiter's email and scores against all four published values. Working meanings are paraphrased from the values page you pasted.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story for this value. Selection scaffold: pick one complaint where the member's view and the policy pulled apart, and you chose the member's side within the rules. If none comes to mind, say so plainly, then give the nearest thing your log carries: "I handled the branch's formal complaints log" (F3). |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Nearest quote: "trained new tellers on our escalation script" (F6). Selection scaffold: a time you explained an outcome and the member had to hear it twice, and what you changed in the wording. If none comes to mind, say so plainly, then say how you taught the script. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. The sentence this value tests is "I built the monthly complaints spreadsheet our regional manager uses." (F4). Expect the panel to notice it. Selection scaffold: if the spreadsheet changed how you dealt with a member, say how; if it only reported, say so and name what you would keep in view for the town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Nearest quote: "I handled the branch's formal complaints log" (F3), which is handling, not solving. Selection scaffold: a complaint you kept hold of until it closed. If it closed without you, say so. If none comes to mind, say so plainly. |

## Question banks

Provenance is the first column after the question type. Every sentence a guidance cell says about you is quoted there. Where the guidance makes no claim about you, the label stands alone.

### Round 1: recruiter screen (persona weights: conversational 5, skeptic 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your pay expectations for this role?" | JD | [grounded] the role's terms, none of your sentences | Logistics slot. Give the figure you actually expect, or ask what band the role carries first. Do not guess a number now. | Pay is a logistics slot under the recruiter row. No figure from you exists in your material, so none is supplied here. |
| A2 | "What notice do you owe, and when could you start?" | JD | [grounded] the role's terms, none of your sentences | Logistics slot. Give your actual notice period and your earliest start date, in your own words. | Knockout check in a friendly register. |
| A3 | "Where would you be based, and which days can you work?" | JD | [grounded] the role's terms, none of your sentences | Logistics slot. State the base and the days you can commit to. If a constraint is firm, say it once and stop. | Location is a logistics slot. Nothing in your material settles it. |
| A4 | "Why are you leaving your current role?" | EXP | [grounded] none of your sentences gives a reason; the answer is yours to give | Logistics slot. Give your real reason in one sentence, in your own words. | The reason is not in your material, so this bank supplies none. |
| A5 | "Walk me through your path to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" / "I handled the branch's formal complaints log and trained new tellers on our escalation script." / "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F1, F2 and F4. Arc: six years in retail banking, the last three as a branch supervisor; the formal complaints log and the escalation script; the monthly spreadsheet your regional manager uses. Add no dates and no outcomes. Speak it in 90 seconds. | Conversational opener that is still scored. The arc is built only from your sentences. |
| A6 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then move to the branch-side work in your quoted words, with no claim that it is contact-centre work. | Knockout risk. F10 is the source. |
| A7 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer: "I handled the branch's formal complaints log." Answer slot: if rules or timescales applied to it, say which; if they did not apply, or you did not track them, say so. | F2's probe, asked early. The second branch lets the rules not have applied. |

### Round 2: Head of Member Services (persona weights: skeptic 4, values/behavioural 2, prober 2, case 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns the complaints process end to end, across branches and the contact centre. Which part of that have you owned?" | JD | [grounded] "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: "I handled the branch's formal complaints log, and that is the part I can describe in full." Answer slot: if you owned any step beyond the log, say which and how you decided; if you did not, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it. | F3 is the headline gap, and the manager is the person most likely to ask it. A rehearsed, non-defensive answer changes the round. |
| B2 | "You've never presented above regional level. What would you do before presenting to a senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your plan, as a plan: what you would prepare and who you would rehearse with first. Never describe a past presentation. | F8 is a stated gap, so the plain acknowledgment is sourced. The plan is a plan. |
| B3 | "Tell me about a complaint where the member's view and the policy pulled apart. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick one complaint you handled where those two pulled apart, and say what you decided and why. If none comes to mind, say so plainly, then give the nearest thing your log carries. | Values/behavioural probe. The log is the only sentence you have to anchor it. |
| B4 | "Tell me about a problem you found that was not yours to fix. What did you do with it?" | VAL | [grounded] the published value "Own the Fix" (from your paste) | Selection scaffold for Own the Fix: pick a problem you found and kept hold of until it was solved, and say whose it was and what you did. If it closed without you, say so. If none comes to mind, say so plainly. | Values round, previewed here. Your material shows no such instance, so the scaffold ends in the honest branch. |
| B5 | "Walk me through how you built the monthly complaints spreadsheet. What does it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4: you built it, monthly, for your regional manager. Answer slot for what it counts: if you chose the columns, say which and why; if the regional manager set them, say so. | The premise "you built it" is quoted. What it counts is not quoted, so it is a slot. |
| B6 | "The role reports monthly on volumes and resolution times. Did your spreadsheet track resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot for F5. If it did, say what it showed and how it was counted, in your own words. If it did not, say so and say what you would add first. Never describe a resolution-time measure you did not track. | The denominator probe. Likely from a prober. |
| B7 | "A branch supervisor is escalating too much to you. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Live problem, story-mapped on F6: you trained tellers on the script. Structure: what you would look at first, what you would say to the supervisor, and what you would change in the script. Say tellers and supervisors separately. | F6 is the coaching gap. The case is a problem in the role, so it presupposes nothing about you. |
| B8 | "The role works with digital teams on self-service journeys. What is your experience there?" | JD | [grounded] "Work with digital teams on self-service journeys" (the JD line) | Answer slot for F7: if you worked with a digital team on any journey, say what it was; if you did not, say so and say how you would start. | The JD raises this, and your material is silent. The second branch lets it never have happened. |
| B9 | "You've said you've never worked in a contact centre. Why would a contact-centre team take a branch person to lead it?" | JD | [grounded] "Never worked in a contact centre" | Hold: the escalation work you did was on the branch side, where complaints start: "I handled the branch's formal complaints log." Concede: "I haven't worked in a contact centre, and I'd want to learn its queue before I changed anything." Hold through two follow-ups before conceding. | F10 is a stated gap. The concession is the plain acknowledgment. |

### Round 3: panel of two branch managers (persona weights: values/behavioural 4, case 2, peer evaluator 2, pressure 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a member's view ahead of what the policy said?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold for Members First, as in the values cheat sheet. If you have one, tell it with its outcome in your own words; if you do not, say so plainly, then give the nearest thing your log carries. | Values round. The panel scores this one hardest. |
| C2 | "Your spreadsheet tracks figures. How do you keep a complaint about a neighbour, not a number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | **Sharpest rehearsal in round 3.** The value sits against your most-quoted credential. Answer slot: if the spreadsheet ever changed how you dealt with a member, say how; if it only reported, say so and name what you would keep in view for the town. Do not argue that numbers and neighbours fit together unless you did that yourself. | Neighbours, Not Numbers is the value your credential is most likely to test. |
| C3 | "Tell me about a time a member had to hear an outcome twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for Plain Words. If no such time comes to mind, say so plainly, then say how you taught the script. | Plain Words scored in a values round. |
| C4 | "Ashgrove moves eight branches into five hubs in 2027. How do you keep a town on side through that move?" | CO | [grounded] the 2026 strategy brief, as you summarised it: eight branches into five hubs over 2027 | Structure: what the town loses, what the member still needs, who tells them, and in what order. Use "hubs" and "digital channels". Name a member's view and what you would do about it, without claiming a past move. | The brief is the source. The strategy knowledge is the differentiator, and a strong answer holds Neighbours, Not Numbers and the hub move together. |
| C5 | Escalation case, 20 minutes: "A member has complained three times about a fee, and the branch and the contact centre have each closed the complaint. The member now says they will take it further. You are the new Member Experience Lead. Walk us through the first hour." | CASE | [generic] | Structure: clarify the facts and the timeline, state the objective (keep the member and meet the complaint rules), name one owner, decide what happens today, then what you would record and how you would coach the people involved. Think aloud. Challenge one premise. | Live problem from the role. It presupposes nothing about your past. |
| C6 | "You've never presented above regional level. Why should we trust you with a monthly report to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Pressure: hold, then concede. Hold: "The regional manager uses the monthly spreadsheet I built." Concede: "I haven't presented above regional, and I would want a rehearsal before I did." Do not concede the core claim until the second follow-up. | F8 is the stated gap. The hold is the one thing you have quoted. |
| C7 | "Our branches sit beside the contact centre. Where is the seam, and what happens when we disagree about a complaint?" | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for the seam between the two: name the handoff you can see from the branch side, and say how you would settle a disagreement with an equal. If you have no disagreement story, say so and state the principle you would use. | F3 and F6 are the seam, and peers probe it. |
| C8 | "Tell me about a problem you found that wasn't yours to solve. What did you do?" | VAL | [grounded] the published value "Own the Fix" (from your paste) | Selection scaffold for Own the Fix, as in the values cheat sheet. Say whose problem it was and whether you kept hold of it. | Own the Fix is the fourth value the panel scores. |
| C9 | "Across branches and the contact centre, what would your first 90 days look like?" | JD | [grounded] "Own the complaints process end to end across branches and the contact centre" (the JD line) | Plan, not past: what you would map first, who you would meet, and what you would report back. Make no claim about what you have already done across branches or the contact centre. | F3 and F10 meet the JD here. The plan is the honest answer. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A5 |
| Experience handling regulated complaints | A7, B3 |
| Own the complaints process end to end across branches and the contact centre | B1, B9, C7, C9 |
| Report monthly on complaint volumes | B5, C2 |
| Report monthly on resolution times | B6 |
| Coach branch supervisors on escalations | B7, C5 |
| Work with digital teams on self-service journeys | B8 |
| Confident presenting to senior leaders | B2, C6 |
| Comfortable with Excel reporting | B5 |

## Reverse questions

Each round has its own, with a one-line reason.

**Round 1.**
- "How is the panel scored, and is the escalation case scored separately from the values?" Why it lands: it shows you are planning for the scoring, and the answer shows how much the case weighs.
- "Who else will be on the panel after the two branch managers?" Why it lands: it shows you are working through the process, not just the first step.

**Round 2.**
- "What would the first 90 days need to look like for you to say this was the right hire?" Why it lands: it turns the gap into success criteria and signals that you intend to own the outcome.
- "How does the hub move change the complaints load you expect in 2027?" Why it lands: it ties the question to the brief you read.
- "Which of the four values do you think the team is weakest on right now?" Why it lands: it invites honesty from the manager and shows you want to fix the gap, not hide it.

**Round 3.**
- "Where do complaints most often stall between a branch and the contact centre today?" Why it lands: it names the seam the JD's "across branches and the contact centre" line is about.
- "How much of the monthly complaints reporting do branch managers see today?" Why it lands: it ties to the spreadsheet you built and shows you are thinking about the people who receive it.
- "What would make a new lead useful to your branch managers in the first month?" Why it lands: a reciprocity question for peers. It shows you are thinking about what you bring to them.

## Prohibited claims

The claims this pack will not coach, each with its basis and its honest form. These are built here, from the fit snapshot, because no dossier is present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says one branch's log. B1's slot stays inside the log. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script," at its own scope. |
| Measured resolution times | Inflated form of F5 | Nothing. The spreadsheet's content is a slot (B6), not a claim. |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated, F10 | "I haven't worked in a contact centre." No slot. |

## Sources

Provided documents only. The JD and your background came from your message. The recruiter's email gave the process. The values came from the Ashgrove values page, pasted on 26 November 2026. The 2026 strategy brief came from the recruiter, as you summarised it. No web search was run, and nothing was attributed to any source outside these.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet and C1, C3, C8 are fixed by the pasted values page. |
| 2. Ashgrove interview process, customer operations | skipped | The recruiter's email names the three rounds and what each holds, so it fixes the loop and the persona weights. |
| 3. Ashgrove strategy, recent news | skipped | The brief you summarised fixes the grounding brief and C4. |
| 4. Named interviewer | n/a | No interviewer is named, so there is no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The two panel members' names → persona weights per member, and a tailored reverse question for each in round 3.
- The Head of Member Services' name → an interviewer read, and persona weights tuned to their path.
- Whether the complaints log carried regulatory timescales, or any rule that applied to it → F2 and A7 move from medium confidence toward a specific artifact you can describe.
- Whether you worked with any digital team on a journey → F7 becomes a story instead of an answer slot.
- Whether the spreadsheet tracked resolution times → F5 becomes a grounded row instead of a slot.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. It would add recent leadership and reorganisation news around the 2027 hub move, which would sharpen C4 and the round-2 reverse questions. Want it?
