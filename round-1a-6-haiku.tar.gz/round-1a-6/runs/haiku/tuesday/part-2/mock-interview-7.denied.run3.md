Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-7-denied-9b065864/6ac83d17-340f-49f0-b593-f5f2de5357e2/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since Tobias runs Live Operations and that's the usual shape for this role.

**The most important prep:** question B1. "You haven't led a team, and this role coordinates four disciplines on every update. Why are you the right person for it?" Your honest answer is to say you haven't led a team, then name the calendar and the release checklist in your own words, and concede once and specifically that you'd need to learn to set priorities for people who don't report to you. Don't claim leadership, and don't stretch "ran the calendar" into "coordinated four teams."

**Two things to know:**
- Web search was refused in this session, so I couldn't check Saltmarsh's values, interview process, or strategy, or anything about Tobias. Those parts of the pack are generic. A pasted values page or Tobias's public profile would fix that.
- The pack lists some inflated versions of your sentences as off-limits. The one to watch is "owned the retention KPIs" when your material says you presented the numbers.

Would you like me to play the Skeptic on B1 so you can rehearse it live? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Three questions, so I can sharpen the pack:
1. Is Tobias the person you'd report to, or a peer, or someone else?
2. Is there a presentation or take-home before or during the 60 minutes?
3. Would you say your four years at the puzzle studio were live-service work? That's the JD's "3+ years producing live-service games or apps" line, and your message doesn't settle it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
**Round:** 60 minutes, Friday. Format (presentation, take-home, panel) not yet known.
**Version:** first version. No changes yet.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: CASE (live problem), JD (a stated requirement), EXP (your past work), VAL and CO (not used here: no values round detected, no company research).
- Guidance is scaffolding, not a script. Say things in your own words.
- Prep time was not stated, so there is no triage section.

## The fit snapshot

Requirements are the JD's own words. Evidence is quoted from your message ("your message"). Nothing else is claimed about your history.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Say the four years and the studio, in those words. Your material does not say whether those years were live-service work, and this pack does not decide that for you. |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The quote carries one title and content drops, not two titles and live events. Its words stay as they are. Answer slot: if you have planned events or run a second title's calendar, say which and how; if not, say so and say how you would set up the second title. |
| F3 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | Lead with the quote in its own terms: you ran it, weekly, for two years, for your main title. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | high | [grounded] | presentation | Reword only: "I wrote the release checklist, and our QA team still uses it." Do not add how the releases ran unless you ran them. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Say that you presented the monthly numbers. Presenting them is exposure, not analysis, and the pack adds no analysis. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you wrote or ran one, say what it covered; if not, say so plainly and say what you would put in one. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Answer slot: if you coordinated any of these teams on an update, say which and what you did; if not, say so and say how you would set that coordination up. |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | Answer slot: bring one written thing you produced and say who it was for. The release checklist in F4 is the nearest, if you can describe it. |
| F9 | leading the people this role coordinates ([generic]: no JD line names it) | "Never led a team" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't led a team." Then how you would learn it, as a plan and never as a past. Never a claim to leadership. |
| F10 | monetization-aware KPIs ([generic]: no JD line names purchases) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first, as a plan. |

## Prohibited claims

Built locally from the fit snapshot. These are the stretched versions of your sentences, and the claims you would reach for under pressure. None of the guidance below asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-service operations for a mobile title | Inflated form of F1 | F1's quote at its own scope. Limit, in this pack's analysis: the material says four years at a puzzle-game studio. |
| Ran live events, or the calendar for two titles | Inflated form of F2 | F2's quote at its own scope. Limit, in this pack's analysis: the material says content drops for one main title. |
| Owned the retention KPIs | Inflated form of F5 | F5's quote at its own scope. Limit, in this pack's analysis: the material says you presented the numbers. |
| Led a team | Negative you stated, F9 | "I haven't led a team." No slot. |
| Worked with in-app purchases | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Weights are the hiring-manager prior: Case/Strategist and Skeptic lead. There is no interviewer profile, so no interviewer-signal adjustments were made. Total: 18 questions.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 5 | Live problems from the calendar and the release process | High. A Head of Live Ops hiring for this role is buying capability and will test it on live problems. | Clarify, then structure, then name the metric you would trust least. |
| Skeptic | 4 | "Why you, given X?" on the stated negatives | High. Two negatives you stated (F9, F10) and four JD lines with no quote (F6 to F8) are where this lands. | Hold the calendar and checklist quotes. Concede once, specifically. |
| Data-Driven Prober | 4 | Questions on retention definitions and KPIs | Medium-high. The JD names retention metrics and KPIs, and F5 is the only quote on them. | Say which definition you reported, or say you do not know it. |
| Pressure | 3 | Time-boxed "why you" and "how much was you" | Medium. The IAP and leadership negatives invite it. Kept mid-weight because the prior does not favour it. | Pause, restate, hold two follow-ups, concede specifically. |
| Conversational | 2 | Opener and a casual question on the JD's live-ops topics | Low to medium. Casual, but still scored. | Use the 90-second arc. Answer the casual question as if scored. |

## Question banks

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Next month's update for one of the two titles slips a week, and the other is on track. What do you do first?" | CASE | [generic] | Clarify what slipped and what it blocks. State the objective: the drop date and what it has to land. Segment the impact by title, team and player group. Then approach in order: unblock, re-sequence, tell the community. Name the metric you watch. Makes no claim about your past. | Live problem from R1 and R2. [generic] because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Retention on your main title fell 20% in the week after an event. Diagnose it." | CASE | [generic] | Clarify: which cohort, which date, the event alone or a release too. Split by cohort, device and version. Check whether the event changed the funnel or only its timing. Name the metric you would trust least. | Covers R3 and R7 in one live problem. |
| A3 | "The role plans and runs a live-events calendar for two titles. How would you set one up from scratch?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F2: the weekly calendar, one title, two years, in those words. Answer slot for the second title: if you have planned events or run a second title's calendar, say which and how; if not, say so and walk through the set-up you would use. | F2 is the evidence for R1 and carries transferability, so a probe will land on the second title. |
| A4 | "Tell me about an update where design, art, engineering and community wanted different things. How did you settle it?" | JD | [generic] (no quoted sentence carries this; F7 is none given) | Open prompt: pick a real update. Answer slot: if you coordinated those teams on one, say what each wanted and what you decided, in your own words; if you did not, say so plainly and walk through how you would settle it. | R2 is the JD's own line. F7 has no quote, so no story is supplied. |
| A5 | "Walk me through how you'd run a release checklist with QA on a live update." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it, in those words. Answer slot: if you ran a release against it, say which steps you owned and how QA signed off; if you did not, say so and walk through how you would run one. | R4 is the JD's line; the checklist is F4's quote. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You haven't led a team, and this role coordinates four disciplines on every update. Why are you the right person for it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: "I haven't led a team." Then name the calendar and the release checklist, in the quotes' own words, and let the interviewer draw the inference. Hold through two follow-ups by returning to those two. Concede once, specifically: "I haven't led a team, and I would want to learn how to set priorities for people who don't report to me." Never claim leadership. | The stated negative sits on the JD's coordination line, so this objection will arrive in some form. Deepest rehearsal, because the material is thinnest here (F9, F3, F4). |
| B2 | "You've spent four years at a puzzle-game studio. What carries over to a mobile title with purchases?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and [grounded] "never worked on a game with in-app purchases." | Say the four years and the studio. Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what carries over: the calendar (F2) and the retention reporting (F5), each in its own words. | R5 is where the live-service question surfaces. F1 and F10 are the rows. |
| B3 | "You presented the monthly retention numbers to the studio head. What did you do with what they showed?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you acted on them, say what and why, in your own words; if you only reported them, say so plainly and say what you would do with them now. Never claim you set the definitions. | R7 and F5. The question's premise is the quote itself. |
| B4 | "Have you written a post-event review? If so, tell me about one." | JD | [generic] (the JD raises it; no candidate sentence carries one, F6 is none given) | Open prompt. Answer slot: if you wrote or ran one, say what it covered, who read it and what changed; if you have not, say so plainly and describe what it would contain. | Covers R3 and R8, since the write-up is a written artifact. F6 has no quote, so no story is supplied. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When you presented the monthly retention numbers, which retention measure was it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measure you reported and its window, in your own words. If you do not know which measure it was, say so plainly. | The question asks for the definition only. No figure was given, so no defend-the-number slot applies. |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how they were cut (cohort, window, which title), say that. If you did not set the method, say so and say whose it was. | A prober's stem on R7. No figure was given, so the slot holds. |
| C3 | "Name three KPIs you'd track for a live mobile title, and what each tells you." | JD | [generic] | Pick three you can defend: one engagement, one retention, one revenue or progression measure. Say what each tells you and what it misses. Makes no claim about your past. | R3 and R7. KPIs are the JD's own line. |
| C4 | "Did you measure whether a content drop worked? What did you look at?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you measured drops, name what you looked at and over what window. If you did not, say so plainly and say what you would look at first. | Premised on F2 only as far as the quote goes: the question asks whether a measure existed, not that it did. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has shipped live-service updates for three years?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate the question, then anchor in the quote: the weekly calendar, two years, one title. Hold through two follow-ups. Concede the gap specifically (live events across two titles) rather than folding on the calendar. | Pressure on R1 and R5. The hold is only what the quote carries. |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say which parts of the calendar you set and which others set, in your own words. If others set the cadence, say so; that is an honest answer, not a weak one. Never claim you set the cadence unless you did. | Attribution probe, which exists to catch inflation. |
| D3 | "A puzzle studio is not a purchase-driven mobile business. Why would you be ready?" | JD | [grounded] "never worked on a game with in-app purchases" | Hold: "I haven't worked on a game with in-app purchases." Then what carries over (the calendar and the retention reporting), in the quotes' words. Concede once: the purchase-driven side is new to you. | Pressure on the IAP negative. Hold, then concede. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc: the four years and the studio; the calendar for two years; the retention numbers you presented; then what you want next. Each beat in the quote's words. | Opener. Casual register, but still scored. |
| E2 | "What are you playing these days, and what would you change in a live title?" | JD | [generic] | Name one title you play and one change you would argue for, with the reason. Keep it to a minute. Makes no claim about your past. | Rapport question on a live-ops theme. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3 |
| "coordinate design, art, engineering and community teams on each update" | A4, B1 |
| "own the post-event review and the KPIs it reports" | A2, B4, C3 |
| "manage the release checklist with QA" | A5 |
| "3+ years producing live-service games or apps" | B2, D1, and the gate question in the message |
| "experience running a content calendar" | A3, C4, D2 |
| "comfortable with player-retention metrics" | A2, B3, C1, C2 |
| "clear written communication" | B4, A5 |

## Reverse questions

1. "Of the two titles, which is further behind on its calendar, and what is blocking it?" *Why it lands:* shows you are already thinking about the job's actual problems.
2. "What does a post-event review look like here today, and who reads it?" *Why it lands:* asks about the JD's line without assuming it exists.
3. "When a release checklist step slips, who can hold the drop?" *Why it lands:* shows you know QA's authority matters.
4. "Which decision in the last quarter did the live-ops team get wrong, and what changed?" *Why it lands:* signals that you want the real record, not the summary.
5. "How will you judge the first six months in this role?" *Why it lands:* signals KPI thinking, and gives Tobias a chance to say what he cares about.

## Sources

- **Provided documents:** your message, which holds the JD text, your background, the interviewer's name, the round's length and day.
- **Searches:** two web searches were sent. Both were refused by the host (permission not granted), so they returned nothing: "Saltmarsh Games mobile game studio" and "Tobias Wrenfield Head of Live Operations Saltmarsh Games". Not retried. No URLs were returned, and nothing was attributable to Saltmarsh Games or to Tobias.
- **Consequence:** everything about the company (values, interview process, strategy) and about Tobias is missing. Those parts of the pack are generic, and no company claim was made.

**Research tier:** L1. Searches 0 of 6 (2 refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet. Not produced: no values round was detected, and no values page is in hand. |
| 2. `Saltmarsh Games interview process` | unavailable | Loop structure, which would have set persona weights by named rounds. Weights use the generic hiring-manager prior instead, which this pack says plainly. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have fed the company-strategy (CO) questions. None were written. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read and a tailored reverse question. The interviewer read is absent. The query was refused. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public profile (once search is available, or pasted) → an interviewer read, persona weights from his public footprint, and a reverse question tied to his own path.
- Saltmarsh's values or careers page, pasted → a values cheat sheet, and the loop structure if the page describes it.
- The recruiter's note on the round's format → whether a presentation or take-home is coming, and a build section for it.
- Your full CV → the fit-snapshot rows gain quotes from the CV, not only your message.
- The live cadence of your puzzle title → upgrades F1 and F2 from medium confidence, if you can state it in your own words.
