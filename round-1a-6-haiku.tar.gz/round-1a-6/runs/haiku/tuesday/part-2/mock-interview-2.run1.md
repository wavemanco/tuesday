Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-2-denied-3298a08f/58387004-d854-48ff-a8a2-374b2955f655/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so I know nothing about Atlas Freight's values, interview loop or current strategy. Those parts are generic, and the pack says so.

The highest-value prep is the gap between your material and the JD:

- **Scale (F1, F3):** you have run three supervisors, not twelve, and you have no multi-site experience. Expect the Skeptic on this (C3), so concede it specifically and say how you'd start rather than claiming more.
- **Gate (F2):** the JD says "5+ years operations leadership required." You have seven years in operations, but nothing in your material shows how many of those you led people.
- **Metrics (F4):** your headline result is the 40% mis-pick cut. The JD asks for on-time performance and cost per shipment, which you haven't cited. Be ready to say which you tracked and which you didn't.
- **Power BI (F5):** say "I haven't used Power BI" yourself, then give a plan. Don't let them find it first.
- **Defend the 40%:** be able to say how it was counted, what it's sensitive to, and which part of the redesign was yours (A1, A2).

Two things would sharpen the pack:

1. Who is interviewing you, and is it a hiring-manager round, a peer, or a panel?
2. How many years have you led people in an operations role, as opposed to working in ops?

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Want me to play the Skeptic on C3 so you can rehearse it? I can also save a `tuesday-dossier.md` to carry these gaps into later sessions, or convert the pack to Word.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not given. Round: assumed hiring-manager round (see upgrade menu).
Research: none completed. Web search was refused in this session, so values, loop and strategy are `[generic]`.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** experience deep-dive, **JD** role-driven, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.

## Fit snapshot

Requirements come from your message, which summarises the JD. They are not the JD's full text, so rows marked `[generic]` could tighten once you paste it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead a team of 12 supervisors" (your message, JD summary) | "senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Say that yourself. Answer slot: if you have run a larger layer of leads, say how; if not, say how you would set the cadence for twelve. |
| F2 | "5+ years operations leadership required" (your message, JD summary) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | hard_gate | Seven years is operations time, not leadership time. The years you have led people are not in your material. This row is answered by the (d) question in the message; see upgrade menu. |
| F3 | "Own daily terminal operations across 4 sites" (your message, JD summary) | none given | none | [generic] | discovery | Multi-site work is not in your material. Answer slot: if you have split attention across sites or locations, say how. If not, say so and describe how you would do it. |
| F4 | "drive on-time performance and cost-per-shipment down" (your message, JD summary) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [grounded] | transferability | Your metric is accuracy, not on-time performance or cost. Answer slot: if you tracked on-time or cost per shipment, say so; if not, say so and name the metric you did move. |
| F5 | "build reporting in Excel/Power BI" (your message, JD summary) | "solid Excel" (your message); "never used Power BI" (your message) | medium | [grounded] | capability | Excel is grounded. Power BI is not. Words: "I haven't used Power BI." Then how you would learn it, as a plan. |
| F6 | "Lean/Six Sigma a plus" (your message, JD summary) | "green belt certified" (your message) | high | [grounded] | none | Credential is grounded. Expect a probe on what you did with it. |

Routing: F2 is a hard_gate row because the JD says "required". It asks nothing in the snapshot; it is raised as a question in the message instead.

## Prohibited claims

Built locally from the fit snapshot. None of these may be coached.

| Claim | Basis | Honest form |
|---|---|---|
| Led or managed twelve supervisors, or any layer above three | Inflated form of F1 (your message: "over 3 supervisors") | "I have led three supervisors as a senior shift manager." |
| Ran multi-site operations | Inflated form of F3; the material has no multi-site line | Answer slot only. |
| Improved on-time performance or cost per shipment | Inflated form of F4; the material cites mis-picks only | "I cut mis-pick rate 40% by redesigning the pick path." Limit stated in analysis only. |
| Built or used Power BI reports | Plain acknowledgment, F5 (your message: "never used Power BI") | "I haven't used Power BI." |
| Five or more years leading operations | Gate row F2; no source for the count | Answer slot, via the (d) question. |

## Persona weights and counter-strategies (hiring-manager round, assumed)

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the scale gap (F1, F3) and the JD gates (F2) | High. The JD's "required" and the team size are where the material is thinnest | Concede the gap specifically, then name what you would do about it |
| Pressure | Holds you to the twelve-supervisor and four-site claim | High, same reason | Hold the position you can back (the surge plan, the redesign), concede the rest |
| Prober | Asks how the 40% was counted (F4, A2) | High. Headline metric on your CV | Say exactly how you measured it, and which part you did |
| Role-checker | Walks the JD line by line (Power BI, OTP, cost) | Medium-high | Answer each line from the fit snapshot in order |

## Question banks

### Prober (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP | Walk me through the pick-path redesign. | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Story beats from the sentence only: the redesign, then the mis-pick reduction. Answer slot: say what the pick path was before and what you changed. If you led the redesign, say so; if you contributed to it, say which part was yours. | Headline metric on your CV, so a probe is likely (F4). |
| A2 | EXP | How did you count the 40%, and over what period? | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not measure it precisely, say so. | Figures raise defend-the-number slots. |
| A3 | EXP | You ran the peak-season surge plan. What did you set up, and what did you not get to? | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: say what the plan covered and where it fell short. If there was no shortfall you can name, say so and give the nearest real stage. | Shows the surge work is yours to describe. |

### Role-checker (weight 2)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | JD | This role leads twelve supervisors. How have you run a team that size? | [grounded] "senior shift manager over 3 supervisors" (your message); raising source: JD line "lead a team of 12 supervisors" | Say how you run your three supervisors today, then how you would scale the cadence. Honest branch: if you have not managed through a layer above three, say so and describe the cadence you would set. | Direct JD requirement (F1). |
| B2 | JD | How would you drive on-time performance and cost per shipment down in your first ninety days? | Raising source: JD line "drive on-time performance and cost-per-shipment down" | CASE shape. Diagnose from the data, pick one lever, and measure it weekly. No past claim is made here. | JD requirement with no rehearsed answer yet (F4). |
| B3 | JD | Show me the reporting you would build in Power BI. | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I haven't used Power BI." Then a plan: build the daily on-time view in Excel first, then rebuild it in Power BI. | Gap row F5. Name the gap yourself before they do. |
| B4 | JD | You have run operations for seven years. How many of those years did you lead people? | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: give your leadership-year count in your own words. If it is short of five, say so, and point to the seven years of operations and the shift-manager role. | Gate row F2. |

### Skeptic (weight 4)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | JD | You cut mis-picks. What did that pick-path change cost in throughput, if anything? | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Open question with no premise. Answer with what you measured. If you did not measure throughput, say so. | Skeptic probe on the one metric you have. |
| C2 | JD | You have a Green Belt. Tell me about that work, and what you personally did on it. | [grounded] "green belt certified" (your message) | Answer slot: name the project if you have one and your own part. If you took the course without a project, say so. | Credentials get probed for application. |
| C3 | JD | You have not run four sites. Why would this be different? | Raising source: JD line "Own daily terminal operations across 4 sites" | Hold the position you can back: you ran a site's peak plan and a pick-path redesign. Concede specifically that multi-site work is new to you, then name how you would start. Do not claim multi-site experience. | Deepest rehearsal. This is the objection the material is most thin on (F3). |

### Pressure (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | JD | Three supervisors is not twelve. Why should we believe you can do it? | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold-then-concede. Hold: the surge plan ran two years running at one site. Concede: twelve across four sites is larger, and say what you would change first. Do not fold on the core claim. | Follows F1 and F3. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | What does success look like for this role in the first six months? | Shows you plan against the scorecard, not the job title |
| R2 | How is on-time performance and cost per shipment measured today across the four sites? | Tests whether the metrics in the JD are already defined |
| R3 | Where does the reporting stack stand today, and is Power BI in use? | Shows you have read the JD's reporting line closely |
| R4 | What has been the hardest operations problem across the four sites this year? | Opens the conversation to their real pain |
| R5 | How is the team of twelve supervisors split across the four sites? | Shows you are thinking about the layer you would manage |

## Sources

- Provided: your message (JD summary, CV summary).
- Web search: two calls sent (`Atlas Freight regional logistics company values`, `Atlas Freight operations manager interview process`). Both refused by the host. Nothing returned.

## Upgrade menu

- The full JD text → F1 to F6 become `[grounded]` against the posting's own wording, not your summary.
- The interviewer's name and title → persona weights and a tailored reverse question.
- The round type and relationship (hiring manager, peer, panel, final) → the persona weights and the question bank reweight.
- Your years leading people → F2 moves from a gate to a grounded row.
- Atlas Freight's published values, loop, and recent strategy (when web search is allowed) → a values round and CO questions.
- Your team and site structure today → F1 and F3 get specific evidence.
