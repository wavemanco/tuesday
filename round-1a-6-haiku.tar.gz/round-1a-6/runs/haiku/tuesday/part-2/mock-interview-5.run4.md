Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-5-denied-3291e76d/6e71f2bc-828c-4cdb-81ad-4511b030d2fe/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. Web search was refused in this session, so the pack has no Kelverton values, interview process or strategy research. Everything company-specific comes from your message, and anything generic is labelled `[generic]`.

**The 15-minute POV.** Three theses, each with a concession you make yourself:

- **Change, not the timetable, is where operators feel the software.** Build partnerships around the operator's change programmes, such as timetable recasts and disruption recovery. Concession: you don't yet know which operators are in a live change programme.
- **Partner the operator's incentives, not just its IT.** Operators are measured on contract performance, so align with that measure. Concession: you don't know how any particular contract measures performance.
- **Partners as delivery, not just as a sales channel.** The integrators already in an operator's estate are the route in. Concession: you don't know whether the channel model works in rail.

Finish on one thing an operator's planner would notice in a month, framed as your proposal and not as a result. Don't invent a figure for it. The POV can't yet depart from the consensus answer, because I haven't seen the strategy report.

**Where the panel will press.**

- **Deepa's skeptic question is the one to rehearse hardest:** "You've never sold into rail. What makes you think you can do it here?" Answer plainly: "I haven't sold into rail." Then bridge to the operator's-eye view and the channel growth, and concede the buying cycle as the thing you'd spend the first month learning.
- **Ross will test the £4M.** Know how it was counted, and say it is influenced revenue, not revenue you closed. Also know your share of it.
- **"Never carried a quota."** Hold the position through two follow-ups, then concede specifically that a direct quota is a different discipline you'd need to learn.

**Four-hour split.** About an hour on the POV, 45 minutes on Ross's commercial questions, 40 minutes on Deepa's case, 30 minutes on the skeptic question, 20 minutes on reverse questions, and the rest as insurance. The pack has the full question banks and five reverse questions.

**Claims I'd keep out of the room:** "I generated £4M", "I built the ISV channel", and "I know how train operators schedule and buy". Your own words are narrower than each of these.

Two things would make this sharper:

1. Can you paste the operator-relevant parts of the strategy team's market report? I haven't seen it, and the POV can only depart from the consensus answer once I have.
2. Can you paste the job description, or the role's description from the recruiter? Without it, the requirement rows are quoted from your message and the recruiter's email, not from the posting.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can run a timed drill with Deepa or Ross playing the question, if you want to rehearse live.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, 60 minutes. First 15 minutes: spoken point of view (no slides) on where you would take operator partnerships over 18 months, landing on what it means for the operators. Remaining 45 minutes: Q&A, with commercials pressed by Ross.
**Panel:** Deepa (VP Partnerships, your future manager); Ross (Commercial Director).
**Research tier:** L0. Web search was refused in this session, so no company values, loop structure or strategy was fetched. Everything company-specific below is from your message. Items marked `[generic]` are role-family patterns, not facts about Kelverton.

## 1. How to use this pack and type key

Personas describe how a question arrives. Types describe what is being scored.

- **CASE**: live problem from the role, scored on structure and reasoning
- **EXP**: your past work, scored on whether claims survive scrutiny
- **JD**: the role's stated responsibilities, including gaps
- **CO**: company and strategy knowledge (thin here; see Sources)
- **VAL**: behavioural and values (no values round detected)

Guidance is scaffolding, not a script.

## 2. Prep triage (about 4 hours)

In order, each tied to a section:

1. **60 min, Section 5 (the POV).** Choose one thesis, write its concession, and say the 15 minutes aloud twice, timed.
2. **45 min, Bank C (Ross).** Write down how the £4M was counted, what it is sensitive to, and your weakest assumption about it (C1, C2). Then answer C3 and C4 aloud.
3. **40 min, Bank A (Deepa, case).** Practise A1 and A2 out loud, with a diagnosis you can build live.
4. **30 min, Bank B (the gap).** Rehearse B1 until it is boring. This is the highest-return prep in the pack.
5. **20 min, Section 8 (reverse questions).** Pick three.
6. **Remaining time: insurance.** Everything else is insurance.

## 3. Fit snapshot

No job description was supplied. Requirements below come from the recruiter's and your own words, and each one is quoted. Nothing here is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter) | "took it from 6 partners to 40" (your message) | medium | [grounded] | none | Lead with the count as you stated it. Expect a probe on how the 40 was counted and what the channel was. Caveat: this was a payments channel, not rail. |
| F2 | "sells scheduling software to train operating companies" (your message, describing Kelverton) | "I've never sold into rail specifically" (your message) | none | [grounded] | capability | Words: "I haven't sold into rail." Then how you would learn the operator buying process, said as a plan, never as a past. |
| F3 | "what it means for the operators themselves" (recruiter) | "so I know the operator world from the other side" (your message), with "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Bus and light rail planning is adjacent to operating a franchised rail business, not the same work. Say which part carries over and where it stops. |
| F4 | "Ross will push on commercials" (recruiter) | "never carried a direct quota, only influenced revenue" (your message), with "roughly £4M of influenced revenue" (your message) | medium | [grounded] | capability | Words: "I haven't carried a direct quota. My revenue has been influenced revenue, roughly £4M." |
| F5 | "Senior Partnerships Manager" (role title, your message) | "9 years in partnerships" (your message) | medium | [grounded] | none | Nine years is the reference point for seniority; say it plainly. |

## 4. Prohibited claims

Built locally from the fit snapshot. These will not be coached, and no answer may imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I generated £4M" or "I drove £4M" | Inflated form of F4: your words are "influenced revenue" | "Roughly £4M of influenced revenue." Limit, in the pack's analysis: the material says influenced, not owned. |
| "I built the ISV channel" | Inflated form of F1: your words are "took it from 6 partners to 40" | "I took it from 6 partners to 40." |
| "I know how train operators schedule and buy" | Inflated form of F3: your words are about bus and light rail planning | "I know the operator world from the other side, through bus and light rail planning." |
| "I've sold into rail" or "I've run a rail quota" | Negative you stated (F2, F4) | "I haven't sold into rail" and "I haven't carried a direct quota." No slot. |

## 5. Graded deliverable: the 15-minute POV

No slides. The announced deliverable is graded, so it gets its own build.

**What the panel scores:** a thesis they could disagree with; a concession you make yourself; a differentiated answer, not the consensus one; and a close that lands on the operator.

**Grounded facts you can build on:** F1 ("took it from 6 partners to 40"), F3 ("I know the operator world from the other side"). Everything about Kelverton's market, customers or strategy is outside this pack because research was refused. You have a market report from their strategy team, which you have read. Paste the operator-relevant parts and this section gets a real differentiation step (see Question 1 below).

**Three candidate theses, each with a mandatory concession:**

- **Thesis A: Change, not the timetable, is where operators feel the software.** Partnerships should be built around the operator's change programmes (timetable recasts, disruption recovery), where a scheduling tool either gets used or does not. *Concession:* I do not yet know which of your operators are in a live change programme, or which of them buy on change rather than on renewal.
- **Thesis B: Partner the operator's incentives, not just the operator's IT.** Operators are measured on contract performance. Partnerships that align with that measure earn their place. *Concession:* I do not know how any particular operator's contract measures performance, and the incentives in one franchise may not hold in another.
- **Thesis C: Partners as delivery, not just as a sales channel.** The integrators and suppliers already inside an operator's estate are the route in. *Concession:* I do not know whether Kelverton's channel model works in rail, and the ISV channel I ran was a different market.

**Differentiation:** the consensus answer to "where would you take operator partnerships" is probably "more partners, deeper integrations." Depart from it, and say why. You cannot do that against the strategy report until you paste it.

**Requested close (what it means for the operators):** finish on one thing an operator's planner does differently in a month they would notice. Say it as your proposal, not as a result you have seen. Do not invent a figure for it.

**Watch the POV for:** any operator statistic you have not been given. Say "I'd want to test this with operators" instead.

## 6. Persona weights

| Panel member | Relationship prior | Dominant personas (weight) | Reasoning |
|---|---|---|---|
| Deepa (VP Partnerships) | Hiring manager | Case/Strategist (5), Skeptic (3), Conversational (2) | Deepa buys capability and derisks the rail gap. Expect a live problem on her operator roadmap. |
| Ross (Commercial Director) | Executive, commercial | Pressure (5), Data-Driven Prober (4) | Commercials and the £4M. Ross tests composure and the counting, not the content. |

No interviewer profile was researched, so there is no interviewer-signal adjustment. Weights come from the round type alone.

## 7. Question banks

Each question carries its provenance (the quoted sentence it rests on) and an answer guidance cell.

### Bank A: Deepa, Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An operator planner tells you their disruption recovery takes two days to rebuild. Where do you start?" | CASE | [generic] | Clarify first: which operators, which contract, what triggers the rebuild. Then structure: where the time goes, who does it, what the tool changes. Say your hypothesis early. | A live problem from the operator's day. No claim about your past. |
| A2 | "What would you need to know about one of our operators before you proposed a partnership?" | JD | [grounded] "I know the operator world from the other side" (your message) | Name three things you would need: the operator's contract incentives, its change calendar, and which suppliers it already uses. Say that the transport side gives you the planner's view, not the operator's contract view. Hold the bus and light rail limit. | F3 is the evidence. The question asks about a process, not your history. |
| A3 | "Which of our operators would you approach first, and why?" | CO | [generic] | Without research you cannot name one. Say what you would test: change activity, contract renewal dates, existing supplier relationships. Name the approach, not the operator. | No rail research was possible; the honest answer is a method. |
| A4 | "How would you know, six months in, that the partnership strategy is working?" | JD | [grounded] "took it from 6 partners to 40" (your message) | Name one leading and one lagging measure. Count partners only if they are shaped by operators. Note that a partner count is a poor measure on its own. | F1 is the evidence and the likeliest place for a metrics probe. |

### Bank B: Deepa, Skeptic (the gap; highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What makes you think you can do it here?" | JD | [grounded] "I've never sold into rail specifically" (your message) | **Highest-ROI prep in this pack.** Say it plainly: "I haven't sold into rail." Then the bridge: "What I bring is the operator's-eye view from transport planning, and running a partner channel from 6 partners to 40." Hold through two follow-ups by returning to what you did. Concede the learning curve specifically: "the buying process and the contract cycle are where I'd spend my first month." | F2 is the biggest gap and this question is near certain. Deepest rehearsal here. |
| B2 | "Why partnerships with train operators, rather than the payments world you just left?" | JD | [grounded] "9 years in partnerships" (your message) | Give the motivation in one sentence about the operator problem, not about leaving. Do not criticise the payments company. | Motivation consistency. The skeptic checks whether you want this or just want out. |
| B3 | "What's the part of this role you'd be weakest at on day one?" | JD | [generic] | Name the buying cycle and the contract structure. Then say how you'd close that: ride along with an operator's planners, and ask Ross for the commercial numbers in week one. | Calibrated candour beats bluffing. |

### Bank C: Ross, Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should I trust a £4M number from a partner channel that wasn't yours to sell?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold: "It's influenced revenue, not revenue I closed. Here's how it was counted:" then the method, in your own words. Concede the limit: "influenced is a judgement, and I would show you the attribution rules before I used it." | F4 is the evidence. Do not defend the number's precision beyond what you can say. |
| C2 | "That £4M: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Give your share in your own words: which partners you brought in and what you ran. If part was the product team, say so. Do not claim the whole. | Attribution honesty. The probe is designed to catch inflation. |
| C3 | "You've never carried a quota. Why would I give you a commercial target?" | JD | [grounded] "never carried a direct quota" (your message) | Hold: "I haven't carried a direct quota. I've been accountable for influenced revenue against a plan." Concede: "a direct quota is a different discipline, and I'd want to learn it." | F4's bridge. Hold the position through two follow-ups; concede specifically, never fold on the core claim. |
| C4 | "What would your first commercial plan for operators look like?" | CASE | [generic] | Clarify the target and the time horizon first. Then a plan with three levers and one number you would test first. | Commercial structure under time pressure. |

### Bank D: Ross, Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Describe the method in the words you used with C1. Name the weakest assumption before he does. If you do not know how a part was counted, say so. | Metric questions include the weakest-assumption move. |
| D2 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the assumption. Do not name a method you did not use. | A probe on the number's sensitivity. |
| D3 | "What's the operator revenue you'd expect in year one?" | JD | [generic] | Do not give a figure. Say what you would need first: the target, the contract pipeline, and the sales cycle length. | You have no rail number and should not invent one. |

### Bank E: Conversational (low weight, the opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "9 years in partnerships" (your message); "5 years in transport consulting" (your message) | A 90-second arc: transport planning, then partnerships at the payments company, then the operator view you bring. | Casual openers are scored. |
| E2 | "What do you think of the operator market right now?" | CO | [generic] | Do not claim a view on Kelverton's market you have not read. Give your general view on franchised operators' pressures and say which of it you would test. | Research was refused, so this is the honest version. |

**Requirement coverage**

| Requirement | Questions | Note |
|---|---|---|
| Operator partnership strategy (recruiter) | A1, A3, C4, Section 5 | Covered |
| What it means for operators (recruiter) | A2, Section 5 close | Covered |
| Commercials, Ross (recruiter) | C1 to C4, D1 to D3 | Covered |
| Rail sales experience (your gap) | B1 | Covered. Deepest rehearsal. |
| Motivation | B2, E1 | Covered |
| Values | none; no values round was detected | Not covered; see Sources |

## 8. Reverse questions

Five, each with a reason it lands.

1. "Which operators are in a live change programme this year, and which are renewing?" *Why it lands:* it shows you are thinking about the operator's calendar, not yours.
2. "How does the operator buying process differ from a payments partner's?" *Why it lands:* it asks Deepa to teach you the gap, and it tells her you know there is one.
3. "What did the last partnerships hire get wrong in their first 90 days?" *Why it lands:* the answer shows you what Deepa is worried about.
4. "How do you see the commercial split between partner-led and direct revenue in operators?" *Why it lands:* it is the question Ross will want asked, and it shows you have thought about it.
5. "What would make you say in six months that this was the right hire?" *Why it lands:* it is a peer-level question, and it gives Deepa a chance to set out the criteria.

## 9. Sources

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet (section 10). Web search was refused, so no values were fetched. |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Loop structure and persona weights. Persona weights come from the round type only. |
| 3. `Kelverton Rail strategy news` | unavailable | CO bank and the POV's differentiation step. Paste the strategy report to recover this. |
| 4. Interviewer footprint for Deepa and Ross | unavailable | Interviewer read and tailored reverse questions. Not searched. |
| 5. Representative JD for a Senior Partnerships Manager | unavailable | JD-tagged questions. No JD was supplied. |

Research tier: L0. Searches sent: 3 (each refused, permission not granted). Searches returned: none.
Provided documents: your message only. The recruiter's internal market report is not in this session; I have not seen it.

## 10. Upgrade menu

- The job description → six `[generic]` rows become `[grounded]`, and JD-tagged questions get real requirement lines.
- The strategy report's operator section → the POV's differentiation step becomes possible; the consensus answer can be named and departed from.
- Public profiles for Deepa and Ross → personal reverse questions and interviewer-specific persona weights.
- Search permission granted → the values, process and strategy targets can run, and CO questions can be grounded.
- The recruiter's note on process, if she has one → coverage of any further deliverable.
