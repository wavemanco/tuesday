The three searches were refused by the session's permission setting, so the pack will run without company research. I'll write it now and note that gap in its Sources section.
Three things before you open the pack. The dossier is 104 days old, so check the posting against it. Web search was refused, so the pack has no company values, interview process, or strategy. And the dossier doesn't list "Shipped API or platform products" as a gap, but the pack does (F6), so don't claim a shipped platform product.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-4-denied-739963a3/b8f13e52-d59f-4d4b-b29c-e0b06bf4e87c/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. I built it for the hiring-manager round, as you described it.

Say the word and I'll play the Skeptic on A2, the dossier's objection and the highest-ROI prep in the pack.
I can also save a tuesday-dossier.md with this pack's pack_feedback, recording what rehearsal exposes for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** 45-minute conversation with the hiring manager, Thursday
- **Interviewer:** not named. Relationship: hiring manager, as you described it.
- **Basis:** the dossier you pasted (dated 2026-08-14, decision conditional_go). Consumed: `role_profile` (the JD tier), `handoff_to_mock_interview` (all six fields), and `decision` (context only).
- **Check before Thursday:** the dossier is 104 days old. If the posting has changed, rows F1 to F6 need regenerating.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script; say the answer in your own words.

Type key: **EXP** work-experience deep-dive. **JD** the role's stated requirement or responsibility. **CASE** a live problem from the role. **VAL** values (none in this pack). **CO** company strategy (none in this pack; research did not run).

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | The quote is adjacent work and does not reach product management. Bridge at its own scope, in the quote's words. The limit, in your words: "I haven't held a product manager title." That acknowledgment is named by field, from prohibited_claims. No slot asks about PM work. |
| F2 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | Words, named by field acknowledge_gap and prohibited_claims: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then the ramp, said as a plan and never as a past: how you would learn how the two squads set priorities before you set anything. No bridge and no answer slot on this area. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | high | [grounded] | presentation | Reword only these two quotes: the REST API work and the playbook. Schemas are not in your material. Answer slot: if you wrote or reviewed API schemas, say so in your own words; if you did not, say so and stay with the REST integration work. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Customer and product contact is in your material; engineering and sales are not. Name the customer side from V1 and the product side from V3, with V3's caveat named. Answer slot: if you worked with engineering or sales on an integration, say how; if you did not, say so and stay with the customer and product work. |
| F5 | "Agile delivery experience" (dossier role_profile R5; uncertain_or_weak_areas) | none given | low | [grounded] | discovery | No verified entry speaks to agile delivery, so no quote is offered. Clarify form: answer slot. If you worked in sprints or from a backlog, say how. If you did not work that way, say so, and say what you would want to confirm about how this team defines agile delivery. |
| F6 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | This row is the pack's own reading; the dossier does not list it as a weak area. Your material shows client integrations against a vendor's API. It does not show a platform product you shipped. Bridge stays at V1's scope. Answer slot: if you shipped an API or platform product, name it and your part in it; if the nearest thing was the integration work, say so. |

Verified evidence, indexed in the order of the dossier's `verified_candidate_evidence` list: V1 is the first entry, V2 the second, V3 the third. V1 is high confidence with an inspectable playbook. V2 is high confidence and inspectable. V3 is medium: confirmed, with limited inspectable proof, so expect a probe.

No hard gates. The dossier lists none, and the material shows none.

## 2. Persona table

Weights come from the hiring-manager prior in the persona model (Case/Strategist plus Skeptic). The dossier adds one interviewer signal: the JD's own unknowns, namely decision authority and the adoption baseline. There is no interviewer profile and no loop source, so no further adjustment.

| Persona | How it shows up in this round | Likelihood and weight | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the PM-title gap, the roadmap gap, and the "why you" question | Top weight (5). The dossier names the PM-title objection, and it is the most predictable question in the round. | Plain acknowledgment, then a bridge limited to quoted scope, then a ramp plan as a plan. |
| Case/Strategist | Live problems from the roadmap, adoption, and two-squad work | Top weight (5). The hiring-manager prior is strong, and the JD assigns roadmap and delivery work. | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober | Asks how the 30+ figure was counted and how adoption would be measured | Mid weight (3). The JD names adoption metrics, the dossier records no baseline, and the V1 figure will draw a count question. | Defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| Conversational | Opens with "walk me through the journey" and asks what you are using in API tooling | Low weight (2). Casual questions still get scored. | A 90-second arc built on the quotes. |
| Pressure | "Why you over an internal candidate?" and "how much of that was actually you?" | Low weight (2). The title gap is the pressure point. | Hold the quoted scope through two follow-ups, then concede the specific gap. |

## 3. Question banks

Weights are as in section 2: Skeptic 5, Case/Strategist 5, Prober 3, Conversational 2, Pressure 2. Depth follows weight.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims "Having owned a product roadmap" | Name roadmap ownership first, in plain words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then the ramp, as a plan: how you would learn how the two squads set priorities before you set anything. No bridge here. | F2 is the gap the dossier marks as capability with no credible evidence, so the answer is the acknowledgment and a plan. The question presupposes nothing about you. |
| A2 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap" | Highest-ROI prep in the pack. Acknowledge in one breath: "I haven't held a product manager title, and I haven't owned a product roadmap." Hold on the scope you ran: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Follow-up one pushes on PM work: return to the same scope, not a larger one. Follow-up two pushes on why you: concede the specific gap. "Roadmap ownership and prioritization are the part I haven't done. My first step would be learning how the two squads set priorities before I set anything." Never argue that integration work equals product work. | The dossier named this objection, and its negatives are the dossier's own prohibited items, so the question keeps them as written. F1 and F2 are the rows it draws on. |
| A3 | "What's the nearest thing to a shipped API product in your work?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: if you shipped an API or platform product, name it and your part in it, in your own words. If the nearest thing was the integration work, say that and describe it in V1's terms. | F6 is the must-have no quote reaches. The question asks for the nearest thing and does not presuppose a shipped product. |
| A4 | "How do you run agile delivery with product and engineering partners?" | JD | [grounded] | Answer slot: if you worked in sprints or from a backlog, say how. If you did not work that way, say so, and say what you would want to confirm about how this team defines agile delivery. | F5 is a discovery gap with no verified evidence. The clarify form asks for the requirement's own wording and allows the honest branch. |
| A5 | "What draws you to a product role now?" | JD | [generic] | Say what you want from the work, in your own words. Nothing in your material says it, so this pack has nothing to quote. Keep the answer on the partner API work. | The skeptic runs this probe on any move from integration into product (F1). Motivation is silent in the material, so the guidance is a selection instruction. |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration adoption has been flat for two quarters. What do you check first?" | CASE | [generic] | Clarify what "adoption" counts before proposing anything. The JD names adoption metrics and your material states no baseline. Then segment by partner, by integration stage, and by the API version the partner calls. Then one approach, the metric you would watch, and the main risk. | A live problem from the JD's adoption responsibility. The dossier's open unknown is the baseline, so the answer starts by asking for it. |
| B2 | "Walk me through your first 90 days owning the roadmap for a partner-facing API platform." | CASE | [generic] | Name the decision you would confirm with the squad leads before committing to any plan. The dossier records decision authority as unknown. Then the first 30, 60 and 90 days, as a plan. Say it is a plan, not a record. | The question's premise is the JD's own responsibility. The answer states the unknown rather than claiming authority you have not had. |
| B3 | "Two engineering squads want different things from the same API. How do you decide what goes first?" | CASE | [generic] | Name who decides before you say how. Your material does not say whether the squad leads or the product owner holds the call, so ask it, and say you would confirm it. Then criteria: partner impact, effort, and risk to existing integrations. | The dossier leaves decision authority open, and the JD gives delivery to two squads. A case that does not say who decides loses on structure. It asks nothing about your past. |
| B4 | "What would you need to know about our integration partners before writing a spec?" | JD | [generic] | Name what you would ask: which partners, what they build against, where their integrations break, and what they would lose if the API changed. Describe discovery as a plan. | Covers the JD's discovery and spec responsibilities with a pattern, not a claim about your history. |
| B5 | "Engineering wants to ship a change that breaks a partner commitment sales has made. Who do you go to first, and what do you do?" | JD | [generic] | Name the stakeholders in order, and the decision you need from each. Name the customer's commitment as the thing to protect. Give a sequence, not a past event. | A live version of R4, stakeholder management across engineering, sales and customers. Your material does not show that work, so the answer stays in the hypothetical. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend-the-number slot. The figure 30+ is yours. Answer in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did not count them, or the count was not yours, say so plainly and describe the integrations you led. | The headline figure is where probers start. The defend-the-number slots apply to the figure only. |
| C2 | "Your team uses the integration playbook you wrote. How do you know it's used, and what would you count?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Story-mapped on V2: you wrote it, and the team uses it. Answer slot: if you measured use, say what you counted. If you did not, say so, and say what you would count first. | V2 is the most inspectable claim, and the adoption metric in the JD is the same kind of measure. The adoption baseline is still unknown, and a reverse question returns to it. |
| C3 | "What did the quarterly roadmap-input sessions feed into, and how would you show it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Medium confidence: volunteer the limit before the probe. The sessions fed client evidence to product, and you should say that in those words. Answer slot: if you saw what product did with the evidence, say what you saw. If you did not, say so and stop at the evidence. | V3 is confirmed with limited proof, so the question tests whether the sessions moved a decision. F2 means the answer must stop at feeding evidence. |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | A 90-second arc: the integration work (V1), the playbook (V2), the product-facing sessions (V3), then the move you are making, in your own words. Use only these three beats and add no product claim. | Casual openers are scored. The three quotes are the whole arc. |
| D2 | "What are you playing with in API docs and schemas these days?" | JD | [generic] | Answer slot: name what you have used, and what you have only read about, in your own words. If you have not worked with schemas, say so, and name the closest API work you have done. | R3 is important, not must-have, and no quote carries schema work. Casual wording is still scored. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); prohibited_claims "Having held a product manager title or role" | Hold the scope and the playbook for two follow-ups. Concede the title specifically: "An internal candidate may have held a PM title and owned a roadmap. I haven't held the title." Do not fold on the integration work. | The pressure version of the PM-title gap (F1). The answer holds what is quoted and concedes only the named gap. |
| E2 | "That 30+ figure — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend-the-number, under pressure. Hold through two follow-ups. Answer slot: if the integrations were yours to lead, say which parts. If some were shared, name the shared part and keep the lead you had. | The attribution probe is the test of V1. The hold is the scope the quote carries. |

### Requirement coverage

| Requirement or responsibility (source) | Covered by |
|---|---|
| 3+ years product management experience (R1) | A1, A2 |
| Shipped API or platform products (R2) | A3 |
| Technical fluency: API docs, schemas (R3) | D2 |
| Stakeholder management across engineering, sales, customers (R4) | B5 |
| Agile delivery experience (R5) | A4 |
| Own the roadmap for the partner-facing API platform (responsibility) | B2, A1 |
| Run discovery with integration partners (responsibility) | B4 |
| Write specs and drive delivery with two engineering squads (responsibility) | B3 |
| Define and track adoption metrics (responsibility) | B1, C2 |

The pack has 17 questions, one under the roughly 18 floor. The shortfall is the Pressure and Conversational banks, which are low-weight. No CO or CASE question is grounded in company strategy, because research did not run.

## 4. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It asks the decision-authority question the JD leaves open. The JD names the two squad leads and the material shows no authority over them. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics and the material states no baseline. The answer gives you the number the defend-the-number questions will need. |
| RQ3 | "What would a PM in this role be expected to have decided by the end of the first quarter?" | It turns the day-one gap into something you can check against the answer. |
| RQ4 | "When a partner request conflicts with a squad's plan, who makes the call, and how fast does it usually come?" | It tests the squad-authority line with a live case, not an abstract one. |
| RQ5 | "What does a good partner-facing API release look like here, from discovery through adoption?" | It shows you are reading the JD's whole loop, from discovery to adoption metrics, and it gets the team's own definition of done. |

## 5. Prohibited claims

What this pack will not coach, and why. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | dossier prohibited_claims: "Having held a product manager title or role" | Plain acknowledgment: "I haven't held a product manager title." Named by field, prohibited_claims. |
| Owned a product roadmap | dossier prohibited_claims: "Having owned a product roadmap"; acknowledge_gap area | Plain acknowledgment: "I haven't owned a product roadmap." Named by field, prohibited_claims and acknowledge_gap. |
| Set prioritization for an engineering squad | dossier prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." Named by field, prohibited_claims. |
| Set what product decided from the roadmap-input sessions | Inflated form of V3, built locally | V3 at its own scope, quoted: "feeding client evidence to product." The limit is the pack's observation only: the material says the sessions fed evidence, not that you set what product decided. No first-person negative. |
| Shipped API or platform products | Inflated form of V1, built locally (F6) | V1 at its own scope, quoted. The limit is the pack's observation only: the material shows integrations against a vendor's API, not a platform product shipped. No first-person negative. |

The dossier's decision summary says "seven years of integration leadership." No verified entry carries that span, so no line of this pack uses it. If it is true, give it to the pack as your own sentence, and it can then be quoted.

## 6. Sources

- **Provided documents:** the dossier you pasted in this conversation (dossier_version 1.1, generated 2026-08-14). Consumed: `role_profile` (JD tier), `handoff_to_mock_interview` (all six fields), `decision` (context only). Labels V1 to V3 index the dossier's `verified_candidate_evidence` list in order.
- **Searches sent:** three. All three were refused, and no URLs came back.
  - "Quartzline company values" (refused)
  - "Quartzline interview process product manager platform APIs" (refused)
  - "Quartzline partner API platform news strategy" (refused)
- **Fetches:** none.
- **Consequence:** there is no values cheat sheet, no loop structure, no strategy brief, and no CO questions. Company-level questions in the banks are generic.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | A values cheat sheet. Every call was refused. The round is a hiring-manager round, not a values-style one, so the section is dropped either way. |
| 2. Quartzline interview process | unavailable | Loop structure. Every call was refused. The round is already known, so persona weights rest on the hiring-manager prior. |
| 3. Quartzline strategy / recent news | unavailable | CO questions and a grounding brief. Every call was refused. |
| 4. interviewer name | n/a | No name was given, so there was no query to form. The upgrade menu says what a name would unlock. |
| 5. representative JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions. |

## 7. Upgrade menu

- Web search allowed for this session → the values, interview-process and strategy rows; a values cheat sheet if values are published; CO questions.
- The current posting text → checks the dossier's 104-day-old requirement lines. Rows F1 to F6 regrade if the wording changed.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Your own sentence on the "seven years" span → F1's bridge gains its span. Not used until you give it.
- A CV line on any API or platform product you shipped → F6 moves from transferability toward presentation, and A3 becomes a story.
- Your words on any engineering or sales work on an integration → F4 upgrades, and B5 and the F4 slot gain material.
- Your words on schema or API-doc work → the F3 slot fills, and D2 gains a story.
- Any named focus areas from the recruiter → the persona weights and the coverage table.
