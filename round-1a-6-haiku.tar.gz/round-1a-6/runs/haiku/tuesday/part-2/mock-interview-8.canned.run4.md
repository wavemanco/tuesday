Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-8-canned-ecc56f6e/ashgrove_member-experience-lead_interview_pack.md. I built it for the three scheduled rounds, in loop mode, with one mini-pack per round. It's also attached above.

Assumptions I made instead of asking:
- **5 December 2026 is a Saturday.** Confirm the date, times and format with the recruiter before you plan around them.
- Interviewer names are unknown, so the personas come from round type.
- The strategy figures come from your summary, not the brief itself. Check them against the brief before you quote them.

The biggest risk is the contact-centre gap. The JD puts the contact centre in scope and you have never worked in one. B5 is the question to rehearse hardest: hold with the plain line, bridge to the branch complaints log, then give your plan for learning the contact-centre side. The pack also marks the stated gaps: no presenting above regional level (B7), and "trained tellers," not "coached supervisors" (B6). It never supplies a story, a figure or a pay, notice, location or reason that you did not give. Where you have no story, the pack tells you to say so.

Run the 20-minute escalation case (C7) timed at least twice before 5 December. The plan in the pack gives the structure. Don't assume Ashgrove's complaint timescales; ask at the start.

Two offers, neither pushed:
- I can run a live drill on B5 with the Skeptic's follow-ups.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Loop:** three scheduled rounds on 5 December 2026, run in loop mode
- **Round 1:** recruiter, 30 minutes
- **Round 2:** Head of Member Services, 45 minutes, mostly behavioural, your future manager (name not given)
- **Round 3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; the values round (names not given)

**Built on:** your message (background and JD as you pasted them), the values text you copied from ashgrovecu.org/about/values on 26 November 2026, and your summary of the July 2026 strategy brief as the recruiter sent it.

**Assumptions I made instead of asking:**
1. Round format (video or in person) is unknown. The pack works for either.
2. Interviewer names are unknown, so personas come from round type, not from interviewer profiles.
3. 5 December 2026 is a **Saturday**. Confirm the date, times and format with the recruiter before you plan around them.
4. No CV was provided. Your evidence is the background paragraph in your message.
5. You have not given pay, notice, location or reason for leaving. The pack supplies none of them.
6. The strategy figures are from your summary. The brief itself was not in my inputs.

## 2. How to use, and the type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural and values; EXP = experience deep-dive; JD = role requirement; CO = company and strategy; CASE = live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Provenance** shows the sentences each guidance cell rests on. If a cell says nothing about you, it carries only its label.
- **Answer slots** end with "if ...; if not, say so". They are instructions for the interview. They are not questions to me.
- If a story is not in your material, the pack says so. Do not fill the gap.

## 3. Prep triage (26 November to 5 December: nine days)

1. **The contact-centre objection (B5, and again in C5).** The JD puts the contact centre in scope and you have never worked in one. This is the most predictable question you will get. Rehearse the plain acknowledgment, the bridge to the branch log, and your plan, until it is boring.
2. **The 20-minute escalation case (C7).** Run it timed twice: once cold, once after the structure below.
3. **The values map (Round 3 section).** One story per value where your material carries one. Where it does not, say so.
4. **Presenting.** You have never presented above regional level, and the JD asks for it. Practise a three-minute walkthrough of how the complaints spreadsheet is structured. Use no member data, in practice or in the room.
5. **Logistics answers (A3 to A6).** Decide your own answers to pay, notice, location and reason for leaving.

Everything else is insurance.

### Day by day to 5 December

- **Thu 26 Nov (today):** Email the recruiter to confirm Saturday 5 December, the times, the format, the interviewers' names, and whether the case will be sent in advance. Write your own answers to A3 to A6.
- **Fri 27 Nov:** For each value, write a story only where you have a real one. Draft your first three steps for the contact-centre question (B5).
- **Sat 28 Nov:** Rest. Read the pack once. Add no new material.
- **Sun 29 Nov:** Round 1 run. Say A1 to A6 aloud, timed at five minutes.
- **Mon 30 Nov:** First timed escalation case (20 minutes), cold, from the structure in the plan. No notes.
- **Tue 1 Dec:** Three-minute walkthrough of the spreadsheet's structure, to a colleague. No member data.
- **Wed 2 Dec:** Full Round 2 run with a colleague playing the Skeptic on B5 to B7, then the pressure form C5.
- **Thu 3 Dec:** Second timed escalation case. Revise the values map. Check each line you would say against your own quotes.
- **Fri 4 Dec:** Light review of the triage list and your logistics answers only. Confirm the time, the place or link, and the names if they have been sent.
- **Sat 5 Dec:** Interview day. Round 1 (30 minutes), Round 2 (45 minutes), Round 3 (60 minutes, including the 20-minute case). Times to be confirmed.

## 4. The fit snapshot

Requirements are quoted from your JD. Evidence is quoted from your message. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | "Six years in retail banking, three of them as a branch supervisor." Self-reported. An employer reference would show it. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | "I handled the branch's formal complaints log." The quote reaches the requirement in other terms. Answer slot: if the log carried a regulatory timescale or a regulator-facing review, say which and what you did; if it did not, say so and stay with the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | "I handled the branch's formal complaints log," at its own scope: one branch. Answer slot: if you followed any complaint from first contact to closure, say which steps were yours; if none were, say so and describe the nearest stage you ran. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | "I haven't worked in a contact centre." Then how you would learn its workflow, said as a plan and never as a past. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | low | [inferred] | transferability | "I trained new tellers on our escalation script." Tellers, not supervisors. Do not stretch it. Answer slot: if you coached a supervisor on an escalation, say what you did; if not, say so and say how you would coach one. |
| F6 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | "I built the monthly complaints spreadsheet our regional manager uses." Volumes are reached; resolution times are not in the quote. Answer slot: if the spreadsheet tracked resolution times, say how they were measured; if not, say so and say what you would add first. |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | none | "I built the monthly complaints spreadsheet our regional manager uses." Say "Excel" only if it was Excel. The spreadsheet itself is the artifact an interviewer can inspect. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or product team, say what the work was and what was yours; if not, say so and say how you would bring the member's side of a complaint to them. |

**Gates.** The JD states no gate (no licence, location or schedule term). No row is `hard_gate`. Whether the role's office pattern changes after the hub plan is in the upgrade menu.

## 5. Grounding brief: the strategy, from your summary

Source: your summary of the July 2026 brief. Verify the figures against the brief before you quote them in the room. The brief is about four months old, inside the six-month freshness window.

- "move 40% of member service to digital channels by 2028": complaints will move to the app and its routing will change.
- "consolidate eight branches into five hubs over 2027": a complaint's home changes when a branch goes. The member's side of the counter has to survive the move.
- "launch a small-business lending product in Q1 2027": expect new complaint types, which may face more scrutiny.
- "the main competitive pressure is app-only banks": member expectations on speed and channel.

**How to use it:** do not argue for or against the hub plan. Talk about keeping the member's complaint whole through the change. "Neighbours, Not Numbers" will be tested here.

## 6. Prohibited claims

These are the claims this pack will not coach, and why. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." Limit, as the pack's own observation: your material describes one branch's log, not a process across branches or the contact centre. |
| Have worked in a contact centre | Negative you stated, F4 | "I haven't worked in a contact centre." Plain acknowledgment. No slot. |
| Have presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." Plain acknowledgment. No slot. |
| Coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." Limit, as the pack's own observation: teller training, not supervisor coaching. |
| Tracked and reported resolution times | Inflated form of F6 | F6's quote at its own scope. Limit, as the pack's own observation: the quote names the monthly spreadsheet, not resolution times. |

Digital self-service (F9) is not listed. Your material is silent on it, which makes it an answer slot, not a prohibited claim.

## Round 1: recruiter screen (30 minutes)

**Persona weights.** Recruiter screens lean conversational, with a light Skeptic. Logistics (pay, notice, location, reason for leaving) is the recruiter's own row, not a persona, so A3 to A6 are logistics slots.

| Persona | Likelihood and reasoning | Counter-strategy |
|---|---|---|
| Conversational (3 questions) | High. The relationship prior for a recruiter screen. Casual questions are scored. | Pre-scripted 90-second arc. Treat casual JD questions as scored. |
| Skeptic, light (1 question) | Medium. The recruiter screens gaps, but gently. | Plain acknowledgment, then your bridge, then stop. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | 90-second arc: six years in retail banking, the last three as a branch supervisor; the formal complaints log; the monthly spreadsheet your regional manager uses. Tell each beat in your own words. Add nothing to any beat. | Opening question. It is casual and still scored. It draws on F1, F3 and F7. |
| A2 | "Is there anything in this role you'd be weakest at?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain line first: "I haven't worked in a contact centre." Then the log. Then the plan for learning the contact-centre side. Do not hide the gap. | The recruiter's version of the objection. A short, plain answer here sets up B5. It draws on F4 and F3. |
| A3 | "What are your pay expectations?" | JD | [generic] | Logistics slot. Give your own number, or ask what band the role carries first. The pack supplies no figure. | Required logistics row. |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | Required logistics row. |
| A5 | "Where are you based, and what office pattern could you work?" | JD | [generic] | Logistics slot. Give your location and office pattern in your own words. If the office pattern after the hub plan is unclear, ask what it is before answering. | Required logistics row. Location matters because of the 2027 hub plan. |
| A6 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot. Give your real reason in one or two sentences. The pack supplies no reason. | Required logistics row. |
| A7 | "What would make this role a good move for you?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Name one thing you want from the role and why, in your own words. You may mention the complaints process end to end. Do not claim knowledge of the brief beyond your summary. | Conversational close. It tests whether you have read the strategy. |

**Reverse questions (Round 1, each with why it lands):**
1. "What complaint volume does this role carry, and how does it split across branches and the contact centre?" Why it lands: shows you think in numbers and scope.
2. "How do the three rounds differ, and who scores what?" Why it lands: shows you want the rules before the game.
3. "Is the digital self-service work inside member services or with a separate team?" Why it lands: shows you read the JD's digital line.
4. "Where does this role sit once the hub plan is in place?" Why it lands: shows you read the strategy and the location issue.
5. "What does a good first three months look like for this role?" Why it lands: shows you plan in time.

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights.** The relationship prior for a hiring manager is Case plus Skeptic. Your recruiter says the round is mostly behavioural, so Values/Behavioral moves to the top.

| Persona | Likelihood and reasoning | Counter-strategy |
|---|---|---|
| Values/Behavioral (4 questions, top) | High. Your recruiter called the round mostly behavioural. | STAR shape. "We" for context, "I" for contribution. |
| Skeptic (4 questions, co-top) | High. A manager is buying capability and checking the gaps in F4, F5 and F8. | Plain acknowledgment, bridge, plan. Hold the bridge. |
| Case/Strategist (2 questions, low) | Medium. Behavioural rounds still include a live problem. | Clarify, then structure, then one challenged premise. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something unwelcome. It needs a named stake, what you actually said, and what happened after. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the log you handled, or how you would handle it. | An unpopular-truth probe. No quoted sentence carries one, so this is a scaffold, not a story. |
| B2 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [generic]; [grounded] "I handled the branch's formal complaints log" | Scaffold: pick a case you carried from first report to fixed. Who else had a stake, and what did you do when it stalled? If you did not carry one to a fix, say so, then describe the nearest complaint you handled through the log. | Maps to Own the Fix. The log is the nearest quoted fact. |
| B3 | "Tell me about a time a report you produced changed what someone did." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say whose decision changed and what it was. The quote says you built the spreadsheet and your manager uses it. If nothing changed because of it, say so and say what the report is for. If it tracked resolution times, say how they were measured; if not, say so (F6). | Tests whether reporting drives action. It covers the monthly reporting line and the Excel line. |
| B4 | "Tell me about a complaint where a regulatory or time limit shaped what you did." | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot (F2): if a timescale or regulator-facing review applied, say which and what you did in your own words; if one did not, say so and stay with the log. | Scores "experience handling regulated complaints." The JD raises regulation, so this is a fair question. |
| B5 | **Highest-ROI prep.** "You've never worked in a contact centre. How would you run complaints across one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Hold: "I haven't worked in a contact centre." Then: "What I have run is the branch's formal complaints log." Then your plan: how you would learn how a contact centre logs and routes a complaint. Hold through two follow-ups by returning to the log and the plan. Concede specifically if pushed: "I don't yet know how a contact centre records a complaint; I would find out in my first weeks." Never claim contact-centre knowledge. | The JD puts the contact centre in scope, and F4 is a stated gap. This objection will come in some form. |
| B6 | "How would you coach a branch supervisor through an escalation they had handled badly?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot (F5): if you coached a supervisor on an escalation, say what you did and what changed. If you did not, say so, then say how you would start: what you would ask the supervisor to show you first. | Scores "coach branch supervisors on escalations." Your evidence is teller training, so the bridge stays adjacent. |
| B7 | "Tell me about the most senior audience you've presented to, or how you would prepare for one." | JD | [grounded] "I've never presented to anyone above regional level" | Plain line: "I haven't presented to anyone above regional level." If you presented at regional level, say what it covered and who was in the room. Then the plan: a three-minute walkthrough, rehearsed with a colleague. | F8 is a stated gap and the JD asks for presenting to senior leaders. |
| B8 | "Tell me about a time you worked with a team outside your branch on a process change." | VAL | [generic] | Scaffold: pick a time you worked across a boundary. If none comes to mind, say so, then give the nearest thing your material carries, or how you would approach a digital team. | Maps to the JD's digital line (F9). Your material is silent on it, so this is an answer slot, not a story. |
| B9 | "A branch's complaint category has risen sharply over two months. What do you check first?" | CASE | [generic] | Clarify what counts as the category. Check whether the rise is in volume or in mix. Check whether any channel changed. Then say who you would speak to and name the weakest assumption in your own count. | A live problem drawn from F6's reporting. It presupposes nothing about you. |
| B10 | "Members start moving to self-service. How would you find out whether a new app journey is causing complaints?" | CASE | [generic] | Set a baseline. Split complaints by channel. Ask for the journey's failure points. Work with the digital team. Check repeat complaints. | Ties the digital line (F9) to the strategy's 40% target. |

**Reverse questions (Round 2):**
1. "What does the first 90 days look like for whoever takes this role?" Why it lands: shows you plan in time.
2. "How are branch supervisors supported on escalations today?" Why it lands: tests whether coaching is real, not stated.
3. "Which complaint trend worries you most at the moment?" Why it lands: shows you are tracking the work.
4. "How will the member complaints process work when branches move into hubs in 2027?" Why it lands: shows you read the strategy.
5. "Where does digital self-service sit: inside member services or with a separate team?" Why it lands: follows the JD's digital line.

## Round 3: panel of two branch managers (60 minutes; values round; 20-minute escalation case)

**Persona weights.** Names are unknown, so the panel is a blend of the top two personas per member. Member A: Values/Behavioral and Pressure. Member B: Case/Strategist and Peer Evaluator. The 20-minute case is the scored part. Your recruiter says the panel scores against the four values.

| Persona | Likelihood and reasoning | Counter-strategy |
|---|---|---|
| Values/Behavioral (4, Member A) | High. The recruiter says this is the values round. | Map one story per value, and say so where none exists. |
| Pressure (2, Member A) | Medium. Branch managers are senior to you. A time-boxed challenge is likely. | Pause, restate, hold through two follow-ups, then concede specifically. |
| Case/Strategist (1 plus the 20-minute case, Member B) | High. The case is in the brief. | Clarify, objective, segmentation, approach, metrics, risks. |
| Peer Evaluator (1, Member B) | Medium. Branch managers will care where the seam sits with their decisions. | Propose seam principles. Do not pretend to know their policy. |

### Values cheat sheet (values round)

Values are quoted from the Ashgrove page as you pasted them.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold C1. If you cannot name one, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | "trained new tellers on our escalation script" (F5). Beats: you taught the script to tellers. Scaffold C2 for what changed when an explanation did not land. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold C3. Honest branch applies. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I handled the branch's formal complaints log" is the nearest quoted fact. Scaffold C4. |

### The 20-minute escalation case: plan

The live case will differ from this one. The practice version is: *A member's fee dispute has been passed between two branches for three weeks. They now ask for someone senior. You are the first person who owns it.*

- **0 to 3 minutes, clarify.** What does the member want? What has been done so far? Which deadlines apply? Is the member vulnerable? Ask before you structure.
- **3 to 6 minutes, objective.** One owner. The member told in plain words. The complaint closed, not passed on.
- **6 to 10 minutes, approach.** Name the owner today. Contact the member within a timescale you state. Check Ashgrove's own timescales; do not assume them. Fix the cause. Write the plain-words reply. Coach the branch supervisor involved. Log it.
- **10 to 14 minutes, metrics.** Time to first contact, time to resolution, reopen rate. Name the one you trust least and why. That is your weakest assumption.
- **14 to 18 minutes, risks.** Repeat complaints. A member moving between branch, phone and app. A regulatory deadline you have not checked.
- **18 to 20 minutes, summary.** Restate the owner, the next step, and one premise you would challenge.

**Honest-use rule for the case.** You may refer to the escalation script you taught tellers. Say that its contents are your own, not Ashgrove's standard.

### Round 3 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a member's position first, when the process pointed elsewhere?" | VAL | [generic] | Scaffold: pick a time you decided from the member's side. Name the stake, what you chose, and what the member got. If none comes to mind, say so, then give the nearest handled complaint from your log and how you would decide. | Members First. No quote carries a story. |
| C2 | "When have you changed how you explained something to a member or colleague? What prompted it?" | VAL | [grounded] "trained new tellers on our escalation script" | Beats: you trained tellers on the script, in your own words. Answer slot (F5): if you changed the explanation after someone did not understand it, say what you changed; if you did not, say so. | Plain Words. The quote carries the training, nothing more. |
| C3 | "Tell me about a time a local situation changed how you handled a branch matter." | VAL | [generic] | Scaffold: pick a time a branch's local context shaped a decision. If none comes to mind, say so plainly, then describe the nearest decision your branch role made. | Neighbours, Not Numbers. No quote carries one. |
| C4 | "Tell me about a problem you took from first report to fixed. What did you do when it stalled?" | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: pick a complaint you held to resolution. If you did not hold one to the end, say so, then describe the nearest complaint from the log, at its own scope. | Own the Fix. The log is the nearest fact. |
| C5 | **Pressure, Member A, time-boxed.** "Sixty seconds: why would we trust someone who has never worked in a contact centre to run complaints across one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Pause. Restate: "You're asking whether I can run complaints across a contact centre I haven't worked in." Then: "I haven't worked in a contact centre. What I have run is the branch's formal complaints log." Hold through two follow-ups. Concede specifically: "I don't yet know the contact centre's systems." | Same gap as B5, in pressure form. |
| C6 | **Pressure, Member A.** "How much of the branch's complaints log was your call, and how much was set for you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Attribution. Say which parts you decided and which were set by process, in your own words. If none were yours to decide, say so. Do not claim decisions the quote does not support. | The "how much was actually you" probe. The quote says handled, not decided. |
| C7 | **Case, Member B.** The 20-minute escalation case (see the plan above). | CASE | [generic] | Follow the structure above. Think aloud. Challenge one premise. | The scored case. It presupposes nothing about you. |
| C8 | "Where does a branch manager's decision end, and the complaints lead's begin?" | JD | [generic] | Propose seam principles: who decides a refund, who decides escalation, who owns the member after a branch decision. Do not pretend to know their policy. Reciprocity: ask what branch managers would need from you. | Peer seam. It also covers "coach branch supervisors." |
| C9 | "Forty per cent of member service is moving to digital by 2028. What happens to complaints in that shift?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Name the risks: complaints moving to the app, responses moving with them, one owner per complaint. Keep the member's side of the counter visible on the screen. Do not claim detail beyond your summary. | Strategy fluency. It answers the digital line (F9) at altitude. |

**Reverse questions (Round 3):**
1. "Where do branch managers and the complaints lead split the escalation decision?" Why it lands: sets the seam before you need it.
2. "What does a good escalation look like in your branch?" Why it lands: specific, and it builds on their answer.
3. "Which complaint pattern would you want fixed first?" Why it lands: shows Own the Fix.
4. "What could a new person do in their first month that would genuinely help your branch?" Why it lands: the reciprocity question for a peer panel.
5. "How will complaints be handled for members when branches move into hubs?" Why it lands: shows you read Neighbours, Not Numbers into the strategy.

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| 4+ years in financial-services customer operations | A1, B2 | F1. |
| Own the complaints process end to end across branches and the contact centre | B5, C4, C5, C7 | F3, F4. |
| Experience handling regulated complaints | B4 | F2. |
| Report monthly on complaint volumes and resolution times | B3, B9 | F6. Resolution times are answer-slot only. |
| Coach branch supervisors on escalations | B6, C2, C8 | F5. |
| Work with digital teams on self-service journeys | B8, B10, C9 | F9. |
| Confident presenting to senior leaders | B7 | F8. |
| Comfortable with Excel reporting | A1, B3 | F7. |

## Sources

- **Provided documents:** your message (background, JD, round descriptions); the values text from ashgrovecu.org/about/values as you pasted it on 26 November 2026; your summary of the July 2026 strategy brief.
- **Queries sent:** none.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values section and the values map. |
| 2. Interview process | skipped | Your recruiter's email names the three rounds and the values round. That loop source establishes the loop, so a search would not move it. |
| 3. Strategy or recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief and C9. Verify the figures against the brief. |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Head of Member Services' name → personas read from their public footprint, and a tailored reverse question for Round 2.
- The two panel members' names → per-member persona weights in Round 3.
- Round format, and confirmation that 5 December is the right date (it is a Saturday) → schedule and delivery notes.
- The strategy brief pasted in full → the four figures verified against the source, and C9 and the grounding brief quoted exactly.
- The recruiter's scoring sheet for the four values → the values map matched to their wording.
- Any presenting you did at regional level → B7's answer slot becomes a story.
- Whether your complaints spreadsheet tracked resolution times → F6 and B3 move from discovery to grounded.
- Any digital or product team work → F9, B8 and B10 get a quoted story.
- Your own pay, notice, location and reason for leaving → A3 to A6 quote your words, and the pack keeps the logistics slots until then.
- Any complaint handling you did by phone, if it happened → an honest quote for F4's bridge. If it did not, the stated gap stands.
