Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-2-denied-681a94f8/09c69f02-522b-4107-af39-caaab92d40da/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it as a hiring-manager round, since your note didn't say who you're meeting. My web searches on Atlas Freight were refused permission, so the pack has no company facts. Everything about the company is from your JD text.

The three things to rehearse, in order:

1. **A2, the leadership-span question.** The JD asks you to lead 12 supervisors across 4 sites. You lead 3 at one site. Answer from the three you run, concede the gap plainly, and don't add a span you haven't run. A1 covers the five-year bar, which is the same objection.
2. **B1 and B2, the 40% mis-pick result.** Expect "how was it counted?" and "how much of it was actually you?" Know the assumption you'd defend least, and say whose part of the pick-path redesign was yours. Your sentence says "redesigning" without saying whose it was.
3. **A4 and D3, Excel and Power BI.** Say "I haven't used Power BI" plainly, then give a learning plan. Don't claim it's quick to pick up.

The JD also asks for on-time performance and cost-per-shipment, and your material only shows mis-pick. B3 covers that. If you did track those two numbers, that's worth knowing before the interview.

Drill offer: I can play the Skeptic on A2 and give feedback against that question's guidance.
Dossier offer: I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
Word offer: If you want the pack as a Word document, say so and I'll convert it.

Who are you meeting, and what round is it: hiring manager, a peer, a panel, or a recruiter screen? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not named. Round: not stated, so this pack is built as a hiring-manager round with flat-leaning persona weights. Recompute once you tell me the round and who you are meeting.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse your answers in your own words, and only about what you actually did.

Type key:
- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims hold up under scrutiny, and what exactly was yours
- **CASE**: how you structure a live problem from this role
- **CO** and **VAL**: not used. No company research ran and no values were found.

## Prep triage (interview is next week)

1. Rehearse A2 and A1 aloud until they are boring. They are the leadership-span and five-year objections, and the JD raises both.
2. Rehearse B1 and B2. The 40% mis-pick result is the headline number on your CV and the first thing a prober will test.
3. Rehearse A4 and D3. Excel and Power BI are the clearest gap in the JD.
4. Do C1 once for structure. Everything else is insurance.

## Fit snapshot

JD requirement quotes are from the JD text you pasted. Evidence quotes are your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | discovery | Your material shows seven years in operations but not how many of them were leadership. It does not establish the five-year leadership bar. Answer slot: say when you first led people in operations, in your own words. If it has been fewer than five years, say so plainly and say which part of your record you would stand behind. Length of experience is graded on fit, not treated as a gate. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the bridge stays at three. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: describe how you would run a layer of twelve, as a plan, and say what you have not yet run. |
| F3 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message); "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material places all of this at one site. Words: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run operations across more than one site, say which and how. If not, say you have run one site and describe how you would run four. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material has a mis-pick result, not on-time performance or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say which and what moved. If not, say so and say what you would measure first. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | discovery | Your material says Excel skill but shows no report you built. Answer slot: name a report you built in Excel, who used it and what decision it changed. If none, say so. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "Green Belt certified" (your message) | medium | [grounded] | none | The certification reaches the requirement. Lead with it by name. A probe on applied projects is likely; see A6 and B4. |

Gate rows: none. The material shows no location, schedule or work-authorisation term in the JD text you gave, so none is surfaced as a gate.

## Prohibited claims

What this pack will not coach, and why. Each entry is an inflated form of something you said, or a negative you stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Led twelve supervisors, or leads a team of 12 | Inflated form of F2 | "I'm currently a senior shift manager over 3 supervisors." |
| Ran operations across four sites | Inflated form of F3 | The one-site sentence at its own scope: "I ran the site's peak-season surge plan two years running." |
| Owned on-time performance or cost-per-shipment results | Inflated form of F4 | "I cut the mis-pick rate 40% by redesigning the pick path." Your material says mis-pick. It does not say on-time or cost per shipment. |
| Five or more years of operations leadership | Inflated form of "7 years in warehouse and distribution ops" | That sentence at its own scope. The leadership span is the F1 answer slot. |
| Personal design credit for the full 40% | The sentence says "redesigning", not whose redesign | The sentence as written. B2 asks whose part it was. |
| Power BI skills or any Power BI reporting | Negative you stated (F6) | "I haven't used Power BI." No slot. |

## Persona weights

Round type is not known, so this is a flat-leaning full-loop pack. That makes it noticeably weaker than a pack built on a known round. Weights below are the hiring-manager prior for an operations role, and they recompute once the round is known.

| Persona | Weight | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 | The leadership span and the five-year bar, asked directly | High. The JD lists both as requirements, and your material shows neither in full. | Rehearse the objection until it is boring. Use the three you lead, the concession, and a plan rather than a claim. |
| Data-Driven Prober | 4 | The 40% counted, and the on-time and cost-per-shipment gap | High. A headline number on the CV draws probes to its assumptions. | Know what you can say about how the 40% was counted. Name the weakest assumption before they do. Say plainly when you do not know. |
| Case/Strategist | 4 | A day-one plan across four terminals, and a live diagnosis | Medium to high. The JD is an ops-ownership role, so live problems are likely. | Clarify, then structure, then metrics, then risks. Think aloud. |
| Pressure | 3 | "How much of that was actually you?" and the Power BI gap | Medium. Pressure questions often follow a headline claim. | Pause, restate, hold the position through two follow-ups, then concede the specific uncertainty. |
| Conversational | 2 | "Walk me through your journey" as an opener | High as an opener, low as a scored question. | A 90-second arc in your own words. Treat casual questions as scored. |

## Question banks

Column key: Provenance carries the one label and every sentence the guidance rests on. Answer slots are instructions for the interview, not questions to me.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role requires five-plus years of operations leadership. How many years have you led people in operations?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say when you first led people, in your own words. If fewer than five years, say so plainly, then say which part of your record you stand behind. Do not round up. | F1 is the JD's stated bar and the likeliest objection. Highest-ROI with A2. |
| A2 | "You lead three supervisors. This role leads twelve across four sites. What makes you the one to do that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Hold: "I'm currently a senior shift manager over 3 supervisors." Then say what you ran with the surge plan, at the scale it ran. Concede: "I haven't run a layer of twelve or more than one site." Hold through two follow-ups by returning to the three you lead. Never add a span. Answer slot: if you have led a larger team or a second site, say so and how. | F2 and F3 converge here. This is the deepest rehearsal in the pack. |
| A3 | "Walk me through your first thirty days running daily operations across four sites." | CASE | [generic] | Structure it: what you would check first (volumes, on-time and cost per shipment by site), whom you would meet, what you would fix first and what you would leave alone. Make no claim about your past. | A live problem from the JD's "Own daily terminal operations across 4 sites". |
| A4 | "This role builds reporting in Excel and Power BI. What have you built, and what did it drive?" | JD | [grounded] "solid Excel"; "never used Power BI" | Excel: answer slot. Name a report you built, who used it and what decision it changed; if none, say so. Power BI: "I haven't used Power BI." Then how you would learn it, as a plan. | F5 and F6. Rehearse the Power BI line until it sounds unforced. |
| A5 | "Why leave shift management for an operations management role, and why now?" | EXP | [generic] | Answer in your own words. The pack has no stated reason for the move, so it supplies none. | Motivation probe; the Skeptic asks why now. |
| A6 | "Lean and Six Sigma are a plus here. Which Lean tool have you used on a live floor?" | JD | [grounded] "Green Belt certified" | Answer slot: name the tool and the floor you used it on, and what moved. If you have used it only in training, say so. | F7. The Green Belt is the evidence; the applied use is the probe. |
| A7 | "You'd run twelve supervisors. What would you keep from your current team of three, and what would you change?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Plan, not past. Name what you would keep and what you would change, and say which of it you have tested. | F2. Keeps the answer on the future, where the candidate cannot be caught overstating. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name in your own words the assumption behind the 40% that you would defend least. Answer slot: how it was counted. If you do not know how it was counted, say so plainly. | The headline CV number is the prober's first target. Defend-the-number slot. |
| B2 | "Of that pick-path change, what did you personally design, and what did your team do?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you did the redesign, say which parts, in your own words. If it was the team's, say so and say what you led. | The sentence says "redesigning" and does not say whose. Do not claim the design. |
| B3 | "This role drives on-time performance and cost per shipment down. What did you measure on those, and where did they move?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked on-time or cost per shipment, say which and what moved. If not, say so and say what you would measure first. Mis-pick is a different measure; do not present it as proof of these. | F4. The JD's headline metrics are not in your material. |
| B4 | "You hold a Green Belt. Tell me about a project you ran under it." | JD | [grounded] "Green Belt certified" | Answer slot: name the project, what you changed and what moved. If no project was yours to run, say so and say what you applied it to. | F7. |
| B5 | "The surge plan ran two years running. Did it change between the two years, and if so, how?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: say whether anything changed, and what. If nothing changed, say so. | Tests whether the repeat is a plan you improved or one you re-ran. |

### C. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance has dropped at one of your four sites. Diagnose it." | CASE | [generic] | Clarify first: which lanes, which shifts, which shipment types, and over what period. Then objective, segmentation, approach, metrics, risks. Think aloud. | A live diagnosis of the JD's on-time ownership. No claim about your past. |
| C2 | "Two sites want the same peak-season labour at the same time. How do you split it?" | CASE | [generic] | Clarify the demand and the contract terms first. Then a split rule, what you would trade off, and the risk on each side. | A peak-season trade-off, drawn from the JD's terminal-operations scope. |
| C3 | "Which of your four terminals would you look at first, and why?" | CASE | [generic] | Name how you would rank them before you name one: on-time, cost per shipment, staffing, recent change. State the assumption behind the first choice. | A structure test. Makes the candidate reason about the whole network. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: say what you did, in the sentence's own terms. Concede: name the part that was the team's, specifically. Do not fold on the core: that the mis-pick rate fell 40%. | B2 is the same question at a calmer pace. This version is the pressure test. |
| D2 | "An internal candidate already leads twelve supervisors. Sixty seconds: why you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause and restate. Anchor in the three you lead. Concede the span plainly. Do not claim a span you have not run. | F2 under time pressure. |
| D3 | "You've never used Power BI, and this job needs it. Why should we wait for you to learn it?" | JD | [grounded] "never used Power BI" | Hold: "I haven't used Power BI." Then your learning plan, as a plan. Do not claim speed of learning. | F6 under pressure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "Green Belt certified" | A 90-second arc in your own words: seven years in warehouse and distribution, now a senior shift manager, the Green Belt. Add nothing. | The opener. It is scored even when it sounds casual. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 5+ years operations leadership required | A1, A2 |
| Own daily terminal operations across 4 sites | A2, A3, C1, C3 |
| Drive on-time performance and cost-per-shipment down | B3, C1 |
| Lead a team of 12 supervisors | A2, A7, D2 |
| Build reporting in Excel/Power BI | A4, D3 |
| Lean/Six Sigma a plus | A6, B4 |

No requirement is left without a question.

## Reverse questions

1. "What would success look like for this role at month six?" Why it lands: it shows you are asking what the hire is measured on.
2. "Which of the four sites is hardest to hit on time today, and why?" Why it lands: it shows you read the JD and want the diagnosis, not a summary.
3. "How is operations reporting built today, in Excel, in Power BI, or both, and who reads it?" Why it lands: it sets up your Power BI plan as a real question.
4. "How are on-time performance and cost per shipment measured across the four sites?" Why it lands: it sets up your answer to B3 and shows you know those are the JD's headline metrics.
5. "What has made the supervisor group most effective, and what has held it back?" Why it lands: it signals you are thinking about the twelve-person layer you would lead.

## Sources

Provided documents: the JD text you pasted, and your background in your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, not built. Query "Atlas Freight values regional logistics company": refused (permission not granted). |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure, so persona weights are a prior, not this company's process. Query "Atlas Freight interview process operations manager": refused (permission not granted). |
| 3. Atlas Freight strategy and recent news | unavailable | Would have fed CO questions; none were written. Query "Atlas Freight logistics strategy news": refused (permission not granted). |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Nothing in this pack about Atlas Freight comes from research. Its company facts are none. Every company-facing line is either your JD text or labeled [generic].

## Upgrade menu

- The round, and who you are meeting → persona weights recomputed, and reverse questions tailored to that person.
- Atlas Freight's own values page, or a pasted copy → a values cheat sheet, if the round is values-style.
- The full JD text, if you have it → the six JD rows quote the posting itself rather than your summary.
- Recent Atlas Freight news, or a strategy brief → CO questions, which are currently absent.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several minutes, needs search permission to run.
