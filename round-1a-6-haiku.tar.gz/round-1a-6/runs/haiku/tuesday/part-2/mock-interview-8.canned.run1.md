I've read the module's playbook and its reference files, and I'm writing the pack to a file now.
Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-8-canned-f0b09365/ashgrove_member-experience-lead_interview_pack.md. I built it for all three rounds, since you have a known loop.

Two things to know before you open it:

- **Your two stated gaps drive most of the pack.** You have never worked in a contact centre, and you have never presented above regional level. Both are in the JD, so I've treated them as the main risks. The most likely objection is the contact-centre one, so that's where I'd spend the most rehearsal time: question B1, with three follow-up levels.
- **Your background is only as strong as your own sentences.** Every claim in the pack is quoted from what you told me. Where the material is silent, such as on digital teams or regulated complaints, the pack gives you an honest "say so plainly" branch instead of supplying an example.

I did no web research. Your pasted values page, the recruiter's loop description and the strategy brief covered everything the pack needed. I worked from your summary of the brief, not the brief itself, so check the three figures against the original before you quote them.

Pronouns for you: none were given, so I've used "you" throughout.

Drill offer: say the word and I'll play the Skeptic on B1.
Dossier offer: I can also save a tuesday-dossier.md recording the gaps this prep exposed.
Word offer: if you'd like the pack as a Word document, say so and I'll convert it.

Does the 20-minute complaint-escalation case come with written material in advance, or is it given on the day?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 5 December 2026. Round 1: 30 minutes with the recruiter. Round 2: 45 minutes with the Head of Member Services, your future manager, mostly behavioural. Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four published values. Interviewers in rounds 2 and 3 are not yet named.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural, tested against a published value
- **EXP**: your own past work, checked for what was actually yours
- **JD**: a requirement in the posting
- **CO**: the company's strategy and altitude
- **CASE**: a live problem set in the role

Guidance is scaffolding, not a script. Rehearse in your own words, and say only what you did.

## Fit snapshot

Requirements are the posting's own words. Evidence is your own sentences, quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the number. Say it as you stated it: six years in retail banking, three as a branch supervisor. Expect a probe on whether those six years were customer operations; your material says retail banking and branch supervision, not the category. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a formal complaints log, not regulated complaints. The words stay there: "I handled the branch's formal complaints log." Answer slot: if the log followed rules or deadlines set from outside the branch, name them and how you kept to them; if it did not, say so plainly and say what it did follow. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch and one log, at that scope. Answer slot: which stages of a complaint were yours to run, such as intake, decision, reply or follow-up. Say which, in your own words. If the log was one stage of a longer process, say so. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly spreadsheet. It does not say which measures it holds. Answer slot: say what the spreadsheet counts, in your own words. If it did not count volumes or resolution times, say so plainly and say what you would add first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | low | [inferred] | transferability | Training tellers is not coaching supervisors, and the bridge should not stretch it. Answer slot: if you coached anyone on an escalation decision, say who and what you did; if not, say so plainly and say how you would start. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have worked with a digital or product team on a customer journey, say what it was and your part in it. If not, say so plainly and say how you would start. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would build the skill, said as a plan and never as a past. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet, with no tool named. Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool only if it was Excel. |

No requirement in this posting is a gate such as a licence, credential, right to work or location, so none is surfaced as a hard gate. The posting names no location and no pay; those belong to the recruiter screen's logistics slots below.

## Grounding brief

From the July 2026 strategy brief, as you summarised it in your message. I have not seen the brief itself, so check every figure against the document before you use it.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

These are the current priorities. Use the company's own framing, and do not describe any of them as already done.

## Persona table

No interviewer names have been given, so there is no interviewer read. Weights follow round priors, adjusted by the loop. The recruiter's email is the loop source: three named rounds, and a round 3 that is scored against the values.

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Values / Behavioral | Round 2, mostly behavioural. Round 3, scored against four values | High. Round 2 is mostly behavioural, which moves this persona above the hiring-manager prior. Round 3 scores the values | Map a story to each value where your material carries one. Where none does, use the selection scaffold and its honest branch. Use "we" for context and "I" for your part | 5 |
| Skeptic | Round 2 manager probing the stated gaps; round 1 light version | High. Two gaps are stated in your own words: contact centre and senior presentation | Rehearse the contact-centre objection until it is plain. Name gaps without bluffing. Give plans as plans | 4 |
| Case / Strategist | Round 3, the 20-minute escalation case and a strategy question | High in round 3. The case is in the posting's own territory | Clarify, then structure, then answer. Name who owns the file first. Think aloud | 3 |
| Pressure | Round 3 panel, time-boxed comparison and attribution challenge | Medium. Panels often press the attribution of a CV line | Hold the position through two follow-ups, then concede precisely | 3 |
| Data-Driven Prober | Round 3, a manager checking the monthly spreadsheet | Medium to high. The spreadsheet claim (F5, F9) is the kind probers test | Say what the sheet counts, and say plainly what you do not know | 3 |
| Conversational / Rapport | Round 1 recruiter screen: logistics and motivation | High in round 1. Pay, notice, location and reason for leaving are asked in a friendly register and are scored | Answer the four logistics slots in your own words. Treat casual questions as scored | 4 (logistics rows are required by the coverage rule) |
| Peer Evaluator | Round 3 branch managers, who work beside the role | Medium. They will test the seam between branches and the contact centre | Offer seam principles, not a seam you have not seen. Show what you bring their teams | 2 |

## Question banks

Provenance comes first. Every quote is a sentence from your message, the JD, the recruiter's email or the strategy brief. Answer slots are instructions for the interview and ask nothing in this conversation.

### A. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you put a member ahead of an internal target or process." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Pick one complaint where the outcome turned on what the member had been through, not on the form. Say what you did and what you did not do, in your own words. If none comes to mind, say so plainly, then give the nearest thing the log carries and what you did with it. Aim for under two minutes. | Members First, Always is a scored value, and the stem is a standard customer-over-metric probe. F3 is the only past in your material to start from, so it is the fallback, not a finished story. |
| A2 | "Tell me about a time you explained something to a customer who needed it explained twice." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Your nearest sentence is the script. If you changed how the script was explained to tellers, say what you changed and why. If you taught it as written, say so, and say what you did when a teller needed it twice. | Plain Words is a published value. F6 is the nearest material and carries training, not a rewrite, so the answer must not claim one. |
| A3 | "Tell me about a time a number told you one thing about a branch and the people in it told you another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: if a figure in your monthly spreadsheet ever disagreed with what you knew of a branch, say what the figure was and what you did about it. If none did, say so plainly and say what you would want the figures to show about the town. | Neighbours, Not Numbers is a published value. The stem tests whether you see people behind the report, and the spreadsheet is the only numbers work in your material. |
| A4 | "Tell me about a complaint you kept hold of until it was solved, even after it moved on from you." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Name one complaint in the log that you stayed with to the end, and say what it took. If no complaint stayed with you past its first handling, say so plainly, then say what you would do to keep hold of one. | Own the Fix is a published value, and the panel will test whether you keep hold of a problem. The log is the nearest material and does not show an ending. |
| A5 | "Tell me about a time you delivered an unpopular truth to someone above you." | VAL | [generic] | Scaffold: pick a time you told someone senior something they did not want to hear. It needs a stake they cared about, a point you did not drop under pushback, and a working relationship afterwards. If none comes to mind, say so plainly, then say how you would deliver that truth now. No ending is supplied for you. | This is the persona stem for values-led behavioural rounds. Your material shows no such instance, and the scaffold says so rather than supplying one. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre. How would you own complaints that come in through one?" | JD | [grounded] "Never worked in a contact centre" — your message | **Highest-ROI prep in this pack.** Hold: "I've never worked in a contact centre." Then what you do know from the branch side, in your own words: "I handled the branch's formal complaints log." Follow-up 1, "What changes for a member who calls instead of walking in?": hold, and answer from the complaint process you ran, scoped to the log. Follow-up 2, "So you'd be learning on our members?": concede precisely, "Partly, yes. Here is what I would do first." Follow-up 3, "What would tell you in ninety days that it is going wrong?": name one measure you could see. Answer slot: if any of your complaints came in other than across the counter, say how and what you did with them; if none did, say so plainly. | The JD's first responsibility names the contact centre, and the stated absence is the objection most likely to be asked. F4 is the row; F3 is the nearest material and is stated at its own scope. Rehearsed to three follow-up levels because it is the one most likely to be asked in some form. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" — your message; "I've never presented to anyone above regional level." — your message | Name the contact-centre part first, then the senior-presentation part, each in your own words. For each, give a plan as a plan. Do not name a third gap your material does not record. | Asked as a ranking, it puts both stated absences (F4, F8) side by side. Your material records no other gap to draw on. |
| B3 | "You've never presented above regional level. Why would a senior leader trust you in front of their table?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you presented your monthly figures to anyone, say to whom and what you showed; if you only sent them, say so plainly. Then say how you would prepare for a senior audience, as a plan and never as a past. | F8 is the capability gap, and a presentation-heavy panel will test it. Hold the stated limit and do not stretch it. |
| B4 | "What would you need to learn in your first ninety days, and how would you know it had worked?" | JD | [generic] | Name two or three things, and for each a measure you could see by day ninety. Keep them to the posting's own duties: complaints, the contact-centre side and digital journeys. | A plan with a check turns a gap into a path. The question makes no claim about your past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has complained three times about a fee that was taken twice. Each branch says it is the contact centre's problem, and the contact centre says it is the branch's. You have the file. What do you do on the first day?" | CASE | [generic] | Clarify first: who owns the file, and what the member has been told. Name one owner today and say you will keep hold of the case until it is solved. Ask the member what outcome they need. Name any complaints timeline that applies and say you will confirm it rather than guess it. Metrics: how many times the file has been passed, and how long it has been open. Risk: a fix right for one channel that is wrong for the other. | This is the panel's 20-minute escalation case, and the JD's first responsibility is named in it. The question is a live problem in the role. It asks about no past and presupposes nothing about you. |
| C2 | "Two of your branch supervisors disagree about whether a complaint should go to escalation. How do you coach them?" | JD | [grounded] "coach branch supervisors on escalations" — JD | Ask each for the case that supports their view, then decide against the escalation criteria. Say how you would check the decision afterwards. Coach the reasoning, not the answer. | This covers the coaching requirement. It asks you to coach, not to report a record, so the guidance needs no quote from you. F6 is the weakest material on this requirement. |
| C3 | "Your strategy moves eight branches into five hubs over 2027. A complaint is open at a branch on the day it closes. Who owns it the next morning?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — recruiter's strategy brief, as summarised by you | Clarify what closing a branch means for open complaints. Structure the answer: who owns the file, what the member is told, and how the hub inherits the history. Say what you would check on the day rather than guess how the files will be handled. | This is the strategy question the round needs. The brief is the recruiter's, so the question is grounded. The answer tests altitude, not your history. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your log was formal complaints. Which rules did it follow, and who checked it?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Hold through two follow-ups by returning to what the log was and how you kept it. Concede precisely. If it followed rules or deadlines set elsewhere, name them and how you kept to them. If it did not, say so plainly and say what it did follow. | F2 is transferability. The word "regulated" is the JD's, and the pressure lands on it. The hold is the log as you named it, not a claim about regulation. |
| D2 | "Sixty seconds: why would you be the choice over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Anchor in the six years and the three as a branch supervisor, in those words, and hold them. Concede the contact-centre side without apology: name what you have not done and the first thing you would do about it. Do not argue the comparison. Name what you bring, and nothing beyond the quotes. | A time-boxed comparison to test composure. Every fact in the answer is one of your quoted sentences. |
| D3 | "That spreadsheet is a branch tool, not a network report. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say which parts you built, in your own words. If all of it was yours, say so. If you cannot separate your parts from what was already there, say so. Concede precisely and do not fold on "I built it." | F5 and F9 rest on this sentence. The attribution probe is the one the sentence cannot answer on its own. |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through what your monthly spreadsheet counts." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot, in your own words: name what it counts. The JD names volumes and resolution times, so expect a probe on them. If it counts them, say how each was counted. If it does not, say so plainly and say what you would add first. Name the tool only if it was Excel. | F5 and F9. No figure from you is in the material, so the defend-the-number slot does not apply. The slot asks what the sheet counts. |
| E2 | "Your message says six years in retail banking. Which of those years were customer operations, and what did a normal week in them involve?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Answer with the six years as you named them. Say which years were customer-facing operations and what a week held. Keep "retail banking" and "branch supervisor" to your own words. Do not stretch them to contact-centre or complaints-operations work beyond the log. | This covers the 4+ years requirement (F1). The question presupposes only the six years you stated. |
| E3 | "If I gave you last month's complaint figures for the whole network, which one would you check first, and why?" | CASE | [grounded] "report monthly on complaint volumes and resolution times" — JD | Name the figure that would change the most decisions, volumes or resolution times, and say what a jump in each would make you check first. Do not claim a method you have not used. | This tests reporting judgement on the JD's reporting duty without relying on your past. |

### G. Conversational / Rapport: recruiter screen logistics (weight 2; four rows required by the coverage rule)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the band for this role first. Use no figure you have not chosen. | Pay is always asked in the screen. The pack supplies no figure and no range. |
| G2 | "What notice would you need to give at your current job?" | JD | [generic] | Logistics slot: give your actual notice period. | The only safe answer is your own. |
| G3 | "Where can you work from, and how often would you need to be on site?" | JD | [generic] | Logistics slot: say the places and days you can work, in your own words. The posting names no location, so the recruiter answers that part, not this slot. | Location is a logistics term, and the hub plan may change it. |
| G4 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give the reason you would give, in your own words, and keep it to what is true for you. The pack supplies no reason. | The screen always asks this. A reason you did not give is not in the pack. |

### H. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our digital team is building self-service journeys. Where would you draw the line between what a member can do alone and what a person should take on?" | JD | [grounded] "work with digital teams on self-service journeys" — JD | Answer slot: if you have worked with a digital or product team on a customer journey, say what it was and your part in it. If not, say so plainly, then name the line you would start from. | Covers the digital requirement (F7), which your material is silent on. The peer register tests whether you would be easy to work beside. |
| H2 | "Our contact-centre and branch teams often see the same complaint differently. Where is the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the file, who can reopen it, how a disagreement is settled. For the disagreement, say how you would argue with an equal without winning on rank. | The Peer Evaluator stem, applied to the seam between branches and the contact centre that the JD names. |

## Values / principles cheat sheet

Round 3 is scored against the four published values. Your material carries a story for none of them yet, so each row is a scaffold with its honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No story carried. Scaffold, A1: pick a complaint where the outcome turned on what the member had been through. If none, say so, then give the nearest thing: the log you handled (F3). |
| Plain Words | If a member needs it explained twice, the wording was wrong | No story carried. Scaffold, A2: the script you taught tellers (F6) carries training, not a rewrite. If you changed its wording, say what. If you taught it as written, say that. |
| Neighbours, Not Numbers | Every branch is part of its town | No story carried. Scaffold, A3: pick a figure that said one thing about a branch and the people in it said another. If none did, say so, then say what you would want the figures to show. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No story carried. Scaffold, A4: name a complaint you stayed with until it was solved. If none, say so, then say what you would do to keep hold of one. |

## Reverse questions

Each question has a line on why it lands. The pack has no interviewer profile, so none ties to an interviewer's path yet.

1. "The plan moves 40% of member service to digital channels by 2028. Which complaints do you expect to stay with people?" Why it lands: it shows you read the strategy and asks about the process this role owns.
2. "When eight branches become five hubs, who owns a complaint that is open on the day of the move?" Why it lands: it turns C3 around and shows you have already thought about ownership.
3. "What does Own the Fix look like when a fix has to cross from a branch into the contact centre?" Why it lands: it uses the panel's own value language, and the answer shows how the panel scores it.
4. "What did the last person in this role leave unfinished, and what would you want fixed first?" Why it lands: it reveals the real backlog and where the first months go.
5. For the branch managers in round 3: "What could someone do in their first month that would genuinely help your branches?" Why it lands: it is a reciprocity question for peers, and it frames you as someone who adds to their load.
6. "How do you tell whether a complaint was resolved from the member's side?" Why it lands: it links Members First to the reporting the role owns, and it asks for their own measure.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and the pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material describes one branch's log. |
| Has worked in a contact centre | Negative you stated, F4 | Your own words: "I've never worked in a contact centre." No slot on whether you have. |
| Has presented to senior leaders | Negative you stated, F8 | Your own words: "I've never presented to anyone above regional level." |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a formal log. |
| Measured complaint volumes and resolution times in the spreadsheet | Inflated form of F5 | F5's quote. E1 asks what the sheet counts, and does not assume these measures. |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "trained new tellers on our escalation script." |
| Named Excel as the tool | Inflated form of F9 | F9's quote: a spreadsheet. Name the tool only if it was Excel. |

## Sources

- Provided documents: the job description you pasted; the values page as you copied it on 26 November 2026; the recruiter's email; the strategy brief as you summarised it; your background in your message.
- Searches and fetches sent: none.
- Target accounting:

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the four names and wording used in the cheat sheet. |
| 2. Ashgrove interview process, member experience | skipped | The recruiter's email fixes three rounds, who runs each, and the values-scored panel. |
| 3. Ashgrove strategy and recent news | skipped | The strategy brief, summarised in your message, is under six months old and supplies the current priorities. |
| 4. Interviewer name and Ashgrove | n/a | No names have been given, so there is no query to form. |
| 5. Representative role JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → persona weights from their public footprint, and a tailored reverse question for each.
- Whether the 20-minute case comes with written material in advance → if it does, a graded-deliverable section built on that material.
- One real case from your work for each of the four values → replaces the four scaffolds (A1 to A4) with mapped stories, and lifts those rows to grounded.
- The tool used for the monthly spreadsheet → confirms or corrects F9 and answers E1's tool line.
- Headings only from the monthly spreadsheet, with no member data → lifts F5 from medium confidence, because it becomes an inspectable artifact, and makes E1 checkable.
- The rules or deadlines the log followed → names them in F2's bridge, so D1 has a precise answer.
- A deeper research pass, optional: up to 6 more searches and 2 more fetches, several minutes. Want it?
- A tuesday-dossier.md from an earlier job check → its verified evidence would replace the scaffolds in A1 to A5 and the low-confidence rows.
- The reporting figures the recruiter can share → lets E3 use the network's real numbers.
