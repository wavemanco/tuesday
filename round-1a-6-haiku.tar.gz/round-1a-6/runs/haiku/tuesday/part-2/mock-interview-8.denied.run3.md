Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-8-denied-49ba9958/c961fccb-ffd3-451a-8994-9cd3240a66d5/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it as three mini-packs, since the recruiter's email names three rounds. It shares one fit snapshot, one prohibited-claims list and one upgrade menu.

Say the word and I'll play the Skeptic on B2, the contact-centre question. The pack names it as the highest-return prep, because it's the most predictable objection and rests on your "Never worked in a contact centre."
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Which rules set the timings and wording for the formal complaints log you handled? If you know the regulator or framework behind it, that changes how the "regulated complaints" answers should go.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead prep pack

Loop mode: three rounds on 5 December 2026 (recruiter, Head of Member Services, branch-manager panel). Built 26 November 2026.

## How to use

- **Personas** say how a question arrives. **Types** say what is scored: **VAL** values and behaviour, **EXP** your own experience, **JD** the listed job, **CO** company strategy, **CASE** a live problem.
- Question IDs: **A** for round 1, **B** for round 2, **C** for round 3.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview. It asks you nothing here, and it always gives you an honest branch.
- Labels: **[grounded]** traces to your message, the JD you pasted, the recruiter's email, or the values and strategy text you pasted. **[inferred]** is my derivation, named. **[generic]** is a pattern with no claim about you or Ashgrove.
- No interviewer read: no names yet for the Head of Member Services or the panel (see upgrade menu).

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your message already reaches the years and the field. Say it in those words. "Branch" does not stretch into "operations" beyond them. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal log, not which rules shaped it. Answer slot: if rules set the log's timings and wording, say which and what they required of you; if none did, say so and describe how you ran the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log, not the process end to end. Say the branch piece at its own scope: "I handled the branch's formal complaints log." Answer slot: if you ran a step beyond the log, say which and whether it was yours to set; if not, say so and stay with the log. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Your words back: "I've never worked in a contact centre." The closure is a plan, said as a plan and never as a past: how you would learn how contact-centre complaints arrive. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly reporting is in your words. Your material does not show whether the spreadsheet carried resolution times. Answer slot: if it did, say which and how each figure was counted; if not, say so and what you would add first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" and "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Teaching tellers a script is adjacent to coaching supervisors, and your message does not say you coached supervisors. Say the teller training at its own scope; name the supervisor years as context, not as coaching. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a negative: your material shows nothing either way. Answer slot: if you worked with any team on how members did things themselves, say which and your part; if not, say so. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Your words back: "I've never presented to anyone above regional level." The closure is a plan, said as a plan. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms. Your message says spreadsheet, not which tool. If it was Excel, say so; do not name features you did not use. |

**Prohibited claims (shared, binds every cell below)**

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log," at its own scope. The limit is my observation: your material says one branch's log. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script," at its own scope |
| Built reporting on resolution times | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses," at its own scope |
| Has worked in a contact centre | Stated negative, F4 | "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Stated negative, F8 | "I've never presented to anyone above regional level." No slot. |

**Grounding brief (strategy)**

I have not read the July 2026 brief. These are your summary of it, so quote them only as your summary; check exact figures against the brief before saying them aloud.

| Strategic fact | Source |
|---|---|
| Move 40% of member service to digital channels by 2028 | "move 40% of member service to digital channels by 2028" (your message) |
| Consolidate eight branches into five hubs over 2027 | "consolidate eight branches into five hubs over 2027" (your message) |
| Small-business lending launch in Q1 2027 | "launch a small-business lending product in Q1 2027" (your message) |
| Main competitive pressure is app-only banks | "the main competitive pressure is app-only banks" (your message) |

---

## Round A: recruiter screen, 30 min

**Persona weights**

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through your journey" | High. A recruiter screen is rapport plus logistics, and casual questions are still scored. | A 90-second arc from your own sentences. Treat casual questions as scored. |
| Skeptic (light) | Knockout checks on the contact centre and on presenting | Medium. F4 and F8 are the two stated absences a screen is likely to check. | Plain acknowledgment, then the plan. |
| Logistics (pay, notice, location, reason for leaving) | Direct questions | High. Recruiter screens check these first. | Answer in your own words; give no figure you have not chosen. |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | A 90-second arc in those three sentences, in your words: the six years, the last three as supervisor, the formal log, the teller training. Then stop and let them ask. | Opener from the conversational persona. The arc is what you can defend under any follow-up. |
| A2 | "Why this role, and why now?" | JD | [generic] | Name the part of the role you most want to own, and say why in one sentence in your own words. Keep it to the job's terms: complaints end to end, digital, hubs. | Motivation check. It makes no claim about your history, so it needs no quote. |
| A3 | "The role covers the contact centre. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | "I've never worked in a contact centre." Then one sentence as a plan: how you would learn how contact-centre complaints arrive. Say nothing about a past in a centre. | Knockout check on F4, a stated absence. The plain acknowledgment is the honest answer. |
| A4 | "The role reports monthly on volumes and resolution times. What have you reported?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet showed, in those words. Answer slot: if it carried resolution times, say which and how each was counted; if it did not, say so and what you would add first. | F5 and F9. Tests whether the spreadsheet claim survives a first follow-up. |
| A5 | "What's your notice period?" | JD | [generic] | Give your actual notice period in your own words. | Logistics slot. The recruiter needs your figure; none is supplied or suggested here. |
| A6 | "What are you looking for on pay?" | JD | [generic] | Ask for the band first: "What's the band for this role?" If you give a figure, give your own. | Logistics slot for pay. No number is supplied or suggested. |
| A7 | "Where are you based, and where could you work?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Say where you can work, in your own words. If the role's hub is unclear, ask which hub it is. | Logistics slot for location. The hub move is in the strategy summary, so expect the question. |
| A8 | "Why are you leaving your current role?" | EXP | [generic] | Give your reason in one sentence, in your own words, with no comment on the bank. | Logistics slot for reason for leaving. The reason is yours to give; none is supplied here. |

**Reverse questions (to the recruiter)**

1. "What does the hiring process look like after the three rounds?" Why it lands: shows you plan around the process, and gets you the decision date.
2. "How will the move from eight branches to five hubs change this role during 2027?" Why it lands: ties your question to the strategy you have read.
3. "What did the last person in this role spend most of their week on?" Why it lands: a real answer you can use in round B.
4. "Is the salary band shared at this stage?" Why it lands: a pay question asked before you answer one.
5. "What would make the first 90 days in this role a success?" Why it lands: a success measure you can prepare against.

---

## Round B: Head of Member Services, 45 min (your future manager, mostly behavioural)

**Persona weights**

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic (top weight) | Probes the stated absences and what you owned | High. A hiring manager's prior is Skeptic plus Case; the recruiter's "mostly behavioural" moves weight to the absences and to attribution. | Rehearse B2 until it is plain. Hold, then concede specifically. |
| Values / Behavioral | Scenario prompts on the four values | High. The recruiter said mostly behavioural. | Story from your log or your supervisor years, at the scope you can defend. |
| Data-driven prober | Follows the spreadsheet claim | Medium. One monthly-report claim (F5). | Say what it showed; say plainly how it was counted if you know. |
| Case | One live problem from the remit | Low to medium. | Structure first, then your view. |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member's interest ahead of a process rule." | VAL | [grounded] "I handled the branch's formal complaints log" | A story from the log, if one turned on a member's interest over a rule. If none did, say so plainly, then describe how you handled a complaint in the log. | Members First, Always. An open prompt; the published value is its raising source. |
| B2 | "You've never worked in a contact centre, and this role owns complaints across it. Why should I believe you can run that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain acknowledgment first: "I've never worked in a contact centre." Then a plan for learning it. Hold through two follow-ups by returning to the log as the nearest evidence. Concede the gap plainly; do not fold on the claim you can make. | **Highest-ROI prep in this pack.** It is the most predictable objection, and it rests on the stated absence in F4. |
| B3 | "Which rules governed how you ran the formal complaints log, and which parts were yours?" | JD | [grounded] "I handled the branch's formal complaints log" | Say the parts of the log that were yours, in your words. Answer slot: if rules set the log's timings and wording, say which and what they required of you; if none did, say so and describe how you ran it. | F2. The JD's "regulated complaints" is the raising source for the rules; the second branch allows that no rules applied. |
| B4 | "Which stages of a complaint have you owned from first contact to closure?" | JD | [grounded] "I handled the branch's formal complaints log" | Say the stages you handled, in your words. Answer slot: if you handled some stages and not others, say which; if you handled only part of the log, say that. | F3. The JD's "end to end" is the raising source; the bridge stays at the log's scope. |
| B5 | "What does your monthly report show, and what would you add to it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it shows. Answer slot: if it carried resolution times, say how each was counted; if not, say so and what you would add first. | F5. The second branch is where a prober follows. |
| B6 | "Tell me about a time you helped someone else handle an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Tell the teller training at the scope the sentence gives: you trained new tellers on the escalation script. Answer slot: if you coached a supervisor through an escalation, say what you did; if not, say the nearest thing was training tellers, and how you would coach supervisors. | F6. An open prompt whose theme is the JD's coaching line. |
| B7 | "A member says the branch and the contact centre gave them different answers about the same complaint. What do you do?" | CASE | [generic] | Structure it: check the facts with both sides, find who owns the decision, fix the member's answer, then fix the seam so it does not repeat. | A live problem from the role's own remit. No claim about your history. |
| B8 | "Tell me about a problem you found and didn't let go of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pick a problem you found and followed through. If the spreadsheet surfaced one you then followed up, say what happened. If no such time comes to mind, say so plainly, then describe the nearest thing you did. | Own the Fix. An open prompt with the published value as its theme. |
| B9 | "You've never presented to anyone above regional level. How would you present complaint trends to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan for preparing, said as a plan. Hold through two follow-ups. | F8, a stated absence. The question names the negative you gave, so the acknowledgment is your own words. |

**Reverse questions (to the Head of Member Services)**

1. "How do complaint trends reach your leadership team today?" Why it lands: you want the reporting line before you design one.
2. "What is the complaint theme you'd most want fixed in year one?" Why it lands: their priority, which you can answer in round C.
3. "How will the move to five hubs change where complaints are handled?" Why it lands: ties your question to the strategy.
4. "As more members move to digital channels, what should still reach a person?" Why it lands: ties to the 40% digital target.
5. "How would you judge this role at six months?" Why it lands: a manager's success measure, asked directly.

---

## Round C: branch-manager panel, 60 min (includes a 20-minute escalation case; scored against the four values)

**Persona weights** (no member names yet, so these are blended from the relationship priors, not per person)

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (top weight) | Each value scored against a story | Very high. The panel scores against the four values, and the recruiter's email documents it. | One mapped story per value, with the honest branch where your material has none. |
| Case / Strategist | The 20-minute escalation case, and the strategy question | High. The case is scored, and expected to be followed up. | Clarify, structure, decide, then keep hold until solved. |
| Peer Evaluator | Seam questions between branches and the contact centre | Medium. Two branch managers pricing what your process costs their branches. | Propose seam principles; reciprocity; no invented seam facts. |
| Data-driven prober | Follows the spreadsheet figure | Low to medium. One claim (F5). | Name the weakest assumption before they do. |

**Values cheat sheet** (the panel's values are scored here)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | "I handled the branch's formal complaints log" carries no decision from the member's side. Scaffold for C1; honest branch applies. |
| Plain Words | If a member needs it explained twice, the wording was wrong | "trained new tellers on our escalation script" carries no change to the wording. Scaffold for C2. |
| Neighbours, Not Numbers | Every branch is part of its town | "I handled the branch's formal complaints log" carries no town context. Scaffold for C3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I built the monthly complaints spreadsheet our regional manager uses" carries no follow-through. Scaffold for C4. |

None of the four values has a story in the material you have shared. Each is a selection scaffold with its honest branch. Stories from your three supervisor years would turn them into story maps (upgrade menu).

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided a complaint from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint you handled and say what you decided from the member's side. If none stands out, say so plainly, then describe how you handled a complaint in the log. | Members First, Always. "Decided" is not in your sentence; the question asks you to choose an instance, so the honest branch carries it. |
| C2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | If you taught the script and changed how it was explained, say what you changed. If not, say so plainly, then say how you check a script is plain. | Plain Words. An open prompt; the second branch is the honest answer. |
| C3 | "Tell me about a complaint where the branch's town mattered more than the figures." | VAL | [grounded] "I handled the branch's formal complaints log" | If local context changed how you handled one, say how. If not, say so, then say how a town's context would change your handling, as your view and not as a past. | Neighbours, Not Numbers. |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | If the spreadsheet surfaced a problem you followed through, say what you did. If no such time comes to mind, say so plainly, then describe the nearest thing you did. | Own the Fix. |
| C5 | Case, 20 minutes: "A member has complained twice about the same fee. The branch has said no, and now the member asks for it to go outside the bank. Walk us through what you do." | CASE | [generic] | Structure it: clarify the facts and the member's need; check the file; decide who owns the decision; fix what you can now; say what the branch and the centre must do; write the member's answer in plain words; record it; keep hold until it is solved. | Scored on structure and on the values in one case. Expect follow-ups on the outside route; say what you would check first. |
| C6 | "Your branches and the contact centre hear different things about the same complaint. Where's the seam, and what happens when you disagree?" | CO | [generic] | Propose seam principles, not facts about these teams. Say how you would settle a disagreement with an equal: the question, the evidence, and who decides. | Peer Evaluator. Seam-splitting between adjacent teams. No claim about your history. |
| C7 | "How would you decide which complaints a branch settles, and which go up to head office?" | JD | [generic] | Set out the rule you would use and what you would check before a complaint went up. Keep it as principle. | Escalation coaching from the branch-manager side. |
| C8 | "If your spreadsheet gave a complaint volume, walk me through how it was counted. Which assumption behind it would you defend least?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counts and how, in your words. Name the weakest assumption you know before they do. Answer slot: if you did not set the counting method, say which part was yours. | Data-driven prober. The conditional keeps any figure out of the question. |
| C9 | "Your strategy moves 40% of member service to digital channels by 2028. Which complaints should stay with a person?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | State the principle: complaints that need judgement stay with a person. Answer slot: if you have worked with a digital team on a self-service journey, say which and your part; if not, say so and how you would find which complaints move well. | F7. The strategy is your summary; check the figure against the brief first. |

**Reverse questions (to the panel)**

1. "Where do complaints escalate most often across your branches?" Why it lands: shows you think in branches, not averages.
2. "How does a complaint file move between a branch and the contact centre today?" Why it lands: asks about the seam directly.
3. "What would a new person do in their first month that would genuinely help your branches?" Why it lands: reciprocity. Peer panels weigh this heavily.
4. "What makes an escalation here go well?" Why it lands: their own standard, which you can use.
5. "How do you each decide when a complaint should go to head office?" Why it lands: tests the rule you proposed in C7.

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B3 |
| Own the member complaints process end to end | B4, B7 |
| Across branches and the contact centre | A3, B2, B7 |
| Report monthly on complaint volumes and resolution times | A4, B5, C8 |
| Coach branch supervisors on escalations | B6, C5, C7 |
| Work with digital teams on self-service journeys | C9 |
| Confident presenting to senior leaders | B9 |
| Comfortable with Excel reporting | A4, C8 |
| Values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | C1, C2, C3, C4 (B1 and B8 also draw on two of them) |

No requirement is left without a question.

## Sources

- Provided documents: your message (background, the strategy summary, the JD text); the recruiter's email as you pasted it; the values text you copied from ashgrovecu.org/about/values this morning. That URL is where the pasted text came from, not a link I read.
- Nothing above came from a search or a fetch.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the pasted text already gives the four names and their definitions |
| 2. Ashgrove interview process | skipped | Loop structure: the recruiter's email names three rounds, who runs each, and that the panel scores against the values. That is a loop source, so no archetype fallback is used. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and C9: your summary of the July 2026 brief fixes the priorities. I have not read the brief itself. |
| 4. Interviewer name with Ashgrove | n/a | No names were given for the Head of Member Services or the panel |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD questions |

## Upgrade menu

- The Head of Member Services' name and the panel members' names → personal persona weights and tailored reverse questions for rounds B and C
- The strategy brief itself, pasted → strategy quotes come from the brief, not your summary, and C9 and A7 can use its exact wording
- Stories from your three supervisor years, in your own words → C1 to C4 and B1 and B8 move from scaffolds to story maps (I will not draft them for you)
- What the formal log and the monthly spreadsheet covered, in your own words → answer slots B3, B4, B5 and C8 get your facts
- Your full CV text → F1, F3, F5 and F9 quote your own sentences, not your message's summary
- The recruiter's band, location and hub details → A5 to A8 and the pay guidance get the real terms
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches on the strategy and panel footprints, several minutes. Want it?
