This is a hiring-manager round, so I'll route it through the tuesday skill's mock-interview module, using the handoff section of your dossier.
The playbook needs several reference files before I can write anything. I'll read them together.
I have the playbook and its references. Before writing the pack, I'll load WebSearch to run the default L1 research on Quartzline, so the strategy and interview-process facts aren't from memory.
The two searches were refused by the permission system, so this pack runs without current Quartzline strategy or interview-process facts. I'll record that in the pack's Sources and write it now.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-4-denied-9d67c2c0/c7ed21da-233a-42d7-b4c2-b830eecd0075/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, using your dossier's handoff section.

Two things to know before you open it. First, the company searches were refused by the permission system, so the strategy questions are generic and I couldn't confirm the current interview loop. Second, the dossier is about three and a half months old, so check the requirements against the live posting if you can.

The most important prep is question B1, the objection you're most likely to get. The answer is to say plainly that you haven't held a PM title or owned a roadmap, then describe the integration and roadmap-input work at its own scope, then give a ramp plan. Rehearse it out loud.

I'd also ask the two employer questions from your dossier. They test the JD's decision-authority line and the missing adoption baseline.

I can run a drill on B1 with a Skeptic persona and give feedback against the pack's guidance. I can also write a `tuesday-dossier.md` with the gaps this prep exposed, so a later session can carry them forward, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Interviewer: not named. Round: hiring-manager conversation, 45 minutes, Thursday.
Built from tuesday-dossier.md (job-underwriter, dossier_version 1.1, generated 2026-08-14, decision conditional_go). Research did not run (see Sources), so company strategy and the loop are not established here.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores.

- **EXP**: work-experience deep-dive. Tests whether what you did holds up under attribution.
- **JD**: role-driven. Tests the stated responsibilities and requirements, gaps included.
- **CASE**: live problem. Tests structure and reasoning, not a claim about your past.
- **VAL**, **CO**: not used this round. No values round was detected, and company research did not run.

Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

1. **B1, the likely objection.** This is the highest-return prep in the pack. Say the plain acknowledgment first, then the two verified stories at their own scope, then the ramp plan. Rehearse it aloud until it sounds unremarkable.
2. **B3 and B4, your two thinnest areas (R2 and R5).** Decide now what you will say if the honest answer is "no".
3. **D1 and D2, the 30+ figure.** Be ready to say how the count was made, what it is sensitive to, and which part was yours.
4. **A2 and C2, roadmap ownership and what happened after your input.** Have the honest limit ready before the question comes.
5. **Reverse questions 1 and 2.** Ask them. They test the JD's decision-authority line and the missing adoption baseline.

Everything else is insurance.

## Fit snapshot

Dossier rows are numbered V1 to V3 here, in the dossier's own order. The requirement text is the dossier's role_profile transcription of the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | high | [inferred] | transferability | Adjacent work only. Say the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's own observation: this is integration delivery, not years of product management. Do not turn it into PM years. The dossier grades the R1 fit low; the confidence here grades your claim, which is high. |
| F2 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3, medium) | none (for roadmap ownership) | [grounded] | capability | Words, from the dossier's acknowledge_gap entry and prohibited_claims: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the input you did give, named as input: V3 at its own scope. Then a ramp plan, said as a plan and never as past. |
| F3 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1, client side of an API you did not build) | none | [inferred] | discovery | The material does not show a shipped API or platform product. The dossier did not grade R2, so this discovery grading is the pack's own. Answer slot only, no bridge: see B3. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook" (dossier V2, high; the team uses it, said outside the quotation marks) | high | [grounded] | presentation | Lead with the playbook, which is inspectable. Schemas are not in the material. Answer slot: if the playbook covers request or response schemas, say which parts; if not, say so and say how you would learn them. See A5. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3, medium) | medium | [inferred] | transferability | Adjacent: customer and product work. The material does not show engineering-squad or sales stakeholder work. Answer slot: say which of those groups you have worked with, in your own words; if none, say so and stay with the customer side. See A4 and A6. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | No verified evidence speaks to agile delivery. Clarify slot only: see B4. |

Gap types routed under the rubric: F1 transferability, F2 capability (stated negative from the dossier), F3 discovery (the pack's own grading; the dossier did not grade R2), F4 presentation, F5 transferability, F6 discovery.

## Prohibited claims

Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims (sourced) | Plain acknowledgment from that field: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | dossier prohibited_claims (sourced) | Plain acknowledgment from that field: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | dossier prohibited_claims (sourced) | Plain acknowledgment from that field: "I haven't set prioritization for an engineering squad." No slot. |
| Owning the roadmap input for the partner API platform, as if it were roadmap ownership | Inflated form of V3 (local) | V3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's analysis: your material says input, not ownership. Never a first-person negative. |
| Having shipped API or platform products | Inflated form of V1 (local): the requirement's wording widens "Led 30+ end-to-end client integrations" | V1 at its own scope. The B3 slot stays inside it. Never a first-person negative. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the role's roadmap, partner adoption and squad delivery | Highest weight. A hiring manager is buying capability and running live problems on the actual job (relationship prior). 6 questions. | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case. |
| Skeptic | Probes the gaps: no PM title, no roadmap, no agile, no shipped API product | High weight. A hiring manager is also derisking the gaps (relationship prior). 4 questions. | Rehearse B1 until it is plain. Bridge only from stated evidence, with its limit named. Concede calibrated, not bluffed. |
| Pressure / Stress | Time-boxed challenges to the claim that the adjacent work counts | Medium weight. Common for a 45-minute round, not dominant. 3 questions. | Pause, restate, hold the position through two follow-ups, then concede the specific uncertainty. |
| Data-Driven Prober | Asks how the 30+ figure was counted and which assumption you would defend least | Medium weight. The only quantified claim is V1's figure. 3 questions. | Say how it was counted only if you know; name the weakest assumption before they do. |
| Conversational | Open journey prompts; casual questions on adoption | Lower weight. Still scored. 2 questions. | A 90-second arc from quoted evidence. Never answer "I think you've covered everything." |
| Values / Behavioral | Not used. No values round detected: no loop source, and the research did not run. | Omitted, because the generic fallback reads no for a values round. | None this round. |
| Peer Evaluator | Not used. The relationship is a hiring manager, not a peer. | Omitted. | None. |

Persona weights rest on the hiring-manager prior. No loop source establishes this company's documented loop, so no loop detail is claimed.

## Question banks

### A: Case / Strategist (6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partner API adoption has been flat for two quarters. What do you need to know before you touch the roadmap?" | CASE | [generic] | Clarify the objective: adoption of what, by which partners, over what time. Segment the partners. State the metrics you would track. Then risks. Think aloud. | The JD names adoption metrics as a responsibility (raising source: "Define and track adoption metrics"). A problem, not a claim about your past. Strategy is generic here because research did not run. |
| A2 | "Walk me through how you would sequence the next two quarters with two engineering squads." | JD | [grounded] raising source: "Write specs and drive delivery with two engineering squads" (JD) | Say which squad owns which API surface first, name the dependencies, and say what you do not yet know about each squad's capacity. Do not claim the sequencing authority. | The JD's delivery responsibility. Tests judgment, not authority. F2 applies. |
| A3 | "In your first 90 days, which integration partners would you speak to first, and what would you ask them?" | JD | [grounded] raising source: "Run discovery with integration partners" (JD) | Name a segment: the partners who integrated fastest, and the ones who stalled. Name two questions you would ask each. | The JD's discovery responsibility. No past claim. |
| A4 | "A large partner asks for a feature that would delay a squad's roadmap. How do you decide?" | CASE | [grounded] raising source: "Stakeholder management across engineering, sales, customers" (JD) | Separate the request from the need. Decide on adoption evidence. Name who you would tell and when. Do not claim a past decision. | R4 stakeholder management. F5 applies. |
| A5 | "How would you check a schema change to the partner API before it ships?" | JD | [grounded] raising source: "Technical fluency: API docs, schemas" (JD) | Name what a reviewer checks: contract compatibility, consumer breakage, docs. Answer slot: if the playbook you wrote covers schema review, say how; if it does not, say so and say how you would learn it. | R3. F4 applies. The slot does not assume the playbook covers schemas. |
| A6 | "A partner asks for a custom field that no other partner needs. Walk me through your call." | CASE | [generic] raising source: "Stakeholder management across engineering, sales, customers" (JD) | Weigh the one partner's revenue against the platform's cost to every other partner. Name the policy you would propose. | R4 stakeholder judgment in a live case. No past claim. |

### B: Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier likely_interviewer_objections, named by the underwriter. Negatives sourced to dossier prohibited_claims (product manager title; product roadmap). Quotes: "Led 30+ end-to-end client integrations of the vendor's REST APIs"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Deepest rehearsal in the pack. Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." Then V1 and V3 at their own scope. Name the limit: that work is integration delivery and roadmap input, not setting a roadmap. Concede plainly that a PM with three years would start faster on roadmap authority. Then the ramp: the first two roadmap calls you would confirm with the squad leads before claiming them. Follow-up ladder: (1) "Which roadmap decision would you make alone on day one?" Answer: you would confirm it with the squad leads first, and say what you would ask them. (2) "What did the input change?" Answer: the answer slot in C2. (3) "So why not hire the PM?" Answer: the concession, then the ramp again. | This is the objection the underwriter named, and it targets the biggest gap (F1, F2). Its negatives have sources, so it is asked as written. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] raising source: "Own the roadmap for the partner-facing API platform" (JD) | Name roadmap ownership and agile product delivery as the weakest areas, plainly. Do not present either as a strength. Then say what you would do first. | Skeptic stem. F2 and F6. |
| B3 | "Tell me about an API or platform product you shipped, or helped ship." | JD | [grounded] raising source: "Shipped API or platform products" (JD). Quote: "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Answer slot. If you shipped or helped ship one, say what it was and your part in it. If not, say so plainly and describe the integration work you led, at its own scope. | R2 has no verified evidence, so the pack does not bridge it. F3. |
| B4 | "Agile delivery inside a product org: what did that look like for you?" | JD | [grounded] raising source: "Agile delivery experience" (JD, preferred) | Clarify slot. If you ran a delivery cadence, describe it in your own words. If you never worked that way, say so, and say what you would confirm about how this team defines agile. | R5, discovery. F6. |

### C: Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM who is already in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Pause before you answer. Restate the question. Anchor in V1 and V3. Hold the position through two follow-ups: you bring the integration side of the roadmap, not a PM title. Concede explicitly that a PM with three years would start faster on roadmap authority. | Pressure stem on F1. The hold is only what V1 and V3 carry. |
| C2 | "What happened after your roadmap-input sessions reached product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3, medium) | Answer slot. If you saw what product did with the input, say what changed and what part was yours. If you did not see the outcome, say so plainly and stay with the sessions. The input is yours; the decision is not. | The premise of an outcome is not in the quote, so the slot's second branch allows that you never saw one. Medium confidence: the prober will find this seam. |
| C3 | "Integration work is not product management. Argue otherwise in one sentence." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | Hold the adjacent position, not equivalence: "Integration work is adjacent. I led 30+ end-to-end integrations, and that is not product management." Concede the limit rather than arguing it away. | Pressure on F1's transferability. |

### D: Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | Defend-the-number slots, in your own words. What counted as an integration, from what record, and which part was yours. Weakest-assumption move: name the assumption you would defend least. Answer slot: if a record supports the count, name it; if you cannot say how it was counted, say so plainly. No method is supplied here. | A headline figure from the dossier raises these slots and only these. |
| D2 | "Which of those 30+ integrations would you defend least as a success?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | Weakest-assumption move. Pick one integration in your own words, and say why. If you have no basis to rank them, say so. | Prober follow-up on the same figure. |
| D3 | "How would you measure partner API adoption, starting from wherever it is measured today?" | JD | [generic] raising source: "Define and track adoption metrics" (JD) | Name the first step: find out how adoption is measured now and what it currently reads. Then name the one metric you would own. | The JD's adoption responsibility. The dossier's unknown about current measurement is not a raising source, so the question does not presuppose it. |

### E: Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1); "Wrote the internal integration playbook" (dossier V2) and V3 | A 90-second arc from V1, V2 and V3, each at its own scope. Then the limit: no PM title, no roadmap ownership. Then the ramp. Claim nothing beyond the quotes. | Casual openers are still scored. Keep the arc inside the evidence. |
| E2 | "What do you think is the hardest part of partner API adoption?" | JD | [generic] raising source: "Define and track adoption metrics" (JD) | Give a view and mark it as a view. If it draws on integration work you did, say which part. | Tests judgment on the adoption responsibility. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | B1, C1, C3, E1 (fit rows F1, F2) |
| R2: Shipped API or platform products | B3 (F3) |
| R3: Technical fluency, API docs, schemas | A5 (F4) |
| R4: Stakeholder management, engineering, sales, customers | A4, A6 (F5) |
| R5: Agile delivery experience | B4 (F6) |
| Roadmap ownership (JD responsibility) | A2, B2 |
| Discovery with integration partners (JD responsibility) | A3 |
| Define and track adoption metrics (JD responsibility) | A1, D3, E2 |
| Defend the 30+ figure | D1, D2 |

Every requirement has coverage. No CO or CASE question is grounded in current company strategy: research did not run, so A1 and A4 are generic.

## Reverse questions

Hiring manager, so no peer-reciprocity question. No interviewer profile, so none is tied to a path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the JD asserts decision authority over two squads and the material does not evidence it. Your answer sets the first 90 days.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: adoption is named as a responsibility with no stated baseline. The answer tells you which metric you would own.
3. **"Who has set the partner API roadmap so far, and how is that changing?"** Why it lands: the same authority question from the other side. A change in process means the seat is new.
4. **"Where does partner discovery run from today, and which partners are you hearing from most?"** Why it lands: the discovery responsibility. It tells you where your first conversations go.
5. **"What would a strong first quarter look like for the person in this seat?"** Why it lands: it sets the bar your 90-day plan is judged against.

## Sources

- **Provided documents:** tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14 by job-underwriter. Consumed: role_profile (requirements R1 to R5 and responsibilities, as the JD tier), handoff_to_mock_interview (verified_candidate_evidence V1 to V3, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims), and decision (conditional_go, as context). Not present in this dossier: evidence_map, risk_register, evidence_state.
- **Dossier age:** about three and a half months old. Its requirement text is the underwriter's transcription. The live posting may differ.
- **Round:** hiring-manager conversation, 45 minutes, stated in your message.
- **Searches sent:** "Quartzline strategy": refused. "Quartzline interview process product manager": refused. The search permission was not granted.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | No call sent; the search tool was refused, so no values page was read. It would have moved the values cheat sheet, but no values round is detected, so that section is dropped either way. |
| 2. Quartzline interview process product manager | unavailable | Query refused. It would have set the loop structure and persona weights. Weights rest on the hiring-manager prior instead. |
| 3. Quartzline strategy | unavailable | Query refused. It would have fed the CO bank. None was written, so A1 and A4 stay generic. |
| 4. Interviewer name | n/a | No name was given. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- Current job-posting text → confirms the dossier's requirements are still live (the dossier is about 3.5 months old) and sharpens the JD-tagged questions.
- Search permission granted → strategy and interview-process facts; A1 and A4 become grounded, and the loop can be checked.
- The interviewer's name → public footprint, for persona weights and a tailored reverse question.
- Your CV → the dossier's quotes become CV-sourced, and the timeline behind the "3+ years" requirement can be checked.
- A recruiter's note on what this round covers → reweights the persona questions.
- A dossier carrying evidence_map and risk_register → the underwriter grades R2 to R4 itself, instead of this pack's grading in F3 to F5.
- Your own answer to D1 (how the 30+ figure was counted), in your words → sharpens F1 and the D1 slot.
