Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-5-denied-65192f4a/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel, with Deepa as your future manager and Ross on commercials.

The pack has no company research. The web searches were refused, so the values, interview-process and strategy sections are missing or generic. I also haven't seen the market report's contents, so the POV can't yet be set against what the panel will expect.

The biggest risk is the rail gap. Deepa is likely to open with "you've never sold into rail," so the pack leads with a plain "I haven't sold into rail." followed by what you did carry. Spend the first hour of prep on the 15-minute POV, and the second on that rail question.

Say the word and I'll play Deepa as the Skeptic on A1, the rail question.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description? Without it, the requirements in the fit snapshot come only from the recruiter's email as quoted in your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

- **Role:** Senior Partnerships Manager
- **Company:** Kelverton Rail (UK rail-tech, about 600 staff, sells scheduling software to train operating companies, as you described it)
- **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
- **Format:** 60 minutes. First 15 minutes: a no-slides POV on where to take operator partnerships over 18 months, landing on what it means for the operators. Rest is Q&A; Ross will push on commercials.
- **Changelog:** first version.

## 1. How to use, and type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse the answer in your own words, and never say a sentence in the guidance that you could not defend if asked about it.

- **JD:** can you do the listed job, gaps included
- **EXP:** do the claims about your past survive scrutiny
- **CASE:** structure and reasoning on a live problem
- **CO:** company and strategy knowledge (no research ran, so these are generic)
- **VAL:** not used; no values round was detected

## 2. Prep triage (about four hours)

| Step | Time | Do | Covers |
|---|---|---|---|
| 1 | 60 min | Pick two or three theses for the POV. Write each concession as one sentence. Deliver the POV aloud with a timer, stopping at 15 minutes. | POV, B1 |
| 2 | 45 min | The rail gap. Say "I haven't sold into rail." aloud until it is flat. Then run hold-then-concede three times against a timer. | A1, A3, C1 |
| 3 | 45 min | The £4M figure. Write what you know about how it was counted, which part was yours, and what you do not know. Practise the "I don't know" branch out loud. | C2, D1, D2, D3 |
| 4 | 30 min | Quota and terms. Practise the plain acknowledgment of no direct quota, then what you did carry. | C3, C4 |
| 5 | 30 min | Pick five reverse questions and learn them cold. | Section 9 |
| 6 | 30 min | The 90-second arc and the motivation answers. | E1, A4, A5 |

Everything else is insurance.

## 3. Fit snapshot

No job description was supplied. The requirements below come only from the recruiter's email as quoted in your message, and from your description of the company. They are [grounded] in that sense, and nothing else is.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter, quoted in your message) | "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says partner work at a payments company, with software vendors as the partners, not operators. Words at its own scope: "I was running the ISV channel at a payments company, and took it from 6 partners to 40." Going further than that is an answer slot (A5). |
| F2 | "what it means for the operators themselves" (recruiter, quoted in your message) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material says planning work for bus and light rail networks, from the other side of the table. Words: "I worked on the planning side of bus and light rail networks." The pack's own observation: your material does not show operator-side work, so do not describe it as if it did. |
| F3 | "Ross will push on commercials" (recruiter, quoted in your message) | "roughly £4M of influenced revenue" (your message); "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | transferability | The adjacent work is influenced revenue, not a quota. Words at its own scope: "I've influenced roughly £4M of revenue." The plain acknowledgment "I've never carried a direct quota" is words you gave, so you may use them. Anything about how the figure was counted is an answer slot (D1 to D3). |
| F4 | "they sell scheduling software to train operating companies" (your message, describing the company) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated, so it can be said plainly: "I haven't sold into rail." Then the route you would take to learn operator buying, said as a plan and never as a past. Never a claim of rail selling. |

## 4. Graded deliverable: the 15-minute POV

The recruiter's words, as quoted in your message: "a short POV on where you'd take our operator partnerships over the next 18 months" and "Please land on what it means for the operators themselves."

**Facts you can build on:** F1 ("took it from 6 partners to 40, roughly £4M of influenced revenue") and F2 ("bus and light rail network planning, so I know the operator world from the other side"). Use each at its own scope, in your own words. Neither supports a claim about rail operations or rail sales (see F4).

**Theses.** Pick two or three. Each has a mandatory concession, and each is [generic] reasoning about how operator partnerships tend to work, not a claim about Kelverton or its operators.

- **T1: operators judge a partner by whether a change gets through their planning cycle on time.** Build the partnership around the operator's timetable-change and disruption-recovery cycle, not around the release schedule. *Concession:* this assumes planning and operations drive the buying decision. If budget holders decide, the partnership moves toward the commercial team, and you would need to find out which.
- **T2: a partner should share operator delivery risk, not just operator cost.** *Concession:* a partner that carries risk needs commercial terms, and those may be terms Kelverton does not want to give. Ross will know which terms are negotiable, which is why this thesis puts a question to him.
- **T3: partner economics should reward operator outcomes, not partner volume.** *Concession:* outcome measures need shared operator data, and you have not seen how Kelverton shares data with operators today.

**Anti-pick.** Do not pitch "scale the partner count" as the answer. It is the number you will be tempted to use, because F1 is your strongest figure, but it tells an operator nothing about their timetable.

**Differentiation against the consensus answer.** Not built. Your strategy team's market report is not in this conversation, and I have not seen its contents, so I cannot say which answer the panel will expect. Paste its headline points and this section gets rebuilt.

**Requested close.** Land on what changes for an operator's planner in a normal week. Keep it to what your theses support, and do not invent operator facts to close on.

## 5. Persona table

The panel is blended per member. Deepa's relationship prior is hiring manager (buying capability and derisking gaps). Ross's is executive (altitude and composure), with his stated focus on commercials.

| Persona | Member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Deepa | "You've never sold into rail." The motivation question. | High. She is your future manager, and F4 is the largest gap the material shows. | Plain acknowledgment, then what you did carry at its own scope, then a plan. |
| Case/Strategist | Deepa | The POV, then live problems on operator partnerships. | High. The 15-minute POV is pre-declared. | Clarify, then objective, approach, metrics, risks. Say the structure aloud. |
| Pressure | Ross | Time-boxed challenge on the rail gap and the quota. | High. He is the commercial voice and the recruiter says he will push. | Pause, restate, hold through two follow-ups, then concede the specific point. |
| Data-Driven Prober | Ross | The £4M figure, asked for its counting and its weak assumptions. | High. It is your headline commercial figure. | Name the assumption you would defend least. Say plainly what you do not know. |
| Conversational | Both | The opener and the "tell me about yourself" arc. | Low to medium. A panel opener is still scored. | A 90-second arc built from your own sentences. |

Interviewer read: not built. No public footprint was searched (see Sources).

## 6. Question banks

Depth follows weight: Skeptic 5, Case/Strategist 4, Pressure 4, Prober 3, Conversational 2. Eighteen questions in total.

### Skeptic (Deepa), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never sold into rail. Why should we believe you can run our operator partnerships?" | JD | [grounded] "Never sold into rail specifically" (your message); "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message) | Open with the plain acknowledgment: "I haven't sold into rail." Then what you did carry, at its own scope: "running the ISV channel at a payments company" and the route to operator buying as a plan. Hold through two follow-ups by returning to what you carried. Concede only the rail selling itself. This is the highest-ROI prep in the pack. | F4 is the largest gap and the most predictable objection. The question is premised on a negative you stated, so it is allowed. |
| A2 | "What do you know about how a train operator makes a scheduling decision?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Say what you know from the planning side and where it stops. Then name the people you would ask first: operator planners and operations. Do not describe how a train operator decides as if you had seen it. | F2 is the only operator-side evidence, and it stops at planning. |
| A3 | "What would you be most wrong about in your first six months?" | EXP | [grounded] "Never sold into rail specifically" (your message) | Give the one thing you would test first, in your own words: rail buying, which you have not done. Then the test you would run. Offer the test, not the outcome. | An open prompt about your self-assessment. It lets the gap be named before the panel names it. |
| A4 | "Most of your partner work has been in payments. Why would operator partnerships suit you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message) | Give the motivation in your own words. The planning work is the honest link (F2). Name the operator problem you want to work on. Do not claim insider knowledge of the sector. | F1 is the evidence the question is aimed at. This tests motivation consistency, which the Skeptic scores. |
| A5 | "Our operator partnerships are the job. Which one would you look at first, and why?" | CASE | [grounded] "our operator partnerships" (recruiter, quoted in your message) | Selection criteria only, since you have not seen the partnerships. Say what you would need to know before you chose: which operators, which change cycle, which partner. Answer slot: if you have seen any of the partnerships, say which and what you saw; if you have not, say so plainly and give the criteria. | The premise comes from the recruiter's own words. Your history is not drawn on here. |

### Case/Strategist (Deepa), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Take one quarter. Where do you start with operator partnerships?" | CASE | [generic] structure only | Clarify the objective first: which operators, which outcome. Then approach, metrics and risks. Give one approach you would start with and one risk you would watch, in your own words. | The live version of the POV. Tests structure before the answer. |
| B2 | "Which operators would you start with, and how would you choose them?" | CASE | [generic] selection criteria only | Name two or three criteria, such as the operator's change cycle or how it buys. Say which one you would weight most and why. Do not name operators you have not researched. | Tests selection logic, which the POV leans on. |
| B3 | "You took a channel from 6 partners to 40. Would you do the same here?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | The anti-pick: do not say yes on count. Say what the count did and did not tell you, and what you would measure for operators instead. | F1 is the evidence and the likeliest trap. Scale is the answer you will be tempted to give. |
| B4 | "What would you stop doing in the first ninety days?" | CASE | [generic] | Name one activity you would stop and why, in your words. Keep it to one. | A judgment question. Its answer shows whether you prioritise. |

### Pressure (Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has sold into rail for ten years?" | JD | [grounded] "Never sold into rail specifically" (your message); "bus and light rail network planning" (your message) | Pause and restate the question. Hold your position on what you carried: F1 and F2 at their own scope. Then concede the specific point: "I haven't sold into rail." Do not fold on the rest. | F4 under time pressure. The hold is on what you carried, and the concession is the one that is true. |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you did specific work toward the figure, say what it was in your own words. If the figure was shared or came from others' work, say so plainly. Do not give a share you cannot defend. | F3. A figure raises an attribution probe, and this is the pressure version of it. |
| C3 | "You've never carried a direct quota. Why would you handle commercials here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I've never carried a direct quota." Then what you did carry, at its own scope: "roughly £4M of influenced revenue." Hold once. Concede the quota gap in specific terms, not in general ones. | F3's quota gap. The acknowledgment is words you gave. |
| C4 | "Name the commercial terms you would put in front of an operator this year." | JD | [generic] | Name the terms you would have to see first, such as how revenue is shared and who carries delivery risk. Give no figures. You have not seen Kelverton's terms, so say that. | Ross pushes on commercials. Naming terms, without numbers, is the honest answer. |

### Data-Driven Prober (Ross), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the influenced revenue figure was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know how it was counted, say how, in your words. If there was no counting step you were part of, or it was not yours, say so plainly. "I don't know how that figure was counted" is a valid answer. | F3. A figure raises a counting probe, and the honest answer may be that you do not know. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the assumption you would defend least, in your own words, before he does. Answer slot: if you know the assumption, name it. If you do not, say you do not know it. | The weakest-assumption move. Converts a gotcha into a credibility gain. |
| D3 | "How much of the 6-to-40 growth would have happened without you?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say what you can defend, and say plainly what you cannot. If other changes drove the growth, name one you know of. | F1. Attribution of a headline count. Overclaiming here is the common failure. |

### Conversational (both), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message); "5 years in transport consulting" (your message) | A 90-second arc in your own words, using these two sentences in order. Do not add a role or a result they do not carry. | The casual opener is scored. It sets the register for the panel. |
| E2 | "What do you know about us?" | CO | [generic] | Say what the recruiter told you about the role, and what you know about the company's business from your own reading. Do not recite the market report's shortlist, since the panel knows it. Research did not run, so say what you know and no more. | Company knowledge is scored even when asked casually. Generic, because no research ran. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A5, B1, B2 | POV section 4 |
| "what it means for the operators themselves" | A2, B2, B4 | POV close, section 4 |
| "Ross will push on commercials" | C2, C3, C4, D1, D2, D3 | |
| Sold into rail (F4) | A1, A3, C1 | Stated gap, no requirement quoted from the JD |

## 7. Reverse questions

No interviewer profile exists, so none is tied to a career path. Deepa is your future manager, so the reciprocity question does not apply.

1. "What would a good first year look like for this role, in terms you would measure?" Why it lands: it shows you think in outcomes, and it lets Deepa define success in her own words.
2. "Where do operator partnerships go wrong today, in your view?" Why it lands: it shows you listen for the gaps, and it tells you what the report does not say.
3. "Which operator partnership is working best right now, and what makes it work?" Why it lands: it asks for the reference model without asking for confidential detail.
4. "How are commercial terms for operator partners set today, and who decides?" Why it lands: it prepares you for Ross's push, and it shows you know partnerships do not decide terms alone.
5. "What did the last person in this role get right, and what would you change?" Why it lands: it asks for the lessons, and it signals that you will build on the work rather than restart it.
6. "What would you need from me in the first thirty days that you have not asked for yet?" Why it lands: it turns the question into a working conversation with your future manager.

## 8. Prohibited claims

Built from the fit snapshot before the banks were written. Each entry names its basis, and the honest form follows from that basis.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" | Negative you stated, F4 | "I haven't sold into rail." Plain acknowledgment. No slot. |
| "I carried a quota" or "I hit quota" | Negative you stated, F3 | "I've never carried a direct quota." Plain acknowledgment. No slot. |
| "I generated or closed £4M" | Inflated form of F3 ("roughly £4M of influenced revenue") | The quote at its own scope: "roughly £4M of influenced revenue." The pack's own observation: your material says influenced, not sourced or closed. |
| "I know the operator business from the inside" | Inflated form of F2 ("so I know the operator world from the other side") | The planning work, at its own scope. The pack's own observation: your material does not show operator-side work. |
| "I built the ISV channel" or "I set the partner model" | Inflated form of F1 ("took it from 6 partners to 40") | "took it from 6 partners to 40" at its own scope. Which decisions were yours is an answer slot (D3). |

## 9. Sources

**Provided documents:** your message, which includes the recruiter's email as quoted. The internal market report was not in this conversation, so its contents were not read.

**Searches and fetches sent:**

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy recent news scheduling software train operators": refused

No fetches were sent. Web search permission was not granted, and I did not retry.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. User links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused. Would have moved the values section (not built, since no values round was detected) and the POV differentiation. |
| 2. Interview process, partnerships | unavailable | Refused. The recruiter's email already fixes this session (60 minutes, panel, 15-minute POV), so this target would have checked the wider loop only. |
| 3. Strategy and recent news | unavailable | Refused. Would have moved the grounding brief and the CO question. E2 stays generic. |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Not sent, because the first searches were refused. Would have moved the interviewer read, the persona weights, and a reverse question tied to their paths. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Not sent. No job description was supplied. Would have moved the requirement rows in section 3. |

## 10. Upgrade menu

- **The job description text, or the recruiter's job spec** → the requirement rows in section 3 move from the recruiter's words to a full JD. That adds the mid-list requirements, which currently have no questions.
- **The market report's headline points, pasted** → the POV's differentiation against the consensus answer (section 4), and the anti-pick, can be built against what the panel will expect.
- **Deepa's and Ross's public profiles, or their names and recent roles** → the interviewer read, persona weights for each member, and a reverse question tied to their paths. Research did not run, so this needs you to paste what you find.
- **Your own account of how the £4M was counted, and which part was yours** → D1 to D3 can be rehearsed from your words instead of as answer slots. Only what you did yourself belongs in it.
- **Permission for web search** → company values, the interview process and recent strategy at the default tier (up to six searches and two fetches). That would move the POV's differentiation, the grounding brief and E2.
- **Any POV criteria the recruiter gave beyond "land on what it means for the operators themselves"** → checked against the POV section.
