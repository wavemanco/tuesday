Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-3-denied-58051ad3/3819381b-5167-4f64-821b-f9ff4cc712a2/scratchpad/stripe_product-operations-manager_interview_pack.md`.

It's a weaker pack than it could be. I had only the role title, and web search was refused this session, so I couldn't check Stripe's values, interview loop, or recent strategy. I didn't fill those gaps from memory. The values cheat sheet and the strategy questions are missing for that reason. The question banks are generic, and every guidance cell that touches your past is a selection scaffold until you give me material.

The pack has 20 questions across seven personas, with flat weights because I don't know the round type. D1 ("Which part of this role would you be weakest at on day one?") is the highest-value prep. Rehearse it until the answer is plain and specific, with a clear ramp plan.

Two things would change the pack most:

1. Who is in the final round, and are they your future manager, a peer, a cross-functional partner, or an executive?
2. Can you paste the job posting and a few lines on your roles and results? A posting turns the generic requirements into quoted ones. Your background turns the scaffolds into story maps.

I can also play the Skeptic on D1 as a live drill, or save a `tuesday-dossier.md` recording the gaps this prep exposed. If you want the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Prep pack: Product Operations Manager, Stripe, final round

Role: Product Operations Manager. Company: Stripe. Interviewer: not given. Round relationship: not given, so persona weights are flat. First version, no changelog.

Built from the role title alone. No job posting, CV, or background was supplied, and web search was refused this session, so nothing here is checked against Stripe's own values, loop, or strategy. Everything about you is an answer slot until you give material.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL**: behavioral / values alignment. **EXP**: work-experience deep-dive. **JD**: role-driven. **CO**: company and strategy knowledge. **CASE**: live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and rehearse only what you actually did.

## Fit snapshot (worksheet variant: no background supplied)

Requirements are role-family patterns, not quoted from a posting, so each is `[generic]`. Every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Running a shared operating cadence across product, engineering and go-to-market (role-family pattern, no posting) | none given | none | [generic] | discovery | Selection scaffold: pick one time you set up a regular planning or review rhythm across teams; name who it involved, what changed, and what you did yourself. If none comes to mind, say so plainly, then describe how you would set one up in your first 30 days. |
| R2 | Defining, tracking and diagnosing metrics for a process or launch (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick one metric you used to make a decision; say how it was counted, what it was sensitive to, and which assumption you would defend least. If you never counted anything yourself, say so and name the nearest decision you made from someone else's figure, marked as theirs. |
| R3 | Driving decisions with stakeholders who disagree (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a decision where a senior or peer stakeholder pushed back; say what you held to, what you conceded, and what was still open at the end. If no such decision comes to mind, say so plainly and describe how you would hold a decision rule with three teams. |
| R4 | Changing a process people already use and getting it adopted (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a process you changed that people resisted; say what you changed, who resisted, and what you did. If none, say so and describe your first move in a new team. |
| R5 | Writing for executives: memos, decision docs, status updates (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a document you wrote that led to a decision; say who read it and what they decided. If none, say so and describe the structure you would use. |
| R6 | Working in ambiguity and at pace with unclear ownership (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a time ownership was unclear; say what you did to settle it and what you left for others to settle. If none, say so and describe how you would find the owner in week one. |

No gate rows: no posting was supplied, so no location, work-authorization, or schedule terms are known. Those would surface here first.

## Persona table

Weights are flat. Round type and the interviewer's relationship are unknown, so no persona outranks another. Every persona is touched, so you never meet one for the first time live.

| Persona | How it shows up | Weight and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: diagnose, plan, sequence | 3, flat: round type unknown | Clarify, then structure, then answer. Say the framework aloud once. | A1–A3 |
| Data-Driven Prober | Asks how a number was counted, and for its denominator | 3, flat | Name the weakest assumption before they do. Say plainly where you do not know. | B1–B3 |
| Pressure / Stress | Interrupts, time-boxes, questions motive | 3, flat | Pause, restate, hold through two follow-ups, then concede the specific point. | C1–C3 |
| Skeptic | Quiet probing of gaps and motivation | 3, flat | Rehearse the predictable objection until it is plain. Concede specifically. | D1–D3 |
| Conversational / Rapport | Friendly openers that are still scored | 2, flat, the lightest weight | Keep a 90-second arc ready. Treat casual role questions as scored. | E1–E2 |
| Peer Evaluator | Seam-splitting, credit, disagreement with equals | 3, flat | Lead with what you bring their team. Propose seam principles, not claimed knowledge. | F1–F3 |
| Values / Behavioral | STAR-shaped scenarios | 3, flat, and the values are not checked: see the sources | Say "we" for context and "I" for what you did. Where nothing fits, say so. | G1–G3 |

## Question banks

Provenance is `[generic]` for every row, because no candidate sentence exists yet. No guidance cell states anything about your past. Each one is a selection scaffold or a live problem.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our launch dates keep slipping because three teams define done differently. What would you do in the first 30 days?" | CASE | [generic] | Clarify what slipped and by how much. Set one objective, name who decides, then propose one definition of done with an owner. Name two metrics, such as slip rate and handoff time, and one risk: a team that resists. | Live problem typical of the role. Generic, so it claims nothing about your past. |
| A2 | "A key weekly metric fell 20% last week. Diagnose it." | CASE | [generic] | Ask what changed in the definition or the instrumentation first. Segment the drop. Rank hypotheses by likelihood, and say what check would confirm each one. | Tests structure under a live number. Generic. |
| A3 | "You have 90 days with a team of 30 across product, engineering and go-to-market. Sketch the operating cadence you would put in place." | CASE | [generic] | Say what you need to learn first: current rituals and decision rights. Then one planning rhythm, one source of priorities, one review cadence, and one thing you would stop doing. | Covers R1 and R6. Generic. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How would you define a success metric for an internal process you want to improve, and what would make you distrust it?" | JD | [generic] | Name the denominator, the baseline, and how the metric could be gamed. Say the weakest assumption you would accept. Answer slot: if you have defined such a metric yourself, say how it was counted; if not, say so and describe how you would check it. | Covers R2. Generic. |
| B2 | "Tell me about a number you used to make a decision. Walk me through how it was counted." | EXP | [generic] | Pick a number you actually used. Give its definition, source, and denominator, what it was sensitive to, and the assumption you would defend least. Say which parts were yours. If you counted nothing yourself, say so and name the nearest decision you made from someone else's figure, marked as theirs. | The defend-the-number move. Generic: no figure of yours is in hand yet. |
| B3 | "How would you know a process change worked, six weeks after you made it?" | CASE | [generic] | Name a before-and-after comparison, one leading and one lagging indicator, and one check for gaming. Say what you would not trust. | Covers R2. Generic. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you for this role, over someone who has already run the function?" | JD | [generic] | Pause. Restate the question in your own words. Give one thing you actually did, in your own words, and what you would need to learn. Hold it through two follow-ups. Concede the specific gap, never the whole answer. | Pressure stem. Generic: it asks for your reason, not a claim you have not made. |
| C2 | "Anyone can say they will fix it in 30 days. What do you do on day one?" | CASE | [generic] | Give concrete first steps: who you meet, what you read, what you check. Concede uncertainty about the specifics. Do not fold on the core plan. | Tests whether a plan has substance under challenge. Generic. |
| C3 | "Your answer is reasonable, but three teams would push back. How do you hold the decision?" | JD | [generic] | Hold the decision rule through two follow-ups. Concede the specific cost of the decision. Name what stays open. Never fold on the core just to restore calm. | Hold-then-concede. Covers R3. Generic. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | This is the highest-ROI prep in the pack. Name the part plainly. Bridge only from an example you actually give, and say the limit in one sentence. Then give a ramp: what you would learn first, and whom you would ask. Likely follow-ups: "What would you need to learn first?", "How long until you are not the weakest person in the room on that?", "Who would you lean on?" Hold through two follow-ups, then concede the specific gap. | The most predictable objection. Its deepest rehearsal is built once the posting is supplied. Generic until then. |
| D2 | "Why this role, and why now, for you?" | EXP | [generic] | Give one true reason in your own words. Do not recite the company's language. Link the reason to what the role does, not to a credential you have not stated. | Motivation consistency. Generic. |
| D3 | "Which of the skills this role needs would you have to learn fastest?" | JD | [generic] | Name one skill and the way you would learn it: a course, a person, a first project. Do not claim the skill yet. | Honest self-assessment; covers R6. Generic. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: what you did, what you learned, why this role next. Use your own words. | Casual register, still scored. Generic. |
| E2 | "What are you actually into in ops tooling these days?" | JD | [generic] | Name one tool or practice you have used, what you did with it, and what you would do next. Do not name tools you have not used. | Casual JD check. Generic. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam between product operations and engineering, and what happens when we disagree?" | JD | [generic] | Lead with what you bring their team, not what you need. Propose seam principles, such as who decides which tickets become work, rather than claiming to know their seam. For disagreement, give a story with spine and tact if you have one; if not, say how you would handle it. | Covers R1. Generic. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the principle: credit the people who did the work, by name, and say so across teams. Answer slot: if you have an example, tell it; if not, say so and describe how you would handle it. | Covers R3. Generic. |
| F3 | "What would you need from my team to make this work?" | JD | [generic] | Name two specific needs, such as data access and a standing review slot. Say what you would give back. | Reciprocity framing. Generic. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick one time. Use "we" for the context and "I" for what you said. Give the hard truth and how it landed. Answer slot: if none fits, say so plainly, then give the nearest one you have. | Open prompt. Generic: the published values were not checked. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the customer's need and an internal number disagreed. Say what you chose and what it cost. Answer slot: if none fits, say so and describe how you would weigh the two. | Open prompt. Generic. |
| G3 | "Tell me about a process you changed that people resisted. What did you do?" | VAL | [generic] | Pick one change. Say what you changed, who resisted, and what you did about it. Give the result only as far as you saw it. | Covers R4. Generic. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| R1 cross-functional cadence | A3, F1 | |
| R2 metrics and diagnosis | A2, B1, B3 | |
| R3 stakeholder disagreement | C3, F2 | |
| R4 process change adoption | G3, C2 | |
| R5 executive writing | none, and why | No question yet. The posting would make this concrete; without it, a question here would guess at the requirement. |
| R6 ambiguity and pace | A1, C1, D3 | |

## Reverse questions

1. "What does a strong first 90 days look like for this role?" Why it lands: it shows you plan for outcomes, not for the job description.
2. "Which operating problem would this role most need to fix?" Why it lands: it asks for the real priority, and you learn what the job is.
3. "When product operations and the teams it serves disagree on priorities, who decides?" Why it lands: it tests decision rights, which is where A1 and C3 bite.
4. "How has this role changed in the past year, and what drove the change?" Why it lands: it shows you are tracking the function, not just the posting.
5. "What would make you say in six months that hiring this person was the right call?" Why it lands: it turns the conversation to success criteria.
6. Peer only, if the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it is reciprocity, and it signals you are thinking about their load.

## Prohibited claims

The pack has no background to check, so these are built locally. Each is a claim a candidate reaches for under pressure. No guidance cell asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Any past metric, launch, team size or outcome | No candidate sentence in hand; a role-family pattern would supply one | Answer slot in each bank. The pack will not supply a figure. |
| Experience with Stripe's internal tools, processes or metrics | No source; the pack has no verified knowledge of them | Answer slot: "if you have used or studied Stripe's products, say what you know from your own experience; if not, say so." |
| Knowledge of Stripe's current values or strategy | Not checked this session | You check this yourself before the round. Nothing in the pack states it. |

## Sources

- Provided documents: none beyond the role title in the request.
- Searches attempted: four, all refused by the session's web search permission. Queries: "Stripe company values operating principles"; "Stripe interview process Product Operations Manager final round"; "Stripe strategy recent news 2026"; "Stripe Product Operations Manager job description". No results were returned, and no pages were fetched.

Research tier: L1, searches 0 of 6 returned results (4 refused), fetches 0 of 2 (not attempted).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) is absent. The condition needs published values in hand, and there are none. |
| 2. Stripe interview process, Product Operations Manager | unavailable | Loop structure not established. The loop falls back to the Generic archetype: flat persona weights, and no values round is assumed. |
| 3. Stripe strategy / recent news | unavailable | Grounding brief and the CO bank are absent. Every question in the pack is generic. |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Requirements R1 to R6 are role-family prose, `[generic]`, with no `[inferred]` rows. |

## Upgrade menu

- Paste the job posting → R1 to R6 become quoted rows, the coverage line checks each requirement against the banks, and any gate terms (location, work authorization, schedule) surface.
- Your CV, or a few lines on your roles and results → the worksheet's `none given` cells fill with your own quoted sentences, and the scaffolds become story maps.
- Round type and who you are meeting (manager, peer, cross-functional, executive) → persona weights recalculated; the flat weights go.
- The interviewer's name → a reverse question tied to their path, and weights from their public footprint.
- The recruiter's note on what the final covers, including any take-home or presentation → coverage of any deliverable they name.
- Allowing web search, once granted → Stripe's values page, the interview loop, and recent strategy: the values cheat sheet, the CO questions, and the loop's real rounds. A deeper pass is available after that; it would cost up to six more searches and two more fetches.
- Prep time available → a prioritized schedule for the pack.
