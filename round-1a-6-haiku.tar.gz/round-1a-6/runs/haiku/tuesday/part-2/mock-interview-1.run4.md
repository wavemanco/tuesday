Your interview prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-1-denied-576f2c58/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it on your message alone (candidate summary, Dan's profile, JD highlights, research note), with no searches run, and I treated the round as a single 60-minute peer conversation.

The pack has 22 questions across seven personas, weighted toward the Data-Driven Prober and the Peer Evaluator. Each question has a type tag, provenance quoted from your inputs, answer guidance and a rationale. It also has a fit snapshot, a persona table, reverse questions and a prohibited-claims list.

The three things to rehearse most:

- **D1, the highest-ROI prep:** "Have you owned any part of go-to-market for a new product line?" Her material shows product strategy and ops, not a launch's go-to-market. The guidance is to hold at that scope and concede specifically if it's true.
- **A1 and E2, the $400M figure:** Dan will probe what the credit rests on and how much of it she owns. Her material says she *proposed* the change and that it is *credited with* the uplift, so she shouldn't say "drove" or "decided."
- **D2, the quota gap:** "I haven't done classic sales ops or set quotas" is the honest line. Then she can state the difference between the volume targets she set and quotas, in her own words.

Three things need her attention before the round:

- The sales-ops and quota line came from your message, not her own words. Have her confirm it herself.
- The JD quotes are your highlights, not the full posting, so the wording may differ.
- The three Northwind priorities and the bundling threat come from your research note and haven't been verified here.

Three questions for you, so I can tighten the pack:

1. Can you paste the full JD text?
2. Did the recruiter name any focus area or deliverable for the 60 minutes?
3. How much prep time do you have?

Offers, if you want them:
- Say the word and I'll play the Skeptic on D1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** single 60-minute conversation, peer. **Interviewer:** Dan Kovac, Director of Sales Strategy (peer; both report to the same VP). **Candidate:** Priya.

Built on: your message (candidate summary, interviewer profile, JD highlights, research note). No full JD text, no recruiter guidance, no prep time, no searches run (research tier L1 with every target skipped; see Sources).

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Tag | Type | What it scores |
|---|---|---|
| **VAL** | Behavioral | Whether past behavior shows the behavior asked about |
| **EXP** | Work-experience deep-dive | Whether your claims survive scrutiny, and what you actually did |
| **JD** | Role / JD-driven | Whether you can do the listed job, including its gaps |
| **CO** | Company and strategy | Homework depth and altitude on Northwind's current priorities |
| **CASE** | Live problem | Structure and reasoning on a problem from the role |

Answer slots are instructions for the interview, not questions to answer here. Where a slot gives two branches, take the one that is true.

## 2. Fit snapshot

Requirements are your JD highlights, quoted as you wrote them. Your JD text is not full, so these are not verbatim JD lines. No requirement in the highlights is a gate (a term such as work authorization, location or a licence), so none is surfaced as a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" — your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Adjacent, not direct: the material shows a revenue model used in negotiations, not partner-motion design. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you set any partner terms, incentives or the structure of the motion, say which and how you decided; if you did not, say so and stay with the model |
| F2 | "own GTM strategy for two new product lines" — your message | "2 years strategy consulting at a top firm" — your message; "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Product strategy and operations is adjacent work; the material shows no go-to-market for a new line. Words: "Nine years at a large consumer-tech company in product strategy and ops." Answer slot: if any go-to-market decision for a launch was yours, name it and how you decided; if none was, say so plainly and name the nearest product-strategy decision you made |
| F3 | "identify whitespace across land/adopt/expand/renew" — your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | The material shows a growth result credited to a change, not whitespace across the lifecycle. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you identified whitespace in any lifecycle stage, say which and how you assessed it; if you did not, say so and say how you would find it. This figure raises the defend-the-number slots in A1, A4 and E2 |
| F4 | "run independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The tools are stated; independent analysis is not shown. Words: "I'm skilled in SQL and Tableau." Answer slot: if you ran an analysis end to end yourself, name one and the call it informed; if you have not, say so and say what you would analyse first |
| F5 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: targets set with consensus across organizations. Lead with it in its own terms: "I set annual volume targets with cross-org consensus." Expect a probe on your part in reaching the consensus |
| F6 | "AI experience a plus" — your message | "uses AI tools daily" — your message | low | [inferred] | transferability | Daily use is adjacent to AI experience, not building with it. Derivation: a usage habit does not establish the experience the posting names. Words: "I use AI tools daily." Answer slot: if you have built or shipped anything with AI, say what; if not, say how you use these tools and for what |
| F7 | Not in your highlights; sales-side mechanics, the likely probe from an interviewer in sales strategy ([inferred] from his title) — your message | "No classic sales-ops or quota-setting experience" — your message | high | [grounded] | capability | A gap you stated; words may be given back. Words: "I haven't done classic sales ops or set quotas." Confirm this in your own words before the round. No answer slot for the gap itself; the next step is how you would learn it, said as a plan and never as a past |

## 3. Graded deliverables

Dropped: no deliverable was announced.

## 4. Grounding brief

From your research note, not verified in this run:

- Three stated priorities: enterprise expansion; an AI copilot launch ('Compass'); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.

If the note is more than a few weeks old, re-check the priorities before the round. Sound current on these; do not recite them as if you had read them this week.

## 5. Reading the interviewer

Public footprint only, as you supplied it: **Dan Kovac, Director of Sales Strategy.** Career spine in pricing and monetization, with one early-stage startup chapter. Self-described "relentlessly data-driven."

Implications:

1. Every headline number will be probed to its assumptions. A1, A2, A4 and E2 carry this; rehearse the defend-the-number slots before anything else.
2. Pricing and monetization is his native language. Frame partner work in those terms, using only what the quote carries (A3, C1).
3. The startup chapter is one chapter. Do not assume skepticism about big-company pace; RQ2 asks what it changed.
4. Mirror: a shared vocabulary only. "partner-level revenue model" (F1) sits close to his monetization background. There is no shared career jump, so none is offered.

## 6. Persona table

Relationship prior for a peer: Peer Evaluator and Data-Driven Prober. Interviewer signals adjust it upward for the Prober (self-described data-driven) and tilt Case toward pricing and packaging (pricing spine). Session total: 22 questions.

| Persona | How it shows up in this round | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Walks through the $400M figure, the volume targets, the partner model | **Weight 5.** Peer prior plus his self-description; every number gets probed | Defend-the-number slots; name your weakest assumption before he does |
| Peer Evaluator (B) | Seams with sales strategy, disagreement, credit across teams | **Weight 5.** Peer prior; he is pricing what the hire adds to work he shares a VP on | Reciprocity; propose seam principles, not a map of his team |
| Case / Strategist (C) | Compass packaging, bundling, the profitability metric | **Weight 3.** Pricing spine tilts case toward price and packaging; the three priorities are stated | Say the framework aloud; state one hypothesis early |
| Skeptic (D) | GTM ownership gap; quota and sales-ops gap | **Weight 3.** Low prior for a peer, raised because two visible gaps (F2, F7) are where a peer will press. D1 is the highest-ROI item | Hold, then concede specifically; a concrete first-90-day plan |
| Pressure (E) | Time-boxed challenge on the figure and on the decision | **Weight 2.** Low for a peer, kept because the $400M figure is the likeliest place for a time-boxed challenge | Pause; restate; hold through two follow-ups |
| Conversational (G) | Casual "journey" opener; AI asked in passing | **Weight 2.** Rapport openers are still scored | A pre-scripted 90-second arc |
| Values / Behavioral (H) | Customer-versus-metric and unpopular-truth stories | **Weight 2.** No published values and no values round; kept minimal | Selection scaffold ending in its honest branch |

## 7. Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift is credited to that change. What does that credit rest on, and how much of it do you own?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (F3) | Hold the quote's words: the change you proposed, credited with the uplift. Beats: what the change was, the uplift it is credited with, the scope of the credit. Answer slots, in your words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did this, say how. If you do not know what the credit rests on, say so plainly and return to the change you proposed. | The likeliest probe for a data-driven peer, aimed at the only headline figure in the material. EXP because it tests attribution, not size. |
| A2 | "Which of the annual volume targets you set would you defend least, and why?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (F5) | Name the target, and the consensus behind it, in the quote's terms. Answer slot: name the assumption you would defend least, in your words. If you cannot name the unit or method the target was built on, say so and say what you would check first. Do not describe a method you did not use. | Weakest-assumption move on a number he will probe; F5 is the only quote on target-setting. |
| A3 | "Your partner-level revenue model: what did it take as given, and which input would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (F1) | Hold the scope: a model, used in negotiations. Beats: what it was for, who used it in carrier negotiations, the input you would defend least. Answer slot: if you set any partner term the model fed, say which and how; if the negotiators set the terms, say so. | F1 is the partner requirement and the pricing-native conversation with him; it tests whether "used in" and "built" stay distinct. |
| A4 | "Who else shares the credit for that ~$400M, and how much of it did you own?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (F3) | Name only the others you know were involved, and what they did, in your words. Answer slot: if you do not know who else shaped it, say so. If the others' share is unknown to you, say that instead of estimating it. | A second angle on the same figure, which a prober follows with "who else?" F3 carries the only quote. |
| A5 | "Tell me about one piece of analysis where you used SQL or Tableau to reach a call. What was the question, and what did you decide?" | JD | [grounded] "skilled in SQL/Tableau" (F4) | Open prompt on the independence the requirement names. The tools are yours; the analysis is not in the material. Answer slot: if you ran one end to end, give the question, where the data came from, and the call it informed. If you have not, say so and say what you would analyse first for a new line. | F4 is the requirement the highlights name that the material shows least; this makes the honest branch rehearsed. |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and a new line's go-to-market, and what happens when we disagree?" | JD | [generic] seam question from the role family; no candidate claim in the question | Propose seam principles, not a map of his team, which you do not know. Example principle: decide where the partner economics sit before deciding who owns the motion. Disagreement slot: a time you disagreed with a peer of equal standing, what you did, and how it ended, in your words; if none fits, say so and say how you would handle it. | The peer's central question, and the cross-functional influence requirement. The disagreement story has no quote, so it is a slot. |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" (F5) | Story from the quote: the targets you set, and the consensus across organizations. Use "we" for the consensus and "I" for what you set. Answer slot: if credit on that consensus was contested, say how it was settled; if it was not, say so. | Credit-sharing is a peer's test of partnership; F5 is the only quote showing work across teams. |
| B3 | "The partner motion touches both my channel and your sales. Which decisions would you want to shape, and which would you leave with us?" | JD | [generic] pattern for a partner motion; no candidate claim | Name a principle for splitting the decisions rather than claiming to know his channel. Example: give the decision to whoever carries the motion's cost. Give one decision you would hand over, and why. | Partner-motion design is a required skill; this is how a peer tests whether you would add to or reduce his load. |
| B4 | "Land, adopt, expand, renew: where would a new line's whitespace sit in that motion, and whose is it?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your JD highlights) | No claim about your past. Name the stage you would test first, and the seam you would need agreed with him before you start. | The whitespace requirement has no direct evidence (F3 is discovery), so the honest answer is a plan. |
| B5 | "Where would you expect the biggest tradeoff between sales strategy and a new line's go-to-market?" | CASE | [generic] role-family tradeoff; no candidate claim | Name one tradeoff, the metric that would decide it, and which side you would take first. Say the hypothesis early. | A live peer probe on the seam, answered as a structure rather than a story. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. How would you think about packaging it for enterprise accounts: attach it, bundle it, or price it separately?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your message, research note) | Clarify, then objective, segmentation, approach, metrics, risks. Lead with price and packaging logic, his native angle. Say the framework aloud and state one hypothesis early. No claim about Northwind's current pricing. | Compass is a stated priority and the pricing-spine tilt makes this his natural case. |
| C2 | "A much larger platform vendor is bundling. How would you price against that?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your message, research note) | Clarify whether the bundle replaces the product or sits beside it. Name the segment where it bites first. Do not assume the rival's price; you do not know it. | Northwind's named threat; a CO question with a CASE answer. |
| C3 | "Enterprise expansion and profitability are both on the list. What is the one metric you would put in front of a new line in year one?" | CO | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your message, research note) | Name one metric and the assumption under it. Do not state Northwind's current values for any metric. | Profitability is a stated priority and his unit-economics background will weigh the answer. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Have you owned any part of go-to-market for a new product line? Which part?" | JD | [grounded] "own GTM strategy for two new product lines" (your JD highlights); "9 at a large consumer-tech company in product strategy & ops" (your message) | **Highest-ROI rehearsal in this pack.** Hold: product strategy and operations is the work you have done; name the closest decision you made. Follow-up 1 asks which decision and how you decided it; follow-up 2 asks what you would do in your first 30 days. Concede specifically, only if it is true: "I haven't owned go-to-market for a new line." Answer slot: if you owned any part of a launch's go-to-market, name it and your decision; if not, say so plainly. Do not present product strategy as go-to-market. | This is the objection most likely to come up in some form. F2 touches the requirement without reaching it, so the held position must stay at F2's scope. |
| D2 | "You haven't run sales ops or set quotas. Why should your targets hold up with a sales team?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message; F7) | Plain acknowledgment first: "I haven't done classic sales ops or set quotas." Then the honest line: "What I have done is set annual volume targets with cross-org consensus," with the difference between targets and quotas said in your own words. Answer slot: if you have worked with sales targets in another form, say how; if not, say so and say what you would do to learn the sales side. | The second most predictable objection, from F7 and his sales-strategy role. The honest difference is the answer. |
| D3 | "What would you still have to learn in your first 90 days?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message; F7) | Name the sales-side mechanics first, then one more area you would close in the first 90 days, and a 30-60-90 ramp in outline. Give the first thing you would do, in your words. | The bridge plan for the gap F7 states, so the Skeptic's close is a plan and not a defence. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (F1) | Time-boxed. Hold: the partner-level revenue model used in carrier negotiations is pricing-native work, and you set annual volume targets with cross-org consensus. Concede, specifically and once: "I have not run sales ops or set quotas, and I would close that first." Do not fold on the held position through two follow-ups. | The stress version of the peer comparison. The hold uses only F1 and F5; the concession is F7's plain acknowledgment. |
| E2 | "You say you proposed it. Who decided it shipped, and was that you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (F3) | Hold the verb: "proposed," not "decided" or "drove." Beats: you proposed the change, and it is credited with the uplift. Concede if true: "I can't separate my share of the decision from the team's beyond the proposal." Answer slot: if you made a decision about shipping, say which; if it was not yours, say so plainly and return to the proposal. | A decision-rights probe on the verb in F3; the reframing risk is the verb moving from proposed to decided. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc, each beat a quoted clause: two years of strategy consulting, nine years in product strategy and ops, the partner revenue model, the volume targets, and why this role. Do not add any beat that is not in those quotes. | A casual opener that is still scored; F2 is the spine of the arc. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message; F6) | Name the tools and one concrete use. Answer slot: if you have built or shipped anything with AI, say what; if not, say how you use these tools and for what. | The AI plus, asked casually. F6 is low confidence, so the answer stays at use. |

### H. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] persona stem; no candidate claim in the question | Selection scaffold: pick a time a customer's need cost you a metric you were tracking; it needs a named metric, a decision, and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | No published values, so this is a behavioral scaffold rather than a values story. Kept to one because the metric-versus-customer framing is a common test for a data-driven interviewer. |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; no candidate claim in the question | Selection scaffold: pick a time you told senior people something they did not want to hear, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Same reasoning as H1; the material carries no such story, so the scaffold's honest branch is the likely answer. |

**Requirement coverage.** Each highlight maps to at least one question.

| Requirement (your highlights) | Covered by |
|---|---|
| own GTM strategy for two new product lines | D1, D3 |
| identify whitespace across land/adopt/expand/renew | B4 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | A3, B3, E1 |
| strong cross-functional influence | A2, B1, B2 |
| AI experience a plus | G2 |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, since he is a peer. It shows you are thinking about his load, not only your own. |
| RQ2 | "You spent most of your career in pricing and monetization, then one early-stage chapter. What did that chapter change about how you price a new line?" | Ties to his own path. It turns an interview into a peer conversation and signals that you researched him, not only the company. |
| RQ3 | "With Compass coming, where do you see the seam between sales strategy and the emerging-product go-to-market sitting?" | Opens the seam question on his side, using the stated priority. |
| RQ4 | "How is your team thinking about the bundling threat from the larger platform vendor for the new lines?" | Shows you read the stated threat, and invites him to say where his team stands on it. |
| RQ5 | "When the company says profitability, which numbers does your team use to judge a new line?" | Invites him onto unit economics, his native ground, and tells you how the new line will be measured. |
| RQ6 | "Which enterprise expansion motion do you see carrying the most whitespace right now?" | Uses the first stated priority and invites a view on where the whitespace sits. |

## 9. Grounding and prohibited claims

Built locally from the fit snapshot. Each entry names its basis; the honest form is the quote at its own scope, with the limit stated as the pack's own observation, not as a first-person negative. Nothing in this section is a claim you should make.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F2 | F2's quote at its own scope. Observation: the material shows product strategy and operations, not a go-to-market for a launch. D1's slot stays inside that scope |
| Designed the partner motion | Inflated form of F1 | F1's quote at its own scope. Observation: the material shows a revenue model used in negotiations, not the motion's design |
| Drove the ~$400M ARR uplift | Inflated form of F3 | F3's quote with "credited with." Observation: the material credits the change with the uplift and does not show your share. A1, A4 and E2 ask only what the credit rests on |
| Ran sales ops or set quotas | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales ops or set quotas." No slot on the gap itself |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily." Observation: the material shows use, not building |
| Ran independent SQL and Tableau analysis | Inflated form of F4 | F4's quote at its own scope: "skilled in SQL/Tableau." A5's slot asks only what you ran yourself |

## 10. Sources

Provided documents: your message (candidate summary, interviewer profile, JD highlights, research note). No dossier was present.

**Research tier: L1 — searches 0 of 6, fetches 0 of 2.** Every L1 target is skipped because your inputs already fix the output it feeds.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | Values cheat sheet: not built. No values round was detected, and no values were supplied |
| 2. Northwind interview process, role family | skipped | Loop structure: your message names a single 60-minute peer conversation, which fixes the structure |
| 3. Northwind strategy and recent news | skipped | Your research note supplies the three priorities and the main threat, which fixes the grounding brief |
| 4. Dan Kovac, Northwind | skipped | Interviewer read: your message supplies the title, career pattern and self-description; public footprint beyond that is an L2 item |
| 5. Representative senior GTM strategy JD | skipped | Your highlights fix the fit snapshot and the JD-tagged questions; full text is an upgrade |

No search was sent, so no query is listed.

## 11. Upgrade menu

- Full JD text → exact-wording check on the six requirement rows, and the JD-tagged questions re-keyed to its own lines
- Priya's own words on the ~$400M figure (how it was counted, who else shares the credit, her share) → A1, A4 and E2 become grounded stories rather than answer slots
- Priya confirming the sales-ops and quota line in her own words → D2 and D3 lose the note that it comes from your message
- Dan's public footprint beyond your note (a talk, a post, a fuller bio) → persona weights and the interviewer read, and a reverse question tied to his writing
- A recruiter note on any focus area or deliverable for the 60 minutes → coverage of any pre-declared deliverable
- Prep time before the round → a prep-triage schedule
- Deep research (L2): strategy brief, Dan's writing, role-family loop reports, recent org news → current-strategy CO questions; costs six more searches and two more fetches, a few minutes
- A `tuesday-dossier.md` would carry the objections and leads from this prep into later sessions
