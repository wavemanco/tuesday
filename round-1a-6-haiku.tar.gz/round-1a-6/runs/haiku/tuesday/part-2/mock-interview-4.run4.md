Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-4-denied-a26cf791/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the hiring-manager round from your dossier.

Web search was refused, so company values, interview structure and strategy are not in the pack. Where that matters, the pack says so and labels those questions generic.

- **Rehearse S1 first.** It's the objection the dossier named. Practice opening with the plain line, "I haven't held the product manager title or owned a roadmap," then the integration work in its own terms, then a 90-day ramp plan.
- **One gap the dossier doesn't flag:** it doesn't grade "Shipped API or platform products" as weak. Your material shows integrating the vendor's APIs for clients, not shipping an API product. Expect that probe (S3).
- **Check the date.** Your note says Thursday, and today is Thursday, 26 November. If the interview is today, do the drill below rather than working through the whole pack.
- **Dossier age.** It's dated 2026-08-14. If the posting has changed since, re-underwrite before relying on the requirements.

I'm not asking you anything before the interview. The upgrade menu at the end of the file lists what would sharpen the pack, such as the interviewer's name and a recruiter note on the round.

I can play the Skeptic on S1 with live follow-ups. I can also save a `tuesday-dossier.md` with the gaps the rehearsal exposes, for you to carry forward. And I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday (per your note)
**Interviewer:** hiring manager, name not given. Relationship: manager. No interviewer profile was read.
**Built from:** tuesday-dossier.md (job-underwriter, conditional_go, dated 2026-08-14). Web research was refused for all three company lookups, so company values, loop structure and strategy are not established here.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Name | Scores |
|---|---|---|
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| EXP | Work-experience deep-dive | Whether what you did survives scrutiny, attribution included |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |
| CO | Company and strategy | Not used. Research did not run. |
| VAL | Values | Not used. No values round is detected and no company values were fetched. |

## Fit snapshot

Requirements are the dossier's role_profile lines (the supplied JD tier). Evidence is quoted from the dossier's verified_candidate_evidence and handoff entries. Grades follow the dossier where it grades a row; rows it does not grade are marked as this pack's derivation.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier grades the PM-years claim low, as a transferability gap. Your material supports integration leadership, not product management years. Say the integration work in the quote's own terms, then name the limit yourself: "I haven't held the product manager title or role." Never claim PM years. |
| F2 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim, acknowledge_gap) | none given | none | [grounded] | capability | The dossier records this gap as a capability gap with no credible evidence. Words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. No bridge here. |
| F3 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | presentation | Confirmed, with limited inspectable proof, so expect a probe. Volunteer the caveat before it is extracted. Your material names customers and product. It says nothing about engineering or sales stakeholders, so do not stretch the quote to cover them. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important; this pack's derivation, not graded by the dossier) | "Wrote the internal integration playbook" — dossier verified_candidate_evidence | high | [grounded] | transferability | The playbook reaches API documentation in adjacent terms. Your material does not show schemas. Answer slot: say what the playbook covered, in your own words. If you wrote or read schemas during integrations, say which. If you did not, say so and say how you would learn the schema before the first roadmap review. |
| F5 | "Shipped API or platform products" (dossier role_profile R2, must_have; this pack's derivation, not flagged by the dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote shows integrating the vendor's APIs for clients, not shipping an API product. Expect this to be probed. Answer slot: if you delivered an API or platform product of your own, say what and what your part was. If the work was integration, say that plainly. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given. The nearest sentence is F1's quote, which is delivery sequencing, not agile practice. | low | [inferred] | discovery | Your material does not show agile practice. Answer slot: the interviewer's probe is "agile delivery." If you ran planning or sprints with a squad, say which. If you worked on another cadence, say that, and say what you would want to confirm about how this team defines agile delivery. |

**Gate rows:** none. The dossier's hard_gates list is empty.

**Observation, in this pack's analysis and not words for you:** the dossier does not grade R2 as weak, but the material shows integration work rather than a shipped product. Treat F5 as the likeliest place for a Skeptic to push beyond the objection in S1.

## Persona table

No loop source was read, because research did not run. The loop therefore falls back to the Generic archetype, which gives flat weights, said plainly. No values-style round is detected. Relationship prior for a hiring manager: Case/Strategist plus Skeptic. The dossier's objection is the Skeptic's.

| Persona | How it shows up in this round | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the JD's must-haves against your material: PM years, roadmap, shipped product | Top, 5 questions. Hiring managers buy capability and derisk gaps. The dossier names this persona's objection as the highest-ROI rehearsal. | Concede the gap in plain words. Bridge only from quoted integration work, with its limit named. Give a ramp plan. |
| Case/Strategist | Live problems on partner adoption and two squads | Mid, 4 questions. Relationship prior, with no loop evidence to adjust it. | Clarify, then structure, metric and risk. Think aloud. |
| Data-Driven Prober | Asks how the 30+ was counted and how adoption is measured | Mid, 4 questions. Adoption has no stated baseline, and the 30+ is a figure. | Say how it was counted and the assumption you would defend least. Say plainly what you do not know. |
| Pressure | Time-boxed "why you over a PM" | Low, 2 questions. Present because the dossier's objection can land hard in a short slot. | Pause. Concede first. Hold through two follow-ups. |
| Conversational | Opener and the journey through your experience | Low, 3 questions. Casual openers are still scored. | A 90-second arc in the quote's terms. |

## Prohibited claims

Sourced entries come from the dossier's prohibited_claims, quoted whole. Inflated-form entries are built here from quoted sentences. No guidance cell asserts any entry on this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held the product manager title or role." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Led the partner-facing API platform | Inflated form of F1 and F5. The quote says integrations, not the platform. | F1's quote at its own scope. The limit is this pack's observation, not words for you: the material shows integrations, not a platform. |
| Shipped API products | Inflated form of F5 | F5's quote at its own scope. S3's answer slot stays inside the integration work. |
| Ran the roadmap-input process end to end | Inflated form of F3 | F3's quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." |

## Question banks

### Skeptic (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (medium, caveat); plain acknowledgment from dossier prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap" | Start with the plain acknowledgment: "I haven't held the product manager title or owned a roadmap." Do not argue that you are better than a PM with three years. Then the adjacent work in the quote's own terms, with its limit named: integration leadership, not product decisions. Volunteer the roadmap-input caveat before it is extracted. Close with a ramp plan for the first 90 days, said as a plan. Hold through two follow-ups by returning to the integrations. Concede roadmap authority explicitly. Do not defend it. | This pack's highest-ROI prep. The dossier named this objection, and both negatives in it are sourced in prohibited_claims, so the question may be asked as written. |
| S2 | "Which part of this JD would you be weakest at on day one?" | JD | Plain acknowledgment from dossier uncertain_or_weak_areas, acknowledge_gap: "Owning a roadmap and prioritization authority"; clarify area: "Agile delivery inside a product org" | Name roadmap ownership first, plainly, as in S1. Then the ramp. For agile: if you ran planning or sprints with a squad, say which. If you worked on another cadence, say so and say what you would want to confirm about how this team defines agile delivery. | F2 and F6. Covers R1's sub-claim and R5. |
| S3 | "What did you deliver in API or platform work, and what was your part?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; [inferred] derivation from F5: the quote shows integration, not a shipped product | Say the integration work in the quote's terms. Answer slot: if you delivered an API or platform product of your own, say which and what you did. If the work was integrating the vendor's REST APIs for clients, say that plainly, and stay with what you led on each integration. | F5. R2 is a must-have, and this is the likeliest probe beyond S1. |
| S4 | "Where does your roadmap-input work end, and the squad leads' decisions start?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what the sessions were for and what went into them, in your words. Answer slot: if a priority came out of those sessions and you set it, say which and how. If the sessions only fed evidence in and someone else made the call, say that. | Decision authority over the squads is the dossier's top unknown. The dossier's condition is that the squad-authority question must verify in interviews. |
| S5 | "What would make you a poor fit for this role?" | JD | [generic] | Name the condition honestly. If the role carries roadmap authority over two squads and you have not held that, say it is the risk you would manage first, and what you would need settled before accepting. Make no claim about your past. | Tests honest self-assessment. Ties to the dossier's unresolved decision-authority risk. |

### Case/Strategist (4 questions, mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose partner API adoption stalls after the first integration. How would you diagnose it?" | CASE | [generic] | Clarify first: what counts as adoption, and which partners. Then objective, then segments (which integration types, which partners), then approach, metrics and risks. Think aloud, and challenge one premise. Answer slot: if you saw a stall in your integration work, say where and what you did. If you did not, say so and reason from the stages the quote names. | A live problem from the role. It is hypothetical, so it presupposes nothing about your past. |
| C2 | "You have two engineering squads and one partner roadmap for next quarter. What goes first, and how do you decide?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (JD) | Clarify who decides and on what basis. Then objective, the trade between partner requests and platform work, approach, and the one metric you would watch. Answer slot: if you ever chose between competing integration requests, say which and how. If you did not, say so and describe how you would decide. | Covers R1's roadmap and decision-authority requirement through a live decision. |
| C3 | "How would you run discovery with an integration partner you have never worked with?" | JD | [grounded] "Run discovery with integration partners" (JD); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it: who you would talk to, what you need to learn before scope, how you turn it into requirements. Answer slot: if you ran scoping or requirements sessions with clients, say what you asked and what came back, in your words. If someone else ran discovery on your integrations, say so. | Covers the JD's discovery responsibility and R4. |
| C4 | "What would you do in your first 30 days?" | CASE | [generic] | A ramp plan, said as a plan: learn the two squads, the partner base, the decision rights, and the adoption data. Make no claim about past work. | The honest answer to S1 and S2 in plan form. |

### Data-Driven Prober (4 questions, mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which adoption metric would you trust least, and what is its weakest assumption?" | JD | [generic] | Name one metric and its weakest assumption, in your own words. Answer slot: if you counted adoption in your integration work, say what you counted and how. If you did not, say so and say what you would count first. | The JD names adoption metrics as a responsibility. The dossier records that no current baseline is stated. |
| D2 | "Walk me through how you counted the 30+ integrations. What counted as done?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words: what done meant (go-live, or after UAT), what the 30+ is sensitive to, the assumption you would defend least, and which of those integrations were yours to lead. Answer slot: if you set the definition of done, say so. If it was set for you, say that. | A figure in your material is the probe's usual target. Its four slots are how counted, sensitivity, weakest assumption and which part was yours. |
| D3 | "How do you know a roadmap input was acted on?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (medium, caveat) | Answer slot: if you can name one product change that followed a session, say which and what you brought to it. If you cannot trace one, say so plainly. This is the medium-confidence seam, and the caveat is yours to volunteer. | F3's probe. Covers R4. |
| D4 | "Walk me through the API docs and schemas you have written or reviewed." | JD | [grounded] "Wrote the internal integration playbook" | Describe what the playbook covered, in your own words. Answer slot: if you wrote or reviewed schemas or API docs, say which. If not, say so and say how you would learn the schema before the first roadmap review. | F4. R3 is important, and schemas are not in your material. |

### Pressure (2 questions, low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; plain acknowledgment from dossier prohibited_claims: "Having held a product manager title or role" | Pause. Concede first: the PM has the three years and the job, and you do not. Then one thing from the quote, in its terms. Hold it through two follow-ups. Never fold on the integration work, and never say you are better than a PM. | Stress persona. Tests whether the concession comes out composed. |
| P2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: for each stage the quote names, say whether you led it, supported it, or were not involved. State it plainly. Hold the "led" claim only where you led it. | Attribution honesty. The hold is the quote's own scope. |

### Conversational (3 questions, low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the vendor's REST APIs and the integrations you led; the playbook; the roadmap-input sessions; then what you want this role to add. Use only these sentences' terms. Do not add PM years. | Rapport openers are scored. This is the arc to rehearse. |
| R2 | "Tell me about the playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook" | Answer slot: say what it covered and how it is used, in your own words. If you do not know how it is used now, say so. | Premised on one quoted sentence, so the question is lawful. |
| R3 | "What part of this job are you most curious about?" | JD | [generic] | Pick one responsibility and say why, in one sentence. Make no claim to have done it. | Casual, and scored against the JD. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years PM experience | S1, S2, C2, P1 |
| R1 sub-claim, roadmap and prioritization | S1, S2, S4, C2 |
| R2, shipped API or platform products | S3, F5 |
| R3, API docs and schemas | D4, C3 |
| R4, stakeholder management | D3, C3 |
| R5, agile delivery | S2 (clarify) |
| Responsibility: define and track adoption metrics | D1 |
| Responsibility: write specs and drive delivery with two squads | C2 |
| Responsibility: run discovery with integration partners | C3 |

## Reverse questions

Your questions. Each has a reason it lands.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the JD asserts decision authority and nothing in your material confirms it. The answer decides whether the ramp in S1 is the right plan.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the JD names adoption metrics as a responsibility and states no baseline. The answer shows whether a number exists.
3. "How do the two engineering squads split the work between internal platform and partner-facing API?" Why it lands: the JD names both squads. The split decides what the first 90 days cover.
4. "What would you need to see in the first month for this hire to have been the right call?" Why it lands: it turns a skeptical close into a success definition you can work to.
5. "What has taken most of the team's time on partner APIs this year?" Why it lands: it shows what the team is living with now, and it asks a current-state fact that research would otherwise have supplied.

## Sources

- **Provided document:** tuesday-dossier.md, job-underwriter v1.1, dated 2026-08-14. Sections consumed: role_profile (the supplied JD tier), handoff_to_mock_interview (all five consumption rules), and decision (context only). No evidence_map section is present in the file.
- **Searches and fetches:** three searches were sent. All three were refused, because the permission to use web search was not granted.
  - "Quartzline values": refused
  - "Quartzline interview process product manager platform APIs": refused
  - "Quartzline strategy news": refused

**Research tier:** L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Refused. No values cheat sheet; company value names are not established. |
| 2. Quartzline interview process | unavailable | Refused. The loop is not established, so the Generic archetype and flat persona weights apply. |
| 3. Quartzline strategy | unavailable | Refused. Company and strategy questions are generic, and C1 and C2 are labeled generic. |
| 4. Interviewer name | n/a | No name was given. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements. |

## Upgrade menu

- The interviewer's name → a public-footprint read, persona weights tuned to their background, and a tailored reverse question. Interviewer research was not run.
- Quartzline's values page, pasted → a values cheat sheet, if the round turns out to be values-style.
- Your recruiter's note on the round, or the interview process → confirms whether this round is its own loop and reweights the personas.
- Quartzline's current strategy, pasted → CASE and CO questions grounded in the company's own priorities. Today C1 and C2 are generic.
- Notes or agendas from one roadmap-input session → moves the medium-confidence line (F3, D3) to inspected proof.
- Time before Thursday → sizes a prioritized triage section.
- Permission for web search → lets the three refused lookups run again at L1.
- A re-underwrite if the posting has changed since 2026-08-14 → the role_profile here is from that date.
