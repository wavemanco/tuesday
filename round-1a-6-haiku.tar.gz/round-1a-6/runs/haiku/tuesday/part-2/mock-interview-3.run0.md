Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-3-denied-11fb7597/e8ad9adb-c118-492a-9fad-6bf88be6f056/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round of unknown format, since your note didn't say who you're meeting or how the round runs.

Web search was refused in this session, so the pack has no Stripe-specific facts: no published values, no interview structure, no current strategy. I haven't filled those from memory. Everything about the company is left out or labelled generic.

Two offers, neither pushed:
- Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. I can also convert the pack to Word if you want it.

Two questions:
1. Who are you meeting in the final round: a hiring manager, a peer, a panel, or a senior leader? The answer reweights every question bank.
2. Can you paste the job posting, and your CV or a paragraph on your last two roles? Without them, the fit snapshot is a worksheet and no answer is tied to your own evidence. I can go on without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final, format and interviewer not yet known, so this is a blended session pack with flat persona weights. Interviewer: not given.

## How to use

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script.

Everything in this pack is `[generic]`. No CV, job posting or company research came in, so nothing here asserts a fact about you or about Stripe.

Type key:

- **VAL**: behavioral and values alignment. No published values are in hand, so these are generic behavioral questions.
- **EXP**: your own experience, tested for attribution.
- **JD**: a stated requirement. None this run, because no posting is in hand.
- **CO**: company and strategy knowledge. None this run, because company research did not run.
- **CASE**: a live problem, worked aloud.

## Fit snapshot (worksheet variant)

No CV and no posting were supplied, so every evidence cell is `none given`. The requirements are role-family patterns, written as prose and not quoted. Each row says what strong evidence looks like, then gives a selection scaffold ending in its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running a planning or operating cadence across several teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is one cadence you set up or ran, with what it decided and how you knew it worked. Scaffold: name a planning cycle you took part in and say which parts were yours to set. If none of it was yours, or there was no such cycle, say so plainly and give the nearest process you did run. |
| F2 | Running a launch or rollout that several teams depend on (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one launch with its dates, its dependencies and who signed off the tradeoffs. Scaffold: pick a launch where several teams had to move together, say what you coordinated and what you decided yourself. If you did not coordinate one, say so and give the nearest piece of work you did coordinate. |
| F3 | Using operating metrics to judge whether a process works (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you defined or used, its source, and a decision it changed. Scaffold: name one metric you used to decide something and how it was counted. If you did not define or count it, say whose it was and which part you did. |
| F4 | Improving a process by writing it down, testing it and getting people to use it (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you documented and what changed for the people using it. Scaffold: pick one process you changed, say what you wrote and whether people still use it. If you changed none, say so. |
| F5 | Taking tradeoffs to senior leaders and getting a decision (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a decision you put to someone senior, the options you gave and what they chose. Scaffold: pick one decision you put to a leader and say what options you offered. If you have not done this, say so and name how you would prepare. |
| F6 | Choosing or building internal tools and dashboards for a team's work (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a tracker or dashboard you built or chose, and who used it. Scaffold: name a tool you used daily and say whether you built it, chose it or inherited it. If you have none, say so. |

No gate row appears. A gate is a term such as location, work authorization, schedule or a credential. None shows in the material because no posting has been supplied. If the posting carries one, it becomes a `hard_gate` row and is surfaced before the others.

## Prohibited list

No entries yet. The list is built from what the candidate has said, and nothing about their past has been said in this conversation. Once a CV or a description arrives, any sentence that stretches it will be listed here.

Until then the honest rule holds for every answer in this pack: name only what you did, in your own words, and say plainly when a practice was not yours.

## Persona table

No relationship or round type is known, so no prior can be picked. The loop is unknown, and no values-style round is detected: the fallback archetype is Generic, which gives flat weights, said plainly, and reads no values round. Each persona therefore gets 3 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live operating problems | Flat, 3 questions. Ops final rounds often include a live problem | Clarify, then structure, then segment, then metrics, then risks. Think aloud |
| B. Skeptic | Probes gaps and motives | Flat, 3 questions. Scope and motivation are the usual first checks | Rehearse the predictable objection until it is boring |
| C. Data-Driven Prober | Asks how figures were counted | Flat, 3 questions. Applies to any metric you cite | Name the weakest assumption before they do |
| D. Pressure | Interrupts, time-boxes | Flat, 3 questions. Tests composure, not content | Pause, restate, hold through two follow-ups, then concede specifically |
| E. Values / Behavioral | Scenario probes, STAR-shaped | Flat, 3 questions. No published values in hand, so the scenarios are generic | One story per scenario, with we for context and I for your part |
| F. Peer Evaluator | Seams, credit, disagreement | Flat, 3 questions. A peer prices the partnership | Propose seam principles; show what you bring, not only what you need |
| G. Conversational | Friendly, unstructured openers | Flat, 3 questions. Casual questions are still scored | A 90-second arc; treat casual questions on the role's world as scored |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | A weekly review shows a key process metric down 15% over two weeks. How would you diagnose it? | CASE | [generic] | Clarify what the metric counts and what changed in the same window: a release, staffing, volume, a definition. Segment before you hypothesize. Rank hypotheses by how fast each can be checked, and name the metric you would watch to confirm. Challenge one premise before you accept it. | Diagnosis is a standard live problem for operations roles. The guidance describes structure, not your past. |
| A2 | A launch is two weeks out and one dependency team says it cannot make the date. What do you do? | CASE | [generic] | Clarify what slips and what the date protects, and who owns the tradeoff. Offer two or three options, with what each costs and to whom. Say what you would need from each team and by when, and who hears it first. | Tests whether you find the decision owner under time pressure. Maps to F2 and F5. |
| A3 | Design an operating cadence for forty people across three functions that has no shared planning today. | CASE | [generic] | Start from the decisions the cadence must support, then the fewest meetings and documents that support them. Name an owner for each, and one signal that tells you at six weeks whether it works. | Tests whether you design from decisions rather than from meetings. Maps to F1 and F4. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Which part of this role would you be weakest at on day one? | EXP | [generic] | The highest-ROI prep in this pack, because this objection will come in some form. Name the one skill the role needs that you have used least, then the first 30 days of how you would close it. If you have not used the skill at all, say so plainly. Hold through two follow-ups by returning to the skill and the plan. Concede the gap specifically once it is real. Never claim past use you cannot name. | Skeptics open on scope. With no CV yet there is no evidence to lean on, so a specific, calm answer carries the whole weight. |
| B2 | Why this role now, and why at this company? | EXP | [generic] | Answer with your own reasons: what you want the next role to do and what you want to stop doing. Do not repeat a claim about the company that you cannot source. If the honest reason is the scope of the role, say that. | Motivation consistency is the Skeptic's central check. The guidance supplies no reasons, only the shape of yours. |
| B3 | What would make you turn this role down after the first month? | EXP | [generic] | Name the one or two conditions that are real for you, and what you would do if they were met. If you have none you would name, say so. Do not invent a threshold to sound decisive. | Tests honest self-assessment, and whether the motivation survives cross-examination. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Tell me about a metric you used to make a decision. How was it counted? | EXP | [generic] | Choose one metric you actually used. Give its definition, where the data came from, what it is sensitive to, and the assumption you would defend least. Say which part of the counting was yours. If you have no such metric, say so and describe the nearest thing. | Probers test attribution first. This is an open prompt, so it supplies no figure. |
| C2 | How would you know a process change worked, six weeks after launch? | CASE | [generic] | Name one leading and one lagging signal. Say what else could have moved the signal in the same window, and which control you would use. Say what you would stop doing if it did not work. | Tests whether you can separate a change from its background. |
| C3 | A dashboard shows adoption up 30% after a rollout. What do you check before you believe it? | CASE | [generic] | Check the definition, the denominator, the time window, selection effects, and what else changed on the same dates. State what evidence would change your mind. | Standard follow-up on any headline number. The answer is method, not a figure. Maps to F3 and F6. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Sixty seconds: why you over someone who has done this role for years? | EXP | [generic] | Pause, restate the question, then answer from one thing you have actually done, in your own words. Hold the position through two follow-ups. Concede a real gap specifically, without folding on the core claim. If you have no comparable experience, say so and name what you would do in the first month. | Tests composure. Hold-then-concede is the structure. No comparison is supplied. Maps to F5. |
| D2 | Name one decision you made yourself in work like this. If none, say so. | EXP | [generic] | Name one decision and what you weighed in it. If your part was a contribution to someone else's decision, say that plainly. Do not add stakes or outcomes you did not have. | Tests attribution under pressure. The second branch is allowed, so the question asks for no particular past. |
| D3 | Your answer was vague. Give me the number. | EXP | [generic] | Give a figure only if you can defend how it was counted. Otherwise say you do not have it, and say how you would measure it. Never round a figure up to satisfy the question. | No figure has been supplied, so the honest answer is the measurement plan. |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | Tell me about a time you had to tell leadership something they did not want to hear. | VAL | [generic] | Pick a time a plan you were part of was failing, or a decision was unpopular. Name the stake, what you said, and how it landed. Use we for context and I for your part. If no such time comes to mind, say so plainly and give the nearest thing you did. | Common behavioral theme. Generic because no published values are in hand. Maps to F5. |
| E2 | When did you put the person using a process ahead of the metric it was built to hit? | VAL | [generic] | Pick a time the two pulled apart. Name what the metric was, who was affected, and what you chose. If you have not faced that trade, say so and describe how you would weigh it. | Values probes often test this trade. The choice stays the candidate's. Maps to F4. |
| E3 | Describe a time a team would not adopt your recommendation. What happened next? | VAL | [generic] | Pick one. Say what you proposed, what they objected to, and what you did next. Say what you would change, only if that is true. If you have no such time, say so and describe how you would approach it. | Tests persuasion without authority, a common operations scenario. |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | Our teams sit side by side. Where is the seam between us, and what happens when we disagree? | VAL | [generic] | Propose principles for the seam rather than pretending to know it. Say who decides when you disagree, and how you would reach a decision with equals. Give a disagreement story only if you have one. Otherwise, state the principle you would use. | Objections from other banks return in collegial form. A peer is pricing the partnership. |
| F2 | How do you handle credit when work spans teams? | VAL | [generic] | Name the principle: each person gets credit for their part, named. Say how you would raise it when it is missed. Stay on your own practice only where you have one. | Credit probes check turf and fairness. |
| F3 | What would you need from my team to make this role work? | EXP | [generic] | Ask for specifics: data access, decision rights, meeting cadence, and who you escalate to. Commit to nothing you cannot do. | Shows whether you know what a working partnership needs. |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | So, walk me through the journey. | EXP | [generic] | Prepare a 90-second arc: where you started, the through-line, and the scope you have had, each in your own words. Until your CV is shared, the arc is a skeleton with empty slots. | Casual openers are scored for economy and clarity. A pre-built arc keeps the answer short. |
| G2 | What are you reading or working on right now that bears on how you think about operations? | EXP | [generic] | Name one real item you have read or used, and what you took from it. Do not list things you have not engaged with. | A casual question on the role's world, scored as interest and honesty. |
| G3 | What is the thing you most want from the next role? | EXP | [generic] | Say one true thing from your own reasons, briefly. Do not claim anything about the company that you cannot source. | Motivation again, asked casually. Keep it consistent with B2. |

**Requirement coverage.** F1 is covered by A3. F2 by A2. F3 by C1, C2 and C3. F4 by A3 and E2. F5 by A2, D1 and E1. F6 by C3. No requirement earns no question.

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | What does a good first 90 days look like for this role, and what has to be true at day 90? | Shows you think in outcomes, not tasks. |
| R2 | Which decisions does this role make most often, and who owns the ones it escalates? | Operations roles fail without decision rights. This tests whether they are defined. |
| R3 | Which process here do people complain about most, and what has been tried? | Shows you want the real problem, not a tidy one. |
| R4 | How does the team tell whether its operations work is working? | Tests whether measurement is owned, which matters for this role. |
| R5 | What would a new person do in their first month that would genuinely help your team? | Reciprocity. It signals you bring something, not only ask for something. |
| R6 | What has changed in how this team plans over the last year? | Gets current context by asking. Nothing about the company is assumed. |

## Sources

- **Provided documents:** your message only (the role, the company, the round). No posting, CV, interviewer name, recruiter guidance or earlier dossier was supplied.
- **Searches sent: 3, all refused.** The host did not grant web search, so no page was returned or fetched.
  - "Stripe values operating principles": refused.
  - "Stripe interview process final round onsite Product Operations Manager": refused.
  - "Stripe strategy news 2026": refused.
- **Pages fetched:** none.

Research tier: L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet and VAL questions mapped to published values: none produced. No values are taken from memory. |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights stay flat because the round format is unknown. |
| 3. Stripe strategy or recent news | unavailable | CO bank: none written. CASE questions stay generic. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative Product Operations Manager posting | unavailable | Fit snapshot requirements. No call was sent, because the host refused search, so the row is unavailable and not skipped. Requirements stay role-family prose, labelled generic. |

## Upgrade menu

- Round type and who you meet (hiring manager, peer, panel, senior leader) → persona weights restructured, and reverse questions retuned to that person.
- The job posting, pasted → worksheet rows become grounded. Any location, eligibility or schedule term becomes a gate row, surfaced first.
- Your CV, or a paragraph on your last two roles → evidence cells fill, and each scaffold becomes a story map wherever your own sentences carry the story.
- Stripe's values page, pasted → values cheat sheet, and VAL questions mapped to the published values.
- Recent Stripe news or strategy, pasted → CO questions, and CASE questions grounded in current strategy.
- The interviewer's name → a persona read from public professional footprint, and a tailored reverse question.
- The recruiter's prep email → any pre-declared deliverable gets its own build section.
