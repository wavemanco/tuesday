Research tools are loaded. I'll run the default L1 targets first: company values, interview process, strategy, and the interviewer's public footprint.
Four searches returned results. I'll fetch the two official pages the values and interview claims depend on.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-7-canned-302e5da9/saltmarsh_live-operations-producer_interview_pack.md`. Friday is tomorrow, so section 2 of the pack is the order to work in.

Three things from the research shape the prep:

- **The round is a tabletop, not a conversation.** Saltmarsh's careers page says the Outage Hour is a live-incident tabletop on a simulated outage during a live event, then a values conversation. Practice talking through the first hour of an outage out loud.
- **The objection to expect is leadership.** You've never led a team, and this role coordinates four functions that don't report to you. The pack's B1 walks through a concession-then-plan answer with follow-ups. It's the highest-value thing to rehearse.
- **Tobias's public talk is on the same theme as one of their values.** His GDC 2026 talk argues a live team is judged by how often its patch notes match what shipped. Saltmarsh's "Ship the Patch Not the Promise" says the same. I only read the search snippet of the talk, so read the full talk if you can, before Friday.

The pack also flags a tension in the research: Saltmarsh announced Project Larkspur in September, which moves two titles to one shared events calendar and one live-ops group from February 2027. That may change what "two titles" means in this role. Reverse question 3 uses it.

You asked for a live drill. I haven't started it yet, because the skill's format ends the pack message on its watch-out line, and the drill's first in-character question has to come after that. Reply "go" and I'll open with B1 as the Skeptic, the pack's highest-ROI question. If you'd rather start with the tabletop, say so and I'll open with A1 as the case.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** The Outage Hour, one 60-minute interview with the hiring manager, Tobias Wrenfield, Head of Live Operations. Friday.
**Format (from the company's careers page):** "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **CASE** live problem · **JD** the listed job's requirements · **EXP** what you actually did · **VAL** the published values · **CO** company knowledge.
- Guidance is scaffolding for a spoken answer of 90 to 120 seconds. It is not a script.
- Provenance labels: **[grounded]** traces to your message, the JD, or a fetched Saltmarsh page. **[inferred]** is a derivation. **[generic]** is a pattern with no claim about you or Saltmarsh.

## 2. Prep triage (Friday is tomorrow)

1. **B1**, the leadership objection, said aloud three times. It is the question most likely to be asked in some form, and the pack names it highest-ROI.
2. **A1 and A3**, the Outage Hour tabletop. Talk through the first hour out loud.
3. **C1 to C3**, the values conversation, with the honest branches ready.
4. Read the interviewer's GDC talk (see section 4) if you can open it.
5. Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title and content drops, not two titles and events. Words that stay at scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about events across two titles. If you planned events, or a second title's calendar, say what and how; if not, say what you ran and how you would extend it. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these teams. Answer slot: name the teams you worked with on an update and what each needed from you. If the only team you coordinated with was QA, say so, then describe how you would set up this update's plan. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material shows you presented the numbers, not that you owned a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported. If you presented numbers someone else produced, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how much of it you wrote versus what QA changed (B2). |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because there is no inspectable calendar yet. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | presentation | The quotes reach the requirement only in other terms: the live-service part is the weekly content drop. Bridge in those terms: "Four years at a puzzle-game studio, and a weekly content drop for the last two of them." Do not add "live-service" as a label for the four years. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | The quote reaches the requirement. No figure was given, so the pack raises no defend-the-number slot. Expect a probe on how the numbers were counted (D1). |
| F8 | "clear written communication" (JD) | none given beyond the checklist | low | [grounded] | discovery | The one written artifact in your material is the checklist. Answer slot: name the written artifact you would show, and what it was for. Upgrade menu: a copy of the checklist would give this row something to point to. |

Stated absences not in the JD table, handled in the question banks: you have never led a team (B1), and you have never worked on a game with in-app purchases (B4). The JD names neither, so no question presupposes them without your own words as the source.

## 4. Reading the interviewer

**Public footprint only.** Career pattern from the search snippet of a GDC 2026 talk: previously a QA lead at a console studio, now Head of Live Operations at Saltmarsh. I read the snippet only and did not open the talk itself.

**Self-described argument:** "a live team is judged by how often its patch notes describe what actually shipped."

**Practical implications**
- His own argument matches Saltmarsh's "Ship the Patch Not the Promise" value. Expect a question on announcing versus shipping (C2).
- A QA background means release discipline will be read closely. Your checklist work is the most relevant thing in your material to him.
- Mirror opportunity, shared domain, not shared path: "Wrote the release checklist our QA team still uses" (your message). Use it to open the QA answers, and do not claim his path as yours.

## 5. Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | The Outage Hour tabletop, live, on a simulated outage | Highest. The round is defined as a tabletop, and the hiring-manager relationship weights Case up | Clarify, then structure, then decide, then say what you would tell players. Think aloud. |
| Skeptic (weight 4) | Quiet probing of the gaps: leadership, IAP, the QA-written-versus-QA-changed question | High. A hiring manager is buying capability and de-risking gaps. Two stated gaps are on your record | Rehearse B1 until it is boring. Concede the fact in one sentence, then give a plan |
| Values / Behavioral (weight 4) | The "values conversation" that closes the hour. The page documents it, so it is guaranteed to appear | High. The loop source establishes it | Map stories only to quoted sentences. Use the honest branch where none carries one |
| Data-Driven Prober (weight 3) | Retention numbers and the KPIs in the post-event review | Medium. The JD names both, and the one figure-type claim you made is retention | Say how the numbers were counted only if you know. Name the weakest assumption you know |
| Pressure / Stress (weight 3) | Time-boxed answers during the tabletop, attribution challenges | Medium. A 60-minute slot with a live problem invites time pressure | Pause, restate, anchor in your own sentence. Hold through two follow-ups, then concede specifically |
| Conversational / Rapport (weight 2) | Warm opener, the "walk me through" question | Lower. The recruiter call has already happened, and this is a working session | 90-second arc from your own sentences. Treat casual questions as scored |

No peer or panel persona is weighted, since the loop is one hiring manager.

## 6. Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running, and claims fail for part of your players. Walk me through the first hour." | CASE | [generic] | Clarify scope first: which players, which platform, what is already confirmed. Decide whether to keep the event live, roll back, or partial-ship. Decide who you tell and in what order. Announce only what is fixed. | The Outage Hour is a live-incident tabletop. The scenario is a generic live problem, so it claims nothing about you. |
| A2 | "Which of the two titles would you protect first in that outage, and what would you ask before deciding?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name the question you would ask first, then choose with a reason. Do not quote numbers for either title. | The JD makes two titles the scope. This tests structure, not knowledge of either title. |
| A3 | "A major event is due Friday, and QA sign-off slips a day. What do you do?" | CASE | [generic] | Ask what is still blocking the checklist. Options: move the start, ship a reduced scope, or hold. Choose one, then say what you tell players and the community team. | Ties the release checklist requirement to a live decision. No claim about your past. |
| A4 | "How would you plan one update so design, art, engineering and community each know what they own?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: name the teams, the dependency order, and one owner per deliverable. If your coordination was with QA only, say so, then describe how you would set up this update's plan. | F2 is discovery. The answer slot covers the honest branch. |
| A5 | "Day-seven retention dropped after an update. Diagnose it." | CASE | [generic] | Split the drop by cohort, platform and date against the release. Rule out a tracking change. Ask engineering what shipped versus what was announced. | Tests the retention metric the JD names. Generic, with no claim about past numbers. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. This role coordinates four functions that don't report to you. Why would they follow you?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | **Highest-ROI prep.** Hold then concede. Concede first in one plain sentence: "I haven't led a team." Hold on what you can stand behind: "Wrote the release checklist our QA team still uses." Then a plan, said as a plan: ask each lead what they need from the update and write the plan with them. Follow-up one, on engineering saying no: say how you would take the disagreement to the decision-maker. Follow-up two, on who decides: name who decides, or say you don't know yet. | The most predictable objection. The negative is your own sentence, so a plain acknowledgment is allowed. The hold rests only on the checklist sentence. |
| B2 | "How much of that release checklist did you write, and how much did QA write?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say what you wrote, in those words. If QA changed it, say what they changed. If you have no account of who changed what, say that. | F4's probe. Tests the attribution line. |
| B3 | "Your background is four years at a puzzle-game studio. What in it is live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say it in those terms: four years at a puzzle-game studio, a weekly content drop for the last two. Do not call the four years "live-service" as a label. | F6 is presentation. The JD asks for live-service work, and your sentences describe it without the label. |
| B4 | "You haven't worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a learning plan, said as a plan. | The JD does not raise IAP, and I could not establish whether Saltmarsh's two titles use it. This question is one an interviewer might choose to raise. |

### C. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win" (saltmarshgames.com/values) | Selection scaffold: pick a time a drop date or schedule ran against what players needed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar, and how you would decide a conflict in it now. "We" for the team, "I" for your call. | Published value, no story in your sentences carries it, so the scaffold ends in the honest branch. |
| C2 | "Tell me about a release where what you announced and what shipped did not match." | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (saltmarshgames.com/values) | Honest branch: if one happened, say what was announced, what shipped, and what you changed after. If no release you worked on mismatched, say so, then describe how you would check announcements against the build. | His talk's theme, so expect it. |
| C3 | "Walk me through the release checklist you wrote. How has it been used since?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-mapped to "Leave the Build Greener", using the beats the sentence states: you wrote it, and QA still uses it. Answer slot: whether it was revised each release. If you revised it, say what changed and why. If not, say so, and say what you would change. | The only value your material maps to. The "better each release" part is a slot, not a claim. |
| C4 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Selection scaffold: if the retention numbers were unwelcome at any point, say what they showed and what you said. If not, say so, and give the nearest unwelcome thing you handled. | Persona stem for the values round. The honest branch is the answer. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you know the definition and window, say them in your own words. If the counting was not yours, say so, and say what you presented and to whom. | F7. No figure was given, so the pack supplies no method. |
| D2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know. If you know none, say so. | Converts a gotcha into a credibility move. |
| D3 | "What is your experience running a post-event review, and which KPIs did it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported. If you presented numbers someone else produced, say so. | F3 is transferability. The question asks about experience, so it presupposes no particular occasion. |

### E. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events for two titles?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Pause, then restate. Anchor in your sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups. If pressed on two titles, concede the scope in your own terms: one title's calendar. | Persona stem. The concession never claims two titles. |
| E2 | "That content-drop calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold on what was yours, in your words. Concede the shared parts specifically. Do not add to the sentence. | Attribution challenge. The honest concession is the rehearsal. |
| E3 | "Tell me about a time QA said no to a release. What happened?" | JD | [grounded] "manage the release checklist with QA" (JD); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Selection scaffold with honest branch: if QA stopped a release you were part of, say what they stopped and how you handled it. If none, say so, then give the nearest thing: the checklist you wrote, and how it is used. | F4's objection under time pressure. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in your own words, built only from those sentences. No added titles, dates or scope. | Casual register is still scored. |
| F2 | "Which live event in a mobile game have you admired most, and what would you have changed?" | CASE | [generic] | Pick one, say what worked, and give one change. No claim about your past. | Tests taste and critique without a factual claim. |

## 7. Values cheat sheet

Values-style round detected: the loop source documents a values conversation.

| Value (official name) | Working meaning | Mapped story, or scaffold with honest branch |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story. Scaffold and honest branch in C1. |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped | No quoted sentence carries a story. Scaffold and honest branch in C2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4 (your message): "Wrote the release checklist our QA team still uses." Mapped in C3. The "better each release" part is an answer slot. |

## 8. Reverse questions

Each has a "why it lands."

1. **"The Outage Hour is a live-incident tabletop. Which real incidents shaped it?"** Why it lands: shows you read the loop page. The answer tells you how the tabletop is scored.
2. **"Your talk argues a live team is judged by how often its patch notes match what shipped. How do you measure that today?"** Why it lands: ties the interviewer's own published argument to a working conversation.
3. **"Project Larkspur moves Tidepool Tactics and Lantern Row to one shared events calendar from February 2027. What will the single live-ops group own that the per-title teams did not?"** Why it lands: shows you read the strategy news. The answer tells you the real scope of the role, which the JD's "two titles" may not match.
4. **"Which of the two titles has the harder calendar right now, and what is it blocked on?"** Why it lands: shows you think in calendars and dependencies.
5. **"How does QA sit in the release decision: who signs off, and what happens when they say no?"** Why it lands: tests the checklist's place in the process, which is your strongest ground.
6. **"What did the last person in this role do in the first 90 days that you'd want the next one to repeat?"** Why it lands: signals you plan to own the role. The answer sets the bar.

## 9. Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Sourced entry: your "Never led a team" (B1), plus an inflated form of the calendar and checklist lines | "I haven't led a team." Then F4's quote at its scope |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its scope: one title's weekly content-drop calendar, for the last two years. The limit is the pack's analysis: your material says one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The limit is the pack's analysis: your material says presented |
| Ran release sign-off with QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." Nothing about who signed off |
| Ran retention analysis | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." Nothing about how they were produced |
| Four years of live-service production | Inflated form of F6 | Four years at a puzzle-game studio, with a weekly content drop for the last two |
| Has worked on an in-app-purchase game | Sourced negative: your "never worked on a game with in-app purchases" (B4) | "I haven't worked on a game with in-app purchases." Then a learning plan, stated as a plan |

## 10. Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, E1 | Material shows one title; the answers stay at that scope |
| Coordinate design, art, engineering and community teams on each update | A4, B1 | F2 is discovery |
| Own the post-event review and the KPIs it reports | D3, D1 | F3 is transferability |
| Manage the release checklist with QA | C3, B2, E3 | F4 has no gap |
| 3+ years producing live-service games or apps | B3 | F6 is presentation |
| Experience running a content calendar | E2 | F5 has no gap |
| Comfortable with player-retention metrics | D1, D2, A5 | F7 has no gap |
| Clear written communication | none, and why: the JD names one line, and the material shows one written artifact, the checklist. Upgrade menu asks for a copy | F8 is discovery |

## 11. Sources

**Provided documents:** the JD and your message, read as supplied. No CV was supplied.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 7: three values by name, from the official page |
| 2. `Saltmarsh Games interview process {role family}` | yes | Loop: one 60-minute Outage Hour with the hiring manager, tabletop then values. Fixes the session and the values round |
| 3. `Saltmarsh Games strategy` / recent news | yes | Found one item, Project Larkspur (September 2026). Used only in reverse question 3. Snippet read, page not fetched |
| 4. `{interviewer name} Saltmarsh Games` | yes | Interviewer read from a GDC 2026 talk snippet. Talk not opened |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

**Queries and what came back**
- "Saltmarsh Games values": saltmarshgames.com/values, fetched.
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing, fetched.
- "Tobias Wrenfield Saltmarsh Games": talks.gdconf.example/2026/patch-notes-are-a-promise, snippet only.
- "Saltmarsh Games strategy news": saltmarshgames.com/news/project-larkspur, snippet only.

All four results named Saltmarsh. None showed a name collision.

## 12. Upgrade menu

- **A copy of the release checklist, or a redacted one** → F4 and F8 move from medium and low toward high, and B2 gets an artifact to point to.
- **The monthly retention report you presented** → D1 and D2 can carry what was counted, if you know it.
- **Any event or second-title calendar you planned** → F1 moves from transferability to grounded.
- **Whether either title uses in-app purchases** → B4 can be tailored. The search did not establish this, so the pack does not claim it.
- **A deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the interviewer's full talk and writing, loop reports, and recent org context. Want it?
