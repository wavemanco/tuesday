Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-2-rooms-case-8-denied-1e3a7f4b/5d220ba2-5dee-4ad4-8eeb-f9663e83d68c/scratchpad/ashgrove_member_experience_lead_interview_pack.md. It's built as three mini-packs, one for each 5 December round, on one shared fit snapshot. The biggest gap is the contact centre: you have never worked in one, and the JD names it in the scope. Round 2, question B1 is the highest-return rehearsal in the pack.

The pack's strongest rows are the branch complaints log and the escalation training. The gaps it can't close are the contact centre, presenting above regional level, regulated complaints, and supervisor coaching. For those, the honest answers are a plain acknowledgment and a plan. I didn't search the web, because your pasted values, the recruiter's round details and the July brief already cover the research targets. The strategy quotes come from your summary of the brief, so check the exact wording before you use them in the room.

I'd like to play the Head of Member Services on B1 in a live drill. Say the word and I'll run it with follow-ups. I can also save a tuesday-dossier.md that records the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack (loop)

Prepared 26 November 2026 for Dara. Three rounds on 5 December 2026: a 30-minute recruiter screen, a 45-minute behavioural round with the Head of Member Services (your prospective manager), and a 60-minute panel of two branch managers that includes a 20-minute complaint-escalation case and scores against the four values.

## Contents

- How to use, and the type key
- 1. Shared fit snapshot
- 2. Grounding brief (strategy)
- 3. Round 1: recruiter screen (persona table, bank, reverse questions)
- 4. Round 2: Head of Member Services (persona table, bank, reverse questions)
- 5. Round 3: panel (persona table, bank, values cheat sheet, reverse questions)
- 6. Prohibited claims (shared across rounds)
- 7. Sources and target accounting
- 8. Upgrade menu

## How to use, and the type key

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: it names what to think about, and both of its honest branches are valid answers.

- **VAL**: behavioural and values alignment, scored against Ashgrove's published values.
- **EXP**: your own experience, probed for what was actually yours.
- **JD**: whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, worked out in the room.

Each round is weighted differently. Round 1 is logistics and motivation, round 2 is probing and behavioural, round 3 is values and a case.

## 1. Shared fit snapshot

Requirements are quoted from the job description you sent. Evidence is quoted from your own message only. No requirement is a gate: "4+ years" is experience, graded like any other requirement, and your material states no licence, credential or other term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." Your material shows the branch log, not the end-to-end process. Answer slot: if you set or changed any step between a complaint arriving and its closing, say which and how you decided, in your own words. If no such step was yours, say so plainly and stay with the log you handled. |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then a plan, said as a plan and never as a past: how you would learn a contact-centre complaint flow. No claim to contact-centre work. |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal, not regulated, so the bridge stops at the log. Answer slot: if the log carried regulated timescales, external referrals or regulator reporting, say which and what your part was. If it did not, say so plainly and say what the log did track. |
| F4 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Words, reworded from the quote only: "I built the monthly complaints spreadsheet our regional manager uses." No figure is given, and none is added. |
| F5 | "and resolution times" — JD | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked how long complaints took to close. Answer slot: if it did, say what it recorded and how it was counted. If it did not, say so plainly and say what it did record. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Your material shows tellers, not supervisors. Answer slot: if you coached supervisors on escalations, say how. If you did not, say so and say what the teller training covered. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you worked with a digital or product team on any member journey, say what it was and what your part was. If you did not, say so plainly and say how you would learn it. |
| F8 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Words: "6 years in retail banking, the last 3 as a branch supervisor." Retail banking is financial services, and the quote carries the years. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then a plan, stated as a plan: how you would prepare for a senior audience. |
| F10 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Words, reworded from the quote only. Your material says spreadsheet. Whether it was Excel is for you to say, and the pack does not say it. |

Analysis, not words for you: the material shows a branch-level complaints log, an escalation script taught to tellers, and a monthly spreadsheet your regional manager uses. It does not show an end-to-end process, contact-centre work, regulated complaints, or presenting above regional level. Those four are where the pack spends its rehearsal.

## Prohibited claims

Built locally from the fit snapshot. Each entry gives its basis and its honest form. No answer slot, hold, bridge or reverse question in this pack asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. Observation, not words for you: your material says the branch log, not the process. |
| Ran complaint handling in a contact centre | Negative you stated, F2 | "I've never worked in a contact centre." No slot on contact-centre practice. |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: you trained tellers. |
| Presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. Observation: your material says formal, not regulated. |
| Built Excel reporting | Inflated form of F10 | "I built the monthly complaints spreadsheet our regional manager uses." Whether it was Excel is yours to say. |

## 2. Grounding brief (strategy)

Your message summarises Ashgrove's July 2026 strategy brief. The brief itself was not pasted, so the quotes below come from your summary. Check the exact wording against the brief before you use it in the room.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

Vocabulary to learn: digital channels, hubs, small-business lending, app-only banks. The brief is dated July 2026, under six months old on 26 November 2026, so nothing here is flagged stale.

## 3. Round 1: recruiter screen (30 minutes)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, background question, "tell me about yourself" | High. A recruiter screen is a conversational register, and it is scored anyway. | A 90-second arc built only from your own sentences (A1). Treat casual questions about the role as scored. |
| Logistics (recruiter's own row) | Pay, notice, location, reason for leaving | High. These are the recruiter's knockout checks. Your material states none of them, so each slot is yours to fill. | Answer in your own words, with your own figures. Give no number the material does not contain. |
| Skeptic, light | One question about the contact centre | Medium. The recruiter may already have read the gap. | Acknowledge the gap plainly and give a plan (A7). |
| Case / Strategist (light) | One question on the strategy brief | Medium. The brief is in the recruiter's hands, so expect one question on it. | Say what it means for the complaints you would handle, in your own words (A8). |

**Question bank (round 1)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about ninety seconds." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | The arc is the four quotes in order, in your own words, ending on what you want next. Keep it under 90 seconds. Do not add a role, a team or a result that is not in the quotes. | The opener that every interviewer's later questions build on. F8, F1, F6 and F4 are its beats. |
| A2 | "What's your notice period?" | JD | [generic] | Give your actual notice period in your own words. Your material does not state one, so the pack gives no figure. | Logistics slot. The recruiter's knockout check, and nothing in the material fills it. |
| A3 | "What are you looking for in salary?" | JD | [generic] | Name your own number, or ask to hear the band for this role first. Your material gives no figure, so none is suggested. If asked what you earn now, say: "I'd rather focus on the range for this role." | Logistics slot. Pay is the recruiter's most common screen. The honest answer is your own figure, or the decline. |
| A4 | "Where can you work from, and how often would you need to be in the office?" | JD | [generic] | Say where and how often, in your own words. Your material states neither. | Logistics slot. Location and office pattern are knockout checks. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your real reason, in your own words. Your material gives none, and a reason should not be borrowed from the posting. | Logistics slot for the reason for leaving. A reason the material does not carry is an invention. |
| A6 | "What drew you to this role?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Name one part of the posting that matches what you did, quoting your own sentence. Do not name the contact centre as a draw unless you mean it. | A motivation question. It tests whether the answer matches your history. |
| A7 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" — your message | Say: "I've never worked in a contact centre." Then one sentence on how you would close that gap, as a plan. | The gap that matters most in round 1 (F2). A plain acknowledgment with its source; the plan is not a claim about the past. |
| A8 | "You've read our July strategy. What stood out?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — your message (summary of the brief) | Pick one line and say what it means for the complaints you would handle, in your own words. Do not recite the brief. | Tests whether you read the strategy and can think at the company's level. |

**Reverse questions (round 1)**

- "What does the first 90 days look like for someone in this role?" Why it lands: it shows you are planning the role, and it opens the contact-centre gap on your terms.
- "Will the small-business lending product share the member complaints process?" Why it lands: it shows you read the brief and are thinking about the next product, not just this job.

## 4. Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: contact centre, end-to-end scope, senior presenting, the figures | Highest. A hiring manager is buying capability and derisking gaps, and the recruiter describes this round as mostly behavioural. | Rehearse the contact-centre objection until it is boring (B1). Hold your claims to the quotes, and concede specifically. |
| Values / Behavioral | Story prompts for members, plain words, coaching escalations | Medium-high. The round is behavioural, so expect STAR stories. | Choose stories where a decision was yours. Say "I" for what you did and "we" for context. |
| Case / Strategist | One scenario from the role, and one from the strategy | Lower. The round is not framed as a case, and the case sits in round 3. | Clarify, then structure, then answer. Use Ashgrove's own words. |

**Question bank (round 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. How would you run complaints across one?" | JD | [grounded] "Never worked in a contact centre" — your message | **Highest-ROI prep in the pack.** Hold: "I've never worked in a contact centre." Then the honest bridge: your material carries the branch log and the escalation script, the nearest thing to contact-facing process. Then the plan: name the first thing you would ask to see in a contact-centre complaint flow. If they press on volume, hold the plan and concede specifically: "I don't know a contact centre's complaint volumes yet, and I would find out before I promised anything." Never fold on the fact that you have not worked there. | F2 is a capability gap, and the JD's scope names the contact centre. This is the objection the panel will most likely echo, so it gets the deepest rehearsal. |
| B2 | "Why should we trust you with end-to-end complaints when your experience is branch-level?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Say the quote: "I handled the branch's formal complaints log." Answer slot: if you set or changed any step from complaint to closure, say which and how you decided. If none was yours, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it. | F1 is the transferability row. This is the question the branch-scope gap invites. |
| B3 | "I don't see senior-leader presenting in your background. How would you handle presenting to our leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Say: "I've never presented to anyone above regional level." Then a plan, stated as a plan: how you would prepare, and the first rehearsal you would ask for. | F9 is a capability gap, and the question quotes your own negative. |
| B4 | "Walk me through the monthly complaints spreadsheet. What did it report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what it reported, in the quote's terms. Answer slot on resolution times (F5): if it recorded how long complaints took to close, say how that was counted. If it did not, say so plainly and say what it did record. | F4, F5 and F10 meet here. The spreadsheet is the nearest thing to the reporting requirement, and the figures are where probers go. |
| B5 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a complaint where the member's side decided what you did, and name your decision and what the member needed to hear. If none comes to mind, say so plainly, then give the nearest thing your log carries: that you handled it. | Maps to Members First, Always. Your sentence does not carry a member-side decision, so this is a scaffold, not a story. |
| B6 | "Tell me about a time you had to make an escalation script clear to someone new." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Story-mapped: you trained new tellers on the script. The beats are the script and the tellers, and nothing more. Answer slot: if you changed how the script was explained after it did not land, say what and why. If you did not, say so and say how the training ran. | Maps to Plain Words. The sentence carries the training; the clarity is for you to show. |
| B7 | "Tell me about a time you coached someone on an escalation they handled badly." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Give the teller training as your nearest example. Answer slot: if you coached a supervisor or teller on a bad escalation, say what you did. If you did not, say so and say what the training covered. | Primary type VAL, JD for the coaching requirement (F6). Your material shows tellers, not supervisors, so the slot holds the difference. |
| B8 | "A branch supervisor sends you three complaints in a week about the same fee. What do you do?" | CASE | [generic] | Clarify first: is the fee policy or error, and what was the member told? Then decide what is yours to do now and what goes to the regional team. Then say how the branch hears back. | A live problem from the role. It asks about no past and presupposes nothing about you. |
| B9 | "Eight branches become five hubs in 2027. Where do complaints from a closing branch go, and who owns them?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — your message (summary of the brief) | Clarify routing before you structure it: which complaints move, which stay, and who owns the open ones. Use the brief's word, hubs. | The strategy question for this round. It tests whether you think at the company's altitude. |

**Reverse questions (round 2)**

- "What would make the first six months a success for you, as the person this role reports to?" Why it lands: it asks the manager for their own success criteria, which is a peer-level conversation.
- "Which complaints do you most want this role to take off your desk?" Why it lands: it shows you are thinking about what the manager needs, not only what the job pays.

## 5. Round 3: panel of two branch managers (60 minutes, incl. 20-minute case; values scored)

Names of the two panel members are not known, so persona weights blend across the panel. Assign per member once names are known (see the upgrade menu).

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four values, one by one | Highest. The recruiter says the panel is the values round and scores against four values. | Map a story to each value (C1 to C4), and say where the material carries no story. |
| Case / Strategist | The 20-minute escalation case, plus a strategy question | High. The case is scheduled and time-boxed. | Clarify, then structure, then say the next 24 hours out loud. |
| Peer Evaluator | "Where's the seam with branch management?", credit-sharing | Medium. Branch managers are the people you would work beside, so they price what you add to their load. | Reciprocity framing: what you bring to their branches, not only what you need. Propose seam principles rather than pretending to know the seam. |
| Pressure / Stress | Time-boxed "why you?", "how much of it was you?" | Medium. A panel can time-box, and the values scoring makes composure visible. | Pause, restate the question, hold through two follow-ups, concede specifically. |

**Question bank (round 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a complaint where the member's side decided what you did. Name your decision and what the member needed to hear. If none comes to mind, say so plainly, then give the nearest thing: the log you handled. | Members First, Always. Scaffold, because your sentence does not carry a member-side decision. |
| C2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" — your message | Story-mapped: the training is the beat the sentence states. Answer slot: if you changed how the script was taught after it did not land, say what and why. If you did not, say so and say how the training ran. | Plain Words. The sentence carries the training; the clarity is yours to show. |
| C3 | "Tell me about a time a branch's local situation changed what you did with a complaint." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Selection scaffold: pick a time a branch's local context changed a complaint's handling. If none comes to mind, say so plainly, then name the first number you would check before trusting a branch figure. | Neighbours, Not Numbers. The spreadsheet is the nearest thing to a number, and the scaffold asks for local context. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Pick one complaint you followed to closure. Beats: you handled it through the log. Honest branch: if the log only recorded complaints and you did not see them through, say so, then describe what the log showed. | Own the Fix. Your sentence says handled, not closed, so the honest branch matters. |
| C5 | "A member has complained three times about a fee refund. The branch says it's policy, and the member says they'll go to the ombudsman. Walk us through the next 24 hours." | CASE | [generic] | Clarify the facts: what the policy says, and what the member was told. Decide who owns it now. Say what you tell the member, in plain words. Say what you record, and when the branch manager steps in. Keep the opening structure to about two minutes, then use the rest for follow-ups. | The 20-minute case. A live problem, presupposing nothing about your past. |
| C6 | "Forty percent of member service moves to digital channels by 2028. A member who can't use the app calls us. Where does their complaint go?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message (summary of the brief) | Name the route the member has now, and what must not change for them. The digital shift changes the channel. It should not change who owns the complaint. | The differentiator question on strategy. It tests whether you see the member, not only the channel. |
| C7 | "How would you report complaint volumes and resolution times to this panel each month?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Bridge from the spreadsheet in the quote's own terms. Answer slot on resolution times (F5): if you have reported them, say how they were counted. If you have not, say so and say how you would start. | The reporting requirement, in the panel's own words. |
| C8 | "Our teams sit side by side. Where's the seam between branch management and member services, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns a complaint once it leaves a branch, rather than claiming to know the seam. For disagreement, use a real story if you have one. If you do not, say so, then say how you would handle it. | Peer Evaluator stem. Open prompt, theme from the panel's own role. |
| C9 | "How do you handle credit when a complaint fix spans two branches?" | JD | [generic] | Say what you would put on the record and who you would name. Give credit to the people who did the work, and say how you would make that visible to both branches. | Peer Evaluator stem. Reciprocity framing. |
| C10 | "Sixty seconds: why you for this role?" | JD | [generic] | Hold: give the 60-second arc from your quotes: six years in retail banking, the last three as a supervisor, and the log you handled. Concede specifically: "I've never worked in a contact centre, and I've never presented above regional level." Do not fold on the arc. | Pressure stem. Hold-then-concede, with the two gaps named before they are raised. |
| C11 | "You handled the branch's formal complaints log. Which outcomes were yours to decide, and which were the branch's?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Hold: "I handled the log." Then say which outcomes were yours to decide, and which were the branch's, in your own words. Concede specifically where the decision was not yours. | Pressure on attribution. The question asks about outcomes, so the answer stays within what "handled" carries. |

**Values cheat sheet (section 10 of the template)**

The panel is the values round, as the recruiter's email says, and the four values are the official names from the copy you sent. Each row maps a story from one of your quoted sentences, or gives a selection scaffold where none carries a story.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No member-side decision is in your material. C1 is a scaffold, and its honest branch is the log you handled. |
| Plain Words | If a member needs it explained twice, the wording was wrong | "trained new tellers on our escalation script" carries the training. C2 scaffolds the clarity, and its honest branch covers a script that was not changed. |
| Neighbours, Not Numbers | Every branch is part of its town | "I built the monthly complaints spreadsheet our regional manager uses" carries the number. C3 is a scaffold for local context, with its honest branch. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I handled the branch's formal complaints log" carries the log. C4 asks whether you saw complaints through, and its honest branch covers a log that only recorded them. |

**Reverse questions (round 3)**

- "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it is the peer reciprocity question. It turns the panel from assessors into people who might work with you.
- "Which of the eight branches moves into a hub first, and what do complaints look like there?" Why it lands: it shows you read the brief and are thinking about the closures, not the slogan.
- "Where do members leave for app-only banks, and do the complaints show why?" Why it lands: it names the competitive pressure from the brief and asks the branch managers for the evidence they see.

## 6. Prohibited claims: shared across rounds

The table in the fit snapshot section governs every round. Restated here so nothing in a round's bank is written against an unlisted claim:

- Do not claim end-to-end ownership, contact-centre work, regulated complaints, coaching supervisors, presenting above regional level, or Excel. Each has its honest form in the table above.

## 7. Sources and target accounting

Sources are the documents you provided. I ran no web searches, because each research target is already answered by pasted material.

- **Job description**: your message.
- **Values**: the copy you pasted on 26 November 2026 from ashgrovecu.org/about/values. I did not fetch or check the page.
- **Recruiter's email**: your message. It sets the three rounds, their lengths, who runs them, and that the panel scores against four values.
- **Strategy brief (July 2026)**: as summarised in your message. The brief itself was not pasted, so check the quoted wording against it.
- **Your background**: your message.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values copy fixes the four names and meanings in the values cheat sheet. |
| 2. `Ashgrove Credit Union interview process Member Experience Lead` | skipped | The recruiter's email names the three rounds, their lengths, and who runs each. Those fix the round structure and persona weights. |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief your message summarises is under six months old, and it covers the priorities the grounding brief and the CO questions use. |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent, and the upgrade menu says what a name would unlock. |
| 5. representative `Member Experience Lead` JD | skipped | The job description you sent fixes the fit snapshot and the JD-tagged questions. |

## 8. Upgrade menu

- **Names of the Head of Member Services and the two branch managers** → an interviewer read, persona weights for each panel member, and tailored reverse questions.
- **Headings only from the monthly complaints spreadsheet, with no member data** → F4 and F10 gain an inspectable artifact, which could lift their confidence from medium toward high, and F5 is answered from what the sheet actually shows.
- **Whether the formal complaints log followed a regulatory timescale or external referral** → F3 moves from a discovery slot to a grounded story.
- **Whether the log recorded how long complaints took to close** → F5 becomes a grounded answer, and C7 and B4 get their resolution-time beat.
- **Any contact-centre exposure at all, such as shadowing or a call-handling project** → F2 gets a grounded row, and B1 and A7 get a sourced answer.
- **Your own notice period, pay position and location, in your own words** → fills the round 1 logistics slots (A2 to A4).
- **The panel's criteria for the four values, if the recruiter has them** → the values cheat sheet becomes exact.
- **How many days you have before 5 December** → a prep triage schedule sized to that time.
- **tuesday-dossier.md** → verified evidence and a prohibited-claims list that would sharpen every bank.
