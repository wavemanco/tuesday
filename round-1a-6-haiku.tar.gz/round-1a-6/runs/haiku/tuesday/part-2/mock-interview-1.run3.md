I couldn't save the pack file: the write to the scratchpad was denied, and both web searches were refused too. The full pack is below instead. Research is limited to your notes, so company values and the current strategy are unverified.

# Northwind Data · Senior GTM Strategy Lead, Emerging Products: interview pack

**Candidate:** Priya · **Round:** one 60-minute peer conversation · **Interviewer:** Dan Kovac, Director of Sales Strategy (peer, same VP)

## 1. How to use, and the type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL** behavioral/values · **EXP** work-experience deep-dive · **JD** role requirement · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- Provenance: `[grounded]` traces to your message or research note · `[inferred]` is derived from a source · `[generic]` is a role-family pattern with no claim about Priya or Northwind.
- Evidence is quoted from your message, which summarises Priya's record and the JD. Neither is her CV or the full JD.

## 2. Prep triage

No prep time was given, so there is no schedule. Start with **C1** and its fit rows (F5, F6), then **B1** and **E2**, which test the same $400M figure. Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your message, which carries the coach's notes on Priya's record. The material has no gate terms (location, schedule, work authorisation, credential), so no gate rows are listed.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent work: a model used in negotiations, not a GTM plan for a product line. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you set the go-to-market plan for any product, say which and how you decided; if not, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | A product-surface proposal credited with an uplift, not a land/adopt/expand/renew funnel. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: how that credit was counted, and which part was yours. |
| F3 | "run independent analysis in SQL and Tableau" (your message) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | No gap, but a skill line with nothing inspected behind it, so expect a probe. Lead with one analysis you ran yourself, named in your words. |
| F4 | "partner-motion design experience required" (your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The model is partner-level, but the requirement is designing a motion, which the material does not show. Words: the quote above, at its own scope. Answer slot: if you designed any part of how partners were engaged, say which and how you decided; if the model was not a motion design, say what it did. |
| F5 | "strong cross-functional influence" (your message) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote already reaches cross-org work in other terms. Reword only the quote: "I set annual volume targets with cross-org consensus." No added practice. |
| F6 | Sales-motion work, quotas and sales ops: role-family pattern, not quoted from the JD | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [generic] | discovery | The coach's note says none, but Priya has not said so herself, so it is not a stated absence. Answer slot: if you have set targets or reviewed a sales plan, say which and how; if not, say so plainly and say how you would build the targets, staying with F5. |
| F7 | "AI experience a plus" (your message) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Daily use is adjacent to building with AI in a product or GTM setting, which the material does not show. Words: "I use AI tools daily." Answer slot: name one task you did with them and what you checked. |

**Confidence note.** Confidence is medium, not high, because these quotes come from your summary, not from Priya's own words or her CV.

## 4. Grounding brief (from your research note)

- **Priorities, as your note states them:** enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- **Competitive frame:** "bundling by a much larger platform vendor."
- **Freshness:** your note is undated and unchecked. Confirm it before relying on it in the room.

## 5. Reading the interviewer

- **Career pattern (from your profile):** pricing and monetization roles as the spine, plus one early-stage-startup chapter.
- **Self-described:** "relentlessly data-driven."
- **Implications:**
  1. Every number will be probed back to its inputs. Weight the Prober up.
  2. Pricing and unit economics are his native language, so tilt the case questions there.
  3. The startup chapter means builder stories land well. Expect "scrappiness" probes on big-company pace.
- **Mirror opportunities:** none offered. No shared professional jump is supported by a fit row.
- **Source:** public footprint only, as you described it. Not independently researched.

## 6. Persona table

Weights follow the peer prior (Peer Evaluator and Data-Driven Prober dominant), adjusted for his profile (Prober up) and for the sales-ops gap (Skeptic kept at 3).

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam questions, "what do you need from me," credit and disagreement | 5. Peer round; he is pricing what the hire adds to his own work | Propose seam principles, not claims about his team's process; reciprocity framing |
| Data-Driven Prober | "Walk me through how that was counted," denominators, assumptions | 4. Self-described data-driven; every figure will be probed | Know how each number was counted and say plainly when you don't; name the weakest assumption first |
| Skeptic | Gap probes on sales ops and quotas; partner-motion design | 3. The biggest fit gap is sales-motion work, the likeliest objection | Rehearse C1 until it is boring; hold on the adjacent evidence; never claim quota work |
| Case / Strategist | Live GTM problems on the priorities and the bundling threat | 3. Pricing-tilted case work is his native ground | Clarify, then structure; think aloud; challenge one premise per case |
| Pressure | "How much of that was actually you?" | 2. Lower weight for a peer round, but it tests the $400M claim | Hold the proposal through two follow-ups; concede attribution specifically |
| Conversational | Journey opener, casual AI question | 2. Casual questions on a JD plus-skill are still scored | 90-second arc; treat the AI question as scored |

## 7. Question banks

**Peer Evaluator (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between a new line's GTM and the land/adopt/expand/renew motions we already run?" | JD, CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Propose seam principles rather than claiming to know his seam: who owns the account at signature, and who sees a partner's pipeline. Name one principle, then ask where his team's line falls. | Peer stem. The premise rests on the JD line only. Relates to F1. |
| A2 | "How do you handle it when you and I disagree on a number?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-map on F5: the target-setting and the cross-org consensus, in your words. Keep "we" for the team and "I" for your part. Answer slot: if a number was challenged and changed, say what changed and why; if no one challenged it, say so and describe how consensus was reached. | Disagreement style with equals is scored. F5 is the only quote that carries cross-org work. |
| A3 | "When work spans teams, who gets the credit in your account of it?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say "I proposed," and give the credit as the figure is credited. Name anyone who carried the build. Answer slot: if the change needed teams you did not lead, say who and what they did. | Peer credit-sharing probe. Ties to B1 and the inflation risk. |
| A4 | "What would you need to believe for a partner-led motion to beat direct sales on a new line?" | CASE | [generic] | Structure: economics by channel, conflict with existing accounts, what would make a partner sell. Name the assumption you would test first. | Live reasoning on a pattern, not a fact about Northwind. |
| A5 | "Where's the line between your pricing calls and the ones my team makes?" | CO | [generic] | Name the boundary principle (who sets list price, who sets deal terms), then ask him where he draws it. | Pricing is his spine. Generic because no source describes Northwind's split. |

**Data-Driven Prober (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend the number: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before he does. Answer slot: if you know the attribution method, say it; if you do not, say plainly that you don't know how it was counted. | The likeliest probe for a data-driven peer. Same quote as E2, so the answers must match. F2. |
| B2 | "Which assumption behind the partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Weakest-assumption move: name one assumption in your own words. Answer slot: if others set the model's inputs, say so and name what you did own. | The model is the evidence for F1 and F4, and the most likely to be probed in depth. |
| B3 | "How were the volume targets built: inputs, denominators, who signed off?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Say which inputs you built and which came from others. Answer slot: if no denominator was yours, say so. | Prober's denominator stem. Quoted only to F5's scope. |
| B4 | "Show me the last analysis you ran in SQL and Tableau, end to end. Where would it break?" | EXP | [grounded] "skilled in SQL/Tableau" (coach's notes) | Describe one analysis you ran yourself, start to finish, and name its weakest input. Answer slot: if you did not run one end to end, say which parts you did run. | The JD asks for independent analysis, which is the raising source for the premise. F3. |

**Skeptic (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you set land and expand targets for these two lines?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Bridge on F5: start with the target-setting you did, in those words. Answer slot: if you set quotas or reviewed a sales plan, say which and how; if not, say so plainly, then describe how you would build the targets from the whitespace. | **Highest-ROI prep in this pack.** F6 is the gap he is most likely to test, and the JD's land/expand language points straight at it. Deepest rehearsal: hold through two follow-ups and never claim quota work. |
| C2 | "Where have you designed a partner motion, rather than used one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: if you designed any part of a partner motion, say which and how you decided; if the model was used to design one, not by you, say so. Give the model's scope in your words. | Premised on the JD line "partner-motion design experience required." The quote supplies only the model. F4. |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes) | Answer slot: if sales-ops or quota work is absent from your record, say so in your own words; then give a concrete ramp plan. | Persona stem. Rehearse it as Priya's words only once she has confirmed the gap herself. F6. |

**Case / Strategist (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Enterprise expansion is the priority, while a much larger platform bundles a competing product. Where do you bet for these two lines?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note, undated) | Take a position: the bet, the bundle's likely effect, and what you would check first. No claim about your past. | Built from the note's priority and threat. Its date is unchecked. |
| D2 | "The Compass copilot launch is this year's priority. How do you launch a new line alongside it without cannibalising it?" | CO | [grounded] "an AI copilot launch ('Compass')" (your research note) | Structure: clarify the launch's timing and audience, then the overlap, then metrics. Name one risk. | Uses only what the note names. No claim about Northwind's plans beyond it. |
| D3 | "Sketch the first 90 days. What do you need to know before you touch land, adopt, expand and renew for a new line?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | JD line; the case format a Case/Strategist scores. |

**Pressure (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I trust you on partner-motion design?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Hold: the model, at its own scope. Hold through two follow-ups. When you concede, concede the specific gap in your own words and say how you would close it. | Hold-then-concede. F4 is the position under challenge; never fold on the model itself. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: "I proposed the change." Concede uncertainty about attribution specifically, if it exists. Never fold the proposal itself. | Pressure stem on the same figure as B1. |

**Conversational (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A pre-scripted 90-second arc: consulting, then product strategy and ops, then the model and the change, each in those words. | Opener, but scored. The arc is built from the quoted record only. |
| K2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name one tool, one task you did with it, and one thing you checked. Answer slot: if your use has been personal rather than work, say so. | The JD plus-skill, asked casually. F7. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A1, D3 (F1, transferability) |
| identify whitespace across land/adopt/expand/renew | A1, C1, D3 |
| run independent analysis in SQL and Tableau | B4 (F3) |
| partner-motion design experience required | C2, E1, B2 (F4) |
| strong cross-functional influence | A2, A3, C1 (F5) |
| AI experience a plus | K2 (F7) |
| Not in the JD highlights: sales-ops and quota work | C1, C3 (F6) |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Owns GTM for a product line" | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material shows a model, not a GTM plan. |
| "Set quotas or ran sales ops" | Inflated form of F5 and F6 | F5's quote at its own scope. F6's slot asks what she actually did. |
| "Designed partner motions" | Inflated form of F4 | F4's quote. The slot stays inside the model. |
| "The $400M was hers" | Inflated form of F2 | "I proposed…" with the credit as the figure states it. The attribution question is B1. |

Priya has not stated any negatives herself, so no plain acknowledgments are scripted.

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent a chapter at an early-stage startup before your pricing work. What did that teach you about pricing?" | Ties to his own path. It turns an interview into a peer conversation and shows you researched him, not only the company. |
| R2 | "How do land, adopt, expand and renew get owned across your team and mine today?" | Surfaces the seam from A1 and uses the JD's own terms. |
| R3 | "Where does the bundling threat show up first in your deal data?" | Shows you read the research note and want his data view. |
| R4 | "How will the Compass launch change what sales strategy measures this year?" | Shows you know the priority and asks how it reaches his function. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. Rapport-style interviewers weight this slot heavily. |

## 10. Sources

- **Provided:** your message, with the JD highlights, the coach's notes on Priya's record, the interviewer profile, and the research note.
- **Research tier: L1, searches 2 of 6, fetches 0 of 2.** Both searches were refused by the host (permission not granted).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Refused. A values cheat sheet needs a detected values-style round. None is detected: one peer conversation, and no archetype fallback applies. Nothing is lost. |
| 2. Northwind interview process | skipped | Your message fixes the loop: one 60-minute conversation with a peer. |
| 3. Northwind strategy / recent news | unavailable | Refused. The grounding brief rests on your undated research note. |
| 4. Dan Kovac + Northwind | skipped | Your profile fixes the interviewer read. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot. Full JD text is missing (upgrade menu). |

Queries sent, both refused: "Northwind Data company values principles" (target 1); "Northwind Data enterprise expansion Compass AI copilot profitability" (target 3).

## 11. Upgrade menu

- **Full JD text** → requirements quoted in the JD's own words; mid-list requirements get rows and questions.
- **Priya's CV wording** → quotes move from your summary to "your CV," and confirmed lines can rise to high confidence.
- **Priya's own confirmation of the three quoted facts** (the partner model, the target-setting, the $400M uplift) → F1, F2 and F4 can rise, and B1 and A3 rest on her words.
- **Recruiter's focus areas or pre-read** → coverage of any graded deliverable.
- **Web search allowed by the host** → values page, strategy under six months old, and a recheck of Compass and the bundling threat.
- **Location, schedule or work-authorisation terms from the JD** → gate rows.

---

Say the word and I'll run a drill as Dan, starting with B1, the $400M count. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you want the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD and Priya's CV wording? The pack currently quotes your summary, and the quotes move to the documents once you do.
2. Did the recruiter flag focus areas or a pre-read for this conversation?
3. Are the three quoted facts (the partner model, the target-setting, the $400M uplift) in Priya's own account, as written?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.