Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-2/rooms/case-8-denied-7cecaac3/ashgrove_member-experience-lead_interview_pack.md`. I built it for all three rounds on 5 December, since the recruiter's email gives a separate format for each.

The pack has a fit snapshot against the JD, a prohibited-claims list, a prep schedule for the nine days you have, a values cheat sheet, and a bank of questions for each round with answer guidance. Each answer is built from your own sentences, and each gap is shown as a gap rather than papered over.

Three things to know before you open it:

- **Your two stated gaps are the core of the prep.** You have never worked in a contact centre and never presented above regional level. Both will come up, probably in the Head of Member Services round and again in the panel. The pack gives you plain, honest sentences for both. Practise saying them flatly, then move straight to what you would do about the gap.
- **The logistics questions are yours to answer.** Pay, notice, location and reason for leaving are not in your material, so the pack gives instructions rather than figures. Decide your own answers before the recruiter screen.
- **The strategy brief has not been checked for currency.** I tried one web search to confirm the brief and values were current, but permission to search was refused and I did not retry. The brief is from July 2026, so check Ashgrove's news page before you rely on it in the room.

I did not run any interviewer research because none of the interviewers is named yet. The upgrade menu lists what names would unlock.

Other options, if you want them:
- I can run a live drill: I play the Head of Member Services or a panel member, and then give feedback against each question's guidance. I'd suggest starting with the escalation case (C1) or the contact-centre question (C5).
- I can save a `tuesday-dossier.md` recording where your prep exposed gaps, for later sessions.
- I can convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 5 December 2026 (loop mode). Built 26 November 2026, nine days out.
Interviewers: the recruiter (30 min), the Head of Member Services, your future manager (45 min), and a panel of two branch managers (60 min, including a 20-minute complaint-escalation case). None of the interviewers is named yet, so there is no interviewer read.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer of 90 to 120 seconds. It is not a script.
- Provenance quotes are your own sentences. If a guidance line makes a claim about your past, it rests on a quote you can read in the same row. If it does not, the row says so.
- An **answer slot** is an instruction for the interview: it tells you the honest branch to take if the story is not yours. It is not a question to answer here.

## 2. Shared fit snapshot

The JD's requirements, quoted, against your own sentences. Gap types follow the taxonomy in the evidence conventions: `none`, `presentation`, `discovery`, `transferability`, `capability`, `hard_gate`. Nothing in the JD is a term-type gate (no location, schedule, pay or credential is stated), so no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words already reach it. Say the years and the branch: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer decide whether that counts as customer operations. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The material shows a formal log. It does not show what made the complaints regulated. Answer slot: if the log ran to a regulatory standard you can name, say which and how you applied it; if it did not, say so plainly and describe how the log ran. |
| F3 | "coach branch supervisors on escalations" — JD | "I trained new tellers on our escalation script." — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and the bridge should not stretch it. Say what you taught and what you did as a supervisor. Answer slot: if you coached anyone on escalations as a supervisor, say how; if not, say so plainly and describe how you would start with a supervisor. |
| F4 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would learn it, as a plan and never as a past. |
| F5 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | none | The quote reaches reporting. Say "spreadsheet", not "Excel", unless you name the tool yourself. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log. Bridge: "I handled the branch's formal complaints log." Keep the scope at one branch. |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The material shows a monthly spreadsheet, not whether it held volumes or resolution times. Answer slot: if it carried either, say which and how it was counted; if not, say so and say what you would add first. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have worked on a self-service journey, say which; if not, say so and say how you would start with the digital team. |
| F9 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then what you would learn first and from whom. |

**Pack observations (analysis, not words for you).** Your material says "the branch's formal complaints log", not a regulated process (F2), and "the monthly complaints spreadsheet", not its columns (F7). It is silent on digital work (F8). It is one branch, not many (F6).

## 3. Prohibited claims

Built from the fit snapshot. Each entry is a wording the pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints across branches and the contact centre | Inflated form of F6 | Quote F6 at its own scope: the branch's formal complaints log. The material shows one branch and no contact centre. |
| Contact-centre experience of any kind | Negative you stated, F9 | "I haven't worked in a contact centre." No slot. |
| Presented to senior leaders or executives | Negative you stated, F4 | "I haven't presented to anyone above regional level." No slot. |
| Complaints handled to a regulatory standard | Inflated form of F2 | The log at its own scope. Say what the material shows, not what the word "regulated" would add. |
| Built Excel reporting or Excel models | Inflated form of F5 | "I built the monthly complaints spreadsheet." The tool is not named in your material. |
| Reported on resolution times | Inflated form of F7 | Answer slot only, as in F7. |
| Coached branch supervisors | Inflated form of F3 | "I trained new tellers on our escalation script." |

## 4. Prep triage (nine days)

In order:

1. **Days 1 to 3:** say the two plain acknowledgments aloud until they sound flat and calm: "I haven't worked in a contact centre." and "I haven't presented to anyone above regional level." (F9, F4). Both will be asked.
2. **Days 1 to 3:** decide your own answers to the logistics questions A4 to A7: pay, notice, location and reason for leaving. Use only your own figures and reasons. Do not borrow numbers from anywhere.
3. **Days 3 to 6:** run the 20-minute case (C1) three times, timed. Then B1 and B4, using two named cases from the complaints log.
4. **Days 6 to 8:** the pressure hold (C5), and the reporting questions (B8, C6). Know exactly what the spreadsheet held.
5. **Everything else is insurance.**

## 5. Grounding brief

Source: the strategy brief Ashgrove published in July 2026, sent to you by the recruiter. Its vocabulary is "member service", "digital channels" and "hubs".

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

**Currency.** The brief is four months old. The one check sent to confirm it was refused (see Sources), so nothing newer has been verified. Before 5 December, check Ashgrove's own news page. Speak to the brief as "your strategy brief says", not as current fact.

## 6. Values cheat sheet (values round detected: the panel scores against four values)

Values as published, quoted from the copy you gave on 26 November 2026. Working meaning is paraphrase.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | "we decide from the member's side of the counter." Decide from the member's side. | F6: "I handled the branch's formal complaints log" — B1, C9. Selection scaffold: pick one log case where your decision came from the member's side. If none comes to mind, say so plainly, then give the nearest case from the log. |
| Plain Words | "if a member needs it explained twice, we wrote it wrong." Say it once, clearly. | F3: "I trained new tellers on our escalation script." — B2, C7. Selection scaffold: pick a time an explanation had to be repeated. If you rewrote the script in plainer words, say so; if not, say what you said the second time. |
| Neighbours, Not Numbers | "every branch is part of its town." A branch's decisions reach the people around it. | No sentence of yours carries a story here. Selection scaffold: pick a time a branch decision reached the people around it. If none comes to mind, say so plainly, then give the honest nearest: the complaints log you handled (B3, C8). |
| Own the Fix | "whoever finds the problem keeps hold of it until it is solved." | F6: "I handled the branch's formal complaints log" — B4, C9. Selection scaffold: pick one case you held until it was closed. If you did not hold one to the end, say so and say what you did with the one you handled. |

## 7. Loop structure and persona weights

Relationship priors from the personas model: recruiter screen is conversational with light skeptic; the Head of Member Services is behavioural, so values and skeptic; the branch-manager panel is peer and pressure, with a case.

| Round | Length | Who | Persona weights (depth) | Why |
|---|---|---|---|---|
| Recruiter | 30 min | Recruiter | Conversational 4, logistics 4 (no depth weight), skeptic light 1 | Logistics, motivation consistency, knockout checks. Scored, though casual. |
| Head of Member Services | 45 min | Future manager | Values/Behavioral 5, Skeptic 3, Pressure 1 | "Mostly behavioural" per the recruiter's email. Likely your manager's focus: F2, F3, F4, F7 |
| Panel of two branch managers | 60 min | Two branch managers | Case 3, Peer 3, Values 2, Pressure 1 (case: the 20-minute escalation case) | The panel scores against the values. Peer managers test the seam between branch and member services. |

## 8. Round 1: recruiter screen (30 minutes)

**Reverse questions for this round**

- R1: "What would success look like at six months for whoever takes this role?" Why it lands: it shows you think in outcomes, and the answer tells you what to prepare.
- R2: "How are the three rounds weighted against each other?" Why it lands: it tells you where to spend your remaining prep days.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it in your own words, in about 90 seconds: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training tellers on the escalation script. Then stop. No adjectives. | F1 and F2 carry the biography. Casual register, scored. |
| A2 | "Why this role, and why Ashgrove?" | JD | [generic] no sentence of yours states a reason for Ashgrove; slot only | Answer slot: say what you want from the role in your own words. A reason you have not said yet is yours to give. Do not borrow the member-owned line from the posting as if it were your reason. | Motivation is scored in every round. No claim about your past is made here. |
| A3 | "What do you make of members moving to apps and self-service?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief | Say what you have seen at the counter, in your own words. You may name the brief's 40% target as "your strategy brief says". Do not recite it. | Casual question on a hot topic; treat it as scored. CO, grounded in the brief. |
| A4 | "What are your pay expectations?" | JD | [generic] logistics slot; no claim about you | Logistics slot: give your own figure, or ask what the band for the role is before you give one. Use no figure you have not chosen. | Logistics the recruiter asks first. Nothing in this pack supplies a number. |
| A5 | "What's your notice period?" | JD | [generic] logistics slot; no claim about you | Logistics slot: give your actual notice period in your own words. | Knockout check. |
| A6 | "Where would you be based, and how often on site?" | JD | [generic] logistics slot; no claim about you | Logistics slot: say where you can work and how often, in your own words. Do not assume the hubs in the brief are where you would be based. | Office pattern is a requirement the recruiter will check. |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] logistics slot; no reason of yours is stated in the material | Logistics slot: give your reason in one sentence, in your own words, about the move you want. Keep it off the branch's problems. | Reason for leaving is logistics in a screen. Nothing here supplies a reason. |
| A8 | "Your background is in branches. Where would a contact-centre complaints role differ?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then one line on what you would learn first. | F9. Skeptic light; the acknowledgment is yours to give. |

## 9. Round 2: Head of Member Services (45 minutes, behavioural)

**Reverse questions for this round**

- R3: "How does the complaints team work with branch supervisors today, and where does it break down?" Why it lands: it asks about a real seam and lets you show you have thought about it.
- R4: "How will the move to digital be measured for member experience, not only for volume?" Why it lands: it ties the strategy to the job's own outcome.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick one case from the log: what the member asked, what you decided, and why it was from their side. If no such decision comes to mind, say so plainly, then give the nearest case from the log and what you did with it. | Members First, Always. An open prompt; the theme comes from the value. |
| B2 | "When did a member have to hear something explained twice?" | VAL | [grounded] "I trained new tellers on our escalation script." | Selection scaffold: pick a time an explanation had to be repeated. If you rewrote the script in plainer words, say so; if not, say so and say what you said the second time. | Plain Words. Honest branch: the explanation may not have been yours to change. |
| B3 | "Ashgrove plans to take eight branches into five hubs over 2027. What would you tell a town whose branch is closing?" | CASE | [generic] pattern for a branch change; no claim about your past | Structure it: who is affected; what they need to know first; what changes for them; what you would say first, in plain words. Make no claim about your past in the answer. | Neighbours, Not Numbers, put to the company's own plan. Live problem; presupposes nothing about you. |
| B4 | "Tell me about a complaint you stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick one log case you held to its close: what kept it open and how it closed. Answer slot: if it was not yours to close, say so plainly and say what you did with it. | Own the Fix. Tests whether you kept hold. Do not name a close you cannot describe. |
| B5 | "How would you coach a branch supervisor who escalates everything, or nothing?" | JD | [grounded] "I trained new tellers on our escalation script." | Answer slot: if you coached anyone on escalations as a supervisor, say how; if not, say so plainly and describe how you would start with a supervisor. | JD line "coach branch supervisors on escalations". F3's gap. |
| B6 | "You have worked in branches. What about a contact centre would be new to you?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then what you would learn first and from whom. | F9, asked as a skeptic's question. |
| B7 | "The role presents to senior leaders. How would you prepare for your first presentation above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. Never describe a past presentation. | F4. Pressure risk: hold the plan, concede the gap specifically. |
| B8 | "What would your first monthly report on complaint volumes and resolution times look like?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet already held volumes or resolution times, say which and how they were counted; if not, say so and describe what you would add first. | F7. JD line "report monthly on complaint volumes and resolution times". |
| B9 | "Ashgrove wants 40% of member service moved to digital channels by 2028. Where would you start with a self-service journey?" | JD | [generic] approach to self-service journeys; no claim about your past. Raising source: the JD line "work with digital teams on self-service journeys" and the brief's 40% target | Structure the answer: which member journey, what the digital team needs from you, what you would measure first. Answer slot: if you have worked on a self-service journey, say which; if not, say so and say how you would start with the digital team. | F8. Covers the JD's digital requirement; the strategy is the context. |

## 10. Round 3: panel of two branch managers (60 minutes, with a 20-minute case)

**Reverse questions for this round**

- R5: "What could someone new do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question to peers. It turns the panel into a working conversation.
- R6: "When a complaint is escalated from your branch, what do you need from the member-experience team that you are not getting?" Why it lands: it names the seam and invites the panel's own experience.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | (20-minute case) "A member at your counter is angry about a fee and says a call-back from the contact centre never came. The complaint has already been reviewed once. Walk us through the next 20 minutes." | CASE | [generic] a practice case; the real case will differ and may carry facts this one does not | Clarify first: what the fee was, what the call-back promise was, what the review decided, and what the complaint deadline is (say you would check it). Objective: resolve it from the member's side and close it with the owner named. Segment: the branch part and the contact-centre part. Approach, then metrics (time to first response; whether the member had to explain twice), then risks. Think aloud. Name the seam you are not sure of rather than guessing it. | Escalation case, the panel's stated format. Presupposes nothing about your past. |
| C2 | "Our teams sit side by side. Where's the seam between a branch and member services, and what happens when you disagree?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Name the seam in principle: who decides a complaint's outcome, and who explains it. If you disagreed with a colleague over a case, say what you did. If not, say so and give the nearest thing your material carries: the escalation script you taught tellers. | Peer seam, asked collegially. F6 and F3 carry it. |
| C3 | "How do you handle credit when a complaint fix needs three teams?" | JD | [generic] approach to shared credit; no claim about your past | Reciprocity framing: what you bring to their team, not only what you need. Propose seam principles rather than pretending to know the seam. Answer slot: if you have done this, say how; if not, say so and say what you would do. | Peer credit probe. The JD's "end to end across branches and the contact centre". |
| C4 | "What would you need from the contact centre to own a complaint end to end?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre, so I'd ask the team who runs it what the hand-off looks like, and who holds the case when it moves." | F9 and F6. The JD line "end to end across branches and the contact centre". |
| C5 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Pressure. Restate the question. Anchor in your six years and three as a supervisor. Hold through two follow-ups: the branch side is what you have done; the contact-centre side is what you would learn first. Concede specifically: "I haven't run a contact centre." Never fold on the branch record. | Pressure hold-then-concede. The most predictable objection, rehearsed. |
| C6 | "Which would you put first on a monthly complaints report, volumes or resolution times, and why?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Give your reasoning. Weakest-assumption move: name the assumption you would defend least about the figure you choose. Answer slot: if the spreadsheet already had either, say which and how it was counted; if not, say so. | F7. JD reporting requirement, asked as a judgement. |
| C7 | "A member says your letter is unclear. Show us how you would rewrite its first paragraph." | VAL | [grounded] "I trained new tellers on our escalation script." | Rewrite it live, in plain words, aloud. Answer slot: if you have rewritten a script or letter before, say so; if not, say so and rewrite it now. | Plain Words, scored on the rewrite rather than the past. |
| C8 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a time a member came before a branch target. If none comes to mind, say so plainly, then give the nearest case from the log you handled. | Neighbours, Not Numbers. Honest branch: the material does not carry this story. |
| C9 | "Tell us about a complaint you saw all the way through to resolution." | VAL | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you saw one through, say what kept it open and how it closed. If you did not hold one to the end, say so plainly and say what you did with the one you handled. | Own the Fix. Same log, different question. |

**Case note.** C1 is a generic practice case. It is not the real case, and the real case may give you facts this one does not. Ask for the case brief from the recruiter before 5 December if one is provided.

## 11. Values round: how each value shows up

See section 6 for the mapped stories. The values are rehearsed through B1, B2, B3 and B4 (Head of Member Services round) and C7, C8 and C9 (panel round).

## 12. Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | F1; A1, C5 |
| experience handling regulated complaints | F2; B1, B4, C2 |
| confident presenting to senior leaders | F4; B7, C5 |
| comfortable with Excel reporting | F5; B8, C6 |
| Own the member complaints process end to end across branches and the contact centre | F6, F9; C1, C3, C4 |
| report monthly on complaint volumes and resolution times | F7; B8, C6 |
| coach branch supervisors on escalations | F3; B5 |
| work with digital teams on self-service journeys | F8; B9 |

## 13. Sources

**Provided documents**

- The JD, from your message.
- Ashgrove's values, copied by you from ashgrovecu.org/about/values on 26 November 2026. Quoted as given.
- The recruiter's email: three rounds on 5 December, their durations, the panel format and the values scoring.
- Ashgrove's 2026 strategy brief, published July 2026, sent to you by the recruiter.
- Your background, from your message.

**Searches and fetches sent**

- Query: "Ashgrove Credit Union values member strategy 2026". Outcome: refused (permission to use web search was not granted). Not retried.

**Research tier: L1 — searches 1 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the cheat sheet (section 6). Their currency was not checked. |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the three rounds, their lengths and the panel format. |
| 3. `Ashgrove Credit Union strategy` / recent news | unavailable | The one check sent was refused. It would have tested the July 2026 brief for anything newer, and it bears on the CO bank (A3, B3, B9) and the grounding brief. |
| 4. Interviewer name | n/a | No names have been given or assigned, so there was no query to form. Section 1 names no interviewer. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## 14. Upgrade menu

- Interviewer names for each round → persona weights and reverse questions tied to each person's public career path (public footprint only).
- The complaints log's columns or the spreadsheet's headers, pasted as text → upgrades F7, B8 and C6 from answer slots to grounded answers, if they hold volumes or resolution times.
- The regulatory standard the log followed → upgrades F2 from `discovery` to a grounded answer.
- Whether you used Excel or another tool → allows the word "Excel" in B8 and C6 in your own mouth. Until then, say "spreadsheet".
- Your pay expectation, notice period, location and reason for leaving, in your own words → fills A4 to A7 with your own answers rather than instructions.
- The case brief, if the recruiter provides one for the panel → replaces the generic C1 with the real case.
- A check of Ashgrove's news page for anything after July 2026 → refreshes the grounding brief and the CO bank.
- A `tuesday-dossier.md`, if you have one → adds verified evidence behind F1 to F9.
