# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** not named. **Built on:** `tuesday-dossier.md`, decision `conditional_go` (dated 2026-08-14). Company research did not run; see Sources.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say what you did, in your own words, and let the interviewer draw the conclusion.

Type key: **EXP** work-experience deep-dive · **JD** role and job-description driven · **CASE** live problem · **CO** company knowledge (none in this pack, because company research was refused) · **VAL** values (none in this pack, because no values-style round was detected).

Sections dropped, not padded: prep triage (prep time not stated), graded deliverables (none declared), grounding brief (no strategy brief), reading the interviewer (no interviewer information), values cheat sheet (no values round detected), delivery coaching (no assessment provided).

Answer slots are instructions for the interview. They are not questions to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | low | [grounded] | transferability | Adjacent, not PM, and the limit comes first: this is integration delivery for clients. Words: "I haven't held a product manager title. What I have done is lead 30+ end-to-end client integrations, from scoping through go-live." Wider step is an answer slot inside the quote's scope: which parts of those integrations were yours to decide, in your own words. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | low | [inferred] | transferability | The dossier does not grade R2, so this grading is the pack's own. The quote reaches APIs, not a product you shipped. Answer slot: name any API or platform product you shipped yourself and your part in it; if there is none, say so plainly, then give the integration work at its own scope. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook … team uses" — dossier verified evidence | high | [grounded] | transferability | Inspectable and high, but the playbook reaches integration practice, not API documentation or schemas. Words: "I wrote the internal integration playbook, and my team uses it." Answer slot: if you wrote API docs or schemas yourself, name them; if the playbook is the closest, say so. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | medium | [inferred] | transferability | Confirmed, with limited inspectable proof: expect a probe. It reaches customers and product, not engineering or sales by name. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Answer slot: if you worked with engineering or sales in those sessions, name what each side needed; if you did not, say so. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier's clarify strategy applies. Nothing quoted reaches agile delivery. Answer slot: if you worked inside a sprint cadence, name the cadence and your part in it. If not, say so plainly: "I haven't worked inside an agile product cadence. I'd want to confirm how your squads define it." |
| F6 | "Owning a roadmap and prioritization authority" (dossier R1 sub-claim, must have) | none given | none | [grounded] | capability | Dossier acknowledge_gap area. Plain acknowledgment only, no bridge, no answer slot: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibilities) | none given | low | [inferred] | discovery | Silence in the material is discovery, not a verdict. The 30+ figure counts integrations, not adoption. Answer slot: if you measured adoption or a similar usage number, say what it counted; if not, say so and say what you would measure first. |

The gap type follows the evidence cell. Gap and bridge words are spoken aloud, so every clause about your past rests on a quoted sentence.

## Prohibited claims

Not to be coached, asserted, softened or implied in any answer. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set priorities for an engineering squad." No slot. |
| Shipped an API or platform product | Inflated form of F2's quote | The integration quote at its own scope. The limit is the pack's observation, not a first-person negative: your material shows integration work, not a product you shipped. |
| Set what product built from client evidence | Inflated form of F4's quote | The quote at its own scope: you fed client evidence to product. Your material does not show you decided what product built. |
| Wrote the API docs or schemas | Inflated form of F3's quote | The playbook quote at its own scope. Docs or schemas are an answer slot, never a claim. |
| "Seven years of integration leadership" | Dossier decision prose only; not in verified evidence | Not coached from this pack. Use whatever tenure your CV states. The number of years is not established by anything quoted here. |

## Persona table

Weights follow the hiring-manager relationship prior: Case/Strategist and Skeptic dominant. No interviewer signals exist. No loop source established the loop, so the fallback is the generic archetype, which is flat and says so. Values/Behavioral is not weighted: no values-style round was detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the R1 gap and the roadmap sub-claim; asks why you, why now | Highest. Hiring-manager prior, and the dossier names the PM-title objection as the single likeliest one | Concede plainly, name the limit, give a ramp plan; hold the integration quote | 5 |
| Case/Strategist | Live problems on roadmap sequencing and adoption | High. Hiring-manager prior, and the posting's responsibilities are operational | Clarify, then objective, segmentation, approach, metrics, risks; think aloud | 4 |
| Data-Driven Prober | Counts the 30+ figure; asks what adoption number you would defend least | Medium. The headline figure and the unstated adoption baseline draw it | Defend-the-number slots in your own words; name the weakest assumption | 3 |
| Peer Evaluator | Asks where the seam with the two squads is, and how disagreement is handled | Medium-low. The hiring manager may bring in squad-lead concerns | Propose seam principles, not a seam you were told about | 2 |
| Pressure | Time-boxed challenge on fit; attribution challenge on the 30+ figure | Medium-low. A 45-minute round can still test composure | Hold through two follow-ups, concede specifically | 2 |
| Conversational | Opens with "walk me through the journey" | Medium-low. Casual openers are still scored | Use a 90-second arc built only from quoted sentences | 2 |

Total: 18 questions.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; plain acknowledgment from dossier prohibited_claims and acknowledge_gap | Highest-ROI prep in this pack; the dossier named this objection. Concede in one sentence, no hedge: "You're right. I haven't held the product manager title or owned a roadmap." Then your strongest true thing: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." Name the limit: "That was delivery work with clients, on the integration side. I haven't set priorities for an engineering squad." Then the ramp, as a plan: "In the first ninety days I'd spend most of my time with the partners and both squad leads before I change anything on the roadmap." If pressed twice, hold the integration quote and the ramp; concede specifically that a PM with three years would start further ahead on the roadmap. Never claim a PM track record. | Named by the dossier as the single likeliest objection and the deepest rehearsal. It is an R1 must-have with a transferability gap (F1) and an acknowledged roadmap gap (F6). |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Name the gap before they do: owning the roadmap and setting priorities across the two squads (F6). Then the nearest true thing, at its own scope: "The closest I've come is scoping requirements with clients for integrations, which is different from deciding what gets built." Then the plan for learning how the squads prioritize. Do not name a day-one strength you cannot quote. | The second Skeptic framing of the same gap. The roadmap clause follows F6 and gets no bridge; the requirements clause follows F1. |
| A3 | "This job runs delivery through two engineering squads on an agile cadence. Which parts of that have you worked inside, and which only from the outside?" | JD | [grounded] none given; nothing quoted reaches agile delivery. Dossier R5 discovery, clarify | Answer slot: if you worked inside a sprint cadence, name the cadence and your part in it, in your own words. If you did not, say so plainly: "I haven't worked inside an agile product cadence. I'd want to confirm how your squads define it." Hold nothing you cannot quote. | R5 is preferred, with a clarify strategy. The question asks for a fact the material does not show, so both honest branches are allowed. |
| A4 | "Have you shipped an API or platform product yourself? Name the closest one and your part in it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Answer slot: if you shipped a product or platform feature, name it and the part that was yours. If you did not, say so plainly, then give the integration work at its own scope: "integration delivery for clients on the vendor's REST APIs." | R2 is a must-have, and the dossier did not grade it. The slot's second branch allows the premise to be false. |
| A5 | "Why move from integration delivery into a product role, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Answer slot: say what in the integration work pulled you toward product, in your own words. The sessions are the only product-facing sentence in your material. If the pull came from somewhere else, say that. Do not turn the sessions into a decision you made. | The Skeptic's motivation probe: why leave, why here, why now. Your answer must match what your quotes show. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's adoption of the platform has been flat for two quarters after go-live. Walk me through how you'd diagnose it before proposing anything." | CASE | [generic] role-family pattern; no entity claim | First clarify: what is adoption measured against, and what is the current baseline? The posting names no baseline. Then objective, segmentation (which partners, which integration types), approach, metrics, risks. Think aloud and state one assumption. Make no claim about past diagnoses. | The adoption baseline is an unknown the dossier flagged, so the first clarifying question is the probe's own gap. Generic because company research was refused. |
| B2 | "Two squads disagree about sequencing a partner-requested change. How do you decide, and who decides?" | CASE | [generic] role-family pattern | Ask first who makes this call today before proposing a process. Then propose principles: partner impact and effort, record the reasoning, escalate what stays split. Do not claim you have ever made this call for a squad. | Decision authority against the two squad leads is unresolved in the dossier. This question tests it directly. |
| B3 | "Partner requests outnumber what the platform team can staff this quarter. What goes on the roadmap first?" | JD | [generic] role-family pattern | Segment the requests: which partners would be lost without, which feed adoption, which are one-offs. Propose a rule, and say what would change your mind. Keep it hypothetical. | Roadmap ownership is a must-have responsibility. The question tests your prioritization approach without assuming authority you do not have. |
| B4 | "You've integrated the vendor's REST APIs for clients. What would you check first if a go-live stalled?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Answer slot: if a go-live stalled in your work, say what you found and which part was yours. If none did, say so plainly and describe how you would approach it, starting from the scoping and requirements work. The checks are yours to name; the pack does not supply them. | Turns the integration evidence into a live problem and tests R2 and R3 adjacency. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Defend-the-number slots, in your own words, with no method supplied. How was the count made? If it was a fixed count, say what it counted. What would change it? Which assumption would you defend least? Which of the scope items were yours? If you did not count it yourself, say so and say where the figure came from. | Headline figure on your material, so a prober's magnet. The "30+" stays attached to "integrations" and does not become users or revenue. |
| C2 | "Which adoption number would you defend least for a partner API, and what would you need to measure it?" | JD | [generic] role-family pattern | Name the weakest assumption before they do: the adoption definition, and the baseline you do not have yet. Then say what you would need from partners to measure it. | Pairs the JD's adoption responsibility with the unknown baseline. |
| C3 | "You ran roadmap-input sessions. How many client requests came through them, and how many reached product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Answer slot: if you counted requests, give the count and what happened to them. If you did not count, say so and say what you would count next time. Do not estimate a figure. | Medium confidence, and the dossier expects a probe here. The premise that requests were counted is a slot, not a fact. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; plain acknowledgment from dossier prohibited_claims | Hold-then-concede. Hold the integration depth and the ramp through two follow-ups. Concede specifically: "A PM with three years starts further ahead on the roadmap, and I haven't held the title." Do not fold on the integration claim to restore harmony. | A time-boxed challenge that tests composure. The hold is only what the quote carries. |
| D2 | "That integration number — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Answer slot: say which scope items were yours to decide and which were the team's, in your own words. If you did the work as part of a team, state the share you held, not the whole number. | Attribution pressure is where inflation is most tempting. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | A 90-second arc built only from these two sentences: integration delivery first, then the roadmap-input sessions, then why product. The "why product" part is an answer slot, as in A5. | Casual register is still scored. A pre-built arc stops you freezing on the biography question. |
| E2 | "What are you actually using day to day in API tooling and documentation?" | JD | [grounded] "Wrote the internal integration playbook … team uses" — dossier verified evidence | Answer slot: name the tools and docs you used in the integration work, in your own words. If you did not write API docs or schemas yourself, say so and name the playbook as the closest thing. | R3 is an important requirement with no other JD-tagged question. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The squad leads own their backlogs. Where's the seam with the platform API work, and what happens when you disagree?" | JD | [generic] role-family pattern | Propose seam principles, not a seam you were told about: who owns the partner-facing contract, who owns internal change. For disagreement, name a principle you can hold to, and an example only if you can quote one. Otherwise say how you would escalate. Reciprocity: what you bring the squads is partner evidence. | The collegial form of the decision-authority question. Stays generic because the squad structure is unknown. |
| F2 | "What would you need from engineering that you couldn't get yourselves?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Answer slot: say what engineering and sales would need to be in those sessions. If you did not work with them there, say so, then describe what you would ask them for. | R4 (stakeholder management across engineering, sales and customers) is an important requirement with thin coverage. |

Total in banks: 18 questions.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1, 3+ years PM experience (must have) | A1, A2, D1, B3 |
| R2, shipped API or platform products (must have) | A4, B4 |
| R3, technical fluency: API docs, schemas (important) | E2 |
| R4, stakeholder management across engineering, sales, customers (important) | F2, C3 |
| R5, agile delivery (preferred) | A3 |
| Responsibility: own the roadmap for the partner-facing API platform | A1, B2, B3 |
| Responsibility: run discovery with integration partners | B1 is diagnosis, not discovery interviews. No question rehearses partner discovery directly. Add one if the interviewer leans there. |
| Responsibility: write specs and drive delivery with two squads | A3, B2 |
| Responsibility: define and track adoption metrics | B1, C2 |
| Dossier unknown: decision authority versus squad leads | B2, F1, and reverse question 1 |
| Dossier unknown: adoption baseline | B1, C2, and reverse question 2 |
| Headline figure: 30+ integrations | C1, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority is asserted in the posting and not evidenced. You need the answer before you accept. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The posting names adoption as a responsibility but gives no baseline. A concrete answer shows how much of the job is definition work. |
| 3 | "When the two squad leads disagree on sequencing, who breaks the tie, and how often has that happened this year?" | Tests the decision-authority risk in concrete terms, and tells you how often the role would be pulled between two leads. |
| 4 | "What would a strong first ninety days look like for someone coming from integration delivery rather than product?" | Tests whether the ramp plan you are offering matches what they would want. |
| 5 | "What did the last person in this role get right, and what would they have done differently?" | Gives you the scope and the failure mode the role was built around. |

## Sources

**Provided documents:** `tuesday-dossier.md`, decision `conditional_go`, dated 2026-08-14. Consumed: `role_profile` (requirement lines and responsibilities, as the JD), `handoff_to_mock_interview` (verified evidence, weak-area strategies, likely objection, prohibited claims, risks, employer questions). `decision` was read as context only. The dossier has no `evidence_map`, `risk_register` or `evidence_state`, so the fit grades in F2, F4, F7 are this pack's own, labeled `[inferred]`. The dossier's JD is the posting as it stood in August.

**Searches sent:** three, all refused (search permission not granted in this session):
- "Quartzline values operating principles": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy recent news": refused

**Research tier:** L1, searches 3 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, section 10. Refused, and no values round is detected, so the cheat sheet is dropped. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure and persona weights. Refused, so the generic archetype applies, said plainly. Persona weights follow the hiring-manager prior. |
| 3. Quartzline strategy and recent news | unavailable | Grounding brief and CO questions. Refused, so the CASE questions stay `[generic]`. |
| 4. Interviewer name with Quartzline | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative JD for the title | skipped | The dossier's role_profile fixes the requirement lines and the JD-tagged questions. |

## Upgrade menu

- Search permission → the three refused L1 targets can run. A values page or a documented values round adds a values cheat sheet, and current strategy replaces the generic CASE bank with CO questions.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own path.
- Your current CV → separates presentation from none on F2 to F4, confirms or drops the "seven years" figure (which appears only in the dossier's decision prose), and shows whether you shipped any product.
- The current posting text → confirms the requirement lines the dossier quoted, which is worth checking because the dossier is dated 2026-08-14.
- Any pre-declared exercise, such as a presentation or take-home → a graded deliverable section.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Want it?
