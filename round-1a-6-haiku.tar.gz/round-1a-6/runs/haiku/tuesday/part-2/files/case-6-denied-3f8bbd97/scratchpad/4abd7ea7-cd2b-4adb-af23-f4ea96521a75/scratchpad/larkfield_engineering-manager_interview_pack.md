# Larkfield Systems, Engineering Manager: loop prep pack

**Candidate:** Yusuf
**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Changelog:** First pack. Loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | Length | With | Persona lead |
|---|---|---|---|
| 1. Hiring manager | 45 min, Tuesday | Director of Engineering (would-be boss) | Case/Strategist, Skeptic |
| 2. Panel | 60 min, Thursday of the following week | Two staff engineers, one product manager | Peer Evaluator and Prober (staff); Values and Conversational (PM) |
| 3. VP Engineering | 30 min, the following Monday | VP Engineering, per the recruiter: "values and leadership philosophy" | Values/Behavioral, Pressure |

## How to use this pack and type key

- **Personas** describe how a question arrives. **Types** describe what is scored.
- Types used: **VAL** behavioral/values, **EXP** experience deep-dive, **JD** role-driven, **CASE** live problem. **CO** (company strategy) is not used, because no company research ran (see Sources).
- Question IDs are round-then-persona: R1-A1 is round 1, persona A.
- **Answer slot:** an instruction for the interview, not a question to you. Where a row has one, the second branch is always "say so plainly", so an honest "that was not mine" is a complete answer.
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you did, in your own words.

## Fit snapshot (shared across all three rounds)

Requirements come from your role description, the only requirement text in hand. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text, your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Words: "I've been a team lead of six for three years." Answer slot: say how running two squads would differ from one team, and whether you have split work across two teams before. If you have not, say so and say how you would split it. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role text, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | Words: "I run our hiring loop for backend roles, about 40 interviews last year." That reaches hiring for backend roles. It does not reach device work or eleven engineers, and no sentence adds them. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Words: the sentence as written. It is adjacent to delivery: a reliability result on one team of six, not delivery across eleven. Answer slot: how the 60% was counted, what else changed in the same period, and which part was yours to decide. If you did not count it that way, say so plainly. |
| F4 | "own delivery, hiring and growth for 11 engineers" — role text | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: name one engineer whose scope you helped grow and how you would know it. If none did, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — role text | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap look smaller. |
| F6 | "partner with hardware and product on roadmap" — role text | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Words: "On my current team I pushed a reliability quarter through against roadmap pressure." This is a software roadmap, not a hardware one, and the pack never presents it as one. Answer slot: which roadmap items the pressure was against, and whether any were delayed. Name them if so; if none were, say so. |
| F7 | Leading through other managers: [inferred] from the VP round's likely scope, not in the role text | "I've never managed managers" — your message | none | [grounded] | capability | Words: "I haven't managed managers." Then how you would learn it, said as a plan. |
| F8 | Location and in-office pattern: not in the role text, a gate the material does not settle | none given; your material does not establish it | none | [generic] | hard_gate | Surfaced, not bridged. Asked once, in the message that presents this pack. No workaround is offered. |
| F9 | Right to work for the role's location: not in the role text, a gate the material does not settle | none given; your material does not establish it | none | [generic] | hard_gate | Surfaced, not bridged. Asked once, in the message that presents this pack. No workaround is offered. |

**Where the picture is thin:** the role asks for growth, hardware partnership and managing through other managers. Your material is silent on the first, states an absence on the second and third, and carries one defensible result (F3) that is one team's, not eleven people's. Round 1's hardware objection is the most likely to be asked, so it gets the deepest rehearsal below.

## Prohibited claims

Built locally from the fit snapshot, because no dossier is present. These are the claims a candidate reaches for under pressure. Nothing in the banks, the bridges or the reverse questions may assert them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Sourced negative: "I've never managed managers" (F7) | "I haven't managed managers." Then the plan. No answer slot. |
| Has owned a hardware-adjacent roadmap | Sourced negative: "never owned a hardware-adjacent roadmap" (F5) | "I haven't owned a hardware-adjacent roadmap." Then the plan. |
| Leads two squads | Inflated form of F1: the sentence says "3 as a team lead of 6" | "I've been a team lead of six for three years." The limit is the pack's observation: your material shows one team. |
| Ran hiring at scale, or owns the hiring process | Inflated form of F2: the sentence says "I run our hiring loop for backend roles — about 40 interviews last year." | The quote at its own scope. No count of hires, offers or hiring design. |
| The reliability quarter alone cut the 60%, or you designed the reliability programme | Inflated form of F3: the sentence says the burden "dropped 60% after I pushed a reliability quarter through" | The quote as written. The defend-the-number answer slot for F3 covers the rest. |

## Round 1: Hiring manager (Tuesday, 45 min)

**Persona weights:** Case/Strategist 3, Skeptic 3, Data-Driven Prober 2, Pressure 2. Reasoning: a hiring manager is buying capability and derisking gaps, and expects live problems on the actual roadmap, so Case and Skeptic lead. Prober and Pressure are touched because a 45-minute slot is often time-boxed, and the one figure on the CV gets probed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem about the two squads and the hardware partnership | High: the role is the roadmap, so the director will test a plan on it | Clarify, then objective, then approach, then risks. Think aloud. |
| Skeptic | Quiet, persistent probing of F4 and F5 | High: this is the fit gap the director will name first | Hold, then concede exactly. Bridges come from quotes only. |
| Data-Driven Prober | Asks how the 60% was counted | Medium: one figure on your record | Defend the number. Name the weakest assumption before they do. |
| Pressure | Time-boxed challenge on the hardware gap | Medium: 45 minutes invites it | Pause, restate, anchor in what you stated. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Two squads are building device management, and the hardware team's release date and product's date do not match. Where do you start?" | CASE | [generic]: role text names hardware and product as partners | Clarify first: who owns the release date, and what the hardware constraint is. State the objective, then the split between the two squads, then the risks. Think aloud. Do not assume you know hardware's constraints; name the questions you would ask the hardware leads. | A live problem from the role's partnership line. It asks about no past, so the guidance makes no claim about you. |
| R1-A2 | "One squad's on-call load is rising, and product wants a feature next quarter. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Clarify the load and the feature's commitment first. Name the trade you would take to product, in your own words. You may use your experience only as the quote states it. Answer slot: if you have made this trade before, say how; if not, say so and say what you would bring to product. | A live problem with a direct link to F3 and F6. The quote is the only past claim allowed. |
| R1-A3 | "How would you split a team of six's work across two squads in your first 90 days?" | JD | [grounded] "Lead two squads building device-management services" — role text; "3 as a team lead of 6" — your message | Name what you would check first: the scope of each squad's services, and who depends on whom. Say how you would decide what moves. Answer slot: if you have set work across two teams before, say how; if not, say so and give the plan. | F1 is the scope gap. The question tests the step from one team to two without claiming it. |
| R1-B1 | "You haven't owned a hardware-adjacent roadmap. What do you do first when hardware and product disagree about a release?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message; "pushed a reliability quarter through against roadmap pressure" — your message | Hold the plan: ask each side for the constraint it cannot move, and write the trade down before deciding. Concede plainly: "I haven't owned a hardware-adjacent roadmap, so I would rely on the hardware leads for the constraints." The one position you can hold is the quarter you pushed through. | The premise is your own stated negative (F5). The hold is F6. Hold-then-concede is the pressure structure. |
| R1-B2 | **Highest-ROI prep.** "You haven't owned a hardware-adjacent roadmap. Why would I give you two squads that depend on one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message; "pushed a reliability quarter through against roadmap pressure" — your message | Hold through two follow-ups by returning to the quarter you pushed through against roadmap pressure and what the on-call number says. Concede the gap exactly: no hardware roadmap owned, and say how you would learn the hardware constraints in the first month. Answer slot: if you have worked on hardware timelines in any role, say what and how; if not, say so plainly and give the first-month plan. | F5 is this objection's source, so it will arrive in some form. F6 is the one defensible position the hold rests on. Never add a hardware claim under pressure. |
| R1-B3 | "You run the hiring loop for backend roles. Why would device-management engineers be hired to the same bar?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Say what bar you run, then where it may differ. You may say you would calibrate the device-side bar with the hardware-adjacent engineers before assuming it transfers. Do not claim device interviews you have not run. | F2 is the hiring evidence. The question asks whether the bar transfers, which F2 does not show. |
| R1-C1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend the number: say what was counted, over which period, against what baseline, and what else changed in the same period, in your own words. Name the assumption you would defend least before they do. Answer slot: if you counted it, say how; if you did not, say so plainly and say what you can and cannot separate. | F3 is a figure, and these are the slots a figure raises. Nothing in the material gives the counting method, so the guidance supplies none. |
| R1-C2 | "How did you know the loop's bar was right?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Say what you checked and what you did not check. Answer slot: if you checked the loop's results against anything, say what; if you did not, say so plainly. | F2 is a loop, not a measured outcome. The honest answer may be that it was not checked. |
| R1-D1 | "Sixty seconds: why you over someone who has owned a hardware roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message | Pause, restate the question, then anchor in the stated absence. Hold the one thing you can defend: "pushed a reliability quarter through against roadmap pressure." Do not compare yourself to someone you have not met. | A pressure stem. The pause and restatement are the composure drill. |
| R1-D2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold what was yours: the part you pushed through. Concede what you cannot separate from the other causes, and anything you did not measure. Do not fold the core claim. | A pressure version of the attribution probe on F3. The concession is the honest part. |

**Reverse questions (round 1)**

1. "What would a strong first 90 days look like for the two squads?" Why it lands: you hear the director's bar and the roadmap in one answer.
2. "Where do the device-management squads depend most on the hardware team today?" Why it lands: it shows you are thinking about the partnership in F5, not avoiding it.
3. "What decision in the last quarter did the group wish it had made earlier?" Why it lands: it opens the director's own account of delivery.
4. "What would make you call this hire a success at six months?" Why it lands: the bar, in their words.
5. "Which part of the hiring loop would you change first?" Why it lands: it tests your loop against theirs.

## Round 2: Panel (Thursday, 60 min)

**Persona weights:** Peer Evaluator 3, Data-Driven Prober 3, Values/Behavioral 2, Conversational 2. Reasoning: the two staff engineers are peers, so the blend takes their top two (Peer, Prober). The product manager is cross-functional, so the blend takes their top two (Values, Conversational). No names are given, so personas are blended, not assigned per member.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (staff) | Seams between your squads and theirs; credit; disagreement | High: the seam is where the hire costs them or helps them | Propose seam principles, not a known seam. Disagreement stories that show spine and tact. |
| Data-Driven Prober (staff) | Numbers, denominators, the on-call figure | Medium to high: one CV figure is a magnet | Defend the number. Name the weakest assumption. |
| Values/Behavioral (PM) | Stories about pushing roadmap items | Medium: product asks cross-functional scenarios | Open prompts, mapped to a quote where one carries the story. |
| Conversational (PM) | Casual questions on the journey and the roadmap | Medium: casual register is still scored | A 90-second arc. Treat casual questions as scored. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Our teams sit side by side. Where is the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] stem; the seam is raised by the role's partnership line | Propose the principles you would hold: who owns a service's interface, how a disagreement escalates, how it closes. Do not pretend to know their seam. Answer slot: if you have seen a seam like this and how it played out, say; if not, say so and give the principle. | A peer stem. The answer is a principle, which the material cannot contradict. |
| R2-A2 | "How do you handle credit when delivery spans teams?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Use "we" for the context and "I" for what you pushed through. Answer slot: if you have given another team the credit for a result, name the moment; if not, say so and give the rule you use. | A peer's credit probe. The quote is the only contribution claim allowed. |
| R2-A3 | "When your priority and mine conflict, who moves?" | CASE | [generic] | Describe how you would decide and what would change your mind. Answer slot: if you have moved a priority across a team boundary, say how; if not, say so and give the decision rule. | The collegial version of the roadmap conflict. |
| R2-B1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name the weakest assumption in your own words before they do. The material does not say which assumption it is, so the pack does not name one. Answer slot: if you tracked the figure, say what it was sensitive to; if you did not, say so. | The weakest-assumption move, on the one figure on your record. |
| R2-B2 | "What roadmap pressure did the reliability quarter push against, and which items moved?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Name the pressure you pushed against and the items you can name. Answer slot: if any roadmap item was delayed, say which; if none was, say so plainly. | The delay is an event the material does not carry, so it is a slot, not a claim. |
| R2-B3 | "Your loop covers backend roles. What would you change to interview device-side engineers?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Give a plan for the loop change, not a record of having made it. Do not claim device-side interviews you have not run. | F2 gives the only past claim. The question asks for a plan. |
| R2-C1 | "Tell me about a time you pushed a roadmap item back." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Open prompt. The story you can map is the quarter: the beats the sentence states are the roadmap pressure and the quarter pushed through. Answer slot: product's reaction, if you can name it, in your words; if you do not recall it, say so. | An open prompt mapped to F6. The reaction is a slot because the role names product partnership. |
| R2-C2 | "When have you said no to a senior stakeholder?" | VAL | [generic] | Open prompt, selection scaffold: pick a time you held a position against senior pressure, with a named stake and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing: the reliability quarter, and what it did. | An open prompt on a generic theme. The honest branch is built in. |
| R2-D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I run our hiring loop for backend roles — about 40 interviews last year." — your message | A 90-second arc built only from those sentences, in order: nine years in engineering, three as a team lead of six, now at a payments company, running the backend hiring loop. Add nothing between them. | The conversational opener is scored. The arc is the quoted sentences, not a story around them. |
| R2-D2 | "What do you know about device management today?" | JD | [generic] | Say what you have read, what you have run and what you have not. Answer slot: if you have used device-management tools or services, say which; if not, say so and say what you would read first. | A casual question on a role topic. The honest branch is "not used". |

**Reverse questions (round 2)**

1. "Where do the two squads and your platform disagree most often?" Why it lands: it maps the seam from R2-A1 on their side.
2. "What would a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, which a peer panel expects.
3. "How do you decide when a reliability fix goes ahead of a feature?" Why it lands: it connects to F6 and shows you have a view on the trade.
4. "What does the product side need from engineering leads that it is not getting now?" Why it lands: it tests the product manager's own pressure.
5. "What would you want the next manager to keep doing from the last one?" Why it lands: it opens the team's own account of what works.

## Round 3: VP Engineering (Monday, 30 min)

**Persona weights:** Values/Behavioral 4, Pressure 3, Case/Strategist 2. Reasoning: the recruiter's own words name a values and leadership round, so Values leads. Skip-level rounds bring Pressure and strategy-heavy cases, so both are touched.

**Values cheat sheet: dropped.** Larkfield's published values were not in hand, and the research searches were refused (see Sources). The section needs them, so no values cheat sheet is given. The VAL questions below are generic, with selection scaffolds where your material does not carry a story.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership-philosophy scenarios; STAR-shaped stories | High: the recruiter's words name it | Map a quote where one carries a story. Use a selection scaffold with its honest branch where none does. |
| Pressure | Time-boxed challenges to composure, in a 30-minute round | Medium: a skip-level round prior | Hold, then concede exactly. |
| Case/Strategist | A live question about leadership and the roadmap at altitude | Medium: the strategy-heavy skip-level prior | Clarify, then name the one premise you are working from. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Selection scaffold: pick a time you said something leadership did not want to hear. The nearest thing your material carries is the quarter you pushed through against roadmap pressure, whose beats are the pressure and the quarter. Answer slot: if leadership reacted in a way you can name, say it in your words; if you do not recall, say so. Do not supply an ending. | Mapped only where the quote carries the beats. The hard-truth ending is a slot, not an outcome the pack provides. |
| R3-A2 | "What leadership principle would you not trade away, and what has it cost you?" | VAL | [generic] | Name one principle in your own words and one instance of it. Name the honest cost. If no instance comes to mind, say so and give the nearest one you have. | An open prompt with no past claim in the guidance. |
| R3-A3 | "When have you grown an engineer into more scope?" | VAL | [grounded] "none given" in F4; the theme is raised by the role's "growth for 11 engineers" | Selection scaffold: pick a time an engineer took on more scope because of you. If none, say so plainly, then say how you would start. The bridge is a plan, never a past. | F4 is discovery: the material is silent, so the guidance is a scaffold ending in its honest branch. |
| R3-A4 | "How do you decide what to say no to as a leader?" | VAL | [generic] | Name the rule you would use and the cost you would accept. Answer slot: if you have had to say no to a roadmap item, say which; if not, say so. | Ties the leadership philosophy to the roadmap partnership. |
| R3-B1 | "You haven't managed managers. What would you need to learn first?" | JD | [grounded] "I've never managed managers" — your message | Hold the plain statement: "I haven't managed managers." Then the first thing you would learn, as a plan. Through two follow-ups, do not claim the experience. Concede the gap exactly. | F7 is sourced by your stated negative, so the plain acknowledgment is allowed. |
| R3-B2 | "How much of that on-call result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold what was yours: you pushed the quarter through. Concede what you cannot separate from the other causes. | The pressure version of the attribution probe on F3. |
| R3-B3 | "Sixty seconds: why this role?" | JD | [grounded] "Lead two squads building device-management services" — role text | Pause, restate, anchor in the two squads. Your material gives no reason for leaving, so do not supply one here. | A composure stem. Reason for leaving is a logistics item for a recruiter screen, not this round. |
| R3-C1 | "Your two squads' services carry a growing on-call load. What would you change in the first quarter?" | CASE | [generic] | Clarify the load and the commitments first. Name the trade between reliability and the roadmap, and how you would decide it. Use your own result only as the quote states it. | A live problem with no past claim beyond F3's quote. |
| R3-C2 | "Where does leadership philosophy meet the roadmap when a hardware date and a reliability fix collide?" | CASE | [generic] | Clarify where the date came from and what the fix risks. State the principle you would use, then name who decides. Answer slot: if you have been in a collision like this, say how; if not, say so. | Altitude. No company strategy is used, because no research ran. |

**Reverse questions (round 3)**

1. "What does leadership philosophy look like here when a hardware date and a reliability fix collide?" Why it lands: the VP states the principle, and you answer against it.
2. "What should a new engineering manager change in their first 90 days?" Why it lands: the VP's own bar.
3. "What has made an EM succeed or struggle with this group?" Why it lands: a skip-level view of the team.
4. "How do you hold engineering managers accountable for growth?" Why it lands: it connects to F4.
5. "What would you want protected that the roadmap tends to erode?" Why it lands: values, in their words.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads building device-management services | R1-A1, R1-A3, R2-A3, R3-B3, R3-C1 |
| Own delivery for 11 engineers | R1-C1, R2-B2, R3-B2 |
| Own hiring for 11 engineers | R1-B3, R1-C2, R2-B3 |
| Own growth for 11 engineers | R3-A3 (F4 is discovery; the material is silent) |
| Partner with hardware on the roadmap | R1-A1, R1-B1, R1-B2, R1-D1, R3-C2 |
| Partner with product on the roadmap | R1-A2, R2-A2, R2-C1 |
| Leading through other managers [inferred] | R3-B1 |
| Location, in-office pattern, right to work (gates) | None in the banks, and why: gates are asked once, in the message that presents this pack, not rehearsed |

## Sources

**Provided documents:** your message. It holds the role description, the three round descriptions, the recruiter's phrase "values and leadership philosophy", and your background sentences quoted above.

**Research tier:** Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both searches were refused by the host's search permission.

| Query sent | Result |
|---|---|
| Larkfield Systems values industrial IoT | Refused |
| Larkfield Systems engineering manager interview process | Refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The values cheat sheet, section 10: dropped. The search was refused, so no values page was read. |
| 2. Larkfield Systems interview process, engineering management | unavailable | Loop structure. The round shapes here rest on your message and the recruiter's words, not on a Larkfield loop source. |
| 3. Larkfield Systems strategy or recent news | unavailable | Not sent, after the first two calls were refused. It would have fed CO questions, so no CO questions appear. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative engineering manager JD | skipped | Your role description fixes the fit snapshot's requirements, so no representative posting was needed. |

## Upgrade menu

- **The full posting text** → F1 to F4 gain a fuller requirement source than your role description. The managers row can be checked against the posting's own words.
- **The Director's, the staff engineers' and the product manager's names** → per-member persona weights and one reverse question per round tied to their paths. Round 1 is the most affected.
- **The recruiter's note on the process** → confirms the round structure, and if it names the sessions, it establishes the loop, so the archetype fallback is not needed.
- **Larkfield's published values page, pasted** → a values cheat sheet for round 3, and R3-A1 to R3-A4 become mapped rather than generic.
- **Larkfield's strategy brief or recent news, pasted** → CO and CASE questions grounded in current strategy, for rounds 1 and 3.
- **The on-call incident data behind the 60%** (a pager export or a ticket count) → F3 moves from medium to high confidence, because an inspectable artifact stands behind the figure.
- **Any named engineer whose scope you helped grow** → F4 moves from discovery to a quoted row, and R3-A3 becomes mapped.
- **Confirmation of the location and right-to-work gates** (asked in the message) → F8 and F9 close or stay surfaced.
- **Deeper research, if the search permission is granted:** up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer footprints and role-family loop reports. Offered once; it runs only on your say-so.
