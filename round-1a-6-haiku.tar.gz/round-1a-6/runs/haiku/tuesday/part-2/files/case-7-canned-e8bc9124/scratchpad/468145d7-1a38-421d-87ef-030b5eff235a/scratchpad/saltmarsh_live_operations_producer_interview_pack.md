# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations (hiring manager)
**Round:** One 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation (saltmarshgames.com/careers/interviewing)
**Candidate:** Femi (they/them)

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the role's requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Every claim about your past is one of your own sentences, quoted in the Provenance column.
- Question IDs (A1, B2, ...) are used across the pack.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop and live planning problems on Saltmarsh's actual titles and calendar | Top weight (5). The careers page names a live-incident tabletop as the core of this round, and hiring managers buy capability on their own roadmap | Clarify, then structure, then act. Say the first question you would ask before proposing anything |
| Skeptic | "Which part of this JD would you be weakest at?" and gap probes | Weight 4. A hiring manager with a fresh gap to fill (two titles, post-event KPIs, no team lead) will press exactly there | Rehearse the top objection (B2) until it is plain. Concede the gap in one sentence, then give the ramp plan |
| Values / Behavioral | A values conversation, documented in the careers page's loop description | Weight 3. The round includes a values conversation, so this persona is guaranteed in the loop | STAR-shaped stories. Map a story only where your own sentence carries one; otherwise say so |
| Pressure | Time-boxed challenges to your past numbers and your reasons for applying | Weight 2. Not stated for this loop; included because a hiring manager may test composure on your retention figure | Pause, restate, hold one position through two follow-ups, then concede exactly what you do not know |
| Prober | Asks how a number or a checklist step was counted or used | Weight 2. Your two strongest artefacts (the checklist and the retention figures) will be read closely | Say what you can and cannot say about how each was counted |
| Conversational | Friendly openers that are scored | Weight 2. Short, low-stakes, and the place a JD plus-skill comes up casually | Keep the biography to 90 seconds. Treat any casual question about live ops as scored |

Weights come from the loop source (the careers page), not from an interviewer profile alone. Source: saltmarshgames.com/careers/interviewing, read through search.

## Fit snapshot

Your sentences are quoted from your message. "Your message" is the only source for what you have done.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not live events across two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned a calendar across more than one title, say how; if not, say so and say what you would carry over |
| F2 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is not owning the review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined the KPIs or ran a review after an event, say which, in your words; if not, say so and say how you would set it up |
| F3 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Do not say you managed the release process. The checklist itself is an inspectable artefact if you can show it |
| F4 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Four years is a length-of-experience bar, not a gate. Whether your title ran as live-service in the posting's sense is not in your material. Answer slot: say what your title's live cadence was, in your words |
| F5 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote already reaches the requirement. Expect a probe on how the calendar was run |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Your material shows you presented retention numbers, not how they were built. Answer slot: if you chose or defined the metric, say so; if you only presented numbers others produced, say that |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written artefact used by another team. The answers in the room will also be scored on clarity |
| F8 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material says nothing about coordinating four disciplines. Answer slot: if you coordinated across design, art, engineering or community on a release, say which and how; if not, say so |
| F9 | "Never led a team, and never worked on a game with in-app purchases." — your message (not a JD requirement) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Stated absence. Words: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Never dress either up |

Your material reaches four of the eight JD requirements directly: F1 and F5 partly, F4 and F7 by years and artefact. F8 is the gap the JD leaves most open.

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the live-events calendar for two titles" | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says one title, not two |
| "I owned the post-event review and KPIs" | Inflated form of F2 | "I presented the monthly retention numbers to the studio head." |
| "I managed the release process with QA" | Inflated form of F3 | "I wrote the release checklist our QA team still uses." |
| Any claim to have led people or coordinated four disciplines | Negative you stated (F9) | "I haven't led a team." |
| Any claim to in-app purchase experience | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and a reward-granting bug has gone out for twenty minutes. Walk me through your first ten minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" — Saltmarsh careers page | Clarify: what is broken, who is affected, what the rollback path is, who decides. Then name the first two people you would bring in. No claim about your past; the scenario is an invented example | This is the round's documented format, so it is the most likely opener |
| A2 | "Two of your titles have events landing in the same week. How would you sequence them?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD | Clarify the goal and the dependencies first, then the sequencing principle, then what you would need from design, art, engineering and community. Your calendar experience can be cited only as "I ran the weekly content-drop calendar for our main title" | Covers the JD's calendar requirement (F1) as a live problem, so it presumes no past event |
| A3 | "Project Larkspur puts both titles on one shared events calendar from February. What would you protect and what would you let go?" | CO | [grounded] "one shared events calendar from February 2027" — Saltmarsh news page (Larkspur) | Name one thing to protect and one to let go, each with a reason. Say what the shared calendar does to per-title events. No claim about your past | Company strategy from the news page. It shows you read recent news and tests altitude |
| A4 | "After a live event, what goes into the post-event review, and which KPIs does it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" — JD | Structure: planned vs. actual, retention cut by cohort, one change to make, owner and date. Do not say you ran this before unless your own words say so; if you did not, say how you would set it up | F2 is the gap here, and this asks for the method rather than a past event |
| A5 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slot. Say what the cohort or window was if you know it. Answer slot: if you chose the definition, say so; if you did not, say where the numbers came from and which assumption you would defend least | F6 and the retention requirement; this is the most likely probe on your strongest figure |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "own the post-event review and the KPIs it reports" — JD | Name one part you have not run, and say why. Then give a 30-day ramp: what you would read, who you would meet, what you would deliver. Keep it to one part | Open prompt. Its answer shows calibrated candor, which the Skeptic is scoring |
| B2 | "You have never led a team. How would you coordinate design, art, engineering and community on each update without direct authority over them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | **Highest-ROI prep.** Hold: "I haven't led a team." Then the mechanism: a shared calendar, one owner per update, a dated checklist. Answer slot: if you have coordinated across those disciplines on a release, say which and how; if not, say so and say what you would do first. Hold through two follow-ups, concede exactly the gap, and never claim a team you did not lead | The gap is the biggest objection to this candidate; F8 and F9 make it predictable |
| B3 | "A season pass changes what a live calendar is measured on. How would you adjust the KPIs?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news page (Larkspur) | Name what changes: pacing, retention by season, what a season-pass player is worth. If you have not worked on an in-app purchase model, say so plainly: "I haven't worked on a game with in-app purchases." Then describe how you would learn it | Tests whether the in-app purchase gap is a problem for this role. A plain acknowledgment only |
| B4 | "What makes you the right person to run two titles' calendars when your experience is one calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Then say what carries over (cadence, checklist, reporting) and what does not. Do not claim you have run two titles | The premise is the interviewer's; your reply stays inside your quote |

### C. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a player's experience and the calendar disagreed. What did you do?" | VAL | [grounded] "Players Before Plans" — Saltmarsh values (search snippet) | Selection scaffold: pick a time a player-facing problem outran a planned slot, a moment you chose the player, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar | Values round, documented in the loop. No quoted sentence carries a story, so the guidance is a scaffold with an honest branch |
| C2 | "Give me a release where you announced less than you had hoped to ship." | VAL | [grounded] "Ship the Patch Not the Promise" — Saltmarsh values (search snippet) | Selection scaffold: a release where the checklist or a QA finding changed what you announced. Answer slot: if the checklist caught something, say what it caught; if it never stopped a release, say so and describe how it guards announcements | Ties the value to your checklist (F3) without supplying a story the quote does not hold |
| C3 | "What does 'leave the build greener' mean to you in a live team?" | VAL | [grounded] "Leave the Build Greener" — Saltmarsh values (search snippet, definition truncated) | Give a working meaning in your own words. Do not quote a definition: the page's definition was not fully retrieved, so the pack does not supply one | Values name only, from the snippet. Read the full page before the round |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the position through two follow-ups: "I ran the weekly content-drop calendar for our main title for the last two years." Concede plainly that you have not run live events across two titles. Do not add to the quote | A stress probe on the calendar gap (F1) |
| D2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: say which parts you produced, in your own words; if you produced none, say so | F6 and the attribution test. Presenting is not producing |

### E. Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the release checklist you wrote is used on a release." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe the steps as QA uses them, in your words. Answer slot: if you can name the step that catches the most issues, say it; if you do not track that, say so | F3 and F7. The artefact is inspectable, which is the strongest thing you have |
| E2 | "What was your title's live cadence, and does it meet the 'live-service' bar in this posting?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: say what the cadence was in your words. If you cannot claim the posting's live-service meaning, say so and say what the content drops were | F4. Length of experience is not a gate, so the answer is about fit, not eligibility |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the studio, the calendar you ran, the checklist, the retention reporting. Stop there | Casual opener that is scored for economy |
| F2 | "What are you playing in live ops these days?" | JD | [generic] | Name a game you have actually played and say what its event cadence looks like to you. Do not claim familiarity you do not have | A casual question on a hot topic is scored |

## Values / principles cheat sheet

Source: saltmarshgames.com/values, read through search only; the page was not fetched. Names are from the snippet. The third value's definition is truncated.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold: C1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold: C2 |
| Leave the Build Greener | Not established: the definition was truncated | Scaffold: C3 |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, A3, B4 |
| Coordinate design, art, engineering and community on each update | A2, B2 |
| Own the post-event review and the KPIs it reports | A4, B1, A5 |
| Manage the release checklist with QA | E1, C2 |
| 3+ years producing live-service games or apps | E2, F1 (conversational) |
| Experience running a content calendar | B4, F1 |
| Comfortable with player-retention metrics | A5, D2 |
| Clear written communication | none, and why: no written exercise was announced, so clarity is scored in the answers themselves |

Session total: 18 questions.

## Reverse questions

1. "Larkspur puts both titles on one calendar from February. How will this role's scope change?" Why it lands: shows you read the news and want the real scope.
2. "The Outage Hour is one hour with you. What does a strong result look like to you?" Why it lands: shows you want the scoring, not just the topic.
3. "What does the post-event review look like today, and who owns it?" Why it lands: tests the KPI ownership gap directly.
4. "Your background includes QA. What did that change about how you want a producer to run a release?" Why it lands: ties to his public path (see Reading the interviewer).
5. "How do the live team and QA share the release checklist day to day?" Why it lands: connects to your own checklist.

## Reading the interviewer

Public footprint only, from a search result. The talk page was not fetched.

- **Career pattern:** previously a QA lead at a console studio, now Head of Live Operations at Saltmarsh (search snippet, GDC 2026 talk listing).
- **Self-described argument:** "a live team is judged by how often its patch notes describe what actually shipped" (search snippet, talk title "Patch Notes Are a Promise").
- **Implications:** your checklist (F3) is the thing to lead with, and his QA background makes release discipline the shared ground. Expect questions about it.
- **Mirror opportunity:** the release checklist QA still uses (your message). This is a shared area of work, not a shared career jump. Your path is not a QA path.

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values names for C1–C3. Definition of the third value truncated; page not fetched |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop: one 60-minute session with the hiring manager, a live-incident tabletop and a values conversation. Persona weights and the values cheat sheet follow from it |
| 3. `Saltmarsh Games strategy news` | yes | Project Larkspur (September 2026): season-pass model, one shared calendar from February 2027, per-title event teams retired. Feeds A3, B3 and reverse question 1 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Public talk listing (GDC 2026): role, previous QA lead. Feeds Reading the interviewer and reverse question 4 |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and URLs returned:
- `Saltmarsh Games values`: saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer`: saltmarshgames.com/careers/interviewing (fetched)
- `Saltmarsh Games strategy news`: saltmarshgames.com/news/project-larkspur (fetched)
- `Tobias Wrenfield Saltmarsh Games`: talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only)

## Upgrade menu

- Your release checklist, or a redacted copy → F3 moves from a quoted sentence to an inspected artefact, and E1 gets a real walkthrough
- The retention figures you presented, with their definitions → F6 and A5 get a defended number
- The full Saltmarsh values page → C3 gets a grounded definition
- Any post-event review or KPI report you produced, even partial → F2 moves from transferability, and A4 gets a real example
- A note on whether the round includes a separate values conversation or a scored one → the values persona weight is confirmed
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): the company strategy brief, Tobias's talk in full, and recent org context → B3 and A3 get sharper. Want it?
