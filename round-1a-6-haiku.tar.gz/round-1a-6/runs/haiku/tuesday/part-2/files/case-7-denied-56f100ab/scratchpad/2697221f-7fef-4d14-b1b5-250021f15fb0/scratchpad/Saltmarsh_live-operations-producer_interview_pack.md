# Live Operations Producer at Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile, about 350 people, as you described it)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship and round type not yet stated; the banks assume a hiring-manager round.
**Round:** 60 minutes, Friday.
**Changes:** first version. Built on your message and the JD you pasted. Company and interviewer research was refused, so this pack has no facts about Saltmarsh or Tobias beyond what you gave me.

## How to use this pack

Personas describe how a question will arrive. Types describe what it scores:

- **JD**: the job's own listed duties and requirements.
- **EXP**: your past work, tested for what was actually yours.
- **CASE**: a live problem you solve in the room.
- **VAL** and **CO**: not used here. No company values were found, and company research was refused.

Guidance is scaffolding, not a script. Answer slots are instructions for the interview: answer from your own experience, or say plainly that the practice was not yours.

## Prep triage

Friday is the deadline. The number of hours you have is not stated, so this is an order, not a schedule.

1. **A1**, the "never led a team" objection. This is the highest-return rehearsal in the pack, because the JD asks you to coordinate four functions and your material has no evidence for it.
2. **D1**, the same objection under pressure: hold, then concede specifically.
3. **A4** and **C1**: the post-event review, and how your retention numbers were defined.
4. **B4**: bring the checklist, and walk through it.
5. **A3** and **A5**: two titles, and events that depend on purchases.

Everything else is insurance.

**Suggested pacing for the 60 minutes** (my split, not something I know about their process):

- About 5 minutes: your arc (E1).
- About 20 minutes: the calendar and team coordination (A1 to A3, B2, B3).
- About 15 minutes: metrics and the post-event review (C1, C4, A4).
- About 10 minutes: a live case (B1 or B2).
- About 10 minutes: your questions (reverse questions below).

## Fit snapshot

The JD names no gate terms, such as location, right to work or licence. "3+ years" is graded on fit, not treated as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title's weekly content drops, not a calendar for two titles. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for a second title, say which and how; if not, say so and say how the one calendar ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these four functions. Answer slot: name a release where you coordinated people across functions, which functions, and how you got their work to the same date; if you did not, say so and say how you would start. |
| F3 | "own the post-event review" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran or wrote one, say which event and what it concluded; if not, say so and say what you would review first. |
| F4 | "the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers reaches reporting them, but not choosing which KPIs the review reports. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, say which and how you decided; if not, say so. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Bridge: as quoted. The checklist itself is an inspectable artifact; showing it would raise this row to high. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years are in your material. The live nature of that title, and your producing work on it, are not. Bridge: "I have four years as an associate producer at a puzzle-game studio." Answer slot: say whether the title was live after launch and what that meant for your work, in your own words. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Bridge: as quoted. |
| F8 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting retention numbers. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined or calculated the retention figures, say how they were counted and which assumption you would defend least; if you presented figures others calculated, say so. |
| F9 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement: a written document other people work from. Bridge: as quoted. |

## Prohibited claims

Claims this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar across two titles | Inflated form of F1 | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title's calendar; A3 stays inside that. |
| Owned the KPI reporting | Inflated form of F4: presented became owned | "Presented the monthly retention numbers to the studio head." No ownership word. |
| Led a team, or led cross-functional teams | Negative you stated | Plain acknowledgment: "I haven't led a team." No answer slot asks about leading. |
| A live-service title you ran | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Whether that title was live is not in your material. |
| Purchase or monetisation experience | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| Owns the release process with QA | Inflated form of F5 | "Wrote the release checklist our QA team still uses." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps: no team leadership, no review ownership, no monetisation | Top. A hiring-manager round prices gaps first, and the JD asks you to coordinate four functions while your material says you have never led a team | Rehearse the single predictable objection until it is plain. Hold, then concede specifically | 5 (A) |
| Case / Strategist | Live problems from the role: a retention drop, a six-week calendar | Top. A Head of Live Operations will test how you structure a live problem | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud | 5 (B) |
| Data-Driven Prober | Asks how the retention numbers were counted | Mid. The JD names player-retention metrics and KPIs | Name the weakest assumption before they do. Say plainly what you do not know | 4 (C) |
| Pressure / Stress | Time-boxed challenges to "never led a team" and to attribution | Mid. The leadership gap makes a stress test likely | Pause, restate, hold through two follow-ups, then concede a specific point | 3 (D) |
| Conversational | Friendly opener, then a casual question on a JD topic | Low. Casual questions are still scored | 90-second arc, and a real game you play | 2 (E) |

No values round and no peer round were detected, so there is no values cheat sheet and no peer reciprocity question.

## Question banks

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never led a team. How would you coordinate design, art, engineering and community on each update without managing any of them?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Hold on the plain acknowledgment: "I haven't led a team." Then say what you coordinated on the calendar and the checklist, in your own words. Answer slot: if you held other functions to their dates, say how; if others ran that coordination and you kept the calendar, say so plainly. Give the coordination plan as a plan, not a past. Hold through two follow-ups by returning to the calendar and the checklist. Concession: "I haven't led a team, and I'd want an early check with each lead on what they need from a calendar." | F2 has no evidence, and the candidate's stated absence of team leadership makes this the most predictable objection. Highest-return rehearsal in the pack |
| A2 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story-mapped on F1 and F7: the calendar, the weekly cadence, the two years, in your own words. Answer slot: if you set what went on the calendar, say which decisions were yours; if someone else set the content, say so and describe how you kept the calendar on time | F1 and F7 are the strongest rows; this is the likeliest opener and it tests what was yours |
| A3 | "The role plans two titles. What changes when you're running two calendars instead of one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Honest: "I've run one title's calendar. What I'd carry across is the weekly cadence. What I'd check first is each title's release schedule." That is a plan, not a past. Answer slot: if you have planned around more than one title's dates, say which and how; if not, say so | F1 is transferability; the two-title scope is where the probe lands |
| A4 | "The role owns the post-event review and the KPIs it reports. What have you owned there?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); "Presented the monthly retention numbers to the studio head." (your message) | Hold on what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, or ran a review after an event, say which and how you decided; if not, say so and say what you presented | F3 has no evidence and F4 is transferability. The question tests whether ownership is claimed |
| A5 | "Your background is a puzzle-game studio. What would you check first if a title's events depended on purchases?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); [generic] purchase-linked events are a common live-ops pattern | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan: what you would check first, as a plan. No answer slot | No JD line names monetisation, so this is a probe your stated absence invites, not a requirement. The plain acknowledgment is the honest form |

### B. Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention drops for three weeks after a content drop. Sketch how you'd diagnose it." | CASE | [generic] role-family live-problem pattern | Clarify what retention means here: day one, day seven, which cohort. Then segment by version, platform and cohort, separate the drop from seasonality, and name the metric you would trust least. No claim about your past | A live problem on the JD's retention requirement; `[generic]` because it is a pattern, not a fact about this employer |
| B2 | "A major update ships in week three. Sketch the next six weeks of live events. What do you need to know first?" | CASE | [generic] role-family live-problem pattern | Clarify before structuring: what design, art, engineering and QA can commit to, what the community needs at launch, and any release freeze. Then sequence the events. No claim about your past | Tests the calendar requirement and the coordination requirement together, in the order the JD lists them |
| B3 | "Who has to agree before a live event goes out, and what happens when one of them says no?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Approach: name each function's gate and how a no gets escalated. Answer slot: if you have had a no you had to resolve, say how; if not, say so | F2 is the coordination row with no evidence; this asks for the process, not a story |
| B4 | "Walk me through your release checklist. What does QA need to see before a release?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F5 and F9: you wrote it, QA uses it now, and you name two items in your own words. Answer slot: if QA shaped or changed it, say how; if you wrote it alone, say so | F5 and F9 are both met by this document. Bring the checklist, if you can, so you are walking through a real artifact |
| B5 | "What would you cut from a live calendar that teams usually keep?" | CASE | [generic] role-family judgment pattern | Pick one item, say what it costs, and say what you would measure before cutting it. Judgment, not a past claim | Tests prioritisation at the calendar level, which the JD's "plan and run" line implies |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: how the cohort and time window were defined. If you defined them, say how; if someone else did, say whose and what you checked. Name in your own words the assumption you would defend least. Do not supply a definition you cannot repeat | F8 is the row; this is the defend-the-number probe, and the honest answer is the one you can repeat under a second question |
| C2 | "Which event do you think moved retention, and how would you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say what you can and cannot separate. Answer slot: if you measured one event's effect, say how; if not, say so | Attribution is the standard probe on a calendar; the answer you can defend is the one with its limit stated |
| C3 | "The checklist is still in use. How do you know it works?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | The only fact your material states is continued use. Answer slot: if you tracked anything the checklist caught or missed, say what; if not, say that continued use is the evidence you have | Tests whether a used artifact is being read as proof of effect |
| C4 | "What KPIs would you report after a live event, and how would you tell a real result from noise?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Plan language, no past claim: name a metric, its baseline, the noise you would expect, and the assumption you would defend least | The JD's KPI line, asked as a method. F3 and F4 meet it here |

### D. Pressure / Stress (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Pause, then restate the question. Hold: "I haven't led a team. What I've done is run the calendar and write the checklist QA uses." Hold through two follow-ups by returning to those two facts. Concede specifically: "I haven't led a team, and I'd want an early check with each lead on what they need from a calendar." Never fold on the calendar or the checklist | The pressure version of A1: hold the position your material carries, then concede only what is true |
| D2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: "I presented them." Then say which part was yours (the presentation, the definitions, the choice of what to show), in your own words. If others built the numbers, say so | Attribution under pressure; the hold is the presentation, and the concession is precise |
| D3 | "Four years as an associate producer. Why take this role now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Give your reason in your own words, about live operations work you want to do. Do not name a title you have not held | Motivation under pressure. Keep it to what you want, not to a story about a title you have not held |

### E. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path into live ops." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." (both your message) | A 90-second arc using those two sentences in that order. Stop at two years | The opener is scored. Keep it to the two quotes |
| E2 | "What are you playing right now, and what would you change about its live events?" | JD | [generic] casual register on a JD topic | Name a game you actually play and one live event you would change. Keep to what you have played | Casual, but it tests the live-events interest the JD asks for |

## Coverage of the JD

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A3 |
| Coordinate design, art, engineering and community teams on each update | A1, B2, B3 |
| Own the post-event review and the KPIs it reports | A4, C4 |
| Manage the release checklist with QA | B4 |
| 3+ years producing live-service games or apps | E1, D3 |
| Experience running a content calendar | A2, E1 |
| Comfortable with player-retention metrics | C1, B1, D2 |
| Clear written communication | B4 (the checklist you wrote) |

## Reverse questions

Each one has a "why it lands". No interviewer profile exists, so none is tied to Tobias's career path. Not a peer round, so no reciprocity question.

1. "What does a live event look like six weeks after it ships, and who reads the review?" **Why it lands:** it shows you think past launch, which is where the post-event review (F3) sits.
2. "How do design, art, engineering and community commit to an update date today?" **Why it lands:** it tests the coordination model you would inherit, which is the A1 objection in practice.
3. "Which of the two titles has the tighter calendar right now, and why?" **Why it lands:** it shows you read the two-title scope (F1) and asks where the pressure is.
4. "How is player retention defined for these titles, and who owns that definition?" **Why it lands:** it separates defining the metric from presenting it (C1, F8).
5. "What does QA need to see before a live update goes out?" **Why it lands:** it leads to the checklist you wrote (B4, F5), and shows you know the release gate.

## Sources

**Provided documents:** the JD, and your background, both in your message. No other documents were given.

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2. All three searches were refused, so no company or interviewer facts were gathered.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Refused. Would have moved the values cheat sheet (section 10), which is absent. Absence does not change this pack's question types |
| 2. `{company} interview process {role family}` | unavailable | No call was sent: search was refused for this session. Would have moved the loop structure and the persona weights, which currently rest on relationship priors only |
| 3. `{company} strategy` / recent news | unavailable | No call was sent: search was refused for this session. Would have moved the CO bank, which is absent |
| 4. `{interviewer name} {company}` | unavailable | Refused. Would have moved the interviewer read and a tailored reverse question, both absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Un-numbered: a further search outside the declared targets, `Saltmarsh Games mobile game studio`: refused. Moved nothing.

Queries sent and their outcomes: `Saltmarsh Games mobile game studio` (refused); `Tobias Wrenfield Head of Live Operations Saltmarsh Games` (refused); `Saltmarsh Games values careers` (refused).

## Upgrade menu

- **Search permission**, or the Saltmarsh values and careers pages, and any public talk or post by Tobias → a values cheat sheet, an interviewer read, a tailored reverse question, and company facts in the banks.
- **The round type and whether Tobias would be your manager** → persona weights recomputed (asked in the message below).
- **The release checklist, with confidential items removed** → F5 and F9 move to high confidence, and B4 becomes a document you walk through.
- **One cross-functional update you coordinated, told in your own words** → F2 gets a quote, and A1 and B3 get a story to map.
- **How the retention figures were defined in your reports** → C1's slot becomes a sourced sentence instead of an open slot.
- **The recruiter's note on focus areas, or any exercise** → a section for any graded deliverable.
- **How many hours you have before Friday** → a sized prep schedule in place of the order above.
- **A `tuesday-dossier.md` from an earlier run** → its verified evidence and prohibited claims would bind every cell in this pack.
