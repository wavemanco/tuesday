# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed. Format: 60-minute interview, single session.

## How to use this pack

- **Personas** = how a question arrives (the delivery). **Types** = what is being scored.
- Types: **JD** (a stated responsibility or requirement), **EXP** (what you actually did), **CASE** (a live problem, no claim about your past), **VAL** (not used: no values-style round detected), **CO** (not used: company research did not run).
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the answer is yours to give from your own experience, including "that was not mine."

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, not live events across two titles. Bridge at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles. If you ran a calendar across a second title, say so and how. If you did not, say so plainly and say how you would plan across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | low | [inferred] | discovery | The material does not show which teams you coordinated on a drop. Answer slot: if other teams worked on a drop, name them and what you did to coordinate them. If you did not coordinate them, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [inferred] | transferability | Presenting figures is adjacent to owning the KPIs and the review, and the material does not show the review. Bridge at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you set what the KPIs measured, or ran a review after an event, say so and how. If you only presented figures set elsewhere, say that. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement. Use the verb you have: "I wrote the release checklist our QA team still uses." Do not say "managed." Expect a probe on how QA uses it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [inferred] | transferability | The years match. The material does not say the title was live-service in the JD's sense, and your title was associate producer. Bridge: "Four years as an associate producer at a puzzle-game studio." Answer slot: the JD says live-service. Say how your main title's updates worked, in your own words. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement directly. Bridge: "For two years I ran the weekly content-drop calendar for our main title." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. The probe will be how the figures were counted (see P1 to P4). Bridge: "I presented the monthly retention numbers to the studio head." |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is written work that another team uses daily. Bridge reworks only that quote: "I wrote the release checklist our QA team still uses." No sample is in the material, so do not describe its clarity beyond that. |

**Requirement with no evidence line:** none. Every JD requirement has a row.

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of gaps: team leadership, and where the JD goes past your material | **Highest.** Assumed hiring-manager prior: a hiring manager is buying capability and checking the gaps. Your two stated gaps (never led a team; no in-app purchase work) make this the top weight. | Rehearse the team-leadership objection until it is routine. Hold on what the material carries, concede the rest plainly. |
| Case / Strategist | Live problems from the role: plan a calendar, diagnose a retention drop | **High.** Hiring-manager prior, and the JD is a planning role. | Clarify, then structure, then name metrics and risks. Say what you need to know first. |
| Data-Driven Prober | Asks how the retention figures were counted, and which assumption you would defend least | **Medium-high.** The retention line is on your CV, so it will be tested. | Know what you can and cannot say about how each figure was counted. Say so when you do not know. |
| Conversational | Friendly opener, "walk me through it" | **Medium.** Common at the start of a 60-minute session. Casual questions are still scored. | Pre-script a 90-second arc. Treat casual questions on the JD's topics as scored. |
| Pressure / Stress | Time-boxed challenges to your credibility or your claims | **Low-medium.** No signal of a stress style in the material. Kept at two questions. | Pause, restate, hold a position through two follow-ups before conceding anything real. |

**Values / Behavioral:** not weighted. No values-style round was detected, and no published values were read (research did not run). The coordination questions in the Skeptic bank cover the behavioral ground.

## Question banks

Session total: 18 questions. Depth follows weight: Skeptic 5, Case 4, Prober 4, Conversational 3, Pressure 2.

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You haven't led a team. How would you coordinate design, art, engineering and community on an update?" | JD, EXP | [grounded] "Never led a team" (your message); raising source: JD line "coordinate design, art, engineering and community teams on each update" | **Highest-ROI prep in this pack.** Hold, then concede. Start with the plain acknowledgment: "I haven't led a team." Then describe the coordination you did, using only the F1 and F2 material: the weekly drops, for two years. Answer slot: if other teams worked on a drop, name them and what you did to coordinate them; if you did not coordinate them, say so plainly and describe how you would set up the first update. Hold through two follow-ups by returning to the drops, not by adding to them. | F2 is the gap and the JD line is the objection. A stated negative makes this the likeliest probe. |
| S2 | "The JD is two titles. Which part of a calendar across two titles have you run yourself?" | JD, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer with F1's bridge: one title, weekly content drops, two years. Answer slot: if you ran a second title's calendar, say which part and how you decided. If you did not, say so plainly and describe how you would plan across two. | F1 is the closest evidence to the JD's first line and the likeliest place to be probed. |
| S3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); raising source: JD line "3+ years producing live-service games or apps" | Name the live-service part as the one your material does not show. Then say how you would learn it first. Do not claim live-service work. | F5 is the transferability gap. Admitting it cleanly scores better than a stretched bridge. |
| S4 | "How would you plan an update that depends on engineering work you don't manage?" | JD, CASE | [generic]; raising source: JD line "coordinate design, art, engineering and community teams on each update" | Structure it: what you would ask engineering first, what the release date depends on, how you would track their slip, and what you would tell the other teams. Make no claim about past engineering work. | A live version of the JD's engineering line. The question presupposes nothing about your past. |
| S5 | "Why leave puzzle games for live operations?" | EXP | [generic] | Answer slot: state your reason in your own words. The material gives none, so this one is yours. Do not borrow a reason from the JD. If your reason is not the JD's, say so. | A motivation probe every hiring manager asks. Decide your reason before the interview. |

### Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the first two weeks of a content calendar for two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's current drop cadence, which teams are free, what the release checklist requires, what the studio head will judge the calendar on. Then objective, approach, metrics, risks. | The JD's first line as a live problem. Scores structure and questions, not the right answer. |
| C2 | "Retention on one title drops 20% in the week after a live event. Diagnose it." | CASE | [generic] | Structure: check the measurement first, then cohorts, then what changed in the release or event, then timing. Name the assumption behind the 20% before you trust it. | Tests the JD's retention line in a live form. |
| C3 | "Walk me through the post-event review you would run for one event." | JD | [generic]; nearest material: "Presented the monthly retention numbers to the studio head." (your message) | Structure: what the review answers, which KPIs, the reading window, what would change the next update. Answer slot: the nearest thing you have done is the monthly retention presentation. Say what it covered and what it did not, in your own words. | Covers the JD's post-event review line, which your material does not show directly. |
| C4 | "Write the headline of a post-event review for a studio head in two sentences. What do you lead with?" | JD, CASE | [generic] | Lead with the one number the studio head acts on, then the change you would make. Keep it to two sentences in the exercise. | Covers "clear written communication" with a live exercise instead of a claim about your writing. |

### Data-Driven Prober (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: say how the figure was counted, in your own words: the definition, the cohort, the window. If you did not define it, say so, and say which part was yours to present. Name the weakest assumption before they do. | Defend-the-number slot for the retention line. The pack does not supply a counting method. |
| P2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the assumption you know of, in your own words. If you do not know how a figure was counted, say so plainly. | Converts a gotcha into a credibility point. |
| P3 | "How did you measure whether a weekly drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer slot: if you measured drops individually, say what and how. If you did not, say so and say what you would measure first. | F6 is the evidence. The measurement is the next question a prober asks. |
| P4 | "Which of your retention figures would you not put in front of a studio head without a caveat?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the figure and the caveat in your own words. Answer slot: if no figure needs a caveat, say so and say why, using only what you know. | Tests whether you know the limits of your own numbers. |

### Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc in your words: the studio, the title, the calendar, the checklist, the retention presentation. Keep the title as associate producer. | An opener that is scored. Keep the arc inside what you have done. |
| K2 | "Tell me about the release checklist. What does QA lean on it for?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message); raising source: JD line "manage the release checklist with QA" | Say what the checklist covers and how QA uses it, in those words. If you did not set QA's practice, say so. | F4 is the evidence for the checklist requirement. |
| K3 | "What would you want to see first on the retention dashboard?" | JD | [generic] | Name the first thing you would check and why, and what would change your next step. | Casual register, JD topic. Scored as much as the formal questions. |

### Pressure / Stress (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why you over someone who has led a team?" | EXP | [grounded] "Never led a team" (your message) | Pause. Hold on what the material carries: two years of weekly content drops on one title. Concede plainly: "I haven't led a team." Do not argue the point past the second follow-up. | Composure test on the stated gap. |
| R2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer slot: say what you wrote and what others shaped, in your own words. If others wrote parts, say which. | Attribution test. Honest precision holds up. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | S2, C1 |
| coordinate design, art, engineering and community teams on each update | S1, S4 |
| own the post-event review and the KPIs it reports | C3 |
| manage the release checklist with QA | K2, R2 |
| 3+ years producing live-service games or apps | S3 |
| experience running a content calendar | P3, K1 |
| comfortable with player-retention metrics | P1, P2, P4, C2, K3 |
| clear written communication | C4 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot and from your own statements.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran the live-events calendar for two titles." | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." Limit, in the pack's analysis: your material says one title's content drops, not live events across two titles. |
| "I owned the post-event review and the KPIs." | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Limit, in the pack's analysis: the material shows presenting, not owning. |
| "I led a team." / "I've managed people." | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot. |
| "I've worked on a game with in-app purchases." | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." The JD does not raise it, so no question here presupposes it. If an interviewer raises monetization, use this line. |
| "Live-service" experience. | Inflated form of F5 | "Four years as an associate producer at a puzzle-game studio." Limit, in the pack's analysis: the material does not establish live-service in the JD's sense. |
| "I'm a producer." | Inflated form of your title | "Associate producer." |
| "I set the retention targets / defined the metric." | Inflated form of F7 | "I presented the monthly retention numbers to the studio head." The material shows presenting. |

## Reverse questions

Every question below is role-generic: no interviewer profile was available. Each has a "why it lands."

1. "What does a good first 90 days look like for someone taking on the calendar for two titles?" Why it lands: turns the Skeptic's gap into a plan conversation.
2. "How are post-event reviews run today: who writes them, and who reads them?" Why it lands: tests whether the review and its KPIs are yours to own, and shows you know it is part of the job.
3. "Which of the two titles needs the most help right now, and why?" Why it lands: shows you are thinking about the calendar, not only the posting.
4. "How far ahead does QA need a drop locked, and what happens when one slips?" Why it lands: links the release checklist to the calendar and shows you know the dependency.
5. "How does the team's retention reporting work now, and which question do you wish it answered?" Why it lands: invites the Head to name the KPI gap, which is the one you can speak to.
6. "Who will I work most closely with on each update, and where does that process break today?" Why it lands: tests the coordination requirement and signals you expect to fix a process, not just run one.

## Sources

- **Provided documents:** the job description and your background, both pasted in your message.
- **Research tier:** L1, with search refused by the host. Searches 4 of 6, fetches 0 of 2. The four calls were refused by the permission system and were not retried.
- **Queries sent (all refused):**
  - "Saltmarsh Games values": refused
  - "Saltmarsh Games interview process live operations producer": refused
  - "Saltmarsh Games mobile studio news strategy": refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10, is omitted. No published values were read, so no values-style round is detected from research. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure not established. The pack assumes a single session, with the generic fallback (flat weights, hiring-manager prior). |
| 3. Saltmarsh Games strategy / recent news | unavailable | Grounding brief (section 6) and any CO questions are omitted. The Case bank is generic. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read (section 7) is omitted, and reverse questions are role-generic. |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- A round-type note from the recruiter (is Tobias the hiring manager, a peer, or part of a panel?) → reweights every persona bank.
- Any presentation or exercise the recruiter announced → a build section for it.
- Tobias's public profile or a link to a talk or post → an interviewer read, persona weights from his path, and a tailored reverse question.
- Web search allowed in a later session → the four refused targets run again: values (a values cheat sheet if published), interview process (loop structure), current strategy (CO and Case questions), and his public footprint.
- A second title or any other team you coordinated → upgrades F1 and F2, the two rows that carry the most weight for the JD's first two lines.
- A copy of the release checklist you wrote, with names removed → an inspectable artifact, which can raise F4 and F8 from medium.
- A `tuesday-dossier.md` file, which would record the gaps this prep exposed for later sessions.
