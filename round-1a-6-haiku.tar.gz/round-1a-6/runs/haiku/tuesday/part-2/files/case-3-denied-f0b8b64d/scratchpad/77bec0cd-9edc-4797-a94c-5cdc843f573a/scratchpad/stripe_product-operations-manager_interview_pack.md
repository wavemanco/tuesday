# Stripe: Product Operations Manager, final round (interviewer not named)

Built from the role and round you named only. No CV, JD, interviewer or recruiter notes were supplied, and web search was refused, so Stripe-specific values, loop structure and strategy are absent. Every question is generic to product operations or an open prompt.

## 1. How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

- **CASE**: live problem from the role, delivered live
- **EXP**: your past work, and whether it holds up under scrutiny
- **JD**: stated responsibilities of the role, including gaps
- **CO**: company and strategy knowledge (none in this pack, since research did not run)
- **VAL**: behavior against published values (none in this pack, for the same reason)

## 2. Prep triage

Prep time not stated, so this section is omitted.

## 3. Fit snapshot (worksheet variant)

No JD or recruiter wording was supplied, so requirements are role-family prose, labeled `[generic]`, with no quotation marks. Every evidence cell reads `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional operating rhythm: planning, launches, reviews ([generic]) | none given | none | [generic] | discovery | Answer slot: name one operating rhythm you have run or helped run, what it was for, and what you would change. If you have not run one, say so, and say how you would set one up. |
| F2 | Turn metrics into decisions ([generic]) | none given | none | [generic] | discovery | Answer slot: name a metric that changed a decision, and how it was counted. If none did, say so, and name the metric you would define first. |
| F3 | Work as a peer with product, engineering, finance and go-to-market teams ([generic]) | none given | none | [generic] | discovery | Answer slot: name one cross-team disagreement, what you did, and how it ended. If there was none, say so. |
| F4 | Run launches and process changes end to end ([generic]) | none given | none | [generic] | discovery | Answer slot: name a launch or process change you took from plan to review. If you have not, say so, and say what you would check first. |

Confidence is `none` on every row because nothing about your background is in the material yet.

## 4. Prohibited claims

No entries. There is no stated background, so there is no stretched wording to rule out yet. This will be rebuilt when your CV arrives.

One guardrail holds regardless: do not describe Stripe's products, internal processes or metrics as if you know them unless you checked them yourself.

## 5. Persona table

Round: final round. Relationship: not stated. Weights are blended, not hiring-manager or peer-specific.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live product-ops problems: a launch off target, a cadence to design | Highest. Product ops is a judgment role; finals usually test how you structure a problem | Clarify, then structure, then name metrics and risks |
| Skeptic | "Where are you weakest?", "why ops, why now" | High. Every row in F1 to F4 is a gap until you answer it | Name the real gap first, then your ramp plan |
| Peer Evaluator | Seams between teams, credit, disagreement | Medium. Relationship unknown, so this is the default for any final loop | Propose seam principles, not a claim about their seam |
| Pressure | "Why you over someone who has done this for years?" | Medium. Common at finals | Pause, restate, hold, concede a specific gap |
| Data-driven prober | "What did you count?" | Medium. Only bites if you cite numbers | Name the figure you would defend least |
| Conversational | "Walk me through the journey" | Always present at some level; casual questions are scored | Prepare a 90-second arc |

## 6. Question banks

Weights: Case/Strategist 5 (top), Skeptic 4, Peer Evaluator 3, Pressure 2, Prober 2, Conversational 2. Total 18.

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is at 40% of its adoption target two weeks out. What do you do?" | CASE | [generic] | Clarify what counts as adoption and where the target came from. Split the gap by segment. Pick two or three levers, each with one metric. Name the risk of each. Say what you would not do. | Live problem from the launch remit; asks about no past |
| A2 | "Twelve product teams each run their own planning. Design the operating rhythm you would put in place." | CASE | [generic] | Clarify scope and what already works. Propose the smallest cadence: one shared input, one review, one decision log. Say who it serves and what it stops. | Tests F1 as a design problem, not a claim |
| A3 | "How would you decide whether a process change is worth keeping?" | CASE | [generic] | Define the outcome before the change. Set a comparison period. Count the cost of the process. Set a stop rule. | Tests F2 |
| A4 | "What would you measure in the first 90 days to know the function was working?" | JD | [generic] | One or two outcome measures plus one health measure. Name the baseline you would set first. Avoid counts of activity. | Common first-90-days probe |
| A5 | "Product and finance disagree on slowing a launch. You are the ops person in the room. What is your move?" | CASE | [generic] | Name who owns the decision. Restate each side's constraint. Propose a decision rule and a date. | Tests F3 under pressure |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap, then how you would close it in the first month. Answer slot: if you have done part of this work, say which part and how. If you have not, say so plainly and say how you would learn it. | Predictable objection; the deepest rehearsal goes here |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Selection scaffold: pick the moment you first took on work about how a team runs rather than what it builds. If you have one, say it in your own words. If not, give your honest motivation in one sentence and what you have done to test it. | Motivation probe |
| B3 | "Tell me about a time you were asked to own something you had no authority over. How did you handle it?" | EXP | [generic] | Open prompt. Pick one instance and say what you did and what you could not decide. If none comes to mind, say so, then give the nearest thing you did. | Tests authority, which the role depends on |
| B4 | "Operations work is invisible when it goes well. How do you make your impact visible without taking credit from the teams?" | EXP | [generic] | Name one reporting habit you use or would use. Say how credit goes to the teams. | Credit-sharing probe |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product ops and the teams you would work with, and what happens when you disagree?" | JD | [generic] | Propose principles for who decides what, rather than claiming to know their seam. For disagreement: state both views, then a decide-by date. | Peer seam probe |
| C2 | "What would you need from me to do this well?" | JD | [generic] | Name two or three concrete asks. Say what you would bring to their team. | Reciprocity |
| C3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work and say who did what. If you have no such example, say so, then describe how you would handle it. | Credit probe |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has done this job for years?" | JD | [generic] | Pause. Restate the question. Hold a position anchored in what you would bring. Concede one specific gap. Do not fold on the core claim. | Composure probe |
| D2 | "Tell me about the result you are most proud of. How much of it was actually you?" | EXP | [generic] | Open prompt. Pick one result. Say what you did and what others did. If you have no countable result, name the nearest thing you did. Hold through two follow-ups. | Attribution under pressure |

### Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick the number you would defend least. How was it counted?" | EXP | [generic] | Open prompt. If you have a number, name it and the assumption you would defend least. If none comes to mind, say so, and name the operational figure you would track first. | Probers ask for the denominator |
| E2 | "Which metric would you retire, and why?" | JD | [generic] | Name one vanity metric and why it misleads. | Tests F2 |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Scaffold for 90 seconds: the roles in order, one turn you chose, and why this role. Use only what your CV or your own words carry. | Casual openers are scored |
| F2 | "Anything you are reading or building on the side that bears on this role?" | JD | [generic] | Name one thing you actually did. Do not invent one. | Interest is scored casually |

### Requirement coverage

No JD supplied, so coverage cannot be checked against stated requirements. Role-family coverage: operating rhythm (A2, F1), metrics into decisions (A3, A4, E2), cross-team work (A5, C1, C2), launches (A1), credit and visibility (B4, C3).

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first 90 days in this role a clear success for you?" | Shows you plan around their outcome |
| R2 | "Which team does this role work with most, and what is their current bottleneck?" | Shows you think in their system |
| R3 | "How does product operations report its impact upward today?" | Tests whether the function has a scorecard |
| R4 | "Which decisions does this role own outright, and which go up?" | Clarifies the authority B3 probes |
| R5 | "What did the last person in this role spend most time on that they would tell you to drop?" | Candid operational detail |
| R6 (if the interviewer is a peer) | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity |

## 8. Sources

Research tier: L1, searches 0 of 6 (3 sent, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe company values` | unavailable | Values cheat sheet dropped. Values are not taken from memory |
| 2. `Stripe Product Operations Manager interview process final round` | unavailable | Loop structure; persona weights are blended rather than loop-specific |
| 3. Stripe strategy / recent news | unavailable | CO bank absent. No strategy brief was supplied |
| 4. Interviewer name | n/a | No name given |
| 5. Representative JD | unavailable | Fit snapshot uses role-family prose, not quoted requirements |

Queries sent, all refused:
- "Stripe company values principles"
- "Stripe Product Operations Manager interview process final round"
- "Stripe Product Operations Manager job description"

## 9. Upgrade menu

- The round type and who you are meeting → persona weights and reverse questions tied to their path
- Pasted JD text → the `[generic]` rows become `[grounded]` quotes, and the coverage line gets checked
- Pasted CV → the evidence column gets real quotes, the prohibited list gets built, and the F-rows and the question banks upgrade
- Web search enabled, or the Stripe values page pasted → values cheat sheet and Stripe-specific CO questions
- A recruiter's note on the final's format → coverage of any deliverable, such as a presentation or a case
