# Engineering Manager, Larkfield Systems: loop prep pack (three rounds)

Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.

Rounds (dates assumed as Tue 1 Dec, Thu 3 Dec, Mon 7 Dec):
- Round 1, 45 min: hiring manager, Director of Engineering (your would-be boss).
- Round 2, 60 min: panel of two staff engineers and a product manager. Names not given.
- Round 3, 30 min: VP Engineering. Recruiter's words: "values and leadership philosophy". Name not given.

Mode: loop. One shared fit snapshot, prohibited list and sources block, then a mini-pack per round with its own persona weights, bank and reverse questions. Upgrade menu at the end.

## How to use

- Personas describe how a question is asked. Types describe what is scored.
- Type key:
  - VAL: behavioural and values alignment. Does past behaviour show the value?
  - EXP: work-experience deep-dive. Do your claims survive scrutiny?
  - JD: role-driven. Can you do the listed job, gaps included?
  - CO: company and strategy knowledge. None in this pack, because no company research ran.
  - CASE: live problem from the role. Structure and reasoning.
- IDs are round, then persona letter, then number. 1A1 is round 1, Case/Strategist, first. Persona letters: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Conversational, E Pressure, G Peer Evaluator, V Values/Behavioural.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.
- An Answer slot is an instruction for the interview. Either honest branch is acceptable.

## The fit snapshot (shared)

Requirements are quoted from your role summary, or marked [generic] where the summary does not state them. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material shows one team of 6, not two squads. Words: "3 as a team lead of 6." Answer slot: if you have ever run two teams or squads at once, say how and when. If you have not, say so, and say how you would split the work. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows a reliability quarter you pushed through, for a team of 6. It does not show delivery across 11 engineers. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you set the quarter's scope and dates, say which. If someone else set them, say so and say what you did within them. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring, though for backend roles. Words: "I run our hiring loop for backend roles — about 40 interviews last year." The count is unverified, so expect a probe on it. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary, growth) | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: if you have helped an engineer grow into a bigger role, say how, in your own words. If you have not, say so plainly and say how you would start with 11 engineers. |
| F5 | "partner with hardware and product on roadmap" (role summary, product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | low | [inferred]: the pack's reading that roadmap pressure is the nearest signal of product partnership | transferability | Your material shows roadmap pressure, not a partnership with product. The pack does not assert the partnership. Answer slot: how did you work with product on what the quarter included? If you did, say how. If the quarter was yours to set without product, say so. |
| F6 | "partner with hardware and product on roadmap" (role summary, hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn the hardware side, as a plan and never as a past. |
| F7 | [generic] managing managers. Not in the role summary; whether the squads have leads is unknown. | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I haven't managed managers." Then the plan for learning it. Nothing is added to make the gap feel smaller. |

Gate rows: none established. The summary names no hard term. See upgrade menu.

## Prohibited claims (shared)

Built locally from the fit snapshot. No dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led two squads", or "delivered for 11 engineers" | Inflated form of F1 and F2 | F1's quote at its own scope: "3 as a team lead of 6." The limit is the pack's observation: your material shows one team of 6. |
| "Designed the hiring loop" | Inflated form of F3 | "I run our hiring loop for backend roles." |
| "I cut on-call by 60%", or "the 60% was mine" | Inflated form of F2. The sentence credits the drop to the team, after you pushed a quarter through | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| "I've managed managers", or "I've led leads" | Sourced: your stated negative (F7) | "I haven't managed managers." No slot. |
| Any hardware-roadmap ownership | Sourced: your stated negative (F6) | "I haven't owned a hardware-adjacent roadmap." No slot. |

## Sources

Provided documents: your message only. It holds the role summary, the three rounds, the recruiter's phrase, and your background.

Research tier: L1, searches 1 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (section 10). Not produced: no published values in hand. Query sent: "Larkfield Systems industrial IoT device management company values engineering", refused by the host. |
| 2. Larkfield interview process, engineering management | unavailable | Loop structure. Persona weights follow the three rounds you listed, not a published loop. |
| 3. Larkfield strategy and recent news | unavailable | Current-strategy questions (CO type). None are in this pack. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. The interviewer read is absent. |
| 5. Representative engineering manager JD | unavailable | Your role summary is not full posting text. Requirements are quoted from it, and no [inferred] requirements were added. |

Not included, because their inputs are absent: prep triage (no prep time stated), grounding brief, graded deliverables, interviewer read, delivery coaching.

## Round 1: Hiring manager (Director of Engineering), Tue 1 Dec, 45 min

Persona weights:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live roadmap problems involving hardware and the two-squad split | High. A Director buying capability for a role that partners with hardware (role summary) | Clarify, objective, risks. Think aloud. |
| Skeptic | "Why not hardware?" and "why not managers?" | High. Your two stated gaps are the two a hiring manager sees first | Rehearse the hardware objection until it is plain. Acknowledge, then plan. |
| Data-Driven Prober | Counting questions on your two figures | Medium. Two figures in your message (60%, about 40) | Say what you know of the count, and say plainly what you do not |
| Pressure | Sixty-second "why you" | Low to medium. Shows up inside the Skeptic round | Pause, restate, hold a position you can back |
| Conversational | Opener | Medium. The usual opener | A 90-second arc from your own sentences |

Question bank:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "The hardware team's firmware slips a quarter, and both squads have committed dates. What do you do in week one?" | CASE | [generic] | Clarify what is committed, to whom, and which slips are real. Name the trade-off you would raise first, and who you would bring into the room. | The role summary raises the hardware partnership. A live problem asked as a decision; it presupposes nothing about your past. |
| 1A2 | "Two squads, one device-management service. How would you split the work, and what would you need to know first?" | CASE | [generic] | Clarify the service's boundaries and each squad's current load before any split. Offer the principle you would test first, not a finished org chart. | Tests structure for the two-squad line in the role summary (F1). |
| 1A3 | "What would you want to own on the hardware side of the roadmap in six months, and what would you leave to hardware?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary) | Name one thing you would own with hardware, and one you would defer to them and why. Hold the boundary. Claim no roadmap ownership. | The role's verb, partner, tested as a boundary. The gap is F6. |
| 1B1 | "I don't see hardware-roadmap ownership in your background. How would you handle that in this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a plan, in your words: the first two things you would do to learn the hardware side, and who you would learn it from. | F6 is a capability gap your Director would buy. This is the highest-ROI prep in the pack: the objection is almost certain, and it is aimed at the gap you stated. |
| 1B2 | "You've never managed managers. What's the first thing you'd get wrong?" | JD | [grounded] "never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then one failure mode you would watch for in the first month, as a principle. Do not offer an example you did not live. | F7. The question rests on your own negative, so the answer is a plan. |
| 1B3 | "Which part of growth for 11 engineers would you start with, and what would you measure?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Answer slot: if you have grown an engineer into a bigger role, say how, in your own words. If you have not, say so plainly and give the first two things you would do. | F4 is discovery. Your material is silent on growth, and a Skeptic probes silence. |
| 1C1 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what was counted and over what period, in your own words. Name the assumption behind the figure you would defend least. Say which part was yours and which was the team's. Answer slot: if you cannot say how it was counted, say so plainly. "I don't know how it was counted" is an honest branch. | F2. A headline figure on your background needs a defend-the-number answer. |
| 1C2 | "Walk me through how the about-40 interviews figure was counted." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what counted as one interview, and how many you ran versus sat in on. Name the assumption you would defend least. Answer slot: if you cannot split them, say so plainly. | F3. A prober asks what "about" covers. |
| 1D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc in your own order: engineering, team lead, payments, hiring loop, the reliability quarter. Use your sentences and add no middle. | F1 and F3. An opener is still scored. |
| 1D2 | "What's the part of this role you're most looking forward to?" | JD | [generic] | Name one line of the role summary and why it draws you, in your own words. Make no claim about your past. | A rapport question scored on whether you read the role. |
| 1E1 | "Sixty seconds: why you over someone who has run a hardware roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "pushed a reliability quarter through against roadmap pressure" (your message) | Pause and restate. Hold the position you can back: the reliability quarter you pushed through, and the hiring loop you run. Hold through two follow-ups, then concede the gap plainly: "I haven't owned a hardware-adjacent roadmap." Never fold on the quarter. Never claim hardware work. | Pressure persona. The question presses F6, so the hold is the quarter, not the hardware side. |

Reverse questions:

| Question | Why it lands |
|---|---|
| "What have the two squads' last two quarters looked like, and where did delivery slip?" | Puts delivery first. You ask about the job, not the title. |
| "When hardware and product disagree on a roadmap date, who decides?" | Maps the seam you would own. Hardware partnership is the role's first clause. |
| "What would make you say, six months in, that this hire worked?" | Puts success in their terms. Shows you think in outcomes. |

## Round 2: Panel (two staff engineers and a product manager), Thu 3 Dec, 60 min

Persona weights. Names are not given, so personas are blended across the panel rather than assigned per person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers testing scale and counting | High. Two staff engineers, and your numbers are their first target | Know what you can and cannot say about each count |
| Peer Evaluator | The PM's seam, credit and disagreement questions | High. The product manager prices partnership | Propose seam principles, not a seam you don't know |
| Case/Strategist | Roadmap-scale problems | Medium. The PM and staff engineers share the roadmap | Clarify, structure, then answer |
| Pressure | Depth challenge | Low to medium. Staff engineers do this | Hold, then concede the specific point |
| Skeptic | Managing managers | Low to medium. Surfaces through the staff engineers | Acknowledge the negative, then plan |
| Conversational | Opener | Medium | A 90-second arc from your quotes |

Question bank:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the assumption in your own words before they do. Say which part was yours. | F2. The weakest-assumption move on a headline figure. |
| 2C2 | "Which of the 60% did you measure directly, and which did you infer?" | EXP | [grounded] the same sentence | Separate what you observed from what you inferred. Answer slot: if you cannot separate them, say so plainly. | F2. A prober checks the difference between measured and inferred. |
| 2C3 | "Which team processes would break first when a lead goes from six people to eleven?" | JD | [grounded] "3 as a team lead of 6" (your message); "own delivery, hiring and growth for 11 engineers" (role summary) | Name the first process you would measure, and the signal you would watch. Answer slot: if you have seen a process break at a team's size, say which. If you have not, say so and reason from the numbers. | F1 and F2. The scale gap. JD-tagged on "11 engineers". |
| 2G1 | "Where's the seam between product and this team, and what happens when you disagree on the roadmap?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary); "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles, not a seam you have not seen. Answer slot: if there was a product objection to the quarter, say what it was and what you did. If the quarter was agreed, say so plainly. | F5. The one disagreement story your material carries. |
| 2G2 | "How do you handle credit when work spans teams?" | JD | [generic] | Give a shared-credit moment only if your quoted sentences carry one. Otherwise give the principle you use and say plainly that you have no example to hand. | Peer persona stem. |
| 2G3 | "What would you need from product to take a roadmap item to delivery in a quarter?" | JD | [generic] | Name two concrete asks, then one thing you would give product in return. | Reciprocity framing: what you bring the peer's team, not only what you need. |
| 2A1 | "Device fleet reports show a firmware rollout failing on part of the fleet. Diagnose it." | CASE | [generic] | Clarify scope and device segments first. Name the rollback risk before any root cause. | Live problem from the role. |
| 2A2 | "Sketch the plan for moving device management onto a new registry service. What do you need to know first?" | CASE | [generic] | Clarify what is in scope, then name the two unknowns that would change the plan. | Live problem from the role. |
| 2E1 | "That reliability quarter — how much of the result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pause and restate. Hold: you pushed the quarter through, and the 60% is the team's drop afterwards. Concede plainly what you cannot attribute. Never claim sole credit. | Pressure persona with hold-then-concede. F2. |
| 2B1 | "Two of your reports might be leads. Which decision would you not delegate?" | JD | [grounded] "never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the decisions you would keep, in principle. No example. | F7. |
| 2D1 | "What's been the most interesting problem your team has worked on?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | Name one problem, what the team was solving, and the part you personally did, in your own words. Answer slot: if you cannot name your part, say so. | F1. A casual question, scored. |

Reverse questions:

| Question | Why it lands |
|---|---|
| To a staff engineer: "What's one architecture decision on device management that a new EM should respect, and why?" | Asks for technical judgment. A staff engineer answers with a real constraint. |
| To the PM: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. Asks about the peer's load. |
| "How do the staff engineers and the PM split a roadmap decision today?" | Maps the seam you would sit in. |

## Round 3: VP Engineering, Mon 7 Dec, 30 min

Persona weights:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | "Values and leadership philosophy" questions | High. Your recruiter's words name this round | Open prompts with your nearest story, and say so when there is none |
| Pressure | Altitude challenges in short time | Medium. A VP has 30 minutes | Pause, hold, concede specifically |
| Case/Strategist | Strategy-heavy live problem | Medium. VP altitude | Clarify, then name one risk |
| Skeptic | Managing managers | Medium. Executive-level version of the gap | Acknowledge, then plan |
| Conversational | Opener | Low. Round 1 covers the arc | Short and principled |

No values cheat sheet is produced. No published Larkfield values are in hand (see Sources). The bank uses your recruiter's words as the raising source.

Question bank:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. The nearest story your material carries is the reliability quarter. Tell what the pressure was, what you said, and what changed. Answer slot: if the truth did not land, say so. Do not supply an ending. If no such time comes to mind, say so plainly, then give the nearest thing you have. | "Values and leadership philosophy" is the recruiter's raising source. |
| 3V2 | "What's your leadership philosophy in one minute?" | VAL | [grounded] "values and leadership philosophy" (recruiter's words, your message); "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Give two or three principles you have tested, each with one sentence from your quoted material as its example. Do not present a philosophy you have not used. | Recruiter's words as raising source. |
| 3V3 | "Tell me about a time you got a hire wrong." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. The nearest story is the hiring loop. Say whether you have a hire you would call a miss, and what you would check differently. Answer slot: if you cannot name a miss, say so plainly and say how you judge the loop. | F3. Hiring is the strongest quoted story you have. |
| 3E1 | "Sixty seconds: why should we trust you on the hardware side?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Pause. Hold what you can back: the reliability quarter, and how you would learn the hardware side as a plan. Then concede plainly: "I haven't owned a hardware-adjacent roadmap." | F6 at executive level. |
| 3E2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold: you pushed the quarter through. The 60% is the team's drop afterwards. Concede what you cannot attribute. Never claim sole credit. | F2. Defend-the-number, at the altitude of the VP. |
| 3A1 | "If we asked for a device-management service roadmap in two quarters, where would you start?" | CASE | [generic] | Clarify what is committed and who decides. Name the risk you would raise first. Make no claim about your past. | Strategic altitude. |
| 3B1 | "What would your first two months as a manager of managers look like?" | JD | [grounded] "never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would learn first. No example. | F7 at the level the VP sits. |
| 3D1 | "What do you look for in a team you'd want to lead?" | VAL | [generic] | Two principles, briefly. No example needed. | Low-weight opener. |

Reverse questions:

| Question | Why it lands |
|---|---|
| "How would you know, from outside a team, that the leadership approach is working?" | Shows outcome thinking. The VP answers in their own terms. |
| "What's one leadership habit you'd want the next EM here to keep from this org?" | Asks for values from inside. Invites a story. |
| "Where should this organisation be two years from now, and what part does the EM play?" | Altitude. Matches the VP's remit. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | 1A2, 2C3 |
| Own delivery for 11 engineers | 1A1, 2E1, 3E2 |
| Hiring | 1C2, 3V3 |
| Growth for 11 engineers | 1B3 (discovery: answer slot) |
| Partner with hardware on roadmap | 1A3, 1B1, 1E1, 3E1 |
| Partner with product on roadmap | 2G1, 2G3 |
| [generic] Managing managers | 1B2, 2B1, 3B1 |
| Values and leadership philosophy (recruiter's words) | 3V1, 3V2, 3V3 |

The 60% figure gets defend-the-number questions in rounds 1, 2 and 3 (1C1, 2C1, 2C2, 2E1, 3E2). The about-40 figure gets one (1C2).

## Upgrade menu

- Full job posting text, or its link → the three role-summary requirements become quotes from the posting, and any requirement I have not seen gets a fit row and a question.
- Web search permission, or Larkfield's values page pasted → a values cheat sheet for round 3, the loop structure for all three rounds, and current-strategy questions.
- Names of the two staff engineers, the PM and the VP → per-person persona weights for round 2, and reverse questions tied to their career paths.
- Whether the squads have leads of their own → settles whether managing managers (F7) is a real requirement, and reweights 1B2, 2B1 and 3B1.
- Growth you have done for engineers, in your own words → F4 moves from discovery to a quoted row, and 1B3 becomes story-mapped.
- Any hardware-adjacent work you have done, however small, in your own words → F6 can be re-graded. The pack will not assume it.
- Any take-home or presentation the recruiter named for a round → a graded-deliverable section for that round.
- A tuesday-dossier.md → carries verified evidence and any objection rehearsed in an earlier session into this pack.
