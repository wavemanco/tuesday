# Stripe — Product Operations Manager — final round prep pack

**Role:** Product Operations Manager. **Company:** Stripe. **Interviewer:** not named. **Round:** final round, structure unconfirmed. **Built on:** your message only. No job description, CV or background was supplied, so this is a worksheet pack: every candidate-evidence cell reads `none given`.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: speak it in your own words, and only about things you actually did.

Type key:
- **VAL**: behavioural / values alignment
- **EXP**: your own experience, probed for what you actually did
- **JD**: the role's stated responsibilities and qualifications
- **CO**: company and strategy knowledge
- **CASE**: a live problem, reasoned through aloud

## Fit snapshot (worksheet variant)

No requirements are quoted, because no job description was supplied. The requirements below are role-family patterns, labelled `[generic]`. Every evidence cell is `none given`, so every gap is `discovery`: the evidence may exist, and this material does not show it. There are no gate rows, because nothing in the material states a hard term. Question (d) asks about that.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional operating process (planning, reviews, launches) across product, engineering and go-to-market teams [generic] | none given | none | [generic] | discovery | Strong evidence is a process you ran end to end: who was involved, what changed, and what you would do differently. Answer slot: name one such process in your own words. If you did not design it, or it was not yours to run, say so plainly and describe your part. |
| F2 | Define and track metrics that drive decisions [generic] | none given | none | [generic] | discovery | Strong evidence is a metric you chose, how it was counted, and a decision it moved. Answer slot: name one metric you have put in front of someone and how it was counted. If you have not done this, say so and describe how you would define one. |
| F3 | Prioritise competing asks and manage stakeholders who disagree [generic] | none given | none | [generic] | discovery | Strong evidence is a decision made between two legitimate asks, with the person who disagreed named. Selection scaffold: pick a time two people wanted different things from you. If no such time comes to mind, say so plainly, then describe how you would handle it. |
| F4 | Roll out a change to a team and measure whether it stuck [generic] | none given | none | [generic] | discovery | Strong evidence is a rollout with a measured adoption figure and what you did when adoption lagged. Answer slot: name one rollout and what you measured. If you have not run one, say so and describe the first measure you would set. |

**Provenance** is `[generic]` on every row because the requirement is a role-family pattern, not a sentence from a posting.

## Prohibited claims

No entries. The material has no candidate sentence to stretch and no negative the candidate has stated. Standing rule for this pack: do not describe a process, metric, team size or ownership unless you can name it yourself.

## Persona table

The round type and interviewer are unknown, so weights are flat. This is the generic archetype, and the pack says so plainly rather than assuming a loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operating problems: a launch slipping, a funnel leaking, two teams in conflict | High. Product Ops interviews usually test reasoning on live problems; flat weight because the round is unconfirmed | Clarify, then structure, then state your metrics, and name the premise you would challenge |
| Skeptic | Probes the gap: "which part of this would you be weakest at on day one?" | High. Every candidate meets this in a final round; flat weight | Name one weak area honestly, then give your ramp plan |
| Data-Driven Prober | Asks how a number was counted and which assumption you would defend least | Medium. Likely wherever a metric comes up in your answers | Say what you can and cannot say about how a figure was counted |
| Peer Evaluator | Seam questions between teams and "what happens when we disagree?" | Medium. Likely if one interviewer is a peer; unknown until question (a) is answered | Propose principles for the seam; do not claim to know their team's seam |
| Pressure / Stress | Time-boxed, challenges your position, "convince me" | Medium. Likely in a final round; flat weight | Hold a position through two follow-ups; concede only the specific uncertainty |
| Conversational / Rapport | "Walk me through your journey," then casual questions on tooling | Medium. Casual questions are still scored | Keep a 90-second arc ready; answer casual questions with the same care |

## Question banks

Provenance is `[generic]` on every row, because no candidate sentence exists yet to quote. No row asserts anything about your past. Where a guidance cell asks about your experience, it is a selection scaffold ending in an honest branch.

### Case / Strategist (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new tool's sign-up funnel loses a third of users before setup. How would you approach it?" | CASE | [generic] | Clarify what counts as a loss and who the users are. Segment by one dimension. Name two or three metrics and what you would check first. Say which assumption you would test before spending time | A live funnel problem, a common operating case; no claim about your past |
| A2 | "Design the operating cadence for three product teams on different planning calendars." | CASE | [generic] | State which decisions the cadence must support. Propose one shared planning artifact, one escalation path, and what happens when teams disagree | Tests the process-design requirement (F1) as a problem, not a memory |
| A3 | "A launch slipped two weeks and two teams blame each other. What do you do in the next 48 hours?" | CASE | [generic] | Stabilise the facts with a written timeline. Name who decides. Separate the question of blame from the fix. Say what you would not do | Tests judgment under conflict; no claim about your past |
| A4 | "What would you want to know in your first 30 days before proposing any change?" | CASE | [generic] | Name three things you would learn before proposing, in order, and who you would learn them from | Tests clarify-first thinking, the habit this persona scores |

### Skeptic (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area honestly. Then give the ramp: what you would learn first and who you would ask. Answer slot: if you have a prior example in that area, give it in your own words; if not, say so plainly and give the ramp | The most predictable objection, asked as a gap question |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Give one reason you can name from your own experience, in your own words. Avoid reasons that describe the title rather than the work | Tests motivation consistency; the answer has to be yours |
| B3 | "You have not run a process at this scale. Why would it work here?" | JD | [generic] | Concede the scale gap plainly. Name what transfers and what you would verify in the first month. Hold the position through two follow-ups | Pressure on a likely gap; the honest answer is a concession plus a plan |

### Data-Driven Prober (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you put in front of a leader. How was it counted?" | EXP | [generic] | Choose one metric you actually reported. Say what was counted and which part was yours. Answer slot: if you have no such metric, say so and describe how you would define one | Open prompt; metrics are where probers go first |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [generic] | Name the weakest assumption in your own words before the interviewer does. Do not invent an assumption you did not make | The weakest-assumption move; converts a gotcha into credibility |
| C3 | "Which metric would you stop tracking, and why?" | JD | [generic] | Name one metric you would drop, the decision it fails to support, and what you would track instead | Tests metric hygiene; reasoning, not recall |

### Peer Evaluator (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our product and engineering teams sit side by side. Where's the seam with operations, and what happens when we disagree?" | CASE | [generic] | Propose principles: who decides what, and how disagreements escalate. Do not claim to know this team's seam | Seam questions test partnership; principles score better than false knowledge |
| D2 | "How do you handle credit when a process change spans several teams?" | EXP | [generic] | Describe your approach to credit. Answer slot: if you have an example, name who did what in your own words; if not, describe the approach | Tests credit-sharing instincts |
| D3 | "What would you need from my team in the first month?" | JD | [generic] | Name two specific things, and what you would offer in return | Reciprocity; the peer is pricing what the hire costs |

### Pressure / Stress (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has done this before?" | JD | [generic] | Name your strongest concrete experience in your own words. Concede the gap plainly. Hold the position through two follow-ups | Time-boxed challenge; the test is composure, not content |
| E2 | "That sounds like busywork. Convince me it isn't." | CASE | [generic] | Hold your position with one concrete reason. Concede only the specific uncertainty. Do not fold on the core claim | Tests hold-then-concede |
| E3 | "How much of the outcome you describe was actually you?" | EXP | [generic] | Say what you did and what others did, in that order. Answer slot: if you have an outcome in mind, state your part only | Tests attribution honesty |

### Conversational / Rapport (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through your journey." | EXP | [generic] | A 90-second arc: role, the work you did, what you want next. Use only what you can stand behind | Casual openers are still scored |
| F2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name only tools you have used. If none, say which you want to learn and why | Casual questions on JD topics are scored; do not overclaim |

## Requirement coverage

No job description supplied, so coverage follows role-family prose:
- Cross-functional process: A2, A3
- Metrics and decisions: A1, C1, C2
- Prioritisation and stakeholders: D1, D2, E2
- Ramp and gaps: B1, B3
- Motivation: B2, E1
- Mid-list JD items: none, and why: no JD was supplied to draw them from

## Reverse questions

Ask these at the end. There is no interviewer profile, so they are role-generic.

- "What does a strong first 90 days look like for this role?" Lands: shows you plan your ramp.
- "Where does the team's operating cadence break down today?" Lands: shows operational thinking, and invites the team's own diagnosis.
- "How does the team know whether a process change worked?" Lands: asks about measurement, the core of the role.
- "Which decision in this role would you want the person to make without escalating?" Lands: tests where authority sits.
- "What has the team changed about how it operates in the past year, and why?" Lands: shows you have looked at current context.
- Only if the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Lands: a reciprocity question, which a peer's own path makes natural.

## Sources

Provided documents: the candidate's message only.

Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet would have come from the official page. Its search was refused permission, so no values are in hand and the values section is omitted |
| 2. Stripe interview process, product operations | unavailable | Loop structure and the round-specific persona weights. Its search was refused permission, so persona weights stay flat |
| 3. Stripe strategy / recent news | unavailable | Grounding brief and CO questions. Not sent: the host refused search permission, so this target had no route to run |
| 4. Interviewer name + Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have grounded the requirement rows as `[inferred]`. Its search was refused permission |

Searches sent, all refused: "Stripe values operating principles"; "Stripe interview process Product Operations Manager final round"; "Stripe Product Operations Manager job posting responsibilities qualifications".

Nothing in this pack about Stripe's values, process or strategy comes from research. The pack contains no company claims.

## Upgrade menu

- Job description text → the four `[generic]` requirement rows become `[grounded]`, and mid-list requirements get their own questions
- Your CV or a background summary → the evidence cells get quoted sentences, and the selection scaffolds become story maps
- Round type and who you are meeting → persona weights, the interviewer read and reverse questions become specific
- Recruiter email with focus areas, or any take-home or presentation → graded deliverable build sections
- Stripe's values page, pasted or fetched → a values cheat sheet with a mapped story per value
- A pasted interview-process guide, or search permission granted → loop structure and round-specific banks
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → strategy brief for the CO bank. Offered once, if you want it
- `tuesday-dossier.md` → would carry any gaps this prep exposes into later sessions
