# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Loop mode.** Three rounds on 5 December 2026: round 1 recruiter (30 min); round 2 Head of Member Services, your prospective manager (45 min, mostly behavioural); round 3 panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). Interviewers are not yet named for rounds 2 and 3, so their weights are relationship priors.

## How to use this pack, and the type key

Personas describe how a question arrives; types describe what it is scoring. The guidance is scaffolding for a spoken answer, not a script. An **answer slot** is an instruction for the interview: answer it in your own words, from your own experience, or say plainly the practice was not yours.

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether your CV's claims survive scrutiny, and what you actually did |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company's current strategy |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

Requirements and duties are quoted from the job description (JD). Evidence is quoted from your message, the only candidate source in hand. The strategy brief is quoted from your summary of it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Medium because your message is the only source; a dated record would raise it. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says the log, and calls it formal. It does not show whether the log carried regulatory steps. Answer slot: if it did, say which steps and how you applied them; if it did not, say so and say how you decided what happened next. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Your words: "I've never presented to anyone above regional level." Then how you would build to it, said as a plan and never as a past. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The bridge is your own sentence, unchanged: "I built the monthly complaints spreadsheet our regional manager uses." Add nothing to it. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The quote covers one branch's log, not an end-to-end process across branches. Answer slot, inside that scope: which steps of a complaint you ran from logging to closing; if you did not run them all, say which you did not. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Your words: "I have never worked in a contact centre." Then how you would learn one, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material shows a monthly spreadsheet. It does not show whether it counted volumes, resolution times, or both. Answer slot: if you reported either, say which and how it was counted; if you did not, say so and say what you would measure first. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | low | [inferred] | transferability | Training tellers is not coaching supervisors, so the bridge stops at the training. Answer slot: if you coached anyone on escalation decisions, say who and what you did; if not, say so and say how you would coach a supervisor. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams or self-service. Answer slot: if you worked on any self-service process, say what it was and your part in it; if not, say so and say how you would start with a digital team. |
| G1 | Place of work: the hub or branch the role sits in. Not in the JD; the brief says "consolidate eight branches into five hubs over 2027" — strategy brief | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work from the hub or branch this role sits in. The question that settles it is in the message that carries this pack. |
| G2 | Pay and notice terms. Not stated in the JD or the recruiter's email; standard round-one logistics | none given | none | [generic] | hard_gate | Your material does not establish pay or notice. The round-one logistics slots carry the answer in your own words. This pack supplies no figure. |

## Grounding brief (current strategy)

The brief is dated July 2026, under six months old on 26 November 2026, so it is current. You gave a summary, not the document, so these quotes are your summary's wording. No stale framing is flagged.

- **Targets:** "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "launch a small-business lending product in Q1 2027".
- **Competitive frame:** "the main competitive pressure is app-only banks".
- **Scale and form:** about 900 staff; member-owned (JD).
- **Vocabulary to use:** member service, digital channels, hubs, member-owned, small-business lending.
- **[inferred] What this may mean for complaints.** Derived from the brief's targets, not from any stated Ashgrove plan: app-originated complaints may rise as service moves to digital; a branch closing may move its open complaints to another branch; the small-business product may bring complaint types the brief does not describe.

## Persona weights and counter-strategies

| Persona | Shows up in | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Round 1 (R1 to R3) | Recruiter-screen prior. Casual questions are still scored. | Ninety-second arc for the journey question; treat every casual question on JD topics as scored. |
| Skeptic | R8, H6 to H8 | Hiring-manager prior. Your stated gaps (F3, F6) are where a skeptic goes. H6 is the deepest rehearsal in the pack. | Plain acknowledgment, then a plan. Hold through two follow-ups; concede specifically. |
| Values/Behavioral | H1 to H4, P1 to P4 | The round-two manager's round is mostly behavioural; the panel scores against the four values. | Selection scaffolds where no quote carries a story; "we" for context, "I" for your contribution. |
| Case/Strategist | H9, H10, P5 to P7 | The 20-minute escalation case is live; the consolidation and digital targets are live roadmap issues. | Clarify, objective, segments, approach, metrics, risks. Think aloud. |
| Peer Evaluator | P8, P9 | Branch managers are near-peers for the seam with the contact centre. | Seam principles, not claimed seams. |
| Pressure | P10 to P12 | The panel is time-boxed. | Hold through two follow-ups, then concede the specific thing you do not know. |

## Round 1: recruiter screen (30 minutes)

Weights: Conversational 3 (R1 to R3), Skeptic 1 (R8), recruiter logistics 4 (R4 to R7, the recruiter's own slots).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message | Ninety seconds: six years in retail banking, the last three as a branch supervisor, then the branch's formal complaints log. Stop at the branch. Say the rest in your own words. | A casual biography, still scored. F1 and F5 give it its beats and nothing beyond them. |
| R2 | "What do you know about Ashgrove?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief | Name one item from the brief in your own words, and what it means for complaint handling. Do not claim a role in it. | A light CO check. The brief is the only research in hand, so keep to it. |
| R3 | "What are you playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | Say what you built and who uses it, in those words. Name a measure only if you tracked it (see F7). | The Excel requirement (F4), asked casually. |
| R4 | "Why are you looking to move?" | EXP | [generic] no reason stated | Logistics slot. Give your actual reason in one plain sentence, once. | The recruiter's reason-for-leaving logistics. No reason was given, so the slot is an instruction. |
| R5 | "What's your notice period?" | JD | [generic] no notice stated | Logistics slot. Give your actual notice period. | A knockout check. The figure is yours to give; the pack supplies none (G2). |
| R6 | "What pay are you expecting?" | JD | [generic] no pay stated | Logistics slot. Ask for the role's band first, then give your own figure. If asked what you earn now: "I'd rather focus on the range for this role." | A pay slot with no figure supplied (G2). The line declines without a number. |
| R7 | "Could you work from the hub or branch the role sits in?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief | Logistics slot. Say yes, no or not yet. If you do not yet know which hub the role sits in, ask before you answer. | Place of work is a gate (G1), and the strategy makes the hub question live. |
| R8 | "What would be hardest for you in this role?" | JD | [grounded] "Never worked in a contact centre" — your message; "I've never presented to anyone above regional level." — your message | Name one gap, not both, unless asked: "I've never worked in a contact centre." Then a plan for learning it. | A light Skeptic line. It reaches for the stated gaps F6 and F3. |

Reverse questions, round 1:

| Question to ask | Why it lands |
|---|---|
| "How is the thirty minutes weighted against the other two rounds?" | Shows you are reading the process, not only the role. |
| "Which of the four values do candidates most often find hard to show?" | Turns the values round into a discussion and shows where to slow down. |
| "Who will I meet in rounds two and three, and what is each person's remit?" | Gets the names the upgrade menu asks for, and shows preparation. |
| "What does a typical month of complaint volumes look like?" | A concrete number to test your answer to F7 against. |
| "What would you want to hear from me in this round to move me on?" | Asks directly how the screen is scored. |

## Round 2: Head of Member Services (45 minutes)

Weights: Values/Behavioral 4 (H1 to H4), JD requirement questions in the behavioural register (H5, H11), Skeptic 3 (H6 to H8), Case/Strategist 2 (H9, H10).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt; nearest thing: "trained new tellers on our escalation script" — your message | Own the Fix. Pick a time you told someone senior what they did not want to hear, with the stake and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries and say which part was yours. | The Own the Fix theme. No quoted sentence carries this story, so the honest branch is written in. |
| H2 | "When did you put a member ahead of a process or a target?" | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Members First, Always. Answer slot: if you chose a member's outcome over a process or a target, say what you decided and why; if no such decision came up at the log, say so and say how you would decide one. | F5 scopes the log to one branch, so the decision has to be yours to claim. |
| H3 | "Tell me how you explained a rule to a colleague who had got it wrong." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Plain Words. Say the script's first line in plain words, as you taught it. Answer slot: if you checked new tellers had understood it, say how; if you did not, say so. | The Plain Words story is the training beat the sentence states. F8 sets its scope. |
| H4 | "Tell me about a decision that looked right on the numbers but cost a town something." | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief | Neighbours, Not Numbers. No quoted sentence carries this story. Pick a decision where a branch's place in its town and the numbers pulled apart. If none, say so, and say how you would weigh a closure against the numbers. | The brief's consolidation raises the value; the scaffold ends in the honest branch. |
| H5 | "Walk me through how a formal complaint moved through your log, and what rules set its deadlines." | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot (F2): if rules set deadlines, name them and how you tracked them; if none did, say so and say how you decided what came next. | The regulated-complaints requirement. "Regulated" is in the JD, not in your sentence, so the deadlines are asked, not assumed. |
| H6 | "This role owns complaints through the contact centre, and you've never worked in one. What would you do in your first 90 days?" | JD | [grounded] "Never worked in a contact centre" — your message | Highest-ROI rehearsal. Plain acknowledgment: "I've never worked in a contact centre." Then the ramp, as a plan: what you would learn first about how contacts reach the centre and how a complaint moves from it to a branch, and who you would learn it from. Hold through two follow-ups by returning to the ramp. Concede specifically: "I don't yet know how the centre's queue works; I'd learn it in the first fortnight." Never describe contact-centre work as something you did. | The most predictable objection: the JD puts the centre inside the owned process (F6, capability). Deepest rehearsal in the pack: run it through three follow-ups. |
| H7 | "The role means presenting to senior leaders. What would you do before your first presentation to them?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: what you would prepare, what you would show first, who you would rehearse with. Hold one follow-up; concede that you have not done it. | The stated gap F3. The JD's presenting requirement needs its own question. |
| H8 | "What draws you to this role?" | EXP | [generic] no reason for this role stated | Give the reason you actually have, in one sentence, and make it match your round-one answer on leaving. If you cannot yet say it in one sentence, say so and give the nearest reason your material carries: "I handled the branch's formal complaints log" — your message. | Motivation consistency, the Skeptic's favourite line. No reason is stated, so the guidance asks for yours. |
| H9 | "A member can't find where to report a long wait in the app, so they phone the branch instead. What would you change, and who would you work with in the digital team?" | JD | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief | Case delivery. Clarify the journey and where it breaks. Objective: fix this member's problem and the journey's cause. Approach: map the journey with the digital team; name what you would ask them and what you would bring. Metrics: time to resolve, repeat contacts. Risk: a fix that moves the queue to the phone. Answer slot (F9): if you have worked with a digital team on any journey, say what it was and your part; if not, say so and say how you would start. | The self-service requirement (F9, discovery). The brief's 40% target makes it likely. The case itself makes no claim about your past. |
| H10 | "Ashgrove plans to consolidate eight branches into five hubs in 2027. What happens to the complaints from the branches that close?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief | Think aloud. Clarify which complaints move with a closing branch and which stay. Structure by complaint type. Name the risks: lost local knowledge, and escalations with no local owner. Ask one question about the hub design. Do not assert Ashgrove's plan. | A CO question grounded in the brief. The consolidation makes it likely for a manager. |
| H11 | "Walk me through what your monthly complaints spreadsheet counts." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | Answer slot (F7): say what it counts, in your words. If it tracked resolution times, say how they were counted; if not, say so and say what you would measure first. Never name a measure it did not track. | The monthly reporting duty (F7, discovery). |

Reverse questions, round 2:

| Question to ask | Why it lands |
|---|---|
| "What does a good first 90 days look like for this role?" | Turns H6 into a plan conversation. |
| "Which escalations reach you today that you would most like handled earlier?" | Shows you think in the manager's queue. |
| "When a branch closes in the hub plan, who owns its open complaints?" | Tests H10 with the person who would own the answer. |
| "What did the last person in this role find hardest?" | Names the real gap and shows you want to learn it. |
| "What would you need to see from me in the first month to think I'm on track?" | Reveals the success criteria. |

## Round 3: panel of two branch managers (60 minutes)

Weights: Values/Behavioral 4 (P1 to P4), Case/Strategist 3 (P5 to P7), Peer Evaluator 2 (P8, P9), Pressure 3 (P10 to P12). The recruiter says the panel scores against the four values, and the 20-minute case is time-boxed. The two branch managers are near-peers for the seam with the contact centre.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time a member's complaint changed what you did at your branch." | VAL | [generic] open prompt; nearest thing: "I handled the branch's formal complaints log" — your message | Members First, Always. Pick a complaint that changed a decision, a process or your own practice, and who made the change. If none comes to mind, say so plainly, then say which part of the log you did yourself. | The values round. No quoted sentence carries a member-side decision, so the honest branch is written in. |
| P2 | "A member says your letter is unreadable. Show us how you would rewrite its first sentence." | VAL | [generic] live problem | Plain Words. Ask what the sentence is for, then rewrite it in fewer words and read it aloud. No past claim is made. | A live test of Plain Words. Practise on any letter you have. |
| P3 | "Tell me about a problem you found and kept hold of until it was fixed." | VAL | [generic] open prompt; nearest thing: "I handled the branch's formal complaints log" — your message | Own the Fix. Pick a problem you found, what you kept checking, and what ended it. If none comes to mind, say so plainly, then say which steps of the log you carried through, if any. | The Own the Fix theme. No quoted sentence states a fix, so the honest branch is written in. |
| P4 | "How do you keep a branch's place in its town in view when it is consolidated?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief | Neighbours, Not Numbers. Say what you would check with a branch's staff and members before a change, as a plan. If you have a story where a branch's place in its town and the numbers pulled apart, say it; if not, say so. | The brief raises it. Your material has no story for it. |
| P5 | "A member's complaint about a fee has been open three weeks, and they now say they will go to an external ombudsman. Walk us through your next twenty minutes." | CASE | [generic] hypothetical case | Clarify the complaint, its status and which regulatory timeline applies. Objective: answer the complaint on its facts, inside the timeline. Segments: the member, the branch's handling, the policy. Approach: check the file; read the complaint back; decide who owns the decision; tell the member what happens next, in plain words. Metrics: days open, whether it was logged as formal, whether the member has a reply. Risk: a policy answer that does not address the complaint. Think aloud and name the owner. | The announced 20-minute case. It asks about no past and presupposes nothing about you. |
| P6 | "Your branch manager says the fee is policy. What do you do?" | CASE | [generic] hypothetical follow-up | Pressure within the case. Hold: the complaint is answered on its facts, whatever the policy says. Check first that the fee was applied correctly. Concede specifically: "I'd check the policy wording before I agree or disagree with it." Hold through two follow-ups. | The pressure sits in the case, not in your history. The hold is about the complaint. |
| P7 | "What would you change so this complaint does not happen again?" | CASE | [generic] hypothetical follow-up | Name one change to where complaints are logged and who can see them, and one change to the handover between branch and centre. Do not describe any system as Ashgrove's. | Closes the case, and links to the escalation coaching in P12. |
| P8 | "Our teams sit side by side. Where is the seam between a branch and the contact centre, and what happens when you disagree with us?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Seam principles, not claimed seams: one rule for who owns a complaint at the handover. On disagreement, name a principle, not a story. If you have a real example of disagreeing with a peer team, say it in your own words. | The Peer Evaluator's seam probe. The contact-centre gap (F6) sits underneath it, so do not claim seam experience. |
| P9 | "How do you handle credit when a fix spans teams?" | VAL | [generic] open prompt; nearest thing: "I built the monthly complaints spreadsheet our regional manager uses" — your message | Pick a fix that spanned teams. If none comes to mind, say so, then say how you would split credit: name who did what, in the order it happened. Do not claim a shared fix you did not run. | The Peer Evaluator's credit probe, with Own the Fix behind it. |
| P10 | "Sixty seconds: why should we hire you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then sixty seconds: what you have done that maps to the job, in its own quoted words; then the ramp, as a plan. Hold one follow-up; concede specifically. | The stated gap F6, under a time box. |
| P11 | "That spreadsheet your regional manager uses. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | Premised on your own sentence. Hold: "I built it." Say what you built, in those words, through two follow-ups. Concede what you do not know: anything changed since you built it, or how the regional manager uses it. Add no measure. | Attribution probe on F4 and F7. The premise is your own quote. |
| P12 | "A supervisor on your team escalates every complaint to you. How do you coach that?" | JD | [grounded] "trained new tellers on our escalation script" — your message | Answer slot (F8): if you coached a supervisor on escalations, say what you did; if not, say so and say how you would coach one. Give the coaching method as a plan. | The JD's coaching duty. F8 is low confidence, so no coaching claim goes beyond the training. |

Reverse questions, round 3:

| Question to ask | Why it lands |
|---|---|
| "What do the branch managers here see most often in escalations that never reach the centre?" | A peer's question about the seam. |
| "What could a new person do in their first month that would genuinely help your teams?" | Reciprocity, the peer question the panel expects. |
| "Where does a branch complaint usually get stuck today?" | Shows you want the handover's real problems. |
| "How does the panel weigh the values round against the case?" | Tells you what the scores will rest on. |
| "If the hub plan goes ahead, which branch's complaints would you worry about first?" | Places you inside the town-level question. |

## Requirement coverage

| JD requirement, duty or gate | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1 |
| Experience handling regulated complaints | H5, P5 |
| Confident presenting to senior leaders | H7, P10 |
| Comfortable with Excel reporting | R3, H11, P11 |
| Own the complaints process end to end across branches and the contact centre | H6, P8, P10 |
| Report monthly on complaint volumes and resolution times | H11, R3 |
| Coach branch supervisors on escalations | P12 |
| Work with digital teams on self-service journeys | H9 |
| Value: Members First, Always | P1, H2 |
| Value: Plain Words | P2, H3 |
| Value: Neighbours, Not Numbers | P4, H4 |
| Value: Own the Fix | P3, H1 |
| Gate: place of work | R7 |
| Gate: pay and notice | R5, R6 |

## Values cheat sheet

Round 3 is the values round: the recruiter says the panel scores against the four values.

| Value (official name) | Working meaning | Candidate's mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold; no quoted sentence carries a member-side decision. Pick a complaint that changed a decision. If none, say so plainly, then the nearest thing your material carries: "I handled the branch's formal complaints log" (F5). Keep it to that scope. |
| Plain Words | If a member needs it explained twice, the writing failed. | Mapped on F8: "trained new tellers on our escalation script". The story is the script you taught. Say its first line in plain words. If you checked understanding, say how; if not, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold with the honest branch; no quoted sentence speaks to a town. Pick a decision where a branch's place in its town and the numbers pulled apart. If none, say so, and give your plan for weighing a closure. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold on F5: pick a problem you found and kept hold of. If none, say so, and say which steps of the log you carried through, if any. |

## Prohibited claims

Built from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, slot, hold or rationale in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run complaints end to end across branches and the contact centre | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material shows one branch's log. No first-person negative. |
| Has regulated-complaints experience | Inflated form of F2 | F2's quote at its own scope. The regulatory step is an answer slot with both branches. |
| Has presented to senior leaders | Negative you stated, F3 | "I've never presented to anyone above regional level." No slot asks about presenting experience. |
| Has worked in a contact centre | Negative you stated, F6 | "I have never worked in a contact centre." No slot implies contact-centre practice. |
| Has reported resolution times | Inflated form of F7 | F7's quote. The spreadsheet is named; its measures are an answer slot. |
| Has coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope. |
| A current salary, a pay figure or a pay floor | Logistics rule: no figure the candidate did not give | The pack never supplies or estimates a figure. The slot is "ask for the band first" or your own figure. |

## Sources

- **Provided documents:** the job description and your background (your message); the Ashgrove values, copied from ashgrovecu.org/about/values on 26 November 2026 (your paste); the recruiter's email on the process (your paste); the July 2026 strategy brief, as your summary of it (your paste; the document itself is not in hand).
- **Research tier:** Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values page you pasted fixes the values cheat sheet's names and meanings. |
| 2. Ashgrove interview process, member experience lead | skipped | Your recruiter's email names the three rounds, their lengths, and that round three scores against the values. That establishes the loop, so no archetype fallback applies. |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief you summarised is under six months old, and fixes the grounding brief and the CO questions. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so there is no query to form. The interviewer read is absent. |
| 5. Representative member experience lead JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

No search or fetch was sent. Research at deeper tiers would add only what the upgrade menu names.

## Upgrade menu

- Your complaints log or spreadsheet, as a file or as counts you are allowed to use → F4 and F7 move from medium toward high, and H11 can be answered from the artifact rather than from memory.
- The names of the round-two and round-three interviewers → persona weights from their public footprint, and a tailored reverse question.
- The recruiter's agenda for the three rounds, if they send one → each round's weights checked against what they say it covers.
- A CV, if you want it checked → F1 to F8 quote from a document, and the medium-confidence rows can be graded against it.
- A `tuesday-dossier.md` carrying confirmed claims → would replace your message quotes with verified evidence, and name an objection from them.
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several minutes, for recent organisational context and the interviewers' public footprint once their names are known. Want it?
