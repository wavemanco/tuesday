# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: first 15 on a spoken POV, no slides, then Q&A with Ross pressing on commercials. Interviewer names are first names only, so no interviewer profile was built.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- CASE: a live problem, scored on structure and reasoning
- EXP: your past work, scored on whether it survives scrutiny and what was actually yours
- JD: the role's stated requirements
- CO: company and strategy knowledge (none rehearsed here; research was refused, see Sources)
- VAL: values (no values-style round was detected, so none is rehearsed)

Guidance is scaffolding, not a script. Rehearse out loud. Anything in quotation marks in the Provenance column is your own sentence from your message to me.

## 3. Prep triage (four hours)

1. First hour and fifteen minutes: write the POV from section 5. Pick T1 with T2 as its mechanism, and write its concession in your own words. Speak it twice with a timer at twelve minutes.
2. Next forty-five minutes: Ross's bank, B1, B2, B5, C1 and C2, out loud. Answer each in under two minutes and hold the number to exactly what you said.
3. Next forty minutes: Deepa's bank, D1 first (the highest-return prep in this pack), then A4 and A1.
4. Next forty minutes: one full run. POV, then twenty-five minutes of questions, ideally with a drill partner or the drill offered below.
5. Last forty minutes: reverse questions and the opening arc, E1. Stop early and sleep.

Everything else is insurance.

## 4. Fit snapshot

The panel's requirements come from the recruiter's own words, since no job description was supplied. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — your message (recruiter's email) | "so I know the operator world from the other side" — your message | medium | [grounded] | transferability | Your material places you on the operator side through transport consulting, not in operator partnerships. Words: "I know the operator world from the other side." Answer slot: if you can name one decision on the operator side that you influenced, say what it was and what you would decide differently now. |
| F2 | "what it means for the operators themselves" — your message (recruiter's email) | "running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Channel scale in payments, not operator outcomes. Words: "I took it from 6 partners to 40," with "it" meaning the ISV channel, at that scope. Say what the operator got, if you can. Otherwise say the channel was not an operator programme. |
| F3 | "Ross will push on commercials." — your message (recruiter's email) | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is influenced, not sourced, and your material does not show how it was counted. Answer slot: how it was counted; if you know, say it in your own words, and if you do not, say so. |
| F4 | commercial accountability for a revenue target — [generic] | "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | capability | Words: "I've never carried a direct quota." Then how you would build a revenue target for rail operators, as a plan and never as a past. |
| F5 | selling into rail operators — [generic] | "Never sold into rail specifically" — your message | medium | [grounded] | capability | Words: "I haven't sold into rail." Then how you would learn it, as a plan, and in what order. |

Gates: your message names none, and the recruiter's email names none. Nothing in the material settles location, notice or right to work.

Rules these rows follow: the quotes are your own words only; the requirement in quotation marks is the recruiter's; the role-family requirements are unquoted prose.

## 5. Graded deliverable: the 15-minute POV

The recruiter declared this: a short POV on where you would take operator partnerships over eighteen months, landing on what it means for the operators themselves, with no slides.

Facts you can build on: F1 and F2, both quoted from your message.

Three theses, each with its concession:

- T1, [generic]: anchor partnerships on one performance measure that the operator already reports, and let that measure choose the first partner. Concession: the measure may belong to an owner outside the commercial team, and a single measure invites gaming.
- T2, [generic]: run one joint pilot per operator, timed to the annual timetable change, before any wider programme. Concession: it is slow and lumpy, and Ross will press on revenue timing.
- T3, [generic]: partner with operator-data specialists so operators get integration without buying a platform. Concession: margins are thin, and it may cut against the company's own product.

Recommendation: T1, with T2 as the mechanism. Differentiation: I have not seen the internal market report, so I cannot say which consensus answer it reaches. Paste it (question 1 below) and this section gets rewritten against it. The anti-pick, which works whatever the report says: "I would decline any operator who will not name an owner for the measure."

Close: what it means for the operators. Frame it as one measure they report, and how they would see it move within a planning cycle. Answer slot: name the measure the operator actually uses. Do not guess it in the room.

Shape for twelve minutes, leaving three for questions: the operator's problem (two), T1 with T2 (five), the concession (two), what it means for the operator (two), how you would know it is working (one).

## 8. Persona table

Panel: each member's top two personas, from relationship priors, since no interviewer profile was built.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | A live operator problem, time-boxed | High: a future manager's prior puts a live problem first | Clarify, then structure, then one metric |
| Pressure | Ross | Interrupts, challenges the number | High: the recruiter said Ross will push on commercials | Pause, restate, hold two follow-ups |
| Data-Driven Prober | Ross | Asks how the £4M was counted | Medium-high: the commercial signal, plus the figure's wording | Defend-the-number, weakest assumption first |
| Skeptic | Deepa | Rail gap, why here | Medium: the rail gap is the obvious probe | Plain acknowledgment, then a ramp plan |
| Conversational | Either | A friendly "walk me through" | Medium: a common opener | Ninety-second arc |

Not weighted: Values/Behavioral (no values-style round in the recruiter's words) and Peer Evaluator (neither member is a peer).

## 9. Question banks

Weights: Case 5, Pressure 5, Prober 3, Skeptic 3, Conversational 2. Total 18.

### Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A train operator's disruption-recovery times are getting worse. Is a partnership the right lever, and how would you decide?" | CASE | [generic] | Clarify what "worse" means to them and who owns the number. Then the objective, the segments of operator, two or three approaches, the one metric you would watch, and the main risk. Name the framework once, then stop using its vocabulary. | A live problem from the POV's own territory. It makes no claim about your past. |
| A2 | "Sketch your first 90 days with an operator that has never bought from us. What do you need to know first?" | CASE | [generic] | Open with questions: who signs, who owns the problem, what they already run. Then three actions in order, each with the signal that would tell you to stop. | Structure under a new-account frame. No operator is named, so nothing is assumed. |
| A3 | "Which operator would you start with, and why not the largest?" | CASE | [generic] | Pick on reachability of a named owner and a measurable pain, not on size. Say what would change your mind. | Tests the POV's operator focus. No research on the company's customers was possible this session. |
| A4 | "You took the ISV channel from 6 partners to 40. Walk me through how that happened." | EXP | [grounded] "took it from 6 partners to 40"; [grounded] "running the ISV channel" | Story-mapped on the quote: the channel, the six, the forty. Answer slot: if a decision about partner selection or terms was yours to set, say which and why; if it was set by someone else, say so and describe what you did inside it. | F2 is your strongest transferable evidence. EXP because it tests what was yours. |
| A5 | "What would you need to know about an operator before proposing a joint pilot?" | CASE | [generic] | Name the problem's owner, the timetable calendar, the procurement route, the data access, and the measure the operator already reports. Ask for the measure before proposing a shape. | Forward-looking, and it sets up T1 and T2 in the POV. |

### Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "That £4M. How much of it did you actually create?" | EXP | [grounded] "roughly £4M of influenced revenue" | Defend the number: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so in your words; if not, say so plainly. The pack supplies no method. Hold by repeating the same number and the same word, influenced. | Ross will press commercials, and this is the likeliest probe. |
| B2 | "You've never carried a direct quota. Why should I trust you with my number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment: "I've never carried a direct quota." Then what you did carry, in the quote's words: "only influenced revenue." Hold through two follow-ups by returning to that sentence. Concede that rail commercial terms are new to you, and offer a plan, not a past. | The stated gap a commercial director will find first. Holding it without spin is the point. |
| B3 | "Sixty seconds: why would an operator pay us for a partnership instead of building it themselves?" | CASE | [generic] | Pause, restate, then answer in the POV's terms: what the operator avoids, and what it gets sooner. Concede one thing it would not get. | Pressure on the POV's core claim, and it can be asked of any thesis. |
| B4 | "Which of your three theses would you drop if the commercial case fails?" | CASE | [generic] | Name the thesis you would drop first, and why: the one with the most fragile operator owner. Hold the others. | Tests whether the POV is held as judgment or as a script. |
| B5 | "Your £4M is influenced, not sourced. Would you put it in front of our board?" | EXP | [grounded] "roughly £4M of influenced revenue" | Give the same number with the same word, influenced. Say what it would take to report it as sourced. Do not restate it as sourced. | The attribution probe, held without drift. |

### Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the £4M counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how it was counted in your own words if you know. If someone else did the counting, or you do not know, say so plainly. | Defend-the-number slot, asked in the most neutral form. |
| C2 | "Which assumption behind your £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the weakest assumption before they do, in your own words. If you cannot name one, say so. | The weakest-assumption move, which turns a gotcha into a credibility gain. |
| C3 | "What does 40 count: partners signed, or partners that brought revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Give the definition you know. If you do not know it, say so. Do not invent an active count. | Tests whether the 40 means what it appears to. |

### Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never sold into rail. Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I haven't sold into rail." Then the ramp plan: what you would learn first, from whom, and by when. A plan, never a past. Deepest rehearsal: two follow-ups, a specific concession each time, and no folding on the operator-side view. | The highest-return prep in this pack. The rail gap is the most predictable objection, and Deepa is your future manager. |
| D2 | "Five years in transport consulting, then nine in partnerships. What's the through-line?" | EXP | [grounded] "5 years in transport consulting"; [grounded] "9 years in partnerships" | State both quotes in your own words, and say the through-line is the operator-side view plus the channel. Do not claim it is more than that. | Motivation consistency under the Skeptic's "why here" probe. |
| D3 | "Operators will ask what you have done on their side of the table. What do you say?" | JD | [grounded] "so I know the operator world from the other side" | Use the operator-side sentence in your words. Do not claim operator experience you did not state. Say the limit plainly. | An open prompt on the recruiter's own theme. It tests the same gap as D1 from another angle. |

### Conversational (either)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; [grounded] "5 years in transport consulting" | A ninety-second arc: transport consulting, the operator side, partnerships, the ISV channel, then one sentence on why this role. Use the quoted beats only. | A casual opener is still scored. Pre-script it. |
| E2 | "What are you reading on operators at the moment?" | JD | [generic] | Name one source you have actually read and say what it changed in your thinking. Do not name a source you have not read. | Casual, on a hot topic, and scored. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1, recruiter: "over the next 18 months" | POV section 5; A1, A5, B4 |
| R2, recruiter: "what it means for the operators themselves" | POV close; A3, D3 |
| R3, recruiter: "Ross will push on commercials" | B1, B2, B5, C1, C2, C3 |
| Rail selling, [generic] | D1, D3, F5 |
| Partnership scale and management, [generic] | A4, E1 |

Nothing in the requirement list is uncovered.

## 11. Reverse questions

Each one carries its reason.

1. To Deepa: "What would you need to see in the first 90 days for this hire to be working?" It shows you plan to be measured.
2. To Deepa: "Which operator relationship would you most want the new hire to strengthen first, and what is wrong with it today?" It shows you have taken the POV's operator focus seriously.
3. To Deepa: "What have the people in this role found hardest so far?" It respects their experience and derisks the question.
4. To Ross: "How is partnership revenue attributed today: sourced, influenced, or something else?" It shows commercial fluency and settles the definition before B1 arrives.
5. To Ross: "Which contract renewals in the next eighteen months carry the most commercial risk?" The answer tells you what the POV's commercial case has to survive.

A reverse question tied to Deepa's own path needs a profile, which was not built. See the upgrade menu.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry names its basis, and each honest form is what the pack will coach instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Stated negative, F5 | "I haven't sold into rail." No slot. |
| Has carried a revenue quota | Stated negative, F4 | "I've never carried a direct quota." No slot. |
| Drove £4M of revenue | Inflated form of F3 | "roughly £4M of influenced revenue," with the counting method as an answer slot. |
| Built the partner programme that took the channel from 6 to 40 | Inflated form of F2 | The quote at its own scope. Your material says the channel grew, not who designed its model. |
| Knows operators' timetabling and disruption from the inside | Inflated form of F1 | "I know the operator world from the other side," at that scope. |

## 14. Sources

- Provided documents: your message, including the recruiter's email as you pasted it. You told me you have read the internal market report; I have not seen it.
- Searches: three sent, all refused by the host before returning anything. No fetches were made.

Research tier: L1, searches 3 of 6 (all refused), fetches 0 of 2, user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused: query "Kelverton Rail values". No values-style round detected, so no cheat sheet. |
| 2. Kelverton Rail interview process | unavailable | Refused: query "Kelverton Rail interview process partnerships". The recruiter's email is a loop source and establishes the panel, so no archetype fallback is used. |
| 3. Kelverton Rail strategy | unavailable | Refused: query "Kelverton Rail strategy news scheduling train operators". Would have moved the CO bank, which is generic as a result. |
| 4. Deepa or Ross, public footprint | unavailable | No search sent. First names with a title and company form a query, so this is not n/a. Would have moved the persona weights and a path-tied reverse question. |
| 5. Representative JD for the title | unavailable | No search sent. No JD was supplied, so the fit snapshot rests on the recruiter's words. |

Everything about Kelverton Rail in this pack is generic or from your message. Nothing about the company, its values, its operators or its strategy has been verified.

## 15. Upgrade menu

- The internal market report's headline argument → the POV gets rewritten to diverge from it, and B4 is retuned to the report's own theses.
- The job description → the fit snapshot's recruiter-sourced rows move to JD lines, and the JD-tagged questions get real requirements to cover.
- Your CV → F1 to F5 quote your CV's sentences rather than your message, and A4 and E1 sharpen.
- Working web search → the values, interview-process and strategy targets run, and A3 and B4 gain real company strategy to stand on.
- Deepa's and Ross's full names or public profiles → personas are reweighted from their footprint, and one reverse question is tied to Deepa's path.
- Notes from the recruiter on whether the POV should name an operator or a segment → T1 and T2 are reshaped to match.
