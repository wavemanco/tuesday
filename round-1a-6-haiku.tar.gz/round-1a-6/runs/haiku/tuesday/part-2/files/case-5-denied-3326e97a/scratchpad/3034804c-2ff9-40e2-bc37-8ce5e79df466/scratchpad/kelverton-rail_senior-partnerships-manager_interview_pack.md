# Kelverton Rail: Senior Partnerships Manager, second-round panel

**Interviewers:** Deepa (VP Partnerships, your future manager; hiring-manager relationship) and Ross (Commercial Director). Format: 60 minutes. First 15 minutes is a spoken POV with no slides; the rest is Q&A, and Ross will push on commercials.
**Changes since last version:** first version.

## 1. How to use, and type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

- **JD:** can you do the listed job, including its gaps
- **EXP:** do your past claims survive scrutiny, and what exactly was yours
- **CO:** company and strategy knowledge (no company research ran; see section 14, so every CO row is generic)
- **CASE:** structure and reasoning on a live problem

## 2. Prep triage (about four hours)

1. **Write the POV, 90 minutes.** Choose one of T1 to T3 in section 5. Write its concession sentence and its operator-outcome close in your own words, then speak it aloud at 15 minutes. Do it twice.
2. **Rehearse B1 out loud, three times, 30 minutes.** This is the highest-ROI prep in the pack: the plain acknowledgment, then the six-month plan.
3. **C1 and D2, 30 minutes.** Write down how the roughly £4M was counted, in your words. If you do not know the counting method, write that down; it is an honest answer.
4. **C2, 20 minutes.** The no-quota hold: say the negative once, then hold.
5. **A1, 30 minutes.** Walk the CASE order aloud: clarify, objective, segmentation, approach, metrics, risks.
6. **Reverse questions and the D1 and D3 answer slots, 20 minutes.**

Everything else is insurance.

## 3. Fit snapshot

The requirements below are the recruiter's own words, quoted from the email you sent. No job description was supplied, so there are no posting requirements yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40" (your message); "running the ISV channel" (your message) | medium | [grounded] | transferability | Words: "At the payments company I took the ISV channel from 6 partners to 40." Your material shows the growth of a partner channel, not an operator one. Answer slot: if any part of how you grew it carries to rail operators, say which part and why, in your own words; if none does, say so plainly and name the first thing you would test with an operator. |
| F2 | "Ross will push on commercials." (recruiter email) | "roughly £4M of influenced revenue" (your message); "never carried a direct quota" (your message) | medium | [grounded] | transferability | Words: "I have never carried a direct quota. What I have carried is influenced revenue, roughly £4M." Influenced revenue is adjacent to owned revenue and does not reach it. Answer slot: how influence was counted, and which part was yours. |
| F3 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | Words: "I've never sold into rail specifically." Then the plan, stated as a plan and never as a past: how you would learn rail buying. Never a claim to rail-sales work. |
| F4 | "Please land on what it means for the operators themselves." (recruiter email) | "bus and light rail network planning" (your message); "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Words: "Five years in transport consulting, on bus and light rail network planning." Answer slot: which side of the table you sat on, in your own words. The operator-side view is yours only if you worked on that side. |

**Gate rows:** none. The recruiter's email names no location, pay, notice or eligibility term, and no posting was supplied. If the posting carries one, it will need its own row.

## 4. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail sales experience | Negative you stated, F3 | "I've never sold into rail specifically." No slot on rail sales. |
| Carried a quota, or owned a revenue target | Negative you stated, F2 | "I have never carried a direct quota." |
| Generated, owned or delivered £4M of revenue | Inflated form of F2 | "roughly £4M of influenced revenue," at its own scope. Pack observation, not words for you: your material says influenced, not owned. |
| Built the ISV channel | Inflated form of F1 | "took it from 6 partners to 40." Your material says taking it, not building it. |
| Worked for, or advised, train operators | Inflated form of F4 | "bus and light rail network planning," with the side you sat on as an answer slot. |
| Knows how operators buy rail scheduling | Entailed practice, F4 | None. Pack observation only: your material says planning, not buying. |

## 5. Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "a short POV on where you'd take our operator partnerships over the next 18 months... Please land on what it means for the operators themselves." No slides.

**Grounded facts to build on:** F1 (the channel went from 6 partners to 40), F4 (the planning background), F3 (the stated lack of rail selling). Do not build a thesis on rail-sales experience.

**Thesis options. Pick one, and own it.**

- **T1. Judge operator partnerships by what changes in an operator's planning week, not by partner count.**
  - Grounded in: F4 (planning) and F1 (you know how a count grows).
  - Mandatory concession: "A count is easy to grow. I don't yet know which planning measure would show a change, and I would test that with operators before committing to it."
  - Differentiation: the likely consensus answer is more operators and more partners. The divergence is measuring at the operator's planning level. The claim that planning cycles run this way is [generic] pattern, not a fact about Kelverton's customers.
- **T2. Make the operator own its change, and make the partner own the first deployment.**
  - Grounded in: no quoted sentence. Label [generic] for the pattern. Answer slot: which part of your channel work covered first deployment, if any.
  - Mandatory concession: this moves delivery cost onto partners, who may not accept it, and it may slow the partner count.
- **T3 (the anti-pick). Decline operator partnerships that cannot show a planning change within 12 months.**
  - Grounded in: F2 (you have been measured on influenced revenue, not outcomes) and Ross's "push on commercials."
  - Mandatory concession: it costs near-term revenue and some operators. Say what you would give up, and by how much, in your own words.
  - Differentiation: most partnership leads will not say no in public. This is the one that answers Ross.

**Requested close (what it means for the operators themselves):** name one operator outcome in operator terms, and the test that would show it. Say it as a test, never as a result you have seen. Answer slot: if you have seen an operator outcome measured, name it in your words; if you have not, name the first measure you would put in front of an operator's planning team.

**Differentiation caveat:** the internal market report is not in hand, so the consensus answer is unknown. Bring one consensus item to show you read the ground, then one divergence with its reason. Upgrade menu line 2 would let this section name the consensus answer.

## 6. Persona table

Panel rule: blend the top two personas of each member's relationship.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | A live plan for the operators over 18 months | High. Deepa is the hiring manager and is buying capability; the POV is the live plan. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Skeptic | Deepa | "Where is the rail experience?" | High for one objection. F3 is the stated gap in the recruiter's own requirement. | Acknowledge the gap in one sentence, then give the plan. Hold, do not defend. |
| Pressure | Ross | Time-boxed challenges on the numbers and the quota | High. Commercial Director, and the recruiter said Ross will push on commercials. | Pause, restate the question, anchor in what you stated, hold two follow-ups, then concede the exact point. |
| Data-Driven Prober | Ross | Denominators and counting method on £4M and 6 to 40 | Medium-high. Those are the only metrics in your material, and a commercial director asks for them. | Name the weakest assumption before it is named for you. Say plainly where you do not know the method. |

Persona weights: Case 5 questions (top), Skeptic 4, Pressure 5 (top), Prober 4. Total 18, the floor for a session pack. No interviewer footprint was researched, so these weights rest on relationship priors and the recruiter's words.

## 7. Question banks

Provenance comes first in each row, and quotes every sentence the guidance rests on.

### A. Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the 18-month plan for our operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, what the partnership is for, what good looks like at month 18. Then objective, segmentation, approach, metrics, risks. Name one assumption you would test first. No claim about your past. | This is the POV's Q&A form. The recruiter's "our operator partnerships over the next 18 months" is the raising source; the question presupposes no past. |
| A2 | "An operator's planners say a partner's change took two weeks longer than promised. Diagnose it." | CASE | [generic] | Ask what "promised" meant and who promised it. Split the delay into the partner's work, the operator's approvals and the planners' process. Say which you would check first. | A live operator-side problem; it asks about process and claims nothing about you. |
| A3 | "Which operators would you start with, and why those?" | JD | [generic] | Name one segmentation axis you can defend (for example, how often a planning team changes timetables). Name two you would start with and what would make you drop one. | Tests the operator-first half of the POV without claiming knowledge of Kelverton's customers. |
| A4 | "Which rail operator segment is most ready for scheduling change, and what would make it move?" | CO | [generic] | No company research ran. Give your view as a hypothesis and say what you would check before trusting it. Do not name a segment as a fact about this company. | Company-strategy question with no researched strategy under it, so it is labelled generic. |
| A5 | "Your ISV channel went from 6 partners to 40. What would carry over to operators, and what wouldn't?" | EXP | [grounded] "took it from 6 partners to 40" (your message); "running the ISV channel" (your message) | Story-mapped on F1: the channel and the count, in the words you used. Answer slot: which part of how you grew it was yours to decide, and which you would test on operators first. If none would carry over, say so plainly. | Premised only on F1's quote. This is where the POV's partner model gets tested. |

### B. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What would your first six months look like?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I've never sold into rail specifically." Then the plan, as a plan: name the two buyer groups you would meet first and what you would learn from each. Hold through two follow-ups by returning to the plan. Claim no rail-sales work and no rail-buyer knowledge. | The highest-ROI objection. F3 is the stated gap in the requirement the recruiter named. Rehearse until the acknowledgment is boring. |
| B2 | "Your consulting was bus and light rail network planning. Whose side of the table were you on?" | EXP | [grounded] "bus and light rail network planning" (your message); "so I know the operator world from the other side" (your message) | Answer slot: say which side of the table you sat on, in your words, and who the clients were. If you were not on the operator side, say so and say what you saw from where you sat. Do not describe operator decisions as yours unless they were. | F4 is the mirror Deepa's "operators themselves" line lands on, and this question checks the relationship. |
| B3 | "Why would someone who has run a payments partner channel want to work in rail?" | JD | [grounded] "running the ISV channel" (your message); "bus and light rail network planning" (your message) | Give your motivation in your words: the operator problem you know from planning work, and the channel skill you would bring. Keep it to what those two quotes carry. | A motivation probe on the switch. F1 and F4 are the two sentences that answer it, and nothing is added to them. |
| B4 | "What's the first gap you'd fix, and how would you know you had fixed it?" | JD | [generic] | Name the rail-buying gap from B1 and one measure that would show it closed, such as an operator meeting outcome. Keep the measure a plan, not a result. | Closes the loop from B1 into a measure. Claims nothing about you. |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we trust the £4M? How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold, then concede. State the figure at its scope: influenced revenue. Say which part of the partner work was yours. Answer slot: how influence was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say plainly where you do not know the method. Hold through two follow-ups. | Pressure on the headline number. C1 and D2 are the defend-the-number slots for F2. |
| C2 | "You've never carried a direct quota. Why should we trust you with a commercial target?" | JD | [grounded] "never carried a direct quota" (your message); "roughly £4M of influenced revenue" (your message) | Plain acknowledgment: "I have never carried a direct quota." Then hold: what you have carried is influenced revenue, roughly £4M, and how you would own a number, stated as a plan. Concede the gap, not the claim: there is no quota record, and influenced revenue is not dressed up as one. | Pressure at its most likely point. The concession is exact and limited to the negative you stated. |
| C3 | "Operators run on thin margins and fixed contracts. What is a partner worth to them?" | CO | [generic] | Do not assert operator margins as fact. Answer with the economics you would test: what the operator saves in planning time or disruption, as a hypothesis. | A commercial live question. Generic because no operator finance was researched. |
| C4 | "What is the one commercial number you would put in front of me on day one?" | CASE | [generic] | Pick one number tied to the operator outcome in your POV close, say what it would hide, and state your concession. | Ross tests the commercial side of the POV. Asks for no past claim. |
| C5 | "What would you walk away from?" | JD | [generic] | Name one kind of operator or partner deal you would refuse, and what it costs you. | The role's real job includes saying no. This is the POV's anti-pick, asked cold. |

### D. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the 6-to-40 count made? What counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say how a partner was counted, and when, in your words. If you do not know the definition, say so. If you do, say what it leaves out. | Defend-the-number on F1. The Prober asks for the denominator the count sits on. |
| D2 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Weakest-assumption move, in your words, before it is named for you. If you do not know how influence was counted, say that. | Defend-the-number slot for F2. It turns a gotcha into a credibility gain. |
| D3 | "Of the 40, how many did you bring on yourself?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: give the split if you know it, in your words. If some partners were already there when you arrived, say so. | The premise is only that you took the channel from 6 to 40. The split is an answer slot, not a fact. |
| D4 | "What commercial metric would you use for a rail partner programme?" | CO | [generic] | Pick one leading and one lagging measure, and say which you would trust less. | Metric design on the Prober's own terms. No researched strategy under it. |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | Section 5; A1, A3, A5, B4 |
| "Please land on what it means for the operators themselves." | Section 5 close; A2, B2 |
| "Ross will push on commercials." | C1 to C5; D1 to D4 |
| Rail selling (stated gap, F3) | B1, B4 |
| Headline numbers (6 to 40; £4M) | A5, D1, D3 (F1); C1, C2, D2 (F2) |

Session total: 18 questions.

## 8. Reverse questions

Deepa's and Ross's public footprint was not researched, so none of these is tied to their career paths (see upgrade menu).

1. "What does a strong first 90 days look like for whoever takes this role?" Why it lands: it shows you plan in operator terms, not only in sales terms.
2. "Which operator relationship is the team proudest of, and what made it work?" Why it lands: it tests the operator outcome from inside the team.
3. "When a deal helps operators but lowers margin, how does the team decide?" Why it lands: it names the commercial tension Ross will test, and asks Ross's view directly.
4. "How do operators reach the product today: direct, through a partner, or both?" Why it lands: it shows you think about the buyer and the channel together.
5. "What did the last person in this role get right, and what would you change?" Why it lands: it gives Deepa a reason to talk about the job, which is the strongest prep signal in a manager interview.
6. "What would make this a success at month 18, in your own words?" Why it lands: it answers the POV's frame from the manager's side.

## 9. Sources

- **Provided documents:** your message (background, and the recruiter's wording quoted in it). The internal market report is read by you but its text was not supplied, so nothing in this pack is drawn from it.
- **Searches sent** (all four refused, because web search permission was not granted in this session):
  1. "Kelverton Rail values": refused
  2. "Kelverton Rail interview process Senior Partnerships Manager": refused
  3. "Kelverton Rail strategy scheduling software train operators": refused
  4. "Deepa VP Partnerships Kelverton Rail": refused

  Ross was not searched.
- **Fetches:** none sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have set a values cheat sheet (section 10 is dropped). No values-style round is detected: the recruiter's words name a POV and Q&A, not values. Query refused. |
| 2. Interview process | unavailable | Would have confirmed the loop beyond the recruiter's email. The email establishes this session (a 60-minute panel with a 15-minute POV), so persona weights rest on it. Query refused. |
| 3. Strategy and recent news | unavailable | Would have moved the CO bank (A4, C3, D4 are generic). Query refused. |
| 4. Deepa, Kelverton Rail | unavailable | Would have produced an interviewer read and a reverse question tied to Deepa's path (section 10 and reverse questions). Query refused; Ross not searched. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the JD-tagged rows. No job description was supplied and no call was sent. |

Company facts in this pack are therefore absent, and every company-level claim is labelled generic.

## 10. Sections dropped

Grounding brief (no L2 research), reading the interviewer (no public footprint), values cheat sheet (no values-style round detected), delivery coaching (no assessment provided). Each would return with the upgrade menu inputs below.

## 11. Upgrade menu

- **The posting's own requirements** (paste the JD text) → the recruiter-sourced rows become posting-sourced, and the requirement-coverage list gets its real items.
- **The market report's headline shortlist** (paste the shortlist and the claims that matter to you, not the whole report) → section 5 can name the consensus answer and build the divergence against it, instead of guessing at it.
- **Permission for web search** (say so and I will re-run the four checks) → targets 1 to 4 move from unavailable, and A4, C3 and D4 can be researched rather than generic.
- **Your notes on how the £4M was counted** → your sentence can be quoted into F2, and C1 and D2 move from answer slots to grounded answers.
- **Your CV** → Provenance cells can quote CV sentences as well as your message, and the confidence bands on F1 to F4 can be re-graded.
- **Public profiles for Deepa and Ross** → the interviewer read, persona weights, and a reverse question tied to Deepa's path.
- **A `tuesday-dossier.md` from a previous session** → would carry earlier objections and verified evidence into this pack without re-asking.
