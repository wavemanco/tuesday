# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Rounds, 5 December 2026**
- Round 1: recruiter, 30 minutes. Recruiter not named in the email.
- Round 2: Head of Member Services, 45 minutes, mostly behavioural. This is the person you would report to. Not named.
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation. The panel is the values round and scores against the four values. Panel members not named.

**Shape:** loop mode. One shared fit snapshot and sources block, then a mini-pack per round with its own persona weights, question bank and reverse questions. The values cheat sheet sits with Round 3, the round your recruiter names as the values round. The upgrade menu is shared at the end.

## How to use, and the type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioural and values alignment. Whether past behaviour shows a published value.
- **EXP**: work-experience deep-dive. Whether your stated experience survives a probe.
- **JD**: role-driven. The job's listed responsibilities and requirements, including the gaps.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, worked aloud.

Guidance is scaffolding, not a script. Where a cell says "answer slot", the honest branch is a complete answer: "if you did this, say how; if not, say so plainly." Say the parts you did in your own words, and add nothing.

## Shared: fit snapshot

Requirements are quoted from the JD in your message. Evidence is quoted from your message, the only source for your background in this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | No gap on the years. The probe to expect is whether branch work counts as customer operations. Answer it with what the branch did, in your words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | low | [grounded] | discovery | Your sentence says formal complaints log. It does not say which rules the log was kept to, so the material does not show that the requirement is met. Answer slot: if a rule set applied, name it and say how the log followed it. If none applied, say so plainly and describe how the log was kept. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log and an escalation script. The JD asks for the whole process across branches and the contact centre, and your sentence does not reach that. Say your branch's part at its own scope. Answer slot: if you ran any part beyond your branch, say which part and how far it went. If none, say so plainly. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | The spreadsheet is monthly, and that is all the sentence carries. Whether it held volumes or resolution times is not in the material. Answer slot: if it counted either, say which and how you counted it. If not, say so and say what you would measure first. |
| F5 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your sentence says tellers, not supervisors. Say the coaching you did at its own scope. Answer slot: if you coached a supervisor on an escalation, say so. If you trained tellers, say that. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material shows this. Answer slot: if you have worked with a digital team, say what the work was. If not, say so plainly and say how you would start. |
| F7 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your sentence reaches reporting in other terms: a spreadsheet, built monthly, used by your regional manager. It does not name Excel. Name the tool the way you used it, and claim no more than that. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "Never worked in a contact centre." Then what you would do to close it, said as a plan. |

Routing note: F2, F4 and F6 are discovery because the material is silent on them, which is not the same as a stated absence. Only F7 and F9 rest on your own words that you have not done the thing, so only they carry plain acknowledgments.

## Shared: prohibited claims

These are the claims this pack will not coach. Each has its basis and its honest form. None of them appears in any answer, hold, bridge or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | Your sentence at its own scope: the branch's formal complaints log. The limit is the pack's own observation: your material says one branch's log, not the process across branches or the contact centre. |
| Has run regulated complaints handling | Inflated form of F2 | Your sentence at its own scope. "Formal" is your word. The rules it followed are not in the material. |
| Reports monthly on complaint volumes and resolution times | Inflated form of F4 | Your sentence at its own scope: you built a monthly complaints spreadsheet. Its contents are not stated. |
| Coached branch supervisors on escalations | Inflated form of F5 | Your sentence at its own scope: you trained new tellers on the escalation script. |
| Has presented to senior leaders | Negative you stated, F7 | "I've never presented to anyone above regional level." Plain acknowledgment. No slot. |
| Has worked in a contact centre | Negative you stated, F9 | "Never worked in a contact centre." Plain acknowledgment. No slot. |
| Excel reporting, as a named tool | Inflated form of F8 | The spreadsheet, named the way you used it. |

## Shared: grounding brief

Strategy points are as you summarised them in your message from the July 2026 brief. The brief's own wording is not in hand, so quote only what you have read in it.

- Digital: "move 40% of member service to digital channels by 2028". Expect questions on how complaints move to self-service, which connects to the digital-teams requirement (F6).
- Branches: "consolidate eight branches into five hubs over 2027". This makes location and the complaints seam between branches and the contact centre live questions for the team.
- Lending: "launch a small-business lending product in Q1 2027". Mostly outside this role, but worth knowing the company's direction.
- Competition: "the main competitive pressure is app-only banks." A useful frame for any question about member expectations.

No stale framing is flagged. Values and loop structure come from the material you pasted and the recruiter's email, not from memory.

---

## Round 1: recruiter screen (30 minutes)

**Persona weights.** Conversational / rapport is the top persona, since this round is about logistics and a biography. Light Skeptic is secondary, for the knockout-style checks on the contact centre and presenting.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | top, 6 questions | Friendly opener, then pay, notice, location and why you're leaving | High. Recruiter screens are logistics-first, and each logistics topic is scored as a knockout | Pre-decide how you'll answer each logistics topic in your own words, before the call |
| Skeptic, light | low, 2 questions | Asks about the contact centre and the spreadsheet in a casual register | Medium. The JD's contact-centre and reporting lines are the two places your material is thinnest | Say the plain acknowledgment first, then the nearest work you did |

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R-1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc in the sentences' own order: years in retail banking, the last three as a branch supervisor, the complaints log, the escalation script. Say it in your words and add no roles, numbers or dates. | Opens the screen. F1 is the years evidence. F2, F3 and F5 are where the first probes will land. |
| R-2 | "What is your notice period?" | JD | none given | Logistics slot. Give your actual notice period in your own words. The material gives no figure, so supply none. | Logistics slot. Notice is not stated, so it is still asked. |
| R-3 | "What are your pay expectations for this role?" | JD | none given | Logistics slot. Give your own figure, or ask for the role's band first. Do not mention your current pay. If asked what you earn now: "I'd rather focus on the range for this role." | Logistics slot. No figure is supplied in this pack. |
| R-4 | "Where would you be based, and which locations could you work from?" | JD | none given | Logistics slot. Name the locations you can work from, in your own words. | Location is a logistics topic. The branch-to-hub plan in the grounding brief is why it may be pressed. |
| R-5 | "Why are you leaving your current role?" | EXP | none given | Logistics slot. Give your own reason, in your own words. The material gives none, so supply none. | Reason for leaving is scored as a logistics topic. |
| R-6 | "What's your experience of the contact-centre side of complaints?" | EXP | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "Never worked in a contact centre." Then the nearest work you did on complaints, in your words, if there is any. | F9. A knockout-style check in a light register. |
| R-7 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped from the sentence: you built it, it is monthly, your regional manager uses it. Answer slot: if you counted volumes or resolution times in it, say which and how you counted them. If not, say so plainly. Name the tool the way you used it. | F4 and F8. The most likely place to be probed for numbers. |
| R-8 | "What made you apply to Ashgrove?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Pick one part of the published plan you would want to work on, and say in your own words why. If you have no view yet, say what you want to learn about it. | Motivation. Ties the answer to the company's own direction, without claiming any experience with it. |

**Reverse questions**, with why each lands.
- "What does success look like in this role at six months?" Why it lands: it gives you the frame the next two rounds will score against.
- "Is the location of this role fixed, or does it move with the branch and hub plan?" Why it lands: it shows you read the strategy brief and are thinking about the team's shape.
- "How will the feedback from the Head of Member Services and the panel reach you?" Why it lands: it shows you want a clear process, which recruiters notice.
- "Who on the panel works on complaints day to day?" Why it lands: it tells you which member will test the escalation case hardest.
- "What is the next step after 5 December?" Why it lands: it closes the screen cleanly and sets up the follow-up.

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights.** The hiring-manager prior is Case plus Skeptic. The loop says this round is mostly behavioural, which lifts Behavioural and holds Case lower. Skeptic is the top persona, because the two gaps this round will test are the contact centre and presenting above regional.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic / JD | top, 5 questions | Probes the contact centre, senior presenting, regulated complaints, supervisors and digital teams | High. Your sentences leave F2, F5, F6, F7 and F9 thin, and the manager is buying capability while derisking gaps | Plain acknowledgment first, then a plan. Hold the log you know through two follow-ups |
| Behavioural / values | mid, 3 questions | Scenario prompts on Members First, Own the Fix and Neighbours | High. The round is mostly behavioural | Selection scaffold: pick a real complaint, the stake, your decision, the outcome you can state. Say so plainly if none comes to mind |
| Case / strategist | low, 2 questions | A live problem on the complaints seam and on the hub move | Medium. The round is behavioural, so the case is short | Clarify first, then structure. Name what you would measure |

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-1 | "I don't see contact-centre experience in your background. How would you handle the contact centre in this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Highest-ROI prep. Start with the plain acknowledgment: "Never worked in a contact centre." Then a ramp plan as a plan: what you would learn first, and from whom. Hold the complaints process you know through two follow-ups by returning to your branch log. Concede the specific gap: the contact-centre side is the part you have not worked in. | F9 and F3. This is the single most predictable objection to you, and the JD's "across branches and the contact centre" is where the material is thinnest. |
| H-2 | "You've never presented above regional level. How would you present the complaints picture to a senior group?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: what you would show, and how you would test it with your regional manager first. | F7. The plan is stated as a plan, not as a past. |
| H-3 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint you decided from the member's side when the log or the rule said otherwise. Give the stake, what you decided, and the outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your log carries, in your own words. | Members First, Always. F3 carries the log. The only story the material supports is the log. |
| H-4 | "Tell me how you've coached someone through an escalation, and what they did next." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Map to the training: you trained new tellers on the escalation script. Answer slot: if you coached a supervisor on an escalation, say so and what they did next. If you coached tellers, say that. Do not stretch tellers into supervisors. | F5. The JD asks about supervisors and your sentence says tellers, so the honest answer names which. |
| H-5 | "Tell me about a problem you found that wasn't yours to fix, and what you did with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: if you found a problem in the log or the script and kept hold of it to the fix, say what it was and where it ended. If none comes to mind, say so plainly, then say how you would keep hold of a recurring complaint pattern. | Own the Fix. A limit beats a neat ending. |
| H-6 | "Tell me about a time you tailored a branch decision to its local customers." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick a time as a branch supervisor when local knowledge changed a decision. If none comes to mind, say so plainly, then say what the three years as a supervisor give you to draw on. | Neighbours, Not Numbers. F1 carries the supervisor years. |
| H-7 | "How was the complaints log kept, and what standard did it have to meet?" | JD | [grounded] "experience handling regulated complaints" (JD). "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: name the standard the log was kept to, if one applied, and how the log met it. If none applied, say so plainly and describe how the log was kept. | F2. The JD raises regulated complaints, so the question may be asked. The material does not show the standard. |
| H-8 | "Sketch how you'd run a complaint escalation that crosses two branches and the contact centre. What do you need to know first?" | CASE | [generic] | Clarify first: who owns the case, what outcome the member needs, and which rules bind the answer. Then the approach, the owners, the checks and the risks. Think aloud. This question asks about no past, so the guidance makes no claim about you. | F3 and F9. The JD's scope, worked as a live problem. |
| H-9 | "How would you work with a digital team on a self-service journey you didn't build?" | JD | [generic] | Frame it from the JD's own line: the digital team builds, and you bring the complaint data and the points where members get stuck. If you have worked with a digital team, say what the work was. | F6. Nothing in your material shows this, so the answer is a plan. |
| H-10 | "A branch manager says the hub move will cut complaint handling time. What would you measure first?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify what counts as handling time and which complaints it covers. Name the member outcome as the objective, not a faster close. Name the measures: volumes and times by location, before and after. Name the risk: a faster close with a worse outcome. | CASE, with a CO link to the strategy brief. The question is grounded in the company's plan as you summarised it. |

**Reverse questions**, with why each lands.
- "What does the first 90 days look like in this role, and what would you want done by day 90?" Why it lands: it gives you the expectation and the ramp you can propose.
- "How will the 2027 hub consolidation change where this role sits?" Why it lands: it ties the question to the strategy brief and to the location question you may already have been asked.
- "Which complaint volumes and resolution times do you review each month, and which should this role own?" Why it lands: it reads the JD's monthly reporting line back as a question about ownership.
- "How do you want the self-service work split between complaints and the digital team?" Why it lands: it tests F6 from the manager's side.
- "What would make the first month a good one for you?" Why it lands: it signals that you are working toward her or his expectations, in neutral terms.

---

## Round 3: panel of two branch managers (60 minutes, values round with a 20-minute case)

**Values round.** Detected from the recruiter's email, which says "the panel is also the values round". The values cheat sheet sits here.

**Persona weights.** The panel's members are not named, so personas cannot be assigned per member yet. Values / behavioural is the top persona, because the panel scores against the four values. Case / strategist is next, since the 20-minute case is the recruiter's own description. Pressure is low, for the follow-ups branch managers tend to press on.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / behavioural | top, 4 questions | Each of the four values, scored | High. The panel says so. | One scenario per value. Pick a real case, or say so plainly |
| Case / strategist | mid, 3 questions | The 20-minute complaint-escalation case, and a follow-up on a branch | High. The recruiter's words name the case | Clarify, objective, owners, first actions, measures, risks. Challenge one premise aloud |
| Pressure | low, 2 questions | "That's a values answer. How much of it was yours?" and a number question | Medium. Branch managers test ownership and numbers | Hold, then concede the specific limit |

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-1 | "Tell me about a complaint where you decided from the member's side of the counter." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Same scaffold as H-3: a complaint decided from the member's side, the stake, your decision and the outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your log carries. | Members First, Always. F3 carries the log. |
| P-2 | "Tell me about an explanation you had to make simpler, and what changed." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Map to the script: you trained new tellers on it. Answer slot: if you changed the wording of a script or an explanation, say what and why. If the wording was not yours to change, say so, and give the nearest explanation you did simplify. | Plain Words. The one story the material supports is the script's training. |
| P-3 | "How would you explain a change to a branch's town?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: a time as a branch supervisor when you explained a local change. If none comes to mind, say so plainly, then say how you would do it. | Neighbours, Not Numbers. The question asks about a change in general, not about any plan of the company's. |
| P-4 | "Tell me about a problem you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold with the honest branch: if the problem ended before it was solved, say so. A limit beats a neat ending. | Own the Fix. F3 carries the log. |
| P-5 | "Walk me through the first hour of a complaint escalation, from the branch to the contact centre." | CASE | [grounded] "a 20-minute case on a complaint escalation" (recruiter's email) | Structure: who raised it and what the member needs; the objective, which is a fair outcome within the rules; who owns each step (branch, contact centre, you); the first three actions; what you would check; one premise you would challenge, aloud. | The recruiter's named case. The recruiter's words are a raising source for this question. |
| P-6 | "Escalations at one branch rose by half in a month while the others held steady. What do you check first?" | CASE | [generic] | Clarify what counts as an escalation and whether the log changed. Then branch-level data, a staffing or training change, the measures, and the risks of acting too early. | A follow-up on a branch, in the case's own style. No claim about you. |
| P-7 | "Two branches handle complaints differently and are about to share a team. Which way do you decide, and how?" | CASE | [generic] | Clarify what each branch does and why. Then the decision rule, the member outcome you protect, and what you would measure in the first month. Challenge one premise aloud. | The hub plan is why this is likely. The question presupposes no company plan. |
| P-8 | "That's a values answer. How much of the log was actually your work?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold, then concede. Hold through two follow-ups by naming what you handled, in the sentence's words. Concede the limit the sentence carries: it is the branch's log, not the process beyond it. | Pressure. Hold a position the sentence carries, and do not claim more. |
| P-9 | "How would you know your complaint resolution times were right?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet tracked resolution times, say how you counted them. If not, say so plainly and say what you would check first. | F4. The second branch lets the honest answer be "it didn't track them". |

**Values cheat sheet.**

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a decision of yours. F3 carries the log. Selection scaffold, with the honest branch in H-3 and P-1. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5 carries the script training. Selection scaffold, with the honest branch in P-2. |
| Neighbours, Not Numbers | Every branch is part of its town | F1 carries the branch-supervisor years. No quote carries a local decision. Selection scaffold, with the honest branch in P-3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 carries the log. Selection scaffold, with the honest branch in P-4. |

Values are the company's own words, pasted from ashgrovecu.org/about/values on 26 November 2026. Working meanings are paraphrase.

**Reverse questions**, with why each lands.
- "Which of the four values do your branches score lowest on today, and how do you know?" Why it lands: it treats the values as working practice, which is what the panel scores.
- "When a complaint crosses from a branch to the contact centre today, where does it usually stall?" Why it lands: it tests the seam the JD asks you to own.
- "What do the supervisors in the branches nearest the hub move worry about most?" Why it lands: it asks about the real pressure on the team without pressing for a view on the plan.
- "What does a branch manager need from the complaints lead that they don't get now?" Why it lands: it asks what the panel's own work needs, which is the question a peer asks.
- Reciprocity question, since the panel are peers: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the interview into a conversation about the work, and it is the question peers expect.

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | R-1 |
| Experience handling regulated complaints | H-7 |
| Own the member complaints process end to end across branches and the contact centre | H-1, H-8, P-5 |
| Report monthly on complaint volumes and resolution times | R-7, P-9 |
| Coach branch supervisors on escalations | H-4 |
| Work with digital teams on self-service journeys | H-9 |
| Confident presenting to senior leaders | H-2 |
| Comfortable with Excel reporting | R-7 |

## Sources

- Provided documents: the JD text in your message; the recruiter's email as you summarised it; the four values as you pasted them from ashgrovecu.org/about/values on 26 November 2026; the strategy points as you summarised them from the July 2026 brief; your background in your message.
- No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Values cheat sheet. The pasted page fixes the names and wording, so the search would add nothing. |
| 2. Ashgrove interview process, member experience lead | skipped | Loop structure. The recruiter's email names the three rounds, their lengths and who runs each. That is a loop source, so no archetype fallback is used. |
| 3. Ashgrove strategy, recent news | skipped | Grounding brief and the CO and CASE questions. The strategy points you summarised are from July 2026, within six months. The brief's own wording is not in hand. |
| 4. Interviewer name, Ashgrove | n/a | No names were given. The Head of Member Services and the panel members are unnamed, so there is no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Names of the Head of Member Services and the two panel members → personas assigned per member, and reverse questions tailored to each.
- The strategy brief's text, pasted in full → exact wording for the grounding brief, and quotes checked against the brief in R-8 and H-10.
- Whether the monthly complaints spreadsheet counted volumes or resolution times → F4 moves from discovery to grounded, and R-7 and P-9 get a defend-the-number rehearsal.
- The standard the branch complaints log was kept to, if one applied → F2 moves from discovery to grounded, and H-7 gets its rule set.
- Any contact-centre contact, or any work with a digital team → F3, F5, F6 and F9 get a grounded answer where there is one.
- How many hours you have before 5 December → a timed prep order, sized to that time.
- Any deliverable the recruiter has declared for the process. None is declared in the email, so no build section is included.
- Deep research, L2 → up to 6 more searches and 2 more fetches, several minutes, on your consent. It would cover recent organisation context around the hub move, and loop reports for this role family.
