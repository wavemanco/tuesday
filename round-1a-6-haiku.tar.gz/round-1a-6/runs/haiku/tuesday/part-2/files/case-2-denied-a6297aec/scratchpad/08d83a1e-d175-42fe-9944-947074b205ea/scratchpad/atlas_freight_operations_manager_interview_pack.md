# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not given. Round: not given, so persona weights are flat (see the persona table). Sections the inputs do not support are left out: values cheat sheet, interviewer read, graded deliverables, prep triage, delivery coaching, grounding brief.

## How to use

Personas describe how a question arrives. Types describe what it scores:

- **JD**: tests a stated requirement from the posting.
- **EXP**: tests a claim from your own experience, and whether you can say exactly what was yours.
- **CASE**: a live problem from the role, scored on structure. It asks about no past of yours.
- **VAL**: a values question. None is included, because no values were researched.
- **CO**: company knowledge. None is included, because no company research ran.

Guidance is scaffolding, not a script. Say it in your own words. Any line that begins "answer slot" is an instruction for the interview: decide your honest answer before you go in.

## Fit snapshot

The requirements are the lines you pasted from the posting, not the full posting. The evidence is quoted from your message. Every confidence, provenance and gap label is one token.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD summary you pasted) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows daily shift leadership over three supervisors. It does not show how many sites you have covered. Answer slot: if you have run operations across more than one site, say which and what you were responsible for; if you have not, say so and describe how you would split your attention across four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD summary you pasted) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your quote is about accuracy, not on-time delivery or cost per shipment. Say it at its own scope: "I cut the mis-pick rate by 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, name the figure and how it was counted; if you did not, say which measure you did track. |
| F3 | "lead a team of 12 supervisors" (JD summary you pasted) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | You lead three supervisors. Twelve is a difference of scale, and the bridge should say that. Answer slot: describe how you would structure a team of twelve, and say which parts you have done at three. |
| F4a | "build reporting in Excel/Power BI" (JD summary you pasted) | "solid Excel, never used Power BI" (your message) | low | [inferred] | discovery | Your material says Excel is solid. It does not say you have built reporting in it. Answer slot: if you have built recurring reports in Excel, say what they tracked and who used them; if you have not, say what you would build first. |
| F4b | "build reporting in Excel/Power BI" (JD summary you pasted) | "solid Excel, never used Power BI" (your message) | none | [grounded] | capability | Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Do not describe Power BI work you have not done. |
| F5 | "5+ years operations leadership required" (JD summary you pasted) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Seven years in operations is in your material. Years in a leadership role are not stated. This is not a gate: experience length is graded on fit. Answer slot: give the dates you have held a leadership role, in your own words; if it has been fewer than five years, say so and describe the nearest role you held. |
| F6 | "Lean/Six Sigma a plus" (JD summary you pasted) | "green belt certified" (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement, and the certificate itself is not yet inspected, so expect a question about what you applied it to. |

No requirement in the summary is a gate. A licence, location or right-to-work term would be a gate, so check the full posting for one.

## Prohibited claims

Each entry names its basis. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1 | "currently a senior shift manager over 3 supervisors." The material does not show the site count. |
| Led twelve supervisors, or led at scale | Inflated form of F3 | The three-supervisor quote at its own scope, with the scale question as an answer slot. |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." Accuracy only. |
| Sole credit for the 40% | Inflated form of F2 | Your quote does not say who else took part. Which part was yours is an answer slot in B1. |
| Built Power BI reporting | Negative you stated, F4b | "I've never used Power BI." No slot. |
| Five years or more of operations leadership | Not stated, F5 | The pack's own observation: your material does not show your years in a leadership role. Words for you are an answer slot. |

## Question banks

Weights are flat because the round and the interviewer are unknown. Depth is 5, 4, 4, 2 and 2 per persona. The highest-ROI prep is A1: the 5+ years requirement is the likeliest objection, and the material is thinnest there.

### A. Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for five-plus years of operations leadership. Where does your leadership time stand?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Say the seven years and the current role, in those words. Answer slot: give your dates in a leadership role. If it has been fewer than five years, say so plainly and name the nearest role you held. | F5 is the requirement most likely to be probed, and the material is silent on leadership span. |
| A2 | "You lead three supervisors. How would you run twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: say how you would structure twelve supervisors, and what you have done at three that carries over. Do not describe a team of twelve as if you had run one. | F3 is a scale gap. Its bridge is a plan, not a past. |
| A3 | "Your role spans four sites. What have you run across more than one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: if you have run operations across more than one site, say which and what you owned. If you have not, say so and describe how you would divide your time across four. | F1 is transferability. The site count is not in the material. |
| A4 | "The role builds reporting in Excel and Power BI. Which have you used for reporting?" | JD | [grounded] "solid Excel, never used Power BI" | Say Excel is what you use, in those words. Say "I've never used Power BI," then how you would learn it. Do not describe a Power BI report. | F4a and F4b. The plain acknowledgment has a source in your own sentence. |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name the weakest requirement honestly. Power BI is the strongest candidate, from A4. Pair the weakness with a concrete first-30-day plan. | Persona stem. It names no past event, so it needs no quote. |

### B. Data-Driven Prober (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number slot. Say the baseline period and what you counted, in your own words. Name the assumption you would defend least. Answer slot: which parts of the redesign were yours to set, and which were someone else's. If you do not know how it was counted, say so. | F2 is the strongest figure you have, and probers go straight to its counting method. |
| B2 | "What else changed in that period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name any other change in the window, or say there were none you know of. Do not claim the redesign was the only cause unless you can show it. | Tests attribution. It presupposes nothing the quote does not carry. |
| B3 | "Which on-time or cost-per-shipment figures have you tracked?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD summary) | Answer slot: name the figures and how you counted them, if you tracked them. If you did not, say so and name the measure you did track. | F2 shows no on-time or cost figure. This is the requirement most likely to be probed. |
| B4 | "How would you build the weekly report for four sites, and in which tool?" | JD | [grounded] "solid Excel, never used Power BI" | Say Excel first, in your own words. Then say how you would learn Power BI. Do not describe a report you have not built. | F4a and F4b. Excel is in the material; Power BI is not. |

### C. Case / Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance dropped five points at one site during a peak week. What do you check first?" | CASE | [generic] | Clarify the metric definition and the time window. Segment by shift, dock, carrier and lane. Name the first two checks and what each would rule in or out. Then say what you would do in the first 24 hours. | Live problem from the role's on-time requirement (F2). It needs no claim about your past. |
| C2 | "Cost per shipment is up eight percent year on year. Where do you start?" | CASE | [generic] | Clarify the cost base and how shipments are counted. Split cost by labour, equipment, overtime and rework. State a hypothesis before you pull data. | Live problem from the cost-per-shipment requirement. |
| C3 | "Peak season is six weeks out and you are staffing four sites. Walk me through your plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell the surge plan in its own sequence: forecast, staffing, training and the weekly check. Answer slot: which parts were yours to set, and which were set for you. | The strongest story in your material. The plan is yours to describe; the decisions are the part to check. |
| C4 | "Which of four sites would you fix first, and why?" | CASE | [generic] | Name the criteria first: volume, error rate, cost, and what the site's leadership is ready for. Pick one, and say what would make you change the choice. | Tests the four-site scope (F1) as a decision, not as a record. |

### D. Pressure / Stress (weight: mid, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Hold: lead with the 40% and the green belt, in those words. Concede plainly: "I have not run four sites or twelve supervisors." Then say how you would close that gap in your first quarter. | Pressure drill. The hold is on what you have; the concession is on what you lack. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote. Answer slot: say which parts of the redesign were yours to set, in your own words. If the redesign was someone else's, say so and describe your part. | This is the attribution probe. Hold through two follow-ups before you concede anything. |

### E. Conversational / Rapport (weight: low, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into operations." | EXP | [grounded] "7 years in warehouse and distribution ops" | A ninety-second arc: where you started, the role you moved into, the site you run now, and one result. Use only the facts you have stated. | Open biography. Casual questions are still scored. |
| E2 | "What have you done with Lean or Six Sigma?" | JD | [grounded] "green belt certified" | Say the certificate and what you applied it to. Answer slot: name the project and its result, if you led one. If the green belt was coursework, say so. | F6. The certificate is not yet inspected, so expect a probe. |
| E3 | "What got you into warehouse work in the first place?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Short and true. Give the reason you took the first role, then the progression. | Low-weight rapport question. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A3, C4 |
| Drive on-time performance and cost-per-shipment down | B3, C1, C2 |
| Lead a team of 12 supervisors | A2, D1 |
| Build reporting in Excel/Power BI | A4, B4 |
| 5+ years operations leadership required | A1 |
| Lean/Six Sigma a plus | E2 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the 5+ years line and the four-site scope | High. The JD lists the leadership-span requirement and your material is thinnest there (F1, F3, F5). | Rehearse A1 until it is plain. Concede the gap in your own words, then the plan. |
| Data-Driven Prober | Asks how the 40% was counted, and for the on-time and cost figures | High. Your one headline figure is the kind probers test. | Know what you can and cannot say about the counting. Name the weakest assumption first. |
| Case / Strategist | Live problems on on-time, cost and sites | Medium. Live problems are common for this title, but no round is confirmed. | Clarify, then structure, then state one hypothesis and test it. |
| Pressure | Time-boxed "why you" and "how much was you" | Medium. A flat prior; a hiring manager would weight it higher. | Hold the position through two follow-ups. Then concede the specific gap. |
| Conversational | Biography and Lean/Six Sigma as casual openers | Low to medium. Easy to underrate. | Keep the arc to ninety seconds and the facts you have stated. |

## Reverse questions

Each has a "why it lands". None is tied to the interviewer's career, because no interviewer is named.

1. "What does a strong first 90 days look like in this role, and how would you measure it?" Why it lands: shows you plan against outcomes.
2. "How is on-time performance defined across the four sites, and where do they differ most?" Why it lands: your question is the one the requirement turns on, and a precise answer tells you how the numbers are kept.
3. "Which of the four sites is hardest right now, and what has been tried?" Why it lands: it invites a conversation about the actual problem.
4. "Who reads the weekly operations numbers today, and what decisions do they drive?" Why it lands: the requirement is to build reporting; this asks whether anyone uses it.
5. "What did the last person in this role leave in good shape, and what did they not get to?" Why it lands: a candid question, and the answer shows you what the job's backlog is.

## Sources

- Provided documents: your message, with the posting summary and your background as pasted. No full posting or CV text was provided.
- Searches sent: three, all refused by the host's permission check. Research tier: L1, searches 3 of 6 (refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. Query "Atlas Freight regional logistics company values" was refused. |
| 2. Atlas Freight operations manager interview process | unavailable | Loop structure and persona weights. Query was refused. |
| 3. Atlas Freight strategy and recent news | unavailable | CO questions and the grounding brief. Query "Atlas Freight logistics strategy news" was refused. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative operations manager JD | skipped | The posting summary you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Round type and who you are meeting → persona weights and the interviewer read
- Full posting text → exact JD quotes, plus any gate rows such as a location or licence requirement
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- Search permission granted → the values, interview-process and strategy targets, which would add the values cheat sheet and CO questions
- Green belt certificate or project summary → F6 moves from medium to high, and E2 gets a real story
- The figures behind the 40% and any on-time or cost numbers → defend-the-number rows B1 and B3 rest on your data, not a slot
- Recruiter's note on focus areas → coverage of any named deliverable
- Prep time → a prioritized triage of this pack
