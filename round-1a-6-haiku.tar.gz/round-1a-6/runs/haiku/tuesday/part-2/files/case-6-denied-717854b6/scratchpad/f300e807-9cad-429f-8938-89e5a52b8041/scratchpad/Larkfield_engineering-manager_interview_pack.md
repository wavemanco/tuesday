# Larkfield Systems, Engineering Manager: loop prep pack (three rounds)

Interviewers: Director of Engineering (hiring manager, Tuesday, 45 min); two staff engineers plus a product manager (panel, Thursday, 60 min); VP Engineering (values and leadership philosophy, Monday, 30 min). No names given, so no interviewer read.

## How to use

Personas are how a question arrives; types are what it scores: JD (role requirement), EXP (your past work), CASE (live problem), VAL (values and leadership), CO (company knowledge). Guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot (shared across rounds)

Source for every requirement: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap." (your message).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Hiring is adjacent and real; growth and delivery at eleven is not in your material. Words: "I run our hiring loop for backend roles." Answer slot: if you set growth or delivery plans for a group that size, say how, in your own words; if you did not, say so and say how you would build them. |
| F2 | "Lead two squads" (your message) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | medium | [grounded] | transferability | One team of six is the adjacent evidence; two squads is wider. Words stay at scope: "I've been a team lead of six." Do not describe two squads. |
| F3 | "partner with hardware and product on roadmap" (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Roadmap pressure is real and you held a position against it, but the work was reliability, not device roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." The 60% is a figure you gave, so expect defend-the-number probes. |
| F4 | "partner with hardware and product on roadmap" (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated; words come only from your sentence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |
| F5 | "device-management services" (your message) | none given | none | [grounded] | discovery | Your material does not show device-facing work. Answer slot: if you have built services that devices or telemetry depend on, say what, in your own words; if not, say so and say what you would learn first. |

Your material does not show whether any of the three rounds' interviewers will weigh the managers-of-managers question. It is covered as a stated limit in the prohibited list and in the VP bank.

## Prohibited claims (built locally from the fit snapshot)

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads or ran two teams | Inflated form of F2 | F2's quote at its scope. Observation for you, not words to say: your material shows one team of six. |
| Managed managers | Negative you stated | Plain acknowledgment: "I haven't managed managers." No answer slot. |
| Owned a hardware-adjacent roadmap | Negative you stated (F4) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No answer slot. |
| The 60% as the sole cause of the drop | Inflated form of F3 ("after I pushed...") | F3's quote at its scope. The causal link is an observation: the drop came after the quarter. |
| Owned hiring for the whole organisation | Inflated form of F1 | F1's quote at scope: a backend hiring loop. |

## Persona weights and round packs

### Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

Persona weights: relationship prior for a hiring manager is Skeptic and Case/Strategist, because they are buying capability and checking the gaps. Skeptic 4 questions (top weight), Case 3, Data-driven Prober 2.

Highest-ROI prep: A1, the hardware roadmap objection. It is the one this role will test first and the one your material is silent on.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary); [grounded] "I haven't owned a hardware-adjacent roadmap." (F4) | Name it in one sentence: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn it, as a plan. Answer slot: if you have worked close to a hardware roadmap in any role, say how and in your own words; if not, say so. Hold through two follow-ups by returning to the plan, never by adding to the past. | F4 is the gap this role presses hardest; the question will come in some form. JD because it scores the stated partnership. |
| A2 | "Your largest team has been six people. This role is eleven across two squads. Which part of that have you actually done?" | JD | [grounded] "3 as a team lead of 6" (F2) | Say the part you did, in the quote's terms: a team of six, for three years. Answer slot: the second squad, and eleven engineers, are not in your material. If you have led a group that large or split a team, say how; if not, say so and say how you would structure two squads. | F2 is the scope gap. The premise is the role summary's number, not an invented team. |
| A3 | "Why this role, and why now, from a payments company?" | CO | [generic] | Answer in your own words. No claim about your past is made here. A plain, specific reason beats a broad one. | Motivation is a Skeptic staple; generic because no source for your reasons is in the material. |
| A4 | "You pushed a reliability quarter through. What did it cost you on the roadmap?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." (F3) | Hold the decision: "I pushed it through." Concede what it cost, specifically, in your own words. Answer slot: if you tracked what was displaced, say what; if you did not, say so. Do not invent a cost. | F3 is the strongest thing you have against roadmap pressure, and the first place a Skeptic will test whether you can name a cost. |
| A5 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (F3) | Defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot for each: if you know, say it in your own words; if you do not, say so plainly. | A figure you gave raises these four slots, and only these. |
| B1 | "Sixty seconds: what would you do first with this team?" | CASE | [generic] | Clarify, then objective, then segmentation of the eleven, then approach, then metrics and risks. Think aloud. | Live problem; asks nothing about your past. |
| B2 | "A device fleet's update rollout failure rate doubles after a release. Walk me through the diagnosis." | CASE | [generic] | Clarify scope and rollback first, then structure: device cohort, release, infrastructure. Name one risk you would check before any change. | Live problem on device-management services; no claim about you. |
| B3 | "How would you partner with hardware and product on a roadmap that mixes firmware and cloud work?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary) | Name the decision rights you would need from each side, and the seam you would test first. Propose principles, not a plan you have not built. | JD requirement with no past claim in the answer. |
| D1 | "Where does the hardware work stop and your squads start?" | CO | [generic] | Name the seam as a principle, then ask what they hold. | Seam probe from a hiring manager who owns the boundary. |

Persona table, round 1:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the hardware and managing gaps | High: the role names hardware partnership and the two-squad scope | Name the gap, then the plan. Rehearse A1 until it is boring |
| Case/Strategist | Live diagnosis on device services | High: hiring managers buy capability and test it on their roadmap | Clarify before structuring |
| Data-driven Prober | Denominators on the 60% and the 40 interviews | Medium: your figures are the easiest probes | Defend-the-number slots (A5, C2) |

Reverse questions, round 1 (each with why it lands):
1. "What would the first six months need to look like for you to call this hire a success?" Why it lands: it turns a scorecard into a shared target.
2. "Which of the two squads has the harder hardware dependency, and why?" Why it lands: it shows you have thought about the seam.
3. "Who holds the final say on a roadmap item when hardware and product disagree?" Why it lands: it surfaces the real decision rights.
4. "Where has the last engineering manager in this seat struggled?" Why it lands: it asks for the honest version of the pressure.
5. "What does the hiring bar look like for engineers on device services?" Why it lands: you run a backend loop; this shows you are ready to calibrate a new one.

### Round 2: Panel (two staff engineers and a product manager), Thursday, 60 min

Persona weights: each staff engineer's relationship prior is Peer Evaluator and Data-driven Prober; the product manager's is Case/Strategist and Conversational. No names, so the weights are blended. Peer Evaluator 3, Data-driven Prober 3, Case/Strategist 2, Conversational 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] persona stem; [grounded] "partner with hardware and product on roadmap" (role summary) | Name the seam as a principle. For disagreement, use a story only if you had one with an equal. Answer slot: if you did not, say so and say how you would handle it. | Peer probe; the role names partnership. |
| C2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (F3) | Name the weakest assumption before they do. If you do not know how it was counted, say that. | Defend-the-number slot. |
| C3 | "How many of the 40 interviews did you sit on every loop for, and did you change the rubric?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (F1) | Say which you ran and which you only sat on. Answer slot: if you changed the rubric, say what and why; if you did not, say so and say what the loop asks. | Defend-the-number on 40, plus an answer slot on a practice the role's hiring line raises. |
| C4 | "What is the hardest technical call you've made in a service other systems depend on?" | EXP | [grounded] "device-management services" (role summary) | Selection scaffold: pick a service other systems depended on, a call you made, and what you would not repeat. If none comes to mind, say so, then give the nearest thing your material carries: the reliability quarter (F3). | Open prompt on the role's domain; no claim about device services. |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the credit rule you use, in your own words. | Peer probe on credit-sharing. |
| E1 | "A hardware partner wants a firmware release the quarter you planned for reliability. What do you do?" | CASE | [generic] | Clarify what the release commits, then options, then what you give up and who decides. | Live roadmap problem, PM register. |
| E2 | "What would you need from product to plan a quarter across two squads?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Name the inputs you would need, not a plan you have not built. | JD requirement; no past claim. |
| G1 | "So — walk me through the journey." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (F2) | A 90-second arc from that sentence, in your own words, with nothing added. | Casual opener, still scored. |

Persona table, round 2:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam and credit probes from the staff engineers | High: they price what the hire adds to their work | Reciprocity framing; principles, not invented seams |
| Data-driven Prober | Denominators on the 60% and the 40 interviews | High: your two figures are the likely targets | Defend-the-number slots (C2, C3) |
| Case/Strategist | Roadmap problems from the PM | Medium | Clarify, then structure |
| Conversational | Opening arc | Medium | Pre-scripted 90-second arc (G1) |

Reverse questions, round 2:
1. "What separates how the staff engineers see the roadmap from how product sees it today?" Why it lands: it names the seam.
2. "What device-service decision is coming up that a new manager would inherit?" Why it lands: it shows you want the real work.
3. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity for peers.
4. "How do the squads hand work to the hardware teams now?" Why it lands: it asks for the process, not the slogan.
5. "What did the last engineering manager wish they had done sooner?" Why it lands: it invites candour.

### Round 3: VP Engineering, values and leadership philosophy, Monday, 30 min

Persona weights: the recruiter's words name a values round, so Values/Behavioral is the top weight. The skip-level prior is Case/Strategist and Pressure. Values/Behavioral 4, Pressure 3, Case/Strategist 2.

Values cheat sheet: not included. It depends on the company's published values, and none were found (see sources), so the honest branch applies to every VAL question below.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "values and leadership philosophy" (recruiter's words, your message); persona stem | Selection scaffold: a time you told a senior person something they did not want to hear, with a named stake, a moment you did not fold, and an intact relationship at the end. Honest branch: if none comes to mind, say so plainly, then give the nearest thing your material carries: "I pushed a reliability quarter through against roadmap pressure." | Recruiter-named values round. |
| H2 | "You've never managed managers. Why would I trust you with two squads' leads?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (F4) | Highest-ROI prep for this round. Plain acknowledgment: "I haven't managed managers." Then what you have done: "3 as a team lead of 6." Then the plan for leads, as a plan. Hold through two follow-ups; concede the gap, do not inflate it. | The most likely objection at this level. |
| H3 | "Sixty seconds: why you over an internal candidate?" | Pressure | [generic] persona stem | Pause; restate; anchor in one quote you can stand behind. Hold the position through two follow-ups. | Composure check. |
| H4 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (F3) | Hold the position: "I pushed the quarter through." Concede specifically what you did not control. | Attribution probe at executive altitude. |
| H5 | "How would you know a reliability quarter was worth more than the roadmap items it displaced?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." (F3) | Name how you would measure the trade, and whether you measured it. Answer slot: if you tracked what was displaced, say how; if not, say so. | Strategy altitude probe. |
| H6 | "When did you put a customer or team ahead of an internal metric?" | VAL | [generic] persona stem | Selection scaffold, same honest branch as H1. | Values probe on a common theme. |

Persona table, round 3:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario and STAR questions | High: the recruiter named the round | Story selection with the honest branch |
| Pressure | Time-boxed challenge on attribution | High: a 30-minute skip-level round | Hold then concede |
| Case/Strategist | Roadmap trade-off | Medium | Clarify, then structure |

Reverse questions, round 3:
1. "How do you decide between a reliability commitment and a roadmap commitment?" Why it lands: it asks for the philosophy, not the slogan.
2. "What does leadership look like here when the pressure is on?" Why it lands: it invites the honest answer.
3. "What would make you say no to a hire at this level?" Why it lands: it names the bar.
4. "How do engineering managers here hold their own quality bar?" Why it lands: it links to your reliability work.
5. "What would you want the next engineering manager to have done in their first 90 days?" Why it lands: it signals you are planning for the role.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Own delivery, hiring and growth for 11 engineers | A2, C3, E2 |
| Lead two squads building device-management services | A2, B1, C4 |
| Partner with hardware and product on roadmap | A1, B3, C1, E1 |
| Device-management services (domain) | B2, C4, F5 |

## Sources

Research tier: L0. Web search was refused by a permission prompt, so no company pages were fetched; every company-specific claim is absent and the pack relies on your message and the recruiter's words.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Query "Larkfield Systems values" refused. Would have supplied the values cheat sheet (section 10) |
| 2. Larkfield Systems interview process engineering manager | unavailable | Query "Larkfield Systems interview process engineering manager" refused. Loop is established by the user's and recruiter's words, so the rounds stand |
| 3. Larkfield Systems strategy / news | unavailable | Query "Larkfield Systems industrial IoT device management strategy news" refused. Would have grounded the CO questions |
| 4. Interviewer name | n/a | No name given |
| 5. Representative EM JD | unavailable | No search sent; the search permission was refused. No JD supplied |

Loop: established by your message and the recruiter's words, which name three rounds, their lengths and who runs them.

## Upgrade menu

- The posting's own text → the role summary rows become quoted posting requirements, and any mid-list requirement gets its own question
- The recruiter's prep email → confirmation of what the panel and VP round each assess
- The Director's name → a tailored reverse question, and persona weights from their public footprint
- Search access → the company's values page (cheat sheet, round 3), the loop, and grounded CO questions
