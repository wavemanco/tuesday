# Larkfield Systems: Engineering Manager, interview prep (loop mode)

Role: Engineering Manager, device-management services. Company: Larkfield Systems (industrial IoT, ~600 people).
Rounds: (1) Tuesday, 45 min, hiring manager (Director of Engineering); (2) Thursday after, 60 min panel, two staff engineers and a product manager; (3) following Monday, 30 min, VP Engineering, "values and leadership philosophy".

Changelog: first version. No prior pack.

## How to use + type key

- Personas = how a question is asked. Types = what it scores: **VAL** values/behavioral, **EXP** your experience, **JD** the role's stated requirements, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse only what you did.
- Provenance quotes are your own sentences, from your message. Quotes from the role are from the role text you gave me.

## Sources and research

- Provided: your message (role summary, your background, round details, the recruiter's phrase "values and leadership philosophy").
- Research tier: L1, but no searches ran. Three searches were sent (company values, interview process, strategy) and the host refused them, so nothing about Larkfield is established from the web.

Research tier: L1 — searches 0 of 6 (3 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10). Dropped: no published values in hand |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have confirmed the loop. Round structure here rests on your message, not on a loop source |
| 3. Larkfield Systems strategy / recent news | unavailable | Would have fed the CO bank and the reverse questions on roadmap |
| 4. Interviewer name + company | n/a | No names given |
| 5. Representative engineering-manager JD | unavailable | Only a role summary is in hand, not a full JD |

Searches sent, all refused: "Larkfield Systems values engineering industrial IoT"; "Larkfield Systems engineering manager interview process"; "Larkfield Systems device management strategy news".

Loop: your message names three rounds with who runs each. That establishes the loop (a loop source, your own words). No archetype fallback is needed.

## Fit snapshot

Requirements: quoted from the role text you gave me, or from your message. Confidence, provenance, and gap type follow the routing rule in the template.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six. It does not show two squads or device management. Words: "For three years I was a team lead of six." Answer slot: if you coordinated work across more than one team, say how you decided what each did; if not, say so and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Hiring is in your material; delivery and growth are not. Words for hiring: "I run our hiring loop for backend roles." Answer slot: how you have owned delivery and growth for a team; if you have not, say so |
| F3 | "partner with hardware and product on roadmap" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote carries product roadmap pressure, not a partnership with hardware. Words stay at the quote's scope: "I pushed a reliability quarter through against roadmap pressure." |
| F4 | "partner with hardware and product on roadmap" — role text | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, as a plan and never as a past |
| F5 | a path to managing managers — [generic], role-family pattern, not from the role text | "I've never managed managers" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't managed managers." Then how you would prepare to, as a plan |
| F6 | location and office days — not in the material | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. Question 2 asks it |
| F7 | "9 years engineering" — your message | "9 years engineering" — your message | high | [grounded] | none | Engineering depth is stated. Lead with it as the base for the manager story |

Gate note: F6 is the only gate in the material, and it is not established. Question 2 asks whether it is met.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | F1's quote at its own scope: one team of six |
| Owned the roadmap with hardware | Inflated form of F3 and F4 | F3's quote; the limit is the pack's observation: your material shows roadmap pressure from product, nothing on hardware |
| Cut on-call by 60% on my own | Inflated form of the 60% sentence | The quote as written: after you pushed the quarter through, your team's on-call burden dropped 60% |
| Managed managers | Plain acknowledgment F5 | "I haven't managed managers." No slot |
| Owned a hardware-adjacent roadmap | Plain acknowledgment F4 | "I haven't owned a hardware-adjacent roadmap." No slot |

## Persona model and loop mode

Weights are shown per round, from the relationship priors and the loop. No interviewer profiles were given, so no interviewer read is included.

## Round 1: hiring manager (Tuesday, 45 min)

Weights: Case/Strategist 35%, Skeptic 35%, Pressure 15%, Conversational 15%. Reason: a hiring manager is buying capability and derisking gaps. Expect live problems on their roadmap.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you run two squads on device-management services when you have led one team of six?" | JD | [grounded] "3 as a team lead of 6" | Story-mapped on F1: one team of six, in those words. Answer slot: if you coordinated across more than one team, say how you decided what each did; if not, say so and say how you would split the work | F1 is the widest gap against the headline requirement |
| A2 | "I don't see hardware-adjacent roadmap work in your background. How would you handle it?" | Skeptic (stem) | [grounded] "I've never owned a hardware-adjacent roadmap." | Hold, then concede: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, with a first 90 days as a plan. Hold through two follow-ups; never claim the work | F4 is the most predictable objection. Deepest rehearsal |
| A3 | "Hardware and product both want the same quarter's capacity. How do you decide?" | CASE | [generic] | Clarify the constraint, then the objective, then the options. Name who you would talk to before deciding. The question presupposes nothing about your past | Live problem from the role's partnership line |
| A4 | "Walk me through the reliability quarter, and how you pushed it through." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3: the quarter, the pressure, what you did. Beats are the quote's own clauses | F3 is your strongest evidence for the roadmap line |
| A5 | "How was the 60% counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number slots: how the figure was counted, the assumption you would defend least, which part was yours. If you cannot say how it was counted, say so | The figure raises defend-the-number slots only |
| A6 | "Tell me about your hiring loop: how did you run the 40 interviews?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F2: what you run, for which roles, in your words. Answer slot: how you have owned delivery and growth for a team; if not, say so | F2 is the base for the hiring requirement |

Reverse questions (round 1):
- "What would the first two quarters look like on the hardware side?" Why it lands: it turns the Skeptic's gap into a planning conversation.
- "Which of the two squads is harder to hire for right now, and why?" Why it lands: it signals you are thinking about the work, not only the job.

## Round 2: panel (Thursday, 60 min)

Blend. Staff engineers: Data-Driven Prober + Peer Evaluator. Product manager: Case/Strategist. Weights: Prober 30%, Peer 30%, Case 30%, Skeptic 10%. Names of panel members are unknown, so personas are blended, not assigned.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 60% was counted, and which assumption you would defend least." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number, as A5. Say the figure as you wrote it, and say the assumption in your own words | Prober question; the figure is yours to defend |
| B2 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | Peer (stem) | [generic] | Seam principles, not a claimed seam: name the decisions you would want to see made jointly. For disagreement, a story where you held a view and kept the working relationship. Answer slot: if you have no such story, say so and give the nearest one | Peer persona; the stem is a standard seam probe |
| B3 | "Sketch a trade-off between device onboarding and a hardware certification milestone. What do you need to know first?" | CASE | [generic] | Clarify: what is fixed, what slips, who decides. Then options and risks. Use the role's own words only | A live problem from the role line; asks nothing about your past |
| B4 | "What did product ask of you in the reliability quarter, and what did you agree to?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3: the pressure, the quarter, what you agreed to. Answer slot: if you agreed to a trade-off, name it; if the quarter went through without a trade-off, say so | Tests the partnership line with product |
| B5 | "I don't see hardware work in your background. How would you handle the first six months?" | Skeptic | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a ramp plan. Hold through two follow-ups | F4 again, from the panel side |

Reverse questions (round 2):
- To a staff engineer: "What decision in the device stack does your team wish it had made earlier?" Why it lands: a peer question, the one that turns the panel into a conversation.
- To the product manager: "What does a good roadmap review look like with the hardware team?" Why it lands: it names the partnership the role lives in.

## Round 3: VP Engineering (Monday, 30 min)

Weights: Values/Behavioral 50%, Pressure 30%, Conversational 20%. Reason: the recruiter named the round "values and leadership philosophy".

Values cheat sheet: dropped. No published values were in hand, and the search was refused. The VAL questions below use selection scaffolds with their honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you took an unpopular position to leadership." | VAL | [generic] | Selection scaffold: pick a time you held a position under roadmap pressure, with a named stake, a moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing: the reliability quarter, and what it cost | Open prompt, theme from the recruiter's words. No claim about your past in the guidance |
| C2 | "What is your leadership philosophy, in a sentence?" | VAL | [generic] | Say it in your own words. Tie it to one decision you made, from the material you have | Common VP opener; no claim |
| C3 | "Why would you leave a payments company for a hardware-adjacent role?" | Pressure | [grounded] "I've never owned a hardware-adjacent roadmap." | Give the reason in your own words. Do not claim hardware work. Hold: "I haven't owned a hardware-adjacent roadmap," then what draws you to it | The VP will test motivation against the gap |
| C4 | "When did you last change your mind after hearing a push-back?" | VAL | [generic] | Selection scaffold: a time you changed a decision on evidence, with the stake named. If none, say so and give the nearest one | Open prompt on the values theme |

Reverse questions (round 3):
- "How do you measure a leadership decision after six months?" Why it lands: it shows you think about outcomes, not only the story.
- "What do you hope the next manager of this group will change first?" Why it lands: it asks for the VP's judgment about the role.

## Requirement-coverage line

| Requirement | Covered by | Gap |
|---|---|---|
| Lead two squads on device management | A1, B3 | — |
| Own delivery, hiring and growth for 11 engineers | A6 | Growth and delivery: none of your sentences state them. Answer slot in A6 |
| Partner with hardware and product on roadmap | A2, A3, B4, B5, C3 | — |

## Upgrade menu

- Paste the role's full job description → the requirement rows become `[grounded]` where now they are `[generic]`, and the coverage line gets checked against the real requirements
- Paste your CV → F1 to F3 gain a fuller quote, and the defend-the-number slots gain your exact wording
- Tell me whether the role has an office-day or location requirement → F6 becomes a gate row with a stated answer
- Paste Larkfield's published values or leadership principles → the round 3 values cheat sheet appears, with a mapped story per value
- Send the recruiter's notes on the process (focus areas, any deliverable) → round structure gets confirmed
- Tell me the interviewers' names → persona weights per panel member, and a tailored reverse question for round 1
