# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final. Interviewer(s): not known. Format: not known (single conversation or a set of sessions). Built on the request alone: no job description, no CV, and no web research (the search tool was refused, see Sources). Everything here is `[generic]` until you add material.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored (CASE = live problem, EXP = your past work, JD = the role's stated needs, CO = company knowledge, VAL = values, CASE and JD are the ones you can prepare most).
- Guidance is scaffolding, not a script. Speak each answer in 90 to 120 seconds.
- Where guidance says "answer slot", the interviewer will likely probe something your material does not yet show. Answer it in your own words from what you actually did. If you did not do it, say so plainly and say what you would do.

## Fit snapshot (worksheet variant)

No requirements were supplied, so these are role-family requirements written as prose, not quotes. No evidence exists in this conversation yet, so every evidence cell reads `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running operating processes, end to end (role family) | none given | none | [generic] | discovery | Answer slot: name one process you set up or changed, in your own words. If you did not set it, say so and describe the nearest process you did run. |
| F2 | Aligning teams that do not report to you (role family) | none given | none | [generic] | discovery | Answer slot: name one cross-team decision you helped land, what you did, and who else was involved. If none, say so and say how you would approach it. |
| F3 | Choosing metrics that drive decisions (role family) | none given | none | [generic] | discovery | Answer slot: name a number you used to decide something, how it was counted, and what you would defend least. If none, say so. |
| F4 | Running launches or programmes to a date (role family) | none given | none | [generic] | discovery | Answer slot: name one date-bound piece of work you drove, what slipped and why. If you did not drive one, say so. |
| F5 | Clear written updates for senior leaders (role family) | none given | none | [generic] | discovery | Answer slot: name one update you wrote for a senior audience and what it changed. If none, say so and describe how you would structure one. |

The candidate's background is the missing input. Without it, the snapshot cannot yet say which rows are strong.

## Prohibited claims

No sentence from the candidate's own record exists yet, so there is no inflated form to list. The standing rule for this pack: any claim about your experience must be one you can repeat under a second follow-up. Items will be added here once a CV or your own notes are shared.

## Persona table

Round type is unknown, so the weights are blended across a final round's usual mix. Session mode; the top weights are the most likely styles.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operations problems, such as a slipping launch or a cross-team dispute | High. A final round usually tests whether you can work on a live problem, and this role is mostly live problems | Clarify, then structure, then answer. Think aloud and challenge one premise |
| Skeptic | Quiet questions on motivation, gaps and "why now" | High. Finals are where motivation and gaps get checked | Rehearse the single most likely objection until it is plain. Name the gap, then the plan |
| Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. Operations roles lean on metrics, so the number you cite will be tested | Say what you know about how a figure was counted, and name the weakest assumption before they do |
| Peer Evaluator | Asks where the seam with their team is, and what happens when you disagree | Medium. Ops sits between product, engineering and finance, so a peer may join the final | Propose seam principles, not claims about their team. Offer what you bring them |
| Pressure / Stress | Time-boxed answers, interruptions, challenges to your credit | Medium. Senior finals often time-box and test composure | Pause, restate the question, hold a position through two follow-ups before conceding anything real |
| Conversational / Rapport | Open, friendly prompts such as "walk me through the journey" | Low to medium. Casual prompts are still scored | Keep a 90-second arc ready. Treat a casual question about the job as scored |
| Values / Behavioral | Asks for stories where you chose a value in action | Low. No values round is established, and the company's values were not checked (see Sources) | Two stories ready, each with an honest branch if none fits |

## Question banks

### Bank A: Case / Strategist (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our weekly launch-readiness checklist is slipping. Three of eight launches missed their date this quarter. What would you do first?" | CASE | [generic] | Clarify first: what counts as missed, who owns each launch, what the checklist is for. Then state the objective, split the misses by cause (late inputs, missing approvals, scope change), propose one test, name two metrics and one risk. Challenge one premise out loud | Live operations problem typical for the role family. Pattern only, not a claim about this employer |
| A2 | "How would you decide whether a team builds an internal tool or buys one for its intake process?" | CASE | [generic] | Criteria first: cost of delay, who maintains it, reversibility. Then a small pilot with a stop condition. Say what you would not decide yet | Tests structure under a make-or-buy trade-off, a common live problem |
| A3 | "Three teams disagree on next quarter's priorities. Walk me through how you get to one plan." | CASE | [generic] | Name the decision owner first. Then the inputs each team needs, the trade-off each one is protecting, and a dated decision rule. Do not pretend the disagreement away | Cross-functional alignment is the core of the role family |
| A4 | "What would you want to learn about our business in your first 30 days to be useful?" | CO | [generic] | Name two or three specific questions about how the operating model works, not facts about the company. Say plainly that you have not researched the company in depth if that is true | No company research ran, so this is a question you must answer from your own preparation, not from this pack |
| A5 | "Pick one operational metric you would put on this team's dashboard. How could it mislead you?" | CASE | [generic] | Name the metric, then the assumption behind it you would defend least, then the second metric that checks the first | Metric questions include the weakest-assumption move by design |

### Bank B: Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why do you want an operations role, and why this one?" | EXP | [generic] | Highest-ROI prep in this pack. Give the one pattern that links your past work to this role, in your own words. If you cannot name a concrete instance, say so and name what you would do to build the experience. Then stop | Motivation is the objection most finals test. The pack cannot see your history yet, so this is a selection scaffold |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name one honest gap, then the first 30 days you would spend closing it. Hold it, do not deflect or over-explain | Final-round interviewers ask this to test self-assessment |
| B3 | "Tell me about a time you were accountable for an outcome you did not control." | EXP | [generic] | Selection scaffold: pick a time with a named outcome, a decision you made, and what you did when it went against the plan. If none comes to mind, say so plainly, then give the nearest thing you have | Accountability without authority is central to operations |
| B4 | "What would make a hiring manager hesitate about you for this role, and what would you say to that?" | Skeptic | [generic] | Name the hesitation honestly, then the evidence you would offer. Do not argue it away | Invites candor and tests whether you can handle a challenge to your own case |

### Bank C: Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you would measure whether a process change actually worked." | CASE | [generic] | Baseline, comparison group or before-and-after, the confound you would worry about most, and the decision the number feeds. Name the weakest assumption | Measurement design is a standard probe for this role |
| C2 | "Pick a number you have used to make a decision. How was it counted, and what would you defend least?" | EXP | [generic] | Selection scaffold: name the number and the decision. Then how it was counted, and the assumption you would defend least. If you have not used a number to decide something, say so and describe how you would count it | Tests whether you know how your own figures were made |
| C3 | "Which metric would you retire from a dashboard, and why?" | CASE | [generic] | Name the metric, what it encourages people to do, and what you would track instead | Tests judgment about metrics that mislead |

### Bank D: Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between ops and engineering in a launch, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who decides scope and who decides timing. Do not claim to know their team's seam | Peers price the hire by how it affects their load |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: name a shared piece of work, how credit was given, and what you would do next time. If you have not had such a case, say so | Credit-sharing is a common peer probe |
| D3 | "What would you need from my team to be useful in your first month?" | JD | [generic] | Name two or three concrete asks, and what you would bring to their team in return | Reciprocity framing turns the probe into a partnership conversation |

### Bank E: Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate the question. Give one reason tied to the role's needs and one honest limit. Hold that position through two follow-ups. Concede a specific uncertainty if asked, never the core claim | Pressure questions test composure, not content |
| E2 | "Think of a process you improved. How much of the improvement was actually yours?" | EXP | [generic] | Selection scaffold: name the process, your part, and the part others played. Be exact about the split | Attribution is tested under pressure |
| E3 | "We have ten minutes. Give me your top-line view of what this role should fix first." | CASE | [generic] | Name the first problem, why it comes first, and one thing you would check before acting. Keep it short | Tests prioritization under time pressure |

### Bank F: Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: each role in one line, then the thread that leads to operations. Build it from your real history only | Casual openers are scored for economy and clarity |
| F2 | "What are you reading or working on lately that's relevant to operations?" | JD | [generic] | Name one real thing and what you took from it. Do not name anything you have not actually read or used | Casual prompts about the job are scored |

### Bank G: Values / Behavioral (2 questions, low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you raised a hard truth to someone more senior." | VAL | [generic] | Selection scaffold: pick a time with a stake, what you said, and how it landed. If none comes to mind, say so, then give the nearest one | Common behavioral probe for senior finals |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: name the customer, the metric, and the decision. If you have no such instance, say so | Common behavioral probe; company values not checked |

Requirement coverage: no JD was supplied. Role-family requirements mapped to questions: process design (A1, A2, F1); cross-team alignment (A3, D1, D3); metrics (A5, C1, C2, C3); ownership and accountability (B3, E2); written updates and prioritization (E3, G1).

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for someone in this role?" | Shows you are planning for the outcome, not just the job |
| R2 | "Which operational problem would you most want this role to fix in the first quarter?" | Surfaces their priority and invites them to name the pain |
| R3 | "How does the team measure whether ops work is succeeding?" | Shows you want to know what you will be graded on |
| R4 | "Who would I work most closely with across product, engineering and finance, and how do those relationships work today?" | Tests the seams, and shows you think in cross-team terms |
| R5 | "What has the team learned from an operations initiative that did not go to plan?" | Invites candor and signals you expect trade-offs |
| R6 | "Is this final one conversation or several sessions, and who is in each?" | A planning question that helps you prepare for each session |

## Sources

Research tier: L1, searches 3 of 6, fetches 0 of 2. All three searches were sent and refused by the host, so no company facts were retrieved.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet. Refused: "Stripe company values" |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Refused: "Stripe interview process product operations final round" |
| 3. Stripe strategy and recent news | unavailable | Company and strategy questions in Bank A (A4). Refused: "Stripe strategy recent news 2026" |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot rows and JD-tagged questions. Not sent; the host refused the search tool |

Provided documents: none beyond the request itself. No dossier was present.

Because no research ran, the values round is not detected and no values cheat sheet appears. The loop structure is unknown and the persona weights are blended for that reason.

## Upgrade menu

- Your job description, pasted → fit snapshot rows become `[grounded]`, and the questions in Banks A to D tie to the posting's own words
- Your CV, pasted → fit snapshot rows get quoted evidence, and the answer slots become story maps where your sentences carry them
- The recruiter's note about the final → the round's format, who is in each session, and any take-home or presentation gets its own build section
- The interviewer's name → persona weights from their public footprint, and a tailored reverse question
- Stripe's values page, pasted → a values cheat sheet, if the round turns out to be values-style
- Web search allowed for this session → the target accounting above reruns, and company-specific questions replace the `[generic]` rows
- A deeper research pass, up to 6 more searches and 2 more fetches, several extra minutes, once search is allowed → company strategy and recent organisational context for Bank A. Want it when search works?
