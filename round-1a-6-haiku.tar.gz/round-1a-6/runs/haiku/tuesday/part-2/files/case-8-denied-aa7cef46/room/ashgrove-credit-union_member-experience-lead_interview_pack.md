# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Rounds:** three, on 5 December 2026 (loop mode)
**Interviewers:** not yet assigned. Round 2 is with the Head of Member Services, your future manager. Round 3 is a panel of two branch managers. No names, so no interviewer read.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **VAL** behavioural and values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script. Rehearse it aloud, in your own words.
- Labels: **[grounded]** traces to your message, the JD, the values page or the strategy brief as you gave them to me. **[inferred]** is a derivation. **[generic]** is a pattern for the problem, with no claim about you or Ashgrove.
- No CV was supplied. Every sentence about your experience below is quoted from your message.

## Prep triage

Nine days to the rounds. In order:

1. **H4**, the contact-centre question. Say the plain acknowledgment and the plan aloud until they come out without hedging. Then **H7**, holding your position through two follow-ups.
2. **The four values** (section 10). One sentence and one story each, or the honest branch, by 3 December.
3. **S1**, your 90-second background arc, timed.
4. **P5 and P6**, the escalation case. Walk the structure once aloud with a timer.
5. **S2 to S5**, the logistics. Decide your own answers in advance.

Everything else is insurance.

## Fit snapshot

No gate in the JD or the recruiter's email: experience length is graded on fit, not treated as a gate. Confidence reflects your message alone, since no document was inspected.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log." (your message) | medium | [grounded] | transferability | Your material says the branch log, not the end-to-end process. Words: "I handled the branch's formal complaints log." Answer slot: if you owned a stage beyond the log, say which and how you decided. If not, say so and stay with the log. |
| F2 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is not coaching supervisors, so do not stretch it. Answer slot: if you coached supervisors on escalations, say how. If you only trained tellers, say so and stay with the training. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The sentence reaches monthly complaint reporting. Resolution times are not in it. Words: the sentence as written, with no added figure or measure. Answer slot: if the spreadsheet recorded resolution times, say how they were counted. If not, say so and say what you would add first. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a gap you stated. Answer slot: if you worked with a digital or app team on a member journey, say what you did and what was yours. If not, say so and say what you would do first. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then a plan for your first senior presentation, as a plan. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Covered in role-relevant terms. Words: "6 years in retail banking, the last 3 as a branch supervisor." Expect a probe on what the customer-operations work covered. |
| F8 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log." (your message) | medium | [grounded] | transferability | Your material says formal, not regulated. Words: the sentence as written. Answer slot: if outside rules or timelines applied to that log, name them as you dealt with them. If none did, say so and describe the formal process you ran. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Name the tool only if it was Excel. Words: the sentence as written. |

## Prohibited claims

What this pack will not coach, built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked in or ran a contact centre | Negative you stated (F2) | "I've never worked in a contact centre." No slot. |
| Presented to senior leaders | Negative you stated (F6) | "I've never presented to anyone above regional level." No slot. |
| Owned the complaints process end to end | Inflated form of F1 | The F1 quote at its own scope. The limit is the pack's own observation: your material says the branch log. |
| Coached branch supervisors | Inflated form of F3 | "trained new tellers on our escalation script" at its own scope. |
| Reported resolution times | Inflated form of F4 | The F4 quote at its own scope. Your material does not say resolution times. |
| Handled regulated complaints | Inflated form of F8 | "I handled the branch's formal complaints log." Your material does not say regulated. |
| Used across the whole region | Inflated scope of F4 | Your material says your regional manager uses it. Nothing wider. |

## Grounding brief

Your note on the 2026 strategy brief (July 2026). Check these against the original brief before you quote any of it in the room.

| Item | Brief, as you noted it | Provenance |
|---|---|---|
| Digital | Move 40% of member service to digital channels by 2028 | [grounded] your note on the brief |
| Branches | Consolidate eight branches into five hubs over 2027 | [grounded] your note on the brief |
| Lending | Launch a small-business lending product in Q1 2027 | [grounded] your note on the brief |
| Competition | The main pressure is app-only banks | [grounded] your note on the brief |

## Sources

Research tier: L1, searches 0 of 6, fetches 0 of 2. Nothing was searched or fetched. Every needed fact came from material you gave me.

Provided documents: the JD (your paste); the values page (your paste, copied from ashgrovecu.org/about/values on 26 November 2026); the recruiter's email on the rounds; your note on the 2026 strategy brief; your background (your message).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the four names and definitions used in section 10. |
| 2. Ashgrove interview process | skipped | The recruiter's email names three rounds, their lengths, the panel's case and the values scoring. That is a loop source, so the loop is established and no archetype is used. |
| 3. Ashgrove strategy and news | skipped | Your note on the July 2026 brief is under six months old and fixes the grounding brief. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

---

## Round 1: recruiter screen (30 minutes)

**Relationship:** recruiter. **Weights:** Conversational leads, with light Skeptic. Logistics and motivation are checked in a friendly register, but they are scored.

| Persona | Depth | Reasoning |
|---|---|---|
| Conversational | 5 | The recruiter's prior. Logistics, motivation and an opener all arrive in this register. |
| Skeptic (light) | 1 | Round 1 can surface the contact-centre gap early, so it needs one rehearsal. |
| Peer, Pressure, Case | 0 | Not weighted for a screen. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in the order these sentences state them: the six years and the supervisor years, then the complaints log you handled, then the spreadsheet your regional manager uses. Stop there. Add no practice. | An opener that is scored. Covers F7 and touches F1, F4, F8 and F9 without stretching any of them. |
| S2 | "What's your notice period?" | JD (notice) | [generic] no claim about you | Logistics slot: give your actual notice period in your own words. | A logistics row. No figure is supplied or suggested. |
| S3 | "What are your pay expectations for this role?" | JD (pay) | [generic] no claim about you | Logistics slot: give the range you would accept, in your own words, or ask for the role's band first. No figure is supplied here. | Pay is asked in the logistics register. Any figure is yours to give. |
| S4 | "Where are you based, and what location arrangements could you work?" | JD (location) | [grounded] "consolidate eight branches into five hubs over 2027" (your note on the brief) | Logistics slot: say where you can work and any limit you hold, in your own words. Answer for your own location only. | The 2027 hub plan is why location may come up. |
| S5 | "Why are you looking to move on?" | EXP (reason for leaving) | [generic] no claim about you | Logistics slot: give your own reason, short and true, in your own words. No reason is supplied here, so none is suggested. | Reason for leaving is a logistics slot. Once you have given it, it is not asked again. |
| S6 | "You haven't worked in a contact centre. Is that going to be a problem?" | JD (F2) | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then your branch complaints work, at its own scope. Then one plan line for learning contact-centre routes. Do not describe contact-centre work you have not done. | F2, asked lightly here. The deep rehearsal is H4. |
| S7 | "Our strategy moves 40% of member service to digital by 2028. Where does complaints handling fit in that?" | CO, JD (F5) | [grounded] "move 40% of member service to digital channels by 2028" (your note on the brief) | Answer as a plan, not a past: which complaints would start in digital channels, and what you would check first. If you have worked on a digital or app journey, say what you did. If not, say so. | The strategy question at recruiter depth. It covers F5. |
| S8 | "Which of our four values do you think is hardest to live day to day?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (values page, your paste) | Pick one value. If your material shows no case of living it, say so, then name the one you would find hardest and what you would do. | The recruiter has said the panel scores against the four values, so this is a values preview. |

**Reverse questions**

- **RS1** "Which of the three rounds carries the most weight in the decision?" Why it lands: it shows you are planning, not guessing.
- **RS2** "Is the panel's scoring against the four values done on a shared rubric?" Why it lands: the answer changes how you prepare the values answers.

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Relationship:** future manager. **Weights:** Values/Behavioral leads, as the recruiter describes the round. Skeptic follows, then one Pressure and one Case question.

| Persona | Depth | Reasoning |
|---|---|---|
| Values/Behavioral | 4 | The recruiter says this round is mostly behavioural. That overrides the hiring-manager prior, which would lead with Case and Skeptic. |
| Skeptic | 3 | A hiring manager is buying capability and checking gaps. Your three stated gaps are the places they will press. |
| Pressure | 1 | Holds your position under a time box. |
| Case | 1 | A short live problem from the 2027 hub plan. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Walk me through a complaint from first contact to closure, and where you were in it." | VAL, JD (F1) | [grounded] "I handled the branch's formal complaints log" (your message) | Story map: the log you handled, using the beats that sentence states. Answer slot: which steps from first contact to closure were yours to set or run. If you handled only the log entries, say so and describe what you did with each. | F1 is the end-to-end requirement. This is its likeliest probe. |
| H2 | "Tell me about a time you coached someone to handle an escalation themselves." | VAL, JD (F3) | [grounded] "trained new tellers on our escalation script" (your message) | Story map: the training you ran, using the beats that sentence states. Answer slot: if you coached supervisors on escalations, say how. If you only trained tellers, say so and stay with that training. | The JD asks about supervisors. Your material shows tellers. Do not stretch it. |
| H3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL (behavioural stem) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Scaffold: pick a time you told someone above you what they did not want to hear, with a named stake and what happened. If none comes to mind, say so plainly. Then give the nearest thing your material carries: the spreadsheet, and only what it actually showed you, in your own words. | A persona stem for the behavioural weight. The spreadsheet is the nearest sentence, and no more. |
| H4 | "I don't see contact-centre work in your background. How would you run complaints that start there?" | JD (F2) | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then a plan, not a past: what you would learn first about how contact-centre complaints arrive, and whom you would ask. Hold through two follow-ups by returning to your branch work and the plan. Concede the gap explicitly. Never claim the process. | **Highest-ROI prep.** The JD names the contact centre, the role spans it, and this objection will come in some form. Hold-then-concede is the structure. |
| H5 | "How would you present complaint trends to senior leaders?" | JD (F6) | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: how you would prepare your first senior presentation, and who would review it with you. | The senior-presentation line in the JD and your stated gap. The plan carries the answer. |
| H6 | "What did the formal complaints log involve, and what outside rules applied to it?" | JD (F8) | [grounded] "I handled the branch's formal complaints log" (your message) | Story map on the log. Answer slot: if outside rules or timelines applied, name them as you dealt with them. If none did, say so and describe the formal process you ran. | The JD says regulated. Your material says formal. |
| H7 | "Sixty seconds: why should we hire you over someone who has run a contact centre?" | Pressure, VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Hold your branch-supervisor position through two follow-ups. Six years and three as a supervisor are what you bring. Concede the contact-centre gap explicitly and specifically. Do not fold on the branch claim. | Hold-then-concede. The position you hold is the one your sentence carries. |
| H8 | "Consolidation takes eight branches into five hubs during 2027. What would you check about complaints before the first branch closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your note on the brief); structure [generic] | Clarify first: which complaints are open, and where they came from. Objective: no complaint lost in transfer. Approach, then metrics and risks. Think aloud, and challenge one premise. | A live problem drawn from the company's own plan. It presumes nothing about your past. |
| H9 | "Tell me about a time a member came back angry after you thought their complaint was closed." | VAL (behavioural stem) | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a time a closed complaint reopened, with the stake and what you did. If none comes to mind, say so, then give the nearest thing the log carries, and only what you handled in it. | A behavioural stem. The log is the nearest sentence. |

**Reverse questions**

- **RH1** "What would a good first 90 days look like for the complaints process?" Why it lands: it shows you think in terms of ownership.
- **RH2** "How are complaint volumes and resolution times reviewed today, and with whom?" Why it lands: it tests what the monthly report is for, without assuming it.
- **RH3** "Which branches move first in the 2027 hub changes, and what do you need from complaints handling on that?" Why it lands: it shows you read the brief and ask what the role must do.

---

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

**Relationship:** panel. **Weights:** blended across the two members. Values/Behavioral leads, because the recruiter says the panel scores the four values. Then Case for the escalation case, one Peer question, and one Prober question.

| Persona | Depth | Reasoning |
|---|---|---|
| Values/Behavioral | 4 | The recruiter says this round is the values round. A values round is detected, so each value gets one question. |
| Case / Strategist | 2 | The 20-minute escalation case. |
| Peer Evaluator | 1 | Branch managers are peers to the role. Turf and seams are their probe. |
| Data-Driven Prober | 1 | They will check the monthly numbers you built. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a decision where the member's side of the counter decided it." | VAL (Members First, Always) | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold on the value: a decision you made from the member's side, with its stake. If none comes to mind, say so. Then give the nearest decision the log carried, and only what you decided. | Panel values round. The honest branch is the answer. |
| P2 | "Tell me about a time a member needed something explained twice, and what you did about it." | VAL (Plain Words) | [grounded] "trained new tellers on our escalation script" (your message) | Story map: the training, using the beats that sentence states. Answer slot: if you changed how the script was explained, say what and why. If you did not, say so and say how you taught it. | Plain Words. The F3 story is the nearest carrier. |
| P3 | "Tell me about a time a branch's place in its town shaped how you handled a complaint." | VAL (Neighbours, Not Numbers) | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message, F7) | Scaffold: pick a time, and say what the town needed from the branch. If none comes to mind, say so plainly. Your material shows no such time. | No sentence in your message carries a town story. The honest branch is the answer. |
| P4 | "When did you find a problem and keep hold of it until it was solved?" | VAL (Own the Fix) | [grounded] "I handled the branch's formal complaints log" (your message, F1) | Scaffold: a problem you found and stayed with until it was solved, with its stake. If you handled only the log, say what you did with each entry. If you did not see one through, say so. | Own the Fix. The published value is the raising source. |
| P5 | "A member has complained three times about the same fee, and says a refund was promised and never paid. Walk us through how you would handle this escalation." | CASE | [generic] pattern, not a fact about Ashgrove | Structure: clarify what was promised and by whom. Objective: the member's money back and the promise kept. Approach. Check the branch record. Decide who owns the fix and by when. Say what you would tell the member. Think aloud. | The 20-minute case the recruiter named. This scenario is an illustration, not the panel's own case. |
| P6 | "The member wants the refund in writing today, and the branch manager disagrees with your call. What do you do?" | CASE, Peer | [generic] pattern, not a fact about Ashgrove | Structure: clarify the basis of the disagreement. Keep the member's outcome in view. Take the manager's view seriously. Decide who makes the call, and record it. | Follows P5. The disagreement tests partnership inside the case. |
| P7 | "Our branches and the contact centre would send you their complaints. Where's the seam between them, and what happens when you disagree with a branch manager?" | Peer, JD (F2) | [generic] seam principles; no claim about you. The disagreement story is a selection scaffold on F1. | Propose seam principles rather than pretending to know the seam. Say what you bring to their teams, not only what you need. If you have disagreed with a peer, say how. If not, say so and name the principle you would start from. | Peer probe. It touches F2, so do not claim contact-centre knowledge. |
| P8 | "Does your monthly spreadsheet record resolution times? If it does, how were they counted?" | EXP, JD (F4, F9) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if it recorded resolution times, say how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. If it did not, say so and say what you would add first. | The prober asks rather than presumes, so no measure is supplied. |

**Values cheat sheet** (section 10, panel round). The panel's values round is documented by the recruiter's email, so this table is required.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log." Selection scaffold, with the honest branch in P1. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F3: "trained new tellers on our escalation script." Answer slot in P2. |
| Neighbours, Not Numbers | Each branch is part of its town | No sentence in your message carries a town story. Honest branch in P3: say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log." Selection scaffold in P4. |

**Reverse questions**

- **RP1** "Which of the four values carries the most weight when you score?" Why it lands: the answer tells you where to spend your preparation time.
- **RP2** "What does a complaints lead need from branch managers that they don't get today?" Why it lands: it is reciprocity, which a peer interview rewards.

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches (F1) | H1, P4 |
| The contact centre (F2) | S6, H4, P7 |
| Coach branch supervisors on escalations (F3) | H2, P2 |
| Report monthly on complaint volumes and resolution times (F4) | P8 |
| Work with digital teams on self-service journeys (F5) | S7 |
| Confident presenting to senior leaders (F6) | H5 |
| 4+ years in financial-services customer operations (F7) | S1 |
| Experience handling regulated complaints (F8) | H6 |
| Comfortable with Excel reporting (F9) | P8 |

Session total: 25 questions across the three rounds (S1 to S8, H1 to H9, P1 to P8), plus 7 reverse questions.

---

## Upgrade menu

- **Interviewer names** (the Head of Member Services and both panel members). Persona weights come from their public footprint, and each gets a tailored reverse question. Public professional footprint only.
- **Your CV.** The quotes would then come from a document, not only your message. Confidence can reach high only where an inspectable artifact backs the claim. For F4 and F9, that is a copy of the spreadsheet's layout with no member data in it.
- **Any work outside banking with a phone or call-handling element.** This is the only thing that could move F2 off capability. If there is none, the plain acknowledgment in H4 stays as it is.
- **Any digital or app team work.** This moves F5 from discovery to grounded.
- **Your notice period, pay approach, location and reason for leaving, in your own words.** These fill the logistics slots in S2 to S5.
- **The recruiter's note on how the panel scores the four values.** This replaces the honest branches in section 10 with the actual criteria.
- **A deeper research pass (L2)**, offered once: up to 6 more searches and 2 more fetches, several minutes. It would cover role-family loop reports for Ashgrove and recent leadership or reorganisation news. Say if you want it.
