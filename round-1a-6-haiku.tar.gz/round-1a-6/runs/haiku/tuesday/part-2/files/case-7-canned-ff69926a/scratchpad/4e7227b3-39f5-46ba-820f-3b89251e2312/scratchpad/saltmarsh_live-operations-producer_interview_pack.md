# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the Outage Hour, a single 60-minute hiring-manager interview (company interviewing page): a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

Session mode. The loop is established by the company's own page, so no archetype fallback applies.

## How to use + type key

Personas = how it's asked. Types = what's scored.

| Tag | Meaning |
|---|---|
| CASE | Live problem from the role, delivered live (the tabletop) |
| VAL | Behavioral question tied to a published value |
| EXP | Deep-dive on what you actually did |
| JD | Stated responsibility or requirement from the posting |
| CO | Company strategy, from research |

Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Time to prep was not stated, so this is an order, not a schedule.

1. **Outage tabletop (A1 to A3).** It is the round's centrepiece and it is a live problem, so rehearse the first ten minutes out loud.
2. **Project Larkspur (A3, C3, R2).** Research found that two titles move to one shared calendar from February 2027. The JD's "two of our mobile titles" is probably this change. Know it before you walk in.
3. **The highest-ROI objection, "you've never led a team" (E1, C1).** Rehearse the plain acknowledgment and the coordination evidence you do have, then stop.
4. **Values (B1 to B4).** Map each published value to a story you actually have, or give the honest branch.
5. **Retention numbers (D1, E2).** Be ready to say which parts you built and which you only presented.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD (the user's input). Evidence is quoted from your message, marked "your message". Quotes are exact.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, not two titles' live events. For two years you ran the calendar for one title. The second title is not in your material. Answer slot: if you ran or shared a calendar for more than one product, say how; if not, say so and say what you would do first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | QA is one cross-team touchpoint your material shows. Design, art, engineering and community coordination is not in it. Answer slot: if you have run an update that needed those four teams, say which and what you did; if not, say so and describe how you would run one. |
| F3 | "own the post-event review" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran one, say what it covered and what you changed after; if not, say so and say what you would review first. |
| F4 | "the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your material says you presented the retention numbers. It does not say you chose the KPIs. Say what you presented in your own words, and who built the figures. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | This is a direct match. The checklist is in use, which is limited inspectable proof: expect a probe on how it is maintained. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Four years of producing is stated. Live-service fit is carried by the content-drop work (F7), and the title was "associate". Say the years and the title as stated. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Direct match. Expect a probe on how the calendar was planned and who signed off each drop. |
| F8 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Presenting is stated. Analysing is not. Expect a probe on how the numbers were built (see D1). |
| F9 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | A written artifact that a team uses every release is in your material. Say that, rather than adjectives. |
| F10 | Not in the JD. The candidate's stated absence: "Never led a team" (your message) | none given beyond the absence | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." Then how you would learn it, as a plan and never as a past. |
| F11 | Not in the JD. The candidate's stated absence: "never worked on a game with in-app purchases" (your message) | none given beyond the absence | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then how you would learn the purchase data, as a plan. |

Routing: F10 and F11 are not JD requirements. They are your own stated gaps, so they are carried as capability rows and the pack gives back only your own words.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one title, not two. |
| Led a team | Negative you stated (F10) | "I've never led a team." Then the coordination you do have, at its own scope. |
| Has worked with in-app purchase data | Negative you stated (F11) | "I haven't worked on a game with in-app purchases." |
| Built the retention analysis | Inflated form of F8 | "I presented the monthly retention numbers to the studio head." The pack's observation: your material says presenting, not building. |

## Interviewer read

- **Career pattern (public):** Previously a QA lead at a console studio; now Head of Live Operations at Saltmarsh Games. Source: GDC 2026 talk listing.
- **Published argument:** "Patch Notes Are a Promise" (GDC 2026). The talk's thesis, as its listing states it: a live team is judged by how often its patch notes describe what actually shipped.
- **Practical implications:**
  1. Expect a probe on whether what you announce matches what shipped. That is B2 and the release checklist (F5).
  2. He came up through QA. Speak to the checklist plainly, without over-claiming QA expertise.
  3. The round includes a live incident. Use the tabletop to show what you would announce during an outage, not only what you would fix.
- **Mirror opportunity:** QA is common ground. The sentence to use is F5's own: "Wrote the release checklist our QA team still uses." Do not claim shared background beyond that.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop, with a live problem from a live event | Highest. The company page makes the tabletop the core of the 60 minutes | Clarify what is live and who is affected before deciding. Think aloud. |
| Values/Behavioral | The values conversation, scored against the three published values | High. The page says the round ends in a values conversation | One story per value, or the honest branch. |
| Pressure | Time-boxed challenge on the gap in leadership, or on how much of a result was yours | Medium. A stress-style interviewer is common in an incident setting | Pause, restate, hold a challenged position through two follow-ups. |
| Data-Driven Prober | Asks how the retention figure was counted | Medium. The JD asks for retention comfort, and F8 is presentation, not analysis | Say which part you built, and which you only presented. |
| Skeptic | "Which part of this role would you be weakest at on day one?" | Medium. The leadership gap is your own stated gap | Give the plain acknowledgment, then the plan. |

Weights: Case/Strategist 5 questions, Values 4, Pressure 3, Prober 3, Skeptic 3. Total 18, within the pack's target range.

## Question banks

### A. Case/Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event's reward server fails forty minutes in. Walk me through the first ten minutes." | CASE | [generic] | Clarify what is live, which players are affected, and what they see right now. Decide between pause and hotfix. Say who you tell first, and what you say publicly. | Mirrors the tabletop named on the company page. No claim about your past. |
| A2 | "Players are mid-event and engineering says the fix needs a day. What do you do?" | CASE | [grounded] "we announce what is built, not what is hoped" (values page) | Name the trade-off between the players and the plan. Decide what you will announce, and say it only when it is built. | Ties to the published value; the premise is the company's own line. |
| A3 | "We are moving two titles to one shared events calendar from February. What do you protect first?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Project Larkspur news, September 2026) | Name the one thing you would protect (a stable release gate, or player trust in the calendar). Say what you would need to know first. | Research-grounded strategy question. You are not asked about your past. |
| A4 | "You have three days to ship an update that needs design, art, engineering and community. How do you run it?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Set the order of the four teams and who decides each. Answer slot (F2): if you have run an update that needed those four teams, say which and what you did; if not, say so and describe how you would run one. | JD requirement F2. Honest branch allows that you have not done this. |
| A5 | "Walk me through how you knew a live event was failing before the numbers showed it." | EXP | [generic] | Name what you would check first (player reports, queue times, purchase or session dips). Say what you would stop doing. | An open prompt about a practice. No claim about your past. |

### B. Values/Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "when the calendar and the players disagree, the players win" (values page); F7 "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Scaffold: pick a time a drop was moved or held because of player signal. If no such time comes to mind, say so plainly, then give the nearest thing your calendar work carries, or how you would handle it. | Players Before Plans. The honest branch is required. |
| B2 | "How do you decide what you announce before it ships?" | VAL | [grounded] "we announce what is built, not what is hoped" (values page); F5 "Wrote the release checklist our QA team still uses" (your message) | Name the checklist gate, and say what it checked before a drop went out. Answer slot: if the checklist stopped an announcement, say that; if it did not, say what it did check. | Ship the Patch Not the Promise. Use the checklist only as far as F5 carries it. |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them" (values page); F5 "Wrote the release checklist our QA team still uses" (your message) | Scaffold: pick a change you made to the checklist or the calendar. Say what was better afterwards, in your own words. If none comes to mind, say so plainly, then give the checklist as the nearest thing your material carries. | Leave the Build Greener. |
| B4 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Scaffold: a moment you presented a number that was not good news. If the numbers were not bad, say so plainly and give the nearest moment. | Values round, open prompt. The honest branch is required. |

### C. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message) | Give the plain acknowledgment: "I've never led a team." Then the coordination you have (F5), then a plan for learning to lead. | F10, the highest-ROI objection. The plain acknowledgment is your own words. |
| C2 | "You've run one title's calendar. How would you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Keep the answer at your one title. Answer slot: what would change with a second title, and what you would check first. | F1 transferability. Do not describe two titles you have not run. |
| C3 | "How would you plan an event around a paid season pass?" | CO | [grounded] "season-pass model" (Project Larkspur news); F11 "I haven't worked on a game with in-app purchases." (your message) | Say plainly that you have not worked on purchase-led events. Then say what you would need to know about purchase data. | F11, given back in your words, followed by a plan. |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention figure you presented was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you built the numbers, say how, in your own words. If you only presented them, say so and say who built them. Name the assumption you would defend least. | Premised question: it presupposes only that you presented a figure (F8). |
| D2 | "Which post-event KPI would you defend least?" | JD | [generic] | Name the weakest assumption behind the KPI, before he does. Do not invent a KPI you have not used. | F3, the post-event review gap. |
| D3 | "What did the retention number tell you that the event itself did not?" | JD | [generic] | Say what the retention number can and cannot show. Keep it to what you can say from your own work. | Retention comfort, asked as a reasoning question. |

### E. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message); F5 "Wrote the release checklist our QA team still uses" (your message) | Hold: name the coordination you have, at its own scope. Concede: "I haven't led a team." Hold through two follow-ups. Do not fold on the coordination you have. | Hold-then-concede on the stated gap. |
| E2 | "That retention figure: how much of it was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: you presented it. Concede: if you did not build it, say so. Name what was yours in your own words. | Attribution pressure. Hold, then concede the exact part. |
| E3 | "We are retiring per-title event teams in February. Convince me you can run one team." | CO | [grounded] "retires per-title event teams in favour of a single live-ops group" (Project Larkspur news) | Name what you would keep from the per-title model, and what you would give up. Say what you would need to see first. | Strategy-grounded pressure on the restructure. |

## Coverage: JD requirement to question

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, C2, E3 |
| Coordinate design, art, engineering and community teams | A4, A2 |
| Own the post-event review and the KPIs | D2, D3, E2 |
| Manage the release checklist with QA | B2, B3 |
| 3+ years producing live-service games or apps | none, and why: the years are one stated fact, given in one sentence in your opening |
| Experience running a content calendar | B1, C2 |
| Comfortable with player-retention metrics | D1, D3, E2 |
| Clear written communication | B3 |

## Values / principles cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold (B1), with the honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold on F5 (B2), with the honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | Scaffold on F5 (B3), with the honest branch |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "The Outage Hour has a tabletop and then a values conversation. Which part tells you most about how someone will run a live event?" | Shows you read the round's structure. |
| R2 | "With Project Larkspur moving two titles to one calendar from February 2027, what does the first ninety days look like for this role?" | Shows you read the news, and asks about the role's real shape. |
| R3 | "Your GDC talk argues that patch notes are a promise. What did the QA side teach you that the calendar side would miss?" | Ties to his own path, from QA lead to Head of Live Operations, and asks for his reasoning. |
| R4 | "When a live event misses its retention target, who decides whether the post-event review is shared?" | Tests the KPI ownership you would be asked about. |
| R5 | "Which per-title event team is retired first, and what happens to the release checklist?" | Ties to F5 and the restructure, and shows you have thought about the checklist. |
| R6 | "What does success look like at the ninety-day mark for the single live-ops group?" | A plain reverse question with a concrete measure. |

## Sources

Provided documents: your message (the JD and the background, as pasted).

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches and fetches sent:
- "Saltmarsh Games values": returned saltmarshgames.com/values (fetched). Values: Players Before Plans; Ship the Patch Not the Promise; Leave the Build Greener.
- "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing (fetched). Round: the Outage Hour.
- "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur (snippet only; not fetched).
- "Tobias Wrenfield Saltmarsh Games": returned talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only).

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet (section above) and B1 to B3 |
| 2. Saltmarsh Games interview process | yes | Round structure: the Outage Hour, persona weights, A1 to A5 |
| 3. Saltmarsh Games strategy / news | yes | A3, C3, E3, R2, R5: Project Larkspur |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, R3, mirror opportunity |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- A recruiter email confirming whether the Outage Hour includes a tabletop with a named scenario → sharper A1 and A5.
- Your own description of any cross-team update you ran → F2 moves from discovery to grounded, and A4 gets a real story.
- Your retention analysis, or the sheet you presented → F8 and D1 move from presentation to grounded, and the attribution slot can be answered with evidence.
- A deeper research pass on Project Larkspur (up to 6 more searches and 2 more fetches, several more minutes) → a fuller strategy brief for A3, C3 and E3.
