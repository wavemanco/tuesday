# Interview prep pack: Engineering Manager, Larkfield Systems (three rounds)

Loop mode: one shared fit snapshot, then a mini-pack per round. Built from your role summary and your message; no full JD or CV was supplied, and no research ran (see Sources).

Rounds: Tuesday, 45 min, hiring manager (Director of Engineering). Thursday after, 60 min panel (two staff engineers, one product manager). Following Monday, 30 min, VP Engineering, described by the recruiter as "values and leadership philosophy."

## How to use, and the type key

Personas describe how a question arrives. Types describe what is scored. Guidance is scaffolding for a spoken answer, not a script.

- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: role-driven; can you do the listed job, gaps included
- **CASE**: live problem from the role, delivered live
- **CO**: company and strategy knowledge (not covered; no research ran)
- **VAL**: behavioral and values alignment

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, for three years, not two squads. Words: "For three years I was a team lead of six." Answer slot: if you have planned work across two teams, say how, in your own words; if you have not, say so and say what you would do first. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Hiring reaches backend interviewing, not owning hiring for 11 engineers across squads. Delivery reaches one reliability quarter. Growth has no sentence in your material. Words: "I run our hiring loop for backend roles." Answer slot on growth: if you have grown engineers, say how and what changed; if not, say so and say what you would start with. |
| F3 | "partner with hardware and product on roadmap" (role summary) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | You stated the absence of owning a hardware-adjacent roadmap. Words: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you have worked on a roadmap alongside a hardware team, say what you did; if not, say so, and say how you would start. Your material does not show partnering either way. |

Confidence and provenance are one token each. F3 is `none` confidence because the stated absence is a negative, and its bridge comes only from your own words.

## 2. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "For three years I was a team lead of six." The pack's observation, in analysis only: your material says one team of six, not two squads. |
| Owned hiring for 11 engineers | Inflated form of F2 | "I run our hiring loop for backend roles." Analysis only: the material says backend interviewing. |
| Set the quarter's priorities | Inflated form of the Q4 sentence | "I pushed a reliability quarter through against roadmap pressure." Analysis only: the material does not say who set its contents. |
| Managed managers | Negative you stated | Plain acknowledgment: "I haven't managed managers." No slot. |
| Owned a hardware-adjacent roadmap | Negative you stated | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot. |

## 3. Persona table

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Hiring manager | Skeptic | Quiet probing of "never managed managers" and the hardware gap | Highest. This is the buying-decision gap the Director is most likely to test. | Rehearse the acknowledgment and a plan, not a past (A1 to A2). |
| Hiring manager | Case/Strategist | Live problems on the device-management roadmap | Medium. Hiring managers buy capability and test on their own roadmap. | Clarify, then structure, then name risks (A5 to A6). |
| Hiring manager | Pressure | Short time-box, challenge on the 60% | Medium. A Director often tests composure on a headline number. | Hold through two follow-ups, concede specifically (A8 to A9). |
| Panel | Peer Evaluator | Seams with hardware, credit sharing, what you need from them | High. Staff engineers and the PM price the hire against their own load. | Reciprocity framing; seam principles, not claimed knowledge (B1 to B4). |
| Panel | Data-Driven Prober | Counting the 60% and the 40 interviews | High. Two staff engineers will check numbers against assumptions. | Name the weakest assumption before they do (B5 to B7). |
| Panel | Case/Strategist | Product tradeoffs with a reliability fix | Medium. The PM will test the roadmap-pressure story as a live decision. | Clarify, objective, approach, metrics, risks (B8 to B9). |
| VP | Values/Behavioral | Unpopular truth, customer over metric, team that tells you when you are wrong | High. The recruiter named this round a values round. | Scaffolds ending in the honest branch; no invented endings (C1 to C4). |
| VP | Pressure | Why trust you with two squads without managing managers | Medium-high, given the stated gaps. | Plain acknowledgment, then how you would learn (C5 to C6). |
| VP | Case/Strategist | Strategy-level problem at skip-level altitude | Low-medium. | Structure first, time-boxed (C7 to C8). |

## 4. Round 1: Hiring manager, Tuesday (45 min)

Weights: Skeptic 4 (top), Case/Strategist 3, Pressure 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads is more than you have led. Which part of this role would you be weakest at on day one?" | JD | [grounded] "3 as a team lead of 6" (your message); "Lead two squads building device-management services" (role summary) | Say the plain acknowledgment first: "I haven't managed managers." Then name the day-one weak point in your own words and the first thing you would do about it, as a plan. Hold through two follow-ups by returning to the plan. | This is the highest-ROI rehearsal. F1 and F3 are where the Director will press. The objection is aimed at the thinnest part of your material, so do not thicken it. |
| A2 | "You haven't owned a hardware-adjacent roadmap. How would you partner with the hardware team on one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan for partnering: how you would learn the hardware constraints and where you would ask. Answer slot: if you have worked alongside a hardware team on a roadmap, say what you did; if not, say so. | F3 is capability. The negative is yours, so you can say it plainly. |
| A3 | "How was the 60% on-call reduction counted, and which figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number: say how it was counted, in your words. If you cannot say how it was counted, say that. Name the assumption you would defend least before they do. | Headline metric; magnet for probers. Your message gives no counting method, so the pack supplies none. |
| A4 | "You pushed a reliability quarter through. Which parts of it were your decision, and which were set by someone else?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: say which parts were your call, in your own words. If the scope was set by someone else, say so plainly and describe what you did to get it through. | Attribution honesty. The material says you pushed it through, not that you set its contents. |
| A5 | "Your device-management service sees a rise in check-in failures across a customer fleet. How do you plan the next two weeks?" | CASE | [generic] | Clarify the failure mode and scope, then objective, segmentation, approach, metrics, risks. Think aloud. The question asks about no past of yours. | Live problem from the role's device-management scope. |
| A6 | "Hardware and product disagree about a firmware date your squads depend on. What do you do?" | CASE | [generic] | Clarify what the dependency is and who owns the date. Name the decision owner. Propose seam principles, not a claimed past. | Role summary raises the partnership with hardware and product. |
| A7 | "The role owns hiring and growth for 11 engineers. How would you grow the people you hire, and how would you know it is working?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what you ran, in those words. Then the plan for 11 engineers. Answer slot on growth: if you have grown engineers, say how and what changed; if not, say so. | Covers the hiring and growth requirements. The growth clause has no sentence in your material, so its branch is an answer slot. |
| A8 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | Sixty seconds, in order: your years, your team, your current company, one thing you did. Hold the position through two follow-ups. Do not claim what your message does not say. | Pressure format. The stem is the persona table's, and the answer is only what your message states. |
| A9 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede. Say what you drove and what the team did, in your own words. Concede the part that was not yours specifically. Never fold on the core claim. | Pressure on attribution. |

Reverse questions (Round 1):
- "What would make the first 90 days look like a success to you?" Why it lands: turns the Skeptic into a success-criteria conversation.
- "Which of the two squads is more at risk right now, and why?" Why it lands: shows you think about the roadmap, not just the job.

## 5. Round 2: Panel, Thursday (60 min)

Weights: Peer Evaluator 4 (top, staff engineers and PM), Data-Driven Prober 3, Case/Strategist 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your squads and hardware, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam. Answer slot: if you have disagreed with a peer team, say how you handled it, in your own words. | Peer stem. Persona table's stem; no past claim. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Answer slot: if you can name a time credit was shared across teams, say it in your own words; if not, say how you would do it. | Peer stem. |
| B3 | "What would you need from us, and what could your squads give ours?" | JD | [generic] | Reciprocity framing. Name what you would bring the peer team, not only what you need. | Reciprocity question for a peer panel. |
| B4 | "The role owns delivery for 11 engineers. How do you decide what goes into a quarter when product and hardware both push?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Story-mapped on the quote: the reliability quarter, roadmap pressure, the on-call drop. Answer slot: if you set what went in, say how; if you took it from others, say so. | Your one roadmap-pressure story. |
| B5 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Weakest-assumption move: name it in your own words before they do. Say plainly if you do not know how the figure was counted. | Metric question. |
| B6 | "How was the 40-interview figure counted, and what would you defend least about it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Defend-the-number: say how the figure was counted, in your words. Name the weakest assumption. If you cannot say how it was counted, say so. | Prober's standard follow-up on a count. |
| B7 | "What is one thing your team of six delivered in the three years you led it, that you can point to directly?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | Name one thing you can show. Answer slot: if you cannot point to one thing directly, say so, then give the nearest thing your material carries. | Prober probing the team-lead claim. |
| B8 | "A product lead asks you to delay a reliability fix for a quarter to ship a device feature. What do you do?" | CASE | [generic] | Clarify the cost of delay and the fix's risk. Objective, approach, metrics, risks. Name one premise you would challenge. | Live version of the roadmap-pressure story, asked fresh. |
| B9 | "Map your first two weeks with hardware and product on the roadmap." | CASE | [generic] | Clarify the roadmap and who is on it. Structure by week, not by team. Name the metrics you would watch. | Partnership is in the role summary. |

Reverse questions (Round 2):
- "What could a new engineering manager do in their first month that would genuinely help your squads?" Why it lands: reciprocity question for a peer panel.
- "Where do the staff engineers think the device-management services are most fragile right now?" Why it lands: asks for the technical reality you will inherit.

## 6. Round 3: VP Engineering, Monday (30 min)

Weights: Values/Behavioral 4 (top), Pressure 2, Case/Strategist 2. The recruiter's phrase is "values and leadership philosophy." No published company values were in hand, so no values cheat sheet is built; the VP's round uses selection scaffolds where your material has no story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Selection scaffold: pick a time you told leadership something they did not want to hear. It needs a named audience, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in your words. | The quote is the nearest material. The scaffold does not supply an ending. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. If none comes to mind, say so plainly, then say how you would handle it. | Values stem. No quote carries a customer story. |
| C3 | "What is your leadership philosophy, and what has it cost you?" | VAL | [generic] | Sixty seconds, in your own words. Name one cost you have actually paid. Do not supply a cost you did not pay. | Open prompt on the recruiter's "leadership philosophy." |
| C4 | "How do you build a team that tells you when you are wrong?" | VAL | [generic] | Selection scaffold: pick a time someone on your team challenged you. If none, say so, then say how you would build it. | Values stem for a leadership round. |
| C5 | "Why should we trust you to run two squads when you have never managed managers?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't managed managers." Then how you would learn it, as a plan. Hold through two follow-ups. | The negative is yours, so you can say it. Pressure on the stated gap. |
| C6 | "What would you not do again on that reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: say what you would change, in your own words. If you would change nothing, say why. | Pressure on a headline story. |
| C7 | "Support load is rising faster than your squads can handle. What do you change first?" | CASE | [generic] | Clarify what is rising and why. Objective, segmentation, approach, metrics, risks. Think aloud. | Strategy-altitude live problem. |
| C8 | "Two of your squads want the same engineer for a quarter. What do you decide?" | CASE | [generic] | Clarify the cost of each path. Name the decision you would take and the one you would not. Challenge one premise. | Case at skip-level altitude. |

Reverse questions (Round 3):
- "What does this organisation mean by leadership philosophy, in practice?" Why it lands: asks for the working definition behind the phrase.
- "What did the VP see in the last engineering manager who made this role work?" Why it lands: asks what success looks like at this altitude.

## 7. Requirement coverage

| Stated requirement | Covered by | Note |
|---|---|---|
| Lead two squads building device-management services | A1, A5, B9, C5, C7 | Covered as a JD and live-problem set. |
| Own delivery, hiring and growth for 11 engineers | Delivery: A3, A4, B4. Hiring: A7, B6. Growth: A7 (answer slot) | Growth has no quote in your material; its branch is an answer slot. |
| Partner with hardware and product on roadmap | A2, A6, B1, B8 | Covered; your material shows no hardware partnership either way. |

## 8. Sources

Provided: your role summary for Larkfield Systems and your message about your background. No JD, CV, values page or interviewer profile was supplied.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | One search was sent for company values and refused (permission not granted). No values cheat sheet; the VP round uses selection scaffolds. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Not sent. Would have set loop structure; the three rounds are from your message, so personas follow them. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Not sent. Would have moved the CO bank, which is therefore absent. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative `Engineering Manager` JD | unavailable | Not sent. Your role summary is not a full JD, so the JD-tagged questions rest on it. |

## Upgrade menu

- The full job posting text → exact quotes for the requirement rows instead of your role summary, and JD-tagged questions grounded in the posting's own words
- Your CV → the EXP questions get the CV's own sentences, and F1 and F2 can move from medium confidence if the CV shows inspectable proof
- The Director's and the staff engineers' names → personas weighted from their public footprint, and a reverse question tied to their path
- The company's published values page → a values cheat sheet for the VP round
- Whether the role has location or office-day requirements → a gate row in the fit snapshot
