# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, 60 minutes. First 15 minutes: a spoken POV, no slides, on where to take operator partnerships over the next 18 months, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pushing on commercials.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Both as you quoted them from the recruiter's email.
**Research tier:** L0. Web search was refused in this session, so nothing below comes from company research. Everything is traced to your message or the recruiter's words you quoted.
**Not seen:** the internal market report the recruiter attached. You have read it; I have not, so no point in this pack rests on its contents. See the upgrade menu.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work, tested), JD (the role), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Speak it in your own words; a guidance cell that sounds like a speech is a cell you have not made yours.
- Quotes in the Provenance column are your own sentences. If you cannot say the thing a row rests on, do not say it in the room.

## Prep triage (about 4 hours)

1. **POV build, 90 minutes.** Section 5. Pick one thesis, write the concession first, then the operator close. Speak it aloud twice, timed. Aim for 8 to 10 minutes so Q&A has room.
2. **Ross drill, 60 minutes.** A1 to A5 aloud, with the hold-then-concede structure. Spend the most time on A2 and A3: the influenced-revenue questions are the ones Ross will press.
3. **Deepa drill, 40 minutes.** B1, B3 and B4 aloud. B3 is the single most likely objection, so it gets the deepest rehearsal.
4. **Full run, 45 minutes.** Open with C1, then the 15-minute POV, then one live Q&A block from Ross and one from Deepa.

Everything else is insurance.

## 1. Title block

Senior Partnerships Manager, Kelverton Rail. Interviewers: Deepa (VP Partnerships, future manager) and Ross (Commercial Director). Built on your message and the recruiter's words, with no interviewer footprint and no JD.

## 2. How to use and type key

Covered above. Personas by interviewer: Ross is weighted to Pressure and Prober; Deepa to Case/Strategist and Skeptic; the opener to Conversational.

## 3. Prep triage

See above.

## 4. Fit snapshot

Requirements come from the recruiter's words as you quoted them, since no JD was supplied. Every requirement row is therefore `[grounded]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email, as you quoted it) | "took it from 6 partners to 40" (your message); "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows a payments ISV channel grown from 6 partners to 40. It does not show any operator partnership. Say the channel growth as you did, and name the operator side as the transfer. Answer slot: if you made a partner decision that carries over to operators, say which and how you decided; if not, say so and stay with the operator knowledge from your consulting years. |
| F2 | "Please land on what it means for the operators themselves." (recruiter's email, as you quoted it) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms: "I know the operator world from the other side." Build the close on that sentence and nothing more. |
| F3 | "Ross will push on commercials." (recruiter's email, as you quoted it) | "never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence of a direct quota, so the words are yours: "I've never carried a direct quota." The £4M is influenced revenue, and it stays at that scope. Answer slot: see A2 and A3. |
| F4 | "they sell scheduling software to train operating companies" (your message, describing the company) | "Never sold into rail specifically" (your message) | low | [grounded] | capability | You stated the absence, so the words are yours: "I've never sold into rail specifically." Your consulting years give you the operator side of the table, not a sales record. Whether this is a gate is open; see upgrade menu and question 1. |

**Pack's observation (analysis, not words for you):** your material shows the operator side from consulting and the partner side from payments. It does not show any operator sale, any rail sale, or any commercial target you carried personally.

## 5. Graded deliverable: the 15-minute POV

The recruiter pre-declared this as the graded deliverable. Build it from F1 and F2 only.

**Grounded facts to build on:**
- F2: "so I know the operator world from the other side" (your message).
- F1: "took it from 6 partners to 40" (your message).

**Thesis A (recommended):** Operator partnerships should be built around the planner's problem, not around partner count. Operators buy when a partner helps them recover from disruption or change a timetable faster.
- **Mandatory concession:** I do not yet know which of Kelverton's operators have planners with that buying authority, and I would test that before building the plan around it.
- **Differentiation against the consensus answer:** the default answer is "grow the partner ecosystem". Name that answer and argue the planner's problem instead.
- **Anti-pick:** do not chase every train operator. A partner attached to an operator who cannot act on the product will cost more than it earns.

**Thesis B:** Partner revenue should be timed to the operator's own planning and franchise calendar, not to our quarter.
- **Mandatory concession:** I have not seen how your current pipeline is timed, and I would check that before defending it.

**Requested close:** end on one operator. What does their planner do differently in the first quarter after the partnership works? Label that answer as generic, since you have not stated a rail case.

Your grounding sentence for the close is F2, quoted as written. Do not claim you have seen a TOC buy.

## 6. Grounding brief

Not included. No strategy brief was supplied and L2 did not run.

## 7. Reading the interviewers

Only the recruiter's words are available: Deepa is "VP Partnerships, your future manager" and Ross is "Commercial Director." No public footprint was retrieved, so no career pattern or self-described style is read here. Personas are weighted from role priors.

## 8. Persona table

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Time-boxed commercial challenge; "how much of that was actually you" | High: "Ross will push on commercials" is the recruiter's own warning | Pause, restate, hold a position through two follow-ups before any concession |
| Data-Driven Prober | Ross | Asks how the £4M was counted and what "influenced" means | High: the figure is a headline number in your message | Name the weakest assumption yourself, in your words; say plainly what you do not know |
| Case / Strategist | Deepa | Live problem on the operator motion; a 90-day plan | High: she is the hiring manager and the POV is her brief | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud |
| Skeptic | Deepa | "Which part would you be weakest at on day one?" | High: F4 is the gap most likely to be raised | Plain acknowledgment, then the ramp plan as a plan, not a past |
| Conversational / Rapport | Opener, whoever leads | "So, walk me through the journey" | Medium: a common opener | Pre-scripted 90-second arc; treat casual questions as scored |

Weights: Ross depth 8 questions across the bank, Deepa 8, opener 2.

## 9. Question banks

Each row cites its Provenance. The Question is the interviewer's line.

### Ross (Pressure and Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us you never carried a direct quota. What did you commercially own?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Say it in your words: "I've never carried a direct quota, only influenced revenue." Hold through two follow-ups by returning to the influenced revenue. Answer slot: if you set the attribution rule for influenced revenue, say so; if others set it, say that plainly and describe what you ran. | F3 is the commercial gap Ross will press first; the premise is your own quote |
| A2 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Defend-the-number: the highest-ROI rehearsal in the commercial bank. Answer slot: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Name the assumption before Ross does. Do not explain a method you cannot repeat under a second question. | F3 and the figure itself; the four defend-the-number slots apply |
| A3 | "Of the 6 partners who became 40, how many did you bring in yourself?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you signed partners yourself, say how many and how you did it; if growth came from others' work, say so plainly and say what you ran. | F1: the claim is scale, and the probe is attribution |
| A4 | "Operators pay on franchise and contract timelines. How does your partner revenue model survive a three-year gap between decision and cash?" | CO | [generic] | Say what you know of how operators pay, and where your knowledge stops. If you do not know Kelverton's contract model, say so. Make no claim about your past. | A generic commercial question on the operator motion; no candidate claim |
| A5 | "You've never sold into rail. Why should we believe a payments-channel person can sell to a train operator?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I've never sold into rail specifically." Then the operator side: "so I know the operator world from the other side." Answer slot: if you have any rail-adjacent buying conversation, say which; if not, say so and say how you would reach a first operator sale. A plan, never a past. | F4; the most likely objection in the Ross bank; plain acknowledgment with its source |
| A6 | "A train operator wants the scheduling tool at cost. What do you do with partner margin?" | CASE | [generic] | Hold a price position and name what you would need to know before moving. No figures, no margin range. | Pressure on commercials; a live problem that asserts nothing about you |
| A7 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years in partnerships"; "took it from 6 partners to 40" | Lead with the two quoted facts, in your words. Do not add a reason you have not stated. | The pressure form of the biography; the sentences carry the whole answer |
| A8 | "Your partners were payments ISVs. What changes when the customer is a train operator, with a franchise and a regulator behind it?" | JD | [grounded] "running the ISV channel" | Name the difference honestly. Answer slot: if you have sold into a regulated or publicly funded buyer, say which; if not, say so and point to the operator side from consulting: "so I know the operator world from the other side." | Presupposes only the quoted ISV channel; the regulated buyer is a raising question, not a claim |

### Deepa (Case and Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you do in your first 90 days to find where operator partnerships should go?" | CASE | [generic] | Clarify the objective first; segment operators by planning problem; propose the approach; name two metrics and one risk. Make no claim about your past. | The POV's natural follow-up; a live problem |
| B2 | "Take one train operator with a timetable-change problem. What does a partnership look like from the planner's side?" | CASE | [grounded] "so I know the operator world from the other side" | Use the consulting-side view only. Say what the planner needs, and where your view comes from, in the quote's scope. Do not say you have sold to a planner. | F2; lets the POV close land under questioning |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Most likely objection in the Deepa bank, so the deepest rehearsal here. Plain acknowledgment: "I've never sold into rail specifically." Then the ramp plan as a plan: who you would meet, what you would learn first, and by when. Hold through one follow-up; concede the gap, never bluff it. | F4; a day-one weakness question is the skeptic's natural form |
| B4 | "Forty partners is not the same as the operator relationship this role needs. Where does your partner playbook break?" | JD | [grounded] "took it from 6 partners to 40" | Answer slot: name the point where the payments playbook would not transfer; if you have not tested the playbook on operators, say so and say how you would test it. | F1; the probe on transferability, asked as a limit |
| B5 | "What was your contact with operators in those five years, in your own words?" | EXP | [grounded] "5 years in transport consulting" | Say the contact at the scope you had it. Answer slot: if you had direct operator contact, say what it was; if your work was for a firm advising operators, say that plainly. | The consulting years are the operator bridge; the scope of the contact decides the claim |
| B6 | "What's one partnership bet you would not make in the first year?" | CASE | [generic] | Name one bet you would decline and why. Make no claim about your past. | The anti-pick; the role's real job includes saying no |
| B7 | "What has changed in the operator world since you were on the consulting side?" | JD | [grounded] "so I know the operator world from the other side" | Say only what you have seen directly, and say when you saw it. Do not claim a current view you have not formed. | A recency probe; it tests whether the operator knowledge is current |
| B8 | "Sketch the operator partnership motion for a market of twenty train operators. What goes first?" | CASE | [generic] | Clarify the segmentation; name the first two operators you would test on; state what would make you stop. | A live problem on the role's own motion |

### Opener (Conversational)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | JD | [grounded] "5 years in transport consulting"; "9 years in partnerships"; "last 4 at a payments company" | A 90-second arc: transport consulting, then nine years in partnerships, then the last four at the payments company. Speak it in your words. | The opener is scored; the arc has the three quoted facts and nothing added |
| C2 | "What's the thing about operator partnerships you think most people get wrong?" | CASE | [generic] | Name one belief you would test first, and why. Make no claim about your past. | A casual question on the hot topic, scored as the POV's first test |

## 10. Values and principles cheat sheet

Not included. No values page was read, and no loop source documents a values-style round.

## 11. Reverse questions

Each has a "why it lands."

1. **To Ross:** "How do partners get credited today: sourced, influenced, or both?" Why it lands: it turns your influenced-revenue answer into a question about how the business measures partners, and it shows you care about the commercial model.
2. **To Ross:** "What does a train operator ask for that the product does not yet do?" Why it lands: it shows you are thinking from the operator's side, which is the POV's own frame.
3. **To Deepa:** "What did you learn about operator partnerships in your first year as VP, and what would you do differently?" Why it lands: it asks about her path, not just the company, and the answer tells you what she will judge you on.
4. **To Deepa:** "What would success on the operator motion look like twelve months in, in terms you would use to judge the hire?" Why it lands: it turns the 18-month POV into a measure she has already set.
5. **To both:** "Where has the operator conversation stalled for the company in the last year?" Why it lands: it invites the hard truth, and an honest answer gives you the next thing to address in the POV's concession.

## 12. Delivery coaching

Not included. No working-style assessment was provided.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Set the ISV channel strategy | Inflated form of "running the ISV channel" and "took it from 6 partners to 40"; the practice is not stated | "took it from 6 partners to 40", at its own scope; A3 asks what you brought in |
| Delivered £4M of revenue | Inflated form of "roughly £4M of influenced revenue"; "delivered" turns influenced into owned | "roughly £4M of influenced revenue", at that scope; A2 asks how it was counted |
| Carried a quota | Negative you stated | Plain acknowledgment: "I've never carried a direct quota." |
| Sold into rail | Negative you stated | Plain acknowledgment: "I've never sold into rail specifically." |
| Knows how operators buy | Inflated form of "so I know the operator world from the other side"; the material shows the consulting side, not operator procurement | "so I know the operator world from the other side", with the consulting-side limit as the pack's own observation, never as a first-person negative |

## 14. Sources

- **Provided, as you quoted them in your message:** the recruiter's email (the panel, the 15-minute POV, "Ross will push on commercials"); your background paragraph.
- **Provided, not read by me:** the internal market report the recruiter attached. You have read it. This pack does not rely on it.
- **Searches sent this session:** three, all refused, so no URLs were returned:
  - "Kelverton Rail values": refused.
  - "Kelverton Rail interview process partnerships": refused.
  - "Kelverton Rail strategy news": refused.

**Target accounting**

Research tier: L0 (searches 0 of 6 returned results; 3 refused; fetches 0 of 2)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet, section 10: value names, which the candidate may be quizzed on. Not detected, since no loop source documents a values round |
| 2. Kelverton Rail interview process, partnerships | unavailable | Loop structure, which would confirm the panel format and whether a values round exists |
| 3. Kelverton Rail strategy or recent news | unavailable | CO questions grounded in current strategy; A4 and A8 are generic as a result |
| 4. Deepa, Kelverton Rail | unavailable | Interviewer read, persona weights and reverse questions tied to her path |
| 5. Ross, Kelverton Rail | unavailable | Interviewer read and commercial persona weights |
| 6. Representative "Senior Partnerships Manager" JD | unavailable | JD requirements that are not in the recruiter's words; the gate question depends on this |

## 15. Upgrade menu

- The JD text → F1 to F4 become JD-sourced quotes; a rail gate can be confirmed or dropped; the JD-tagged questions can be checked against it.
- The market report's headings or shortlist, pasted by you → the POV's differentiation can be built against the consensus answer. Until then, the differentiation in section 5 is generic.
- Public footprints for Deepa and Ross → a persona read, and reverse questions tied to their paths.
- Your own words on A2 and A3 outside a drill → quoted into the fit snapshot as new material, and F3 is rewritten from them.
- A web search, once available → the company values, the interview process and recent strategy, each at L1.
