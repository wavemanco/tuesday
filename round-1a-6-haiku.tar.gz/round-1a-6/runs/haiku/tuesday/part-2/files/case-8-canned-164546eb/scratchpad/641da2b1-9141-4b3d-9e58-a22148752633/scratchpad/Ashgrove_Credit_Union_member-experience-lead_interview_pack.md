# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead (member-owned, about 900 staff)
**Company:** Ashgrove Credit Union
**Candidate:** Dara
**Interviews:** 5 December 2026, three rounds

| Round | Length | Who | Personas weighted |
|---|---|---|---|
| 1. Recruiter screen | 30 min | Recruiter | Conversational, Skeptic |
| 2. Behavioural | 45 min | Head of Member Services (future manager) | Values/Behavioral, Skeptic, Case/Strategist |
| 3. Panel | 60 min, including a 20-minute complaint-escalation case | Two branch managers | Values/Behavioral, Peer Evaluator, Data-Driven Prober, Case/Strategist |

This is the first version. Nothing has changed yet.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored.
- **Types:** VAL = behavioural/values alignment. EXP = your own work, tested closely. JD = the listed job's requirements. CO = company and strategy knowledge. CASE = a live problem.
- Guidance is scaffolding, not a script. Say it in your own words and only where it matches what you did.
- Each question has an ID (R1, B1, P1 and so on) so the drill and the notes can point to it.

## Fit snapshot

Requirements are quoted from the JD you sent. Evidence is quoted from your own messages or CV. Where a requirement has no quote, the pack says so and does not fill it in.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material says the branch's formal complaints log. Say that, in those words: "I handled the branch's formal complaints log." Answer slot: if a complaint ran from first contact to close through your hands, say which steps were yours and in what order; if it did not, say so plainly and stay with the log. |
| F2 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | high | [grounded] | presentation | The years and the supervisor role reach the requirement in other terms. Words: "For six years I've worked in retail banking, the last three as a branch supervisor." No added practice. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log." (your message) | medium | [grounded] | presentation | The quote reaches complaints handling; the word "regulated" is not in it. Answer slot: the JD says regulated, so expect a probe on what rules the log had to follow. If any were yours to apply, say which and how; if none were, say so and describe how the log was kept. |
| F4 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms; "Excel" is not in it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Do not add the tool name unless you can say it is what you used. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked resolution times. Answer slot: if it did, say which figures and how they were counted; if it did not, say so and say how you would add them. |
| F7 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | low | [inferred] | transferability | Training tellers is adjacent to coaching supervisors. The adjacency is this pack's reading, not your claim. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone through an escalation, say who and what you did; if you have not, say so. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you have worked with anyone on a self-service journey, say what you did; if you have not, say so plainly and say how you would start. |

Seven rules the columns hold:

- Confidence, Provenance and Gap type each hold one token.
- Evidence holds only your own sentences, quoted, with the source named.
- Requirements in quotation marks are in the JD you sent.
- The gap type follows the evidence, not the writer's sense of the row.
- F4's words come from what you stated. F6 and F8 are answer slots because your material is silent.
- Bridges reword your quotes and add nothing that happened.
- Confidence grades your evidence. Provenance grades what this pack wrote about it.

## Grounding brief

What you are interviewing into, from the July 2026 strategy brief as you relayed it. Use the vocabulary, not a rehearsed speech.

- **Digital:** move 40% of member service to digital channels by 2028.
- **Branches:** consolidate eight branches into five hubs over 2027.
- **Lending:** launch a small-business lending product in Q1 2027.
- **Competition:** the main competitive pressure is app-only banks.
- **Values:** Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. These are copied from ashgrovecu.org/about/values on 26 November 2026.

## Persona table

| Persona | Round | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport | 1 | Warm opener, "walk me through your journey" | High. Recruiter screens are friendly and still scored. | Have a 90-second arc ready. Treat casual questions about the JD's topics as scored. |
| Skeptic | 1, 2 | "You've never worked in a contact centre" | High in round 2. The manager's job is to test the gaps in F1, F4 and F6. | Rehearse the contact-centre objection until it is plain. Concede specifically. |
| Values / Behavioral | 2, 3 | Scenario probes mapped to the four values | High. The recruiter said round 2 is mostly behavioural and the panel scores against the values. | Map a story to each value where your quotes carry one. Where they do not, use the selection scaffold and its honest branch. |
| Case / Strategist | 2, 3 | Live problems: digital shift, branch hubs, a complaint escalation | Medium in round 2 (the manager's roadmap). High in round 3 (the 20-minute case). | Clarify, then structure, then answer. Name the risk. |
| Peer Evaluator | 3 | Seam questions between branches and the contact centre | High. The panel members are branch managers, so they are peers of the people you would coach. | Propose seam principles, not claims about how seams were handled in your past. |
| Data-Driven Prober | 3 | "Walk me through how that was counted" | Medium. The panel will read the spreadsheet line on your CV. | Say what you can and cannot say about how the spreadsheet was built. Say plainly when you do not know. |
| Pressure | Low, touched in B4 | Interruptions, time-boxing | Low. Nothing in the material signals a stress interview. | Pause, restate, then answer from what you stated. |

Panel weights: the panel members are branch managers, so each is a peer-type relationship. The panel also scores the values, so Values/Behavioral sits alongside the two personas a peer relationship names.

## Round 1: Recruiter screen (30 min)

Logistics slots: pay, notice, location and the reason for leaving are asked here. You gave no figures or reasons, so each answer is yours to give in your own words. Nothing in this pack supplies one.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot. Give your own figure, or ask for the band before you give one. Do not give a figure you have not chosen. | Pay is the first logistics question in any screen. |
| R2 | "When could you start, and what notice do you need to give?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. Check your start date with your branch before you commit to one. | Notice is the second logistics question. |
| R3 | "Where could you work, and how often?" | JD | [generic] | Logistics slot. Say which sites and which days you can work, in your own words. | Location is the third logistics question; the role spans branches and the contact centre. |
| R4 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot. Give your own reason, in your own words. The material you sent has no reason, so this is an instruction, not a script. | The reason for leaving is the fourth logistics question. |
| R5 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it in the order those two quotes give: six years in retail banking, the last three as a branch supervisor, then the complaints log and the teller training. Keep it under 90 seconds and do not add to it. | F2 is the four-year threshold. F1 and F7 are the complaints evidence. This is the opener, so it is scored. |
| R6 | "You haven't worked in a contact centre. Why would this role suit you?" | EXP | [grounded] "Never worked in a contact centre" (your message) | **Highest-return prep in this pack.** Say the negative once and plainly: "I've never worked in a contact centre." Then the nearest thing your material carries: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log. Concede specifically: the contact centre is new to you, and say how you would learn it. | The contact-centre gap is the biggest one. It is the JD's scope line (F1), and the panel's case will test it too. |

## Round 2: Behavioural with the Head of Member Services (45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time someone brought you an escalation they couldn't resolve. What did you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Choose one escalation and describe what you did with it, in order. The log and the script are the beats the sentence states. Answer slot: if you coached someone through an escalation, say who and what you did; if you did not, say so plainly and describe the one you did take on. | F7 is the JD's escalation-coaching line. The recruiter said round 2 is mostly behavioural. |
| B2 | "Tell me about a complaint you followed through until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log." | Open prompt. Describe a complaint from first entry to close, in the order you dealt with it. Answer slot: if you kept it with you until it was solved, say which steps were yours; if it passed to someone else at a stage, say who and what you did before that. | Own the Fix means holding the complaint until it is solved. Do not claim to have held one you did not. |
| B3 | "The role owns complaints end to end across branches and the contact centre. Which part have you owned end to end?" | JD | [grounded] "I handled the branch's formal complaints log." [grounded] "Never worked in a contact centre" | Hold: "I handled the branch's formal complaints log," and say the contact centre is new: "I've never worked in a contact centre." Answer slot: if any complaint ran end to end through your hands, say which steps and in what order; if none did, say so plainly and stay with the log. | F1 is the headline requirement. The end-to-end claim is on the prohibited list. |
| B4 | "This role presents to senior leaders each month. How would you prepare for your first one?" | JD | [grounded] "I've never presented to anyone above regional level." | Hold without stretching: "I've never presented to anyone above regional level." Then describe how you would prepare, as a plan. Do not describe a presentation you have not given. | F4 is a stated absence. The question asks about the future, so it presupposes nothing about your past. |
| B5 | "Walk me through the monthly complaints spreadsheet you built, and who used it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story map: you built it, and the regional manager uses it. Those are the beats the sentence states. Answer slot: if you chose what it held and how it was laid out, say which parts; if someone else set the layout, say so. | F5 is the Excel requirement. The question tests whose spreadsheet it was in design. |
| B6 | "Digital channels are meant to take 40% of member service by 2028. Where would complaints from members who move to the app sit, and what would you watch?" | CASE | [grounded] strategy brief, July 2026: "move 40% of member service to digital channels by 2028" | Clarify what counts as service and what counts as a complaint. Objective: complaints stay visible in both channels. Segment by channel. Approach: one log across app and branch. Metrics: complaint volume and resolution time by channel. Risk: complaints that fall between channels. Speak it in 90 to 120 seconds. | F8 is the digital requirement. The manager's roadmap leads here. This is a live problem and makes no claim about your past. |

## Round 3: Panel (60 min, with a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "A member has complained three times about a fee. The branch says it is closed; the member says it is not. You are the escalation point. What do you do first, and what do you change?" | CASE | [generic] | Practice case written by this pack; the panel's case may differ. Structure: clarify what the record shows and what the member was told; check each contact; decide who holds the fix today; set a date to call back; put the explanation in plain words; record the root cause for the branch. Think aloud and state your assumptions. | The recruiter named a complaint escalation case. This is a practice version, not the panel's. |
| P2 | "Tell me about a time an explanation didn't land with a member, and what you did differently." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, scored on Plain Words. The nearest beat is the script training: say how you taught it, in your own words. Answer slot: if you rewrote wording for members or tellers, say what changed and whether it worked; if you did not, say so and say how you would test a plainer version. | Plain Words is scored, and the script is the nearest thing your material carries. |
| P3 | "The plan moves eight branches into five hubs during 2027. A town loses its branch. How do you keep its complaints heard?" | CO | [grounded] strategy brief, July 2026: "consolidate eight branches into five hubs over 2027" | Clarify what happens to open complaints when a branch closes. Objective: members still reach someone who knows their case. Segment: local branch complaints against hub complaints. Approach: a named contact and a transferred record. Metrics: resolution time by town. Risk: members lost in the move. | Neighbours, Not Numbers is tested most here. It is the brief's hardest consequence for complaints. |
| P4 | "Tell me about a time a figure pointed one way and a local member's situation pointed another. What did you do?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Open prompt, scored on Neighbours, Not Numbers. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the spreadsheet is a numbers tool. Say how you used the numbers for a particular branch's complaints, only if you did. | The spreadsheet is the nearest evidence to numbers versus towns. |
| P5 | "What in your monthly reporting would you check first if a regional figure looked wrong?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Method question, not a claim. Say what you would check and in what order. Answer slot: if you have checked a figure from the spreadsheet before, say what you found; if you have not, say so and say how you would test it. | F5 and F6 are the reporting requirements. A prober will ask how the numbers were built. |
| P6 | "Tell me about a decision a member disliked but which was right for them." | VAL | [grounded] "I handled the branch's formal complaints log." | Open prompt, scored on Members First, Always. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the complaints log, or how you would handle it. Do not describe a decision made from the member's side that you did not make. | No quote carries a member-side decision. The honest branch is required. |
| P7 | "Our teams sit side by side. Where's the seam between branch and contact-centre complaints, and what happens when you disagree with a branch manager?" | JD | [generic] | Peer question. Propose seam principles, not claims about the seam's history. Principle: one owner per complaint until it is closed. On disagreement: take the disagreement to the record and agree a decision rule. | Peer Evaluator. The panel members are peers, so this is the collegial version of F1. |

## Values / principles cheat sheet

The panel scores against four values, so this section is included. Working meanings are paraphrased.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quote carries a member-side decision. Selection scaffold in P6, with its honest branch. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | Nearest: "trained new tellers on our escalation script" (F7). Scaffold in P2. |
| Neighbours, Not Numbers | Every branch is part of its town. | Nearest: "I built the monthly complaints spreadsheet our regional manager uses." (F5). Scaffold in P4. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | "I handled the branch's formal complaints log." (F1). Scaffold in B2. |

## Question coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B3, R6, P1 |
| Experience handling regulated complaints | B2, P1 |
| Coach branch supervisors on escalations | B1 |
| Confident presenting to senior leaders | B4 |
| Comfortable with Excel reporting | B5, P5 |
| Report monthly on complaint volumes and resolution times | P5 |
| Work with digital teams on self-service journeys | B6 |
| 4+ years in financial-services customer operations | R5 |

Totals: 19 questions across the three rounds (R1 to R6, B1 to B6, P1 to P7).

## Reverse questions

Ask one or two in each round. Each has a reason it lands.

1. "Where do complaints go when they move from a branch to the contact centre, and who decides when they are closed?" Why it lands: it names the seam the role owns, and it shows you have thought about that seam before the interview.
2. "How will the move to five hubs change how complaints are escalated?" Why it lands: it connects the hub plan to the job, and the interviewer will want to talk about it.
3. "What is the first self-service journey the digital team is looking at, and where would complaints data come from?" Why it lands: it ties your work to the JD's digital requirement.
4. "How are complaint volumes and resolution times reported today, and who reads the monthly report?" Why it lands: it shows you care about the reporting the JD asks for.
5. For the panel, a reciprocity question: "What could a new person do in their first month that would genuinely help your branch teams?" Why it lands: the panel are peers, and this asks what you would bring to them.

## Prohibited claims

What this pack will not coach. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." The limit is this pack's observation: your material says the branch's log, not the whole process. |
| Presented to senior leaders | Negative you stated, F4 | "I've never presented to anyone above regional level." Plain acknowledgment, no slot. |
| Worked in a contact centre | Negative you stated (your message) | "Never worked in a contact centre." Plain acknowledgment, no slot. |
| Coached branch supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Owned monthly reporting on resolution times | Inflated form of F5 and F6 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times are an answer slot in F6, not a claim. |

## Sources

- **Provided documents:** your background, the recruiter's email, the values page text you copied on 26 November 2026, and the July 2026 strategy brief as you relayed it.
- **Searches and fetches:** none. Research tier L0, since no research was consented. Searches 0 of 0; fetches 0 of 0.
- **Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and their lengths. |
| 3. Ashgrove strategy and recent news | skipped | The strategy brief you relayed supplies the grounding brief. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD you sent fixes the fit snapshot. |

## Upgrade menu

- The Head of Member Services' name → an interviewer read, and round 2 persona weights from their public footprint. This needs a research search.
- A real complaint you took to resolution, in the order you handled it → B2 and P2 move from scaffolds to story maps.
- Whether the spreadsheet tracked resolution times → F6 and P5 become answered rather than slots.
- A self-service or digital project you worked on → F8 and B6 become grounded.
- The recruiter's guidance on the 20-minute case → P1 is replaced by the actual case.
- Your notice period, pay position and reason for leaving → R1 to R4 become answered in your own words.
- A `tuesday-dossier.md` file would record what this prep exposed, so the next session starts from it.
