# Operations Manager, Atlas Freight: interview prep pack

Interviewer: not given. Round: assumed to be a hiring-manager round, since your note didn't say who you are meeting. Company research: web search was refused in this session, so no company material is in this pack. Everything about Atlas Freight comes from your job description.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the listed job), EXP (your past work under scrutiny), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Say the answer in your own words, in 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows warehouse and distribution operations at one site, not daily control across four. Bridge at its own scope: "I have 7 years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the four-site line makes a probe on multi-site control likely. If you have run work across more than one site, say how; if not, say so plainly and say how you would set up daily control across four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the scale your material shows; twelve is four times that. Bridge at its own scope: "I'm a senior shift manager over 3 supervisors." Answer slot: the twelve-supervisor line makes a probe on span of control likely. If you have led supervisors at a larger span, say how; if not, say so and say how you would structure twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Your material gives seven years in operations, but not how long you have been in charge of people. That length is not a gate; it is graded like any other requirement. Answer slot: state, in your own words, when your first role leading people began. If that was less than five years ago, say so plainly and lead with the operations years. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | medium | [grounded] | none | The quote already reaches the Excel part of the requirement. Medium because nothing has been inspected: bring a report you built if you can. Bridge: "I'm solid in Excel." |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated, which words cannot close. Words: "I haven't used Power BI." Then say how you would learn it, as a plan and never as a past. Never describe Power BI work. |
| F6 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The figure is pick accuracy, not on-time performance or cost per shipment. Bridge at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Limit, in the pack's analysis: your material says mis-pick rate, not on-time or cost. Answer slot: if you tracked on-time or cost per shipment, say what and how; if not, say so and say which measure you would start with. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote covers the requirement. Medium because no certificate has been seen; bring it. Bridge: "I'm green belt certified." |

Gate check: the JD states no gate you have told me about (no location, schedule or credential bar), so no hard gate is surfaced. If the posting has one I have not seen, send it.

## How you could be asked to go past your material

Section 13, built from the fit snapshot before the question banks. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | F1's quote at its own scope. Your material shows one site. |
| Led twelve supervisors | Inflated form of F2 | "a senior shift manager over 3 supervisors" at its own scope. |
| Built reports in Power BI | Negative you stated, F5 | "I haven't used Power BI." |
| Cut on-time or cost per shipment | Inflated form of F6 | "cut mis-pick rate 40% by redesigning the pick path" at its own scope. |

## Personas and weights

Assumed: hiring-manager round. The hiring-manager prior weights Case/Strategist and Skeptic highest; Prober and Pressure follow; Conversational is kept at the floor so you have heard it once.

| Persona | How it shows up | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps: scale, Power BI, leadership years | Highest. The JD lists four requirements your material does not fully reach | Top (5 questions) | Rehearse the scale objection until it is plain. Name the gap yourself before it is pointed out. |
| Case/Strategist | Live problems on four sites, peak and cost | High. A hiring manager buys ability to run the job | Top (5 questions) | Clarify, then structure, then state your metrics. Think aloud. |
| Data-Driven Prober | Asks how the 40% was counted and who did what | Mid. Your one headline number will be checked | Mid (3 questions) | Say how it was counted only if you know. Name the assumption you would defend least. |
| Pressure | Time-boxed challenges to your seniority and your numbers | Mid. A common stress move on a scale-up of responsibility | Mid (3 questions) | Pause, restate, hold the position through two follow-ups, then concede the exact point. |
| Conversational | Friendly openers that still score | Low. Costs little to rehearse | Low (2 questions) | Use a 90-second arc built from your quoted sentences. Treat casual questions as scored. |

## Question banks

Coverage line for the JD. A requirement with no question would be a free miss.

- Own daily terminal operations across 4 sites: B1, C3, C5
- Drive on-time performance and cost-per-shipment down: C1, D1
- Lead a team of 12 supervisors: B1, C5
- Build reporting in Excel/Power BI: B2, D3, F2
- 5+ years operations leadership required: B4, E3
- Lean/Six Sigma a plus: B5

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns daily operations across four sites and twelve supervisors. Where in your experience does that scale show up?" | JD | [grounded] "a senior shift manager over 3 supervisors" (F2); [grounded] "ran the site's peak-season surge plan two years running" (F1) | Highest-ROI prep in this pack. Start with what you run today, in your own words, quoted: "a senior shift manager over 3 supervisors." Then the nearest scale you handled: the peak-season surge plan, two years running. Answer slot: if you have run work across sites or supervisors beyond three, say how; if not, say so plainly, then say how you would build daily control across four sites and twelve supervisors. Hold through two follow-ups by returning to what you ran. Concede the exact gap, not the whole question. | F1 and F2 are the largest gaps against the JD, and this objection is the one most likely to be asked in some form. The rehearsal is the honest answer, not a bigger one. |
| B2 | "What is the one part of this job you would be weakest at on day one?" | JD | [grounded] "I haven't used Power BI." (F5) | Name Power BI first, plainly: "I haven't used Power BI." Then say how you would learn it in the first month, as a plan. Keep it to one gap; do not list several. | F5 is the stated negative the JD's reporting line presses on. Naming it first converts a probe into a plan. |
| B3 | "You are moving up a level. What about this role made you apply?" | JD | [generic] | Answer slot: give your own reason for applying, in your own words. No reason is supplied here. | Motivation consistency is scored by the skeptic. The pack has no quote for your reason, so none is written for you. |
| B4 | "The role asks for 5+ years of operations leadership. Walk me through when your leadership started." | JD | [grounded] "7 years in warehouse and distribution ops" (F3) | Answer slot: state the start of your first role leading people, in your own words. If it is under five years, say so, then lead with the seven years of operations work. | F3 is discovery: the material shows the years in operations, not the years in charge. The question asks for the date, not a bigger number. |
| B5 | "Lean and Six Sigma are a plus here. What did you take from your Green Belt into the job?" | JD | [grounded] "green belt certified" (F7) | Give the certification plainly. Answer slot: if the training produced a project that measured something, say what it measured; if it did not, say so and name the one tool you would apply first. | F7 is covered by the quote. The question presses for use, which the material does not show. |

### Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Cost per shipment is up at one of four sites and on-time performance has dropped. Walk me through how you would diagnose it." | CASE | [generic] | Clarify first: which shipment types, whether this is peak, what changed. Then break it into labour, dock, linehaul and dwell, state a hypothesis for each, and say what you would look at in the first week. | Live problem from the JD's two metrics. Asked as a decision, so it needs no claim about your past. |
| C2 | "Peak starts in six weeks at a site that is taking on a large new hire class. What is your plan for the first week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (F1) | Use the surge plan as your reference point, in your own words. Answer slot: say what that plan covered, and whether it covered new starters. If it did not, say so and say what you would add. | The surge plan is the nearest story to this problem. The guidance names only what the quote carries. |
| C3 | "Four sites, four different ways of working, one standard. How do you set it?" | CASE | [generic] | Structure it: what the standard measures, what is common across sites and what is local, how you would check a site is following it, and who decides exceptions. | The JD's four-site line raised as a live design question. No claim about your past is made. |
| C4 | "What would you check across the network before proposing a change to how the terminals run?" | CASE | [generic] | Describe the checks in order: current performance by site, where volume and staffing sit, what the change touches, and what it would cost to test it first. | Company research did not run, so this stays generic and says so. |
| C5 | "What would your first ninety days look like across four sites?" | JD | [generic] | Structure it: learn the sites and their numbers, meet the supervisors, agree the two targets, then fix one thing at one site before changing the rest. | Covers the four-site and twelve-supervisor requirements in a single plan. The plan is generic; state it as your plan. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F6) | State the period and the unit you measured, in your own words. Name the assumption you would defend least. Answer slot: if you do not know how it was counted, say so plainly; do not reconstruct a method on the spot. | F6 is the one headline figure and the likeliest place to be probed. The rehearsal is precise attribution, not a better method. |
| D2 | "Which part of that 40% came from the pick path, and what else changed in the same period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F6) | Say what the pick-path change did, in your own words. Answer slot: if other changes happened in that period, name them and say what share was yours; if nothing else changed, say that. | Separates your contribution from the period's noise. The quote carries the causal claim and nothing beyond it. |
| D3 | "The role builds reporting in Excel and Power BI. Which report would you build first, and who would read it?" | JD | [grounded] "solid Excel" (F4); [grounded] "I haven't used Power BI." (F5) | Excel: name one report you have built, what it showed and who used it, if you have one. Power BI: say you have not used it, then state the first report you would build and why. Answer slot: if you have no Excel report to name, say so plainly. | Answers the JD's reporting line on both tools without claiming Power BI work. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That forty percent. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F6) | Pause, then restate what you did: the pick path, in your words. Hold through two follow-ups. Concede exactly what others did, if anything, and no more. | Hold-then-concede on the number you are most likely to be pushed on. |
| E2 | "Sixty seconds: why should we pick you over someone who has already run a site?" | JD | [generic] | Answer with two quoted facts and one plain limit: your seven years in operations and your surge plan, then the gap you will close first. Answer slot: give your own reason in your own words. | The pressure version of B3. The reason is yours to supply; none is written for you. |
| E3 | "You are a senior shift manager over 3 supervisors, and this job asks for 5+ years of operations leadership. Why is this not a stretch?" | JD | [grounded] "a senior shift manager over 3 supervisors" (F2) | Hold the position that you have the operations years, then concede the leadership span. Hold through two follow-ups; do not fold on the operations record. | The premise is quoted from your material. The hold is only what the quote carries. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (F1); [grounded] "currently a senior shift manager over 3 supervisors" (F2) | A 90-second arc in this order: seven years in warehouse and distribution operations, then your current role, then the surge plan and the pick-path result. Answer slot: say why you are moving on, in your own words. | A relaxed opener is still scored. Keep the arc to quoted facts. |
| F2 | "What are you actually doing in Excel these days?" | JD | [grounded] "solid Excel" (F4) | Name one thing you do in Excel now, in your own words. Answer slot: if you do nothing regular in Excel, say so. | A casual question about a JD topic, scored as a JD question. |

## Reverse questions

Interviewer profile not given, so none ties to a career path. Each question below is generic.

1. "What would the first ninety days look like for someone taking over operations across four sites?" Why it lands: shows you are thinking about the network, not just the title.
2. "Which of the four sites is furthest from its on-time target right now, and what is driving it?" Why it lands: asks for the numbers and shows you want the real problem.
3. "How is reporting built today, which tools, and who reads it?" Why it lands: tests your Power BI gap against their tools and shows you care about reporting.
4. "How are the supervisors' on-time and cost targets set, and who owns them?" Why it lands: shows you know the two metrics are run through people, not only systems.
5. "What has separated the operations leaders who did well in this role from those who struggled?" Why it lands: a question about the job, not about you, which signals judgement.
6. "How does the team run peak season across the sites?" Why it lands: connects to your surge plan and invites them to describe their approach.

## Sources

- Provided: the job description and your background, both in your message.
- Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section 10) and any VAL questions, if a values round is detected. Every search was refused. |
| 2. Atlas Freight interview process, operations role | unavailable | Loop structure and persona weights. Every search was refused, so the hiring-manager round is an assumption. |
| 3. Atlas Freight strategy and recent news | unavailable | CO questions. The search was refused, so C1 to C5 are generic. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | Your job description fixes the fit snapshot and the JD questions. |

Queries sent, all refused: "Atlas Freight regional logistics company values"; "Atlas Freight operations manager interview process"; "Atlas Freight logistics news strategy 2026". No fetch was sent.

## Upgrade menu

- Who you are meeting and their title → persona weights for that person, and a tailored reverse question
- Atlas Freight's careers page or values text, pasted → the values section, and company language in place of generic framing
- The recruiter's note on the round's format or focus areas → loop structure, and any deliverable if one is named
- Your Green Belt certificate → F7 moves from medium to high confidence
- The period and unit behind the 40% figure → D1 and D2 become rehearsable with exact figures
- A tuesday-dossier.md, if you have one → verified evidence and the highest-ROI objection carried over
