# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: presumed hiring manager, from the title alone; not confirmed. Format: 60 minutes, Friday, round type not stated.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

- **JD**: can you do the listed job, including its gaps
- **EXP**: do the claims in your own sentences survive scrutiny
- **CASE**: a live problem from the role, solved aloud
- **CO**: company and strategy knowledge (not covered; see Sources)
- **VAL**: values alignment (not detected; see Persona table)

## Reading the interviewer

Title only. No public footprint was read, because web search was declined. Implications from the title: the JD is likely his scoring sheet, so expect the calendar, the post-event review and the KPIs, and the release checklist. No mirror opportunities are offered: nothing you gave me shares a career path with his.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one main title and weekly content drops, not two titles or live events. Say the one-title calendar in those words. Answer slot: if you planned anything across more than one title, say what; if not, say so and say how you would start. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Lead with the calendar in its own terms. Expect a probe on what "ran" covered (C4). |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The four years are on your message. Whether the puzzle title was live-service is not stated. Say that in your own words: what the game's content cadence was. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on how the figures were counted (C1, C2). |
| F5 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The evidence is a working document in use, not a writing sample. Say so if asked. A writing sample would upgrade this row (upgrade menu). |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: wrote, not managed. Bridge rewords only that quote: "I wrote the release checklist our QA team still uses." Add no management. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material is silent on coordinating these teams. Answer slot: if you coordinated any of them on a drop, say which and how; if not, say so and say how you would start. |
| F8 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | The quote touches KPIs without showing a review. Answer slot: B4. |
| F9 | Team leadership, not named in the JD; the likely probe through F7 | "Never led a team" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't led a team." Then a plan, said as a plan and never as a past: how you would coordinate without line authority. |
| F10 | Monetization and in-app purchases, not named in the JD; a likely probe for mobile live operations (generic expectation) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it. Do not describe monetization work you have not done. |

**Observations (the pack's analysis, not words for you).** Your material is strongest on the calendar, the checklist and the retention presentation. It shows no review you ran, no coordination of design, art, engineering or community, no team leadership and no monetization work. Those four absences are where the interview will press.

## Prohibited claims

Claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led the content team, or managed people on the calendar | Inflated form of "I ran the weekly content-drop calendar" | Quote at its own scope. Observation: your material says you ran the calendar, not that you led people. |
| Owned the live-ops roadmap for two titles | Inflated form of F1 | The one-title quote at its own scope. |
| Managed the release checklist with QA | Inflated form of "Wrote the release checklist" (F6) | The quote as written: wrote it, and QA still uses it. |
| Owned the post-event review and its KPIs | Inflated form of "Presented the monthly retention numbers" (F8) | Quote at its own scope. No ownership claimed. B4 is the slot. |
| Has led a team | Negative you stated (F9) | "I haven't led a team." No slot. |
| Has worked with in-app purchases or monetization | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Relationship prior for a hiring manager is Case/Strategist and Skeptic on top. No loop source establishes the Friday round's format, so the fallback archetype is Generic: flat weights, said plainly. The weights below are that prior, adjusted for JD emphasis. Values/Behavioral is not detected, so there is no values section. Peer does not apply.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | A live plan for two titles; a retention dip to diagnose; a slipped update across four teams | High. The JD is written as tasks (plan, coordinate, own), and the hiring-manager prior weights this persona top | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. |
| Skeptic (weight 4) | Where the leadership and monetization gaps show, and where the numbers went | High. Two stated absences and one JD line with no evidence | Plain acknowledgment, then how you would learn it. Hold only what your quotes carry. |
| Data-Driven Prober (weight 4) | How the retention figure was counted; the assumption you would defend least | High for this candidate. Retention comfort is a JD line and your strongest headline | Say what you can and cannot say about the count. Name the weakest assumption first. |
| Pressure (weight 3) | Challenges to the leadership gap; "how much of that was actually you" | Medium. Composure on the leadership gap is the likeliest test | Pause, restate, hold through two follow-ups, concede a specific thing |
| Conversational (weight 2) | A journey opener and a casual question about the calendar | Low to medium. A low-weight opener, but casual questions are scored | A 90-second arc from your own sentences only |

## Question banks

Provenance comes first in each row. The sentences in it are the only candidate claims the guidance rests on.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the live-events calendar for two mobile titles for the next quarter. What do you need to know first?" | CASE | [generic] for the question; "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before you structure: which title is more fragile, what the team can ship each week, which dates are fixed. Then objective, approach, metrics, risks. Say aloud that your calendar covered one title, and that the second is a planning question you would ask about. | The JD line "Plan and run the live-events calendar for two of our mobile titles" is the raising source. CASE because it asks for a plan, not a past. F1 is the evidence. |
| A2 | "A content drop goes out on a Tuesday and a retention metric falls the following week. Diagnose it." | CASE | [generic] | Clarify: did the drop ship as planned, and is the fall in the cohort that saw it? Separate the event from seasonality and from anything else that changed that week. Name the one cut you would look at first. | JD "comfortable with player-retention metrics". The scenario is a pattern for the problem, not a fact about your work. |
| A3 | "Design, art, engineering and community all need the same two weeks for one update, and engineering says the build slips four days. What do you do?" | CASE | [generic] | Decide what the slip costs and who decides the cut. Tell community first, not last. Name what is fixed and what can move. | JD "coordinate design, art, engineering and community teams on each update". Presupposes no event in your past. F7 is the gap. |
| A4 | "You have 30 days to take over the calendars for two titles. What do you do in week one?" | CASE | [generic] | Read the last quarter's post-event reviews and the release checklist before any meeting. Meet each discipline's lead. Pick one metric to watch and say why. | JD "Plan and run" and "own the post-event review" are the raising sources. Presupposes nothing about you. |
| A5 | "Which KPIs would you put in a post-event review for a content drop, and what would make you call it a miss?" | JD | [grounded] JD line "own the post-event review and the KPIs it reports"; "Presented the monthly retention numbers to the studio head." | Name two or three KPIs, the baseline you would compare against, and the threshold for a miss. Answer slot: if you have set a baseline for a review before, say what it was compared against; if not, say so and say what you would compare against first. | The JD line is the raising source. Your retention presentation (F4) is the nearest thing in your material, and it does not show a review (F8). |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Once you had presented the monthly retention numbers, what happened next, and who acted on them, if anyone?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold what the quote carries: you presented them, and say what that involved. Answer slot: if you influenced a decision they fed, say which and how, in your own words; if nothing followed, or what followed was not yours, say so plainly and stay with the presentation. | F4 is the strongest JD-adjacent line. The likely follow-on is the post-event review (F8). |
| B2 | "I don't see team leadership in your background, and this role coordinates four disciplines on every update. How would you do that without line authority?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't led a team." Then the plan, said as a plan: how you would run a shared update calendar, who signs off what, how you would settle a disagreement between design and engineering. Hold through two follow-ups. Concede one specific thing: leading people is the part you have not done. Answer slot: if you coordinated any of the four on a drop, say which and how; if not, say so. | The biggest direct conflict between a stated absence and a JD line (F7, F9). The Skeptic's stem is built from the stated negative, so this is the question most likely to come in some form. |
| B3 | "You haven't worked on a game with in-app purchases. How would you plan a content drop that also carries a store offer?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it: the economy, the offer cadence, and what the revenue lead tracks. Do not describe monetization work you have not done. | F10. The JD does not name monetization. The question is the interviewer's probe, and it is likely on mobile live operations (generic expectation). |
| B4 | "Tell me about a post-event review you owned, end to end." | JD | [grounded] JD line "own the post-event review and the KPIs it reports" | Answer slot: if you ran a post-event review, say its scope and the decision it fed; if you took part in one someone else ran, say that exactly; if you have not done one, say so and say what you would measure first. Never describe a review you did not run. | An open prompt on the JD's raising line. No quoted sentence says you ran one. F8 is low confidence, and this is where it gets tested. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you can and cannot say about the count. If you know the cohort window and the definition, say them. If the figure came from someone else's dashboard, say that. Answer slot: if you set how it was counted, say how; if you did not, say so. | F4 headline. The defend-the-number slot, asked in your own words. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption before the interviewer does. If you do not know how it was counted, say that, and say what you would check first. | Defend-the-number slot. Naming the weakest assumption turns a gotcha into a credibility gain. |
| C3 | "Walk me through the release checklist you wrote. What does a release look like when it passes?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe the checklist's stages in your words. Stay with "wrote" and "QA still uses it", both in your sentence. Answer slot: if the checklist changed how a release went, say what changed; if you have no record of that, say so. | F6. The probe is whether you wrote the checklist or managed it. Stay with "wrote". |
| C4 | "You ran a weekly content-drop calendar for two years. Which parts did you decide: the content, the dates, the size of each drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what "ran" covered, in your words. Answer slot: for each part, say whether it was yours to set and how you decided; if someone else set it, say so and name who. | F1 and F2. The inflation check: which decisions were yours. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team" (your message) | Pause and restate the question. Plain acknowledgment first: "I haven't led a team." Then hold on what you did: you ran the calendar and wrote the checklist, and you presented retention to the studio head. Hold through two follow-ups. Concede one specific thing: you may need someone with leadership first, and say what you would learn in your first quarter. Never fold on the calendar. | Pressure stem on the leadership gap (F9). Tests composure, not content. |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold what "ran" carries, then name what others set. Concede specifically, not in general. Do not add "I set the strategy." | Pressure on attribution. The honest answer is the precise one. |
| D3 | "Presenting numbers isn't owning them. Defend the difference." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: you presented them, and say what that involved. Concede what your material does not show: what the studio head did with them. Do not claim the decisions. | F4 bridge. Hold the presenting, and no more. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "Presented the monthly retention numbers to the studio head." | A 90-second arc: the puzzle studio, the calendar, the checklist, the retention presentation, and why live operations at a mobile studio. Use only those sentences. | A casual opener is still scored. |
| E2 | "What's been the most interesting part of running a content calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one drop you actually ran, and say what it taught you about timing, in your own words. | JD "experience running a content calendar", asked casually. |

**Coverage.** Every JD requirement maps to at least one question, or to a stated reason.

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A4, C4 |
| Coordinate design, art, engineering and community on each update | A3, B2 |
| Own the post-event review and the KPIs it reports | A5, B1, B4 |
| Manage the release checklist with QA | C3 |
| 3+ years producing live-service games or apps | none, and why: the years are on your message and are settled by F3; E1 covers the journey |
| Experience running a content calendar | E2, C4, D2 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | none, and why: no interview question tests written output; a writing sample would (upgrade menu) |

## Reverse questions

Every question below is for Tobias. No career-path tie is available, because no public footprint was read.

1. "What would success look like for this role at 90 days across the two titles?" Why it lands: it turns the JD's two titles into a concrete bar, and it shows you read the JD closely.
2. "How is the post-event review run today, and what do its KPIs feed?" Why it lands: it is the JD's own line. The answer tells you how hard to rehearse B4.
3. "How is the economy planned into a content calendar here?" Why it lands: it is the question you would want answered, given B3, and it asks for the team's practice, not a judgement on you.
4. "Who maintains the release checklist with QA today, and what would you change in it?" Why it lands: it ties to the checklist you wrote (C3) and shows you have thought about the QA side.
5. "Which of the two titles needs the most attention next quarter, and what would you want the new hire to fix first?" Why it lands: it shows you are planning ahead, and it gets you his priorities in his own words.

## Sources

Provided documents: the JD and your background, both in your message. No provided document was fetched.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Search was refused in this session (permission not granted), so every search below returned nothing.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet not built. Query refused: "Saltmarsh Games values". Would have set value names from the official page. |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure not established, so persona weights are the flat hiring-manager prior. Query refused. |
| 3. `Saltmarsh Games strategy / recent news` | unavailable | No CO bank was written. Query refused: "Saltmarsh Games mobile game strategy news". |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | No interviewer read beyond the title. Query refused: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Company-specific claims in this pack are absent, not guessed. The values, the loop, the strategy and the interviewer's footprint are all unknown.

## Upgrade menu

- Search permission, if you grant it → Saltmarsh's values, the loop structure, recent strategy and Tobias's public footprint: a values section if values are published, persona weights from his record, and a tailored reverse question.
- Whether Friday is a panel, or a presentation or take-home was announced → a graded deliverable section.
- A writing sample, anonymised (a checklist, a KPI readout you wrote) → F5 and the written-communication row become inspectable evidence.
- Whether the puzzle title was live-service, and what its content cadence was → F3 is grounded in your own words.
- How the retention figure was counted → the answer slots in C1 and C2 get your own method, not a slot.
