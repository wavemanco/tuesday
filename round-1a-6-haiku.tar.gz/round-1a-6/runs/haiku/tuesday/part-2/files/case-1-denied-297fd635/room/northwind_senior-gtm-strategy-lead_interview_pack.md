# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. A peer, on the same VP's team.
**Round:** One 60-minute conversation with Dan.
**Built on:** The coach's notes only: the JD highlights, the candidate summary, the research note and Dan's profile. No full JD text and no web research (see Sources).

---

## How to use this pack, and the type key

Personas describe how a question arrives: the tone, the pace and what the interviewer is listening for. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every answer must be the candidate's own, in her own words.

| Type | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. None in this pack: no values-style round is detected for a peer conversation. |
| EXP | Work-experience deep-dive | Whether the stated experience holds up under scrutiny, and what she actually did |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy | Homework depth on Northwind's priorities and threat |
| CASE | Live problem | Structure and reasoning on a problem from the role, asked live |

Provenance labels: `[grounded]` traces to the coach's notes or the JD highlights in them. `[inferred]` is a derivation from a weaker source, with the derivation named. `[generic]` is a role-family pattern with no claim about this candidate or this company.

---

## Fit snapshot

Every evidence quote is from the coach's notes, the only input. None is yet in Priya's own words or from her CV. Confirm each one with her before rehearsing (see the upgrade menu). Until then, every row is a relayed claim.

No gate appears in the JD highlights. The full JD may hold one, such as a location, office-days or start-date requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "in product strategy & ops" (coach's notes) | medium | [grounded] | transferability | Product strategy and ops is adjacent. It is not GTM ownership of a launch, so the bridge stops at the quote. Words: "I spent nine years in product strategy and ops." Answer slot: if you made any go-to-market decision for a product, name it and say how you decided. If none was yours, say so and say how you would own one here. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | The quote is an ARR result from a product change. It is not a whitespace map across the four stages. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you mapped where revenue was or was not coming from before proposing it, say what you looked at. If you did not, say so and say how you would size whitespace across the four stages. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | The quote names the tools, not an analysis she ran alone. Words, from the quote only: "I'm skilled in SQL and Tableau." Answer slot: name one analysis you ran yourself, the question it answered and what it changed. If the work was a team's, or you only used existing dashboards, say so plainly. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | A partner-level revenue model used in negotiations is adjacent to designing how partners are engaged. It is not the same work. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped how partners were engaged, say which part and how. If you did not, say so and say what the model covered. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote already reaches cross-org influence in other terms. The bridge only rewords it. Words: "I set annual volume targets with cross-org consensus." If someone disagreed, the answer slot is who and how it was resolved. If no one did, say so. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | discovery | The quote shows use, not building or applying AI in a product or workflow. Words: "I use AI tools daily." Answer slot: name one thing you built or changed with AI. If daily use is the extent of it, say that. |
| F7 | "Senior GTM Strategy Lead" (role title, coach's notes) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | none | The two stretches already speak to the seniority the title implies. No bridge is needed. Use the quote's own terms. |
| F8 | Not in the JD highlights. Raised in the coach's notes as the known gap, and a likely probe given Dan's sales-strategy role. | "No classic sales-ops or quota-setting experience." (coach's notes) | none | [grounded] | capability | The absence is stated. Words: "I don't have classic sales-ops or quota-setting experience." Anything beyond that is a plan, said as a plan, never as a past. |

Gap-type routing: F1, F2, F4 and F6 are a bridge from a quote to a wider requirement. F3 is a discovery row because the material is silent on whether analysis was run. F8 is a capability row because she stated the absence. Confidence measures the candidate's evidence, not the row's wording.

---

## Interviewer read

Source: the coach's notes. No public footprint was checked, so this is not a public-profile read (target 4 below).

- **Career pattern:** a pricing and monetization spine, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven".
- **Implications:**
  - Every metric she offers will be probed to its assumptions. The Prober is up.
  - Case questions tilt toward pricing, packaging and unit economics. That is his native language.
  - The startup chapter means he may value builder stories and probe a big-company background for scrappiness. Expect that probe.
- **Mirror opportunities:** weak. He has no shared jump with her. A comparable domain exists: he works in monetization, and F4's revenue model, quoted in B1, sits next to it. Use it only if it comes up naturally, and never as a claim about her pricing experience.

---

## Persona table

Weights are relationship priors (peer: Peer Evaluator and Data-Driven Prober), adjusted by the interviewer signals above and by the single session. Depth follows weight: top 4 to 5 questions, middle 3, low 2.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy (rehearsal method) | Question IDs |
|---|---|---|---|---|
| Data-Driven Prober | Counts the ARR and carrier-model figures, and asks for inputs and denominators | Top (5). Peer prior, plus "relentlessly data-driven". Her headline numbers are the magnets. | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before he does. | A1 to A5 |
| Peer Evaluator | Seam questions with his pricing work, and disagreement and credit | High (4). A peer prior. His monetization work sits next to her revenue model, so seam probes are likely. | Reciprocity framing: what you bring his team. Propose seam principles, not a claimed knowledge of his seam. | B1 to B4 |
| Case / Strategist | A live problem on Compass or the whitespace | Middle (3). A pricing-native interviewer tilts cases to packaging and unit economics. Cases are less likely in a peer conversation. | Clarify, then objective, segmentation, approach, metrics, risks. Say the structure aloud. | C1 to C3 |
| Skeptic | The sales-ops and quota gap, and day-one weakness | Middle (3). The gap is the predictable objection. A peer probes it through a seam, not a gotcha. | Rehearse the single objection until it is boring. Hold, then concede the specific gap. Do not claim quota experience. | D1 to D3 |
| Conversational / Rapport | An opener, and a casual question on AI | Low (2). An informal start to a 60-minute conversation. Casual questions are still scored. | A 90-second arc for the opener. Treat the AI question as scored. | E1, E2 |
| Pressure / Stress | A sharp "why you" or an attribution challenge | Low (2). Peers rarely time-box, but a data-driven peer may challenge. | Pause and restate. Hold through two follow-ups. Concede specifically. | F1, F2 |
| Values / Behavioral | (not included) | None. No values-style round is detected, so no VAL questions and no values cheat sheet. | n/a | none |

---

## Question banks

Total: 19 questions, inside the 18 to 26 range. Each row's Provenance sits before its guidance. The Rationale refers to the candidate's history only by fit-snapshot row ID.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Beats the quote states: you proposed the change, and it is credited with the uplift. Say that in those words. Answer slot: if you know how the uplift was counted, say how, in your own words. If you do not, say so plainly and say who did the counting. Weakest-assumption move: name the assumption behind the figure you would defend least, before he does. | F2 is the headline number, and a data-driven peer probes it first. EXP because it tests attribution. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Name the weakest assumption in your own words, and say which part of the figure was yours: the proposal, the credit or the counting. Answer slot: if you did not see how it was counted, say so. Do not guess an assumption. Stay with what you said in A1. | F2 again. A Prober's stem, and the second follow-up on the same figure. Naming the weak assumption first turns a gotcha into a credibility gain. |
| A3 | "Walk me through the carrier revenue model: what did you build yourself, and what did you take as given?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped on F4: you built a partner-level revenue model, and it was used in carrier negotiations. Tell it in those beats. Answer slot: say which parts of the model you built and which you took as given. If all of it was yours, say so. If some inputs came from others, name them as theirs. | F4 is the partner-requirement evidence, and the carrier use shows the model was used. The Prober tests the inputs, so the slot asks which were hers. |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau. What question did it answer, and what changed?" | JD | [grounded] "skilled in SQL/Tableau" (coach's notes) | Open prompt, so a selection scaffold. Pick one analysis you ran yourself: the question, the tool, and what it changed. If the work was a team's, or you only used existing dashboards, say so plainly and give the nearest analysis you did. Name the tools only as the quote does. | The JD requires independent analysis in SQL and Tableau, so this is the only JD-tagged question for that requirement. F3 is discovery because the quote names tools without showing analysis. The honest branch is the weak point. |
| A5 | "How much of that uplift would you have expected without the change?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Answer slot: the counterfactual is the probe a Prober runs on a credited number. If you had a baseline or comparison, say what it was. If you did not, say so plainly, and say what you can and cannot say about the baseline. Do not supply a counterfactual. | The second defend-the-number question on F2, aimed at its counting. The question assumes a baseline the quote does not state, so the honest branch must allow there was none. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes). The principle is [generic]. | Propose seam principles, not a claimed knowledge of his seam: for example, who sets price, and who owns the buyer or partner conversation. Name one principle the seam should follow, then say you would agree it with him rather than assume it. The revenue model is the one place your material touches monetization. Say that once, and say what you would want from him. | A peer stem. He works in pricing and monetization, so the model's overlap is where collegial probing lands. F4 is the evidence. The principle is generic. |
| B2 | "Where would you expect us to disagree on how a new product line gets priced or packaged?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Hold to the one consensus the quote carries: you set annual volume targets with cross-org consensus. Say how a disagreement was handled, in your words. Answer slot: if you have a case where you disagreed with an equal and kept the working relationship, name it. If the consensus came without conflict, say so plainly. | The JD's cross-functional influence line raises this, and F5 is the evidence. Peer disagreement style is what he scores. JD-tagged because that requirement has no other question. |
| B3 | "How do you handle credit when work spans teams? The ARR change was credited to someone. Was it you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Separate proposing from delivering. Say whose the credit was and what others did, in your words. Answer slot: if the credit was shared, name who else shared it and what they did. If it was yours alone, say that plainly. | Credit-sharing is a peer probe, and "credited" in F2 invites it. EXP because it tests attribution. |
| B4 | "Where does product strategy stop and GTM strategy start, for a new line?" | JD | [grounded] "in product strategy & ops" (coach's notes) | Give the seam in the quote's terms: what product strategy covered in your nine years. Then the principle: product decides what ships, and GTM decides how a buyer finds and adopts it. The principle is generic. Answer slot: name one go-to-market decision you were part of for a product, and say your part. If none, say so plainly. | "Own GTM for two new product lines" is the first JD requirement, and a peer will test the product and GTM seam. F1 is the evidence. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you'd set land, adopt, expand and renew targets for Compass. What do you need to know first?" | CASE | [grounded] "an AI copilot launch ('Compass')" (coach's research note). Raising line: "identify whitespace across land/adopt/expand/renew" (JD highlights). | A live problem, asking about no past. Clarify, then objective, segmentation, approach, metrics, risks. Say first what you would need to know: the copilot's buyer, its price, and what it is bundled with. Challenge one premise respectfully. Use the four stages as the frame. | Compass is a stated priority from the coach's research note, which is not independently verified in this run. CASE tests structure, and the question presupposes nothing about her history. |
| C2 | "Enterprise expansion is the priority. Where's the whitespace in our installed base, and what's the first cut you'd make?" | JD | [grounded] "enterprise expansion" (coach's research note). Raising line: "identify whitespace across land/adopt/expand/renew" (JD highlights). | Clarify the base and the stage first. Then state the cut, the metric and the risk. Claim no installed-base data you have not seen. CASE delivery. | The only JD-tagged whitespace question, so the requirement has coverage. CO content from the research note. Primary type JD, delivered as a case. |
| C3 | "Bundling by a much larger platform vendor is the threat. How would you price a standalone line against a bundled offer?" | CO | [grounded] "bundling by a much larger platform vendor" (coach's research note) | Structure: what the bundle replaces, for whom, and what it costs the buyer. Unit economics before price. Name the metric and the risk. The bundle may be free to the buyer, which is generic. Make no claim about her pricing experience. | The main competitive threat, stated in the research note. Pricing-native interviewer, so this tilts to packaging and unit economics. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see quota-setting or sales-ops in your background. How would you set targets for a new line without that?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." (coach's notes). Nearest quote: "set annual volume targets with cross-org consensus" (coach's notes). | **The highest-ROI prep in this pack.** Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then hold, do not fold. The nearest thing you stated is "set annual volume targets with cross-org consensus". Say it at that scope, and do not stretch it into quota experience. Concede specifically, then give the ramp plan as a plan: what you would learn in the first month, and from whom. Hold through two follow-ups by returning to the quote. | This objection will arrive in some form. F8 is the evidence, and F5 is the adjacent limit. Dan's sales-strategy role makes a skeptical probe likely, which is the pack's analysis, not a fact about him. Deepest rehearsal: the most follow-up levels, and the exact concession wording. |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the one requirement you would be least ready for on day one, then what you would do in the first month. Answer slot: if you have designed a partner motion, say which. If you have not, say so plainly. Stay within the quote's scope. Do not say you have designed a motion. | The partner-motion requirement is the one with no direct evidence (F4 is transferability). A skeptic's stem, and the honest answer is the gap, not a bluff. |
| D3 | "Why this role after nine years in consumer tech, rather than one closer to pricing?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Answer slot: give your actual reason for the move, in your own words. The material gives none beyond the quote, so the pack supplies none. Do not disparage the consumer-tech years. | A motivation probe, and the reason is absent from every source. Left as a slot so no reason is invented. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes). [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes). | A 90-second arc. Beats: strategy consulting, then product strategy and ops in consumer tech, with the carrier revenue model as the concrete middle. Each beat is a clause a quote states. Add no story middle. End with the ARR proposal only if he leads there. | A casual opener, scored for economy and genuine interest. Two quotes carry the beats. |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools in your own words, and one concrete thing you did with them. If it is only daily use, say so. Do not inflate to building AI, even as a plan. | The JD's AI-as-a-plus line, asked casually. The question is scored, and F6 is low-confidence, so the guidance stays at the level of use. |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who's run quota targets for a decade?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." (coach's notes) | Pause, then restate. Hold the position you can back: the volume targets you set with cross-org consensus. Two follow-ups without folding on the core. Concede the gap specifically: "I haven't set quotas." Then the ramp plan. Do not say you would be as good as someone who has. | A pressure stem on the sourced gap. The hold is only what F5's quote carries. |
| F2 | "The volume targets you set. How much of the consensus was actually you?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Hold: you set the targets, and the consensus was shared. Say which part was yours. Concede specifically: say what was shared and what was yours. Do not claim the consensus as solely yours. Hold through two follow-ups. | Pressure on attribution. F5 is the evidence. The consensus is shared by definition, so the concession is honest. |

### Requirement coverage

| JD highlight requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B4 (JD), C1 (CASE) |
| identify whitespace across land/adopt/expand/renew | C2 (JD), C1 (CASE) |
| run independent analysis in SQL and Tableau | A4 (JD) |
| partner-motion design experience required | D2 (JD), A3 (EXP) |
| strong cross-functional influence | B2 (JD) |
| AI experience a plus | E2 (JD) |

Deliverables: none declared. No build section.

---

## Reverse questions

Five or more, each with its reason. One ties to Dan's own path, and one is reciprocity for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You started in pricing and monetization, and had an early-stage chapter. What did that teach you about launching something new that a big-company track wouldn't?" | Ties to his own path. It turns the motivation probe into a peer conversation about his experience, not an interrogation. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer signal. It shows you are planning to add to his team, not only to take from it. |
| R3 | "Where does your pricing work end and the new-line GTM work start today? Who decides?" | Opens the seam directly, so B1 and B4 become a shared problem. |
| R4 | "For Compass, what's the one metric your team will watch in the first quarter?" | Shows you know the priority, and asks his view, not a fact about the company. |
| R5 | "When a platform vendor bundles, where does your team see the first customer loss?" | Sharpens C3 with his real data, and tests the bundling threat from the research note. |
| R6 | "How does the profitability priority change which new-line bets get funded this year?" | Connects the third priority to the decision he would make. |

---

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them is coached, and no guidance cell may assert, soften or imply one.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The pack's own observation, not words for her: the material says product strategy, not a GTM launch. |
| Designed the partner motion | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says a revenue model, not a partner-motion design. |
| Delivered the $400M, or drove the $400M ARR | Inflated form of F2 | "proposed ... credited with". The material says credited, not delivered. |
| Ran an analysis in SQL or Tableau that changed a leadership decision | Inflated form of F3 | The tools only, as the quote says them. An analysis appears only as the answer slot. |
| Led cross-org alignment | Inflated form of F5 | "set ... with consensus", at the quote's own scope. |
| Has set quotas or run sales ops | Negative stated by the candidate, F8 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot. |
| Has AI product experience | Inflated form of F6 | "uses AI tools daily", at the quote's own scope. |

---

## Sources

Provided documents: the coach's notes. These cover the candidate summary, the JD highlights, the research note on Northwind's priorities and threat, and Dan's profile. No provided document is a values page, a loop description or a strategy brief.

Searches sent, and what came back: "Northwind Data company values" (refused, the search permission was not granted). "Northwind Data interview process sales strategy" (refused, the same). No fetches were attempted. Nothing attributable to Northwind Data was returned, so no web-sourced claim appears in this pack.

Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data` values | unavailable | Values cheat sheet, not built: no values-style round is detected for a peer conversation. Query "Northwind Data company values" was refused. |
| 2. `Northwind Data` interview process, sales strategy | unavailable | Loop structure. Persona weights stay at the peer prior, with no archetype claim. Query "Northwind Data interview process sales strategy" was refused. |
| 3. `Northwind Data` strategy / recent news | skipped | The coach's research note already supplies the three priorities and the bundling threat. Its date is unknown, so the pack labels it as the note, not as verified current strategy. |
| 4. Dan Kovac, Northwind Data | unavailable | Public footprint: the interviewer read, and personal reverse questions. No call was sent, because search was unavailable in this run. |
| 5. representative JD for the title | skipped | The JD highlights supplied, which fix the snapshot's requirements. They are highlights, not full text. Full text is on the upgrade menu. |

---

## Upgrade menu

- Full JD text → the highlight rows become quoted JD lines. It may also reveal a gate (location, office days or start date) and mid-list requirements the highlights leave out.
- Priya's own words on each quoted line in the fit snapshot → rows move off the relayed-claim caveat. Without this, every row here is the coach's summary, not her evidence.
- A real example of consensus-building under disagreement, in her words → upgrades B2 and D1 from a limit to a story.
- The recruiter's note on focus areas or a pre-declared deliverable → a deliverable build section, if one is named.
- Dan's public footprint (name given; search refused this run) → a personal reverse question and a deeper interviewer read.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, for a company strategy brief and recent org context → the Compass and bundling questions cited to sources instead of the research note. Want it?
- A `tuesday-dossier.md` → replaces the locally built prohibited list with graded evidence, if one exists.
