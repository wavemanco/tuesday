# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager).
Round: the Outage Hour, as Saltmarsh's careers page describes it: one 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
Built on: the JD as supplied, your background as you described it, and L1 research.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment, measured against Saltmarsh's published values.
- **EXP**: your own work, tested for attribution.
- **JD**: the listed job's responsibilities and requirements, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, structured on the spot.

Guidance is scaffolding, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title's content-drop calendar. Live events across two titles are not in it. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across more than one title or built live events, say what and how you decided, in your own words; if not, stay with the calendar you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these teams. The only team it names is QA. Answer slot: name the teams you worked with on an update and what each did; if the work ran through QA alone, say so plainly and describe that handoff. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows you presented the numbers. It does not show you owned a post-event review or its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you decided what was reported, or what was reviewed after an event, say what and how; if you did not, say so and describe how you would run the review. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement: you wrote the checklist, and QA still uses it. Rehearse what you did with it on a release, in your own words (A5). |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years and the title are your words. The material does not say "live-service"; your content-drop calendar is the closest link. Bridge: "For four years I was an associate producer at a puzzle-game studio." "Associate producer" is not "producer", so say the title as it was. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on how far the calendar went (A3). |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in role terms; the bridge only reuses it: "I presented the monthly retention numbers to the studio head." Answer slot: if you can say how those numbers were counted, say so; if not, say so plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written document other teams depend on is in the quote; the bridge reuses it. The material holds no other writing sample, and the loop has no written component, so this is judged live through D3. |

Two items from your message have no JD line: no team leadership, and no game with in-app purchases. They are handled in the Skeptic bank as sourced negatives, not as rows.

Requirement coverage:

| Requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, B1 |
| Coordinate design, art, engineering and community teams | A4, B1 |
| Own the post-event review and its KPIs | A2, D1, D2, D3 |
| Manage the release checklist with QA | A5, C3 |
| 3+ years producing live-service games or apps | B1 |
| Experience running a content calendar | A3 |
| Comfortable with player-retention metrics | D1, D2, F2 |
| Clear written communication | D3 (no written sample in the loop; judged live only) |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| I have led a team | Sourced negative (your message) | "I haven't led a team." Then the plan, as a plan (B2). |
| I have worked on a game with in-app purchases | Sourced negative (your message) | "I haven't worked on a game with in-app purchases." Then how you would learn it (B3). |
| I ran live events, or a calendar across two titles | Inflated form of F1 | F1's quote at its own scope. Pack observation: the material shows one title's content-drop calendar. |
| I owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. Pack observation: the material shows a presentation, not an owned review. |
| I managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it. |

## Reading the interviewer

Public professional footprint only.

- **Career pattern:** a GDC 2026 talk listing (search snippet) names him Head of Live Operations at Saltmarsh, previously a QA lead at a console studio.
- **Self-described thesis:** "a live team is judged by how often its patch notes describe what actually shipped."
- **Implications:** expect probes on release accuracy, so bring the checklist and say exactly what it checks. He comes from QA, so be precise about what you did and what QA did. Patch-note accuracy maps onto the post-event review: say what a review checks its findings against.
- **Mirror opportunity:** the release checklist with QA is shared vocabulary. There is no shared career jump to claim.
- **Verification:** the talk page was not opened; the link's domain looks like a placeholder. Confirm the talk on the conference's own schedule before you mention it.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a live incident during an event | High. The loop's named format, per the careers page. | Clarify, objective, options, decision, comms, review. Think aloud. |
| Skeptic | Probes the two-title gap, leadership and in-app purchases | High. A hiring manager buys capability and derisks gaps; the gaps are in F1, F2, F5 and the two sourced negatives. | Rehearse B1 until it is boring. Bridge only from what you stated. Name limits plainly. |
| Values / Behavioral | The values conversation after the tabletop, against three published values | High. The loop source documents a values conversation. | Map each value to a story where one exists; use the selection scaffold where none does. |
| Data-Driven Prober | Asks how the retention numbers were counted | Medium. Post-event review and KPIs are in the JD, and the interviewer's background is QA. | Name the weakest assumption if you know one; if not, say so. |
| Conversational / Rapport | Warm opener, "walk me through the journey" | Medium. | A 90-second arc built only from your sentences. |
| Pressure / Stress | Sharp follow-up on leadership or attribution | Low to medium. | Hold, then concede the exact gap. |

Weights: hiring-manager prior gives Case and Skeptic; the loop source's values conversation makes Values certain; the QA background tilts toward Prober on release and review. Depth: Case 5, Skeptic 4, Values 4, Prober 3, Conversational 2, Pressure 2. Twenty questions in total.

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two hours into a weekend event on one of your two titles, a reward bug starts paying out double. Walk me through it." | CASE | [grounded] saltmarshgames.com/careers/interviewing: "a live-incident tabletop on a simulated outage during a live event" | Clarify first: how many players, what it costs per hour, whether it can be switched off without a patch. Set the objective: stop the payout without misleading players. Lay out options (pause the event, hotfix the reward, compensate players), each with its cost and who must agree. Name who comes in and in what order: engineering to stop it, QA to verify the fix, community to explain it. Say the decision aloud, then the review you would run afterward. | The Outage Hour is this format. The question presupposes nothing about your past. |
| A2 | "After an event closes, what goes into the post-event review, and which KPI would you trust least?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Name the review's inputs: the KPIs it reports, the release timeline, the player feedback channel. Name the one KPI whose counting you would question first, and why, in your own words. Say what the review changes next time. | Scores the JD's post-event line. The ask is about method, not your history. |
| A3 | "Your calendar has to cover two titles, each shipping updates every week. How do you lay it out?" | JD | [grounded] JD: "Plan and run the live-events calendar for two mobile titles"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from what is fixed: freeze dates, each team's capacity, events that cannot move. Lay both titles on one view so collisions show. Say how you would decide which title wins a clash. Answer slot: if you have laid out a calendar across more than one title, say how; if not, say you have run one weekly calendar and describe how you would extend it. | F1 and F6. The two-title scope is the JD's headline and the likeliest probe. |
| A4 | "On an update, who do you bring in, when, and who decides when the plan changes?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | List the four teams in the order they touch an update, then name the decision owner. Say when each enters and what it signs off. Answer slot: name the teams you coordinated on a release and what each did; if your work ran through QA alone, say so and describe that handoff. | F2 has no quote, so the slot carries the rehearsal. |
| A5 | "Walk me through a release, from the checklist to the ship decision." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Begin with the checklist you wrote and what it checks. Then one release, step by step, in your own words: what you ran through it and who signed off. Answer slot: if you ran each release through it yourself, say how; if not, say so and say what your part was. | F4. The JD names the checklist with QA; the premise is your sentence. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your calendar ran one title, a puzzle game. What changes when you run two live-service titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "4 years as an associate producer at a puzzle-game studio." | Highest-ROI prep in this pack. Concede the difference first, plainly: one title, puzzle, a content-drop cadence. Then name what carries over: the calendar, the weekly rhythm, the checklist. Answer slot: if you have worked on a second title or on live events, say which and what you did; if not, say so and name how you would learn the difference in the first month. Hold through two follow-ups by returning to what you ran, not to what you would do. | F1 and F5 both carry it. "Live-service" and "two titles" are JD raising sources. Deepest rehearsal goes here. |
| B2 | "You've never led a team. How would you run this one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't led a team." Then the plan, as a plan: which decisions you would take on day one, which you would hand off, how you would check in with the four teams. Never describe past leadership. | The JD asks for coordination, which is influence without authority, so the gap is predictable. |
| B3 | "I don't see in-app purchase work in your background. How would you handle monetized updates in this role?" | Stem | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it: which people you would ask and which material you would read first. | A persona stem, with your own negative as its source. |
| B4 | "Why live operations, after four years on one puzzle title?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your reason in your own words. The material does not state one, so this is a slot: name the live-ops work you want and why, in terms you can back with one thing you did. If you cannot, say so plainly. | Motivation consistency is scored in the Skeptic persona. |

### Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] value: "Players Before Plans" (saltmarshgames.com/values). No quoted sentence carries a story. | Selection scaffold: pick an update where player feedback or retention numbers pushed back on the plan. It needs the plan, the signal, and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented, and what they showed, in your own words. | VAL coverage. No story is quoted, so this is a scaffold, not a mapping. |
| C2 | "Ship the Patch Not the Promise: when did something get announced before it was built?" | VAL | [grounded] value: "Ship the Patch Not the Promise" (saltmarshgames.com/values). No quoted sentence carries a story. | Selection scaffold: pick a time an announcement ran ahead of the build, or one you held back. If none, say so, then describe what the release checklist checks before anything is announced. Answer slot: if you held an announcement back, say what triggered it. | Same reasoning as C1. |
| C3 | "Leave the Build Greener: what did you leave better than you found it?" | VAL | [grounded] value: "Leave the Build Greener" (saltmarshgames.com/values); [grounded] "Wrote the release checklist our QA team still uses." | Story map: the checklist is the story. Beats are the quote's own clauses: you wrote it, and it is still in use. Name what it checks. Answer slot: if you know what it replaced, say so; if it had no predecessor, say so. | F4 carries the only story sentence. The published value's "every release leaves ... better" is matched by "still uses". |
| C4 | "Tell me about a time you had to deliver an unpopular truth to a leader." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number went against what the leader hoped. Name the number, the hope, and what you said. If the numbers always told the leader what they wanted, say so, then give the presentation as it was. | Persona stem. The retention presentation is the nearest quote, with no outcome supplied. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What was the retention number you presented, and what did it measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say the number's name and what it measured, in your words. Answer slot: if you know how it was counted, say how; if not, say plainly that you do not know how it was counted. | F7. No figure was given, so this is an open counting question with an honest branch. |
| D2 | "What is the weakest assumption you know of in a metric you have reported?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name one assumption you would defend least, in your own words. If you cannot name one, say so. | The metric move, with no assumption supplied. |
| D3 | "Write me the first paragraph of a post-event review for a studio head who has ten minutes." | JD | [grounded] JD: "clear written communication"; [grounded] JD: "own the post-event review" | Structure: what happened, its effect on players, the KPI movement, the decision, the next check. Say it in the room. No claim about your past. | The loop has no written round, so this tests the JD's writing requirement live. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, in your own words, built from these four sentences and nothing else: the studio, the calendar, the checklist, the retention presentation. | Rapport openers are scored. The arc is the pack's structure, not an added story. |
| E2 | "What live game do you play most closely, and what would you change in its update cadence?" | JD | [generic] | Name one game and one cadence change, with a reason you could defend. Do not build a history with the game that you have not stated. | A casual question on live service, scored. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you for a team you have never led?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold, then concede. Hold the calendar and the checklist. Concede the leadership gap in its plain words: "I haven't led a team." Then the plan. Do not fold on what you ran. | Composure test. The leadership gap is a sourced negative. |
| F2 | "That retention number — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold what you presented, in its own words. If others produced the figure, say so and concede it. Concede what you did, in your own words, if anything. Do not claim the number. | An attribution probe. The honest answer is the precise one. |

## Values / principles cheat sheet

Detected: the loop source documents a values conversation. Values as published, from saltmarshgames.com/values.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Selection scaffold: C1. Nearest quote: the retention presentation (C4). |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | Selection scaffold: C2. |
| Leave the Build Greener | Every release leaves "the codebase and the checklist better than it found them." | C3: "Wrote the release checklist our QA team still uses." |

## Reverse questions

1. "Your talk on patch notes argued a live team is judged by how often its notes describe what shipped. What did the team change after that?" Why it lands: it converts the interview into a conversation on his own path. Use it only after you have confirmed the talk on the conference's schedule.
2. "Your announcement about a single live-ops group across two titles: how do post-event reviews change when the team is shared?" Why it lands: it shows you read the company's public news, and it targets the two-title scope the JD asks for.
3. "In the outage tabletop, who has authority to pause an event mid-run?" Why it lands: decision rights are where live-ops roles usually stall, and the question shows you think in incidents.
4. "What does the first 90 days look like for whoever owns the post-event review?" Why it lands: it scopes the role and shows you are planning for the job, not for the interview.
5. "Which release on the checklist has caused the most trouble lately?" Why it lands: it shows you care about the QA side of the release, which is where his background sits.

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and C1–C3. Four values not in the cheat sheet: none. |
| 2. Saltmarsh interview process | yes | Loop structure: one 60-minute Outage Hour with the hiring manager, a tabletop and a values conversation. No take-home. Persona weights follow it. |
| 3. Strategy / recent news | yes | A September 2026 news snippet on a single live-ops group across two titles: A3 framing and reverse question 2. Snippet only; not opened. |
| 4. Interviewer name | yes | A GDC 2026 talk listing: the interviewer read and reverse question 1. Snippet only; not opened. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries and results:

- "Saltmarsh Games mobile studio values" → saltmarshgames.com/values (fetched)
- "Saltmarsh Games interview process live operations producer" → saltmarshgames.com/careers/interviewing (fetched)
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" → talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; not opened)
- "Saltmarsh Games recent news 2026 strategy live service titles" → saltmarshgames.com/news/project-larkspur (search snippet only; not opened)

Provided documents: the JD text and your message.

## Upgrade menu

- Your CV or résumé, pasted → more of your own sentences: F3, F5 and F8 get stronger evidence and fewer answer slots.
- The names of your two titles, or any live-events work you have done → A3 and B1 name the titles and rehearse an answer rather than a slot.
- Who else is in the room → confirms a one-to-one; a panel would reweight the personas.
- The Saltmarsh news release, full text → sharpens A3 and reverse question 2 with the actual framing.
- The talk on the conference's own schedule → confirms the interviewer read and reverse question 1.
- How the retention numbers were counted, in your words → D1 and D2 move from answer slots to grounded answers.
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for the CO questions, and more on the interviewer's public talks.
