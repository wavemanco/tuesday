# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** Outage Hour, 60 minutes, hiring-manager round (per Saltmarsh's careers page). **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Friday 27 November.**
**Changelog:** first version.

## 2. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

- **CASE:** a live problem from the role, solved aloud.
- **JD:** a stated requirement from the job description.
- **EXP:** a question about your past work, probing what was actually yours.
- **VAL:** a question mapped to Saltmarsh's published values.
- **CO:** company and strategy knowledge.

## 3. Prep triage (Friday is tomorrow)

1. **A4, the two-title calendar.** This is the highest-ROI prep. Your material shows one title's calendar, and the JD asks for two. Rehearse the honest answer until it is plain.
2. **A1 and A6, the Outage Hour tabletop and the post-event review.** Practise clarify, then decide, then review, out loud, for 90 seconds each.
3. **C1, "never led a team."** Say "I haven't led a team" in one breath, then move to what you did do.
4. **B1 to B4, the values conversation.** Know the three values by name and have one honest answer for each.
5. **Everything else is insurance.** Skim it once.

## 4. Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your own message, and the page quotes come from Saltmarsh's site.

No row is a hard gate. The JD asks for years of experience and skills, not a credential or eligibility, so no requirement needs the gate treatment.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, not two titles' live-events calendars. Say the round you ran, not the scope you have not run. Answer slot: if you planned across more than one title, say how; if not, say so and describe how you would sequence two. |
| F2 | "experience running a content calendar" (JD) | "ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote already reaches this requirement. Lead with it in your own terms. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none given | [grounded] | discovery | Your material does not show cross-team coordination on updates. Answer slot: describe one update where you brought other teams in and what you did; if none, say so and say how you would run one. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | discovery | Your quote shows presenting KPIs, not owning a post-event review. Answer slot: if you ran or wrote a post-event review, say what it covered; if not, say so and say what you would include. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms: you wrote it and QA still uses it. Keep the claim to writing it. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years is past the three in the JD, but your title was associate producer on a puzzle game. Say the years and the title as they are. Do not call the work live-service unless you can describe its live cadence, which you can: the content-drop calendar in F1. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your quote shows you presented retention numbers monthly. Say that, and how you knew what each number was. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A checklist is written work, but your material holds no writing sample. Answer slot: if a document you wrote can be shared or described, say what it was for and who used it. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote about it. F4 and F8 are `low` because the evidence is thin, and `[inferred]` because the bridge is this pack's reading of your quote.

## 5. Graded deliverables

None announced.

## 6. Grounding brief (what Saltmarsh looks like now)

- **Project Larkspur (September 2026):** Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027. Per-title event teams are retired in favour of a single live-ops group. Use this vocabulary, and do not call it an old plan.
- **Three values** (below).
- **Outage Hour:** a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## 7. Reading the interviewer

Public footprint only. The GDC 2026 talk "Patch Notes Are a Promise" is known from a search snippet. I did not open the full page.

- **Career pattern:** previously a QA lead at a console studio, now Head of Live Operations.
- **Argument:** a live team is judged by how often its patch notes describe what actually shipped.

**Implications:**
- The QA background means your checklist answers (B3, D4, P2) will be tested closely. Know exactly what you wrote and what QA did with it.
- The talk's argument is the same as Ship the Patch Not the Promise. Use the phrase only after you have given a real example.
- **Shared jump:** Tobias's path ran from QA into live operations. Your path ran from building a QA checklist into producing a live calendar. Quote F5 as your side of that path: "Wrote the release checklist our QA team still uses."

## 8. Persona table

Prior for a hiring-manager round is Case/Strategist plus Skeptic. The company page names a tabletop and a values conversation, so Case and Values rise. Weights below are a judgment; tell me if you know this interviewer better.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop on a live event | Highest. The careers page names this format. | Clarify scope first, then state the metric you would watch, then decide. |
| Values/Behavioral | The values conversation on the three published values | Certain. The company page names it. | One honest story per value, or say plainly where you have none. |
| Skeptic | "Never led a team," and the two-title scope | High. Your material's gaps are the likely probes. | Say the gap plainly, then the nearest real evidence. |
| Data-Driven Prober | Counting the retention numbers you presented | Medium. You listed retention as a presentation, not an analysis. | Say how each number was counted, or which part you presented. |
| Pressure | A time-boxed challenge on the two-title scope | Lower. It is a single hour interview. | Hold the claim through two follow-ups, then concede precisely. |

## 9. Prohibited claims

These are claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. This pack observes that your material says one title's calendar. A4's slot stays inside that calendar. |
| Led cross-team update coordination | Inflated form of F3 | No quote carries it. F3's slot asks what you did do. |
| Owns post-event reviews and the KPIs they report | Inflated form of F4 | F4's quote shows presenting numbers, not owning a review. |
| Designed the retention analysis | Inflated form of F7 | F7's quote at its own scope: you presented the numbers. |
| Has led or managed a team | Stated negative: "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." No slot. |
| Has worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## 10. Values cheat sheet

Values are from saltmarshgames.com/values, fetched.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | B1: quote "ran the weekly content-drop calendar for our main title for the last two years." Selection scaffold, with its honest branch in B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | B2: no quote carries a story here. Selection scaffold, with its honest branch in B2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | B3: quote "Wrote the release checklist our QA team still uses." Answer slot in B3. |

## 11. Question banks

Session totals: 19 questions. Weight: Case 6, Values 4, Skeptic 3, Prober 4, Pressure 2.

### A: Case/Strategist (Outage Hour tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your live event is an hour in and one platform's build is crashing. Walk me through what you do first." | CASE | [generic] | Clarify: how many players, which platform, since when. Then name who you pull in: engineering, QA, community. Then decide whether to pause or hotfix. Say the first ten minutes out loud. | A live problem from the Outage Hour format. No claim about your past. |
| A2 | "A retention number drops during an event. What do you check before you call it a problem?" | CASE, JD | [generic] | Name the weakest assumption in the metric before they do: did the measurement change, or is it the event? Then say what you would look at first. | JD line on post-event KPIs. Metric questions name their weakest assumption. |
| A3 | "The checklist says no-go and the event is announced for Friday. What do you do?" | CASE | [generic] | Name who decides with QA, what you tell the community, and what you would record. | JD line on the release checklist with QA. |
| A4 | "Two titles, one shared calendar from February. How do you sequence the next quarter?" | CASE, CO | [grounded] "ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "one shared events calendar from February 2027" (saltmarshgames.com/news/project-larkspur) | Start with the one calendar you ran for two years, in your words. Then say how you would sequence two titles against one calendar. Answer slot: if you have planned across more than one title, say how; if not, say so and describe the sequencing you would use. | Highest-ROI prep. F1's scope is the likeliest probe here, and the Larkspur news makes it current. |
| A5 | "Community wants a fix that engineering says is not ready. How do you run that conversation?" | CASE | [generic] | Bring the decision to the affected groups, name what each team needs, and say what you would tell players. | JD line on coordinating teams on each update. |
| A6 | "Walk me through the post-event review you would run after this outage." | CASE, JD | [generic] | Timeline first, then what you would measure, then who owns each action. Answer slot: if you have run a post-event review, say which one and what it covered; if not, say so and describe the one you would run. | F4 is discovery, so the honest branch must be ready. |

### B: Values/Behavioral (values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "ran the weekly content-drop calendar for our main title for the last two years" (your message) | Selection scaffold: pick a drop date that conflicted with something players needed. If no conflict comes to mind in two years, say so, then give the nearest real conflict you had. | Values question mapped to the calendar you ran. |
| B2 | "Ship the Patch Not the Promise. When did you announce something before it was built?" | VAL | [generic] | Selection scaffold: if you can name one announcement and what shipped, say both. If not, say so, then say how you would check an announcement against the build. | No quote carries a story here, so the honest branch is required. |
| B3 | "Leave the Build Greener. What have you changed in a process that you would keep?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | The checklist, and that QA still uses it. Answer slot: if you changed it after it went live, say what changed; if not, say what you would change first. | Maps the checklist you wrote to the value. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Only if the numbers were bad news. If they were not, pick a different moment and say so. | Open prompt. Choose the moment yourself, and do not invent one. |

### C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never led a team. How do you coordinate four disciplines without authority?" | EXP, JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then describe how you have coordinated across teams you did not manage. Answer slot: if you have, say how; if not, say how you would earn the authority. | Stated negative, so the plain acknowledgment is allowed. The most likely objection. |
| C2 | "You have worked on puzzle games. Have you run anything with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message); [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the live cadence you did run: the weekly content drops. | Stated negative. Keep it to what you did. |
| C3 | "What would you need to learn in your first 90 days?" | JD | [generic] | Name specific things: how the two titles' KPIs are read, how the live calendar is built. Claim no prior knowledge of them. | JD question on the role's first months. |

### D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: say how each number was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not compute them, say which part you presented. | F7 is the likeliest prober target. Defend-the-number slot. |
| D2 | "Which calendar decisions were yours, and which were set above you?" | EXP | [grounded] "ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: name the decisions you made and the ones set for you. Say plainly if none were yours. | Tests attribution on the calendar. |
| D3 | "What does a retention number tell you that a daily-active chart can't?" | JD | [generic] | Reason about cohorts, the time a player stays, and what a single-day number hides. | JD line on retention metrics, asked as a judgment rather than a fact. |
| D4 | "You wrote the release checklist. What does QA do that the checklist does not cover?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what the checklist covers. Answer slot: name what it does not cover, if you know. If you do not, say so. | Probes the checklist you wrote, the most likely QA follow-up. |

### P: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has run two titles?" | JD, EXP | [grounded] "ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Hold the position: you ran one title's calendar for two years, and say what that taught you. Hold through two follow-ups, then concede specifically: you have not run two titles. | Time-boxed challenge on the two-title scope. |
| P2 | "That checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: you wrote it. Answer slot: if others edited it, name who and what they changed. | Tests attribution on the checklist. Hold the claim you can back. |

### Coverage against the JD

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, P1, D2 |
| Coordinate design, art, engineering and community teams on each update | A5, C1 |
| Own the post-event review and the KPIs it reports | A2, A6 |
| Manage the release checklist with QA | A3, D4, P2 |
| 3+ years producing live-service games or apps | C2 |
| Experience running a content calendar | D2, B1 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | none, and why: no writing sample in your material. The upgrade menu asks for one. |

## 12. Reverse questions

1. **"With Larkspur putting both titles on one calendar from February, what would success look like for this role in the first quarter?"** Why it lands: shows you read the news, and invites them to name the measure.
2. **"Your GDC talk argues patch notes should describe what shipped. What happens in the Outage Hour when they don't?"** Why it lands: a peer conversation about their own published argument.
3. **"What made the move from QA into live operations work for you?"** Why it lands: asks about their path, which is the shared jump.
4. **"Which of the two titles has the harder live calendar right now, and why?"** Why it lands: asks for specifics, which signals you are already thinking about the work.
5. **"How does the post-event review feed the KPIs, and who signs off the numbers?"** Why it lands: targets the JD's exact owned piece.

## 13. Sources

- **Provided:** your message (the JD, your background).
- **Fetched:** saltmarshgames.com/values. Full text. Used for the values cheat sheet.
- **Fetched:** saltmarshgames.com/careers/interviewing. Full text. Used for the Outage Hour format.
- **Search snippet only:** saltmarshgames.com/news/project-larkspur (September 2026). Used for the grounding brief and A4.
- **Search snippet only:** talks.gdconf.example/2026/patch-notes-are-a-promise, GDC 2026. Used for the interviewer read. Not opened.

**Queries:**
- "Saltmarsh Games values": returned saltmarshgames.com/values.
- "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing.
- "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur.
- "Tobias Wrenfield Saltmarsh Games": returned the GDC 2026 talk.

**Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet, section 10: three values by name. |
| 2. saltmarsh interview process, live operations producer | yes | Outage Hour is the loop: one 60-minute hiring-manager round with a tabletop and a values conversation. Persona weights follow it. |
| 3. saltmarsh strategy / recent news | yes | Larkspur (September 2026): the grounding brief and A4. |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read: QA background, the GDC 2026 talk (snippet only). |
| 5. representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## 14. Upgrade menu

- **A written sample of your work** (a checklist or a report you wrote and can describe) → F8 moves from discovery, and B3, D4 and P2 gain a quotable artifact.
- **A post-event review or KPI report you wrote or ran** → F4 moves from discovery, and A6 gets a real answer in place of its slot.
- **Whether the two titles in the JD are Tidepool Tactics and Lantern Row** → A4 names them instead of "two titles."
- **Deeper research (L2):** one more pass of up to 6 searches and 2 fetches, several more minutes, covering Saltmarsh's strategy brief, the interviewer's talks, and recent org changes. Want it?
- **The GDC talk's full text** → the interviewer read uses its argument, not just its title.
