Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also offers a "cheque for €1,850" that you "deposit" and then "send the balance on to the vendor." Paying a fee for equipment, depositing a cheque and sending it on, and sending ID and bank details before any offer are all very likely a scam. Hold all of it until you have checked the invite with the company through contact details you find on its own website or careers page, not through the email or anything it links to. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as brennock_remote_administrative_assistant_interview_pack.md. It's built on your background and the ad as you summarised it. I did not run any research on the company, so the values and interview structure are not established.

The sections that matter most:
- **The Skeptic is the likeliest interviewer style.** Booking travel and processing invoices are the two places your experience doesn't reach. Questions B1 and B2 are the ones to rehearse hardest. Say what you actually did, and what you would learn first.
- **Your strongest material is the appointment book for four physios.** That is the calendar answer, and it's yours. Don't stretch it to executives.
- **Excel is "okay" in your own words.** Name a real task if you have one; don't call it advanced.

Two questions:
- Can you paste the full ad text? The requirement rows then quote the posting itself, not my summary.
- Can you work remotely from home, with a stable connection and the equipment the role needs? This is the one gate I can't tell from your material.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. I can run the Skeptic on B2 as a practice round, if you'd like to rehearse that answer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_administrative_assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Relationship: a manager-level screen on practical admin work.
Built from: your message, the ad as you summarised it, and no research (see Sources).

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: CASE (live problem), EXP (your past work), JD (the listed job), CO (company), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words.
- Answer slots are instructions for the interview, not questions to answer here. Each one gives two honest branches: "if you did this, say how; if not, say so plainly."

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as you summarised it) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says one appointment book for four physios. Bridge: "I ran the appointment book for four physios." The limit is the pack's observation: your material does not show multi-person executive diaries. |
| F2 | "booking travel" (the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for someone, say what you booked and how; if not, say so plainly and say how you would learn the company's booking tools first. |
| F3 | "preparing documents in Word" (the ad) | "good with Word" (your message) | medium | [grounded] | presentation | Bridge: "I'm good with Word." No document types are named in your material, so none are claimed here. |
| F4 | "preparing documents in Excel" (the ad) | "okay with Excel" (your message) | low | [inferred] | discovery | Your material says "okay with Excel" and names no task. Answer slot: if you have used Excel for a task, name it in your own words; if not, say "okay" and what you would practise first. |
| F5 | "processing supplier invoices" (the ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Bridge: "I chased unpaid invoices." Chasing is the payment end of the process; the ad's job is processing. Answer slot: if you entered, matched or approved invoices, say how; if not, say you chased payment and what you would learn first. |
| F6 | Remote working (the invite: "Remote Administrative Assistant") | none given | none | [grounded] | hard_gate | Your material does not establish remote working. This row asks nothing here; the one question on it is in the message. |

Confidence is a band on your evidence. Gap type is a separate call on what the row needs.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Processed supplier invoices" | Inflated form of F5: "chased unpaid invoices" widened to processing | The quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. |
| "Managed calendars for executives" | Inflated form of F1: four physios widened to executives | The quote at its own scope: "I ran the appointment book for four physios." |
| "Advanced Excel" | Inflated form of F4: "okay with Excel" widened to advanced | "okay with Excel," as your sentence says it. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | "Your background is a clinic reception; what would you do differently here?" Probes the gaps: travel, invoices, remote work | High. An office manager screening an admin hire will test the three gaps F2, F5 and F6 first. | Rehearse the travel and invoice answer slots until they are plain. Say what you did, and what you would learn first. | 4 questions |
| Case / Strategist | Practical admin scenarios: a clash of meetings, a travel change, an invoice with no purchase order | High. The round is a practical check on the job's daily work. | Clarify first, then order the steps: check conflicts, confirm with attendees, hold options, then book. | 4 questions |
| Conversational | A "walk me through your background" opener and a casual question about what you liked | Medium. A 30-minute call with an office manager often starts this way, and casual questions are still scored. | Keep a 90-second arc ready, built only from your own sentences. | 2 questions |
| Data-Driven Prober | "How would you rate yourself in Excel, and what do you use it for?" | Low to medium. The ad names Excel, so a quick check is likely. | Say "okay" as you said it, then name a real task. | 2 questions |

Depth follows weight: the top personas get 4 questions, the rest 2. Session total is 12. That is below the usual 18 because the material is thin; the upgrade menu says what would add more.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you booked travel for someone else." | EXP | [grounded] "ran the appointment book for four physios" | Answer slot: if you booked travel for someone, say what and how. If you did not, say so plainly, then describe how you handled the appointment book, and say how you would learn the company's booking tools. Do not claim travel booking. | F2 is the row this probe tests. The ad names travel, and the question is open. |
| B2 | "The role processes supplier invoices. What have you done with invoices?" | JD | [grounded] "chased unpaid invoices" | Say what you did with the unpaid invoices in your own words. Answer slot: if you entered, matched or approved invoices, say how; if not, say you chased payment and what you would learn first. | F5 is the closest thing to the requirement. The highest-ROI rehearsal in this pack, because the gap is the one a probe finds fastest. |
| B3 | "Your background is a clinic reception. What would you do in your first month here that a receptionist wouldn't?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Name the two years and what you took from them, in your words. Give a first-month plan: learn the booking tools, the invoice process, and the approvers. | This is the Skeptic's standard objection to a change of setting. A plan answers it without claiming experience. |
| B4 | "This role is remote. What is your experience of working without someone next to you?" | JD | [grounded] "Remote Administrative Assistant" (the invite) | Answer slot: if you have worked remotely, say how; if not, say so plainly and say how you would set up for it. | F6 is the gate. Remote working is not in your material, so do not claim it. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A director asks you to move a client meeting and book the same person on a train tomorrow. Walk me through it." | CASE | [generic] | Clarify what is fixed, check the calendar for clashes, confirm with the attendees, hold options, then book and send the confirmations. | A live admin problem from the ad's calendar and travel duties. It needs no claim about your past. |
| C2 | "You need a board pack in Word with figures from an Excel sheet. How do you approach it?" | CASE | [generic] | Confirm the deadline and the format, check the figures' source, build the document, then check totals before sending. | The ad's document work, asked as a process. |
| C3 | "A supplier invoice arrives with no purchase order. What do you do?" | CASE | [generic] | Check the supplier and the approver, find out whether a PO should exist, hold the invoice, and say who decides. | The ad's invoice duty as a decision. It asks nothing about your past. |
| C4 | "Two people need the same boardroom at 2pm and your manager is away. How do you decide?" | CASE | [generic] | Clarify priority and any rule, check who can decide, offer a fallback room, and tell both people in writing. | A scheduling conflict in the ad's calendar duty. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | A 90-second arc: the clinic, the appointment book for four physios, and the invoices you chased. Use those words and add nothing. | The biography opener. Casual, and still scored. |
| A2 | "What part of that reception job did you enjoy most?" | EXP | [grounded] "I ran the appointment book for four physios" | Say it in your own words, then tie it to one admin task in the ad. | A rapport question with a scored answer. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you rate yourself in Excel, and what do you use it for?" | JD | [grounded] "okay with Excel" | Say "okay" as your sentence says it. Answer slot: if you have used Excel for a task, name it; if not, say what you would practise first. | F4 is low-confidence, so the answer must not be inflated. |
| D2 | "Show me how you would set up a simple invoice tracker." | CASE | [generic] | Name the columns you would track (supplier, invoice number, date, amount, status) and the checks you would make. | A practical test of the ad's Excel and invoice duties. |

## Requirement coverage

| Requirement | Questions | Gap |
|---|---|---|
| Managing calendars | A1, A2, C1, C4 | none |
| Booking travel | B1, C1 | F2, a discovery gap |
| Preparing documents in Word | C2 | none |
| Preparing documents in Excel | D1, D2, C2 | F4, a discovery gap |
| Processing supplier invoices | B2, C3, D2 | F5, a transferability gap |
| Remote working | B4 | F6, a hard gate |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of calendar and travel booking look like in this role?" | Shows you are planning the work, not just the title. |
| R2 | "How is the supplier invoice process run today: who approves, and who pays?" | Tests how much of the invoice work the role carries. |
| R3 | "How is remote working set up for this role, and which systems would I use day to day?" | Puts the remote question to the role, not to your equipment. |
| R4 | "What would success look like at the end of the first 90 days?" | Turns the interview toward your plan. |
| R5 | "What happens after this call, and how many steps are left?" | Asks about the process itself, which is a fair question. |

## Sources

Research tier: L0. No search was sent for this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities values` | unavailable | No search sent this turn. Values would have come from the company's own site, after the invite is checked. |
| 2. `Brennock Facilities interview process administrative assistant` | unavailable | No search sent. Loop structure is unknown; the round is taken from the invite alone. |
| 3. `Brennock Facilities strategy` / recent news | unavailable | No search sent. No CO questions were written. |
| 4. `{interviewer name} Brennock Facilities` | n/a | No name was given. |
| 5. representative Remote Administrative Assistant JD | unavailable | No search sent. The fit snapshot uses the ad as you summarised it. |

Your message and the ad as you summarised it are the only sources.

## Upgrade menu

- The full ad text: the requirement column quotes the posting's own words, not your summary.
- Your answer to the remote question (the gate in F6): decides whether that row changes.
- Any travel or invoice-processing work, even small: upgrades F2 and F5 from answer slots to stories.
- The office manager's name and public role: a tailored reverse question and interviewer read.
- Deeper company research (up to 6 more searches and 2 more fetches, several minutes): available on your go-ahead.
