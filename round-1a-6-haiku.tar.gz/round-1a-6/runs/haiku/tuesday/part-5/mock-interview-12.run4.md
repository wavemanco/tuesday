Please don't pay anything, send a passport photo or bank details, or deposit that cheque yet. The invite asks for "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", for "a photo of your passport and your bank details before the interview", and for you to "deposit the cheque and send the balance on to the vendor". Requests like these, a fee for equipment, a cheque to deposit and identity or bank details before any offer, are a known scam pattern, and this job offer is very likely a scam. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. Hold all of those until you've checked the invite with the company through contact details you find on its own website or careers page, not through this email. If you want the whole invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-5-rooms-case-12-denied-35eab528/e6c2bccb-526a-4737-a6b3-95eed64eae50/scratchpad/brennock_remote-administrative-assistant_interview_pack.md. It has 16 questions across four interviewer styles, with answer guidance for each, built only on what you told me about the clinic work. The most important prep is A2: the likeliest objection is that you haven't processed supplier invoices or booked travel, so practise saying that plainly and then your plan to learn it.

I can run a practice round where I play the skeptic on A2 and push back on your answer. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the 30-minute call with the person you'd report to day to day, or with someone from elsewhere in the company? The answer changes how the questions are weighted.

Can you meet the hours and location the role needs? I've assumed yes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Round: 30-minute video call. Relationship to you not stated, so the round is read as a hiring-manager round. Session mode, first pack for this role.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it is scoring: JD (the ad's own requirements), EXP (your past work), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.
- Answer slots ask you for your real answer in the interview. They are not questions to me.

Type key: **JD** = role requirement. **EXP** = your experience. **CASE** = live problem. **CO** = company knowledge. **VAL** = values.

## Fit snapshot

Requirements are the four duties you summarised from the ad. The full ad text was not supplied, so these are your words, not the ad's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as you summarised it) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says the appointment book, for four physios. Bridge: "For two years I ran the appointment book for four physios." Nothing about calendars beyond that. |
| F2 | "booking travel" (the ad, as you summarised it) | none given | none | [grounded] | discovery | Your material does not show travel booking, and you have not said you lack it. Answer slot: if you have booked travel for someone, say what and for whom. If you have not, say so plainly, and say how you would learn the booking tools the role uses. |
| F3 | "preparing documents in Word" (the ad, as you summarised it) | "good with Word" — your message | medium | [grounded] | none | The quote already reaches this. Say it as you wrote it: "I'm good with Word." Limited inspectable proof, so expect a probe. |
| F4 | "preparing documents in Excel" (the ad, as you summarised it) | "okay with Excel" — your message | low | [inferred] | discovery | Your material touches Excel without showing what you did in it. Do not describe Excel work you did not do. Answer slot: if you built, checked or summarised anything in a sheet, say what it did. If you did not, say so plainly, and say what you would learn first. |
| F5 | "processing supplier invoices" (the ad, as you summarised it) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices, not the same work. Words: "For two years I chased unpaid invoices." Do not say you processed, matched or paid invoices. Answer slot: if you handled any part of a supplier invoice from receipt to payment, say which part. If not, say so plainly, and say what you would learn first. |

Gap types: F2 and F4 are `discovery`, because your material is silent, not because you said you lack the skill. F5 is `transferability`, and its limit stays in the bridge.

## Persona weights

| Persona | Weight | How it shows up | Why (relationship and loop) | Counter-strategy |
|---|---|---|---|---|
| Skeptic | top (4 questions) | Probes the gaps: travel, invoices, Excel. "Why this role after a clinic front desk?" | A hiring-manager round for an admin role. The likeliest objection is that you have not run supplier invoices or bookings. | Say the limit first, in your own words, then your plan to learn it. Do not stretch "chased" into "processed". |
| Case / Strategist | mid (3 questions) | A live admin problem: a clash in a calendar, a mismatched invoice, a template to build | Hiring managers test how you would handle the actual job. | Clarify first, then state your steps out loud. |
| Conversational | mid (3 questions) | Opens with "walk me through how you got into this", and casual questions about the tools | A 30-minute call often starts friendly, and the casual questions are still scored. | Keep a 90-second arc ready. Answer casual Excel questions from what you actually use. |
| Data-Driven Prober | low (2 questions) | Asks how a sheet was built or checked. | Excel is your thinnest area, so a prober will go there. | Name what you actually did in Excel. If it was little, say so. |

## Prohibited claims

Claims this pack will not coach, because they go beyond what you said.

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices," at its own scope. Your material shows chasing, not processing. |
| Expert in Excel | Inflated form of F4 | "okay with Excel," at its own scope. Excel is where your material is thinnest. |
| Managed the whole office's calendars | Inflated form of F1 | "ran the appointment book for four physios." |

## Question banks

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" — your message | Name Excel as the area you described as "okay", then how you would get it to the level the role needs. Keep it to the plan. | F4 is the thinnest row and the likeliest weak spot. |
| A2 | "I don't see supplier invoices or travel bookings in your background. How would you handle those?" | JD | [grounded] "chased unpaid invoices" — your message | Limit first: the material shows "chased unpaid invoices". Answer slot: if you handled any part of a supplier invoice, say which part. If not, say so plainly, and say what you would learn first. For travel, if you booked it for someone, say what; if not, say so plainly. | F5 and F2 are the objections most likely to come up, so this is the highest-value rehearsal. |
| A3 | "Why this role, after two years at a clinic front desk?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Give the reason you actually have, in your own words. The quote carries only the job, so do not add a motive. | Motivation is a Skeptic's first probe for a career move. |
| A4 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" — your message | Tell the beats the sentence states: the book, the four physios, two years. Answer slot: if any scheduling rule was yours to set, say which and how you decided. If not, say so plainly and describe how the book ran. | F1 is your strongest calendar evidence and a likely place to be probed. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director needs to travel to a conference next month, and her calendar has three clashing meetings. What do you do?" | CASE | [generic] | Clarify her priorities first. Then check the travel options, confirm with her, and state what you would move and who you would tell. | A live problem from the calendar and travel duties (F1, F2). Presupposes nothing about your past. |
| B2 | "A supplier invoice doesn't match its purchase order. Walk me through what you do." | CASE | [generic] | Check the order, the delivery record and the invoice line by line. Query the supplier in writing, and log the outcome. | A live problem from the invoice duty (F5). Presupposes nothing about your past. |
| B3 | "How would you set up a Word template for the weekly meeting pack?" | JD | [generic] | Say what fields stay fixed and what changes each week, then how you would keep the template current. | Covers the Word duty (F3) with a live problem. |

### C. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through how you got into office work." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | A 90-second arc from the quote: the front desk, the appointment book, the invoices you chased. Stop there. | Casual openers are scored. The arc carries only what you have said. |
| C2 | "Which Excel features do you use most?" | JD | [grounded] "okay with Excel" — your message | Name the features you actually used. Answer slot: if you used few, say so plainly and name the one you would learn first. | F4 raised casually. A made-up list will fail on the next question. |
| C3 | "What does a normal week look like for you at the moment?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Describe your real week in the quote's terms. Do not add meetings or systems you did not use. | A rapport question that tests whether your story is consistent. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Show me how you'd check that a total in a sheet matches its line items." | JD | [generic] | Say the check you would make: recalculate the sum and compare. Say plainly if you have not built this before. | Tests the Excel duty (F4) with a live check, not a claim. |
| D2 | "How many invoices did you chase in a typical month?" | EXP | [grounded] "chased unpaid invoices" — your message | If you know the figure, give it. If not, say you do not know and what you would count. Do not estimate. | A number-probe on F5. The honest answer is the count you actually know. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| managing calendars | A4, B1, C3 |
| booking travel | A2, B1 |
| preparing documents in Word and Excel | B3, C2, D1 |
| processing supplier invoices | A2, B2, D2 |

Total: 16 questions across four personas.

## Reverse questions

Each has a reason it lands.

1. "What does a typical week in this role look like, and which part is most time-sensitive?" *Why it lands:* it shows you are planning the work, not just the title.
2. "Who checks the travel and invoice work before it goes out?" *Why it lands:* it asks about approvals, which is where an admin role carries risk.
3. "Is this 30-minute call the only stage before an offer, and what comes after it?" *Why it lands:* it tells you what to prepare for next.
4. "Which tools does the team use for calendars and shared documents?" *Why it lands:* it shows you will learn their systems, and tests your Excel gap.
5. "What would a good first month look like for whoever takes this role?" *Why it lands:* it turns the interview into a planning talk.

## Sources

Provided documents: your message (your background; the ad as you summarised it; the invite text).

Research tier: L0 — no searches were run; the pack uses provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Values cheat sheet; not triggered, since no values round was detected |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | Loop structure; persona weights follow the named round |
| 3. `Brennock Facilities Ltd strategy` / recent news | skipped | Could not move an admin-role pack that has one 30-minute call |
| 4. `office manager Brennock Facilities Ltd` | n/a | No name was given, so there is no query to form |
| 5. representative Remote Administrative Assistant JD | skipped | The duties you summarised fix the fit snapshot |

## Upgrade menu

- The full ad text → the five requirement rows become verbatim `[grounded]`, not your summary
- The office manager's name → an interviewer read and persona weights from their public footprint
- An L1 research run → the loop structure and a values read, if the employer's own careers page is supplied
- A `tuesday-dossier.md` → the gaps this prep exposed, carried into later sessions
