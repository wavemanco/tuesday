# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Format: 45-minute panel on Thursday with Principal Dolores Vantongeren and two fourth-grade team members (the two team members are not named in the invite). Built from the invite and your resume only; no outside research has run yet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and rehearse it until it sounds like you.

Question types:

- **VAL**: behavior that shows a published value.
- **EXP**: a deep dive into your own experience and what you actually did.
- **JD**: whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge (not covered here; no research has run).
- **CASE**: a live problem, reasoned through aloud.

Prep triage is omitted because no prep time was given.

## Fit snapshot

Requirements are quoted from the invite or your resume. Role-family requirements with no source are marked `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material states the license and its expiry, and the endorsement covers grades 1–6, which includes fourth grade. Confirm the record on the Illinois State Board of Education's license lookup before Thursday. Expect at most a confirmation question. |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Your words: "I've taught third grade for six years." Limit in your words: "I've never taught fourth grade." Answer slot: which third-grade practices you would carry into fourth grade, and what you would learn first. |
| F3 | Reading instruction — `[generic]` role-family requirement, no quote | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Your reading work is in the material in role-relevant terms. Describe what you did, in those words. |
| F4 | Working with the fourth-grade team, per the panel's makeup — invite | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [grounded] | transferability | The material shows you leading a move, not leading a team. Your words: "I led our grade level's move to a new reading curriculum in 2024." Limit in your words: "I've never been a team lead." Answer slot: how the move was decided and what part was yours. |
| F5 | Family communication — `[generic]` role-family requirement, no quote | "I write a weekly email to families" — your CV | medium | [grounded] | none | Your words: "I write a weekly email to families." Describe its content and how often it goes out. |

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot. Each one is a stretched form of something you did say, or a claim the material does not support.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience, or fourth-grade content knowledge as past practice | Inflated form of F2 | "I've taught third grade for six years," at its own scope. "I've never taught fourth grade" is the limit. |
| Team lead, or having led the grade-level team | Inflated form of F4 | "I led our grade level's move to a new reading curriculum in 2024," at its own scope. "I've never been a team lead" is the limit. |
| Reading results, scores or growth from the curriculum move or the club | Inflated form of F3; the material gives no figures or outcomes | "I've run the after-school reading club for the last two years," at its own scope. The material shows no results, so any result is an answer slot, and you give only what you can defend. |

## Reading the panel

No interviewer profiles were provided, so there is no interviewer read. Persona weights follow the panel's makeup: one principal and two team members.

## Persona table

| Persona | Panel member | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet, persistent probing of the gaps: no fourth-grade experience, no team lead | Top weight. A principal hiring for a grade-level role is buying capability and derisking the two stated gaps | Rehearse the fourth-grade objection until it is calm. Hold what you did; concede the gaps plainly |
| Peer Evaluator | Two team members | Seam-splitting between classes, disagreement, credit | Top weight, because the team members will be working beside you and price what the hire adds to their load | Lead with what you bring to their team; describe disagreement with spine and tact |
| Case / Strategist | Principal | Live problems: a struggling student, a flat test year | Mid weight. Principals often run live problems to see how you reason | Clarify, then structure, then answer. Think aloud |
| Data-Driven Prober | Team member | Asks how the reading club and the curriculum move were measured | Mid weight. Claims about results invite a probe into the numbers | Name what you tracked, if anything. If you tracked nothing, say so |

Depth follows weight: the two top personas get five and four questions, and the two mid personas get four each.

## Question banks

**Types used:** EXP, JD, CASE, CO. Questions are the interviewer's lines. Answer slots are instructions for the interview, not questions for this conversation.

### A. Skeptic (top weight; principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What would you need to learn before you taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" — your message | Name the fourth-grade content you would learn first and how. Say what third grade gives you to start from, in those words. Do not claim fourth-grade experience. | F2 is the requirement gap, and the title is what is scored. This is its first probe. |
| A2 | "Why should we hire you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" — your message | **Highest-ROI prep in this pack.** Hold: "I've taught third grade for six years, and that's where I'd start from." Concede: "I haven't taught fourth grade. I'd close that in the first month by" and one concrete step, such as planning units with the team. Hold through two follow-ups by returning to your third-grade years. Never add a fourth-grade claim. | The likeliest objection, aimed at F2 where the material is thinnest. Deepest rehearsal, because it will come in some form. |
| A3 | "You've never been a team lead. Why would we trust you to lead a grade-level change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" — your message | Hold the 2024 move in your own words. Concede the title: "I haven't been a team lead. I did lead that move." Name what you decided yourself. Answer slot: if the decision was not yours, say so plainly and describe what you did. | F4's gap is a stated negative. The question presses on the scope of the leadership claim. |
| A4 | "How much of that curriculum move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Pressure: pause, restate the move, then name your specific part in your own words. Hold through two follow-ups. Concede exactly what others decided. Answer slot: if you chose the materials or set the timeline, say which. If not, say whose decision it was. | Tests attribution on a led claim, the Skeptic's central check. |
| A5 | "What would you do in your first month on a team that has been teaching fourth grade for years?" | CASE | [generic] | Structure it: listen first to the team's current units and assessments; propose one change only after you have seen how the team works; say how you would raise a concern with the team. Make no claim about your past. | A live scenario for the team-fit gap. `[generic]`, because it is a pattern for the situation, not a fact about this school. |

### B. Peer Evaluator (top weight; two team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two classes teach the same reading unit at the same time. What happens when our pacing doesn't match?" | CASE | [generic] | Name a principle: agree the unit's sequence with the team, and say what you would decide together and what you would decide alone. Claim no past arrangement. | A seam question. Team members weigh how you would collaborate. |
| B2 | "Tell me about a disagreement you had with a colleague about the reading block." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Open prompt: choose a real instance from the move. If none comes to mind, say so plainly, then describe how you would handle one. Describe the other person's concern in their terms. | Peer disagreement is the stem. The CV gives the setting but no disagreement, so the slot stays open. |
| B3 | "How do you share credit when a grade-level change works?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Name the team by name. Use "we" for the context and "I" only for your part. | Credit-sharing is a peer stem. The move is the one story the CV carries. |
| B4 | "What would you bring to our team that we don't already have?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" — your CV | Describe the reading club and the weekly family email, in those words, and what you did in each. Let them draw the inference. Do not claim the club produced results. | Reciprocity and fit. Both quotes describe things you did. |

### C. Case / Strategist (mid weight; principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student reading two years below grade level joins your class in October. What is your first week?" | CASE | [generic] | Structure it: assess what the student can read, group, tell the family, and plan. Name the first step and why it comes first. | A live problem at the core of the job. No past claim. |
| C2 | "Our fourth-graders' reading scores were flat last year. Where do you start?" | CASE | [generic] | Clarify first: which strand, which group, what changed. Then one hypothesis and one check. | A live diagnostic that tests clarifying before structuring. |
| C3 | "If the team's reading curriculum were new to you, how would you learn it?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Use the 2024 move as the example, in your own words: what you learned first, and what took longest. Name no figure. Answer slot: if your learning path was different, describe it. | Gives the reading question its evidence from your CV. |
| C4 | "How would you tell a family that their child is behind?" | CASE | [grounded] "I write a weekly email to families" — your CV | Start from the weekly email: what it covers, how you would add a specific concern, and how you would invite a meeting. Speak to the family's side. | Connects family communication to a hard case. |

### D. Data-Driven Prober (mid weight; team member)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the reading club was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer slot: if you tracked anything (attendance, assessments, teacher notes), name what and how it was recorded. If you tracked nothing, say so plainly and say what you would track next. Do not name a result the material does not give. | The Prober's first check on a claim with no figure attached. |
| D2 | "How did you know the 2024 reading move worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you have a figure, say how it was counted and which part was yours. If you have none, say so plainly. Never give a figure you cannot defend. | The defend-the-number question. The material gives no outcome, so the slot leaves room for none. |
| D3 | "Which assumption behind that result would you defend least?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Asked only if you gave a figure in D2: name the weakest assumption you know of before they do. If you gave none, say what you would measure instead. | The metric follow-up, conditional on a figure you give. |
| D4 | "What would you measure in your first month with fourth-grade students?" | JD | [generic] | Name one or two measures, how you would count them, and when you would check. Make no outcome claims. | A JD-tagged measurement question. The CV does not cover it. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois Professional Educator License with elementary endorsement | None, and why: your material states it held and active. Confirm the expiry date before Thursday. |
| Fourth Grade Teacher position | A1, A2, D4 |
| Panel with principal and two team members | A (principal), B (team), C (principal), D (team) |

Session total: 17 questions across four personas. This is under the usual 18-question floor for a full loop, because the panel has three members and the pack covers each.

## Reverse questions

Each has a reason it lands.

1. "What would success look like for this role in the first semester?" Lands because it shows you are planning for the job, not just hoping for it.
2. "How does the fourth-grade team plan the reading block together?" Lands because it asks about the collaboration norms you will have to work within.
3. "What has changed about reading instruction on the fourth-grade team in the last two years?" Lands because it shows you know reading is the team's current work.
4. "What could a new teacher do in the first month that would genuinely help this team?" Lands as the peer reciprocity question. It turns the conversation toward what you would add.
5. "How does the team handle a student whose needs go beyond the classroom plan?" Lands because it asks about the support structures you will rely on.
6. "How does the school keep families informed across the grade level?" Lands because it links to your weekly family email and shows you think about communication as part of the job.

## Sources

- **Provided documents:** the invite text, your resume, and your message in this conversation.
- **Research tier:** L0, no searches. Research runs only with your go-ahead.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford published values | unavailable | Values cheat sheet, not built. Would move the values section. |
| 2. District interview process for this role | unavailable | Loop structure. Would move the persona weights. |
| 3. Recent district or school news | unavailable | Current context for the reverse questions. |
| 4. Dolores Vantongeren, principal, public footprint | unavailable | Interviewer read and the principal's persona weights. |
| 5. Representative fourth-grade teacher job posting | unavailable | JD-tagged requirements. The invite gives only the title, so the requirements are `[generic]` for now. |

Targets 1 to 5 were not searched because research is at L0 until you say go ahead. None of them has been checked.

## Upgrade menu

- The job description text → the requirements in the fit snapshot quote its exact words, and the `[generic]` rows become `[grounded]`.
- Your go-ahead for a public-web check → the district's published values, its interview process, and a representative job posting. This makes the values section and the persona weights possible.
- The two team members' names and roles, if the invite or the district site gives them → per-member persona assignment and a reverse question tied to their own path.
- A `tuesday-dossier.md` → would add verified evidence and the objections your prep has exposed, so the next session starts from them.
