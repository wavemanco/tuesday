# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Interviewer: support team lead (name not given). Round: chat interview with the team lead, after a recruiter contact. First version; no changes yet.

## How to use

Personas describe how a question arrives. Types describe what is being scored: **VAL** (values), **EXP** (your experience), **JD** (the role's requirements), **CO** (company knowledge), **CASE** (a live problem). Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are from the job ad as you summarised it, not verbatim, so they are unquoted. Quotes in the evidence column are from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap on years. The sector differs, and you have said so: say it yourself, in your words. |
| F2 | Zendesk or a similar ticketing tool (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a ticketing tool of the same kind. Describe what you do in it. Do not claim Zendesk. |
| F3 | Clear written communication (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your message shows email volume, not how clear the writing was. Answer slot: say what written replies you wrote and how you checked they were clear. If you cannot point to any, say so plainly and say how you would show it. |
| F4 | Confidence handling escalations (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Nothing you have shared says you escalated cases. Answer slot: if you handed cases up in your energy role, say which kinds and to whom. If you did not, say so plainly, and say how you would handle a case you could not resolve. |

Your material does not establish any software-company experience. The ad does not ask for it, so there is no row, but expect it as a probe.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2 | "I use Freshdesk every day", at its own scope. Your material does not show Zendesk. |
| Handled tickets or cases daily | Inflated form of F1 and F3 | "answering around 60 calls and emails a day", at its own scope. The figure is calls and emails, not tickets. |
| Escalation experience | Inflated form of F4 | No quote carries it. F4's answer slot is the only route. |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic (A) | Top, 5 questions | Hiring-manager round. They are checking the sector gap and the escalation gap. |
| Case / Strategist (B) | 5 questions | Live problems from the role's daily work. |
| Data-driven Prober (D) | 3 questions | Your numbers (60 a day, four starters) will be asked about. |
| Conversational (C) | 3 questions | Chat interviews open casually; casual questions are still scored. |
| Pressure (E) | 2 questions | Sector gap and volume claims under challenge. |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is in energy customer service. What would you need to learn first to support our customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" ; [grounded] "I've never worked for a software company." | Name one thing you would learn first, in your own words. Say plainly that you have not worked for a software company. Do not argue the sector. | F1 and the sector gap; the negative is your own statement. |
| A2 | "What have you done in a ticketing tool, and for how long?" | JD | [grounded] "I use Freshdesk every day" | Describe your daily Freshdesk work in your words. If asked about Zendesk: say you have not used it, and name Freshdesk as your daily tool. | F2 is the requirement most directly matched; the Zendesk question is likely. |
| A3 | "You answer calls and emails all day. How does that carry over to a ticket queue?" | JD | [grounded] "answering around 60 calls and emails a day" | Describe the volume and how you prioritised it, in your words. Name the difference between a call queue and a ticket queue, and how you would adapt. | F3 is thin; the probe asks you to bridge it. |
| A4 | "Why leave an energy supplier for a software company?" | EXP | [generic] | Answer slot: give your own reason for leaving, in your own words. Nothing in your material states it. | Stock motivation probe; the reason is yours to supply. |
| A5 | "Tell me about a time you escalated a case you could not close." | EXP | [generic] "I trained four new starters on our refunds process last year" | Selection scaffold: pick a case you handed up, or a decision you had to make. If none comes to mind, say so plainly, then give the nearest thing you did, such as the refunds process you taught. | F4 is the gap. This is the most likely place to be probed. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says their refund has not arrived after ten days and is angry. What do you do first?" | CASE | [generic] | Clarify what the customer has been told, check the refund status, state what you can promise, and say when you would escalate. | Daily work in the role; no claim about your past. |
| B2 | "A ticket has been open five days with no reply, and the team lead wants it closed today. What do you do?" | CASE | [generic] | Structure: check the history, respond to the customer, and decide whether closing is honest. Name what you would not do. | Tests judgment under a stated deadline. |
| B3 | "Write your first reply to a customer who says the product is broken and wants their money back." | CASE | [generic] | Structure: acknowledge, state what you will check, give one clear next step, and promise nothing you cannot keep. Keep it short. | This chat is also a writing test (F3). |
| B4 | "What would you need to be able to do by the end of your first month?" | JD | [generic] | Name the tools, the product and the process you would learn first. Keep it concrete. | The role's stated expectations. |
| B5 | "How would you decide a case needs a specialist team?" | CASE | [generic] | Name the signals: a question you cannot answer, a policy you do not own, a risk to the customer. Say how you would hand it over. | Escalation judgment (F4), asked as a decision. |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your last three years." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; [grounded] "answering around 60 calls and emails a day"; [grounded] "I trained four new starters on our refunds process last year" | A 90-second arc: role and years, the daily volume, the refunds process you taught. Each beat is a clause the quotes state. Nothing added. | F1 and F4's nearest evidence, delivered casually. |
| C2 | "What are you using in ticketing tools these days?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and one feature you use. Say you have not used Zendesk, if it arises. | F2, asked casually. |
| C3 | "How do you keep on top of a busy queue?" | JD | [generic] | Selection scaffold: describe how you prioritised your queue. If you did not prioritise, say so plainly and say what you did. | A casual opener on daily work. |

### D. Data-driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted, and what share was emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number. Name the weakest assumption: "around" is an estimate unless you counted. Answer slot: if you counted, say how. If it is an estimate, say so, and say what it is based on. | The figure is the one number on your message; probers test it first. |
| D2 | "How do you measure your own performance in Freshdesk?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: if you have a measure you were held to, say what it was. If you had none, say so plainly. | The question presumes a measure your material does not show. |
| D3 | "How did you know the refunds training worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked how the starters did, say how. If you did not, say so plainly and say how you would check. | The question presumes an outcome your material does not show. |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with software-support experience?" | JD | [grounded] "I've never worked for a software company." | Hold on what you did: volume, and the refunds process you taught. Concede plainly that you have no software background. Hold through two follow-ups before conceding anything more. | The sector gap under time pressure. |
| E2 | "That's a lot of contacts a day. How much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say which of the contacts you handled yourself, and whether anyone shared your queue. | Tests whether the volume is yours. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical first month look like for someone in this role?" | Shows you are planning to be useful, not just hired. |
| R2 | "How are escalations split between the support team and specialists?" | Shows you care about the escalation part of the role. |
| R3 | "Which ticketing tool does the team use day to day?" | Lets you show how Freshdesk skills transfer. |
| R4 | "How is the quality of written replies checked?" | Shows you take written communication seriously. |
| R5 | "What would make someone in this role successful at 90 days?" | Gives the team lead a chance to state the bar. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | A1, C1, E1 |
| Zendesk or similar ticketing tool | A2, C2, D2 |
| Clear written communication | B3, F3 answer slot, R4 |
| Confidence handling escalations | A5, B5, D3 |

## Sources

Provided documents: your message, and the job ad as you summarised it. No search or fetch was run for this pack.

Research tier: L0 (provided documents only).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Not run; offered at L1. |
| 2. Lumenvale interview process | unavailable | Round structure. Not run; offered at L1. |
| 3. Lumenvale strategy / recent news | skipped | Not needed for this role's questions. |
| 4. Team lead name and background | n/a | No name given. |
| 5. Representative Customer Support Specialist JD | skipped | Your summary fixes the requirements. |

## Upgrade menu

- The job ad's full text → verbatim quotes in the requirement column; F3 and F4 get firmer wording.
- Your CV → sentences the evidence column can quote beyond your message.
- Research at L1 (company values and interview process) → a values cheat sheet and round structure.
- The team lead's name → tailored reverse questions, once you have confirmed who the team lead is.
- `tuesday-dossier.md` → would carry the F3 and F4 gaps into later sessions.
