# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Format: 45-minute panel with Principal Dolores Vantongeren and two members of the fourth-grade team. Built from the HR invite and your resume only. No posting, no research, no interviewer profile yet.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the stated role), EXP (your experience), VAL (values), CASE (live problem), CO (company knowledge).
- Guidance is scaffolding for a spoken answer, not a script. Each answer should run 90 to 120 seconds.
- Provenance: `[grounded]` traces to your own words or the invite. `[inferred]` is my derivation. `[generic]` is a pattern for this kind of interview, with no claim about you or this district.
- Quoted sentences are yours. Do not add to them in the room.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | No gap on the record. Say it plainly: "I hold an active Illinois Professional Educator License with an elementary endorsement, through June 30, 2029." Confirm the status on the state lookup before the panel, since this is a self-reported claim. |
| F2 | "Fourth Grade Teacher" (invite, role title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Your material shows elementary teaching at third grade, not fourth. Words: "I taught third grade for six years. I haven't taught fourth grade." Answer slot: which parts of that work carry over to fourth grade, in your own words. |
| F3 | Works with a grade-level team (role-family pattern; the invite names a fourth-grade team on the panel) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [generic] | transferability | Your material shows you led one curriculum change. It does not show you led a team. Words: "I led our grade level's move to a new reading curriculum in 2024." Plain acknowledgment: "I haven't been a team lead." |

**Observation (analysis, not words for you):** the material does not show any fourth-grade teaching or any team-lead role. Those two absences are the interviewers' likeliest probes.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Taught or planned fourth-grade instruction | Negative you stated (F2) | "I haven't taught fourth grade." No slot that suggests otherwise. |
| Led a team, or the grade level | Negative you stated (F3) | "I haven't been a team lead." |
| Led the grade level as a whole | Inflated form of F3 | Quote the curriculum move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is my observation: your material says the curriculum move, not the grade level. |
| Designed the reading curriculum or the reading club | Inflated form, not in your material | Describe only what you did with the curriculum move and the club, in your words. |

## Persona weights (panel)

Panel rule: each member takes the top two personas of their relationship. No interviewer profiles were available, so there is no interviewer read.

| Interviewer | Relationship | Dominant personas | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Principal Dolores Vantongeren | Manager in the school line | Skeptic (top), Case/Strategist | Probes the fourth-grade gap and asks how you would plan | Hold with one plain acknowledgment, then a plan. Pause before answering. |
| Team member 1 (fourth grade) | Peer | Peer Evaluator (top), Data-Driven Prober | Seams between classrooms, reading-data questions | Lead with what you bring to their team. Name the weakest assumption before they do. |
| Team member 2 (fourth grade) | Peer | Peer Evaluator (top), Values/Behavioral | Collaboration and disagreement scenarios | Use real disagreement stories. Choose one only if you actually had one. |
| Panel overall | Blend | Pressure at low weight | A challenge to a held claim | Hold through two follow-ups, then concede precisely. |

Weights: Skeptic 4 questions, Peer Evaluator 4, Case/Strategist 3, Data-Driven Prober 3, Values/Behavioral 2, Pressure 2. Total 18.

**Highest-ROI prep: A1.** The fourth-grade gap is the most predictable objection, and the answer is in F2.

## Question banks

### A. Skeptic (principal, team)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've never taught fourth grade" | Start with the six years, in those words. Then the plain acknowledgment: "I haven't taught fourth grade." Then the plan: how you would learn the fourth-grade content before your first week. Answer slot: if you have worked alongside fourth-grade colleagues or materials, say how; if not, say so and give the plan. | F2 is the likeliest probe. Deepest rehearsal here: hold the six years, concede the grade, never claim the grade. |
| A2 | "I don't see team leadership in your background. How would you work with a grade team that expects a lead?" | JD | [grounded] "I've never been a team lead"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment: "I haven't been a team lead." Then the 2024 move, in your words: "I led our grade level's move to a new reading curriculum in 2024." Then how you would contribute to a team and what you would ask of the lead. Answer slot: if you led any part of a group effort, say what; if not, say so and give your plan. | F3. The premise is the stated absence, so it may be used as written. |
| A3 | "Why move up a grade, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Give your reason in your own words. The material does not state one. Answer slot: your reason for moving to fourth grade, in your words; if none has a specific reason, say what draws you to it. | Motivation consistency. Skeptic probes the move itself. |
| A4 | "What would you need from us in your first ninety days?" | JD | [generic] | Name two or three concrete needs: materials, schedule, a mentor or planning time. Ask rather than assume. | Ramp plan, a standard panel question. No claim about your past. |

### B. Peer Evaluator (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. How do you handle it when a colleague disagrees with your approach?" | EXP | [generic] | Open prompt. Choose a disagreement you actually had. Say what each side wanted, what you did, and where it landed. Answer slot: if you have such an instance, use it; if not, say how you would approach it. | Disagreement style with equals. A persona stem; no claim about your past. |
| B2 | "Tell me about bringing colleagues along on a change you led." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story map from the quote: the move, in 2024, in your words. Answer slot: if you did something specific to bring colleagues along, say what, in your words. If the move went forward without that step, or the step was not yours, say so and stay with the move itself. | F3 is the bridge: the team-lead gap is answered by the curriculum move, not by the word lead. |
| B3 | "What would you bring to our weekly planning?" | EXP | [grounded] "I write a weekly email to families" | Name the weekly email as a habit of communication, in your own words. Do not claim it is a planning tool. | Reciprocity framing. What you bring their team, not only what you need. |
| B4 | "Our two classes feed each other in reading. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not specifics: who sets the reading sequence, when to meet, how to escalate. Do not pretend to know their current sequence. | Peer seam question; the stated disagreement is a standard peer probe. |

### C. Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your first month with a new fourth-grade class." | CASE | [generic] | Clarify first: what the curriculum is, what the assessments show, what the students need. Then the objective, the approach, how you would measure progress, and the risks. | A live problem from the role. Asks about no past event. |
| C2 | "A student is reading below grade level in October. What do you do next?" | CASE | [generic] | Clarify what data exists, then diagnose, then plan with a family contact and a follow-up date. Name one premise you would check. | Structure and reasoning; a standard principal probe. |
| C3 | "What from your after-school reading club would carry into a fourth-grade classroom?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story map from the quote: you ran the club for two years. Answer slot: if any part of the club's approach was yours to set, say what and how; if not, say so and describe what you did run. | Connects the club to the role. It presupposes only the club the quote states. |

### D. Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you judge whether a curriculum change is working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name the measure you would use first, and why. Answer slot: if you tracked any measure during the 2024 move, name it and what it showed; if you did not, say so and say what you would track. | Prober stem; ties the curriculum move to measurement. Presupposes no result. |
| D2 | "What evidence from the reading club would you point to?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what you observed in your own words. Answer slot: if you recorded anything about the students, say what; if you did not, say so. | Attribution honesty: what was actually recorded. |
| D3 | "Which assumption behind any progress data you'd show us would you defend least?" | EXP | [generic] | Name the assumption before they do. Keep it to something you actually know about the data. | Prober stem. Presupposes no figure of yours. |

### E. Values/Behavioral (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to deliver difficult news to a family." | VAL | [grounded] "I write a weekly email to families" | Open prompt. Choose a real instance. Answer slot: if a family message ever carried hard news, say what and how it landed; if not, say the nearest thing you did. | Scored behavioral conversation. Theme from the persona stem, not a claim. |
| E2 | "When did you put a student's need ahead of the plan?" | VAL | [generic] | Pick a time that had a real cost. Say what you gave up. If no such time comes to mind, say so, then give the nearest thing you did. | Values-style scenario. Honest branch built in. |

### F. Pressure (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a fourth-grade teacher who already teaches it?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Hold: "I have an active elementary license and six years in the classroom." Concede: "I haven't taught fourth grade, and I'd say so in the first week." Do not argue the comparison. | Pressure: hold the position through two follow-ups, then concede precisely. |
| F2 | "That reading curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." Concede what you did not do or decide, in your own words. | Attribution probe. The hold is only what the quote carries. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | — none, and why | Met on your resume (F1). The panel will verify it, not ask about it. |
| Fourth Grade Teacher | A1, A3, F1 | F2 |
| Team lead or team collaboration (not stated in the invite) | A2, B1, B2, B4 | F3 |

## Reverse questions

1. "What does a new fourth-grade teacher's first month look like here?" Why it lands: shows you are planning the ramp.
2. "How does the fourth-grade team plan together week to week?" Why it lands: a peer question, asked of the peers.
3. "What reading curriculum does fourth grade use, and how long has it been in place?" Why it lands: connects to your curriculum move.
4. "What would make a new team member successful in the first semester?" Why it lands: asks for the standard the panel will score.
5. "What could a new person do in the first month that would genuinely help your team?" Why it lands: reciprocity, for the peers.
6. "Is there a demo lesson or written component before a decision?" Why it lands: process check, asked as a planning question.

## Sources

Research tier: L0. Provided documents only (the HR invite and your resume). No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford values | unavailable | Values cheat sheet, section not built: no published values in hand |
| 2. Interview process for fourth-grade teacher | unavailable | Loop structure and persona weights; the panel format comes from the invite |
| 3. Strategy or recent news | unavailable | Current priorities for CO questions; no CO questions in this pack |
| 4. Dolores Vantongeren, Halvering | unavailable | Interviewer read; this name is known, no search was run |
| 5. Representative fourth-grade teacher JD | unavailable | Would turn the [generic] rows into [inferred] or [grounded] ones |

## Upgrade menu

- The posting or district job description → the [generic] requirement rows become [grounded], and A4 and B4 gain specifics.
- Your consent to research Halvering and Orrinsford → values cheat sheet, current strategy questions, and the process of the loop.
- The principal's and team members' public profiles, if you have names and roles → a tailored interviewer read and persona weights.
- Any demo lesson or prepared material → a build section for it.
