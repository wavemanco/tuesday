# Operations Coordinator at Quillmoor Diagnostics: recruiter screen prep pack

Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30-minute phone call. She will ring the mobile number on your application. Her agenda, in her words: "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move".

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **EXP** is your own work and its attribution, **JD** is the advert's own requirements. A recruiter screen does not score the other types, so none appear here.

Guidance is scaffolding, not a script. Say things in your own words. Every sentence in quotation marks below is one you wrote or one the advert or recruiter wrote, and nothing else is attributed to you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material says delivery schedules across three depots, not production schedules across planning, the warehouse and QA. Keep the words there: "I schedule deliveries for our three depots." Answer slot: if you have set or shared schedules with planning, the warehouse or QA, say how and what you decided. If you have not, say so plainly and say how you would learn the production side first. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | Your sentence already reaches this requirement. Say it in those terms. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | Your sentence reaches the requirement. The figure stays at its own scope, "about a third over a year" (see B3). |
| F4 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The sentence shows a spreadsheet you rebuilt. It does not show your Excel skill level, so the level is not established. Answer slot: name the Excel functions you used on the stock count, and if none beyond basics, say so. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | Your sentence reaches the requirement. Length of experience is not a gate. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Words: "I haven't used SAP." Then, if asked about your system: "We run our own in-house stock system." Then how you would learn an ERP, said as a plan and never as a past. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on deliveries or dispatch timing, say what you counted and how often. If not, say so plainly and say what you would track first. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert, a location and schedule term) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own stated constraint, met as you stated it. Words: "two days at Avonmouth is fine, but I wouldn't want more than three." |
| F9 | "£38,000–£44,000" (advert, a pay term) | "I'm hoping for £42,000." (your message) | high | [grounded] | hard_gate | Your figure sits inside the advertised band. Whether the band applies to this role is for the call to settle, so it is surfaced here and not bridged. |

## Prohibited claims

Built locally from the fit snapshot, because no dossier is present. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules across planning, the warehouse and QA | Inflated form of F1. "I schedule deliveries" does not carry production scheduling | The quote at its own scope. Your material says delivery scheduling across three depots, not production scheduling. The slot in B1 stays inside what you did. |
| Has ERP or SAP experience | Negative you stated (F6) | "I haven't used SAP." No slot. |
| Cut discrepancies by a third through your own method | Inflated form of F3. The sentence gives the drop, not what caused it | The quote at its own scope: "discrepancies fell by about a third over a year", with "I rebuilt our stock-count spreadsheet" beside it. Nothing about cause. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (weighted highest, 5 questions) | Open biography, then the four logistics topics in a friendly register | High. A recruiter screen's prior, and Hannah named all four topics in her message | A 90-second arc from your own sentences. Answer each logistics topic in one clean sentence and stop. |
| Skeptic, with one prober question (4 questions) | The SAP gap, the production-scheduling gap, the dispatch report, and "how was the third counted" | Medium. The advert's production and ERP lines sit against your delivery and in-house-system material | Hold your real scope. Name the gap plainly rather than bluffing it. Know the figure you gave and its scope. |
| Pressure, Data-Driven Prober as a separate persona, Peer, Case | Not weighted | Low for a recruiter screen. The prober case is covered inside B3 | None separately |

## Question banks

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Four years as a logistics coordinator at a building-supplies wholesaler, the deliveries you schedule for three depots, and chasing suppliers when orders slip. Those beats, in your words, under 90 seconds. Add nothing. | Opening question. It sets the record the later questions check. F5 and F2 carry it. |
| A2 | "What are you looking for in salary?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Say your figure in your own words: "I'm hoping for £42,000." Then stop. If asked what you earn now: "I'd rather focus on the range for this role." No reasons, no flexibility, no range. | Pay is a logistics slot filled by your own figure. F9 is its row. |
| A3 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Logistics slot, not yet filled: give your actual notice period in one sentence, in your own words. Your material does not give one, so it is left open here. | Named in Hannah's message, so the answer is asked of you. The question below asks you for it. |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say it at the sentence's own scope: two days at Avonmouth is fine, and more than three is the limit. If asked about the journey, your own words were: "I live in north Bristol." | Location and schedule are a logistics slot. F8 is its row. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | State the fact in that sentence's scope: the office closes next year, and the only offer is relocation to Reading, which you don't want. No criticism of the company. Answer slot: if a reason for this role beyond staying in Bristol is yours, say it in your own words. If it is not, the stated reason stands on its own. | Hannah named this topic. The reason is the whole slot, kept whole. |

### Skeptic, with one prober question

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. Your experience is deliveries across depots. How do you see the gap?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Highest-return prep in this pack. Say what you did in those words: delivery schedules for three depots, and chasing suppliers when orders slip. Answer slot: if you have set or shared schedules with planning, the warehouse or QA, say how and what you decided. If not, say so plainly and say how you would learn the production side first. Hold through two follow-ups by returning to deliveries. Never describe a production role you did not have. | F1 is the largest mismatch, and the advert's headline duty raises it. This is the objection most likely to come up. |
| B2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Plain acknowledgment: "I haven't used SAP." Then, if you want to: "We run our own in-house stock system." Then how you would learn an ERP, said as a plan. No ERP claim. | F6 is a stated negative, so the plain acknowledgment is allowed. |
| B3 | "You say discrepancies fell by about a third. How was that counted, and how much of it was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." (your message) | Hold the figure exactly as you gave it: "about a third over a year." Answer slots: how it was counted, if you know. If you don't, say you don't know how it was counted. Name the assumption you would defend least, in your own words. Say which part was yours: the spreadsheet you rebuilt. Do not round the figure up or assign causes you did not see. | The headline figure on your material. The defend-the-number slots are how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. This also covers the Excel requirement (F4) in your own frame. |
| B4 | "Have you reported weekly on on-time dispatch?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you have reported on delivery or dispatch timing, say what you counted and how often. If not, say so plainly and say what you would track first. | F7, a discovery gap. No quote carries it. |
| B5 | "How do you handle late supplier orders?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Describe chasing suppliers when orders slip, in those words. If you have one example from your own work, use it with only its own facts. | F2: your sentence already reaches the requirement, so this is a clean answer. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | B5 |
| Keep stock records accurate | B3 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | B3 partly; the skill level itself is not probed in this screen |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000–£44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |

## Reverse questions

Five, because it is a recruiter screen. There is no interviewer profile, so none is tied to a career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role, including the weekly dispatch report?" | Asks about the reporting duty the advert names, so you hear how it is measured. |
| R2 | "How do planning, the warehouse and QA pass schedule changes to each other?" | Shows you understand the seam the role sits in. |
| R3 | "Which stock system does the team use day to day, and is SAP in use?" | Tests whether ERP is a plus or a need in practice, and keeps the gap honest. |
| R4 | "What happens next, and roughly when?" | Hannah has said she will cover next steps. Asking shows you want the timeline. |
| R5 | "What would you want the person in this role to have done in their first three months?" | Tests whether the role's priorities match what she has described. |

## Sources

- Provided documents: Hannah Lowther's message as you relayed it, the advert as you pasted it, and your own message.
- Research tier: L1, searches 0 of 6 completed (2 refused), fetches 0 of 2.

Searches sent, both refused before returning anything:

- "Quillmoor Diagnostics values": refused (search permission not granted in this session).
- "Quillmoor Diagnostics interview process Operations Coordinator": refused (same).

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have checked for published values to cite. Those would move only an optional values section, which a recruiter screen does not use here. Nothing for this pack. |
| 2. Quillmoor Diagnostics interview process, Operations Coordinator | unavailable | Would have shown whether a hiring-manager round or case follows. This would change the next round's pack, not this one. |
| 3. Quillmoor strategy and recent news | unavailable | Would have given current company context. No grounding section is included here. |
| 4. Recruiter's public profile (Hannah Lowther) | unavailable | Not sent, because search was already refused. Would have shown her public focus, not her agenda. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

No searches were sent outside the declared targets.

## Upgrade menu

- Your notice period: A3 becomes your own figure, in your words, and no longer an open instruction.
- Any time you have sat in on or scheduled production, planning, warehouse or QA work: B1's answer slot gets its own story.
- The hiring manager's or panel's names: persona weights and tailored reverse questions for the next round.
- A tuesday-dossier.md from earlier prep, if you have one: it would carry the objections you have already rehearsed, so B1 does not start from scratch.
