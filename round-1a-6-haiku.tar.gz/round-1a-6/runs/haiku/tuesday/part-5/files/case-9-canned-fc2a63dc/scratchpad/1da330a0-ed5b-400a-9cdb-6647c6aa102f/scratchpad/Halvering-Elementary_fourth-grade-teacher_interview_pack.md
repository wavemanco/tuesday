# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Interviewer: Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given). Round: 45-minute panel, Thursday. Relationship: manager-level panel with two peers.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

- **JD**: the posting's stated responsibilities and qualifications
- **EXP**: whether your past work survives scrutiny
- **VAL**: whether past behavior fits the district's published beliefs
- **CASE**: a live problem from the job, with no claim about your past
- **CO**: company and strategy knowledge (none asked in this pack; the district's public literacy plan is noted in the reverse questions)

## Fit snapshot

Requirements come from the invite's own words (quoted) and from the district's public hiring page (quoted, with its source). Evidence is quoted from your CV or your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate shown met on your CV. Bring the license record to the panel; the panel may check it. |
| F2 | "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Your material says a third-grade reading move, not fourth grade. Say the third-grade scope in those words: "I led our grade level's move to a new reading curriculum in 2024." Anything wider is an answer slot in F4. |
| F3 | "Panels ask about ... how you work with families." (district hiring page); "Each teacher speaks with every family each term." (district values page) | "I write a weekly email to families." (your CV) | medium | [grounded] | presentation | Your CV carries a weekly email, which reaches the family-contact requirement in its own terms. Say the weekly email as written; do not describe conversations with every family, which the CV does not carry. |
| F4 | "Panels ask about reading instruction..." (district hiring page); "Plan and teach reading ... differentiate instruction using assessment data" (representative fourth-grade listing, not this employer, labeled [inferred]) | none given for differentiation using assessment data | low | [inferred] | discovery | Your material does not show how you used assessment data to differentiate. Answer slot: if you did, say what data and how you grouped students; if you did not, say so and say what you would use first. |
| F5 | "Fourth Grade Teacher" (invite) | "I've never taught fourth grade and I've never been a team lead." (your message) | none | [grounded] | capability | The absence is one you stated. Words: "I haven't taught fourth grade." Then how you would learn it, as a plan and never as a past. |
| F6 | Team membership of a grade-level team (invite) | "I've never been a team lead." (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." The nearest carried sentence is F2's, quoted at its own scope. |

Rules applied: the gap type comes from the evidence cell, not from how the row feels. F5 and F6 are the two gaps you named yourself, so their words come from your own negatives and nothing is added.

## Prohibited claims

Not coached, with the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| "I taught fourth grade" or "I have fourth-grade experience" | Negative you stated (F5) | "I haven't taught fourth grade." No slot. |
| "I've been a team lead" or "I led the grade team" | Negative you stated (F6) | "I haven't been a team lead." Then F2's sentence at its own scope. |
| "I designed the curriculum" or "I led the district's reading plan" | Inflated form of F2: your sentence says you led the grade-level move, not that you chose the curriculum | "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says the grade-level move, not who selected the program. |
| "I hold conferences with every family" | Inflated form of F3: your sentence is a weekly email | "I write a weekly email to families." |
| "The reading club raised scores" | No quote; your material says you ran the club, not what it did to results | Describe what the club covered, and results only if you tracked them. |

## Reading the interviewer

Public professional footprint only.

- **Dolores Vantongeren**, principal of Halvering Elementary since 2022; nine years as a reading specialist before that. Source: a 2025 forum speaker listing.
- Her 2025 talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5. Source: the same listing.

Implications: she will probably test reading instruction in depth, and small-group practice is her recurring theme. Your CV does not yet carry a small-group practice, so do not claim one. Ask what it is in her building (see reverse questions).

## Persona table

Panel: each member's top two personas, blended. The principal is treated as a hiring manager; the two team members as peers. Names of the team members are not known, so weights are per role.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | "You've never taught fourth grade"; "You've never been a team lead" | High. Both gaps are on your own record, and the invite's panel is a hiring decision. | Plain acknowledgment, then a concrete ramp plan. Hold through two follow-ups. |
| Case / Strategist (principal) | A reading lesson for fourth graders; a student with a specific gap | High. The district's panel topics include reading instruction. | Clarify, then objective, then the check you would use. |
| Peer Evaluator (team) | "Where would you need our support?"; how you handle disagreement on a team | Medium-high. Team members weigh what a new colleague adds to their load. | Reciprocity: what you bring to their grade team, then what you need. |
| Data-Driven Prober (team) | "What did you measure?" after the curriculum move | Medium. Peers ask about evidence; your CV has no measurement claim. | Say what you tracked, if anything; say plainly if you did not. |
| Conversational (any) | "Walk us through your path." | Medium. Casual openers are scored too. | A 90-second arc from your CV. |

Weights: Skeptic 5 (highest-ROI); Case 3; Peer Evaluator 3; Data-Driven Prober 2; Conversational 2.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What would make fourth grade different for you?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Acknowledge plainly: "I haven't taught fourth grade." Then what carries over: "I've taught third grade for six years." Then a first plan: what you would read in the fourth-grade standards and ask the team first. | F5 is the most likely first objection; the answer should be ready before the probe. |
| A2 | "Fourth grade is a real step up from third. Why should we believe you're ready by September?" | JD | [grounded] "I've never taught fourth grade"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | **Highest-ROI prep.** Hold: "I haven't taught fourth grade, and I'd be learning the content in the first weeks." Hold through two follow-ups by returning to the third-grade work and the plan. Concede specifically: "I can't promise the first month will be smooth; I can promise I'll ask for the team's help early." Do not promise a timeline you have not planned. | Deepest rehearsal: the objection sits exactly where the material is thin. |
| A3 | "You've never been a team lead. Why would you be a strong member of a grade team?" | EXP | [grounded] "I've never been a team lead."; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment: "I haven't been a team lead." Then the nearest sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you set the plan the team worked from, say which decisions were yours; if you did not, say so and describe how you contributed. | F6 gap, rehearsed so the honest answer is ready. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk us through how you'd teach a reading lesson to fourth graders on a text you haven't seen before." | CASE | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page) | Clarify first: grade-level standard, students' current reading levels, what the team already uses. Then objective, a short model, guided practice, an exit check. No claim about your past. | Reading instruction is a stated panel topic; CASE tests structure, not experience. |
| B2 | "A student reads fluently but misses inference questions. What do you do on Monday?" | CASE | [generic] | Name the diagnostic you would use, the small group you would form, and the check you would run the next week. | Live problem from the job; no past claim. |

### Peer Evaluator and Data-Driven Prober (weight 3 and 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led the move to the new reading curriculum. Which decisions were yours, and which were the team's?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Stay inside the quote: the move, and what you led in it. Answer slot: if you chose parts of the program or the rollout, say which and how you decided. If the decisions were the team's, say so, and describe your role in them. | F2 is the strongest sentence you have; the panel will ask how far it goes. |
| C2 | "How did you measure whether the new curriculum worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you tracked anything, say what and how often; if you did not, say so and say what you would track first. | Your CV does not show measurement; a Prober asks anyway. |
| C3 | "How do you keep families in the loop when reading goals change?" | VAL | [grounded] "I write a weekly email to families." (your CV); [inferred] "Families Are Partners" (district values page) | Say the weekly email as written. Do not describe conversations with every family. Answer slot: what the email covers, in your own words. | Families Are Partners is a published district belief; your CV carries the email, not the conversations. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years." | A 90-second arc: third grade in Joliet, the curriculum move in 2024, the reading club for two years, what you want to do next. Say each in your own words. | Casual openers are scored; the arc uses only your CV's sentences. |
| D2 | "What drew you to Halvering?" | VAL | [inferred] the district's published literacy plan (search result from the district's own news page: a 2026–2029 literacy plan with a new grades 3–5 reading curriculum from fall 2027) | Selection scaffold: name something specific you read on the district's site, and connect it to a part of your own work. Do not claim a link you have not made. | Shows you looked at the district; the literacy plan is public and attributable. |

### Values and VAL (theme from district's published beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Our goal is that no student leaves third grade without a reading plan. How have you made that real?" | VAL | [inferred] "Every Child a Reader" (district values page); [grounded] "I've run the after-school reading club for the last two years." | Answer slot: describe what the club covered and how you planned for each child's reading, in your own words. If you did not plan individually, say what you did instead. | The district's first belief is a raising source; the club is your only reading-focused work on your CV. |

## Requirement coverage

| Stated requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement | F1; not a question (the gate is shown met) |
| Reading instruction (district hiring page) | B1, B2, C1, F2 |
| Classroom routines (district hiring page) | none, and why: your material does not carry routines; add it in the upgrade menu |
| Working with families (district hiring page) | C3, F3 |
| Differentiation using assessment data (representative listing) | F4; no bank question, since F4 is an answer slot |

## Reverse questions

Each one has a "why it lands."

1. "How does the fourth-grade team plan reading instruction across the year?" Why it lands: it asks about the panel's topic and shows you are listening for their process.
2. "The district's 2027 grades 3–5 reading curriculum change is on the public plan. How is the fourth-grade team preparing for it?" Why it lands: it connects your curriculum experience to a public district change, and it is a question a peer can answer.
3. "You moved from reading specialist to principal in 2022. What do you look for in a teacher's reading practice?" Why it lands: it ties to her own path and to her public talk.
4. "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" Why it lands: reciprocity for the peers, and a plan you can act on.
5. "How does the school hear from families about reading progress?" Why it lands: it tests the Families Are Partners belief from the other side.

## Sources

- Provided documents: the invite text in your message; your résumé-style notes in your message. Your Social Security number was not used or repeated. It is not needed for this prep, so keep it off anything sent to the school.
- Research tier: L1, searches 5 of 6, fetches 2 of 2. User links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary School values | yes | Searched "Halvering Elementary School values"; fetched the district's Mission and Beliefs page: "Every Child a Reader," "Families Are Partners," "Teach for Tomorrow, Not for the Test." Moved VAL question V1 and C3. These are published beliefs, not a values-style round. |
| 2. Halvering fourth grade interview process | yes | Searched "Halvering Elementary School fourth grade teacher interview process"; fetched the district's How We Hire Teachers page: one 45-minute building panel with the principal and two grade-level teachers. This is a loop source that establishes the loop, so no archetype fallback. |
| 3. Strategy / recent news | yes | Searched "Orrinsford Community School District strategic plan priorities." The result is the district's own news page (search snippet, not fetched): a 2026–2029 literacy plan with a new grades 3–5 reading curriculum from fall 2027. Moved D2 and reverse question 2. |
| 4. Dolores Vantongeren Halvering Elementary | yes | Searched her name with the school; result is a forum speaker listing (snippet): principal since 2022, prior reading specialist, 2025 talk on reading conferences in grades 3 to 5. Moved the interviewer read and reverse question 3. |
| 5. Representative fourth-grade teacher JD | yes | Searched "elementary fourth grade teacher job description Illinois Professional Educator License reading instruction." Result is a jobs-board listing (snippet), not this employer; used only as an [inferred] representative for F4. |

## Upgrade menu

- The posting's full text → the invite's requirements become quoted posting lines, and the [inferred] listing rows become [grounded].
- The two team members' names → persona weights per member, instead of per role.
- Your reading club's details (what it covered, how you tracked progress) → V1 and D1 gain grounded answers, and the answer slot in V1 closes.
- What you decided in the 2024 curriculum move → C1 and A3 get grounded answers instead of slots.
- Your classroom routines and how you used assessment data → F4 and the routines coverage row get grounded answers.
- Prep time before Thursday → a prioritized prep schedule.
- A deeper research pass (strategy brief, loop reports) → up to 6 more searches and 2 more fetches, several minutes. Want it?
