# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Changelog:** first version.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Say the quoted sentences in your own words, and never add a figure, practice or event that is not in them.

Type key: **JD** = the advert's requirement. **EXP** = your own work history. **CASE** = a live problem. **VAL** and **CO** do not apply to this round.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Covered. Lead with the four years and the role, in those words. Expect a probe on what the four years involved. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production planning or QA. Make the adjacent case and stop there. Do not stretch it to production. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Covered. Say it in those words. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | none | Covered. The figure below is the part to be ready to defend. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show whether you reported on dispatch timing. Answer slot: if you did, say what you reported and how often; if you did not, say so and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The rebuild shows you used a spreadsheet. It does not show your level in Excel. Answer slot: name the functions you actually used; if you have not used others, say so. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used SAP." Then your in-house stock system, in your own words. Learning SAP is a plan, not a past. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine" (your message) | high | [grounded] | none | Met by your own statement. |

Gap and bridge language sits in the last column. Confidence grades your evidence; Provenance grades what this pack wrote.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Production planning or QA experience | Inflated form of F2 | "I schedule deliveries for our three depots." The limit is the pack's observation: your material shows delivery scheduling, not production planning. |
| SAP or ERP experience | Negative you stated, F7 | "I haven't used SAP." No slot. |
| Advanced Excel | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." Nothing beyond it. |
| The whole third of the discrepancy reduction as yours alone | Inflated form of F4 | "discrepancies fell by about a third over a year" over the period you worked on it. Whether anyone else contributed is for you to say. |
| Your current salary | Not stated | Decline without a figure (see A4). |

## Question banks

Persona weights, shown as reasoning. A recruiter screen's usual mix is conversational, with a light skeptic. Your pay, notice, location and reason for leaving are the logistics slots: she asks them to check fit, not to test you. Depth: Conversational 5 questions, Skeptic 4, Prober 1.

### Bank A: Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I rebuilt our stock-count spreadsheet" | A 90-second arc: the role, the three depots, the supplier chasing, the stock-count rebuild. Use your own words for each. Do not add a team or a scope. | Open prompt. F1, F3 and F4 are the evidence. |
| A2 | "What's drawing you to this role?" | JD | [grounded] "Coordinate production schedules between planning, the warehouse and QA" | Name two parts of the advert that match what you already do: supplier chasing and stock accuracy. Stop there. Do not claim the production side. | Motivation. F2 marks the edge of your fit, so say what matches and leave the rest. |
| A3 | "Why are you looking to move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those words. Do not add a view of the company or the Reading offer beyond them. | Logistics slot for reason for leaving. |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Give that figure in your own words. If she asks for a range or flexibility, say you would like to understand the band for this role first. If asked what you earn now: "I'd rather focus on the range for this role." Never state a current figure, a floor or a counter-offer. | Logistics slot for pay. The advert's band is £38,000 to £44,000, so £42,000 sits inside it. |
| A5 | "What's your notice period?" | JD | none given | Give your actual notice period. It is not in what you have shared, so this is an open item (upgrade menu). | Logistics slot for notice. Asked first in most screens. |
| A6 | "The role is two days a week at Avonmouth. Does that work?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine" | Say yes, in those words. If asked how many days you would want: "I wouldn't want more than three." Do not volunteer the three-day ceiling otherwise. | Logistics slot for location and pattern. |

### Bank B: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert asks for SAP or similar. Have you used an ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment: "I haven't used SAP." Then: "we run our own in-house stock system", in your words. Then how you would learn it, as a plan. | F7 is the most likely knock-out question. Rehearse the plain line until it is boring. |
| B2 | "Production scheduling covers planning, the warehouse and QA. You've scheduled deliveries. What's the difference?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you have worked with planning or QA, say how, in your own words; if not, say so plainly and say how you would learn the production side. | F2 is the edge of your fit. The honest answer is the adjacent one. |
| B3 | "Excel is in the advert. How would you rate yourself?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the functions you used to rebuild it, in those words. If you used no others, say so. Do not give a rating you cannot back. | F6. A rating invites a probe you cannot answer. |
| B4 | "Have you reported on on-time dispatch?" | JD | none given | Answer slot: if you reported on delivery timing, say what, how often and to whom; if not, say so and say what you would report first. | F5. The advert asks for it weekly. |

### Bank C: Data-Driven Prober (weight 1, the figure only)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Say how it was counted, in your words. Name the assumption you would defend least. Say which part was yours. If you did not count it yourself, say so. | The figure raises a defend-the-number slot. It is the one number in your material, so expect a follow-up. |

## Reverse questions

1. "What does a typical week look like for this role across planning, the warehouse and QA?" Why it lands: it shows you are weighing the production side, not only the advert's title.
2. "How is on-time dispatch measured and reported today?" Why it lands: it links to the weekly report and shows you read the requirement.
3. "Is the Avonmouth pattern of two days fixed, or agreed per team?" Why it lands: it tests the hybrid terms without implying you want more flexibility.
4. "What would success look like at the end of the first three months?" Why it lands: it turns the screen into a working conversation.
5. "What's the timeline from here to a decision?" Why it lands: it shows you are planning around the process, which recruiters notice.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules (planning, warehouse, QA) | A2, B2 |
| Track supplier deliveries, chase late orders | A1 |
| Keep stock records accurate | A1, C1 |
| Weekly on-time dispatch reporting | B4 |
| Confident with Excel | B3 |
| ERP (SAP or similar), a plus | B1 |
| Pay, hybrid pattern, notice, location, reason for leaving | A3, A4, A5, A6 |

## Persona table

| Persona | How it shows up here | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through", a casual logistics check | High. Recruiter screens are mostly this. | Have a 90-second arc ready. Treat the casual questions as scored. |
| Skeptic | Pressing on SAP, production scheduling and Excel | Medium. The advert's requirements are where your material is thin. | Plain acknowledgment on SAP, adjacent case on production, no rating on Excel. |
| Prober | Asking how the discrepancy figure was counted | Low to medium. It is the only figure you have given. | Name the weakest assumption before she does. |

## Sources

- Provided documents: the advert, your message, and the recruiter's LinkedIn message (booking and her topics).
- Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have fed a values cheat sheet, but no values-style round was detected, so it would not have moved the pack. |
| 2. Quillmoor interview process, operations | unavailable | Would have confirmed what a recruiter screen covers here. Her own message already says it. |
| 3. Quillmoor strategy / recent news | unavailable | Would have fed a "what do you know about us" answer. Not in the pack yet. |
| 4. Hannah Lowther, Quillmoor | unavailable | Would have given an interviewer read, but a recruiter screen does not need one. |
| 5. Representative Operations Coordinator JD | skipped | The advert you gave fixes every fit row. |

Refused call: web search for "Quillmoor Diagnostics Avonmouth Bristol diagnostic test manufacturer". Permission to use the search tool was not granted, so no research ran.

## Upgrade menu

- Your notice period → a grounded answer to A5, instead of an open item.
- A second pass with research enabled → a values and news check on Quillmoor (rows 1 to 3 above).
- Any Excel or dispatch-report detail you have → rows F5 and F6 move from answer slots to stated facts.
