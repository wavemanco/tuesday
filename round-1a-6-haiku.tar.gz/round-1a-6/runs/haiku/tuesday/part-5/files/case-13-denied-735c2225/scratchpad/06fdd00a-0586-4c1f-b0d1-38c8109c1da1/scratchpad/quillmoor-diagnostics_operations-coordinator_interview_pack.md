# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff). Avonmouth, Bristol. Hybrid, two days a week on site. £38,000–£44,000.
**Round:** Recruiter screen, phone, 30 minutes, Thursday at 2pm.
**Interviewer:** Hannah Lowther, Talent Partner (recruiter).
**Changelog:** First version.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script.

| Type | Name | What it scores here |
|---|---|---|
| VAL | Behavioural and values alignment | Not in this pack: no values-style round is detected |
| EXP | Work-experience deep-dive | Whether what you did survives a closer look |
| JD | Role and JD-driven | The listed job's terms: pay, notice, location, the duties |
| CO | Company and strategy knowledge | Not in this pack: no company research ran |
| CASE | Hypothetical or live problem | Not in this pack: a recruiter screen does not run one |

## Prep triage

Prep time is not stated, so this is an order, not a schedule. Your message says Thursday at 2pm. If that is today, cover items 1 to 4 and stop there.

1. **Pay (A3).** Say your figure in your own words: "I'm hoping for £42,000."
2. **Notice period (A4).** Your inputs do not give it, and this pack gives no figure. Know your real number before the call.
3. **Hybrid and location (A5).** Your stated limit, in your own words.
4. **Reason for leaving (A2).** Your own words, with no reasons added.
5. **The one-third figure (B3).** Be ready to say how it was counted, in your own words, or to say you don't know.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the advert you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows deliveries scheduled across three depots, not production schedules across planning, the warehouse and QA. Words: "I schedule deliveries for our three depots." Answer slot: if you coordinated any of those three functions, say which and how, in your own words; if you did not, say so and say what you do schedule. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your message) | medium | [grounded] | none | Words: "I chase suppliers when orders slip." Your material shows chasing, not tracking. Expect a probe on how you kept track of deliveries, and answer it in your own words. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Words: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The "about a third" is a figure, so expect a probe on how it was counted (B3). |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch or delivery-timing reporting. Answer slot: if you measured delivery timing or dispatch, say what you counted and how often; if you did not, say so plainly and say what you would count first. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | A length-of-experience requirement, graded on fit like any other. Words: "4 years as a logistics coordinator at a building-supplies wholesaler." |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | Your material shows a spreadsheet you rebuilt, not Excel by name. Words: "I rebuilt our stock-count spreadsheet." |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | none | [grounded] | capability | You stated the SAP absence. Words: "I haven't used SAP." The in-house system is handled in B2. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" and "I live in north Bristol" (your message) | high | [grounded] | none | Your own constraint, stated. It is a location and schedule term, and your material shows it met. Words: "Two days at Avonmouth is fine, but I wouldn't want more than three." |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your own figure, stated. It sits inside the advert's range. Words: "I'm hoping for £42,000." |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed three depots | Inflated form of F1 | "I schedule deliveries for our three depots." Your material says deliveries, not depot management. That limit is this pack's observation. |
| Ran production scheduling across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. A2's answer slot in B1 asks which of those functions were yours. |
| Has ERP or SAP experience | Stated negative, F7 | "I haven't used SAP." No slot attached to this line. |
| Discrepancies fell because of your work alone | Inflated form of F3 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not say what else changed. That limit is this pack's observation. |

## Persona table

Weights follow the recruiter-screen prior. The conversational persona carries the screen. The skeptic is light. The prober is low, because a short screen rarely digs in.

| Persona | How it shows up here | Likelihood | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | Friendly walk-through, with pay, notice, location and reason for leaving asked casually | High | Top weight, 5 questions. A recruiter screen's logistics arrive in this register, and casual questions are still scored | Give a 90-second arc. Answer the logistics in your own words, and do not add to them |
| Skeptic | Why now, and the SAP gap | Medium | Light weight, 3 questions. The SAP gap is the one a recruiter is likely to flag | Say the negative plainly. Bridge only from what you stated |
| Data-driven prober | The one-third figure and dispatch reporting | Low | Low weight, 2 questions | Name the weakest assumption. Say what you don't know |

Ten questions, below the usual range. A 30-minute recruiter screen does not run deep rounds, and padding it would teach you to skim.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background, in a couple of minutes." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet" (all your message) | Run through the role, the three depots, the supplier chasing and the stock-count rebuild, in that order. Use your own words and keep to what those sentences say. Finish in about 90 seconds. | The opening of every screen. F5, F1, F2 and F3 are the four sentences it draws on, so the answer stays inside them. |
| A2 | "Why are you looking to move on?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Give the reason in your own words: the Bristol office closes next year, and the only offer is relocating to Reading, which you don't want. If asked for more, give the same words again and add no reason. | The reason-for-leaving slot. Your answer is already in your message, so the rehearsal is saying it aloud without adding to it. |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Give the figure in your own words: "I'm hoping for £42,000." Add no range, floor, flexibility or counter-offer you did not give. If asked what you earn now, you may decline with: "I'd rather focus on the range for this role." | Pay is a listed term. F9 gives the figure, and it raises no answer slot. |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period in your own words. Your inputs do not state it, so this pack gives no figure. Have it ready before Thursday. | The notice term is the logistics slot your inputs left open, so the answer is yours to supply. |
| A5 | "The role is two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" and "I live in north Bristol" (your message) | Give your stated answer: two days at Avonmouth is fine, and you would not want more than three. Your north Bristol home is the context. Do not describe a commute you did not give. | F8 is your stated limit. The location slot is met by your own words, so nothing is added. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Name the part you have least direct experience of, in your own words. The production-side scheduling across planning, the warehouse and QA is the advert's, and your sentences show deliveries. Answer slot: if you have coordinated any of that scheduling, say where. If you have not, say so plainly, then say how you would get up to speed. | F1 is the likeliest place to be probed, and this is the standard form of the skeptic's question. |
| B2 | "You haven't used SAP. What would you do with an ERP on day one?" | JD | [grounded] "Never used SAP" and "we run our own in-house stock system" (your message) | Plain acknowledgment: "I haven't used SAP." Then, answer slot: if you used the in-house stock system day to day, say what you did in it. If you did not, say so, and say how you would learn SAP. | The highest-ROI prep in this pack. The SAP gap is the most predictable objection, because F7 is the stated gap against the advert's plus. The question's premise is your own stated negative. |
| B3 | "Discrepancies fell by about a third. How much of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Hold to the sentence: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Name, in your own words, the assumption behind "about a third" that you would defend least. If you cannot say how it was counted, say so. If other changes happened that year, say what they were. If you do not know, say that. | F3 is the figure, and a figure you gave raises the defend-the-number slot. This is the one most likely to draw a follow-up. |

### C. Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role reports weekly on on-time dispatch. Have you produced a figure like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you measured delivery timing or dispatch, say what you counted and how often. If you did not, say so plainly and say what you would count first. | F4 is the row with no evidence. The advert's own line raises the question. |
| C2 | "You chase suppliers when orders slip. How many orders slipped in a typical week?" | EXP | [grounded] "I chase suppliers when orders slip" (your message) | Answer slot: if you counted slipped orders, say the number you know and how you counted it. If you did not count, say so plainly and say how you knew an order had slipped. | F2 is the sentence. The count is an answer slot, and this pack supplies no number. |

## Requirement coverage

| Requirement (advert) | Covered by |
|---|---|
| Coordinate production schedules across planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A1, C2 |
| Keep stock records accurate | B3 |
| Report weekly on-time dispatch | C1 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | None, and why: a 30-minute screen does not test Excel. B3 may draw on the spreadsheet. |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000–£44,000 | A3 |
| Two days a week at Avonmouth | A5 |

## Reverse questions

Hannah has said they will cover the team and next steps. Use these only where that does not reach them.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What happens after this call, and who would I meet next?" | It shows you are planning the next round. |
| R2 | "Is the two-day Avonmouth pattern fixed for the team, or does it vary by role?" | It tests whether the pattern has room, which bears on your three-day limit. |
| R3 | "What would the weekly on-time dispatch report look like, and who reads it?" | It ties C1 to how the role's output is actually used. |
| R4 | "What would someone in this role want to have done well in its first six months?" | It shows you are thinking about success in the role, not only its advert. |
| R5 | "Who sits either side of this role, in planning and in QA?" | It shows you see the coordination role as the interface it is. No interviewer profile was researched, so no question here ties to Hannah's own path. |

## Sources

**Provided documents:** the advert text, your background and constraints as you wrote them, and Hannah's booking message.

**Research tier:** L1 — searches 4 of 6, fetches 0 of 2. Web search was refused in this session, so no research result was used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Section 10 (values cheat sheet). No values-style round is detected here, so it is dropped and nothing in this pack is affected. |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | The loop structure after this screen, and the persona weights for those rounds |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Current facts for CO questions. This screen's bank has none. A hiring-manager pack would need them. |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | The interviewer read (section 7). Dropped, since no public profile was confirmed. |
| 5. Representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused:
- "Quillmoor Diagnostics values"
- "Quillmoor Diagnostics interview process operations coordinator"
- "Quillmoor Diagnostics news 2026"
- "Hannah Lowther Talent Partner Quillmoor Diagnostics"

## Upgrade menu

- Hannah's answer on the rounds after this screen, from the call or an email → the loop line, and persona weights for the next round
- Web search allowed in this session → the four refused targets re-run, which would mainly firm up the loop structure and recent news
- Hannah's public profile text, pasted by you → an interviewer read, and a reverse question tied to Hannah's own path
- What you did in the in-house stock system, in your own words → upgrades B2's answer slot to a grounded answer, if the honest answer is yes
- A tuesday-dossier.md → carries the SAP gap, the one-third figure and the dispatch reporting into later sessions. No dossier is present now.
