# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30-minute phone call with Hannah Lowther (Talent Partner), Thursday 2pm. She will ring the mobile number on your application.
**Her agenda, in her words:** salary expectations, notice period, how the hybrid pattern would work, what is prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| EXP | Work-experience deep-dive | Whether what you did is what you say you did |
| JD | Role and advert driven | Whether you can do the listed job, gaps included |
| CASE | Hypothetical or live problem | Structure on a problem from the role |
| VAL | Values alignment | Not used: no values round is detected here |
| CO | Company knowledge | Not used: no company research ran |

The guidance is scaffolding, not a script. Say it in your own words, and answer only from what you did.

This pack holds 14 questions. A 30-minute screen run on her own list cannot use 18, and 14 covers every requirement in the advert and every logistics topic she named. This is a judgement, not a padded total.

## Fit snapshot

Each evidence cell holds your own words, as quoted, with its source. Confidence is about your evidence. Provenance is about what this pack wrote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. It is a self-reported job line with nothing to inspect, so expect a check on dates. Say it in those words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material carries delivery scheduling across three depots. It does not show production schedules, or work with planning, the warehouse or QA. Give the adjacent work at its own scope: "I schedule deliveries for our three depots." Answer slot: if you set schedules with planning, stock or quality teams, say which and how, in your own words; if you only scheduled deliveries, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | The quote already reaches chasing late orders, in other words. Keep its words: "I chase suppliers when orders slip." Tracking deliveries is not in the quote, so add nothing to it. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. The figure is yours, and it draws a count question (C1). Keep it as "about a third, over a year". |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: if you reported any delivery-timing figure, say what it counted and how; if you did not, say so plainly and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | discovery | The material shows a spreadsheet. It does not name the program, and it does not show Excel. Answer slot: say which program the stock-count spreadsheet was in and what you built in it; if it was not Excel, say so plainly. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | high | [grounded] | capability | Your words for this: "I've never used SAP." Then the in-house stock system at its own scope. Any ERP learning is a plan, said as a plan, never as past experience. Do not call the in-house stock system ERP experience. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol"; "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your stated limit covers the advert's two days. No gap. Your own words carry it. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your stated figure sits inside the advert's band. It fills the pay slot (A4) and raises no question of its own. |

Notice period is not in the advert, and your material does not give one. It is handled as a logistics slot in A5.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, a biography question, casual checks on pay and notice | Top weight, 5 of 14. Her agenda is a recruiter's list in a friendly register, and casual questions are still scored | Use a 90-second arc for the biography. Give pay and notice in your own words, and no more |
| Skeptic | Quiet probes on the Reading move, the Avonmouth pattern, the production line and the SAP line | 4 of 14. The relationship prior for a recruiter screen is light Skeptic. The advert has two plain gaps (production scheduling, SAP) she may raise | Restate the gap in the quote's terms. Bridge only from what you stated |
| Data-Driven Prober | Asks how the one-third figure was counted, and what the spreadsheet ran in | 3 of 14. A figure on a CV-style line draws a count question even in a screen | Give the figure as you gave it. Say plainly where you do not know how it was counted |
| Pressure / Stress | A time-boxed "why should we go on" on the gaps | 2 of 14. Low for a recruiter screen. Pressure on the pay figure is not written, because the rules do not allow asking whether a stated figure is firm | Hold the quoted line through two follow-ups. Concede the SAP gap plainly |

## Question banks

### Persona A: Conversational / Rapport Builder (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, the short version." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip" | Three beats, in order: the four years and the wholesaler, the three depots, then chasing suppliers when orders slip. Speak each quote's clause, nothing more. Answer slot: if there is one thing you did that you want to name, say it in your own words. | F1, F2 and F3 are the opening evidence. The casual register is still scored |
| A2 | "Tell me about the stock-count spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Beats: you rebuilt it, then discrepancies fell over a year, and the figure is "about a third". Say what you rebuilt in your own words. If you cannot name the parts, say so plainly and name the one you remember. | F4 is your strongest match to the stock-records line. The question is open enough that the words stay yours |
| A3 | "What tools do you use day to day for stock?" | JD | [grounded] "we run our own in-house stock system" | Name the in-house stock system, then the spreadsheet. Answer slot: say which program the spreadsheet ran in. If it was Excel, say so. If it was another program, name it | F6 is the Excel line. Asked casually, it still scores the Excel requirement |
| A4 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Say your figure in your own words: "I'm hoping for £42,000." If asked what you earn now, say: "I'd rather focus on the range for this role." | F9 fills this logistics slot. It raises no defend-the-number question and no question about why the figure |
| A5 | "What's your notice period?" | JD | [grounded], the logistics line she named | Give your actual notice period in your own words. Your material does not state one, so this slot is yours to fill on the call | Notice is her named topic and not in the advert. The slot is an instruction for the call, not a blank |

### Persona B: Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert asks you to coordinate production schedules. Your background is a building-supplies wholesaler. How would you handle that?" | JD | [grounded] "I schedule deliveries for our three depots"; "4 years as a logistics coordinator at a building-supplies wholesaler"; the advert's "Coordinate production schedules between planning, the warehouse and QA" | Start from the quote: "I schedule deliveries for our three depots." Answer slot: if you set schedules with planning, stock or quality teams, say which and how, in your own words. If you only scheduled deliveries, say so plainly, then say what you would do first. Do not name production work you did not do | This is the highest-ROI prep in the pack. F2 is the weakest bridge, and the production line is the advert's headline. Expect this probe in some form |
| B2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it whole, in your words: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If asked whether you would relocate, give the same words again, with nothing added | This is her named topic. Keep it to what you stated |
| B3 | "The hybrid pattern is two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol"; "two days at Avonmouth is fine, but I wouldn't want more than three" | Give your stated limit: "two days at Avonmouth is fine, but I wouldn't want more than three." Give the north Bristol point only if it is asked for, in those words | F8 is firm and is yours to state. Nothing about the commute is added |
| B4 | "The advert lists SAP as a plus. Have you used it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment: "I've never used SAP." Then the in-house stock system, at its own scope. Then how you would learn it, as a plan | F7 is a stated absence. It is a plus, not a requirement, so a plain answer does the job |

### Persona C: Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Give the figure as you gave it: "about a third, over a year". Name the assumption you would defend least, before she does. Answer slot: if you know how discrepancies were counted, say how. If you don't, say so plainly | F4's figure raises the count question. The pack supplies no baseline and no counting method |
| C2 | "The advert asks for weekly on-time dispatch reporting. What have you reported?" | JD | [grounded] | Answer slot: if you reported any delivery-timing figure, say what it counted and how. If you did not, say so plainly, and say what you would report first | F5 is silence in your material. The pack gives no figure and no report |
| C3 | "What happens when an order slips?" | EXP | [grounded] "chase suppliers when orders slip" | Tell it in your words: you chase the supplier when an order slips. Answer slot: if you had a point at which you chased, say what it was. If you did not, say so plainly | Her probe on chasing will test the scope of the quote. Keep the answer inside it |

### Persona D: Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take this further, given the advert's SAP and production scheduling lines?" | JD | [grounded] "I schedule deliveries for our three depots"; "Never used SAP — we run our own in-house stock system" | Hold through two follow-ups by returning to the quotes. Concede the gap plainly: "I haven't used SAP." Do not fold on the core claim to restore harmony | F2 and F7 are the two places the material is thin. A held position they can back is the one that survives the second follow-up |
| D2 | "What would you not be able to do on day one?" | JD | [generic] | Name one thing you would need to learn and how you would learn it, as a plan, never as past experience. Do not claim a skill you do not have | No claim about your past. The question is a pressure stem, not a fact about you |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A1, C3 |
| Keep stock records accurate | A2, C1 |
| Report weekly on on-time dispatch | C2 |
| Confident with Excel | A3 |
| ERP (SAP or similar) a plus | B4, D1 |
| Hybrid: two days a week at Avonmouth | B3 |
| £38,000–£44,000 | A4 |
| Notice period (not in the advert, named by Hannah) | A5 |
| Reason for moving (named by Hannah) | B2 |

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. None of these is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says delivery scheduling, not production schedules. Limit stated as the pack's observation |
| Used SAP, or any ERP | Stated negative, F7 | "I've never used SAP." Plain acknowledgment, no slot |
| Discrepancies fell by a third because of the rebuild alone | Inflated form of F4: the causal sole credit and the dropped "about" | "discrepancies fell by about a third over a year." Your sentence puts the rebuild and the fall together. It does not say the rebuild alone caused it |
| Reported weekly on on-time dispatch | Inflated form of an advert line your material does not show | Your material does not show dispatch reporting. The pack's observation only. No words for you, and the answer is C2's slot |
| Advanced Excel | Inflated form of F6 | "the stock-count spreadsheet I rebuilt." Which program it ran in is C2's slot |
| A figure for current pay | Not given | "I'd rather focus on the range for this role." No figure |

## Reverse questions

Ask these at the end of the call. Each has a reason it lands.

1. "What does a typical week look like across planning, the warehouse and QA?" Why it lands: it shows you read the advert's coordination line as a real job, not a list of words.
2. "How is on-time dispatch reporting done today, and who reads it?" Why it lands: it tests F5 without asking about your history.
3. "How is the two-day Avonmouth pattern set, and is it fixed or agreed week by week?" Why it lands: it checks your stated limit against the real pattern, with her own words.
4. "Is this a new role or a replacement, and how many interview stages come after this call?" Why it lands: it covers the next steps she named.
5. "How is the stock system kept accurate across the team?" Why it lands: it opens the in-house system at its own scope, which is your strongest adjacent evidence.

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message as you quoted it, the advert as you pasted it, and your background as you told it.

**Research tier:** L1, searches 2 of 6, fetches 0 of 2. User links read 0. Both searches were refused by the host, so the pack has no company-specific content.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Refused: "Quillmoor Diagnostics values operations careers". No values round is detected, so section 10 is absent either way |
| 2. Quillmoor Diagnostics interview process, operations | unavailable | No call sent: search was refused on target 1. Would have set the loop. The recruiter's own account of the call sets this one session, so no archetype is used |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | No call sent. Would have fed a CO question. The pack carries no CO question |
| 4. Interviewer name and company | skipped | The recruiter's own message fixes the call's agenda and register, which set the persona weights. Her public path would change only a reverse question, which the upgrade menu offers |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions |

A further search outside the declared targets: "Quillmoor Diagnostics Avonmouth Bristol". Refused. Moved nothing.

## Upgrade menu

- Your notice period → A5 becomes a stated answer, not an instruction
- The program your stock-count spreadsheet ran in, and any dispatch figures you reported → F5 and F6 move from discovery to a quoted answer
- Hannah's description of any values or competency round, if she names one → a values section and a reweighted Prober
- Search access on a later run → the values, interview-process and strategy targets, so the pack carries Quillmoor-specific content
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence carried into these banks, with no re-asking
