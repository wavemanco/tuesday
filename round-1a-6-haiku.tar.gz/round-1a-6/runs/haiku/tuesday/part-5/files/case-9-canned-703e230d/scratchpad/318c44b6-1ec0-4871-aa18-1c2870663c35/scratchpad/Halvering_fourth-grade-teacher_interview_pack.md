# Halvering Elementary School: Fourth Grade Teacher panel prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel: Principal Dolores Vantongeren and two fourth-grade team members (names not given)
**Built from:** your message, your CV as you pasted it, the HR invite, and the district's own hiring and values pages. No job posting was supplied.
**Size:** 16 questions. That is under the usual 18 to 26, because the invite gives one requirement line; the posting would fill that out (upgrade menu).

## How to use and type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive
- **JD**: role requirement
- **CO**: company and strategy knowledge (none in this pack, see Sources)
- **CASE**: live problem

Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it in your CV's terms: "Illinois Professional Educator License, Elementary Education (grades 1–6) endorsement, active through June 30, 2029." Confirm the license against the state's records before Thursday; that check is yours. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Adjacent work, not the grade: the quote carries third grade. Words: "For six years I taught third grade at a public elementary school in Joliet. I've never taught fourth grade." Answer slot: if any of that third-grade work carried into fourth grade in a way that was yours, say which; if none did, say so and say what you would do first. |
| F3 | "our fourth-grade team" (invite; the panel is drawn from the team, and the role is implied to sit on it) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [grounded] | transferability | Adjacent: a curriculum move led within a grade level, not team leadership. Words: "In 2024 I led our grade level's move to a new reading curriculum." Plain acknowledgment: "I've never been a team lead." Answer slot: which parts of the move were yours to decide, and how the team decided the rest; if the team decided together, say so. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Negative you stated, F2 | "I've never taught fourth grade." No slot. |
| Team leadership ("I led a team") | Inflated form of F3 | F3's quote at its own scope. The limit is this pack's observation, not words for you: your material says a curriculum move, not a team. |
| "I've been a team lead" | Negative you stated, F3 | "I've never been a team lead." No slot. |
| Reading-club results (scores, growth, attendance) | Inflated form of "I've run the after-school reading club for the last two years" | That sentence at its own scope. Your material says you ran the club; it gives no outcomes. |
| A school-wide family-communication program | Inflated form of "I write a weekly email to families" | That sentence at its own scope. |

## Reading the interviewer

**Principal Dolores Vantongeren** (public footprint only):
- Principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- 2025 forum talk, "Small Groups, Big Readers," on weekly reading conferences in grades 3 to 5.

Implications:
- Reading is her home ground. Expect reading questions from her, and expect the 2024 curriculum move to get probed.
- Mirror opportunity shared with her professional work: reading, and grade 3, which is inside the range of her talk. This is a shared domain, not a shared identity.

**The two team members:** no names were given, so there is no read. Persona weights for them below are the peer prior only.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes F2 and F3 directly: why you for fourth grade, and whether you've led anyone | High, weight 5. Two of the three fit rows are gaps, and the principal is the one who can act on them. | Bridge from quoted work only. Hold, then concede plainly. Never bluff a fourth-grade or team-lead claim. |
| Peer Evaluator | The grade-level team asks what you need and what you'd bring | Medium-high, weight 3. Two of three panelists are peers, so collegial seam questions are likely. | Reciprocity: what you bring the team, not only what you need. |
| Case / Strategist | A reading-instruction problem, because the district's hiring page says panels ask about reading instruction | Medium, weight 3. Live problems are the usual way to test that topic. | Clarify, then structure, then name your assumptions. |
| Values / Behavioral | Families and assessment, because the district's published beliefs and its hiring page both name them | Medium, weight 3. Family work is a named panel topic. | Map to what you actually did. Where nothing is quoted, use a selection scaffold with its honest branch. |
| Conversational | A warm opener, and "any questions for us?" | Low to medium, weight 2. Casual openers are still scored. | Keep a 90-second arc ready. Never answer the reverse-question slot with "I think you've covered everything." |

Round structure: the district's hiring page establishes one 45-minute building panel, so this is session mode. No values-style round is named, so no values cheat sheet is included.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What would you do in your first two weeks to learn where your students are?" | JD | [grounded] "I've never taught fourth grade" | Plain acknowledgment: "I've never taught fourth grade." Then a plan, said as a plan and never as a past: how you would learn where your students are. Hold by returning to the plan. | F2 is the gap the panel will test first. The answer is a plan, not a claim. |
| A2 | "For six years you taught third grade. What carries over to fourth, and what do you have to learn?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Story-mapped on F2. Say the sentence in your own words: "For six years I taught third grade at a public elementary school in Joliet." Then name what carries over and what you'd learn. Answer slot: if any of it carried over in a way that was yours, say which; if none did, say so. Hold through two follow-ups. Concede plainly: "I haven't taught fourth grade, and I'd learn it with the team." | **Highest-ROI prep in this pack.** The single most predictable objection is F2, and this is where the material is thinnest. Rehearse the concession until it is boring. |
| A3 | "Have you ever led a team of teachers?" | EXP | [grounded] "I've never been a team lead" | Plain acknowledgment: "I haven't been a team lead." Then the quote from F3 at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Hold: the move, not a team. Answer slot: which decisions in the move were yours, and how the team decided the rest. | F3 is the team-lead gap, and the panel may ask it outright. |
| A4 | "Why should we hire you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold on what the third-grade years and the 2024 move give you, in your words. Concede: "A candidate with fourth-grade years starts further along on the grade's routines. I'd come ready to learn them with your team." Hold through two follow-ups. Do not fold to "I'm just as ready." | Hold-then-concede. The position you hold is the one your quotes carry, and nothing more. |
| A5 | "Your Illinois license runs through June 2029. What does the elementary endorsement cover?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | State the license and its dates in the CV's terms. State the endorsement's scope only as the quote gives it: grades 1 to 6. | Covers the invite's one hard requirement. The gate is met on your own statement, so this is a fit probe, not a gate question. |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from a grade-level team to do well here, and what would you bring to it?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity. What you bring is the 2024 move, in the quote's terms. What you need is stated as a question you'd ask first. Answer slot: which part of the move was yours to decide, and how the team decided the rest. | Peer seam. Reciprocity is the answer a peer is listening for. |
| B2 | "Tell us about a disagreement with a colleague over a plan. How did it end?" | VAL | [generic] | Selection scaffold: "pick a disagreement where you both kept working together. If none comes to mind, say so plainly, then give the nearest thing your material carries: the 2024 reading curriculum move." | Open prompt, theme from the Peer persona stem. |
| B3 | "When a grade-level project works, how do you handle credit?" | VAL | [generic] | Name the people in the work and the part that was yours, in your own words. | Persona stem on credit-sharing. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads well below grade level in a class that is otherwise on track. What's your first move?" | CASE | [generic] | Clarify first: what was measured, and how. Then a small step, and say who you would check with. Do not invent data. | Live problem. It asks about no past and presupposes nothing about you. |
| C2 | "The panel asks about reading instruction. Walk us through how you'd structure a week of reading in fourth grade." | JD | [inferred] "Panels ask about reading instruction, classroom routines and how you work with families" (the district's hiring page) | Structure first: time, groups, and how you'd check progress. State your assumptions. Describe your plan, not a practice you have run. | The district's page names reading as a panel topic. [inferred] because a page's topic is not this team's practice. |
| C3 | "A curriculum isn't landing with half of a grade. What's your first step?" | CASE | [generic] | Clarify what "isn't landing" means and how you'd know. Then talk with the team before changing anything. | Live problem on the curriculum theme. No claim about your past. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Families Are Partners: each teacher speaks with every family each term. How do you do that?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the quote: "I write a weekly email to families." Answer slot: if you've spoken with families one-to-one each term, say how, in your words. If you haven't yet, say so, and say how you would reach every family each term. | Values theme drawn from the district's published belief, which is a raising source. |
| D2 | "Tell us about a time a family disagreed with a decision about their child." | VAL | [generic] | Selection scaffold: "pick a time a family pushed back and you stayed in the conversation. If none comes to mind, say so plainly, then give the nearest thing your material carries: the weekly family email." | Open prompt on the panel's family topic. |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. Tell us about a time an assessment changed what you taught." | VAL | [generic] | Selection scaffold, with the same honest branch as D2. Name the assessment, what it showed, and what you changed. Say plainly if none did. | Open prompt on the district's third published belief. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years" | A 90-second arc with each beat from a quote: six years of third grade, the 2024 curriculum move, two years running the reading club. Answer slot: if you have a reason for fourth grade, say it in your words. The material does not state one. | Casual register, still scored. The arc is the same one every other panelist will hear. |
| E2 | "What are you reading with your students right now?" | VAL | [generic] | Name a title only if you use it with students. If you don't use a title, say how you choose what to read. | Casual question on a reading topic the principal probably cares about. |

## Requirement coverage

| Requirement or panel topic | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1, A5 |
| Fourth Grade Teacher position (invite) | F2, A1, A2, A4 |
| Our fourth-grade team (invite) | F3, A3, B1, B2, B3 |
| Reading instruction (district hiring page) | C1, C2, C3, E2 |
| Classroom routines (district hiring page) | none, and why: no sentence of yours carries routines, and a routines question would ask for a practice you haven't stated |
| How you work with families (district hiring page) | D1, D2, E1 |
| "Every Child a Reader" (district belief) | C2 |
| "Teach for Tomorrow, Not for the Test" (district belief) | D3 |

## Reverse questions

1. **"What does a first month look like for a new fourth-grade teacher here?"** Why it lands: shows you have thought about the grade you haven't taught.
2. **"How does the team plan reading across the grade?"** Why it lands: asks about the panel's own topic, of the people who run it.
3. **"You came to Halvering after nine years as a reading specialist. What did that work teach you about reading in small groups?"** Why it lands: ties to the principal's own path, and turns a formal panel into a conversation with a peer about reading.
4. **Reciprocity, for the peers: "What could a new person do in the first month that would genuinely help your team?"** Why it lands: asks what you can give, not only what you need.
5. **"How do families here hear from teachers during a term?"** Why it lands: connects to the district's Families Are Partners belief.
6. **"What happens after the panel, and who will I hear from?"** Why it lands: asks about the next step without questioning the invite.

## Sources

Research tier: L1, searches 3 of 6, fetches 2 of 2; user links read 0.

Queries and results:
1. "Halvering Elementary School Orrinsford Community School District values" returned https://orrinsfordschools.example/about/mission-and-beliefs (fetched)
2. "Orrinsford Community School District fourth grade teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers (fetched)
3. "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Three published beliefs: Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test. These are the raising sources for D1 to D3 and C2. No values cheat sheet, because no values-style round is named. |
| 2. Interview process, fourth grade | yes | One 45-minute building panel: principal and two grade-level teachers. Topics are reading instruction, routines and families. This establishes session mode and sets the persona weights. |
| 3. Strategy or recent news | unavailable | Not run. Would have moved a CO bank, which this pack does not have. Offered on the upgrade menu. |
| 4. Interviewer name | yes | Principal's public bio and 2025 talk. Moved the interviewer read and the reading emphasis in the persona weights. The team members were not named, so no call was sent for them. |
| 5. Representative JD | unavailable | Not run. The invite is the only role text supplied, and the district's page gives the panel's topics. A posting would make F2 and F3 more than one line each. |

## Upgrade menu

- **The job posting's full text** → F2 and F3 move from one invite line each to the posting's own requirements, and the JD-tagged questions rest on those.
- **The two team members' names** → their public footprint, and persona weights set per panelist rather than from the peer prior.
- **The HR office's note on focus areas, or any teaching demonstration** → coverage of that deliverable as its own build section.
- **Prep time before Thursday** → a prioritized schedule, with A2 first.
- **A deeper research pass (L2)**: up to 6 more searches and 2 more fetches, several more minutes. It would add the district's strategy brief for CO questions. Want it?
