# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Relationship read: likely your day-to-day manager, so weight toward a hiring-manager round.

## How to use

Personas are how the question is asked. Types are what is being scored: **JD** (the listed job), **EXP** (what you actually did), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values). Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are the ad as you described it. The full ad text would let these rows quote it exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says you ran an appointment book for four people. Say that, in those terms. Answer slot: if you moved or coordinated across their diaries, say how; if not, say so and stay with the book. |
| F2 | Booking travel (ad) | none given | none given | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly. |
| F3 | Preparing documents in Word (ad) | "good with Word" — your message | low | [grounded] | discovery | A self-rating, with no document behind it. Answer slot: name one document you produced in Word and what it was for. |
| F4 | Preparing documents in Excel (ad) | "okay with Excel" — your message | low | [grounded] | discovery | A self-rating, with no task behind it. Answer slot: name one thing you did in Excel and what it produced. |
| F5 | Processing supplier invoices (ad) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing is adjacent to processing, not the same work. Your bridge is the chasing, at its own scope. Answer slot: if you touched any step beyond chasing (entering, matching, approving), say which. |
| F6 | Remote working: hours and availability (ad) | Your material does not establish this | none given | [grounded] | hard_gate | Your material does not show whether you can meet the role's hours or time zone. Surfaced, not bridged. Asked in the closing questions. |

Seven rules applied: confidence, provenance and gap type hold one token each. Quotes are yours, unchanged. Gap wording comes only from quotes or answer slots. F3 and F4 are low because they are self-ratings. F6 is a gate, so it is surfaced and never bridged.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Booked travel for an organisation | Inflated form of F2; the ad's requirement, not your material | Nothing. F2's answer slot asks only what you have booked |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: you chased unpaid invoices. Your material says chasing, not processing |
| Expert in Excel or Word | Inflated form of F3 and F4 | "good with Word", "okay with Excel", in your own words |

The limits above are this pack's observation of your material, not things you must say about yourself.

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Your background is a clinic. Why would this work?" | High. The ad lists four tasks and your material covers two of them. | Name what carries across, and answer F2 and F5 plainly |
| Case / Strategist | A practical scenario: move three meetings, book a flight | Medium. A 30-minute call with an office manager often includes one scenario. | Clarify first, then say the steps in order |
| Conversational | "Walk me through your background" | Medium. A short opener is normal in a 30-minute call. | A 90-second arc from your own sentences |

Skeptic carries the most questions. Persona weights rest on the relationship read, not on the company's documented process.

## Question banks

### Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is a clinic. What makes you think this role fits?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Name what carries across: the appointment book for four people, and the front-desk work. Answer slot: name any admin task beyond that; if you have none, say so plainly. | F1 and F2 are the likely probes. This is the highest-ROI prep in this pack. |
| A2 | "Tell me how you'd process a supplier invoice from receipt to payment." | JD | [grounded] "chased unpaid invoices" — your message | Start from what you did, chasing. Answer slot: if you handled any step beyond chasing, say which; if not, say you chased payments and describe how you would learn the approval step. | F5's transferability. The premise is the ad's, and the guidance does not adopt it as your practice. |
| A3 | "Tell me about a time you had to keep someone's diary organised under pressure." | EXP | [grounded] "ran the appointment book for four physios" — your message | Open prompt: choose a real instance from the appointment book. If none comes to mind, say so, then give the nearest thing your material carries. | F1. Your own sentence is the story. |

### Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "good with Word"; "okay with Excel" — your message | A 90-second arc: the clinic, the book, the invoices you chased, Word and Excel as you rated them. Use only these facts. | Sets the scene before any probe. |
| B2 | "What are you doing with Excel these days?" | JD | [grounded] "okay with Excel" — your message | Say what you actually do in Excel, in your own words. Answer slot: if you use it for nothing yet, say so. Do not upgrade "okay". | F4. |

### Case / Strategist (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A director needs three meetings moved and a flight booked for next Tuesday. How would you approach it?" | CASE | [generic] | Clarify first: their calendar, the flight budget, any approval rule. Then state the steps in order. Make no claim about past bookings. | A live problem from F2. Asked as a plan, not a record. |

## Reverse questions

1. "What does a typical week look like, and how is it split between calendar work, documents and invoices?" Why it lands: shows you are planning for the real job.
2. "Which tools do you use for travel booking and invoice processing?" Why it lands: tests F2 and F5 without claiming either.
3. "How many people's calendars would I manage?" Why it lands: sizes the job.
4. "What are the hours and time zone for this role?" Why it lands: surfaces F6 directly.
5. "What happens after this call?" Why it lands: tells you the process. It is not a check on the invite.

No reverse question asks for contact details, the fee, the cheque, the bank details or the passport.

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Values cheat sheet would have been built. Not used, since no values-style round is detected |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Loop structure. Persona weights rest on your relationship read |
| 3. Company strategy / recent news | unavailable | Would have moved CO questions; none drafted |
| 4. Interviewer name | n/a | No name given |
| 5. Representative JD | unavailable | Would have moved the fit snapshot; the ad summary you gave stands in |

Searches sent, both refused: `Brennock Facilities Ltd values`; `Brennock Facilities Ltd interview process administrative assistant`.

Provided documents: your message and the invite pasted in it.

## Upgrade menu

- The full ad text, not a summary → the requirement rows quote it exactly and F2 and F5 can be checked against it.
- The office manager's name and role → a tailored reverse question and a persona read.
- One document you wrote in Word, or one Excel task → upgrades F3 and F4 from low to medium.
- `tuesday-dossier.md` → one line on what it would add: a record of these gaps for later sessions.
