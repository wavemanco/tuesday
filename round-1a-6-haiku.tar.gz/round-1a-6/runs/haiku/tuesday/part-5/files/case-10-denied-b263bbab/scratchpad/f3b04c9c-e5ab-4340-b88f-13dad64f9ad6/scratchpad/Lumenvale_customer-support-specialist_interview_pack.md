# Lumenvale Software: Customer Support Specialist (remote), interview prep

**Role:** Customer Support Specialist, remote
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given)
**Round:** text chat, one interview; the invite says offer and onboarding would also run in the chat
**Relationship:** team lead, so the priors are a hiring-manager round: live problems plus a skeptical read of the gaps

Built on your message, the job ad as you summarised it, and your background. No research was run (see Sources).

## How to use and type key

Personas describe how a question arrives. Types describe what is being scored.

- **CASE**: a live problem from the role, asked as a decision
- **EXP**: a deep-dive into your own past work
- **JD**: a requirement from the job ad
- **CO**: company knowledge (none rehearsed here; no research run)
- **VAL**: published values (none detected)

Guidance is scaffolding, not a script. In a text chat, aim for answers you could type in about 90 seconds.

## Fit snapshot

Quotes in the evidence column are your message unless noted. Requirements are quoted from your message, since that is the only ad text in hand.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, your message) | "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | No gap in the words. Expect a probe on how that work compares with support for a software product. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | The quote names a similar ticketing tool, so the requirement is reached in other terms. Words: "I use Freshdesk every day." Do not stretch this to Zendesk. |
| F3 | "clear written communication" (job ad, your message) | none given | none | [grounded] | discovery | Your material does not show written communication. This chat is itself a written sample. Answer slot: if a reply you wrote was acted on by a customer without a follow-up, say what it was and what happened; if none comes to mind, say so and say how you check a reply is clear before sending it. |
| F4 | "confidence handling escalations" (job ad, your message) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Training others on a process is adjacent to escalations and does not reach them. Words: "I trained four new starters on our refunds process last year." Limit: your material does not show escalations handled. Answer slot: if escalations reached you, say what you did with one, in your own words; if none did, say so and say how you would approach one. |

The software-company line in your message ("I've never worked for a software company") is not a requirement in the ad as you summarised it, so it has no row. It is the most likely objection, and it is rehearsed in B1 and D1.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material names Freshdesk. |
| Has handled escalations | Inflated form of F4 | F4's quote at its own scope. Your material names refunds training, not escalations. |
| Ran the refunds process | Inflated form of the F4 quote | The quote at its own scope: you trained four new starters on it. |
| Has worked in software support | Negative you stated: "I've never worked for a software company" | Plain acknowledgment: "I've never worked for a software company." No slot. |

## Personas

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live tickets: a refund that has not arrived, a missed callback, a handover | High. A team lead hiring for support tests judgement on live tickets, and the ad asks for escalations. | Structure before answering: confirm the facts, say what you can check yourself, say what you tell the customer, then when to escalate. |
| Skeptic | Probes on the software gap and the escalation gap | High. These are the visible gaps against the ad (F4, and the software line above). | Plain acknowledgment first, then a plan. Do not bluff product knowledge. |
| Data-Driven Prober | Questions on the 60-a-day figure and how it was counted | Medium. The figure is yours and will be probed. | Say how it was counted if you know; if you do not, say so. |
| Pressure | A short, time-boxed challenge on attribution | Medium. A chat limits interruption, but a challenge still comes. | Hold once; concede one specific point. |
| Conversational | A casual opener, or "why support, why remote" | Medium. Chat openers are often casual, and casual questions are scored. | A 90-second arc built from the F1 and F4 quotes. |

Weights: Case 5 questions, Skeptic 3, Prober 2, Pressure 2, Conversational 2. The pack is shorter than the usual range because the source material is short; the upgrade menu says what would add more.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer's refund has not arrived after ten days. What do you do first, and when do you pass it on?" | CASE | [generic] | Structure it: check the refund's status and the order yourself; tell the customer what you found and when they will hear next; pass it on when you cannot resolve it yourself, with the facts stated. | A live problem from the role. Makes no claim about your past. |
| A2 | "A customer says they were promised a callback yesterday and nobody called. Reply to them here, now." | CASE | [generic] | Acknowledge without grovelling; say what you will do and by when; promise only what you can keep. Keep it to a few sentences. | This is the interview's own medium, so the reply is scored as written communication. F3 has no quote, so the guidance makes no claim about past writing. |
| A3 | "An escalation lands on your desk, but the account owner is on leave and the fix needs engineering. What goes in the handover?" | CASE | [generic] | State the ticket facts, what was tried, what the customer was told, and what you need from whom and by when. Answer slot: if escalations reached you in a past job, say what you did with one, in your own words; if none did, say so and say how you would approach this one. | Covers the escalation requirement (F4). It is an answer slot because F4's quote does not carry escalations. |
| A4 | "How do you find a customer's earlier contacts when a new ticket arrives?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say the Freshdesk fact in those words, then describe how you find earlier contacts in your own words. Answer slot: if you have used a customer's history in the tool, say how you found it; if not, say you would look for the history view first. | Covers the ticketing-tool requirement (F2). |
| A5 | "A customer says the last agent promised them a refund. What do you check?" | CASE | [generic] | Check what was logged against what the policy allows. Answer slot: if you have had to check a promise against a record, say what you looked at; if not, say what you would look at first. | Tests judgement with a claim you cannot verify. Makes no claim about your past. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we trust you on our product?" | JD | [grounded] "I've never worked for a software company" (your message); "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | Plain acknowledgment: "I've never worked for a software company." Then the handling work: "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day." Then a plan to learn the product, said as a plan. Hold through two follow-ups by returning to the handling work. Concede one specific point: you will need time on the product. | Highest-ROI prep. This is the most likely objection, and a plain, non-defensive answer changes the interview. The plan is the only part that is not a claim about your past. |
| B2 | "Zendesk is what we use here. What's your experience with it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say the Freshdesk fact in those words. Answer slot: if you have used Zendesk, say what you did in it; if not, say so, and say the tool you use every day is Freshdesk. | Covers the F2 presentation gap. The answer must not stretch Freshdesk into Zendesk. |
| B3 | "Tell me about a written reply to a customer that worked, and how you could tell." | JD | [generic] | Selection scaffold: pick a reply where the customer knew what to do next and did not need a second contact. If none comes to mind, say so and describe how you check a reply is clear before sending. | Covers "clear written communication" (F3, no quote). Makes no claim about your past. |
| B4 | "What would you need to learn about our product in your first thirty days?" | JD | [generic] | Answer as an ordered plan: the product's main flows, the tools, the escalation path, then first tickets with a lead. Say it as a plan, never as something done. | An honest answer to B1's gap, and a question you can answer well. |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted, and which part of it was yours?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number in your own words. If you know how it was counted, say how. If you do not, say you do not know. If you know the assumption behind it you would defend least, name it; if not, say so. | F1 is the evidence for the experience requirement and the likeliest place to be probed. Defend-the-number slots, as the rubric sets them. |
| C2 | "Walk me through how you trained the four new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Story-mapped beats the quote states: four new starters, the refunds process, last year. Answer slot: what the training covered and how you checked they had it; if you checked, say how; if you did not, say so. | F4's quote. The checking is a practice the quote does not state, so it is a slot. |
| C3 | "How did you know a customer's problem was solved, and not just closed?" | JD | [generic] | Selection scaffold: pick a ticket where you checked with the customer after closing. If none comes to mind, say so and describe how you would check. | Quality-minded support, tested on a practice. Makes no claim about your past. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has worked in software support?" | JD | [grounded] "I've never worked for a software company" (your message); "answering around 60 calls and emails a day" (your message) | Hold once: you have not worked in software support, and what you have is three years answering around 60 calls and emails a day. Concede one specific point: a candidate from software support will know the product sooner. Do not argue that you are the better fit. | The pressure counterpart to B1, with the concession named before it is asked for. |
| D2 | "Who set the refunds process you trained them on?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you set any part of the process, say which part and how you decided; if you did not, say you trained others on the process as it was. Do not add to the process. | Tests attribution against F4's quote. The second branch lets the honest answer be that you did not set it. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into customer support." | EXP | [grounded] "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | A 90-second arc: how you started, the energy supplier, the daily volume, the refunds training. Each beat is a clause the quote states. | A casual opener, still scored. |
| E2 | "Why support, and why remote?" | EXP | [generic] | Give the reason you actually have. If remote work is new to you, say so, and say how you would set up your day. | No quote states a reason, so the guidance supplies none. |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| 2+ years in customer support | A4, C1, E1 |
| Zendesk or a similar ticketing tool | A4, B2 |
| Clear written communication | A2, B3, C3 |
| Confidence handling escalations | A3, A5, C2, D2 |

## Reverse questions

Each has a "why it lands" line.

1. "What does a typical escalation look like here, from first contact to resolution?" Why it lands: shows you are thinking about the handover, which is the escalation requirement.
2. "How do new starters learn the product in their first month?" Why it lands: turns the software gap into a practical question you can ask well.
3. "What would make a first month here go well, from your side?" Why it lands: the answer tells you the bar.
4. "Which tools sit alongside the ticketing system day to day?" Why it lands: shows you think of support as more than one tool.
5. "How does the team handle a ticket that needs engineering?" Why it lands: follows on from the handover question and shows you have thought about where escalations go.

## Sources

- Provided documents: your message (the invite's text, your summary of the job ad, your background).
- Research tier: L0, provided documents only. No search or fetch was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Not run at L0; the values section is dropped because no values were detected. |
| 2. Lumenvale interview process, support role | unavailable | Loop structure. Not run at L0. The round is described in the invite as a single text chat. |
| 3. Lumenvale strategy / recent news | unavailable | Grounding brief and CO questions. Not run at L0. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative job ad | skipped | The ad you summarised fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The full job ad text → each requirement becomes a grounded row, and the coverage line is checked against the full list
- Consent to L1 research on Lumenvale's public pages → company values, the interview process and recent support context become grounded, with sources
- The team lead's name → persona weights and a tailored reverse question, from public professional footprint only
- A tuesday-dossier.md → verified evidence per requirement and a sharper rehearsal of the likeliest objection
