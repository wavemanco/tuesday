Before anything else: the invite has a warning sign. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "your offer and onboarding will be completed in this chat as well". A process run wholly by chat leaves open who is on the other end, and a chat alone doesn't show you who you are dealing with. Until you've confirmed who sent it, don't send documents, ID, bank details or any payment through this chat. Check through contact details you find on Lumenvale's own website or careers page, not any number, handle or link in the invite. job-underwriter can check the posting and the invite if you ask for it separately. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-5-rooms-case-10-denied-b81fa261/64789fd2-f15b-4503-8891-2f6c3d41c9b5/scratchpad/lumenvale_customer-support-specialist_interview_pack.md. I built it for a chat with the team lead, which I treated as a hiring-manager round, since the invite doesn't name the team lead. Company research didn't run because the search permission was refused, so the pack has no Lumenvale facts yet. The upgrade menu says what would add them.

**Highest-ROI prep:** question A1, "You haven't worked for a software company. What would make you effective in ours?" It's the most likely objection, because your lack of software experience is the gap on this ad. Say the acknowledgment first, then the work that carries over. Say the word and I'll play the Skeptic on A1.

Your three key lines to rehearse are "answering around 60 calls and emails a day", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year". Don't stretch any of them. The pack lists the inflated versions to avoid, such as "Ran the refunds process" and "Set up or ran Freshdesk".

Drill offer: I can run one live round with the Skeptic or the Case persona, with follow-ups that react to your answers.

Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed.

If you want the pack as a Word document, say so and I'll convert it.

Three questions:
1. Will the support team lead be your manager, or someone else on the team?
2. Can you paste the full ad? That turns the four requirement rows into exact quotes instead of your summary.
3. Does the ad name a location, time zone or right-to-work condition for this remote role?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote) at Lumenvale Software

**Role:** Customer Support Specialist, remote
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given). Relationship: treated as hiring manager, since the invite says the chat is with the team lead.
**Format:** a text chat on Telegram. Every persona below arrives as a written message, so rehearse by typing your answers.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken or typed answer, not a script.

Type key:
- **VAL**: behavioural and values alignment
- **EXP**: a deep-dive into your own work experience
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live, hypothetical problem

Requirements below are quoted from your summary of the ad. Paste the full ad to make them exact.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap in the years. Expect a probe on whether energy-supplier service is the same work. Say it in your words: "3 years as a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is a ticketing tool of the same kind, so say it as you used it: "I use Freshdesk every day." Do not claim Zendesk experience. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Emails are written work, but your material does not show how clear they were. Answer slot: if a written reply of yours was checked or praised, say what it was. If none was checked, say so, and say how you would check your own writing in the first month. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material says nothing about escalations. Answer slot: if you handled escalations, say what you did. If you did not, say so plainly and say how you would handle one. |
| F5 | (not in the ad) working in a software company's support team: plain prose, [generic] | "I've never worked for a software company" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. |
| F6 | a location, time-zone or right-to-work condition for a remote role: plain prose, [generic] | none given | none | [generic] | hard_gate | Your material does not establish this gate. The one question on it is in the message that presents this pack. |

## Prohibited claims

Each entry names its basis. None of these may be asserted, softened or implied in an answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | The quote at its own scope: "I trained four new starters on our refunds process last year." Limit, in the pack's analysis: your material says you trained on the process, not that you set it. |
| Answered 60 contacts a day alone and resolved them all | Inflated form of "answering around 60 calls and emails a day": it adds "alone" and "resolved" | The quote at its scope, with "around" kept: "answering around 60 calls and emails a day." Limit: resolution is not in your material. |
| Set up or ran Freshdesk | Inflated form of "I use Freshdesk every day" | The quote at its scope. Limit: your material says you use it, not that you administer it. |
| Software-company experience | Negative you stated: "I've never worked for a software company" | Plain acknowledgment: "I've never worked for a software company." No answer slot. |

## Persona table

| Persona | How it shows up in a text chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A written scenario from a real ticket | High. A team lead is buying capability, and a chat is the simplest place to run a scenario. | Clarify first, then write the first reply, then answer the follow-up. |
| Skeptic | Short messages probing F4, F5 and the Freshdesk-for-Zendesk gap | High. The background gap is visible on the ad, and the chat is where it gets tested. | Acknowledge the gap plainly, then bridge only from what you have stated. |
| Data-Driven Prober | Asks for the figure behind the 60-a-day number | Medium. The one number on your material is a likely target. | Defend the number in your own words, as given. |
| Conversational | Opens with "walk me through" | Medium. A usual opener, and still scored. | A 90-second arc built from your own three beats. |
| Pressure | Terse follow-ups that hold you to one claim | Low. A text chat applies less pressure than a call, though it can still be sharp. | Hold the claim through two follow-ups, then concede the specific uncertainty. |

Weights: Skeptic 5 questions, Case 5, Prober 3, Conversational 2, Pressure 2. The Skeptic and the Case persona carry the most weight: the background gap is the biggest risk in the material, and the written scenario is the most likely format.

## Question banks

### Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. What would make you effective in ours?" | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "answering around 60 calls and emails a day" (your message) | Plain acknowledgment: "I've never worked for a software company." Then the work that carries over, in your words, from "answering around 60 calls and emails a day" and "I use Freshdesk every day." Answer slot: how you would learn their product, said as a plan, not as a past. Never claim software experience. | **The highest-ROI prep in this pack.** It is the most likely objection, because F5 is the gap this candidate carries. Rehearse until the acknowledgment comes first. |
| A2 | "The ad asks for Zendesk or a similar tool. How quickly could you work in it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say the daily use in your words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where. If you have not, say so plainly and say how you would learn it. Do not claim Zendesk use. | F2 is the presentation gap, and a probe on "similar" is a sharper version of this question. |
| A3 | "Tell me about a time a customer's issue had to be escalated. What did you do?" | JD | [generic] no quoted sentence carries an escalation. The raising source is the ad: "confidence handling escalations" (your message). | Open prompt, so you choose the instance: a case that went beyond first-line handling, the stake, and what you did next. Answer slot: if none comes to mind, say so plainly, then say how you would handle one. | F4 is silent on escalations, so this is a discovery gap. The answer has to come from a case that is yours. |
| A4 | "What's drawing you to this role?" | JD | [generic] no sentence of yours gives a reason | Instruction in your own words: give your actual reasons. The pack holds none of them, so none is written here. | The Skeptic checks motivation consistency. A reason you can say plainly beats one built for the chat. |
| A5 | "The ad asks for two years or more in customer support. What did your three years cover?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Say the three years in your own words. Your material gives the role and the volume, and nothing more about the duties, so describe the duties you actually did. | Covers the years requirement. The question scores whether those years were the same work. |

### Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that a refund has not arrived after three weeks. Walk me through your first three replies." | CASE | [grounded] "I trained four new starters on our refunds process last year" (your message) | Structure: clarify the facts, check the refund's status, then tell the customer what you will do and by when. Name the steps only as you ran them, in your own words. Do not promise a date you cannot confirm. | Refunds is your strongest documented process. A team lead will test whether you know it from the inside, not only from having trained others. |
| B2 | "A customer says they will complain to a regulator if they don't hear back today. What do you write?" | CASE | [generic] | Structure: acknowledge, state what you can confirm now, and name who owns the next step and when. Answer slot: if you have handled a complaint like this, say what you did. If not, say how you would route it. | Tests escalation judgement in the written channel the role uses. |
| B3 | "A customer was charged twice. Write the reply you would send, in four lines or fewer." | CASE | [generic] | Write it as you would send it: what happened, what you are doing, what happens next. Check that every promise in it is one you can keep. | Clear written communication is in the ad, and the reply is the evidence. |
| B4 | "A customer says the app is broken. How do you tell a bug from user error before you escalate?" | CASE | [generic] | Scaffold: ask what they did and what they saw, check the known issues, then escalate with the steps. Do not claim engineering or product experience. | A live problem from the role. A good answer shows judgement without a software background. |
| B5 | "A customer says a reply they got was wrong. What do you check first?" | CASE | [generic] | Scaffold: the ticket history, what was promised, and what was actually sent. Say the order you would check them in. | A second written-channel question, so the written skill is tested twice. |

### Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handle around 60 contacts a day. How many were calls, how many were emails, and how many did you close?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number: say it as you gave it, with "around" kept. Name the weakest assumption: the figure is an estimate. Answer slot: if you know the split or the closed count, say how you know. If you do not, say so plainly. | The one figure on your material is the likeliest probe target. It has no split, so say that. |
| C2 | "Which Freshdesk features do you use every day?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Name the features you actually used, in your words. Answer slot: if you can name only a few, name those and say you have not used the rest. | A probe on F2. The tool answer has to be specific to be believed. |
| C3 | "You trained four starters on refunds. How did you check they could do it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Describe what you covered and how you checked it. Answer slot: if you checked them by a method, say which. If you did not check formally, say so. | Training shows process knowledge. The check question tests whether the method was yours. |

### Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey to support work." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message) | A 90-second arc in this order: the energy supplier, the daily Freshdesk work, then the training. Use only these beats. Do not add a promotion or a reason you did not give. | A rapport opener is still scored. Your three sentences, in order, are the arc. |
| D2 | "What would you want to get right in your first month?" | JD | [generic] | Name, as plans, the first thing you would learn, the tool, and the escalation route. Anchor each one in your own material, in your words. | A casual question on a topic the ad raises, and it is scored. |

### Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has done this in software?" | JD | [grounded] "I've never worked for a software company" (your message) | Hold: "you have answered around 60 calls and emails a day, and you have not worked in software," said first. Concede specifically: you would need to learn the product, and say how. | The held position is the one you can back: your energy-supplier work. The concession is the learning plan. |
| E2 | "That 60-a-day figure. How much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold: say what you answered, in your words, and keep "around". Concede specifically: if any of it was handed on or shared, say so. Answer slot: if none of it was shared, say so. | Pressure on the one number. The hold is the number as given, not a bigger one. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | A5, D1 |
| Zendesk or a similar ticketing tool | A2, C2 |
| Clear written communication | B3, B5 |
| Confidence handling escalations | A3, B2 |
| Location and time zone for a remote role | none: the ad's terms are not in your summary. See the upgrade menu. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a typical first week of tickets look like?" | It shows you are planning for the work itself. |
| 2 | "Which ticketing tool does the team use day to day, and how is it set up?" | It settles the tool question you cannot answer yet, and shows you know the tool is the risk. |
| 3 | "How do escalations move from first line, and to whom?" | It shows you think in routes, not heroics. |
| 4 | "How is the quality of written replies checked?" | It tests the written-communication requirement from their side. |
| 5 | "What would the first 30 days cover, and what training comes first?" | It shows you are planning for ramp-up, which the Skeptic wants to see. |
| 6 | "Will there be another step after this chat before any offer?" | A prep reason only: it tells you how many rounds to prepare for. |

No interviewer profile exists, so no reverse question ties to the interviewer's path.

## Sources

Provided documents: your message (your summary of the ad, and the invite text as you pasted it).

Research tier: L1. Searches: 0 of 6 returned results. Fetches: 0 of 2.

Searches sent:
- "Lumenvale Software customer support specialist careers": refused (search permission was not granted).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have fed a values cheat sheet. None is detected from this invite, so it would not have changed the pack. |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure. The invite itself establishes the loop: one text chat with the support team lead. That comes from the recruiter's own words, so no archetype fallback is used. The search was refused. |
| 3. Lumenvale strategy / recent news | unavailable | Would have fed the CO questions. The bank has none, because this research did not run. |
| 4. team lead's name and Lumenvale | n/a | No name was given for the team lead. Marcus Hale is the recruiter, not the interviewer. |
| 5. representative customer support specialist JD | skipped | The ad summary you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The full ad text → the four requirement rows quote the ad exactly, instead of your summary.
- The team lead's name and title → persona weights from their public footprint, and a reverse question tied to their path.
- The ad's location, time-zone and right-to-work terms → gate row F6 gets an answer.
- Permission to search for Lumenvale's own careers and values pages → targets 1 to 3 run, and the pack gets company facts.
- A tuesday-dossier.md from an earlier session → the gaps here are sourced rather than inferred.
