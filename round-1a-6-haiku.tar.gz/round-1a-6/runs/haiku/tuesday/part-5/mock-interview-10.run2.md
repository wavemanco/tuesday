Before the prep, one thing in the invite. It says "your interview will be a text chat here with our support team lead" and that "if you are successful your offer and onboarding will be completed in this chat as well", and that "our hiring process is fully remote and is carried out entirely on Telegram." A hiring process run wholly by chat does not show who you are dealing with, so until you have checked it, send no money, documents or bank details through the chat. To check, use a phone number, email or careers contact from Lumenvale's own website, not anything in this chat. I can't verify the sender from here. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite checked as a separate request, job-underwriter can do that.

Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/tuesday/part-5/rooms/case-10-denied-c85674ab/lumenvale_customer-support-specialist_interview_pack.md. I built it for a first interview with the team lead. Web research was refused in this session, so it rests on your message and the invite only: no values, no interview loop, no company news. The prep centres on the gap the ad asks about most directly, escalations: your message shows refunds training, not escalations handled. Expect that probe first.

I can also rehearse it as a drill, playing the Skeptic on A2, the question the pack names as the highest-return prep. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. And I can convert the pack to a Word document if you want one.

Is this chat the whole interview, or does a call or video step follow it? That changes how much of the pack to rehearse for the chat.

Could you paste the full text of the job ad? If you'd rather not, I'll work from your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given in the invite)
**Relationship:** hiring manager. Round: first interview, as a text chat. A later step is not known yet.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **Skeptic:** probes the gaps between your CV and the ad.
- **Case / Strategist:** gives a live problem from the job and scores how you structure it.
- **Conversational:** opens the chat with a friendly prompt. Casual questions are still scored.

Type key:

- **EXP:** what you actually did
- **JD:** can you do the listed job, gaps included
- **CASE:** a live problem, structured out loud
- **VAL:** behaviour against stated values (not used here; no values were found)

The guidance is scaffolding, not a script. Say it in your own words. Where a line reads "answer slot", the interviewer's probe is likely and the answer is yours to give.

## The fit snapshot

Requirements come from your summary of the ad, not its full text, so none are in quotation marks. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap: the three years are stated. Expect a probe on what those years covered; answer it in your own words. |
| F2 | Experience with Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar tool in daily use, and the quote reaches the requirement. Your material shows Freshdesk only. Do not stretch it to cover Zendesk. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows the volume of emails, not how clear they were. Answer slot: if you have a written reply, explanation or refund message you wrote, describe what it said in your own words. If none stands out, say so and describe how you write a clear reply. |
| F4 | Confidence handling escalations (your summary of the ad) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | The quote is about a process you taught, not escalations you handled. Answer slot: if you handled an escalation, say what it was and what you did. If you did not, say so plainly and describe how you would decide when to escalate. |

Gap types: none of the four rows is a gate. The ad's experience length is graded on fit, not treated as a gate.

## Prohibited claims

These claims are not coached. Each is the stretched wording of a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Resolved 60 tickets a day | Inflated form of F1's volume quote. Your message says calls and emails. | "answering around 60 calls and emails a day." The pack's observation: your material says calls and emails, not tickets. |
| Led the refunds process | Inflated form of F4's training quote. Your message says you trained others on it. | "I trained four new starters on our refunds process last year." |
| Handled escalations | Inflated form of F4. The material does not show escalations handled. | The refunds-training quote at its own scope. The escalation question goes to answer slot A2. |
| Zendesk experience | Inflated form of F2. The quote names Freshdesk. | "I use Freshdesk every day." The pack's observation: your material shows Freshdesk only. |

## Persona table

| Persona | How it shows up in this chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks about the gap between your CV and the ad: tools, escalations, written work | High. A hiring manager for a support role buys capability and tests gaps. F2 and F4 are where a probe is most likely | Answer the gap in your own words. Do not stretch the quote to cover it. Hold the position through a follow-up before conceding anything real |
| Case / Strategist | Gives a live support problem and scores the structure of your answer | High. Support hiring managers often use a case to test how you prioritise | Clarify, then prioritise, then say what you will do first. Think aloud in the chat |
| Conversational | Opens with a friendly prompt about your background | Medium. Chat openers are friendly but still scored | Prepare a 90-second arc from your message. Do not improvise the biography |

Depth follows weight: Skeptic 5 questions, Case / Strategist 3, Conversational 2.

## Question banks

### Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which ticketing tools have you used, and for how long?" | JD | [grounded] "I use Freshdesk every day" | Lead with Freshdesk, in those words. Answer slot: if you have used Zendesk, say where and how. If you have not, say so plainly and stay with Freshdesk. | F2 is the evidence for the ticketing requirement, and a probe on the named tool is likely |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I trained four new starters on our refunds process last year" | This is the highest-return prep in the pack. Answer slot: if you handled escalations, say what they were and what you did, in your own words. If you did not, say so plainly, then say how you would learn the team's escalation path first. Hold the answer through a second follow-up by returning to the training you did, never by adding to it | F4 is the weakest requirement and the most likely objection. It is the one this interviewer is most likely to press |
| A3 | "I don't see escalation handling in your background. How would you handle the first one here?" | JD | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: describe how you would handle a first escalation, in your own words. Do not claim a past escalation the quote does not carry | F4 gap, asked as a live problem. The interviewer's line presupposes the gap the quote does not fill |
| A4 | "Your experience is calls and emails. How does a text-only chat change how you work?" | JD | [grounded] "answering around 60 calls and emails a day" | Say what you did in emails, in your own words, and what carries over to a written chat. Answer slot: if you have a specific written example, describe it. If not, say what you would check before sending a reply | F3 is the written-communication evidence. This is a chat, so the test is the chat itself |
| A5 | "Why do you want to move from energy into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; [grounded] "I've never worked for a software company." | Say what the energy years gave you and what you want next. Plain acknowledgment, if you choose to say it: "I've never worked for a software company." | The invite names a software company. The probe on the move from energy is likely |

### Case / Strategist (weight: middle)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says they were charged twice. What do you check first, and what do you tell them?" | CASE | [generic] | Structure: confirm the charge, check the record, say what you can promise and when, then reply. Do not promise a refund you cannot make | A live support problem. Tests structure and the refunds process |
| B2 | "You have 40 open tickets and two are escalations. What do you do first?" | CASE | [generic] | Clarify the deadlines, prioritise by customer impact, say what you will do first and why | Tests prioritising under load. Links to the escalation requirement (F4) without claiming escalation experience |
| B3 | "Write the first reply to a customer who is angry that a refund is late." | CASE | [generic] | Structure: acknowledge, say what you know, say what happens next and when, ask for nothing you do not need | Tests written communication in the medium of the interview itself (F3) |

### Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you got into customer service." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; [grounded] "answering around 60 calls and emails a day" | A 90-second arc: the three years, the energy supplier, the volume of calls and emails. Answer slot: if you want to mention the refunds training, say what you did in your own words | F1 is the opening evidence. A casual opener is still scored |
| C2 | "What part of the job do you do best?" | JD | [generic] | Pick one part of the job you did well and name what it was. If none stands out, say so and name the nearest thing your material carries: the refunds training | An open prompt. It scores whether you can name a strength without stretching it |

## Reverse questions

Ask these at the end. None of them checks the invite or asks the interviewer for contact details.

1. "What does a typical first month look like: how much is chat with the team, and how much is tickets?" Why it lands: it shows you are thinking about the job, not just the offer.
2. "Which ticketing tool does the team use day to day, and how is it set up?" Why it lands: it answers the tool question by asking it, and shows you know what matters.
3. "How are escalations passed on? Who decides, and how quickly is a reply expected?" Why it lands: it turns the weakest requirement into a question you can ask well.
4. "How does the team review written replies, and what does a good one look like?" Why it lands: it shows you care about the same thing the chat tests.
5. "What would make someone successful in their first 90 days?" Why it lands: it is a standard close that gives the team lead room to answer.

## Requirement coverage

| Requirement (your summary of the ad) | Question IDs |
|---|---|
| 2+ years in customer support | C1, A5 |
| Zendesk or a similar ticketing tool | A1 |
| Clear written communication | A4, B3 |
| Confidence handling escalations | A2, A3, B2 |

## Sources

- Your message, and the invite text you pasted.
- Research tier: L1. Searches 0 of 6 returned results. Fetches 0 of 2. One search was attempted and refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Search refused: "Lumenvale Software company customer support". No values cheat sheet |
| 2. Lumenvale Software interview process | unavailable | No search could run. Persona weights rest on relationship priors only, not the actual loop |
| 3. Lumenvale Software strategy and recent news | unavailable | No search could run. The grounding brief is absent |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative support-specialist job ad | unavailable | No search could run. Requirements come only from your summary |

Not used: the interviewer read, the values cheat sheet and graded deliverables. None had inputs.

## Upgrade menu

- The full text of the job ad → requirement rows F1 to F4 become quoted, and the question banks can quote its lines directly
- Your experience with Zendesk, if any → A1 and F2 get a stronger answer
- A written example you wrote in your job (a reply, a refund explanation) → F3 and A4 get a specific example to rehearse
- An escalation you handled, if you handled any → F4, A2 and A3 get the answer in your own words
- The interviewer's name and title, if the invite gives them → persona weights and a tailored reverse question
- `tuesday-dossier.md` → one line on what it would add
