Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-5-rooms-case-13-denied-24620a0b/a906e1b4-7fe5-40b2-9945-30c1777505e0/scratchpad/quillmoor_operations-coordinator_interview_pack.md`.

Research didn't run: web search was refused, so the pack has nothing on Quillmoor's values, interview process or recent news. It rests on the advert and your message.

For Thursday, the four topics Hannah named are where to start:

- **Pay:** say "I'm hoping for £42,000." The advert's band is £38,000–£44,000, so that sits inside it.
- **Notice period:** your message doesn't give one, so the pack tells you to give your actual figure rather than supplying one.
- **Hybrid:** "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- **Reason for moving:** keep it to what you wrote: the Bristol office is closing and the only offer is relocating to Reading.

The two gaps most likely to come up are SAP and production scheduling across planning, the warehouse and QA. The pack gives you a plain answer for each rather than suggesting you claim experience you haven't described. Your stock-count result is the strongest thing you have to say, and the pack flags that she may ask how much of it was yours.

Would you like a drill? I can play Hannah and run the pay and SAP questions with follow-ups. I can also save a `tuesday-dossier.md` recording the SAP and production-scheduling gaps for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Quillmoor Diagnostics, Operations Coordinator

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Changes since last version:** first version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements and the logistics), EXP (what you actually did), CASE (a live problem from the role).
- Guidance is scaffolding, not a script. Say the answers in your own words.
- Every claim about your past is quoted from your message to me. Quoted sentences are the only things you should say about your experience. Where the material is silent, the pack gives you an answer slot, not words.
- Research did not run (see Sources), so there is no company values, interview-process or strategy content. Everything here comes from the advert and your message.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | high | [grounded] | none | No gap. Say it as you wrote it: "4 years as a logistics coordinator at a building-supplies wholesaler." |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material carries deliveries across three depots, not production schedules across planning, the warehouse and QA. Keep the words at that scope: "I schedule deliveries for our three depots." Answer slot: if you have coordinated across planning, the warehouse or QA, say which and how, in your own words; if you have not, say so plainly and say what you would do first. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms. Words: "I chase suppliers when orders slip." Add no volumes or examples you have not given. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | high | [grounded] | none | No gap. Words: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The figure is "about a third", and it raises the defend-the-number slots in C1 and C2. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported on delivery timing to anyone, say what and how often; if you did not, say so and say what you would report first. |
| F6 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [grounded] | discovery | The quote touches Excel without showing your level. Answer slot: if you built that sheet in Excel, say which features you used and how confident you are; if it was another tool, say which. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never used SAP." Then, in your words: "We run our own in-house stock system." Then how you would learn an ERP tool, said as a plan and never as a past. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | No gap. Your words are the answer: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

Your pay, notice and reason for moving are logistics, not fit rows. They are covered in the Conversational bank (A1, A2, A4).

## Prohibited claims

Not coached, and why. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any SAP or ERP experience | Negative you stated, F7 | "I've never used SAP." No slot. |
| Ran or owned stock control, or the stock accuracy process | Inflated form of F4 | The material says you rebuilt the stock-count spreadsheet. Keep it at that scope: "I rebuilt our stock-count spreadsheet." |
| A sharper figure than "about a third" | Inflated form of F4 | "About a third", as you wrote it. |
| Coordinating production schedules across planning, the warehouse or QA | Inflated form of F2 | F2's quote at its own scope. Your material says deliveries across three depots. |

## Persona weights

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Conversational / Rapport | Most of this call. Hannah has said she will cover pay, notice, the hybrid pattern and the move, then the team and next steps. | High: she has named the topics herself. | Say each logistics answer in your own words, once, and stop. Never leave a logistics question without an answer. | 5 |
| Skeptic (light) | The gaps in the advert: SAP, production scheduling, Excel. | Medium: the advert lists SAP and production planning, and you have told me you have not used SAP. Recruiters screen for these early. | Name the gap plainly, then your plan. Do not bluff a skill. | 5 |
| Data-Driven Prober | Your stock-count figure. | Medium: "about a third" is the only number in your material. | Say how the figure was counted, if you know. If you do not, say so. | 2 |
| Pressure / Stress | A time-boxed challenge to a strong claim. | Low to medium: a screen is short, but she may ask you to justify an experience line in under a minute. | Pause, restate the question, hold your position through two follow-ups. | 2 |
| Case / Strategist | A short live scenario from the role. | Low: a screen rarely goes into a full case, but a single scenario is possible. | Clarify first, then structure. | 2 |

Depth follows weight. This pack is 18 questions, which is more than a 30-minute screen will use. Rehearse the Conversational and Skeptic banks first.

## Question banks

### Conversational / Rapport (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I'd like to cover your salary expectations." (Hannah) | JD | [grounded] "I'm hoping for £42,000." (your message) | Say it as you wrote it: "I'm hoping for £42,000." Then stop and let her answer. If she asks what you earn now, say: "I'd rather focus on the range for this role." Do not give a figure for your current pay. If she asks for a range or a minimum, you have not given one, so say what you have said. | Pay is her first logistics topic. The advert's band is £38,000 to £44,000, and your figure sits inside it. |
| A2 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. If you are unsure of your contract's terms, say so and say when you will check. Your message does not give a notice period, so this pack does not supply one. | Notice is one of the four topics she named. It is a knockout check in a friendly register. |
| A3 | "How would the hybrid pattern work for you?" (advert: "two days a week at our Avonmouth site in Bristol") | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say that sentence in your words. The ceiling is three days, and you gave no further commute detail, so do not add any. If asked about the commute, your own words were: "I live in north Bristol, so two days at Avonmouth is fine." | Location is her third topic and your answer is already given. |
| A4 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say that sentence in your own words, and stop. Do not add detail about Reading or the company that is closing. | Reason for leaving is her fourth topic. Keep it short and factual, as you wrote it. |
| A5 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds. Start with the four years, then the three depots and deliveries, then chasing suppliers when orders slip, then the stock-count rebuild (F4), in your own words. Stop there. | This is the opener. Every line you say here comes from F1, F2, F3 and F4. |
| A6 | "What would you want from the first few months in this role?" | JD | [generic] | Name what you would learn first: the planning, warehouse and QA routines, and the stock system's use at the Avonmouth site. Do not promise outcomes. | The advert's first requirement is coordination across three teams. Asked casually, it is still scored. |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert asks for SAP or a similar ERP. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Plain acknowledgment: "I've never used SAP." Then: "We run our own in-house stock system." Then your plan to learn an ERP tool, stated as a plan and not a past. This is the highest-ROI prep in the pack: it is the most likely knockout, and a plain answer beats a bluff. | F7 is the most predictable gap in the advert. |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. Which of those have you worked with directly?" | JD | [grounded] "I schedule deliveries for our three depots." (your message) | Answer slot: if you have coordinated across planning, the warehouse or QA, say which and how, in your own words. If you have not, say so plainly, then give the nearest thing you did: scheduling deliveries across three depots. | F2 is a transferability gap. The advert's wording is the interviewer's line, and your answer is your own. |
| B3 | "You rebuilt a stock-count spreadsheet. How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Answer slot: say which Excel features you used on that sheet and how confident you are. If it was another tool, say which. Do not claim a level you have not described. | F6 is low confidence. The advert asks for Excel directly. |
| B4 | "Have you reported on on-time delivery before?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you reported on delivery timing to anyone, say what and how often. If you did not, say so and say what you would report first. | F5 is a discovery gap. Silence in your material is not a yes. |
| B5 | "You've worked in building supplies. What do you know about diagnostic-test manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | Say what you know from the advert and from your work, and say plainly what you do not know. Do not claim sector knowledge you have not described. | The sector change is an obvious probe for a light Skeptic. |
| B6 | "Tell me about the last late supplier order you chased. What did you do first?" | EXP | [grounded] "chase suppliers when orders slip." (your message) | Walk through one real order, in your own words: what slipped, who you contacted, what you did next. If you cannot name one, say so and describe how you usually handle a slipped order. | F3 is the strongest match for the advert's chasing requirement. Keep it to one specific order. |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year." (your message) | Say the period and the figure as you wrote them. Answer slot: name the assumption behind that figure which you would defend least, if you know one. If you do not know how it was counted, say so. | F4's figure raises the defend-the-number slots. |
| C2 | "Walk me through how you rebuilt the stock-count sheet. What was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Walk through the rebuild in the order you did it. Answer slot: if other people did part of it, say which part; if you did the whole rebuild, say so. | F4 raises the same slot. Your part is the only thing you can claim. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over an internal candidate?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Pause before you answer. Restate the question in your own words. Then say the two things you have stated: four years and the stock-count result. Hold through two follow-ups. Do not claim a skill you lack. | A timed challenge tests composure, not content. |
| D2 | "That result, how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Hold: "I rebuilt the spreadsheet." Concede only what is true: if other changes also happened that year, say so. Do not fold on the rebuild itself. | Hold-then-concede. |

### Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A key supplier's delivery is three days late, and the production plan depends on it. What do you do first?" | CASE | [generic] advert: "track supplier deliveries and chase late orders" (advert). [grounded] "chase suppliers when orders slip." (your message) | Clarify first: which order, what the production impact is, and who needs to know. Then chase the supplier, then tell planning and QA what changes. Say it as steps. | The advert's chasing line is the raising source. Your chasing experience is the quote. |
| E2 | "Your planning team wants a stock figure you don't trust. What do you do?" | CASE | [generic] advert: "keep stock records accurate" (advert) | Say how you would check the figure against the count and the records, then who you would tell. Do not claim you have done this before unless you have said so. | A live problem from the advert's accuracy line. |

## Reverse questions

Ask at least some of these. Each one has a reason it lands.

1. "What happens between this call and the next step?" Why it lands: she has said she will cover next steps, so this shows you are following the process.
2. "How does the role split its time between planning, the warehouse and QA?" Why it lands: it tests the production-scheduling gap in her own words (F2).
3. "How is on-time dispatch measured today, and who reads the weekly report?" Why it lands: it tests F5 without claiming dispatch reporting.
4. "Is there training on the ERP system, and which one is it?" Why it lands: it tests F7 and shows you are thinking about the system gap.
5. "Is the Avonmouth pattern set by the team, or fixed by the site?" Why it lands: it asks about flexibility without stating a limit you have not given.

## Sources

- Provided documents: the advert (as you pasted it), Hannah Lowther's LinkedIn message, your message about yourself.
- Research tier: L1 requested, run as L0. Searches 0 of 6, fetches 0 of 2. Three searches were attempted and refused by the permission prompt, so no company page, interview-process source or news was read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet: not built. Search refused: "Quillmoor Diagnostics company", "Quillmoor Diagnostics values interview process recruitment", "Quillmoor Diagnostics Avonmouth site news" |
| 2. Quillmoor Diagnostics interview process, operations | unavailable | Loop structure: not established. Refused, as above |
| 3. Quillmoor Diagnostics strategy / recent news | unavailable | CO bank: not built. Refused, as above |
| 4. Hannah Lowther Quillmoor Diagnostics | unavailable | Interviewer read and reverse-question tailoring: not built. No search sent |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the questions |

## Upgrade menu

- Quillmoor's public values page, or the team and process details Hannah offers on the call → adds a values cheat sheet and a loop structure
- Your notice period, in your own words → turns the A2 instruction into your figure
- What the stock-count sheet ran in, and any SAP-like or ERP-like tools you have used → resolves the F6 and F7 answer slots
- Search access, if you want research run → company values, interview process and recent news, labelled by source
- A short list of the Avonmouth site's routines or team → sharper E1 and B2 answers
- Time before Thursday → a prioritized prep schedule (Conversational first, then Skeptic)
