Your resume includes a full Social Security number. The prep doesn't need it, so I didn't use it and it's left out of the pack. Remove it from the resume before you send that file to anyone, including the school.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-5-rooms-case-9-canned-19c1a5f4/6a7c70bd-4924-4b11-a9cc-324d622b4d5c/scratchpad/halvering_fourth-grade-teacher_interview_pack.md, and I've sent it to you as a file too. I built it for the 45-minute panel with Principal Vantongeren and two fourth-grade teachers.

The main things to prepare:

- **Fourth grade is your most likely objection.** You've taught third grade for six years, so say that plainly and name one practice that carries over. Question A1 has the full rehearsal.
- **Team leadership is the second gap.** Don't describe leading a team. You led your grade level's move to the new reading curriculum in 2024, and that's the accurate way to say it.
- **The district's careers page says panels ask about reading instruction, classroom routines and working with families.** Your CV covers reading and families. Routines is the one you have nothing written about, so think of one routine you've run before the panel.

Your license covers the invite's requirement. Bring the license or its ISBE lookup record.

Would you like to rehearse? I can play the principal's skeptic on A1 and push back on your answer until you hold it. I can also save a tuesday-dossier.md that records the gaps this prep exposed, for later sessions.

Two quick questions:

1. Did HR mention a demo lesson, a writing task, or focus areas for the panel?
2. If you have the full posting, paste it in. Right now the pack rests on the invite and the careers page snippet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Round:** 45-minute panel, Thursday. Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).
**Interviewers:** Principal (hiring-authority, skip-level for this role); two grade-level teachers (peers).
**Built from:** the invite, your CV as you pasted it, your message, and one district careers page (search snippet only).

## How to use + type key

Personas are how a question arrives. Types are what it scores.

- **EXP**: your experience, and whether it holds up when asked about in detail
- **JD**: the role's stated requirements
- **VAL**: how you handle families, colleagues, and classroom practice
- **CASE**: a live classroom problem, answered from structure, not from past events

Guidance is scaffolding for a spoken answer, not a script. Use your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met as stated. Bring the license or its ISBE lookup record so you can show it. Checking it is yours to do. |
| F2 | "Fourth Grade Teacher" (invite, role title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Adjacent work, not the same grade. Words: "I haven't taught fourth grade. I taught third grade at a public elementary school in Joliet for six years." Answer slot: the panel will probably ask what carries over. If you can name one practice from third grade that carries over, say it and how you used it; if none comes to mind, say so and say what you would check first. |
| F3 | "two members of our fourth-grade team" (invite) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Grade-level work, not a fourth-grade team. Words: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if the panel asks how you would work with this team, say which parts of the 2024 move were yours to set, in your own words; if none were, say so. |
| F4 | Team leadership (role-family expectation, not in the invite) [generic] | "I've never been a team lead" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't been a team lead." Then F3's quote, at its own scope. Never describe a leadership role you did not hold. |
| F5 | "Panels ask about reading instruction" (district careers page) | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | The CV reaches reading instruction in role terms. Expect a probe on what you did yourself in the curriculum move. |
| F6 | "how you work with families" (district careers page) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | The CV reaches family communication. A sample email with names removed would raise this to an inspectable artifact. |
| F7 | "classroom routines" (district careers page) | none given | none | [grounded] | discovery | The material is silent on routines. Answer slot: describe a routine you have run and how you set it up. If you have not run one you can describe, say so and describe the one you would start with. |

**Gate:** the license is met as stated (F1). The gate is not a question for you to answer again here.

**Plain acknowledgments available** (your own negatives): "I haven't taught fourth grade" (F2) and "I haven't been a team lead" (F4). Use them as written.

## Prohibited claims

Not to be coached, with basis and honest form:

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade, or fourth-grade experience | Stated negative, F2 | "I haven't taught fourth grade." |
| Led a team, or served as team lead | Inflated form of F3; stated negative, F4 | F3's quote at its own scope; "I haven't been a team lead." |
| Chose or selected the reading curriculum | Inflated form of F3 ("led … the move" does not say who picked it) | F3's quote at its own scope; the answer slot names which parts were yours |

Note on silence: your material does not show reading-score results, or how families responded to your email. Those are answer slots (F5, F6), not claims to make.

## Interviewer read

Not built. No interviewer profile was researched and the team members are not named. The persona weights below rest on the round type, not on individual interviewers.

## Persona table

The loop source (district careers page) establishes one 45-minute building panel: the principal and two grade-level teachers. So no archetype fallback was needed.

| Persona | Who on the panel | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet probing of fourth-grade fit and team leadership | Highest. F2 and F4 are the gaps the material shows most clearly. | Rehearse the fourth-grade objection until it is plain. Name the adjacent work in your own words. |
| Peer Evaluator | Grade-level teachers | Reading planning, disagreement, working with the team | High. The invite names the team as panelists, and the careers page raises reading. | Show what you would bring to the team, not just what you need from it. |
| Case / Strategist | Principal | A classroom problem to structure | Medium. The careers page raises classroom practice; the principal runs the panel. | Clarify, then structure, then answer. No past claims are needed. |
| Values / Behavioral | Principal and team | Families, routines, how you work with people | Medium. The careers page names families and routines. | Describe what you did, with "I" for what was yours. |
| Data-Driven Prober | Team | How you know a child is progressing | Lower. The careers page raises reading instruction; the CV has no headline figures to probe. | Name the check you use and say what it showed. |
| Conversational / Rapport | Any | Friendly opener, path into teaching | Lower, but scored. | A 90-second arc from your own sentences. |

## Question banks

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What would you do in your first month?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Begin with "I haven't taught fourth grade." Then the third-grade years, in your words. Then a plan, said as a plan: read the fourth-grade scope with the team, and watch how the team runs its routines before changing any. Hold through two follow-ups by returning to what you have actually done. Concede specifically: the first term will be a ramp-up. | F2. The most predictable objection to this candidate, so it gets the deepest rehearsal. |
| A2 | "You haven't been a team lead. Why would the team want you on it?" | VAL | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say "I haven't been a team lead." Then the 2024 move, at its own scope. Answer slot: say what you would bring to the team, in your own words. Do not claim leadership you did not hold. | F4 and F3. Holds the stated gap without covering it. |
| A3 | "Another applicant has taught fourth grade. Why should we choose you?" | JD | [generic] | Do not argue the other applicant. Say what you have: six years in third grade and the reading work. Say plainly that you have not taught fourth grade. Let the panel decide. | F2. Presupposes an applicant pool the material does not show. |
| A4 | "What is your weakest area for this role?" | VAL | [grounded] "I've never taught fourth grade" (your message); "I've never been a team lead" (your message) | Name the two gaps you told me about, in your own words. Name one concrete step you would take on each. Do not add a third. | F2 and F4. Open prompt; the honest branch is your own stated gaps. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you plan reading instruction across a unit?" | JD | [grounded] "Panels ask about reading instruction" (district careers page) | Story-mapped on F5: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you planned units during that move, say how, in your own words; if the planning was done by others, say so and say what you did. | F5. Reading is a stated panel topic. |
| B2 | "Tell me about a time you and a grade-level colleague disagreed about how to teach something." | VAL | [generic] | Pick a time you disagreed with a colleague. Say what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the 2024 reading move), or how you would handle it. | Open prompt, from the persona stem. Peer disagreement is a common panel probe. |
| B3 | "Tell me how you work with a grade-level team." | VAL | [grounded] "two members of our fourth-grade team" (invite) | Describe your practice in your own words. Answer slot: if you have done this with a grade-level team, say how; if not, say so and describe how you would start. | F3. The invite's own words raise the topic. |
| B4 | "How would you handle a colleague who doesn't use the new reading curriculum?" | CASE | [generic] | A live problem. Structure it: first understand why, then support, then escalate if needed. No past claims needed. | Hypothetical; the 2024 move makes it plausible. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student reads two levels below the rest of the class and the family is upset. Walk me through your first week." | CASE | [generic] | Clarify what you know. Talk to the previous teacher. Plan one check. Talk to the family with the team. No past claims. | Live problem, from the role. |
| C2 | "Plan the first two weeks of reading in a new class." | CASE | [generic] | Clarify the class's level. Set one goal. Group students. Name a check at the end of each week. Involve families. | Structure, not content. |
| C3 | "How would you plan reading groups for students at three levels?" | CASE | [generic] | Clarify the level data first. Then how many groups, how often, and what each group needs. | Structure, not a past event. |

### D. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you keep families informed about what their child is learning?" | VAL | [grounded] "I write a weekly email to families" (your CV) | "I write a weekly email to families." Then what it covers, in your words. Answer slot: if you have changed the email in response to a family, say what changed; if not, say so. | F6. The careers page raises families directly. |
| D2 | "Tell me about a classroom routine that works for you." | VAL | [grounded] "Panels ask about … classroom routines" (district careers page) | Story-mapped on F7 if you have one to describe. Answer slot: if you have a routine you can describe, say how you set it up; if not, say so and describe the one you would start with. | F7. Routines are a stated panel topic with no material behind them. |
| D3 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say what you did, in those words. Answer slot: if you know how many children attended, say it; if you do not, say so. Never add an outcome you did not record. | Your strongest specific. Tests what was yours to run. |

### E. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you know a child is making progress in reading?" | JD | [grounded] "Panels ask about reading instruction" (district careers page) | Name the check you use. Answer slot: if a reading check or assessment you ran showed progress, say which and what it showed; if you do not have a fixed check, say so and describe the one you would use. | Reading is a stated topic; a probe is likely. |
| E2 | "Walk me through a time reading data changed what you did." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if the data changed what you did, say which data and what changed; if it did not, say so and describe the check you would use. | Open prompt, from the reading move. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through how you got here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I write a weekly email to families" (your CV) | A 90-second arc from those sentences: Joliet, six years of third grade, the 2024 reading move, the reading club, the weekly email. Answer slot: the reason you went into teaching, in your own words. | Opener. It is scored even though it is casual. |
| F2 | "What would you want us to know about you that isn't on your resume?" | VAL | [generic] | Pick one thing you would want the panel to know. Keep it short. | Open prompt, from the persona stem. |

## Reverse questions

1. "What does a typical first month look like for a new fourth-grade teacher on this team?" Why it lands: shows you are planning around their routine.
2. "How does the team plan reading across the grade?" Why it lands: a peer question that invites them to talk about their own practice.
3. "How do families usually get updates from the team?" Why it lands: connects to your weekly email.
4. "What would make the first term feel successful to the principal?" Why it lands: aligns your goals with hers.
5. "What is the one thing a new team member most often gets wrong in the first year here?" Why it lands: candor, and it gives you something to watch for.
6. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, for the peer members.

## Coverage

| JD / invite requirement | Question IDs | Note |
|---|---|---|
| Illinois PEL with elementary endorsement | none, and why: met as stated (F1); you can show the record | Gate |
| Fourth Grade Teacher | A1, A3, A4, C1 | |
| Two members of the fourth-grade team | B1, B2, B3 | |
| Reading instruction (careers page) | B1, E1, E2 | |
| Classroom routines (careers page) | D2 | |
| How you work with families (careers page) | D1, F1 | |
| Team leadership (role-family) | A2, A4 | |

## Sources

- Provided: the invite, as pasted; your CV, as pasted; your message.
- Search 1: "Halvering Elementary School Orrinsford Community School District". No results. Values not established.
- Search 2: "Orrinsford Community School District fourth grade teacher panel interview". Returned https://orrinsfordschools.example/careers/how-we-hire-teachers (search snippet only, not fetched): "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel."

**Research tier:** L1, searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Search returned no results. Values not established; no values cheat sheet built. |
| 2. Interview process | yes | The careers page establishes the loop: one 45-minute panel. Topics (reading, routines, families) feed the question banks. |
| 3. Company strategy / news | unavailable | Not run this turn. Would have moved the CO bank, which this panel does not draw on. |
| 4. Interviewer footprint | unavailable | Not run this turn. Would have built the interviewer read. |
| 5. Representative JD | unavailable | Not run this turn. No posting text was supplied. |

## Upgrade menu

- The full posting text → JD rows become grounded in the posting instead of the invite.
- Whether HR named a demo lesson, writing task, or focus areas → a graded-deliverable section.
- The two team members' names → an interviewer read and per-member persona weights.
- One weekly family email, with names removed → makes F6 and D1 an inspectable artifact.
- Fetching the careers page → the exact panel wording, rather than the search snippet.
- A `tuesday-dossier.md` from earlier sessions, if you have one → would add its gaps to the banks.
