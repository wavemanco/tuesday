Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and to "deposit the cheque and send the balance on to the vendor." Requests like these, a fee for equipment, a cheque to deposit with money to pass on, and ID and bank details before any offer, are a known scam pattern, and this invite is very likely a scam. Hold the fee, the cheque and the documents until you've checked the invite with the employer through a phone number or address you find on its own website or careers page, not through this email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

I built this for a 30-minute video call with the office manager, as the email describes it. Your note doesn't give the full job ad, so the requirements below are your summary of it. Everything is in this message, not saved to a file.

**How to use:** personas are how a question is asked; types are what it scores. EXP is your experience, JD is the job's requirements, CASE is a live problem, and CO is company knowledge. Guidance is a scaffold for a spoken answer, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your words already reach calendar work: "I ran the appointment book for four physios." Keep it there. Don't stretch it to executive diaries |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what you booked and how; if you haven't, say so plainly and say how you'd learn the booking tool |
| F3 | "preparing documents in Word and Excel" (your message) | "good with Word" (your message) | medium | [grounded] | none | Word is covered: "I'm good with Word." Say it as you wrote it |
| F4 | "preparing documents in Word and Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | discovery | Say "okay with Excel" as written, not stronger. Answer slot: if you have built or changed a spreadsheet for work, say what it did; if you haven't, say so and say how you'd get up to speed on the parts this role needs |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing is adjacent to processing, so the bridge stays at its scope: "I chased unpaid invoices." Answer slot: which part of that was yours, and what you did when a payment was late. If you entered, matched or approved supplier invoices, say what that involved; if you only chased payment, say so and say what you'd need to learn |

Your material shows chasing, not processing, and it shows scheduling for four people, not for executives. Those are the limits to rehearse around.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Processed supplier invoices" | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The slot stays inside chasing |
| "Strong in Excel" | Inflated form of F4 | F4's quote: "okay with Excel." No first-person negative is needed |
| "Managed executive calendars" | Inflated form of F1 | F1's quote at its own scope: "ran the appointment book for four physios" |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic and Case (hiring-side manager) | Probes the requirements you didn't cover, and gives a live scheduling or travel problem | High. The office manager is scoring you against the four requirements, and a 30-minute round is short | Hold to what you did; name the gap in one sentence and say how you'd close it |
| Conversational | Opens with "walk me through", casual but scored | Medium. Typical opener for a 30-minute call | Practise a 90-second arc in advance |
| Pressure | Time-boxed challenge on why you over someone with office experience | Low to medium. Two questions, so you're ready if it comes | Hold on the evidence, then concede the specific gap |

## Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 (Skeptic, highest-ROI) | "Your background is a clinic reception, not an office admin role. Why this role?" | JD | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" | Name the two things you did, in your own words, then say what you want to do next. Don't claim office admin experience you don't have | F1 and F5 are your nearest evidence, and this is the likeliest objection. This is the highest-ROI rehearsal in the pack |
| A2 (Skeptic) | "Walk me through how you handled supplier invoices." | JD | [grounded] "chased unpaid invoices" | Describe what chasing involved: who you followed up with and how. Answer slot: if you entered, matched or approved supplier invoices, say what that involved; if you only chased payment, say so plainly and say how you'd learn processing | F5. Processing is a requirement, so expect this probe |
| A3 (Case) | "A director needs travel booked for two people next Thursday, but the calendar is double-booked and the budget is tight. What do you do?" | CASE | [generic] | Clarify first: which trip, what the budget limit is, who decides. Check both calendars, offer two options, confirm with the director. Make no claim about your past | F2's requirement as a live problem. It needs no claim about your past |
| A4 (JD) | "Show me how you'd set up a simple invoice log in Excel." | JD | [grounded] "okay with Excel" | Say what you already do in Excel, in your own words. If you haven't built one, say so and describe the steps you'd take | F4 is your weakest evidence, so a practical probe is likely |
| A5 (Conversational) | "Tell me about yourself, the two-minute version." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "good with Word" | A 90-second arc: the clinic, the appointment book for four physios, the invoices, and Word. Use only those facts | F1, F3 and F5 in one arc. Casual, but scored |
| A6 (Pressure) | "Sixty seconds: why should we hire you over someone with office experience?" | JD | [grounded] "ran the appointment book for four physios"; "good with Word" | Hold on what you have done: the appointment book and Word. Answer slot: if there's a part of the role you haven't done, name it and say how you'd learn it | Hold through two follow-ups, then concede specifically |

**Requirement coverage:** managing calendars → A1, A5 · booking travel → A3 · Word and Excel → A4, A5 · processing supplier invoices → A2, A6.

## Reverse questions

1. "What does a typical week look like in this role?" Why it lands: shows you're thinking about the job itself.
2. "Which tools do you use for calendars and travel bookings?" Why it lands: shows you'd pick up the tools quickly.
3. "How do supplier invoices move from receipt to payment here?" Why it lands: shows you're interested in processing, and gets you the process.
4. "How is work split between in-office and remote staff?" Why it lands: relevant to a remote role.
5. "What happens after this call, and when would I hear back?" Why it lands: a process question that's fair to ask.

## Sources

Provided documents: your message, with the invite text and your background. No searches or fetches were run this turn. Research tier: L0. Rows 1 to 3 and 5 were not run at this tier; row 4 is n/a because no interviewer name was given. Your summary of the ad fixes the requirements, so the representative-JD search was skipped.

## Upgrade menu

- The full job ad → the fit snapshot quotes the ad's own words instead of your summary, and A1 to A3 get exact requirements
- The office manager's name → an interviewer read, and a reverse question tailored to their path
- A sample of a spreadsheet you've built → F4's evidence becomes stronger
- `tuesday-dossier.md` → records what this prep exposed, so later sessions start from it

Is the office manager your direct manager, or a peer? The answer changes how much weight the Skeptic questions get.

I can run a practice call on A1, the question this pack names as highest-ROI prep, and I can save a `tuesday-dossier.md` of the gaps this prep found.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.