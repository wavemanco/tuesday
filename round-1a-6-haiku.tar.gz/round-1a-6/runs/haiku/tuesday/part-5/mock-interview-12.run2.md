Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also says "a cheque for €1,850" and "you deposit the cheque and send the balance on to the vendor." Requests like these, a fee to register equipment, a cheque to deposit and forward, and passport and bank details before any interview, are a known scam pattern, and the fee and cheque requests are very likely a scam. Hold the fee, the cheque, the passport photo and your bank details until you have checked the invite with the employer, using contact details from its own website or careers page rather than anything in the invite. If you want the invite checked, job-underwriter can do that as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-tuesday-part-5-rooms-case-12-denied-1b696b3d/108832a5-11e9-46e6-af73-912243ee6138/scratchpad/Brennock_Remote-Administrative-Assistant_interview_pack.md`. It covers what to expect: a 30-minute video call with the office manager, with questions on the four duties in the ad. Your strongest material is the appointment book and the invoice chasing; your weakest areas are booking travel and processing invoices, so most of the prep goes there. The highest-value prep is question A2, "have you processed an invoice from receipt to payment?"

Say the word and I'll play the Skeptic on A2 and run a drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Can you paste the full text of the ad? It would turn the four requirement lines into exact quotes instead of my reading of your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_Remote-Administrative-Assistant_interview_pack.md -----
# Remote Administrative Assistant at Brennock Facilities Ltd: interview prep

Interviewer: the office manager (name not given). Round: a 30-minute video call, read as a hiring-manager round.

## How to use

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

Type key:

- **VAL**: behavioural and values fit
- **EXP**: a deep-dive on your past work
- **JD**: whether you can do the listed duties
- **CO**: knowledge of the company
- **CASE**: a live problem from the job

**What to expect:** a short video call with the office manager. Expect questions on the four duties in the ad, a practical scheduling or invoice problem, and a warm-up about your background. Your strongest material is the appointment book and the invoice chasing. Your weakest is booking travel and processing invoices, so most of the prep goes there.

**Highest-ROI prep: A2.** Expect the question "have you processed an invoice from receipt to payment?" in some form, and rehearse the honest answer until it is routine.

## The fit snapshot

Requirements are quoted from your message, which summarises the ad. Evidence is quoted from your message as well.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says a clinic's appointment book for four physios, not calendars for several managers; the limit is the pack's observation. Words for you: "For two years I ran the appointment book for four physios." Answer slot: if you moved bookings or settled clashes yourself, say how; if the calendar was set by others, say so and stay with the book you ran. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: if you have booked travel for anyone, say what and how; if not, say so plainly and say how you would learn the booking tools. A plan, not a past. |
| F3 | "preparing documents in Word and Excel" (your message) | "I'm good with Word, okay with Excel" (your message) | low | [inferred] | discovery | A self-rating with no example behind it. Word is the stronger claim; Excel is "okay", which reaches the requirement only in part. Answer slot: name one document you prepared in Word and one sheet you built or changed in Excel, and say what each did; if you have none, say so and say what you would learn first. |
| F4 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | Chasing payment is adjacent to processing an invoice; it is not the same work. Words for you: "I chased unpaid invoices." Answer slot: if you entered, matched or approved supplier invoices, say the steps in your words; if you only chased payment, say so and say how you would learn the supplier steps. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Ran calendars for executives | Inflated form of F1 | F1's quote at its own scope: the appointment book for four physios. The limit is in the pack's analysis, not a line for you to say. |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices". Slot A2 asks which steps, if any, were yours. |
| Expert in Excel | Inflated form of F3 | F3's quote at its own scope: "okay with Excel". |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: the duties you have not shown, and why this role | High. The office manager is hiring for duties your material shows only in part, so probes on F2 to F4 are likely. Weight 4 questions. | Hold to your quotes. Say what you did, say what you did not, and give a plan for the rest. |
| Case / Strategist | A live calendar or invoice problem from the job | Medium. Admin roles are often tested on a practical scenario. Weight 3 questions. | Clarify first, then state the steps you would take and what you would record. |
| Conversational | A warm-up that invites your background | Medium. A 30-minute first call often opens this way. Weight 2 questions. | Give a 90-second arc from your message. Keep it accurate. |
| Data-Driven Prober | Asks how a figure was counted | Not weighted. Your material has no figures to defend. The Skeptic covers the same ground for what you did. | None needed. |
| Pressure | A time-boxed challenge | Not weighted. Nothing in the invite suggests a stress panel. A2's hold-then-concede serves the same composure test. | None needed. |

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" (your message) | Name the weakest part in your words, using your own two halves: Word is the stronger one, Excel is "okay". If booking travel is the weakest, say so plainly; if you have booked travel before, say how; if not, give a plan for learning the tools. | The Skeptic opens with the widest gap. F2 and F3 supply the words. |
| A2 | "You've chased invoices. Have you processed one from receipt to payment?" | JD | [grounded] "chased unpaid invoices" (your message) | Your honest answer starts with "I chased unpaid invoices." Answer slot: if you entered, matched or approved supplier invoices, say the steps in your words; if you only chased payment, say so and say how you would learn the supplier steps. Hold through two follow-ups by returning to the chasing. | F4 is the least supported requirement and the likeliest probe. Highest-ROI prep. |
| A3 | "Two years at a front desk: what makes you think you can manage calendars for several people?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Say what the book involved in your words: you ran it for four physios. Answer slot: if you moved bookings or settled clashes yourself, say how; if the calendar was set by others, say so and stay with the book you ran. | F1 is the adjacent work and its limit is that it was a clinic's book. |
| A4 | "How good are you in Excel, and what have you built in it?" | JD | [grounded] "okay with Excel" (your message) | Say "okay" as your sentence does. Answer slot: if you built a sheet or a calculation, say what it did; if you have not built one, say so plainly and say what you would learn first. Concede without folding on the rest. | F3 is the Excel half of the documents requirement. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two directors have clashing meetings on Thursday, and one is flying out on Wednesday. What do you do first?" | CASE | [generic] | Structure it: who decides which meeting moves, what you check first (the flight, the attendees' diaries), what you confirm and in what order, and what you record. The guidance makes no claim about your past. | The live calendar problem the ad names. |
| B2 | "If someone needed a flight and a hotel for a trip next week, what would you do?" | CASE | [generic] | Structure it: dates and budget, the traveller's preferences, the booking, written confirmation, and what you send them. Describe what you would check. Do not describe a booking you did not make. | Covers F2 as a live problem, since your material shows no travel work. |
| B3 | "A supplier invoice arrives twice: once for €480, and once for €480 with a different reference. What do you do?" | CASE | [generic] | Structure it: check the order or receipt, query the supplier before any payment, make sure it is not paid twice, and log the outcome. | Covers F4 as a live problem. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through how you got here." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, the appointment book for four physios, the invoices you chased, then your reason for applying in your own words. Answer slot: your reason for applying is yours to give. | The opener is scored like the rest. |
| C2 | "This is a remote role. How do you keep track of work when nobody is in the room?" | JD | [generic] | Answer slot: if you have worked remotely, say how you kept track; if not, say so plainly and describe how you would set up your day. A plan, not a past. | The word "remote" comes from the ad's own title; the answer draws on no past claim. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Managing calendars | A3, B1 |
| Booking travel | A1, B2 |
| Preparing documents in Word and Excel | A4. Word: none, and why: your message gives a self-rating with no example; the upgrade menu asks for one. |
| Processing supplier invoices | A2, B3 |

Coverage is below the usual session size, because your material is short. Padding the pack would mean inventing specifics.

## Reverse questions

Each one has a reason it lands with an office manager.

1. "What does a typical week look like for the person in this role?" Why it lands: shows you are planning for the real job, not the ad.
2. "Which of the four areas takes most of the time?" Why it lands: shows you listened to the ad and want to know where the effort goes.
3. "Who approves supplier invoices here, and how do they reach payment?" Why it lands: shows you understand the control points in the invoice process.
4. "What tools does the team use for calendars and documents?" Why it lands: lets you show your Word and Excel level against a real tool.
5. "After this call, what happens next, and how long does it usually take?" Why it lands: a process question with a prep reason, and it gives you the timeline.
6. "What would you want the next person in this role to do well from day one?" Why it lands: shows you are thinking about the outcome, not only the tasks.

## Sources

Provided documents only: your message, which contains the invite's text and your background. No search or fetch ran. The invite's warning signs add no search, since no declared target covers one.

Research tier: L0, no searches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Values cheat sheet, section 10. Not detected: no loop source names a values round. |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Loop structure and persona weights. The 30-minute call is taken from your message only. |
| 3. `Brennock Facilities Ltd strategy` | unavailable | CO questions. None written. |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given. |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your message's summary of the ad fixes the requirement rows. |

## Upgrade menu

- The full text of the ad → the four requirement lines become exact quotes from the ad, not your summary.
- Your CV → adds evidence beyond the two sentences in your message, and can upgrade F2 and F3.
- A document or sheet you built, in Word or Excel → upgrades F3 and A4 from a slot to a named example.
- The office manager's name → a tailored reverse question. Nothing is researched on a name without a source.
- A `tuesday-dossier.md` → records the gaps this prep exposed, for later sessions.
