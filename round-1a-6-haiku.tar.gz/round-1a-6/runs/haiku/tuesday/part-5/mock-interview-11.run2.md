Before I build the prep, I need to flag something in the message itself.

The invite says the whole process, "from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed." It also came from a number you don't recognise, after "found your profile online." A hiring process run entirely over chat doesn't show who you're actually dealing with, so I can't tell from here whether it's one of your applications. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Until you know, don't send money, documents or bank details through this chat. To check, find the organisation's contact details on its own website or careers page, not through this chat or any number or email in the message, and ask them whether they're running an interview with you. If you want, job-underwriter can check the invite as a separate request.

To build a prep pack I need the company name and the job title, since the message names neither. Which organisation and role is this interview for?