**Not yet. Hold on this one until you know where the job is based. Status: `hold_pending_answers`.**

The posting contradicts itself on location, and that is a hard gate. The JD you pasted says "Fully remote (UK)". Brindlemoor's own careers page says "Leeds office four days a week." I fetched that page and it says this. I can't tell which is current, so I'm not resolving it.

If the role is fully remote, this moves to `conditional_go`. If it's Leeds four days a week, it depends on whether you can work from there. Your location isn't in what you've shared, so I can't check it.

**Fit ledger.**

- `hard_gate`: unclear: H1 (fully remote UK against a Leeds office four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM), R5 (presenting to underwriting leads), R6 (design and read price tests); adjacent: R1 (build and monitor rating models); unclear: R7 (turn results into product recommendations)
- `important`: adjacent: R8 (pet-insurance pricing)
- `preferred`: direct: R9 (insurance experience)

R1 and R8 are adjacent because your rating and GLM work is motor, not pet. R7 is unclear because your evidence covers underwriting recommendations, not product.

**Opportunity ledger.** Clean on the material I have, with one unresolved contradiction. The location conflict (RR1) is a risk signal. Nothing in the posting is a red flag. The JD gives no salary, and it doesn't say whether the role manages anyone. Management isn't in the requirements, so I haven't scored it.

- **Hard gates:** none failed; unconfirmed: H1 (fully remote UK against a Leeds office four days a week); candidate constraints not given. Checks against them are unknown. You didn't give your location, right-to-work status, pay floor or start date.
- **Severe red flags:** none found.
- **What the hold waits on:** H1 is the only answer that can change the status. Remote confirmed and pet-domain pricing acceptable gives `conditional_go`. Leeds four days a week that you can't do gives `no_go`.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, pet-insurance product, reports to the Director of Pricing | `[grounded]` JD and careers page |
| Scope | Pricing analytics for one product: rating models, price tests, recommendations | `[grounded]` JD |
| Working pattern | Fully remote UK (JD) vs Leeds office four days a week (careers page) | `[grounded]` both sources, in conflict |
| Unknowns | Salary; whether the role manages anyone; size of the pet book; product maturity | — |
| Contradictions | Location, as above | `[grounded]` both sources |

**Evidence map.** Your claims are CV self-report, so confidence tops out at `medium` for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Fully remote UK | hard_gate | unclear | none | hard_gate | Posting contradicts itself; your location not given | `[grounded]` both sources | Question 1 |
| R1 | Build and monitor rating models | must_have | adjacent | medium | transferability | GLM rating model for young-driver motor. Limit: no pet rating work | `[grounded]` CV | Bridge case, with the limit stated |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, two as senior analyst | `[grounded]` CV | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, per your account | `[grounded]` CV | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` CV | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to head of underwriting | `[grounded]` CV | none |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 tests last year with underwriting | `[grounded]` CV | none |
| R7 | Recommendations for product, not just underwriting | must_have | unclear | low | discovery | Underwriting recommendations evidenced; product not | `[grounded]` CV silence on product | Question 2 |
| R8 | Pet-insurance pricing | important | adjacent | medium | transferability | Motor pricing carries over. Limit: no pet risk drivers, vet-cost patterns or breed factors | `[inferred]` from "for our pet-insurance product" | Bridge case, with the limit stated |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurer, UK | `[grounded]` CV | none |

**Gap recovery queue.** No questions in the rows. The questions are in the closing block.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet pricing (R8) | transferability | Motor pricing with GLMs and price tests; no pet work | An interviewer will probe this first | Any pricing of a non-motor line, or work on a claims or loss-ratio model whose drivers you can name | A sanitised model outline or a price-test write-up | `[inferred]` bridge from the motor work; `[generic]` that this is the likely probe |
| G2 | Product recommendations (R7) | discovery | Underwriting recommendations evidenced | "Underwriting and product" is in the JD | A recommendation that changed a product feature, eligibility rule or pricing structure | A product brief or review note | `[grounded]` CV silence on product |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The role may be hybrid in Leeds, or the careers page may be out of date | `[inferred]` from the two sources disagreeing | "Is this role fully remote, or based in your Leeds office four days a week?" | unresolved |
| RR2 | Product remit | unknown | — | "turn the results into recommendations for underwriting and product" | Product ownership may sit with another team | `[inferred]` from the JD's wording | "Which product decisions does this role recommend on directly, and who decides?" | unresolved |
| RR3 | Salary withheld | unknown | — | JD gives no salary | Pay may fall below your expectation | `[grounded]` JD silence | "What's the budgeted salary band for this post?" | unresolved |

**Research.** One employer search returned only the careers page, which is the employer's own site. A search for "Brindlemoor pet insurance" returned nothing, so there is no independent footprint yet. I haven't recorded the standing "employer not established" entry, because the employer's own domain attributes the posting. The thin footprint is still worth a check.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor pet insurance" (no results); fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved RR1: the careers page contradicts the JD on location |
| 2. Role-family sweep | unavailable | Not run in this pass. Would have set market calibration for pay and scope |
| 3. Hiring manager's public footprint | unavailable | Not run in this pass. A name, Odile Varga, was given. Would have set the positioning for this reader |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the employer, through contact details from its own site, whether the role is fully remote or Leeds-based | Resolves H1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the verification questions of RR2 and RR3 at the first interview | Register doubles as prep | `[grounded]` register | pending your approval |

**Evidence status.** Verified: none yet. Every claim above is CV self-report at `medium`.

**Upgrade menu.**

- The employer's answer on location → H1 closes and the status moves to `go` or `no_go`.
- A sanitised pet-related model or price-test write-up, or any inspectable artifact → R8 and R1 move toward `high`.
- A product brief or review note → R7 moves off `unclear`.
- Your location and right-to-work status → checks against your constraints run.
- Your pay floor and start date → the hard-gate line gets its checks.
- A research pass on the role-family pay band and Odile Varga's public footprint → targets 2 and 3 run.

**Questions.**

1. **H1:** Is this role fully remote, or based in the Leeds office four days a week? Where are you based?
2. **G2 / R7:** Have you ever recommended a product change, not just an underwriting one? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Offer: I can dig further into Brindlemoor's public footprint and the pay band for this role, but only if you want that.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.