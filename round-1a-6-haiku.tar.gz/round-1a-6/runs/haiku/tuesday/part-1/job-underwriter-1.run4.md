**Yes, apply, on conditions. Your core analytics background matches the must-haves. The gaps are healthcare data and three ownership claims I can't check from what you've shared. Status: `conditional_go`.**

**Fit ledger**

- `hard_gate`: none stated
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R8 (partner with clinicians); unclear: R6 (define and maintain the metrics layer), R7 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

Every must-have is `direct`, so the gaps sit in one important row and one preferred row, plus two unclear responsibilities. R8 and R9 are where the healthcare gap shows.

**Opportunity ledger.** The employer and the posting are unverified (RR1), because web search was refused in this session and I couldn't check them. The posting names a clear first-year scope, with the responsibilities set out (RR2, positive).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 verifies: the posting is live on Harborlight's own careers page; (2) R6 and R7 come back as concrete ownership in your answers; (3) R9 is framed as consumer-privacy adjacency (GDPR/CCPA, consent model), never as HIPAA experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD as stated; not checked against its site |
| Mandate | Own product analytics for the care-navigation app; metrics layer; A/B tests; Looker; mentor two juniors | `[grounded]` JD |
| Scope read | Analytics lead with a mentoring component; the JD gives no decision rights | `[inferred]` from the responsibilities list |
| Market calibration | Not run: the salary search was refused and the posting gives no pay | — |
| Unknowns | Employer existence; pay; whether the metrics layer is owned by this role | — |
| Contradictions | None visible from the JD alone; not checked against the careers page | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated in your message; prose intake, so medium at most | `[grounded]` user-stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake | `[grounded]` user-stated | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test with an 11% retention lift | `[grounded]` user-stated | Ask for a sanitized readout to raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch; 40+ governed dashboards | `[grounded]` user-stated | Dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo; monthly VP Product presentation | `[grounded]` user-stated | A redacted memo would raise to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards show you consumed definitions; the message doesn't say you owned them | `[inferred]` from the dashboard work | Question G6 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in the message about mentoring | `[grounded]` silence | Question G7 |
| R8 | Partner with clinicians | important | adjacent | medium | transferability | Partner-with-PMs work carries over; no clinician partnership stated | `[inferred]` from the PM partnership you described | Bridge case in the application |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA PII and the consent-state model carry over; HIPAA rules (PHI, BAAs, minimum necessary) are not in your experience | `[inferred]` from consumer-privacy work | Question G9 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G6 | Metrics layer (R6, important) | discovery | Governed dashboards are in your history; metric definitions as an owned layer aren't | Owning definitions would move R6 to direct | Defining a shared metric, resolving a disputed definition, a metric dictionary | A metric definitions doc, a dictionary page | `[inferred]` that the layer is a named responsibility |
| G7 | Mentoring (R7, important) | discovery | No mention of mentoring or managing analysts | A stated responsibility with no evidence | Onboarding a junior, code or query reviews, a development plan | A review template, a mentoring example | `[grounded]` silence |
| G9 | Healthcare data (R9, preferred) | transferability | Consumer privacy work; no health data | Preferred, but it will come up | Any project touching sensitive or regulated data | A data-handling doc, a consent model diagram | `[inferred]` bridge from consumer-privacy work |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting may be live and the employer real; neither was checked | `[generic]` pattern for an unverified posting, not a claim about this employer | Which team is this role on, and where is the posting on your careers page? | unresolved |
| RR2 | Clear scope with outcomes | positive_signal | — | "Own product analytics for our care-navigation app" | The role has a defined remit | `[grounded]` JD | Which of the listed responsibilities would this hire own first? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Harborlight's own careers page before applying | Closes RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead the resume with the experiment program and the Looker build, each in your own words, with the 11% retention figure kept attached to the retention test | Puts R3 and R4 first | `[grounded]` your message; `resume_edits_pending_approval` | pending your approval |
| A3 | Frame healthcare as consumer-privacy work only; no HIPAA claim | Keeps R9 honest | `[inferred]` from R9 | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (permission not granted) and no page was fetched. Would have verified the employer and the posting (RR1) |
| 2. Role-family sweep | unavailable | Refused with the rest. Would have set a pay band for this title; no band is given here |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- The careers-page link or the live posting URL → RR1 closes, and the conditional cap lifts.
- Any salary range in the posting or the recruiter's reply → a pay band can be set against it.
- A sanitized memo, readout, or dashboard screenshot → R3, R4 and R5 move from `medium` to `high`.
- Answers to G6, G7 and G9 → R6, R7 and R9 get a row each.
- A search-enabled run → the two refused targets run, and the employer check and pay band come back.

I can also emit a `tuesday-dossier.md` for this role if you want the map and register kept for later turns.

**Questions**

- G6: Did you own the metric definitions for the company, or consume them? Give one definition you set, and who signed off on it.
- G7: Have you formally mentored or managed junior analysts? If so, what did you own: reviews, hiring, development plans?
- G9: Have you worked with health data, or any HIPAA-covered data, even briefly?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.