**No, don't pursue it on these terms.** Your two stated limits both fail on the posting's own text: base pay tops out at $85k against your $150k floor, and the role is on-site in Austin five days a week with "no exceptions." `no_go`.

**Fit ledger.**
- `hard_gate` — failed: R1 (base pay), R2 (on-site location)
- `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM) · unclear: R6 (SEO/content, brand, PR, partnerships, sales ops)
- `important` — unclear: R7 (ambiguity, evolving success metrics)

R1 and R2 are hard gates, so the fit match elsewhere doesn't rescue the decision. R3–R5 are confirmed in your intake but unprobed (`medium`). R6 and R7 have no evidence either way.

**Opportunity ledger.** The role is under-specified and expects a lot: one person to start across seven growth functions with no team (RR3), always-on hours (RR2), and success metrics that will change (RR4). The company's Series A and profitability claims are unverified (RR5).

- **Hard gates:** failed: R1 (base pay), R2 (on-site location)
- **Severe red flags:** none found
- **What would change this:** the posted base would have to reach $150k and the role would have to be remote-compatible from Portland. Nothing else in the posting resolves either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's self-description; not checked |
| Mandate | Own all revenue growth across paid, SEO/content, lifecycle, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Schedule | On-site Austin, five days; evenings and weekends "when it matters" | `[grounded]` posting |
| Market calibration | Not run; search permission was refused, so there is no role-family band | — |
| Contradictions | Seven functions and end-to-end accountability against a team of one and a $70–85k base | `[inferred]` from the posting's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay ($70–85k posted; your floor $150k) | hard_gate | hard_gate_fail | high | hard_gate | Posted top is $65k under your floor. Confidence grades your own floor, not the role | `[grounded]` posting; your stated floor | none; only the employer changing its base resolves this |
| R2 | Remote-only from Portland vs on-site Austin 5 days, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Posting rules out remote; you won't relocate | `[grounded]` posting; your stated constraint | none; only the employer changing terms resolves this |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two subscription companies. Stated, no artifact yet | `[grounded]` your intake | none |
| R4 | Paid acquisition ownership | must_have | direct | medium | none | Owned paid at both companies, per your account | `[grounded]` your intake | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze, per your account | `[grounded]` your intake | none |
| R6 | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Not in your stated background; no evidence either way | `[grounded]` absence from your intake | none needed for this decision |
| R7 | Thrive on ambiguity; success metrics evolve | important | unclear | low | discovery | You scaled $8M to $40M ARR with your own budget, but ambiguity and shifting metrics are not described | `[inferred]` from your intake | none needed for this decision |

## Gap recovery queue

No gap here changes the decision: the two gates are settled by the posting's own terms. The queue is empty of questions by design.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay far below the mandate | risk_signal | medium | "$70–85k base plus meaningful equity upside" | Base may be set for a junior hire, with equity carrying more of the package | `[inferred]` from the range against 8+ years and seven functions; market band not established | "Is the base range fixed, and what is budgeted for this role in total?" | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours may run past the stated schedule | `[generic]` "just who we are" phrasing often signals unscheduled demands | "What does a typical week look like for this role, including after-hours requests?" | unresolved |
| RR3 | Responsibility without resources | risk_signal | medium | "a team of one to start … we don't need a bench" | Accountability for seven functions with no committed team or budget | `[inferred]` from the posting's scope against its silence on budget | "What team, budget and decision rights come with this role in year one?" | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Performance may be judged on criteria set after the fact | `[inferred]` from the posting's own wording | "What three metrics define success at six and twelve months, and who sets them?" | unresolved |
| RR5 | Company claims unverified | unknown | — | "Series A, profitable since day one" | Stage and profitability are the posting's own claims | `[grounded]` posting; research not run | "Can you share your latest funding announcement and profitability timeline?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply on the posted terms | R1 and R2 fail | `[grounded]` R1, R2 | recommended |
| P2 | If you want to test it anyway, ask the recruiter in writing whether the role is open to remote and what base is budgeted | Only the employer can change either gate | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: your two constraints, R1 and R2, at `high`. Your experience claims (R3–R5) are user-stated at `medium` and not yet probed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked Novaline exists and the posting is live (RR5). Search permission was not granted in this session |
| 2. Role-family sweep | unavailable | Would have set a market band for pay and scope (RR1). Search permission was not granted; no band was taken from memory |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Even with both searches, the two gates would stand: they come from the posting's terms against your stated limits.

**Upgrade menu**
- A remote-compatible posting, or a base that reaches $150k → R1 and R2 could move, and the decision could become `hold_pending_answers`.
- Search permission → verifies Novaline and calibrates pay (RR1, RR5). It cannot clear the two gates.
- Inspectable artifacts, such as a growth dashboard, paid-channel results or a Braze lifecycle program → R3–R5 move from `medium` to `high`.
- A prior resume → checks R3–R5 against a written record.

If you want a `tuesday-dossier.md` from this assessment, I can emit one for later use in interview prep. Say so and I'll write it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.