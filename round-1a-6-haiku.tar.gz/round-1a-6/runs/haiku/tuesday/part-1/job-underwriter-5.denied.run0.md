**Yes, worth applying, on three conditions: `conditional_go`.** The must-haves match your background closely. BigQuery is the one real gap, and two checks are still open: your location and pay floor, which you haven't given me, and whether the employer checks out, which I couldn't search.

- **Fit ledger.**
  - `hard_gate` — unclear: R9 (Work location: remote US or Denver), R10 (Base pay against your floor)
  - `must_have` — direct: R1, R2, R3, R4, R5
  - `important` — adjacent: R6 (BigQuery warehouse); unclear: R7 (Ingestion from app and CRM), R8 (Data contracts for analysts)

  R1 6 years; R2 SQL and Python daily; R3 dbt on Snowflake; R4 Airflow; R5 Great Expectations suite; R6 Snowflake, not BigQuery; R7 and R8 not in your background; R9 and R10 not yet given. Every must-have is `direct` at `medium`, the ceiling for prose background that nothing has inspected yet.

- **Opportunity ledger.** Pay sits inside the report's interquartile range (RR2), and the scope is wider than a typical single-domain role (RR1). Equity is unquantified (RR3), and I could not verify the employer from here (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Work location: remote US or Denver), R10 (Base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 and R10 confirmed: you're US-based or in Denver, and the base meets your floor; (2) RR4 cleared: the role appears on Pellucid's own careers page; (3) R6 framed as Snowflake transfer, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company About page as you pasted it; self-reported, not verified |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse in BigQuery, and analyst data contracts | `[grounded]` JD |
| Seniority | "Senior" with 5+ years required | `[generic]` report: "senior" typically means 5–8 years |
| Scope read | Three areas (ingestion, warehouse, contracts) in one post, a wider remit than one domain's pipelines | `[inferred]` from the JD's three named areas, against `[generic]` typical scope of one domain, no direct reports |
| Market calibration | Posted base $148k–$166k; report median $151k, interquartile range $139k–$163.5k; the posting sits inside that band | `[grounded]` JD figures; `[generic]` band from the Datawright report you shared |
| Unknowns | Equity size and vesting; hiring manager (none named); team; contract type | — |
| Contradictions | None between the JD and the About page as you pasted them. Not checked against the live careers page (search unavailable) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated; not yet inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, stated | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse; stated | `[grounded]` your background | a sanitized dbt repo excerpt would raise to `high` |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R5 | Experience with data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated | `[grounded]` your background | none |
| R6 | BigQuery warehouse (named in the JD's responsibilities) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is unused. Limit: no BigQuery experience | `[inferred]` adjacency from the Snowflake work you described | see G1 |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background; could exist | `[grounded]` silence in your background | see G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background; could exist | `[grounded]` silence in your background | see G3 |
| R9 | Work location: remote US or Denver | hard_gate | unclear | none | hard_gate | No constraint given, so nothing to grade; the check is unknown | `[grounded]` JD; no candidate statement | answer Q1 |
| R10 | Base pay against your floor | hard_gate | unclear | none | hard_gate | No floor given; posted base is $148k–$166k | `[grounded]` JD; no candidate statement | answer Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake dbt work, no BigQuery | The posting names it, so it will come up | Any BigQuery use, including a sandbox or a course project; dbt adapter work across warehouses | A dbt project or a BigQuery project you touched | `[inferred]` bridge from Snowflake work; `[generic]` that interviewers test named tools |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Not stated | Named in the JD's first responsibility | Pipelines from an app database or a CRM API; Fivetran or similar connectors you configured | A pipeline diagram or DAG listing | `[grounded]` silence in your background |
| G3 | Data contracts (R8, important) | discovery | Not stated | Named as what analysts depend on | Schema tests, dbt model contracts, or agreed table SLAs with analysts | A contract doc or dbt schema YAML | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope bundles three areas into one post | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse …, and the data contracts" | The role may be a platform role across teams, not one domain | `[inferred]` from the JD's three areas; `[generic]` typical single-domain scope | Which of the ingestion, warehouse and contract work sits with this role, and which sits with app or CRM teams? | unresolved |
| RR2 | Pay sits inside the provided band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is at market for this seniority | `[grounded]` JD figure; `[generic]` band from the report | Is $148k–$166k the base range, and is the top of it reachable at this level? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity could be meaningful or token | `[inferred]` from the posting's silence on size | What is the equity grant size, its vesting schedule, and the strike price basis? | unresolved |
| RR4 | Employer not verified from here | unknown | — | "pellucidlearning.com/careers/senior-data-engineer" | Pellucid may be real and as described; the search that would confirm it did not run | `[generic]` standing caution, not a claim about this employer | Can you point me to this role on your own careers page, and who is the recruiter? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor before investing in the application | R9, R10 | `[grounded]` gate rows | pending your answer |
| A2 | Find the live posting on Pellucid's careers page and ask the recruiter for the hiring manager and team | RR4 | `[generic]` pattern: unverified postings go stale | pending your approval |
| A3 | Describe the BigQuery gap as: "I've built and run a dbt project of about 180 models on Snowflake; I haven't used BigQuery yet." | R6 | `[grounded]` your background; proposed language, audited against it | pending your approval |
| A4 | Tailor the CV to this posting with the resume-tailor module | Next step once A1 and A2 clear | — | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed the employer exists, the posting is live, and the Series C and headcount figures. Web search was refused by permission, so RR4 stays open |
| 2. Role-family sweep | unavailable | Would have cross-checked the Datawright band and scope norms. The provided report is used instead, labeled `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Three searches were refused and none ran. Those refusals count against the budget, as the line above shows.

Once you grant web search, I can run the L1 checks on targets 1 and 2 (up to 5 searches and 2 fetches).

## Upgrade menu

- The live posting from Pellucid's careers page, or the recruiter's email domain → RR4 clears or stays open; the decision can move to `go` once it does.
- Your US location and your base-pay floor → R9 and R10 move from `unclear` to `direct` or `hard_gate_fail`; the decision moves with them.
- A dbt repo excerpt or model-count screenshot → R3 to `high`.
- Any BigQuery exposure, even a sandbox → R6 moves from `adjacent` to `direct` for the claim you can make.
- The equity grant size and vesting → RR3 closes.
- The hiring manager's name → the scope read and the positioning for that reader.

If you want this saved as `tuesday-dossier.md` for later use, I can emit it.

1. Are you based in the US, and would remote-US or a Denver office work for you?
2. Have you used BigQuery at all, even in a sandbox, a course, or a side project? Have you built pipelines that ingest from an app database or a CRM?
3. What is your base-pay floor for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.