**Yes, it's worth applying to, on three conditions. Status: `conditional_go`.**

Your core stack matches the posting. BigQuery is the one real gap, and it's recoverable from Snowflake work. Two hard gates (location and pay floor) are unconfirmed because I don't have your constraints, and the employer isn't verified from here.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver location), R2 (salary and pay floor)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 — the one real gap, transferable from Snowflake work with its limits named. R1 and R2 — gates you haven't answered. R9 and R10 — not in your background, so unknown rather than missing.

**Opportunity ledger.** Stage, scale and pay are on the positive side (RR4, RR3). Scope, team and equity are unknown (RR1, RR5). The employer isn't verified from here (RR2, `severity: medium`).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (salary and pay floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 check out against your location and pay floor; (2) RR2 clears: the posting is live on the company's own careers page; (3) R8 is framed as transferable, never as BigQuery experience, with a sandbox artifact if you can build one before interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` the about page you pasted; not checked here |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts | `[grounded]` JD |
| Working pattern | Remote US or Denver office | `[grounded]` JD |
| Scope read | Ownership of one domain's pipelines, no reports named; consistent with the usual scope for this title | `[generic]` the Datawright norm you shared; `[inferred]` that no reports is the posting's silence on them |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500, typical 5–8 years. The posted $148,000–$166,000 brackets the median; its midpoint ($157,000) sits inside the IQR | `[generic]` the Datawright 2026 report you shared (n=2,310); a pattern, not this employer's offer |
| Contradictions | The requirement asks for "a cloud warehouse"; the duties name BigQuery specifically. Read as: BigQuery is the platform you'd run | `[grounded]` JD |
| Unknowns | Team size and on-call; ingestion ownership; data-contract ownership; equity size and vesting; the hiring manager (none named) | — |

## Evidence map

Confidence is capped at `medium` on intake prose, since nothing has been inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location and work-arrangement constraint isn't stated, so the gate isn't established | `[grounded]` JD; your constraint not given | Q1 |
| R2 | Base $148,000–$166,000 against your pay floor | hard_gate | unclear | none | hard_gate | No floor given. The range sits around market median | `[grounded]` JD figure; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; prose only, no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, as you stated | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 models on Snowflake meets "a cloud warehouse" | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; expect a probe on coverage | `[grounded]` your background | none |
| R8 | BigQuery warehouse (in the duties) | important | adjacent | medium | transferability | Snowflake dbt and SQL work carries over; BigQuery-specific operations are untested | `[inferred]` transfer from Snowflake work; `[generic]` BigQuery specifics such as partitioning and bytes-scanned cost | G1, Q3 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background, so not established either way | `[grounded]` silence in your background | upgrade menu |
| R10 | Data contracts analysts rely on | important | unclear | none | discovery | Not in your background | `[grounded]` silence in your background | upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8, important) | transferability | Snowflake dbt and SQL work; no BigQuery | The posting names BigQuery in its duties, so it's the platform you'd run daily | Any dbt model or scheduled query on another cloud warehouse; cost or partitioning decisions on Snowflake; a sandbox BigQuery project | A sandbox project with one dbt model and one partitioned table, with the repo link | `[inferred]` transfer from Snowflake work; `[generic]` that BigQuery-specific limits are the likely probe |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Not in your background | Two of the duties are unevidenced, so the role's core could be a gap | Pipelines that pull from an app database or a CRM; any schema or interface agreement with downstream analysts | A pipeline diagram or an interface doc | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and team unstated | unknown | — | "Build and run the pipelines" | The role may be a one-person platform with no on-call rotation | `[generic]` pattern for data-platform roles | Who else works on the data platform, and who is on call for these pipelines? | unresolved |
| RR2 | Employer not verified from here | risk_signal | medium | "Pellucid Learning runs live online tutoring" | Web search was refused, so the entity and the posting's liveness are unchecked; the company may be real and simply unverified | `[generic]` pattern for companies this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay sits at market | positive_signal | — | "$148,000–$166,000 plus equity" | The posted range is a credible offer for this band | `[grounded]` JD figure against `[generic]` band | What is the base range's position for this level, and is it negotiable? | noted |
| RR4 | Stage and scale stated | positive_signal | — | "Series C ($52M, February 2026)" | Funding and headcount suggest an established data function | `[grounded]` the about page you pasted; `[inferred]` that a company this size has a data team | — | noted |
| RR5 | Equity unsized | unknown | — | "plus equity" | Equity could be a large part of total pay or close to nothing | `[generic]` pattern for equity offers | What is the equity grant, and how does it vest? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting is live on the company's own careers page before applying | RR2 | `[grounded]` RR2 | your action |
| P2 | Resume line, no BigQuery claim: "Built a dbt project of about 180 models on Snowflake; used Airflow for orchestration; set up a Great Expectations test suite. New to BigQuery." Every clause traces to your sentences | R5, R6, R7, R8 | `[grounded]` your background; "new to BigQuery" is your own statement | `resume_edits_pending_approval` |
| P3 | Ask RR1 and RR5 verbatim in the first recruiter or hiring call | Register doubles as interview prep | `[grounded]` register | pending your approval |
| P4 | Build a small BigQuery sandbox project and keep the repo link | G1 | `[generic]` that a sandbox artifact is what this field keeps | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The web search was refused by permission, so the employer and whether the posting is live are not checked from here. The company facts are as you pasted them. Would have moved RR2 |
| 2. Role-family sweep | skipped | The Datawright figures you shared (median, IQR, 5–8 years, scope norm) are in hand, so the band is fixed without a search |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The live posting or the recruiter's email domain → RR2 closes, and the employer is verified.
- Your location and pay floor → R1 and R2 close, and the decision can move to `go`.
- A BigQuery sandbox project or dbt repo → R8 moves toward `direct` with a real artifact.
- A sentence or two on ingestion and data-contract work → R9 and R10 come off `unclear`. I didn't ask this turn, to keep to three questions.
- The hiring manager's name → the scope read (RR1) and which story to lead with.
- Granting web-search permission → I can run the employer check (target 1) and verify RR2 against the live posting.

I can write this up as `tuesday-dossier.md` on your word, so the register and gap queue carry into interview prep.

1. **R1** — Are you based in the US, and would remote work or a Denver office work for you?
2. **R2** — Is a base of $148,000 above your floor?
3. **G1** — Have you run anything on BigQuery, such as a sandbox project, a scheduled query or a partitioned table? If not, what's the closest you've done on another warehouse for cost or partitioning?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.