## Decision snapshot

Yes, on conditions: **`conditional_go`**. On what you've told me, your experience matches the must-haves. Apply once the posting is confirmed on Brindlemoor's own careers page and the UK-remote gate is confirmed.

**Fit ledger.**

- `hard_gate` — unclear: R8 (fully remote, UK-based)
- `must_have` — direct: R1, R2, R3, R4
- `important` — direct: R5, R6; adjacent: R7 (pet-insurance product)
- `preferred` — direct: R9 (insurance experience)

What matters: R3 is your strongest proof but has no artifact yet (`medium`); R7 is the objection most likely to come up; R8 is the one gate nobody has confirmed.

**Opportunity ledger.** The outcomes are concrete: build and monitor rating models, run and read price tests, recommend to underwriting. The posting is silent on line management and salary (RR2, RR4), and I could not check the employer at all in this run (RR1).

- **Hard gates:** none failed; unconfirmed: R8 (fully remote, UK-based). Your residence and right to work weren't in what you gave me, so checks against them are unknown. Met: none `direct`.
- **Severe red flags:** none found.
- **What would change this:** (1) the posting appears on Brindlemoor's own careers page (RR1); (2) you confirm UK residence and right to work (R8); (3) the line-management question (RR2) comes back workable for you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech | `[grounded]` JD header only; not verified |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior analyst scope with model ownership and a recommending role; no people leadership stated | `[inferred]` from the responsibility list against its silence on team |
| Market calibration | Not run: the role-family search was refused, so there is no band | — |
| Unknowns | Line management; salary; decision rights over rate changes; depth of pet claims data; company stage | — |
| Contradictions | None visible from the JD alone; the careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in motor pricing analytics, the last two senior | `[grounded]` your statement; no artifact | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement; no artifact | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the young-driver GLM, which is specific and direct | `[grounded]` your statement; no artifact | W1 would raise to high |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, the exact audience named | `[grounded]` your statement; no artifact | E1 |
| R5 | Design and read price tests | important | direct | medium | none | Fourteen tests run last year with underwriting; the JD's responsibility is implied, not a listed requirement | `[grounded]` your statement; JD responsibility | W1 |
| R6 | Build and monitor rating models | important | direct | medium | none | Maintaining a live GLM is monitoring-adjacent; building is direct | `[grounded]` your statement; JD responsibility | none |
| R7 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Rating methods (GLMs, rating factors, test design) carry over from motor. Limit: nothing on pet-specific drivers such as breed, species, lifetime versus annual cover, or vet-cost inflation | `[inferred]` from your motor work against the product named in the JD | see G1 |
| R8 | Fully remote, UK-based (your residence and right to work) | hard_gate | unclear | low | hard_gate | The posting sets the terms; nothing you gave me confirms your side of it | `[grounded]` JD term; candidate side not given | Q1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement; no artifact | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R7, important) | transferability | Motor rating work is direct; nothing on pet-specific risk drivers or products | The most likely objection in an interview, and it touches the product Brindlemoor names | Any work on claims, lapse or frequency analysis outside motor; reading or building on vet-cost or breed data; benchmarking another product line | A short note on how you'd adapt a motor GLM to pet risk drivers; a pet-data sample | `[inferred]` bridge derived from your motor work; `[generic]` that pet risk drivers differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified in this run | unknown | — | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The posting may be stale or aggregated, or the company may be too new or small for a web footprint. This run could not check, so this is unverified, not found missing | `[generic]` pattern for companies of this size; not a finding about this one | Can you point me at the role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Line management not stated; "Senior" title | unknown | — | "Senior Pricing Analyst" | The role may include managing people, which you have not done | `[inferred]` from the title against the silent responsibility list | Does this role line-manage anyone now or within the first year, and who would I work with day to day? | unresolved |
| RR3 | Decision rights over rate changes not stated | unknown | — | "turn the results into recommendations for underwriting and product" | You may recommend while others decide the rates | `[inferred]` from the word "recommendations" against silence on sign-off | Who signs off rate changes after a price test, and what decision rights does this role hold? | unresolved |
| RR4 | Salary withheld | unknown | — | JD gives no pay | The budget may sit below what you expect for senior pricing roles, or the company may not publish pay | `[inferred]` from the posting's silence | What salary is budgeted for this post? | unresolved |
| RR5 | Pet book may be early, with thin claims history | risk_signal | low | "build and monitor rating models" | Greenfield pet models with limited claims data would make the work harder to validate | `[generic]` pattern for new insurtech products | How much claims history does the pet book have, and which rating models already exist? | unresolved |
| RR6 | Scope and outcomes are concrete | positive_signal | — | "build and monitor rating models, design and read price tests" | The role is defined around work you already do | `[grounded]` JD responsibility list | Who owns the pet pricing roadmap, and how are recommendations acted on? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's own careers page and note the hiring contact before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter about line management, salary band and location before the first interview | see RR2, RR4, R8 | `[grounded]` RR2, RR4 | pending your approval |
| E1 | Lead the CV summary with the quarterly review to the head of underwriting and the fourteen price tests, with the scope stated | see R4, R5 | `[grounded]` your statements | pending your approval |
| W1 | A one-page sanitised case study of a GLM build or price test, with company identifiers removed | see R3, R5, and the path to high confidence | `[grounded]` R3, R5 rows | pending your approval |
| P1 | Position pet as adjacency: motor rating methods carry over, and pet-specific drivers would be new to you. Do not claim pet experience | see R7 limit | `[inferred]` R7 | pending your approval |

## Evidence status

Verified: R1, R2, R3, R4, R5, R6, R9 claims, sourced to your statements in this message. Verified is about the claim, not the fit. None has an artifact yet, so confidence stays `medium`. R7 is a verified adjacency, not a verified match. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Brindlemoor insurtech pet insurance" and "Brindlemoor careers Senior Pricing Analyst" were both refused by the search permission, so nothing returned. Would have moved the organization row, the JD-versus-careers-page check and RR1 |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst pet insurance UK salary GLM" was refused. Would have moved the market calibration line and RR4's band |
| 3. Hiring manager's public footprint | unavailable | Hiring manager Odile Varga is named, so the query could be formed, but search was refused and I did not retry. Would have moved the scope read and the positioning for this reader |

Assessment rests on your statements and the posting alone. I did not retry refused searches.

Dossier offer: I can write this out as a `tuesday-dossier.md` for you to keep, if you'd like.

## Upgrade menu

- Brindlemoor's live posting from its own careers page: closes RR1, one of the three conditions.
- The budgeted salary, or the salary band the recruiter gives: closes RR4 and sets it against the band.
- A sanitised GLM rating-factor summary or a price-test readout: R3 and R5 go to high.
- Permission to run web search: the three targets above run, within the L1 caps of 5 searches and 2 fetches.

## Questions

**R8:** Are you resident in the UK with the right to work here?

**RR2:** Would you apply if this role line-managed one or two analysts, given you haven't managed people before?

**RR1:** Do you have the link to the posting on Brindlemoor's own careers page?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.