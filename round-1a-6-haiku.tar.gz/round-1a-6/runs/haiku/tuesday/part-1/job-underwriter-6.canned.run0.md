**Decision: conditional go.** Apply. Your pipeline, renewal and Salesforce work is a strong match, and the company looks real. The two gaps are forecast ownership and billing data, and the posting asks for both. Apply with a clear answer on each, and confirm the two open items below before you spend a lot of time on it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page confirms Bristol, UK invoicing and payments software for builders' merchants, founded 2018, 96 staff, £11M Series A (April 2025) [grounded]. The careers URL I tried returned nothing, so the posting is not confirmed on the company's own site. |
| 2 | Role-family sweep (pay) | yes | Ledgerline 2026 UK pay guide: revenue operations lead, UK B2B software, median base £64,200, IQR £57,800–£70,400 [generic]. |
| 3 | Hiring manager footprint | yes | Search result: Tamsin Achebe, Head of Revenue Operations at Quillfield; previously four years as sales operations manager at Corvane Payments [grounded, from a search snippet only]. |

**Decision snapshot**
- Decision: `conditional_go`
- Hard gates: location (Bristol, two office days a week) is unknown because your location isn't in the brief. Pay (£61,500–£67,000) is unknown because your floor isn't in the brief. No hard gate has failed.
- Fit, must-haves: Salesforce admin, met (certified). SQL and spreadsheets, met (weekly and daily), though your evidence is reporting, not modelling. Four-plus years in RevOps or sales ops, met, with the caveat that your employer is B2B payments rather than software. Owning a company forecast, gap. Finance work on billing or revenue data, gap.
- Fit, preferred and implied: pipeline and renewal reporting, met and strong. Monthly pipeline review, met. Owning CRM and billing data, partial (CRM yes, billing no).

**Role reality**
- Hybrid Bristol, £61.5k–£67k plus share options. You would own CRM and billing data, the pipeline and renewal reporting, and the quarterly revenue forecast with the CFO.
- Market calibration: the posted band sits at the generic median and inside the IQR [generic].
- Hiring manager: Tamsin Achebe, Head of RevOps. This role probably reports to her [inferred from title].

**Evidence map** (confidence: H = high, M = medium, L = low)

| Requirement | Fit | Confidence | Your evidence |
|---|---|---|---|
| Salesforce admin | met | H | Certified; rebuilt pipeline and renewal dashboards |
| SQL and spreadsheet modelling | partial | M | SQL weekly, Excel daily; reporting, not modelling |
| 4+ years RevOps or sales ops at B2B software | partial | M | 5 years at a B2B payments company |
| Owning a forecast | gap | L | Finance owned it |
| Finance work on billing or revenue data | gap | L | No billing data experience |
| Pipeline and renewal reporting | met | H | Core of the last two years |

**Gap recovery queue**
- *Forecast:* the posting makes this a core duty. What would close it is evidence of inputs you supplied to the forecast (stage probabilities, pipeline-weighted numbers, a finance handoff), even if finance owned the output.
- *Billing data:* what would close it is any exposure to invoice, renewal or revenue-recognition data, or an honest statement that you haven't worked with it.

**Opportunity risk register**
- Posting not confirmed on the company's own site (`severity: medium`). Ask the recruiter for the live link or the company email domain.
- Scope ambiguity (`severity: medium`): does the CFO own the forecast model, with this role supplying the inputs? Ask in the first interview.

**Application plan** (draft only; nothing is final until you approve it)
- Lead with pipeline and renewal dashboards, the Salesforce work, and the monthly review with the sales director.
- On the forecast, state only what you did. For example: "I have not owned a company forecast; I have run the pipeline review that feeds one." Don't claim forecast ownership.
- Tamsin's background is a payments sales-ops role like yours. That's a real point of overlap to use with her, but don't overstate it.

**Dossier offer:** I can save this as a `tuesday-dossier.md` for your other applications, if you want.

**Upgrade menu**
- A sample of the dashboard or SQL work (anonymised) would raise the pipeline and reporting rows to high confidence.
- Any artifact showing forecast inputs would move the forecast row from low to medium.
- Deeper company diligence (funding, leadership churn, recent news) is available as an L2 run: up to 5 more searches and 2 more fetches. Say yes if you want it.

**Questions**
1. Where are you based, and can you do two office days a week in Bristol?
2. Is £61.5k–£67k plus share options above or below your floor?
3. Did you supply any inputs to the company forecast, even if finance produced it?

Response modes: answer in text, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.