**Hold pending three answers. Lean yes: this is a credible stretch, not a stretch too far.** Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate`: unclear: R7 (hybrid, two days a week in the Bristol office), R8 (salary £61,500–£67,000 plus share options)
- `must_have`: direct: R1a (4+ years in sales or revenue operations), R2 (Salesforce admin), R3 (SQL and spreadsheets); adjacent: R1b (B2B software company, you're in payments), R5 (owning a forecast); unclear: R6 (working with finance on billing or revenue data)
- `important`: direct: R4 (pipeline and renewal reporting)

R5 is adjacent, R6 unclear: the pipeline review you run is forecast input, not forecast ownership, and the billing gap is the one the answers could move. R1 is the rare case here where the years are a direct match and the company type is not.

**Opportunity ledger.** The posting is sound and transparent: the pay sits inside the market band (RR1), and the employer checks out (RR2 is positive). Two things stay open: whether the role owns forecast sign-off or only runs the forecast with the CFO (RR3), and whether the posting is live on Quillfield's own careers page (RR4).

- **Hard gates:** none failed; unconfirmed: R7 (hybrid, two days a week in the Bristol office), R8 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** the hold waits on Q1 (R6), Q2 (R5) and Q3 (R7, R8). If Q1 turns up revenue or settlement data worked alongside finance, R6 moves to adjacent and the status likely becomes `conditional_go`. If Q3 is a no, R7 or R8 becomes `hard_gate_fail`, and the status drops to `no_go` unless Quillfield flexes the terms.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; founded 2018; 96 employees; £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about (search snippet) |
| Scope read | The role owns CRM and billing data, builds pipeline and renewal reporting, and runs the quarterly forecast with the CFO. That is broader than a standard RevOps lead | `[inferred]` from the posting's responsibilities |
| Market calibration | Median base £64,200 for UK revenue operations leads at B2B software companies; interquartile range £57,800–£70,400 | `[generic]` Ledgerline 2026 pay guide, n=438. The posted £61,500–£67,000 is `[grounded]` from the posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, per a public profile. Previously sales operations manager at Corvane Payments for four years, the same route as yours | `[grounded]` profile snippet only; the full profile was not read |
| Unknowns | Whether the posting is live on Quillfield's careers page; reporting line; whether finance signs off the forecast | — |
| Contradictions | None found between the posting and the about page (both say Bristol) | `[grounded]` |

**Evidence map** (confidence is at most `medium` for every row: nothing is verified yet)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | Five years in sales ops, the last two running RevOps; self-reported | `[grounded]` your intake | none |
| R1b | At a B2B software company | must_have | adjacent | medium | transferability | B2B payments, not software. Limit: no software-company product cycle | `[inferred]` from your employer type | Make the bridge case and state the limit |
| R2 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` your intake | Offer the certificate to lift to `high` |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; "modelling" isn't stated | `[grounded]` your intake | none |
| R4 | Build pipeline and renewal reporting that sales and finance use | important | direct | medium | presentation | Rebuilt your pipeline and renewal dashboards; the CV should lead with them | `[grounded]` your intake | Propose a CV edit (pending your approval) |
| R5 | Own the revenue forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review but never owned the company forecast; finance did. Limit: no forecast ownership or finance sign-off | `[inferred]` bridge from the pipeline review | Q2 |
| R6 | Work with finance on billing or revenue data | must_have | unclear | low | discovery | No billing data; a payments company may hold revenue or settlement data you touched | `[grounded]` your intake | Q1 |
| R7 | Hybrid, two days a week in the Bristol office | hard_gate | unclear | high | hard_gate | Your constraint isn't stated, so checks against it are unknown | `[grounded]` posting; your constraint not given | Q3 |
| R8 | £61,500–£67,000 plus share options | hard_gate | unclear | high | hard_gate | Your pay floor isn't stated, so checks against it are unknown | `[grounded]` posting; your floor not given | Q3 |

**Gap recovery queue.** Q1 closes R6. Q2 closes R5. Q3 closes R7 and R8. The questions are in the closing block.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay in market band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is stated and sits inside the band | `[generic]` band; `[grounded]` posting | — | noted |
| RR2 | Employer established | positive_signal | — | "Quillfield" | Quillfield is a funded company with a verified footprint | `[grounded]` about page | — | noted |
| RR3 | Forecast authority unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may run the forecast with finance holding sign-off | `[inferred]` from "with the CFO" against silence on decision rights | Which parts of the forecast does this role own, and which does finance sign off? | unresolved |
| RR4 | Live posting not confirmed on the employer's careers page | unknown | — | Tallyboard listing | The listing may be an aggregator copy, or the role may be filled | `[inferred]` from the listing source, not a finding about the employer | Is this role live on your careers page, and who would I report to? | unresolved |

**Application plan** (every row is a proposal, pending your approval)

- Check the role on Quillfield's own careers page before investing effort (RR4).
- Ask Tamsin Achebe the RR3 question in the first conversation.
- Lead with the pipeline and renewal dashboards (R4), and present the pipeline review as what you owned, not as forecast ownership (R5).

**Evidence status.** Verified: none yet. Every claim so far is your self-report, which is a lead for checking, not proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and got quillfield.co.uk/about. Entity established. The careers page was not fetched, so RR4 stays open |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead job description salary UK B2B software" and got the Ledgerline 2026 pay guide. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and got a public profile snippet: Head of Revenue Operations, Corvane Payments before. Positioning only; the full profile was not read |

**Dossier offer.** I can write this up as a `tuesday-dossier.md` that you can keep and update as answers come in. Say the word.

**Upgrade menu**

- Your answer to Q1 → R6 moves off `unclear`.
- Your answer to Q2 → R5 is either confirmed as adjacent or narrowed.
- Your answer to Q3 → R7 and R8 resolve.
- The careers-page link or the recruiter's reply → RR4 closes.
- Deeper research on Quillfield (funding rounds, hiring patterns; up to 5 more searches and 2 more fetches) is available if you want it.

**Questions**

Q1 (R6): Did revenue, settlement or reconciliation data from your payments company pass through your hands, working alongside finance? What did you own?

Q2 (R5): Did you ever supply the pipeline numbers or assumptions that fed a company forecast, even if finance built it?

Q3 (R7, R8): Are two days a week in the Bristol office and the £61,500–£67,000 range workable for you, or is there a figure you won't go below?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you go ahead, mock-interview can prep the round with Tamsin Achebe.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.