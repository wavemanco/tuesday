**Yes, apply, but as a conditional go.** Your core fit is strong: CRM admin, SQL, pipeline and renewal reporting, and five years in the field. The two gaps are forecast ownership and billing data, and you'd need to show credible adjacent work on both.

**Decision snapshot**

**Status: `conditional_go`.** Apply, on the conditions below.

**Fit ledger.**
- `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 plus share options)
- `must_have`: direct: R4 (Salesforce admin), R5 (SQL and spreadsheets); adjacent: R3 (B2B software), R6 (forecast ownership); unclear: R7 (finance-facing revenue data)
- `important`: direct: R8a (CRM ownership), R9 (pipeline and renewal reporting); absent: R8b (billing data)

R6 — pipeline review is a real bridge, forecast ownership is not yet shown; R8b — no billing work, nearest adjacency not yet examined.

**Opportunity ledger.** Sound on the posting's own terms: stated pay and share options (RR2), and a defined scope (RR3 is a bundling risk, not a red flag). Open: the posting isn't confirmed on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show forecast-adjacent work beyond the monthly pipeline review, such as commit calls or inputs you built for finance; (2) you can describe one piece of revenue data work done with finance, even if it isn't billing; (3) the posting is confirmed live on Quillfield's own site.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | UK invoicing and payments software for builders' merchants; founded 2018 in Bristol, 96 employees, £11M Series A (April 2025) | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile snippet |
| Scope read | Three roles folded into one title: CRM and billing ownership, forecasting, and reporting | `[inferred]` from the JD's three responsibility clauses |
| Pay | £61,500–£67,000 plus share options. One 2026 UK survey puts revenue operations leads in B2B software at a median of £64,200 (interquartile range £57,800–£70,400) | JD `[grounded]`; survey `[generic]`, one guide, not this employer's offer |
| Unknowns | Whether billing data sits with this role or with finance; how much of the forecast this role owns; whether the posting is live on Quillfield's own site | — |
| Contradictions | None found between the JD and Quillfield's about page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in office | hard_gate | unclear | medium | hard_gate | Your location and office tolerance weren't given | `[grounded]` JD | Q3 |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | medium | hard_gate | Your pay floor wasn't given | `[grounded]` JD | Q3 |
| R3 | 4+ years in RevOps or sales ops at a B2B software company | must_have | adjacent | medium | transferability | Five years, but at a payments company, not software | `[inferred]` from your intake | Confirm the software-company angle in the CV |
| R4 | HubSpot or Salesforce admin | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` your intake | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; no modelling example yet | `[grounded]` your intake | none |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Monthly pipeline review is an input to forecasting; you never owned the forecast | `[inferred]` bridge | G1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Pipeline and renewal data are revenue data; finance collaboration isn't established | `[grounded]` your intake, silent on finance work | G2 |
| R8a | Own CRM data | important | direct | medium | none | Salesforce admin | `[grounded]` your intake | none |
| R8b | Own billing data | important | absent | none | transferability | Never worked on billing; payments-company adjacency unexamined | `[grounded]` your intake | G2 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt both dashboards; no artifact inspected | `[grounded]` your intake | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Pipeline review with the sales director; forecasting owned by finance | Forecast ownership is in the must-have tier and the JD asks for it by name | Commit or best-case calls at the monthly review; a pipeline-to-forecast input you built; a forecast accuracy check against actuals | Forecast template, review deck, or a call log | `[inferred]` bridge; `[generic]` that forecasting ownership is the likeliest objection |
| G2 | Billing or revenue data with finance (R7, R8b) | discovery | No billing work; revenue reporting only | Two rows at unclear and absent, in the must-have and important tiers | Reconciling pipeline to invoiced revenue; renewal-to-billing handoffs; any finance-facing revenue figure | A reconciliation sheet, a renewal report, or a finance handoff | `[grounded]` intake silence; `[generic]` that revenue ops roles usually touch billing |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | risk_signal | low | Posting at jobs.tallyboard.example; quillfield.co.uk/careers returned no page | The role may be on another board or stale | `[grounded]` search and fetch; `[generic]` that third-party postings lag | Is this role live on Quillfield's own careers site, and who would I interview with? | unresolved |
| RR2 | Pay and share options stated | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is visible and sits near the survey median | `[grounded]` JD; `[generic]` survey | Is the £61,500–£67,000 range fixed, and how do the share options vest? | noted |
| RR3 | Responsibilities bundled across three roles | risk_signal | low | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may be overloaded or split with finance | `[inferred]` from the JD's three clauses | Which of CRM, billing data and the forecast sits with this role day to day, and which stays with finance? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the live link and whether the role is on Quillfield's own site | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put the RR3 question to the recruiter before the first interview | Scope is the biggest unknown | `[grounded]` RR3 | pending your approval |
| A3 | No CV or outreach edits proposed yet | Need G1 and G2 answers first | `[grounded]` gap queue | — |

**Evidence status**

Verified: none yet. Your intake is self-report, so every claim is a lead until you confirm specifics.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead" and "Quillfield invoicing software company Bristol", which returned quillfield.co.uk/about (Bristol, 96 employees, Series A). Fetched quillfield.co.uk/careers: no page returned, so the posting is not confirmed on the company's own site (RR1) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software"; fetched "Ledgerline 2026 UK Revenue Operations Pay Guide" (median £64,200). Feeds the pay calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned her public profile snippet (Head of Revenue Operations at Quillfield; previously Corvane Payments). Role reality's scope read only |

Dossier offer: I can write this analysis to `tuesday-dossier.md` for later use, if you want it.

**Upgrade menu**
- A link to the live posting, or the recruiter's confirmation → RR1 closes.
- Forecast work from G1 → R6 moves from adjacent toward direct.
- A billing or reconciliation example from G2 → R7 and R8b move.
- An inspectable artifact such as a pipeline dashboard screenshot → R9 moves from medium to high.
- Your location and pay floor → R1 and R2 close, and the hard-gates line can clear.
- A deeper research pass on Quillfield (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

Q1 (G1): When the monthly pipeline review fed a number the business committed to, what did you actually decide: which deals counted, how the call was made, and was it checked against actuals afterwards?

Q2 (G2): Have you ever worked on a revenue figure that had to reconcile with finance, such as invoiced revenue, renewals into billing, or the revenue line in a board pack? Who owned it?

Q3 (R1, R2): Are Bristol two days a week and £61,500–£67,000 workable for you? These are gate checks, not a negotiation.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.