**Yes, with conditions.** Apply if you can answer the location question and the forecast question below in your favour. You match the tooling and reporting half of this role well. The forecast and billing-data half is a real stretch. This is my recommendation, and the call is yours.

**Decision snapshot**

- **Status:** `conditional_go`. Apply; the conditions are listed under "What would change this."
- **Fit ledger:**
  - `hard_gate`: unclear R1 (Bristol base, hybrid two days a week in office)
  - `must_have`: direct R2 (4+ years), R4 (Salesforce admin), R5 (SQL), R10 (pipeline and renewal reporting); adjacent R3 (B2B software company), R6 (spreadsheet modelling), R7 (owning a forecast), R8 (billing data); unclear R9 (working with finance on revenue data)
  - R2, R4, R5 and R10 are where your record matches the posting. R7 and R8 are the stretch. R9 and R1 are unknowns you can answer.
- **Opportunity ledger:** The posting is clear about scope and pay, and I see no red flags in its text (R-entries below). The employer is unverified: this is the Tallyboard Jobs listing, not Quillfield's own careers page, and I haven't checked either (research not run).
- **Hard gates:** none failed; unconfirmed: R1 (Bristol base, hybrid two days a week in office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `conditional_go` are:
  1. Bristol with two office days a week is workable for you (R1).
  2. The forecast is one you build and defend, not inputs to a finance process that you only support (R7).
  3. Billing data is learnable from the posting's own tools, and finance collaboration is a real part of the role (R8, R9).

**Role reality**

- Quillfield, B2B invoicing software `[grounded: posting, your description]`
- Bristol, hybrid, two days a week in office `[grounded: posting]`
- £61,500–£67,000 plus share options `[grounded: posting]`
- Scope: owns CRM and billing data, builds pipeline and renewal reporting for sales and finance, runs the quarterly revenue forecast with the CFO `[grounded: posting]`
- Hiring manager Tamsin Achebe: from the recruiter, not on the posting, not verified `[grounded: recruiter]`
- Market calibration: not run `[generic]`. The salary band cannot be checked against market yet.
- Contradictions: none. The posting is consistent in what it asks.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | hard_gate | Bristol base, hybrid two days a week in office | unclear | low | discovery | Your location isn't in what you gave me | `[grounded]` posting |
| R2 | must_have | 4+ years in revenue ops, sales ops or analytics | direct | high | — | 5 years sales ops; last 2 running RevOps for the UK team | `[grounded]` your background |
| R3 | must_have | Experience at a B2B software company | adjacent | medium | transferability | B2B payments company. Limit: payments, not software | `[inferred]` |
| R4 | must_have | HubSpot or Salesforce administration | direct | high | — | Salesforce admin certified | `[grounded]` |
| R5 | must_have | Strong SQL | direct | medium | — | SQL weekly. Weekly use is not proof of strength | `[grounded]` |
| R6 | must_have | Spreadsheet modelling | adjacent | medium | transferability | Excel daily. No modelling work described | `[grounded]` |
| R7 | must_have | Owning a forecast (quarterly revenue forecast with the CFO) | adjacent | low | transferability | Ran the monthly pipeline review with the sales director. Never owned the company forecast; finance did. Limit: inspecting pipeline is not owning the number | `[grounded]` + `[inferred]` |
| R8 | must_have | Working with billing data (owning CRM and billing data) | adjacent | low | transferability | Never worked on billing data. Renewal and pipeline data is revenue-adjacent. Limit: no billing system work | `[grounded]` + `[inferred]` |
| R9 | must_have | Working with finance on billing or revenue data | unclear | low | discovery | Not described either way | `[generic]` |
| R10 | must_have | Building pipeline and renewal reporting for sales and finance | direct | high | — | Rebuilt pipeline and renewal dashboards | `[grounded]` |

**Gap recovery queue** (no questions here; the questions are in the closing block)

- **G1 (R7, transferability):** Adjacent: monthly pipeline review with the sales director. Limit: no forecast ownership. Strengthener: any example where you set, challenged or defended a forecast or commit number, even as an input to finance. This would move R7 from `low` toward `medium`.
- **G2 (R8, transferability):** Adjacent: renewal and pipeline data. Limit: no billing data. Strengthener: any work reconciling pipeline or renewals to booked or invoiced revenue.
- **G3 (R9, discovery):** Whether you worked with finance on revenue numbers at all.

**Opportunity risk register**

- **Unknown:** Whether this role owns the forecast number or prepares inputs for the CFO. The posting says "run the quarterly revenue forecast with the CFO," which can mean either. Verification question for the employer: "Does this role own the final forecast number, or prepare inputs for the CFO to sign off?"
- **Unknown:** Employer not verified. The posting is hosted on Tallyboard Jobs. Verification question for the employer: "Which team posted this role, and who would I be interviewing with?"

**Application plan**

- Before applying, ask the recruiter the forecast-ownership question. The answer decides whether to lead on R7 or position around it.
- Lead the CV with R4, R5 and R10: Salesforce admin, weekly SQL, and the pipeline and renewal dashboards you rebuilt. The R2 years line supports them.
- Describe the monthly pipeline review as what it was. Do not describe it as forecasting. Any forecast-adjacent example needs your own confirmation before it goes in.
- No CV language is proposed yet. Any wording needs your approval before it is used.

**Evidence status**

Research tier: L0 — no searches; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Quillfield's official site and careers page | skipped | Not run in this pass; research was not consented to |
| 2 | Role-family sweep (scope, title, pay for this seniority) | skipped | Not run in this pass |
| 3 | Tamsin Achebe's public professional footprint | skipped | Not run in this pass |

Dossier offer: I can save this analysis as `tuesday-dossier.md`, so a later interview-prep run can pick it up.

Upgrade menu:
- Research at the default tier (up to 5 searches and 2 page fetches). This would check that Quillfield exists and the role is live on its own site, give a market salary band, and read Tamsin Achebe's public professional footprint. I'll only run it if you say yes.
- Your salary floor and any non-negotiables. This unlocks the hard-gate checks against you.
- Your CV as a document. This moves R5, R6 and R10 from what you've told me to evidence I can read.
- Quillfield's own careers-page link, or the recruiter's email domain. This resolves whether the employer is verified.

Questions:

R1 — Where are you based, and is two office days a week in Bristol workable for you?

R9 — Have you worked with finance on revenue numbers, such as reconciling pipeline or renewals to booked revenue, or supplying data for a finance report? What did you own, and who owned the final figure?

R7 — When your pipeline review fed a forecast, what part did you produce, and did anyone ask you to defend the number?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.