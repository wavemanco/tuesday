# Job underwriting: Senior Product Analyst, Harborlight Health

## Decision snapshot

Yes, apply. Your background covers the core of this role on paper: R1, R2, R3, R4 and R7 are all `direct`. The gaps are healthcare data, clinician work, and mentoring. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: no rows; the JD states no gate terms
- `must_have`: direct: R1, R2, R3, R4, R7
- `important`: adjacent: R5 (metrics layer), R6 (clinician partnership) · unclear: R8 (mentoring)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R5 — maintenance without definitions on record; R6 — PM partnership shown, clinicians not; R8 — no mentoring stated; R9 — consent and PII work, no protected health data. Every confidence band here is `medium` or `none`, because nothing is inspected yet.

**Opportunity ledger.** The scope is clear (RR5), but the pasted JD gives no pay, location, or decision rights (RR1, RR2), and the employer is unchecked (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed on Harborlight's own careers page (RR4); (2) pay and location are workable for you (RR1); (3) you're comfortable with the healthcare experimentation constraints (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your JD text |
| Mandate | Product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership | `[grounded]` JD |
| Scope read | A senior individual-contributor role that also owns metric definitions and mentors two juniors | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run: the role-family sweep was refused (see Evidence status), so no pay or scope band is given | — |
| Unknowns | Pay, location or remote, who sets metric definitions, data stack, reporting line, contract type | — |
| Contradictions | None found within the pasted JD; no live posting was checked | — |
| Stage | Evaluating (assumed) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; self-report, no artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is not shown by an artifact | `[grounded]` your background | A sanitized query or metric definition raises it to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, plus a pricing test behind an 11% retention lift. The lift's basis (relative or absolute, significance) is a likely probe | `[grounded]` your background | A sanitized test readout raises it to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards | `[grounded]` your background | A dashboard inventory or screenshot raises it to high |
| R5 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the consent-state model are near this work. Ownership of canonical definitions is not stated. Limit: maintaining a layer you didn't set | `[inferred]` from R4 work | Q2 below |
| R6 | Partner with PMs and clinicians to turn analysis into decisions | important | adjacent | medium | transferability | Monthly exec memo and VP Product reviews show PM partnership. No clinician work stated | `[inferred]` from your reporting work | A memo excerpt that changed a non-product decision |
| R7 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your background | A sanitized memo raises it to high |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background says so; it may exist informally | `[grounded]` absence in your background | Q1 below |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer-PII handling and a consent-state model. No protected health data. Limit: consumer data, not PHI | `[inferred]` adjacency | Wording proposal A3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8, important) | discovery | Nothing about training or managing analysts | The JD names two junior analysts as part of the role | Reviewing a junior's SQL; running a tool training; interviewing analysts | A note on a mentee's work, or a training you ran | `[grounded]` JD; absence in your background |
| G2 | Metric ownership (R5, important) | transferability | Dashboard and definition work, but not who set the definitions | Decides whether the role defines metrics or maintains them (RR2) | Owning a metric's definition; resolving a metric dispute | A metric definitions doc | `[inferred]` from the JD's wording |
| G3 | Clinician partnership (R6, important) | transferability | PM and exec partnership; no clinicians | Clinicians are a named stakeholder group | Working with ops, finance or legal on a decision | A memo that changed a non-product decision | `[grounded]` JD and your background |
| G4 | Healthcare data (R9, preferred) | transferability | Consent state and PII handling; no PHI | Health data carries rules beyond GDPR/CCPA | Access or consent reviews on sensitive data | A sanitized consent-model design | `[grounded]` your background; `[generic]` that health data carries extra rules |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and location not stated | unknown | — | (pasted JD has no pay or location line) | Pay and location may be withheld, or left out of this excerpt | `[inferred]` from the pasted text | What is the base salary range, and is the role based in an office or remote? | unresolved |
| RR2 | Decision rights on metric definitions unclear | unknown | — | "define and maintain the metrics layer" | The role may maintain definitions that someone else sets | `[inferred]` from the scope language against its silence on authority | Who signs off metric definitions today, and which decisions would this role make alone? | unresolved |
| RR3 | Healthcare experimentation constraints | unknown | — | "design and analyze A/B tests" in a care-navigation app | Tests touching clinical workflows or patient data may need review beyond a product A/B process | `[generic]` pattern for healthcare product teams, not a claim about this employer | How are experiments reviewed when they touch clinical workflows or patient data, and how many ran last year? | unresolved |
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Unchecked, not negative: the searches were refused. The entity and posting still need confirming | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Experimentation and self-serve dashboards are explicit scope | positive_signal | — | "build self-serve dashboards in Looker"; "design and analyze A/B tests" | The role's defined work matches what you already do | `[grounded]` JD | Which experiments are planned for the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Harborlight's own careers page, and note the pay and location it lists | RR4, RR1 | `[generic]` pattern for employers this size | your call |
| A2 | Lead the CV with the 30+ tests a year and the 40+ governed dashboards, as you stated them | R3, R4 | `[grounded]` your background | `resume_edits_pending_approval` |
| A3 | Describe the consent-state model under GDPR/CCPA consumer data as your bridge to R9. Don't write "healthcare experience" or "HIPAA" | R9 | `[grounded]` your intake; no clause beyond your sentences | `resume_edits_pending_approval` |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search calls were refused in this session, so no source was read. Would have moved RR4 and whether the posting is live |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the pay and scope calibration; none is given here, and no band is taken from memory |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want a record of this, I can write a `tuesday-dossier.md` holding this assessment, which a later interview-prep run can read.

## Upgrade menu

- A link to the live Harborlight posting or its careers page → confirms the employer (RR4), and reads pay and location if listed (RR1). Links you give me don't count against the research budget.
- A sanitized SQL sample or metric definition → R2 to `high`
- A sanitized test readout, with its metric definition and confidence interval → R3 to `high`, and the 11% claim becomes checkable
- A dashboard inventory or screenshot → R4 to `high`
- A memo excerpt that changed a decision → R6 and R7 strengthen
- Deeper research on Harborlight (funding, leadership changes, past reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 (G1, R8): Have you trained, reviewed the work of, or hired junior analysts, even informally? Name one: what you did, and how you know it helped.

Q2 (G2, R5, RR2): Who set the canonical metric definitions at your company, and did you change them, maintain them, or only use them?

Q3 (structural input, checks the hard gates): What are your non-negotiables on location or remote work, and on base pay? State them, and I'll check them against the role.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.