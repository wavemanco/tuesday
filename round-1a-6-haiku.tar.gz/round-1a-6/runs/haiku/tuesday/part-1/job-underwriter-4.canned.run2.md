**Renata: yes, apply, but settle the location question first.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads), R6 (build and monitor rating models), R7 (design and read price tests)
- `important`: adjacent: R9 (pet-insurance product pricing)
- `preferred`: direct: R8 (insurance experience)

R9 — motor pricing carries over, pet claims behaviour is new to you; R1 — the JD and the careers page disagree on location.

**Opportunity ledger.** The employer is established: the careers page is live and matches the JD's role (RR3). The open items are the location conflict (RR1) and the withheld pay (RR2). Nothing in the posting is a red flag.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK or Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) location confirmed: either you can do Leeds four days a week, or the role is remote as the JD says (RR1, R1); (2) base pay confirmed within your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | Contradiction: JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources |
| Scope read | Senior analyst owning one product's pricing analytics, with no stated line management | `[inferred]` from the JD's silence on direct reports |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 pay survey (n=612) |
| Pay | Not stated in the JD or on the careers page | `[grounded]` absence |
| Hiring manager | Odile Varga, Director of Pricing; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books; previously head of pricing analytics at Calloway Re | `[grounded]` public profile and talk listing |
| Unknowns | Which location applies; base pay; how large the pet book is; whether the role has line management | — |
| Contradictions | Location: JD vs careers page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Location constraint not given, so there is nothing to grade the fit against. The sources conflict | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics, last two as senior analyst. Self-reported, no inspectable artifact yet | `[grounded]` your background, CV-equivalent | Expect a probe on dates and scope |
| R3 | Strong SQL and Python | must_have | direct | medium | none | SQL and Python daily. Self-reported | `[grounded]` your background | Expect a live-skill probe |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book (motor) | `[grounded]` your background | Name the book and the model's life cycle when asked |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | None |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained one (motor); monitoring is implied by maintaining it, not stated | `[grounded]` your background; `[inferred]` monitoring | Confirm how you monitored it |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | Ask what you designed vs ran |
| R8 | Insurance experience | preferred | direct | medium | none | Motor insurance, five years | `[grounded]` your background | None |
| R9 | Own pricing analytics for the pet-insurance product | important | adjacent | medium | transferability | Credible bridge: rating-model and price-test work carries over. Limit: no pet-insurance pricing done; pet claims, vet-cost inflation and policy structure are not exercised | `[inferred]` bridge from motor work; `[generic]` that pet claims behave differently from motor | Make the bridge case with its limit, and name a pet-data question for interviews |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product pricing (R9, important) | transferability | Motor pricing only; no pet work | The most likely interview objection; a clear bridge narrows it | Rating-model or price-test work on a segment with different claim patterns; any work on policy structure or claims-severity drivers | A pet-data or claims-analysis sample (anonymised), or a motor-to-pet bridge note | `[inferred]` bridge; `[generic]` that pet and motor claims differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict | risk_signal | medium | JD: "Fully remote (UK)"; careers: "Leeds office four days a week" | The role may be hybrid in Leeds, with the JD's remote line out of date | `[inferred]` from the two sources disagreeing | Is this role fully remote as the JD says, or Leeds four days a week as the careers page says? | unresolved |
| RR2 | Pay not stated | unknown | — | Neither source gives a base salary | The figure may sit below or above the band, or may not be published | `[inferred]` from the withheld figure, against the `[generic]` band | What is the base salary range for this role? | unresolved |
| RR3 | Employer established, posting live | positive_signal | — | "Accepting applications." (careers page) | The posting is genuine and current | `[grounded]` careers page fetched | None needed | noted |
| RR4 | Pet-claims unfamiliarity | risk_signal | low | "Own pricing analytics for our pet-insurance product" | Interviewers may test pet-specific judgement you have not practised | `[generic]` pattern for a motor-to-pet move | What pet-specific pricing or claims questions would I be expected to answer in the first six months? | unresolved |

The Varga talk ("Small Books, Loud Errors", on monitoring rating models in small books) is a positioning lead, not a register entry. It is `[grounded]` as a public talk title, and it suggests your monitoring work is the story to lead with for this reader.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the 14 price tests you ran with underwriting and the quarterly review you present to the head of underwriting. Keep "ran", not "designed" | Your evidence for R5 and R7 is the strongest you have | `[grounded]` your background | pending your approval |
| P2 | Describe the GLM as the young-driver motor model you built and maintained, with no pet claim | Keeps the R9 bridge honest | `[grounded]` your background | pending your approval |
| P3 | Ask the verification questions of RR1 and RR2 before investing in the application | They decide the status | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is CV-equivalent at intake, so every claim is `medium` until you confirm it in a probe.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor Senior Pricing Analyst pet insurance careers" and fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Confirmed the posting is live and surfaced the Leeds contradiction. An earlier search, "Brindlemoor insurtech pet insurance", returned nothing, so the entity rests on the careers page alone |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM", which returned the Pricewell 2026 survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance", which returned a public profile (linkedin.example/in/odile-varga) and her 2025 forum talk |

## Upgrade menu

- Confirming the location → R1 closes, and the decision simplifies.
- Your base-pay floor, or the budgeted salary → RR2 closes, and the figure is set against the band.
- An anonymised pet or claims sample, or a motor-to-pet bridge note → R9 and G1 strengthen.
- A deeper company pass on Brindlemoor (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). I'm offering this once; say the word and it runs.

I can save this as `tuesday-dossier.md` if you want to keep it.

**Questions:**

**R1:** Can you work from Leeds four days a week, or do you need the fully remote setup the JD describes? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**RR2:** What is the lowest base salary you would accept for this role? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.