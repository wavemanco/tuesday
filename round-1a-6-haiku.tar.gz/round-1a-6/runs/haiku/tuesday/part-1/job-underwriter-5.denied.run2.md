**Probably yes, on conditions. Status: `conditional_go`.** Web search was refused by the host, so nothing about Pellucid or the pay band has been checked outside what you pasted.

**Fit ledger**
- `hard_gate`: unclear: R1 (location: Remote US or Denver office), R2 (base salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery, named in the responsibilities); unclear: R9 (data contracts analysts depend on), R10 (ingestion from app and CRM)

R3, R4, R5, R6 and R7 are your daily stack. R8 is the real edge: Snowflake and dbt carry over, but BigQuery specifics don't. R9 and R10 are described in the posting, and the material you gave me doesn't show you doing either.

**Opportunity ledger.** RR1 is the open risk: the employer is not verified, so this decision is capped at `conditional_go`. RR2 is positive: the posted base sits at or above the recruiter report's median. RR3 is a scope read: the posting spans ingestion, warehouse and contracts, which is wider than the usual one-domain remit. RR4 is unknown: the equity is unquantified.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on Pellucid's own careers page (RR1); (2) your location fits R1; (3) your pay floor sits at or below the posted base (R2); (4) the BigQuery, contracts and CRM-ingestion scope is confirmed in interviews (R8, R9, R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` About text you pasted; not checked externally |
| Mandate | Build and run ingestion, a dbt warehouse in BigQuery, and data contracts | `[grounded]` JD |
| Scope read | Wider than a one-domain remit; no reports stated | `[inferred]` JD scope against the pay report's norm |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" usually means 5–8 years | `[generic]` recruiter-supplied report, unverified |
| Unknowns | Hiring manager, team size, equity amount, BigQuery's share of the work | — |
| Contradictions | None between the JD text you pasted and the careers page you cited; not fetched | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote US or Denver office | hard_gate | unclear | none | hard_gate | No location given; the gate is not settled | `[grounded]` JD; candidate not stated | Q1 |
| R2 | Base salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated in intake prose; self-report, no artifact | `[grounded]` candidate statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact | `[grounded]` candidate statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` candidate statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` candidate statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up | `[grounded]` candidate statement | none |
| R8 | BigQuery warehouse (named in responsibilities) | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery-specific experience (partitioning, cost model, load paths) is not stated | `[inferred]` from the Snowflake experience against the JD's BigQuery | G1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned in the material | `[grounded]` silence | G2 |
| R10 | Ingestion from app and CRM sources | important | unclear | low | discovery | Ingestion is implied by your work, but app and CRM sources aren't named | `[grounded]` silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt at scale; no BigQuery | Named in the responsibilities; likely the first technical question | A migration, a cost-tuning job, or a clustering decision on any warehouse | A sandbox BigQuery project or a short design note | `[inferred]` bridge; `[generic]` that this is a likely probe |
| G2 | Data contracts (R9) | discovery | Silent | Analysts depend on it; the posting names it explicitly | Schema agreements, producer-consumer checks, breaking-change handling | A contract spec or a schema-change log | `[grounded]` silence |
| G3 | CRM and app ingestion (R10) | discovery | Silent on source systems | Half the stated mandate | Pipelines from Salesforce, HubSpot, or an app database | A pipeline diagram | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring" | Search was refused, so the employer and posting are unverified; this is not a finding against the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Posted base at or above the recruiter report's median | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is competitive for the title; band is recruiter-supplied | `[grounded]` posting; `[generic]` band | What base is budgeted for this role, and how is the equity structured? | noted |
| RR3 | Scope wider than one domain | risk_signal | low | "Build and run the pipelines … ingestion … warehouse … data contracts" | Ownership may be broader than one domain, with no reports | `[inferred]` JD scope against `[generic]` norm | Which of these three areas does this role own end to end, and who owns the others? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Value cannot be assessed from the posting | `[grounded]` JD | What is the equity grant, vesting schedule, and strike price? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for the BigQuery usage, the contract scope and the CRM sources | G1–G3 | `[grounded]` gap queue | pending your approval |
| A3 | Prepare one BigQuery bridge example, sandbox or design note, only if it's real | G1 | `[inferred]` R8 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your intake prose, which is CV-equivalent and unprobed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches for Pellucid's careers page and About text were refused by the host. RR1 stays open; the pasted About and JD text is unverified. |
| 2. Role-family sweep | unavailable | The search for the Datawright 2026 pay report was refused. The market band is the recruiter's figure, unchecked. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- Search access, which would verify the employer and posting (RR1) and check the pay report's source (RR2). The L1 budget remains open.
- A BigQuery artifact (sandbox project or design note) → R8 to `high`.
- The posting's live link or the recruiter's email domain → RR1 closes or stays open.
- The hiring manager's name → role reality's scope read, and the interview angle.
- A deeper research pass on Pellucid (leadership changes, funding, past hiring; up to 5 more searches and 2 more fetches) — say the word and it runs, if search access returns.

I can also write this up as `tuesday-dossier.md` for later sessions.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R1:** Are you based in the US, and would Remote (US) work, or do you need Denver?
2. **R2:** What is your base floor? Is anything below $148,000 a dealbreaker?
3. **G2, G3:** Have you owned data contracts between producers and analysts, or ingestion from a CRM or app source? Name the system, what you built, and who depended on it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.