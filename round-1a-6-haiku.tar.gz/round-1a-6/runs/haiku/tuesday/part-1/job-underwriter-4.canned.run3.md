## Decision snapshot

Probably yes on fit, but don't apply yet: `hold_pending_answers`. The posting says both "fully remote (UK)" and, on Brindlemoor's careers page, "Leeds office four days a week", and that gap decides whether the role is workable for you.

**Fit ledger.**

- `hard_gate`: unclear: R1 (office attendance, Leeds four days a week against fully remote)
- `must_have`: direct: R2 (4+ years pricing), R3 (strong SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads)
- `important`: direct: R7 (designing and reading price tests), R8 (monitoring rating models); adjacent: R6 (pet-insurance product pricing); unclear: R10 (recommendations to product)
- `preferred`: direct: R9 (insurance experience)

R6 — a motor-to-pet bridge, its limit named; R10 — product recommendations not yet evidenced; R1 — the one gate that can end this.

**Opportunity ledger.** The employer checks out: its own careers page carries the live posting (RR4 notes this as a positive). The open points are the location contradiction (RR1) and pay, which neither source states (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (office attendance, Leeds four days a week against fully remote); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** (1) if the role is confirmed fully remote, and your own location and pay floor fit, it moves to `go`; (2) if it is Leeds four days a week and you can do that, `conditional_go`, with R6 and RR2 as conditions; (3) if you cannot do the Leeds pattern, it is `no_go` with R1 as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech whose pet-insurance product this role owns | `[grounded]` careers page |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD as you pasted it |
| Reporting line | Director of Pricing | `[grounded]` careers page |
| Working pattern | Contradiction: "Fully remote (UK)" in the JD summary; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Pay | Not stated in the material I have | `[grounded]` absence |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` Pricewell 2026 pay survey; a sector band, not this employer's offer |
| Scope read | A senior individual-contributor remit with a defined product; no team or budget stated | `[inferred]` from the posting's scope language against its silence on team |
| Hiring manager | Odile Varga, Director of Pricing at Brindlemoor; previously head of pricing analytics at Calloway Re; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books | `[grounded]` public profile and talk listing (see Evidence status) |
| Unknowns | Work pattern (remote or Leeds); pay; contract type; whether product recommendations are part of the job | — |
| Contradictions | Working pattern, as above | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Office attendance (Leeds four days a week) against fully remote | hard_gate | unclear | medium | hard_gate | The two sources disagree and no candidate constraint was given; fit is not established until the working pattern is confirmed | `[grounded]` both sources | Question Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; CV-stated, no inspectable artifact yet | `[grounded]` your intake statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code or query sample seen | `[grounded]` your intake statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM for a young-driver motor book; motor, not pet | `[grounded]` your intake statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your intake statement | none |
| R6 | Pricing for a pet-insurance product (inferred from the role's scope) | important | adjacent | medium | transferability | Rating and monitoring work transfers; no pet product priced. Limit: motor loss patterns differ from pet, where vet-fee inflation and lifetime cover drive the book | `[inferred]` from the JD's product scope; `[generic]` that pet cost drivers differ | Gap G1 |
| R7 | Designing and reading price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your intake statement | none |
| R8 | Building and monitoring rating models | important | direct | medium | none | Maintained a live GLM rating model; monitoring is part of that | `[grounded]` your intake statement | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake statement | none |
| R10 | Turning results into recommendations for product, not only underwriting | important | unclear | low | discovery | Your underwriting presentations are evidenced; product recommendations are not | `[grounded]` the gap between your stated work and the JD's wording | Gap G2 |

The JD names no people-management requirement, so your never having managed anyone opens no row. `[grounded]` JD.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R6) | transferability | Motor rating and monitoring only; no pet product priced | The role's whole product is pet; the bridge needs its limit stated | Any rating model, monitoring, or price test on a product with a different loss driver; any work on claims-cost trends or cover design | A sanitized rating-model or monitoring note; a pet-sector pricing talk or paper you've read or prepared | `[inferred]` bridge from R4 and R8; `[generic]` that pet cost drivers differ |
| G2 | Product-level recommendations (R10) | discovery | Underwriting presentations are evidenced; product changes are not | The JD asks for recommendations for product too | Recommending excess, cover terms, or a price structure change; a test read that led to a product change | A product memo, a test readout that changed a product decision | `[grounded]` the JD's wording against your stated work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two is out of date, or the role is hybrid with the summary left stale | `[grounded]` the two sources differ; the cause is not established | "Is this role fully remote, or based in the Leeds office four days a week?" | unresolved |
| RR2 | Pay and contract type not stated | unknown | — | none in the material I have | The figure may sit near the sector band, or it may be withheld | `[grounded]` absence; band `[generic]` | "What is the base salary band, and is the contract permanent?" | unresolved |
| RR3 | Hiring manager's public work matches your rating-model work | positive_signal | — | "Small Books, Loud Errors", on monitoring rating models in small books | Your monitoring experience is the thing this reader has written about | `[grounded]` the talk listing | "What did you find hardest to monitor in a small book?" | noted |
| RR4 | Employer confirmed from its own careers page | positive_signal | — | "Accepting applications. Senior Pricing Analyst, Leeds office four days a week." | The employer is real and the posting is live; the standing failed-attribution entry does not apply | `[grounded]` careers page fetched | "Can you confirm the working pattern on the posting?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern and pay band before investing effort | RR1, RR2, R1 | `[grounded]` register | pending your approval |
| A2 | Prepare a pet-bridge answer: what carries from motor, the limit, and the artifact that would narrow it | R6, G1 | `[inferred]` from R6 | pending your approval |
| A3 | Lead with rating-model monitoring for this reader | RR3 | `[grounded]` talk listing; `[generic]` that a reader rewards a matched example | pending your approval |

No CV wording is proposed yet: the evidence is intake-stated, and the reframing audit needs your confirmed sentences before any line is drafted.

## Evidence status

Verified: none yet. Your intake statements are CV-equivalent leads at `medium`, so R2 to R9 hold until you confirm the specifics.

Unverified leads: none.

Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst", which returned the careers posting; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: organization and the working-pattern contradiction (RR1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst salary UK insurance GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]` and the basis for RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned the public profile "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Positioning for RR3 and A3 |

## Upgrade menu

- Confirmed working pattern, and your location relative to Leeds → R1 closes, and the status moves to `go` or `no_go` on the facts.
- Your pay floor and contract requirement → RR2 closes, and the band in role reality is checked against them.
- A pet-related artifact, such as a rating-model note or a pet-sector pricing paper → R6 moves up from `adjacent`.
- An example of a product recommendation → R10 moves from `unclear`.
- A deeper research pass on Brindlemoor (funding, leadership changes, past candidate reports; up to 5 more searches and 2 more fetches): say the word and it runs. Offered once.

I can also write this up as a `tuesday-dossier.md` you can keep and add to.

## Questions

Q1 (R1, the gate): Where are you based, and can you work from the Leeds office four days a week, or do you need fully remote?

G2 (R10): Have you recommended changes to a product, such as cover terms, excess or price structure, not only to underwriting? If so, what changed?

RR2: What is your pay floor, and do you need a permanent contract?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.