**Yes, apply, on conditions. Status: `conditional_go`.** Your must-haves (R1, R2, R3, R4, R5) are direct matches for what you've described. Two things keep this from a plain `go`: I could not verify that the employer or the posting exists, and the posting says nothing about pay or location.

- **Fit ledger.**
  - `must_have` — direct: R1, R2, R3, R4, R5
  - `important` — adjacent: R6 (metrics layer), R7a (product-manager partnership) · unclear: R7b (clinician partnership), R8 (mentoring two junior analysts)
  - `preferred` — adjacent: R9 (HIPAA data experience) · absent: R10 (digital-health product experience)

  R6 is a bridge with its ownership limit unstated; R7b has no evidence yet; R9 is a credible bridge from consent work, with HIPAA not exercised.

- **Opportunity ledger.** The scope is concrete (RR6, positive signal). Pay and location are silent (RR2, RR3). The employer is unverified (RR1, standing entry).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 cleared: the live posting and the employer confirmed on the company's own careers page; (2) RR2 and RR3 answered: pay range and location; (3) R7b and R8 confirmed in interviews; R9 and R10 framed as adjacent, not as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not verified, since the search was refused |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Single-owner senior remit spanning analytics, clinical partnership and people leadership | `[inferred]` from the responsibility list |
| Market calibration | Not run. The search was refused, so there is no pay or scope norm to set against | — |
| Unknowns | Pay, location and work pattern, reporting line, team size, clinical data-access rules | — |
| Contradictions | None found within the posting text | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated in intake; no inspectable artifact yet | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is the JD's bar, not a level you stated | `[grounded]` your intake | sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran a 30+ tests-a-year program, including a pricing test behind an 11% retention lift | `[grounded]` your intake | anonymized readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards | `[grounded]` your intake | sanitized dashboard screenshot |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents to VP Product monthly | `[grounded]` your intake | sanitized memo |
| R6 | Metrics layer definition and maintenance | important | adjacent | medium | transferability | Governed dashboards built; ownership of canonical metric definitions unstated | `[inferred]` from "governed dashboards" | G3 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Memo and VP Product presentations shape decisions; PM partnership not stated | `[inferred]` | bridge case in interview |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background names clinicians | `[grounded]` silence | G1 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Not stated | `[grounded]` silence | G2 |
| R9 | HIPAA / healthcare data experience | preferred | adjacent | medium | transferability | GDPR/CCPA consumer-PII handling and a warehouse consent-state model; HIPAA not exercised | `[inferred]` adjacency | framing E2 |
| R10 | Digital-health or care-navigation product experience | preferred | absent | none | capability | You've said you've never worked in healthcare; no adjacent product evidence found | `[grounded]` your intake | closure path G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7b, important) | discovery | No stated work with clinicians, nurses or care staff | Clinicians are named in the mandate; a yes could move R7b to direct | A project where clinical input changed an analysis or decision | `[grounded]` silence in intake; `[inferred]` that it matters for this mandate |
| G2 | Mentoring junior analysts (R8, important) | discovery | No stated mentoring or review of junior work | The role names it; a yes could move R8 to direct | Onboarding, review or code-review practice with juniors | `[grounded]` silence |
| G3 | Metric-definition ownership (R6, important) | transferability | Governed dashboards are built; whether you owned canonical definitions is unstated. Limit: the layer itself isn't named | Defining and maintaining the layer is the first responsibility | A metrics dictionary, or a definition you set and governed | `[inferred]` bridge from "governed dashboards" |
| G4 | Healthcare product experience (R10, preferred) | capability | No credible evidence after looking | Preferred-tier, so a minor risk, not a blocker | HIPAA training, plus one healthcare-data analysis project | `[generic]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified (standing entry) | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Not failed, only unchecked: the search was refused, so the company and live posting are unconfirmed. Small or new companies often have thin footprints, and postings can be stale | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Pay withheld | unknown | — | (no salary stated in the posting) | May be budgeted below market, or simply unpublished. No market band available | `[inferred]` from the posting's silence | "What is the base salary range for this role?" | unresolved |
| RR3 | Location and work pattern unstated | unknown | — | (no location stated in the posting) | Could conflict with constraints you haven't given | `[inferred]` from the posting's silence | "Is this role remote, hybrid or on-site, and where must the person be based?" | unresolved |
| RR4 | Clinician partnership and health-data rules | unknown | — | "partner with product managers and clinicians"; "healthcare data experience (HIPAA) a plus" | Clinical data access may run under HIPAA-level rules, beyond consumer-privacy practice | `[inferred]` from the stakeholder list and HIPAA line | "Which clinical stakeholders would this role work with, and what rules govern their data access?" | unresolved |
| RR5 | Mentoring with no team structure | unknown | — | "mentor two junior analysts" | Unclear whether the role leads a team or mentors informally | `[inferred]` from the posting | "Who else is on the analytics team, and who owns the junior analysts' reviews?" | unresolved |
| RR6 | Concrete scope | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | Scope is defined and matches your core work | `[grounded]` JD | "What would success look like in the first year?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's careers site before you apply | RR1 | `[grounded]` RR1 | your call |
| E1 | CV line: "Designed and ran an A/B testing program of 30+ tests a year, including a pricing test behind an 11% retention lift" | R3 | `[grounded]` your intake; audit: scope and kind unchanged | `resume_edits_pending_approval` |
| E2 | CV line: "Built the consent-state model for our warehouse under GDPR and CCPA consumer-PII rules" | R9 | `[grounded]` your intake | `resume_edits_pending_approval` |
| E3 | Interview framing for the healthcare gap: "Health data is new to me. The consent and access discipline carries over; HIPAA I haven't worked under yet." | R9, R10 | `[inferred]` that the discipline transfers; limit stated by you | `pending your approval` |
| Q1 | Ask RR2 through RR5 verbatim in the first screen | The register doubles as interview prep | `[grounded]` register | your call |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused by the session's permissions. Would have checked the company exists as described, the posting is live, and the JD matches the careers page (RR1) |
| 2. Role-family sweep | unavailable | The role-family search was refused. Would have set the pay and scope norm for this title (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: I can write this analysis to `tuesday-dossier.md` so the interview-prep module can pick it up later.

## Upgrade menu

- The live posting link or the careers-page listing → RR1 closes, and targets 1 and 2 can run.
- A pay range → RR2 closes, and the figure is set against the market band.
- The work pattern → RR3 closes.
- A sanitized query, dashboard screenshot, or experiment readout → R2, R4 or R3 moves to `high`.
- Ownership of metric definitions (G3) → R6 moves to direct.
- Permission for web search → I rerun targets 1 and 2 at L1.

## Questions

G1 — Have you worked directly with clinicians, nurses or care staff, or on a product used in care delivery? If so, how did their input change a decision?

G2 — Have you mentored, managed or reviewed the work of junior analysts? What did that look like?

Constraints — Where do you need to be based, and is there a base-pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.