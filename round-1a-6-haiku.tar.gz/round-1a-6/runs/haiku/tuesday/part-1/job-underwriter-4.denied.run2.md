**Decision snapshot**

Yes, apply, but as `conditional_go`: the role fits you well, and the posting itself still needs checking. The seven must-have rows (R2, R3, R4, R5, R6, R8, R9) are `direct`. Research didn't run in this session, so the employer, pay and contract are unverified.

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (Pet-insurance product knowledge)
- `preferred`: direct: R10

R1 — location and right to work not yet given; R7 — motor pricing transfers, pet risk drivers don't.

**Opportunity ledger.** The scope is concrete (RR5), but pay (RR1) and contract type (RR2) aren't stated, the posting doesn't say who decides rate changes (RR3), and the employer couldn't be verified in this run (RR4, a standing entry that caps the status at `conditional_go`).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live role on Brindlemoor's own careers page matches this posting (RR4); (2) pay and contract type are acceptable (RR1, RR2); (3) you confirm UK base and right to work, which closes R1. The pet gap (R7) stays a gap, so present it as transfer, not experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An analyst role that recommends; the posting doesn't say who approves rate changes | `[inferred]` from the JD's verbs against its silence on decision rights |
| Market calibration | Not run: the pay and role-family searches were refused, so there is no band | — |
| Unknowns | Salary; contract type; decision rights; whether the role has direct reports (the JD doesn't say, so no requirement is recorded from it); the hiring manager's background, Odile Varga, Director of Pricing (not checked) | — |
| Contradictions | None within the text you pasted; the careers page wasn't checked | `[grounded]` the pasted text |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based, right to work | hard_gate | unclear | none | hard_gate | No location or right-to-work statement from you yet | `[grounded]` JD term | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, two as senior analyst; your statement, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no sample inspected | `[grounded]` your intake | A sanitised query or notebook would raise this to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor, not pet) | `[grounded]` your intake | A sanitised model write-up would raise this to high |
| R5 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 tests last year; "ran" doesn't settle whether you designed them | `[grounded]` your intake; `[inferred]` from the JD's "design and read" | Q3 |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Build is clear; the monitoring cadence isn't stated | `[grounded]` your intake | Be ready to say how you monitored the GLM in use |
| R7 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor frequency/severity work carries over; pet risk drivers, claims patterns and vet-cost dynamics are not exercised | `[inferred]` adjacency from motor work; `[generic]` that pet risk drivers differ from motor | G1, Q2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting; no actuarial audience stated | `[grounded]` your intake | none |
| R9 | Turning results into recommendations for underwriting and product | must_have | direct | medium | discovery | Underwriting audience evidenced; product audience not | `[grounded]` your intake | G2, Q3 |
| R10 | Insurance experience | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your intake | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R7, important) | transferability | Motor pricing; no pet or health work stated | The pet-specific risk drivers are the first thing a hiring manager will probe | Any pet, health or accident product work, even as an input; claims or loss-cost analysis on any product | A claims or loss-ratio summary, or a product note | `[inferred]` bridge from motor GLM work; `[generic]` that pet risk drivers differ from motor |
| G2 | Product audience (R9, must_have) | discovery | Recommendations to underwriting only | The posting names product as an audience too | Any product-team review or pricing decision where product gave input | The review note or deck | `[grounded]` posting names product; `[grounded]` your intake names underwriting only |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | Posting text has no pay | Pay could sit below your floor, or simply be unpublished | `[inferred]` from the posting's silence on pay | What is the salary band for this role? | unresolved |
| RR2 | Contract type not stated | unknown | — | Not stated | The role could be fixed-term or contract | `[inferred]` from the posting's silence on contract | Is this role permanent, and if not, what is the term? | unresolved |
| RR3 | Decision rights over rate changes not stated | risk_signal | low | "Turn the results into recommendations for underwriting and product" | The role may recommend while others approve; normal for analysts, but worth knowing | `[inferred]` from the recommend-verb against silence on decision rights | Who approves rate changes for the pet product, and which decisions sit with this role? | unresolved |
| RR4 | Employer and live posting not verified in this run | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | This run could not search, so the employer is unconfirmed here; the posting may be stale, or may not come from the employer. Nothing found it missing. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Concrete scope and a named hiring manager | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Specific scope is easier to check and to ask about | `[grounded]` posting | What does a good first year look like, and how will it be measured? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the live posting on Brindlemoor's own careers page and compare it with this text | see RR4 | `[grounded]` RR4 | your action |
| A2 | Ask the recruiter for the pay band and contract type before investing in the loop | see RR1, RR2 | `[grounded]` RR1, RR2 | your action |
| A3 | Position on GLM build, 14 price tests and the quarterly review to underwriting; present pet as a transfer with its limits | see R4, R5, R8, R7 | `[grounded]` rows; `[inferred]` the framing | pending your approval; no CV wording is final until you approve it |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches sent, both refused by the host. Would have confirmed the employer exists, its stage, and whether the posting is live (RR4). |
| 2. Role-family sweep | unavailable | One search sent, refused. Would have set the pay and scope band for the calibration line. |
| 3. Hiring manager's public footprint | unavailable | Name given; one search sent, refused. Would have checked Odile Varga's public talks and writing. |

The host refused WebSearch permission on every call, so none of these checks ran.

If you'd like me to write this up as a `tuesday-dossier.md` that the other Tuesday modules can read, I can do that.

**Upgrade menu**

- Grant WebSearch and I'll rerun the three checks (up to 5 searches and 2 fetches). Until then I won't offer a pay band from memory.
- A sanitised price-test write-up or GLM documentation would move R4 and R5 to `high`.
- Any pet, health, accident or claims-cost work would move R7 off `adjacent`.
- Your location and right to work would close R1.
- The pay band and contract type would close RR1 and RR2.

**Questions**

1. **R1:** Are you UK-based with the right to work here, and is there a pay floor or contract type you won't go below?
2. **G1 (R7):** Have you done any work on health, accident, pet or claims-cost data, even as an input to someone else's model?
3. **G2 (R9, and R5):** Did you design the 14 price tests yourself, or did others design them and you read the results? And for the rate changes they fed, did underwriting or product sign them off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.