**Yes, probably apply, on conditions you can check before you put much effort in. Status: `conditional_go`.**

Your intake shows five direct or near-direct matches for this posting. Two must-haves are the risk: owning the forecast, and working with finance on billing or revenue data. Both are things you can answer with a sentence or two, and either could move this to `go` or to `no_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two days a week in the office), R2 (£61.5–67k salary)
- `must_have`: direct: R4 (Salesforce or HubSpot admin), R5 (SQL and spreadsheet modelling); adjacent: R3 (4+ years, B2B software), R6 (forecast ownership); unclear: R7 (billing or revenue data with finance)

The JD doesn't tier its requirements, so I've treated all five as must-haves.

**Opportunity ledger.** The company is real and the scope is specific (Series A, 96 staff, a named forecast and reporting remit). The open question is how the forecast is split with the CFO (RR1). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two days a week in the office), R2 (£61.5–67k salary); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you have contributed to forecast inputs or calls, even without owning the number (R6); (2) you have worked with finance on revenue or invoice data (R7); (3) Bristol two days a week and the salary both work for you (R1, R2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Quillfield, invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A, April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61.5–67k plus share options | `[grounded]` posting |
| Market calibration | UK B2B software revenue-ops lead: median £64.2k, interquartile range £57.8–70.4k (one 2026 survey, n=438). The posted range sits inside the interquartile range | `[generic]` role-family pattern, not this employer's offer |
| Unknowns | Forecast split with finance; billing-data scope; reporting line (the recruiter named Tamsin Achebe as hiring manager) | — |
| Contradictions | None found in what I could read | — |

The hiring manager's public profile lists her as Head of Revenue Operations at Quillfield. That came from one search result matched on name and company, so treat it as a lead to confirm, not a verified fact.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning · provenance |
|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in office | hard_gate | unclear | none | hard_gate | Your location and schedule weren't in your message · `[grounded]` posting |
| R2 | Salary £61.5–67k | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given · `[grounded]` posting |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops at a B2B payments company, the last two running RevOps. Payments rather than software is the stretch · `[grounded]` your message |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards. Certificate not yet inspected · `[grounded]` your message |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. Modelling is not shown yet · `[grounded]` your message |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have never owned the company forecast; finance did it. You run the monthly pipeline review with the sales director, which feeds forecasting · `[grounded]` your message; `[inferred]` that the review is forecast input |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You have never worked on billing data. Working with finance on revenue data isn't mentioned · `[grounded]` your message |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Pipeline review with the sales director; no forecast ownership | The role runs the quarterly forecast with the CFO, so this is central | Preparing pipeline-weighted or commit views for the sales director; reconciling pipeline to actuals; any forecast input you produced | A pipeline review deck or forecast sheet you built | `[grounded]` your message; `[inferred]` that the review feeds forecasting |
| G2 | Billing and revenue data with finance (R7, must_have) | discovery | No billing data; finance collaboration not stated | The role owns billing data | Revenue reconciliation, invoice or collections data, ARR or renewal bridges shared with finance | A reconciliation or revenue report | `[grounded]` your message |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast split with finance unstated | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may co-own the forecast, or may own the model while finance owns the number | `[inferred]` from JD wording | Which parts of the quarterly forecast does this role own outright, and which does finance own? | unresolved |
| RR2 | Posting not confirmed on Quillfield's own site | unknown | — | Posting hosted on tallyboard.example | The role may be live only on a job board | `[grounded]` posting host; quillfield.co.uk/careers returned no page | Which page on Quillfield's own site carries this role? | unresolved |
| RR3 | Reporting line to the hiring manager unstated | unknown | — | "Revenue Operations Lead" with no reporting line | The role may report to the Head of Revenue Operations | `[inferred]` from the lead profile | Who does this role report to, and what do you own versus the CFO? | unresolved |

No standing "employer not established" entry: Quillfield is attributable to a real company.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the live link on Quillfield's own careers page | RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Prepare one honest forecast-input example from your pipeline reviews, with its limits named | R6 | `[grounded]` your message | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" (quillfield.co.uk/about: company facts) and "Quillfield Bristol Revenue Operations Lead" (no results). Fetched quillfield.co.uk/careers: no page at that address. Moved RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software 2026" (Ledgerline 2026 UK Revenue Operations Pay Guide). Moved the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (one public profile, Head of Revenue Operations at Quillfield). Moved RR3 |

**Upgrade menu**

- A forecast or pipeline model you built, with your role named → R6 to `high`.
- A reconciliation or revenue report you worked on with finance → R7 to `medium` or better.
- A Salesforce certificate or dashboard screenshot → R4 to `high`.
- A deeper pass on Quillfield (funding, leadership, recent hires, reports from candidates; up to 5 more searches and 2 more fetches). Say the word and I'll run it.

Dossier offer: I can save this as `tuesday-dossier.md` for your interview prep if you want it.

Questions:

G1 — When you ran the pipeline review, did you prepare any forecast view for the sales director, such as commit or best-case numbers, even if the sales director or finance made the final call?

G2 — Have you ever worked with finance on revenue or invoice data, such as reconciling pipeline to billing, collections, or ARR? If so, what was your part?

Gates — Can you work in Bristol two days a week, and is £61.5–67k above your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.