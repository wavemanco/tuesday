**No, this isn't worth pursuing: R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate`: failed: R1 (base at least $150k, against $70–85k posted); R2 (on-site five days in Austin, against remote-only)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM)
- `important`: adjacent: R9 (building the function alone, team of one); unclear: R6 (SEO/content), R7 (partnerships), R8 (sales ops), R10 (brand, PR)

Your experience covers the must-haves, but both gates fail, and fit can't offset a gate.

**Opportunity ledger.** Scope is large and unfunded: seven functions with no team, no stated budget, and no defined success metric (RR1, RR2, RR4). Expectations run past hours (RR3). The profitability claim (RR5) is the posting's own and unverified.

- **Hard gates:** failed: R1 (base at least $150k, against $70–85k posted), R2 (on-site five days in Austin, against remote-only).
- **Severe red flags:** none found.
- **What would change this:** both gates would have to differ, which means a posted base at or above $150k and remote work in writing. The posting says "no exceptions" on location and states the range.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims, unverified (research skipped) |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site five days, "no exceptions"; evenings and weekends | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run | `[generic]` none yet |
| Unknowns | Budget, headcount, success metric, equity terms | — |
| Contradictions | Seven-function mandate and "8+ years required" alongside "team of one" and a $70–85k base; the posting doesn't reconcile them | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Basis |
|---|---|---|---|---|---|---|
| R1 | Base at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor, against the posted range |
| R2 | Remote-only, Portland, no relocation | hard_gate | hard_gate_fail | high | hard_gate | Your stated constraint, against "on-site Austin, no exceptions" |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then head at two companies; prose intake, nothing inspected |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at two companies |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze |
| R6 | SEO/content | important | unclear | low | discovery | Not in your background as given |
| R7 | Partnerships | important | unclear | low | discovery | Not in your background as given |
| R8 | Sales ops | important | unclear | low | discovery | Not in your background as given |
| R9 | Building the function as one person | important | adjacent | medium | transferability | Built and ran teams of 3–7 with a budget; never started solo |
| R10 | Brand and PR | important | unclear | low | discovery | Not in your background as given |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it |
|---|---|---|---|---|
| G1 | SEO/content, partnerships, sales ops, brand/PR (R6–R8, R10) | discovery | Your intake doesn't cover these | A list of which you have owned, with one artifact each (a content plan, a partner list, a sales dashboard). Moot for this posting. |
| G2 | Solo start (R9) | transferability | Strong budget ownership at scale; no solo build | Limit: no zero-team start. Strengthener: a program you launched before a team existed. |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority–pay mismatch | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base sits far below a head-level mandate; whether it is below market is unconfirmed | `[generic]` pattern for this title; market sweep not run | What base range is budgeted for this role, and is $70–85k the full cash range? | unresolved |
| RR2 | Seven functions, no team | risk_signal | medium | "You will be a team of one to start" | You would be accountable for all seven with no people or budget named | `[inferred]` from the scope list against the team-of-one line | Which budget and headcount are committed for the first six months, and which function comes first? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The hours are unscoped and expected | `[inferred]` from the wording | How often do you expect work outside core hours in a typical quarter, and how is that handled? | unresolved |
| RR4 | No defined success metric | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no stated target | `[inferred]` from the wording | What revenue number will this role be measured against at twelve months? | unresolved |
| RR5 | Stated profitability | positive_signal | — | "profitable since day one" | If true, lowers financial risk | `[grounded]` the posting's own claim | What are current revenue and cash like? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting | R1 and R2 fail on the posting's own terms | `[inferred]` from the gate rows | pending your approval |
| P2 | Screen future postings against the two gates before reading the rest | Saves the cost of a full read on a role that can't work | `[inferred]` from this run | pending your approval |

**Evidence status**

Verified: R1 and R2, your two constraints, stated directly (`high`). R3–R5 and R9 rest on intake prose, unprobed, at `medium` at most. No unverified leads or rejected inferences.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Both gates are fixed by the posting's terms and your constraints. The employer check could only move a standing entry that caps a `go`, and this decision is already below `go`. |
| 2. Role-family sweep | skipped | The R1 fail rests on your floor, not on the market band. The sweep would only calibrate RR1. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` with the verification questions attached, if you want a record.

**Upgrade menu**

- A posted base at or above $150k and remote work in writing would move R1 and R2 to `direct`, and the decision would then turn on RR1–RR4.
- The official-site check (up to 5 searches, 2 fetches) would confirm the employer exists and the posting is live. It can't lift `no_go`.
- A market sweep would place $70–85k against a band for this scope. It would calibrate RR1 only.
- An inspectable artifact for your $8M to $40M result, such as a P&L summary or attribution dashboard with identifying detail removed, would move that claim from `medium` to `high`. It matters only for roles you would consider.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.