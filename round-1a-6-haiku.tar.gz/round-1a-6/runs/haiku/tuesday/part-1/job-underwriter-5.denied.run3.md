**Yes, it's worth applying, on two conditions: `conditional_go`.** On the requirements you listed, your fit is strong. Two checks are still open, the pay floor and the work location, and I could not verify the company because the web searches were refused by this session's permissions.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (pay band $148,000–$166,000), R2 (remote US or Denver location)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important` — adjacent: R9 (BigQuery warehouse); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R9 — Snowflake work transfers, BigQuery specifics do not yet (`medium`); R10 — nothing in what you shared (`low`); R11 — nothing in what you shared (`low`).

**Opportunity ledger.** The posted pay sits inside the recruiter's report band; the open risks are that the company is unverified (RR1), the hiring manager is unnamed (RR2), and equity is unstated (RR4).

- **Hard gates:** unconfirmed: R1 (pay band $148,000–$166,000), R2 (remote US or Denver location); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the posting appears on the company's own careers page and the company checks out; (2) you confirm R1 and R2 against your own pay floor and location; (3) R9, R10 and R11 hold up when probed in the first interview.
- **What would change this:** a pay floor above $166,000, or a location outside the remote-US or Denver terms, would move R1 or R2 to `hard_gate_fail` and the status to `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the About text you pasted; not verified against the web |
| Mandate | Build and run ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Scope read | Reads as ownership of one data domain's pipelines | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Senior Data Engineer at Series B–D: median $151,000, IQR $139,000–$163,500; typical "senior" is 5–8 years; no direct reports | `[generic]` the recruiter's Datawright report as you pasted it; not checked against a second source |
| Compensation | Posted $148,000–$166,000 plus equity; midpoint $157,000 sits above the report median | `[grounded]` JD; comparison against `[generic]` band |
| Unknowns | Equity terms; hiring manager; whether the BigQuery warehouse exists or this role builds it; CRM ingestion scope | — |
| Contradictions | None found between the JD and the About text | `[grounded]` both as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay band $148,000–$166,000 (your floor) | hard_gate | unclear | none | hard_gate | Your floor was not given, so the band cannot be checked | `[grounded]` JD; floor not stated | Q1 |
| R2 | Remote US or Denver location | hard_gate | unclear | none | hard_gate | Your location was not given | `[grounded]` JD; location not stated | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, self-reported | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | Built a project of about 180 models | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake in production | `[grounded]` your background | state it as Snowflake |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your background | none |
| R9 | dbt warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery specifics not exercised | `[inferred]` from your Snowflake work; `[generic]` that BigQuery's cost and partitioning model differs | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Ingestion appears in your background, but not from a CRM specifically | `[grounded]` your background silent on CRM | Q2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned in what you shared | `[grounded]` your background silent | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale; no BigQuery | The posting names BigQuery; the gap is platform-specific, not conceptual | A warehouse migration or cost-tuning project on any platform | A sample dbt model or a short BigQuery exercise | `[inferred]` bridge from your Snowflake work; `[generic]` that the platforms differ in cost and partitioning |
| G2 | CRM and app ingestion (R10, important) | discovery | Ingestion exists in your background; CRM not named | Ingestion from the app and CRM is the first responsibility listed | Any source-system ingestion you owned | A pipeline description or diagram | `[grounded]` your background |
| G3 | Data contracts (R11, important) | discovery | Not mentioned | Analysts depend on the contracts; this is a named responsibility | Schema agreements, breaking-change handling | A contract doc or review example | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning" | The company's footprint could not be checked; the searches were refused, not failed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager not named | unknown | — | JD header | The team sits outside your reporting line | `[inferred]` from the JD's silence | Who is the hiring manager, and which team does this role sit in? | unresolved |
| RR3 | Warehouse state unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The role may run an existing warehouse, or build it | `[inferred]` from the JD's phrasing | Does the BigQuery warehouse already exist, or does this role build it? | unresolved |
| RR4 | Equity unstated | unknown | — | "plus equity" | Equity terms are not given | `[grounded]` JD | What is the equity grant and vesting schedule? | unresolved |
| RR5 | Posted pay within report band | positive_signal | — | "$148,000–$166,000" | Pay is at or near market for a senior role | `[grounded]` JD against `[generic]` band | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the posting on the company's own careers page before investing effort | RR1 | `[grounded]` register | your action |
| P2 | Describe your dbt and warehouse work as Snowflake; claim no BigQuery experience | R6, R9 | `[grounded]` your background | pending your approval |
| P3 | Ask RR2–RR4 of the recruiter | RR2, RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, so every row sits at `medium` at most.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Pellucid Learning were refused by the session's permissions. They would have confirmed the company and that the posting is live (RR1). |
| 2. Role-family sweep | unavailable | One salary search was refused. The pay band rests on the recruiter's report as you pasted it. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Dossier offer

If you want, I can write these findings to a `tuesday-dossier.md` for use in later rounds.

## Upgrade menu

- Search permission granted → the company check and a second pay source for the `[generic]` band (up to 2 searches and 2 fetches on targets 1 and 2).
- Your pay floor and location → R1 and R2 close, and the status likely becomes `go` or `no_go`.
- A short BigQuery exercise or project description → R9 moves toward `direct`.
- A deeper research pass on the company (leadership, funding history, past postings; up to 5 searches and 2 fetches) — say the word once search permission is in place.

## Questions

Q1 (R1, R2): Is your pay floor at or below $148,000, and can you work under the remote-US or Denver terms from where you live?

Q2 (G2, R10): Did you own ingestion from a CRM or from application event data? Which sources, and who consumed the output?

Q3 (G3, R11): Did you own data contracts or schema agreements with analysts, and how did you handle breaking changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.