# Job underwriting: Product Manager, Platform APIs at Quartzline

**Not a waste of time, but a stretch: `conditional_go`.** R1a (3+ years of titled PM experience) is absent, and R1b (the product work beneath it) is adjacent. The application case rests on R1b holding up under one question you can answer.

**Fit ledger.**

- `must_have`: adjacent: R1b (product management work without the title) · absent: R1a (3+ years of product management, titled)
- `important`: direct: R3 (technical fluency), R4a (engineering and customer stakeholders) · adjacent: R2 (shipped API or platform products) · unclear: R4b (sales and support launches), R5 (agile delivery), R6 (adoption metrics)

R1a is the gap that matters most. R1b is the bridge, with its limits named in the map.

**Opportunity ledger.** The posting's scope is concrete: a roadmap, two squads, metrics and launches (RR3). Compensation is not stated (RR2), and decision rights over the roadmap are unclear (RR4). The employer is unverified (RR1), and that standing entry caps the decision at `conditional_go`.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify on Quartzline's own careers site (RR1); (2) you answer the decision question (G2) with a concrete example; (3) the agile and metrics answers (G5, G6) don't contradict the resume.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; partner discovery; specs and delivery with two engineering squads; adoption metrics; launch coordination with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Working pattern and location | Not stated | — |
| Scope read | A defined PM mandate, not a bundled role; the posting names squads, metrics and launches | `[inferred]` from the JD's list of responsibilities |
| Market calibration | Not established. The role-family search was refused, so there is no pay or scope band | — |
| Unknowns | Compensation; location; reporting line; whether the role signs off its own roadmap | — |
| Contradictions | None visible in the posting as provided. The careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience, as a title | must_have | absent | none | capability | You have said you have never held a PM title. The posting makes this a must-have. It is a length-of-experience requirement, so it is graded on fit, not treated as a gate | `[grounded]` your statement | G1 |
| R1b | Product management work without the title: roadmap input, specs, delivery coordination | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions for product, wrote requirements documents, and coordinated engineers and PMs on custom builds. Limits: the material shows product made the roadmap decisions, and no priorities or metrics you owned are stated. The period of the roadmap work is not stated, so its years cannot be counted | `[grounded]` CV; `[inferred]` adjacency to the PM work described | G2 |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | 30+ REST API integrations delivered to clients, end to end. These are integrations of an API, not an API product you owned or released. The posting does not say whether shipping the product itself is required | `[grounded]` CV; `[inferred]` adjacency | G3 |
| R3 | Technical fluency: reads API docs, discusses schemas | important | direct | medium | none | Postman, SQL and OpenAPI reading are named. Specific, but no inspectable artifact yet; expect a probe | `[grounded]` CV | Upgrade menu: an OpenAPI review would raise this to high |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds; ran UAT and go-live with clients | `[grounded]` CV | none |
| R4b | Stakeholder management across sales and support, launch coordination | important | unclear | low | discovery | The CV is silent on sales or support launch work. The playbook is internal to your team | `[grounded]` CV silence | G4 |
| R5 | Agile delivery with engineering squads | important | unclear | low | discovery | The CV is silent on sprints, agile practice or squad planning | `[grounded]` CV silence | G5 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent on metrics. The playbook is in team use, but the material does not measure that use. An unverified earlier note may bear on it | `[grounded]` CV silence; memory lead unverified | G6 |

Hard-gate rows: none, since the posting states no gates and your constraints were not given.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, must_have) | capability | No titled PM years, by your own account | This is the one must-have the material cannot bridge. The realistic closure paths are a scoped-down target role or a move to a PM title, or carrying it as the main risk | A PM-titled role where you held roadmap or delivery decisions; a smaller company where your title was PM; an internal PM-scoped project | A role description, or a project brief with your name on the decisions | `[grounded]` your statement; `[generic]` that PM hiring often screens on titled years first |
| G2 | Product decisions (R1b, must_have) | transferability | Adjacent evidence: roadmap input and requirements documents. Limit: the decisions the material shows were product's. Strengthener: a decision you drafted and its outcome | Decides whether the bridge is a PM bridge or only an input bridge. It is the most likely decision-mover in this assessment | A priority you set and defended; a scope cut you proposed and got accepted; an adoption target you set | A requirements document or decision memo you drafted, with its outcome | `[grounded]` CV; `[inferred]` the bridge reading |
| G3 | Shipped API products (R2, important) | transferability | Adjacent evidence: 30+ integrations shipped. Limit: no API product you owned or released. Strengthener: a sanitized integration playbook | Narrows the objection that integration work is not product work | Versioning or deprecation you drove; an integration playbook you wrote | A sanitized playbook excerpt or a go-live checklist | `[grounded]` CV; `[inferred]` the bridge reading |
| G4 | Sales and support launches (R4b, important) | discovery | The CV is silent | Launch coordination is a named responsibility of the role | A client go-live where you briefed the customer's support or sales team; enablement material you wrote | A launch plan or enablement doc | `[grounded]` CV silence |
| G5 | Agile delivery (R5, important) | discovery | The CV is silent | Delivery with two squads is central to the role | Sprint planning with a dev team on integration builds; release coordination | A delivery plan or a sprint board you ran | `[grounded]` CV silence |
| G6 | Adoption metrics (R6, important) | discovery | The CV is silent. An unverified earlier note may bear on this | Decides whether metrics can be answered from experience or only from interest | Playbook usage, time to go-live, tickets avoided, a tool other teams adopted | A metric sheet or dashboard you used | `[grounded]` CV silence; memory lead unverified |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Product Manager, Platform APIs — Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (no compensation line in the posting as provided) | The figure may be published elsewhere, or withheld | `[grounded]` the posting has no salary line | What base range is budgeted for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform … define and track adoption metrics" | Success is measurable, which is good for a PM role | `[grounded]` JD text | Which roadmap decisions does this role make without sign-off, and which adoption metrics are already defined? | noted |
| RR4 | Decision rights over the roadmap not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | "Own" may mean setting priorities, or carrying a roadmap others sign off | `[inferred]` from "own" against silence on sign-off | Who signs off the roadmap, and what authority does this role hold over the two squads' priorities? | unresolved |

RR1 stays `medium` because a thin footprint is common and is not a sign of fraud. It is unresolved here because the search that would have checked it was refused, not because it was found absent.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Replace the first bullet with: "Led scoping workshops, requirements documents, integration architecture, UAT and go-live for 30+ client REST API integrations" | R2, R3. Every clause traces to your sentence "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live." The 30+ attaches to integrations | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Keep the roadmap-input bullet as written. Do not reword it toward roadmap ownership | R1b. Rewording it would claim the decisions the material does not show | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Position on integration ownership and client-facing roadmap input. Do not describe yourself as having product-management experience | R1a. Leading with a title you do not hold fails the first check | `[inferred]` from R1a and the reframing audit | pending your approval |
| P2 | Rehearse the title answer: "I haven't held a PM title. What I've done is …" built only from your confirmed facts | R1a, G2 | `[grounded]` your statement | pending your approval |
| P3 | Before applying, find the posting on Quartzline's own careers site and ask who signs off the roadmap | RR1, RR4 | `[generic]` pattern: postings are verified this way | pending your approval |

## Evidence status

Verified: none yet. Your resume lines are leads for verification, not proof, until you answer a probe on them.

Unverified leads: an earlier note suggests you may have built an internal request-triage tool that support agents adopted. It is unconfirmed, so it is a basis for question G6 only, never evidence.

Rejected inferences: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the employer and role were refused, so nothing returned. This would have checked that the employer exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Searching was refused; this would have set the pay and scope norm for a product manager with 3+ years of experience |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

If you want this kept, I can write it to a `tuesday-dossier.md` that you can update as answers come in.

**Upgrade menu**

- The live posting or careers page, and a recruiter contact → RR1 closes, and the conditional_go cap lifts if it verifies.
- Web search was refused in this session, so the employer check and the pay and scope band did not run. Say so and I can re-run them if search is allowed → RR1 and the compensation band.
- A sanitized integration playbook excerpt or a go-live checklist → R2 can move to `high`, and G3 closes.
- An OpenAPI review or schema write-up you did → R3 moves to `high`.
- A decision memo you drafted (G2) → R1b strengthens, and it is the likeliest move toward `go`.
- The budgeted salary → RR2 closes.

**Questions**

G2 — Name one product decision you made or drove. What did you choose, who else had a say, and what happened afterward?

G6 — An earlier note, which I have not verified, says you may have built an internal request-triage tool that support agents adopted. Is that right? If so, how did you measure adoption, and what was your part?

G5 — Have you worked in sprints or as part of a dedicated engineering squad? What was your role in planning, and what cadence did you run?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.