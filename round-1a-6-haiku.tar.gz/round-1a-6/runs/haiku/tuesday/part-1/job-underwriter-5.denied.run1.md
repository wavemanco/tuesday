**Yes, worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (US work authorization), R3 (pay band and equity)
- `must_have`: direct: R4 (5+ years data engineering), R5 (strong SQL and Python), R6 (dbt and a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R11 (BigQuery warehouse); unclear: R9 (ingestion from the app and CRM), R10 (data contracts analysts depend on)

R4, R5, R6, R7 and R8 are each `medium`, because they rest on your intake description and nothing has been inspected. R11 is a transferability case: dbt on Snowflake carries over, and BigQuery-specific work does not exist yet. R9 and R10 are unknowns, because your background doesn't mention either.

**Opportunity ledger.** The posting is specific and its pay band straddles the market median (RR5). Equity is unquantified (RR3), no hiring manager is named (RR2), and the scope spans ingestion, warehouse and contracts (RR4). The employer and the live posting are not verified (RR1), because the research calls were refused in this run, so that check is still open.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (US work authorization), R3 (pay band and equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out on Pellucid's own careers site (RR1); (2) R1–R3 hold for you: you are US-based with work authorization, and $148k clears your floor; (3) the BigQuery gap is framed as adjacent (R11), never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the About text you pasted; not independently checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Mostly one domain (reporting), but ingestion, warehouse and contracts together sit at the broad edge of the typical one-domain scope; no direct reports stated | `[inferred]` from the JD's listed responsibilities against the typical scope |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, 5–8 years typical. Posted $148,000–$166,000 straddles the median, with the top just above the upper quartile. Series C falls inside the B–D cohort. Midpoint $157,000. Equity is not valued. | `[generic]` from the Datawright 2026 report you supplied (n=2,310, US); the report's method was not checked |
| Unknowns | Hiring manager; team; equity value and terms; whether the post owns ingestion and contracts alone; your location, work authorization and pay floor | — |
| Contradictions | None found between the JD and the About text. The careers page was not read (research unavailable). | `[grounded]` absence in the two pasted sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | medium | hard_gate | Your location was not given, so the terms are not settled either way | `[grounded]` JD; your location not stated | Q3 |
| R2 | US work authorization (implied by US-remote) | hard_gate | unclear | medium | hard_gate | Not stated in the JD; implied by "Remote (US)". Your status was not given. | `[inferred]` from "Remote (US)" | Q3 |
| R3 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | medium | hard_gate | Your floor was not given. The equity terms are unquantified. | `[grounded]` JD | Q3; recruiter on equity |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in intake. Self-report, so capped at `medium`. | `[grounded]` your intake | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact inspected | `[grounded]` your intake | none |
| R6 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, stated in intake | `[grounded]` your intake | upgrade menu: a dbt repo or docs |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite, stated in intake | `[grounded]` your intake | upgrade menu: suite config |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence in your intake | Q1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned. Great Expectations is quality testing, which is related but not the same practice. | `[grounded]` absence; `[inferred]` the relation | Q2 |
| R11 | BigQuery warehouse (named in the role description, not the requirements list) | important | adjacent | medium | transferability | dbt on Snowflake carries over. Limit: no BigQuery-specific work. | `[inferred]` adjacency from R6; `[grounded]` your no-BigQuery statement | gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Not in your background | Ingestion is the first thing this role builds, so an answer moves the fit call | Pulling from a product database or SaaS API; scheduled extracts; a CRM sync you maintained | Pipeline diagram, DAG list, or a sanitized connector | `[grounded]` absence; `[generic]` that ingestion is the typical first build |
| G2 | Data contracts (R10, important) | discovery | Not in your background | Analysts depend on these, so the role is accountable for them | Schema agreements with producers; breaking-change handling; a documented table SLA | A contract document or schema-change log, sanitized | `[grounded]` absence |
| G3 | BigQuery (R11, important) | transferability | dbt and Snowflake work, with no BigQuery | The posting names BigQuery as the warehouse | dbt models and tests that port directly; Airflow-to-warehouse loads | A small BigQuery project, or a note on what ports from Snowflake | `[inferred]` bridge from R6; `[generic]` that a warehouse-specific limit is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified in this run | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The refused research calls are the reason, not a finding about Pellucid. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No hiring manager named | unknown | — | (posting names none) | The hiring manager may sit in the reporting team | `[generic]` common in postings at this stage | Who is the hiring manager, and which team does this role sit in? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity value may be material to total pay | `[generic]` equity is often unquantified early in a process | What equity is offered, as shares or percent, with vesting and strike price? | unresolved |
| RR4 | Scope breadth | unknown | — | "Build and run the pipelines… ingestion… a dbt-modelled warehouse… data contracts" | The role may own all of this, or share some with other teams | `[inferred]` from the JD's responsibility list | Which of these pipelines does this role own end to end, and which do other teams own? | unresolved |
| RR5 | Salary band posted and near market median | positive_signal | — | "$148,000–$166,000" | The band is realistic for this level | `[generic]` band from the report; `[grounded]` posted figure | Is this range the budgeted one for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers site before applying | RR1 | `[grounded]` RR1 | pending your action |
| A2 | Put RR2 to RR4 to the recruiter before investing in the loop | Scope and equity decide whether the role is the one described | `[grounded]` RR2–RR4 | pending your approval |
| A3 | Describe the warehouse as dbt on Snowflake with BigQuery as a stated gap, never as BigQuery experience | R11's limit; a claim of BigQuery use would be the one an interviewer tests first | `[inferred]` R11 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Pellucid's site and careers page were refused by a permission prompt, so no page was read. They would have moved the employer check, the Series C fact, and whether the posting is live (RR1 and the contradictions row). |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes the band and the seniority norm, so no search was needed. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Upgrade menu

- Permission to run web search would rerun target 1: the employer, the Series C fact and the live posting. That is up to 3 more searches and 2 fetches within the L1 caps.
- A dbt repo, sanitized model lineage or dbt docs → R6 to `high`.
- A Great Expectations suite config or sample check → R8 to `high`.
- A short BigQuery project, or a note on what ports from Snowflake → R11's limit narrows.
- The recruiter's answers on hiring manager, team and equity (RR2, RR3) → the scope read and the equity call firm up.
- Your location, work authorization and pay floor → R1 to R3 settle, which can move the status to `go` or `no_go`.

If you want this written up as `tuesday-dossier.md`, so the map and register carry into a later interview prep or an update, I can emit it.

1. **Q1 (R9, G1):** Have you built ingestion from a product database or a SaaS API such as a CRM? Which sources, how often did it run, and who consumed the output?
2. **Q2 (R10, G2):** Have you defined or enforced data contracts between producers and analysts? What did a contract cover, and who agreed to it?
3. **Q3 (R1–R3):** Are you based in the US with work authorization for remote US work, and does the $148,000–$166,000 range meet your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.