**Yes, apply, as `conditional_go`.** Your experience covers the core of this role. The conditions are about the employer, which I couldn't verify, and about two scope items your background doesn't show.

Research tier: L1, searches 2 of 5, fetches 0 of 2; both web searches were refused by the permission prompt, so no company or pay-band facts are used below.

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Fit ledger:**
  - `must_have`: direct: R1, R2, R3, R4, R6a, R7; adjacent: R5 (metrics layer; governed dashboards, but no metric-definition layer claimed).
  - `important`: unclear: R6b (clinician partnership), R8 (mentoring two analysts).
  - `preferred`: adjacent: R9 (healthcare data; consumer PII only, not PHI).
  - Reading: R5 is the one core-scope gap; R6b and R8 are unanswered rather than missing; R9 is preferred and transferable.
- **Opportunity ledger:** the employer is unverified (RR1, `risk_signal`, medium), because web search was refused. Pay is withheld (RR2, unknown). The posting's scope is specific and its outcomes are named (RR3, positive).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Harborlight's own careers page (RR1); (2) clinician-facing work and mentoring scope hold up in interviews (R6b, R8); (3) a pay figure or band is confirmed (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; stage and size not checked |
| Mandate | Own product analytics for the care-navigation app: metrics layer, experiments, Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Senior IC plus people management of two analysts | `[inferred]` from the JD's list |
| Market calibration | Not run; no band given | — (web search refused) |
| Unknowns | Clinician involvement, mentoring expectations, pay, how PHI is separated from analytics | — |
| Contradictions | Not checked against the careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; prose background, not yet inspected | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is your judgment, not yet shown | `[grounded]` your statement | Share one anonymized query to raise confidence |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; the pricing test is tied to an 11% retention lift | `[grounded]` your statement | Share one test readout |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` your statement | Screenshot or dashboard list |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards imply defined metrics, but no metric-definition layer is claimed | `[inferred]` from governed dashboards | Ask whether you owned canonical metric definitions |
| R6a | Partner with PMs; turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly memo to the exec team; presents to the VP Product monthly | `[grounded]` your statement | none |
| R6b | Partner with clinicians | important | unclear | low | discovery | CV silent on clinicians or domain experts | `[grounded]` silence in CV | G2 |
| R7 | Strong written communication for non-technical readers | must_have | direct | medium | none | The monthly metrics memo is read by execs | `[grounded]` your statement | Share a sanitized memo |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not on record | `[grounded]` silence in CV | G1 |
| R9 | Healthcare data (HIPAA), a plus | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII work carry over. HIPAA/PHI rules are not exercised | `[inferred]` adjacency | G3 |

The hard-gate rows are none: the JD states no gate, and you haven't given constraints.

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8) | discovery | No mentoring on record | `important` row, unclear | Onboarding or reviewing a junior analyst's work; code review of queries; leading a rotation | A mentoring plan or a junior analyst's reviewed work | `[grounded]` CV silence |
| G2 | Clinician partnership (R6b) | discovery | No work with clinicians or domain experts outside product | Likely to come up in interviews for this posting | Working with ops, support or a regulated partner on a metric or policy | A stakeholder brief or spec you co-wrote | `[grounded]` CV silence; `[generic]` that healthcare roles probe this |
| G3 | HIPAA and PHI (R9) | transferability | Consent-state and PII work, consumer data only | Preferred tier; the distance to PHI is the objection | Any work on regulated or access-controlled data; BAA or data-access reviews | Your consent-state design doc (sanitized) | `[inferred]` adjacency; `[generic]` that PHI rules differ from consumer PII rules |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (research refused) | risk_signal | medium | "Harborlight Health (digital-health scale-up…)" | The employer's footprint is unverified here; it may be new, small, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Pay withheld | unknown | — | (no salary stated) | The figure may sit below the role-family band, or pay may simply not be published | `[inferred]` from the missing figure | "What is the budgeted base range for this role?" | unresolved |
| RR3 | Scope and outcomes stated | positive_signal | — | "Own product analytics for our care-navigation app" | The role has clear scope and named deliverables | `[grounded]` JD | "Which two outcomes will define success in the first year?" | noted |
| RR4 | PHI boundary unclear | unknown | — | (not stated) | Health data may sit separately from the analytics warehouse, or may not | `[inferred]` from the healthcare context | "How is PHI kept separate from the analytics warehouse, and who has access?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program and the Looker build. Proposed: "Designed and ran the experimentation program: 30+ A/B tests a year, including a pricing test tied to an 11% retention lift." ("behind" downgraded to "tied to"; the lift is not attributed to you alone) | R3, R4 | `[grounded]` your sentences; audit: ambiguity resolved downward | resume_edits_pending_approval |
| E2 | Describe the consent-state model as consumer-PII work. Do not call it healthcare or HIPAA experience | R9 | `[grounded]` your statement | resume_edits_pending_approval |
| E3 | Before investing in the loop, verify the employer and posting on its own careers page | RR1 | `[generic]` pattern | pending your approval |
| E4 | Put the RR questions to the employer in the first screen | RR1, RR2, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own statements, not yet confirmed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search was refused, so no results. Would have verified RR1 and the posting's consistency with the JD |
| 2. Role-family sweep | unavailable | Every search was refused. Would have set the market calibration and the RR2 band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- The live posting link from Harborlight's own careers page → RR1 closes; the decision can move to `go`.
- Permission for web search → pay band (RR2) and employer footprint (RR1) get checked.
- A sanitized pricing-test readout → R3 moves to `high`.
- A sanitized monthly memo → R7 moves to `high`; R5 may follow if the memo shows defined metrics.
- Your constraints (pay floor, location, contract type, start date) → hard-gate checks run.

If you'd like, I can write this up as a `tuesday-dossier.md` you can keep and reuse across the job search.

1. Have you mentored or managed junior analysts, formally or informally? What did you own, and how did it go? (G1, R8)
2. Have you worked on a product with clinicians or other domain experts outside product and data? What did you personally own? (G2, R6b)
3. What are your non-negotiables for this search: pay floor, location or remote, contract type, and earliest start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.