**Not yet: hold until the location question is answered.** Status: `hold_pending_answers`. On the core requirements you look strong on paper, but the posting gives two different working patterns, and that decides whether this is a fit at all.

Research tier and sources are under Evidence status below.

## Decision snapshot

**Hold. Status: `hold_pending_answers`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (fully remote UK work pattern)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (GLM rating models), R4 (SQL and Python), R6 (presenting to underwriting leads)
- `important`: direct: R5 (price tests); adjacent: R8 (pet-insurance product)
- `preferred`: direct: R7 (insurance experience)

R1 is unresolved and decides the status. R8 is a motor-to-pet transfer with its limit named. R2, R3, R4, R5, R6 and R7 are `direct` on the CV, each at `medium` until probed.

**Opportunity ledger.** RR1: the JD and the careers page disagree on location. RR2 and RR3: decision rights and line management are not stated. RR4: no salary appears in the posting. RR5 (positive): the hiring manager's public talk matches the role's monitoring emphasis.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK work pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** If the role is confirmed fully remote UK and your location constraint allows it, expect `conditional_go`, with conditions on RR2 and RR3. If it requires the Leeds office four days a week and that does not work for you, R1 becomes `hard_gate_fail` and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor; careers page is live and names this role, reporting to the Director of Pricing | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | JD: fully remote (UK). Careers page: Leeds office four days a week | `[grounded]` both sources; contradiction (RR1) |
| First-year outcomes | None stated | `[inferred]` from silence |
| Scope read | A senior analyst owning one product's pricing analytics, reporting to the Director | `[inferred]` from title and reporting line |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median £58,400, IQR £52,100–£64,900 (Pricewell 2026, n=612). The posting shows no salary, so this is what to expect, not an offer | `[generic]` role-family sweep; `[grounded]` posting has no salary |
| Employer footprint | Careers page attributes the role. One search found no independent coverage beyond it. That thin footprint raises no register entry | `[grounded]` careers page; `[generic]` on thin footprints |
| Unknowns | Decision rights (RR2); line management (RR3); salary (RR4) | — |
| Contradictions | Location (RR1) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK (JD) vs Leeds office four days a week (careers page) | hard_gate | unclear | none | hard_gate | The sources disagree, and your own location constraint was not given, so nothing settles it | `[grounded]` JD and careers page | Q1 below; confirm terms through the careers page contact |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, last two as senior analyst. Self-reported, so `medium` | `[grounded]` your intake statement | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver book. Motor, not pet | `[grounded]` intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, per intake; no artifact yet | `[grounded]` intake | none |
| R5 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` intake | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` intake | none |
| R7 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` intake | none |
| R8 | Pet-insurance product (named in the mandate; not a stated requirement) | important | adjacent | high | transferability | Your statement that you have never worked on pet insurance is specific and yours, so `high`. Motor rating and GLM work carry over; pet-specific risk drivers are not yet exercised | `[grounded]` your statement; `[generic]` that pet risk drivers differ from motor | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R8, important) | transferability | Motor rating and GLM work; no pet work | Likely the first objection; a stronger bridge narrows it | Any rating or pricing work outside motor; any animal, health or vet-cost data | A sanitised note on what changes between motor and pet books | `[inferred]` that this is the likeliest objection; `[generic]` that pet risk drivers differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | "Fully remote (UK)" (JD); "Leeds office four days a week" (careers page) | The careers page may be out of date, or the role may be hybrid with Leeds attendance | `[inferred]` from the two sources conflicting | Is this role fully remote in the UK, or does it need me in the Leeds office four days a week? | unresolved |
| RR2 | Decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may own the analysis while rate-change decisions sit with the Director | `[inferred]` from the reporting line against the JD's silence on authority | Which pricing decisions does this role make alone, and which go through the Director of Pricing? | unresolved |
| RR3 | Line management unstated | unknown | — | JD silent on direct reports | The role may or may not carry reports, now or in year one | `[inferred]` from JD silence | Does this role have direct reports now, or are any planned in the first year? | unresolved |
| RR4 | Salary not in posting | unknown | — | Posting names no salary as provided | Salary may sit below the band, or may simply be unpublished | `[inferred]` from the posting's silence, against the `[generic]` band | What is the base salary range for this role? | unresolved |
| RR5 | Hiring manager's public talk matches the role's monitoring emphasis | positive_signal | — | "build and monitor rating models" (JD); talk "Small Books, Loud Errors", 2025 Insurance Pricing Forum | Monitoring rating models is a stated interest of the role's leader | `[inferred]` from a public talk title against JD language | Which monitoring practices would you expect me to set up in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead with the GLM rating model built and maintained for the young-driver book, and name the motor scope in that line | Keeps the motor scope visible rather than implying pet | `[grounded]` intake; R3 | resume_edits_pending_approval |
| A1 | Ask the location terms through the careers page contact, not a third party | Resolves R1 and RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Pet positioning, proposed wording: "I haven't priced pet insurance. The GLM rating work I built and maintained on a motor book is the part that carries over; pet risk drivers are what I'd need to learn." | Names the limit before an interviewer does | `[grounded]` your statements; the transfer limit is `[generic]` | pending your approval |
| Q2 | Ask RR2, RR3 and RR4 verbatim in the first conversation with the employer | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is intake prose, which caps at `medium`.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" (found brindlemoor.co.uk/careers/senior-pricing-analyst) and fetched that page: the posting is live and states Leeds four days a week, contradicting the JD (RR1). Also searched "Brindlemoor pet insurance insurtech": no results, so no footprint beyond the careers page is established |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration (`[generic]`) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a public profile (linkedin.example/in/odile-varga) listing a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models. Moved RR5 and the positioning. Used only as public professional footprint |

## Upgrade menu

I can emit this as a `tuesday-dossier.md` you can keep and reuse; say the word.

- Written location terms (remote, or Leeds four days a week) → R1 and RR1 close, and the status moves.
- Your own location constraint (Q1) → R1's statement of the constraint, graded `high` if specific.
- A salary range from the recruiter → RR4 closes against the band.
- A sanitised motor-to-pet transfer note, or any pet, animal or health-data work → R8 moves toward `direct`.
- Your salary floor and any contract-type requirement → checks against them run; without them the decision cannot clear.
- A deeper research pass on Brindlemoor (funding, leadership churn, hiring patterns; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1 — Could you work from the Leeds office four days a week, or do you need fully remote UK? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

RR4 — What is the lowest base salary you would take for this search? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.