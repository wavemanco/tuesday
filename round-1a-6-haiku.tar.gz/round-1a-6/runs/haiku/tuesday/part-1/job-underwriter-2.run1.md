**No, you're not wasting your time: `conditional_go`.** Apply, but expect the screen to press on the titled-PM must-have, which you can't meet on paper. Your strongest case is the bridge from implementation lead to product-minded owner, backed by one or two concrete decision stories.

**Decision snapshot**

- **Fit ledger**
  - `must_have`: direct R3, R4 · adjacent R1a (3+ years PM-type work), R2 (shipped API products) · unclear R5 (agile delivery) · absent R1b (titled PM years)
  - `important`: direct R6, R9 · adjacent R7 (two-squad delivery), R10 (owning the roadmap) · unclear R8 (adoption metrics)
  - R1a: product-adjacent work, limit named. R1b: the titled years, the gap to plan around. R8: no owned metrics stated yet. R10: input collected, decisions not owned.
- **Opportunity ledger:** RR1 (`unknown`) is unstated decision rights on the roadmap. RR2 (`positive_signal`) is concrete scope. RR3 (`unknown`) is that the employer and live posting are unchecked from here.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** `conditional_go` on three conditions. (1) G1 and G2 produce a concrete PM-shaped decision story. (2) RR3 verifies: the requisition is live on Quartzline's own careers page. (3) RR1 comes back clean in the first interview.

**Role reality**

- Product Manager, Platform APIs, Quartzline (B2B logistics tech, ~150 people, Series B). [grounded] from the JD header; not verified externally.
- Scope: owns the partner-facing API roadmap, runs partner discovery, writes specs and drives delivery with two squads, defines adoption metrics, coordinates launches with sales and support. [grounded] from the JD.
- Seniority: 3+ years of PM experience is a must-have, so this is a mid-level PM role. [grounded]
- First-year outcome: a partner API roadmap with tracked adoption. [inferred] from the ownership and metrics language.
- Unstated: compensation, location or remote terms, reporting line, whether PMs hold final say.
- Contradictions: none found in the JD.
- Market calibration: not run (no search). Pay band: unknown.

**Evidence map** (CV only; the triage-tool note is a `memory_lead` and is not counted)

| # | Priority | Requirement | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | must_have | 3+ yrs PM-type work | adjacent | medium | transferability | Roadmap-input sessions and requirements docs are product-adjacent; no decision rights claimed | [grounded] CV | G1 |
| R1b | must_have | 3+ yrs titled PM experience | absent | none | transferability | No PM title and no claim of one. Experience length is not a legal gate, so this is a screen risk, not an eligibility stop | [grounded] CV silence; [generic] screen pattern | G1 |
| R2 | must_have | Shipped API or platform products | adjacent | medium | transferability | 30+ REST integrations delivered end to end, as implementer, not as owner of a shipped API product | [grounded] CV | G1, G2 |
| R3 | must_have | Reads API docs, discusses schemas | direct | medium | none | Postman, SQL, OpenAPI named; integration architecture owned; no artifact inspected | [grounded] CV | Upgrade menu |
| R4 | must_have | Stakeholders across eng, sales, customers | direct | medium | none | Coordinated internal engineers, client engineers and PMs; quarterly client sessions | [grounded] CV | none |
| R5 | must_have | Agile delivery | unclear | low | discovery | CV does not name sprints, backlog or ceremonies | [grounded] CV silence | G3 |
| R6 | important | Discovery with integration partners | direct | medium | none | Scoping workshops and roadmap-input sessions with integrators | [grounded] CV | none |
| R7 | important | Specs and delivery with two squads | adjacent | medium | transferability | Wrote requirements docs and coordinated engineers; did not run a squad's backlog | [grounded] CV | G3 |
| R8 | important | Define and track adoption metrics | unclear | low | discovery | SQL skill, but no metric she defined or tracked is stated | [grounded] CV silence | G2 |
| R9 | important | Launch coordination with sales and support | direct | medium | none | Owned UAT and go-live for client integrations; sales and support coordination not stated | [grounded] CV | none |
| R10 | important | Owns the partner API roadmap | adjacent | medium | transferability | Ran roadmap-input sessions for product; did not decide the roadmap | [grounded] CV | G1 |

**Gap recovery queue**

- G1 (R1a, R1b, R2, R10): No example of a product call she owned. Closes with one specific decision, what she weighed, and the outcome.
- G2 (R2, R8): The triage tool is unconfirmed. If real, it could show shipped internal product work and adoption. Closes with what it decided, who used it, and how adoption was known.
- G3 (R5, R7): Sprint and backlog ownership not stated. Closes with who ordered the work and who broke ties with clients or engineering.

**Risk register**

| ID | Class | Signal | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | unknown | Roadmap decision rights unstated | "Own the roadmap for our partner-facing API platform" | Accountable for the roadmap without final say over sales or engineering trade-offs | [inferred] from ownership language vs. silence on authority | "Which roadmap trade-offs does this role decide alone, and which need sales or engineering sign-off?" | unresolved |
| RR2 | positive_signal | Concrete scope and metrics | "adoption metrics" with "two engineering squads" | A defined, resourced role | [inferred] from JD scope | "What adoption measure will this role be held to in year one?" | unresolved |
| RR3 | unknown | Employer and live posting unchecked | (posting header) | Posting may be stale or not match the employer as described | [generic] check gap; research did not run | "Is this requisition open on your careers page, and who would I interview with?" | unresolved |

No `severity: high` entries. The standing failed-attribution entry is not raised, because no research ran.

**Application plan**

1. Verify RR3 on Quartzline's careers page before spending effort.
2. Lead the CV with roadmap input, the integration playbook and the 30+ integrations. Do not use "product manager" as a title or claim roadmap ownership.
3. Prepare one decision story (G1) and a sprint answer (G3). Do not use the triage tool in the CV unless G2 confirms it.

Proposed edits, `resume_edits_pending_approval`: move the roadmap-input line and the playbook to the top of the summary. Add no new facts. Nothing is final until you approve it.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was not granted when sent |
| 2 | Role-family sweep | unavailable | Same permission refusal |
| 3 | Hiring manager footprint | n/a | No hiring manager named |

I can offer a `tuesday-dossier.md` that holds this assessment so later sessions can pick it up.

**Upgrade menu**

- Quartzline's careers-page posting link → verifies RR3 and lifts the `conditional_go` cap.
- Your constraints: location or remote, pay floor, travel → runs the hard-gate checks.
- An anonymized integration requirements doc or playbook excerpt → can raise R3 and R7 toward `high`.
- Triage-tool details: what it decided, adoption numbers → could move R2 and R8.
- Permission to run web search → company check and a role-family pay band.

**Questions**

- G1 — Name one decision about what a product or integration did or didn't do where the call was yours, not the client's or the team's. What did you decide, what did you weigh, and what happened?
- G2 — Did you build the internal request-triage tool your notes mention? If so, what did it decide, who adopted it, and how did you know?
- G3 — Have you worked in sprints with a backlog you helped order? When engineering and a client disagreed on priority, who decided?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.