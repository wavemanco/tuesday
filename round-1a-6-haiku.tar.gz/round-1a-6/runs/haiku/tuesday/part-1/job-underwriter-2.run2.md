## Decision snapshot

No, not on fit alone. This is worth an application, but expect the first screen to be the "3+ years product management" must-have, which you don't meet on title. **Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3 (technical fluency: API docs and schemas), R7 (stakeholder management) · adjacent: R1b (product work short of a title), R2 (shipped API or platform products), R4 (discovery with integration partners), R5 (specs and delivery with engineering squads) · unclear: R6 (define and track adoption metrics) · absent: R1a (3+ years PM experience)
- `important`: adjacent: R8 (launch coordination with sales and support) · unclear: R9 (agile delivery)

R1a — the titled years; R2 — integrating an API is not the same as shipping one; R6 — adoption tracking is missing from the record; R9 — delivery method unstated.

**Opportunity ledger.** The posting is clear about its scope: roadmap ownership, two named squads and adoption metrics (RR3, positive). Pay, location and contract basis are not in what you shared (RR2). Whether a product leader already exists, and who holds roadmap decisions, is unknown (RR1). Quartzline itself is unchecked (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Questions 1 and 3 below show you shaped product decisions, or the triage tool verifies with adoption data; (2) Question 2 shows you measured whether integrations were used; (3) the posting is confirmed on Quartzline's own careers page (RR4); (4) RR1 is answered before you accept an offer.
- **What would change this:** strong answers to Questions 1–3 move R2, R1b and R6 up, and that could make this a `go`. A `no_go` would need a constraint of yours that the role's terms conflict with, or a finding that the employer isn't real. Neither is in the material yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` as you described it; not checked online |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | Senior-level scope on one platform, and possibly its first PM seat | `[inferred]` from the breadth of the mandate against the absence of any reporting line |
| Market calibration | Not run. Both searches were refused by the host (see Evidence status), so there is no pay or scope band | — |
| Compensation | Not stated in the posting as shared | `[grounded]` JD |
| Unknowns | Pay, location, contract type, reporting line, whether a product leader exists, the platform's maturity | — |
| Contradictions | None visible in what was provided; the careers page was not checked | — |

A length-of-experience requirement like "3+ years" is not a hard gate. It is graded as a must-have on fit, which is why R1 is split below.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | high | transferability | You have never held a PM title. This is your own specific statement, so the confidence is about the statement, not the fit. | `[grounded]` your statement | Closure path under Gap queue G1 |
| R1b | 3+ years product management experience (the product work short of a title) | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product, and requirements documents for 30+ integrations. Limit: no stated ownership of a product decision. | `[grounded]` CV; `[inferred]` adjacency | Question 1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations of a vendor's REST API. You integrated a product; you did not ship one. Limit: no stated role in API design, versioning or deprecation. | `[grounded]` CV | Questions 1 and 3 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are on the CV. No inspectable artifact yet, so expect a probe. | `[grounded]` CV | Upgrade menu: an integration architecture doc or sanitized OpenAPI review would raise this to `high` |
| R4 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and requirements gathering are discovery in form. They were built around known client needs, not to find unmet needs across a partner base. | `[grounded]` CV; `[inferred]` adjacency | Gap queue G2 |
| R5 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordination of vendor, client and PM engineers on custom builds. Limit: no stated ownership of sprint delivery with a standing squad. | `[grounded]` CV | Gap queue G4 |
| R6 | Define and track adoption metrics | must_have | unclear | low | discovery | The CV is silent on adoption tracking. SQL and go-live work suggest the means, not the practice. | `[inferred]` from the skills list | Question 2 |
| R7 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs across 30+ integrations. Sales-side coordination is not stated. | `[grounded]` CV | None beyond the upgrade menu |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination is on the CV. Support-side work is not on the CV. | `[grounded]` CV | Question 3 |
| R9 | Agile delivery experience | important | unclear | low | discovery | The CV does not name a delivery method. Your integration playbook may describe one. | `[inferred]` from the CV's silence | Gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, must_have) | transferability | No PM title. Product-input work is on the CV (R1b) | This is the must-have most likely to end the screen. The gap is real and cannot be worded away | Owning a feature or integration roadmap at a smaller company; running a product pilot with a defined success metric | A PM-scope project brief you wrote; a roadmap you owned | `[grounded]` CV silence on titles; `[generic]` that screens often match titles literally |
| G2 | Partner discovery (R4, must_have) | transferability | Scoping and requirements work for specific clients | Discovery across a partner base is the job's core. Your version was client-led | Surveys or interviews of several partners that changed a build; a pattern you found across clients | A requirements summary that generalized across clients | `[inferred]` bridge derived from the CV |
| G3 | Adoption metrics (R6, must_have) | discovery | Nothing on the CV about post-launch usage | The role is measured on adoption. Without evidence here, the stronger candidate is someone who has tracked it | Post-go-live usage checks; drop-off analysis in SQL; the triage tool's usage, if it exists | A usage query or dashboard; a go-live report | `[inferred]` from the posting's metrics line against the CV's silence |
| G4 | Delivery method (R5, R9) | discovery | Coordination is on the CV; the cadence is not | Two squads imply an agile cadence. An interviewer will ask how you ran one | Sprint reviews, backlog ownership, or a release process you ran | Your integration playbook, sanitized | `[generic]` that squad-based roles probe cadence |

The queue holds no questions. Its questions are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership with unclear decision rights and reporting | unknown | — | "Own the roadmap for our partner-facing API platform" | This may be the platform's first PM seat, with no product leader above it, or the roadmap may need sign-off you can't see | `[inferred]` from the scope against the posting's silence on reporting | Who does this role report to, is there a product leader for the platform today, and which roadmap decisions does this role make without sign-off? | unresolved |
| RR2 | Pay, location and contract basis not in the posting | unknown | — | (no pay, location or contract line in what was shared) | Not a warning sign; the posting as shared simply omits these | `[grounded]` the posting as provided | What's the base range, is the role remote or hybrid, and is it permanent? | unresolved |
| RR3 | Outcomes and scope stated | positive_signal | — | "Define and track adoption metrics"; "coordinate launches with sales and support" | Success is measurable and the scope is defined | `[grounded]` JD | What adoption number would you expect this role to move in year one? | noted |
| RR4 | Employer and posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Not checked. Research was refused, so this is an open check, not a finding | — | Can you point me at the live posting on your own careers site, and who would I interview with? | unresolved |

No request to pay for anything, to deposit money, or to share bank or ID details appears in the material. No routine-step entry is needed.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's own careers page before applying | Effort spent on an unverified posting is the cheapest loss | `[generic]` pattern for postings of this kind, not a claim about Quartzline | pending your approval |
| A2 | Answer Questions 1–3 before you edit the CV | Their answers decide whether to lead with product decisions or with delivery | `[grounded]` R1b, R2, R6 | pending your approval |
| A3 | Lead positioning with the 30+ integrations and requirements documents; describe roadmap-input sessions as collecting client feedback for product. Do not use "product manager" in any title or summary | These are the strongest sentences that trace to your own words | `[grounded]` CV, audited against your wording | `resume_edits_pending_approval` |
| A4 | Ask a current Quartzline employee or a partner-side contact for an introduction before applying cold | Introductions often get past the first filter at companies this size | `[generic]` pattern for how hiring works at companies of this size, not a fact about Quartzline | pending your approval |
| A5 | Use the triage tool only if you verify it (Question 3). Until then it appears on no document | It is an unconfirmed lead, not evidence | `[grounded]` memory_lead, unverified | pending your approval |

## Evidence status

Verified: none yet. Everything on your CV is self-reported, so it is a lead until you confirm the specifics. Unverified leads: a prior-context note that you built an internal request-triage tool that support agents adopted. Unconfirmed and unverified. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the host (permission not granted), and I did not retry. Would have moved the organization and contradictions rows, and RR4 |
| 2. Role-family sweep | unavailable | Same refusal. Would have moved the market calibration line and the pay band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Quartzline's live posting from its careers page, or the recruiter's email domain → RR4 closes, and the cap on this decision lifts.
- Permission to run the web searches (or the pay and location from the posting) → the market band, Quartzline's public footprint, and RR2.
- An integration architecture doc or a sanitized OpenAPI review → R3 to `high`.
- The integration playbook, sanitized → R5 and R9 (delivery method).
- The triage tool: a one-page description, and any adoption numbers → R2 and R6 strengthen, if verified.

I can also write this up as a `tuesday-dossier.md` you can keep for later interview prep.

Question 1 (R1b, R2): Did you ever decide something about an API itself, such as a schema shape, a versioning or deprecation call, or a field a partner depended on, that engineers then built? What was it, who else was in the decision, and what happened?

Question 2 (R6): After a client went live, did you ever measure whether they actually used the integration, through calls, endpoints, time to first successful call or drop-off? Where did that data live, and did you act on it?

Question 3 (R2, R8; memory lead): Your earlier notes mention an internal request-triage tool that support agents adopted. Did you build it? If so, what did it do, who used it, and do you have any adoption numbers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.