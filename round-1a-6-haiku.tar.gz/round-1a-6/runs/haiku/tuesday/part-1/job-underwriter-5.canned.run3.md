**Yes, probably worth applying, on conditions. `conditional_go`**

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (base pay of $148,000–$166,000 against your floor); candidate constraints not given, so checks against them are unknown.
- **Fit ledger**
  - `hard_gate`: unclear: R1 (remote-US or Denver), R2 (base pay)
  - `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
  - `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (data contracts for analysts), R10 (ingestion from app and CRM)
  - R8 is a Snowflake-to-BigQuery bridge, and its limit is named. R9 and R10 have no evidence in what you've given me, so they are open questions.
- **Opportunity ledger:** The posting is consistent with the company's own site, and the stated pay brackets the market median (RR2, positive). Contract basis is not stated (RR1, unknown). The hiring manager isn't named (RR4, unknown, routine). The company is funded (RR3, positive), but that figure is self-reported.
- **Severe red flags:** none found.
- **What would change this:** For `conditional_go`, the conditions are (1) R1 and R2 check out against your location and pay floor, (2) R8 is framed honestly as a bridge with its limit stated, and (3) R9 and R10 are confirmed in interviews or by your answers below.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states, Denver, 264 staff | `[grounded]` company About page, matches search |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, dbt-modelled warehouse in BigQuery, data contracts | `[grounded]` JD |
| Scope read | Ownership of one domain's pipelines, no direct reports stated | `[inferred]` from the JD's wording against the scope norm below |
| Market calibration | Senior Data Engineer at Series B–D: median $151,000, IQR $139,000–$163,500; "Senior" usually 5–8 years; scope is one domain, no reports. The posted $148,000–$166,000 brackets the median and runs above the IQR top | `[generic]` for the band (recruiter-forwarded report, not independently checked); `[grounded]` for the posted range |
| Unknowns | Contract basis, your location and pay floor, hiring manager, ingestion scope | — |
| Contradictions | None between the JD and the posting on the company's site | `[grounded]` search result |

**Evidence map** (confidence is capped at `medium` on intake prose; nothing is inspected yet)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote-US or Denver location | hard_gate | unclear | none | hard_gate | Your location isn't in what you gave me | `[grounded]` JD; no candidate claim | Q-G3 |
| R2 | Base pay $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | Your floor isn't given; the posted range is at market | `[grounded]` JD | Q-G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated, CV-level | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake | `[grounded]` your intake | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow set up and run, stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite you set up, stated | `[grounded]` your intake | offer: a sanitized suite excerpt would raise to `high` |
| R8 | BigQuery warehouse (in JD responsibilities) | important | adjacent | medium | transferability | Snowflake dbt modelling carries over; no BigQuery operation | `[inferred]` from your Snowflake work against the JD's BigQuery line | Q-G1 |
| R9 | Data contracts for analysts | important | unclear | none | discovery | Nothing in your intake covers contracts | `[inferred]` from the JD's responsibilities | Q-G2 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not stated in your intake | `[inferred]` from the JD's responsibilities | Answer in interview; no separate question |

**Gap recovery queue** (questions are in the closing block)
- **G1 — R8 (BigQuery), transferability.** Your Snowflake work is the bridge; the limit is that you haven't run BigQuery, its cost and partitioning model, or its operations. Closing path: a short BigQuery project or sandbox migration you scoped. `[inferred]` bridge; `[generic]` that this is the likeliest objection.
- **G2 — R9 (data contracts), discovery.** The JD names contracts as a deliverable, so one concrete example would matter.
- **G3 — R1 and R2 (gates), hard_gate.** Location and pay floor are the only hard checks. Neither is a workaround question.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contract basis not stated | unknown | — | (absent) | The post may be fixed-term | `[generic]` pattern for postings that omit it | Is this role permanent or fixed-term? | unresolved |
| RR2 | Posted pay at market | positive_signal | — | "$148,000–$166,000" | Pay is in the band for this seniority | `[grounded]` JD against `[generic]` band | none needed | noted |
| RR3 | Company funded and staffed | positive_signal | — | "Series C ($52M, February 2026)" | Stable hiring base | `[grounded]` company About page; self-reported, not independently checked | none needed | noted |
| RR4 | Hiring manager not named | unknown | — | (absent) | Routine for postings like this | `[generic]` pattern | Who would I interview with, and who owns this pipeline? | unresolved |

The standing "employer not established" entry is not triggered. The company's own domain and its search results describe the same entity consistently. I found no independent third-party confirmation, so the Series C and headcount figures remain self-reported.

**Application plan** (every row pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location and pay floor against R1 and R2 before applying | The only hard gates | `[grounded]` JD | pending your approval |
| A2 | Use this bridge line, quoted from your own words: "I built a ~180-model dbt project on Snowflake. I haven't used BigQuery yet." | Reframing audit: every clause traces to your intake sentence, no added scope | `[grounded]` your intake | pending your approval |
| A3 | Ask the recruiter RR1 and RR4 verbatim | Closes contract basis and hiring-manager unknowns | `[grounded]` RR1, RR4 | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers", which returned the careers posting on the company's domain, "Accepting applications", with JD text matching yours. Searched "Pellucid Learning Series C funding tutoring company", which returned the About page matching your pasted text. A first search, "Pellucid Learning live online tutoring K-12 Denver", returned no results. Moved: role reality's contradictions row (none) and the standing entry check (not triggered) |
| 2. Role-family sweep | skipped | Your pasted pay-report figures fix the market calibration line already, so no search was sent. Not independently checked: the recruiter-forwarded Datawright report itself |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**
- A sanitized dbt or Great Expectations artifact (lineage diagram, test suite excerpt) → R5 and R7 to `high`.
- A BigQuery sandbox or short project → R8 moves toward `direct`.
- Your location and pay floor → R1 and R2 close; the decision likely becomes `go` or `no_go`.
- The recruiter's answer on contract basis → RR1 closes.
- A deeper pass on Pellucid (leadership, independent funding confirmation, employee reports; up to 5 more searches and 2 more fetches) → say the word and it runs.

If you want it, I can also write this up as `tuesday-dossier.md` for later use.

Questions (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- **G3 — Are you in the US, and what is your base-salary floor?**
- **G2 — Have you defined data contracts with consumers (schemas, SLAs, change process)? Describe one.**
- **G1 — Have you run anything on BigQuery, even a sandbox or a migration you scoped?**

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.