**No, don't pursue this as posted.** Two hard gates fail: the role is on-site in Austin five days a week, and the posted base is $70–85k against your $150k floor. `conditional_go` and `hold_pending_answers` don't fit, because the posting states both terms and says the on-site requirement has no exceptions. Status: `no_go`.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site in Austin, 5 days a week), R2 (base salary $70–85k)
- `must_have` — direct: R3 (paid acquisition), R4 (lifecycle and CRM), R8 (8+ years growth leadership) · unclear: R5 (SEO and content), R6 (brand and PR), R7 (partnerships and sales ops), R9 (thriving on ambiguity)

R1 and R2, the two gates, both failed; R3 (`medium`), R4 (`medium`) and R8 (`medium`) are credible on your own account but no artifact has been inspected; R5, R6, R7 and R9 have no evidence in what you gave me.

**Opportunity ledger.** RR1 (employer not verified), RR2 (after-hours expectation), RR3 (scope without a team or budget), RR4 (posted base against your floor, see R2) and RR5 (success metrics undefined) are risk signals; RR6 (stated profitability) is the one positive signal, and it is unverified.

- **Hard gates:** failed: R1 (on-site in Austin, 5 days a week), R2 (base salary $70–85k against a $150k floor)
- **Severe red flags:** none found. No request in the material asks you to pay, deposit a cheque, or send bank or ID details.
- **What would change this:** both R1 and R2 would have to differ. The role would need to be remote-capable and its base at or above $150k.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` the posting's own claim; not verified, because search was refused |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin, 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Scope read | Seven functions held by one person to start, with no bench | `[inferred]` from the function list against "team of one to start" |
| Market calibration | Unavailable: the role-family search was refused, so no band is stated | — |
| Unknowns | Stated profitability and stage; equity terms; budget and hiring rights; success metrics | — |
| Contradictions | None within the posting; no second source was read | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only, Portland, no relocation. The posting rules out remote and names no exception. Confidence grades your statement, not the fit | `[grounded]` JD; `[grounded]` your intake statement | none |
| R2 | Base pay at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Posted base is $70–85k, which leaves a gap of $65k even at the top of the range. Confidence grades your floor | `[grounded]` JD; `[grounded]` your intake statement | none |
| R3 | Owns paid acquisition | must_have | direct | medium | none | Owned paid as growth lead and as Head of Growth. Self-reported, no artifact inspected | `[grounded]` intake prose, CV-equivalent | Campaign or budget summary would raise to high |
| R4 | Owns lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; Braze named. Self-reported, no artifact | `[grounded]` intake prose | Lifecycle program summary would raise to high |
| R5 | SEO and content | must_have | unclear | none | discovery | Intake is silent. Work may exist and simply went unmentioned | `[inferred]` from silence | G1 |
| R6 | Brand and PR | must_have | unclear | none | discovery | Intake is silent | `[inferred]` from silence | G2 |
| R7 | Partnerships and sales ops | must_have | unclear | none | discovery | Intake is silent | `[inferred]` from silence | G3 |
| R8 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth. This is a length-of-experience requirement, graded on fit and not a gate | `[grounded]` intake prose | none |
| R9 | Thrives on ambiguity; metrics will evolve | must_have | unclear | none | discovery | Intake describes a budget-controlled scale-up, not an ambiguous mandate. Whether that counts is open | `[inferred]` from the intake's structure | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R5, must_have) | discovery | Intake names no SEO or content work | Would matter only if the gates changed, so it does not move this decision | Any organic-channel, editorial, or content-led growth you directed | A content plan or organic traffic report | `[grounded]` intake silence |
| G2 | Brand and PR (R6, must_have) | discovery | Intake names no brand or PR work | As G1 | Launches, press coverage, or brand work you owned or directed | A press list or brand brief | `[grounded]` intake silence |
| G3 | Partnerships and sales ops (R7, must_have) | discovery | Intake names no partnerships or sales-ops work | As G1 | Affiliate, co-marketing, or sales-to-growth handoff you ran | A partner pipeline or handoff doc | `[grounded]` intake silence |
| G4 | Thriving on ambiguity (R9, must_have) | discovery | No direct evidence either way | As G1. Also a question of framing for any later application | Launches with no playbook; channels you opened from scratch | A dated launch with its metric | `[inferred]` from the intake's structure |

None of these four questions would change `no_go`, since R1 and R2 decide it. So none is asked this turn.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from attributable sources | risk_signal | medium | "Head of Growth — Novaline (e-commerce enablement startup, Series A…)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a live hiring entry. Not verified here, and not shown absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Work outside hours is presented as the norm for this role, not an occasional need | `[inferred]` from the posting's own wording | In a typical month, how often are evenings and weekends expected? | unresolved |
| RR3 | Scope without team or budget | risk_signal | medium | "Own all revenue growth end to end… team of one to start" | Seven functions sit with one person, and dotted-line board reporting may not carry decision rights | `[inferred]` from the function list against its silence on budget and hiring | Which budget and hiring decisions does this role make directly, and what is committed for year one? | unresolved |
| RR4 | Base against your floor | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The posted base is well below your floor for a role with this scope. Compared against your floor only, since no band was searched | `[grounded]` JD figure against your stated floor; see R2 | Is $70–85k the approved base range for this role as it stands today? | confirmed |
| RR5 | Success metrics undefined | risk_signal | low | "success metrics will evolve as we learn" | Accountability for every growth channel with no stated definition of success | `[inferred]` from the posting's wording | What three numbers will define success at six and twelve months? | unresolved |
| RR6 | Stated profitability and stage | positive_signal | — | "Series A, profitable since day one" | If accurate, runway is stronger than typical for the stage | `[grounded]` the posting's own claim; unverified | What does profitability look like month to month, and what is current runway? | unresolved |

**Severity note.** No entry is `severity: high`. No request in the material asks you to pay or disclose anything, so no hold applies.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't submit on this posting as written | R1 and R2 both fail, and the posting says the on-site requirement has no exceptions | `[grounded]` R1, R2 | pending your approval |
| A2 | Check Novaline's own careers page for this role, and its current terms, before closing the file | RR1 is unverified; the posting is the only source here | `[generic]` pattern for employer verification | pending your approval |
| A3 | Point the search at roles whose terms you can meet, using the experience in R3, R4 and R8 | Those rows are the strongest part of your background | `[inferred]` from the map | pending your approval |

No résumé edits are proposed, since there is no application to tailor.

## Evidence status

Verified: R1 and R2, your own stated constraints. Both are specific and came from you directly. R3, R4 and R8 are self-report at the intake ceiling, so they are not verified. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline were refused by a permission gate, so no fetch was attempted. Would have checked that the entity exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search for Head of Growth base pay at Series A companies was refused. Would have set the market calibration line and the band for RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Because the searches were refused, RR1 stays unverified and no market band is stated. I did not fill either from memory.

## Upgrade menu

- Permission to run the remaining L1 searches (2 searches and 2 fetches are left in the L1 budget). This would verify the employer and set a market band for RR4. It would not change `no_go`, because the two gates stand on the posting's own terms.
- Novaline's live posting or careers-page link. This would let RR1 be checked directly without a search.
- If you want this assessment saved for later sessions, I can write it out as `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.