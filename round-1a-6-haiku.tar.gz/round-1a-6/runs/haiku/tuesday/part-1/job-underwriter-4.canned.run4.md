**Yes, probably worth applying, as `conditional_go`.** Settle one thing first: the posting says fully remote (UK), but the careers page says Leeds, four days a week.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK, or Leeds four days a week); candidate constraints not given, so checks against them are unknown.
- **Fit ledger**
  - `hard_gate`: unclear: R1 (fully remote UK)
  - `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads)
  - `important`: direct: R6 (designing and reading price tests), R7 (building and monitoring rating models) · adjacent: R8 (pet-insurance product)
  - `preferred`: direct: R9 (insurance experience)
  
  R2 to R5 are `medium` each: self-reported, with no artifact yet. R8 is adjacent: motor pricing carries over, but pet-specific loss patterns are not evidenced. R1 is unclear because two employer statements disagree.
- **Opportunity ledger:** Location is unresolved across two employer sources (RR1). Salary is not stated anywhere (RR2). Direct reports are not mentioned (RR3). The hiring manager's public footprint is a positive signal (RR4).
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 and R1 resolve to a location you can work with; (2) the base salary (RR2) sits within your floor, which you have not told me; (3) the pet-insurance bridge (R8) is framed as adjacent, not as pet expertise.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and fetched brindlemoor.co.uk/careers/senior-pricing-analyst. The page matches the JD's own wording but says "Leeds office four days a week", which contradicts the JD's "fully remote". A search for "Brindlemoor insurtech pet insurance" returned nothing, so there is no press or company profile to confirm the firm beyond its careers page. |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary GLM", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey): senior pricing analysts at UK insurers and insurtechs, n=612, median £58,400, interquartile range £52,100 to £64,900. Moved the market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a public profile (linkedin.example/in/odile-varga): Director of Pricing at Brindlemoor; a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books; six years earlier as head of pricing analytics at Calloway Re. Moved the positioning: lead with rating-model monitoring. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD; careers page |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to Odile Varga, Director of Pricing | `[grounded]` JD; careers page |
| Working pattern | Contradictory: "fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` JD and careers page, both quoted |
| Scope read | A normal senior analyst remit: one product, two named outputs | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median £58,400, interquartile range £52,100 to £64,900 | `[generic]` Pricewell 2026 survey, n=612; the posting states no pay, so this is what to expect, not this employer's offer (RR2) |
| Unknowns | Base salary; direct reports, if any; how much of the pet product the role owns; whether the 14 price tests you ran match what the role means by "design" | — |
| Contradictions | Location (above). Otherwise the JD and careers page agree | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Two employer statements disagree, and no candidate constraint was given to check against. Not failed, not met. | `[grounded]` both sources | Q1 below; RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, two as senior analyst. Self-reported, so no artifact yet. | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, per your intake. No artifact yet. | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. A model write-up would raise this. | `[grounded]` your intake | upgrade item below |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. | `[grounded]` your intake | none |
| R6 | Designing and reading price tests | important | direct | medium | none | You ran 14 price tests with underwriting last year. "Ran" may not mean designed, so confirm (Q2). | `[grounded]` your intake; `[inferred]` that "ran" covers the role's wording | Q2 below |
| R7 | Building and monitoring rating models | important | direct | medium | none | You built and maintained the GLM. Monitoring cadence is not stated. | `[grounded]` your intake | confirm monitoring cadence in first contact |
| R8 | Pet-insurance product knowledge (the posting names no requirement, so I inferred it from the product scope) | important | adjacent | medium | transferability | Motor pricing carries over: rating structure, GLM, test design. Pet loss patterns and product mechanics are not evidenced. | `[inferred]` from the JD's product scope against your motor work | G1 below |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance, five years. | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R8, important) | transferability | Motor pricing, nothing pet-specific | Likely the first objection in an interview | Any work on non-motor personal lines or a loss-cost review for a different product; any shared rating structure between motor and another product | A sanitised rating-factor summary, or a note on how motor and pet differ | `[inferred]` bridge from motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts across two employer sources | risk_signal | medium | "fully remote (UK)" (JD); "Leeds office four days a week" (careers page) | The careers page may be stale, or the remote policy may differ from the office expectation | `[inferred]` from two employer statements that disagree | Is this role fully remote, or Leeds-based with four office days a week? | unresolved |
| RR2 | Base salary not stated | unknown | — | "Accepting applications" (careers page; no pay given) | The figure may sit below the market band in role reality, or simply go unpublished | `[inferred]` from the posting's silence, against the `[generic]` band | What is the base salary for this post? | unresolved |
| RR3 | Direct reports not stated | unknown | — | "reports to the Director of Pricing" (JD) | The role may have no reports, or may be expected to line-manage later | `[inferred]` from the JD's silence on reports | Does this role have direct reports now or planned? | unresolved |
| RR4 | Hiring manager's public footprint | positive_signal | — | Forum talk "Small Books, Loud Errors" (monitoring rating models) | The hiring manager's interests and background overlap the role's monitoring work | `[grounded]` public profile page | What does monitoring a rating model in a small book look like here? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV with the GLM rating model work in your own words: "built and maintained the GLM rating model for the young-driver book" | R4, R2 | `[grounded]` your intake | pending your approval |
| P2 | Frame pet insurance as a transfer: motor rating and test design, with pet loss patterns named as the limit | R8, G1 | `[inferred]` bridge, limit named | pending your approval |
| P3 | Ask RR1 and RR2 before investing in an application, or in the first contact | R1, RR1, RR2 | `[grounded]` register | pending your approval |
| P4 | In the cover letter, name monitoring rating models as the work you know best; don't claim small-book experience | RR4 | `[grounded]` your intake and the talk; `[generic]` that a talk topic signals what a hiring manager cares about | pending your approval |

## Evidence status

Verified: none yet. Your intake is self-reported; it reaches `medium` until you confirm specifics or share an artifact.

## Upgrade menu

- A model write-up or price-test readout, anonymised → R4 and R6 to `high`.
- The employer's answer on location → R1 and RR1 close, and the decision may move to `go` or `no_go`.
- The base salary → RR2 closes, and the figure is set against the band in role reality.
- Your pay floor and any other non-negotiables → the hard-gate checks run; right now they cannot.
- A deeper research pass on Brindlemoor (funding, leadership changes, past hiring; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write `tuesday-dossier.md` for this role so the analysis carries into interview prep.

1. **Q1 (R1, RR1):** Could you work from Leeds four days a week, or do you need fully remote? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **Q2 (R6):** For the 14 price tests, did you design the test structure yourself, or did you run tests others designed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **Q3 (RR2 and constraints):** What base salary do you need, and is there any other constraint I should check against (contract type, notice, anything else)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.