## Decision snapshot

**No, not as posted. R1 (base pay) and R2 (on-site, five days) both fail, so the status is `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (base pay), R2 (on-site, five days)
- `must_have` — direct: R3 (8+ years), R4 (paid acquisition), R5 (lifecycle/CRM) · unclear: R6 (SEO/content), R9 (thriving on ambiguity)
- `important` — unclear: R7 (brand, PR), R8 (partnerships, sales ops)

R1 — the top of the posted range is $65k under your floor; R2 — the posting says "no exceptions" to on-site; R3 (`medium`), R4 (`medium`), R5 (`medium`) — stated by you, not yet inspectable; R6 (`low`), R7 (`low`), R8 (`low`), R9 (`low`) — no evidence in what you've given.

**Opportunity ledger.** The scope is ambitious and under-specified: one seat carries seven functions (RR2), after-hours work is described as normal (RR3), success is undefined (RR4), and the pay sits far below the title's scope (RR5). Novaline itself is not verified from here, because the search was refused (RR1); the reporting line is clear (RR6).

- **Hard gates:** failed: R1 (base pay), R2 (on-site, five days).
- **Severe red flags:** none found.
- **What would change this:** R1 would need a published base at or above $150k, and R2 would need remote eligibility. The posting says "no exceptions" to on-site, so R2 is the term that would have to change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` the posting's own claim; not verified (RR1) |
| Mandate | All revenue growth across seven functions, as a team of one to start | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin, five days, "no exceptions"; evenings and weekends | `[grounded]` JD |
| Pay | $70–85k base plus equity | `[grounded]` JD |
| Scope read | One seat holds the work of about seven functions | `[inferred]` from the JD's list against "team of one" |
| Market calibration | Not established. The role-family search was refused, so I have no band and won't supply one from memory | none run |
| Unknowns | Equity terms, what "meaningful" means, budget, success metric, how the range was set | — |
| Contradictions | "Head of Growth" with "8+ years required" against a $70–85k base | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Top of range is $65k under your $150k floor. The range is published, so the employer would have to change a stated term. Confidence grades your own specific floor | `[grounded]` JD pay line; your stated floor | none |
| R2 | On-site Austin, five days, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | You are remote-only and not relocating. Confidence grades your own statement | `[grounded]` JD; your stated constraint | none |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then head of growth at two B2C subscription companies, as you stated. Not yet inspectable; expect a probe | `[grounded]` your prose | none |
| R4 | Paid acquisition ownership | must_have | direct | medium | none | Owned paid at both companies, and controlled budget at one. Expect a probe on channel results | `[grounded]` your prose | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze, as stated. Expect a probe on program results | `[grounded]` your prose | none |
| R6 | SEO and content | must_have | unclear | low | discovery | Not in what you've given; the posting asks for it | `[grounded]` JD list; absent from your prose | Ask in G1 only if a gate moves |
| R7 | Brand and PR | important | unclear | low | discovery | Not in what you've given | `[grounded]` JD list | Ask in G1 only if a gate moves |
| R8 | Partnerships and sales ops | important | unclear | low | discovery | Not in what you've given | `[grounded]` JD list | Ask in G1 only if a gate moves |
| R9 | Thriving on ambiguity | must_have | unclear | low | discovery | Your scaling story shows pace, not a role with undefined metrics | `[inferred]` from the JD's wording | Ask in G2 only if a gate moves |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R6, R7, R8) | discovery | Your stated work is paid, lifecycle and experimentation | Only matters if R1 or R2 moves; it doesn't change `no_go` now | Owning SEO or content strategy; PR or brand work; partner deals; running sales-ops tooling | A content calendar, PR log, or partner agreement | `[grounded]` absence from your prose; `[inferred]` that it doesn't move the decision |
| G2 | Thriving on ambiguity (R9) | discovery | Nothing in your prose speaks to undefined goals | Same as G1 | A role where success was set mid-stream and you defined it | A launch brief or a goal-setting doc | `[inferred]` from the JD's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Unverified here because the search was refused; this is not a finding about Novaline | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Responsibility without authority or resources | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops." | Seven functions in one seat with no team named | `[inferred]` from the posting's list against "team of one" | Which of these seven will I own from day one, and what budget and headcount back paid acquisition and sales ops? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the posted week may be routine | `[inferred]` from the sentence's own wording | How often has "when it matters" meant evenings and weekends in the last two quarters? | unresolved |
| RR4 | Success metrics absent on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Full revenue accountability with no defined target | `[inferred]` from the posting's wording | What revenue number will this role be measured against in year one, and who set it? | unresolved |
| RR5 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" against "$70–85k base" | A Head-of-title scope at this pay may sit well below market; the band is unverified | `[inferred]` from the posting's own terms; band not established | What is the budgeted base, and how was $70–85k set against this scope? | unresolved |
| RR6 | Reporting line stated | positive_signal | — | "Report to the CEO with a dotted line to the board" | A clear decision line and a visible sponsor | `[grounded]` JD | Who on the board sponsors this role, and what has the board asked for in year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't submit to this posting as written | R1 and R2 fail on its published terms | `[grounded]` JD | pending your approval |
| P2 | If you want to test it anyway, ask the employer, using contact details from Novaline's own site, for the live posting and careers page | Verifies RR1 only; R1 and R2 stand unless the published terms change | `[inferred]` from RR1 | pending your approval |

## Evidence status

Verified: R1 and R2, your own stated constraints, which are specific. R3–R5 are your prose and stay unverified until there is inspectable proof. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused, so nothing returned. Would have moved RR1 and the organization row |
| 2. Role-family sweep | unavailable | Search refused. Would have moved the market calibration line and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Search access, if you grant it: runs the three L1 targets (up to 5 searches and 2 fetches). It would verify Novaline and the posting (RR1) and set a pay band from a real survey (RR5). It cannot change R1 or R2.
- The live posting link or Novaline's careers page: RR1 closes, or stays open.
- A published base at or above $150k plus remote eligibility: R1 and R2 would move, and I would re-run the decision.

If you want to keep this, I can write it up as a `tuesday-dossier.md` you can reuse for other postings.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.