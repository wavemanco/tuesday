## Decision snapshot

Not a waste of time, but you're not a fit yet on the PM-specific rows. Status: `hold_pending_answers`. Apply only if your answers to the three questions below show owned product decisions.

**Fit ledger.**

- `must_have`: direct: R8a · adjacent: R1, R6, R7, R8b, R10 · unclear: R9
- `important`: direct: R3, R4 · adjacent: R2 · unclear: R5

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Opportunity ledger.** The posting is clear on scope: you'd own the roadmap and two named squads (RR3). Salary, location and reporting line are missing (RR2). Quartzline itself is unverified because web search was refused (RR1).

**What would change this:**
- **To `conditional_go`:** you show a product decision you owned that shipped (Q1, R6, R7), or an adoption-tracked tool you built (Q2, R9). Either would move rows from adjacent toward direct. Quartzline's own posting link would also have to verify (RR1).
- **Stays short of `go`:** the PM-title gap (R1) can't be closed by answers, only by evidence of product ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your JD text; not verified (see RR1) |
| Mandate | Own the roadmap for the partner-facing API platform | `[grounded]` JD |
| Team | Two engineering squads | `[grounded]` JD |
| Scope read | Coherent for a single platform PM; the requirements sit at the senior end of the title | `[inferred]` from the JD's responsibilities against its requirements |
| Market calibration | Not run; no market band was checked | — |
| Unknowns | Salary, work location, reporting line, whether this is an IC role | — |
| Contradictions | None visible in the JD text you gave | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years of implementation-lead work on REST integrations is adjacent, not PM time. No PM title. Length of experience is not a gate, so this is graded, not screened out | `[grounded]` CV | Q1 |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | You led 30+ client go-lives of REST APIs. You were the integrator, not the owner of the product | `[grounded]` CV | Q1 |
| R3 | Technical fluency: API docs, schemas | important | direct | medium | none | Names Postman, SQL and OpenAPI. Self-reported, no artifact yet | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering, sales, customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds | `[grounded]` CV | none |
| R5 | Agile delivery experience | important | unclear | low | discovery | Not stated on the CV | `[grounded]` CV silence | Q3 |
| R6 | Own the partner API platform roadmap | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions for product. Input was yours; the decisions aren't stated as yours | `[grounded]` CV | Q1 |
| R7 | Run discovery with integration partners | must_have | adjacent | medium | transferability | Client feedback sessions are the closest match. They collected feedback rather than running discovery as an owner | `[grounded]` CV | Q1 |
| R8a | Write specs | must_have | direct | medium | presentation | Requirements documents and integration architecture across 30+ integrations | `[grounded]` CV | E1 |
| R8b | Drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Coordinated engineers and PMs on custom builds, not standing squads on a product roadmap | `[grounded]` CV | Q3 |
| R9 | Define and track adoption metrics | must_have | unclear | none | discovery | Nothing on the CV about adoption measures. A triage-tool note from an earlier conversation is an unconfirmed lead, not evidence | `[grounded]` CV silence; lead is `memory_lead` | Q2 |
| R10 | Coordinate launches with sales and support | must_have | adjacent | medium | transferability | Go-live coordination for client integrations. Internal sales and support work isn't named | `[grounded]` CV | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1, R6) | transferability | Integration leadership and collected client feedback | Two must-haves sit at adjacent | A roadmap call you made and shipped, even a small one | Decision log, release notes, a product doc you wrote | `[inferred]` bridge from roadmap-input work |
| G2 | Adoption measures (R9) | discovery | Nothing on the CV | A must-have with no evidence | A tool you measured usage for | Adoption figures, a dashboard screenshot | `[generic]` that PM roles usually track adoption |
| G3 | Agile squads (R5, R8b) | discovery | Not stated | Two rows depend on it | A sprint or release cadence you ran | Team process doc, sprint board | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Product Manager, Platform APIs — Quartzline" | Research didn't run, so the employer and live posting are unchecked here. This is not a finding that the employer is unreal | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR2 | Salary, location and reporting line withheld | unknown | — | Not stated in the JD | The package may sit in a band you haven't seen, or the posting simply omits it | `[inferred]` from the JD's silence | What is the base range and work location for this role? | unresolved |
| RR3 | Scope and resourcing stated | positive_signal | — | "two engineering squads" | Named resources are a positive sign for a realistic scope | `[grounded]` JD | Which product decisions does this role make without sign-off, and who leads each squad? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| Q1–Q3 | Answer the three questions below | They decide R1, R6, R7, R9 and R10 | `[grounded]` gap queue | pending your answers |
| E1 | Keep the roadmap-input line as written and give specs their own bullet: "Wrote requirements documents and integration architecture for 30+ client integrations." | Presents R8a truthfully; "Ran quarterly roadmap-input sessions collecting client feedback for product" stays unchanged so no verb drifts to "owned" | `[grounded]` CV | resume_edits_pending_approval |
| A1 | Target PM roles where the title gap is smaller, such as integrations or partner-platform PM roles at companies your size | Lower title pressure | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company" and "Quartzline jobs Product Manager Platform APIs"; web search was refused in this session, so no result came back. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs job description years of experience salary range B2B"; refused. Would have set the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Permission for web search was not granted, and I did not retry.

## Upgrade menu

- Quartzline's careers-page link to this posting, and the budgeted salary → RR1 and RR2 close.
- Web search permission for the two refused searches → the employer check and the market calibration run.
- The outcome of one roadmap-input session you ran, with what changed and who decided → R6 and R7 may move toward direct.
- A triage tool or any adoption figures you can show → R9 may move from unclear.
- Any spec you wrote that shipped as a product feature → R2 may move toward direct.
- A deeper research pass on Quartzline (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs once search is allowed.

If you want this saved for later sessions, I can write it out as `tuesday-dossier.md`.

**Q1 — R1, R6, R7:** Think of one product-facing change you took from input to shipped. What did you decide, what did you have to convince people of, and what happened after launch?

**Q2 — R9, R10:** I have an unconfirmed note from an earlier conversation that you may have built an internal request-triage tool that support agents used. Is that real? If so, what did it do, whose decision was it to build it, and how did you know it was being used?

**Q3 — R5, R8b:** Did your teams run sprints or a similar delivery cadence? If so, who set it and how often did you ship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.