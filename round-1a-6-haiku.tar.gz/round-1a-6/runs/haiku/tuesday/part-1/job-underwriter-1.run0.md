**Apply, and the fit is good on the core of the role.** R1, R2, R3, R4 and R5, the five must-haves, read `direct` on what you've told me. The status is `conditional_go`: apply once the posting checks out, and once pay, location and contract type are confirmed. Those three are unknown from what you've shared.

Research didn't run. Web search wasn't granted, so the three searches were refused and nothing was verified about Harborlight. Everything below rests on your background and the pasted posting.

## Decision snapshot

**Apply — `conditional_go`.** R1, R2, R3, R4 and R5 are your five must-haves and all read `direct` on your own account. The conditions are below.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (define and maintain the metrics layer), R8 (partner with PMs and clinicians) · unclear: R7 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R3 — the strongest credential, with a probe on how the 11% lift was measured; R6 — metrics-layer ownership unconfirmed; R7 — no mentoring stated; R9 — consumer consent work, no HIPAA.

**Opportunity ledger.** The posting's scope is concrete (RR4). Pay, location and contract type are unstated (RR3), as are reporting line and decision rights (RR2). The employer itself is unverified (RR1), and that check didn't run.

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this, for `conditional_go`:** (1) RR1: the role is confirmed live on the company's own careers page; (2) RR3: pay, location and contract fit your terms; (3) R6 and R7: you can describe what you actually did on metric definitions and mentoring. If the answer to either is no, the pitch shifts, and the status doesn't change on that alone.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` the pasted JD header; not verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership | `[grounded]` JD |
| Scope read | A senior individual-contributor role that also mentors two analysts | `[inferred]` from the responsibilities list |
| Market calibration | Not run; the role-family search was refused. The JD states no pay, so there is no figure to calibrate | — |
| Unknowns | Pay, location and remote terms, contract type, reporting line, whether the metrics layer exists today | — |
| Contradictions | None within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years. "Expert" is self-rated and unprobed | `[grounded]` your background | none |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years at one subscription company, as you stated it | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift. Expect a probe on how the lift was measured | `[grounded]` your background | upgrade menu: one test write-up |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance and 40+ governed dashboards from scratch | `[grounded]` your background | none |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents to the VP Product monthly | `[grounded]` your background | none |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | "Governed" dashboards and an exec memo imply shared definitions. You haven't said you owned them. Limit: ownership unconfirmed | `[inferred]` from "governed" dashboards | Q2 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring or management stated | `[grounded]` silence in your background | Q1 |
| R8 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | medium | transferability | PM and exec partnership is evident. No clinician work is stated. Limit: no clinical stakeholders | `[grounded]` memo and VP reviews; `[inferred]` adjacency | none |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer GDPR/CCPA consent-state model. No PHI, no HIPAA. Different regulatory regime | `[grounded]` consent model; `[inferred]` adjacency | none; don't claim HIPAA work |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Mentoring (R7) | discovery | No mentoring or management in your background | Two of the responsibilities depend on it | A mentoring plan, a note on analysts you coached, a review process you ran | `[grounded]` silence in your background |
| G2 | Metrics layer (R6) | transferability | "Governed" dashboards, but who defined and maintained the metrics is unstated | It's the role's first listed responsibility | A metric-definitions doc or spec you authored | `[inferred]` from "governed" dashboards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research didn't run, so this is unverified rather than found missing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Reporting line and decision rights not stated | unknown | — | "Own product analytics…" | The role may own analytics without authority over roadmap calls | `[inferred]` from the JD's scope against its silence on authority | Who does this role report to, and what decisions does it make alone? | unresolved |
| RR3 | Pay, location and contract type not stated | unknown | — | (absent from the posting) | Terms may not fit your constraints, and none are checked yet | `[grounded]` JD silence | What is the base range, what is the location or remote policy, and is the role permanent? | unresolved |
| RR4 | Scope and outcomes concrete | positive_signal | — | "Own product analytics… define and maintain the metrics layer" | The responsibilities are specific, so the role is defined | `[grounded]` JD | Which metrics does the role own on day one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experiment program and the Looker build, in your words: "Designed and ran the experimentation program: 30+ tests a year" | R3, R4 | `[grounded]` your background | pending your approval |
| A2 | Describe the consent-state model as consumer GDPR/CCPA work, and say plainly that it involved no PHI and no HIPAA | R9. Overclaiming here is the likeliest way to lose the interview | `[grounded]` your background | pending your approval |
| A3 | Before applying, confirm the posting on the company's own careers page and ask the recruiter about pay, location and contract type | RR1, RR3 | `[inferred]` from the register | pending your approval |
| A4 | Don't add metrics-layer ownership or mentoring to any document until you've confirmed them | R6, R7 | `[grounded]` the rows above | pending your approval |

## Evidence status

Verified: none yet. Everything here is your own account, which counts as intake until you confirm specifics.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches refused, as web search permission was not granted. Would have confirmed the company exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search refused. Would have set title, scope and any pay band against role-family norms |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can also write this up as a `tuesday-dossier.md` you can reuse for other rounds, if you want.

## Upgrade menu

- Grant web search and I'll run targets 1 and 2: this checks RR1 and gives a market band for this title and seniority.
- Your constraints (pay floor, location or remote, contract type, start date): this runs the hard-gate checks, which are unknown right now (RR3).
- One sanitized experiment write-up, such as the pricing test: R3 moves to `high`.
- A deeper pass on Harborlight (funding, leadership, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

1. Constraints: what are your non-negotiables for this search, meaning pay floor, location or remote, contract type, and earliest start date?
2. R6: did you set the canonical metric definitions at your company, or use definitions others set? What did you maintain?
3. R7: have you mentored or managed junior analysts? If so, what did you do with them, and how did you know it worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.