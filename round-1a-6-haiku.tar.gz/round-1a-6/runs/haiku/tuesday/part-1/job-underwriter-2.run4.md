**`conditional_go`: not a waste of time, but not a clean match.** Your strongest case is as a technical, partner-facing integration lead moving toward product. The posting's first must-have, 3+ years of PM work, is not met by title, so expect to be screened on it.

- **Fit ledger.**
  - `must_have`: direct: R3 · adjacent: R1 (3+ years product management), R2 (shipped API or platform products), R4 (stakeholder management across engineering, sales, customers) · unclear: R6a (agile delivery)
  - `important`: direct: R9 · adjacent: R5 (owning the roadmap), R6b (specs and delivery), R8 (launch coordination) · unclear: R7 (adoption metrics)
  - R3 is the strongest match, self-reported. R1, R2 and R4 are credible bridges with limits named below. R6a has no evidence either way yet, so it is a question, not a gap.
- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** The scope is concrete (RR3). Pay (RR2) and decision rights (RR1) are unstated, and the employer is unverified (RR4).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify on Quartzline's own careers site (RR4); (2) your answers to G1 and G2 show roadmap or delivery ownership, which would move R1 and R6a; (3) the salary band is confirmed before you invest in the loop (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B, as you described it | `[grounded]` your JD text; existence not checked (research refused) |
| Mandate | Own the roadmap for a partner-facing API platform; drive delivery with two engineering squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | Concrete: one platform, two squads, measurable adoption | `[inferred]` from the listed scope |
| Market calibration | Not run; the role-family sweep was refused, so there is no band | — |
| Unknowns | Decision rights (RR1), pay (RR2), employer verification (RR4) | — |
| Contradictions | None visible in the text you pasted; not checked against a careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years as solutions engineer and implementation lead, owning client integrations end to end, with requirements documents and roadmap-input sessions. No PM title, and prioritization ownership is not stated. | `[grounded]` CV; `[generic]` that PM-title screening is common | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations delivered to clients. The product itself was not yours to ship. | `[grounded]` CV | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading are stated. Self-reported, no artifact yet; expect a probe. | `[grounded]` CV | none |
| R4 | Stakeholders across engineering, sales, customers | must_have | adjacent | medium | transferability | Engineering and customer coordination is evidenced; sales is not. | `[grounded]` CV | Name any sales-facing work in the G1 answer |
| R5 | Own the platform roadmap | important | adjacent | medium | transferability | Contributed roadmap input; did not own the roadmap. | `[grounded]` CV | G1 |
| R6a | Agile delivery experience | must_have | unclear | low | discovery | The CV is silent on sprints, backlog and release cadence. | `[grounded]` CV silence | G2 |
| R6b | Write specs; drive delivery with squads | important | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds. | `[grounded]` CV | G2 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | No adoption or usage measurement stated. | `[grounded]` CV silence | G3 |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT for client integrations are evidenced; support and sales launch work are not stated. | `[grounded]` CV | Add a support-facing launch to the G1 answer |
| R9 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and requirements gathering with client integration teams. | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM ownership (R1, R2, R5, R8) | transferability | Shaped roadmaps through input; shipped integrations for clients; no decision where you owned what got built | The PM-years must-have is your biggest exposure; one owned decision moves R1 toward direct | A prioritization call for a client or internal team; a feature you drove from request to release; a roadmap-input summary that changed what shipped | A roadmap-input summary, PRD or release note you wrote | `[inferred]` bridge from the CV; `[generic]` that PM-title screening is common |
| G2 | Agile delivery (R6a, R6b) | discovery | The CV does not say how delivery ran with engineers | R6a is a must-have at unclear | Sprint planning or backlog ownership; release plans you ran | A sprint board, backlog or release plan | `[grounded]` CV silence |
| G3 | Adoption metrics (R7) | discovery | No usage measurement stated | An important row, and the posting's own definition of success | A tool or feature whose use you tracked; an integration-completion or onboarding metric | A dashboard screenshot or metric report | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap decision rights not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own the roadmap while sign-off sits with sales or engineering leadership | `[inferred]` from "own the roadmap" against silence on decision rights | Which roadmap decisions does this role make alone, and which need engineering or sales sign-off? | unresolved |
| RR2 | Pay not stated | unknown | — | (no compensation in the posting text) | Pay is withheld; the band cannot be checked here because the sweep was refused | `[grounded]` posting silent on pay | What base-salary range is budgeted for this role? | unresolved |
| RR3 | Scope defined | positive_signal | — | "two engineering squads"; "define and track adoption metrics" | Scope is concrete: a platform, two squads, measurable adoption | `[grounded]` JD | What adoption metric does this role own first, and what is its current baseline? | noted |
| RR4 | Employer not established | risk_signal | medium | "partner-facing API platform" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: research was refused, so this is unverified, not shown absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's careers site before applying | RR4 | `[grounded]` RR4 | pending your approval |
| A2 | Answer G1–G3, each with one inspectable artifact if you have one | R1, R2, R6a, R7 | `[grounded]` gap queue | pending your approval |
| A3 | Resume edit: keep "Led 30+ client integrations of our REST APIs end to end"; express the roadmap-input sessions as input you gathered and fed to product. Do not write "owned the roadmap" or any PM title. | R1, R5 | `[grounded]` CV; reframing audit: "roadmap input" must not become "roadmap owner" | resume_edits_pending_approval |
| A4 | Position yourself as a technical integration lead moving into API product work. Lead with the 30+ integrations and name the PM-years limit yourself before a screener does. | The bridge case | `[inferred]` from R1, R2 | pending your approval |
| A5 | Put RR1–RR3 to the recruiter or hiring manager early, and get the salary band before the loop | RR1, RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed, so it is not evidence and only shapes the G3 question.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company" and "Quartzline Product Manager Platform APIs jobs"; both refused, as the search permission was not granted. Would have moved RR4 and the posting-live check. |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs salary B2B logistics software"; refused. Would have moved the market band and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'd offer to run the dossier, which would capture this map and register so a later interview-prep pass can reuse it.

**Upgrade menu**
- A live posting link or a careers-page listing → clears RR4 and one `conditional_go` condition.
- Your pay floor, location, contract type and start date → hard-gate checks against them; none exist yet in the posting.
- One inspectable artifact per gap (a PRD, roadmap-input summary, sprint plan or adoption metric) → moves R1, R6a and R7 toward `high` confidence.
- Approve search use and I'll rerun both refused targets (3 of 5 searches used) → the company check and a market band for this title.

**Questions**
1. G1 — Have you ever owned a prioritization decision for a product or internal tool? What did you decide, who had to agree, and what happened?
2. G2 — How did delivery run with engineers: sprints, backlog ownership, or a release cadence? Which parts did you run?
3. G3 — Have you built or launched something a team then adopted? How did you know it was used?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.