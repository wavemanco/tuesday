**Probably worth applying, once two gates are answered. Status: `hold_pending_answers`.** Your skills match the must-haves closely. The open questions are where you're based and whether the $148,000 base clears your floor.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar orchestration), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R7 and R8 are direct on your own statements, with no artifact inspected yet (`medium`); R6 is a credible bridge with its limit named; R9 and R10 are not in your material, and one question covers both.

- **Hard gates:** none failed (R1 and R2 are unconfirmed, not failed); unconfirmed: R1 (Remote US or Denver location), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** sound and checkable. Positive: RR3 (Series C, February 2026, 264 employees), RR4 (stated base within the market band). Open: RR1 (no hiring manager named), RR2 (equity terms not stated).
- **What would change this:** if R1 fails (you can't be US-based or in Denver), the status is `no_go`. If R2 fails (your base floor is above $148,000), it is `no_go` unless the employer moves the base; equity doesn't count toward a base floor unless you say it does. The hold waits on G1 (location) and G2 (base floor).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C $52M, February 2026 | `[grounded]` about page, matched by search |
| Mandate | Build and run the reporting pipelines: app and CRM ingestion, a dbt warehouse on BigQuery, data contracts | `[grounded]` posting, fetched and matching your paste |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | One domain's pipelines, no reports named: consistent with the title's usual scope | `[inferred]` from the posting's language against the recruiter's report |
| Market calibration | Senior data engineers at Series B–D: base median $151,000, interquartile range $139,000–$163,500; "senior" typically 5–8 years, which matches your six | `[generic]` Datawright 2026 report, n=2,310, from your recruiter's paste. Posted range `[grounded]` |
| Unknowns | Hiring manager, equity terms, data-team size | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material | `[grounded]` posting | G1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your base floor wasn't given | `[grounded]` posting | G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated at intake; no artifact yet | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated at intake | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your statement | none |
| R6 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery use. Limit: BigQuery's own cost and partitioning model is unexercised | `[grounded]` your statement; `[generic]` that dbt modelling transfers and platform specifics don't | G1 |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration, stated at intake | `[grounded]` your statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated at intake | `[grounded]` your statement | none |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in the material; may exist | `[grounded]` silence in your material | G3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in the material; may exist | `[grounded]` silence in your material | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6) | transferability | Snowflake and dbt experience; no BigQuery | An important row; a small artifact narrows the objection | A dbt project you ran on any cloud warehouse; partitioning or cost work on Snowflake that transfers | A small BigQuery dbt project, or a note on the cost model you'd apply | `[inferred]` bridge from your Snowflake work; `[generic]` that this is the likeliest objection |
| G3 | Ingestion and data contracts (R9, R10) | discovery | Not in your material | Both are named responsibilities | Pipelines from a product database or a CRM; agreed schemas with consumers | A pipeline diagram or a data-contract doc | `[grounded]` silence in your material |

The queue holds no questions. The questions are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | "Senior Data Engineer — Pellucid Learning" | The team owner and reporting line are unclear | `[generic]` postings often omit the manager | Who would I report to, and what does the data team own today? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Equity could be worth little or a lot | `[inferred]` from the posting's silence on grant size | What is the grant size, its vesting, and the latest valuation? | unresolved |
| RR3 | Funding and scale stated | positive_signal | — | "Series C ($52M, February 2026)" | Funded and staffed for a reporting function | `[grounded]` about page | What runway does the Series C give the data team? | noted |
| RR4 | Stated base within market band | positive_signal | — | "$148,000–$166,000" | Pay reads as market-normal for the title | `[generic]` band from the 2026 report; posted figure `[grounded]` | How is the base set for this level? | noted |

Employer-not-established: not raised. The about page and the live careers page both match the posting, so the standing entry doesn't apply.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Answer G1 and G2 before applying | They decide R1 and R2 | `[grounded]` gate rows | proposed |
| A1 | Build a small BigQuery dbt project; note what you learned | Gives R6 a work sample | `[generic]` that a work sample narrows a transferability limit | proposed, pending your approval |
| A2 | Ask the recruiter who the hiring manager is and what the data team owns | RR1 | `[grounded]` RR1 | proposed, pending your approval |
| A3 | Ask the recruiter for the equity grant, vesting and valuation | RR2 | `[grounded]` RR2 | proposed, pending your approval |
| A4 | If you apply, describe BigQuery as new to you, not as experience | Keeps the claim within what you've done | `[grounded]` R6 | proposed, pending your approval |

## Evidence status

Verified: R3, R4, R5, R7, R8 — your own specific statements, not yet backed by an inspected artifact (`medium`). Unverified leads: none. Rejected inferences: none. The standing employer-not-established entry is not raised.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C tutoring Denver" and fetched pellucidlearning.com/careers/senior-data-engineer. The posting is live ("Accepting applications") and matches your paste; the about page matches too. Moved: the employer-established check; no contradiction |
| 2. Role-family sweep | skipped | Your recruiter's pasted 2026 report already fixes the market calibration line and the scope and seniority norms; no search would change those rows |
| 3. Hiring manager's public footprint | n/a | No name was given |

Your material holds no named hiring manager, so there was nothing to research at target 3.

I can save this analysis as `tuesday-dossier.md` if you want it kept.

**Upgrade menu**

- Your location (R1) and your base floor (R2): these decide the hold. They are the most useful inputs.
- A small BigQuery artifact → R6 moves toward `direct`.
- The recruiter's answers on the hiring manager and equity → RR1 and RR2 close.
- A deeper research pass on Pellucid (leadership changes, past hiring, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

1. **G1 (R1):** Where are you based, and are you US-based and able to work remotely or from Denver?
2. **G2 (R2):** Is $148,000 base your floor, or would you need more base, with equity as the difference?
3. **G3 (R9, R10):** Have you built ingestion from a CRM or product database, or owned a data contract analysts relied on? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.