**Yes, it's worth applying, on conditions. Status: `conditional_go`.** Your core stack matches the posting. The open items are two hard-gate terms the posting states and you haven't stated your position on, plus BigQuery, which you haven't used.

**Fit ledger.**

- `hard_gate` — unclear: H1 (Remote (US) or Denver office), H2 ($148,000–$166,000 salary)
- `must_have` — direct: R1 (5+ years data engineering), R2 (strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (orchestration with Airflow or similar), R5 (data quality testing)
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R6 (ingestion from app and CRM), R7 (data contracts analysts depend on)

R3 `medium` — your stack and dbt work are stated, not yet inspected. R8 `adjacent` — Snowflake transfers, BigQuery itself is unused.

**Opportunity ledger.** The posting is clear: pay is stated, scope is concrete, and the seniority matches the market norm (RR3 positive). The open items are the self-sourced funding claim (RR1) and the unnamed hiring manager (RR2).

- **Hard gates:** none failed; unconfirmed: H1 (Remote (US) or Denver office), H2 ($148,000–$166,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work in the US remotely or from Denver (H1); (2) $148,000 clears your floor (H2); (3) BigQuery is framed as new, never as experience (R8).
- **What would change this:** a failed H1 or H2 would make it `no_go`. An interview that shows the ingestion or data-contract work (R6, R7) is outside your history would weaken the fit.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016, Denver, 264 employees | `[grounded]` company About page, fetched by search |
| Mandate | Build and run ingestion (app and CRM), a dbt-modelled BigQuery warehouse, and analyst-facing data contracts | `[grounded]` JD |
| Scope read | Owns the reporting pipeline domain; no direct reports stated | `[inferred]` from the duties list |
| Market calibration | Posted band $148k–$166k, midpoint $157k. Datawright median $151k, IQR $139k–$163.5k. The band sits around the median, and its top end is above the IQR. Seniority norm 5–8 years fits your 6 | `[grounded]` pasted Datawright report; `[generic]` what this means for pay at Series B–D |
| Unknowns | Your pay floor, your work location and authorization, the ingestion and contract scope, the hiring manager | — |
| Contradictions | None: the live careers page matches the JD text you pasted | `[grounded]` fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Remote (US) or Denver office | hard_gate | unclear | medium | hard_gate | Your location and authorization weren't in the material | `[grounded]` JD; `[inferred]` unstated | Q1 |
| H2 | $148,000–$166,000 salary | hard_gate | unclear | medium | hard_gate | Your floor wasn't given; the posted band is in the JD | `[grounded]` JD | Q2 |
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years stated in intake prose; no artifact yet | `[grounded]` your background, self-reported | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake, stated | `[grounded]` your background | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production, stated | `[grounded]` your background | none |
| R5 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite, stated | `[grounded]` your background | Offer a sanitized suite excerpt |
| R6 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned in your background | `[inferred]` from the duties list | Q3 (G2) |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned; your data-quality work may be adjacent | `[inferred]` from the duties list | Q3 (G3) |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery's cost model, partitioning and IAM are not exercised | `[inferred]` bridge from your Snowflake work | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience, no BigQuery | The duties name BigQuery; the requirement doesn't | Porting a dbt project between warehouses; any cost or partitioning decision on Snowflake | A small BigQuery dbt project, or your Snowflake cost work | `[inferred]` bridge; `[generic]` that BigQuery is the likeliest interview objection |
| G2 | Ingestion from app and CRM (R6) | discovery | Your payroll pipelines are not described as app or CRM ingestion | A duty, not a stated requirement, but it is the work you'd own | Pulling from a product database, a CRM API, or event streams | Pipeline diagram or sanitized DAG | `[inferred]` from the duties list |
| G3 | Data contracts (R7) | discovery | Contract work is not described | Analysts depend on it; a stated duty | Schema agreements, breaking-change handling, or tests consumers relied on | A sanitized contract or schema-test example | `[inferred]` from the duties list |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Funding and headcount are self-sourced | risk_signal | low | "Series C ($52M, February 2026)" | The figures appear only on the company's own About page; two searches found no independent report | `[grounded]` search results | Which investors led the Series C, and where was it announced? | unresolved |
| RR2 | Hiring manager not named | unknown | — | (posting names no manager) | The team and reporting line are unknown | `[grounded]` JD | Who is the hiring manager, and which team does this role sit in? | unresolved |
| RR3 | Pay and scope stated | positive_signal | — | "Salary $148,000–$166,000 plus equity" | You can judge fit before applying | `[grounded]` JD | What does the equity grant look like: size, vesting, and strike? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt-on-Snowflake build and the Great Expectations suite | Your strongest verifiable claims for R3 and R5 | `[grounded]` your background | proposed |
| P2 | Name BigQuery as new, with the Snowflake transfer stated | Avoids claiming experience you don't have (G1) | `[grounded]` R8 | proposed |
| P3 | Ask RR2 and RR3 in the first recruiter contact | The register doubles as interview preparation | `[grounded]` register | proposed |

Every line here is for you to approve before it goes out.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver Series C" and "Pellucid Learning $52M Series C funding tutoring", both returning only pellucidlearning.com/about. Fetched pellucidlearning.com/careers/senior-data-engineer: the live posting matches the JD text you gave, so there's no contradiction. Raised RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the band and the seniority norm; a search would add nothing |
| 3. Hiring manager's public footprint | n/a | No name was given |

Your pasted material was not checked against a second source; the funding figures remain self-reported (RR1).

If you want, I can write this up as `tuesday-dossier.md`, a file you can keep and update as the loop moves.

**Upgrade menu**

- A small BigQuery dbt project, or a description of a Snowflake cost decision → R8 moves toward `direct`.
- A sanitized Great Expectations suite excerpt → R5 gets an inspectable artifact and moves to `high`.
- An independent report of the Series C (press or an investor announcement) → RR1 closes.
- The hiring manager's name → RR2 closes and the scope read sharpens.
- A deeper pass on the company (leadership changes, funding, employee reports): up to 5 more searches and 2 more fetches. Say the word and I'll run it.

**Questions**

Q1 (H1): Are you authorized to work in the US, and can you work remotely from the US or from Denver?

Q2 (H2): Is $148,000 your floor for this role?

Q3 (G2, G3): Have you built ingestion from an app or CRM, or data contracts that analysts relied on? If so, describe one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.