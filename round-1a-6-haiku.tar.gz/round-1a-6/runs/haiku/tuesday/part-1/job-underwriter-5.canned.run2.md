**Probably worth applying to, once one gate is answered.** Your core stack matches five of the six must-haves. The real gap is BigQuery, and the posting is silent on location, equity and team. Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office)
- `must_have`: direct: R2 (5+ years), R3 (SQL and Python), R4 (dbt and a cloud warehouse), R5 (Airflow or similar), R6 (data quality testing)
- `important`: adjacent: R7 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R7 is a real gap: Snowflake carries over, BigQuery does not yet. R1 is the one open gate. R8 and R9 are not in your message at all.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR1 and RR2 are unknowns (equity amount and team scope are unstated). RR6 is positive: the posted pay sits inside the market band. The standing employer-not-established entry did not fire, because the company's own careers page matches the posting.
- **What would change this:** the hold waits on G1 (R1). If you are US-based or can work from Denver, this moves to `conditional_go`, with the BigQuery gap framed as adjacent (R7) and equity and team scope confirmed (RR1, RR2). If you are not US-based, it is `no_go`, and the gate is the reason.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring, 31 states, Denver, 264 employees, Series C $52M (Feb 2026) | `[grounded]` company About page, from search snippet; not fetched or independently checked |
| Role | Pipelines for reporting, app and CRM ingestion, dbt warehouse on BigQuery, data contracts | `[grounded]` JD, matches the careers page fetched |
| Scope | Ownership of one domain's pipelines and contracts; no team named | `[inferred]` from the JD's silence on team |
| Pay | $148,000–$166,000 base, plus equity; midpoint $157,000 | `[grounded]` JD |
| Market calibration | Senior DE at Series B–D: median $151,000, IQR $139,000–$163,500; posted range sits inside the IQR, upper half | `[generic]` Datawright 2026 pay report (n=2,310), from your recruiter; a pattern, not this employer's offer |
| Unknowns | Equity amount and vesting; team size; hiring manager (not named); your location | — |
| Contradictions | None between the JD text and the careers page | `[grounded]` careers page fetch |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in what you gave me; no claim exists yet | `[grounded]` JD location line | G1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated; no artifact yet. Length of experience is graded, not gated | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; not inspected | `[grounded]` your stated background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | Built a dbt project of about 180 models on Snowflake, stated | `[grounded]` your stated background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated | `[grounded]` your stated background | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | `[grounded]` your stated background | none |
| R7 | BigQuery warehouse (responsibility) | important | adjacent | medium | transferability | Snowflake and dbt carry over. The limit is BigQuery-specific work, such as cost, partitioning and loading. You say you have never used BigQuery | `[inferred]` adjacency from Snowflake to BigQuery | G2 |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your message | `[grounded]` JD responsibilities | G3 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your message | `[grounded]` JD responsibilities | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence |
|---|---|---|---|---|---|
| G1 | Location and work authorization (R1, hard_gate) | hard_gate | Nothing in your message settles it | It decides between `conditional_go` and `no_go` | Confirmation of your location (a yes or no answer is enough) |
| G2 | BigQuery (R7, important) | transferability | Snowflake and dbt experience; no BigQuery | Narrows the one real technical objection | A small BigQuery project, or a sanitized note on what would differ |
| G3 | App and CRM ingestion (R8, important) | discovery | Not stated | A named responsibility of the role | Pipeline design note, or a repo |
| G4 | Data contracts (R9, important) | discovery | Not stated | A named responsibility of the role | A sanitized contract or schema doc |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unquantified | unknown | — | "plus equity" | Equity could be worth little or a lot; the posting gives no amount or vesting | `[generic]` equity terms are often left unstated early | What is the equity grant, its vesting schedule, and how is its value set? | unresolved |
| RR2 | Team and decision scope unstated | unknown | — | "Build and run the pipelines" | Ownership could be solo or shared with others | `[inferred]` from the JD's silence on team | Who else owns the warehouse and the BigQuery models, and which decisions are mine? | unresolved |
| RR3 | Hiring manager not named | unknown | — | none in posting | Reporting line unclear | `[grounded]` JD names no one | Who would I report to? | unresolved |
| RR4 | Stage and headcount self-reported | unknown | — | "Series C ($52M, February 2026)" | Only the company's own site states them; I found no independent coverage | `[grounded]` About page; the absence of coverage is one search | Which investors led the round, and where can I read about it? | unresolved |
| RR5 | Posted pay inside market band | positive_signal | — | "$148,000–$166,000" | Pay is in the expected range for this seniority | `[generic]` pay report band | none needed | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and work authorization before investing in the application | R1 gate | `[grounded]` JD location line | waiting on your answer |
| A2 | Proposed resume line on BigQuery: "dbt and Snowflake, about 180 models; no BigQuery use yet" | R7, honest framing | `[grounded]` your stated "Built our dbt project on Snowflake — about 180 models" and "Never used BigQuery" | pending your approval |
| A3 | Ask the recruiter RR1, RR2 and RR3 before the loop | Equity, team and reporting line | `[grounded]` register | pending your approval |
| A4 | Optional: a small BigQuery project as a work sample | R7 limit | `[generic]` common way to close a platform gap | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report until you confirm specifics.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: matches the JD you pasted. Searched "Pellucid Learning live online tutoring K-12 Denver": no results. Searched "Pellucid Learning Series C funding February 2026": returned pellucidlearning.com/about (snippet only, not fetched). Moved: the employer resolves to its own site, with no independent coverage found, so stage and headcount rest on self-report |
| 2. Role-family sweep | skipped | Your recruiter's pay report already fixes the market band (median $151,000, IQR $139,000–$163,500); a search would restate it |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` so the next step can read it.

**Upgrade menu**

- A small BigQuery project or sanitized note → R7's limit narrows, and the confidence can rise if it is inspectable.
- A sanitized ingestion design or contract doc → R8 and R9 move off `discovery`.
- The recruiter's answers on equity, team and reporting line → RR1, RR2 and RR3 close.
- A deeper pass on Pellucid (funding coverage, leadership, reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Are you based in the US, and is remote-US or the Denver office workable for you?

G3 — Have you built ingestion from a product app or a CRM? Which sources and tools, and who owned it end to end?

G4 — Have you defined data contracts with analysts or other consumers (schemas, ownership, breaking-change rules)? If so, what did one look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.