**No. Don't pursue this one as posted.** It fails both of your hard constraints on its own terms, and the other things that feel off are real.

## Decision snapshot

No: R1 and R2, both hard gates, fail. The base tops out $65k under your $150k floor, and the on-site requirement is stated as "no exceptions." **Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: failed: R1 (Base compensation), R2 (On-site location)
- `must_have`: direct: R3, R4, R5; unclear: R6 (SEO and content), R7 (Brand), R8 (PR), R9 (Partnerships), R10 (Sales ops)
- `important`: direct: R13 (SQL and GA4); unclear: R11 (Team of one to start), R12 (Ambiguity)

R3, R4 and R5 are direct on your profile, but the profile is prose, not documents. The unclear rows are scope the posting names and your profile does not.

**Opportunity ledger.** Your unease tracks the posting's own language. RR3 and RR4 are the severe flags. RR2 (evenings and weekends as the default) and RR5 (success metrics that "will evolve") are unresolved risks. The equity term is undefined, and the mandate is seven functions for one person to start (RR1). The reporting line is clear (RR6).

- **Hard gates:** failed: R1 (Base compensation), R2 (On-site location); met: none
- **Severe red flags:** RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** both gates would have to differ, not one. A written remote option for R2 and a base of at least $150k for R1. Nothing else in the posting moves the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; stage and profitability claims unchecked |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site 5 days, "no exceptions"; evenings and weekends as default | `[grounded]` posting |
| Pay | $70–85k base plus "meaningful equity upside" (undefined) | `[grounded]` posting |
| Scope read | Seven functions for one person at the start | `[inferred]` from the list against one headcount |
| Market calibration | Not established. The salary search was refused, so there is no band, and I won't give one from memory | none |
| Unknowns | Equity terms, budget and headcount, success metrics, whether the profitability claim holds | — |
| Contradictions | None found within the posting. Its own careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at or above $150k | hard_gate | hard_gate_fail | high | hard_gate | Posted range tops out at $85k | `[grounded]` posting; your stated floor | none |
| R2 | Remote-only, not relocating | hard_gate | hard_gate_fail | high | hard_gate | Austin on-site 5 days, "no exceptions" | `[grounded]` posting; your stated constraint | none |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Growth lead then Head of Growth | `[grounded]` your profile | CV to raise to high |
| R4 | Own paid acquisition end to end | must_have | direct | medium | none | Owned paid at two B2C subscription companies | `[grounded]` your profile | CV |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze | `[grounded]` your profile | CV |
| R6 | SEO and content | must_have | unclear | low | discovery | Not in your profile | `[grounded]` profile silence | G1 |
| R7 | Brand | must_have | unclear | low | discovery | Not in your profile | `[grounded]` profile silence | G1 |
| R8 | PR | must_have | unclear | low | discovery | Not in your profile | `[grounded]` profile silence | G1 |
| R9 | Partnerships | must_have | unclear | low | discovery | Not in your profile | `[grounded]` profile silence | G1 |
| R10 | Sales ops | must_have | unclear | low | discovery | Not in your profile | `[grounded]` profile silence | G1 |
| R11 | Team of one to start | important | unclear | low | discovery | Built and managed teams of 3–7; solo operation not described | `[inferred]` from profile | G2 |
| R12 | Thrive on ambiguity, metrics evolve | important | unclear | low | discovery | Scaled $8M to $40M ARR with a budget you controlled; ambiguity not described | `[inferred]` from profile | G2 |
| R13 | Analytics: SQL, GA4 | important | direct | medium | none | Deep in SQL and GA4 | `[grounded]` your profile | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content, brand, PR, partnerships, sales ops (R6–R10, must_have) | discovery | Profile lists paid, lifecycle, experimentation and analytics; none of these five | Five must-haves with no evidence, and most of the posted scope | Owning a content or SEO program, a brand refresh, press coverage, a partner channel, a sales-to-marketing handoff | A CV, channel reports, a content plan, a partnership brief | `[grounded]` profile silence; `[generic]` that a Head of Growth listing carries this breadth |
| G2 | Operating solo before building a team (R11, R12) | discovery | Teams of 3–7 are documented; operating alone or with no budget control is not | The posting says it wants players who "don't need a bench" | A launch you ran with no direct reports; a channel built before hiring | A launch plan, a budget you set | `[inferred]` from the team history against the posting's framing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seven functions for one person at the start | risk_signal | medium | "You will be a team of one to start" | Year-one scope may exceed one person's capacity, with no budget or headcount named | `[inferred]` from the function list against one headcount | What budget and headcount will this role control in the first 90 days, and which of these functions are expected in year one? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Frequent off-hours work is likely the default | `[generic]` always-on pattern | How often were evenings and weekends needed last quarter, and how is that time recognised? | unresolved |
| RR3 | Base pay below your stated floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Top of range is $65k short of your floor; equity is undefined | `[grounded]` posting figure against your floor | What base salary is budgeted for this role, and is it open above $85k? | confirmed |
| RR4 | On-site rule with no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Incompatible with remote-only | `[grounded]` posting against your constraint | Is any remote or hybrid arrangement possible for this role, and on what terms? | confirmed |
| RR5 | Success metrics undefined on a broad mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no stated definition of success | `[generic]` absent-metrics pattern | What three numbers will define success at six and twelve months, and who sets them? | unresolved |
| RR6 | Clear reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Mandate and reporting are concrete | `[grounded]` posting | Who on the board reviews growth results, and how often? | noted |
| SE1 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | Not checked: search was refused, so existence is unverified. It may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply or start outreach on this posting as written | R1 and R2 fail on the posting's own terms | `[grounded]` R1, R2 | pending your approval |
| A2 | If you want to test it, ask the recruiter in writing whether the on-site rule and base range are open | Only a written change could move R1 or R2 | `[grounded]` RR3, RR4 | pending your approval |
| A3 | Find the posting on Novaline's own careers page before any contact | SE1: employer not yet established | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Your constraints are user-stated, and your profile is prose with no documents behind it.

Web search was refused by the session's permission setting, so no employer or market check ran.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline were refused. Would have moved role reality's organization and contradictions rows, and SE1 |
| 2. Role-family sweep | unavailable | One search for Head of Growth base pay at Series A was refused. Would have set the market calibration line and the pay check in RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want this kept for later prep, I can write it to `tuesday-dossier.md`. Say the word.

## Upgrade menu

- **Search permission granted:** the employer check and salary band can run. The L1 cap has 2 searches and 2 fetches left. This would settle SE1, RR3 and the market calibration line.
- **A CV or a work sample:** R3, R4, R5 and R13 move from medium toward high, and G1 shows whether any of the five unevidenced channels has real work behind it.
- **A written reply from the recruiter on the on-site rule or pay:** RR3 and RR4 close. The status changes only if a gate does.

**Questions**

RR3 / RR4: Has anyone at Novaline said anything about Austin or base pay beyond what the posting states? A written answer that the on-site rule or the $150k floor can move is the only thing that would change this status.

G1: Which of SEO and content, brand, PR, partnerships or sales ops have you owned yourself, even in part? Name the work, not the title.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.