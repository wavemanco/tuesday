**Yes, on conditions. Status: `conditional_go`.** Your record matches the must-haves. Before you invest in the application, two things need checking: whether the posting is real and live, and the pet-insurance gap.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK-based)
- `must_have` — direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting or actuarial leads)
- `important` — direct: R6 (designing and reading price tests) · adjacent: R7 (pet-insurance product knowledge)
- `preferred` — direct: R8 (insurance experience)

R3 (`medium`) — daily use stated, no artifact yet; R7 — motor pricing bridges it, and the pet-specific limits are yours to name.

**Opportunity ledger.** The employer is not yet verified (RR1), pay is absent from the JD as you pasted it (RR3), and whether the role manages people is unstated (RR2). One entry runs the other way: the mandate and its outcomes are specific (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting appears on Brindlemoor's own careers page (RR1); (2) you are UK-based and eligible to work there (R1); (3) the pet gap is framed as transferable, with its limits named (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD as pasted |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior analytics post owning rating and test work end to end; whether it carries people leadership is not stated | `[inferred]` from the responsibility list against silence on reports |
| Market calibration | Not established: the role-family search was refused, so there is no pay band to set against | — |
| Unknowns | Pay; line management; the employer's own posting; any pet claims or pricing data you have touched | — |
| Contradictions | None visible in the JD as pasted; the careers page was not checked | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (eligible to work) | hard_gate | unclear | low | hard_gate | Not established in what you gave; no constraint stated | `[grounded]` JD | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years stated, last two senior; length is graded as fit, not a gate; self-reported | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no query or code inspected | `[grounded]` your intake | none; a sanitised query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver book; motor, not pet | `[grounded]` your intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests run last year with the underwriting team | `[grounded]` your intake | none |
| R7 | Pet-insurance product knowledge (from "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over; pet cost-of-care and claim-frequency patterns are not in your history | `[inferred]` adjacency from motor pricing; `[generic]` that pet claim patterns differ from motor | G1 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance pricing | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R7, important) | transferability | Motor pricing and GLM work; no pet data, claims or product | An important row at `adjacent`; a stronger bridge narrows the likeliest objection | Any pricing or claims work on pets, or on a product with vet-cost or claim-frequency drivers; a monoline product with its own loss history | A sample pricing note, a claims-frequency analysis, or a course outline | `[inferred]` bridge from motor work; `[generic]` that pet claim patterns differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | Research was refused, so the employer is unverified. The posting may be stale or aggregated, or the employer may be too new or small to have a footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Line management not stated | unknown | — | "Own pricing analytics" | The role may carry people leadership, and you have not managed anyone | `[inferred]` from the responsibility list against silence on reports | Does this role line-manage anyone, and if so, how many people and at what level? | unresolved |
| RR3 | Pay absent from the JD as pasted | unknown | — | JD as pasted states no pay | Pay may sit on the careers page or be withheld | `[grounded]` JD as pasted | What is the base salary range for this role? | unresolved |
| RR4 | Specific mandate and outcomes | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is concrete and matches your record | `[grounded]` JD | What does success look like at twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Brindlemoor's own careers page before investing effort | see RR1 | `[generic]` pattern | pending your approval |
| A2 | Lead the CV with the GLM model, the 14 price tests and the quarterly review, all described as motor work | see R4, R5, R6 | `[grounded]` your intake | resume_edits_pending_approval |
| A3 | Present pet as transferable, with the limit named: motor pricing and loss analysis carry over; pet cost and claim patterns are new to you | see R7 | `[inferred]` from the G1 bridge | pending your approval |
| A4 | Ask the employer about line management and pay rather than assuming either | see RR2, RR3 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst" were refused (WebSearch permission not granted). Would have moved whether the employer and posting are live (RR1) and pay (RR3) |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst UK pet insurance salary GLM" was refused. Would have moved the market calibration and the pay check |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. Would have moved the scope read and which story to lead with for this reader |

If you grant WebSearch permission, I can rerun these three targets.

I can also write this up as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- The posting URL or the careers-page link → RR1 closes or stays open, and RR3 may close.
- WebSearch permission → the three refused searches run, calibrating pay and checking the employer and the hiring manager's public footprint.
- A sanitised pricing note, claims-frequency analysis or other sample from motor work → R3 to `high`.
- Any pet, livestock or vet-cost dataset or project you have touched → R7 closes or narrows.

## Questions

R1 — Are you based in the UK and eligible to work there for a fully remote UK role?

G1 — Have you done any work where pet-style cost or claim patterns mattered, even a side project or a course? If not, say skip.

Candidate constraints — Do you have non-negotiables (pay floor, contract type, start date, location) so I can check this role against them? If none, say skip.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.