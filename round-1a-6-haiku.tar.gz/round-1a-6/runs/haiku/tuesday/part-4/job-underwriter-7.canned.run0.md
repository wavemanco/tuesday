**Yes, apply, on conditions. Status: `conditional_go`.** Your core clinical match is strong: wound care, catheter care, insulin and home visits all have ward or discharge-team evidence. The gaps are your own caseload, end-of-life and care planning, written records on an EPR, and Doppler. None of them is a gate you fail, and none needs to be settled before you apply.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: direct: R1, R2
  - `must_have`: direct: R3, R4a, R5a, R6a · adjacent: R4b (leg-ulcer care), R8 (own caseload) · unclear: R5b (continence), R6b (care planning), R7 (end-of-life), R9 (written records, EPR)
  - `preferred`: absent: R10 (Doppler)

  R4a and R8 carry the strongest evidence and the clearest limits. R7 and R9 are open questions, not failures.
- **Opportunity ledger.** Sound posting with an identified employer and a named contact. The pay sits inside the market band, and the only unknowns are about how the role is supported (RR1, RR2) and whether the advert is live (RR4). No severe red flags.
- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. "Direct" here means met on your own statement. Nothing has been checked against the NMC register or your licence.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm your NMC entry and licence are as stated; (2) you can give a real example of home work beyond your first-week visits, or name what you would need to learn; (3) the advert is confirmed live on the employer's own careers page.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` their About page |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team; spoke at the 2025 Community Nursing Forum on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Pay | Posting £31,050–£37,800 plus mileage. Survey median for community staff nurse Band 5 in England is £34,300, interquartile range £32,400–£36,600. The posting's range sits around that middle. | `[generic]` one 2026 survey, n=1,240; `[grounded]` posting |
| Mileage and car | 61% of survey respondents were paid mileage; the posting says mileage is paid and pool cars are provided | `[generic]` survey; `[grounded]` posting |
| Unknowns | Mileage rate; how caseloads are allocated; how senior support works in practice | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Your stated registration, revalidation March 2028. Stated, not checked. | `[grounded]` CV | Check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, stated, not checked | `[grounded]` CV | Check your own licence |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse; CV-only | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds on ward and in discharge work | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over; leg-ulcer work is not on your CV. Limit: no leg-ulcer caseload. | `[inferred]` from R4a | Ask whether you have dressed leg ulcers |
| R5a | Catheter care | must_have | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | Ask (Q3 below) |
| R6a | Insulin administration | must_have | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R6b | Care planning | must_have | unclear | low | discovery | CV silent on planning across visits | `[grounded]` CV silence | Ask (Q2 below) |
| R7 | End-of-life visits | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | Ask (Q2 below) |
| R8 | Small caseload of own, housebound adults at home | must_have | adjacent | medium | transferability | Home visits in your first week after discharge, 18 months. Limit: no ongoing caseload, never held your own. | `[inferred]` from CV | Ask (Q1 below) |
| R9 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | CV silent on records and EPR | `[grounded]` CV silence | Ask (Q3 below) |
| R10 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler experience. Closure path is training, which the contact has spoken publicly about. | `[grounded]` CV; `[grounded]` forum page | Ask at the informal chat whether training is given |

**Gap recovery queue.** Rows state the gap and what would close it. The questions are in the closing block.

- **G1, own caseload (R8):** closes with one example of home work beyond the first week, or of planning across visits.
- **G2, end-of-life and care planning (R6b, R7):** closes with one named case at home.
- **G3, records (R9):** closes with the EPR you used and how fast you wrote up visits.
- **G4, Doppler (R10):** closes with training from the employer, or with any prior vascular assessment.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload support not described | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Supervision may be light or heavy; the posting does not say | `[inferred]` from silence | How many patients will a new Band 5 hold, and how often do you review their notes with the senior nurse? | unresolved |
| RR2 | Doppler training not mentioned | unknown | — | "Doppler assessment for leg ulcers" (desirable) | Training may be given to staff without it | `[grounded]` forum talk on Doppler training | Is Doppler training provided for staff who have not done it? | unresolved |
| RR3 | Mileage rate unstated | unknown | — | "plus mileage" | Rate and pool-car access unknown | `[inferred]` | What is the mileage rate, and is a pool car allocated to each nurse? | unresolved |
| RR4 | Advert not confirmed live | unknown | — | the posting you shared | The posting may be stale or only on a third-party board | `[inferred]` | Is this advert live on your careers page? | unresolved |
| — | Positive: named contact, explicit supervision, pool cars, pay within band | positive_signal | — | — | Role is defined and resourced | `[grounded]` posting; `[generic]` band | — | noted |

**Application plan** (every row needs your approval)

- **A1** — Apply. Lead with wound care, catheter care, insulin and home visits. `pending your approval`
- **A2** — Describe your home visits as they were: first-week post-discharge visits in a team that did them, not as an ongoing caseload. Do not say you have managed a caseload. `resume_edits_pending_approval`
- **A3** — Ask Rhiannon Mabbott about caseload support and Doppler training at the informal chat. `pending your approval`

**Evidence status**

Verified: none yet. Everything above rests on your CV, which the map treats as leads until you confirm specifics.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched calderbrookhealth.example/about, which confirms the CIC, its NHS contract, 410 staff and four hubs. Searched for the careers page twice without finding it, so the posting is not confirmed live (RR4). |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary"; returned Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration: `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched Rhiannon Mabbott's name with the employer; returned the Community Nursing Forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the Doppler question (RR2) and the choice of what to ask her. |

**Dossier offer.** I can write this up as a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**

- A written example of caseload work or planning across visits → R8 and G1 close.
- A redacted record or EPR screenshot showing your documentation → R9 and G3 close.
- The advert link on the employer's own careers page → RR4 closes.
- Deeper research on Calderbrook: leadership, staffing patterns, past adverts (up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- **G1 (R8):** When you did discharge-to-assess visits, did you ever follow a patient beyond their first week, or plan their care across several visits? Describe one case.
- **G2 (R6b, R7):** Have you led on care planning or end-of-life care for a patient at home? What did you own, and what happened?
- **G3 (R9):** Which electronic record did you document in, and how quickly did you write up a visit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.