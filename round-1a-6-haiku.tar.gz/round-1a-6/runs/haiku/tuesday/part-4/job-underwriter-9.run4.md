**Short answer: yes, this is routine.** Bank details, PPS number and a passport scan after a written offer that names the role, pay and location are normal onboarding. Nothing in this offer asks for them before you accept, and nothing in it is a red flag. Your rule ("never hand those over") is good for early-stage requests, such as an unsolicited job offer that asks for ID before any interview. This one comes after a process you went through in person.

**Decision snapshot: `conditional_go`**

Yes, the data requests are routine. The offer names the role, the €40,000 salary, the reporting line, the hybrid pattern and the start date. It asks for your details only through a portal after you accept.

- **Fit ledger.**
  - `hard_gate` — unclear: R9 (Hybrid, two days a week in Limerick)
  - `must_have` — direct: R1, R2, R3, R4, R5, R6 · unclear: R7 (Irish PAYE, PRSI and USC)
  - `important` — adjacent: R8 (Pension changes)
  
  R7 is the one must-have the evidence doesn't yet cover. R8 is a learning area, not a gap you have to hide.
- **Opportunity ledger.** The offer is specific and consistent with the advert. The one open item is that I could not check Marrowgate's own web footprint (RR1).
- **Hard gates:** none failed; unconfirmed: R9 (Hybrid, two days a week in Limerick); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 — you confirm the post on Marrowgate's own careers page before accepting; (2) R9 — two office days a week work for your commute and notice period.
- **What would change this:** a request to pay anything, to deposit a cheque, or to send bank or ID details before a written offer, or a change to the role or pay in the final offer.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Marrowgate Housing, a Limerick housing association | `[grounded]` advert and offer |
| Mandate | Monthly payroll for 240 staff, starters and leavers, pension changes, monthly ledger reconciliation | `[grounded]` advert |
| Pay | €40,000 offered, inside the advertised €38,000–€42,000 band | `[grounded]` advert and offer |
| Reporting | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Contradictions | None between advert and offer | `[grounded]` both documents |
| Unknowns | Employer footprint (unchecked); scope of pension changes | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Payroll for about 90 staff, fortnightly, for 2+ years | must_have | direct | medium | none | Three years at a hotel group | `[grounded]` your statement | none |
| R2 | Starters and leavers | must_have | direct | medium | none | Part of the same role | `[grounded]` your statement | none |
| R3 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done monthly | `[grounded]` your statement | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your statement | none |
| R5 | Strong Excel | must_have | direct | medium | none | Pivot tables and XLOOKUP daily | `[grounded]` your statement | none |
| R6 | Irish PAYE, PRSI and USC | must_have | unclear | medium | evidence | Not stated whether you have run Irish statutory payroll | — | question 1 |
| R7 | Pension changes | important | adjacent | low | experience | You know the deductions side; your manager handled changes | `[grounded]` your statement | question 3 |
| R8 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Constraint not given | — | question 2 |

The table has eight rows because I've merged your "2+ years" with the payroll run in R1. R6 and R7 are the two gaps the advert would test.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not checked | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The employer may be too small to have a web footprint, the posting may be stale, or it may not be the hiring entity. Your two in-person interviews make this less likely | `[generic]` pattern for small employers, not a claim about this one | Which page on Marrowgate's own website lists this Payroll Administrator post, and what is the address of your onboarding portal? | unresolved |

RR1 is a standing check. It stays open because I could not search (see evidence status). Nothing else in the offer is an entry. Entering your bank, PPS and passport details in the employer's own portal is routine, as is bringing originals on day one.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the post on Marrowgate's own careers page before accepting | RR1 | `[generic]` standing check | pending your approval |
| A2 | Enter bank, PPS and passport details only in the portal at the address on Marrowgate's own website; never email scans | Keeps the data in the employer's system | `[generic]` routine onboarding | pending your approval |
| A3 | Ask Declan which pension tasks the role covers | R7 | `[grounded]` advert | pending your approval |

**Evidence status**

Verified: none yet. Every claim above is from what you told me.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused (permission not granted), so the employer check in RR1 did not run. This is the check that would close RR1 |
| 2. Role-family sweep | unavailable | Not sent after the refusal. Would have calibrated the €40,000 salary against `[generic]` norms |
| 3. Hiring manager's public footprint | unavailable | Not sent after the refusal. Declan Garvagh is named; would have shaped interview positioning only |

**Upgrade menu**

- Your own check of Marrowgate's careers page and portal address closes RR1.
- Any Irish statutory payroll you have run, on Revenue's systems or at a hotel group with Irish payroll, moves R6 up.
- Declan's answer on pension scope moves R7.
- If you allow web search, I can run the three L1 targets above.

I can also write this assessment to `tuesday-dossier.md` so you can keep it.

Questions, answer in text or say skip for any of them:
1. Have you run PAYE, PRSI or USC yourself, on Revenue's systems or in a payroll with Irish statutory deductions? (R6)
2. Does two days a week in the Limerick office work with your commute and your notice period? (R8)
3. Have you done any pension admin, such as enrolments or contribution changes, even assisting your manager? (R7)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.