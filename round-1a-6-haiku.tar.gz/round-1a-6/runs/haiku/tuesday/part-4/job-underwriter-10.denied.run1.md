**Worth going on with the call, on conditions. Status: `conditional_go`.** I can't establish Fernquay's legitimacy from here, because web search was refused and nothing was checked, so that is unverified, not a finding against it. Nothing in these messages asks you for money, a deposit or bank details, and the interview is a video call rather than chat.

## Decision snapshot

**Fit ledger.**
- `hard_gate`: direct R1 · unclear R2 (Pay €52,000–€60,000)
- `must_have`: direct R3 (3+ years of product design), R4 (strong Figma) · adjacent R5 (own the booking flow end to end)
- `important`: direct R6 (own user research), R8 (working directly with engineers) · unclear R7 (research calls with school owners)
- `preferred`: adjacent R9 (operator-facing booking software)

R5, a bridge from squad work to sole ownership with its limit named. R7, where the method is yours and the audience is not yet shown. R2, waiting on your pay floor.

**Opportunity ledger.** Thin on verification, not on substance. RR1 (employer not established, `severity: medium`) caps the decision at `conditional_go`. RR2 (equity terms) and RR3 (pay not calibrated) are open. RR4 (scope wide for one designer) is low. RR5 is a positive signal: the posting describes the work concretely and names the interview.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay confirmed as a real hiring company, RR1; (2) your pay floor at or below €52,000, R2; (3) the call shows you owning the flow without a design lead, R5 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting, self-described; not verified |
| Footprint | You found little online | `[grounded]` your report; not checked by me |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days at the Galway office, the rest remote | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Process | 45-minute video call with Ronan and Saoirse (CTO); invite sent by email | `[grounded]` WhatsApp message |
| Market calibration | Not run. The role-family sweep needed search, which was refused. The pay band is uncalibrated | — |
| Unknowns | Company footprint, equity terms, your pay floor, research budget | — |
| Contradictions | None found between the posting and the WhatsApp message (name, role, company agree) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, stated at intake; the office days are reachable | `[grounded]` posting and intake | none |
| R2 | Base salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You have not stated a pay floor, so whether this clears your constraint is not established | `[grounded]` posting figure | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported and not inspected. Length is graded on fit, not treated as a gate | `[grounded]` intake | Share the checkout case study (A3) |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily, self-reported; the checkout case study is the likely artifact | `[grounded]` intake | A3 |
| R5 | Be the only designer and own the booking flow end to end | must_have | adjacent | medium | transferability | Redesigned a checkout flow inside a squad of four engineers. You have not been the only designer, and whether you owned the checkout calls alone is not established | `[grounded]` intake; adjacency `[inferred]` from the squad work | G1 |
| R6 | Run your own user research | important | direct | medium | none | Monthly usability sessions with customers, self-reported | `[grounded]` intake | none |
| R7 | Run research calls with school owners | important | unclear | low | discovery | Your research was with travel-booking customers. The method carries; the business-owner audience is not shown | `[inferred]` from the audience difference | G2 |
| R8 | Work directly with engineers | important | direct | medium | none | Worked in a squad with four engineers | `[grounded]` intake | none |
| R9 | Operator-facing booking software for small activity businesses | preferred | adjacent | medium | transferability | Your booking experience is consumer travel; the posting's customers are schools. Requirement inferred, not stated | `[inferred]` from "booking flow" and "school owners" | none beyond G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole ownership (R5, must_have) | transferability | Squad work and one checkout redesign; no solo design decisions shown | The main objection a first-designer hire will raise; a bridge narrows it | A flow you shaped with no design peer to check it; a call you made alone and defended | The checkout case study's decision log, or a write-up of one solo decision | `[grounded]` intake; `[generic]` that first-designer roles are judged on this |
| G2 | Research with school owners (R7, important) | discovery | Consumer research shown; no business-owner research | The posting names this audience directly | Interviews with small-business owners, trade customers or operators' staff | A research plan or notes from a study with business users | `[inferred]` from the audience gap |
| G3 | Pay against your floor (R2, hard_gate) | hard_gate | Posted range; no stated floor | The inputs don't settle whether this gate is met | None; this is your own statement | None | `[grounded]` posting figure |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price or dilution could change the equity's value; none is given | `[inferred]` from the posting's silence | What vesting schedule, strike price and share class apply? | unresolved |
| RR3 | Pay not calibrated against the market | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may sit well off what this level pays; not checked, since search was refused | `[generic]` role-family pattern, unsearched; figure `[grounded]` posting | Is this base set for the level you'd be hired at? | unresolved |
| RR4 | Scope wide for one designer | risk_signal | low | "own the booking flow end to end ... run research calls ... ship alongside our two engineers" | One person may carry design, research and delivery with no named research time or design review | `[inferred]` from the scope against the silence on resources | What research time and budget does the role get, and who reviews the design work? | unresolved |
| RR5 | Work and process described concretely | positive_signal | — | "45-minute video call with me and Saoirse, our CTO" | A named process with the CTO involved, and a specific description of the work | `[grounded]` posting and WhatsApp message | What happens after the call, and who decides? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before more time goes in, find Fernquay on its own site or careers page, and check the invite's sender domain matches it. WhatsApp for scheduling is routine | RR1 | Check is advice; `[generic]` pattern for small employers | proposed |
| A2 | Ask Ronan RR1's question on the call, word for word | RR1 | `[grounded]` register | proposed |
| A3 | Put the checkout case study forward as the artifact for R3 and R4 | R3, R4 to `high` | `[grounded]` intake | pending your approval |
| A4 | On the call, name one decision you'd own alone and how you'd check it | R5, RR4 | `[inferred]` from the sole-designer gap | proposed |
| A5 | Ask about vesting, strike price and share class before weighing the equity | RR2 | `[inferred]` from the silence | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software sea kayak surf schools"; the search was refused, so nothing returned. Would settle whether the company exists as described and whether the posting is live |
| 2. Role-family sweep | unavailable | No call sent; search was unavailable for the session. Would calibrate pay (RR3) and scope (RR4) |
| 3. Hiring manager's public footprint | unavailable | Searched "Fernquay Ronan Kehoe Galway"; refused. Would inform positioning for Ronan |

## Upgrade menu

- Allow web search and I'll run the L1 checks now: the company site and careers page (RR1), a role-family sweep for pay and scope (RR3, RR4), and Ronan's public professional footprint.
- The checkout case study, or any artifact you can inspect → R3 and R4 to `high`.
- Your pay floor → R2 closes.
- One example of a decision you made alone → G1's bridge strengthens.

If you want the full analysis kept for later, I can write it out as `tuesday-dossier.md`.

1. G3: What is the lowest base salary you'd accept, and does €52,000 clear it?
2. G1: Think of one project where you made a call with no design lead to check it. What did you decide, and what happened?
3. RR1: What domain did the invite email come from, and does it match Fernquay's own website?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.