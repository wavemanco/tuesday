## Decision snapshot

**Worth applying to, on one condition. Status: `conditional_go`.**

Yes, it looks legitimate. Fernquay's own about page and careers page both list this role, and independent search agrees on the company, its product and its founders. The WhatsApp message is ordinary scheduling for a call held elsewhere, and nothing in the posting or messages asks you for money or personal details.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (base salary €52,000–€60,000)
- `must_have`: direct: R3 (3+ years product design), R4 (strong Figma), R5 (ran your own user research), R6 (works directly with engineers)
- `important`: adjacent: R7 (research calls with school owners), R8 (own the booking flow end to end), R9 (first designer, no design peer)

R7 and R8 are the rows to check: your research and checkout work is adjacent to both, and the limits are named in the evidence map. R2 is unclear because your pay floor was not given, so the salary check has not been run.

**Opportunity ledger.** The role itself is well specified: a six-person company, two engineers, a named co-founder, and a salary that sits inside the market band (RR5). Equity terms are withheld (RR2), the CTO's title differs between sources (RR4), and a first designer with no design peer is a real fit risk (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (base salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your base-salary floor sits within €52,000–€60,000 (R2); (2) the equity terms are clear enough to weigh (RR2); (3) you are comfortable being the only designer, with the review gap in RR3 covered in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, founded 2023 | `[grounded]` fernquay.example/about, fetched |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD and careers page |
| Working pattern | Hybrid, two days a week in Galway; the rest flexible | `[grounded]` JD and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD and careers page |
| Market calibration | Product designers with 3–5 years sit around a €57,000 median base (interquartile €51,500–€62,000), so the posted range sits inside the band | `[generic]` one 2026 Ireland salary survey, n=520; `[grounded]` the posted figures |
| Unknowns | Equity vesting and strike terms; whether the CTO title is current; what design tooling and research budget exist | — |
| Contradictions | None between the JD and the careers page. The WhatsApp message calls Saoirse "CTO"; the about page names Saoirse Doyle as a co-founder. Both can be true | `[grounded]` about page and message text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | high | none | You moved back to Galway last year, a fact you stated | `[grounded]` your intake | none |
| R2 | Base salary €52,000–€60,000 (your floor, not stated) | hard_gate | unclear | none | hard_gate | No claim from you yet; the pay gate cannot be checked without your floor | `[grounded]` JD; no candidate claim | Ask Q1 in the closing block |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, stated but not inspected | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, stated | `[grounded]` your intake | none |
| R5 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated | `[grounded]` your intake | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers, stated | `[grounded]` your intake | none |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Your research was with travel customers, not small business owners in sea and surf schools. Limit: no business-buyer interviews | `[inferred]` adjacency from your usability work | Gap G2 |
| R8 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout, one stage of a booking flow. Limit: not stated as owning the whole flow | `[grounded]` your checkout case study, as described | Gap G1 |
| R9 | First designer, no design peer | important | adjacent | medium | transferability | You have never been the only designer; you have worked closely with engineers. Limit: no solo design practice yet | `[inferred]` from your squad experience | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R8) | transferability | Checkout redesign, not the whole booking flow | Owning the flow end to end is the core of the job | Deciding booking steps beyond checkout; work on availability, confirmation or payments; a decision you made about the flow as a whole | A checkout case study with the decisions you owned, and any booking-flow work beyond checkout | `[grounded]` your intake; `[inferred]` that the whole-flow scope is the gap |
| G2 | Research with school owners (R7) | transferability | Monthly usability sessions with customers, none with small business owners | Owners are the buyers; interviewing them is a stated responsibility | Interviews with small-business buyers or operators; research with resellers or suppliers | A research plan or summary from any buyer-side interviews | `[grounded]` your intake; `[inferred]` the audience gap |
| G3 | First designer, no design peer (R9) | transferability | Squad work with engineers; no sole-designer role | The company has no design review; you would set the standard alone | Work with no design review, such as a solo project; running research and critique with engineers | A project where you set design standards without a peer reviewer | `[grounded]` your intake; `[generic]` that first design hires usually set their own standards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting confirmed | positive_signal | — | "Open now: Product Designer, our first design hire" (careers page) | Posting, about page and careers page agree on role, product, location and pay | `[grounded]` careers and about pages, fetched | Who besides the two engineers would I work with day to day? | noted |
| RR2 | Equity terms withheld | unknown | — | "plus 0.5–1% equity" | Equity is part of pay, but vesting, strike price and dilution are not stated | `[inferred]` from the posting's silence on terms | What is the vesting schedule, and is the 0.5–1% options or shares? | unresolved |
| RR3 | Single designer, no design peer | risk_signal | low | "You would be our first designer" | The role may depend on setting design standards alone, with no peer review | `[generic]` pattern for first design hires at small companies, not a claim about this one | What design decisions would be mine alone, and how is design work reviewed? | unresolved |
| RR4 | Saoirse's title differs between sources | unknown | — | "Saoirse, our CTO" (message); "Saoirse Doyle" as co-founder (about page) | Both can be true; the call can settle it | `[grounded]` message text and about page | What is Saoirse's role now, and who would I work with? | unresolved |
| RR5 | Pay disclosed, within band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The posted range sits around the market median | `[grounded]` posting; `[generic]` salary survey | What is the base for this role, and where in the range is it set? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before joining the call, check the invite comes from an address at fernquay.example, the company's own domain. Apply at the careers page's address, jobs@fernquay.example | Routine scheduling by chat is fine; the domain check is advice | `[grounded]` careers page | pending your approval |
| P2 | Prepare the 45-minute call with mock-interview | The call is with the co-founder and CTO | `[grounded]` message | pending your approval |
| P3 | Lead with the checkout case study and the research sessions, and name the school-owner gap (G2) before anyone else does | R7 and R8 are the rows an interviewer will probe | `[grounded]` R5, R7, R8 rows | pending your approval |
| P4 | Ask RR2, RR3 and RR4 on the call, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row is a proposal; you decide what to act on.

## Evidence status

Verified: none yet. Every claim so far rests on your intake, which is CV-equivalent and capped at `medium` until a specific probe or an inspectable artifact confirms it. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" (returned fernquay.example/about) and "Fernquay careers product designer" (returned fernquay.example/careers/product-designer). Fetched both pages. Role reality: the company exists as described, the posting is live, and it matches the JD on pay, location and scope. Standing failed-attribution entry not needed |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Snippet only, not fetched. Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe", which returned the LinkedIn profile of Ronan Kehoe, co-founder and CEO, previously product lead at a Galway travel-software company for five years. Snippet only, not fetched. Moved the positioning read for the call |

## Upgrade menu

- Your base-salary floor → R2 closes and the gate can be called met or failed.
- The checkout case study, or a link to it → R3, R4 and R8 raise from `medium` to `high`.
- A booking-flow project beyond checkout → R8 moves from `adjacent` toward `direct`.
- Any buyer-side interview notes → R7 closes or narrows.
- The equity terms, from the company → RR2 closes.

A dossier can record all of this as `tuesday-dossier.md`, which I can produce whenever you want it.

**Questions:**

Q1 (R2): What base salary would you need to accept this role, and is that within €52,000–€60,000?

Q2 (R9): Have you ever done design work with no other designer to review it? If so, how did you get feedback on it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.