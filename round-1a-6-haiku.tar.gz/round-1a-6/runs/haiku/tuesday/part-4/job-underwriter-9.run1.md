I've already loaded the job-underwriter playbook and its reference files, so I'll go straight to the research step. Running the three L1 targets now: the employer's own site and careers page, a salary and role sweep, and the public footprint of the named manager.
**Yes, those requests are routine for an offer like this, and the offer is not a red flag. Status: `conditional_go`.** I could not check the employer itself, because my web searches were refused, so that check is still open.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (right to work in Ireland), R2 (Limerick, two days a week)
  - `must_have`: direct: R3 (2+ years running payroll), R5 (payroll qualification or working towards one), R6 (monthly payroll-to-ledger reconciliation), R7 (starters and leavers); unclear: R4 (Irish PAYE, PRSI and USC)
  - `important`: direct: R9 (strong Excel); adjacent: R8 (pension changes); unclear: R10 (answering staff payroll queries)

  R3 (`medium`): three years, fortnightly, 90 staff, self-reported and not yet inspected. R8: a bridge from payroll change processing, with the limit that you have never run pension changes.

- **Opportunity ledger.** No red flags. The ad names a specific scope, a manager and a salary inside its band, which are positive signals. The offer asks for details only after a written offer that names the role and pay, which is routine. Nothing in the material asks you to pay, deposit a cheque, or run the process only by chat.
- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (Limerick, two days a week); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you have the right to work in Ireland without sponsorship (R1); (2) the Limerick days work for you (R2); (3) you confirm the employer and the offer independently (below); (4) R4 closes, meaning your certificate or your experience covers Irish PAYE, PRSI and USC.

**Is it normal to give bank, PPS and passport details?**

Yes, after a written offer. [generic] Irish employers need a PPS number for Revenue returns, bank details to pay salary, and right-to-work evidence before someone starts. The offer follows the usual order: offer first, details later, through a portal, with the original passport checked on day one. [inferred from the offer's wording] Your rule still holds for unsolicited requests and anything before an offer.

If you accept, do this:
- Enter the details only in the portal, and reach it from the company's own website, not only from a link in the email.
- Don't send the passport, PPS or bank details by email.
- Before you send anything, phone the employer on the number from its website, ask for the People Team, and confirm the offer and the portal. Check that the sender's domain matches the website's domain.

I don't need your passport, PPS or bank details, and you shouldn't share them with me.

**Fit by requirement**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland, no sponsorship | hard_gate | unclear | none | hard_gate | Not stated; the offer's passport check tests it | `[grounded]` offer email |
| R2 | Limerick office, two days a week | hard_gate | unclear | none | hard_gate | Your location is not stated | `[grounded]` ad and offer |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years, fortnightly, 90 staff | `[grounded]` your background |
| R4 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Not stated; the certificate may cover it, unconfirmed | `[grounded]` ad; `[inferred]` on the certificate |
| R5 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background |
| R6 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done monthly in your last role | `[grounded]` your background |
| R7 | Starters and leavers | must_have | direct | medium | none | Done in your last role | `[grounded]` your background |
| R8 | Pension changes | important | adjacent | low | transferability | Bridge: payroll change processing; limit: never ran pension changes | `[inferred]` bridge; limit from you |
| R9 | Strong Excel | important | direct | medium | none | Daily: pivot tables, XLOOKUP | `[grounded]` your background |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` ad |

The ad covers 240 staff and your experience is 90. That is a step up in volume, not a listed requirement, so it is not a row.

**Research**

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by a permission setting, so nothing came back. Would have checked that the employer exists, the posting is live, and the email domain matches. |
| 2. Role-family sweep | unavailable | One search was refused. Would have set the €38–42k band against role-family norms. |
| 3. Hiring manager's public footprint | unavailable | One search was refused. Would have checked Declan Garvagh's public role. |

Because of this, the standing check on whether the employer is real has not been run. It is neither confirmed nor flagged.

**Upgrade menu**
- Your right-to-work position: closes R1, the largest unknown.
- Your Limerick commute: closes R2.
- The syllabus from your payroll certificate, or a short note on Irish PAYE, PRSI and USC use: moves R4 toward direct.
- One small pension-change example: moves R8 up from low confidence.
- Permission to retry web search: lets me check the employer, its domain, the live posting, the salary band and Declan Garvagh's role.

I can also save this assessment as a `tuesday-dossier.md` file if you'd like a record.

Three questions:

- R1: Do you have the right to work in Ireland, with no sponsorship needed?
- R2: Can you do two days a week in the Limerick office from where you live?
- R4: Did your Payroll Technician certificate cover Irish PAYE, PRSI and USC, or have you used them in a job?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.