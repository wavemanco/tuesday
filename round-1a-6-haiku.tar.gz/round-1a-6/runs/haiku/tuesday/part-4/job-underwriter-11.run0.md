**Short answer:** Duinvaart is worth applying to. Kroonhaven is not, for now.

I ran this at L0, with no web research, so both postings are read from your text only. I used the Tuesday job-underwriter method, which holds each role's fit and its own risks on separate ledgers.

## 1. Duinvaart Cold Chain, Operations Analyst (Rotterdam)

**Decision snapshot**

Yes, worth your time. `conditional_go`, on one condition: that the three-days-a-week Rotterdam schedule works for you.

**Fit ledger.**

- `hard_gate`: unclear: R1 (hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: R2 (2+ years in logistics or operations analysis), R3 (strong SQL), R4 (Power BI or Tableau)
- `important`: direct: R5 (weekly Power BI dashboards), R6 (working with depot managers on route changes), R7 (on-time delivery tracking); unclear: R8 (temperature compliance across the refrigerated fleet)
- `preferred`: adjacent: R9 (Dutch, a plus; "conversational" is the limit)

R5, R6 and R7 read from your parcel-carrier dashboard and route review. R8 is the one responsibility with no evidence behind it.

**Opportunity ledger.** The posting is ordinary and specific. It names a measurable scope (DR3, positive). Salary and contract type are not stated (DR1, DR2, unknowns). I found no red flags in the text.

- **Hard gates:** none failed; unconfirmed: R1 (hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 confirmed: you can commit to three days a week in Rotterdam; (2) DR1 and DR2 answered in the first call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | One analyst with dashboards and depot-facing work; ordinary for the title | `[inferred]` from the listed duties |
| Market calibration | Not run at L0 | — |
| Unknowns | Salary, contract type, team size, whether temperature data already exists | — |
| Contradictions | None visible in the posting | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week, Rotterdam office | hard_gate | unclear | none | hard_gate | Your home location and schedule limits were not given | `[grounded]` JD; no candidate statement | Q1 |
| R2 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier (your statement) | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL used daily (your statement) | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily (your statement) | `[grounded]` your background | none |
| R5 | Weekly Power BI dashboards | important | direct | medium | presentation | You built or ran the on-time dashboard depot managers use; the weekly cadence isn't stated | `[grounded]` your background | A1 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R7 | On-time delivery tracking | important | direct | medium | none | The on-time delivery dashboard is yours | `[grounded]` your background | none |
| R8 | Temperature compliance, refrigerated fleet | important | unclear | none | discovery | Nothing in your background touches temperature or cold chain | `[grounded]` CV silence; `[generic]` parcel networks often don't track temperature | G1 |
| R9 | Dutch (a plus) | preferred | adjacent | medium | transferability | "Conversational, not fluent" (your statement); the posting asks for it as a plus | `[grounded]` your statement | A2 |

**Gap recovery queue** (rows only; the question for each is in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R8, important) | discovery | No condition or threshold work in your background | It is the first responsibility the posting names | Any role where you tracked thresholds, alarms or condition data, even outside logistics | A report or dashboard with thresholds | `[grounded]` CV silence |
| G2 | Dutch (R9, preferred) | transferability | Conversational, not fluent | Limit: don't present it as working Dutch | A Dutch-language report or meeting you ran, if any | One example | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Salary not stated | unknown | — | (no salary given) | May be withheld | `[grounded]` JD silence | What is the salary range for this role? | unresolved |
| DR2 | Contract type not stated | unknown | — | (no contract type given) | Could be fixed-term | `[grounded]` JD silence | Is this role permanent? | unresolved |
| DR3 | Defined, measurable scope | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Scope is concrete | `[grounded]` JD | How is temperature compliance measured today, and where does that data sit? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the on-time dashboard depot managers use and the weekly route-performance review. Edits table: `resume_edits_pending_approval` | R5, R6, R7 | `[grounded]` your CV sentences | pending your approval |
| A2 | Say "conversational Dutch," never fluent. Don't add cold-chain or temperature work you haven't described | R9, R8 | `[grounded]` your statements | pending your approval |
| A3 | Ask DR1, DR2 and DR3 verbatim in the first call | The register doubles as interview prep | `[grounded]` the register | pending your approval |

## 2. Kroonhaven Foods, Supply Planner (Utrecht)

**Decision snapshot**

No, not worth applying to now. R2 (3+ years of FMCG planning) and R3 (fluent Dutch) are both must-haves you don't meet, and neither closes within this posting's reach. `no_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: absent: R2 (3+ years supply or demand planning in FMCG), R3 (fluent Dutch); unclear: R6 (advanced Excel), R7 (SAP IBP or a similar planning system)
- `important`: adjacent: R4 (running the weekly S&OP meeting); unclear: R5 (13-week plan, balancing capacity against forecast)
- `preferred`: none listed

R4 is the closest match, via your weekly route review. R2 and R3 are absent, and your own statement rules out planning experience.

**Opportunity ledger.** The posting is clear and defined: a 13-week scope and a named weekly meeting (KR3, positive). Salary and contract type are not stated (KR1, KR2, unknowns). No red flags in the text.

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** R2 and R3 would both have to be different: several years of FMCG planning, and fluent Dutch.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Working pattern | On-site, Utrecht | `[grounded]` JD |
| Scope read | An owner-level role for one range; normal for the title | `[inferred]` from the listed duties |
| Market calibration | Not run at L0 | — |
| Unknowns | Salary, contract type, planning systems in use | — |
| Contradictions | None visible | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site, Utrecht | hard_gate | unclear | none | hard_gate | Your home location was not given | `[grounded]` JD | Q1 |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning, and have no FMCG work (your statement) | `[grounded]` your statement | KG1 |
| K3 | Fluent Dutch | must_have | absent | medium | capability | "Conversational, not fluent" is below the stated bar (your statement) | `[grounded]` your statement | KG2 |
| K4 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review; no supply-demand decisions are in your background | `[grounded]` your background | KG3 |
| K5 | Own the 13-week plan; balance capacity against forecast | important | unclear | none | discovery | Nothing in your background either way | `[grounded]` CV silence | Q3 |
| K6 | Advanced Excel | must_have | unclear | none | discovery | Not mentioned | `[grounded]` CV silence | Upgrade menu |
| K7 | SAP IBP or similar planning system | must_have | unclear | none | discovery | Not mentioned | `[grounded]` CV silence | Upgrade menu |

**Gap recovery queue** (rows only)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| KG1 | FMCG planning (K2, must_have) | capability | No planning or FMCG work | Years of planning are the stated bar | Planning roles, even in a related function | Not closable by this posting | `[grounded]` your statement |
| KG2 | Fluent Dutch (K3, must_have) | capability | Conversational | The bar is fluency now | Sustained Dutch-language work | A Dutch-language artifact, if one exists | `[grounded]` your statement |
| KG3 | S&OP (K4, important) | transferability | Weekly performance review | Limit: a review, not balancing supply and demand | One planning-adjacent artifact | A forecast or capacity sheet, if one exists | `[grounded]` your background |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Salary not stated | unknown | — | (no salary given) | May be withheld | `[grounded]` JD silence | What salary is budgeted for this role? | unresolved |
| KR2 | Contract type not stated | unknown | — | (no contract type given) | Could be fixed-term | `[grounded]` JD silence | Is this role permanent? | unresolved |
| KR3 | Defined scope with a named weekly forum | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | Scope is concrete | `[grounded]` JD | Who sets the forecast that the plan balances against? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| KA1 | Skip this one for now. Put the effort into operations-analysis roles, and into planning roles only once you have planning evidence | K2, K3 | `[inferred]` from the must-have rows | recommendation |

## 3. Shared

**Evidence status.** Verified: none yet. Unverified: all claims are your own statements.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it would have moved |
|---|---|---|
| 1. Official site and careers page | unavailable | Confirms both employers exist and both postings are live |
| 2. Role-family sweep | unavailable | Market band for both titles (DR1, KR1) |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer.** I can save this as `tuesday-dossier.md` so the Duinvaart register can feed interview prep later.

**Upgrade menu**

- Research at L1 (up to 5 searches and 2 fetches): confirms both employers and postings are live, and sets salary bands for both titles.
- Salary and contract type for either posting (DR1, DR2, KR1, KR2): closes the unknowns.
- A sanitized screenshot of the on-time dashboard, or a route-review summary: raises R5 and R7 to `high`.
- Excel and SAP IBP depth (K6, K7): the Kroonhaven rows stay open until you tell me.

**Questions**

- **Q1 (R1, Duinvaart; K1, Kroonhaven):** Where do you live, and can you commit to three days a week in Rotterdam, or to on-site in Utrecht?
- **Q2 (G1, R8, Duinvaart):** Have you tracked temperature or other condition data, with thresholds, in any role?
- **Q3 (K5, Kroonhaven):** Have you ever forecast volumes or planned capacity, such as peak planning or depot throughput, and in which tools?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.