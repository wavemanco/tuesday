**Yes, it's worth applying for, on the conditions below.** Status: `conditional_go`. Your core clinical skills match the role, and the gaps are the caseload and a few named care areas.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4
- `important`: direct: R5, R7, R8 · adjacent: R6, R12 · unclear: R9, R10, R11, R13
- `preferred`: absent: R14

R1 and R2 are your registration and licence, both stated on your CV and both checkable by you. R3 is five years as a staff nurse. R4 (clear, timely written records) is the must-have with no evidence yet. R12 is a bridge: discharge-to-assess home visits, with the limit that you have never held a caseload. R14 (Doppler) is a capability gap, but it is preferred, not essential.

**Opportunity ledger.** The posting is credible at employer level: Calderbrook is a CIC running adult community nursing under an NHS contract, with 410 staff (RR1 is the open item, since the careers page would not load). The posted pay range is wide and its bottom end sits below the survey's interquartile range (RR2). Nothing in the posting asks anything of you that needs a warning (no payment, deposit or bank details).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live on Calderbrook's own careers site (RR1); (2) written-records expectations are confirmed with your NMC and CV evidence (R4); (3) the caseload bridge is described as adjacent, not as caseload experience (R12).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Calderdale; adult community nursing under an NHS contract; 410 staff across four hubs | `[grounded]` organization's about page (search snippet) |
| Role | District nursing caseload, housebound adults at home; small caseload with senior nurse support | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` posting |
| Pay calibration | Survey median £34,300, interquartile range £32,400–£36,600 (England, 2026, n=1,240); 61% of respondents paid mileage | `[generic]` role-family pay survey; the range is not this employer's offer |
| Unknowns | Whether the role is live; Agenda for Change terms (the posting says "Band 5" but a CIC sets its own pay); whether Doppler training is provided; records expectations | — |
| Contradictions | None found between the posting and the organization's about page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated on CV; registration is a credential, so the register entry is yours to check | `[grounded]` CV | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as full, category B; checking is yours | `[grounded]` CV | Confirm on your licence |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on records | `[grounded]` CV silence | Q G3 |
| R5 | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | low | transferability | General wound care is stated; leg ulcers are not | `[inferred]` from R5 | Describe any leg-ulcer exposure |
| R7 | Catheter care | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Insulin administration | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Q G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Q G2 |
| R11 | Care planning | important | unclear | low | discovery | Discharge work plausibly involves it; CV doesn't say | `[grounded]` CV silence | Q G2 |
| R12 | Own caseload, supported by a senior nurse | important | adjacent | medium | transferability | 18 months of home visits in the first week after discharge; limit: never held a caseload | `[inferred]` bridge from the discharge-to-assess role | Q G1 |
| R13 | Electronic patient record | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | Ask what EPR experience you have |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence | `[grounded]` CV | Closure path: training (see RR4) |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Closing path |
|---|---|---|---|---|---|
| G1 | Own caseload (R12) | transferability | Home visits and first-week follow-up on discharge; no ongoing caseload | The role's central feature; the main interview probe | Any ongoing follow-up you owned, even partly |
| G2 | Continence, end-of-life, care planning (R9–R11) | discovery | Not on your CV | Core to housebound care | Examples from home visits |
| G3 | Written records (R4) | discovery | Not on your CV | Essential | Audit, feedback, or a record you can describe |
| G4 | Doppler (R14) | capability | None | Preferred only | Training from the employer, or a course |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live on employer's site not confirmed | unknown | — | "Current vacancies are listed on our careers page" | The post may be stale, or the advert may be aggregated | `[generic]` pattern for listings | Is this post currently open on your careers site? | unresolved |
| RR2 | Pay range wide; bottom below survey interquartile range | unknown | — | "£31,050–£37,800 a year plus mileage" | Offer may sit at the bottom of the range for a new caseload | `[grounded]` posting; `[generic]` survey | Where in this range would a new-to-caseload appointment sit? | unresolved |
| RR3 | Pay terms unstated (Band 5 label; CIC) | unknown | — | "Community Staff Nurse, Band 5" | Agenda for Change terms may not apply | `[inferred]` from "Band 5" against a CIC | Are these posts on Agenda for Change terms? | unresolved |
| RR4 | Doppler training may be available | positive_signal | — | Team Lead's 2025 talk on "Doppler training for staff new to community work" | Training may be offered to nurses new to community work | `[inferred]` from a conference talk; not confirmed for this post | Is Doppler training provided for nurses new to community work, and is it funded? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Add a line to your CV: "Seconded 18 months to discharge-to-assess team: home visits to patients in the first week after discharge." Keep "never held a caseload" for interview answers, not the CV | Caseload bridge (R12) | `[grounded]` your CV wording; no added scope | pending your approval |
| A1 | Check your NMC register entry and licence | R1, R2 | `[grounded]` CV | your action |
| A2 | Confirm the post on the employer's careers site before applying | RR1 | `[grounded]` RR1 | your action |
| A3 | Prepare a plain answer on the caseload limit | R12 | `[grounded]` R12 | pending your approval |

**Evidence status**

Verified: none yet. Everything so far is CV-based.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "…community staff nurse careers"; the about page (calderbrookhealth.example/about) confirmed the CIC and NHS-contract details. Fetched calderbrookhealth.example/careers: no page found, so the posting remains unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 salary UK district nursing 2026"; the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide) gave the median and interquartile range (`[generic]`, RR2) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; the communitynursingforum.example speaker page confirmed the role and the 2025 Doppler talk (RR4) |

**Upgrade menu**

- A link to the live post, or the careers-site listing → RR1 closes.
- Your NMC register entry, or a copy of it → R1 moves to `high`.
- Any written-records artifact (audit, feedback) → R4 moves from `unclear`.
- Any ongoing follow-up you owned → R12 moves to `high`.
- A budgeted salary point → RR2 closes.
- Deeper research on Calderbrook (up to 5 more searches and 2 more fetches): say the word and I'll run it.

If you want, I can write this up as `tuesday-dossier.md` to keep alongside your other prep.

**Questions**

G1 (R12): Did any of your 18 months in discharge-to-assess involve ongoing follow-up of a patient, or were visits single assessments? If there was follow-up, what did you own, and for how long?

G2 (R9–R11): Have you carried out continence assessments or end-of-life visits at home, and what did they involve?

G3 (R4): Where can you show timely written records, such as an audit, feedback from a senior, or a record you can describe?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.