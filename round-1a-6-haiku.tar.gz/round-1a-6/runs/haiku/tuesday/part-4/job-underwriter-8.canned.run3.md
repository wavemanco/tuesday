**Decision: `no_go`. Don't go ahead, and send nothing yet.** You asked whether to go ahead, and the answer is no: the messages ask you to pay for equipment, deposit a cheque, and give bank and ID details before any offer.

**Hard gates:** none failed, but your €30,000 floor is unchecked. The posting gives "up to €26 an hour plus commission" for 15–30 hours a week. At that rate the base pay is about €20,300 to €40,600 a year `[inferred]` from the posting's own figures, before commission, so the floor is only reached at the top of the hours range.

**Fit ledger (your side, `[grounded]` from your message):**

- `must_have`: customer-service ticket work (3 years, about 60 tickets a day in Zendesk) is `adjacent`; spreadsheet tracking (Excel) is `direct` at `medium`, since it's your own statement; training two new starters is `direct` at `medium`.
- `must_have`: written English and a quiet workspace are `unclear`, because nothing you've shared settles them.

Your background fits the role well enough. The problem is the opportunity.

**Opportunity ledger:**

- **RR1, `red_flag`, `severity: high`, `confirmed`.** Quote: "pay €349 by bank transfer to our equipment partner." Employers don't ask new hires to pay for their own equipment. **Hold: pay nothing.** Verification question, asked of the employer through contact details on its own website: "Do you ask new hires to pay for equipment before starting?"
- **RR2, `red_flag`, `severity: high`, `confirmed`.** Quote: "we are posting you a cheque for €2,850 … transfer the rest to our equipment partner." This request is very likely a scam. **Don't deposit the cheque.** Verification question, asked of the employer through its own site: "Do you send new starters cheques to deposit and forward money to a third party?"
- **RR3, `red_flag`, `severity: high`, `confirmed`.** Quote: "before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport." This asks for bank and ID details before any offer. **Don't send them.** Verification question: "Do you collect bank, PPS or passport details before a written offer?" I haven't used or repeated your IBAN, and I don't need your ID.
- **RR4, `red_flag`, `severity: high`.** Quote: "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Interviews and the offer happen only in chat, which leaves the process unverifiable. No verdict here, only the sign. Verification question: "Can you point me to the live role on your careers page, and who would I interview with?"
- **Standing entry, `risk_signal`, `severity: medium`, `unresolved`.** Employer not established. My two searches for "Velloway Logistics" (company careers, and the role title) returned no results. That's `[generic]` for a thin footprint, not a finding about this firm. The possibilities are side by side: too new or small, a stale or aggregated posting, or not a real hiring employer.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan (all proposed, none done):**

1. Don't reply with details, don't pay, don't deposit the cheque.
2. Check the employer yourself: find its contact details on its own website, not in the Telegram chat or the email the messages gave you. The email domain (postmail.example) isn't one I can connect to an employer's own site.
3. If you want, report the posting to the jobs site where you found it.
4. Your next applications are better spent on roles where the first contact is a named employer with a verifiable careers page. Your Zendesk, tracker and training experience fits those well.

**Research tier:** L1, searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics company careers" and "Velloway Logistics remote order processing coordinator"; both returned no results. Employer not established (standing entry) |
| 2. Role-family sweep | skipped | The decision is already set by the requests in hand, so a pay band can't change it; no pay band is given |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can save this analysis as `tuesday-dossier.md` if you want it on file.

**Upgrade menu:**

- A link to the live posting or the employer's own careers page → the standing entry can be checked, and the decision could move to `conditional_go` only if the employer verifies and the requests are withdrawn.
- A written offer from a verified employer that names the role and pay → RR3's bank and ID details become routine onboarding.

**Questions:**

- Does a careers page on the employer's own website list this role? If so, paste the link.
- Has anyone interviewed you by phone or video, or met you in person? Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.