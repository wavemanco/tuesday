**Yes, it's worth applying for, on two checks first.** Status: `conditional_go`. You meet all three essential gates on your own statement, and the role lines up well with your discharge-to-assess work. The two checks are that the post is live on the employer's careers page and that your NMC and licence details match the registers. Neither check has been run yet.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R6, R8, R10 · adjacent: R5 (home visits to housebound adults), R7 (leg-ulcer care), R11 (care planning) · unclear: R9 (continence care), R14 (clear, timely written records)
- `important`: adjacent: R13 (own caseload) · unclear: R12 (end-of-life visits)
- `preferred`: absent: R15 (Doppler assessment)

R5, R7 and R11 are credible bridges with their limits named. R9, R12 and R14 are unevidenced, so each needs one question. R15 is absent, but it is preferred only.

**Opportunity ledger.** The employer is real and the salary is published: RR3 is positive. The posting itself is not yet confirmed live (RR1). Caseload size and out-of-hours cover are unstated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`). Constraints you haven't given me, such as a pay floor, schedule or contract type, are unchecked.
- **Severe red flags:** none found. Nothing in the posting asks you for money or bank details.
- **Conditions for go:** (1) the post appears on the employer's own careers page (RR1); (2) the NMC register matches R1 as you stated it.
- **What would change this:** an inactive NMC registration would make R1 a failed gate and the status `no_go`.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` employer's About page, fetched |
| Mandate | Home-based district nursing for housebound adults; a small caseload, supported by a senior community nurse | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Self-reported 2026 survey of community staff nurses, Band 5 (n=1,240): median £34,300, interquartile range £32,400–£36,600. The posted range spans that interquartile range. This is a pattern, not this employer's offer; I did not check the official NHS pay scale | `[generic]` survey (wardround.example) |
| Unknowns | Caseload size; on-call or out-of-hours cover; shift pattern; whether Doppler training is provided | — |
| Contradictions | None found. The careers page was not reached | — |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team. She has a public talk (2025 forum) on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (communitynursingforum.example) |

**Evidence map.** Your claims are your own statement, so every confidence band is capped at `medium`. Nothing is inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated active, revalidation March 2028. The registration is yours to check | Check the NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated category B. Not inspected | Check your licence record |
| R3 | Work in Halifax (posting location) | hard_gate | direct | medium | none | Stated you live in Halifax | none |
| R4 | At least 1 year post-registration | must_have | direct | medium | none | Five years on an acute medical ward | none |
| R5 | Home visits to housebound adults | must_have | adjacent | medium | transferability | Home visits in the first week after discharge. Limit: no ongoing caseload visits | Bridge case (see G1) |
| R6 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | none |
| R7 | Leg-ulcer care | must_have | adjacent | medium | transferability | General wound care only; no leg ulcers named | Bridge case (see G2) |
| R8 | Catheter care | must_have | direct | medium | none | Stated | none |
| R9 | Continence care | must_have | unclear | low | discovery | Not mentioned | Ask (Q3) |
| R10 | Insulin administration | must_have | direct | medium | none | Stated | none |
| R11 | Care planning | must_have | adjacent | medium | transferability | Discharge assessment and planning. Limit: no long-term care plans named | Bridge case (see G1) |
| R12 | End-of-life visits | important | unclear | low | discovery | Not mentioned | Ask (Q2) |
| R13 | Own caseload | important | adjacent | medium | transferability | You have never held your own caseload; the discharge visits are the nearest thing | Bridge case (see G1) |
| R14 | Clear, timely written records (EPR) | must_have | unclear | low | discovery | Records not mentioned; no EPR system named | Ask for the EPR system in an informal chat |
| R15 | Doppler assessment | preferred | absent | medium | capability | You have never done one (your own statement) | Closure path: a Doppler course (see G6) |

**Gap recovery queue.** No questions here; the questions are in the closing block, tagged by row.

| # | Gap | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Own caseload (R13, R5, R11) | transferability | Discharge-to-assess visits, planned and followed up by you in the first week | A count of visits you planned and followed up yourself | `[grounded]` CV; `[inferred]` the bridge |
| G2 | Leg-ulcer care (R7) | transferability | Wound care in general, no leg ulcers named | Any leg-ulcer work, even under supervision | `[grounded]` CV |
| G3 | Continence (R9) | discovery | Not in the CV | Q3 | `[grounded]` CV silence |
| G4 | End-of-life (R12) | discovery | Not in the CV | Q2 | `[grounded]` CV silence |
| G5 | Written records (R14) | discovery | Not stated | Which EPR system you used | `[grounded]` CV silence |
| G6 | Doppler (R15) | capability | Never done, your own statement | A course, or a placement with Doppler training | `[grounded]` your statement |

**Opportunity risk register.**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | The post may be filled, or only listed on an aggregator | `[generic]` pattern for postings of this kind | Is this post live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Caseload size and out-of-hours cover unstated | unknown | — | "Small caseload" could mean very different things; on-call could be heavy | `[inferred]` from "small caseload" against silence on cover | What size is a typical caseload here, and what on-call or out-of-hours cover does the role carry? | unresolved |
| RR3 | Pay and mileage stated | positive_signal | — | Transparent pay in the survey's interquartile range | `[grounded]` JD; `[generic]` survey comparison | Where in £31,050–£37,800 would a new Band 5 start, and how is mileage paid? | noted |
| RR4 | Doppler provision for new community staff | positive_signal | — | Training may exist, since the team lead has spoken on it publicly | `[grounded]` forum speaker page; `[inferred]` that it applies here | Is Doppler training provided for staff who have not done one? | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Frame the discharge-to-assess home visits as adjacent to caseload work, naming the limit (no ongoing caseload) | see R5, R13 | `[grounded]` CV | pending your approval |
| E2 | Say you are learning leg-ulcer care and Doppler; claim neither as experience | see R7, R15 | `[grounded]` CV | pending your approval |
| A1 | Check the posting on the employer's careers page | see RR1 | `[grounded]` | pending your approval |
| A2 | Check your NMC register entry matches what you stated | see R1 | `[grounded]` | pending your approval |
| A3 | Ask Rhiannon Mabbott RR2 and RR4 at the informal chat | the posting invites the chat | `[grounded]` JD | pending your approval |

If you want to rehearse for that chat, mock-interview can build a prep pack for it.

**Evidence status.** Verified: none yet. Every claim above is your own statement, not yet probed.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "calderbrookhealth careers vacancies community staff nurse"; fetched calderbrookhealth.example/about. The employer exists as described. The careers page address was not given, so the posting is unverified live (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 pay scale 2026/27 annual salary", which returned the Wardround 2026 community nursing pay guide. Market calibration `[generic]`; the official pay scale is unchecked |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the forum speaker page (communitynursingforum.example). Role reality and the chat's positioning |

I'd like to keep this as a file. Want me to write it up as `tuesday-dossier.md`?

**Upgrade menu.**
- The careers-page link for the post → RR1 closes
- A printout or screenshot of your NMC register entry → R1 to `high`
- A licence record check → R2 to `high`
- A count of discharge visits you planned and followed up yourself → R13 strengthens
- Caseload size and out-of-hours detail from the employer → RR2 closes
- The official NHS Band 5 pay point → the market calibration is confirmed or corrected
- A Doppler or leg-ulcer training record → R7 and R15 move

**Questions.**
- R13: How many home visits did you plan and follow up yourself in a typical week in discharge-to-assess?
- R12: Have you made end-of-life visits at home, and what did they involve?
- R9: Have you assessed or managed continence care, and what did that involve?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.