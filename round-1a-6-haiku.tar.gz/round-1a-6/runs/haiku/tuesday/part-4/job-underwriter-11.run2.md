**Duinvaart (Operations Analyst): apply, `conditional_go`. Kroonhaven (Supply Planner): don't apply now, `no_go`.**

**Fit ledger, Duinvaart**
- `hard_gate`: unclear: A1 (hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: A2 (2+ years logistics or operations analysis), A3 (strong SQL), A4 (Power BI or Tableau); unclear: A6 (temperature compliance across the refrigerated fleet)
- `important`: direct: A5 (on-time delivery tracking), A7 (route changes with depot managers)
- `preferred`: adjacent: A8 (Dutch)

A2, A3, A4, A5 and A7 are your strongest ground. A6 is new to you, and A1 stays open until you tell me where you live.

**Fit ledger, Kroonhaven**
- `hard_gate`: unclear: K1 (on-site in Utrecht)
- `must_have`: adjacent: K2 (3+ years of FMCG planning); unclear: K3 (advanced Excel); absent: K4 (SAP IBP or a similar planning system), K5 (fluent Dutch)

K4 and K5 have no evidence behind them. K2 is adjacent only: you have reviewed route performance, but you have not forecast, balanced capacity or run S&OP.

- **Hard gates, Duinvaart:** none failed; unconfirmed: A1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Hard gates, Kroonhaven:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found, in either posting.

Neither posting asks you for money, a deposit or personal details.

**Role reality**
- Duinvaart: a delivery-performance and dashboard role over a refrigerated fleet, with route changes made alongside depot managers. `[grounded]` JD. Whether the role owns those route decisions is unknown (RR2).
- Kroonhaven: owns a 13-week plan for chilled ready meals, balances capacity against forecast, and runs S&OP. `[grounded]` JD. The posting is Dutch-language-heavy and has no salary. Withheld pay is `[grounded]` from the posting, and any band would be `[generic]`.
- Market calibration: not run. Web search was refused this session (see Evidence status).

**Evidence map, key rows**

| # | Requirement | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|
| A2 | 2+ years logistics or ops analysis | direct | medium | none | Four years at a parcel carrier. Self-reported, no artifact yet | `[grounded]` background |
| A5 | On-time delivery tracking | direct | medium | presentation | You built the depot on-time dashboard. Parcel, not refrigerated; say so | `[grounded]` background |
| A6 | Temperature compliance | unclear | low | discovery | Nothing in your background either way. Ask | `[grounded]` silence in background |
| K2 | 3+ years FMCG planning | adjacent | medium | transferability | Route-performance review is adjacent. No forecasting, capacity or S&OP | `[inferred]` from your route review |
| K4 | SAP IBP or similar | absent | none | capability | No planning-system use recorded | `[grounded]` background |
| K5 | Fluent Dutch | absent | medium | capability | You describe your Dutch as conversational | `[grounded]` your own statement |

**Gap recovery queue**
- A6 (`discovery`): you may have temperature or cold-chain data exposure. A question follows.
- K2 and K4 (`transferability`, `capability`): the planning core is untested. Closing it takes years, not a course.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | unknown | — | "Operations Analyst — Duinvaart Cold Chain" | Web check did not run; the employer and posting are unconfirmed, not failed | `[generic]` pattern; no entity claim | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Route-change authority | unknown | — | "work with depot managers on route changes" | The role may recommend route changes rather than decide them | `[inferred]` from the verb "work with" | Does this role decide route changes, or recommend them to depot managers? | unresolved |
| RR3 | Temperature scope | unknown | — | "track … temperature compliance across our refrigerated fleet" | You may own temperature reporting from day one, in a domain you have not worked in | `[inferred]` from the responsibility and your background | What temperature data does the team already track, and who answers for a breach? | unresolved |
| RR4 | Specific deliverables | positive_signal | — | "build weekly dashboards in Power BI" | Concrete, measurable work. Scope is clear | `[grounded]` JD | Which dashboards exist today, and which are new? | noted |

Kroonhaven has no register entries beyond the same employer-not-verified status as RR1.

**Application plan**
1. **Duinvaart: apply once RR1 clears.** Confirm the posting on the employer's own careers site before you spend effort. `[grounded]` RR1.
2. **Lead with the on-time dashboard and the route review** in your CV. Frame them as delivery performance, not as cold-chain work. Any CV wording needs your approval before it is used. `[grounded]` A2, A5, A7.
3. **Name the temperature gap yourself in the interview**, and give a closure path, such as learning temperature logging. Do not claim cold-chain experience you do not have. `[grounded]` A6.
4. **Kroonhaven: do not apply now.** Put the effort into delivery or ops analyst roles. `[inferred]` from K4 and K5. This is a `no_go` on current evidence, not a hard gate.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused by the session's permission setting, so I did not retry. Would have moved RR1: whether both employers exist and whether each posting is live |
| 2. Role-family sweep | unavailable | Searches "supply planner FMCG Netherlands salary S&OP 13-week" and "operations analyst cold chain logistics Netherlands salary Power BI" were refused. Would have set the market calibration for both titles |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Both employers are therefore unverified, not failed. Duinvaart stays at `conditional_go` for that reason.

**Decision and what would change it**
- **Duinvaart, `conditional_go`:** (1) A1 holds, meaning you can commute to Rotterdam three days a week; (2) RR1 clears on the employer's own site; (3) RR2 and RR3 do not come back as blockers. If A1 fails, this becomes `no_go`.
- **Kroonhaven, `no_go`:** the facts that would have to differ are three or more years of planning experience, or fluent Dutch. Neither is likely to change before you need the job.

I can save this analysis as `tuesday-dossier.md` so later turns build on it. Say the word and I'll emit it.

**Upgrade menu**
- Your city of residence, or your commute preference → resolves A1 and the Duinvaart gate.
- Any temperature-log, cold-chain or compliance-reporting exposure, even from side work → A6 moves from unclear.
- How you would rate your Excel, with an example → K3 closes.
- A link to the live Duinvaart posting and its careers page → RR1 closes.
- Permission to run web search this session → the research rows above run, and RR1 and the market calibration get real sources.

**Questions**
1. A1: Where do you live, and could you work three days a week in Rotterdam?
2. A6: Have you ever worked with temperature data, such as logs, excursions or compliance reports, even alongside parcel work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.