**Yes, that request is routine.** [generic] After a written offer, Irish employers normally collect bank details for salary, a PPS number for Revenue, and a right-to-work check, which is the passport copy plus the original on day one. What you were told never to hand over is those details before an offer, or to someone you can't verify. Here the offer names the role and the salary, and it follows two in-person interviews at their office. The thing to protect is where you type the details, not whether you give them.

**Decision: `conditional_go`.** Accept if Marrowgate checks out on its own website, and enter details only through its portal.

**Fit ledger.**

- `hard_gate`: unclear: R1 (right to work in Ireland), R2 (Limerick office, two days a week), R3 (salary against your floor)
- `must_have`: direct: R4 (2+ years running payroll), R6 (strong Excel), R7 (payroll qualification); unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R8 (starters and leavers), R10 (monthly reconciliation to the ledger); adjacent: R9 (pension changes); unclear: R11 (staff payroll queries)

R5 is the must-have not yet shown. R9 is adjacent only, and R11 is not yet shown.

**Opportunity ledger.** The posting and the offer agree on title, pay (mid-band) and hybrid pattern, and the in-person interviews are a positive signal (RR2). Open: the employer is not established from attributable sources in this run (RR1), because the web searches were refused.

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (Limerick office, two days a week), R3 (salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm the vacancy and the employer on Marrowgate's own website before replying or entering anything (RR1); (2) your PAYE, PRSI and USC working knowledge (R5) holds up when you check it against this job's payroll work.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | [grounded] job ad |
| Scope | Monthly payroll for 240 staff, starters and leavers, pension changes, ledger reconciliation, staff queries | [grounded] job ad |
| Pay | €40,000 offered; posted band €38,000–€42,000 | [grounded] offer and ad |
| Market calibration | Not run; the search was refused, so the only band is the posted one | — |
| Contradictions | None between the ad and the offer | [grounded] both documents |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | Nothing you've stated settles it | [inferred] from the offer's right-to-work step | Q2 |
| R2 | Limerick office, two days a week | hard_gate | unclear | none | hard_gate | Your commute isn't stated | [grounded] job ad | Q2 |
| R3 | Salary | hard_gate | unclear | none | hard_gate | Offer is mid-band; your pay floor isn't stated | [grounded] offer and ad | Q2 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; self-reported | [grounded] your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not named in your background | [inferred] | Q1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP; self-reported | [grounded] your background | none |
| R7 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024; a copy would raise this to high | [grounded] your background | none |
| R8 | Starters and leavers | important | direct | medium | none | Three years' experience | [grounded] your background | none |
| R9 | Pension changes | important | adjacent | low | transferability | You have not processed them; your manager did. Limit: no pension-change experience of your own | [inferred] | Q3 |
| R10 | Monthly reconciliation to the general ledger | important | direct | medium | none | Monthly payroll-to-ledger reconciliation for three years | [grounded] your background | none |
| R11 | Staff payroll queries | important | unclear | low | discovery | Not named in your background | [inferred] | Carried to the upgrade menu |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it |
|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R5) | discovery | Not stated, though hotel payroll likely touched these | An example from your hotel payroll: a USC or PRSI calculation, a year-end return |
| G2 | Pension changes (R9) | transferability | Watched, not processed | Any pension-related task you did, even alongside your manager |
| G3 | Staff queries (R11) | discovery | Not stated | Whether you answered staff payroll questions at the hotel group |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | [generic] pattern for companies of this size, not a claim about this one | Can you point me to this vacancy on Marrowgate's own careers page, and confirm the domain your offer and portal come from? | unresolved |
| RR2 | Two in-person interviews at their office, then a written offer naming role and pay | positive_signal | — | "two in-person interviews at their office" | Consistent with a real hiring process at a known address | [grounded] your account | Which payroll system do you run, and is pension administration in-house or with a provider? | noted |

Routine steps (the bank, PPS and passport requests) take no register entry.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Type Marrowgate's web address yourself, not from the email. Confirm this vacancy is listed on its careers page | RR1 | [generic] standard verification | your action |
| A2 | Before entering anything, check the portal link's domain matches that website. Don't enter details via a link in an unexpected email | RR1 | [generic] standard onboarding practice | your action |
| A3 | Once A1 and A2 check out, reply to accept within five working days, and ask which payroll provider and pension scheme they use | R9, RR2 | [grounded] offer deadline | pending your decision |
| A4 | Send the passport scan through the portal, not plain email. Keep the original for day one | Right-to-work check | [generic] standard practice | your action |

**Evidence status**

Verified: none yet. Your background is self-report, and no document has been inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Marrowgate Housing Limerick housing association", "Marrowgate Housing careers payroll administrator") were refused by the host. Would have checked the entity and whether the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The search for payroll administrator pay in Limerick was refused. Would have given a market band |
| 3. Hiring manager's public footprint | unavailable | The search for Declan Garvagh was refused. Would have checked a public professional footprint |

**Upgrade menu**

- Confirming Marrowgate's careers page and offer domain yourself → RR1 closes.
- Your right to work, commute and pay floor → R1 to R3 close.
- An example of PAYE, PRSI or USC work → R5 to medium.
- Any pension-related task → R9 to medium.
- A copy of the Payroll Technician certificate → R7 to high.
- Search access on a later run → the three research targets run, including the market band.

If you'd like, I can save this as `tuesday-dossier.md`.

1. Is there anything in your hotel payroll where you calculated or checked PAYE, PRSI or USC? (R5, G1)
2. Can you confirm you have the right to work in Ireland, can get to Limerick two days a week, and that €40,000 meets your floor? (R1 to R3)
3. Have you done any pension-related task, even alongside your manager? (R9, G2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.