## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst: worth applying, on conditions. Status: `conditional_go`.**

**Kroonhaven Foods, Supply Planner: not worth your time right now. Status: `no_go`.**

### Duinvaart Cold Chain

**Fit ledger.**

- `hard_gate`: unclear: D8
- `must_have`: direct: D1, D2, D3, D4
- `important`: direct: D6; absent: D5
- `preferred`: adjacent: D7

D1–D4 are the core match. D5 has no cold-chain evidence. D7 is conversational Dutch against "a plus." D8 is the three-day Rotterdam schedule, which isn't settled yet.

- **Hard gates:** none failed; unconfirmed: D8 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the role is confirmed live on the company's own careers page or through a recruiter contact (RR1); (2) the three Rotterdam days are workable (D8). Describe the temperature gap as a gap, not as experience.

### Kroonhaven Foods

**Fit ledger.**

- `hard_gate`: unclear: K7
- `must_have`: absent: K1, K4; adjacent: K2, K5; unclear: K3
- `important`: adjacent: K6

K1 (3+ years of FMCG planning) and K4 (SAP IBP or similar) are absent, and you've never worked in planning. K2 and K5 are adjacent at best, and K3 (Excel) is unknown. Several must-haves are missing with no realistic closure in one application.

- **Hard gates:** none failed; unconfirmed: K7 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change it:** 3+ years of planning experience and fluent Dutch would both have to be different.

## Role reality

**Duinvaart Cold Chain**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A normal analyst remit for one fleet | `[inferred]` from the responsibilities listed |
| Market calibration | Not established: no search ran and the posting states no salary | — |
| Unknowns | Salary; who decides route changes; whether the employer is live | — |
| Contradictions | None found within the posting; the company's own site was not checked | — |

**Kroonhaven Foods**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | Ownership of a plan and a meeting from the first day, with no ramp stated | `[inferred]` from the responsibilities |
| Market calibration | Not established: no search ran and the posting states no salary | — |
| Unknowns | Salary; planning-team support; whether the employer is live | — |
| Contradictions | None found within the posting; the company's own site was not checked | — |

## Evidence map

**Duinvaart Cold Chain**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A CV claim, checkable through dates or a reference | `[grounded]` CV | none |
| D2 | Strong SQL | must_have | direct | medium | none | Daily SQL use per the CV; no sample yet | `[grounded]` CV | none |
| D3 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | Daily Power BI use per the CV; the posting names Power BI | `[grounded]` CV, JD | none |
| D4 | Track on-time delivery | must_have | direct | medium | none | The CV describes the on-time dashboard depot managers use. It doesn't say whether you built it or maintained it | `[grounded]` CV | Q3 |
| D5 | Track temperature compliance across a refrigerated fleet | important | absent | medium | capability | No cold-chain or temperature data in the CV. Parcel work is ambient | `[grounded]` CV silence | Q2; otherwise carry as a material risk |
| D6 | Work with depot managers on route changes | important | direct | medium | none | Ran the weekly route-performance review that depot managers use | `[grounded]` CV | none |
| D7 | Dutch a plus | preferred | adjacent | medium | capability | Conversational, below what day-to-day work would use | `[grounded]` CV | State the level as it is |
| D8 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | The posting sets the term. Your constraint wasn't given, so the fit can't be settled | `[grounded]` JD | Q1 |

**Kroonhaven Foods**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years FMCG supply or demand planning | must_have | absent | high | capability | You've stated you have never worked in planning | `[grounded]` candidate statement | none within one application |
| K2 | Own a 13-week supply plan; balance capacity against forecast | must_have | adjacent | low | transferability | Route capacity and performance analysis is the nearest work. No forecasting or capacity planning is stated | `[inferred]` from the route review | none |
| K3 | Advanced Excel | must_have | unclear | low | discovery | Not in the CV. SQL and Power BI don't establish Excel | `[inferred]` CV silence | Ask |
| K4 | SAP IBP or a similar planning system | must_have | absent | medium | capability | None stated | `[grounded]` CV silence | none |
| K5 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent; the role runs in Dutch | `[grounded]` candidate statement | none |
| K6 | Run the weekly S&OP meeting | important | adjacent | low | transferability | Ran a weekly route-performance review. S&OP is a different forum | `[inferred]` | none |
| K7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting sets the term. Your constraint wasn't given | `[grounded]` JD | Answer only if you pursue it |

## Gap recovery queue

**Duinvaart Cold Chain**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (D5, important) | capability | No temperature or cold-chain data in the CV | It's a stated responsibility of the role | Any temperature logging, excursion reports, or audit work, even on a side project | A sanitised monitoring report or a note on how the data was reviewed | `[grounded]` CV silence |
| G2 | Dutch (D7, preferred) | capability | Conversational | Preferred, so a minor risk | Formal Dutch study, or Dutch-language work | A Dutch-language writing sample | `[grounded]` candidate statement |

**Kroonhaven Foods**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (K1, must_have) | capability | None | A must-have with no adjacent planning work | Demand, capacity or inventory planning roles | Planning artefacts | `[grounded]` candidate statement |
| G4 | SAP IBP or similar (K4, must_have) | capability | None stated | Tool required for the role | Any planning-system use | Screenshots or a training record | `[grounded]` CV silence |

## Opportunity risk register

**Duinvaart Cold Chain**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Possible reasons, none ranked as likely: a new or small company, a stale posting, or a posting not from a live hiring employer. Caps the decision at `conditional_go` | `[inferred]` no search ran | Where is this role listed on your careers page, and is it open now? | unresolved |
| RR2 | Salary not stated | unknown | — | none in posting | The role may pay below its market band, or the employer may not publish pay | `[grounded]` posting silence | What is the salary range for this role? | unresolved |
| RR3 | Route-change decision rights unstated | unknown | — | "work with depot managers on route changes" | The role may propose changes while depot managers or fleet planning decide | `[inferred]` from the wording | Who makes the final route-change decision for this role? | unresolved |

**Kroonhaven Foods**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possible reasons as above, none ranked as likely. Caps any `go` at `conditional_go` | `[inferred]` no search ran | Where is this role listed on your careers page, and is it open now? | unresolved |
| RR2 | Salary not stated | unknown | — | none in posting | Same as above | `[grounded]` posting silence | What is the salary range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role is live on Duinvaart's careers page or through a recruiter whose address matches the company's domain | RR1 | `[grounded]` | recommended |
| A2 | Prepare one example of on-time tracking you ran, with confidential figures removed. Say "used" or "built" only as the answer to Q3 supports | D4 | `[grounded]` | pending your approval |
| A3 | State your Dutch as conversational in any application | D7; avoids a claim an interviewer would probe | `[grounded]` | pending your approval |
| A4 | Don't apply to Kroonhaven now. K1 and K4 would be the first things probed | K1, K4 | `[grounded]` | recommended |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was declined in this session (4 searches refused). Neither employer's site was checked, so RR1 stays open for both |
| 2. Role-family sweep | unavailable | No salary band or market scope was checked. RR2 and the market calibration rows stay open for both |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A live posting link or careers-page listing for Duinvaart → RR1 closes, and the verdict can move to `go` if D8 and Q2 also resolve.
- A salary range for either role → RR2 closes, and the figure can be checked against a band if search is allowed.
- An answer to Q1 → D8 resolves for Duinvaart.
- A sanitised on-time dashboard description or screenshot → D4 moves to `high`.
- Web search was declined here. If it's allowed later, I'd run one check each on both employers and one salary-band check. A deeper pass (up to 5 more searches and 2 fetches) is available if you want it.

If you want, I can write these verdicts and questions to a `tuesday-dossier.md` file so they carry into interview prep.

**Questions**

- **Q1 (D8):** Can you work from the Rotterdam office three days a week, and what is the longest commute you'd accept?
- **Q2 (D5):** Have you ever worked with temperature or cold-chain data, even in an audit, pilot, or side project?
- **Q3 (D4):** Did you build the on-time delivery dashboard, or use and maintain it?

Answer each in a line; skipping one is also an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.