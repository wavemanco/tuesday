**Status: `conditional_go`. Worth applying to, but verify the company first.** I couldn't check the company from here: web search was refused in this session, so the employer is still unverified. Nothing in the posting or the WhatsApp message asks you for money, a cheque deposit or bank details, or says the hiring happens only in chat. The WhatsApp message is a scheduling step and is routine.

**Fit ledger.**

- `hard_gate`: direct: R7 · unclear: R8 (Base salary against your pay floor)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end) · unclear: R6 (Work as the only designer)

R3: the method transfers, but the audience is school owners, not travel customers. R5: your checkout redesign is one slice of a booking flow, not the whole flow. R6: you've never been the only designer, and the posting's central ask is that you would be.

**Opportunity ledger.** Concrete and plausible: named scope, a named co-founder and CTO, a live product with two engineers (positive, RR6). The open items are the unverified employer (RR1), equity with no vesting terms (RR2), and single-designer scope (RR3). Pay is unbenchmarked (RR4).

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Base salary within €52,000–€60,000). Your pay floor and equity expectations were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company and this posting verify on its own site and the company register, RR1; (2) the call confirms what you would decide alone on the booking flow and what the CTO reviews, R6 and RR3; (3) the pay and equity terms meet your floor and are explained, R8, RR2 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Two days a week in the Galway office, otherwise remote | `[grounded]` posting |
| Market calibration | Not established: the salary benchmark search was refused, so I have no band to compare €52–60k against | — |
| Unknowns | Company existence and live posting, equity vesting, the salary's basis, what the first designer decides alone | — |
| Contradictions | None between the posting and the message | `[grounded]` |
| Routine step | The WhatsApp scheduling message is routine. The video invite should come by email, so check it | `[generic]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` your statement | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | portfolio file, if asked |
| R3 | Runs own user research | must_have | direct | medium | transferability | Monthly usability sessions with customers; the posting wants school owners | `[grounded]` statement, `[inferred]` audience transfer | none |
| R4 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your statement | none |
| R5 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | Redesigned checkout inside a squad; end-to-end ownership not stated | `[inferred]` from the checkout work | checkout case study showing ownership, from research to ship |
| R6 | Works as the only designer | must_have | unclear | low | capability | No sole-designer experience; the posting implies it | `[grounded]` posting and your statement | a project where you made the final design call without a design lead |
| R7 | Hybrid, Galway, two days in office | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R8 | Base salary €52,000–€60,000 | hard_gate | unclear | low | hard_gate | Your floor was not given | `[grounded]` posting | your pay floor |

The checkout case study is the one Ronan mentions, so it is already with them.

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer work (R6) | capability | No sole-designer experience | The posting's central ask | Any project where you made the design call with no design lead signing off | A short write-up of that decision | `[grounded]` posting |
| G2 | End-to-end ownership (R5) | transferability | Checkout redesign only | Booking flow is the job | Research-to-ship decisions on the checkout, even inside a squad | Checkout case study with decision points | `[inferred]` |

The questions for G1 and G2 are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software" | Unverified from here, since the search was refused. The company may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies this size | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity without vesting terms | unknown | — | "plus 0.5–1% equity" | Equity may be worth less than it looks without vesting, dilution or exercise terms | `[generic]` | What vesting schedule and cliff apply, and how many shares is the company split into? | unresolved |
| RR3 | Single-designer scope | risk_signal | low | "You would be our first designer: own the booking flow end to end" | One designer may carry design, research and delivery with no design partner | `[inferred]` from scope against stated team size | Who reviews design decisions day to day, and what research already exists with school owners? | unresolved |
| RR4 | Salary not benchmarked | unknown | — | "Salary €52,000–€60,000" | The band may sit above or below market for this role in Galway; I could not check | `[grounded]` posting; benchmark not established | How was this band set, and is there room in it for someone with four years' experience? | unresolved |
| RR6 | Concrete scope and named leadership | positive_signal | — | "we would rather see one messy real project than a polished deck" | The team values working product over presentation | `[inferred]` from the posting's wording | Which part of the product would I work on first? | noted |

No entry is raised for the WhatsApp message, which is routine scheduling.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the company on its own website and careers page, and search the Companies Registration Office register for the registered name | Verify the employer before effort, RR1 | `[generic]` check method | proposed |
| A2 | Check the invite comes from an address on the company's own domain, and that the video link opens to a company meeting | Routine invite check, advice only | `[generic]` | proposed |
| A3 | Reply to Ronan on WhatsApp only to confirm the time, and take the pay and equity questions to the call | Keeps the substance in writing and on the call | `[grounded]` message | proposed |
| A4 | Ask RR2, RR3 and RR4 verbatim on the call | The register doubles as prep | `[grounded]` register | proposed |
| A5 | Lead with the checkout redesign and the usability sessions; frame R5 as adjacent, not as owning a booking flow | Matches the evidence | `[grounded]` R3, R5 | pending your approval |
| A6 | Describe any sole-design decision you made, without claiming sole-designer experience | Avoids an unsupported claim on R6 | `[grounded]` R6 | pending your approval |

## Evidence status

Verified: none yet. Your background is your statement, not sourced.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software Galway sea kayak surf schools" and "Fernquay careers Product Designer"; both refused by the host. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland Galway 3 years experience"; refused. Would have moved RR4 |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. Would have moved the scope read and the positioning for Ronan |

I did not retry the refused searches.

Dossier offer: I can write this up as `tuesday-dossier.md` to keep beside your interview prep, if you want it.

## Upgrade menu

- The live posting link or the careers page → RR1 closes or stays open.
- Your pay floor → R8 becomes direct or absent, checked against €52,000.
- A portfolio link or the checkout case study → R1–R5 confidence rises; R5's gap narrows.
- The company's equity terms → RR2 closes.
- Search access restored → the three targets above can run. A deeper pass on funding, leadership and public reviews (up to 5 more searches and 2 more fetches) is available once search works; say the word.

Questions:

1. (R8, RR4) What's your base-pay floor, and does €52,000 meet it?
2. (G1, R6) Is there a project where you made the final design call without a design lead to sign it off?
3. (RR1) Does the calendar invite come from an address on the company's own domain? A yes or no is enough.

Answer in prose; skipping a question is an answer too.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.