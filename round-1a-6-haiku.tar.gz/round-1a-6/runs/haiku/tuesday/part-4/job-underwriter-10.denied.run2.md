**Short answer:** Worth the 45-minute call, but I could not verify that Fernquay is a real, hiring company. Web search was refused in this session, so every company check failed to run. Nothing in what you've shared asks you for money, bank details, or hiring entirely over chat, so I have no red flag to raise. The WhatsApp message is routine: scheduling a call is an ordinary step, and the invite and interview are supposed to come from the company's own email domain.

**Research tier: L1 — searches 5 of 5, fetches 0 of 2; all searches refused.**

## Decision snapshot

Take the call: `conditional_go`. The call is itself the cheapest check. Go in with three things to confirm: the company and role exist on Fernquay's own site, the pay is above your floor, and the equity terms are clear.

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2 (pay band against your floor)
- `must_have`: direct: R3 (3+ years product design), R4 (strong Figma), R5 (ran own user research), R6 (works directly with engineers)
- `important`: adjacent: R7 (first designer, no design peers), R8 (end-to-end booking flow), R9 (research with school owners)

R7 — never the only designer, so the closest proof is squad work; R8 — a travel-booking checkout, not a school-booking product; R9 — customer usability sessions, not business owners (`medium`).

**Opportunity ledger.** Transparent posting: salary, hybrid terms and first-year scope are stated (RR4). The main open items are whether the company checks out (RR1), the solo-designer scope (RR2), and equity with no vesting or strike terms (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your floor); your pay floor was not given, so checks against it are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is on Fernquay's own careers page and the company is registered; (2) R2 clears against your floor; (3) RR2 and RR3 get concrete answers on the call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A solo first-designer role at a team this size is ordinary for early-stage product companies | `[generic]` pattern, not a claim about Fernquay |
| Market calibration | Not run: the salary search was refused | — |
| Unknowns | Funding and runway, equity vesting and strike, whether the role is already on Fernquay's site, who reviews design work | — |
| Contradictions | None found within the posting | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; a stated fact, not inspectable | `[grounded]` your background | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given, so no claim exists to check | `[grounded]` posting | Q1 below |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; self-reported | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use | `[grounded]` your background | none |
| R5 | Has run own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers (not business owners) | `[grounded]` your background | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R7 | First designer, no design peers | important | adjacent | medium | transferability | You redesigned checkout within a squad but were never the only designer | `[inferred]` from your background | Q2 below |
| R8 | Owns booking flow end to end | important | adjacent | medium | transferability | Checkout redesign in travel booking; a different domain from school booking | `[inferred]` from your background | Use the case study as the bridge |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Customer usability work carries over; business-owner interviews do not appear in your background | `[inferred]` from your background | Q3 below |

## Gap recovery queue

- **G1 (R2, hard_gate):** The pay gap is a gate, not a skill gap. Closes when you state your floor (see Q1).
- **G2 (R7, transferability):** Carries over: owning a flow inside a squad. Limit: no experience setting direction alone. Strengthener: an example where you made a flow decision without a design lead (see Q2).
- **G3 (R9, transferability):** Carries over: running usability sessions. Limit: the interviewees were customers, not owners of a small business. Strengthener: a redacted research plan or interview guide (see Q3).

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Fernquay ... six people in Galway" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Web search was refused, so this is not a finding about Fernquay | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers page, and what is the company's registered name? | unresolved |
| RR2 | Solo designer scope | risk_signal | low | "You would be our first designer" | Design feedback and research priorities may depend on you alone | `[inferred]` from "first designer", "own end to end", "run research calls" | Who reviews design work day to day, and who sets research priorities? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price and round terms are missing, so the equity figure cannot be valued | `[generic]` early-stage equity is usually described with vesting and strike terms | What is the vesting schedule, the strike price, and the total share count? | unresolved |
| RR4 | Transparent pay and terms | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Salary is published and the hybrid pattern is explicit | `[grounded]` posting | What would success look like at six months? | noted |

Nothing in the messages asks for payment, bank details or a deposit, and the interview and offer steps are routine, so the register holds no severe red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, check Fernquay's own website for the role and the company name | Closes RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Ask RR1, RR2 and RR3 on the call, word for word | The register doubles as call prep | `[grounded]` register | pending your approval |
| P3 | Prep the call with mock-interview once it is booked | Practice for the call | `[generic]` interview practice | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at `medium` until you share something inspectable.

Research tier: L1 — searches 5 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Company existence, live posting and consistency with the posting. Every search was refused, including the company, careers and registration searches |
| 2. Role-family sweep | unavailable | Market band for product designers at this seniority. Would calibrate R2 and the equity note |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe's public role and background; would shape how to pitch the call |

## Dossier offer

I can write this up as a `tuesday-dossier.md` so the verification questions carry into your call prep.

## Upgrade menu

- Search access → targets 1–3 run: the company's own site, its registration, a salary band for product designers in Ireland, and Ronan Kehoe's public background. This is the fastest way to close RR1.
- A link to the live posting on Fernquay's site → RR1 closes or narrows.
- The checkout case study, or a redacted copy → R3 and R8 move from `medium` to `high`.
- Your pay floor → R2 closes.
- Equity terms from the call → RR3 closes.

## Questions

R2 — What is the lowest base salary you would accept, and does the €52,000–€60,000 range meet it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R7 — Have you ever shaped a flow or a research plan with no design lead to review your work, even informally? What did you decide alone, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R9 — Can you share the checkout case study, or a redacted copy, so the bridge to this role can be shown?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.