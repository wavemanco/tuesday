**Decision: don't go ahead. Send nothing, pay nothing, and don't paste your IBAN, PPS number or passport anywhere.**

**Decision snapshot**
- Opportunity: `no_go` on the posting's own terms. Stop before any payment or personal-data step.
- Candidate fit: strong. Your Zendesk volume, training experience and Excel tracking match the stated requirements well. Fit doesn't change the decision, because the risk sits in how the job is being run.
- Hard gates: none stated. Your €30,000 floor is not met on the posting's figures alone (see pay below).

**Red flags (quoted from the posting and messages)**
| Quote | Why it matters |
|---|---|
| "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Hired entirely by chat, with no verifiable contact. |
| "send your IBAN, your PPS number and a clear photo of your passport" before any interview | Full identity and bank details requested before any offer. |
| "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Paying to take a job, with the refund only promised. |
| "We are posting you a cheque for €2,850. Lodge it to your account, keep €350… and transfer the rest to our equipment partner." | You would send real money from your account against a cheque that may not clear. If it bounces later, the transferred funds are typically yours to repay. |

The company's own website and its contact details are the place to check. The Telegram account and the velloway.hr@postmail.example address are the only contacts so far, and they are the ones asking for money and documents.

**Pay check**
- At €26/hr, 15 hrs/week over 52 weeks is about €20,300. At 30 hrs/week it is about €40,600. Commission is unstated, so the posting does not show whether €30,000 is reachable.

**Evidence status**
Research tier: L0 — no searches. I haven't checked whether Velloway Logistics exists, so this rests only on the posting and the messages you pasted.

**Dossier offer**
If you want, I can write a `tuesday-dossier.md` file with this assessment for your records.

**Upgrade menu**
- Official company check: a live careers page, the company's registration record, and a named recruiter with a company email domain would change or confirm this. None of them would make the €349 fee or the cheque plan acceptable.

**Questions**
1. Have you already sent any of your IBAN, PPS number or passport photo to this contact? If yes, contact your bank about it and treat your details as exposed.
2. Do you want me to run a research pass (up to 5 searches and 2 page fetches) on Velloway Logistics to see whether it has an independent web presence?

**What to do now**
- Don't pay the €349, don't lodge or forward the cheque, and don't send documents.
- If you want to check the role, use contacts from the company's own website, not the Telegram account.
- If you've already shared details or sent money, contact your bank and report it to the Gardaí.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.