**Decision: no_go. Don't send anything, pay anything, or deposit the cheque.**

**Decision snapshot**
- **Fit (candidate):** Strong on the stated requirements. Three years of Zendesk ticket work, two people trained, and an Excel tracker all match the posting. Written English isn't evidenced in what you've given me.
- **Opportunity:** Fails on several counts. The stated terms do not reach your floor on the posted figures.
- **Hard gates:**
  - **Pay (your €30k floor): not met on the stated terms.** At €26/hour, €30k a year needs about 22 hours a week every week, and commission is unquantified. At 15 to 30 hours, base pay runs about €20k to €40k.
  - **Payment and documents before an offer: red flag, high severity.** The posting itself is a hiring process run entirely by chat, and the messages ask for payment and bank and ID documents before any offer.

**Red flags, quoted from the messages**
1. "Please send your IBAN, your PPS number and a clear photo of your passport" before any interview.
2. "Please pay €349 by bank transfer to our equipment partner" for a laptop and headset, "refunded with your first wages."
3. "We are posting you a cheque for €2,850… keep €350… and transfer the rest to our equipment partner."
4. The whole process runs on Telegram, with no calls, video or company-domain email. The only contact is a generic mailbox at postmail.example.

Routine steps such as payroll details after a written offer from a verifiable employer are normal. Asking for money, or for a cheque to be partly passed on, before any offer is not. A cheque can also bounce after the money you sent from it has left your account.

**Role reality:** Remote order processing, 15 to 30 hours, commission on orders. Nothing in the posting says what the employer does, where it is registered, or who employs you.

**Evidence status:** Research tier L0. No searches run. I did not check whether Velloway Logistics exists, because the decision holds on the material you pasted. Failed attribution is therefore not established either way, which is one more reason not to proceed.

**Risk register**
| Class | Item | Severity |
|---|---|---|
| Red flag | Payment for equipment before an offer | high, confirmed |
| Red flag | Bank, tax and ID details requested before an offer | high, confirmed |
| Red flag | Cheque deposit with a partial transfer out | high, confirmed |
| Mismatch | Stated pay doesn't reach €30k without about 22+ hours a week | medium |
| Unverified | Employer existence and contact domain | medium |

**What to do now**
- Don't paste your IBAN or PPS number into the Telegram chat, and don't send the passport photo.
- Don't pay the €349 and don't deposit any cheque.
- If you want to check the employer, do it through a route they didn't give you: search for the company's own website and careers page, and look up its registration.
- If you've already sent documents, contact your bank and consider reporting the chat to the platform where you found the posting.

**Dossier offer:** I can write a `tuesday-dossier.md` with this assessment for your records, if you'd like one.

**Upgrade menu:** A link to the employer's own careers page or a company-domain contact would let me run the attribution check. A written offer from a verifiable employer, with pay stated in full, would change the pay gate.

**Questions**
1. Do you have a link to a company careers page or a company-domain email address for Velloway Logistics?
2. Has any money, bank detail or ID been sent so far, or is this still at the chat stage?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.