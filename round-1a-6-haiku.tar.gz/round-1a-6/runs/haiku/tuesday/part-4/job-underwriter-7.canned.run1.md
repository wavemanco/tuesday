**Yes, it's worth applying, on one condition you can check before you spend time on it. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4a, R5a, R7 · adjacent: R4b (leg-ulcer care) · unclear: R5b (continence care), R6 (end-of-life visits), R8 (care planning), R10 (clear, timely written records)
- `important`: adjacent: R9 (own caseload)
- `preferred`: absent: R11 (Doppler assessment)

R4b — a credible bridge from wound care, its limit named; R5b, R6, R8 and R10 — nothing in the CV yet, asked below; R11 — no evidence, a closure path exists.

**Opportunity ledger.** The employer is established and the salary sits inside the market band, so the posting itself reads as sound. The main open point is that the post is not yet confirmed live (RR2). RR1, RR3 and RR4 are positive: the employer exists as described (RR1), the pay range covers the survey's interquartile band (RR3), and the caseload has defined support (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2 — the post is confirmed open on the employer's careers page; (2) you can speak to continence, end-of-life and caseload ownership at interview (R5b, R6, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` employer's about page |
| Scope | District nursing with a small personal caseload, supported by a senior community nurse | `[grounded]` posting |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | 2026 community staff nurse Band 5 survey: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage | `[generic]` Wardround 2026 pay guide, one search, n=1,240 |
| Unknowns | Caseload size; mileage rate; closing date; how much of the caseload is continence or end-of-life | — |
| Contradictions | None found between the posting and the employer's about page. The careers page could not be reached, so the posting is not confirmed live | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Stated PIN and active registration; not inspected | `[grounded]` your CV | Check your own NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated full category B; not inspected | `[grounded]` your CV | Check your own driving record |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds named | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over; leg-ulcer work is not named. Limit: no leg-ulcer work stated | `[inferred]` from R4a | Q1 |
| R5a | Catheter care | must_have | direct | medium | none | Named in CV | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | none | discovery | CV silent | `[grounded]` CV silence | Q1 |
| R6 | End-of-life visits | must_have | unclear | none | discovery | CV silent | `[grounded]` CV silence | Q2 |
| R7 | Insulin administration | must_have | direct | medium | none | Named in CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | unclear | none | discovery | CV silent on planning | `[grounded]` CV silence | Q2 |
| R9 | Own caseload with senior support | important | adjacent | medium | transferability | Seconded home visits in discharge-to-assess are the nearest work. Limit: you have never held your own caseload | `[inferred]` from the CV's visit history | Q3 |
| R10 | Clear, timely written records on an electronic record | must_have | unclear | none | discovery | CV silent on records or the system used | `[grounded]` CV silence | Q3 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path: a Doppler course. The team lead spoke on Doppler training for new community staff in 2025 | `[generic]` closure path; `[grounded]` forum listing | Consider a course (P4) |

Confidence is capped at `medium` for CV-only claims, so nothing reaches `high` yet.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Leg-ulcer and continence care (R4b, R5b) | discovery, transferability | Wound and catheter work is in the CV; leg-ulcer and continence work is not | Both are must-haves for housebound patients | A patient group you cared for, even briefly | `[grounded]` CV |
| G2 | End-of-life and care planning (R6, R8) | discovery | Neither appears in the CV | Both are must-haves and typical of community visits | Any end-of-life visit or a care plan you wrote or reviewed | `[grounded]` CV silence |
| G3 | Caseload and records (R9, R10) | transferability, discovery | Home visits and a record system are implied, not stated | The role is caseload-based on an electronic record | Visits you controlled, and the system you documented on | `[inferred]`; `[grounded]` CV silence |
| G4 | Doppler (R11) | capability | No evidence | Preferred only | A course, or current training | `[generic]` |

The questions for these gaps are in the closing block, tagged to their rows.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established as described | positive_signal | — | "Calderbrook Community Health is a community interest company running adult community nursing…" | An established employer with an NHS contract | `[grounded]` about page | How many nurses hold a caseload in the Halifax team? | noted |
| RR2 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page." | The post may have closed or been filled | `[inferred]` from the careers page being unreachable | Is this post still open, and what is the closing date? | unresolved |
| RR3 | Mileage terms unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Mileage terms may vary; the survey shows most roles pay it | `[grounded]` posting; `[generic]` survey | How is mileage paid, and are pool cars available for all visits? | unresolved |
| RR4 | Defined caseload with senior support | positive_signal | — | "hold a small caseload of your own, supported by a senior community nurse" | Scope is defined and supported | `[grounded]` posting | What is the caseload size, and how often do you review cases with the senior nurse? | noted |

Severity is `—` where it does not apply. Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the post on the employer's careers page before applying | RR2 | `[grounded]` RR2 | Your check |
| P2 | Ask for an informal chat with Rhiannon Mabbott on caseload support and leg-ulcer clinics | R4b, R9, R11 | `[grounded]` forum listing: the 2025 talk on leg-ulcer clinics and Doppler | Pending your approval for any wording |
| P3 | If your answers to Q1–Q3 show real experience, propose CV edits | R4b, R5b, R6, R8, R9, R10 | `[grounded]` your answers | Pending your approval |
| P4 | Consider a Doppler course | R11 | `[generic]` closure path | Pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health community staff nurse band 5 Halifax jobs". Fetched calderbrookhealth.example/careers, which returned no page. Moved: the entity exists as described (calderbrookhealth.example/about). Posting not confirmed live (RR2) |
| 2. Role-family sweep | yes | Searched "NHS band 5 community staff nurse salary 2026 £31,050"; returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration (`[generic]`) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; returned her speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved P2 and R11 |

## Upgrade menu

- Confirmation that the post is live on the careers page → RR2 closes.
- Your answers to Q1–Q3 → R4b, R5b, R6, R8, R9 and R10 move from unclear or adjacent toward direct, and a truthful CV edit can follow (P3).
- Your NMC register entry and driving record checked by you → R1 and R2 move from stated to checked.
- A deeper pass on Calderbrook Community Health (leadership, inspection reports, staff reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

If you want the full assessment saved as a `tuesday-dossier.md` file to reuse for interview prep, I can emit it at the end of the engagement.

1. Did any of your discharge-to-assess or ward work involve leg-ulcer patients or continence needs, and what did you do for them? (G1; rows R4b, R5b)
2. Have you led a care plan, or been involved in end-of-life care in a patient's home? (G2; rows R6, R8)
3. Did you ever hold a caseload or sole responsibility for visits, and which record system did you document on? (G3; rows R9, R10)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.