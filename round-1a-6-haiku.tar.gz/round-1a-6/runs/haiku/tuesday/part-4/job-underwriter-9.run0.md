**Snapshot:** Conditional go. The document requests are normal for an Irish employer at this stage. I could not verify that Marrowgate Housing exists as described, because the web search was refused, so that check is still open.

**Are the requests normal?** Yes, once a written offer is in hand. Irish employers typically need three things:
- **PPS number:** Revenue requires it for PAYE and USC, so payroll cannot run without it.
- **Bank details:** needed to pay salary.
- **Passport or other right-to-work document:** employers must verify right to work, and a passport is the most common document. Many employers take a scan through an onboarding portal and also check the original in person, which is why they ask you to bring it on day one.

Asking for these after the offer, rather than before any interview, is routine. Asking for them before any offer, by chat, or to pay for equipment or training would be a different matter. Nothing in this offer looks like that.

**What I could not check:** I did not confirm that Marrowgate Housing is a real employer, or that people@marrowgatehousing.ie belongs to it. The search call was refused, so this is not-established, not a finding against them.

**Before you send anything:**
1. Find the company's own website from a search you run yourself. Check that the careers page lists this role, that Declan Garvagh is listed as Finance Manager, and that the phone number and address match.
2. Call the switchboard number from that website, not one from the email, and ask whether the People Team sent the offer.
3. Check the onboarding portal link when it arrives. It should sit on the company's own domain, not a third-party domain. Do not upload documents through a link you cannot confirm.
4. Ask for the written contract or statement of terms before you give notice. Irish law requires a written statement of terms, so this is a reasonable request. Ask about probation, pension scheme and leave.
5. Do not hand over original documents to anyone other than the People Team, and only at the agreed point.

**Fit note, separate from legitimacy:** The role includes pension changes, which you have not done yourself. Ask the employer what the pension admin involves and whether there is training or a handover from the current person. That is a question about the job, not a warning sign.

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file so you can reuse it for interview prep. The full dossier and the upgrade menu are available on request.

**What would change this:**
- If the company's own site and switchboard confirm the role and the People Team, this is a go.
- If the offer comes from a different domain, or the portal is not on the company's domain, stop and verify with the company directly before sharing anything.

**Questions (up to three):**
1. Where did you first see the job ad, and is the link still live on their careers page?
2. Did your two interviews include anyone from the finance team, such as Declan Garvagh?
3. Do you want me to draft a reply asking for the written contract and the pension details, without accepting yet?

**Evidence status:** L1 research, searches 1 of 5, fetches 0 of 2. The company-existence check was refused by the host. Its status is `unavailable`. Its reason is that the web search permission was denied, so the employer's website and public presence were not checked.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; the search was refused by the host.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.