**Aoife, yes, it's worth applying, once you've confirmed the post is still listed on Calderbrook's own careers page.** Status: `conditional_go`.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given. Checks against your pay floor, schedule and other limits are unknown, because you didn't list any.
- **Fit ledger:**
  - `hard_gate`: direct: R1, R2
  - `must_have`: direct: R3, R4a, R5a, R6 · adjacent: R4b (leg-ulcer care), R7 (holding own caseload) · unclear: R5b (continence care), R8 (care planning), R9 (written records and EPR)
  - `important`: unclear: R10 (end-of-life visits)
  - `preferred`: absent: R11 (Doppler assessment)

  R4b is a credible bridge with its limit named. R7 is adjacent because discharge-to-assess visits are the nearest evidence, not a caseload. R5b, R8, R9 and R10 are silent on the CV, so they are open questions, not gaps you've confirmed.
- **Opportunity ledger:** The employer is established (RR4 is positive). The posting is not confirmed live (RR1), and mileage and caseload terms are unstated (RR2, RR3). No severe red flags.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed on the employer's careers page (RR1); (2) R8, R9 and R10 come back in your favour when we ask; (3) the leg-ulcer bridge is framed as adjacent, never as experience you have.

**Your National Insurance number** isn't needed for this assessment. I haven't used it and it isn't in any search.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Employer | Calderbrook Community Health CIC: adult community nursing under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` employer's about page |
| Role | Community Staff Nurse, Band 5; district nursing for housebound adults, a small own caseload with senior nurse support | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | Band 5 community staff nurses, England, 2026 sample of 1,240: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage. The posting's bottom sits below that range's floor and its top above the ceiling. This is a pattern, not this employer's offer. | `[generic]` Wardround 2026 pay guide |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead. Public record: eleven years as a district nurse; spoke in 2025 on nurse-led leg-ulcer clinics and Doppler training for new community staff | `[grounded]` speaker page |
| Contradictions | The careers page address I tried returned no page, so the posting is not confirmed live | `[grounded]` fetch result |
| Unknowns | Mileage rate; caseload size; the senior nurse's role; which EPR system; whether the post is open | — |

## Evidence map

Confidence is capped at `medium` on a first pass, because nothing has been inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Your stated, active registration. Stated, not checked. | `[grounded]` CV | You check the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full, category B, stated. Expiry not given; stated, not checked. | `[grounded]` CV | You check your licence record |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds on the CV | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | adjacent | medium | transferability | Same wound assessment skills; leg-ulcer care is not on the CV. Limit: no leg-ulcer work. | `[inferred]` from R4a | Bridge case, gap queue G1 |
| R5a | Catheter care | must_have | direct | medium | none | On the CV | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask |
| R6 | Insulin administration and care planning (insulin) | must_have | direct | medium | none | On the CV | `[grounded]` CV | none |
| R7 | Holding own caseload in people's homes | must_have | adjacent | medium | transferability | Discharge-to-assess home visits, first week after discharge. Limit: short episodes, no caseload. | `[inferred]` from CV | Bridge case |
| R8 | Care planning | must_have | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask |
| R9 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | No EPR system named | `[grounded]` CV silence | Ask |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one | `[grounded]` your statement | Closure path, see Application plan |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4b) | transferability | Pressure-ulcer and surgical-wound assessment on the CV; no leg-ulcer work | The must-have most likely to be probed | Any leg-ulcer dressing, review or compression work, even observed | A sanitized wound-review note | `[inferred]` bridge from R4a; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the careers page | risk_signal | low | "For an informal chat about the role, contact Rhiannon Mabbott" | The post may have moved or been listed elsewhere | `[generic]` pattern for NHS-contracted employers changing vacancy pages | Which page lists this post, and is it still open? | unresolved |
| RR2 | Mileage rate and pool-car terms not stated | unknown | — | "plus mileage" / "pool cars are provided" | The real pay depends on both | `[inferred]` from the posting's silence | What is the mileage rate, and do pool cars cover home visits? | unresolved |
| RR3 | Caseload and senior-nurse support not described | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Size and support model decide how far R7 is a bridge | `[inferred]` from the posting's silence | How many patients would I carry, and what support on a home visit? | unresolved |
| RR4 | Named contact publicly covers two of the posting's items | positive_signal | — | Speaker page: leg-ulcer clinics and Doppler training | The team's public agenda matches the posting | `[grounded]` speaker page | Is Doppler training given to new community staff, and how soon? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on the employer's own site before you apply | RR1 | `[grounded]` RR1 | proposed |
| A2 | Check your NMC register entry and licence record yourself | R1, R2 | `[grounded]` stated, not checked | proposed |
| A3 | Frame leg-ulcer care as an adjacent bridge, naming the limit | R4b | `[inferred]` from R4b | pending your approval (any CV wording) |
| A4 | Ask RR2 and RR3 at the informal chat; the mock-interview module can prep that conversation | RR2, RR3 | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. The CV and your intake are self-report, so every claim is still unverified. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; the about page (calderbrookhealth.example/about) confirmed the employer. Fetched calderbrookhealth.example/careers: no page. The posting is not confirmed live (RR1). |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing caseload salary"; the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide) gave the market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead"; the speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) gave the public record in Role reality. |

## Upgrade menu

- The posting on the employer's own careers page → RR1 closes, and `conditional_go` can move to `go`.
- A sanitized wound-review note, or an observed leg-ulcer or Doppler session → R4b and R11 move.
- Your EPR system's name and one sanitized home-visit record → R9 can move to `medium`.
- The mileage rate and car terms → RR2 closes, and the real pay becomes clear.
- A deeper research pass on Calderbrook (inspection reports, public staff reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

When this assessment settles, I can produce a `tuesday-dossier.md` file for you to keep. Say so if you'd like one.

**Questions**

R8 — In the discharge-to-assess visits, did you decide the next steps in a patient's care plan, or only carry out a plan the ward team had set? What did you own?

R10 — Have you ever been the nurse for a patient's last weeks at home, on the ward or in discharge work?

R9 — Which electronic patient record systems have you used, and how did you record home visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.