**Decision snapshot**

Yes, it's worth applying, and taking the call is worth your time. Status: `conditional_go`. The company checks out on its own website, and the posting and the WhatsApp message are consistent with it. The open question is whether you can show you can own the booking flow alone, since you've never been the only designer.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (salary €52,000–€60,000, your floor not given)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (own the booking flow end to end), R8 (first and only designer)
- `important`: adjacent: R9 (research with school owners)
- `preferred`: adjacent: R10 (booking-software domain)

R7 — checkout ownership inside a squad, adjacent until you show what you decided alone; R8 — no sole-designer experience, the limit to name on the call.

**Opportunity ledger.** The employer is real and the pay sits inside the market band (RR1, RR2). The open items are who holds design decision rights (RR3) and the unquantified equity (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000, your floor not given); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name a flow you owned from research through shipping, and which decisions were yours alone (R7, R8); (2) €52,000 clears your floor (R2); (3) RR3 resolves cleanly in the call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` fernquay.example/about |
| Posting | Live on the careers page, same hybrid pattern, salary and equity as your copy | `[grounded]` fernquay.example/careers/product-designer |
| Market calibration | Product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000, so €52,000–€60,000 sits inside the band | `[generic]` one 2026 Ireland salary survey (n=520); not a claim about this employer's offer |
| Scope read | First designer with end-to-end ownership, research and shipping alongside two engineers | `[inferred]` from the posting's wording |
| Contact | WhatsApp scheduling plus an emailed calendar invite for a video call | `[grounded]` your message; routine step, no register entry |
| Unknowns | Decision rights on design, equity terms, whether Saoirse is CTO (the About page lists them as co-founder, no title) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Based in Galway for two in-office days a week | hard_gate | direct | medium | none | You say you moved back to Galway; intake prose, so medium at most | `[grounded]` your intake message |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given, so nothing to grade | — |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported | `[grounded]` your intake message |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake message |
| R5 | Has run own user research | must_have | direct | medium | presentation | Monthly usability sessions with customers; likely under-shown on the CV | `[grounded]` your intake message |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your intake message |
| R7 | Owns a flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow; unclear which decisions were yours | `[inferred]` from the checkout work you described |
| R8 | Designs alone, no design peers | must_have | adjacent | low | transferability | Squad work, never the only designer; the limit is real | `[inferred]` from your history |
| R9 | Research with school owners (business customers) | important | adjacent | medium | transferability | Customer research transfers; different audience | `[inferred]` from R5 |
| R10 | Booking-software domain | preferred | adjacent | medium | transferability | Travel booking is close, not the same | `[inferred]` from your employer's sector |

**Gap recovery queue**

- **G1 (R7, R8, transferability):** the bridge is the checkout work plus monthly research. Its limit is that you never had a design peer to review decisions. The closing question asks which flow you owned and what you decided alone. A case-study excerpt where you made a call with no review would raise R7 and R8.
- **G2 (R2, hard_gate):** only you can close it, with your floor.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established from its own pages | positive_signal | — | "Six people, based in Galway" | The standing employer-not-established entry does not apply | `[grounded]` About page and live careers page | Who would I be interviewing with? | noted |
| RR2 | Salary inside market band | positive_signal | — | "€52,000–€60,000" | Pay is in line for this experience | `[generic]` one survey band | What is the budgeted salary range? | noted |
| RR3 | Design decision rights unstated | risk_signal | low | "you will be our first designer: own the booking flow end to end" | You may carry the outcome without final say on design | `[inferred]` from the posting's scope against its silence on decisions | Who makes the final call on booking-flow design, and who reviews it? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus 0.5–1% equity" | Value depends on share class, vesting and strike | `[generic]` standard for early-stage equity | What class of shares, what vesting, and what strike price? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Before replying on WhatsApp, check the calendar invite comes from fernquay.example and matches the careers-page contact | Routine scheduling, so this is advice, not a warning | `[grounded]` careers page, your message | pending your approval |
| A1 | Prepare one flow story: what you owned, what you decided alone, what the squad decided | Answers R7 and R8 directly | `[grounded]` your history | pending your approval |
| A2 | Check €52,000 against your floor before the call | Closes R2 | — | pending your approval |
| A3 | Ask RR3 and RR4 on the call | They decide the conditions | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (About page, fernquay.example/about) and "Fernquay Product Designer job Galway" (careers page). Fetched both. The employer exists as described, and the posting is live and matches yours |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 3 years experience", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]`. I did not run a separate scope search |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn snippet (linkedin.example/in/ronan-kehoe). Not fetched. The profile lists co-founder and CEO, and a prior product-lead role at a Galway travel-software company for five years. Expect product-level questions |

Saoirse Doyle is not a declared target, so no research was run on them.

Dossier offer: I can write this up as `tuesday-dossier.md` to carry into the call, if you want it.

**Upgrade menu**

- Your floor and the salary → R2 closes.
- A case-study excerpt where you made a call alone → R7 and R8 move toward `direct`.
- Equity terms in writing → RR4 closes.
- A deeper research pass on Fernquay (funding, leadership, public reviews; up to 5 more searches and 2 more fetches). Say the word and I'll run it.

**Questions**

1. R2: Does €52,000 clear your salary floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. R7: Which booking or checkout flow did you own from research through shipping, and which decisions did you make alone? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.