**Yes, apply: `conditional_go`.** Fernquay checks out as a real company with a live posting that matches what you were sent, and the WhatsApp message is ordinary scheduling. The open question is the first-designer part, not legitimacy.

**Decision snapshot**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: none
- `must_have`: direct: R2, R3, R4a, R5 · adjacent: R4b (school owners as the audience), R6 (own the booking flow end to end)
- `important`: unclear: R7 (first designer, no design peers)
- `preferred`: none stated in the posting

R4b and R6 are transferability cases with their limits named; R7 is a discovery question about how you've worked without design peers.

**Opportunity ledger.** Sound and attributable: the company, its careers page and its co-founder's public profile agree with the posting (RR3, positive). RR1 (first design hire with nobody to review your work) and RR2 (equity and runway not stated) are unresolved.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the first call gives a concrete answer on who reviews design work and how decisions get made (RR1, R7); (2) the company states its runway and the basis of the equity (RR2); (3) you set your own limits (lowest base, office days, contract type) before going past the first call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway; makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` company About page (from search result, not fetched) |
| Mandate | First designer: own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` careers page |
| Market calibration | Ireland, 2026, product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posting sits inside that range, below the median. | `[generic]` Tillerby 2026 Ireland design salary report (n=520); not this employer's offer |
| Unknowns | Funding and runway; equity value; who reviews design work | — |
| Contradictions | None between the posting and the careers page. The About page gives Saoirse Doyle as a co-founder; the message calls her CTO. That is not a contradiction, but ask on the call. | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You say you moved back to Galway last year. Checked against location only; you haven't stated any limit on days. | `[grounded]` your statement | Confirm your days (question 2) |
| R2 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. A length-of-experience requirement, so graded on fit, not as a gate. | `[grounded]` your statement, unprobed | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use. The checkout case study they liked is the inspectable artifact; I haven't read it. | `[grounded]` your statement; recruiter's reply | Send me the case study to read |
| R4a | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. | `[grounded]` your statement | none |
| R4b | Research calls with school owners | must_have | adjacent | medium | transferability | Same method, different audience: travel customers, not small-business owners. Limit: no sessions with business buyers. | `[inferred]` adjacency from R4a | Question 3 |
| R5 | Work directly with engineers | must_have | direct | medium | none | Four-engineer squad. | `[grounded]` your statement | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout within a squad. Limit: a shared flow in a larger product, not one you owned alone. | `[inferred]` adjacency from the checkout work | Question 1 |
| R7 | Work as the first designer, with no design peers | important | unclear | medium | discovery | You say you've never been the only designer anywhere. Nothing shows how you handled critique or decisions alone. | `[grounded]` your statement | Question 1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a flow alone (R6, R7) | transferability | Checkout redesign inside a squad; no solo ownership | Both are must-have or important and both will be probed | Side projects, freelance work, or a flow you drove and shipped with no designer reviewing it | Your case study, or a short write-up of who decided what | `[inferred]` from your background; `[generic]` that first-designer roles get probed hardest here |
| G2 | School-owner research (R4b) | transferability | Consumer usability sessions only | A named must-have in the posting | Any interview with a business owner, operator or buyer, even informal | Research notes or a sanitised interview guide | `[inferred]` adjacency |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First design hire, no design peers | risk_signal | medium | "our first design hire" | You may be the whole design function, with no one to review decisions | `[generic]` pattern for first design hires at small companies, not a claim about Fernquay | Who reviews design work today, and how are design decisions made? | unresolved |
| RR2 | Runway and equity basis not stated | unknown | — | "plus 0.5–1% equity" | Equity may be worth little without knowing the stage and runway | `[inferred]` from the posting's silence; the About page says it is "funded by its customers" | How much runway does the company have, and what is the equity's basis? | unresolved |
| RR3 | Scope and pay stated | positive_signal | — | "own the booking flow end to end"; "€52,000–€60,000" | The scope and pay are specific and checkable | `[grounded]` posting | What would you expect me to have shipped in my first 90 days? | noted |

The WhatsApp message is routine scheduling for an interview held on video, so it gets no register entry. Still, confirm the invite comes from the company's own address before you join.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp with a time. Check that the invite comes from the company's domain (the careers address is jobs@fernquay.example). | Scheduling by chat is routine; the invite is the thing to check | `[grounded]` careers page | pending your approval |
| A2 | Ask RR1, RR2 and RR3 verbatim on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Describe the checkout work as "redesigned the checkout flow in a squad." Don't say "owned it end to end." Name the limit (consumer travel, not school owners) before they ask. | Reframing audit: "owned" is a claim you can't yet back | `[inferred]` from R4b and R6 | pending your approval |

The call prep itself is mock-interview's job, so ask for that module when you want it.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" (fernquay.example/about, from the result snippet) and "Fernquay Product Designer careers Galway"; fetched fernquay.example/careers/product-designer. Moved: the company exists as described; the posting is live and matches the JD on pay, hybrid pattern and equity. No failed-attribution entry. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience software company" → Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Moved: the market calibration line, `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" → public profile (linkedin.example/in/ronan-kehoe). Moved: his public role as co-founder and CEO, and a prior product role at a Galway travel-software company. Saoirse was given without a surname, so I didn't search for her. |

I haven't read the checkout case study, so R3 and R6 stay at `medium`.

I can write this up as `tuesday-dossier.md` whenever you want it saved.

**Upgrade menu**

- Your own limits (lowest base, office days, contract type) → R1 and the hard-gates line close; the decision may move to `go`.
- The company's answer on who reviews design work → RR1 and R7 move.
- Runway and equity basis from the company → RR2 closes.
- The checkout case study, or a short write-up of it → R3 and R6 can move to `high`.
- A deeper pass on Fernquay (funding, news, past hires; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. Have you ever done design work with no other designer to review it? If not, how did you get critique and make calls on your own? (R6, R7)
2. What are your own limits: the lowest base you'd accept, how many office days you can do, and whether a fixed-term contract is a no? (R1)
3. Have you ever run a research session with a small-business owner rather than an end user? (R4b)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.