**Decision: `conditional_go`.** Yes, it's worth applying, and nothing I can check suggests it's a scam. The company exists, the posting is live and matches what you pasted, and the WhatsApp message is ordinary interview scheduling.

**Fit ledger**
- `hard_gate`: direct: R7 · unclear: R8 (Pay €52,000–€60,000 against your floor)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important`: adjacent: R6 (Research calls with school owners) · unclear: R9 (Working as the only designer)

Your product experience fits the role's stated requirements. The adjacent rows are where an interviewer will push: your checkout work is part of a booking flow, and your research was with travel customers, not school owners.

**Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**Opportunity ledger:** The employer checks out (RR4, RR5). The main open items are the equity terms (RR2) and what support a first designer gets (RR1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, founded 2023, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, funded by customers | `[grounded]` fernquay.example/about |
| Posting | Live on the company careers page, same terms as your paste (€52,000–€60,000, hybrid, equity) | `[grounded]` fernquay.example/careers/product-designer |
| Salary calibration | Median €57,000 for product designers with 3–5 years, IQR €51,500–€62,000. Ireland-wide, not Galway-specific | `[generic]` Tillerby 2026 report (n=520); posting figure `[grounded]` |
| Contradiction | About page names Saoirse as co-founder; the message calls them CTO. Probably both are true, so confirm on the call | `[grounded]` |
| Unknowns | Equity vesting, strike price and dilution; contract basis; how design decisions get made | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | none | Four years stated; intake self-report, no artifact yet | `[grounded]` your background |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use stated | `[grounded]` your background |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions stated | `[grounded]` your background |
| R4 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad stated | `[grounded]` your background |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is one part of a flow; end-to-end ownership not yet shown. Strengthener: the checkout case study with its outcome | `[inferred]` from your checkout work |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Your research was with travel customers; the buyer here is a business owner | `[inferred]` from the posting and your background |
| R7 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway; no non-negotiable stated | `[grounded]` posting and your background |
| R8 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | high | hard_gate | Your floor isn't given, so the fit can't be settled. Confidence grades the posting's figure, not your floor | `[grounded]` posting |
| R9 | Working as the only designer | important | unclear | low | discovery | Posting says "our first designer"; you've never been the only designer | `[inferred]` from the posting's "first designer" |

**Gap recovery queue**
- **R5 (transferability):** Checkout is a strong bridge, but it doesn't show you owning discovery through to launch. Closing it means a second flow or a project where you ran the whole loop.
- **R6 (transferability):** Your research was with consumers. Closing it means showing you have dealt with business customers, even informally.
- **R9 (discovery):** You have no direct evidence of working alone as the design function. The question for this row is below.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First designer, with no design peers | risk_signal | medium | "You would be our first designer" | You may carry design decisions alone, with no review or research budget | `[inferred]` from the posting's silence on design support | Who reviews design decisions day to day, and what is my budget for research tools and participant incentives? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Value depends on vesting, strike price and future dilution | `[inferred]` from the posting's silence on terms | What is the vesting schedule, what is the strike price, and what funding would dilute it? | unresolved |
| RR3 | Contract basis unstated | unknown | — | Not stated in posting | Unknown whether the role is permanent | `[inferred]` from the posting's silence | Is this a permanent contract? | unresolved |
| RR4 | Stated pay sits in the market band | positive_signal | — | "€52,000–€60,000" | Pay is at or near market for a 3–5 year designer | `[generic]` band; `[grounded]` posting | What is the basis for the range, and is there room above €60,000? | noted |
| RR5 | Outcomes and access | positive_signal | — | "run research calls with school owners … ship alongside our two engineers" | Named outcomes and direct engineering access suggest real scope | `[grounded]` posting | — | noted |

The WhatsApp message asking for a call, and the email invite, are routine interview scheduling. They get no register entry.

**Application plan**
- **Submit the checkout case study with outcome numbers, if you have them.** The company already said they liked it. Pending your approval.
- **Prepare answers for R5, R6 and R9 before the call.** Pending your approval.
- **Put RR1 and RR2 to Ronan and Saoirse on the call.** Pending your approval.

**Evidence status**
Verified: none yet. Your background is self-report until you give a specific answer I can confirm.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay careers Product Designer"; fetched fernquay.example/careers/product-designer (posting live, matches your paste) and fernquay.example/about (entity exists). Moved the organization row and cleared the attribution check |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 2026 typical range" → Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Moved the salary calibration `[generic]`; not Galway-specific |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" → public profile snippet (linkedin.example/in/ronan-kehoe): co-founder and CEO at Fernquay, previously product lead at a Galway travel-software company for five years. Snippet only; page not fetched |

Each of the four searches and two fetches above is named by its query or address.

**Dossier offer:** I can save this as `tuesday-dossier.md` if you want it kept for the call.

**Upgrade menu**
- Your floor salary and whether permanent contract is a requirement → R8 and RR3 close.
- The checkout case study with its outcome → R5 moves toward `direct`.
- One example of research with a business customer → R6 moves toward `direct`.
- The recruiter's answer on equity terms → RR2 closes.

**Questions**
1. R8: Is €52,000 your floor, and is a permanent contract a requirement for you?
2. R9: When you've needed to make a design call with no one to check it with, what did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.