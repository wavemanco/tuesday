**Short answer:** The Duinvaart role is worth applying to once one question is answered: can you work in the Rotterdam office three days a week? The Kroonhaven role is not worth your application time as written: it asks for years of supply planning and a planning system you haven't used.

Web search was refused by the permission setting, so nothing below about either company is checked against the public web. I did not retry. If you allow WebSearch, I can run the employer and pay checks.

---

# Role 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Worth applying to, once one answer is in. Status: `hold_pending_answers`.** Your background matches the analyst work closely. The hold is on the hybrid office requirement, which the posting makes a hard gate and your constraints don't settle.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (hybrid, three office days a week in Rotterdam)
  - `must_have`: direct: R2 (2+ years in logistics or ops analysis), R3 (strong SQL), R4 (Power BI or Tableau), R5 (on-time delivery tracking), R7 (weekly Power BI dashboards), R8 (depot manager route work)
  - `important`: unclear: R6 (temperature compliance, refrigerated fleet)
  - `preferred`: adjacent: R9 (Dutch, conversational)
- **Hard gates:** none failed; unconfirmed: R1 (hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** The posting is specific and read as a real analyst role (RR3). The open items are unverified employer details and no stated pay (RR1, RR2).
- **Severe red flags:** none found.
- **What would change this:** if you can do three office days in Rotterdam, the status moves to `conditional_go`, on the condition that the posting checks out on the company's own careers page. If the office days are impossible, R1 becomes `hard_gate_fail` and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Scope read | Analyst remit with a reporting and route-influence component; normal for the title | `[inferred]` from the listed duties |
| Market calibration | Not run: search refused, so no pay or scope band | — |
| Pay | Not stated | `[grounded]` posting is silent |
| Unknowns | Employer and posting not verified; pay; how much day-to-day work is cold-chain specific; who decides route changes | — |
| Contradictions | None visible in the pasted text | `[grounded]` |

## Evidence map

Your background is prose, which counts as self-report, so confidence tops out at `medium` until you send a CV or an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | No statement from you on commuting or relocating | `[grounded]` posting; your constraints not given | Q1 below |
| R2 | 2+ years in logistics or ops analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier | `[grounded]` your background (self-report) | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | none |
| R5 | Track on-time delivery | must_have | direct | medium | none | You built the on-time delivery dashboard depot managers used | `[grounded]` your background | none |
| R6 | Track temperature compliance, refrigerated fleet | important | unclear | none | discovery | Nothing in your background touches temperature | `[grounded]` absence in your background | Q2 below |
| R7 | Build weekly dashboards in Power BI | must_have | direct | medium | none | Same tool, same reporting cadence | `[grounded]` your background | none |
| R8 | Work with depot managers on route changes | must_have | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background; `[inferred]` that it transfers to route changes | none |
| R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: not enough for a fluent-Dutch job | `[grounded]` your statement | none |

**Gap queue.** Gaps are recovery items; their questions are in the closing block.
- **G1 (R1, hard_gate):** Whether you can commit to three office days in Rotterdam. Closes the hold.
- **G2 (R6, discovery):** Any temperature-controlled or regulated-transport exposure, even reading temperature logs. Could move R6 from `unclear` to `direct`.
- **G3 (R9, transferability):** Limit to state plainly: conversational Dutch, not fluent Dutch. Strengthener: any written Dutch sample.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | "(no pay in posting)" | The role may pay below your expectations, or the employer may simply not publish pay | `[inferred]` from the posting's silence on pay | What is the pay range for this role? | unresolved |
| RR2 | Employer and posting not verified | unknown | — | Company name and "Operations Analyst" in the posting | Research was refused, so this is unchecked, not failed. Verify before investing effort | `[generic]` standard pre-application check | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |
| RR3 | Scope and outcomes are specific | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Defined remit with named tools and duties | `[grounded]` posting | Who sets the on-time and temperature targets this role reports against? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the three-days-a-week office requirement before applying | Closes R1 and the hold | `[grounded]` R1 | pending your approval |
| A2 | Check the posting on Duinvaart's own careers page before applying | Verifies RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Lead with the on-time delivery dashboard and the route-performance review | These are your strongest direct matches (R5, R7, R8) | `[grounded]` R5, R7, R8 | pending your approval |
| A4 | Describe the route review as a performance review you ran, not as route planning or capacity planning | Reframing audit, kind axis: planning is a different kind of work from reviewing | `[grounded]` your statement | pending your approval |
| A5 | Describe your Dutch as "conversational", in those words | Logical form: "fluent" would overstate it | `[grounded]` your statement | pending your approval |

---

# Role 2: Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**Not worth applying to as written. Status: `no_go`.** The core of the job is planning: a 13-week plan, capacity balanced against forecast, and a planning system. Your background has none of these. Your background does match the S&OP meeting format, but that alone does not carry the role.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (on-site in Utrecht)
  - `must_have`: direct: none; adjacent: R6 (fluent Dutch, you are conversational); absent: R2 (3+ years FMCG supply or demand planning), R3 (own the 13-week plan and balance capacity against forecast), R4 (SAP IBP or similar); unclear: R5 (advanced Excel)
  - `important`: adjacent: R7 (run the weekly S&OP meeting)
- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** The posting is clear about scope (RR3). Pay is not stated (RR1), and the employer is unverified (RR2). Neither is a red flag.
- **Severe red flags:** none found.
- **What would have to differ:** 3+ years of planning experience, or hands-on planning-system experience, plus fluent Dutch. Without those, the realistic path is a junior or planning-adjacent role rather than this posting.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Scope read | A mid-level planning role; the 3+ year bar is what the posting sets | `[inferred]` from the listed duties and stated bar |
| Market calibration | Not run: search refused | — |
| Pay | Not stated | `[grounded]` posting is silent |
| Unknowns | Employer and posting not verified; pay; the forecasting method and planning tools in use | — |
| Contradictions | None visible in the pasted text | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on commuting | `[grounded]` posting | Q1 is about the Rotterdam role; this gate is moot if R2–R4 stay absent |
| R2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | transferability | You have no planning years. Closest adjacent work is operational analysis of volumes and performance, not planning | `[grounded]` your statement; `[inferred]` adjacency | Closure path: a junior planning role first |
| R3 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | No credible evidence of planning or capacity balancing | `[grounded]` your statement | Closure path: a planning course and a junior role |
| R4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system experience stated | `[grounded]` your statement | Closure path: a tool-specific course |
| R5 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned in your background | `[grounded]` absence | Q3 below |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Limit: not enough to run a Dutch-language S&OP | `[grounded]` your statement; `[inferred]` that the S&OP runs in Dutch | none |
| R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran the weekly route-performance review: the same weekly cadence and stakeholder format | `[grounded]` your background; `[inferred]` the format transfers | none |

**Gap queue.** The questions are in the closing block.
- **G1 (R2, transferability):** The limit is absent planning years. Strengthener: any forecast you produced, even in a spreadsheet.
- **G2 (R3–R4, capability):** Closure path: a junior planning role plus a planning-system course. Carried as a material risk.
- **G3 (R5, discovery):** Whether you have used Excel for forecasting or modelling.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | "(no pay in posting)" | Pay may sit below your expectations, or it may simply not be published | `[inferred]` from the posting's silence | What is the pay range for this role? | unresolved |
| RR2 | Employer and posting not verified | unknown | — | Company name and role title | Research was refused, so this is unchecked, not failed | `[generic]` standard pre-application check | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |
| RR3 | Scope is specific | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | Defined remit, named duties | `[grounded]` posting | Which planning tool does the team use today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Do not apply to this posting as written | R2, R3, R4 are absent; no realistic closure within this posting | `[inferred]` from the evidence map | pending your approval |
| B2 | Target junior or planning-adjacent roles instead (demand planning, S&OP coordinator, planning analyst) | These match R7 and your analysis background | `[inferred]` from R2, R3, R7 | pending your approval |
| B3 | Do not describe route-review work as demand or supply planning | Reframing audit, kind axis | `[grounded]` your statement | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page, Duinvaart | unavailable | Search refused. Would have checked the entity, whether the posting is live, and the pay band (RR2) |
| 1. Official site and careers page, Kroonhaven | unavailable | Search refused. Would have checked the same for this posting (RR2) |
| 2. Role-family sweep (supply-planning pay and scope) | unavailable | Search refused. Would have set the market calibration for both titles and pay (RR1 for both) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- **Your CV or resume** → lifts R2–R5 and R7 from self-report toward `high` once claims can be checked. Adds the strongest evidence you can give for the Duinvaart role.
- **An anonymised screenshot of the on-time delivery dashboard, with client data removed** → raises R5 and R7 to `high`.
- **Permission to run web search** → verifies both employers, the posting, and the pay bands (RR1, RR2 for both roles).
- **Your commute or relocation position** → closes R1 for Duinvaart and Kroonhaven.
- **A Dutch certificate, or a short written sample in Dutch** → moves R6 (Kroonhaven) and R9 (Duinvaart) from `medium` toward `high`.

If you want, I can write this up as a `tuesday-dossier.md` you can keep and reuse.

Questions, one per gap:

- **Q1 (R1, Duinvaart):** Can you commit to three office days a week in Rotterdam, and what is your commute from where you're based?
- **Q2 (R6, Duinvaart):** Have you done any work with temperature-controlled or regulated transport, even reading temperature logs?
- **Q3 (R2/R3, Kroonhaven):** At the carrier, did you ever forecast volumes or plan capacity for upcoming weeks, even in a spreadsheet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.