**Worth applying, with conditions. Status: `conditional_go`.**

Yes, this is a real employer, and the posting matches its own website. Fernquay exists as described, and its careers page carries the same salary, hybrid pattern and equity range. The request to talk by video is routine, and I don't read anything suspicious into it. The open items are pay, equity terms and how much support you'd have as the only designer.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (own the booking flow end to end)
- `important` — adjacent: R8 (research calls with school owners), R9 (first and only designer)

R7 — adjacent: your checkout work is real, but it sat inside a squad. R9 — adjacent: you've never been the only designer.

**Opportunity ledger.** The employer is established (RR1, positive signal). The equity terms are undefined (RR2, unknown), and the scope leaves the design-support question open (RR3, unknown).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your pay floor sits within €52,000–€60,000 (R2); (2) the equity terms hold up when you ask about them (RR2); (3) you're comfortable being the only designer, or you've had a version of that before (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software for sea-kayak, surf and sailing schools; six people in Galway; founded 2023 with Ronan Kehoe and Saoirse Doyle | `[grounded]` fernquay.example/about |
| Mandate | Own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Market calibration | Ireland 2026 survey, product designers with 3–5 years: median base €57,000, interquartile range €51,500–€62,000; the posted €52,000–€60,000 sits inside that range | `[generic]` role-family sweep, tillerby.example (search snippet, not fetched); not this employer's offer |
| Unknowns | Equity vesting, option type and strike price; Saoirse's role (the WhatsApp message says CTO; the about page names her as co-founder and gives no title); decision rights and research budget | — |
| Contradictions | None between the posting, the careers page and the about page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; self-reported, so medium | `[grounded]` your intake | none |
| R2 | Salary €52,000–€60,000 (pay gate) | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so nothing to grade | `[grounded]` posting | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years, self-reported; a length requirement, graded on fit, not a gate | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; the checkout case study is the artifact to show | `[grounded]` your intake | none |
| R5 | Has run own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your intake | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your intake | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign in travel booking, inside a team; never shown owning the whole flow alone. Limit: not end-to-end ownership | `[inferred]` from your checkout work | Bridge case in the application; the checkout write-up would confirm it |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Customer usability sessions transfer; your customers' type isn't stated. Limit: no business-owner research | `[inferred]` from your sessions | Name the customer type in the application |
| R9 | First and only designer (inferred from "our first designer") | important | adjacent | medium | discovery | Designed in a squad with engineers; you've never been the only designer | `[inferred]` from your intake | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Provenance |
|---|---|---|---|---|---|
| G1 | Salary (R2, hard_gate) | hard_gate | No floor stated | Pay is a gate; the posted band sits inside the market range, so the answer is probably yes | `[grounded]` posting; `[generic]` market band |
| G2 | First and only designer (R9) | discovery | No evidence of working without design peers | Would move R9 toward direct | `[inferred]` from your intake |
| G3 | Owning the booking flow (R7) | transferability | Checkout work sat inside a squad | Your limit is named; the case study can narrow it | `[inferred]` |
| G4 | School-owner research (R8) | transferability | Customer type not stated | Name it to close the gap | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established, posting live and consistent | positive_signal | — | "Open now: Product Designer, our first design hire." | The role is real and matches the employer's own site | `[grounded]` careers page and about page | Can you send the interview invite from the company address on the careers page? | noted |
| RR2 | Equity without terms | unknown | — | "plus 0.5–1% equity" | The equity may be hard to value without vesting or strike terms | `[generic]` pattern for early-stage equity | What are the vesting schedule, option type and strike price, and how is the 0.5–1% range set? | unresolved |
| RR3 | Sole designer, support undefined | unknown | — | "You would be our first designer: own the booking flow end to end" | You may carry the booking flow's outcomes without a say in priorities or research time | `[inferred]` from the scope language against its silence on decision rights | Who sets booking-flow priorities, and what time and budget do I get for school-owner research? | unresolved |

The WhatsApp invitation to a video call is routine scheduling by chat for an interview held elsewhere. It takes no register entry and no condition.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the video call only once the invite arrives from a fernquay.example address; if unsure, check with jobs@fernquay.example | Confirms the contact through the employer's own domain | `[grounded]` careers page | proposed |
| A2 | Bring one real project, messy parts included, not a polished deck | The posting asks for this | `[grounded]` posting language | proposed |
| A3 | Ask RR2 and RR3 verbatim on the call | The register doubles as prep | `[grounded]` register | proposed |
| A4 | Frame R7 and R9 as adjacent, with the limit named | Honest framing holds up better under questions | `[inferred]` | proposed |

## Evidence status

Verified: none yet. Your claims rest on your intake and will be probed.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (fernquay.example/about) and "Fernquay Product Designer careers Galway" (fernquay.example/careers/product-designer); fetched the careers page. Moved RR1: the employer exists and the posting is live |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience scale-up", which returned the Tillerby 2026 Ireland design salary report. Moved the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned linkedin.example/in/ronan-kehoe: co-founder and CEO, previously product lead at a Galway travel-software company for five years. Public roles only; Saoirse Doyle was not searched |

## Upgrade menu

- Your checkout case study, the one the company liked → R7 and R5 could move to `high` once I read it; paste it or a link.
- Your pay floor → R2 closes.
- Equity terms from Ronan → RR2 closes.
- A deeper pass on Fernquay (funding, past hires, news; up to 5 more searches and 2 more fetches) → say the word and it runs.

Questions, one for each of the two gaps that could change the decision:

G1 — Does a base of €52,000 meet your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you ever done design work with no other designer to review or pair with? What did you do, and what did you not get to do? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.