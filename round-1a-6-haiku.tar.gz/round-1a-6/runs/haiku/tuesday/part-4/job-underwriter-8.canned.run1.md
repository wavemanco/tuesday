**No, don't go ahead, and send nothing yet.** Status: `no_go`.

I'm going only on what you've shared. The posting and the messages ask for bank details, a passport and a PPS number before any offer, and ask you to pay for equipment and to deposit and forward a cheque. The hiring runs only on Telegram. The fit with your background is not the problem: the opportunity is.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R3 (Confident with spreadsheets); adjacent: R2 (Strong attention to detail); unclear: R4 (Good written English)
- `important`: adjacent: R5 (Order processing)

R3 and R5 are your strongest matches. R4 is unsettled by anything you've given me.

**Opportunity ledger.** Four severe red flags are confirmed from the messages themselves: RR1, RR2, RR3 and RR4. Each one alone is enough to stop. RR5 and RR6 add uncertainty about the employer and the pay.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the employer, reached through contact details from its own website, would have to show each request above is not part of its process, and show a live role with written hours and pay. Until then, no.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. No public footprint found under that name | `[grounded]` search returned no results |
| Pay | €26 an hour plus commission, for 15–30 hours a week. That is €20,280–€40,560 a year at 52 weeks | `[grounded]` posting; `[inferred]` arithmetic |
| Pay against your floor | Your €30,000 is reached only at about 22 hours a week, before commission | `[inferred]` from the posted rate |
| Market | Pennoral's 2026 Ireland guide puts order-processing and customer-operations coordinators at a median €31,200 a year, salaried roles only | `[generic]` one pay guide |
| Process | Telegram only, no calls or video, offer and payment requests in chat | `[grounded]` posting and messages |
| Contradictions | Posting says training is provided, yet asks you to pay €349 for kit; says there are no calls, yet asks for bank and ID details before any offer | `[grounded]` posting and messages |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your stated floor) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The posting's hours and commission don't settle it | `[grounded]` your statement; `[inferred]` arithmetic | none; the employer would need to state hours and commission in writing |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | 60 tickets a day and the weekly tracker are credible proxies; nothing inspected | `[inferred]` from your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly Excel tracker; no file inspected | `[grounded]` your intake message | none |
| R4 | Good written English | must_have | unclear | low | discovery | Your intake message is the only sample here | `[grounded]` absence of other material | none; not a deciding factor |
| R5 | Order processing | important | adjacent | medium | transferability | Three years of parcel-courier customer service, Zendesk. Not order processing; no order-entry or commission work exercised | `[inferred]` bridge from your background | none |

**Gap recovery queue.** R1 is the only `hard_gate` gap, and it is surfaced above, not worked around. R4 is a `discovery` gap that doesn't move the decision.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | Employers don't normally ask for bank and passport details before a written offer; once sent, these can't be recalled | `[generic]` pattern for requests like this | Does your payroll need my bank and ID details before any written offer? | confirmed |
| RR2 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Paying for kit, and refunds promised later, is a known way money is taken from applicants | `[generic]` pattern | Do you ever ask a new hire to pay for their own equipment? | confirmed |
| RR3 | Cheque deposit and forwarding money | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner" | A cheque can bounce after the money is passed on, leaving you out of pocket | `[generic]` pattern | Will you ever ask me to deposit a cheque and send part of it to a third party? | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The interview and offer happen only in chat, which leaves nothing to check the process against | `[grounded]` posting and messages | Can you show the interview and offer process on your own website, with a named contact? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR6 | Pay below your floor | risk_signal | medium | "up to €26 an hour plus commission … 15–30 a week" | The posted hours and rate may not reach €30,000, and commission is unquantified | `[inferred]` arithmetic against your floor; `[generic]` band | What are the weekly hours and the commission basis, in writing? | unresolved |

**Hold.** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. Don't paste your IBAN, PPS number or passport anywhere in these messages.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't send your IBAN, PPS number or passport | RR1 | `[generic]` RR1 pattern | your call |
| P2 | Don't pay for equipment or deposit or forward the cheque | RR2, RR3 | `[generic]` RR2, RR3 patterns | your call |
| P3 | Put your effort into openings you find on employers' own careers pages | RR5, RR4 | `[generic]` pattern | your call |

**Evidence status.** Verified: R1 (your own stated floor). Everything else in your background is unprobed intake prose and stays at `medium` at most.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results. Employer not established; RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland part-time": Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration `[generic]`; RR6 band |
| 3. Hiring manager's public footprint | n/a | No person's name was given; the handle is not one |

If you want this kept for later, I can save it as a `tuesday-dossier.md` file.

**Upgrade menu**

- An employer's careers page or a live posting, with contact details you find on that employer's own website, would close RR5. It would not clear RR1–RR4 on its own.
- A written answer from the employer on each request in RR1–RR3 would move those rows. The decision stays `no_go` unless each one is withdrawn.
- Written hours and commission terms would settle R1 and RR6.
- An L2 deep pass on the firm (up to 5 more searches and 2 more fetches) is available if you want it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.