This is a job-posting vetting question, so I'll load the job-underwriter module.
The playbook requires several reference files before the first-pass assessment. I'll read them together.
The playbook calls for L1 research: company site and careers page, a role-family pay sweep, and the named co-founder's public footprint. Running the searches in parallel.
**Short answer: worth applying, but I couldn't verify the company from here.** Web search was refused in this session, so I can't yet confirm Fernquay exists as described or what the salary band is. Nothing in the posting or the messages asks you for money or bank details.

**Decision snapshot**

Yes, it's worth applying to, on conditions: `conditional_go`. Your experience matches the three-plus years, Figma, research and engineering requirements well. The open risks are being the only designer and whether the €52,000–€60,000 pay works for you. On legitimacy, the company check didn't run, so that part is still open.

- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2
  - `must_have`: direct: R3, R4, R5a, R7 · adjacent: R5b, R6
  - `important`: unclear: R8
  - R5b (`medium`) and R6 (`medium`) are adjacent with the limits named. R1 is direct and R2 is unclear because your pay floor was not given.
- **Opportunity ledger.** Clear scope and a named team (RR4, positive). The main risks are a solo design role with no design peers (RR1) and a pay band with no sign of how it was set (RR2). The company itself is unverified (RR3).
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your pay floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and this role check out on their own website (RR3); (2) the pay works against your floor and the band (R2, RR2); (3) you're comfortable being the only designer (R8, RR1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools; two engineers, a CTO (Saoirse) and co-founder (Ronan Kehoe) named | `[grounded]` posting and message |
| Role | First designer: own the booking flow end to end, run research calls with school owners, ship with engineers | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Scope read | A first-hire role with no design peers; the booking flow is a whole-product ownership claim, larger than a single checkout | `[inferred]` from "first designer" against "own the booking flow end to end" |
| Market calibration | Not checked: the band search was refused | — |
| Unknowns | Pay band basis, who reviews design decisions, whether the company and role are live | — |
| Contradictions | None found in the material you gave; the careers page was not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Self-report, nothing to inspect | `[grounded]` your background | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your floor wasn't given, so fit can't be read; the band is unchecked | `[grounded]` posting | Q1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Length requirement, so not a gate | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file to inspect yet | `[grounded]` your background | Offer: a Figma file or portfolio would raise to high |
| R5a | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers that you ran | `[grounded]` your background | none |
| R5b | Research calls with school owners | must_have | adjacent | medium | transferability | Your research was with travellers (consumers), not business owners | `[inferred]` from your customer sessions against the posting's owner calls | Q3 |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout inside a squad: the end of the flow, not the whole | `[grounded]` your background; `[inferred]` the gap | Q2 |
| R7 | Work directly with engineers, ship alongside | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your background | none |
| R8 | First designer: set direction with no design peers | important | unclear | low | discovery | You've never been the only designer; not yet shown either way | `[grounded]` your background | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Owner research (R5b) | transferability | Consumer research only | Likely first question from a founder | A short owner-interview summary or plan | `[inferred]` bridge from your customer sessions |
| G2 | End-to-end ownership (R6, R8) | transferability | Checkout ownership inside a squad | The job is whole-flow ownership with no peer | A checkout write-up with your decisions marked | `[grounded]` your background |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo design role | risk_signal | medium | "you would be our first designer" | Design decisions may go unreviewed | `[inferred]` from the first-designer wording | Who reviews design decisions day to day, and what's already been decided? | unresolved |
| RR2 | Pay band basis unknown | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may sit below or within the market | `[generic]` market band not checked this run | How was the €52,000–€60,000 band set, and where does someone at my experience start? | unresolved |
| RR3 | Employer and role not verified | unknown | — | "Fernquay. We are six people in Galway" | Not checked: search refused. This is unknown, not a finding against the company | `[inferred]` from the refused search | Can you point me to this role on Fernquay's own careers page? | unresolved |
| RR4 | Clear scope and named team | positive_signal | — | "two engineers … our CTO, Saoirse" | Named roles and a concrete brief | `[grounded]` posting | What would the first 90 days look like for the design hire? | noted |

Scheduling by WhatsApp, with a calendar invite and a video call, is a routine step. It gets no register entry.

**Application plan** (all proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Fernquay's own website and check Ronan and Saoirse appear there | RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Before the call, check the invite comes from a Fernquay address that matches the website | Routine check; advice only | `[generic]` common practice | pending your approval |
| A3 | Ask for the pay range in writing before the call | R2, RR2 | `[generic]` early pay disclosure is common | pending your approval |
| A4 | Lead with the checkout work and say which parts were yours | R6 | `[grounded]` your background | pending your approval |
| A5 | Rehearse the "only designer" answer: what you would do with no review | R8, RR1 | `[inferred]` from the posting | pending your approval; mock-interview can drill it |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four web searches were refused (permission not granted), so the site was not read. Would have checked RR3 |
| 2. Role-family sweep | unavailable | Would have set the market band for R2 and RR2 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, so a query could be formed, but the search was refused. Would have checked the team |

**Dossier offer:** I can save this as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Web search access → reruns targets 1–3: the company's own site, the salary band, and Ronan Kehoe's public professional footprint. This closes RR3 and sharpens RR2.
- Your pay floor, and whether two office days in Galway are firm → closes R1 and R2 and the hard-gate line.
- A Figma file, portfolio, or the checkout case study → R4 and R5a to high.
- Any owner research or B2B work → R5b.

**Questions**

Q1 (R2, hard gates): Is there a pay floor below which you won't go, and is two office days a week in Galway workable, or is either non-negotiable?

Q2 (R6, R8): Think of one checkout decision. Who made the final call, and was any of it yours alone, with no lead or peer reviewing it?

Q3 (R5b): Have you ever run research calls with business owners rather than end customers? If so, what did you learn about running them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.