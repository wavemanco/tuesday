**Yes, asking for bank details, a PPS number and a passport scan through the employer's own portal, after a written offer like this one, is routine. It is not a warning sign.** On the job itself: `conditional_go`, on the conditions below.

**Fit ledger.**
- `hard_gate`: direct: R3 · unclear: R1 (Limerick office two days a week), R2 (€40,000 against your pay floor)
- `must_have`: direct: R4 (2+ years running payroll), R6 (monthly reconciliation to the ledger), R7a (starters and leavers) · adjacent: R10 (monthly run for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R8 (Excel) · absent: R7b (pension changes)
- `preferred`: direct: R9 (payroll qualification or working towards)

R5 (`low`) is the must-have the material leaves unsettled; R7b has no evidence of your own yet, so a question closes it; R10 is a bridge, with its limit named.

- **Hard gates:** none failed (R3 `direct`); unconfirmed: R1 (Limerick office two days a week), R2 (€40,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate is confirmed through contact details on its own website, not the email (RR1); (2) you show working knowledge of Irish statutory payroll (R5); (3) you confirm the two office days and your pay floor (R1, R2); (4) you read the written contract and pension scheme before accepting (R7b, RR2).

**Opportunity ledger.** The offer is concrete: it names the role, pay, a permanent post, the hybrid pattern and a reporting line (RR3). The open items are the employer's public footprint, which I could not check in this session (RR1), one post's scope against 240 staff with no team named (RR2), and the pay against the market (RR4).

**Your question, answered.** Your rule is right about giving these details to someone unverified, before an offer, or through a chat. After a written offer that names the role and pay, payroll and right-to-work checks need them, and that is routine [generic]. The check that matters is where you enter them: only in the portal at the address Marrowgate's own website gives, never by replying to the email or attaching scans.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` job ad |
| Role | Permanent Payroll Administrator, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer |
| Pay | €40,000 offered; the ad's band is €38,000–€42,000 | `[grounded]` offer and ad |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` offer and ad |
| Process | Two in-person interviews at their office | `[grounded]` your account |
| Market calibration | Not run: the salary search was not permitted, so the ad's own band is the only figure in hand | `[grounded]` session record |
| Unknowns | Team around the role; pension scheme; who approves pension changes | — |
| Contradictions | None between the ad and the offer | `[grounded]` ad and offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Limerick office two days a week | hard_gate | unclear | none | hard_gate | Your location and commute are not in the material | `[grounded]` offer; constraint not given | Question Q3 |
| R2 | €40,000 against your pay floor | hard_gate | unclear | none | hard_gate | Your floor is not in the material; the offer sits inside the ad's band | `[grounded]` offer and ad | Question Q3 |
| R3 | Permanent post | hard_gate | direct | medium | none | The offer names the post as permanent; the contract itself is unseen | `[grounded]` offer | Read the contract (A2) |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; your account, not inspected | `[grounded]` intake | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your message does not say which statutory rules you have run, or whether the 2024 certificate covered Irish rules | `[grounded]` intake silence | Question Q1 |
| R6 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done monthly for three years | `[grounded]` intake | none |
| R7a | Starters and leavers | must_have | direct | medium | none | Done in the hotel group | `[grounded]` intake | none |
| R7b | Pension changes | important | absent | none | discovery | Your manager handled these; none of your own | `[grounded]` intake | Question Q2 |
| R8 | Strong Excel | important | direct | medium | none | Daily use; pivot tables and XLOOKUP named | `[grounded]` intake | none |
| R9 | Payroll qualification or working towards | preferred | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` intake | Certificate copy, optional |
| R10 | Monthly payroll run for 240 staff | must_have | adjacent | medium | transferability | You run fortnightly for 90. Limit: monthly cycles and the larger population are not yet exercised. Strengthener: a sample run summary | `[inferred]` bridge from your fortnightly run; `[generic]` that monthly runs share the same mechanics | Sample run summary, upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R5, must_have) | discovery | Your message names no Irish PAYE, PRSI or USC work | This must-have decides whether the role is credible on day one | Live PAYE/PRSI/USC runs; year-end returns; a Revenue query you handled | Payslip structure, a year-end checklist, the certificate's syllabus | `[grounded]` intake silence; `[generic]` that Irish statutory work is the usual test here |
| G2 | Pension changes (R7b, important) | discovery | You have not run pension changes yourself | The ad lists them as a duty | Enrolments, contribution changes, opt-outs, scheme remittances, pension queries answered for staff | A change form, a remittance report, a scheme booklet | `[grounded]` intake; `[inferred]` that the ad's list makes this a real duty |

The queue holds no questions; the closing block asks them, tagged to their rows.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing People Team" | Web checks were not run, so the employer's public footprint is unverified. The in-person interviews point the other way, but they are your account, not a check | `[generic]` pattern for organizations of this size, not a claim about this one; the refused search is the reason, `[grounded]` session record | Can you point me at this role on your own careers page? | unresolved |
| RR2 | Scope with no stated team | unknown | — | "Run the monthly payroll for our 240 staff … reconcile payroll to the general ledger" | The post may be the only payroll role for 240 staff, or sit beside a payroll manager the ad does not name | `[inferred]` from the ad's duty list against its silence on team | Who else works in payroll, and who approves pension changes and signs off the monthly ledger reconciliation? | unresolved |
| RR3 | Named reporting line and concrete duties | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | The authority line is stated and the duties are specific | `[grounded]` offer and ad | What does a normal month look like for this post, from the first run to ledger sign-off? | noted |
| RR4 | Pay not calibrated against the market | unknown | — | "€40,000 a year" | The offer sits inside the ad's own band; whether that band fits Limerick payroll pay is unchecked | `[grounded]` offer and ad; the market band is not run | How was €40,000 set for this post, and when is pay next reviewed? | unresolved |

**Severe red flags:** none found. The bank, PPS and passport requests are routine steps, so they carry no entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before replying, check the people@ address against the domain on Marrowgate's own website, and confirm the offer by calling the switchboard listed there, not a number from the email | RR1 | `[generic]` practice for verifying any offer | pending your approval |
| A2 | Ask the People Team for the written contract, the pension scheme booklet and the working pattern before you accept | R3, R7b, RR2 | `[grounded]` offer invites questions by reply | pending your approval |
| A3 | Enter bank, PPS and passport details only in the portal at the address on Marrowgate's website; never attach scans to an email | Routine steps, handled safely | `[generic]` practice | pending your approval |
| A4 | Treat the five-working-day window as the time to ask A2's questions; the ask is normal before accepting | Offer terms | `[grounded]` offer's five-day line | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Marrowgate's own site and careers page were refused; this session did not permit web search, so I did not retry. Would have moved RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search for Limerick payroll-administrator pay was refused. Would have moved RR4 and the market calibration line |
| 3. Hiring manager's public footprint | unavailable | One search for Declan Garvagh was refused. Would have moved the scope read in RR2 and the questions to ask |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep.

**Upgrade menu:**
- Allowing web search lets me run the three checks above, which would settle RR1 and RR4.
- Your pay floor and whether you can attend the Limerick office two days a week close R1 and R2.
- A copy of the 2024 certificate's syllabus, or any Irish statutory payroll work, raises R5.
- The written contract and pension scheme booklet close RR2 and R7b.

**Questions:**
- Q1 (G1, R5): Have you run Irish PAYE, PRSI and USC in live payrolls, and was your 2024 Payroll Technician certificate an Irish one?
- Q2 (G2, R7b): Have you touched any pension element of payroll, such as enrolment, contribution changes, opt-outs or scheme remittances, even if your manager made the final call?
- Q3 (R1, R2): Can you work two days a week in the Limerick office, and is €40,000 above the pay you need?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.