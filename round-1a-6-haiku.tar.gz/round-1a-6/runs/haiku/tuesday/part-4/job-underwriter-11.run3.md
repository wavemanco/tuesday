## Decision snapshot

**Role 1, Operations Analyst at Duinvaart Cold Chain: `conditional_go`.** Worth applying. Your SQL, Power BI and depot-facing work is most of what the posting asks for. The conditions are the employer check and the cold-chain and commute questions below.

- **Fit ledger:** `must_have`: direct on 2+ years in ops analysis, strong SQL, and Power BI; direct on on-time delivery tracking; adjacent on route changes with depot managers; absent on temperature-compliance tracking. `preferred`: adjacent on Dutch (conversational).
- **Hard gates:** none failed on what you've told me. Unconfirmed: the three-day Rotterdam week. You didn't give your constraints, so I can't check them.
- **Severe red flags:** none in the posting.
- **Conditions for go:** (1) confirm the posting is live and the employer is as described; (2) you can live with the Rotterdam commute; (3) you present temperature work as transferable, not as cold-chain experience.

**Role 2, Supply Planner at Kroonhaven Foods: `no_go` for now.** Not worth your first application slot. The posting asks for skills you've said you don't have, and two of them are central.

- **Fit ledger:** `must_have`: absent on 3+ years of FMCG planning, and absent on SAP IBP or a similar system. Adjacent on the weekly review format, but not on planning itself. Unclear on advanced Excel, which your background doesn't mention. `preferred` level not applicable. Fluent Dutch is `must_have`, and you're conversational, so it's adjacent at best.
- **Hard gates:** none stated as failed. Unconfirmed: on-site Utrecht, since your constraints weren't given.
- **Severe red flags:** none in the posting.
- **Facts that would have to differ:** about three years of planning or supply experience, and fluent Dutch. A planning-adjacent step, such as demand analysis or forecast-accuracy work, would be the realistic route in.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: organization | Cold-chain operator with a refrigerated fleet and a Rotterdam office | `[grounded]` posting only; not checked online |
| Duinvaart: scope | Fleet KPIs, weekly dashboards, route changes with depot managers | `[grounded]` posting |
| Duinvaart: working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` posting |
| Kroonhaven: organization | FMCG food producer, chilled ready-meals, Utrecht | `[grounded]` posting only; not checked online |
| Kroonhaven: scope | 13-week supply plan, capacity balancing, runs the weekly S&OP | `[grounded]` posting |
| Salary, both roles | Not listed | `[grounded]` posting silent |
| Market calibration | Not run. Research was unavailable, so I have no sourced band for either role | — |
| Contradictions | None within each posting | `[grounded]` |

## Evidence map

Your background is your own statement. I haven't checked it against a CV document, so the confidence stays at `medium` at best.

**Role 1**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance | Next step |
|---|---|---|---|---|---|---|---|
| A1 | 2+ years in logistics or ops analysis | must_have | direct | medium | none | `[grounded]` your background | none |
| A2 | Strong SQL | must_have | direct | medium | none | `[grounded]` daily use | none |
| A3 | Power BI or Tableau | must_have | direct | medium | none | `[grounded]` daily use; depot on-time dashboard | none |
| A4 | On-time delivery tracking | must_have | direct | medium | none | `[grounded]` your background | none |
| A5 | Temperature-compliance tracking | must_have | absent | high | domain | `[grounded]` no cold-chain or temperature work in your background | Q2 |
| A6 | Route changes with depot managers | important | direct | medium | none | `[grounded]` ran the weekly route-performance review | none |
| A7 | Dutch | preferred | adjacent | medium | capability | `[grounded]` conversational | closes slowly |
| A8 | Hybrid, three days in Rotterdam | hard_gate | unclear | low | hard_gate | `[grounded]` posting; your constraints not given | Q1 |

**Role 2**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance | Next step |
|---|---|---|---|---|---|---|---|
| B1 | 3+ years FMCG supply or demand planning | must_have | absent | high | experience | `[grounded]` you've never worked in planning | not closable quickly |
| B2 | Advanced Excel | must_have | unclear | low | discovery | `[grounded]` not mentioned | Q3 |
| B3 | SAP IBP or similar | must_have | absent | high | tool | `[grounded]` not in your background | learnable, but not a substitute for B1 |
| B4 | Fluent Dutch | must_have | adjacent | medium | capability | `[grounded]` conversational | slow |
| B5 | 13-week plan, capacity vs forecast, S&OP | must_have | adjacent | medium | transferability | `[inferred]` from the weekly review format only | Q3 |
| B6 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | `[grounded]` posting; your constraints not given | Q1 |

## Opportunity risk register

| # | Signal | Class | Severity | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Temperature-compliance scope is in the role, with no sign of how much of the job it is | unknown | — | `[grounded]` posting | How much of the role is temperature monitoring, and how much is route and on-time work? | unresolved |
| RR2 | Hybrid commute to Rotterdam, three days a week | unknown | — | `[grounded]` posting | Is a three-day Rotterdam week workable for you? | unresolved |
| RR3 | Employer existence unverified | risk_signal | medium | `[grounded]` research unavailable | Link to the live posting and the careers page | standing |
| RR4 | Employer existence unverified (Kroonhaven) | risk_signal | medium | `[grounded]` research unavailable | Link to the live posting and the careers page | standing |
| RR5 | No salary in either posting | unknown | — | `[grounded]` posting | What is budgeted for these roles? | unresolved |
| RR6 | Clear scope in Role 2: 13-week plan and a named S&OP | positive_signal | — | `[grounded]` posting | — | noted |

**Standing entry on RR3 and RR4:** the postings can't be verified from here. Research was refused. Until you check, neither role can go above `conditional_go`. To resolve it, send me the live posting link, the company's careers page, or the recruiter's email domain.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the Duinvaart posting on its own careers page and get the live link | RR3 | `[grounded]` | pending your approval |
| P2 | Describe your on-time and route work in terms you can back up, e.g. "ran the on-time dashboard depot managers use" | A1, A4, A6 | `[grounded]` your own words | proposed wording, pending your approval |
| P3 | Name temperature monitoring as a transfer question, not a claimed skill | A5 | `[grounded]` A5 | pending your approval |
| P4 | State your Dutch honestly as conversational | A7 | `[grounded]` | pending your approval |
| P5 | Put Role 2 at the bottom of your list unless you'd accept a stretch | B1, B3, B4 | `[grounded]` ledger | advice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 5 of 5, fetches 0 of 2

| Target | Status | What it would have moved |
|---|---|---|
| 1. Official site and careers page (both companies) | unavailable | Whether each company and posting exist as described (RR3, RR4) |
| 2. Role-family sweep (both roles) | unavailable | Market calibration and salary band (RR5) |
| 3. Hiring manager's public footprint | n/a | No name was given |

The five searches were refused by a permission setting in this session, so no company or market facts were checked. Everything above rests on your posting text and your background.

## Upgrade menu

- The live posting link or careers-page URL for each company → RR3 and RR4 close, and Role 1 can move from `conditional_go` to `go` if the posting checks out.
- Your commute and on-site limits → A8 and B6 close.
- Any temperature, sensor or cold-storage data work, even as a viewer → A5 becomes evidence, not a gap.
- Any forecast, capacity or production-number exposure → B5 strengthens.
- A salary expectation or the budgeted figure → RR5 closes.
- If search permission is granted in a later turn, I can run the company and salary checks.

## Questions

Dossier offer: I can save this as `tuesday-dossier.md` for later interview prep.

1. **(A8, B6)** What are your hard limits? Is three days a week in Rotterdam from Amsterdam workable, and is on-site in Utrecht workable?
2. **(A5)** Have you ever worked with temperature, sensor or cold-storage data, even as a viewer or in a parcel or depot setting?
3. **(B2, B5)** Have you touched forecasts, capacity or production numbers in any role, even as the person using someone else's plan? And what is your Excel level?

Reply to any of these, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.