**Decision: don't go ahead, and send nothing yet.** Status: `no_go`.

- **Why:** RR1, RR2, RR3 and RR4 are each a request this posting makes of you, and each is confirmed in the messages you pasted. Together they make this a `no_go` whatever the pay or fit.
- **What's going on:** the requests in these messages are very likely a scam. They ask you to pay for equipment, deposit a cheque and forward money, and give bank and PPS details plus a passport photo before any written offer. I can't establish the firm from here: neither search found Velloway Logistics.
- **Your fit is not the problem.** Spreadsheets and customer-operations work match the role. The issue is what this process asks of you.

**Hold, straight after the register:** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

- **Hard gates:** none failed; unconfirmed: R6 (your €30,000 a year floor, against a posting that says "up to €26 an hour" for 15–30 hours).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the four requests withdrawn, or confirmed as legitimate by the employer through its own website's contacts, and RR5 cleared.

**Fit ledger.**
- `important` — direct: R1 · adjacent: R4 · unclear: R2, R3, R5 · hard gate: R6 unclear

R1 is your own Excel tracker. R4 is your ticket work against order processing. R2, R3 and R5 aren't in what you shared.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; no web presence found | `[grounded]` posting; search found nothing |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Pay arithmetic | At full rate, €30,000 a year needs about 22 hours a week, before commission and tax. 15 hours is about €20,300 and 30 hours about €40,600 | `[inferred]` from posting figures |
| Market band | Salaried order-processing and customer-operations coordinators, Ireland 2026: median €31,200, interquartile range €28,400 to €34,100 | `[generic]` Pennoral 2026 Ireland pay guide (salaried only; commission-only work excluded) |
| Process | Telegram only; no calls or video | `[grounded]` posting and messages |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Confident with spreadsheets | important | direct | medium | none | Weekly team tracker in Excel; your statement, not yet inspected | `[grounded]` your message | Expect a probe; a sample tracker would raise it to high |
| R2 | Strong attention to detail | important | unclear | low | discovery | Nothing in what you shared settles it | `[grounded]` absence | None until you have evidence |
| R3 | Good written English | important | unclear | low | discovery | Not stated in your background | `[grounded]` absence | None |
| R4 | Order processing | important | adjacent | medium | transferability | About 60 Zendesk tickets a day at a parcel courier, plus training two starters. Limit: no order-system work named | `[inferred]` from your stated history | Name the limit when you use it |
| R5 | Quiet place to work | important | unclear | low | discovery | Not stated | `[grounded]` absence | None |
| R6 | Pay floor €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Your own stated floor, confirmed. The posting's rate reaches it only at about 22 hours a week, and commission is unstated | `[grounded]` your constraint and posting | RR6's question |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pays for equipment before starting | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Paying up front puts your money at risk, and a refund promised later may not come | `[generic]` employers don't ask applicants to pay for equipment | Does this role ever require the applicant to pay for equipment? What is the refund policy, in writing? | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner" | Cheques can be returned after the money has gone out, leaving you owing it | `[generic]` how overpayment schemes work | Does this role ever ask a new hire to deposit a cheque and forward part of it? | confirmed |
| RR3 | Bank, PPS and passport before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | These details are hard to take back once shared; a written offer comes first | `[generic]` how onboarding normally runs | Does your payroll collect bank and PPS details before a written offer? | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Nothing here lets you verify the employer or the interview | `[grounded]` posting | Are interviews and offers ever made only through Telegram? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR6 | Pay is "up to" with commission unstated | unknown | — | "Earn up to €26 an hour plus commission" | Base pay and commission may fall well short of your floor | `[inferred]` from the posting's wording | What is the guaranteed weekly pay, and how is commission calculated? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no bank details, PPS number, passport, payment or cheque | RR1–RR4 | `[grounded]` the register | proposed |
| A2 | Find the employer's own website and contact it there, not through Telegram | RR5 | `[generic]` verification practice | proposed |
| A3 | Ask RR1–RR6 through those contacts | Register doubles as the question list | `[grounded]` register | proposed |
| A4 | If nothing verifies, put your effort into other openings | RR5 unresolved | `[generic]` search practice | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator": no results, so the employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland per hour": one result, Pennoral 2026 pay guide, the market band in role reality (salaried roles only) |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, with no person's name |

**Upgrade menu**
- The employer's own careers page, or a live posting you found independently → RR5 resolves either way.
- Written base pay and commission terms from the employer → RR6 closes, and the figure is set against the band.
- A two-day deeper check on the employer, up to 5 more searches and 2 more fetches → RR5's footprint.

Do you know of any way to reach Velloway Logistics that doesn't go through Telegram, such as a website or a phone number you can find independently?

Have you been given any base pay figure or weekly hours in writing, beyond the posting's "up to"?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you'd like, I can write this up as a `tuesday-dossier.md` you can keep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.