**Yes, worth taking the call: `conditional_go`.** Nothing in the posting or the WhatsApp message asks you for money, a deposit, or bank or ID details. The fit is solid on Figma, research and working with engineers. I could not check the company, though: web search was refused in this session, so Fernquay's existence, its footprint and the pay band are all unverified.

- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
  - `must_have`: direct: R3, R4, R6, R9 · adjacent: R5 (own the booking flow end to end)
  - `important`: adjacent: R7 (research calls with school owners) · unclear: R8 (first designer, no design peer)

  R5 — checkout covers part of the flow; R7 — consumer research, not school owners; R8 — nothing shows you working without a design peer.
- **Opportunity ledger.** RR1 (employer not established in this session, `risk_signal`, medium) and RR2 (solo scope, `risk_signal`, low) are the open risks; RR3 (equity terms) is unknown; RR4 is a positive signal, since pay and hybrid terms are stated.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role and company appear on the company's own website, and the calendar invite comes from its domain (RR1); (2) your base-salary floor sits inside €52,000–€60,000 (R2); (3) on the call, solo design decisions and research budget get tested (R8, RR2).
- **What would change this:** a verified employer moves it toward `go`. A floor above €60,000 that the employer won't move would fail R2 and make this `no_go`. If web search is allowed, the company checks could move RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people, Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not verified |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not checked. Search was refused, so I won't give a band from memory | — |
| Scope read | First designer with two engineers and a CTO; the scope is clear, and the decision rights and design support are not stated | `[inferred]` from the posting |
| Unknowns | Company footprint, equity terms, design review, research budget | — |
| Contradictions | None in the text you pasted. The posting's "two engineers" and the message's "our CTO" agree | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, Galway office two days a week | hard_gate | direct | medium | none | You moved back to Galway last year. You did not state this as a constraint | `[grounded]` your intake | none |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not given, so the gate is not settled | `[grounded]` posting | Q2 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. A length requirement, so not a gate. Self-reported | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported. The checkout case study is the artifact, and I have not read it here | `[grounded]` your intake | Link or paste the case study |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign carries over. Discovery-to-launch ownership and the rest of the booking flow are not stated | `[inferred]` bridge from the checkout redesign | Q3 |
| R6 | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your intake | none |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | The method transfers. Your sessions were with travel customers, not business owners | `[inferred]` from R6 against the posting's audience | G3 |
| R8 | First designer, working without a design peer | important | unclear | low | discovery | Inferred from "you would be our first designer." You have never been the only designer, and nothing shows you deciding alone | `[inferred]` posting; `[grounded]` your intake | Q1 |
| R9 | Work directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo design decisions (R8) | discovery | No evidence either way about deciding without a design peer | The role is built on this, and it is the gap an interviewer will probe | A flow you designed and shipped with no design reviewer; a call you made and defended alone | A project brief, a decision log, a launch note | `[grounded]` absence in intake; `[generic]` that this is the usual probe for a first-designer role |
| G2 | End-to-end ownership (R5) | transferability | Checkout redesign only | Checkout is one flow, not the whole booking flow | Discovery, design and launch on any flow you led | The checkout case study | `[inferred]` bridge from the checkout work |
| G3 | Business-customer research (R7) | transferability | Consumer usability sessions | The method carries over, the audience does not | Any interview with a business or operator customer | Interview guide or notes, if any | `[inferred]` from R6 and R7 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established in this session | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. My search was refused, so this says nothing either way about Fernquay itself | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and what is the company's registered name? | unresolved |
| RR2 | Solo scope with no stated design review or research budget | risk_signal | low | "You would be our first designer: own the booking flow end to end" | You may own the flow with no one reviewing decisions or funding research | `[inferred]` from the posting's scope against its silence on both | Who reviews design decisions, and what research budget and time are committed to this role? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value depends on vesting, strike price and share count, none given | `[inferred]` from the posting's silence | What is the vesting schedule, the strike price and the current share count? | unresolved |
| RR4 | Pay and office terms stated | positive_signal | — | "€52,000–€60,000 … two days a week at our Galway office" | Specific terms are a transparency signal | `[grounded]` posting | Is this salary range the budgeted figure for the hire? | noted |

The WhatsApp message asks for a video call and gives a time. Under the register's rules, scheduling by chat is routine and gets no entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Fernquay and the role on its own website, and check that the calendar invite comes from the company's domain | RR1 | Advice | your call |
| P2 | Re-read the checkout case study and note which decisions were yours alone | R5, G1 | `[grounded]` your case study | your call |
| P3 | Prepare your floor and the equity questions for the call. For prep on the 45-minute call itself, the mock-interview module can build a pack | R2, RR3 | `[grounded]` posting | your call |

## Evidence status

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused in this session, so the queries did not run. Would have moved the organization row and RR1 |
| 2. Role-family sweep | unavailable | Same refusal. Would have moved the market calibration and the pay check on R2 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, so a query was sent and refused. Would have moved how to position for Ronan |

Verified: none yet.

I have not rerun the searches and have not tried another route to the web. If you allow web search, I can run the three checks above.

**Dossier offer:** I can write this up as `tuesday-dossier.md` on request.

**Upgrade menu**
- Your base-salary floor: R2 closes, and the status can move to `go` or `no_go`.
- The checkout case study, linked or pasted: R4 and R5 get an artifact to check against.
- Web search allowed for this session: runs the three checks above (up to 5 searches, 2 fetches). A deeper company pass (leadership, funding, public reports) is available once, at up to 5 more searches and 2 more fetches, if you want it.
- The equity terms in writing: RR3 closes.

**Questions**

R8 — Have you ever been the only person deciding how a product's design worked, with no design peer reviewing it? Name the project, what you decided alone, and who signed it off.

R2 — What is your minimum base salary, and is €52,000 above or below it?

R5 — On the checkout work, did you own discovery, design and launch, or only part of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.