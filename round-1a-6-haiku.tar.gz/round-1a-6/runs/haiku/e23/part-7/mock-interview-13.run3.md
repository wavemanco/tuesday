Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-7-rooms-case-13-denied-03f22629/6134c550-10bb-49f9-83b3-a95ffc9e187f/scratchpad/quillmoor-screen-prep.md`. Here it is in full.

**Assumption:** built from the advert and your background as you gave them. I didn't run company research, so nothing here is about Quillmoor's values or recent news.

**Date check:** today is Thursday 26 November. Confirm whether "Thursday at 2pm" means this Thursday or 3 December.

## 1. Fit snapshot

| Requirement | Your evidence | Gap | What to say |
|---|---|---|---|
| 2+ years in operations or logistics | "4 years as a logistics coordinator…" | None | n/a |
| Coordinate production across planning, warehouse, QA | "I schedule deliveries for our three depots." | Production scheduling and QA are new to you | "My scheduling has been delivery-side across three depots. Coordinating between sites is what I'd carry over." |
| Track deliveries, chase late orders | "I chase suppliers when orders slip." | None | n/a |
| Accurate stock records | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | None | n/a |
| Weekly on-time dispatch reporting | Nothing in your material | Unknown | Q8 |
| Confident with Excel | The spreadsheet rebuild | Level unstated | Q9 |
| SAP or similar ERP (a plus) | "Never used SAP — we run our own in-house stock system." | SAP experience | "I haven't used SAP. I've worked with our in-house stock system." |

## 2. Claims not to make

- Any SAP or ERP experience beyond your in-house system.
- Production scheduling or QA experience.
- Any dispatch or KPI figure you haven't produced.
- An Excel level you can't demonstrate.
- A discrepancy figure beyond "about a third over a year".

## 3. Likely questions

**Q1. "Tell me about your background."**
Give the 30-second version: four years coordinating logistics at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers, and rebuilding the stock-count spreadsheet.

**Q2. "What are your salary expectations?"**
First ask for their budget band. If pressed: "I've seen the advertised £38,000–£44,000. I'm looking for around £42,000, depending on the overall package." Decide your floor before the call. You haven't told me one.
*Answer slot: your floor.*

**Q3. "What's your notice period?"**
Give the number and your earliest start date in one sentence.
*Answer slot: notice period.*

**Q4. "How do you feel about the hybrid pattern?"**
"Two days at Avonmouth works from north Bristol. I'd want to keep it to no more than three."

**Q5. "What's prompting the move?"**
"Our Bristol office is closing next year, and the only offer is relocating to Reading. I'd like to stay in Bristol, so I'm looking for a role here." Keep it factual and don't criticise your current employer.

**Q6. "You haven't used SAP. How would you handle that?"**
"I haven't used SAP. I've worked with our in-house stock system and rebuilt our stock-count spreadsheet." Then say how you'd get up to speed. Don't claim you'll pick it up quickly unless you have a basis.
*Answer slot: how you'd get up to speed.*

**Q7. "Tell me about a time you improved accuracy."**
Use the stock-count rebuild and keep the figure as "about a third over a year". Be ready for "how did you measure it?"
*Answer slot: how discrepancies were measured.*

**Q8. "Have you reported on dispatch or on-time performance?"**
*Answer slot: any regular reporting you've done. If none, say so and link to the tracking you do.*

**Q9. "How confident are you with Excel?"**
*Answer slot: name the functions you've actually used. Don't rate yourself above that.*

## 4. Questions to ask Hannah

1. "What does a typical week look like across planning, warehouse and QA?" This shows how heavy the coordination load is.
2. "How is on-time dispatch measured and reported, and to whom?"
3. "Which ERP does the team use, and what training is there for someone new to it?" This addresses the SAP gap directly.
4. "Are the hybrid days fixed, or flexible?"

## 5. Upgrade menu

- **Your notice period, salary floor and Excel level** let me fill Q2, Q3, Q6 and Q9 properly.
- **The full job description**, if the advert above is abridged, would confirm the fit rows.
- **Deep research on Quillmoor** (values, Avonmouth news) is available but not run. It would add about 6 searches and 2 page fetches.
- **Any written process details** from Hannah could change the question order.

**Offers, not pushed:**
- Want a live rehearsal? I can play Hannah and ask these questions with follow-ups, then give feedback.
- Want a `tuesday-dossier.md` file saved from this pack so other tools can use it?

**To tighten the answers, I need three things:**
1. What's your notice period?
2. What's the lowest salary you'd accept?
3. Which Excel functions have you used (for example lookups, pivot tables, formulas)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-screen-prep.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

Round: 30-minute phone recruiter screen with Hannah Lowther (Talent Partner). Built from the advert and Sam's background as provided. No company research run; generic recruiter-screen norms are labelled generic.

## 1. Fit snapshot

| Requirement (advert) | Sam's evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | High | None | n/a |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots." | Medium | Experience gap (production scheduling, QA) | "My scheduling has been delivery-side across three depots, not production or QA. Coordinating between sites is the part I'd carry over." |
| Track supplier deliveries; chase late orders | "I chase suppliers when orders slip." | High | None | n/a |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | n/a |
| Weekly on-time dispatch reporting | Not in the material | None | Evidence gap | Answer slot (see Q8) |
| Confident with Excel | Spreadsheet rebuild is the only evidence | Medium | Evidence gap (level unstated) | Answer slot (see Q9) |
| ERP experience (SAP or similar), a plus | "Never used SAP — we run our own in-house stock system." | Low for SAP | Experience gap | "I haven't used SAP. I've worked with our in-house stock system." |

## 2. Prohibited claims (built locally)

- Any SAP or other ERP experience beyond the in-house stock system.
- Production scheduling or QA experience.
- Any dispatch or KPI figure Sam has not produced.
- Any Excel level beyond what Sam can demonstrate.
- Any discrepancy figure beyond "about a third over a year".

## 3. Question bank: recruiter screen

**Q1. "Tell me about your background."** Type: Background.
Guidance: 30-second version: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilt the stock-count spreadsheet.
Provenance: stated. "I schedule deliveries for our three depots…"

**Q2. "What are your salary expectations?"** Type: Compensation.
Guidance: first ask for the budget band. If pressed: "I've seen the advertised £38,000–£44,000. I'm looking for around £42,000, depending on the overall package." Settle your floor before the call; the material doesn't give one.
Provenance: stated. "I'm hoping for £42,000."
Answer slot: your floor.

**Q3. "What's your notice period?"** Type: Logistics.
Guidance: give the number and your earliest start date in one sentence.
Answer slot: notice period.

**Q4. "How do you feel about the hybrid pattern?"** Type: Logistics.
Guidance: "Two days at Avonmouth works from north Bristol. I'd want to keep it to no more than three."
Provenance: stated. "Two days at Avonmouth is fine, but I wouldn't want more than three."

**Q5. "What's prompting the move?"** Type: Motivation.
Guidance: keep it factual and forward-looking: "Our Bristol office is closing next year, and the only offer is relocating to Reading. I'd like to stay in Bristol, so I'm looking for a role here." Don't criticise the current employer.
Provenance: stated. "Our Bristol office is closing next year and the only offer is relocating to Reading."

**Q6. "You haven't used SAP. How would you handle that?"** Type: Gap.
Guidance: "I haven't used SAP. I have worked with our in-house stock system and rebuilt our stock-count spreadsheet." Then name what you'd do to get up to speed. Don't say you'll pick it up quickly unless you have a basis for it.
Provenance: stated. "Never used SAP — we run our own in-house stock system."
Answer slot: how you'd get up to speed.

**Q7. "Tell me about a time you improved accuracy."** Type: Achievement.
Guidance: the stock-count rebuild. Keep the figure as "about a third over a year". Be ready for "how did you measure it?"
Provenance: stated. "Discrepancies fell by about a third over a year."
Answer slot: how the discrepancies were measured.

**Q8. "Have you reported on dispatch or on-time performance?"** Type: Gap.
Answer slot: any regular reporting you've done. If none, say so and bridge to the tracking you do.

**Q9. "How confident are you with Excel?"** Type: Gap.
Answer slot: name the specific functions you've used (for example lookups, pivots, formulas). Don't rate yourself above that.

## 4. Reverse questions for Hannah

1. "What does a typical week look like across planning, warehouse and QA?" Why: tests how heavy the coordination load is.
2. "How is on-time dispatch measured and reported, and to whom?" Why: shows you understand the weekly reporting duty.
3. "Which ERP does the team use, and what training is there for someone new to it?" Why: addresses the SAP gap directly.
4. "Are the hybrid days fixed, or flexible?" Why: confirms the two-day pattern before the next round.

## 5. Upgrade menu

- Notice period, salary floor and Excel level: fill the answer slots in Q2, Q3, Q6, Q9.
- Full job description, if the advert above is abridged: confirms the fit snapshot rows.
- Deep research on Quillmoor (values, Avonmouth news): offered, not run. Adds about 6 searches and 2 page fetches.
- Any written process details Hannah sends: can change the question order.
