# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

Round: 30-minute phone recruiter screen with Hannah Lowther (Talent Partner). Built from the advert and Sam's background as provided. No company research run; generic recruiter-screen norms are labelled generic.

## 1. Fit snapshot

| Requirement (advert) | Sam's evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | High | None | n/a |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots." | Medium | Experience gap (production scheduling, QA) | "My scheduling has been delivery-side across three depots, not production or QA. Coordinating between sites is the part I'd carry over." |
| Track supplier deliveries; chase late orders | "I chase suppliers when orders slip." | High | None | n/a |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | n/a |
| Weekly on-time dispatch reporting | Not in the material | None | Evidence gap | Answer slot (see Q8) |
| Confident with Excel | Spreadsheet rebuild is the only evidence | Medium | Evidence gap (level unstated) | Answer slot (see Q9) |
| ERP experience (SAP or similar), a plus | "Never used SAP — we run our own in-house stock system." | Low for SAP | Experience gap | "I haven't used SAP. I've worked with our in-house stock system." |

## 2. Prohibited claims (built locally)

- Any SAP or other ERP experience beyond the in-house stock system.
- Production scheduling or QA experience.
- Any dispatch or KPI figure Sam has not produced.
- Any Excel level beyond what Sam can demonstrate.
- Any discrepancy figure beyond "about a third over a year".

## 3. Question bank: recruiter screen

**Q1. "Tell me about your background."** Type: Background.
Guidance: 30-second version: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilt the stock-count spreadsheet.
Provenance: stated. "I schedule deliveries for our three depots…"

**Q2. "What are your salary expectations?"** Type: Compensation.
Guidance: first ask for the budget band. If pressed: "I've seen the advertised £38,000–£44,000. I'm looking for around £42,000, depending on the overall package." Settle your floor before the call; the material doesn't give one.
Provenance: stated. "I'm hoping for £42,000."
Answer slot: your floor.

**Q3. "What's your notice period?"** Type: Logistics.
Guidance: give the number and your earliest start date in one sentence.
Answer slot: notice period.

**Q4. "How do you feel about the hybrid pattern?"** Type: Logistics.
Guidance: "Two days at Avonmouth works from north Bristol. I'd want to keep it to no more than three."
Provenance: stated. "Two days at Avonmouth is fine, but I wouldn't want more than three."

**Q5. "What's prompting the move?"** Type: Motivation.
Guidance: keep it factual and forward-looking: "Our Bristol office is closing next year, and the only offer is relocating to Reading. I'd like to stay in Bristol, so I'm looking for a role here." Don't criticise the current employer.
Provenance: stated. "Our Bristol office is closing next year and the only offer is relocating to Reading."

**Q6. "You haven't used SAP. How would you handle that?"** Type: Gap.
Guidance: "I haven't used SAP. I have worked with our in-house stock system and rebuilt our stock-count spreadsheet." Then name what you'd do to get up to speed. Don't say you'll pick it up quickly unless you have a basis for it.
Provenance: stated. "Never used SAP — we run our own in-house stock system."
Answer slot: how you'd get up to speed.

**Q7. "Tell me about a time you improved accuracy."** Type: Achievement.
Guidance: the stock-count rebuild. Keep the figure as "about a third over a year". Be ready for "how did you measure it?"
Provenance: stated. "Discrepancies fell by about a third over a year."
Answer slot: how the discrepancies were measured.

**Q8. "Have you reported on dispatch or on-time performance?"** Type: Gap.
Answer slot: any regular reporting you've done. If none, say so and bridge to the tracking you do.

**Q9. "How confident are you with Excel?"** Type: Gap.
Answer slot: name the specific functions you've used (for example lookups, pivots, formulas). Don't rate yourself above that.

## 4. Reverse questions for Hannah

1. "What does a typical week look like across planning, warehouse and QA?" Why: tests how heavy the coordination load is.
2. "How is on-time dispatch measured and reported, and to whom?" Why: shows you understand the weekly reporting duty.
3. "Which ERP does the team use, and what training is there for someone new to it?" Why: addresses the SAP gap directly.
4. "Are the hybrid days fixed, or flexible?" Why: confirms the two-day pattern before the next round.

## 5. Upgrade menu

- Notice period, salary floor and Excel level: fill the answer slots in Q2, Q3, Q6, Q9.
- Full job description, if the advert above is abridged: confirms the fit snapshot rows.
- Deep research on Quillmoor (values, Avonmouth news): offered, not run. Adds about 6 searches and 2 page fetches.
- Any written process details Hannah sends: can change the question order.
