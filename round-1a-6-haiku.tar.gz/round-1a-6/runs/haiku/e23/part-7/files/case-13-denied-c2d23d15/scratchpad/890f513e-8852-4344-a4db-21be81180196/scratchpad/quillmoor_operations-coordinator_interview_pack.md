# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff), hybrid, Avonmouth site in Bristol
**Call:** Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30 minutes, by phone on the mobile number on your application
**Candidate:** Sam
**Round type:** Recruiter screen. Relationship: recruiter, not the hiring manager. Scoring is light, but the call is a knockout and motivation check.
**Changes since last draft:** first version.

## How to use + type key

Personas are how a question arrives. Types are what is being scored.

- **EXP**: what you actually did. Checks that your CV claims survive a close look.
- **JD**: the advert's stated responsibilities and requirements, including the gaps.
- **CO**: company knowledge. Not covered: no company research ran (see Sources), so this pack has no CO questions.
- **VAL**: published values. Not covered: this is a screen, not a values round, and no values were published in what you gave me.
- **CASE**: live problem. Not covered: none is scheduled.

Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds or less.

## The fit snapshot

Requirements are quoted from the advert you pasted. Evidence is quoted from your message. Nothing else is quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | The sentence already meets the requirement. Say it as written. Expect a date check if the CV is read closely; nothing to add. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message); "I schedule deliveries for our three depots" (your message) | medium | [grounded] | presentation | Your sentence already reaches the requirement in other words. Say "I chase suppliers when orders slip", in those words, and add no practice to it. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The sentence reaches the requirement. The figure will be probed; see B1 for how to answer how it was counted. |
| F4 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [inferred] | transferability | Delivery scheduling is adjacent to production scheduling, not the same work, and the bridge should not stretch it to planning or QA. Say the sentence at its own scope. Answer slot: if you have set or changed timing anywhere upstream of dispatch, say what and how; if you have not, say so, and say how you would get up to speed on production planning. |
| F5 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | medium | [grounded] | transferability | The SAP line is your stated negative: "I haven't used SAP." The in-house stock system is adjacent to an ERP, and it stays at its own scope. Answer slot: if you did more in that system than keep stock records, say what; if not, say so. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The rebuild is evidence of working in Excel, but it does not state a confidence level. Say what you built, and rate yourself only as far as you can show. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material is silent on any dispatch report, so the bridge is a question you can answer either way. Answer slot: if you produced a weekly figure on delivery timing, say what it measured and who saw it; if you did not, say so, and say what you would report first. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert, gate) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | This is your own constraint, and the advert's pattern sits inside it. Gate met on your statement: say the sentence. |
| F9 | "£38,000–£44,000" (advert, pay gate) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advertised band. Say the figure; see A3 for the sequence. |

Notes on the table:
- Notice period is not in the advert and not a requirement, so it is not a row. It is a Step 1 question below.
- No gate row is silent. The only gate terms (pay, location) are both stated by you.

## Prohibited claims

Built here from the fit snapshot, because no dossier was provided. Each entry names its basis and the honest form. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have SAP experience" or "I've worked in an ERP" | Inflated form of F5 | "I haven't used SAP." Then the stock system at its own scope: "we run our own in-house stock system." Your material says the stock system, not an ERP. |
| "I cut discrepancies by a third" as your sole result | Inflated form of F3 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." That sentence does not say what else changed, or who else worked on the count. |
| "I've coordinated production schedules, planning, or QA" | Inflated form of F4 | "I schedule deliveries for our three depots." Stated at its own scope. Your material says deliveries, not production. |

## Persona table

Recruiter screen priors are Conversational plus light Skeptic. The weights below follow that prior and the call's four stated topics.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Logistics checks, the four topics in order, a short "tell me about yourself" | High. Hannah has listed the topics, so this is the call's shape. Casual questions are still scored. | Keep each answer under 90 seconds. Say the figure, then stop. |
| Skeptic | Checks the gaps: Excel, SAP, production and QA, the figure | Medium. The advert's requirement list is where a screener probes. | Say the gap in your own words first, then the bridge you can support. Do not bluff a tool you have not used. |
| Pressure | Pushes on the salary, or on how firm the move reason is | Low to medium. This is a screen, not an adversarial round, but salary and motive are where firmness gets tested. Generic pattern, not a claim about Hannah. | Pause, restate the question, hold the number, concede only what is true. |
| Data-driven prober | Asks how the discrepancy figure was counted | Folded into B1. A separate persona would be padding for one probe. | Use B1's defend-the-number moves. |

Weights: Conversational 6 questions, Skeptic 5, Pressure 2. That is 13 in total. It is a 30-minute screen, so this is deliberately smaller than a full-loop pack.

## Question banks

### Bank A: Conversational, weight highest

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip" (your message) | 60 to 90 seconds: the role, the four years, the three depots, the chasing, the stock spreadsheet. Use the sentences as written, in that order. | F1 and F2 are the evidence for the call's opening. JD because the answer checks the advert's first requirement. |
| A2 | "What does a typical slipped order look like, and what do you do?" | EXP | [grounded] "chase suppliers when orders slip" (your message) | Answer with the steps you actually take, in order. Answer slot: the advert asks for chasing late orders, so expect a probe on the steps. If the steps were yours, describe them; if the process was set by someone else, say so and describe your part. | F2 is the only evidence for chasing. EXP because it asks for what you did. |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." and "£38,000–£44,000" (your message; advert) | Say the figure first, as the target: "I'm hoping for £42,000." Then ask what the package includes, because the advert shows only a base range. Holding the number is the whole point. If she asks for your budget first, say you would like to hear the band and that your target is £42,000. | F9 sits inside the band, so naming it first is low risk, and it shows you read the advert. Tagged JD because the pay is the advert's stated band. |
| A4 | "What's your notice period?" | JD | [grounded] none for the number. Provenance is your own answer: <notice period> | Answer slot: <notice period>, in your words. Say it as a number of weeks or months, and say when you could start. If you are on a contract with a different term, say so. Do not offer to negotiate it on this call. | Notice is not in the advert, so the material does not establish it, and the only source for the number is you. It is a screen check. |
| A5 | "Two days at Avonmouth: is that workable for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say the sentence. Then stop. If she asks about days or timing, say two days works, and that three is the most you would accept. Ask her which days the team uses. | F8 is a gate you have stated. Stopping after the sentence keeps the answer short. |
| A6 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say it briefly and plainly: "The Bristol office closes next year. The only offer I have is relocating to Reading, and I'd rather stay in Bristol." Then pivot to the role's duties, which match F2 and F3. Do not criticise the former employer, Reading, or anyone in the closure. | The motive is the one thing she will ask that the advert cannot answer. It is short because the screen is short, and the honest line is the strongest one you have. |

### Bank B: Skeptic, weight second

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | The highest-ROI prep on this pack. Give the figure as you said it: about a third, over a year. Name the weakest assumption you would defend, in your own words; the material does not say how it was counted. Answer slot: if the counting method was yours to set, say how you set it; if it was set by someone else, say so plainly and say which part you did. Hold to the spreadsheet, not to the whole count. | F3 is the strongest number on the CV and the likeliest probe. The defend-the-number moves apply because a figure was given. |
| B2 | "How confident are you in Excel, and what have you built in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Name what you built, and the formulas or features you used in it, if you can name them. Do not rate yourself beyond what you can show. Answer slot: if you have used lookups, pivots, or macros, say which; if not, say so and say what you would learn first. | F6 is the Excel evidence. The advert says "confident", so this question is scored, not casual. |
| B3 | "The role lists SAP as a plus. Do you have ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | Plain acknowledgment: "I haven't used SAP." Then the stock system at its own scope: "we run our own in-house stock system." Then the answer slot: if you did more in that system than keep stock records, say what; if not, say so. Do not say you have ERP experience. | F5 is a stated negative, so the plain acknowledgment is yours to give. Her question presupposes an ERP, which the advert raises, so the second branch is allowed. |
| B4 | "What's your experience coordinating production, planning and QA?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Say the delivery sentence at its own scope. Then the answer slot: if you have had any part in production planning or QA, say what and how; if you have not, say so, and say how you would learn the production side first. | F4 is adjacent, not the same work. The advert's "Coordinate production schedules" is the raising source, and the slot allows that the practice was never yours. |
| B5 | "Do you report weekly on on-time dispatch?" | JD | none given. Provenance is the advert: "report weekly on on-time dispatch" | Answer slot: if you produced a weekly figure on delivery timing, say what it measured and who saw it; if you did not, say so and say what you would report first. Do not describe a report you did not produce. | F7 is silence in your material, so the words are a slot, not a claim. The advert raises the report, so the question is lawful as asked. |

### Bank C: Pressure, weight lowest

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our band starts at £38,000. Why should we go to £42,000?" | JD | [grounded] "I'm hoping for £42,000." and "£38,000–£44,000" (your message; advert) | Hold the figure. Say it sits inside the band, and that you would like to see the package. Do not justify the figure with market talk you cannot source. If pushed twice, concede only what is true: you would like to discuss the whole package. | F9 is the one number you have stated. The hold is only what your sentence carries. |
| C2 | "You're only looking because the office is closing. How committed are you to this role?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Hold: the office closure is the reason, and the role is the one you want to keep in Bristol. Do not claim a commitment you have not stated. If pushed, say the role's duties are the work you already do, and that you want to keep doing it near home. | The motive is the test. Holding the stated reason is more honest than adding a commitment you have not made. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Track supplier deliveries and chase late orders | A2 |
| Keep stock records accurate | B1 |
| Confident with Excel | B2 |
| ERP experience (SAP or similar) a plus | B3 |
| Coordinate production schedules between planning, the warehouse and QA | B4 |
| Report weekly on on-time dispatch | B5 |
| Hybrid, two days a week at Avonmouth | A5 |
| Pay band | A3, C1 |
| Notice period (not in advert) | A4 |

## Reverse questions

Hannah has said she will tell you about the team and next steps. These questions are for the time she gives you at the end.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time dispatch reported today, and who receives the weekly figure?" | It tests the B5 gap from the other side. Asking it shows you read the advert's line about the report. |
| R2 | "Which system does the production schedule run on: SAP, or something else?" | It answers the B3 question in her terms and tells you what the tools are. |
| R3 | "How is the handoff between planning, the warehouse and QA run day to day?" | It lets you hear the production side from the team, which is the F4 gap. |
| R4 | "Is the two-day Avonmouth pattern set by the team, or by company policy?" | It turns the hybrid check into a question about flexibility, which keeps your three-day ceiling out of the answer. |
| R5 | "What's included beyond the base: bonus, pension, benefits?" | The advert gives only a base range. Asking shows you read the advert and want the whole package before saying yes. |
| R6 | "What happens after this call, and when would you expect to hear?" | It is the closing question she will expect. It keeps the next step with her. |

## Sources

Provided documents:
- The advert for Operations Coordinator, Quillmoor Diagnostics, as pasted.
- Your message, including the ABOUT ME section and the note of what you would tell Hannah.
- Hannah Lowther's LinkedIn message, as pasted.

Research:
- One search was sent: "Quillmoor Diagnostics Avonmouth diagnostic test manufacturer values". The host refused it, so nothing came back. No other search or fetch was sent.

### Target accounting

Research tier: L0 in effect. Searches 0 of 6 completed (1 attempted, refused by the host). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values section, not included. This is not a values round, so the section would have been dropped anyway. A grounded "why Quillmoor" answer would have needed it; see the upgrade menu. |
| 2. Quillmoor interview process, Operations | unavailable | Loop structure. A screen with one recruiter has no loop, so persona weights would not have moved much. |
| 3. Quillmoor strategy and recent news | unavailable | CO questions. This pack has none, so nothing moved; the upgrade menu says what a grounded strategy line would unlock. |
| 4. Hannah Lowther, Talent Partner, Quillmoor | unavailable | Interviewer read. She is the recruiter; her public footprint would add little to this screen. |
| 5. Representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- A notice period → fills the A4 answer slot. It is the only input the call needs and the pack does not have.
- Your CV, pasted → lets the fit snapshot quote the CV instead of your message, and lets F6 and F5 be checked against listed skills.
- A reason you want to work at Quillmoor beyond the role and the closure → gives a grounded "why here" answer. The pack has none yet, and Hannah may ask it.
- Quillmoor's published values or recent news, if you can paste them → unlocks a grounded "why here" answer and a CO question. Research was refused, so this needs you to paste it.
- Excel detail: the formulas, lookups or pivots you have used → upgrades B2 from a slot to a story.
