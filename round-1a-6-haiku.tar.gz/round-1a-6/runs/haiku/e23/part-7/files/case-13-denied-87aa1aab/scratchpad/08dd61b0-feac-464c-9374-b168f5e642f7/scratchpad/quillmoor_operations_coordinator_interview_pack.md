# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Hannah Lowther, Talent Partner. Phone, Thursday 2pm, 30 minutes. Recruiter screen.

## How to use this

Personas describe how a question is asked. Types describe what is being scored: **JD** means the advert's requirements, **EXP** means what you actually did. Guidance is scaffolding, not a script. Aim for 60 to 90 seconds an answer. Anything in square brackets is a slot for you to fill in your own words.

## Prep triage

Prep time isn't stated, so this is ordered by what matters most on a 30-minute call:

1. Decide your lowest acceptable salary and your notice period (A3, A4). Hannah will ask both, and neither is in what you've given me.
2. Rehearse B1 (production planning and QA). It is the advert's first duty and the gap most likely to come up. This is the highest-return prep in the pack.
3. Rehearse B4 (the one-third figure) so you can say how it was counted, or say plainly that you don't know.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Meets the requirement. Four years is specific but has no inspectable record behind it, so expect a check on dates rather than a probe on the work. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling, so the bridge stops at that scope. Answer slot: if you had any part in planning sequences with warehouse staff, or in work with a QA team, say which, in your own words. If none of it was yours, say so plainly and stay with the depot scheduling. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Meets the requirement. Keep your own phrase, "orders slip". |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement. Say "about a third, over a year", and give no figure you have not given. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported any delivery or dispatch timing figures, say what and how often. If you didn't, say so and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The quote shows spreadsheet work, not a skill level. Say the rebuild in those words, and don't rate yourself beyond it. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | You have stated the SAP absence, and your in-house stock system is the adjacent work. Say "I haven't used SAP. We run our own in-house stock system." Do not claim ERP experience. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | hard_gate | Pay is a term, and your material does not establish a minimum. The £42,000 target sits inside the band, so what is open is your floor, not the target. |
| F9 | "two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own limit, stated specifically. It meets the advert's two days with one day of room. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned production scheduling" | Inflated form of F2. It widens delivery scheduling to production planning. | "I schedule deliveries for our three depots." Your material shows delivery scheduling, not production planning. |
| "Advanced Excel" | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." |
| "Experience with SAP" | A negative you stated, F7 | "I haven't used SAP." A plain acknowledgment, with no slot. |
| "Cut discrepancies by 33%" | Inflated form of F4. It turns "about a third" into a precise figure. | "discrepancies fell by about a third over a year." |

## Persona table

Relationship prior for a recruiter screen is Conversational plus a light Skeptic. There is no interviewer profile, so the weights are not adjusted.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Opens with your journey, then walks through salary, notice and hybrid in a friendly register | High. A recruiter screen runs this way, and Hannah has listed the topics. | Keep answers short and complete. Treat "any questions for me?" as scored. |
| Skeptic | "Why now, and why not Reading?" Checks the advert's requirements one by one. | Medium. The move reason and the production gap are standard checks. | Rehearse B1 and A2. Plain answers, no bluffing. |

## Question banks

### Bank A: Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your current role." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Four years, the three depots, and chasing suppliers, in about 60 seconds. Add the stock-count rebuild as one line. Use your own words and no new scope. | The opener. Scored for brevity and for sounding like the person in the CV (F1, F2, F3). |
| A2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the office closing and the relocation offer once, plainly. Then [say what draws you to this role, in your own words]. Don't criticise the employer. | Hannah asked it directly. The answer is true and needs no spin. A Skeptic check on consistency. |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." (your message) | "I'm looking for around £42,000." Then ask what the band is for this role. Answer slot: [your lowest acceptable figure]. Decide it before Thursday, and say it only if you would take it. | A knockout check. £42,000 sits inside the advert's £38,000 to £44,000 band (F8). Your floor is not in your material. |
| A4 | "What's your notice period?" | JD | [generic] No claim about your past. Notice period is a fact only you hold. | Answer slot: [your notice period, in your own words]. | Hannah listed it. It is not in the advert or in your material, so fill it in before the call. |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | "Two days at Avonmouth works. I'm in north Bristol. Three days is the most I'd want." State the limit once and don't explain it further. | F9 is high-confidence and stated by you. Hybrid is a term, so give it briefly. |

### Bank B: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. What's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Make the transferable case within the quote's scope: delivery scheduling across three depots, and chasing suppliers when orders slip. Answer slot: if you had any part in planning sequences with warehouse staff, or in work with a QA team, say which and how, in your own words. If none of it was yours, say so plainly and say what you would learn first. Hold through one follow-up by returning to the depot scheduling. | F2 is the largest gap and the advert's first duty. This is the highest-return prep in the pack. |
| B2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | "I haven't used SAP. We run our own in-house stock system." Stop there. Don't claim a similar system. | A stated negative, so a plain acknowledgment is allowed. ERP is listed as a plus, not a requirement, so keep it short (F7). |
| B3 | "How would you rate your Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | "I rebuilt our stock-count spreadsheet." If pressed, name only the features you actually used. | "Confident with Excel" is a self-rating. The spreadsheet is your evidence for it (F6). |
| B4 | "Your discrepancies fell by a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Keep "about a third, over a year." Name the assumption you would defend least before they ask. Answer slot: how it was counted, and which part was yours. If you don't know how it was counted, say so. | A headline figure, so a magnet for probing. The pack does not supply a method (F4). |
| B5 | "This role reports weekly on on-time dispatch. Have you reported on delivery timing?" | JD | [grounded] advert: "report weekly on on-time dispatch". No sentence of yours covers it. | Answer slot: if you reported any delivery or dispatch timing figures, say what and how often. If you didn't, say so and say what you would report first. | F5 is a discovery gap. The advert raises the requirement; your material does not show it. |

## Reverse questions

1. "What does the first 90 days look like in this role?" Why it lands: it shows you're planning to do the job, not just the interview.
2. "How do planning, the warehouse and QA usually hand off a production schedule?" Why it lands: it shows you understand the coordination the role depends on.
3. "Which supplier delays cause the most trouble at the moment?" Why it lands: it asks about the core of the job and signals you've read the advert closely.
4. "How is on-time dispatch reported now, and who receives the weekly report?" Why it lands: it links to the advert's reporting line and shows you read it.
5. "What does a typical week look like on the Avonmouth days?" Why it lands: it turns the hybrid question into a practical one and shows you've thought about the commute.

## Sources

- Provided: your message (background, targets, the reason for moving), the advert text you pasted, and Hannah's LinkedIn message.
- Research tier: L0. I did not run any web searches or fetches for this pack. It uses only the material above.
- Target accounting: company values, unavailable (no search run at this tier). Interview process, unavailable (same reason). Company strategy, skipped (the screen is set by the advert and Hannah's note). Interviewer, n/a (no profile). Representative JD, skipped (you supplied the advert).

## Upgrade menu

- Your notice period and lowest acceptable salary: A3 and A4 become concrete lines, and F8 gets a stated floor.
- Quillmoor's full job page, if it has more than the advert: could confirm or change F2, F5 and F6.
- Company research (site, values, recent news): useful for later rounds, not needed for this screen.
