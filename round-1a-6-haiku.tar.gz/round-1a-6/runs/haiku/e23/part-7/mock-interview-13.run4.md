Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-7-rooms-case-13-denied-7eeb1ae1/cd4966b3-6a76-498f-9fd5-98ed02d2e0de/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. It's built from the advert, your message and Hannah's note. No CV was provided and I ran no web research.

**The four topics Hannah named**

- **Salary:** "I'm looking for around £42,000." That sits inside the advert's £38,000–£44,000 band. Say it once, then stop and let her respond. Don't offer a lower figure.
- **Notice period:** I don't have yours. Give the exact figure from your contract in one sentence.
- **Hybrid:** "Two days on site at Avonmouth works for me. I'd want to keep it to two, three at most."
- **Why you're moving:** "Our Bristol office is closing next year. The only option offered is relocating to Reading, which doesn't work for me. I'm looking for a role I can keep in Bristol." State the fact, don't criticise the company, and stop.

**The gaps**

- **SAP:** "I haven't used SAP. We ran our own in-house stock system." Then give your plan for learning it, in the future tense. Don't describe it as past experience.
- **Production planning and QA:** "The closest I've done is scheduling deliveries across three depots. I haven't coordinated production or worked with QA."
- **Excel:** your material doesn't name the functions you used. Anchor to the stock-count rebuild and say only what you actually did.
- **On-time dispatch reporting:** the advert asks for it weekly. If you've tracked dispatch figures, say what and how often. If not, say how you'd start.
- **Discrepancies:** say exactly what fell, which is discrepancies by about a third over a year. Don't turn it into an overall accuracy claim.

**Reverse questions**

1. What does a typical week look like across planning, the warehouse and QA?
2. Are the hybrid days fixed, or agreed with the team?
3. What stock or ERP system do you run, and is a change planned?
4. How is on-time dispatch measured and reported against target?
5. What are the next steps and the timeline?

**Practical**

- Keep your CV and the advert open on the call.
- Hannah will ring your mobile, so make sure it's charged and you're somewhere quiet.

I didn't read the skill's full question rubric, so the question types in the pack are plain labels, not its standard taxonomy.

Two offers, neither pushed:
- I can run a practice round where I play Hannah and push on the SAP and production gaps.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two questions:
1. What's your notice period?
2. Which Excel functions did you use in the stock-count sheet: lookups, pivots, formulas, or something else?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes, by phone on Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner
**Built from:** the advert, your message, and the call note from Hannah. No CV was provided and no research was run (provided documents only).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Guidance is scaffolding, not a script. Say it in your own words.
- Anything in quotation marks is your own sentence, or the advert's wording.

## Hannah's agenda, in her words

Salary expectations, notice period, how the hybrid pattern would work, what is prompting a move, then the team and next steps.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Lead with the four years and the job title. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | none | Name the three depots. This is your closest match to the role. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | Say exactly what fell: discrepancies, by about a third, over a year. Do not turn it into a claim about overall accuracy. |
| F4 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Words: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as a past. This is a plus, not a hard requirement. |
| F5 | "confident with Excel" (advert) | none given. The closest is the spreadsheet rebuild in F3. | low | [inferred] | discovery | Answer slot: which functions did you use in the stock-count sheet (lookups, pivots, formulas, something else)? Say only what you did. |
| F6 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | none given. You have said the production and QA side is new to you. | none | [grounded] | transferability | Words: "The closest I've done is scheduling deliveries across three depots. I haven't coordinated production or worked with QA." |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Answer slot: have you tracked on-time delivery or dispatch figures? If you have, say what and how often. If not, say so and say how you would start. |

## Prohibited claims

These are claims a candidate reaches for under pressure. This pack will not coach any of them:

- **SAP or ERP experience.** You have said you have not used SAP. Your own system is an in-house stock system, not an ERP.
- **Production planning or QA coordination.** Nothing in your material covers either.
- **On-time dispatch reporting**, unless you did it. The advert asks for it weekly; your material does not show it.
- **An overall accuracy figure.** The one-third is a fall in discrepancies, not a measured accuracy rate.

## Persona: recruiter screen

Hannah is screening. She is checking that you meet the basics and that the pay, notice and hybrid terms fit. Expect short, direct questions and a quick move to the next step.

## Question banks

Types, in plain terms: **Pay**, **Logistics**, **Gap**, **Motivation**, **Process**.

**R1. What are you hoping for in salary?** (Pay)
- **Provenance:** "I'm hoping for £42,000" (your message)
- **Guidance:** Say "I'm looking for around £42,000." That sits inside the advert's published £38,000–£44,000 band. Say it once, then stop and let her respond. Do not offer a lower figure.
- **Answer slot:** If she asks for your current salary, decide before the call whether you will give it. You may decline politely.

**R2. What is your notice period?** (Process)
- **Provenance:** none given
- **Guidance:** Answer slot. Use the exact figure from your contract, in one sentence.

**R3. How would the hybrid pattern work for you?** (Process)
- **Provenance:** "two days at Avonmouth is fine, but I wouldn't want more than three" (your message)
- **Guidance:** "Two days on site at Avonmouth works for me. I'd want to keep it to two, three at most." Keep it there.

**R4. What is prompting the move?** (Motivation)
- **Provenance:** "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message)
- **Guidance:** "Our Bristol office is closing next year. The only option offered is relocating to Reading, which doesn't work for me. I'm looking for a role I can keep in Bristol." State the fact, don't criticise the company, and stop.

**R5. Tell me about your experience with production planning or QA.** (Gap)
- **Provenance:** "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message)
- **Guidance:** "The closest I've done is scheduling deliveries across three depots. I haven't coordinated production or worked with QA." Then say what you would do to learn the production side. Do not stretch the delivery scheduling into production planning.

**R6. You haven't used SAP. How would you get up to speed?** (Gap)
- **Provenance:** "Never used SAP — we run our own in-house stock system." (your message)
- **Guidance:** "I haven't used SAP. We ran our own in-house stock system." Then your plan: which training, which module, how fast. Keep the plan in the future tense.

**R7. How confident are you with Excel?** (Gap)
- **Provenance:** "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message)
- **Guidance:** Answer slot. Anchor to the rebuild, and name the functions you actually used. If your Excel is basic, say so and point to the rebuild as the evidence.

**R8. Tell me about a time you chased a late order.** (Logistics)
- **Provenance:** "chase suppliers when orders slip" (your message)
- **Guidance:** Use one real example. Name the supplier type, what slipped, what you did, and the result. Keep it under 90 seconds.

## Reverse questions

Ask two or three. Each one is here because it tells you something real.

1. **What does a typical week look like across planning, the warehouse and QA?** It shows whether the role is mostly coordination or mostly firefighting.
2. **Is the hybrid pattern fixed days, or agreed with the team?** It tells you whether two days at Avonmouth stays two days.
3. **What stock or ERP system do you run, and is a change planned?** It shows whether the SAP gap is a hard skill the team needs on day one.
4. **What does on-time dispatch look like against target, and how is it reported?** It tells you what the weekly report actually measures.
5. **What are the next steps and the timeline?** It sets the pace and gives you a date to follow up.

## Sources

- Provided documents only: the advert, your message, and Hannah's call note.
- No searches or page fetches were run.

## Upgrade menu

- Your notice period → R2 becomes a complete answer you can rehearse.
- Your CV → the fit rows can quote your CV directly, and the Excel row (F5) can be grounded.
- Hannah's full advert or job description → the requirements can be quoted from the complete wording.
- Your current salary, if you decide to disclose it → R1 can include a planned answer.
