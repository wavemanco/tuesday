Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-7-rooms-case-13-denied-43ce11ed/b5df43f6-a10c-402a-bd83-3fa00e496eff/scratchpad/quillmoor_operations_coordinator_interview_pack.md. The pack is below. I built it for a recruiter screen, since Hannah's message sets the agenda.

# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep (for Sam)

Recruiter: Hannah Lowther, Talent Partner. Format: 30-minute phone call, Thursday 2pm, to the mobile on your application. Her agenda: salary expectations, notice period, how the hybrid pattern would work, what's prompting the move, then the team and next steps.

Research: none run. You haven't asked for it in this message, so every outside-facing row below is marked unavailable and the upgrade menu offers it.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements), EXP (what you actually did), VAL (company values), CO (company knowledge), CASE (a live problem). This screen uses JD and EXP only. There is no values round to prepare for and no live problem to solve.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Meets the years bar. Say the four years and the title as you wrote them, and make no further claim. |
| F2 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Your material shows a rebuilt spreadsheet, not a skill level. Use only this quote: "I rebuilt our stock-count spreadsheet." |
| F3 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" (your message); "we run our own in-house stock system" (your message) | none | [grounded] | capability | A stated absence, so the words are yours: "Never used SAP." Then how you would learn it, said as a plan and never as a past. The in-house system is adjacent, not ERP. |
| F4 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | low | [inferred] | transferability | Delivery scheduling across three depots is adjacent work. It does not show production scheduling or QA. Use the quote at its own scope. Answer slot: the advert raises production and QA scheduling, so expect a probe. If you coordinated either, say how; if not, say so plainly and describe the delivery scheduling you did. |
| F5 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Say "chase suppliers when orders slip" in those words. |
| F6 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Reaches the requirement. The one figure is "about a third" over "a year." Expect a probe on how it was counted (D1, D2). |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you produced a regular report on delivery timing, say what it measured and how often; if not, say so and say how you would track on-time dispatch. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met by your own stated constraint. Say "two days at Avonmouth is fine." |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Within the advertised band. Say "I'm hoping for £42,000." Your floor is not in the material (see upgrade menu). |
| F10 | "your notice period" (Hannah's message) | none given | none | [grounded] | hard_gate | Your material does not establish a notice period, and it is a term the recruiter will check. The figure comes from your contract (question below). |
| F11 | "what's prompting a move" (Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own statement, so it carries high confidence. Say it in its own order: the closure, the Reading offer, why you don't want it. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through your background," then the logistics questions | High. Recruiter screens run in this register, and the casual questions are still scored | Have a 60-second arc ready. Treat the warm questions as scored |
| Skeptic | Salary, notice and hybrid checks, and "why are you leaving" | High. Her stated agenda is a list of knockout checks, and F8 to F11 are where a screen tests fit | Short, exact answers. Bridge only from what you stated. Don't argue the band |
| Pressure | "Why should we hire you over someone who has run production planning?" | Low to medium. Screens rarely push hard, but the production gap (F4) is the likeliest push | Pause, restate, hold the coordination claim, concede the production gap plainly |
| Data-driven prober | "How was that third counted?" | Low to medium. The single figure on your CV is the only number she can check | Name the baseline if you have one. Say which assumption you'd defend least |

Weights: Conversational 4 questions, Skeptic 5, Pressure 2, Prober 2. The session total is 13, below the 18 floor for a full loop. A 30-minute screen cannot rehearse more, so the floor does not apply here.

## Prohibited claims

Built from the fit snapshot. Each entry gives its basis and its honest form. None of these may be coached, implied or softened in any answer below.

| Not coached | Basis | Honest form |
|---|---|---|
| ERP experience, or "I run an ERP" | Inflated form of "we run our own in-house stock system," plus your stated "Never used SAP" | "Never used SAP." and "we run our own in-house stock system." Your material shows an in-house system, not ERP |
| Production or QA scheduling | Inflated form of "I schedule deliveries for our three depots" | Quote it at its scope: deliveries, three depots |
| Advanced or expert Excel | Inflated form of "I rebuilt our stock-count spreadsheet" | "I rebuilt our stock-count spreadsheet." Name what you used only if you can list it |
| The whole third of the fall was yours | Attribution widened from "discrepancies fell by about a third over a year" | Quote the figure with "about" and "over a year." The part that is yours is in D2's slot |

## Question banks

Provenance comes before the guidance. Every quote is from the fit snapshot or from the advert or Hannah's message.

### Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background, and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Story-mapped on F1 and F5, in order: the four years and your title, the three depots you schedule deliveries for, chasing suppliers when orders slip. About 60 seconds. Add no duties to the list | The opener. Her JD checks, tracking deliveries and chasing late orders, are the first things she will match against |
| A2 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Give the figure as your contract states it. If it depends on a date or on an agreed release, say so in one sentence. Answer slot: your material does not establish a notice period, so the figure is yours to supply | F10, a hard gate. It is a knockout check she asked for by name |
| A3 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the closure, then the Reading offer, then why you don't want it, in that order and your words. Then stop. Answer slot: if there is another reason you are looking, say it; if there is not, the closure is the reason | F11. The motivation probe is answered by the sentence you already wrote, and a second reason would have to be yours |
| A4 | "How would the hybrid pattern work for you, two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth is fine." Stop and let her respond. Give the three-day ceiling only if she asks about more days | F8. Volunteering the ceiling invites a counter on days the advert does not offer |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message); "£38,000–£44,000" (advert) | "I'm hoping for £42,000." If she presses on flexibility, say you'd want to see the full package. Answer slot: if you have a lowest acceptable figure, decide it before Thursday and say it only if asked directly | F9. Pay is a term, and your stated figure sits inside the band |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); "coordinate production schedules between planning, the warehouse and QA" (advert) | Answer slot: the advert raises production and QA scheduling. If you coordinated production or QA schedules, say how and when, in your own words. If you did not, say so plainly and return to the deliveries you scheduled for three depots. Hold through two follow-ups by returning to the deliveries | F4. This is the highest-ROI rehearsal in the pack: a manufacturer is hiring a wholesaler's coordinator for production work, so this is the probe most likely to come |
| B3 | "The advert lists SAP or similar ERP as a plus. Have you used either?" | JD | [grounded] "Never used SAP" (your message); "we run our own in-house stock system" (your message) | "Never used SAP." Then: "We run our own in-house stock system." Then, as a plan, how you would learn the ERP. Do not say you know an ERP, or that the in-house system is one | F3. A plus, stated absence, and a plan. The plan is the only forward claim |
| B4 | "How would you rate your Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | "I rebuilt our stock-count spreadsheet." Stop there. Answer slot: if she asks which functions you used, name the ones you used, and if you cannot list them, say so | F2. The sentence is the only evidence, so the rating is not yours to give beyond it |
| B5 | "The role reports weekly on on-time dispatch. Have you produced anything like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert). No candidate quote | Answer slot: if you produced a regular report on delivery timing, say what it measured and how often. If you did not, say so plainly, then say how you would track on-time dispatch | F7. A JD line with no evidence in your material, which makes it a likely miss |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has run production planning?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Pause, then restate the question in your words. Hold: the four years of scheduling, chasing and stock accuracy are the logistics side of this role. Hold through two follow-ups on that. Concede: production planning is new to you; say what you would do first to learn it | F4 and F6. Hold-then-concede: hold what the quotes carry, concede the production gap in words |
| C2 | "Isn't this really a job search that started with a closure?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message); "Avonmouth site in Bristol" (advert) | Hold: "Yes, the closure is why I'm looking now." Then: "I don't want to move to Reading, and this role is in Bristol." Concede nothing you do not mean | F11. Motivation consistency under light pressure |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that third was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Say what the discrepancy count was, over which year, and the baseline if you have one. Answer slot: if you can describe how discrepancies were counted, say how; if the count came from somewhere else, or you do not know its method, say so plainly. Name the assumption you would defend least, in your own words | F6. The one CV figure is the thing a prober checks first |
| D2 | "How much of that third would you say was down to you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Answer slot: if you can separate your rebuild's share from the rest of the year, say how. If you cannot, say that plainly. Do not put a percentage on your share | F6. Weakest-assumption move, asked of the figure and not of the rebuild |

### Coverage: JD requirements to question IDs

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | B4 |
| ERP (SAP or similar), a plus | B3 |
| Coordinate production schedules between planning, the warehouse and QA | B2, C1 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | D1, D2 |
| Report weekly on on-time dispatch | B5 (none, and why: no candidate quote, so the answer is a slot) |
| Hybrid: two days a week at Avonmouth | A4 |
| Pay £38,000 to £44,000 | B1 |
| Notice period (her agenda) | A2 |
| What is prompting the move (her agenda) | A3, C2 |

## Reverse questions

Each one carries why it lands. No interviewer profile exists, so none is tied to a career path.

1. "Which teams would I be coordinating with day to day: planning, the warehouse, QA?" Why it lands: the advert names three functions, and this shows you read the seam.
2. "How is the on-time dispatch report produced now, and who reads it?" Why it lands: it shows you noticed the weekly reporting line, and it gets you the real process.
3. "Is SAP experience something I'd be trained on, or needed from day one?" Why it lands: the advert calls it a plus, and this asks what the plus means in practice.
4. "How many days a week does the team actually sit at Avonmouth, and does that differ by team?" Why it lands: it tests the hybrid pattern against the advert's "two days" without arguing it.
5. "What are the next steps after this call, and how long does each stage take?" Why it lands: it is the question her agenda ends on, and it gives you the timeline.

## Sources

- Provided documents: the advert, your message (background, constraints, reason for moving), and Hannah Lowther's LinkedIn message (call details and agenda).
- Searches and fetches: none.

Research tier: L0. Research was not run because you did not ask for it in this message.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet (not included: no values round is detected for a screen). Would have added company language |
| 2. Quillmoor interview process, Operations | unavailable | Loop structure. This screen's agenda is fixed by Hannah's message, so the loop would only add the later rounds |
| 3. Quillmoor strategy and recent news | unavailable | Company context for the reverse questions. Not run |
| 4. Hannah Lowther, Quillmoor | unavailable | Public footprint for the reverse questions. Not run |
| 5. Representative Operations Coordinator JD | skipped | Your advert fixes the fit snapshot and the JD questions, so a representative JD would not move any output |

## Upgrade menu

- Your lowest acceptable salary → B1 gets a decided floor and a fallback line. Without it, B1 stays at "I'm hoping for £42,000."
- Any production or QA scheduling you did, however small → B2 and C1 become quote-backed stories. Without it, both stay answer slots.
- Any regular report on delivery timing → B5 gets a quote-backed answer. Without it, B5 stays a slot.
- The Excel functions you used in the stock-count spreadsheet → B4 names them. Without them, B4 stays at the one quote.
- Research at the one-search tier (Quillmoor values, recent news, and Hannah's public profile) → rows 1 to 4 of the target accounting, and reverse questions 1 and 2 tuned to what they find.
- Hannah's pre-call email, if she sent one → coverage of any deliverable she named. None is in the material.

---

Say "drill" and I'll play Hannah on B2, the question the pack names as the highest-ROI prep, and give feedback against its guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period, as your contract states it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep (for Sam)

Recruiter: Hannah Lowther, Talent Partner. Format: 30-minute phone call, Thursday 2pm, to the mobile on your application. Her agenda: salary expectations, notice period, how the hybrid pattern would work, what's prompting the move, then the team and next steps.

Research: none run. You haven't asked for it in this message, so every outside-facing row below is marked unavailable and the upgrade menu offers it.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements), EXP (what you actually did), VAL (company values), CO (company knowledge), CASE (a live problem). This screen uses JD and EXP only. There is no values round to prepare for and no live problem to solve.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Meets the years bar. Say the four years and the title as you wrote them, and make no further claim. |
| F2 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Your material shows a rebuilt spreadsheet, not a skill level. Use only this quote: "I rebuilt our stock-count spreadsheet." |
| F3 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" (your message); "we run our own in-house stock system" (your message) | none | [grounded] | capability | A stated absence, so the words are yours: "Never used SAP." Then how you would learn it, said as a plan and never as a past. The in-house system is adjacent, not ERP. |
| F4 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | low | [inferred] | transferability | Delivery scheduling across three depots is adjacent work. It does not show production scheduling or QA. Use the quote at its own scope. Answer slot: the advert raises production and QA scheduling, so expect a probe. If you coordinated either, say how; if not, say so plainly and describe the delivery scheduling you did. |
| F5 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Say "chase suppliers when orders slip" in those words. |
| F6 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Reaches the requirement. The one figure is "about a third" over "a year." Expect a probe on how it was counted (D1, D2). |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you produced a regular report on delivery timing, say what it measured and how often; if not, say so and say how you would track on-time dispatch. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met by your own stated constraint. Say "two days at Avonmouth is fine." |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Within the advertised band. Say "I'm hoping for £42,000." Your floor is not in the material (see upgrade menu). |
| F10 | "your notice period" (Hannah's message) | none given | none | [grounded] | hard_gate | Your material does not establish a notice period, and it is a term the recruiter will check. The figure comes from your contract (question below). |
| F11 | "what's prompting a move" (Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own statement, so it carries high confidence. Say it in its own order: the closure, the Reading offer, why you don't want it. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through your background," then the logistics questions | High. Recruiter screens run in this register, and the casual questions are still scored | Have a 60-second arc ready. Treat the warm questions as scored |
| Skeptic | Salary, notice and hybrid checks, and "why are you leaving" | High. Her stated agenda is a list of knockout checks, and F8 to F11 are where a screen tests fit | Short, exact answers. Bridge only from what you stated. Don't argue the band |
| Pressure | "Why should we hire you over someone who has run production planning?" | Low to medium. Screens rarely push hard, but the production gap (F4) is the likeliest push | Pause, restate, hold the coordination claim, concede the production gap plainly |
| Data-driven prober | "How was that third counted?" | Low to medium. The single figure on your CV is the only number she can check | Name the baseline if you have one. Say which assumption you'd defend least |

Weights: Conversational 4 questions, Skeptic 5, Pressure 2, Prober 2. The session total is 13, below the 18 floor for a full loop. A 30-minute screen cannot rehearse more, so the floor does not apply here.

## Prohibited claims

Built from the fit snapshot. Each entry gives its basis and its honest form. None of these may be coached, implied or softened in any answer below.

| Not coached | Basis | Honest form |
|---|---|---|
| ERP experience, or "I run an ERP" | Inflated form of "we run our own in-house stock system," plus your stated "Never used SAP" | "Never used SAP." and "we run our own in-house stock system." Your material shows an in-house system, not ERP |
| Production or QA scheduling | Inflated form of "I schedule deliveries for our three depots" | Quote it at its scope: deliveries, three depots |
| Advanced or expert Excel | Inflated form of "I rebuilt our stock-count spreadsheet" | "I rebuilt our stock-count spreadsheet." Name what you used only if you can list it |
| The whole third of the fall was yours | Attribution widened from "discrepancies fell by about a third over a year" | Quote the figure with "about" and "over a year." The part that is yours is in D2's slot |

## Question banks

Provenance comes before the guidance. Every quote is from the fit snapshot or from the advert or Hannah's message.

### Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background, and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Story-mapped on F1 and F5, in order: the four years and your title, the three depots you schedule deliveries for, chasing suppliers when orders slip. About 60 seconds. Add no duties to the list | The opener. Her JD checks, tracking deliveries and chasing late orders, are the first things she will match against |
| A2 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Give the figure as your contract states it. If it depends on a date or on an agreed release, say so in one sentence. Answer slot: your material does not establish a notice period, so the figure is yours to supply | F10, a hard gate. It is a knockout check she asked for by name |
| A3 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the closure, then the Reading offer, then why you don't want it, in that order and your words. Then stop. Answer slot: if there is another reason you are looking, say it; if there is not, the closure is the reason | F11. The motivation probe is answered by the sentence you already wrote, and a second reason would have to be yours |
| A4 | "How would the hybrid pattern work for you, two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth is fine." Stop and let her respond. Give the three-day ceiling only if she asks about more days | F8. Volunteering the ceiling invites a counter on days the advert does not offer |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message); "£38,000–£44,000" (advert) | "I'm hoping for £42,000." If she presses on flexibility, say you'd want to see the full package. Answer slot: if you have a lowest acceptable figure, decide it before Thursday and say it only if asked directly | F9. Pay is a term, and your stated figure sits inside the band |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); "coordinate production schedules between planning, the warehouse and QA" (advert) | Answer slot: the advert raises production and QA scheduling. If you coordinated production or QA schedules, say how and when, in your own words. If you did not, say so plainly and return to the deliveries you scheduled for three depots. Hold through two follow-ups by returning to the deliveries | F4. This is the highest-ROI rehearsal in the pack: a manufacturer is hiring a wholesaler's coordinator for production work, so this is the probe most likely to come |
| B3 | "The advert lists SAP or similar ERP as a plus. Have you used either?" | JD | [grounded] "Never used SAP" (your message); "we run our own in-house stock system" (your message) | "Never used SAP." Then: "We run our own in-house stock system." Then, as a plan, how you would learn the ERP. Do not say you know an ERP, or that the in-house system is one | F3. A plus, stated absence, and a plan. The plan is the only forward claim |
| B4 | "How would you rate your Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | "I rebuilt our stock-count spreadsheet." Stop there. Answer slot: if she asks which functions you used, name the ones you used, and if you cannot list them, say so | F2. The sentence is the only evidence, so the rating is not yours to give beyond it |
| B5 | "The role reports weekly on on-time dispatch. Have you produced anything like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert). No candidate quote | Answer slot: if you produced a regular report on delivery timing, say what it measured and how often. If you did not, say so plainly, then say how you would track on-time dispatch | F7. A JD line with no evidence in your material, which makes it a likely miss |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has run production planning?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Pause, then restate the question in your words. Hold: the four years of scheduling, chasing and stock accuracy are the logistics side of this role. Hold through two follow-ups on that. Concede: production planning is new to you; say what you would do first to learn it | F4 and F6. Hold-then-concede: hold what the quotes carry, concede the production gap in words |
| C2 | "Isn't this really a job search that started with a closure?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message); "Avonmouth site in Bristol" (advert) | Hold: "Yes, the closure is why I'm looking now." Then: "I don't want to move to Reading, and this role is in Bristol." Concede nothing you do not mean | F11. Motivation consistency under light pressure |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that third was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Say what the discrepancy count was, over which year, and the baseline if you have one. Answer slot: if you can describe how discrepancies were counted, say how; if the count came from somewhere else, or you do not know its method, say so plainly. Name the assumption you would defend least, in your own words | F6. The one CV figure is the thing a prober checks first |
| D2 | "How much of that third would you say was down to you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Answer slot: if you can separate your rebuild's share from the rest of the year, say how. If you cannot, say that plainly. Do not put a percentage on your share | F6. Weakest-assumption move, asked of the figure and not of the rebuild |

### Coverage: JD requirements to question IDs

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | B4 |
| ERP (SAP or similar), a plus | B3 |
| Coordinate production schedules between planning, the warehouse and QA | B2, C1 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | D1, D2 |
| Report weekly on on-time dispatch | B5 (none, and why: no candidate quote, so the answer is a slot) |
| Hybrid: two days a week at Avonmouth | A4 |
| Pay £38,000 to £44,000 | B1 |
| Notice period (her agenda) | A2 |
| What is prompting the move (her agenda) | A3, C2 |

## Reverse questions

Each one carries why it lands. No interviewer profile exists, so none is tied to a career path.

1. "Which teams would I be coordinating with day to day: planning, the warehouse, QA?" Why it lands: the advert names three functions, and this shows you read the seam.
2. "How is the on-time dispatch report produced now, and who reads it?" Why it lands: it shows you noticed the weekly reporting line, and it gets you the real process.
3. "Is SAP experience something I'd be trained on, or needed from day one?" Why it lands: the advert calls it a plus, and this asks what the plus means in practice.
4. "How many days a week does the team actually sit at Avonmouth, and does that differ by team?" Why it lands: it tests the hybrid pattern against the advert's "two days" without arguing it.
5. "What are the next steps after this call, and how long does each stage take?" Why it lands: it is the question her agenda ends on, and it gives you the timeline.

## Sources

- Provided documents: the advert, your message (background, constraints, reason for moving), and Hannah Lowther's LinkedIn message (call details and agenda).
- Searches and fetches: none.

Research tier: L0. Research was not run because you did not ask for it in this message.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet (not included: no values round is detected for a screen). Would have added company language |
| 2. Quillmoor interview process, Operations | unavailable | Loop structure. This screen's agenda is fixed by Hannah's message, so the loop would only add the later rounds |
| 3. Quillmoor strategy and recent news | unavailable | Company context for the reverse questions. Not run |
| 4. Hannah Lowther, Quillmoor | unavailable | Public footprint for the reverse questions. Not run |
| 5. Representative Operations Coordinator JD | skipped | Your advert fixes the fit snapshot and the JD questions, so a representative JD would not move any output |

## Upgrade menu

- Your lowest acceptable salary → B1 gets a decided floor and a fallback line. Without it, B1 stays at "I'm hoping for £42,000."
- Any production or QA scheduling you did, however small → B2 and C1 become quote-backed stories. Without it, both stay answer slots.
- Any regular report on delivery timing → B5 gets a quote-backed answer. Without it, B5 stays a slot.
- The Excel functions you used in the stock-count spreadsheet → B4 names them. Without them, B4 stays at the one quote.
- Research at the one-search tier (Quillmoor values, recent news, and Hannah's public profile) → rows 1 to 4 of the target accounting, and reverse questions 1 and 2 tuned to what they find.
- Hannah's pre-call email, if she sent one → coverage of any deliverable she named. None is in the material.
