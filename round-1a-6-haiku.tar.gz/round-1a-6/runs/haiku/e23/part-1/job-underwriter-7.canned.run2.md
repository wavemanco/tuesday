**Yes, worth applying, on one condition: `conditional_go`.** Your CV meets the registration, licence and experience requirements and most of the clinical work. The condition is pay: the advert gives £31,050–£37,800 plus mileage, and I don't have your floor. If that floor sits above the band, the answer becomes no.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3 · unclear: R4 (salary £31,050–£37,800 plus mileage)
- `must_have` — direct: R5, R8a, R10 · adjacent: R7 (wound and leg-ulcer care) · unclear: R6 (clear, timely written records), R8b (continence care), R9 (end-of-life visits), R11 (care planning)
- `important` — adjacent: R12 (own caseload, supported by a senior nurse) · unclear: R13 (electronic patient record)
- `preferred` — absent: R14 (Doppler assessment for leg ulcers)

R7 is a credible bridge from pressure-ulcer and surgical-wound care, with leg ulcers not yet named. R12 is adjacent because your discharge-to-assess visits were home visits, but you have never held a caseload of your own.

**Opportunity ledger.** The advert is clear about scope, pool cars and a named contact (RR4, RR5), with the caseload size, the employer's live posting and the pay band still unknown (RR1–RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (salary £31,050–£37,800 plus mileage)
- **Severe red flags:** none found
- **Conditions for go:** (1) your pay floor sits at or below £31,050, so R4 clears; (2) the role is confirmed live on the employer's careers page, RR2; (3) the caseload is confirmed workable in the interview, RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` advert |
| Mandate | District nursing for housebound adults in their own homes | `[grounded]` advert |
| Working pattern | Home visits, pool cars provided, own small caseload with senior nurse support | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Scope read | A post with its own caseload and clinical breadth across wound, catheter, insulin and end-of-life care | `[inferred]` from the listed duties |
| Market calibration | Not run. No role-family sweep at this research tier, so the pay band is uncalibrated | — |
| Unknowns | Caseload size and acuity, continence and end-of-life scope, records system, care-planning ownership, your pay floor | — |
| Contradictions | None visible within the advert | `[grounded]` advert |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | CV states active registration, revalidation March 2028; not yet probed | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states full licence, category B | `[grounded]` CV | none |
| R3 | Working base in Halifax | hard_gate | direct | medium | none | You live in Halifax; the advert places the team in Halifax | `[grounded]` CV and advert; `[inferred]` that this is the working base | none |
| R4 | Salary £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | Fit unclear because your floor is not given; the band itself is stated | `[grounded]` advert | Q1 below |
| R5 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R6 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on record-keeping | `[grounded]` CV silence | G6 |
| R7 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carry over; leg ulcers are not named. Limit: leg-ulcer care not exercised per your CV | `[grounded]` CV; `[inferred]` adjacency | G1 |
| R8a | Catheter care | must_have | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R8b | Continence care | must_have | unclear | low | discovery | CV is silent on continence | `[grounded]` CV silence | G3 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV is silent on end-of-life care | `[grounded]` CV silence | G4 |
| R10 | Insulin administration | must_have | direct | medium | none | CV names insulin administration | `[grounded]` CV | none |
| R11 | Care planning | must_have | unclear | low | discovery | CV does not say whether you planned care or only carried out plans | `[grounded]` CV silence | G5 |
| R12 | Own caseload, supported by a senior nurse | important | adjacent | medium | transferability | Discharge-to-assess home visits are the nearest thing. Limit: you have never held your own caseload | `[grounded]` CV; `[inferred]` adjacency | G2 |
| R13 | Electronic patient record | important | unclear | low | discovery | CV does not name the records system | `[grounded]` CV silence | G6 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence; you have said you have never done one | `[grounded]` CV | G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7, must_have) | transferability | Wound care is evidenced; leg ulcers are not | Leg ulcers are named first in the duties | Any leg-ulcer dressing or compression work on the ward or at home | Anonymised wound-care entry or care plan | `[inferred]` bridge; `[generic]` that this is the likely objection |
| G2 | Own caseload (R12, important) | transferability | Home visits with a supporting nurse, no caseload of your own | The advert promises one | Patients you were assigned during discharge-to-assess | Visit schedule or handover format | `[inferred]` |
| G3 | Continence care (R8b, must_have) | discovery | No continence work in the CV | Named in the same duty as catheter care | Continence assessments or product choices during home visits | Continence assessment record | `[grounded]` CV silence |
| G4 | End-of-life visits (R9, must_have) | discovery | No end-of-life work in the CV | A core duty of the post | Any end-of-life care on the ward or in the discharge team | A handover or care plan with the end-of-life element | `[grounded]` CV silence |
| G5 | Care planning (R11, must_have) | discovery | CV is silent on who wrote plans | Care planning is the caseload holder's job | Writing or revising plans during discharge-to-assess | Anonymised care plan | `[grounded]` CV silence |
| G6 | Records and EPR (R6, R13) | discovery | No record-keeping evidence | Written records are essential | Charting on a system, timely documentation | Anonymised entry | `[grounded]` CV silence |
| G7 | Doppler (R14, preferred) | capability | No evidence | Preferred only | None | None | `[grounded]` CV |

**G7 closure path:** a Doppler course, or naming a Doppler course you can book before interview, carried as a minor risk. It is not a blocker.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and acuity not stated | unknown | — | "a small caseload of your own" | "Small" may mean a large number of complex patients | `[inferred]` from the advert's silence on numbers | How many patients would I typically carry, and how is the caseload weighted for acuity? | unresolved |
| RR2 | Employer and posting not independently verified | unknown | — | "Calderbrook Community Health CIC, Halifax" | The advert may be out of date, or may not reflect current hiring | `[inferred]` from a single pasted advert with no link | Is this role live on your careers page, and what is the closing date? | unresolved |
| RR3 | Pay band not calibrated | unknown | — | "£31,050–£37,800 a year plus mileage" | The band may or may not be typical for this post | No market claim made; research not run | How does progression work across the band, and how is mileage paid? | unresolved |
| RR4 | Named contact and informal chat offered | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | A transparent, low-pressure route in | `[grounded]` advert | What does a typical week look like for someone new to a caseload? | noted |
| RR5 | Pool cars provided | positive_signal | — | "pool cars are provided" | Reduces the cost and wear of home visits | `[grounded]` advert | Are pool cars shared, and how is mileage paid on top? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Work out your pay floor and check it against £31,050 plus mileage | R4, RR3 | `[grounded]` R4 | awaiting you |
| P2 | Ask RR1 and RR5 verbatim at the informal chat with Rhiannon Mabbott | RR1, RR5 | `[grounded]` register | pending your approval |
| P3 | Keep "wound care including pressure ulcers and surgical wounds" as written; add leg-ulcer work only if G1 turns up evidence | R7 | `[grounded]` CV | pending your approval |
| P4 | Lead with your discharge-to-assess home visits as the nearest thing to a caseload | R12 | `[inferred]` | pending your approval |
| P5 | Name a Doppler course you can book, as a training gap with a closure path | R14 | `[generic]` closure pattern | pending your approval |

Nothing here goes into a CV, cover letter or outreach until you approve it.

## Evidence status

Verified: none yet. Your CV claims are leads until you confirm them under probing.

Research tier: L0 — no searches; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | L0 run, research not yet consented. Would confirm the employer and live posting (RR2) |
| 2. Role-family sweep | unavailable | L0 run, research not yet consented. Would calibrate the pay band (R4, RR3) |
| 3. Hiring manager's public footprint | unavailable | L0 run, research not yet consented. Rhiannon Mabbott is named as team lead; a public professional profile would show how the team is described |

**Dossier offer:** I can save this as `tuesday-dossier.md` for mock-interview to use later, if you want it.

## Upgrade menu

- A light research pass (up to 5 searches and 2 fetches) → confirms the employer and posting (RR2) and sets the pay band (R4, RR3)
- Your pay floor → R4 closes, and the decision firms up
- Any leg-ulcer work, in any setting → R7 moves
- An anonymised record or care plan → R6 and R13 move
- A booked Doppler course → R14 gains a closure path
- A public professional profile for Rhiannon Mabbott → shows the team's scope

## Questions

R4 — What is your lowest acceptable salary, and does £31,050 plus mileage clear it?

G1 (R7) — Have you dressed or assessed leg ulcers on the ward or in a patient's home, even if it wasn't labelled leg-ulcer care?

G4 (R9) — Did you give or coordinate any end-of-life care, on the ward or during your home visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.