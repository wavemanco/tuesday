I'll run the consented default research tier (L1) on the employer and role, starting with the employer's footprint and the role-family pay band. I'm leaving your name and details out of every query.
**Yes, worth applying, on conditions.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R7 · adjacent: R5b (leg-ulcer care) · unclear: R4 (written records), R6b (continence care)
- `important`: direct: R11 (home-based work) · adjacent: R8 (care planning) · unclear: R9 (end-of-life visits), R10 (holding a caseload)
- `preferred`: absent: R12 (Doppler assessment)

What matters: R10, your caseload experience, is not established either way; R4, written records on an electronic record, is unevidenced; R5b, leg-ulcer care, is a bridge from wound care with its limit named; R12, Doppler, is absent and desirable only.

**Opportunity ledger.** Sound. The pay sits inside the surveyed market band, and the posting defines its essentials clearly (RR3, RR4, both positive). Two entries stay open: the vacancy is not yet confirmed live on the careers page (RR1), and the caseload size is unquantified (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the vacancy is confirmed live (RR1); (2) the caseload model is confirmed as a supported caseload of your own (R10, RR2); (3) the records standard and the electronic record are confirmed at interview (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: an NHS-contracted community interest company, founded 2015, 410 staff across four locality hubs | `[grounded]` about page |
| Mandate | District nursing for housebound adults in their own homes, with a small personal caseload supported by a senior community nurse | `[grounded]` posting |
| Working pattern | Home visits, pool cars provided, mileage paid | `[grounded]` posting |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` posting |
| Market calibration | Surveyed median for band 5 community staff nurses is £34,300, interquartile range £32,400–£36,600. The posting's bottom figure sits just under that floor and its top sits above the range | `[generic]` Wardround 2026 pay guide, England, n=1,240 |
| Scope read | A normally scoped band 5 post: a caseload with senior support is ordinary for the grade | `[inferred]` from the posting's stated structure |
| Unknowns | Whether the vacancy is live on the careers page; caseload size; which electronic record system is used; the mileage rate | — |
| Contradictions | None between the posting and the about page. The careers page itself was not located | `[grounded]` about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | high | none | Adult-field registration, active, revalidation due March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Full licence, category B; pool cars provided, so the requirement is met as written | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV describes no documentation standard and names no electronic record system | `[grounded]` CV silence | G4 |
| R5a | Wound care | must_have | direct | high | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over; leg ulcers are not named. Limit: no leg-ulcer work stated | `[inferred]` adjacency from R5a | G1 |
| R6a | Catheter care | must_have | direct | high | none | Stated on the CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not stated on the CV | `[grounded]` CV silence | none; ask if relevant |
| R7 | Insulin administration | must_have | direct | high | none | Stated on the CV | `[grounded]` CV | none |
| R8 | Care planning | important | adjacent | medium | transferability | Discharge assessment visits involve planning for the first week at home. Limit: no care-plan authorship stated | `[inferred]` from discharge-to-assess work | none |
| R9 | End-of-life visits | important | unclear | low | discovery | Not stated on the CV | `[grounded]` CV silence | none |
| R10 | Holding a small caseload with senior support | important | unclear | low | discovery | The CV says you have never held your own caseload. Whether the discharge-to-assess visits were your own allocation is not stated | `[grounded]` CV | G3 |
| R11 | Working in patients' homes | important | direct | high | none | Eighteen months of home visits in the first week after discharge | `[grounded]` CV | none |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler evidence on the CV | `[grounded]` CV | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | transferability | Pressure-ulcer and surgical wound care, both direct; leg ulcers not named | Leg-ulcer care is the first duty listed, so the bridge needs a stated limit | Any leg-ulcer dressing or review, including in home visits; wound training that covered venous ulcers | A wound-care training record; a de-identified dressing plan | `[inferred]` bridge from CV wound-care entries; `[generic]` that leg ulcers feature in community listings |
| G2 | Doppler assessment (R12, preferred) | capability | No Doppler evidence | Desirable rather than essential, so a minor risk | None on the CV | A course booking or training plan | `[grounded]` CV silence; closure path is a course or in-house training |
| G3 | Holding a caseload (R10, important) | discovery | Never held your own caseload; the discharge-to-assess allocation is not stated | The role is built around a caseload, so it matters for both fit and the caseload conditions | Any list of patients you were responsible for, and who set your visit order | A de-identified visit schedule or allocation note | `[grounded]` CV |
| G4 | Written records on an electronic record (R4, must_have) | discovery | Not stated on the CV | An essential criterion, likely probed at interview | Any electronic record you documented in; handover and timeliness practice | A de-identified note | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not located on the careers page | unknown | — | "Current vacancies are listed on our careers page." | The listing may be closed, stale, or aggregated | `[generic]` pattern for listings; `[grounded]` the about page's careers claim | Is this Community Staff Nurse vacancy live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Caseload size and senior support unquantified | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" could mean a large list in practice, with support limited to ad hoc advice | `[inferred]` from the unquantified "small" | What is the target caseload for this band, and how often does the senior community nurse review cases? | unresolved |
| RR3 | Pay within the surveyed band; mileage and pool cars provided | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Pay is competitive for the grade, with the bottom end near the surveyed floor | `[generic]` Wardround interquartile range; `[grounded]` posting | What is the mileage rate, and is a pool car available to every community nurse? | noted |
| RR4 | Employer established as a real NHS-contracted provider | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | A stable local provider with an NHS contract | `[grounded]` about page | Which locality hub would this role sit in? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the vacancy is live on the careers page, or ask the recruiter for the link, before applying | see RR1 | `[grounded]` about page | proposed |
| P2 | Describe the discharge-to-assess work as home visits in the first week after discharge, with no claim of caseload or Doppler experience | see R10, R12; the audit found no new claim in this wording | `[grounded]` CV | pending your approval |
| P3 | Interview framing for leg ulcers: "I have dressed pressure and surgical wounds at home and have not yet done leg-ulcer assessment; Doppler is my next training step" | see R5b, R12 | `[grounded]` CV | pending your approval |
| P4 | Read the public talk by the Community Nursing Team Lead on leg-ulcer clinics and Doppler training before any interview, and ask about the Doppler training route | see R12; the talk is public professional material | `[grounded]` public forum listing | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse band 5 careers"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Role reality: the employer is established. The careers page was not located, so RR1 stays unresolved |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary £31,050 £37,800"; fetched "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Halifax", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott); the snippet only, not fetched. Application plan P4 |

## Upgrade menu

- A caseload or discharge-to-assess allocation note → R10 and RR2 close, and the decision may simplify to `go`.
- A leg-ulcer case, wound-training record or Doppler course booking → R5b moves toward direct, or R12 gets a closure path.
- The live posting link, or the recruiter's email → RR1 closes.
- A deeper research pass on Calderbrook (leadership changes, recruitment history, staff reviews; forum-sourced claims labeled `[inferred]` at most): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want, I can save this as a `tuesday-dossier.md` file to carry into interview prep.

Three questions, each tagged to its row:

G3 — In discharge-to-assess, who decided which patients you visited and in what order? Did you ever own a list of patients with decisions about their care?
G4 — Which electronic patient record have you documented in, and how did you keep notes current when visits ran back to back?
G1 — Have you dressed or assessed any leg ulcers, including during home visits?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.