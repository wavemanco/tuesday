**Yes, it's worth applying for, as `conditional_go`.** Your core nursing skills match the role, and nothing in the posting is a red flag. The conditions are that the post is confirmed live and permanent, and that you can describe your caseload gap honestly. Your pay floor, contract preference and shift limits weren't given, so I could not run the checks against them.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5a, R6a, R7a · adjacent: R5b (leg-ulcer care, named limit: not yet done), R7b (care planning, named limit: discharge visits, not an ongoing plan), R9 (caseload, named limit: never held your own) · unclear: R4 (written records, system not named), R6b (continence care, not in CV), R8 (end-of-life visits, not in CV)
- `preferred` — absent: R10 (Doppler assessment)

R9 is the one that matters most: it is a must-have the posting says outright, and your home-visiting experience is adjacent to it, not the same thing. R10 is preferred, so it is a minor risk, not a blocker.

**Opportunity ledger.** Sound, with no severe red flags. The support for the caseload is stated (RR1, positive), but the post itself is not confirmed on the employer's careers page (RR2), and the contract basis and mileage rate are unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR2 and RR3 resolve to a live, permanent post; (2) R9 is framed as adjacent with its limit stated; (3) R10 is presented as a gap with a closure plan, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract across Calderdale, founded 2015, 410 staff | `[grounded]` employer's About page, from search |
| Role | District nursing for housebound adults in their homes; a small personal caseload with senior community nurse support | `[grounded]` JD |
| Working pattern | Home visits; pool cars provided; mileage paid on top of salary | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage; position in the band not stated | `[grounded]` JD |
| Market calibration | Band 5 community staff nurse, England, 2026: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage, 24% with a pool or lease car. The posting's range brackets the median, and its floor sits below the interquartile range. This is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide, from search |
| Hiring lead | Rhiannon Mabbott, Community Nursing Team Lead; a public speaker on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page, from search |
| Scope read | A small caseload with senior support is ordinary for this title | `[inferred]` from the JD's own description |
| Unknowns | Contract basis; mileage rate; where in the band the offer starts; whether the post is currently advertised; whether the employer offers Doppler training | — |
| Contradictions | None found between the JD and the About page. The careers page could not be reached, so the post's status is unverified, not contradicted | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Registration and PIN stated as active, revalidation March 2028; not checked against the NMC register | `[grounded]` your CV | Check your NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full category B stated; licence not inspected | `[grounded]` your CV | none |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse, acute medical ward; CV only | `[grounded]` your CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | CV does not name the records system or how notes were kept | `[grounded]` CV silence | Gap queue G1 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated; CV only | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound assessment and dressing skills carry over; no leg ulcers named. Limit: not yet done | `[grounded]` CV for wound skills; `[inferred]` adjacency | Gap queue G4 |
| R6a | Catheter care | must_have | direct | medium | none | Stated; CV only | `[grounded]` your CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | Upgrade menu |
| R7a | Insulin administration | must_have | direct | medium | none | Stated; CV only | `[grounded]` your CV | none |
| R7b | Care planning | must_have | adjacent | medium | transferability | Discharge-to-assess planning for the first week; not ongoing care for a caseload. Limit: planning owned over days, not months | `[inferred]` from the discharge role | Gap queue G4 |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not in the CV; acute ward work may include end-of-life care, unstated | `[grounded]` CV silence | Upgrade menu |
| R9 | Holding a small caseload of your own | must_have | adjacent | medium | transferability | Home visits are direct; an owned ongoing caseload is not. Limit: never held one | `[grounded]` CV; `[inferred]` adjacency | Gap queue G2; question 2 |
| R10 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done | `[grounded]` your CV | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | CV does not name the records system or how timely notes were kept | Records are a named essential; a named system closes the question | Notes written on the ward or during discharge visits; any electronic record you used | Named system; a sample of anonymised note style | `[grounded]` CV silence |
| G2 | Own caseload (R9, must_have) | transferability | Home visits in the first week after discharge, not a continuing caseload | The posting's central role; the bridge must state its limit | Any patients you followed up across several visits; any care you planned and reviewed yourself | Discharge visit records, anonymised | `[inferred]` bridge from the discharge role |
| G3 | Doppler assessment (R10, preferred) | capability | Never done | Preferred only, so a minor risk; a training route closes it | A course booked, or a supervised first assessment | Training booking or plan | `[generic]` that employers often train new staff in Doppler |
| G4 | Leg-ulcer and care planning (R5b, R7b, must_have) | transferability | Wound skills are direct; leg ulcers and ongoing planning are not | Both are named in the posting's own care list | Any leg ulcer you dressed; any plan you updated across visits | Anonymised wound-care example | `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload support stated | positive_signal | — | "supported by a senior community nurse" | Role has defined support, not sole accountability | `[grounded]` JD | "What does senior support look like in a normal week?" | noted |
| RR2 | Post not confirmed live on the careers page | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | Post may be closed or only advertised by word of mouth | `[inferred]` from the failed careers-page fetch | "Is this post currently advertised on your careers page?" | unresolved |
| RR3 | Contract basis and mileage rate unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Post may be fixed-term; mileage rate affects take-home pay | `[inferred]` from the posting's silence | "Is this a permanent post, and what is the mileage rate?" | unresolved |
| RR4 | Position in pay band unstated | unknown | — | "£31,050–£37,800" | Start point may sit near the floor, below the market median | `[generic]` band comparison; `[grounded]` JD range | "Where in the band does a new starter with five years' experience usually start?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the post is live and permanent before investing in an application | RR2, RR3 | `[grounded]` register | proposed |
| P2 | Lead with wound, catheter and insulin evidence; name the leg-ulcer and caseload limits yourself | R5a, R6a, R7a, R5b, R9 | `[grounded]` CV; `[inferred]` adjacency | pending your approval |
| P3 | Present Doppler as a named gap with a plan to close it, never as experience | R10 | `[grounded]` CV | pending your approval |
| P4 | Ask Rhiannon Mabbott, in the informal chat, whether new community staff get Doppler training | R10; her public talk | `[grounded]` forum page; whether the employer offers training is unknown | proposed |

Nothing in this plan is final until you approve the wording.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health vacancies community staff nurse Rhiannon Mabbott"; fetched calderbrookhealth.example/careers, which returned no page. The About page (calderbrookhealth.example/about) confirms the employer exists as described. Posting status stays unverified, so RR2 remains open |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing Halifax salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line and RR4 |
| 3. Hiring manager's public footprint | yes | The name was in the posting, so the search included it. Returned the community nursing forum speaker page for Rhiannon Mabbott. Moved the scope read and the positioning in P4 |

## Dossier offer

I can save this analysis as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- The live posting or careers-page link → RR2 closes, and the decision can move to `go`.
- The recruiter's answer on contract basis and mileage rate → RR3 closes.
- Your non-negotiables (pay floor, contract type, shift pattern) → the hard-gate checks run; right now they are unknown.
- An anonymised leg-ulcer or ongoing wound example → R5b rises toward `direct`.
- The name of the records system you used → R4 closes.
- Any Doppler course or plan → R10 gains a closure path.
- Continence and end-of-life experience, if any → R6b and R8 close.

1. Your non-negotiables: what is your pay floor, do you need a permanent post, and are there shift limits? (hard-gate checks; `Gap queue`, none row)
2. R9 — Have you ever had a caseload or continuing care you were responsible for, even briefly, beyond a first-week discharge visit? Describe what you owned and for how long.
3. G1 — Which records system did you write notes in on the ward and on discharge visits, and how did you keep them timely?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.