**Yes, it's worth applying for, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3 · unclear: R4 (Pay, £31,050–£37,800 plus mileage)
- `must_have`: direct: R5 · unclear: R6 (Clear, timely written records)
- `important`: direct: R8a, R9a, R10 · adjacent: R7 (Home visits to housebound adults), R8b (Leg-ulcer care), R13 (Own small caseload) · unclear: R9b (Continence care beyond catheters), R11 (End-of-life visits), R12 (Care planning)
- `preferred`: absent: R14 (Doppler assessment for leg ulcers)

R1, R2 and R5 are met on your CV; R4 and R6 are open; R7, R8b and R13 are adjacent with limits named; R14 is not held.

**Opportunity ledger.** The scope is clear and a named route for questions is offered (RR5, positive). Hours, pay basis and caseload size are unstated (RR1, RR2, RR3), and the employer has not been checked from any outside source (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Pay, £31,050–£37,800 plus mileage); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) pay, hours and on-call sit within your limits (R4, RR1); (2) the records system and caseload support are confirmed with Rhiannon Mabbott (R6, RR3); (3) leg-ulcer, Doppler and continence work is described as not yet held (R8b, R9b, R14).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` posting |
| Mandate | District nursing for housebound adults in their own homes | `[grounded]` posting |
| Scope read | A small own caseload with senior community nurse support | `[grounded]` posting |
| Working pattern | Pool cars and mileage; hours, shifts and on-call not stated | `[grounded]` posting, silence noted |
| First-year outcomes | None stated | `[grounded]` posting |
| Market calibration | Not run. No band comparison is made here. The posting's own figure is the only pay reference | — |
| Unknowns | Hours, on-call, contract type, caseload size, records system, Doppler training | — |
| Contradictions | None in the posting text. The "Band 5" label on a CIC employer is unexplained (RR2) | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Active registration and revalidation date on CV; CV-only | `[grounded]` CV | None; the employer checks the register |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Full category B on CV; CV-only | `[grounded]` CV | Bring the licence to any check |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax; the role is in Halifax. No travel radius stated | `[grounded]` CV, posting | None |
| R4 | Pay £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | Your floor was not given, so the check cannot run | `[grounded]` posting; floor unknown | Q1 |
| R5 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse, dated on CV | `[grounded]` CV | None |
| R6 | Clear, timely written records (electronic record) | must_have | unclear | none | discovery | CV does not mention records or any record system | `[grounded]` CV silence | Q2 |
| R7 | Home visits to housebound adults | important | adjacent | medium | transferability | 18 months' home visits, but only in the first week after discharge, not ongoing housebound care | `[grounded]` CV; limit `[inferred]` | Gap G3 |
| R8a | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Named on CV | `[grounded]` CV | None |
| R8b | Leg-ulcer care | important | adjacent | low | transferability | General wound care carries over; no leg-ulcer work on CV | `[inferred]` from R8a | Q3 |
| R9a | Catheter care | important | direct | medium | none | Named on CV | `[grounded]` CV | None |
| R9b | Continence care beyond catheters | important | unclear | none | discovery | CV silent | `[grounded]` CV silence | Raise in the chat (E3) |
| R10 | Insulin administration | important | direct | medium | none | Named on CV | `[grounded]` CV | None |
| R11 | End-of-life visits | important | unclear | none | discovery | CV silent | `[grounded]` CV silence | Q3 |
| R12 | Care planning | important | unclear | low | discovery | CV describes discharge visits, not who planned or reviewed care | `[inferred]` from CV | Raise in the chat (E3) |
| R13 | Own small caseload with senior support | important | adjacent | medium | transferability | You hold patients in the first week; you have never held your own caseload, by your statement | `[grounded]` CV and your statement | Gap G8 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence | `[grounded]` CV silence | Closure path in G9 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay (R4) | hard_gate | Range stated; your floor not given | The only gate that cannot be checked yet | — | Your floor figure and hour limits | `[grounded]` posting |
| G2 | Written records (R6) | discovery | No record system on CV | Essential in the posting | Any electronic record use, or record-keeping on home visits | One redacted record you wrote | `[grounded]` CV silence |
| G3 | Housebound home visiting (R7) | transferability | Home visits in the first week after discharge only | Core of the role | Ongoing home visits, if any | Visit notes, redacted | `[inferred]` |
| G4 | Leg-ulcer care (R8b) | transferability | Pressure and surgical wounds only | Named first in the duties | Any wound assessment or compression work | A wound-care record, redacted | `[inferred]` from CV |
| G5 | Continence beyond catheters (R9b) | discovery | Catheter care only | Named duty | Bladder or bowel assessment, continence products | Assessment tool used | `[grounded]` CV silence |
| G6 | End-of-life visits (R11) | discovery | Not on CV | Named duty | Supporting dying patients or families, ward or home | — | `[grounded]` CV silence |
| G7 | Care planning (R12) | discovery | Discharge visits only | Paired with caseload | Discharge plans, referrals, care-plan reviews | Anonymised plan | `[inferred]` |
| G8 | Own caseload (R13) | transferability | Never held one | Core of the role | Patients you were personally accountable for | — | `[grounded]` your statement |
| G9 | Doppler (R14) | capability | None | Preferred only | None | — | `[generic]` closure path: training in role, to be confirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hours, shifts and on-call not stated | unknown | — | "£31,050–£37,800 a year plus mileage" | On-call or out-of-hours work may be expected | `[inferred]` from silence | What are the contracted hours, the shift pattern, and is there on-call or out-of-hours work? | unresolved |
| RR2 | Band 5 label on a CIC; pay basis unstated | unknown | — | "Community Staff Nurse, Band 5" | The band may follow a published public-sector pay scale, or be a local figure | `[generic]` that "Band 5" usually names a public-sector pay band | Which pay scale and pay point does this band use, and where would my five years place me? | unresolved |
| RR3 | Caseload size not stated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" may mean more patients than expected, or thin senior support | `[inferred]` from silence on numbers | How many patients would I hold, and how is senior support given day to day? | unresolved |
| RR4 | Employer and posting not checked from outside | unknown | — | "Calderbrook Community Health CIC, Halifax" (no link or contract entity in the posting) | The post may be live and genuine, but nothing here confirms it | `[grounded]` posting text | Which listing carries this post, and which entity would employ me? | unresolved |
| RR5 | Named contact and stated support | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The team offers an informal route to talk before applying | `[grounded]` posting | What would a typical first month look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with: "Seconded 18 months to discharge-to-assess, visiting patients at home in the first week after discharge" | Presents R7 and R13 as the bridge | `[grounded]` CV | pending your approval |
| E2 | In the cover note, state plainly that you have not held a caseload or done Doppler, and don't claim leg-ulcer work | Keeps R8b, R13 and R14 at their true bands | `[grounded]` R8b, R13, R14 | pending your approval |
| E3 | Ask Rhiannon Mabbott about caseload size, records system, hours and on-call, pay scale, and Doppler training | Closes RR1, RR2, RR3 and R6 before you apply | `[grounded]` posting invites the chat | pending your approval |
| E4 | Settle your pay floor and hour limits before the chat | Lets R4 be checked | `[grounded]` R4 | pending your approval |
| E5 | Find the live listing, or the employer's own page, before you apply | Closes RR4 | `[inferred]` from the unchecked employer | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are self-report until a specific answer is confirmed.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run: you asked for no outside lookups. Would have shown whether the post is live and who employs (RR4) |
| 2. Role-family sweep | unavailable | Not run, same reason. Would have set the Band 5 pay and terms against role-family norms (RR2) |
| 3. Hiring manager's public footprint | unavailable | Not run, same reason. A name was given (Rhiannon Mabbott). Would have shaped how your home-visit work is positioned |

I can also write this up as a `tuesday-dossier.md` file if you want it kept.

## Upgrade menu

- Your pay floor and hour limits → R4 and RR1 close, and the hard-gates line can be checked.
- The record system you have used, plus one redacted record → R6 moves off unclear.
- A leg-ulcer or end-of-life example in your own words → R8b and R11 move.
- The live listing or the employer's own careers page → RR4 closes.
- A role-family sweep of Band 5 pay terms (up to 5 searches and 2 page fetches) → RR2 gets a `[generic]` calibration. Say the word and it runs; I won't offer it again.

## Questions

R4 (RR1): What is the lowest pay you would accept for this role, and are there limits on hours, shifts or on-call that it would have to meet?

R6: Which electronic patient record systems have you used, and how did you keep notes current on home visits?

R8b, R11: Have you assessed or dressed a leg ulcer, or supported a patient through end-of-life care at home or on a ward? Tell me what you personally did.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.