**Yes, apply, with conditions: `conditional_go`.** Your NMC registration and driving licence both fit (R1, R2). The one essential requirement the CV doesn't clearly cover is written records in an electronic patient record (R4, unclear). The posting also isn't on the employer's careers page yet, which needs checking before you invest in it.

- **Fit ledger:**
  - `hard_gate`: `direct` R1, R2
  - `must_have`: `direct` R3; `unclear` R4 (clear, timely written records)
  - `important`: `direct` R6a, R7, R9; `adjacent` R5 (own caseload), R6b (leg-ulcer care); `unclear` R8 (continence care), R10 (end-of-life visits), R11 (care planning)
  - `preferred`: `absent` R12 (Doppler assessment for leg ulcers)
  - Biggest gaps: R5 (caseload ownership) and R12 (Doppler). R4 needs evidence of your recording practice.
- **Opportunity ledger:** The employer is real: it's a community interest company holding an NHS contract, with 410 staff across four locality hubs (PS1). The posting itself isn't on the careers page I could reach (RR1, `severity: medium`). Pay sits at the market median (PS2).
- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given (you didn't state a pay floor or on-call limit), so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** Confirmation that the post is live (RR1) moves this to `go`. Evidence of caseload-style follow-up (R5) or written-records work (R4) strengthens it. A confirmed on-call or out-of-hours requirement you can't accept, or a pay floor above £37,800, would make it `no_go`.

## Role reality

- **Role:** Community Staff Nurse, Band 5. District nursing for housebound adults in their homes. Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded electronically. You'd hold a small personal caseload with a senior community nurse for support.
- **Organization:** Calderbrook Community Health CIC, Calderdale/Halifax. Adult community nursing under an NHS contract, founded 2015, 410 staff, four hubs (`[grounded]`, from the About page's search snippet; I did not open the full page).
- **Requirements:** Essential: NMC Adult registration (gate), full UK driving licence (gate), at least one year post-registration, clear timely records. Desirable: Doppler assessment.
- **Hard gates:** NMC registration and licence, both met on your CV (`[grounded]`).
- **Scope read:** A personal caseload is a real step up from your current role. Expect independent decisions about care plans, which is the core transition to plan for.
- **First-year outcomes:** Independent caseload management and reliable records (`[inferred]` from the JD's description).
- **Unknowns:** Caseload size, on-call or out-of-hours expectations, induction length for a caseload-first nurse.
- **Pay:** Posting: £31,050–£37,800 plus mileage (`[grounded]`). Market band for Band 5 community staff nurses: median £34,300, interquartile £32,400–£36,600, n=1,240, 2026 survey (`[generic]`). The posting's midpoint of £34,425 sits at that median. About 61% of respondents were paid mileage, and 24% had a pool or lease car (`[generic]`).
- **Market calibration:** A Band 5 community role with its own caseload, at this pay, is within the normal range (`[generic]`).

## Evidence map

| # | Requirement | Priority | Fit | Gap | Confidence | Evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | n/a | medium | Registered Nurse (Adult), registration active, revalidation March 2028 | `[grounded]` CV, self-reported |
| R2 | Full UK driving licence | hard_gate | direct | n/a | medium | Full licence, category B | `[grounded]` CV, self-reported |
| R3 | ≥1 year post-registration experience | must_have | direct | n/a | high | Five years as staff nurse, acute medical ward | `[grounded]` CV |
| R4 | Clear, timely written records (EPR) | must_have | unclear | discovery | low | CV is silent on records or EPR | `[inferred]` from CV silence |
| R5 | Own caseload with senior support | important | adjacent | transferability | medium | 18 months in discharge-to-assess home visits; no caseload held | `[grounded]` CV |
| R6a | Wound care | important | direct | n/a | medium | Pressure ulcers, surgical wounds | `[grounded]` CV |
| R6b | Leg-ulcer care | important | adjacent | transferability | low | Wound care generally; leg ulcers not named | `[inferred]` |
| R7 | Catheter care | important | direct | n/a | medium | Catheter care | `[grounded]` CV |
| R8 | Continence care | important | unclear | discovery | low | Not named | `[inferred]` |
| R9 | Insulin administration | important | direct | n/a | medium | Insulin administration | `[grounded]` CV |
| R10 | End-of-life visits | important | unclear | discovery | low | Not named | `[inferred]` |
| R11 | Care planning | important | unclear | discovery | low | Discharge work may include planning; not stated | `[inferred]` |
| R12 | Doppler assessment (leg ulcers) | preferred | absent | capability | high | You've never done it | `[grounded]` CV statement |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it |
|---|---|---|---|---|
| G1 | Own caseload (R5) | transferability | Home visits in your first post-discharge week; no ongoing caseload | Examples of ongoing follow-up you planned and owned, even informally. Bridge limit: you haven't owned care plans for weeks. |
| G2 | Written records / EPR (R4) | discovery | No record-keeping evidence on the CV | A redacted sample entry or an account of your documentation practice |
| G3 | Continence and end-of-life (R8, R10) | discovery | Not on the CV | Any partial exposure on the ward or discharge team |
| G4 | Leg-ulcer care (R6b) | transferability | Wound care is established; leg ulcers aren't named | Whether leg-ulcer dressings or compression were part of your wound work |
| G5 | Doppler (R12) | capability | You've never done one | Closure path: a supervised Doppler course or trust training, after appointment. Carried as a risk, not closed. |

## Opportunity risk register

| ID | Class | Severity | Signal | Source quote | Verification question (asked of the employer) | Provenance |
|---|---|---|---|---|---|---|
| RR1 | risk_signal | medium | Posting not found on the employer's careers page | Fetch of calderbrookhealth.example/careers returned no page | "Is this vacancy live on your careers page, and what's the closing date?" | `[grounded]` fetch; hypothesis `[generic]`: postings can be stale or aggregated |
| RR2 | unknown | n/a | Caseload size and on-call expectations not stated | Posting: "a small caseload"; no on-call detail | "What's the expected caseload size, and is there an on-call or out-of-hours rota for this post?" | `[inferred]` |
| RR3 | unknown | n/a | Induction and supervision for a caseload-first nurse not described | Posting: "supported by a senior community nurse" | "What supervision and induction does someone new to holding a caseload get in the first three months?" | `[inferred]` |
| PS1 | positive_signal | n/a | Established NHS-contracted employer with a multi-hub structure | About page snippet | "Which locality hub would I be based at?" | `[grounded]` |
| PS2 | positive_signal | n/a | Pay at the market median; mileage and pool car provided | Posting; Wardround 2026 | "What's the mileage rate, and is a pool car available from day one?" | `[grounded]` posting; `[generic]` band |

## Application plan

- **Apply** once RR1 is cleared. Ask the employer, or Rhiannon Mabbott, whether the vacancy is live.
- **Lead with** discharge-to-assess home visits, wound care (pressure and surgical), catheter and insulin work. These are your strongest direct matches.
- **Don't claim** caseload ownership, Doppler, or leg-ulcer work. Describe them as what they are: adjacent, or not yet done.
- **Prepare** a precise account of how you'd transition to a personal caseload (G1). Interviewers are likely to probe this.
- **Proposed CV line** (`resume_edits_pending_approval`): "Seconded 18 months to a discharge-to-assess team, visiting patients at home in their first week after discharge; wound (pressure and surgical), catheter and insulin care." Nothing here goes into a CV or application until you approve it.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page found via "Calderbrook Community Health CIC Halifax" and the Band 5 query. Careers fetch failed, so the posting was not confirmed live. |
| 2 | Role-family sweep | yes | "NHS Band 5 staff nurse salary 2026 community district nursing": Wardround 2026 pay guide |
| 3 | Hiring manager's public footprint | skipped | Rhiannon Mabbott is named as contact; not searched in this pass. Available on request. |

## Upgrade menu

- **Live posting link or a careers-page screenshot** clears RR1 and moves this to `go`.
- **A quick check of your NMC register entry** firms R1's confidence to high.
- **Any ongoing follow-up examples** (R5, G1) decide how strong the caseload case is.
- **Your pay floor and on-call limit** let the hard-gate checks run against you, not only the JD.
- **Deeper diligence (L2):** up to 5 more searches and 2 more fetches on funding, leadership, recent news, and public candidate reports. Say so if you want it; it's offered once.

I can also write this assessment to `tuesday-dossier.md` for interview preparation later, if you want it.

Three questions:

- **R5 / G1:** Have you ever owned follow-up for a set of patients, even informally, such as on the discharge team? What did that involve?
- **R8, R10 / G3:** Have you had any continence assessment or end-of-life visit experience, even partial?
- **Constraints:** Do you have a pay floor or an on-call limit I should check against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.