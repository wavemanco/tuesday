**Please don't pay anything or send any documents yet. This email looks like a scam.** I haven't run the mock-interview skill yet, because a prep pack built around this employer would be prepping you for a likely fraud.

**Red flags in the email:**
- **Upfront fee.** Legitimate employers don't charge candidates for equipment, "registration," or interview slots.
- **Early request for a passport photo and bank details.** That's the information needed for identity theft.
- **The cheque scheme.** You'd deposit a €1,850 cheque and send the "balance" to a vendor. The cheque would bounce weeks later, after the real money had gone out. This is the classic fake-cheque scam.
- **The domain.** `hr@brennock.example` uses `.example`, a reserved domain that can't belong to a real company. Check the sender's actual address too.
- **Vague details.** There's no named hiring manager and no verifiable company information.

**What to do now:**
- Don't pay the fee, send ID or bank details, or deposit any cheque.
- Verify the company independently. Search the Companies Registration Office (cro.ie) for Brennock Facilities Ltd, and find its website and phone number yourself rather than using contacts from this email.
- If you've already sent anything, call your bank now, tell them it's fraud, and ask them to block or recall the payment. Report it to the Gardaí and to the job board where you saw the ad. If you sent ID, watch your accounts and consider a credit-file alert.

**Prep for the real role**, if you find a genuine employer for this kind of job:

Your strongest material is the appointment book and the invoice chasing. Your gaps are travel booking and Excel.

- **Calendars and scheduling:** You ran a four-physio diary. Talk about handling clashes, reschedules, and no-shows, and how you kept things moving when several people wanted something at once.
- **Invoices:** Chasing unpaid invoices shows you can be firm and polite under pressure. Also say you understand the basic payment cycle (receive, match, approve, pay, reconcile) and that you'd verify any change to supplier bank details by phone before paying. That answer also shows you'd spot a scam.
- **Travel booking:** You have no direct experience, so be honest. Say how you'd learn the company's booking policy and tools, and that you'd check itineraries carefully.
- **Excel:** "Okay" won't help you. Before the interview, practise SUMIF, XLOOKUP or VLOOKUP, pivot tables, and basic formatting. Be ready to say which you've used and what you'd still need to learn.
- **Remote work:** Explain how you stay organised without someone beside you, and which communication tools you've used.

**Likely questions and a structure for answering:**
- *Tell me about yourself.* Give a 60-second version: receptionist, appointment and invoice work, and why you want admin work.
- *Tell me about a time you juggled competing priorities.* Use STAR (situation, task, action, result) with a real clinic example.
- *Tell me about a difficult conversation about money.* Use the invoice chasing.
- *How would you rate your Excel?* Be specific and honest about what you can do.
- *How do you handle confidential information?* Use patient privacy as your example.

**Good questions to ask them:**
- Who provides equipment for remote staff, and does anyone ever ask candidates to pay for it?
- What does the first month look like?
- Who would I report to, and how is the role measured?

If you confirm the company through the CRO and its own website, or get a genuine invitation through a verified channel, I can run the full mock-interview pack with a live drill.