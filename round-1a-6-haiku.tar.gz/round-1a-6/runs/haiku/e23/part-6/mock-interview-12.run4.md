**Stop before you pay or send anything.** This email has the hallmarks of a fake job scam:

- It asks you to pay a €95 "equipment registration fee" to a supplier account. Legitimate employers don't charge candidates for equipment or interview slots.
- It asks for a passport photo and bank details before any interview. Those are enough to commit identity fraud, and no interview needs them.
- It sends a €1,850 cheque, tells you to deposit it, and asks you to send the "balance" to a vendor. This is the classic overpayment scam. The cheque will bounce after you've sent real money, and you'll owe the bank that money back.

**What to do now:**
1. Don't pay, don't send documents, and don't deposit any cheque.
2. Check whether the company is real. Search the Companies Registration Office (cro.ie) for "Brennock Facilities". The domain in the email, `brennock.example`, is a reserved placeholder domain, not a real company domain, which is another red flag.
3. Reply only through the job board or site where you applied, or find the company's phone number independently and call them. Don't use contact details from this email.
4. If you've already sent money or bank details, contact your bank now and report it to the Gardaí (Garda National Economic Crime Bureau).

If the company checks out through an independent route, I'll tighten the prep below. Until then, treat the interview as unconfirmed.

## Interview prep (for the role itself)

**What to expect:** a 30-minute video call with the office manager, likely short practical questions about calendars, documents, invoices and how you work day to day.

**Fit against the ad**

| Requirement | Your evidence | Gap |
|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong match |
| Booking travel | Not in your material | Gap. Be honest. |
| Word and Excel | "good with Word, okay with Excel" | Excel depth |
| Supplier invoices | "chased unpaid invoices" | You followed up on payments but didn't process invoices |
| Remote working | Not in your material | Gap |

**Don't claim:** travel booking experience, invoice processing or accounts-payable software, advanced Excel, or remote work you haven't done.

**Likely questions and how to approach them**
- **"Tell me about your background."** About 60 seconds: the physio clinic, the appointment book for four physios, invoice chasing, Word.
- **"How do you manage calendars when people are double-booked?"** Use a real example of handling conflicts and rescheduling.
- **"Have you booked travel?"** Answer honestly, then give your closest real example (arranging clinic appointments, rooms or equipment) and say how you'd learn the booking tools.
- **"How do you use Word and Excel?"** Give a specific Word example. For Excel, say exactly what you do and what you'd need to learn.
- **"What's your experience with supplier invoices?"** "I chased unpaid invoices, so I know the follow-up side. I haven't processed supplier invoices in a finance system."
- **"Have you worked remotely?"** Name real tools you've used, or say you haven't and describe how you stay organised.
- **"Why this role?"** Link to what you enjoy: organising, keeping things moving, following through.

**Your questions for them:** "What does a typical week look like?", "Which booking and finance tools does the team use?", "How is the role supported in the first month?"

**Biggest risk:** "You haven't done travel or invoice processing." Practise the honest bridge until it takes under 20 seconds.

**Delivery:** test your camera and background beforehand, keep answers to about 90 seconds, and have one example each for calendars, documents and chasing payments.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me. Rehearse only what you actually did, in your own words.

The full pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-6-rooms-case-12-denied-bca74212/cb88897c-059c-480a-b60e-ffe2cd1a1387/scratchpad/brennock-interview-prep.md`. I didn't run web research on the company, so the values and loop details are missing.

**Upgrade menu:** the original job advert or job-board listing (so I can check the duties against it), any remote or travel experience, even informal (sharpens Q3 and Q6), and a confirmed interview time from a verified company contact.

**Offers (neither pushed):** I can run a live mock interview where I play the office manager, and I can build a dossier file that tracks your evidence and gaps.

**Questions:**
1. How did you find this listing: a job board, a recruiter, or did it come to you directly?
2. Do you have any travel-booking or remote-working experience, even informal?
3. Has anything been paid or sent to this company yet?

----- file the response produced: brennock-interview-prep.md -----
# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**Before anything else: the email asks you to pay and hand over documents. Do not do any of it yet. See the warning in the message.**

## 1. Fit snapshot

| Job requirement (from ad) | Your evidence (your words) | Confidence | Gap type | Bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong | None | Direct match: multi-calendar scheduling |
| Booking travel | Not in your material | Gap | Experience gap | "I haven't booked travel professionally, but I manage complex schedules and would learn the booking tool quickly" |
| Preparing documents in Word and Excel | "good with Word, okay with Excel" | Moderate | Skill-depth gap (Excel) | "Word is strong; with Excel I'm comfortable with core tasks and would build up the rest" |
| Processing supplier invoices | "chased unpaid invoices" | Partial | Process gap | "I've followed up on unpaid invoices, so I know the payment side; I haven't processed invoices end to end" |
| Remote working | Not in your material | Gap | Experience gap | Name any remote tools or self-management you have used |

## 2. Prohibited claims (do not say these)

- That you have booked travel for anyone.
- That you have processed or entered supplier invoices or used accounts-payable software.
- That you are advanced in Excel.
- That you have worked remotely, unless you have.

## 3. Question bank (the 30-minute call with the office manager)

Persona: practical operations manager. Expect short, concrete questions and a focus on how you work day to day.

**Q1. Tell me about your background.** *(Behavioural)*
- Guidance: 60 seconds. Physio clinic, appointment book for four physios, invoice chasing, Word strength.
- Provenance: your sentences: "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios".

**Q2. How would you manage calendars for several people who are often double-booked?** *(Behavioural)*
- Guidance: describe how you handled conflicts, priorities and rescheduling at the clinic.
- Provenance: your sentence: "ran the appointment book for four physios".

**Q3. Have you booked travel before? Walk me through it.** *(Skill gap)*
- Guidance: answer honestly. Say what you have not done, then give the closest real example (booking clinic-related appointments, arranging rooms or equipment), and say how you would learn the booking tools.
- Provenance: answer slot. Your material does not show travel booking.

**Q4. How do you use Word and Excel for documents?** *(Skill)*
- Guidance: give examples of Word documents you produced. For Excel, state exactly what you do (e.g. lists, simple formulas) and what you would need to learn.
- Provenance: your sentences: "good with Word, okay with Excel".

**Q5. What is your experience with supplier invoices?** *(Skill gap)*
- Guidance: "I chased unpaid invoices, so I know the follow-up side. I have not processed supplier invoices in a finance system." Do not stretch this further.
- Provenance: your sentence: "chased unpaid invoices".

**Q6. Have you worked remotely or with video tools?** *(Experience gap)*
- Guidance: name real tools you have used (video calls, shared calendars, cloud documents). If none, say so and describe how you stay organised.
- Provenance: answer slot.

**Q7. Why this role, and why remote admin?** *(Motivation)*
- Guidance: link to what you enjoy: organising, keeping things moving, reliable follow-through.
- Provenance: general guidance, not from your material.

**Q8. Do you have questions for us?** *(Reverse)*
- Ask: "What does a typical week look like?", "Which booking and finance tools does the team use?", "How is the role supported in the first month?"
- Provenance: generic.

**Most likely objection:** "You haven't done travel or invoice processing." Rehearse the honest bridge from Section 1 until it sounds natural in under 20 seconds.

## 4. Values cheat sheet

Not generated. Brennock's values could not be verified (see the upgrade menu).

## 5. Reverse questions

Listed in Q8. Also useful: "How would you measure success in this role after three months?"

## 6. Delivery

- Test your video setup and background before the call.
- Keep your answers to about 90 seconds.
- Have one example each for calendars, documents and chasing payments ready.

## 7. Upgrade menu

- Original job advert or the job-board listing you applied through (lets me check the duties and company against it).
- Any remote-working or travel experience, even informal (unlocks stronger answers for Q3 and Q6).
- Confirmed interview date, time and platform, sent from a verified company contact.
