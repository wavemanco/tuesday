**Stop before you prepare: this email has the hallmarks of a recruitment scam.** Please don't send any money, passport photo, or bank details yet.

- **Paying to be interviewed.** A real employer doesn't charge candidates an "equipment registration fee," and it doesn't make the interview depend on a payment to a "supplier" account.
- **Documents before the interview.** A passport photo and bank details are what identity thieves want. An interview doesn't need them.
- **The cheque.** You deposit a €1,850 cheque and send the "balance" to a vendor. The cheque later bounces, and the money you sent out is gone. This is the classic overpayment scam.
- **The address.** `hr@brennock.example` uses a `.example` domain. That suffix is reserved for documentation and isn't used by real companies. Treat it as fake.
- **Pressure.** "Before your slot can be confirmed" and "to speed up onboarding" are used to stop you checking.

**What to do now:**
1. Don't pay, don't reply with documents, and don't deposit any cheque.
2. If you've already sent anything, call your bank now and ask them to stop or recall the payment.
3. Check the company yourself. Find its website and phone number through a search engine, not from this email, and ask them directly whether they've invited you to interview. If the company is registered in Ireland, check the Companies Registration Office register.
4. Report it to the Garda National Cyber Crime Bureau or your local Garda station, and report the ad to the job site where you found it.
5. Keep the email as evidence.

If the company turns out to be real and confirms the interview through a verified channel, the prep below applies. I'm not extending the material to any payment or document request.

---

## Prep pack (built from your material only, no research)

**Fit snapshot**

| Requirement | Your evidence (quoted) | Confidence | Gap type | Bridge |
|---|---|---|---|---|
| Manage calendars | "I ran the appointment book for four physios" | Strong | None | Frame it as scheduling for several people at once |
| Book travel | Not in your material | Gap | Experience | Be honest; describe how you'd approach it |
| Word documents | "good with Word" | Strong | None | Give one concrete example |
| Excel | "okay with Excel" | Partial | Depth | Name what you've actually done in Excel and say you're keen to build it |
| Process supplier invoices | "chased unpaid invoices" | Partial | Direction | This was money owed *to* the clinic. Say so precisely |
| Remote working | Not in your material | Gap | Experience | Describe how you stay organised without someone beside you |

**Prohibited claims (don't say these):**
- That you have Excel skills beyond "okay."
- That you've booked travel or processed supplier invoices. Chasing unpaid invoices is different work.
- Anything about remote-working experience you don't have.

**Likely questions**

*Background (warm-up)*
- **Q: Walk me through your background.**
  - Guidance: Two minutes. Start with the appointment book for four physios, then the invoice chasing, then why you want admin work.

*Behavioural*
- **Q: Tell me about a time you kept a busy schedule under pressure.**
  - Guidance: Use the appointment book. Give a specific example of double-bookings, cancellations, or competing priorities, and what you did.

*Skeptic (the likely objection)*
- **Q: You chased unpaid invoices. Have you processed supplier invoices?**
  - Guidance: Answer straight: "I haven't processed supplier invoices. I chased payments owed to the clinic, so I know the invoice lifecycle and the follow-up. I'd learn the payables process quickly."
- **Q: How would you rate your Excel?**
  - Guidance: "Okay. I use it for [specific task you've really done]. I'd want to get stronger on [specific thing]."

*Situational / gap*
- **Q: Have you booked travel for someone else?**
  - Guidance: "Not formally. Here's how I'd approach it: confirm the traveller's constraints, compare options against the policy, and keep a clear itinerary."
- **Q: How do you work when you're remote?**
  - Guidance: Describe your system (calendar blocking, task list, how you check in). Don't claim experience you don't have.

**Most likely objection and its rehearsal:** the invoice question. Practise saying "I chased money owed to the clinic" without flinching. That's the highest-value prep.

**Reverse questions**
- What does a typical week look like for the person in this role?
- Which tools does the team use for calendars, travel, and invoices?
- What would success look like at 90 days?

**Interview format:** 30-minute video call with the office manager. Prepare two or three examples, your three reverse questions, and a clear explanation of each gap.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me. Rehearse only what you actually did, in your own words.

---

**Upgrade menu** (each would sharpen this pack):
- The full job ad text, so I can match its exact wording.
- Any verified information about the company: its website, its real HR contact, and its office location.
- How much prep time you have.

**Offers:**
- A live mock interview where I play the office manager and follow up on your answers.
- I can also save this as a Word document or update it if you find out more.

**Questions:**
1. Have you replied to this email, sent any documents, or paid anything yet?
2. Do you have a contact at Brennock, or did you find this ad on a job site?