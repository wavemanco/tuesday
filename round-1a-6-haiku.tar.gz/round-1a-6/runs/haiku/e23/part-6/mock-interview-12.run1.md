**Stop before you pay or send anything. This email has the hallmarks of a job scam.**

- **The €95 "equipment registration fee"** is a red flag. Legitimate employers don't charge candidates to register, interview or get hired.
- **Passport photo and bank details before the interview** are a fraud pattern. Identity documents and bank details are collected after a formal offer, through a verified HR process, never by email before you've spoken to anyone.
- **The €1,850 cheque to deposit, with the balance forwarded to a vendor**, is the classic fake-cheque scam. The cheque looks genuine at first, so your bank may show the funds as available, but it bounces days later. By then the money you sent is gone and you're liable for it.
- **The IBAN doesn't look valid.** The check digits are "00", which fails the standard IBAN check, so it isn't a real account number.

**What to do now**

1. **Don't pay the fee, send the passport or bank details, or deposit the cheque.**
2. **Check the company independently.** Search the Companies Registration Office (cro.ie) for Brennock Facilities Ltd. Find the company's phone number on its official website, not from this email, and ask whether it's hiring for this role.
3. **Check the job ad's source.** If you found the role on a job board, look for the same listing on the company's own careers page.
4. **If you've already sent money or details:** contact your bank immediately, report it to your local Garda station or the Garda National Cyber Crime Bureau, and monitor your accounts and credit file for misuse of your identity.

**If the company checks out and you still want to interview**, here's what to expect and how to prepare. I haven't researched this company, so treat the format below as generic.

**The format.** A 30-minute video call with the office manager. Expect a short introduction, questions on your background, a few scenario questions, and time for your questions. Mostly they're testing whether you can run the role's daily work.

**Likely questions, and how your experience answers them**

- *"Tell me about yourself."* Two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios. Keep it to 60–90 seconds.
- *"How would you manage a busy calendar for several people?"* You ran one appointment book across four practitioners. Describe how you handled double-bookings, cancellations and priorities. Only claim what you actually did.
- *"How do you handle unpaid invoices?"* You chased them. Describe the process you used: reminders, escalation, keeping records. This maps directly to processing supplier invoices.
- *"What's your Excel experience?"* Be honest. "Okay" is fine if you say what you can do and what you're building. Before the call, practise the functions the role likely needs: SUM, VLOOKUP/XLOOKUP, simple pivot tables, and basic formatting.
- *"How do you organise travel bookings?"* If you haven't done this, say so and explain how you'd approach it: comparing options, checking policy, confirming details with the traveller.

**Preparation**

- Rehearse two or three real examples out loud, each with a situation, what you did, and the result.
- Test your video setup: camera, microphone, lighting, and a quiet room.
- Prepare two or three questions for them, such as what a typical week looks like or what the first 90 days would involve.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.