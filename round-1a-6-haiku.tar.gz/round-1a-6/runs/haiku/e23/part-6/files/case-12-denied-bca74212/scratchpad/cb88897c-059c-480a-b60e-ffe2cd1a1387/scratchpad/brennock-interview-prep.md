# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**Before anything else: the email asks you to pay and hand over documents. Do not do any of it yet. See the warning in the message.**

## 1. Fit snapshot

| Job requirement (from ad) | Your evidence (your words) | Confidence | Gap type | Bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong | None | Direct match: multi-calendar scheduling |
| Booking travel | Not in your material | Gap | Experience gap | "I haven't booked travel professionally, but I manage complex schedules and would learn the booking tool quickly" |
| Preparing documents in Word and Excel | "good with Word, okay with Excel" | Moderate | Skill-depth gap (Excel) | "Word is strong; with Excel I'm comfortable with core tasks and would build up the rest" |
| Processing supplier invoices | "chased unpaid invoices" | Partial | Process gap | "I've followed up on unpaid invoices, so I know the payment side; I haven't processed invoices end to end" |
| Remote working | Not in your material | Gap | Experience gap | Name any remote tools or self-management you have used |

## 2. Prohibited claims (do not say these)

- That you have booked travel for anyone.
- That you have processed or entered supplier invoices or used accounts-payable software.
- That you are advanced in Excel.
- That you have worked remotely, unless you have.

## 3. Question bank (the 30-minute call with the office manager)

Persona: practical operations manager. Expect short, concrete questions and a focus on how you work day to day.

**Q1. Tell me about your background.** *(Behavioural)*
- Guidance: 60 seconds. Physio clinic, appointment book for four physios, invoice chasing, Word strength.
- Provenance: your sentences: "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios".

**Q2. How would you manage calendars for several people who are often double-booked?** *(Behavioural)*
- Guidance: describe how you handled conflicts, priorities and rescheduling at the clinic.
- Provenance: your sentence: "ran the appointment book for four physios".

**Q3. Have you booked travel before? Walk me through it.** *(Skill gap)*
- Guidance: answer honestly. Say what you have not done, then give the closest real example (booking clinic-related appointments, arranging rooms or equipment), and say how you would learn the booking tools.
- Provenance: answer slot. Your material does not show travel booking.

**Q4. How do you use Word and Excel for documents?** *(Skill)*
- Guidance: give examples of Word documents you produced. For Excel, state exactly what you do (e.g. lists, simple formulas) and what you would need to learn.
- Provenance: your sentences: "good with Word, okay with Excel".

**Q5. What is your experience with supplier invoices?** *(Skill gap)*
- Guidance: "I chased unpaid invoices, so I know the follow-up side. I have not processed supplier invoices in a finance system." Do not stretch this further.
- Provenance: your sentence: "chased unpaid invoices".

**Q6. Have you worked remotely or with video tools?** *(Experience gap)*
- Guidance: name real tools you have used (video calls, shared calendars, cloud documents). If none, say so and describe how you stay organised.
- Provenance: answer slot.

**Q7. Why this role, and why remote admin?** *(Motivation)*
- Guidance: link to what you enjoy: organising, keeping things moving, reliable follow-through.
- Provenance: general guidance, not from your material.

**Q8. Do you have questions for us?** *(Reverse)*
- Ask: "What does a typical week look like?", "Which booking and finance tools does the team use?", "How is the role supported in the first month?"
- Provenance: generic.

**Most likely objection:** "You haven't done travel or invoice processing." Rehearse the honest bridge from Section 1 until it sounds natural in under 20 seconds.

## 4. Values cheat sheet

Not generated. Brennock's values could not be verified (see the upgrade menu).

## 5. Reverse questions

Listed in Q8. Also useful: "How would you measure success in this role after three months?"

## 6. Delivery

- Test your video setup and background before the call.
- Keep your answers to about 90 seconds.
- Have one example each for calendars, documents and chasing payments ready.

## 7. Upgrade menu

- Original job advert or the job-board listing you applied through (lets me check the duties and company against it).
- Any remote-working or travel experience, even informal (unlocks stronger answers for Q3 and Q6).
- Confirmed interview date, time and platform, sent from a verified company contact.
