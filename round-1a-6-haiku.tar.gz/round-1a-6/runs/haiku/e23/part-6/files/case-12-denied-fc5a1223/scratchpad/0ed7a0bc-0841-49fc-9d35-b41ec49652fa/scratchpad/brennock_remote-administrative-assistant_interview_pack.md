# Read this first: this email has the hallmarks of a job scam

Before any interview prep, please don't act on the email's requests:

- **Don't pay the €95 "equipment registration fee"**, to any account. Legitimate employers don't charge candidates to register or to be interviewed.
- **Don't send your passport photo or bank details** before an interview or offer.
- **Don't deposit the €1,850 cheque, and don't send any of its money on to a "vendor".** This is the classic fake-cheque pattern: the cheque bounces later, and you are left owing the bank the amount you forwarded.
- **Verify the company independently.** Find the firm through its official register (in Ireland, the Companies Registration Office) and call a number you found there, not one in the email. The sender's address ends in `.example`, a reserved placeholder domain that is not a real company domain.
- **If you have already paid anything or sent details,** contact your bank now, and report the email to the Gardaí.

A real interviewer will still be happy to run the 30-minute call once you've verified them. The prep below is still useful for any real interview.

# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Changelog:** first version. Built from your summary of the ad and your background message. No research was run (tier L0).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| JD | Can you do the listed job, including its gaps |
| EXP | Does your background hold up under a closer look |
| CASE | How you structure a live admin problem |
| VAL | Values fit (not included: no values round detected) |
| CO | Company knowledge (not included: no research run) |

## Prep triage

Prep time wasn't given, so no schedule is built. If you have about two hours: A2 (the invoice gap), A3, B1 and E1 first, then the remaining questions.

## Fit snapshot

Requirements come from your summary of the ad (not verbatim), so they are unquoted and labelled `[grounded]`. Evidence quotes are from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Manage calendars (your summary of the ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | The material says an appointment book for four physios, not executive calendars. Words: "I ran the appointment book for four physios." Answer slot: if you moved or resolved clashes across those diaries, say how; if not, say so and describe how you kept the book right. |
| F2 | Book travel (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel bookings. Answer slot: if you have booked travel, say how; if not, say so and say how you would learn the company's booking process. |
| F3 | Prepare documents in Word (your summary of the ad) | "good with Word" — your message | medium | [grounded] | none | The quote already reaches the requirement. Words: "I'm good with Word." Expect a probe for an example; answer slot below. |
| F4 | Prepare documents in Excel (your summary of the ad) | "okay with Excel" — your message | low | [grounded] | discovery | "Okay" does not show the level the role needs. Answer slot: name the most complex Excel task you have done; if it was basic, say so plainly. |
| F5 | Process supplier invoices (your summary of the ad) | "chased unpaid invoices" — your message | low | [grounded] | transferability | Chasing payment is adjacent to processing supplier invoices, and does not reach it. Words stay at that scope: "I chased unpaid invoices." Answer slot: say whether those were invoices you raised, received, or chased, and whether any supplier invoice went through you; if none did, say so and describe the nearest step you took. |

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate may reach for under pressure, and this pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive or senior calendars | Inflated form of F1 | F1's quote at its own scope: the appointment book for four physios. The limit is this pack's observation: your material shows an appointment book, not executive diaries. |
| Processed supplier invoices or accounts payable | Inflated form of F5 | F5's quote at its own scope: chased unpaid invoices. A5's slot is about which side of the invoice you handled. |
| Advanced Excel | Inflated form of F4 | F4's quote at its own scope: okay with Excel. |

## Persona table

No interviewer profile was given, so there is no interviewer read. A 30-minute video call with an office manager, for a remote admin role, fits the hiring-manager prior: Case and Skeptic dominate.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Probes the gap between a receptionist background and an admin role | High: the ad names invoice processing and your message doesn't show it | Rehearse A2 until it's plain; use your own words; name what you'd learn first |
| Case / Strategist (B) | Live admin problems: clashing diaries, odd invoices | High: a hiring-manager prior, and the role is operational | Clarify first, then state your steps aloud |
| Data-Driven Prober (C) | Asks how you checked your work or how you counted | Medium: your message includes no figures, so probes will ask for them | Say how you did it, or say you did not count |
| Conversational (D) | Opens with "tell me about yourself" | Medium: common openers | A 90-second arc |
| Pressure (E) | Challenges fit: "why you over someone with invoice experience?" | Medium: the invoice gap invites it | Hold the quote, concede the gap specifically |
| Peer (F) | Collaboration and handoffs | Low: the interviewer is an office manager, not a peer | Brief rehearsal only |

## Question banks

Provenance comes first, with the quotes each guidance cell rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background says you're good with Word and okay with Excel. How would you rate yourself honestly?" | JD | [grounded] "good with Word"; "okay with Excel" — your message | Say it in those words. Answer slot: name the most complex Excel task you've done; if it was basic, say so, and say how you'd build up the level the role needs. | F3 and F4 are the Word and Excel evidence; the probe tests honesty about the Excel level. |
| A2 | "You chased unpaid invoices. This role processes supplier invoices. What's your experience there?" | JD | [grounded] "chased unpaid invoices" — your message | **Highest-ROI prep in this pack.** Hold to the quote: "I chased unpaid invoices." Answer slot: say which side of the invoice you handled and whether any supplier invoice went through you; if none did, say so plainly and describe the nearest step. Hold through two follow-ups by returning to what you did, never by adding to it. | F5 is the biggest gap, and the JD names it directly, so expect this in some form. |
| A3 | "Walk me through how you'd handle two clashing diaries, and where you've booked travel for someone." | JD | [grounded] "ran the appointment book for four physios" — your message | Story-mapped on F1: the appointment book, four physios, in your words. Answer slot: if you resolved clashes across those diaries, say how; if not, say so. Travel: if you've booked it, say how; if not, say so and say how you'd learn the company's process. | F1 and F2 are the calendar and travel requirements; travel has no quote, so the answer is a slot. |
| A4 | "Tell me about the appointment book you ran for four physios." | EXP | [grounded] "ran the appointment book for four physios" — your message | Tell it in your own words, using the sentence's scope. Answer slot: if you set rules for booking conflicts, say what they were; if others set them, say so. | F1 is the strongest calendar evidence, and the probe checks whose decisions those were. |
| A5 | "Which Word document did you produce that others relied on, and what did it need to do?" | JD | [grounded] "good with Word" — your message | Name one document in your own words. Answer slot: if others used it, say who and how; if you made it only for yourself, say so and name the nearest document you did make. | F3's quote is only a claim, so this asks for an instance. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two directors' meetings clash, and one director is travelling Thursday. What do you do?" | CASE | [generic] | Clarify priorities first, then check who can move, hold both options, confirm travel dates, record what you decided. | A live calendar problem from the ad's calendar and travel duties; no claim about your past. |
| B2 | "A supplier invoice arrives with no purchase order. What do you do?" | CASE | [generic] | Check the approval route, ask the budget holder, hold payment, record the query. | Tests the invoice process from the ad, without any claim about your experience. |
| B3 | "A spreadsheet total is off by a few hundred euro. How do you find the error?" | CASE | [generic] | Trace the inputs, check the totals, ask someone to review. | Tests Excel judgement, without any claim about your level. |
| B4 | "What would you do in your first week to learn our booking and invoice tools?" | CASE | [generic] | Name a plan: which tool, whom to ask, and what you'd check first. | A plan, not a past. Tests how you'd close the F2 and F5 gaps. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you track the invoices you chased, and how many were paid?" | EXP | [grounded] "chased unpaid invoices" — your message | Say how you tracked them, in your words. Answer slot: if you have a figure, say how it was counted and which part was yours; if you kept no count, say so. | F5 is the evidence behind this probe, and it asks for a figure you haven't given. |
| C2 | "When you ran the appointment book, how did you know it was right?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Name the checks you did. Answer slot: if you checked against something, name it; if you didn't, say so. | F1 at its own scope. |
| C3 | "Which of the four physios' diaries did you control, and which did they?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Answer from the sentence's scope: the book was yours, the diaries were theirs, if that's accurate. Answer slot: where decisions were shared, say so. | Tests attribution, the honesty this pack is built around. |

### D. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey from reception into admin." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | A 90-second arc: the clinic, two years, the appointment book, the invoices, why admin. | The biography question, answered from the quote. |
| D2 | "What do you enjoy most about office work?" | JD | [generic] | Keep it short and true. | Casual, but scored. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has processed supplier invoices?" | JD | [grounded] "chased unpaid invoices" — your message | Hold: "I chased unpaid invoices." Hold through two follow-ups. Concede the gap specifically: answer slot on what you'd learn first. | F5 under time pressure. Hold the quote, concede specifically. |
| E2 | "You're okay with Excel. Why would we trust you with budget spreadsheets?" | JD | [grounded] "okay with Excel" — your message | Hold to the words. Answer slot: name the spreadsheet work you have done, and say how you'd build the level needed. | F4, challenged directly. |

### F. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If the calendar and the invoice queue both needed you at once, which would you drop?" | CASE | [generic] | Name the order you'd use and why, and say who you'd tell. | Tests prioritisation between the two duties. |
| F2 | "Where would you draw the line between your work and the team's?" | JD | [generic] | Describe the handoffs you'd expect and how you'd check them. | Collaboration, asked in an admin register. |

## Requirement coverage

| Requirement (your summary of the ad) | Covered by |
|---|---|
| Manage calendars | A3, A4, B1, C2, F1 |
| Book travel | A3, B4 (travel has no quote, so it is an answer slot) |
| Prepare documents in Word and Excel | A1, A5, B3, E2 |
| Process supplier invoices | A2, B2, C1, E1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| What does a typical week look like for whoever holds this role? | Shows you're planning the job, not just the interview. |
| How are supplier invoices approved today, and who signs off? | Lets you see the process before you're asked to run it. |
| Which calendar and booking tools does the team use? | Ties your B4 plan to real tools. |
| What would success look like after 90 days? | Gives you the scoring criteria in the interviewer's words. |
| How does the team stay connected when the role is remote? | A remote-role question the interviewer can answer concretely. |

## Sources

Provided documents: your summary of the ad, and your background message. No searches or fetches were run.

**Research tier: L0** (provided documents only)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet: not included, since no values round was detected. L0 was used by default. |
| 2. Interview process for the role | unavailable | Loop structure: the persona weights rely on the round type, not on a confirmed process. |
| 3. Company strategy / recent news | unavailable | Would have moved the CO questions. L0 was used by default. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative JD for the title | skipped | Your summary of the ad fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The full ad text, pasted → the requirements become verbatim quotes, and F1, F2 and F5 can be rewritten from the ad's own words.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Any recruiter notes on the process → coverage of any declared assessment.
