# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Panel: Principal Dolores Vantongeren and two fourth-grade team members, 45 minutes, Thursday (Orrinsford Community School District).

Built on: the invite and your resume. No posting and no research yet, so the pack is 16 questions, below the usual 18, and the requirement list is the invite's one line plus role-family expectations.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **EXP** experience deep-dive, **JD** stated requirement, **CASE** live problem, **CO** company knowledge, **VAL** values. Guidance is scaffolding for a spoken answer, not a script. Rehearse the plain acknowledgments out loud; they are the words most likely to come out wrong under pressure.

## Persona weights

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | The principal asks about the fourth-grade gap and the team-lead gap | High | Principal is the hiring-manager prior, and the invite's grade is the gap you named yourself | Plain acknowledgment, then the nearest real material |
| Case / Strategist | Classroom scenarios from the principal | High | Hiring-manager prior: they are buying capability for a grade they know | Clarify, plan, then check |
| Pressure | Time-boxed challenges from the principal in a 45-minute panel | Medium | Panel length and a senior interviewer; composure is scored | Hold through two follow-ups, concede specifically |
| Peer Evaluator | Team members on collaboration, credit and where the grade's work meets yours | High | Both team members are peers, and they price what a hire adds to their load | Propose principles for the seam; credit others |
| Data-Driven Prober | A team member probing the reading club and the curriculum move | Medium | Peer prior; your resume has no figures attached to either | Say what you tracked and what you did not |
| Conversational | The opening question | High | Every panel opens casually, and casual questions are still scored | A rehearsed 90-second arc |

Depth: Skeptic 4 questions, Case 3, Pressure 2, Peer 3, Prober 2, Conversational 2.

## Fit snapshot

Requirements are quoted from the invite (HR's words) where it states them; role-family expectations are plain prose and carry no quotation marks.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met on your material. Medium because nothing has been inspected yet: bring your license record and check the expiry date yourself. No bridge needed. |
| F2 | "Fourth Grade Teacher position" — HR invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Third grade is adjacent to fourth, not the same grade. Keep the words at that scope: "I taught third grade for six years." Answer slot: if you have taught any fourth-grade content, expectation or unit, say which; if none, say so and say what you would learn first. |
| F3 | Team-lead work on a grade-level team (role-family, [generic]; not in the invite) | "I've never been a team lead" — your message; "led our grade level's move to a new reading curriculum in 2024" — your CV | none | [grounded] | capability | A gap you stated, so the words come from you: "I haven't been a team lead." Then the curriculum move at its own scope, with no added role. |
| F4 | Reading instruction and family communication (role-family, [generic]) | "I've run the after-school reading club for the last two years" — your CV; "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap. Both lines already reach the expectation in role terms. Neither carries a figure, so expect a probe on what they achieved. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1; no question needed, verify the license |
| Fourth Grade Teacher position (invite) | A1, A4, B3 |
| Members of our fourth-grade team (invite) | A2, D1, D3 |
| Team-lead work (role-family, not in the invite) | A2 |
| Reading instruction and family communication (role-family) | E1, E2, G2 |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | You stated it: "I've never taught fourth grade" | "I haven't taught fourth grade." No slot. |
| Having been a team lead | You stated it: "I've never been a team lead" | "I haven't been a team lead," then the curriculum move at its own scope. |
| Designing or choosing the reading curriculum | Inflated form of "led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. Your material says you led the move, not that you selected the curriculum; C2's slot stays inside the move. |
| Reading-club or curriculum results (scores, attendance, growth) | No figures in your material; a result would be supplied, not given | Only E1 and E2's slots: say what you tracked, if anything. |

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What makes you ready for this classroom?" | EXP | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Plain acknowledgment: "I haven't taught fourth grade." Then the six years, in your own words, with no fourth-grade content added. Answer slot: if you have taught any fourth-grade content, expectation or unit, say which; if none, say so and say what you would learn first. Hold through two follow-ups by returning to third grade, never by claiming fourth-grade familiarity. | **Highest-ROI prep in this pack.** F2 is the objection this panel will almost certainly raise, and a rehearsed plain acknowledgment turns it from a gotcha into a credible answer. |
| A2 | "You've never been a team lead. Why would a grade-level team follow your lead?" | EXP | [grounded] "I've never been a team lead" — your message; "led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment: "I haven't been a team lead." Then the nearest thing your material carries: "I led our grade level's move to a new reading curriculum in 2024," in your words. Answer slot: if you made decisions about that move, say which and how; if the school or district set it, say so and describe what you led. | F3 is the second-likeliest objection. The panel includes a fourth-grade team, so the answer must not claim lead experience. |
| A3 | "Why leave third grade now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Your material does not give a reason for the move. Give your own, in your words, true for you, and stop when you have answered. Do not build a story about fourth grade you have not told. | Motivation probe, the Skeptic's usual follow-up to a grade change. Needs no claim beyond the quoted years. |
| A4 | "On day one, what would you be weakest at in this classroom?" | EXP | [grounded] "I've never taught fourth grade" — your message | Name the fourth-grade content or routine you would need to learn first, as a plan for learning and never as something you already know. One or two sentences, then stop. | Matches F2's gap; calibrated candor is what a Skeptic scores. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student who read fluently in third grade is struggling with comprehension this fall. What would you do in your first month?" | CASE | [generic] | Structure it: what you would look at first (assessment data, your observations), who you would talk to, what you would try with small groups, and how you would know it is working. Name the first check before the first move. | A live problem from the role's reading demands, asked as a decision. It needs no claim about your past, so the guidance makes none. |
| B2 | "The grade team wants to change a reading unit mid-year. How would you decide?" | CASE | [grounded] "led our grade level's move to a new reading curriculum in 2024" — your CV | Clarify who decides, what evidence is needed, and how you would bring colleagues along. If you draw on the 2024 move, keep to its scope: you led it. | Case on team decisions; ties your strongest curriculum line to a scenario without extending it. |
| B3 | "Walk me through how you would plan a fourth-grade reading unit, from the first lesson to the assessment." | CASE | [generic] | Walk the order: the text and standards, the first lesson, checks along the way, the assessment, then what you would change. Use "I would" for plans; never describe a fourth-grade unit you have taught. | Case on the role's core work. The honest frame is a plan, and the plan is what the panel is scoring. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire someone new to fourth grade over a teacher who already teaches it?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've run the after-school reading club for the last two years" — your CV | Hold the position: six years teaching third grade and two years running the reading club, and the steady weekly contact with families. Hold through two follow-ups. When pressed, concede specifically: "I haven't taught fourth grade, so I would be learning its content." Do not fold on the core claim. | Pressure test built on F2 and F4. The hold is only what your quotes carry. |
| C2 | "You led a curriculum move. How much of it was actually you?" | EXP | [grounded] "led our grade level's move to a new reading curriculum in 2024" — your CV | Answer in your own words with your part as you did it. Answer slot: if you chose the curriculum, say how you decided; if the decision was not yours, say so plainly and describe what you led. Hold the part that was yours; concede the rest specifically. | The attribution probe for a led-project line. The inflation this could tempt is listed under Prohibited claims. |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you worked through a shared decision with colleagues on the same grade." | EXP | [grounded] "led our grade level's move to a new reading curriculum in 2024" — your CV | Open prompt: choose the instance yourself. Use the 2024 move if it fits, within its scope: what you led, who decided, what the team did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | The team members are peers: this is their collaboration probe. Theme from the Peer Evaluator stem. |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say who did what, in the terms you would use with a colleague. Credit the people who did it, and do not assign others' work to yourself or claim the team's. | Credit-sharing probe, answered from principle, with no claim about your past. |
| D3 | "Where would your planning overlap with ours, and what happens when we disagree?" | EXP | [generic] | Propose a principle for the seam (who owns which assessment, how you raise a concern). If you have a real disagreement story, use it; if not, say how you would raise one. | The seam is where peers price a hire. A principle is honest where a claimed history is not. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your reading club has run two years. What do you track to know whether it is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer slot: if you track anything, name it and how it is counted; if you do not, say so plainly and say what you would start tracking. Name the assumption you would defend least before they do. | The club is the one headline line with no figure attached; this is where a prober goes. |
| E2 | "Did the 2024 curriculum move change anything for your students, and how would you know?" | EXP | [grounded] "led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you measured anything, say what and how it was counted; if you did not, say so plainly and say what you would measure first. Do not describe results you have not seen. | The defend-the-outcome probe on the curriculum move. Results are not in your material, so the answer has to be an honest branch. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk us through how you came to teach in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | A 90-second arc: how you started, the six years, the reading work you can name. Stop at about two minutes. | Casual openers are scored. This is the arc to have ready. |
| G2 | "What's the part of the job you enjoy most?" | EXP | [grounded] "I write a weekly email to families" — your CV | Name the weekly family email in your words: what it covers and why you send it. Do not claim it changed outcomes unless you know it did. | Your concrete, checkable habit, offered in a light register. |

## Reverse questions

Each lands for a reason. At least one is a reciprocity question, since the team members are peers.

1. "What does the fourth-grade team plan together each week, and where would a new teacher fit?" — It shows you want to join the team's work, not just the job.
2. "Which reading curriculum is in use this year, and what has the team changed in it?" — It opens the reading question you can answer well, and it is the team's own story.
3. "How does the principal support a teacher new to a grade?" — It tests the Skeptic's concern from the principal's side, and it invites a direct answer.
4. "What would success look like at the end of the first semester?" — It turns the panel into a planning conversation.
5. Reciprocity: "What could a new person do in their first month that would genuinely help your team?" — The peer question. It converts the seam into a shared problem.
6. "What do families most often ask your grade about?" — It connects to your weekly family email and gives you a real answer to rehearse.

## Sources

- Provided documents: the interview invite; your resume; your message.
- Research tier: L0. No searches or fetches have been run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford values | unavailable | Values section, not run. Research has not been consented to. |
| 2. Interview process, fourth-grade panel | unavailable | Persona weights for the principal and team members. Would have confirmed the loop. |
| 3. Recent strategy and news | unavailable | Company-knowledge questions (CO). Research has not been consented to. |
| 4. Principal Dolores Vantongeren public footprint | unavailable | Interviewer read and a reverse question tied to her path. |
| 5. Representative fourth-grade posting | unavailable | Requirement list beyond the invite's one line. |

## Upgrade menu

- The full posting text → the requirements you cannot see now become grounded; mid-list items get their own questions.
- Your license record (a printout or the public lookup) → F1 moves from medium to high.
- The two team members' names → personas assigned per member.
- Principal Dolores Vantongeren's public footprint → an interviewer read and a reverse question tied to her career path.
- Any focus areas or demo lesson from HR or the recruiter → coverage for anything they pre-declare.
- Any count or tracking for the reading club → E1 becomes a defend-the-number answer.
- Deep research (L2), if you want it: up to 6 further searches and 2 page fetches on company strategy, recent news and interviewer talks. It adds a grounding brief and CO questions.
