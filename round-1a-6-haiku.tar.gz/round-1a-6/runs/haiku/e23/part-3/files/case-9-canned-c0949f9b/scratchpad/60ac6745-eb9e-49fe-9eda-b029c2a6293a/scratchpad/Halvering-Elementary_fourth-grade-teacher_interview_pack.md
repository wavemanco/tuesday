# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · 45-minute panel · Thursday
Panel: Principal Dolores Vantongeren and two fourth-grade team members (names not given).
Built from the invitation, your CV, your message, two district pages and one interviewer search. No job posting was supplied, so requirements come from the invitation, the district's own pages, or are marked [inferred]. Assumed: the Thursday after today.

How to use: personas are how a question arrives; types are what it scores. Type key: **VAL** values, **EXP** your experience, **JD** the role's requirements, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | No gap. Have your license status ready to state. Do not read out identifiers. |
| F2 | "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | presentation | Say it in the quote's terms: "I led our grade level's move to a new reading curriculum in 2024." Expect a probe on the move. Answer slot: which parts of it were yours to decide and which were decided above you, in your own words. |
| F3 | Fourth Grade Teacher position — invitation | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | capability | Words: "I've never taught fourth grade." Then the six years in third grade and what carries across. Then how you would learn the fourth-grade year, said as a plan, never as a past. |
| F4 | two members of our fourth-grade team — invitation; work with the grade-level team — [inferred] from a representative posting, unquoted | "I've never been a team lead" — your message | none | [grounded] | capability | Words: "I've never been a team lead." Then the move in F2's own scope. Do not turn it into team leadership. |
| F5 | how you work with families — district hiring page; "each teacher speaks with every family each term" — district mission page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The quote carries writing, not speaking. Words: "I write a weekly email to families." Answer slot: how you speak with families, in your own words; if there are parts you do not yet do, say so and say how you would start. |
| F6 | "Every Child a Reader: no student leaves third grade without a reading plan." — district mission page | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The club is after-school reading work, at its own scope: "I've run the after-school reading club for the last two years." Answer slot: if a child you taught or ran the club for had a written plan, say what it held; if none did, say how you would build one for a fourth grader who is not reading at grade level. |

## Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| Valid PEL with elementary endorsement (invitation) | E1 — F1 is a fact, not a gap |
| Reading instruction (district page) | C1, C2, E2, F1 |
| Classroom routines (district page) | C2 |
| How you work with families (district page) | C3, D1, D3 |
| Fourth Grade Teacher position (invitation) | A1, A4 |
| Grade-level team (invitation) | A2, B1, B2 |
| Team-lead experience (district page, representative posting) | A2 — F4 |
| Assessments inform teaching (district mission page) | B3 |
| Every Child a Reader (district mission page) | D2 |

## Prohibited claims

This pack will not coach these claims. Each names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've taught fourth grade" | Sourced negative: your message, "I've never taught fourth grade" | "I've never taught fourth grade." Plain acknowledgment; no slot. |
| "I've been a team lead" | Sourced negative: your message, "I've never been a team lead" | "I've never been a team lead." Plain acknowledgment; no slot. |
| "I chose the reading curriculum" | Inflated form of F2's quote, "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. Pack observation: your material says you led the move, not what you decided in it. A3 asks which parts were yours to decide. |
| "I speak with every family every term" | Inflated form of F5's quote, "I write a weekly email to families" | The quote at its own scope. Pack observation: your material shows writing, not speaking. |
| "The students in the reading club improved" | Invented outcome; no quote carries one | The quote at its own scope: "I've run the after-school reading club for the last two years." No outcome claimed. |

## Reading the interviewer

**Principal Dolores Vantongeren.** Public footprint from one speaker page: nine years as a reading specialist, then principal of Halvering Elementary since 2022. A 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.
- Expect reading-instruction probes, and conference vocabulary.
- The shared professional subject is reading. Bring the reading club and the 2024 curriculum move; do not build on any personal affinity.
- Reverse question 5 uses her path, not her identity.

## Persona table

Relationship prior: a panel blends the top two personas of each member. Members are named only as the principal and two grade-level teachers, so weights are panel-level. Loop: the district's hiring page establishes one 45-minute building panel. No values-style round is named, so the values cheat sheet is not built.

| Persona (weight) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5) | Quiet probes on fourth grade and team lead | Top weight: the principal is the hiring authority, and F3 and F4 are the panel's likeliest gaps | Concede the plain negative first, then the nearest quote; hold through two follow-ups |
| Peer Evaluator (4) | Seam and load: "what would you need from us" | Two grade-level teachers price what a hire costs their work | Reciprocity; describe seams as principles |
| Case/Strategist (3) | A live reading problem | Reading instruction is on the panel's list, and the principal's public work is on reading | Clarify before answering; state the approach as a plan |
| Values/Behavioral (3) | Families and reading plans | District pages name both families and every child's reading plan | Story-map from a quoted sentence, or take the honest branch |
| Conversational (2) | The warm opener and the "tell us about yourself" arc | Panels open warm, and the opener is scored | A 90-second arc |
| Prober (2) | Counts and measures for the 2024 move and the club | Only two result-shaped lines are in the material | Say what was counted; name the weakest assumption you know |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you ready for this room?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Open with the absence in your words: "I've never taught fourth grade." Then the six years in third grade and what carries across. Close with a 60-day plan, said as a plan. Make no claim of fourth-grade experience. | F3 is the likeliest objection; the question presupposes the absence, so the guidance concedes it first. |
| A2 | "You've never been a team lead. Why would a grade-level team trust you with its work?" | JD | [grounded] "I've never been a team lead" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Highest-ROI prep in this pack. Say the plain negative first: "I've never been a team lead." Then the move, at its own scope: you led the move. Hold through two follow-ups by returning to what the move was. Concede that team lead is a role you have not held. Answer slot: which parts of the move were yours to decide and which were decided above you; say which, in your words. | F4 is the largest gap, and a fourth-grade team will be in the room; this objection will come in some form. Deepest rehearsal. |
| A3 | "On your CV the 2024 move is the closest thing to leadership. What did you actually decide?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer in order: what you led, who was involved, what you did. Answer slot: say which parts were yours to decide and which were decided above you. If none were yours to decide, say so plainly and describe your part. | F2 is presentation-graded; attribution is the probe. The question presupposes a decision the quote does not carry, so the guidance asks rather than states. |
| A4 | "Why would a team that already has its routines take on someone new to fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | Name what carries across from third grade, in your words, then what you would ask the team in week one. Make no claim about this team's routines. | F3 under pressure; the hold is the plan, not the past. |

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from our team in your first month?" | JD | [grounded] "I write a weekly email to families" — your CV | Ask for what a new teacher needs: the unit calendar, the assessment schedule, the family-contact routine. Offer what you bring: the weekly family email, as a routine you already keep. | The peer form of the team-fit question (F4); reciprocity framing. |
| B2 | "Where does your reading work end and ours begin?" | JD | [grounded] "I've run the after-school reading club for the last two years" — your CV | Describe the seam as principles: what the club is, what the school day covers, and what you would bring to the team's decisions. Claim no boundary the district has not drawn. | A seam probe from a peer; F6 is the only reading-club evidence. |
| B3 | "What happens when a colleague and you disagree about a student's reading level?" | VAL | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district mission page | If you have a time you handled a disagreement about a student, tell it. If not, say so and give your approach: bring the assessment data, name what it does not show, and decide together with the team. | Peer disagreement style, framed by the district's own value. |
| B4 | "How do you share credit when work spans the team and the club?" | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say what you ran and what others did, as far as you know it. Claim only what you ran. | A credit probe; the club is the only span-of-work evidence in the material. |

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Three students are two levels behind in reading by October. What's your first move?" | CASE | [generic] | Clarify: which measure, what the classroom data shows, and what the grade-level team already uses. Objective: each student's next reading step. Approach: small-group conferences, then check progress against a written plan. Risks: over-testing, and a plan nobody reviews. | A live problem from the role, asked as a decision. No claim about your past. |
| C2 | "Walk us through the first two weeks of a reading block in a fourth-grade room." | CASE | [generic] | Routine first, then the diagnostic, then the groups, then the family note. Name the assessment you would use and why. Do not describe this school's curriculum. | Routines and reading instruction are on the panel's list (F2). |
| C3 | "A family emails that their child is falling behind. What do you do before you reply?" | CASE | [grounded] "I write a weekly email to families" — your CV | Clarify the concern, check the data, decide what the family needs to hear, then reply. The weekly email is the habit you already keep for families. | Ties F5 to a live problem. |

### Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you explained a hard reading result to a family." | VAL | [grounded] "I write a weekly email to families" — your CV | Open prompt: choose a real instance. Map the weekly email: what you tell families about reading, and how. Answer slot: if you have a specific conversation about a hard result, tell it in your words; if not, say so and describe what the weekly email carries. | "Families Are Partners" is a district belief (F5); the open prompt is the panel's to ask. |
| D2 | "How do you make sure no child in your class goes without a reading plan?" | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV | Quote the club as the reading work you have done. Answer slot: if a student had a written plan, say what it held; if none did, say how you would build one. | "Every Child a Reader" is on the district's page; the plan premise is the district's, and the second branch stays open. |
| D3 | "Tell me how you speak with families, not just write to them." | VAL | [grounded] "I write a weekly email to families" — your CV | Answer slot: say how you speak with families, and what you do not yet do; if you are not yet doing a part, say how you would start. | Presupposes speaking, which only the district's values page raises, so the second branch stays open. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through your route into teaching." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV; "Six years teaching third grade at a public elementary school in Joliet" — your CV | A 90-second arc: the license, six years in third grade in Joliet, the reading work since. Stop at the reading club. | A casual opener, scored; the rest of the panel tests this arc. |
| E2 | "Which reading program have you used most?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Name the program in your words, only if you can name it. If you cannot, describe what it was for. | Reading instruction is on the panel's list (F2); a named program is the quickest sign of grounding. |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which reading measures did the 2024 move use, and how were they counted?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: say which measures you used and how they were counted, in your words. If you did not track a measure, say so, and name the assumption you would defend least. | The defend-the-number slot. No figure is given, so none is defended. |
| F2 | "How many students were in the reading club, and what did you track for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer slot: if you can state the number of students and what you tracked, say both. If you did not track anything, say so. State no outcome the material does not show. | A count on a figure the CV does not give; the outcome half is the inflation risk. |

## Reverse questions

1. "What does a strong first semester look like for a new fourth-grade teacher here?" — Why it lands: it shows you are planning for the year.
2. "How does the team plan reading together, and where would a new teacher fit?" — Why it lands: a peer-facing question that prices the seam.
3. "What reading data does the team review each term, and who decides the next step?" — Why it lands: it ties to the district's assessment belief.
4. "How does the district support a teacher who is new to a grade?" — Why it lands: it points at F3 and gives the panel room to describe support.
5. "You were a reading specialist before you became principal. What do you look at first in a classroom's reading?" — Why it lands: it uses the principal's own path and turns an interview into a peer conversation.
6. "What could a new person do in the first month that would genuinely help your team?" — Why it lands: reciprocity, for the two grade-level teachers.

## Sources

Provided documents: the invitation text, your CV, and your message.

Searches and fetches, as sent:
- "Halvering Elementary School Orrinsford Community School District values" — returned the district's Mission and Beliefs page; fetched.
- "Orrinsford Community School District teacher interview process panel" — returned the district's How We Hire Teachers page; fetched.
- "Dolores Vantongeren principal Halvering Elementary" — returned a state principals' forum speaker page; not fetched.
- "fourth grade teacher job posting Illinois elementary endorsement Professional Educator License" — returned one job-board listing for a fourth-grade teacher, not attributable to this district. Used only as a representative posting for [inferred] wording; nothing quoted from it.

Research tier: L1 — searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | yes | Mission page named three beliefs; F5, F6, B3, D2 |
| 2. Interview process | yes | One 45-minute building panel; persona blend and the panel's topics |
| 3. Strategy / recent news | unavailable | Not sent in this run. Would have moved a CO bank, which this pack therefore lacks |
| 4. Interviewer | yes | Principal's public footprint: Interviewer read, C1's focus, reverse question 5 |
| 5. Representative JD | yes | One listing not attributable to this district; used only for [inferred] wording |

Values-style round: not detected. The hiring page names no values round, so the values cheat sheet is not built.

## Upgrade menu

- Full job posting text → turns the [inferred] requirements into quoted rows and adds JD-tagged questions
- Your answers to the answer slots (A2, A3, F1, F2) → those rows become grounded and the guidance sharpens
- The recruiter's note on any demo lesson or task → a build section for it
- The two team members' names → per-member persona assignment
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for a CO bank and loop reports
