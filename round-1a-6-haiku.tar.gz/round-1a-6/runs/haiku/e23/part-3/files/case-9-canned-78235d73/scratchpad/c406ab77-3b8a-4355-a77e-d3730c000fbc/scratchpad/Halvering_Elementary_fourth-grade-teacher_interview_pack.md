# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team.

Built without a job posting. Requirements come from the invitation (quoted) and from your CV and notes. Changelog: first version.

## How to use

- **Personas** describe how the question is asked. **Types** describe what is being scored.
- Type key: **EXP** = a question about experience you can point to. **JD** = tests a stated requirement. **CASE** = a live problem that makes no claim about your past.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it plainly: your license is active through June 30, 2029. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Your material shows third grade, not fourth. Bridge at the quote's own scope: "For six years I taught third grade." The step to fourth grade is an answer slot: name what carries over and what you would need to learn. |
| F3 | Working with colleagues on a grade-level team (generic role expectation; the panel includes two fourth-grade team members) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [generic] | transferability | Your material shows a curriculum change you led for your grade level. Do not stretch it into team leadership. Answer slot: where the decisions were yours to make, say which; where the team or the district decided, say so. |
| F4 | Team leadership (generic role expectation) | "I've never been a team lead" (your message) | none given | [grounded] | capability | A gap you stated. Words: "I haven't been a team lead." Then a plan for how you would prepare for a lead role, said as a plan, never as a past. |
| F5 | Communicating with families (generic role expectation) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | A CV line with nothing measured behind it, so expect a probe. Lead with the weekly email in its own terms. |

Gap-and-bridge language is in the rightmost column. Gap types follow the routing in the evidence-conventions reference.

## Prohibited claims

Not coached, with the basis for each:

| Not coached | Basis | Honest form |
|---|---|---|
| "I was the team lead" or "I have led teams" | Inflated form of F3, and the stated negative in F4 | F4: "I haven't been a team lead." |
| "I have fourth-grade experience" or "I know the fourth-grade curriculum" | Inflated form of F2 | F2: "For six years I taught third grade." |
| Reading-score gains, test results or percentages from the reading club or the curriculum move | No figures appear in your material; inventing them is the failure this pack exists to stop | If you have results, tell me and they enter the snapshot. If not, say what you observed. |

## Question banks

Persona weights: the principal is most likely to test fit and leadership (high). The two team members are most likely to test the fourth-grade seam (high). A pressure follow-up from either is possible (moderate).

### A. Principal (evaluative administrator): high weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What changes for you in fourth grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Start with the six years, in those words. Name one thing that carries over and one thing you would need to learn. Answer slot: the fourth-grade content you would need to learn, and how you would learn it, as a plan. | F2 is the transferability gap and the likeliest probe. |
| A2 | "Tell me about a time you led colleagues through a change." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell the curriculum move in your words: what you did and what the grade level decided. Answer slot: where the decisions were yours, say which; where the team or district decided, say that. Do not call it team leadership. | F3. This is your strongest story, and it must stay at its own scope. |
| A3 | "Have you held a leadership role on a team?" | JD | [grounded] "I've never been a team lead" | Plain acknowledgment: "I haven't been a team lead." Then point to A2 as the closest experience, at its own scope, and say how you would prepare for a lead role. | F4 is a gap you stated. Naming it plainly is stronger than hedging. |

### B. Fourth-grade team members (peers): high weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What do you do for families each week, and how would you adapt it for our fourth graders?" | EXP | [grounded] "I write a weekly email to families" | Describe the weekly email in your words and what it contains. Answer slot: if you have written for families of a different grade, say what you would change for fourth grade. | F5. The seam is the adaptation, so do not claim it is already done. |
| B2 | "Our team plans reading together. How would you fit in?" | CASE | [generic] | Ask what the team's current plan is. Then describe how you would share your reading experience and ask where the team wants you. This question makes no claim about your past. | A peer seam: they want to know whether you will collaborate, not just what you have done. |
| B3 | "What did you actually do in the after-school reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Name the club, the two years, and what you did in sessions, only what you actually did. Answer slot: if you saw results, say what you observed; if you have no figures, say so. | Peers ask for the denominator. Do not add numbers you do not have. |

### C. Pressure follow-up (skeptic): moderate weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Six years in third grade. Why should we believe you'll be fine with fourth?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Hold: state the six years and one specific transfer. Concede what you would need to learn, and say how. Do not argue the premise. | Pressure on F2. Hold, then concede. |
| C2 | "Have you ever been responsible for a team's outcomes?" | JD | [grounded] "I've never been a team lead" | Hold: "I haven't been a team lead." Concede at the scope you did have: the curriculum move in A2. Do not broaden it. | Pressure on F4. The honest answer is short. |
| C3 | "Show us the reading results from the curriculum move." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you tracked results, say what they were; if you did not, say so and say what you would track first. Never supply figures. | The question presumes results. Your material shows none, so the honest branch is valid. |

## Reverse questions

Each has a reason it lands.

1. "What does a successful first year look like for someone in this role?" Why: it puts the focus on outcomes and gives you the panel's own measure.
2. "What is the fourth-grade team's current reading plan?" Why: it connects B2 to a live plan and shows you are already thinking about their work.
3. "How does the team plan together, weekly or by unit?" Why: it is practical, and it tells you how much to prepare for the collaboration questions.
4. "How does the district support a new teacher who later takes on a lead role?" Why: it turns the team-lead gap (F4) into a question about growth.
5. "What could a new person do in the first month that would genuinely help your team?" Why: a reciprocity question for a team-member panel. It shows you want to contribute, not just be assessed.

## Sources

- Provided documents: the interview invitation; your CV; your notes in this conversation.
- Research tier: L0. No searches were run in this session, so no outside facts are in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering / Orrinsford values | unavailable | Values cheat sheet, not built: no search was run and no values document was provided |
| 2. Panel interview process for this district | unavailable | Loop structure and persona weights, here set from the invitation's stated panel format |
| 3. Recent strategy / news | unavailable | Current district priorities, not gathered |
| 4. Principal Dolores Vantongeren public footprint | unavailable | Interviewer read and a tailored reverse question, not built: no search was run |
| 5. Representative fourth-grade teacher posting | unavailable | Would have turned F2 and F3 from [generic] into [inferred] |

## Upgrade menu

- The full job posting → F2 and F3 requirements become [grounded] quotes, and the question banks use the real requirements.
- HR's focus areas, or any deliverable such as a lesson demonstration → a deliverable section, with the grounded facts to build on.
- The principal's public profile → an interviewer read and a reverse question tied to their career path.
- Research at L1 (district values, the panel format, recent district news) → a values cheat sheet and a grounding brief.
