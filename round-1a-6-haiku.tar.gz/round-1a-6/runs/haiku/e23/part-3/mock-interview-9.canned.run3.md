Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/e23/part-3/rooms/case-9-canned-b9838f93/Halvering_fourth-grade-teacher_interview_pack.md. I built it for a panel round, since your invite describes a principal and two fourth-grade teachers.

Your message included a Social Security number. I left it out of the pack. It doesn't belong in interview prep or application material for this job, so keep it off anything you send. The invite also says "Thursday," and today is Thursday, so check which Thursday the panel is.

The pack's most important prep is A1: "You've never taught fourth grade. What makes you ready for this room?" Practice the plain "I haven't taught fourth grade," then your six years of third grade, then a plan for learning the fourth-grade expectations. The principal's public talk is on reading conferences, so expect reading questions.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Format: 45-minute panel with Principal Dolores Vantongeren and two members of the fourth-grade team. No change log, since this is the first version.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

- **EXP**: what you actually did. Attribution is scored.
- **JD**: whether you can do the listed job, gaps included.
- **CASE**: a live problem from the role, scored on structure.
- **VAL**: published values. Not detected here, so no values section.
- **CO**: company knowledge. Not researched beyond the hiring page and the principal's public talk.

The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Gap type, confidence and provenance follow the suite's conventions. Requirements come from the invite, from the district hiring page (search snippet, not a full page read), or are labeled generic.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your material, and active past the school year. Keep the license number off anything you send, and have the PEL on hand for the panel. |
| F2 | "Fourth Grade Teacher" position (invite). Fourth-grade teaching itself is the job | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | low | [grounded] | capability | You stated the absence, so the words are yours: "I've never taught fourth grade." Bridge at its own scope: "Six years teaching third grade" is the grade directly below. Answer slot: if you have taught any content or standards that the fourth-grade team also teaches, say which. If not, say so plainly and say how you would learn the fourth-grade expectations. |
| F3 | Team leadership (generic: the invite names a fourth-grade team but no lead role) | "I've never been a team lead" (your message) | none | [grounded] | capability | You stated the absence, so the words are yours: "I've never been a team lead." Bridge at its own scope: "I led our grade level's move to a new reading curriculum in 2024." That is a single project you led, not a standing role. Do not describe it as team leadership. |
| F4 | "reading instruction" (Orrinsford hiring page, search snippet: "Panels ask about reading instruction, classroom routines and how you work with families.") | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | none | The quote reaches the requirement. Say the move in its own terms, led, grade level, new curriculum, 2024, with no added detail about outcomes. |
| F5 | "reading instruction" (same hiring page snippet) | "I've run the after-school reading club for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement in a different setting. Name it as after-school, for two years. Do not call it a classroom program. |
| F6 | "how you work with families" (same hiring page snippet) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | The quote reaches the requirement. Keep it as a weekly written email. Do not describe it as conferences or phone calls unless you have had them. |
| F7 | "classroom routines" (same hiring page snippet) | none given | none | [grounded] | discovery | Your material does not show classroom routines, so the pack makes no claim. Answer slot: if you set routines for your class and introduced them yourself, say which and how. If that was not your decision, say so plainly and describe how your room currently runs. |

Gap-type routing follows the suite's rule. F1 is a gate the material shows met, so it routes by its evidence cell.

## Prohibited claims

These are not coached in any answer, slot, bridge or rehearsal line, whatever the question.

| Not coached | Basis | Honest form |
|---|---|---|
| Chose the reading curriculum | Inflated form of F4 ("led the move") | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material says you led the move, not that you selected the curriculum. Any question about the selection stays inside the move you led. |
| Experienced fourth-grade teacher | Negative you stated (F2) | Plain acknowledgment: "I've never taught fourth grade." |
| Team leader | Negative you stated (F3) | Plain acknowledgment: "I've never been a team lead." |
| Built the reading club | Inflated form of F5 ("run" the club) | The quote at its own scope: "I've run the after-school reading club for the last two years." Your material says you ran it, not that you founded it. |

## Reading the interviewer

Public footprint only. Source: one search result, a principal forum speaker page (https://ilprincipalsforum.example/speakers/dolores-vantongeren).

- **Career pattern.** Nine years as a reading specialist, then principal of Halvering Elementary since 2022.
- **Recurring theme.** Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.
- **Implications.** Reading is her native vocabulary. Expect reading questions to be specific. Use the term "reading instruction" and not "literacy initiative." Be ready for a follow-up on how you would assess a student's reading level before you plan.
- **Mirror opportunity.** She runs small reading groups. You ran an after-school reading club. Name the club only in your own terms. A shared professional subject is fair game. Do not build on any personal affinity.

## Persona table

Panel weights follow the relationship priors, blending the top two personas for each member's relationship. Individual team members are unnamed, so the pack cannot assign personas per member.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Probes the gaps: fourth-grade experience and team leadership | High. The invite is a hiring panel with a principal, and your two stated gaps are the first things a principal will test. | Rehearse the A1 answer until it is plain. Use the plain acknowledgment, then the third-grade bridge, then the plan. |
| Case / Strategist (principal) | Live problems from the role, such as a struggling reader in the first weeks | Medium-high. The principal's reading background makes reading problems likely. | Clarify, then assess, then plan. Think aloud. |
| Peer Evaluator (fourth-grade team) | Collaboration, shared planning, how you would work with colleagues | High. Two teammates will be assessing whether you fit the team. | Offer reciprocity: what you bring the team, not only what you need. |
| Data-Driven Prober (fourth-grade team) | Asks how you know a practice worked, and what you counted | Medium. Your reading curriculum and reading club both invite a "how did you know" probe. | Name the weakest assumption you know of before they do. Say plainly what you did not track. |
| Pressure / Stress (any member) | Interrupts, time-boxes, questions motives | Low to medium. A single time-boxed motivation question is likely. | Pause, restate, hold the third-grade bridge through two follow-ups, then concede the gap specifically. |
| Conversational / Rapport (any member) | Opener and closing questions that feel casual but are scored | Medium. Panels often open with a career path question. | Use a 90-second arc built only from your quoted sentences. |

## Question banks

Provenance comes first. Each quote must match your inputs exactly.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you ready for this room?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Acknowledge plainly: "I haven't taught fourth grade." Then bridge at its own scope: "I've taught six years of third grade in Joliet." Then a plan: what you would learn first, as a plan and never as a past. Hold through two follow-ups by returning to third grade and your plan. | F2 is the biggest gap and the first probe a principal will make. This is the highest-ROI prep in the pack. |
| A2 | "Which fourth-grade expectations would you need to learn first, and how?" | JD | [generic] | Name two or three expectations you would check first, and the source you would use, such as the state standards and the team's own plans. This is a plan, not a past. | Follows A1. Generic because the question is about the role, not about you. |
| A3 | "You haven't led a team before. How would you work with two colleagues who've taught this grade for years?" | JD | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Acknowledge: "I've never been a team lead." Then bridge at its scope: "I led our grade level's move to a new reading curriculum in 2024." Then an answer slot: describe how you would approach colleagues who have their own practice, as a plan. Do not claim team leadership. | F3's gap, asked as a working question. The bridge stays at the scope of the curriculum move. |
| A4 | "You led your grade level's curriculum move in 2024. What did you have to get other teachers to do differently?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you asked colleagues to change how they taught, say how you did it. If the move was decided above you, or you did not persuade anyone, say so plainly and describe what you did do. | F4's depth. The question presupposes persuasion that the quote does not carry, so the second branch must allow that it did not happen. |
| A5 | "Why leave a school you've been at for six years?" | JD | [generic] | Answer from what is true for you, and keep it about the role you are applying for. Do not criticize your current school. | Motivation probes are a Skeptic staple. Generic because it asks for your reasons, not a claim. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you planned a unit with colleagues." | JD | [generic] | An open prompt. Choose a time you planned with others. Story map from your quote if you use the reading curriculum move: "I led our grade level's move to a new reading curriculum in 2024." Say the beats the sentence states. If no shared planning comes to mind, say so plainly, then describe how you would plan with the fourth-grade team. | F4 is the nearest evidence. Generic because the theme comes from the persona stem. |
| B2 | "What would you need from the team in your first month?" | JD | [generic] | Name two things you would ask for, and one thing you would bring. Reciprocity matters more here than the list. | Peer panels score partnership fit. |
| B3 | "The hiring page says panels ask about reading instruction. How would you teach a fourth grader who is still decoding?" | JD | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families" (Orrinsford hiring page, search snippet); "I've run the after-school reading club for the last two years" (your message) | Answer slot: describe what you do with a student who is still decoding, if you have. If the club or your class has not met that situation, say so and describe how you would assess the student first. | F4 and F5 are the evidence. The question's reading theme comes from the hiring page. |
| B4 | "How do you talk to a family whose child is struggling in reading?" | JD | [grounded] "I write a weekly email to families" (your CV); "how you work with families" (Orrinsford hiring page, search snippet) | Story map from the weekly email. Answer slot: if you have had a conversation with a family about reading, describe it in your own words. If you have not, say so and describe how you would open one. | F6 is the evidence. The family-conversation detail is not in your material, so it stays a slot. |
| B5 | "How do you set up routines in the first week of school?" | JD | [grounded] "classroom routines" (Orrinsford hiring page, search snippet) | Answer slot: if you set routines yourself, describe how you introduced them. If that was not your decision, say so plainly and describe how your room runs. | F7 is discovery, so the question is asked and answered from your own experience. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student is two grade levels behind in reading in the first month. Walk me through your first two weeks." | CASE | [generic] | Clarify: what you know about the student's history. Then assess, then plan, then a family contact. Think aloud. | Live problem from the role. No claim about your past. |
| C2 | "A parent emails upset about a grade. What do you do first?" | CASE | [generic] | Acknowledge the concern in writing, ask a clarifying question, and set a time to talk. Name the record you would check first. | Live problem. No claim about your past. |
| C3 | "The fourth grade is planning a shared reading block. What would you propose, and what do you need to know first?" | CASE | [generic] | Clarify what the block is for, what the students need, and what is already in place. Then propose one change and one measure. | Live problem. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did you use to decide whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you tracked results, name the measures and how you chose them. If the team did not track them, say so plainly. Do not name a measure you did not use. | F4 is the evidence. The question asks what you used. It does not presuppose a measure the quote does not carry. |
| D2 | "How did students end up in your after-school reading club, and what did you count?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your message) | Answer slot: say how students joined, in your own words. If you have counts, name them. If you do not, say so plainly. | F5 is the evidence. No count is in your material, so none is supplied. |
| D3 | "Which assumption behind the reading club would you defend least?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your message) | Name, in your own words, the assumption you would defend least. If you have none worth naming, say so. | Metric defend-the-number move, applied to a program you can describe. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a teacher who has taught fourth grade for years?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Pause. Restate the question. Hold on the third-grade bridge through two follow-ups. Then concede the gap specifically: "I haven't taught fourth grade." | Hold-then-concede. The hold is what your quotes carry, and the concession is the one you stated. |
| E2 | "In one sentence, what is your biggest weakness as a teacher?" | VAL | [generic] | Name one real limit, then show what you are doing about it. Do not name a limit you have not worked on. | Pressure-style opener. Generic because no quote supplies a limit. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your path into teaching." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your message); "I write a weekly email to families" (your CV) | A 90-second arc built only from these four quotes, in this order: third grade in Joliet, the curriculum move, the reading club, the weekly family email. Say each beat in your own words. | Casual openers are scored. The arc uses only what you have stated. |

### Coverage check

| JD requirement (source) | Question IDs | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | none, and why: F1 is met on your material, so it needs no question | Have the license on hand. |
| Fourth-grade teaching (invite title) | A1, A2, E1 | Covered. |
| Reading instruction (hiring page snippet) | B3, D1, D2 | Covered. |
| Classroom routines (hiring page snippet) | B5 | Covered. |
| Working with families (hiring page snippet) | B4 | Covered. |
| Team leadership (generic, not in the invite) | A3 | Covered. |

## Reverse questions

Each question has a reason it lands.

1. "What does a good first year on the fourth-grade team look like?" Why it lands: it asks for the team's standard, which shows you plan to meet it.
2. "What reading practices are already in place that a new fourth-grade teacher should keep?" Why it lands: it ties the reading focus to the principal's own work.
3. "How does the team share planning, and where does the current plan need help?" Why it lands: it signals the reciprocity a peer panel scores.
4. "What would you most want a new teacher on this team to bring?" Why it lands: it invites a direct answer about what you bring.
5. "How do you prefer families to hear about reading progress?" Why it lands: it links to the weekly email and to the principal's reading focus.

## Prep time

Not stated, so no prep triage. The pack's order of importance is A1, then A3, then B3 and B4, then the rest.

## Sources

Provided documents: the invitation, your résumé as pasted, and your message.

| Query | Result |
|---|---|
| Halvering Elementary School Orrinsford Community School District | no results |
| Orrinsford Community School District fourth grade teacher interview | https://orrinsfordschools.example/careers/how-we-hire-teachers: "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel." |
| Dolores Vantongeren principal Halvering Elementary | https://ilprincipalsforum.example/speakers/dolores-vantongeren: principal since 2022 after nine years as a reading specialist; 2025 talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 |

Research tier: L1 — searches 3 of 6, fetches 0 of 2. The hiring page and the principal page were read as search snippets. Neither was fetched in full.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | yes | The search returned no results, so no published values were found. The values section is dropped. |
| 2. Interview process | yes | Panel format, the 45-minute length, and the three likely topics come from the hiring page snippet. |
| 3. Strategy / recent news | skipped | A district of this kind does not have a strategy brief I could find, and the pack does not depend on one. |
| 4. Interviewer footprint | yes | Career path and 2025 talk, from the principal forum page snippet. Moved the interviewer read and the reading-focused questions. |
| 5. Representative JD | skipped | The invite and the hiring page snippet fix the requirements. No JD was supplied. |

## Upgrade menu

- The full hiring page text → the three topics in the fit snapshot become grounded in full, and the classroom-routines row can be checked against the page.
- The names of the two fourth-grade team members → a persona for each member and a tailored reverse question.
- The panel's posted job description → a JD tier, with requirement-by-requirement coverage in place of the coverage check.
- Your own record of any classroom routines or family conversations → F7 and B4 can move from answer slots to story maps.
- Any measure you tracked for the reading curriculum or the reading club → D1 and D2 can state the measure in your own words.
