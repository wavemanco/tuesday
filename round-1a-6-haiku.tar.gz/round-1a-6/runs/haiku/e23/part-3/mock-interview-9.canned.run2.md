Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-3-rooms-case-9-canned-a87c044d/a7c4cce4-6610-4411-bfb9-a14b25c5998f/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it from your résumé note and the invite alone, with no research run and no job posting, so requirements beyond the invite are labeled generic.

The two gaps the panel is most likely to probe are the ones you named: you've never taught fourth grade, and you've never been a team lead. The pack rehearses both as plain acknowledgment followed by a bridge to what you did (six years of third grade, and leading the 2024 reading curriculum move), without claiming more than that. It has 20 questions across five panel styles, with the skeptic-style questions weighted most heavily.

Two things to do before Thursday:
- **Verify your license** on the ISBE lookup. The invite makes it a hard requirement, and I've treated your stated record as the only evidence for it.
- **Don't include your SSN** in the interview or on any interview paperwork. It isn't needed for interview prep, so I left it out of the pack.

Offers, neither pushed:
- **Drill:** I can play the panel and run any question live, then give feedback against that question's guidance.
- **Dossier:** I can write a `tuesday-dossier.md` from this pack if you want to carry it into other prep.

Question: could you paste the job posting and tell me the interview date? Today is Thursday, so the interview is either today or next Thursday, and the posting would let me replace the generic requirements with quoted ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Format:** 45-minute panel interview, Thursday
**Panel:** Principal Dolores Vantongeren (principal); two members of the fourth-grade team (peers, names not given)
**Gate from the invite:** valid Illinois Professional Educator License with elementary endorsement

**Built from:** your résumé note and the HR invitation only. No job posting, no research run (tier L0). Requirements below come from the invite's own words; anything else is labeled `[generic]`.

## How to use this pack

- **Personas** describe how a question is asked (the panel's style). **Types** describe what is being scored.
- **Type key:** JD = role requirements; EXP = your past work, tested for precision; VAL = values (none detected); CO = company knowledge (none researched); CASE = live problem.
- **Guidance is scaffolding, not a script.** Each answer should be 90 to 120 seconds spoken. Use your own words.

## Fit snapshot

| # | Requirement (source) | Candidate evidence (verbatim) | Confidence | Gap type | Gap-and-bridge language | Provenance |
|---|---|---|---|---|---|---|
| F1 | Valid Illinois PEL with elementary endorsement (invite: "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement") | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | medium: confirm on the ISBE license lookup before the interview | none | Gate met on your stated record. Verify it, then state it plainly. | [grounded] |
| F2 | Fourth-grade teaching (invite: "Fourth Grade Teacher position" and "our fourth-grade team") | "Six years teaching third grade at a public elementary school in Joliet." / "I've never taught fourth grade" | medium | transferability | Six years of elementary teaching, third grade as the adjacent grade. The limit is fourth-grade content and pacing, which is new to you. | [grounded] |
| F3 | Team participation and leadership (invite names a panel of a team; the team-lead role is not in the invite) | "I've never been a team lead." / "Led our grade level's move to a new reading curriculum in 2024." | medium | transferability | You have led one grade-level change, not a team lead role. State that limit yourself. | [grounded] |
| F4 | Reading instruction at grade level `[generic]` (typical for this role; not in the invite) | "I've run the after-school reading club for the last two years." / "Led our grade level's move to a new reading curriculum in 2024." | medium | none | Reading work is a strength to lead with, scoped to what you did. | [grounded] for evidence, [generic] for the requirement |
| F5 | Family communication `[generic]` (typical for elementary teaching; not in the invite) | "I write a weekly email to families." | medium (self-reported) | none | Routine communication you already run. | [grounded] for evidence, [generic] for the requirement |
| F6 | District's current grade-4 standards, pacing, and assessments (not in material) | none given | none | discovery | Ask the team in the interview which standards and pacing guide they use. Do not claim you already know them. | [generic] |

**Gate status:** F1 is the only hard gate. The record says it is active through June 30, 2029. Verify it on ISBE before Thursday.

## Prohibited claims

Built locally from the fit snapshot. These are the claims you may be tempted to reach for under pressure. Do not say them in the interview.

| # | Claim to avoid | Basis | Honest form |
|---|---|---|---|
| P1 | "I've taught fourth grade" | Candidate statement: "I've never taught fourth grade" | "Six years of third grade, and I haven't taught fourth yet." |
| P2 | "I'm a team lead" or "I led the team" | Candidate statement: "I've never been a team lead" | "I led our grade level's move to a new reading curriculum in 2024." Stay with that scope. |
| P3 | "I led the grade level" (inflated form of "Led our grade level's move to a new reading curriculum in 2024") | The résumé says you led one change, not the grade level. Wording to avoid, not a finding about you. | Quote the sentence as written. Your material says the move, not the grade level. |
| P4 | "I built or wrote the reading curriculum" (inflated form of "led ... move to a new reading curriculum") | The résumé says you led a move to a curriculum. Building it is not in your material. | Say what you led: the move. Name who chose or wrote the program only if that is true. |

## Persona weights

| Persona | Who | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal, team | 5 questions | The F2 and F3 gaps are the obvious probes. A panel with a principal weights experience with the grade level heavily. | Plain acknowledgment, then the bridge. Rehearse the hold and concession. |
| Peer Evaluator | Team members | 4 questions | They price what you would add to their grade-level work. | Describe the routine you already run. Ask about their practice. |
| Case / Strategist | Principal | 4 questions | Live situations from the role. | Structure first, then specifics. Name what you would check. |
| Data-Driven Prober | Team | 3 questions | Asks how you know something worked. The 2024 move and the reading club will attract this. | Weakest-assumption move: name the assumption you would defend least. |
| Pressure | Principal | 2 questions | A time-boxed challenge on the fourth-grade gap. | Hold then concede. |
| Conversational | Panel | 2 questions | Opening and welcome. | Use a 90-second opener built from your own sentences. |

Total: 20 questions. Ordered by weight.

## Question banks

### A. Skeptic (weight 5)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP / JD | "You've taught third grade for six years. What is different about fourth grade, and how have you prepared?" | Name the gap first: you have not taught fourth grade. Then the adjacent part: six years of elementary teaching. Name one thing you would check first (standards, pacing, the team's assessments). Preparation answer slot: if you have reviewed fourth-grade materials, say which; if not, say so and name what you would do first. | [grounded] "Six years teaching third grade at a public elementary school in Joliet." [grounded] "I've never taught fourth grade." | F2. The most likely first question, and the one most worth rehearsing. |
| A2 | JD | "Have you ever been a team lead?" | Plain acknowledgment: "No, I haven't been a formal team lead." Then the bridge: "I led our grade level's move to a new reading curriculum in 2024." Stop at that scope. | [grounded] "I've never been a team lead." [grounded] "Led our grade level's move to a new reading curriculum in 2024." | F3. A direct probe; the answer has to be short and clean. |
| A3 | JD | "Why should we hire someone who has never taught fourth grade over someone who has?" | Hold: your six years of elementary teaching and your 2024 reading work are real. Concede: "Someone with fourth-grade experience will need less ramp-up on content; I would expect to ramp up on grade-four pacing and would ask the team early." Do not promise a timeline. | [grounded] "Six years teaching third grade at a public elementary school in Joliet." [grounded] "I've never taught fourth grade." | F2. Hold-then-concede structure. |
| A4 | CASE | "How would you bring a new reading curriculum to a team that doesn't want it?" | Describe how you approached the 2024 move. Answer slot: if the 2024 move met resistance, say what it was and how it was handled; if it did not, say so and describe how you would approach it. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | F3 and F4. Hypothetical with a real anchor. |
| A5 | JD | "How would you handle a colleague who disagrees with your approach to instruction?" | Open prompt. Pick a time you disagreed with a colleague about instruction. If none comes to mind, say so plainly, then give the nearest thing your material carries: the grade-level move. Answer slot: if the 2024 move involved disagreement, say how it was resolved in your own words; if it did not, say so and describe your approach. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | F3. Open prompt with an honest branch. |

### B. Peer Evaluator (weight 4)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "What does your weekly family email look like, and what have families said about it?" | Describe the routine. Answer slot: if you have feedback from families, say what it was; if you have not gathered any, say so. | [grounded] "I write a weekly email to families." | F5. Shows how you would communicate with the team's families. |
| B2 | EXP | "Tell me about a time you planned instruction with colleagues." | Open prompt. Story map from the 2024 move: the change, then the planning it needed. Answer slot: the planning you did, in your words; if the planning was someone else's, say so and describe your part. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | F3 and F4. |
| B3 | EXP | "What did your part of the reading curriculum move actually involve?" | Name only your part. Weakest-assumption move: name the assumption you would defend least, before they do. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | Attribution honesty. The question tests whether "led" is precise. |
| B4 | EXP | "What did the team keep from the curriculum, and what did it change?" | Open question. Answer slot: if the team changed anything, say what and why; if you made no changes, say so. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | F4. Tests whether you describe a process, not a claim. |

### C. Case / Strategist (weight 4)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE | "A student reads two levels below grade level in October. What do you do in the next two weeks?" | `[generic]` structure: assess the gap, group for targeted instruction, monitor progress weekly, contact the family. Say what you would check first. | [generic] | Live problem from the role. Structure first. |
| C2 | CASE | "Your grade team is using a math pacing guide you think is too fast. What do you do?" | `[generic]` structure: learn the reasoning behind the pacing, raise concerns with the team, and propose one test. Do not criticize the team. | [generic] | Tests collaboration. |
| C3 | JD | "What should a fourth grader be able to do in reading by June?" | `[generic]` answer: fluency, comprehension of grade-level text, written response. Name the current Illinois standards and say you would check the district's version. | [generic] | Tests whether you know the grade's target. |

### D. Data-Driven Prober (weight 3)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| D1 | EXP | "How do you know the reading curriculum change worked?" | Weakest-assumption move: name the assumption behind your answer. Answer slot: if you tracked a measure, name it and how you counted; if you did not track one, say so and name what you would track. | [grounded] "Led our grade level's move to a new reading curriculum in 2024." | Prober. The résumé gives no measure, so you should not invent one. |
| D2 | EXP | "What did your after-school reading club show in attendance or reading levels?" | Answer slot: if you have attendance or reading level data, say the figures and how you counted them; if you did not track them, say so. | [grounded] "I've run the after-school reading club for the last two years." | Prober. Defend the numbers you have, or none. |
| D3 | CO | "Which reading assessment does this district use?" | `[generic]`. You have not researched this. Say you would check with the team, and name the assessment you know from your current school. | [generic] | Tests the candidate's preparation. |

### E. Conversational (weight 2)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| E1 | JD | "Tell us about yourself." | 90-second opener built from your own sentences: PEL, six years of third grade in Joliet, the 2024 reading move, the reading club, the weekly family email. | [grounded] "Six years teaching third grade at a public elementary school in Joliet." / [grounded] "I've run the after-school reading club for the last two years." | Opening. Use your words. |
| E2 | JD | "What drew you to Halvering?" | `[generic]` until you research the school. Name one specific reason you can verify from its public page. Do not guess at its program. | [generic] | Rapport. Weak without research. |

### Pressure (weight 2, uses A3 structure)

| ID | Type | Question (interviewer's line) | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| P-1 | JD | "Fourth grade is a different job from third. Why should we see your experience as enough?" | Hold: your six years and your 2024 reading work are real. Concede: "It's a real gap, and I would close it by planning with the team early and asking for their materials." Do not claim fourth-grade experience. | [grounded] "Six years teaching third grade at a public elementary school in Joliet." / [grounded] "I've never taught fourth grade." | F2. Hold then concede, with a plan rather than a claim. |

## Reverse questions

1. "What does a new fourth-grade teacher's first month look like here?" *Why it lands: shows you are planning the transition.*
2. "How does the fourth-grade team plan reading instruction together?" *Why it lands: shows you care about the team's practice.*
3. "What would make this role a success at the end of the first year?" *Why it lands: frames success in their terms.*
4. "What does the principal look for in a teacher who will later take on a leadership role?" *Why it lands: connects to the team lead gap and asks for a path.*
5. "What is the team's biggest challenge this year?" *Why it lands: invites a conversation.*
6. "What could a new person do in their first month that would genuinely help your team?" *Why it lands: the reciprocity question for team members.*

## Sources

- Provided documents: HR invitation to the panel interview; the résumé note you supplied.
- Searches run: none. Fetches run: none.
- Research tier: **L0** (provided documents only).
- Target accounting: company values, loop structure, and current strategy: skipped. Interviewer public footprint: skipped (names of team members not given; principal named but not searched). Recent organization context: skipped. Role-family loop reports: skipped.

## Upgrade menu

- **Job posting text** → F4 and F5 become `[grounded]` rows instead of `[generic]`, and the requirements in the invite are checked against the posting.
- **Interview date and any stated focus areas or a teaching demonstration** → the panel's structure and the guidance change.
- **Names of the two team members** → a public-footprint check on their roles and any published work, and an interviewer read.
- **Deep research on the school and district (tier L1, about 6 searches and 2 page fetches)** → school and district context, current strategy, and the principal's public footprint, which tailors E2 and the reverse questions. L2 adds up to 6 further searches and 2 further fetches and takes more time; say if you want either.
- **Program name and any figures from the 2024 reading move or the reading club** → sharpens B2, D1 and D2. Only figures you can stand behind.
- **ISBE license lookup result** → upgrades F1 from `medium` to `high`.
- **A Word version of this pack** → available on request.
