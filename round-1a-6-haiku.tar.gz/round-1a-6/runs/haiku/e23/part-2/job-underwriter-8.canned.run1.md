**Don't go ahead. This is a scam, and the posting is the least of it.** Stop all contact with @VellowayHiring and don't send anything else.

**Why it's a scam:**
- **Advance-fee and fake-cheque fraud.** You're asked to pay €349 for "equipment" and then to deposit a €2,850 cheque, keep €350, and send the rest to a "partner." Cheques take days to clear and can be reversed, so the money you send out is really yours and the scammers' cheque bounces. You end up out of pocket.
- **Money mule recruitment.** Lodging third-party cheques and forwarding money is how fraud proceeds get laundered. If you did it, the bank would treat you as a participant, and you could lose your account.
- **Identity theft setup.** They asked for your IBAN, PPS number and passport photo before any interview. That's the set needed to open accounts or take out loans in your name.
- **Telegram-only hiring with no calls, plus a fake "screening" and "interview" done in chat.** Real employers with a legitimate payroll don't do this, and they don't ask for a passport before a first conversation.
- **Red flags in the posting:** "earn up to €26/hour plus commission on every order" with no experience needed, the vague 15–30 hours, and a generic-looking contact address (`velloway.hr@postmail.example`) rather than a company domain.

**What to do now:**
1. **Don't send your IBAN, PPS number, passport photo, or any money.** If you already sent anything, call your bank now, tell them it was a scam payment, and ask about recalling it. Also consider a fraud alert with the Credit Registry and Revenue.
2. **Report it.** Use the Garda National Cyber Crime Bureau's online reporting or your local Garda station, and report the Telegram account to Telegram. Tell the jobs site so the listing gets removed.
3. **Don't deposit the cheque or forward money for anyone.**

**Your background is a real asset.** Three years of Zendesk ticket volume, training new starters, and running a team's Excel tracker fit actual remote customer-operations and support roles. Look for them on the employers' own career pages, or on job boards where the posting links to a verifiable company website. I can help you check a real posting or tailor your CV for one.

**Watch-out:** A summary line here can contradict the evidence table. Before you act on a count, an "only" or an all-clear, check it against the table's rows.