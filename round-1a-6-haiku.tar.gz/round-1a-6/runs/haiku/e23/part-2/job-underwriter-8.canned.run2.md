**No, this isn't legitimate. Don't send anything, and don't paste your IBAN anywhere.** This is a textbook advance-fee and overpayment scam.

**Why I'm confident:**

- **You pay them.** They want €349 for "equipment" before you start. Legitimate employers don't charge for a work kit, and "refunded with your first wages" is a promise made to get your money first.
- **The cheque is the core trick.** They'd send you a €2,850 cheque, ask you to deposit it, keep €350, and transfer the rest to their "equipment partner." The cheque would later be returned as fraudulent, and the money you sent out would be gone, and your bank would hold you liable for the amount.
- **Sensitive data before any real interview.** Your IBAN, PPS number and passport photo are enough for identity theft and bank fraud. A real employer collects these only after a signed contract, through a formal onboarding process.
- **Telegram-only hiring with no calls or video**, an "interview" that is a chat, and a job offered in the same chat, with no company website, contract, or verifiable contact. The email domain `postmail.example` is generic and unconnected to any company.
- **Pressure and fast approval.** "Passed screening," "the job is yours," and the cheque came quickly after a chat. That speed is designed to get you to act before you think.

**What to do:**

1. **Stop replying** to @VellowayHiring and velloway.hr@postmail.example. Don't send the IBAN, PPS number, or passport photo.
2. **If you've already sent any of those,** contact your bank now, ask them to flag the account and watch for suspicious activity, and consider changing passwords. In Ireland, report it to the Gardaí and to the fraud reporting service on your bank's site.
3. **If a cheque ever arrives,** don't deposit it or send money from it.
4. **If you want to check the company,** search the CRO register and the company's own website, not any link they send. I can't verify this company's existence from here, but nothing in the posting suggests it's real.

**On fit:** Your background is a good match for remote customer-operations and order-processing roles: Zendesk volume, training new starters, and Excel tracking are real, relevant evidence. Look for these on job boards and company career pages with a real application process. Also note that the posting's pay (up to €26/hr for 15–30 hours a week) only reaches about €30k a year at the upper end of hours, so check any real offer against your floor.

**Watch-out:** A summary line here can contradict the evidence table. Before you act on a count, an "only" or an all-clear, check it against the table's rows.