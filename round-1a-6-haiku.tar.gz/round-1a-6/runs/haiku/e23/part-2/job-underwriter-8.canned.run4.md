**Decision: `no_go`.** Don't send anything to this contact, and don't pay or deposit anything.

**Decision snapshot**
- **Fit:** Your customer service, Zendesk and Excel experience match the posted duties. The pay floor does not match.
- **Opportunity:** Multiple scam markers, all from the posting and messages you provided.
- **Hard gates:** Pay (your €30,000 floor) fails on the posted figures. At the €26/hour ceiling, 15–30 hours a week comes to about €20,300–€40,600 a year before commission. "Up to" is a ceiling, and the commission is unquantified. `[grounded]`, from the posting's own numbers.

Research tier: L0, no searches. The posting and messages are decisive without them, so I did not look up Velloway.

**Role reality**
- Remote order processing, 15–30 hours a week, "up to €26/hour" plus unquantified commission, no experience needed.
- Hiring runs only on Telegram, with no calls or video interviews. Interviews also happened in chat.
- Pay floor mismatch: see the hard-gate line above.

**Evidence map** (fit is against the posting's stated requirements)

| # | Priority | Requirement | Fit | Basis |
|---|---|---|---|---|
| 1 | hard_gate | Pay meets €30,000/year | Does not fit on posted figures | Posting arithmetic `[grounded]` |
| 2 | must-have | Customer-facing, high-volume work | Strong | About 60 Zendesk tickets/day, 3 years, from your CV (CV-only, so a lead, not proof) |
| 3 | must-have | Spreadsheet confidence | Strong | Keeps a weekly Excel tracker, from your CV |
| 4 | must-have | Attention to detail | Not shown in documents | No evidence provided |
| 5 | must-have | Good written English | Not shown in documents | Your writing is the only sample, and the employer did not assess it |
| 6 | preferred | Trains others | Strong | Trained two new starters, from your CV |

**Opportunity risk register**
1. **Upfront identity requests** (severe): they asked for your IBAN, PPS number and a passport photo before any interview. Legitimate employers collect these after a signed offer, through a secure HR system.
2. **Fee for equipment** (severe): €349 to a "partner" for a laptop and headset, refunded "with your first wages." Real employers supply equipment. This is a common scam.
3. **Overpayment cheque** (severe): they plan to send you €2,850, asking you to deposit it, keep €350 and forward the rest to their "partner." The cheque will likely bounce after you have transferred real money. This is a classic fraud pattern `[generic]`.
4. **No real interview** (high): "passed the interview" came after a few chat answers, with no role-specific assessment.
5. **Contact channel** (high): Telegram only, with a generic email domain (postmail.example) for "problems."
6. **Pay mismatch** (high): see the hard-gate line.

**Application plan**
Don't apply through this channel. Your background fits real roles at real employers, so apply directly through the company's own careers page or a verified job board. Set a €30,000 floor in your searches and ask for the hourly rate, base pay and commission terms in writing before any interview.

**If you have already sent anything**
- Don't send anything else, and don't deposit the cheque if one arrives.
- Contact your bank today about the IBAN, and ask them to watch the account.
- Report the chat to the Gardaí and the jobs site where you found the posting.
- If you sent your PPS number or passport photo, consider a credit check and monitoring.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0, no searches run |
| 2. Role-family pay and scope sweep | skipped | L0, no searches run |
| 3. Hiring manager footprint | n/a | No name given |

**Dossier offer:** At the end of this engagement, I can write a `tuesday-dossier.md` file with these findings and your background for later use.

**Upgrade menu:** Nothing you could add would make the equipment fee, the upfront identity requests or the cheque arrangement acceptable. A search could confirm whether Velloway Logistics exists, but that would not change this decision. A link to a real posting on the company's own site would help you compare it.

**Questions**
1. Have you already sent your IBAN, PPS number or a passport photo to @VellowayHiring, or paid anything?
2. Has a cheque or payment arrived from them yet?

Reply to either question, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.