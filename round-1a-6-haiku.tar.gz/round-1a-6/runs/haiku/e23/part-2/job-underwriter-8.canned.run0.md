**Don't go ahead. This is a scam, and I'd stop all contact with @VellowayHiring now.**

I didn't run web checks on Velloway. The verdict doesn't need them, because the conversation shows the pattern on its own:

- **Your bank and identity details came before any real interview.** A genuine employer asks for IBAN, PPS and passport details only after a signed contract, and never through Telegram.
- **You're asked to pay money to start.** The €349 "equipment partner" payment is a classic advance fee. Real employers don't ask new hires to pay for their own kit, and "we'll refund it later" is the usual line.
- **The cheque is the most dangerous part.** You'd deposit €2,850, keep €350, and send the rest on to them. Banks often show deposited cheques as available within days, before the cheque is cleared. When it bounces, the money you sent out is gone and you owe the bank that amount. You'd be acting as a money mule.
- **The contact is a free-mail-style address, not a company domain,** and the "job" is advertised with vague pay, no named company contact, and a Telegram-only process.

**Don't send your IBAN, PPS number or passport photo, don't pay anything, and don't deposit or forward any cheque or transfer.** You haven't sent anything yet, so keep it that way.

**What to do now:**
- **Don't paste your IBAN** into anything from this recruiter.
- **Block the account and report it** to Telegram, and report the listing to the jobs site.
- **If you've already sent anything,** contact your bank's fraud line straight away, and report it to the Gardaí. If you've shared your PPS number, watch for unexpected activity and consider telling the Department of Social Protection.

**For the job search:** your background suits real remote customer-support and operations roles: three years of Zendesk ticket volume, training new starters, and running a team tracker in Excel are all strong evidence. To find genuine roles, apply through the employer's own careers page, and expect a video interview with a named person on a company email domain before any paperwork. If you paste a real posting here, I can check it against your experience and tell you where the gaps are, and I can help tailor your CV for it.