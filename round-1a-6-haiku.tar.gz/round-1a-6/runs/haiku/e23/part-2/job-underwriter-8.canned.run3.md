**Decision: no_go.** This is almost certainly a scam. Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit the cheque.

## Decision snapshot

- **Candidate fit (ledger 1):** Strong on paper. Your Zendesk volume, Excel tracker and training experience match the stated tasks. [grounded, from your background]
- **Opportunity quality (ledger 2):** Fails on its own terms. Every stage asks for money or sensitive data, and none of it is verifiable. The fit doesn't change the verdict.
- **Hard gates:**
  - **Pay floor (€30k), at risk.** At the top rate of €26/hr, 52 weeks, you need about 22 hours a week to reach €30k before commission. The posting's "up to" rate and unstated hours don't guarantee that. [grounded arithmetic from the posting]
  - **Hard-gate failures:** none confirmed; the pay gate is unmet by default.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Attention to detail | must | strong | medium | none | Zendesk volume, tracker (your account) |
| 2 | Spreadsheets | must | strong | medium | none | Weekly Excel tracker (your account) |
| 3 | Good written English | must | unknown | low | discovery | No writing sample provided |
| 4 | Quiet workspace | must | unknown | low | discovery | Not stated |
| 5 | Pay ≥ €30k/yr | hard_gate | at risk | high | hard-gate | Arithmetic above |

## Opportunity risk register

| Class | Severity | Risk |
|---|---|---|
| Fraud | critical | Upfront "equipment" payment of €349 to a third party, refunded "with wages". This is a standard advance-fee pattern. |
| Fraud | critical | Cheque-overpayment scam: you'd deposit €2,850, keep €350, and send €2,500 out. The cheque bounces later and the money you sent is gone. |
| Data harvesting | critical | IBAN, PPS and passport requested before any real interview. This is enough to commit identity theft. |
| Employer identity | high | Unverified. Telegram-only, no company site, no registration, no call or video. |
| Process | high | A "screening" and a "job offer" both happen in chat, within days, with no role-specific questions. |
| Pay | medium | "Up to" rate, unstated hours and an unspecified commission. |

## Application plan

Don't apply through this route. Your real experience (Zendesk at roughly 60 tickets a day, two starters trained, an Excel tracker) is worth applying with to employers you can verify. Lead with those three facts. They are accurate as you stated them, so don't inflate them.

## What to do now

1. **Stop replying to @VellowayHiring.** Don't send any IBAN, PPS or passport details. Don't paste your IBAN into Telegram, even though you have it ready.
2. **If you've already sent anything, or a cheque has arrived:** call your bank now, report the cheque or transfer as suspected fraud, and report the scam to the Gardaí. Change any passwords tied to details you shared.
3. **Check the employer yourself:** the Companies Registration Office (CRO) search and the company's own website. If neither exists, you have your answer.

**Research tier: L0 — no searches; no user links read.** I did not check the company registration, the website or the posting, so the verdict rests on the posting and messages you gave me.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 tier; no research consented |
| 2. Role-family sweep (pay norms) | skipped | L0 tier; no research consented |
| 3. Hiring manager footprint | n/a | No name given |

## Gap recovery queue

- **G1, employer identity:** Closes with a CRO record matching the company name, a live careers page on the company's own domain, and a contact email on that domain.
- **G2, pay:** Closes only with a written contract stating base rate, guaranteed hours and commission. Telegram messages don't count.
- **G3, written English and quiet workspace:** Self-report only. Closes with a writing sample if a real employer asks for one.

## Next

If you'd like, I can check Velloway's registration and website. That needs your go-ahead, since it means searching. I can also draft a short message declining the role.

Questions:
1. Have you sent anything yet, or deposited any cheque or paid any money? That decides the urgency of the bank steps above.
2. Do you want me to run the registration and website checks (L1)?

I can also write up the full dossier (`tuesday-dossier.md`) for this assessment if you'd like to keep it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.