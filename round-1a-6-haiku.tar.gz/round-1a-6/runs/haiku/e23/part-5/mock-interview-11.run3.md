**Please check this before you reply to Jess.** The message has several classic recruitment-scam signs:

- **Unsolicited contact** from an unknown number, saying they "found your profile online."
- **WhatsApp only, with no calls or video.** A real recruiter can usually do a short video or phone screen, and the lack of one removes your easiest way to verify them.
- **The whole process, including the contract, happens over WhatsApp,** with an interview tomorrow and no earlier email or job reference.
- **"Remote with flexible hours"** is the usual hook in fake job offers.

This doesn't prove it's fake, but treat it as high risk until you verify it. Before tomorrow:

1. **Ask for the job reference and the company name,** then search the role on the company's own careers page, not a link they send.
2. **Ask for an email from a company domain** (not Gmail or similar), and check the domain matches the company.
3. **Look up the recruiter on LinkedIn** and check whether they really work at that company.
4. **Ask for a short video call.** A genuine recruiter will normally agree. Refusing or dodging is a red flag.
5. **Never send ID, bank details, tax or National Insurance numbers, or pay for equipment, training or "onboarding."** Stop immediately if they ask for any of these.

If you want to go ahead, you can take the screen, but share no personal or financial details until the company is verified.

## Interview prep pack (generic, since no JD or CV was provided)

Everything below is generic. Nothing describes your experience yet.

**1. Self-assessment worksheet**

| Field | Your answer |
|---|---|
| Company and role title (as stated by the recruiter) | |
| Where you saw or applied for the role | |
| Three requirements from the job ad, copied word for word | |
| For each requirement, one sentence from your CV that shows it | |
| Requirements you cannot yet evidence | |

**2. Question bank (recruiter screen)**

| Question | Type | Guidance | Provenance |
|---|---|---|---|
| Tell me about yourself. | Background | Two minutes: current role, two relevant achievements you did yourself, why you are looking. | Generic |
| Why this role? | Motivation | Name one specific thing from the job ad and one thing you want next. Avoid praise you can't back up. | Generic |
| What is your experience with remote or flexible working? | Working style | Describe a real remote setup or habit. Don't claim experience you lack. | Generic |
| What are your salary expectations? | Compensation | Give a range based on your research, and ask what the advertised band is first. | Generic |
| When could you start? | Logistics | Give your real notice period. | Generic |
| Why are you leaving your current role? | Motivation | Keep it brief and forward-looking. Don't criticise a former employer. | Generic |
| What do you not yet have that this role needs? | Gap | Name one real gap and how you'd close it. Don't invent a bridge you haven't started. | Generic |

*Rationale:* these are standard screen questions testing fit, motivation and logistics. Accuracy is the only thing you control.

**3. Questions to ask them**

- What is the exact job title, company name and posting reference?
- Can you confirm the role by email from a company address?
- Who is the hiring manager, and what does the team do?
- What does the full interview process look like, and can it include a video call?
- What is the advertised salary range?

A legitimate recruiter can answer these in writing. Evasive answers are informative.

**4. Upgrade menu**

- **Job advert or JD text:** lets me map your real evidence to each requirement.
- **Your CV:** turns the worksheet into a story-based answer bank.
- **Company name and where you saw the role:** lets me help check the company.
- **Round type and who interviews you:** changes which questions get weighted.

The full pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-e23-part-5-rooms-case-11-denied-50016edc/b9999777-d1a8-4b5e-8eb4-774fb078011b/scratchpad/interview-prep-pack.md`.

**Offers:** I can run a live practice interview once you've shared a JD and CV. I can also start a tailored prep file from them.

**Questions for you:**

1. What company and role is Jess recruiting for, and where did you apply or see it?
2. Can you share the job description and your CV?
3. Is this a first screen with a recruiter, or will you also meet the hiring manager?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: interview-prep-pack.md -----
# Interview prep pack (generic, session 1)

Provenance: no JD, CV or company was provided, so every item below is labelled **Generic**. Nothing here describes your experience.

## 1. Fit snapshot (self-assessment worksheet)

| Field | Your answer |
|---|---|
| Company and role title (as stated by the recruiter) | |
| Where you saw or applied for the role | |
| Three requirements from the job ad, copied word for word | |
| For each requirement: one sentence from your own CV that shows it | |
| Requirements you cannot yet evidence | |

## 2. Question bank (recruiter screen)

| Question | Type | Guidance | Provenance |
|---|---|---|---|
| Tell me about yourself. | Background | Two minutes: current role, two relevant achievements you did yourself, why you are looking. | Generic |
| Why are you interested in this role? | Motivation | Name one specific thing from the job ad and one thing you want next. Avoid praise you cannot back up. | Generic |
| What is your experience with remote or flexible working? | Working style | Describe a real remote setup or habit, such as a schedule, tools, or how you check in with others. Do not claim experience you lack. | Generic |
| What are your salary expectations? | Compensation | Give a range based on research you have done, and ask what the advertised band is first. | Generic |
| When could you start? | Logistics | Give your real notice period. | Generic |
| Why are you leaving your current role? | Motivation | Keep it brief and forward-looking. Do not criticise a former employer. | Generic |
| Is there anything you have not yet done that this role needs? | Gap | Name one real gap and how you would close it. Do not invent a bridge you have not started. | Generic |

**Rationale:** these are the standard screen questions. They test fit, motivation and logistics before any technical round. The only thing you control is accuracy, so answer from your own record.

## 3. Questions to ask the recruiter (reverse questions)

- What is the exact job title, company name and posting reference?
- Can you confirm the role by email from a company address?
- Who is the hiring manager, and what does the team do?
- What is the full interview process, and can it include a video call?
- What is the advertised salary range?

**Why these land:** a legitimate recruiter can answer each one in writing without difficulty. Evasive answers are informative.

## 4. Upgrade menu

- **Job advert or JD text:** lets the pack map your real evidence to each requirement.
- **Your CV:** turns the worksheet into a story-mapped answer bank.
- **Company name and where you saw the role:** allows checking the company and its careers page.
- **Round type and who interviews you:** changes which questions are weighted.
- **Recruiter details, if you share them:** can be used to check the process.
