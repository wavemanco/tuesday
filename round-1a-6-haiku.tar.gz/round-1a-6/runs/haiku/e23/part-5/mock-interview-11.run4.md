I'd hold off on the interview prep for now. This message has several hallmarks of a recruitment scam, and I'd want you to check it before you spend time or share anything.

**Red flags**
- **Unsolicited contact** from an unknown number, claiming to have found you "online" without naming the company, the role, or a job you applied for.
- **Chat-only process.** A genuine recruiter may use WhatsApp to schedule, but a full interview through to contract with no call or video is unusual.
- **Vague and appealing:** remote, flexible hours, no company name, no job title, no salary.
- **Fast timeline:** an interview "tomorrow" with no prior conversation.

Scammers who run this pattern usually later ask for ID or passport scans, bank details, or National Insurance/Social Security numbers. They may ask you to pay for "training", equipment or software, or to buy crypto or gift cards for "onboarding". Any of these would be a clear sign to stop.

**Before you reply with any details**
1. **Ask specific questions:** What company is hiring, what's the exact job title, and which posting did you apply to? Ask for the consultant's full name and the agency's name. A real recruiter will answer these easily.
2. **Check the company independently.** Go to the company's official website yourself, not via any link they send, and look for the role on its careers page. If there's no listing, or the company doesn't know about this recruiter, that's your answer.
3. **Confirm through official channels.** Call the company's main switchboard from its website and ask whether this person works there. For agencies, check the business is registered in your country.
4. **Search** the company or consultant name together with "scam" or "reviews", and check LinkedIn for both the person and the company.
5. **Don't share** ID, bank details, tax numbers or personal documents over WhatsApp, don't pay anything, and don't click links or install apps they send.

If you reply, you could say something like: *"Happy to continue, but please tell me the company name, the job title, and the posting I applied to. I'll also need to verify the role directly with the company before going further."*

**Once it checks out**, send me the job description, the company's name, and your CV, and I'll run the mock-interview prep: likely questions, answer guidance, gaps to address, and questions to ask them. If it turns out to be a scam, you don't need to prep, and I can help you spot other warning signs in later messages.