# Interview prep pack (generic, session 1)

Provenance: no JD, CV or company was provided, so every item below is labelled **Generic**. Nothing here describes your experience.

## 1. Fit snapshot (self-assessment worksheet)

| Field | Your answer |
|---|---|
| Company and role title (as stated by the recruiter) | |
| Where you saw or applied for the role | |
| Three requirements from the job ad, copied word for word | |
| For each requirement: one sentence from your own CV that shows it | |
| Requirements you cannot yet evidence | |

## 2. Question bank (recruiter screen)

| Question | Type | Guidance | Provenance |
|---|---|---|---|
| Tell me about yourself. | Background | Two minutes: current role, two relevant achievements you did yourself, why you are looking. | Generic |
| Why are you interested in this role? | Motivation | Name one specific thing from the job ad and one thing you want next. Avoid praise you cannot back up. | Generic |
| What is your experience with remote or flexible working? | Working style | Describe a real remote setup or habit, such as a schedule, tools, or how you check in with others. Do not claim experience you lack. | Generic |
| What are your salary expectations? | Compensation | Give a range based on research you have done, and ask what the advertised band is first. | Generic |
| When could you start? | Logistics | Give your real notice period. | Generic |
| Why are you leaving your current role? | Motivation | Keep it brief and forward-looking. Do not criticise a former employer. | Generic |
| Is there anything you have not yet done that this role needs? | Gap | Name one real gap and how you would close it. Do not invent a bridge you have not started. | Generic |

**Rationale:** these are the standard screen questions. They test fit, motivation and logistics before any technical round. The only thing you control is accuracy, so answer from your own record.

## 3. Questions to ask the recruiter (reverse questions)

- What is the exact job title, company name and posting reference?
- Can you confirm the role by email from a company address?
- Who is the hiring manager, and what does the team do?
- What is the full interview process, and can it include a video call?
- What is the advertised salary range?

**Why these land:** a legitimate recruiter can answer each one in writing without difficulty. Evasive answers are informative.

## 4. Upgrade menu

- **Job advert or JD text:** lets the pack map your real evidence to each requirement.
- **Your CV:** turns the worksheet into a story-mapped answer bank.
- **Company name and where you saw the role:** allows checking the company and its careers page.
- **Round type and who interviews you:** changes which questions are weighted.
- **Recruiter details, if you share them:** can be used to check the process.
