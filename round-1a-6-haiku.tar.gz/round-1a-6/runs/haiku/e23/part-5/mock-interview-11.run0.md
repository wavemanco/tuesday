I can't build the prep pack yet, and I'd hold off on the interview until you've checked Jess out.

**This message has several common recruitment-scam markers:**
- An unknown number, and no company or job title named
- "We found your profile online," which scammers use because it sounds like they've already vetted you
- A remote role with flexible hours
- The whole process over WhatsApp, with calls and video ruled out
- An interview tomorrow, with very quick scheduling

Some real recruiters work this way, but a legitimate one will name the company and role, and will be happy to talk on the phone or by video. Before you spend time preparing, I'd suggest:

1. **Reply and ask for specifics:** the client company's name, the exact job title, a link to the job advert, and the name of the agency Jess works for.
2. **Check the advert:** search for the job on the company's own careers page, or on the job board where you applied. Your recent applications may include this one, but confirm the details match.
3. **Verify the agency and person:** look up the agency on the Companies House register (UK) or the equivalent in their country, and check that Jess appears on the agency's website or on LinkedIn.
4. **Ask for a call or video chat** before the interview. Refusing is a warning sign.
5. **Never pay anything** (fees, equipment, training, "onboarding"), and don't send your passport, bank details, or other ID until you've verified a real employer and have a formal contract. Scams often ask for these early and make it sound routine.

Once you have the company and role, I can build the full prep pack for you. Please send me:
1. **The company name and exact job title** (the one thing I need to start). If Jess won't give them, that's useful information too.
2. **The job description**, if you have it, so I can match your experience to the role.
3. **Your CV or a short summary of your background**, so the answers are based on what you've actually done.