I'd hold off on prepping for this one. The message has several hallmarks of a recruitment scam, and I'd verify it before spending time on interview answers.

**Red flags:**
- **Unsolicited contact from an unknown number**, with a vague "we found your profile online."
- **No named company or role.** Jess hasn't said who the employer is or what the job is.
- **Everything over WhatsApp, including the contract, with no call or video.** Legitimate recruiters almost always speak by phone or video at some point.
- **An interview set for tomorrow** with no earlier screening.
- **Remote work with flexible hours**, which is a common lure for fake jobs.

Scams like this often lead to requests for ID or bank details, a fee for "training" or equipment, or use of your account to move money.

**How to check it:**
1. **Reply with questions, not a yes:** "Which company is this for, and what's the job title? Which job posting or platform did you see my application on?"
2. **Check the agency or company yourself.** Look up the company's official website and LinkedIn, and find the recruiter's name there. Don't use contact details from the WhatsApp message.
3. **Look at where you applied.** If the job was on LinkedIn, Indeed, or the company's careers page, the posting and the recruiter should be visible there.
4. **Ask for a phone call** on a number you found independently. Someone legitimate will agree.
5. **Don't share** your passport, ID, bank details, National Insurance or Social Security number, or any payment, and don't accept a contract or "onboarding" forms over WhatsApp.

You can decline the 11am slot. For example: "Before I commit, please send the company name, job title and job posting link, and let's do a phone call first."

If Jess gives you a company and role that check out, and you have a real call or the job description, I can run the mock-interview prep pack. I'll need the job description, your CV, and the company name.