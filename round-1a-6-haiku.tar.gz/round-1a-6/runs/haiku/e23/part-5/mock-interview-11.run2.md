Before we prep, I'd hold off on the interview. This message has several hallmarks of a recruitment scam, and I haven't run the prep skill yet because it would be rehearsing for something that may not be real.

**Red flags:**
- Unsolicited contact from an unknown number, with a vague "we found your profile online."
- No calls or video at any stage, including the interview. Legitimate employers almost always use video or phone for interviews.
- An interview set up for tomorrow, with no company name, role title or job posting.
- Remote work with "flexible hours" and no details about pay, employer or responsibilities.

Scams like this often go on to ask for your ID, passport or bank details "for the contract," or ask you to pay for equipment or training, or to receive money and forward it. Please don't share any of those.

**Before you reply with a yes, check:**
1. **Ask Jess for the company's full legal name, the job title, the job advert, and a video call.** A real recruiter will answer all of these. If Jess avoids them or pushes for speed, treat that as the answer.
2. **Check the company independently.** Search for its official website and check whether it lists this role or this recruiter. Look up the company in your country's business registry if it has one.
3. **Check Jess on LinkedIn**, and confirm the company's recruiters appear on the company's own page.
4. **Check the source of the application.** If you applied through a known job board, log in there and look for the application or a message from the employer. Real applications usually show up in your account.

If you've already shared personal details or sent any money, contact your bank now and report it to your national fraud reporting service.

**Once you've verified the role,** send me the job advert and your CV (or paste the text), and I'll run the mock-interview prep. It will then cover likely questions, how to frame your background, and questions to ask the interviewer. I can also draft a reply to Jess asking for those details.