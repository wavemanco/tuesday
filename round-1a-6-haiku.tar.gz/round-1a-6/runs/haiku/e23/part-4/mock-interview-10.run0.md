I'll load the interview-prep skill, then build the pack around your background and the job ad. I also want to flag something about the invitation first.
Here's your prep pack. I haven't searched the web for Lumenvale yet, so it's built only from your message and the job ad summary you gave me. Before you reply to Marcus, though, please read the first section.

## 0. Check Lumenvale before you reply

The invitation has several features that match common recruitment scams. None of them proves this is a scam, but together they're enough to verify before you share anything:

- The whole process runs on Telegram: the interview, the offer, and onboarding.
- You applied through their careers page, but the contact came from a personal messaging app.
- The message is quick to move to offer and onboarding.

Before you name a time:

1. **Find the contact on Lumenvale's official website.** Use the contact details listed there, not the ones in the message. Confirm the Customer Support Specialist listing still exists on their careers page.
2. **Ask for a video or phone call** with the team lead, and for the invitation from a company email address. A real employer will usually agree. Reply with something like: *"Thanks, Marcus. Before I confirm a time, could you send the interview details from a Lumenvale email address and set up a video call? I'd like to meet the team lead on video."*
3. **Never send** bank details, ID or passport scans, tax or national insurance numbers, passwords, or card details. Never pay for equipment or "training", and never accept a payment or check to forward to someone else.
4. **Stop** if you're asked for personal documents before a verified interview, or if you're told to keep the process private.

## 1. Assumptions

Built on: a Telegram-only text interview with the support team lead, the four job-ad requirements you listed, and your CV summary. No full job ad, no web research, and no interviewer profile. The team lead has no name in the invitation.

## 2. Fit snapshot

| Requirement | Your evidence (quoted) | Gap type | Gap-and-bridge language | Confidence |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier" | None | Lead with this | High |
| Zendesk or similar ticketing tool | "I use Freshdesk every day" | Partial: similar tool, not Zendesk | "I haven't used Zendesk, but I use Freshdesk daily for ticket queues and replies" | Medium |
| Clear written communication | "answering around 60 calls and emails a day" | Partial: volume shown, writing quality not shown | Use a written example (see Q5) | Medium |
| Confidence handling escalations | None in your material | Gap: no escalation example quoted | Answer slot: pick a real case where you passed something up or handled a hard refund | Low |
| Software company experience | "I've never worked for a software company." | Gap | "I haven't worked in software, but I've supported customers on a product every day" | High |
| Text chat (no calls) | None | Gap: format | Bridge from email and written work | Medium |

## 3. Prohibited claims (built locally)

Don't say or imply any of these:
- That you've used Zendesk, or know its features
- That you've handled chat support, unless you have
- That you've handled escalations, unless you can describe a real case
- That you know software products or have tech-support experience with software
- That you trained people formally, unless your training role matched what you describe

## 4. Question banks

**Likely from the team lead (process and tools)**

**Q1. Have you used Zendesk or a similar tool?** `[type: tool fluency]`
*Provenance: "I use Freshdesk every day"*
Answer honestly: "I haven't used Zendesk. I use Freshdesk daily, for ticket queues, replies, and status updates. The core workflow is similar, and I'd expect to pick up Zendesk quickly." Don't overstate. Rehearse saying it in one or two sentences.

**Q2. Tell me about a time you escalated a case.** `[type: escalation]`
*Provenance: none. Answer slot.*
Pick a real case where you passed a complaint or refund to a supervisor, or handled a difficult refund decision yourself. Describe what you did and what happened. If you have nothing like this, say so and explain how you'd decide when to escalate.

**Q3. How would you explain a refund decision to a frustrated customer in writing?** `[type: written communication]`
*Provenance: "I trained four new starters on our refunds process last year"*
Structure: acknowledge the problem, state the decision, explain the reason in plain language, and give the next step. Use the refund training to show you can teach process clearly.

**Q4. How do you handle several conversations at once?** `[type: working style, chat format]`
*Provenance: "answering around 60 calls and emails a day"*
Bridge from volume: you already juggle many cases. Say what changes in chat (shorter replies, faster turnaround) and how you'd keep track of several open chats.

**Q5. You're in a text chat, and the customer threatens a chargeback and asks for a manager now. What do you write?** `[type: escalation under pressure, generic scenario]`
*Provenance: none. Generic scenario.*
Acknowledge, stay calm, explain what you can do now, and say what you'll escalate and when. Keep it short.

**Likely from the skeptic (gap-probing)**

**Q6. You've never worked for a software company. Why should we take a chance on you?** `[type: fit objection]`
*Provenance: "I've never worked for a software company."*
Don't apologise. Acknowledge the gap in one sentence, then name the transferable part: years of customer work, a daily ticketing tool, and training others. This is your highest-value objection to rehearse.

**Q7. How did you train the four new starters?** `[type: how much was you]`
*Provenance: "I trained four new starters on our refunds process last year"*
Say what you personally did: whether you designed the material, delivered it, or supported people afterwards. Don't claim more than that.

**Likely from the team lead (remote and chat)**

**Q8. Why do you want to work remotely, in chat, for us?** `[type: motivation]`
*Provenance: none. Answer slot.*
Give a real reason. Keep it to two or three sentences.

## 5. Questions to ask the team lead

- **"What does a typical escalation look like here, and who owns it once it's passed on?"** This tests how their escalation process works.
- **"Which ticketing tool does the team use, and how are chat and email handled in it?"** This tests tool fit.
- **"What does the first week look like for a remote hire?"** This tests onboarding and whether it happens over a verified channel.
- **"How do you judge the quality of a written reply?"** This tests what they value in writing.
- **"How is the support team structured, and who would I report to?"** This tests the team and the reporting line.

## 6. Upgrade menu

- **Full job ad text:** would let me check every requirement, not only the four you listed.
- **Team lead's name, if they give it to you:** would let me add an interviewer read (public background only).
- **Web research on Lumenvale:** would add their published values and support approach. I haven't done this. It's a single-tier search and I can run it if you want.
- **Your tuesday-dossier.md, if you have one:** would sharpen the objection work.

**Offers, not pushed:**
- Want a live rehearsal? I can play the team lead and run Q2 or Q5 with follow-up questions.
- Want me to save this pack as a file or a Word document?

**Questions:**
1. Can you paste the full job ad text, so I can check every requirement?
2. Do you want me to run the web research on Lumenvale before you reply to Marcus?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.