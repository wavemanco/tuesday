# Interview pack: Customer Support Specialist, Lumenvale Software (remote)

Interviewer: support team lead (name not given). Arranged by Marcus Hale, talent team. Format: text chat on Telegram.
Relationship assumed: hiring-manager type, since the lead owns the team. Not yet confirmed. Built with no research (see Sources).

**Process check before you share anything:** the recruiter's message says the interview, offer and onboarding all happen in this Telegram chat. Treat that as a warning sign until verified: confirm the role on Lumenvale's own website, confirm Marcus Hale's name and role on their site or LinkedIn, and ask for the offer to come from a company email address. Never send ID documents, bank details or any payment in a chat. The reverse questions below include this check.

## How to use this pack

- **Personas** = how a question is asked (tone, pressure, format). **Types** = what is being scored.
- Type key: **JD** = matches the job ad's requirements. **EXP** = tests what you actually did in past work. **CASE** = a live problem from the role. **VAL** = values (none detected). **CO** = company knowledge (none researched).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

Requirements are from the job ad as you summarised it; the full ad was not provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | Your line already reaches the requirement in its own terms. Say the three years and the role; the match is the interviewer's to draw. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, and daily use is stated, not inspected. Say Freshdesk and daily use. Do not claim Zendesk experience. |
| F3 | "clear written communication" (job ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write a lot, not how clearly. Answer slot: if you can point to a specific email or reply you are proud of, describe what made it clear; if you cannot, say you have not reviewed your writing against a standard and say what you would check first. |
| F4 | "confidence handling escalations" (job ad) | "trained four new starters on the refunds process last year" (your message) | low | [grounded] | transferability | That line is adjacent work: it covers refunds, not escalations. Say the training in those terms. Answer slot: if you escalated a case yourself, say which and how you decided; if you did not, say so plainly and say what you did handle. |
| F5 | Software-company background (your own note; not in the ad as summarised) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |

Seven rules applied: confidence is one token per cell; the evidence column holds your words only; gap language is spoken aloud and kept to what the quotes carry.

## Prohibited claims

Not to be coached, each with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| Has handled escalations | Inflated form of F4 | The refunds-training line at its own scope. Observation for you: your material does not show escalation handling. |
| Designed or owned the refunds process | Inflated form of F4 | "trained four new starters on the refunds process last year" |
| Resolved most of the 60 a day / has a resolution rate | Figure not in your material beyond volume | "answering around 60 calls and emails a day" |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the escalation requirement and the missing software background | High. The ad names escalations and F4 is thin; F5 is your own stated gap | Rehearse A1 until it is plain. Use the plain acknowledgment in F5, then a plan |
| Case / Strategist | Live tickets: an angry customer, a case beyond your authority | High. A support lead in a chat will test the job with a scenario | Clarify, then act, then say what the customer hears next |
| Data-driven prober | Asks how "60 calls and emails a day" was counted | Medium. A headline number on your CV is a probe magnet | Say what you know about the count; say plainly what you do not |
| Pressure | Short, time-boxed replies; challenges "how much was you" | Medium-low. Text limits interruption but not terse challenge | Hold a position through two follow-ups before conceding |
| Conversational | Opens with "walk me through your journey" | Medium. Casual questions about the ad's topics are still scored | Keep a 90-second arc ready |

Weights: Skeptic 5, Case 4, Prober 3, Pressure 3, Conversational 3. Total 18 questions.

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a case you escalated, or one you decided not to escalate. How did you decide?" | JD | [grounded] "confidence handling escalations" (job ad) | **Highest-ROI prep in this pack.** Answer slot: if you escalated a case, name the case, what you checked first, and what you handed over. If you did not escalate anything, say so plainly, then describe the most difficult case you did handle and how you decided what to do. Hold through two follow-ups by returning to that case, never by adding detail to it | F4 is the gap, and the ad names escalations directly. This objection is near-certain in some form |
| A2 | "You've never worked for a software company. Why would you fit a product support team?" | JD | [grounded] "I've never worked for a software company" (your message) | "I haven't worked for a software company." Then name what carries over from F1, in its own terms, and a plan for learning the product | F5 is your own stated gap; a plain acknowledgment with a plan is the honest answer |
| A3 | "The ad asks for experience with Zendesk or a similar ticketing tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" (your message) | "I use Freshdesk every day." Then say what you do in it, using only what you actually do. If you have used Zendesk, say so; if not, do not imply it | F2 is the requirement's match, and the probe asks for the exact tool |
| A4 | "Where would support work here need to change for someone coming from energy?" | JD | [grounded] "I've never worked for a software company" (your message) | Name one difference you can see from what you know, and how you would check it. No claim about past product work | F5 again, asked as a plan rather than a record |
| A5 | "Why are you leaving energy for this role?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Answer from what you want in a remote support role, in concrete terms. If the reason is simply a move to remote support, say that | F1 gives the context; the motive must be yours, stated plainly |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry that their refund hasn't arrived after two weeks. What is your first reply?" | CASE | [generic] | Clarify (what was paid, when, which method), acknowledge once, check the case history, say what you will do and when they will hear back | A live problem from the role; no claim about your past, so no quote needed |
| B2 | "A ticket is beyond what you can resolve. What do you do in the next hour?" | CASE | [generic] | Check policy, escalate with full context so nobody re-asks, tell the customer what happens next and when | Targets the escalation requirement in F4; keep the answer to the steps, not to past cases |
| B3 | "Write me two lines to a customer who has waited a week." | CASE | [generic] | Write it live. Short, direct, one apology, a clear next step with a time | Tests the written-communication requirement in F3 under time pressure |
| B4 | "You'd be set up in a tool you haven't used. How would you learn it in your first week?" | JD | [grounded] "I use Freshdesk every day" (your message) | Start from Freshdesk daily use: describe how you learned it, then how you would apply that method to a new tool | F2 is the ground; the answer is a method, not a claim of Zendesk |

### C. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handle around 60 calls and emails a day. How was that counted, and what is in it?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you know how the figure was counted, say how in your own words; if you do not, say so plainly. Name the assumption behind the figure you would defend least, before they ask | F3 rests on this number; a figure you cannot explain under a second question is worse than none |
| C2 | "Of those contacts, what share were emails, and how did you handle the written side?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the split if you know it. If you do not, say so. Describe the written side only as far as you actually did it | Tests F3's written-communication evidence without adding a figure |
| C3 | "Walk me through how you trained four new starters on the refunds process." | EXP | [grounded] "trained four new starters on the refunds process last year" (your message) | Tell the beats the sentence states: what you taught, to four people, last year. Say nothing about outcomes you do not have | F4 is adjacent work; this question tests whether the training was really yours |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take someone from energy over someone who knows our product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Pause, restate the question in your head, then hold: your three years of customer service is the job; product knowledge can be learned. Hold through two follow-ups before conceding anything | Tests composure on the F5 gap |
| D2 | "That 60-a-day figure: how much of it was actually you, rather than the queue?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you can say which part of the volume was yours to decide, say it; if the queue set the volume, say so. Hold the position you can back, and concede a limit only where it is true | Pressure on C1's number; the honest answer is the one you can defend under a follow-up |
| D3 | "You say you use Freshdesk. Show me you know it, not just that you've logged in." | JD | [grounded] "I use Freshdesk every day" (your message) | Name one thing you do in Freshdesk. If you cannot name a feature, concede the limit plainly and say what you would learn first | F2's stated use, tested for depth |

### E. Conversational / rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "trained four new starters on the refunds process last year" (your message) | A 90-second arc: energy advisor for three years, the daily volume, Freshdesk daily, training new starters on refunds. Keep to what the sentences say | F1 and F4 are the arc's beats; the arc is a rehearsal of your own sentences |
| E2 | "What do you enjoy most about support work?" | JD | [generic] | One honest sentence, from what you actually find rewarding. No claim needed | Casual but scored; a generic answer reads as unrehearsed |
| E3 | "How do you keep a customer calm when all you have is their words?" | JD | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: name a writing habit you use if you have one; if not, name one you would adopt and why | Links to F3's written communication without claiming a skill you have not shown |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in customer support (F1) | E1, A5 |
| Zendesk or similar ticketing tool (F2) | A3, B4, D3 |
| Clear written communication (F3) | B3, C1, C2, E3 |
| Confidence handling escalations (F4) | A1, B2, C3 |
| Software-company background, not in the ad as summarised (F5) | A2, A4, D1 |

## Reverse questions

1. **"Is the offer and onboarding handled in this chat, or does the offer come from a company email address?"** Why it lands: it verifies the process, and a clear answer either way tells you something.
2. **"Which ticketing tool does the team use today, and how do escalations reach engineering?"** Why it lands: it ties your next question to the escalation requirement, and shows you read the ad.
3. **"Who would I work alongside day to day, and how big is the team?"** Why it lands: it asks for the team's shape, which a support lead can answer.
4. **"What does the first thirty days look like, and what does product training involve?"** Why it lands: it turns the F5 gap into a plan question.
5. **"How does this team measure a good support week?"** Why it lands: it shows you think about outcomes, and gives you their real metric.

No interviewer profile was provided, so no reverse question ties to the interviewer's path.

## Interviewer read

Skipped: no interviewer name or profile was given.

## Delivery coaching

Skipped: no working-style assessment was provided.

## Sources

- Provided documents: your message (the Telegram invitation, your CV summary, the job ad as you summarised it).
- Web search, two calls, both refused by the host (permission not granted): "Lumenvale Software company"; "Lumenvale Software recruitment scam Telegram interview". No results returned, so nothing about the company is established.

**Research tier:** L0, searches 0 of 0, fetches 0 of 0 (two attempted, both refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Values cheat sheet, not produced; search refused |
| 2. `Lumenvale Software interview process customer support` | unavailable | Loop structure and persona weights; search refused |
| 3. `Lumenvale Software strategy` / recent news | skipped | Not needed for a support screen; fit snapshot and banks are built from your inputs |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name given |
| 5. representative `Customer Support Specialist` JD | unavailable | Would have checked requirements beyond your summary; search refused |

## Upgrade menu

- The support team lead's name → a tailored reverse question and persona weights from their public footprint
- The full job ad text → requirement rows become `[grounded]` in full, and any missing requirement gets a question
- Confirmation that the team lead is your future manager or a peer → persona weights reweighted
- Web search permission → company values, interview process and recent news; the process check can be run against Lumenvale's own site
