# Lumenvale Software: Customer Support Specialist (remote), interview prep pack

**Round:** text chat on Telegram with the support team lead (name not given). Arranged by Marcus Hale, talent team.
**Relationship:** team lead, so hiring-manager type. Weights below follow that prior.
**Version:** first version.

## Before you share anything

Telegram-only recruiting, with the offer and onboarding in the same chat, is a known scam pattern. Web search was refused, so I could not verify Lumenvale Software or Marcus Hale. Check the role on Lumenvale's official site, confirm your application through your careers-page account or email, and verify the recruiter through a contact route from the company's site. Never send ID or bank details in chat before a verified offer.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (job requirement), EXP (experience deep-dive), CASE (live problem), VAL (values; not used here), CO (company knowledge; not used, since no research ran).
- Guidance is scaffolding, not a script. In a text chat your typed reply is the scored artifact, so keep each answer to a few short paragraphs.

## Fit snapshot

Requirements are quoted from your summary of the ad. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (JD, as summarised in your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Your material shows the years and the role. Say it in those words: "For three years I was a customer service advisor at an energy supplier." It is self-reported with no proof attached, so expect a probe on what the day-to-day involved. |
| F2 | "experience with Zendesk or a similar ticketing tool" (JD, as summarised in your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: Freshdesk is a ticketing tool, and the ad accepts "a similar ticketing tool". Say it in your words: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where and for what. If you have not, say so plainly and say how you would get up to speed. |
| F3 | "clear written communication" (JD, as summarised in your message) | "around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is not clarity. The material shows you wrote a lot, not that your writing was clear. Answer slot: name one written reply that had to be right first time and what made it clear. If none stands out, say so, and say how you check your writing before sending. This chat is itself a written test, so every reply here is evidence. |
| F4 | "confidence handling escalations" (JD, as summarised in your message) | none given | none | [grounded] | discovery | Your material does not show escalations at all. Answer slot: if you handled escalations, say which and what you did with them. If none came to you, or they were not yours to handle, say so plainly, then describe how you would take an escalation from an unhappy customer. |
| F5 | Not in the ad: software-company experience (your concern, not a requirement) | "I've never worked for a software company" (your message) | none | [grounded] | capability | It is not a requirement, so it is not a gap in the ad, but expect it as a probe. Words: "I haven't worked for a software company." Then a plan, not a past: say what you expect to be slowest in the first month and how you would close it. Never claim software experience. |
| F6 | Not in the ad: process training (your evidence) | "I trained four new starters on our refunds process last year" (your message) | medium | [grounded] | none | Relevant to support work and to the Case and Conversational answers. Say it in your words, without adding a result you did not see. |

Gap type follows the routing in `output-template.md`: F2 is `presentation` because its quote already reaches the requirement in other terms; F3 and F4 are `discovery` because the material is silent or thin; F5 is `capability` because you stated the absence.

## Prohibited claims

Not coached in any answer, reverse question or drill feedback in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The pack's observation: your material names Freshdesk, not Zendesk. |
| Designed or set the refunds process | Inflated form of F6 | F6's quote at its own scope: you trained others on the process. The pack's observation: your material says you trained on it, not that you set it. |
| Worked for a software company | Negative you stated (F5) | "I haven't worked for a software company." No answer slot. |

## Persona weights

| Persona | How it shows up in this chat | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: Zendesk, escalations, software background | Top weight (5). A team lead buys capability and checks gaps; F2, F4 and F5 are the gaps | Rehearse the single most predictable objection (A2) until it is plain. Hold the limit, then give a plan |
| Case / Strategist | Live support problems from the role | 4. Hiring-manager prior, and a support role is mostly case-shaped | Clarify, then structure, then steps. Say the steps in order |
| Data-Driven Prober | Asks how the 60-a-day figure was counted | 3. F3's figure is the only number in your material | Say what the count was, and what you would defend least |
| Pressure | Short, timed challenges in text | 2. Chat removes tone but not time | Hold the core claim through two follow-ups, then concede the specific limit |
| Conversational | Chatty opener | 2. Still scored | A 90-second arc, in order |
| Peer Evaluator | Seams with product, disagreement with product | 2. Peer-style probes come from the team around the lead | Name what you would need, and make the disagreement case in writing |

No interviewer profile was given, so there is no interviewer read. No values round was detected, so there is no values cheat sheet.

## Question banks

Question IDs are letter-by-persona so drills and coaching can refer to them.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see Zendesk in your background. How would you handle that in this role?" | JD | [grounded] "I use Freshdesk every day" (your message) | Lead with the Freshdesk line in those words, then how you use it day to day. Answer slot: if you have used Zendesk, say where and for what. If you have not, say so plainly and say how you would get up to speed in your first week. Hold through two follow-ups by returning to Freshdesk, never by adding Zendesk. | The ad names Zendesk, so this is the likeliest probe on F2. |
| A2 | "You've never worked for a software company. What would slow you down most in your first month?" | EXP | [grounded] "I've never worked for a software company" (your message) | **Highest-ROI prep in this pack.** It is the objection you raised yourself. Hold: "I haven't worked for a software company." Then name the one thing you expect to be slowest and how you would close it, as a plan. Hold through two follow-ups. Never claim software experience and never make the gap sound smaller than it is. | F5 is the stated gap, and the question takes your own negative as its premise. This is where the material is thinnest, so the honest answer is the one to rehearse. |
| A3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Open prompt. Answer slot: if one came to you, tell it in order: what the customer needed, what you did, where it ended. If none came to you, or it was not yours to handle, say so plainly, then describe how you would take one now. | F4 is the gap. The theme comes from the ad's escalation line, so the question is fair. |
| A4 | "How do you know a written reply is clear before you send it?" | JD | [inferred] derived from F3 | Describe the check you actually use, in your own words. Answer slot: if you have a check you rely on, name it. If you rely on a colleague or a template, say so. | F3 is thin: your material shows volume, not clarity, and this chat is a written test. |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | Name the part you expect to be weakest, drawing on the F5 limit, and give the plan for it. Do not pick a fake weakness that is really a strength. | The Skeptic's standard stem, asked as a day-one question, so answer with the plan rather than the past. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says they were charged twice for their subscription and the second charge has been there ten days. Walk me through your first three replies." | CASE | [grounded] "I trained four new starters on our refunds process last year" (your message) | Structure before answering: clarify (account, both charges, dates), then say what you can check and what you cannot, then the refund or escalation route. If the steps you would take follow the refunds process you trained others on, say so and name the step. Describe steps, not outcomes. | The role's core live problem, a refund-type case. F6 is the one process you can say you have taught, so the link to your own material is honest. |
| B2 | "A new user writes that the product 'does nothing' and asks whether to cancel. What do you ask first?" | CASE | [generic] | Clarify before diagnosing: what they expected, what they tried, what they see now, and when it started. Then say what you would check and what you would send back. One clause per step. | Tests structure in a chat. Generic, because no line of your material bears on it. |
| B3 | "You have forty open tickets and two of them are escalations. How do you sort them?" | CASE | [generic] | Sort by customer impact and clock first: which are closest to a missed reply, which are blocked. Say what you would do with the rest and what you would tell customers you have not reached yet. | The ad's escalation line and your daily volume (F3) both make prioritisation a likely question. |
| B4 | "What would go in an escalation note so the engineering team does not come back to you with questions?" | CASE | [generic] | List what a reader needs without you: steps to reproduce, account and time, what the customer was told, what you have already ruled out. Say it as a checklist you would use. | The ad's escalation line as a live problem. It presupposes nothing about your past. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your message says around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "around 60 calls and emails a day" (your message) | Defend the number. Answer slot: say what record it came from, over what period, and which part of the count you would defend least. If you did not count it, say so, and say what it is an estimate of. | F3's figure is the only number in your material, so a prober will ask how it was counted. |
| C2 | "You trained four new starters on refunds. What did you measure to know they were ready?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you measured readiness, say what and how. If you judged it by watching them work, say that. Hold to the training you gave, not to any result you did not see. | The question presupposes a measure the quote does not carry, so the second branch must allow that none existed. |
| C3 | "Freshdesk and Zendesk handle things differently. What differences matter for support work?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer from Freshdesk, which you use daily, and name the differences you would check on Zendesk. If you do not know the differences, say so and say how you would learn them. | A follow-on to A1 that asks for a comparison you may not be able to make, so the honest branch is ready. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "One reason to hire you over someone who has worked in software support." | EXP | [grounded] "I've never worked for a software company" (your message); "I use Freshdesk every day" (your message); "I trained four new starters on our refunds process last year" (your message) | Hold: name the strongest thing you bring from support, then concede the software gap specifically: "I haven't worked for a software company." Do not fold on the support base. | Tests whether you hold a position without going defensive. The position is one your quotes carry: support work and training, not software skills. |
| D2 | "What is the weakest part of your application, in one sentence?" | EXP | [grounded] "I've never worked for a software company" (your message) | Pause, then answer in one sentence: the software gap, stated as a fact. Hold through two follow-ups with the same sentence, and concede a specific limit, not a general one. | A short, timed answer. Hold, then concede. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "around 60 calls and emails a day" (your message); "I use Freshdesk every day" (your message); "I trained four new starters on our refunds process last year" (your message) | A 90-second arc, in order: the energy supplier role and its volume, daily Freshdesk use, the refunds training, then why support at a software company now, in your own words. The why-now is yours to supply; the pack does not supply it. | A rapport opener in a chat, and still scored. |
| E2 | "What drew you to this role?" | JD | [generic] | Tie the answer to the ad's own words, clear written communication and handling escalations, and say what you want to do with them. Keep it under a minute. | Casual-register question on a scored topic. Generic, because no line of your material answers it. |
| E3 | "Tell me one thing about yourself that is not on your CV." | EXP | [generic] | Pick one short, true, non-private thing that bears on support work. Do not share anything you would not want a recruiter to repeat. | A rapport question that still scores communication economy. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Support and product often disagree about whether a ticket is a bug. What do you do when you think it is one and product says user error?" | CASE | [generic] | Reproduce it first, attach the evidence to the ticket, and send it through the route the team uses. Respect their call on the product and still make your case in writing. | Tests disagreement with equals. Generic. |
| F2 | "What would you need from the support lead in your first month to do the job well?" | JD | [generic] | Name concrete things: tool access, the escalation path, a regular feedback point. Keep it specific. | A reciprocity question. A clear ask shows you have thought past the offer. |

## Requirement coverage

| Requirement (from your summary) | Question IDs |
|---|---|
| 2+ years in customer support | E1, C1 |
| Experience with Zendesk or a similar ticketing tool | A1, C3 |
| Clear written communication | A4, B4 |
| Confidence handling escalations | A3, B3, B4 |

Total: 18 questions.

## Reverse questions

No interviewer profile exists, so none is tied to the team lead's career path.

1. "What happens to an escalation after it leaves support: who owns it, and how long does it usually take?" Why it lands: it shows you think past the queue, and it ties to B4.
2. "Which tools does the team use alongside the ticketing system day to day?" Why it lands: it tests the Zendesk question directly and shows product curiosity.
3. "What does a good first 90 days look like in this role?" Why it lands: it asks about outcomes, not just duties.
4. "Who would I work with most in my first month?" Why it lands: it asks about peer context, which the Peer persona scores.
5. "Is the written chat format how the team talks with customers day to day?" Why it lands: it shows you noticed the format, and it links to clear written communication.
6. "What would make someone in this role succeed quickly?" Why it lands: it invites the team lead to state the bar.

## Sources

- **Provided documents:** your message (the ad as you summarised it, your background, and Marcus Hale's Telegram message). No dossier was consumed.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. Three searches were refused by permission.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet not produced. Query sent, refused: "Lumenvale Software values careers customer support" |
| 2. Lumenvale Software interview process, customer support | unavailable | Loop structure not established, so persona weights rest on the round-type prior. No query sent. |
| 3. Lumenvale strategy and recent news | unavailable | Grounding brief not produced. No query sent. |
| 4. Interviewer name and company | n/a | No interviewer name was given. Marcus Hale is the recruiter, not the team lead. |
| 5. Representative customer support JD | skipped | Your ad summary fixes the fit snapshot and the JD-tagged questions. |

Un-numbered searches: "Lumenvale Software company", refused, meant to verify the company exists. "\"Marcus Hale\" Lumenvale talent", refused, meant to verify the recruiter.

## Upgrade menu

- The full ad text → the four requirements become verbatim quotes from the ad, not from your summary.
- Permission to run web search, or the company's values page pasted → a values cheat sheet, a grounding brief, and the company check above.
- The team lead's name → persona weights from their public footprint, and a tailored reverse question.
- Any Zendesk use, or any escalation you handled in any role → F2, F4 and A1 move from answer slots to stories, provided you tell me in your own words.
- A `tuesday-dossier.md` from job-underwriter → verified evidence and prohibited claims in place of the local list above.
