# Lumenvale Software: Customer Support Specialist interview pack

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** Support team lead (name not given). Recruiter contact: Marcus Hale, talent team.
**Format:** Text-only interview in a Telegram chat. Offer and onboarding are also said to run in the chat.
**Built on:** your message and your background summary. No full job ad, no CV text, no web research (search was refused).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the ad's requirements), EXP (your own experience), CASE (a live problem), and VAL (values; none found, so none listed).
- Guidance is scaffolding, not a script. Say it in your own words.
- Because the interview is text, your written replies are the thing being scored. Write each answer as you would send it to a customer.

## Verify before you share anything

This is a sensitive point. A Telegram-only process where the offer and onboarding also happen in chat matches a common pattern in job scams. Before you share any personal or financial details:

1. Find the Customer Support Specialist posting on Lumenvale's own careers page, and confirm it matches the one you applied to.
2. Confirm that Marcus Hale works at Lumenvale through a company email or a LinkedIn profile linked from the company site. Don't rely on the Telegram profile.
3. Ask for a video call or a company-domain email for the interview, and ask who the team lead is.
4. Never send ID documents, bank details, or payment for equipment, training or "onboarding" in this chat.

## Fit snapshot

Requirements are your summary of the ad, not the ad's exact wording. Gap types follow the routing rule in the skill's output template.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your material shows three years in customer service, not the word "support". Say the role in those terms: "three years as a customer service advisor." Don't stretch it to other roles. |
| F2 | Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is the same category of tool. Say it plainly: "I use Freshdesk every day." Don't claim Zendesk experience. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write often, not how well. Answer slot: if you can recall a written reply you're proud of, describe what you wrote and why it worked, in your own words. If you can't, say what you would do to check your writing. |
| F4 | Confidence handling escalations (your summary of the ad) | "trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training others is adjacent, not escalation. Answer slot: if you handled a case beyond your own level, say what it was and what you did. If you didn't, say so and describe how you'd escalate. |
| F5 | Software-product background (implied by a software company; not in your summary of the ad) | "I've never worked for a software company." (your message) | none | [grounded] | transferability | Your stated negative. Plain acknowledgment: "I haven't worked for a software company." Then the adjacent work: "I use Freshdesk every day." |
| F6 | Right to work and location for a remote role (gate) | Your material does not establish this. | none | [grounded] | hard_gate | Surface it, don't bridge it. Confirm with the recruiter that the role's location and work-authorisation terms suit you before going further. |

**Confidence and gap types in one line:** F1 and F2 have a real quote behind them. F3 and F4 are thin. F5 is a stated negative with a clear bridge. F6 is a gate the material doesn't settle.

## Prohibited claims

Things this pack will not coach, and why each is off limits.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Contradicts F2 (you said Freshdesk) | "I use Freshdesk every day", plus a plan to learn Zendesk |
| Owned or designed the refunds process | Stretches "trained four new starters on our refunds process" (F4) | "I trained four new starters on our refunds process." Say what you taught, and nothing about who set the process |
| Handled escalations | Not in any sentence you gave me | The F4 answer slot. Say only what you actually did |
| Exact figure beyond "around 60" | Your message says "around" | Keep "around 60 calls and emails a day" and say how you'd count it if asked |
| Software company experience | Stated negative (F5) | "I haven't worked for a software company." |

## Persona weights

Relationship prior: a team lead in a hiring round. This maps to Skeptic and Case/Strategist, with a Pressure check and a light conversational opener. There is no interviewer profile, so no interviewer-based adjustments.

| Persona | Weight | How it shows up | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Top (5) | "You've never worked for software; why you?" | Team leads often start with the gaps | Plain acknowledgment, then the quotes, then a concrete ramp plan |
| Case / Strategist | 3 | A live ticket to answer in writing | The chat is a writing test | Acknowledge, own the next step, give a time you can keep |
| Pressure | 2 | Short replies demanded, "one risk" questions | Tests composure over text | Restate, hold on your quotes, concede one specific thing |
| Conversational | 2 | Warm opener about your background | Looks casual, still scored | Use a 90-second arc built from your quotes |
| Data-Driven Prober | Folded into Skeptic (A4) | "How was the 60 counted?" | Your one number | Name the part you'd defend least; say if you don't know |

## Question banks

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ad asks for Zendesk or a similar tool. You use Freshdesk. How do you get productive in a tool you haven't used?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say that Freshdesk is the tool you use every day. Then a plan for learning Zendesk: what you'd do in week one. Answer slot: if you know a Freshdesk feature you use daily, name it. If you don't, say you'd learn the ticketing setup first. | F2: the closest tool you have. The question is a live probe of the Zendesk line. |
| A2 | "You've never worked for a software company. Why would this be different?" | JD | [grounded] "I've never worked for a software company." (your message); "I use Freshdesk every day." (your message) | Plain acknowledgment first: "I haven't worked for a software company." Then: "I use Freshdesk every day, and I've handled customer contacts for three years." Hold through two follow-ups by returning to what you did. Concede one specific gap: "I don't know your product yet. I'd learn it by..." | F5: the most likely objection. Rehearse until it's boring. |
| A3 | "When a customer's problem needed to go beyond your level, what did you do?" | EXP | [inferred] Your summary of the ad asks for confidence with escalations; no sentence of yours describes an escalation | Open prompt. Pick one real time you passed a case up or handled a hard one. Name the steps. If you can't think of one, say so plainly, then describe how you'd escalate. | F4: no quote carries an escalation. The question is open and asks you to pick. |
| A4 | "Around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Use "around". Say which part of the figure you'd defend least, in your own words. If you don't know how it was counted, say so. | F3: your one figure. Probers test it first. |
| A5 | "Why leave energy customer service for a software support team?" | EXP | [generic] Persona stem: "why leave, why here, why now" | Give a motivation in your own words. Don't claim a reason you can't stand behind. | Skeptic stem. It's a motivation probe, asked as a stem, not a claim about your past. |
| A6 | "The ad asks for clear written communication. Describe the last written reply you'd be proud of." | JD | [inferred] Your summary of the ad asks for clear written communication; no sentence of yours names a specific written reply | Open prompt. Pick a reply you wrote or would write. Describe the customer, what you said, and why it worked. | F3: the interview is itself a writing test. A specific example beats an adjective. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry that a refund is three weeks late and says they'll complain publicly. Reply to them here, then tell me what you'd check internally." | CASE | [generic] | Structure: acknowledge the delay plainly, state what you'll do next, give a time you can keep, then list what you'd check. Keep the reply to a short paragraph. | Live written problem, typical of support. The reply is the score. |
| B2 | "A ticket needs a decision you're not allowed to make. Who do you escalate to, and what do you tell the customer while they wait?" | CASE | [generic] | Name the escalation step, then the customer update: what you know, what you don't, and when they'll hear next. | Live problem on escalation. It asks about a process, not your past. |
| B3 | "What would you do in your first thirty days to learn our product well enough to answer tickets?" | CASE | [generic] | A plan in the future tense: product docs, shadowing, a set of questions for the team lead. Don't claim prior product knowledge. | F5 bridge as a plan. This is a plan, not a past. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two sentences. Why should we hire you over someone with software experience?" | JD | [grounded] "I use Freshdesk every day." (your message); "answering around 60 calls and emails a day" (your message) | Hold on the two quotes. Concede one specific thing: "They'd know your product faster. I'd close that gap by..." Don't argue that software experience doesn't matter. | F5 under time pressure. Hold on the facts; concede the gap. |
| C2 | "That refund process you trained people on. How much of it did you design?" | EXP | [grounded] "I trained four new starters on our refunds process last year." (your message) | Answer slot: if you designed any part, say which part and how you decided, in your own words. If you didn't, say so plainly, then describe what you taught. | Premised on design, which no sentence of yours states. The second branch must allow that you didn't design it. |
| C3 | "Your last answer was long. Give me the one thing that would make you a risk in this role." | JD | [inferred] Your summary of the ad: escalations and tool-use requirements; no sentence of yours states a risk | Name one real gap, specifically: a tool you haven't used (Zendesk) or the software context (F5). Say what you'd do about it. Don't add a second. | Pressure probe. A specific concession held calmly is stronger than a list. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey into customer support." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message); "I trained four new starters on our refunds process last year." (your message) | Build a 90-second arc from those three sentences, in your own words, in that order. | Opener. Casual, but scored. |
| D2 | "How is the support team organised?" | JD | [generic] | Keep it short and curious. Ask about the answer in one follow-up. | A rapport question, but it tests your interest in the team. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | D1, F1 (no dedicated question; covered by the arc) |
| Zendesk or a similar tool | A1, A2 |
| Clear written communication | A6, B1, C1 |
| Confidence handling escalations | A3, B2 |

## Reverse questions

Each one has a "why it lands."

1. "What happens when a ticket needs a decision above the support team?" Why it lands: it shows you think about handoffs, which matters for escalations.
2. "What does a new Customer Support Specialist need to know in the first month?" Why it lands: it shows you're planning for the ramp (A1, B3).
3. "How do you judge a good written reply here?" Why it lands: it points at the medium the chat is testing.
4. "Which ticketing tool does the team use, and how is it set up?" Why it lands: it connects your Freshdesk experience to the stack (A1).
5. "What are the next steps after this chat, and which company email will the offer come from?" Why it lands: it's a fair question for the team lead, and it helps you verify the process (see "Verify before you share anything").

## Sources

- Provided documents: your message, the recruiter message as you quoted it, your background summary.
- Search results: none. Two company searches were refused because WebSearch permission wasn't granted.

**Research tier:** L0 (documents only)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Values section dropped. Search was refused. |
| 2. `Lumenvale Software interview process customer support` | unavailable | Loop structure unknown. Search was refused. |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Could have added company-context questions to the Conversational bank. Search was refused. |
| 4. `{interviewer name} Lumenvale` | n/a | No interviewer name given. Only the recruiter's name. |
| 5. representative `Customer Support Specialist` JD | unavailable | Your summary stands in for the ad. Search was refused. |

Queries sent, both refused: `Lumenvale Software careers customer support specialist`; `Lumenvale Software company`.

## Upgrade menu

- The full job ad, pasted word for word → turns the JD rows into exact quotes and tightens A1, A3, C3
- The team lead's name → a tailored reverse question and interviewer-based persona weights
- A short note from the recruiter about the interview's focus areas → coverage of anything they name
- Search access, so the company, the recruiter and the role can be checked → verification of Lumenvale's posting and contacts
