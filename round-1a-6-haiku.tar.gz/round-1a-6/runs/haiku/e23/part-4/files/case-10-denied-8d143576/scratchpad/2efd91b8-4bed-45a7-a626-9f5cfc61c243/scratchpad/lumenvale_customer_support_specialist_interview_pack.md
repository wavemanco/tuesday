# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Format:** written interview in a Telegram chat with the support team lead. Recruiter contact: Marcus Hale (talent team).
**Interviewer:** support team lead (name and relationship not yet known).
**Built from:** your message and the job-ad requirements you summarised. No web research was run (tier L0).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (can you do the listed job), EXP (what you actually did), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Speak it in your own words.
- In a chat interview, your written answer is the test. Aim for short, complete messages: the answer first, then one supporting detail.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap. Say it in your terms: "I have three years as a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | transferability | Freshdesk is the adjacent tool, and the bridge should not stretch past it. Words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how. If you have not, say so, and say how you would learn it, as a plan. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | presentation | The quote shows volume, not quality. Words: "I answer around 60 calls and emails a day." This interview is written, so the quality is being judged in front of them. Let your replies carry the evidence. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | The material shows refunds training, not escalation handling. Answer slot: if you have handled escalations, pick one and say what you did, in your own words. If you have not handled one as an escalation, say so plainly and describe the nearest thing you do carry: the refunds process. |
| F5 | Software-company experience (your own concern, not in the ad) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked for a software company." Then what carries over, from your own quotes: the daily ticketing tool and the call and email volume. |

## Prohibited claims

Not coached in this pack, with the basis for each:

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| Handling escalations | Inflated form of F4 | "I trained four new starters on our refunds process last year." The material shows refunds training, not escalation ownership. |
| Software-company experience | Sourced negative (F5, your words) | "I haven't worked for a software company." No slot. |
| Formal praise or assessed quality of your written work | Inflated form of F3 | "I answer around 60 calls and emails a day." Quality is for them to judge. |
| Leading or running a training programme | Inflated form of "trained four new starters" | "I trained four new starters on our refunds process last year." Trained, not programme owner. |

## Persona weights

No interviewer profile was given. Weights follow the relationship prior for a hiring manager (a team lead), adjusted for the written format.

| Persona | How it shows up in chat | Likelihood | Depth | Counter-strategy |
|---|---|---|---|---|
| Skeptic | The gaps are obvious: no Zendesk, no software company | High | 5 | Rehearse the software question until it is calm. Concede the gap plainly, then return to what you have. |
| Case / Strategist | Written scenarios about a customer or a ticket | Medium | 3 | Clarify first, then give the steps, then the next update you would send. |
| Conversational | A friendly opener: "walk me through your background" | Medium | 3 | Prepare a 90-second background that stops where it should. |
| Data-Driven Prober | Follow-ups on the 60-a-day figure | Medium | 2 | Say what you know about how the figure was counted, and say plainly when you do not know. |
| Pressure | Terse follow-ups, a challenge on a claim | Low | 2 | Hold the position through two follow-ups before conceding anything real. |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ad asks for Zendesk or a similar ticketing tool. What's your experience with those?" | JD | [grounded] "I use Freshdesk every day" (your message) | Lead with the quote: "I use Freshdesk every day." Name the parts of Freshdesk you use, in your own words. Then say you have not used Zendesk, and describe how you would learn it, as a plan. Answer slot: if you have used Zendesk, say where and how. | F2 is the likeliest objection in the ad. Premise is the ad's own line. |
| A2 | "Why should we take a chance on someone with no software background?" **Highest-ROI prep.** | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "I use Freshdesk every day" (your message); [grounded] "answering around 60 calls and emails a day" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then the carry-over, in your words: you use a ticketing tool daily and handle around 60 calls and emails a day. Hold through two follow-ups by returning to the tool and the volume. Do not add a claim about software you have not made. | F5 is the most predictable objection. A calm, specific answer changes the interview. |
| A3 | "Your ad mentions escalations. Tell me about the hardest one you've handled." | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot. If you have handled escalations, pick one and say what you did, in your own words. If you have not handled one as an escalation, say so, then describe the refunds process you trained others on. | F4 is the thinnest area. The honest branch is an answer, not a confession. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that their refund hasn't arrived after two weeks. What do you do first?" | CASE | [generic] | Clarify: order reference, refund route, payment status. Then acknowledge, check the process, give a next update time. Say when you would escalate and to whom. | Tests the escalation requirement as a live problem. Presupposes nothing about your past. |
| B2 | "A ticket turns out to be a bug, not a support question. How do you pass it to engineers?" | CASE | [generic] | Reproduce steps, what the customer saw, the customer impact, and one written handover message that stands alone. | Tests written clarity and escalation judgment together. |
| B3 | "In three sentences, reply to a customer still waiting on a refund." | CASE | [generic] | Short and complete: what you know, what you are doing, when they will hear next. No filler apologies. | The format is the test. Every sentence should be one the customer can act on. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "answering around 60 calls and emails a day" (your message); [grounded] "I use Freshdesk every day" (your message) | A 90-second arc: role, volume, tool, refunds training. Stop there, and ask whether they want more detail. Do not add what you have not told me. | F1 and F2 are your strongest stated facts, and they open the interview. |
| C2 | "What's the most useful thing you've taught someone?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say what you trained on and how you did it, in your own words. Answer slot: if you can say how the starters did afterwards, say it; if you do not know, say so. | An open prompt. It rewards the specific, honest answer. |
| C3 | "What have you looked at in our support documentation so far?" | CO | [generic] | Answer only with what you have actually read. If you have read nothing yet, say so and say what you would read first. | Tests whether the homework is real. No research was run for this pack. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How much was calls versus emails, and how did you count?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number in your own words. Answer slot: if you know the split and how it was counted, say so; if you do not know how it was counted, say that. Name the assumption you would defend least. | A figure you gave raises this probe. The pack does not supply a method. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In one message: why should we hire you over someone who has used Zendesk?" | JD | [grounded] "I use Freshdesk every day" (your message) | Hold: you use a ticketing tool every day. Concede: you have not used Zendesk. Give a learning plan as a plan. Hold through two follow-ups before conceding anything more. | A hold-then-concede shape, not a fold on the core claim. |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| 2+ years in customer support | C1 | Stated in your background arc |
| Zendesk or a similar ticketing tool | A1, E1 | Freshdesk is the bridge |
| Clear written communication | B2, B3, D1 | Written format |
| Confidence handling escalations | A3, B1 | Answer slot on A3 |
| Software background (not in ad) | A2 | Your own concern, rehearsed |

## Reverse questions

Each has a reason it lands. None is generic.

1. "What does a new support specialist handle in their first month?" Shows you are planning the job, not just applying for it.
2. "How do escalations move from the support team to engineering?" Ties directly to the ad's escalation requirement.
3. "What does a strong written reply look like on your team?" Asks about the standard they score in a written interview.
4. "Which ticketing tool do you use, and is training on it provided?" Shows you have read the ad's tool line.
5. "Which steps of hiring and onboarding happen outside this chat?" Asks a verification question, and it is also a fair one to ask about a Telegram-only process.

## Verifying the offer before you share anything

This hiring process runs entirely on Telegram, including the offer and onboarding. That pattern is also used by job scams, so verify it independently before replying with personal details:

- Confirm the job posting on Lumenvale's official careers page, and check the company's official website for the domain. Do not use links sent in the chat.
- Confirm that Marcus Hale works at Lumenvale through the company's own website or a verified professional profile, not through the Telegram account alone.
- Do not send bank details, a passport or ID, a national insurance or tax number, or any payment (for equipment, training, or a "processing fee") in chat until the offer is verified outside it.
- Be wary of an offer that comes quickly, asks for money, or asks you to move off the platform. Ask for a written offer on company letterhead sent from a company email address.

## Sources

- Provided documents: your message (interview invitation text and your background), and the job-ad requirements as you summarised them.
- Research tier: L0. No searches or page fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Not run at L0. |
| 2. Lumenvale interview process | unavailable | Loop structure. Not run at L0. |
| 3. Lumenvale strategy / news | unavailable | CO questions. Not run at L0. |
| 4. Team lead's name and footprint | n/a | No name given |
| 5. Representative job description | skipped | Your job-ad summary fixes the requirements in the fit snapshot |

## Upgrade menu

- Full job-ad text → turns the summarised requirements into exact quotes and checks for any requirement not yet covered.
- The team lead's name → a tailored reverse question and persona weights from their public professional footprint.
- Whether the team lead is your future manager or a peer → reweights the persona table.
- Any exercise, focus area or timed test Marcus mentioned → covers any graded deliverable.
- Lumenvale's published values or support model (needs a research consent) → a values cheat sheet and company-knowledge questions.
- Any Zendesk use you have had → upgrades A1 and E1 from a plan to a stated experience.
