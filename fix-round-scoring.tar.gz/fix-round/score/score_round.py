"""Score the fix round against the bar fixed before the run (docs/fix-round-plan-detail.md section 4).

Reads the nine compare_arms outputs (score/compare-<model>-part-<n>.txt, made by the worktree's
evals/compare_arms.py at b8702ac), the routing results files (<model>/e*.json) and the quality runs'
meta files, and prints every gated item, its figures and its verdict, then the reported items the
script can read. Writes score/scorecard.json beside this file.
"""
import glob
import json
import math
import re
import sys
from pathlib import Path

R = Path(__file__).resolve().parent.parent
MODELS = {"haiku": "claude-haiku-5-5", "sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5"}
PARTS = {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}


def lchoose(n, k):
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def hyper(x, n1, n2, k):
    return math.exp(lchoose(n1, x) + lchoose(n2, k - x) - lchoose(n1 + n2, k))


def fisher2(a, n1, b, n2):
    """Exact two-sided Fisher p, as compare_arms computes it (sum of tables no likelier than the seen one)."""
    k = a + b
    lo, hi = max(0, k - n2), min(n1, k)
    p0 = hyper(a, n1, n2, k)
    return min(1.0, sum(hyper(x, n1, n2, k) for x in range(lo, hi + 1) if hyper(x, n1, n2, k) <= p0 * (1 + 1e-7)))


def fisher_greater(a, n1, b, n2):
    """One-sided Fisher p that the first proportion is above the second."""
    k = a + b
    hi = min(n1, k)
    return min(1.0, sum(hyper(x, n1, n2, k) for x in range(a, hi + 1)))


FRAC = r"(\d+)/(\d+)"


def parse_compare(path):
    text = Path(path).read_text()
    out = {"text": text}
    m = re.search(r"graded pass rate, both graders' verdicts: \S+ (\d+)/(\d+) \(([\d.]+)%\), \S+ \(control\) (\d+)/(\d+) \(([\d.]+)%\), difference ([+-][\d.]+) points", text)
    out["graded"] = {"arm": (int(m[1]), int(m[2])), "ctl": (int(m[4]), int(m[5]))}
    m = re.search(r"part-\d: (\d+) runs, (\d+) harness-invalid, (\d+) nudged, (\d+) with a save refused", text)
    out["arm_runs"], out["arm_invalid"], out["arm_nudged"], out["arm_save_refused"] = map(int, m.groups())
    m = re.search(r"part-\d \(control\): (\d+) runs, (\d+) harness-invalid, (\d+) nudged, (\d+) with a save refused", text)
    out["ctl_runs"], out["ctl_invalid"], out["ctl_nudged"], out["ctl_save_refused"] = map(int, m.groups())
    lines = text.splitlines()
    i = next(n for n, l in enumerate(lines) if l.strip().startswith("each family counted once per run"))
    units = []
    for l in lines[i + 1:]:
        s = l.strip()
        if (s.startswith("a quick check of the user's material") or s.startswith("truthfulness")
                or s.startswith("quotes, re-cut") or s.startswith("expectations:")):
            break
        if s.startswith("("):
            units_note = s
            continue
        m = re.match(r"(.+?)\s+(\d+)/(\d+)\s+(\d+)/(\d+)\s+p(?:=([\d.]+)|<([\d.]+)| n/a)", s)
        if not m:
            raise SystemExit(f"unparsed family row in {path}: {s!r}")
        p = float(m[6]) if m[6] else (float(m[7]) if m[7] else None)
        units.append({"unit": m[1], "arm": (int(m[2]), int(m[3])), "ctl": (int(m[4]), int(m[5])), "p_printed": p,
                      "p_strict_less": bool(m[7])})
    out["units"] = units
    truth = {}
    for m in re.finditer(r"truthfulness \[([a-z_+]+)\]\s+(\d+)/(\d+)\s+(\d+)/(\d+)\s+p(?:=([\d.]+)|<([\d.]+)| n/a)", text):
        truth[m[1]] = {"arm": (int(m[2]), int(m[3])), "ctl": (int(m[4]), int(m[5]))}
    out["truth"] = truth
    tc = {}
    j = next((n for n, l in enumerate(lines) if l.startswith("== text-change measures")), None)
    if j is not None:
        for l in lines[j + 2:]:
            m = re.match(r"\s+(.+?)\s{2,}(\d+)/(\d+)(?: \([\d.]+\))?\s+(\d+)/(\d+)(?: \([\d.]+\))?\s+(\d+)/(\d+)", l)
            if m:
                tc[m[1]] = {"pooled": (int(m[2]), int(m[3])), "arm": (int(m[4]), int(m[5])), "ctl": (int(m[6]), int(m[7]))}
    out["tc"] = tc
    return out


def pct(a, n):
    return 100.0 * a / n if n else float("nan")


def frac(t):
    return f"{t[0]}/{t[1]}"


def quality(model):
    res = {}
    for part, mod in PARTS.items():
        c = parse_compare(R / "score" / f"compare-{model}-part-{part}.txt")
        items = {}
        a, b = c["graded"]["arm"], c["graded"]["ctl"]
        diff = pct(*a) - pct(*b)
        items["1 graded"] = {"arm": frac(a), "ctl": frac(b), "diff_points": round(diff, 2), "margin": 5,
                             "miss": diff < -5}
        gated, misses, nearest = [], [], None
        for u in c["units"]:
            (x, n1), (y, n2) = u["arm"], u["ctl"]
            if u["unit"].startswith("ledger_sentence_form"):
                continue
            if n1 < 10 or n2 < 10:
                continue
            d = pct(x, n1) - pct(y, n2)
            p = fisher2(x, n1, y, n2)
            row = {"unit": u["unit"], "arm": f"{x}/{n1}", "ctl": f"{y}/{n2}", "diff_points": round(d, 1), "p": p}
            gated.append(row)
            if d >= 10 and p < 0.01:
                misses.append(row)
            if d > 0 and (nearest is None or p < nearest["p"]):
                nearest = row
        items["2 checks"] = {"gated_units": len(gated), "misses": misses, "nearest_rise": nearest, "miss": bool(misses)}
        key = {"job-underwriter": "proposed_language" if model == "haiku" else "proposed_language+ledger_counts",
               "mock-interview": "no_overclaim", "resume-tailor": "row_quote"}[mod]
        t = c["truth"].get(key)
        if t is None:
            items["3 truthfulness"] = {"row": key, "error": "row not printed", "miss": None}
        else:
            (x, n1), (y, n2) = t["arm"], t["ctl"]
            gate = n1 >= 10 and n2 >= 10
            d = pct(x, n1) - pct(y, n2)
            p = fisher2(x, n1, y, n2)
            items["3 truthfulness"] = {"row": key, "arm": f"{x}/{n1}", "ctl": f"{y}/{n2}", "diff_points": round(d, 1),
                                       "p": p, "gated": gate, "miss": gate and d >= 10 and p < 0.05}
        sa = max(c["arm_invalid"] / c["arm_runs"], c["ctl_invalid"] / c["ctl_runs"])
        items["4 set aside"] = {"arm": f"{c['arm_invalid']}/{c['arm_runs']}", "ctl": f"{c['ctl_invalid']}/{c['ctl_runs']}",
                                "miss": sa > 0.10}
        items["reported"] = {"nudged": f"{c['arm_nudged']}/{c['arm_runs']} tuesday, {c['ctl_nudged']}/{c['ctl_runs']} alone",
                             "save_refused": f"{c['arm_save_refused']} tuesday, {c['ctl_save_refused']} alone"}
        res[mod] = {"items": items, "miss": any(v.get("miss") for k, v in items.items() if k != "reported"),
                    "tc": c["tc"]}
    return res


BASE = {  # section 4.2 baselines, pooled over arms: (count, n)
    "haiku": {"h1": (35, 47), "claims": (9, 47), "present": (48, 80), "e5": (12, 20), "e8": (0, 20), "reported": (17, 20)},
    "sonnet": {"h1": (31, 80), "claims": (2, 80), "present": (80, 80), "e5": (2, 20), "e8": (0, 20), "reported": (19, 19)},
    "opus": {"h1": (65, 80), "claims": (2, 80), "present": (80, 80), "e5": (2, 20), "e8": (0, 20), "reported": (14, 14)},
}


def down(now, base):  # falls from baseline at p < 0.01
    return pct(*now) < pct(*base) and fisher2(now[0], now[1], base[0], base[1]) < 0.01


def up(now, base):
    return pct(*now) > pct(*base) and fisher2(now[0], now[1], base[0], base[1]) < 0.01


def text_change(model, q):
    tc1 = q["job-underwriter"]["tc"]
    tc2 = q["mock-interview"]["tc"]
    b = BASE[model]
    out = {}
    h1 = tc1["ledger_sentence: sentences after the ledger above one"]
    claims = tc1["ledger_sentence: failed for a set claim (any reason but a second sentence)"]
    present = tc1["ledger_present: passing, of job-underwriter's valid runs"]
    form = tc1["ledger_sentence_form: passing, the list form or no sentence (reported)"]
    target = 0.20 if model == "haiku" else 0.10
    g_present = not down(present["pooled"], b["present"])
    g_claims = not up(claims["pooled"], b["claims"])
    hp = h1["pooled"]
    closed = hp[0] / hp[1] <= target and g_present and g_claims
    improved = (not closed) and down(hp, b["h1"]) and g_present and g_claims
    worse = up(hp, b["h1"]) or not g_present or not g_claims
    out["H1"] = {"share": frac(hp), "pct": round(pct(*hp), 1), "per_arm": [frac(h1["arm"]), frac(h1["ctl"])],
                 "baseline": frac(b["h1"]), "target_pct": target * 100,
                 "p_vs_baseline": fisher2(hp[0], hp[1], *b["h1"]),
                 "guard_ledger_present": {"now": frac(present["pooled"]), "base": frac(b["present"]), "holds": g_present,
                                          "p": fisher2(*present["pooled"], *b["present"])},
                 "guard_set_claims": {"now": frac(claims["pooled"]), "base": frac(b["claims"]), "holds": g_claims,
                                      "p": fisher2(*claims["pooled"], *b["claims"])},
                 "list_form_reported": frac(form["pooled"]),
                 "outcome": "closed" if closed else ("worse" if worse else ("improved" if improved else "unchanged")),
                 "worse": worse}
    e5 = tc1["zero_calls: failing, job-underwriter eval 5"]
    e5q = tc1["zero_calls: a quick check, job-underwriter eval 5"]
    e8 = tc2["zero_calls: failing, mock-interview eval 8"]
    e8q = tc2["zero_calls: a quick check, mock-interview eval 8"]
    rep1 = tc1["every call reported (the checks below), of the runs that sent a call"]
    rep2 = tc2["every call reported (the checks below), of the runs that sent a call"]
    rep = (rep1["pooled"][0] + rep2["pooled"][0], rep1["pooled"][1] + rep2["pooled"][1])
    fail_rep = (rep[1] - rep[0], rep[1])
    t1 = fail_rep[0] * 10 <= fail_rep[1] if rep[1] else True
    t2 = e5["pooled"][0] * 10 <= e5["pooled"][1]
    closed = t1 and t2
    improved = (not closed) and down(e5["pooled"], b["e5"]) and not t2
    worse = up(e8["pooled"], b["e8"])
    out["calls"] = {"target1_runs_failing_to_report": frac(fail_rep), "target1_met": t1,
                    "per_fixture_reported": {"eval5": frac(rep1["pooled"]), "eval8": frac(rep2["pooled"])},
                    "target2_eval5_beyond_quick_check": frac(e5["pooled"]), "target2_met": t2,
                    "eval5_per_arm": [frac(e5["arm"]), frac(e5["ctl"])], "eval5_baseline": frac(b["e5"]),
                    "eval5_quick_check": frac(e5q["pooled"]),
                    "eval8_beyond_quick_check": frac(e8["pooled"]), "eval8_baseline": frac(b["e8"]),
                    "eval8_quick_check": frac(e8q["pooled"]),
                    "outcome": "closed" if closed else ("worse" if worse else ("improved" if improved else "not closed")),
                    "worse": worse}
    return out


def routing(model):
    def load(name):
        return json.loads((R / model / name).read_text())
    e0, e1, e2 = load("e0-personal.json"), load("e1-plugin.json"), load("e2-plugin.json")
    suite = json.loads((R / "wt-text" / "evals" / "suite-routing.json").read_text())
    cases = {c["id"]: c for c in suite["cases"]}

    def outcomes(d):
        return {c["id"]: [r["outcome"] for r in c["runs"]] for c in d["results"]}
    o0, o1, o2 = outcomes(e0), outcomes(e1), outcomes(e2)
    items = {}
    files = {n: load(n) for n in ["e0-personal.json", "e1-plugin.json", "e2-plugin.json"]}
    extra = {"haiku": 3, "opus": 10}.get(model)
    if extra:
        for n in [f"e0-personal.case{extra}.json", f"e1-plugin.case{extra}.json"]:
            files[n] = load(n)
    sa = {n: (d["reach"]["set_aside"], sum(len(c["runs"]) for c in d["results"])) for n, d in files.items()}
    items["1 set aside"] = {n: frac(v) for n, v in sa.items()} | {"miss": any(a > 0.10 * n for a, n in sa.values())}
    exp2 = json.loads((R / "wt-text" / "evals" / "suite-explicit.json").read_text())
    exp_cases = {c["id"]: c for c in exp2["cases"]}
    foc = sum(1 for cid, rs in o2.items() for r in rs if r == "focused")
    dec2 = sum(1 for cid, rs in o2.items() for r in rs if r not in ("timeout", "error", "void"))
    items["2 explicit focused"] = {"focused": f"{foc}/{dec2}", "miss": foc != dec2}
    tues_files = [n for n in files if n.startswith("e1") or n.startswith("e2")]
    hidden = {n: files[n]["reach"]["hidden"] for n in tues_files}
    hidden_runs = {n: sum(1 for c in files[n]["results"] for r in c["runs"]
                          if str(r["outcome"]).startswith("hidden-") or any(str(x).startswith("hidden-") for x in (r.get("reached") or [])))
                   for n in tues_files}
    items["3a hidden (routing, this model)"] = {"summary_hidden": hidden, "runs_with_hidden_reach": hidden_runs,
                                                "miss": any(hidden.values()) or any(hidden_runs.values())}
    off = [11, 12, 13, 14, 19, 20]
    fires = sum(1 for cid in off for r in o1[cid] if r != "neither")
    items["4 off-topic fires"] = {"fires": f"{fires}/{sum(len(o1[c]) for c in off)}", "miss": fires > 0}
    single = [c for c in cases if cases[c]["expected"] in PARTS.values()]
    wrong = sum(1 for cid in single for r in o1[cid] if r in PARTS.values() and r != cases[cid]["expected"]
                or str(r).startswith("hidden-"))
    items["5 wrong picks"] = {"wrong": f"{wrong}/{sum(len(o1[c]) for c in single)}", "miss": wrong > 2}

    def right(o):
        return sum(1 for cid in single for r in o[cid] if r == cases[cid]["expected"]), sum(len(o[cid]) for cid in single)
    r0, r1 = right(o0), right(o1)
    p0, p1 = pct(*r0), pct(*r1)
    if p0 <= 80:
        miss6 = not (p1 >= p0 + 10 and p1 >= 60)
        rule = "today <= 80%: Tuesday >= today + 10 and >= 60%"
    else:
        miss6 = p1 < p0 - 5
        rule = "today > 80%: Tuesday >= today - 5"
    items["6 right module, single-module"] = {"tuesday": f"{r1[0]}/{r1[1]} ({p1:.1f}%)", "today": f"{r0[0]}/{r0[1]} ({p0:.1f}%)",
                                              "rule": rule, "miss": miss6}
    starved = {}
    for mod in PARTS.values():
        ids = [c for c in single if cases[c]["expected"] == mod]
        a = sum(1 for c in ids for r in o1[c] if r == mod)
        b = sum(1 for c in ids for r in o0[c] if r == mod)
        n = sum(len(o1[c]) for c in ids)
        starved[mod] = {"tuesday": f"{a}/{n}", "today": f"{b}/{n}", "miss": a < b - 3}
    items["7 no module starved"] = starved | {"miss": any(v["miss"] for v in starved.values())}
    span_ids = [9, 21] if model == "opus" else [9, 10, 21]

    def span(o):
        return sum(1 for cid in span_ids for r in o[cid] if r in cases[cid]["siblings"]), sum(len(o[c]) for c in span_ids)
    s0, s1 = span(o0), span(o1)
    items["8 spanning"] = {"cases": span_ids, "tuesday": frac(s1), "today": frac(s0), "miss": s1[0] < s0[0] - 2,
                           "per_case": {cid: {"tuesday": sum(r in cases[cid]["siblings"] for r in o1[cid]),
                                              "today": sum(r in cases[cid]["siblings"] for r in o0[cid])} for cid in [9, 10, 21]}}
    per_case = {cid: {"expected": cases[cid]["expected"], "today": o0[cid], "tuesday": o1[cid]} for cid in sorted(cases)}
    reported = {
        "tuesday_after_explicit": sum(1 for c in e2["results"] for r in c["runs"] if r.get("hub_fired")),
        "hub_path_contact": {n: files[n]["reported"]["hub_path_contact"] for n in tues_files},
        "skills_root_named": {n: files[n]["reported"]["skills_root_named"] for n in files},
        "refused": {n: (files[n]["reported"]["refused"], files[n]["reported"]["runs_refused"]) for n in files},
        "output_tokens": {n: files[n]["reported"]["output_tokens"] for n in files},
        "seconds": {n: files[n]["reported"]["seconds"] for n in files},
        "hashes": {n: (files[n].get("hub_sha256"), files[n].get("frontdoor_sha256")) for n in tues_files},
    }
    return {"items": items, "miss": any(v.get("miss") for v in items.values()), "per_case": per_case, "reported": reported}


def extras():
    out = {}
    for model, cid in [("opus", 10), ("haiku", 3)]:
        exp = json.loads((R / "wt-text" / "evals" / "suite-routing.json").read_text())
        case = next(c for c in exp["cases"] if c["id"] == cid)
        good = set(case.get("siblings") or [case["expected"]])

        def count(name, std):
            d = json.loads((R / model / name).read_text())
            runs = [r for c in d["results"] if c["id"] == cid for r in c["runs"]]
            return sum(r["outcome"] in good for r in runs), len(runs)
        t_std, s_std = count("e1-plugin.json", True), count("e0-personal.json", True)
        t_x, s_x = count(f"e1-plugin.case{cid}.json", False), count(f"e0-personal.case{cid}.json", False)
        t = (t_std[0] + t_x[0], t_std[1] + t_x[1])
        s = (s_std[0] + s_x[0], s_std[1] + s_x[1])
        p_skills_ahead = fisher_greater(s[0], s[1], t[0], t[1])
        p_tues_below = p_skills_ahead
        if cid == 10:
            if p_skills_ahead < 0.05:
                reading = "1: today's skills significantly ahead"
            elif s[0] <= 4 and t[0] <= 2:
                reading = "2: both arms low"
            elif t[0] >= s[0]:
                reading = "3: Tuesday at least as often as today's skills"
            else:
                reading = "4: inconclusive"
        else:
            if p_tues_below < 0.05:
                reading = "1: Tuesday significantly below today's skills"
            elif s[0] <= 5 and t[0] <= 5:
                reading = "2: both arms at most 5 of 50"
            else:
                reading = "3: no significant gap"
        out[f"{model} case {cid}"] = {"tuesday": f"{t[0]}/{t[1]} (standard {frac(t_std)}, extra {frac(t_x)})",
                                     "today": f"{s[0]}/{s[1]} (standard {frac(s_std)}, extra {frac(s_x)})",
                                     "p_one_sided_today_ahead": p_skills_ahead, "reading": reading}
    return out


def hidden_all():
    """Item 3(b): every Tuesday session of the round, quality (each invocation, nudges included) and routing."""
    per = {}
    for m in MODELS:
        q_sessions = q_hidden = 0
        for f in glob.glob(str(R / m / "tuesday" / "part-*" / "*.meta.json")):
            for inv in json.loads(Path(f).read_text()).get("invocations", []):
                q_sessions += 1
                q_hidden += str(inv.get("fire", "")).startswith("hidden-")
        r_sessions = r_hidden = 0
        for f in glob.glob(str(R / m / "e[12]-plugin*.json")):
            d = json.loads(Path(f).read_text())
            for c in d["results"]:
                for r in c["runs"]:
                    r_sessions += 1
                    r_hidden += str(r["outcome"]).startswith("hidden-") or any(str(x).startswith("hidden-") for x in (r.get("reached") or []))
        n = q_sessions + r_sessions
        h = q_hidden + r_hidden
        per[m] = {"quality_sessions": q_sessions, "routing_sessions": r_sessions, "reaches": h,
                  "bound_95_pct": round(100 * (1 - 0.05 ** (1 / n)), 2) if h == 0 else None}
    n = sum(v["quality_sessions"] + v["routing_sessions"] for v in per.values())
    h = sum(v["reaches"] for v in per.values())
    return {"per_model": per, "sessions": n, "reaches": h,
            "bound_95_pct_zero": round(100 * (1 - 0.05 ** (1 / n)), 2), "miss": h > 1}


def main():
    card = {"quality": {}, "text_change": {}, "routing": {}}
    for m in MODELS:
        q = quality(m)
        card["text_change"][m] = text_change(m, q)
        for mod in q:
            q[mod].pop("tc")
        card["quality"][m] = q
        card["routing"][m] = routing(m)
    card["hidden_3b"] = hidden_all()
    card["extras"] = extras()
    q_miss = any(card["quality"][m][mod]["miss"] for m in MODELS for mod in PARTS.values())
    r_miss = any(card["routing"][m]["miss"] for m in MODELS) or card["hidden_3b"]["miss"]
    t_worse = any(card["text_change"][m][k]["worse"] for m in MODELS for k in ("H1", "calls"))
    card["bar_met"] = not (q_miss or r_miss or t_worse)
    card["parts"] = {"quality_miss": q_miss, "routing_miss": r_miss, "text_change_worse": t_worse}
    (R / "score" / "scorecard.json").write_text(json.dumps(card, indent=1, default=str))
    # Print
    for m in MODELS:
        print(f"\n######## {m}")
        for mod, v in card["quality"][m].items():
            it = v["items"]
            print(f"  quality {mod}: {'MISS' if v['miss'] else 'holds'}")
            g = it["1 graded"]
            print(f"    1 graded {g['arm']} vs {g['ctl']} diff {g['diff_points']:+} (miss if < -5)")
            c = it["2 checks"]
            nr = c["nearest_rise"]
            print(f"    2 checks: {c['gated_units']} gated units, misses {len(c['misses'])}; nearest rise "
                  f"{nr['unit'] + ' ' + nr['arm'] + ' vs ' + nr['ctl'] + ' p=' + format(nr['p'], '.3f') if nr else 'none'}")
            for x in c["misses"]:
                print(f"       MISS {x}")
            t = it["3 truthfulness"]
            print(f"    3 truth [{t['row']}] {t.get('arm')} vs {t.get('ctl')} diff {t.get('diff_points')} p={t.get('p', 0):.3f} gated={t.get('gated')}")
            s = it["4 set aside"]
            print(f"    4 set aside {s['arm']} / {s['ctl']}; reported {it['reported']}")
        for k, v in card["text_change"][m].items():
            print(f"  text change {k}: {v['outcome'].upper()}  {json.dumps({x: y for x, y in v.items() if x not in ('outcome', 'worse')}, default=str)}")
        rt = card["routing"][m]
        print(f"  routing: {'MISS' if rt['miss'] else 'holds'}")
        for k, v in rt["items"].items():
            print(f"    {k}: {json.dumps(v, default=str)}")
    print("\n######## hidden 3(b):", json.dumps(card["hidden_3b"]))
    print("######## extras:", json.dumps(card["extras"], indent=1))
    print("\nBAR MET" if card["bar_met"] else "\nBAR MISSED", json.dumps(card["parts"]))


if __name__ == "__main__":
    main()
