import sys,json,glob,os,collections
V='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/verify/harness-fault-hunt'
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
sys.path.insert(0,V+'/src/evals')
import run_fixtures as rf, output_checks as oc
from fixture_clauses import dated
SK={1:'job-underwriter',2:'mock-interview',3:'resume-tailor'}
cases={s:{c['id']:c for c in rf.cases_for(s,[])} for s in SK.values()}
diff=collections.Counter(); ex=[]
for m in ['haiku','sonnet','opus']:
  for a in ['tuesday','alone']:
    for p,s in SK.items():
      d=f'{R}/{m}/{a}/part-{p}'
      skill_md=rf.REPO/'skills'/s/'SKILL.md'
      line=oc.declared_watch_out(skill_md.read_text())
      for mf in sorted(glob.glob(d+'/*.meta.json')):
        meta=json.load(open(mf)); stem=meta['stem']
        case=dated(cases[s][meta['id']], rf.run_date(meta))
        status,reasons=rf.harness_status(meta)
        body=open(f'{d}/{stem}.md').read()
        rec=oc.run_checks(case, meta['mode'], body, meta.get('research_log'), status, reasons, watch_out=line or '')
        rec={'skill':s,'id':case['id'],'run':meta['run'],'stem':stem,**rec}
        saved=json.load(open(f'{d}/{stem}.checks.json'))
        if rec==saved: diff['same']+=1
        else:
          diff['diff']+=1
          if len(ex)<5: ex.append((m,a,p,stem,[k for k in rec if rec.get(k)!=saved.get(k)]))
print(diff); print(ex)
