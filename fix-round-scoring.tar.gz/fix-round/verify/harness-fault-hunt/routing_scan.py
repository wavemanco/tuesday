import json,glob,os,re,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
MODS=['job-underwriter','mock-interview','resume-tailor']
builtins=collections.Counter()
for m in ['haiku','sonnet','opus']:
  for fn in sorted(glob.glob(f'{R}/{m}/e*.json')):
    d=json.load(open(fn)); name=os.path.basename(fn)
    oc=collections.Counter(); keys=collections.Counter(); probs=[]
    for c in d['results']:
      for i,r in enumerate(c['runs']):
        oc[r['outcome']]+=1
        keys.update(r.keys())
        init=r.get('init_skills') or []
        tues=[s for s in init if re.search(r'(tuesday|job-underwriter|mock-interview|resume-tailor)',s)]
        others=[s for s in init if s not in tues]
        builtins[tuple(sorted(others))]+=1
        ids={re.search(r'-([0-9a-f]{8})$',s).group(1) for s in tues if re.search(r'-([0-9a-f]{8})$',s)}
        if len(ids)!=1: probs.append((c['id'],i,'ids',tues))
        if d['arm']=='skills':
          if any('tuesday' in s for s in tues) or len(tues)!=3 or any(':' in s for s in tues): probs.append((c['id'],i,'e0 init',tues))
        else:
          exp={f'tuesday-{x}:{mm}-{x}' for x in ids for mm in MODS+['tuesday']}
          if set(tues)!=exp: probs.append((c['id'],i,'e1 init',tues))
        reached=r.get('reached')
        o=r['outcome']
        if d['arm']=='frontdoor' and not c.get('explicit') and 'suite-explicit' not in d['cases_file']:
          hid=[x for x in reached if x.startswith('hidden-')]
          routed=[x for x in reached if not x.startswith('hidden-')]
          want = hid[0] if hid else routed[0] if routed else ('tuesday-unrouted' if r.get('hub_fired') else 'neither')
          if o!=want: probs.append((c['id'],i,'outcome/reached',o,reached,r.get('hub_fired')))
          if o in MODS and not r.get('hub_fired'): probs.append((c['id'],i,'module without hub',o))
        if 'suite-explicit' in d['cases_file']:
          if o!='focused' or reached: probs.append((c['id'],i,'e2',o,reached,r.get('loaded'),r.get('hub_fired')))
        if r.get('hub_path_contact') or r.get('skills_root_named'): probs.append((c['id'],i,'contact',r.get('hub_path_contact'),r.get('skills_root_named')))
      # fired list consistency
      if 'fired' in c:
        pass
    print(m,name,d['arm'],d['layout'],d.get('hub_sha256','')[:8],d.get('frontdoor_sha256','')[:8],'cases',len(d['results']),'runs',sum(oc.values()),dict(oc))
    print('   reach',d.get('reach'))
    print('   unscored',d.get('unscored'),'passed',d.get('passed'),'/',d.get('total'))
    for p in probs[:20]: print('   PROB',p)
for b,n in builtins.items(): print(n,len(b),b)
