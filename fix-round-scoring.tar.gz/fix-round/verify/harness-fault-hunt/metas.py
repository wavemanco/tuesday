import json,glob,os,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
for m in ['haiku','sonnet','opus']:
  for a in ['tuesday','alone']:
    for p in [1,2,3]:
      c=collections.Counter(); ex=[]
      for f in sorted(glob.glob(f'{R}/{m}/{a}/part-{p}/*.meta.json')):
        M=json.load(open(f)); inv=M['invocations']
        c[('ninv',len(inv))]+=1
        c[('fire',M.get('fire'))]+=1
        c[('trig',M.get('triggered_unprompted'))]+=1
        c[('graded_inv',M.get('graded_invocation'))]+=1
        c[('harness',M['harness']['status'])]+=1
        for i in inv:
          c[('cli',i.get('init',{}).get('claude_code_version'))]+=1
          c[('model',i.get('init',{}).get('model'))]+=1
          c[('ifire',i.get('fire'),i.get('nudged'))]+=1
          c[('outcome',i.get('outcome'))]+=1
          c[('perm',i.get('init',{}).get('permissionMode'))]+=1
          c[('competing',len(i.get('init',{}).get('competing_skills') or []))]+=1
          c[('loaded',i.get('init',{}).get('installed_loaded'))]+=1
          c[('nskills',i.get('init',{}).get('skills'))]+=1
          r=i.get('result') or {}
          c[('res',r.get('subtype'),r.get('is_error'),r.get('incomplete'))]+=1
          for s in i.get('skills_fired') or []: c[('fired',s.split('-')[0] if ':' in s else s.rsplit('-',1)[0])]+=1
        if len(inv)>1: ex.append((os.path.basename(f)[:-10],[(i.get('fire'),i.get('nudged'),i.get('skills_fired')) for i in inv]))
      print(m,a,p,sorted(c.items(),key=str))
      for e in ex: print('   ',e)
