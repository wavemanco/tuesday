import sys
from pathlib import Path
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
sys.path.insert(0,R+'/wt-text/evals')
import compare_arms as ca
cases=ca.fixture_cases()
for m in ['haiku','sonnet','opus']:
  for p in [1,2,3]:
    a=[r for r in ca.load(Path(f'{R}/{m}/tuesday/part-{p}'),None,cases) if r['meta_read']]
    c=[r for r in ca.load(Path(f'{R}/{m}/alone/part-{p}'),None,cases) if r['meta_read']]
    ca.expect_graders(a,c)
    only=ca.failure_only(a+c)
    present=set(ca.check_names(a+c))
    for name,members,via,_ in ca.FAMILIES:
      if not present & set(members): continue
      for label,v in (('anchored',via),('any member',members)):
        fa,na,_=ca.unit_counts(a,name,v,only); fc,nc,_=ca.unit_counts(c,name,v,only)
        p_=ca.fisher(fa,na,fc,nc)
        d=(100*fa/na-100*fc/nc) if na and nc else None
        print(m,p,f'{name[:38]:38}',label,f'{fa}/{na} vs {fc}/{nc}', 'diff', None if d is None else round(d,1), 'p', None if p_ is None else round(p_,4))
