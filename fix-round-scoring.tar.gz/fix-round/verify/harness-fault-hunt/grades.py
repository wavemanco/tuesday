import json,glob,os,sys,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
for m in ['haiku','sonnet','opus']:
  for a in ['tuesday','alone']:
    for p in [1,2,3]:
      d=f'{R}/{m}/{a}/part-{p}'
      metas=sorted(glob.glob(d+'/*.meta.json'))
      stems=[os.path.basename(x)[:-10] for x in metas]
      nv=0; vs=collections.Counter(); keys=collections.Counter(); bad=[]
      for s in stems:
        gs=sorted(glob.glob(f'{d}/{s}.grade-*.json'))
        if len(gs)!=2: bad.append((s,'ngrade',len(gs)))
        for g in gs:
          try: G=json.load(open(g))
          except Exception as e: bad.append((s,g,'bad json')); continue
          keys.update(k for k in G)
          v=G.get('verdicts') or []
          nv+=len(v)
          for x in v: vs[x.get('verdict')]+=1
        md=f'{d}/{s}.md'
        if not os.path.exists(md) or os.path.getsize(md)==0: bad.append((s,'md empty'))
      print(m,a,p,len(stems),'verdicts',nv,dict(vs),bad[:5])
      print('   keys',dict(keys))
