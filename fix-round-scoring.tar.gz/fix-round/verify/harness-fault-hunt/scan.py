import re,glob
for f in sorted(glob.glob('/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/verify/harness-fault-hunt/compare-*.txt')):
  sec=None
  for line in open(f):
    if line.startswith('  each family'): sec='units'
    elif line.startswith('  quotes, re-cut') : sec=None
    elif line.startswith('  truthfulness:'): sec='truth'
    elif line.startswith('  expectations:'): sec=None
    m=re.match(r'\s+(.+?)\s+(\d+)/(\d+)\s+(\d+)/(\d+)\s+(p\S+)',line)
    if m and sec:
      a,n1,b,n2=map(int,m.group(2,3,4,5))
      if n1 and n2:
        d=100*a/n1-100*b/n2
        if d>=5 or sec=='truth': print(f.split('/')[-1],sec,line.rstrip())
  for line in open(f):
    if 'graded pass rate, both graders\'' in line: print(f.split('/')[-1], line.strip()[:200])
