import json,glob,os,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
agg=collections.Counter()
for g in sorted(glob.glob(R+'/*/*/part-*/*.grade-*.json')):
  G=json.load(open(g)); rel=g[len(R)+1:]
  agg[('model',G.get('grader_model'),G.get('requested_model'))]+=1
  agg[('pv',G.get('grader_prompt_version'))]+=1
  agg[('cli',G.get('cli_version'))]+=1
  exp=G.get('expected'); v=G['verdicts']
  odd=[]
  if isinstance(exp,list): ne=len(exp)
  else: ne=exp
  if ne!=len(v): odd.append(f'expected {ne} got {len(v)}')
  for k in ['incomplete','missing','duplicates','invalid','regraded','truncated']:
    if G.get(k): odd.append(f'{k}={G.get(k)}')
  bad=[x for x in v if x.get('verdict') not in ('PASS','FAIL')]
  if bad: odd.append(f'badverdict {bad}')
  ns=[x.get('n') for x in v]
  if sorted(ns)!=list(range(1,len(ns)+1)): odd.append(f'ns {ns}')
  if odd: print(rel, odd)
print(agg)
