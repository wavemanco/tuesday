import sys,json,glob,os,re,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
sys.path.insert(0,R+'/wt-text/evals')
import output_checks as oc, run_fixtures as rf
cases={c['id']:c for c in rf.cases_for('mock-interview',[])}
ROWRE=re.compile(r'^(?P<src>.+?) row (?P<row>[^:]+): "(?P<span>.*)" — "(?P<frag>.*)" is not in what the candidate gave')
for m in ['haiku','sonnet','opus']:
  for a in ['tuesday','alone']:
    d=f'{R}/{m}/{a}/part-2'
    runs_fail=0; runs_only_list=0; nfail=0; nlist=0; ex=[]
    for cf in sorted(glob.glob(d+'/*.checks.json')):
      C=json.load(open(cf)); stem=os.path.basename(cf)[:-12]
      fails=[f for f in C['checks'] if f['check']=='quotes' and f['verdict']=='FAIL']
      if not fails: continue
      runs_fail+=1
      M=json.load(open(d+f'/{stem}.meta.json')); case=cases[M['id']]
      hay=oc.normalise_quote(case['prompt'])
      resp=open(d+f'/{stem}.md').read()
      cells={}
      for source,body in oc.split_response(resp):
        for t in oc.md_tables(body):
          names=oc.header_names(t)
          if any('provenance' in h for h in names) and any('answer guidance' in h for h in names):
            col=next(i for i,h in enumerate(names) if 'provenance' in h)
            for cells_ in t['rows']:
              if col<len(cells_):
                rid=cells_[0].replace('`','').replace('*','').strip()[:20]
                cells.setdefault(rid,[]).append(cells_[col])
      listy=0
      for f in fails:
        nfail+=1
        mm=ROWRE.match(f['why'])
        if not mm or f['target']!='banks': continue
        rid=mm.group('row').strip(); frag=mm.group('frag')
        for cell in cells.get(rid,[]):
          spans=oc.quoted_spans_with_origin(cell)
          for i,(sp,orig) in enumerate(spans):
            if oc.normalise_quote(sp).strip(oc.EDGE).startswith(frag[:15]) and orig is None:
              later=[o for s,o in spans[i+1:] if o]
              if later and oc.other_source(later[0]) and oc.contains_words(frag,hay):
                listy+=1; nlist+=1; ex.append((stem,rid,frag[:50],later[0][:30]))
                break
          else: continue
          break
      if listy==len(fails): runs_only_list+=1
    print(m,a,'runs with quote fail',runs_fail,'runs whose every quote fail is a list sharing an other-source origin',runs_only_list,'fails',nfail,'listy',nlist)
    for e in ex[:6]: print('   ',e)
