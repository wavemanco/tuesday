import sys,json,glob,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
sys.path.insert(0,R+'/wt-text/evals')
import output_checks as oc
c=collections.defaultdict(collections.Counter); kinds=collections.defaultdict(set); unchecked=collections.Counter(); status=collections.Counter()
for f in glob.glob(R+'/*/*/part-*/*.checks.json'):
  C=json.load(open(f)); status[C.get('status')]+=1
  for x in C['checks']: c[x['check']][x['verdict']]+=1; kinds[x['check']].add(x.get('kind'))
  for u in C.get('unchecked') or []: unchecked[str(u)[:60]]+=1
for k in sorted(c):
  tag='FO' if k in oc.FAILURE_ONLY else 'RP' if k in oc.RECORDS_PASSES else 'REP' if k in oc.REPORTED else '??'
  flag=''
  if tag=='FO' and c[k]['PASS']: flag='<< FO with PASS'
  if tag=='??': flag='<< unknown'
  print(f'{k:28} {tag:3} {dict(c[k])} {kinds[k]} {flag}')
print('unchecked',unchecked); print(status)
