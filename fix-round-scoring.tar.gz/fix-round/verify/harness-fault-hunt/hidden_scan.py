import json,glob,os,re,collections
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
MODS=['job-underwriter','mock-interview','resume-tailor']
tot=collections.Counter(); hits=[]
for m in ['haiku','sonnet','opus']:
  for p in [1,2,3]:
    d=f'{R}/{m}/tuesday/part-{p}'
    own=MODS[p-1]
    for f in sorted(glob.glob(d+'/*.meta.json')):
      M=json.load(open(f))
      for inv in M['invocations']:
        room=os.path.basename(inv['room']); rid=room.rsplit('-',1)[1]
        s=f'{d}/streams/{room}.jsonl'
        if not os.path.exists(s): hits.append((f,'nostream')); continue
        tot['sessions']+=1
        pb=collections.Counter()
        for line in open(s):
          try: e=json.loads(line)
          except: continue
          if e.get('type')!='assistant': continue
          for it in e.get('message',{}).get('content',[]):
            if it.get('type')!='tool_use': continue
            blob=json.dumps(it.get('input',{}))
            for mod in MODS:
              if f'{mod}-{rid}' in blob: hits.append((f[len(R):],inv['nudged'],'names hidden folder',mod,it['name'],blob[:200]))
            if it['name']=='Skill':
              sk=str(it['input'].get('skill',''))
              if any(mod in sk for mod in MODS): hits.append((f[len(R):],'Skill',sk))
            for mod in MODS:
              if re.search(rf'references/{mod}\.md',blob): pb[mod]+=1
        others=[k for k in pb if k!=own]
        tot[('playbooks', tuple(sorted(pb)))]+=1
        if others: hits.append((f[len(R):], inv['nudged'], inv.get('fire'), 'other playbook read', dict(pb)))
print(tot)
for h in hits: print(h)
