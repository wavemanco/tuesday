import json,glob,os,re
R='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
MODS=['job-underwriter','mock-interview','resume-tailor']
for m in ['haiku','sonnet','opus']:
  for p in [1,2,3]:
    d=f'{R}/{m}/tuesday/part-{p}'
    for f in sorted(glob.glob(d+'/*.meta.json')):
      M=json.load(open(f))
      for inv in M['invocations']:
        room=os.path.basename(inv['room']); s=f'{d}/streams/{room}.jsonl'
        calls=[]
        for line in open(s):
          e=json.loads(line)
          if e.get('type')!='assistant': continue
          for it in e.get('message',{}).get('content',[]):
            if it.get('type')=='tool_use': calls.append((it['name'],json.dumps(it['input'])[:250]))
        if not any(re.search(rf'references/{mod}\.md',c[1]) for c in calls for mod in MODS) and not inv['nudged'] and inv['fire']=='fired':
          print(f[len(R):], inv['fire']); [print('   ',c) for c in calls[:6]]
