"""Independent recount of compare_arms' unit block (families once per run, then other failures),
from the raw .checks.json files, with my own folding. Imports nothing from the repository.

Family rules as section 2.2 item f and the README describe them: a family applies where a
member that records passes has a finding (and is not unchecked), or where the family failed.
Failure-only checks (they write a finding only to fail) apply in every valid run.
"""
import json
import re
import sys
from math import comb
from pathlib import Path

ROUND = Path(sys.argv[1])
MODEL = sys.argv[2]
FAIL_ONLY = {"gates_form", "severity_form", "ledger_markup", "evidence_form", "evidence_map", "format",
             "candidate_constraints", "canary_fixture", "tally_remark"}
REPORTED = {"ledger_sentence_form"}
NO_TABLE = ("the response has no accounting table", "the accounting table could not be read")
CLAIM = {"snapshot_count": re.compile(r'^the snapshot\'s prose: "(.+?)" is '),
         "ledger_sentence": re.compile(r'^in the sentence after the ledger, "(.+?)" is ')}


def fisher2(a, n1, b, n2):
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    pr = lambda x: comb(n1, x) * comb(n2, k - x) / tot
    obs = pr(a)
    return min(1.0, sum(pr(x) for x in range(max(0, k - n2), min(k, n1) + 1) if pr(x) <= obs * (1 + 1e-9)))


def aimed_targets(meta):
    """Targets research calls were aimed at, from the run's research_log (targets field)."""
    out = set()
    for e in meta.get("research_log") or []:
        for t in e.get("targets") or []:
            out.add(str(t))
    return out


def units_of(meta, checks):
    """(failed units, set of checks with a recording finding) for one run."""
    un = set(checks.get("unchecked") or [])
    fs = [f for f in checks["checks"] if f["check"] not in un]
    fails = [(i, f) for i, f in enumerate(fs) if f.get("verdict") == "FAIL"]
    used, failed = set(), {}

    def take(name, idx):
        idx = idx - used
        if idx:
            failed[name] = len({fs[i]["check"] for i in idx})
            used.update(idx)
    take("hard-gates line", {i for i, f in fails if f["check"] in ("gates_line", "gates_form")})
    take("severity slot", {i for i, f in fails if f["check"] in ("severity", "severity_form")})
    zero = {i for i, f in fails if f["check"] == "zero_calls"}
    if zero:
        aim = aimed_targets(meta)
        zero |= {i for i, f in fails if f["check"] in ("accept", "skip_has_no_call") and str(f.get("target")) in aim}
    take("a call where none belongs", zero)
    rows = {f.get("target") for i, f in fails if f["check"] == "unavailable_has_refusal"}
    take("canned unavailable, nothing refused",
         {i for i, f in fails if f["check"] == "unavailable_has_refusal" or (f["check"] == "accept" and f.get("target") in rows)})
    notab = {i for i, f in fails if f["check"] == "row" and str(f.get("why", "")).startswith(NO_TABLE)}
    if notab:
        notab |= {i for i, f in fails if f["check"] == "tally"}
    take("no accounting table, nor its tally line", notab)
    claims = {}
    for i, f in fails:
        p = CLAIM.get(f["check"])
        m = p.match(str(f.get("why", ""))) if p else None
        if m:
            claims.setdefault(m.group(1), {}).setdefault(f["check"], i)
    take("one set claim, read twice", {i for c in claims.values() if len(c) == 2 for i in c.values()})
    for i, f in fails:
        if i not in used and f["check"] not in REPORTED:
            failed.setdefault(f["check"], 1)
    recording = {f["check"] for f in fs}
    return failed, recording


FAM_VIA = {"hard-gates line": ("gates_line", "gates_form"), "severity slot": ("severity", "severity_form"),
           "a call where none belongs": ("zero_calls",),
           "canned unavailable, nothing refused": ("unavailable_has_refusal",),
           "no accounting table, nor its tally line": ("row", "tally"),
           "one set claim, read twice": ("snapshot_count", "ledger_sentence")}

for part, module in {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}.items():
    per_arm = {}
    all_checks = set()
    for arm in ("tuesday", "alone"):
        folder = ROUND / MODEL / arm / f"part-{part}"
        runs = []
        for mp in sorted(folder.glob("*.meta.json")):
            meta = json.loads(mp.read_text())
            if (meta.get("harness") or {}).get("status", "ok") != "ok":
                continue
            checks = json.loads((folder / (mp.name[:-10] + ".checks.json")).read_text())
            failed, rec = units_of(meta, checks)
            all_checks |= {f["check"] for f in checks["checks"]}
            runs.append((failed, rec, set(checks.get("unchecked") or [])))
        per_arm[arm] = runs
    units = [u for u, via in FAM_VIA.items() if all_checks & set(via)]
    others = sorted({u for runs in per_arm.values() for failed, _, _ in runs for u in failed} - set(FAM_VIA))
    print(f"== {module}")
    for u in units + others:
        row = []
        for arm in ("tuesday", "alone"):
            via = FAM_VIA.get(u, (u,))
            rec_via = [m for m in via if m not in FAIL_ONLY]
            n = f = 0
            for failed, rec, un in per_arm[arm]:
                if rec_via:
                    app = any(m in rec for m in rec_via) or u in failed
                else:
                    app = any(m not in un for m in via)
                if app:
                    n += 1
                    f += u in failed
            row.append((f, n))
        (a, n1), (b, n2) = row
        gated = n1 >= 10 and n2 >= 10
        diff = 100 * a / n1 - 100 * b / n2 if n1 and n2 else float("nan")
        p = fisher2(a, n1, b, n2) if n1 and n2 else float("nan")
        miss = gated and diff >= 10 and p < 0.01
        print(f"  {u:<42} {a:>3}/{n1:<3} {b:>3}/{n2:<3} diff {diff:+6.1f}  p={p:.3f}  "
              f"{'gated' if gated else 'not gated'}  {'MISS' if miss else 'holds' if gated else ''}")
