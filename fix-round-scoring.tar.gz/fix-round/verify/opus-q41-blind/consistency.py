import json, sys
from collections import Counter
from math import comb
from pathlib import Path
R = Path(sys.argv[1])
bad = []
usage = Counter()
for arm in ("tuesday", "alone"):
    for p in (1, 2, 3):
        f = R / arm / f"part-{p}"
        for mp in sorted(f.glob("*.meta.json")):
            m = json.loads(mp.read_text()); stem = mp.name[:-10]
            for g in (1, 2):
                gr = json.loads((f / f"{stem}.grade-{g}.json").read_text())
                for k in ("skill", "id", "run", "mode"):
                    if gr.get(k) != m.get(k): bad.append((arm, stem, g, k, gr.get(k), m.get(k)))
                if gr.get("grader") != g: bad.append((arm, stem, g, "grader", gr.get("grader")))
                if gr.get("requested_model") != gr.get("grader_model"): bad.append((arm, stem, g, "grader model", gr.get("requested_model"), gr.get("grader_model")))
            ck = json.loads((f / f"{stem}.checks.json").read_text())
            for k in ("skill", "id", "run", "mode", "stem"):
                if ck.get(k) != m.get(k): bad.append((arm, stem, "checks", k))
            for inv in m["invocations"]:
                mu = (inv.get("result") or {}).get("modelUsage") or {}
                top = max(mu, key=lambda k: mu[k].get("costUSD") or 0) if mu else None
                usage[(arm, f"part-{p}", tuple(sorted(mu)), top)] += 1
print("mismatches:", bad)
for k, v in sorted(usage.items()): print(k, v)

def one_sided(a, n1, b, n2):  # P(X >= a) for the arm count, hypergeometric
    k, n = a + b, n1 + n2
    return sum(comb(n1, x) * comb(n2, k - x) for x in range(a, min(k, n1) + 1)) / comb(n, k)
for lab, a, n1, b, n2 in (("JU truth pair", 21, 40, 15, 40), ("JU truth PL", 9, 25, 4, 25),
                          ("MI evidence_form", 16, 100, 7, 100), ("JU tally", 5, 35, 3, 35),
                          ("RT row_quote", 5, 50, 4, 50)):
    print(lab, f"one-sided p={one_sided(a, n1, b, n2):.4f}")
