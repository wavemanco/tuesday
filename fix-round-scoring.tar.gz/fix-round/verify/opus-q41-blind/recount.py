"""Independent recount of section 4.1 figures for one model, from the raw run files.

Reads only: <round>/<model>/<arm>/part-<n>/*.{meta,checks,grade-1,grade-2}.json and the raw
evals.json files of the measured worktree (clause references read with my own regex). Imports
nothing from the repository.
"""
import json
import re
import sys
from collections import Counter, defaultdict
from math import comb
from pathlib import Path

ROUND = Path(sys.argv[1])
MODEL = sys.argv[2]
WT = ROUND / "wt-text"
PARTS = {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}
FAMILY = {"job-underwriter": [("proposed_language", "ledger_counts"), ("proposed_language",)],
          "mock-interview": [("no_overclaim",)], "resume-tailor": [("row_quote",)]}
REF = re.compile(r"\{\{([a-z0-9_]+)\}\}")


def fisher2(a, n1, b, n2):
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    pr = lambda x: comb(n1, x) * comb(n2, k - x) / tot
    obs = pr(a)
    return min(1.0, sum(pr(x) for x in range(max(0, k - n2), min(k, n1) + 1) if pr(x) <= obs * (1 + 1e-9)))


def family_expectations(module):
    spec = json.loads((WT / "skills" / module / "evals" / "evals.json").read_text())
    out = {}
    for case in spec["evals"]:
        out[case["id"]] = {i: set(REF.findall(e)) for i, e in enumerate(case["expectations"], 1)}
    return out


def load_arm(folder):
    runs = []
    for mp in sorted(folder.glob("*.meta.json")):
        stem = mp.name[:-len(".meta.json")]
        meta = json.loads(mp.read_text())
        grades = {}
        for g in (1, 2):
            gp = folder / f"{stem}.grade-{g}.json"
            grades[g] = json.loads(gp.read_text()) if gp.exists() else None
        cp = folder / f"{stem}.checks.json"
        checks = json.loads(cp.read_text()) if cp.exists() else None
        runs.append({"stem": stem, "meta": meta, "grades": grades, "checks": checks,
                     "md": (folder / f"{stem}.md").exists()})
    return runs


def invalid(meta):
    h = meta.get("harness")
    if h:
        return h.get("status") != "ok"
    return bool(meta.get("error")) or meta.get("skill_fired") is False


out = {}
for part, module in PARTS.items():
    fam_exp = family_expectations(module)
    res = {}
    for arm in ("tuesday", "alone"):
        folder = ROUND / MODEL / arm / f"part-{part}"
        runs = load_arm(folder)
        killed = sorted(p.name for p in (folder / "killed").glob("*")) if (folder / "killed").exists() else []
        r = {"runs": len(runs), "killed_files": len(killed)}
        r["invalid"] = sum(invalid(x["meta"]) for x in runs)
        r["harness_status"] = dict(Counter(json.dumps(x["meta"].get("harness")) for x in runs))
        r["fire"] = dict(Counter(x["meta"].get("fire") for x in runs))
        r["skill_fired"] = dict(Counter(str(x["meta"].get("skill_fired")) for x in runs))
        r["nudged_inv"] = sum(any(i.get("nudged") for i in x["meta"].get("invocations") or []) for x in runs)
        r["triggered_unprompted_false"] = sum(x["meta"].get("triggered_unprompted") is False for x in runs)
        r["n_invocations"] = dict(Counter(len(x["meta"].get("invocations") or []) for x in runs))
        r["meta_model"] = dict(Counter(x["meta"].get("model") for x in runs))
        r["via"] = dict(Counter(x["meta"].get("via") for x in runs))
        r["layout"] = dict(Counter(x["meta"].get("layout") for x in runs))
        r["room_writable"] = dict(Counter(str(x["meta"].get("room_writable")) for x in runs))
        r["run_date"] = dict(Counter(x["meta"].get("run_date") for x in runs))
        r["cli_init"] = dict(Counter((i.get("init") or {}).get("claude_code_version")
                                     for x in runs for i in x["meta"].get("invocations") or []))
        r["init_model"] = dict(Counter((i.get("init") or {}).get("model")
                                       for x in runs for i in x["meta"].get("invocations") or []))
        r["inv_outcome"] = dict(Counter(i.get("outcome") for x in runs for i in x["meta"].get("invocations") or []))
        r["grader_cli"] = dict(Counter((g or {}).get("cli_version") for x in runs for g in x["grades"].values()))
        r["grader_model"] = dict(Counter((g or {}).get("grader_model") for x in runs for g in x["grades"].values()))
        r["grader_prompt"] = dict(Counter((g or {}).get("grader_prompt_version") for x in runs for g in x["grades"].values()))
        r["missing_grade_files"] = [(x["stem"], g) for x in runs for g, v in x["grades"].items() if v is None]
        r["missing_checks"] = [x["stem"] for x in runs if x["checks"] is None]
        r["missing_md"] = [x["stem"] for x in runs if not x["md"]]
        r["grade_harness_invalid"] = [(x["stem"], g) for x in runs for g, v in x["grades"].items()
                                      if v and v.get("harness_invalid")]
        # grade-file problems as recorded by the grader runner
        probs = []
        for x in runs:
            for g, v in x["grades"].items():
                if not v:
                    continue
                for key in ("incomplete", "missing", "duplicates", "invalid", "regraded"):
                    if v.get(key):
                        probs.append((x["stem"], g, key, v[key]))
                ns = [d.get("n") for d in v.get("verdicts") or []]
                if sorted(ns) != sorted(v.get("expected") or []):
                    probs.append((x["stem"], g, "verdict numbers differ from expected", ns, v.get("expected")))
        r["grade_problems"] = probs
        # verdicts over all runs that are valid (none invalid here, checked above)
        vs = Counter()
        per_run_verdicts = {}
        for x in runs:
            if invalid(x["meta"]):
                continue
            n = 0
            for g, v in x["grades"].items():
                for d in (v or {}).get("verdicts") or []:
                    vs[d.get("verdict")] += 1
                    n += 1
            per_run_verdicts[x["stem"]] = (x["meta"]["id"], x["meta"].get("mode"), n)
        r["verdicts"] = dict(vs)
        r["pass"] = vs["PASS"]
        r["total"] = sum(vs.values())
        # runs with fewer verdicts than peers on the same fixture and room
        peers = defaultdict(list)
        for stem, (fid, mode, n) in per_run_verdicts.items():
            peers[(fid, mode)].append((stem, n))
        short = []
        for key, lst in peers.items():
            top = max(n for _, n in lst)
            short += [(s, n, top) for s, n in lst if n < top]
        r["short_verdict_runs"] = short
        r["verdicts_per_fixture_room"] = {f"{k[0]}/{k[1]}": sorted({n for _, n in v}) for k, v in sorted(peers.items())}
        # truthfulness families
        for fam in FAMILY[module]:
            failed = graded = 0
            for x in runs:
                if invalid(x["meta"]):
                    continue
                nums = [i for i, refs in fam_exp[x["meta"]["id"]].items() if refs & set(fam)]
                if not nums:
                    continue
                v1 = {d["n"]: d["verdict"] for d in (x["grades"][1] or {}).get("verdicts") or []}
                v2 = {d["n"]: d["verdict"] for d in (x["grades"][2] or {}).get("verdicts") or []}
                any_fail = any("FAIL" in (v1.get(i), v2.get(i)) for i in nums)
                complete = any(v1.get(i) in ("PASS", "FAIL") and v2.get(i) in ("PASS", "FAIL") for i in nums)
                if complete or any_fail:
                    graded += 1
                    failed += any_fail
            r["truth " + "+".join(fam)] = (failed, graded)
        r["family_expectations"] = {fid: [i for i, refs in m.items() if refs & set(FAMILY[module][0])]
                                    for fid, m in fam_exp.items()}
        # a few raw check counts: failing runs / runs with a finding, per check
        fails, seen = Counter(), Counter()
        for x in runs:
            if invalid(x["meta"]) or not x["checks"]:
                continue
            un = set(x["checks"].get("unchecked") or [])
            names = {f["check"] for f in x["checks"]["checks"]} - un
            for c in names:
                seen[c] += 1
            for c in {f["check"] for f in x["checks"]["checks"] if f.get("verdict") == "FAIL"} - un:
                fails[c] += 1
        r["check_fail_runs"] = dict(sorted(fails.items()))
        r["check_finding_runs"] = dict(sorted(seen.items()))
        res[arm] = r
    out[module] = res

print(json.dumps(out, indent=1, default=str))
print()
for module, res in out.items():
    t, a = res["tuesday"], res["alone"]
    print(f"== {module}: runs {t['runs']} / {a['runs']}; invalid {t['invalid']}/{t['runs']} vs {a['invalid']}/{a['runs']}")
    pt, pa = 100 * t["pass"] / t["total"], 100 * a["pass"] / a["total"]
    print(f"   graded {t['pass']}/{t['total']} ({pt:.2f}%) vs {a['pass']}/{a['total']} ({pa:.2f}%), diff {pt - pa:+.2f}")
    for k in t:
        if k.startswith("truth "):
            (f1, n1), (f2, n2) = t[k], a[k]
            print(f"   {k}: {f1}/{n1} ({100*f1/n1:.1f}%) vs {f2}/{n2} ({100*f2/n2:.1f}%), "
                  f"diff {100*f1/n1-100*f2/n2:+.1f}, p={fisher2(f1, n1, f2, n2):.4f}")
