"""Raw cross-check for 4.3 item 3(b): scan every Tuesday-arm quality stream for a tool call
whose input names a module's installed (suffixed) name, the reader's sign of a hidden reach,
and for a Skill call naming a module by any name. Reads files only."""
import glob, json, os, re, sys
from collections import Counter
ROUND = sys.argv[1]
MODS = ["job-underwriter", "mock-interview", "resume-tailor"]
tot = Counter(); hits = []
for m in ["haiku", "sonnet", "opus"]:
    for f in sorted(glob.glob(f"{ROUND}/{m}/tuesday/part-*/streams/*.jsonl")):
        room = os.path.basename(f).split(".")[0]
        rid = room.rsplit("-", 1)[-1]
        tot[m] += 1
        pat = re.compile(r"(?:%s)-%s" % ("|".join(MODS), re.escape(rid)))
        skill_calls = Counter()
        for line in open(f, errors="replace"):
            try:
                ev = json.loads(line)
            except Exception:
                continue
            if ev.get("type") != "assistant":
                continue
            for it in (ev.get("message") or {}).get("content") or []:
                if it.get("type") != "tool_use":
                    continue
                blob = json.dumps(it.get("input", {}))
                if pat.search(blob):
                    hits.append((m, f, it.get("name"), blob[:200]))
                if it.get("name") == "Skill":
                    sk = (it.get("input") or {}).get("skill", "")
                    base = sk.split(":")[-1].lstrip("/")
                    for mod in MODS:
                        if base == mod or base.startswith(mod + "-"):
                            hits.append((m, f, "Skill", sk))
print("streams scanned", dict(tot), "total", sum(tot.values()))
print("hits", len(hits))
for h in hits[:20]:
    print(h)
