"""Blind re-score of the fix round's sections 4.3 and 4.4 from the routing results JSON.

Recounts every figure from each run's `outcome` (and `reached`, `hub_fired`), never from
the files' own `passed`, `reach`, `explicit` or `reported` summaries; those are compared
afterwards only as a cross-check. Reads files only. Usage:
    python3 -I score_routing.py <round folder> <round-3 folder> <suite-routing.json>
"""
import glob
import json
import math
import os
import statistics
import sys
from collections import Counter

ROUND, R3, SUITE = sys.argv[1:4]
MODELS = ["haiku", "sonnet", "opus"]
MODULES = ["job-underwriter", "mock-interview", "resume-tailor"]
SET_ASIDE = {"timeout", "error", "void"}
HUB_SHA = "4d10c30930488ed3f63067f9dc47651dad6c2874f3a992817f87951332f1ce80"
FD_SHA = "8d10162a0a58e5f99fb39356b473c79952cd8faa5533c4a909cecdd28261af12"
EXTRA = {"haiku": 3, "opus": 10}

suite = {c["id"]: c for c in json.load(open(SUITE))["cases"]}
SINGLE = [i for i, c in suite.items() if c["expected"] in MODULES]
OFF = [i for i, c in suite.items() if c["expected"] == "neither"]
SPAN = [i for i, c in suite.items() if c["expected"] == "either"]
assert SINGLE == [1, 2, 3, 4, 5, 6, 7, 8, 15, 16, 17, 18], SINGLE
assert OFF == [11, 12, 13, 14, 19, 20], OFF
assert SPAN == [9, 10, 21], SPAN


def load(path):
    d = json.load(open(path))
    runs = {}
    for r in d["results"]:
        runs.setdefault(r["id"], []).extend(r["runs"])
        # the case's `fired` list must agree with its runs' outcomes
        assert [x["outcome"] for x in r["runs"]] == r["fired"], (path, r["id"])
    return d, runs


def comb(n, k):
    return math.comb(n, k) if 0 <= k <= n else 0


def fisher_one_sided_greater(a, n1, c, n2):
    """P(X >= a): arm 1 (a of n1) ahead of arm 2 (c of n2), hypergeometric."""
    K, N = a + c, n1 + n2
    tot = comb(N, n1)
    return sum(comb(K, x) * comb(N - K, n1 - x) for x in range(a, min(K, n1) + 1)) / tot


def fisher_two_sided(a, n1, c, n2):
    K, N = a + c, n1 + n2
    tot = comb(N, n1)
    probs = {x: comb(K, x) * comb(N - K, n1 - x) / tot for x in range(max(0, K - n2), min(K, n1) + 1)}
    p0 = probs[a]
    return min(1.0, sum(p for p in probs.values() if p <= p0 * (1 + 1e-7)))


def upper0(n):
    return 1 - 0.05 ** (1 / n)


def upper_k(k, n):
    """One-sided 95% Clopper-Pearson upper bound for k events in n, by bisection."""
    lo, hi = 0.0, 1.0
    for _ in range(200):
        p = (lo + hi) / 2
        cdf = sum(comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k + 1))
        if cdf > 0.05:
            lo = p
        else:
            hi = p
    return hi


def is_hidden_reach(run):
    return run["outcome"].startswith("hidden-") or any(
        str(x).startswith("hidden-") for x in (run.get("reached") or []))


def fired_any(run):
    """A fire through any arm: a module, the hub, or anything but neither (set-aside excluded)."""
    o = run["outcome"]
    return o not in SET_ASIDE and (o != "neither" or bool(run.get("hub_fired"))
                                   or bool(run.get("reached")))


out = {"models": {}}
check_vs_summary = []
for m in MODELS:
    M = {}
    files = {"e0": f"{ROUND}/{m}/e0-personal.json", "e1": f"{ROUND}/{m}/e1-plugin.json",
             "e2": f"{ROUND}/{m}/e2-plugin.json"}
    if m in EXTRA:
        cid = EXTRA[m]
        files["e0x"] = f"{ROUND}/{m}/e0-personal.case{cid}.json"
        files["e1x"] = f"{ROUND}/{m}/e1-plugin.case{cid}.json"
    D, R = {}, {}
    for k, p in files.items():
        D[k], R[k] = load(p)

    # ---- file-level facts, recounted
    fileinfo = {}
    for k in files:
        allruns = [x for rs in R[k].values() for x in rs]
        n = len(allruns)
        sa = Counter(x["outcome"] for x in allruns if x["outcome"] in SET_ASIDE)
        outc = Counter(x["outcome"] for x in allruns)
        refused_calls = sum(len(x["refused"]) for x in allruns if x.get("refused") is not None)
        runs_refused = sum(1 for x in allruns if x.get("refused"))
        refused_unread = sum(1 for x in allruns if x.get("refused") is None)
        toks = [x["output_tokens"] for x in allruns if x.get("output_tokens") is not None]
        secs = [x["seconds"] for x in allruns if x.get("seconds") is not None]
        fi = {
            "file": os.path.basename(files[k]), "model_field": D[k].get("model"),
            "arm": D[k].get("arm"), "layout": D[k].get("layout"),
            "cases": len(R[k]), "runs": n, "runs_per_case": sorted({len(v) for v in R[k].values()}),
            "set_aside": sum(sa.values()), "set_aside_by": dict(sa),
            "set_aside_pct": round(100 * sum(sa.values()) / n, 2),
            "outcomes": dict(outc),
            "unscored_field": D[k].get("unscored"),
            "hub_sha256": D[k].get("hub_sha256"), "frontdoor_sha256": D[k].get("frontdoor_sha256"),
            "hub_sha_ok": (D[k].get("hub_sha256") == HUB_SHA) if D[k].get("arm") == "frontdoor" else None,
            "fd_sha_ok": (D[k].get("frontdoor_sha256") == FD_SHA) if D[k].get("arm") == "frontdoor" else None,
            "hidden_reach_runs": sum(1 for x in allruns if is_hidden_reach(x)),
            "hub_fired_runs": sum(1 for x in allruns if x.get("hub_fired")),
            "hub_path_contact": sum(1 for x in allruns if x.get("hub_path_contact")),
            "hub_path_contact_field_present": sum(1 for x in allruns if "hub_path_contact" in x),
            "skills_root_named": sum(1 for x in allruns if x.get("skills_root_named")),
            "refused_calls": refused_calls, "runs_refused": runs_refused,
            "refused_unread": refused_unread,
            "refused_by_tool": dict(Counter(t for x in allruns for t in (x.get("refused") or []))),
            "output_tokens": sum(toks), "output_tokens_n": len(toks),
            "output_tokens_median": statistics.median(toks) if toks else None,
            "seconds": round(sum(secs), 1), "seconds_n": len(secs),
            "seconds_median": statistics.median(secs) if secs else None,
            "init_has_foreign": None,
        }
        # cross-check against the file's own summaries (read only after recounting)
        rep = D[k].get("reported", {})
        for a, b in (("refused_calls", "refused"), ("runs_refused", "runs_refused"),
                     ("refused_unread", "refused_unread"), ("hub_path_contact", "hub_path_contact"),
                     ("skills_root_named", "skills_root_named"), ("output_tokens", "output_tokens")):
            if rep.get(b) is not None and rep.get(b) != fi[a]:
                check_vs_summary.append(f"{m} {k} {a}: mine {fi[a]} vs file {rep.get(b)}")
        if rep.get("seconds") is not None and abs(rep["seconds"] - fi["seconds"]) > 0.2:
            check_vs_summary.append(f"{m} {k} seconds: mine {fi['seconds']} vs file {rep['seconds']}")
        reach = D[k].get("reach", {})
        if reach and k != "e2":
            dec = n - fi["set_aside"]
            if reach.get("decided") != dec:
                check_vs_summary.append(f"{m} {k} decided mine {dec} vs file {reach.get('decided')}")
            mine_hidden = sum(1 for x in allruns if x["outcome"].startswith("hidden-"))
            if reach.get("hidden") != mine_hidden:
                check_vs_summary.append(f"{m} {k} hidden mine {mine_hidden} vs file {reach.get('hidden')}")
        fileinfo[k] = fi
    M["files"] = fileinfo

    # ---- item 1: set aside <= 10% in every file
    M["item1"] = {k: f"{fi['set_aside']}/{fi['runs']}" for k, fi in fileinfo.items()}
    M["item1_holds"] = all(fi["set_aside"] / fi["runs"] <= 0.10 for fi in fileinfo.values())

    # ---- item 2: explicit commands focused
    e2 = [(cid, x) for cid, rs in R["e2"].items() for x in rs]
    dec2 = [(cid, x) for cid, x in e2 if x["outcome"] not in SET_ASIDE]
    foc = [(cid, x) for cid, x in dec2 if x["outcome"] == "focused"]
    foc_strict = [(cid, x) for cid, x in foc if x.get("loaded") is True and not x.get("reached")]
    M["item2"] = {"focused": len(foc), "decided": len(dec2), "focused_loaded_and_nothing_reached": len(foc_strict),
                  "not_focused": [(cid, x["outcome"], x.get("reached")) for cid, x in dec2 if x["outcome"] != "focused"],
                  "per_case": {cid: f"{sum(1 for x in rs if x['outcome']=='focused')}/{len(rs)}" for cid, rs in R["e2"].items()},
                  "hub_fired": sum(1 for _, x in e2 if x.get("hub_fired")),
                  "hub_fired_runs": [(cid, x["outcome"]) for cid, x in e2 if x.get("hub_fired")]}
    M["item2_holds"] = len(foc) == len(dec2) and len(dec2) > 0

    # ---- item 3(a): hidden reaches in Tuesday routing runs
    tue_keys = ["e1", "e2"] + (["e1x"] if "e1x" in R else [])
    hid = {k: fileinfo[k]["hidden_reach_runs"] for k in tue_keys}
    tue_runs = {k: fileinfo[k]["runs"] for k in tue_keys}
    M["item3a"] = {"hidden_by_file": hid, "runs_by_file": tue_runs,
                   "total": f"{sum(hid.values())}/{sum(tue_runs.values())}"}
    M["item3a_holds"] = sum(hid.values()) == 0
    # e0 hidden check too (should be impossible)
    M["e0_hidden_runs"] = fileinfo["e0"]["hidden_reach_runs"] + (fileinfo["e0x"]["hidden_reach_runs"] if "e0x" in fileinfo else 0)

    # ---- quality sessions for 3(b)
    q_inv = Counter()
    q_meta = 0
    q_nudged = 0
    q_hidden = []
    q_labels = Counter()
    q_cli = Counter()
    for f in sorted(glob.glob(f"{ROUND}/{m}/tuesday/part-*/*.meta.json")):
        d = json.load(open(f))
        q_meta += 1
        for inv in d.get("invocations") or []:
            q_inv[os.path.basename(os.path.dirname(f))] += 1
            q_nudged += bool(inv.get("nudged"))
            lab = inv.get("fire")
            q_labels[(lab, bool(inv.get("nudged")), inv.get("outcome"))] += 1
            if isinstance(lab, str) and lab.startswith("hidden-"):
                q_hidden.append((f, lab))
            q_cli[(inv.get("init") or {}).get("claude_code_version")] += 1
    M["quality"] = {"metas": q_meta, "invocations": sum(q_inv.values()), "by_part": dict(q_inv),
                    "nudged": q_nudged, "labels": {str(k): v for k, v in q_labels.items()},
                    "hidden": q_hidden, "cli": dict(q_cli)}
    M["sessions_3b"] = sum(q_inv.values()) + sum(tue_runs.values())
    M["reaches_3b"] = len(q_hidden) + sum(hid.values())

    # ---- per-case counts this round, standard 5 runs
    def case_counts(runs_by_case, cid):
        rs = runs_by_case.get(cid, [])
        dec = [x for x in rs if x["outcome"] not in SET_ASIDE]
        c = suite[cid]
        if c["expected"] in MODULES:
            good = sum(1 for x in dec if x["outcome"] == c["expected"])
        elif c["expected"] == "either":
            good = sum(1 for x in dec if x["outcome"] in c["siblings"])
        else:
            good = sum(1 for x in dec if not fired_any(x))
        fires = sum(1 for x in dec if fired_any(x))
        return {"good": good, "fires": fires, "decided": len(dec), "runs": len(rs),
                "outcomes": dict(Counter(x["outcome"] for x in rs))}

    per_case = {}
    for cid in sorted(suite):
        per_case[cid] = {"e0": case_counts(R["e0"], cid), "e1": case_counts(R["e1"], cid)}
    M["per_case"] = per_case

    # ---- item 4: off-topic fires through Tuesday
    off_runs = [(cid, x) for cid in OFF for x in R["e1"][cid]]
    off_dec = [(cid, x) for cid, x in off_runs if x["outcome"] not in SET_ASIDE]
    off_fire = [(cid, x["outcome"], x.get("hub_fired"), x.get("reached")) for cid, x in off_dec if fired_any(x)]
    M["item4"] = {"fires": len(off_fire), "decided": len(off_dec), "runs": len(off_runs), "list": off_fire,
                  "e0_fires": sum(1 for cid in OFF for x in R["e0"][cid] if fired_any(x))}
    M["item4_holds"] = len(off_fire) == 0

    # ---- item 5: wrong picks among 60 single-module runs (Tuesday)
    sm = [(cid, x) for cid in SINGLE for x in R["e1"][cid]]
    sm_dec = [(cid, x) for cid, x in sm if x["outcome"] not in SET_ASIDE]
    wrong = [(cid, x["outcome"]) for cid, x in sm_dec if x["outcome"] in MODULES and x["outcome"] != suite[cid]["expected"]]
    other_nonright = Counter(x["outcome"] for cid, x in sm_dec if x["outcome"] not in MODULES)
    later_other = [(cid, x["outcome"], x.get("reached")) for cid, x in sm_dec
                   if any(r in MODULES and r != suite[cid]["expected"] for r in (x.get("reached") or []))]
    wrong_e0 = [(cid, x["outcome"]) for cid in SINGLE for x in R["e0"][cid]
                if x["outcome"] in MODULES and x["outcome"] != suite[cid]["expected"]]
    M["item5"] = {"wrong": len(wrong), "decided": len(sm_dec), "runs": len(sm), "list": wrong,
                  "non_module_outcomes": dict(other_nonright),
                  "runs_reaching_another_playbook_anywhere": later_other, "e0_wrong": len(wrong_e0)}
    M["item5_holds"] = len(wrong) <= 2

    # ---- item 6: right module on single-module cases
    def right(runs_by_case, ids):
        dec = [(cid, x) for cid in ids for x in runs_by_case[cid] if x["outcome"] not in SET_ASIDE]
        return sum(1 for cid, x in dec if x["outcome"] == suite[cid]["expected"]), len(dec)

    r1, n1 = right(R["e1"], SINGLE)
    r0, n0 = right(R["e0"], SINGLE)
    p1, p0 = 100 * r1 / n1, 100 * r0 / n0
    if p0 <= 80:
        rule = "today's <= 80%: Tuesday >= today's + 10 points and >= 60%"
        holds6 = (p1 >= p0 + 10 - 1e-9) and (p1 >= 60 - 1e-9)
    else:
        rule = "today's > 80%: Tuesday >= today's - 5 points"
        holds6 = p1 >= p0 - 5 - 1e-9
    M["item6"] = {"tuesday": f"{r1}/{n1}", "tuesday_pct": round(p1, 2), "today": f"{r0}/{n0}",
                  "today_pct": round(p0, 2), "gap_points": round(p1 - p0, 2), "rule": rule,
                  "p_two_sided_fisher": fisher_two_sided(r1, n1, r0, n0)}
    M["item6_holds"] = holds6

    # ---- item 7: no module starved
    i7 = {}
    holds7 = True
    for mod in MODULES:
        ids = [i for i in SINGLE if suite[i]["expected"] == mod]
        a, na = right(R["e1"], ids)
        b, nb = right(R["e0"], ids)
        pa, pb = 100 * a / na, 100 * b / nb
        ok = pa >= pb - 15 - 1e-9
        holds7 &= ok
        i7[mod] = {"cases": ids, "tuesday": f"{a}/{na}", "today": f"{b}/{nb}",
                   "gap_runs": a - b, "gap_points": round(pa - pb, 2), "holds": ok}
    M["item7"] = i7
    M["item7_holds"] = holds7

    # ---- item 8: spanning
    span_ids = [9, 21] if m == "opus" else [9, 10, 21]

    def span(runs_by_case, ids, key="outcome"):
        dec = [(cid, x) for cid in ids for x in runs_by_case[cid] if x["outcome"] not in SET_ASIDE]
        if key == "outcome":
            g = sum(1 for cid, x in dec if x["outcome"] in suite[cid]["siblings"])
        else:  # any sibling anywhere in the turn (Tuesday arm only has `reached`)
            g = sum(1 for cid, x in dec if x["outcome"] in suite[cid]["siblings"]
                    or any(r in suite[cid]["siblings"] for r in (x.get("reached") or [])))
        return g, len(dec)

    s1, sn1 = span(R["e1"], span_ids)
    s0, sn0 = span(R["e0"], span_ids)
    s1r, _ = span(R["e1"], span_ids, key="reached")
    M["item8"] = {"cases": span_ids, "tuesday": f"{s1}/{sn1}", "today": f"{s0}/{sn0}", "gap_runs": s1 - s0,
                  "tuesday_any_sibling_in_reached": f"{s1r}/{sn1}",
                  "per_case": {cid: {"tuesday": f"{per_case[cid]['e1']['good']}/{per_case[cid]['e1']['decided']}",
                                     "today": f"{per_case[cid]['e0']['good']}/{per_case[cid]['e0']['decided']}"}
                               for cid in [9, 10, 21]}}
    M["item8_holds"] = s1 >= s0 - 2
    if m == "opus":
        # alternative reading: case 10 included in Opus spanning too (not the bar's reading)
        a3, an3 = span(R["e1"], [9, 10, 21])
        b3, bn3 = span(R["e0"], [9, 10, 21])
        M["item8_alt_with_case10"] = {"tuesday": f"{a3}/{an3}", "today": f"{b3}/{bn3}", "holds": a3 >= b3 - 2}

    # ---- 4.4 extra case
    if m in EXTRA:
        cid = EXTRA[m]
        c = suite[cid]
        good_set = c["siblings"] if c["expected"] == "either" else [c["expected"]]

        def pool(std, extra):
            rs = std[cid] + extra[cid]
            dec = [x for x in rs if x["outcome"] not in SET_ASIDE]
            return {"runs": len(rs), "decided": len(dec),
                    "good": sum(1 for x in dec if x["outcome"] in good_set),
                    "any_fire": sum(1 for x in dec if fired_any(x)),
                    "std_good": sum(1 for x in std[cid] if x["outcome"] in good_set),
                    "extra_good": sum(1 for x in extra[cid] if x["outcome"] in good_set),
                    "outcomes": dict(Counter(x["outcome"] for x in rs)),
                    "hub_fired": sum(1 for x in rs if x.get("hub_fired")),
                    "reached": dict(Counter("|".join(x.get("reached") or []) for x in rs)) if "hub_fired" in rs[0] else None}

        t = pool(R["e1"], R["e1x"])
        s = pool(R["e0"], R["e0x"])
        p_today_ahead = fisher_one_sided_greater(s["good"], s["decided"], t["good"], t["decided"])
        p_tue_below = p_today_ahead  # same test, same direction
        X = {"case": cid, "tuesday": t, "today": s,
             "p_one_sided_today_ahead": p_today_ahead,
             "p_two_sided": fisher_two_sided(t["good"], t["decided"], s["good"], s["decided"]),
             "tuesday_upper95": upper_k(t["good"], t["decided"]) if t["good"] else upper0(t["decided"]),
             "today_upper95": upper_k(s["good"], s["decided"]) if s["good"] else upper0(s["decided"])}
        if m == "opus":
            if p_today_ahead < 0.05:
                X["reading"] = 1
            elif s["good"] <= 4 and t["good"] <= 2:
                X["reading"] = 2
            elif t["good"] >= s["good"]:
                X["reading"] = 3
            else:
                X["reading"] = 4
        else:
            if p_tue_below < 0.05:
                X["reading"] = 1
            elif s["good"] <= 5 and t["good"] <= 5:
                X["reading"] = 2
            else:
                X["reading"] = 3
        M["x44"] = X

    out["models"][m] = M

# ---- 3(b) overall
tot_s = sum(out["models"][m]["sessions_3b"] for m in MODELS)
tot_r = sum(out["models"][m]["reaches_3b"] for m in MODELS)
out["item3b"] = {"sessions": tot_s, "reaches": tot_r,
                 "upper95_zero": upper0(tot_s), "upper95_one": upper_k(1, tot_s),
                 "per_model": {m: {"sessions": out["models"][m]["sessions_3b"], "reaches": out["models"][m]["reaches_3b"],
                                   "upper95": upper0(out["models"][m]["sessions_3b"]) if out["models"][m]["reaches_3b"] == 0 else upper_k(out["models"][m]["reaches_3b"], out["models"][m]["sessions_3b"]),
                                   "sessions_without_nudged": out["models"][m]["sessions_3b"] - out["models"][m]["quality"]["nudged"]}
                               for m in MODELS},
                 "holds": tot_r <= 1}
out["item3b"]["sessions_without_nudged"] = tot_s - sum(out["models"][m]["quality"]["nudged"] for m in MODELS)
out["item3b"]["upper95_zero_without_nudged"] = upper0(out["item3b"]["sessions_without_nudged"])

# ---- round 3 per-case comparison
r3 = {}
for m in MODELS:
    base = f"{R3}/claude-{m}-5-5"
    entry = {}
    for k, fn in (("e0", "e0-personal.json"), ("e1", "e1-plugin.json"), ("e2", "e2-plugin.json")):
        d, runs = load(f"{base}/{fn}")
        allr = [x for rs in runs.values() for x in rs]
        entry[k] = {"runs": len(allr), "set_aside": sum(1 for x in allr if x["outcome"] in SET_ASIDE),
                    "outcomes": dict(Counter(x["outcome"] for x in allr)), "model": d.get("model"),
                    "hidden": sum(1 for x in allr if is_hidden_reach(x)),
                    "hub_fired": sum(1 for x in allr if x.get("hub_fired"))}
        if k in ("e0", "e1"):
            pc = {}
            for cid in sorted(suite):
                rs = runs.get(cid, [])
                dec = [x for x in rs if x["outcome"] not in SET_ASIDE]
                c = suite[cid]
                if c["expected"] in MODULES:
                    good = sum(1 for x in dec if x["outcome"] == c["expected"])
                elif c["expected"] == "either":
                    good = sum(1 for x in dec if x["outcome"] in c["siblings"])
                else:
                    good = sum(1 for x in dec if not fired_any(x))
                pc[cid] = {"good": good, "decided": len(dec), "fires": sum(1 for x in dec if fired_any(x)),
                           "runs": len(rs)}
            entry[k]["per_case"] = pc
    r3[m] = entry
out["round3"] = r3

# ---- calibration check of the 4.4 thresholds
cal = {}
for t_ in (0, 1, 2):
    need = next(s_ for s_ in range(0, 51) if fisher_one_sided_greater(s_, 50, t_, 50) < 0.05)
    cal[t_] = {"need": need, "p_at_need": fisher_one_sided_greater(need, 50, t_, 50),
               "p_at_need_minus_1": fisher_one_sided_greater(need - 1, 50, t_, 50)}
out["calibration_44"] = cal
out["summary_crosscheck_mismatches"] = check_vs_summary

json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "scores.json"), "w"), indent=1, default=str)
print("written")
