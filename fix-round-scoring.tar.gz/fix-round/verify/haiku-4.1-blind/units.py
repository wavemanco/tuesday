import re, sys
from math import comb
def fisher(a,n1,b,n2):
    if not n1 or not n2: return None
    k,n=a+b,n1+n2; t=comb(n,k); p=lambda x: comb(n1,x)*comb(n2,k-x)/t; o=p(a)
    return min(1.0,sum(p(x) for x in range(max(0,k-n2),min(k,n1)+1) if p(x)<=o*(1+1e-9)))
V=sys.argv[1]
for part in (1,2,3):
    txt=open(f'{V}/compare_arms.part-{part}.txt').read()
    blk=txt.split('runs with two or more members failing)\n')[1]
    blk=re.split(r'\n  (quotes, re-cut|a quick check|truthfulness:)',blk)[0]
    print(f'== part-{part}')
    for line in blk.splitlines():
        m=re.match(r'  (.+?)\s+(\d+)/(\d+)\s+(\d+)/(\d+)\s+(p[=<]\S+|p n/a)',line)
        if not m: print('UNPARSED',line); continue
        u=m.group(1); a,na,b,nb=map(int,m.group(2,3,4,5))
        gated = na>=10 and nb>=10
        diff = (100*a/na - 100*b/nb) if na and nb else None
        p=fisher(a,na,b,nb)
        miss = gated and diff is not None and diff>=10 and p<0.01
        print(f'{u[:60]:<60} T {a}/{na} ({100*a/na if na else 0:.1f}%)  A {b}/{nb} ({100*b/nb if nb else 0:.1f}%)  diff {diff if diff is None else round(diff,1)}  p {p if p is None else round(p,4)}  printed {m.group(6)}  gated {gated}  {"MISS" if miss else ("holds" if gated else "not gated")}')
