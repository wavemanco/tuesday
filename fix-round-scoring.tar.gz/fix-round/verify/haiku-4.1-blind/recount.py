"""Independent recount of section 4.1 figures for Haiku, from raw files only.

Reads meta/grade/checks JSON and the fixtures' raw evals.json; imports nothing from the repo.
Run: python3 -I recount.py ROUND_DIR WT_DIR
"""
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from math import comb
from pathlib import Path

ROUND = Path(sys.argv[1])
WT = Path(sys.argv[2])
PARTS = {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}
FAMILY = {"job-underwriter": [("proposed_language",), ("proposed_language", "ledger_counts")],
          "mock-interview": [("no_overclaim",)], "resume-tailor": [("row_quote",)]}
REF = re.compile(r"\{\{([a-z0-9_]+)\}\}")
FAILURE_ONLY = {"canary_fixture", "candidate_constraints", "evidence_form", "evidence_map", "format",
                "gates_form", "ledger_markup", "severity_form", "tally_remark"}


def fisher(a, n1, b, n2):
    if not n1 or not n2:
        return None
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    p = lambda x: comb(n1, x) * comb(n2, k - x) / tot
    o = p(a)
    return min(1.0, sum(p(x) for x in range(max(0, k - n2), min(k, n1) + 1) if p(x) <= o * (1 + 1e-9)))


def fixtures(module):
    spec = json.loads((WT / "skills" / module / "evals" / "evals.json").read_text())
    clauses = spec.get("clauses") or {}
    nested = {k: REF.findall(v) for k, v in clauses.items() if REF.findall(v)}
    out = {}
    for case in spec["evals"]:
        exps = case.get("expectations") or []
        out[int(case["id"])] = {
            "n_exp": len(exps),
            "refs": [set(REF.findall(e)) for e in exps],
            "expanded": [REF.sub(lambda m: clauses.get(m.group(1), m.group(0)), e) for e in exps],
        }
    return out, nested


def load_arm(folder):
    runs = []
    for mp in sorted(folder.glob("*.meta.json")):
        stem = mp.name[: -len(".meta.json")]
        meta = json.loads(mp.read_text())
        grades = {}
        gfiles = sorted(folder.glob(stem + ".grade-*.json"))
        for gp in gfiles:
            g = json.loads(gp.read_text())
            grades[int(re.search(r"grade-(\d+)\.json$", gp.name).group(1))] = g
        cp = folder / (stem + ".checks.json")
        checks = json.loads(cp.read_text()) if cp.exists() else None
        md = folder / (stem + ".md")
        runs.append({"stem": stem, "meta": meta, "grades": grades, "checks": checks, "md": md.exists()})
    return runs


def invalid(meta):
    h = meta.get("harness")
    if h:
        return h.get("status", "ok") != "ok"
    return bool(meta.get("error")) or meta.get("skill_fired") is False


def main():
    report = {}
    for part, module in PARTS.items():
        fx, nested = fixtures(module)
        arms = {a: load_arm(ROUND / "haiku" / a / f"part-{part}") for a in ("tuesday", "alone")}
        res = {"nested_clauses": nested}
        for arm, runs in arms.items():
            r = {}
            r["runs"] = len(runs)
            r["invalid"] = sum(invalid(x["meta"]) for x in runs)
            r["no_md"] = sum(not x["md"] for x in runs)
            r["no_checks"] = sum(x["checks"] is None for x in runs)
            r["grade_file_sets"] = {str(k): v for k, v in Counter(tuple(sorted(x["grades"])) for x in runs).items()}
            r["grade_harness_invalid"] = sum(bool(g.get("harness_invalid")) for x in runs for g in x["grades"].values())
            r["nudged"] = sum(x["meta"].get("triggered_unprompted") is False for x in runs)
            r["fire"] = dict(Counter(str(x["meta"].get("fire")) for x in runs))
            r["skill_fired"] = dict(Counter(str(x["meta"].get("skill_fired")) for x in runs))
            r["via_layout_writable"] = dict(Counter(str((x["meta"].get("via"), x["meta"].get("layout"),
                                                     x["meta"].get("room_writable"))) for x in runs))
            r["meta_model"] = dict(Counter(str(x["meta"].get("model")) for x in runs))
            r["invocations_per_run"] = dict(Counter(len(x["meta"].get("invocations") or []) for x in runs))
            cli, initmodel, usage, gcli, gmodel, gver, rundate = Counter(), Counter(), Counter(), Counter(), Counter(), Counter(), Counter()
            for x in runs:
                rundate[x["meta"].get("run_date")] += 1
                for inv in x["meta"].get("invocations") or []:
                    init = inv.get("init") or {}
                    cli[init.get("claude_code_version")] += 1
                    initmodel[init.get("model")] += 1
                    for k in ((inv.get("result") or {}).get("modelUsage") or {}):
                        usage[k] += 1
                for g in x["grades"].values():
                    gcli[g.get("cli_version")] += 1
                    gmodel[g.get("grader_model")] += 1
                    gver[g.get("grader_prompt_version")] += 1
            r.update(cli=dict(cli), init_model=dict(initmodel), result_modelUsage_keys=dict(usage),
                     grader_cli=dict(gcli), grader_model=dict(gmodel), grader_prompt_version=dict(gver),
                     run_date=dict(rundate))
            # verdicts
            vals = Counter()
            per_run_counts = defaultdict(list)
            anomalies = []
            hash_ok = hash_bad = 0
            hash_bad_list = []
            for x in runs:
                fid = int(x["meta"]["id"])
                mode = x["meta"].get("mode")
                for gn, g in x["grades"].items():
                    vs = g.get("verdicts") or []
                    for v in vs:
                        vals[v.get("verdict")] += 1
                    ns = [v.get("n") for v in vs]
                    per_run_counts[(fid, mode)].append((x["stem"], gn, len(vs)))
                    if len(vs) != fx[fid]["n_exp"] or sorted(ns) != list(range(1, fx[fid]["n_exp"] + 1)):
                        anomalies.append((x["stem"], gn, len(vs), fx[fid]["n_exp"]))
                    for key in ("incomplete", "missing", "duplicates", "invalid", "regraded"):
                        if g.get(key):
                            anomalies.append((x["stem"], gn, key, g.get(key)))
                    for n, h in (g.get("expectation_sha256") or {}).items():
                        text = fx[fid]["expanded"][int(n) - 1]
                        if hashlib.sha256(text.encode()).hexdigest() == h:
                            hash_ok += 1
                        else:
                            hash_bad += 1
                            hash_bad_list.append((fid, int(n), "{{date" in text))
            r["verdict_values"] = dict(vals)
            total = sum(vals.values())
            r["graded_pass"] = (vals["PASS"], total)
            r["graded_pass_pf"] = (vals["PASS"], vals["PASS"] + vals["FAIL"])
            r["verdict_anomalies"] = anomalies
            r["verdicts_per_grade_file_by_fixture"] = {
                f"{k[0]}/{k[1]}": sorted(Counter(c for _, _, c in v).items()) for k, v in per_run_counts.items()}
            r["expectation_hash"] = {"match": hash_ok, "mismatch": hash_bad,
                                     "mismatch_kinds": sorted(Counter(hash_bad_list).items())[:20]}
            # truthfulness
            for fam in FAMILY[module]:
                failed = graded = 0
                fam_exps = Counter()
                for x in runs:
                    if invalid(x["meta"]):
                        continue
                    fid = int(x["meta"]["id"])
                    nums = [i + 1 for i, refs in enumerate(fx[fid]["refs"]) if refs & set(fam)]
                    if not nums:
                        continue
                    fam_exps[(fid, tuple(nums))] += 1
                    states = []
                    for n in nums:
                        got = [next((v.get("verdict") for v in (x["grades"].get(gn, {}).get("verdicts") or [])
                                     if v.get("n") == n), None) for gn in (1, 2)]
                        if "FAIL" in got:
                            states.append("fail")
                        elif all(v == "PASS" for v in got):
                            states.append("pass")
                    if states:
                        graded += 1
                        failed += "fail" in states
                r[f"truth[{'+'.join(fam)}]"] = (failed, graded)
                r[f"truth_expectations[{'+'.join(fam)}]"] = sorted(fam_exps.items())
            # checks: raw rows and simple units
            def fails_of(x):
                return [f for f in (x["checks"] or {}).get("checks", []) if f.get("verdict") == "FAIL"]

            def applies(x, check):
                c = x["checks"]
                if c is None or check in (c.get("unchecked") or []):
                    return False
                return check in FAILURE_ONLY or any(f.get("check") == check for f in c.get("checks", []))
            names = sorted({f["check"] for x in runs for f in (x["checks"] or {}).get("checks", [])})
            rows = {}
            for ch in names:
                ap = [x for x in runs if not invalid(x["meta"]) and applies(x, ch)]
                rows[ch] = (sum(any(f["check"] == ch for f in fails_of(x)) for x in ap), len(ap))
            r["check_rows"] = rows
            # family units with simple folds
            def fam_unit(members, anchors, failcond):
                ap = [x for x in runs if not invalid(x["meta"]) and
                      (any(applies(x, m) for m in anchors if m not in FAILURE_ONLY) or failcond(x))]
                return sum(bool(failcond(x)) for x in ap), len(ap)
            r["unit_hard_gates"] = fam_unit(("gates_line", "gates_form"), ("gates_line", "gates_form"),
                                            lambda x: any(f["check"] in ("gates_line", "gates_form") for f in fails_of(x)))
            r["unit_severity"] = fam_unit(("severity", "severity_form"), ("severity", "severity_form"),
                                          lambda x: any(f["check"] in ("severity", "severity_form") for f in fails_of(x)))
            r["unit_call_none_belongs"] = fam_unit(("zero_calls",), ("zero_calls",),
                                                   lambda x: any(f["check"] == "zero_calls" for f in fails_of(x)))
            NO_TABLE = ("the response has no accounting table", "the accounting table could not be read")
            r["unit_no_table"] = fam_unit(("row", "tally"), ("row", "tally"),
                                          lambda x: any(f["check"] == "row" and str(f.get("why", "")).startswith(NO_TABLE)
                                                        for f in fails_of(x)))
            claim = {"snapshot_count": re.compile(r'^the snapshot\'s prose: "(.+?)" is '),
                     "ledger_sentence": re.compile(r'^in the sentence after the ledger, "(.+?)" is ')}

            def claims(x):
                seen = defaultdict(set)
                for f in fails_of(x):
                    pat = claim.get(f["check"])
                    if pat and (m := pat.match(str(f.get("why", "")))):
                        seen[m.group(1)].add(f["check"])
                return {k for k, v in seen.items() if len(v) == 2}
            r["unit_one_claim"] = fam_unit((), ("snapshot_count", "ledger_sentence"), lambda x: bool(claims(x)))

            # residual ledger_sentence / snapshot_count: fails not absorbed by one-claim fold
            def residual(ch):
                pat = claim[ch]
                ap = [x for x in runs if not invalid(x["meta"]) and applies(x, ch)]
                n = 0
                for x in ap:
                    cl = claims(x)
                    for f in fails_of(x):
                        if f["check"] != ch:
                            continue
                        m = pat.match(str(f.get("why", "")))
                        if not (m and m.group(1) in cl):
                            n += 1
                            break
                return n, len(ap)
            if "ledger_sentence" in names:
                r["unit_ledger_sentence_residual"] = residual("ledger_sentence")
                r["unit_snapshot_count_residual"] = residual("snapshot_count")
            # residual tally: tally fails when no no-table row fail
            ap = [x for x in runs if not invalid(x["meta"]) and applies(x, "tally")]
            r["unit_tally_residual"] = (sum(any(f["check"] == "tally" for f in fails_of(x)) and not any(
                f["check"] == "row" and str(f.get("why", "")).startswith(NO_TABLE) for f in fails_of(x)) for x in ap), len(ap))
            res[arm] = r
        report[module] = res
    print(json.dumps(report, indent=1, default=str))


main()
