"""Independent recount of the section 4.2 measures from raw .meta.json and .checks.json files.

Reads only; writes nothing. Does not import any repository module.
Usage: python3 -I recount.py <round folder>
"""
import glob
import json
import os
import sys

ROUND = sys.argv[1]
REPORTING = ("tally_searches", "tally_fetches", "skip_has_no_call", "off_target_shown", "row", "tally")
SECOND = "more than one sentence after the ledger"


def runs(model, arm, part):
    out = []
    for mp in sorted(glob.glob(os.path.join(ROUND, model, arm, f"part-{part}", "*.meta.json"))):
        meta = json.load(open(mp))
        stem = os.path.basename(mp)[: -len(".meta.json")]
        cp = mp[: -len(".meta.json")] + ".checks.json"
        checks = json.load(open(cp)) if os.path.exists(cp) else None
        out.append({"stem": stem, "meta": meta, "checks": checks, "arm": arm})
    return out


def finds(r, name):
    if r["checks"] is None:
        return []
    return [f for f in r["checks"].get("checks") or [] if f.get("check") == name]


def valid(r):
    return (r["meta"].get("harness") or {}).get("status") == "ok"


def measures(rs):
    ju = [r for r in rs if valid(r) and r["meta"].get("skill") == "job-underwriter"]
    ls_applied = [r for r in ju if finds(r, "ledger_sentence")
                  and "ledger_sentence" not in (r["checks"].get("unchecked") or [])]
    no_count = [r for r in ls_applied if any("sentences" not in f for f in finds(r, "ledger_sentence"))]
    h1 = sum(any((f.get("sentences") or 0) > 1 for f in finds(r, "ledger_sentence")) for r in ls_applied)
    setc = sum(any(f.get("verdict") == "FAIL" and not str(f.get("why", "")).startswith(SECOND)
                   for f in finds(r, "ledger_sentence")) for r in ls_applied)
    # any FAIL at all, and FAIL whose reason is the second sentence, for context
    ls_fail = sum(any(f.get("verdict") == "FAIL" for f in finds(r, "ledger_sentence")) for r in ls_applied)
    present = sum(any(f.get("verdict") == "PASS" for f in finds(r, "ledger_present")) for r in ju)
    form_applied = [r for r in ju if finds(r, "ledger_sentence_form")
                    and "ledger_sentence_form" not in (r["checks"].get("unchecked") or [])]
    form = sum(all(f.get("verdict") == "PASS" for f in finds(r, "ledger_sentence_form")) for r in form_applied)
    out = {
        "H1 sentences>1": (h1, len(ls_applied)),
        "ledger_sentence any FAIL": (ls_fail, len(ls_applied)),
        "set claims": (setc, len(ls_applied)),
        "ledger_present PASS": (present, len(ju)),
        "list form PASS": (form, len(form_applied)),
        "ls findings lacking sentences": (len(no_count), len(ls_applied)),
    }
    called_total, called_ok, calls_sum, calls_n = 0, 0, 0, 0
    called_ok_by_fix = {}
    for skill, fid in (("job-underwriter", 5), ("mock-interview", 8)):
        on = [r for r in rs if valid(r) and r["meta"].get("skill") == skill and r["meta"].get("id") == fid]
        zc = [r for r in on if finds(r, "zero_calls")]
        fail = [r for r in zc if any(f.get("verdict") == "FAIL" for f in finds(r, "zero_calls"))]
        qc = [r for r in zc if any(f.get("quick_check") for f in finds(r, "zero_calls"))]
        out[f"{skill} eval {fid} zero_calls FAIL"] = (len(fail), len(zc))
        out[f"{skill} eval {fid} quick check"] = (len(qc), len(zc))
        out[f"{skill} eval {fid} runs on fixture"] = (len(on), len(on))
        # calls: from the research_log (user_links are empty for both fixtures), and cross-checked
        # against the 'calls' that zero_calls records
        mismatch = 0
        fx_called, fx_ok = 0, 0
        for r in on:
            log = r["meta"].get("research_log")
            if log is None:
                continue
            n = len([e for e in log if isinstance(e, dict)])
            zcalls = [f.get("calls") for f in finds(r, "zero_calls") if "calls" in f]
            if zcalls and zcalls[0] != n:
                mismatch += 1
            calls_sum += n
            calls_n += 1
            if n:
                fx_called += 1
                bad = [f for f in r["checks"].get("checks") or []
                       if f.get("check") in REPORTING and f.get("verdict") == "FAIL"]
                if not bad:
                    fx_ok += 1
        called_total += fx_called
        called_ok += fx_ok
        out[f"{skill} eval {fid} every call reported"] = (fx_ok, fx_called)
        out[f"{skill} eval {fid} research_log vs zero_calls.calls mismatches"] = (mismatch, len(on))
    out["every call reported (both fixtures)"] = (called_ok, called_total)
    out["calls per run"] = (calls_sum, calls_n)
    return out


def main():
    result = {}
    for model in ("haiku", "sonnet", "opus"):
        per = {}
        for arm in ("tuesday", "alone"):
            rs = runs(model, arm, 1) + runs(model, arm, 2)
            per[arm] = (rs, measures(rs))
        pooled = measures(per["tuesday"][0] + per["alone"][0])
        print(f"== {model}")
        for k in pooled:
            p, t, a = pooled[k], per["tuesday"][1][k], per["alone"][1][k]
            print(f"  {k:<66} pooled {p[0]:>4}/{p[1]:<4} tuesday {t[0]:>4}/{t[1]:<4} alone {a[0]:>4}/{a[1]:<4}")
        result[model] = {"pooled": pooled, "tuesday": per["tuesday"][1], "alone": per["alone"][1]}
        nudged = [r["stem"] + "@" + r["arm"] for arm in ("tuesday", "alone") for r in per[arm][0]
                  if r["meta"].get("triggered_unprompted") is False]
        print(f"  nudged runs in parts 1-2: {nudged}")
    json.dump({m: {k: {kk: list(vv) for kk, vv in v.items()} for k, v in d.items()} for m, d in result.items()},
              sys.stdout if False else open(os.devnull, "w"))


main()
