"""Section 4.2 tests: compare_arms.fisher (taken verbatim from the measured commit's source by ast,
so nothing else of the module is imported), the plan's example thresholds, and the round's
figures against the baselines. Reads only. Usage: python3 -I -B tests.py <compare_arms.py>"""
import ast
import sys
from math import comb

src = open(sys.argv[1]).read()
tree = ast.parse(src)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "fisher")
ns = {"comb": comb}
exec(compile(ast.Module(body=[fn], type_ignores=[]), "fisher", "exec"), ns)
fisher = ns["fisher"]


def own_fisher(a, n1, b, n2):
    """An independent exact two-sided Fisher (sum of tables no likelier than observed)."""
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    pr = {x: comb(n1, x) * comb(n2, k - x) / tot for x in range(max(0, k - n2), min(k, n1) + 1)}
    obs = pr[a]
    return min(1.0, sum(v for v in pr.values() if v <= obs * (1 + 1e-7)))


def check_same(a, n1, b, n2):
    p, q = fisher(a, n1, b, n2), own_fisher(a, n1, b, n2)
    assert abs(p - q) < 1e-12, (a, n1, b, n2, p, q)
    return p


def fall(x, n, b, m):
    return x * m < b * n and check_same(x, n, b, m) < 0.01


def rise(x, n, b, m):
    return x * m > b * n and check_same(x, n, b, m) < 0.01


def thr_fall_holds(n, b, m):
    """Smallest x of n at which a fall is NOT significant (guard holds from there up)."""
    return min(x for x in range(n + 1) if not fall(x, n, b, m))


def thr_rise_holds(n, b, m):
    """Largest x of n at which a rise is NOT significant (guard holds up to there)."""
    return max(x for x in range(n + 1) if not rise(x, n, b, m))


def max_fall(n, b, m):
    """Largest x of n that is a significant fall (improved at most x)."""
    xs = [x for x in range(n + 1) if fall(x, n, b, m)]
    return max(xs) if xs else None


def min_rise(n, b, m):
    xs = [x for x in range(n + 1) if rise(x, n, b, m)]
    return min(xs) if xs else None


print("== plan's example thresholds, at the plan's expected counts, by compare_arms.fisher, p < 0.01")
ex = [
    ("ledger_present guard holds from, Sonnet/Opus (base 80/80, of 80)", thr_fall_holds(80, 80, 80), 73),
    ("ledger_present guard holds from, Haiku (base 48/80, of 160)", thr_fall_holds(160, 48, 80), 68),
    ("set-claim guard holds up to, Sonnet/Opus (base 2/80, of 80)", thr_rise_holds(80, 2, 80), 11),
    ("set-claim guard holds up to, Haiku (base 9/47, of 95)", thr_rise_holds(95, 9, 47), 39),
    ("H1 improved at most, Sonnet (base 31/80, of 80)", max_fall(80, 31, 80), 15),
    ("H1 improved at most, Opus (base 65/80, of 80)", max_fall(80, 65, 80), 49),
    ("H1 improved at most, Haiku (base 35/47, of 95)", max_fall(95, 35, 47), 48),
    ("H1 worse at least, Sonnet (base 31/80, of 80)", min_rise(80, 31, 80), 49),
    ("H1 worse at least, Opus (base 65/80, of 80)", min_rise(80, 65, 80), 77),
    ("H1 worse at least, Haiku (base 35/47, of 95)", min_rise(95, 35, 47), 87),
    ("eval 5 improved at most, Haiku (base 12/20, of 40)", max_fall(40, 12, 20), 9),
    ("eval 8 worse at least (base 0/20, of 40)", min_rise(40, 0, 20), 12),
]
for label, got, plan in ex:
    print(f"  {label:<70} test {got!s:>4}  plan {plan:>4}  {'match' if got == plan else 'MISMATCH'}")
# the p-values at the edges
edges = [(72, 80, 80, 80), (73, 80, 80, 80), (67, 160, 48, 80), (68, 160, 48, 80), (11, 80, 2, 80), (12, 80, 2, 80),
         (39, 95, 9, 47), (40, 95, 9, 47), (15, 80, 31, 80), (16, 80, 31, 80), (49, 80, 65, 80), (50, 80, 65, 80),
         (48, 95, 35, 47), (49, 95, 35, 47), (48, 80, 31, 80), (49, 80, 31, 80), (76, 80, 65, 80), (77, 80, 65, 80),
         (86, 95, 35, 47), (87, 95, 35, 47), (9, 40, 12, 20), (10, 40, 12, 20), (11, 40, 0, 20), (12, 40, 0, 20)]
print("  edge p-values: " + "; ".join(f"{a}/{n1} v {b}/{n2} p={check_same(a, n1, b, n2):.4g}" for a, n1, b, n2 in edges))

print()
print("== the round's figures (pooled over arms) against the baselines")
# (model, item, round count, round n, base count, base n, direction)
rows = [
    ("sonnet", "H1 sentences above one", 0, 79, 31, 80, "fall=improved / rise=worse"),
    ("haiku", "H1 sentences above one", 60, 82, 35, 47, "fall=improved / rise=worse"),
    ("opus", "H1 sentences above one", 11, 79, 65, 80, "fall=improved / rise=worse"),
    ("sonnet", "guard ledger_present (broken on a fall)", 79, 80, 80, 80, "fall"),
    ("haiku", "guard ledger_present (broken on a fall)", 82, 160, 48, 80, "fall"),
    ("opus", "guard ledger_present (broken on a fall)", 79, 80, 80, 80, "fall"),
    ("sonnet", "guard set claims (broken on a rise)", 1, 79, 2, 80, "rise"),
    ("haiku", "guard set claims (broken on a rise)", 6, 82, 9, 47, "rise"),
    ("opus", "guard set claims (broken on a rise)", 3, 79, 2, 80, "rise"),
    ("sonnet", "eval 5 beyond a quick check (improved on a fall; not read for worse)", 1, 20, 2, 20, "fall"),
    ("haiku", "eval 5 beyond a quick check (improved on a fall; not read for worse)", 21, 40, 12, 20, "fall"),
    ("opus", "eval 5 beyond a quick check (improved on a fall; not read for worse)", 1, 20, 2, 20, "fall"),
    ("sonnet", "eval 8 beyond a quick check (worse on a rise)", 0, 40, 0, 20, "rise"),
    ("haiku", "eval 8 beyond a quick check (worse on a rise)", 1, 40, 0, 20, "rise"),
    ("opus", "eval 8 beyond a quick check (worse on a rise)", 0, 40, 0, 20, "rise"),
    ("sonnet", "every call reported (reported; target 1 is a fixed 1-in-10)", 20, 20, 19, 19, "-"),
    ("haiku", "every call reported (reported; target 1 is a fixed 1-in-10)", 33, 43, 17, 20, "-"),
    ("opus", "every call reported (reported; target 1 is a fixed 1-in-10)", 18, 20, 14, 14, "-"),
]
for m, item, x, n, b, bn, d in rows:
    p = check_same(x, n, b, bn)
    tags = []
    if fall(x, n, b, bn):
        tags.append("significant FALL")
    if rise(x, n, b, bn):
        tags.append("significant RISE")
    print(f"  {m:<7}{item:<74} {x}/{n} ({100 * x / n:.1f}%) v base {b}/{bn} ({100 * b / bn:.1f}%)  p={p:.4g}  "
          f"{', '.join(tags) or 'no significant change'}")

print()
print("== thresholds at the round's actual denominators")
act = [
    ("sonnet H1 improved at most / worse at least (of 79, base 31/80)", max_fall(79, 31, 80), min_rise(79, 31, 80)),
    ("opus H1 improved at most / worse at least (of 79, base 65/80)", max_fall(79, 65, 80), min_rise(79, 65, 80)),
    ("haiku H1 improved at most / worse at least (of 82, base 35/47)", max_fall(82, 35, 47), min_rise(82, 35, 47)),
    ("sonnet/opus ledger_present holds from (of 80, base 80/80)", thr_fall_holds(80, 80, 80), None),
    ("haiku ledger_present holds from (of 160, base 48/80)", thr_fall_holds(160, 48, 80), None),
    ("sonnet/opus set claims hold up to (of 79, base 2/80)", thr_rise_holds(79, 2, 80), None),
    ("haiku set claims hold up to (of 82, base 9/47)", thr_rise_holds(82, 9, 47), None),
    ("haiku eval 5 improved at most (of 40, base 12/20)", max_fall(40, 12, 20), None),
    ("eval 8 worse at least (of 40, base 0/20)", min_rise(40, 0, 20), None),
]
for label, a, b in act:
    print(f"  {label:<70} {a}{'' if b is None else f' / {b}'}")
