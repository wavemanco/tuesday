"""Reported-not-gated digest for the fix round: reads saved files only, calls no model."""
import sys
sys.dont_write_bytecode = True
import json, re, collections
from pathlib import Path

R = Path('/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round')
sys.path.insert(0, str(R / 'wt-text' / 'evals'))
import compare_arms as ca  # noqa: E402
import output_checks  # noqa: E402

MODELS = ('haiku', 'sonnet', 'opus')
PARTS = {1: 'job-underwriter', 2: 'mock-interview', 3: 'resume-tailor'}
ARMS = ('tuesday', 'alone')
CASES = ca.fixture_cases()

data = {}
for m in MODELS:
    for p, mod in PARTS.items():
        t = [r for r in ca.load(R / m / 'tuesday' / f'part-{p}', None, CASES) if r['meta_read']]
        a = [r for r in ca.load(R / m / 'alone' / f'part-{p}', None, CASES) if r['meta_read']]
        ca.expect_graders(t, a)
        data[(m, p)] = {'tuesday': t, 'alone': a}

section = sys.argv[1] if len(sys.argv) > 1 else 'all'


def out(*x):
    print(*x)


def fx(a, n1, b, n2):
    return ca.pval(ca.fisher(a, n1, b, n2))


if section in ('all', 'nudged'):
    out('== nudged runs, stems')
    for (m, p), d in data.items():
        for arm in ARMS:
            st = [r['stem'] for r in d[arm] if r['valid'] and r['nudged']]
            if st:
                out(m, PARTS[p], arm, len(st), st)

if section in ('all', 'refused'):
    out('== refused per tool, per model and arm, pooled over modules (graded invocation); runs with any refusal')
    for m in MODELS:
        for arm in ARMS:
            tools = collections.Counter(); runs_by_tool = collections.Counter(); n = 0; anyr = 0; saves = 0
            for p in PARTS:
                for r in data[(m, p)][arm]:
                    if not r['valid'] or r['refused'] is None:
                        continue
                    n += 1
                    anyr += bool(r['refused'])
                    saves += bool(r['save_refused'])
                    for tool, k in r['refused'].items():
                        tools[tool] += k
                        runs_by_tool[tool] += 1
            out(m, arm, f'runs read {n}, with a refusal {anyr}, save refused {saves}; calls by tool {dict(tools)}; runs by tool {dict(runs_by_tool)}')

if section in ('all', 'units'):
    out('== check rows and units applied in fewer than 10 runs in an arm')
    for (m, p), d in data.items():
        a = [r for r in d['tuesday'] if r['valid']]; c = [r for r in d['alone'] if r['valid']]
        only = ca.failure_only(a + c)
        for check in ca.check_names(a + c):
            if check in output_checks.REPORTED:
                continue
            fa, na = ca.check_counts(a, check, only); fc, nc = ca.check_counts(c, check, only)
            if na < 10 or nc < 10:
                out(f'  check {m} {PARTS[p]} {check}: tuesday {fa}/{na} alone {fc}/{nc}')
        present = set(ca.check_names(a + c)) - output_checks.REPORTED
        fams = {name: (mem, via) for name, mem, via, _ in ca.FAMILIES if present & set(via)}
        for unit in [*fams, *sorted(present)]:
            mem, via = fams.get(unit, ((unit,), (unit,)))
            fa, na, _ = ca.unit_counts(a, unit, via, only); fc, nc, _ = ca.unit_counts(c, unit, via, only)
            if (na < 10 or nc < 10):
                out(f'  unit  {m} {PARTS[p]} {unit}: tuesday {fa}/{na} alone {fc}/{nc}' + ('' if (fa or fc or unit in fams) else '  (not printed by compare_arms: no failure)'))
    out('-- canary / canary_absent / user_link canary FAIL findings, all sets')
    for (m, p), d in data.items():
        for arm in ARMS:
            for r in d[arm]:
                for f in r['checks'] or []:
                    if 'canary' in f['check'] and f['verdict'] == 'FAIL':
                        out(f'  {m} {arm} {r["stem"]} mode={r["mode"]} {f["check"]} t{f.get("target")}: {f["why"][:200]}')
    cnt = collections.Counter()
    for (m, p), d in data.items():
        for arm in ARMS:
            for r in d[arm]:
                for f in r['checks'] or []:
                    if 'canary' in f['check']:
                        cnt[(m, arm, r['mode'], f['check'], f['verdict'])] += 1
    for k, v in sorted(cnt.items()):
        out('  ', k, v)

if section in ('all', 'expect'):
    out('== expectation gaps (runs passing every grader), |diff| >= 3 of 10 (or 2 of 5) or p < 0.1')
    for (m, p), d in data.items():
        a = [r for r in d['tuesday'] if r['valid']]; c = [r for r in d['alone'] if r['valid']]
        keys = sorted({(r['id'], r['mode'] or '', n) for r in a + c for n in ca.expectation_states(r)},
                      key=lambda k: (k[0], k[1], k[2]))
        rows = []
        for fid, mode, n in keys:
            def tally(rs):
                st = [ca.expectation_states(r).get(n) for r in rs if r['id'] == fid and (r['mode'] or '') == mode]
                return sum(s == 'pass' for s in st), sum(s in ('pass', 'fail') for s in st)
            ta, tc = tally(a), tally(c)
            if not ta[1] or not tc[1]:
                continue
            diff = ta[0] / ta[1] - tc[0] / tc[1]
            pv = ca.fisher(ta[0], ta[1], tc[0], tc[1])
            clauses = CASES.get((PARTS[p], fid), {}).get('clause_refs') or []
            cl = clauses[n - 1] if n - 1 < len(clauses) else []
            rows.append((pv, diff, fid, mode, n, ta, tc, cl))
        big = [x for x in rows if abs(x[1]) >= 0.3 or (x[0] is not None and x[0] < 0.1)]
        big.sort(key=lambda x: (x[0], -abs(x[1])))
        out(f'-- {m} {PARTS[p]}: {len(rows)} expectation rows; {sum(1 for x in rows if x[0] < 0.05)} with p<0.05 '
            f'({sum(1 for x in rows if x[0] < 0.05 and x[1] > 0)} favour tuesday, {sum(1 for x in rows if x[0] < 0.05 and x[1] < 0)} favour alone)')
        for pv, diff, fid, mode, n, ta, tc, cl in big:
            out(f'   f{fid} [{mode}] #{n} tuesday {ta[0]}/{ta[1]} alone {tc[0]}/{tc[1]} {ca.pval(pv)} {"+" if diff>0 else ""}{100*diff:.0f}pts clauses={cl}')

if section in ('all', 'low'):
    out('== runs with fewer than 40% of graded verdicts passing (both graders pooled)')
    for (m, p), d in data.items():
        for arm in ARMS:
            for r in d[arm]:
                vs = [v for g in r['grades'].values() for v in g.values()]
                if not vs:
                    out(f'  {m} {PARTS[p]} {arm} {r["stem"]}: NO VERDICTS')
                    continue
                share = sum(v == 'PASS' for v in vs) / len(vs)
                if share < 0.4:
                    out(f'  {m} {PARTS[p]} {arm} {r["stem"]}: {sum(v=="PASS" for v in vs)}/{len(vs)} ({100*share:.0f}%) nudged={r["nudged"]}')
    out('-- distribution: runs below 50% and 60% per model/module/arm')
    for (m, p), d in data.items():
        row = []
        for arm in ARMS:
            sh = []
            for r in d[arm]:
                vs = [v for g in r['grades'].values() for v in g.values()]
                sh.append(sum(v == 'PASS' for v in vs) / len(vs) if vs else 0)
            row.append(f'{arm} <40% {sum(s<0.4 for s in sh)}/{len(sh)} <50% {sum(s<0.5 for s in sh)} <60% {sum(s<0.6 for s in sh)}')

        out(f'  {m} {PARTS[p]}: ' + '; '.join(row))

if section in ('all', 'watch'):
    out('== watch_out: runs whose chat finding passes (exact last line) / runs where watch_out applied; file findings')
    for m in MODELS:
        for arm in ARMS:
            tot = [0, 0]; per = []
            files_fail = []; files_seen = 0; reasons = collections.Counter()
            for p in PARTS:
                ok = n = 0
                for r in data[(m, p)][arm]:
                    if not r['valid'] or r['checks'] is None or 'watch_out' in r['unchecked']:
                        continue
                    w = [f for f in r['checks'] if f['check'] == 'watch_out']
                    if not w:
                        continue
                    n += 1
                    chat = [f for f in w if f.get('target') == 'chat']
                    if all(f['verdict'] == 'PASS' for f in w):
                        ok += 1
                    for f in w:
                        if f.get('target') != 'chat':
                            files_seen += 1
                            if f['verdict'] == 'FAIL':
                                files_fail.append((r['stem'], f['target'], f['why'][:100]))
                        elif f['verdict'] == 'FAIL':
                            reasons[f['why'][:70]] += 1
                            per.append((r['stem'], f['why'][:160]))
                tot[0] += ok; tot[1] += n
                out(f'  {m} {arm} {PARTS[p]}: all watch_out findings pass {ok}/{n}')
            out(f'  {m} {arm} POOLED: {tot[0]}/{tot[1]} ({100*tot[0]/tot[1]:.1f}%); file findings {files_seen}, failing {len(files_fail)} {files_fail}')
            for s, w in per:
                out(f'     chat FAIL {s}: {w}')

if section in ('all', 'traces'):
    out('== resume-tailor traces')
    for m in MODELS:
        for arm in ARMS:
            rs = [r for r in data[(m, 3)][arm] if r['valid']]
            fails = []; cells = collections.Counter(); verdicts = collections.Counter(); applied = 0
            for r in rs:
                tf = [f for f in r['checks'] or [] if f['check'] == 'traces']
                if tf:
                    applied += 1
                for f in tf:
                    verdicts[f['verdict']] += 1
                    if f['verdict'] == 'FAIL':
                        fails.append((r['stem'], f.get('target'), f['why'][:220]))
                for i in (json.load(open(R / m / arm / 'part-3' / f'{r["stem"]}.checks.json')).get('info') or []):
                    if 'trace' in i.lower() or 'Traces' in i:
                        cells[i[:90]] += 1
            out(f'  {m} {arm}: runs with traces findings {applied}/{len(rs)}; findings {dict(verdicts)}; failing runs {len({s for s,_,_ in fails})}')
            for x in fails:
                out('     FAIL', x)
            for k, v in cells.most_common(4):
                out('     info', v, k)

if section in ('all', 'closing'):
    from fixture_clauses import clause_refs
    out('== resume-tailor closing-block verdicts ({{closing}} clause)')
    refs = clause_refs(R / 'wt-text' / 'skills' / 'resume-tailor' / 'evals' / 'evals.json')
    for m in MODELS:
        for arm in ARMS:
            c = collections.Counter(); runs_fail_real = set(); runs_fail_any = set(); runs = set(); ex = []
            for r in data[(m, 3)][arm]:
                nums = [i for i, names in enumerate(refs.get(r['id'], []), 1) if 'closing' in names]
                for g in sorted((R / m / arm / 'part-3').glob(f'{r["stem"]}.grade-*.json')):
                    d = json.load(open(g))
                    for v in d['verdicts']:
                        if v['n'] in nums and v.get('verdict') in ('PASS', 'FAIL'):
                            c['n'] += 1; runs.add(r['stem'])
                            if v['verdict'] == 'FAIL':
                                c['fail'] += 1; runs_fail_any.add(r['stem'])
                                if re.search('harness', v['why'], re.I):
                                    c['fail_cites_harness'] += 1
                                else:
                                    c['fail_real'] += 1; runs_fail_real.add(r['stem']); ex.append((g.name, v['n'], v['why'][:260]))
            out(f'  {m} {arm}: verdicts {dict(c)}; runs with a closing FAIL {len(runs_fail_any)}/{len(runs)}; runs with a non-harness FAIL {len(runs_fail_real)}/{len(runs)}')
            for e in ex:
                out('     ', e)

if section in ('all', 'mi5'):
    out('== mock-interview eval 5: rows written skipped where unavailable is required')
    for m in MODELS:
        for arm in ARMS:
            rs = [r for r in data[(m, 2)][arm] if r['valid'] and r['id'] == 5]
            hits = []
            for r in rs:
                for f in r['checks'] or []:
                    if f['verdict'] == 'FAIL' and f['check'] in ('accept', 'skip_has_no_call', 'vocabulary', 'row') and 'skipped' in f['why']:
                        hits.append((r['stem'], f['check'], f.get('target'), f['why'][:200]))
            out(f'  {m} {arm}: runs {len({h[0] for h in hits})}/{len(rs)}')
            for h in hits:
                out('     ', h)

if section in ('all', 'form'):
    out('== ledger_sentence_form: list form vs no sentence')
    for m in MODELS:
        for arm in ARMS:
            rs = [r for r in data[(m, 1)][arm] if r['valid'] and ca.applies(r, 'ledger_sentence_form', set())]
            lst = nos = fail = 0
            for r in rs:
                f = [x for x in r['checks'] if x['check'] == 'ledger_sentence_form']
                if all(x['verdict'] == 'PASS' for x in f):
                    if any('no sentence' in x['why'] for x in f):
                        nos += 1
                    else:
                        lst += 1
                else:
                    fail += 1
            out(f'  {m} {arm}: applied {len(rs)}; list form {lst}; no sentence {nos}; not the form {fail}')

if section in ('all', 'calls'):
    out('== calls: both fixtures (JU eval 5, MI eval 8) per arm; quick checks by fixture')
    for m in MODELS:
        for arm in ARMS:
            sent = []
            for p, fid in ((1, 5), (2, 8)):
                sent += [r for r in data[(m, p)][arm] if r['valid'] and r['id'] == fid and r['calls'] is not None]
            called = [r for r in sent if r['calls']]
            rep = sum(not any(f.get('check') in ca.REPORTS_CALLS for f in ca.failing(r)) for r in called)
            out(f'  {m} {arm}: calls {sum(r["calls"] for r in sent)}/{len(sent)} runs = {sum(r["calls"] for r in sent)/len(sent):.2f}; '
                f'runs sending a call {len(called)}; reporting every call {rep}/{len(called)}')
            for p, fid in ((1, 5), (2, 8)):
                on = [r for r in data[(m, p)][arm] if r['valid'] and r['id'] == fid and r['calls'] is not None]
                out(f'      {PARTS[p]} eval {fid}: calls {sum(r["calls"] for r in on)}/{len(on)}; by mode '
                    + str({mode: sum(r['calls'] for r in on if r['mode'] == mode) for mode in ('canned', 'denied')}))
        for p in (1, 2):
            for fid in sorted({r['id'] for arm in ARMS for r in data[(m, p)][arm] if r['declares_quick_check']}):
                row = []
                for arm in ARMS:
                    ran = [r for r in data[(m, p)][arm] if r['id'] == fid and r['checks'] is not None and r['calls'] is not None]
                    by = {mode: (sum(r['quick_check'] for r in ran if r['mode'] == mode), sum(1 for r in ran if r['mode'] == mode)) for mode in ('canned', 'denied')}
                    row.append(f'{arm} {sum(r["quick_check"] for r in ran)}/{len(ran)} {by}')
                out(f'   quick check {m} {PARTS[p]} eval {fid}: ' + '; '.join(row))
