"""Section 4.3 reported items from saved routing results; reads files only."""
import json, collections, sys
from pathlib import Path

S = Path('/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad')
R = S / 'fixround' / 'round'
M17 = S / 'm17'
MODELS = ('haiku', 'sonnet', 'opus')
cases = {c['id']: c for c in json.load(open(R / 'wt-text' / 'evals' / 'suite-routing.json'))['cases']} \
    if isinstance(json.load(open(R / 'wt-text' / 'evals' / 'suite-routing.json')), dict) else \
    {c['id']: c for c in json.load(open(R / 'wt-text' / 'evals' / 'suite-routing.json'))}

HUB = ('4d10c30930488ed3f63067f9dc47651dad6c2874f3a992817f87951332f1ce80',
       '8d10162a0a58e5f99fb39356b473c79952cd8faa5533c4a909cecdd28261af12')


def load(p):
    return json.load(open(p)) if p.exists() else None


def right(case, run):
    exp = case.get('expected')
    out = run['outcome']
    if exp == 'neither':
        return out == 'neither'
    if exp == 'either':
        return out in case['siblings']
    return out == exp


section = sys.argv[1] if len(sys.argv) > 1 else 'all'

if section in ('all', 'files'):
    print('== results files: arm, layout, hashes, reported block')
    for m in MODELS:
        for name in ('e0-personal', 'e1-plugin', 'e2-plugin', 'e0-personal.case3', 'e1-plugin.case3', 'e0-personal.case10', 'e1-plugin.case10'):
            d = load(R / m / f'{name}.json')
            if not d:
                continue
            hashes = (d.get('hub_sha256'), d.get('frontdoor_sha256'))
            hs = 'n/a' if d['arm'] == 'skills' else ('match' if hashes == HUB else f'MISMATCH {hashes}')
            rep = d.get('reported') or {}
            reach = d.get('reach') or {}
            outc = collections.Counter(run['outcome'] for r in d['results'] for run in r['runs'])
            hubfired = sum(bool(run.get('hub_fired')) for r in d['results'] for run in r['runs'])
            print(f'{m} {name}: arm {d["arm"]} layout {d["layout"]} model {d["model"]}; hashes {hs}; runs {sum(len(r["runs"]) for r in d["results"])}; '
                  f'outcomes {dict(outc)}; hub_fired {hubfired}; reach {json.dumps({k: reach.get(k) for k in ("decided","reached","wrong_skill","hidden","set_aside","tuesday_unrouted","reached_tuesday")})}')
            print(f'     reported: hub_path_contact {rep.get("hub_path_contact")}, skills_root_named {rep.get("skills_root_named")}, '
                  f'refused calls {rep.get("refused")} on {rep.get("runs_refused")} runs (unread {rep.get("refused_unread")}), '
                  f'seconds {rep.get("seconds")} (median {rep.get("seconds_median")}), output tokens {rep.get("output_tokens")} '
                  f'(median {rep.get("output_tokens_median")}) on {rep.get("tokens_read")} runs')
            tools = collections.Counter(t for r in d['results'] for run in r['runs'] for t in run.get('refused') or [])
            print(f'     refused by tool {dict(tools)}')

if section in ('all', 'explicit'):
    print('== explicit commands: outcomes and Tuesday firing')
    for m in MODELS:
        d = load(R / m / 'e2-plugin.json')
        for r in d['results']:
            outs = collections.Counter(run['outcome'] for run in r['runs'])
            hub = sum(bool(run.get('hub_fired')) for run in r['runs'])
            reached = collections.Counter(tuple(run.get('reached') or []) for run in r['runs'])
            print(f'  {m} case {r["id"]} expected {r["expected"]}: outcomes {dict(outs)}; hub_fired {hub}; reached {dict(reached)}')
        d3 = load(M17 / f'claude-{m}-5-5' / 'e2-plugin.json')
        if d3:
            hub3 = sum(bool(run.get('hub_fired')) for r in d3['results'] for run in r['runs'])
            print(f'  {m} round 3 e2-plugin: hub_fired {hub3} of {sum(len(r["runs"]) for r in d3["results"])}')

if section in ('all', 'percase'):
    print('== per case: right outcome / decided, this round Tuesday (e1) vs round 3 Tuesday (e1) vs today\'s skills this round (e0) [vs round 3 e0]')
    for m in MODELS:
        e1 = load(R / m / 'e1-plugin.json'); e0 = load(R / m / 'e0-personal.json')
        r1 = load(M17 / f'claude-{m}-5-5' / 'e1-plugin.json'); r0 = load(M17 / f'claude-{m}-5-5' / 'e0-personal.json')

        def table(d):
            out = {}
            if not d:
                return out
            for r in d['results']:
                runs = [x for x in r['runs'] if x['outcome'] not in ('timeout', 'error', 'void')]
                c = cases.get(r['id'], {'expected': r['expected']})
                out[r['id']] = (sum(right(c, x) for x in runs), len(runs), collections.Counter(x['outcome'] for x in runs))
            return out
        t1, t0, q1, q0 = table(e1), table(e0), table(r1), table(r0)
        print(f'-- {m}  (round 3 e1 file {"found" if r1 else "MISSING"}, e0 {"found" if r0 else "MISSING"})')
        tot = collections.Counter()
        for cid in sorted(t1):
            exp = cases.get(cid, {}).get('expected')
            a, b, c, dd = t1.get(cid), q1.get(cid), t0.get(cid), q0.get(cid)
            def f(x):
                return f'{x[0]}/{x[1]}' if x else '-'
            flag = ''
            if a and b and a[0] < b[0]:
                flag += f' DOWN vs r3 ({b[0]-a[0]})'
            if a and c and a[0] < c[0]:
                flag += f' BELOW today ({c[0]-a[0]})'
            wrong = {k: v for k, v in a[2].items() if k != exp and not (exp == 'either' and k in ('job-underwriter','mock-interview','resume-tailor'))}
            print(f'   case {cid:>2} exp {exp:<15} tuesday {f(a):>5}  r3-tuesday {f(b):>5}  today {f(c):>5}  r3-today {f(dd):>5}  other outcomes now {dict(wrong)}{flag}')
            for k, x in (('t1', a), ('q1', b), ('t0', c), ('q0', dd)):
                if x:
                    tot[k + 'n'] += x[0]; tot[k + 'd'] += x[1]
        print(f'   TOTAL right: tuesday {tot["t1n"]}/{tot["t1d"]}, r3-tuesday {tot["q1n"]}/{tot["q1d"]}, today {tot["t0n"]}/{tot["t0d"]}, r3-today {tot["q0n"]}/{tot["q0d"]}')

if section in ('all', 'extra'):
    print('== extra cases pooled with standard runs')
    for m, cid in (('haiku', 3), ('opus', 10)):
        for arm in ('e0-personal', 'e1-plugin'):
            std = load(R / m / f'{arm}.json'); ext = load(R / m / f'{arm}.case{cid}.json')
            runs = [x for r in std['results'] if r['id'] == cid for x in r['runs']] + [x for r in ext['results'] if r['id'] == cid for x in r['runs']]
            print(f'  {m} case {cid} {arm}: {len(runs)} runs; outcomes {dict(collections.Counter(x["outcome"] for x in runs))}; '
                  f'hub_path_contact {sum(bool(x.get("hub_path_contact")) for x in runs)}; skills_root_named {sum(bool(x.get("skills_root_named")) for x in runs)}')
