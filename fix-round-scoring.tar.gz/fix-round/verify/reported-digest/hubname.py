"""G1/G2: every mention of 'tuesday' (any case) in module outputs, other than the dossier file name,
classified as a day of the week or as the hub's name; and every 'front door' mention. Reads files only."""
import re, glob, collections, sys
from pathlib import Path

R = Path('/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round')
V = R / 'verify' / 'reported-digest'
pat = re.compile(r"(?<!user-)(?<!user/)tuesday(?!-dossier)", re.I)
# The hub named as a skill: its install name with suffix, in code, as "the tuesday skill", Tuesday's
# references/playbooks/files, the plugin, a path, "through/via Tuesday", "the hub", "sibling".
HUB = re.compile(r"tuesday-[0-9a-f]{8}|`tuesday`|tuesday\s+(skill|plugin|suite|module|hub|front)|"
                 r"tuesday(?:'s|’s)\s+(own|references|playbook|instructions|file|folder|routing|modules?|skill)|"
                 r"/tuesday\b|(via|through|from|use|run|invoke|ask|open)\s+tuesday\b|tuesday\s+(routes|runs|holds)", re.I)
PATHS = re.compile(r'\S*(?:/tmp/|scratchpad|claude-0|home-user-tuesday)\S*')
FD = re.compile(r'front[\s-]?door', re.I)
for arm in ('tuesday', 'alone'):
    hub, other, fd = [], collections.Counter(), []
    files_with_any = set()
    for f in sorted(glob.glob(str(R / '*' / arm / 'part-*' / '*.md'))):
        t = PATHS.sub(' <path> ', open(f).read())
        rel = f.split('/round/')[1]
        for mm in pat.finditer(t):
            ctx = t[max(0, mm.start() - 90):mm.end() + 90].replace('\n', ' ')
            near = t[max(0, mm.start() - 40):mm.end() + 40]
            files_with_any.add(rel)
            if HUB.search(near):
                hub.append((rel, ctx))
            else:
                other[t[mm.start():mm.end()]] += 1
        for mm in FD.finditer(t):
            fd.append((rel, t[max(0, mm.start() - 120):mm.end() + 120].replace('\n', ' ')))
    print(f'== {arm}: files with a non-dossier tuesday mention {len(files_with_any)}; hub-shaped mentions {len(hub)}; '
          f'other mentions by spelling {dict(other)}; front-door mentions {len(fd)}')
    for rel, ctx in hub:
        print('   HUB?', rel, '::', ctx)
    for rel, ctx in fd:
        print('   FD', rel, '::', ctx)
    with open(V / f'tuesday-other-{arm}.txt', 'w') as out:
        for f in sorted(glob.glob(str(R / '*' / arm / 'part-*' / '*.md'))):
            t = PATHS.sub(' <path> ', open(f).read())
            for mm in pat.finditer(t):
                near = t[max(0, mm.start() - 40):mm.end() + 40]
                if not HUB.search(near):
                    out.write(f.split('/round/')[1] + ' :: ' + t[max(0, mm.start() - 60):mm.end() + 60].replace('\n', ' ') + '\n')
