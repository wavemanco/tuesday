import hashlib, json, re, sys
from pathlib import Path
R = Path(sys.argv[1]); WT = R / "wt-text"
REF = re.compile(r"\{\{([a-z0-9_]+)\}\}")
PARTS = {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}
for part, mod in PARTS.items():
    spec = json.loads((WT / "skills" / mod / "evals" / "evals.json").read_text())
    cl = spec["clauses"]
    exp = {c["id"]: [hashlib.sha256(REF.sub(lambda m: cl[m.group(1)], e).encode()).hexdigest()
                     for e in c["expectations"]] for c in spec["evals"]}
    for arm in ("tuesday", "alone"):
        ok = bad = 0; badlist = []
        for gp in sorted((R / "sonnet" / arm / f"part-{part}").glob("*.grade-*.json")):
            g = json.loads(gp.read_text())
            for n, h in g["expectation_sha256"].items():
                if exp[g["id"]][int(n) - 1] == h: ok += 1
                else: bad += 1; badlist.append((gp.name, n))
        print(mod, arm, "hash match", ok, "mismatch", bad, sorted({b[1] for b in badlist})[:10], sorted({b[0].split('.run')[0] for b in badlist})[:10])
