"""My own recount of the family block (units), written from evals/README.md's description,
not by importing compare_arms. Approximation noted: the 'a call where none belongs' family folds
accept / skip_has_no_call failures of every target in a run failing zero_calls (the scorer folds
only targets the calls were aimed at); runs where that matters are listed."""
import json
import re
import sys
from math import comb
from pathlib import Path

ROUND = Path(sys.argv[1])
MODEL = sys.argv[2]
FAILURE_ONLY = {"canary_fixture", "candidate_constraints", "evidence_form", "evidence_map", "format",
                "gates_form", "ledger_markup", "severity_form", "tally_remark"}
REPORTED = {"ledger_sentence_form"}
NO_TABLE = ("the response has no accounting table", "the accounting table could not be read")
CLAIM = {"snapshot_count": re.compile(r'^the snapshot\'s prose: "(.+?)" is '),
         "ledger_sentence": re.compile(r'^in the sentence after the ledger, "(.+?)" is ')}
FAMS = [  # name, members, anchors
    ("hard-gates line", ("gates_line", "gates_form"), ("gates_line", "gates_form")),
    ("severity slot", ("severity", "severity_form"), ("severity", "severity_form")),
    ("a call where none belongs", ("zero_calls", "accept", "skip_has_no_call"), ("zero_calls",)),
    ("canned unavailable, nothing refused", ("unavailable_has_refusal", "accept"), ("unavailable_has_refusal",)),
    ("no accounting table, nor its tally line", ("row", "tally"), ("row", "tally")),
    ("one set claim, read twice", ("snapshot_count", "ledger_sentence"), ("snapshot_count", "ledger_sentence")),
]


def fisher(a, n1, b, n2):
    if not n1 or not n2:
        return None
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    p = lambda x: comb(n1, x) * comb(n2, k - x) / tot
    obs = p(a)
    return min(1.0, sum(p(x) for x in range(max(0, k - n2), min(k, n1) + 1) if p(x) <= obs * (1 + 1e-9)))


def fold(name, fails):
    idx = set()
    if name in ("hard-gates line", "severity slot"):
        mem = dict((f[0], f[1]) for f in FAMS)[name]
        idx = {i for i, f in enumerate(fails) if f["check"] in mem}
    elif name == "a call where none belongs":
        if any(f["check"] == "zero_calls" for f in fails):
            idx = {i for i, f in enumerate(fails) if f["check"] in ("zero_calls", "accept", "skip_has_no_call")}
    elif name == "canned unavailable, nothing refused":
        tg = {f.get("target") for f in fails if f["check"] == "unavailable_has_refusal"}
        idx = {i for i, f in enumerate(fails) if f["check"] == "unavailable_has_refusal"
               or (f["check"] == "accept" and f.get("target") in tg)}
    elif name == "no accounting table, nor its tally line":
        rows = {i for i, f in enumerate(fails) if f["check"] == "row" and str(f.get("why", "")).startswith(NO_TABLE)}
        if rows:
            idx = rows | {i for i, f in enumerate(fails) if f["check"] == "tally"}
    elif name == "one set claim, read twice":
        claims = {}
        for i, f in enumerate(fails):
            pat = CLAIM.get(f["check"])
            m = pat.match(str(f.get("why", ""))) if pat else None
            if m:
                claims.setdefault(m.group(1), {}).setdefault(f["check"], i)
        idx = {i for c in claims.values() if len(c) == 2 for i in c.values()}
    return idx


def defects(findings):
    fails = [f for f in findings if f.get("verdict") == "FAIL"]
    absorbed, out = set(), {}
    for name, _, _ in FAMS:
        got = fold(name, fails) - absorbed
        if got:
            out[name] = len({fails[i]["check"] for i in got})
            absorbed |= got
    for i, f in enumerate(fails):
        if i not in absorbed and f["check"] not in REPORTED:
            out.setdefault(f["check"], 1)
    return out, fails


def applies(chk, findings, unchecked):
    if chk in unchecked:
        return False
    return chk in FAILURE_ONLY or any(f["check"] == chk for f in findings)


def load(folder):
    runs = []
    for mp in sorted(folder.glob("*.meta.json")):
        meta = json.loads(mp.read_text())
        if (meta.get("harness") or {}).get("status") != "ok":
            continue
        c = json.loads((folder / f"{meta['stem']}.checks.json").read_text())
        runs.append((meta["stem"], c.get("checks") or [], set(c.get("unchecked") or [])))
    return runs


def counts(runs, unit, anchors):
    rec = [a for a in anchors if a not in FAILURE_ONLY]
    fail = app = multi = 0
    for stem, f, un in runs:
        d, _ = defects(f)
        if rec:
            ok = any(applies(a, f, un) for a in rec) or bool(d.get(unit))
        else:
            ok = any(applies(a, f, un) for a in anchors)
        if ok:
            app += 1
            fail += bool(d.get(unit))
            multi += d.get(unit, 0) > 1
    return fail, app, multi


for part in (1, 2, 3):
    T = load(ROUND / MODEL / "tuesday" / f"part-{part}")
    A = load(ROUND / MODEL / "alone" / f"part-{part}")
    present = {f["check"] for _, fs, _ in T + A for f in fs} - REPORTED
    print(f"== part-{part}  checks present: {sorted(present)}")
    # call-family approximation: list runs failing zero_calls with accept/skip failures
    for side, rs in (("tuesday", T), ("alone", A)):
        for stem, f, _ in rs:
            fl = [x for x in f if x.get("verdict") == "FAIL"]
            if any(x["check"] == "zero_calls" for x in fl):
                print(f"   {side} {stem} zero_calls fails with: {[ (x['check'], x.get('target')) for x in fl]}")
    units = [(n, m, a) for n, m, a in FAMS if present & set(a)] + [(c, (c,), (c,)) for c in sorted(present)]
    for name, mem, anc in units:
        ft, nt, mt = counts(T, name, anc)
        fa, na, ma = counts(A, name, anc)
        is_fam = name in {x[0] for x in FAMS}
        if not is_fam and not (ft or fa):
            continue
        p = fisher(ft, nt, fa, na)
        gated = nt >= 10 and na >= 10
        diff = (100 * ft / nt - 100 * fa / na) if nt and na else None
        miss = gated and diff is not None and diff >= 10 and p is not None and p < 0.01
        print(f"   {name:<45} T {ft}/{nt}  A {fa}/{na}  diff {diff if diff is None else round(diff, 2)}  "
              f"p={p if p is None else round(p, 4)}  gated={gated}  miss={miss}" + (f"  [{mt}/{ma}]" if is_fam else ""))
