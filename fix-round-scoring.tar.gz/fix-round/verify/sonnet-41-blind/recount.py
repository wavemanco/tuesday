"""Independent recount of section 4.1 figures for Sonnet from raw run files.

Reads only: <round>/sonnet/<arm>/part-<n>/*.meta.json, *.grade-*.json, *.checks.json, *.md,
and the raw evals.json of each module in wt-text (for clause references). Imports nothing
from the repository.
"""
import json
import re
import sys
from collections import Counter, defaultdict
from math import comb
from pathlib import Path

ROUND = Path(sys.argv[1])
MODEL = sys.argv[2] if len(sys.argv) > 2 else "sonnet"
WT = ROUND / "wt-text"
PARTS = {1: "job-underwriter", 2: "mock-interview", 3: "resume-tailor"}
FAMILIES = {
    "job-underwriter": {"pair": ("proposed_language", "ledger_counts"), "pl": ("proposed_language",)},
    "mock-interview": {"no_overclaim": ("no_overclaim",)},
    "resume-tailor": {"row_quote": ("row_quote",)},
}
REF = re.compile(r"\{\{([a-z0-9_]+)\}\}")


def fisher(a, n1, b, n2):
    if not n1 or not n2:
        return None
    k, n = a + b, n1 + n2
    tot = comb(n, k)
    p = lambda x: comb(n1, x) * comb(n2, k - x) / tot
    obs = p(a)
    return min(1.0, sum(p(x) for x in range(max(0, k - n2), min(k, n1) + 1) if p(x) <= obs * (1 + 1e-9)))


def family_numbers(module):
    spec = json.loads((WT / "skills" / module / "evals" / "evals.json").read_text())
    clauses = spec.get("clauses", {})
    out = {}
    for fam, names in FAMILIES[module].items():
        per_case = {}
        for case in spec["evals"]:
            nums = []
            for i, e in enumerate(case["expectations"], 1):
                refs = set(REF.findall(e))
                # nested references, in case a clause includes another
                for r in list(refs):
                    refs |= set(REF.findall(clauses.get(r, "")))
                if refs & set(names):
                    nums.append(i)
            per_case[case["id"]] = nums
        out[fam] = per_case
    texts = {fam: [clauses[n] for n in names] for fam, names in FAMILIES[module].items()}
    nexp = {case["id"]: len(case["expectations"]) for case in spec["evals"]}
    return out, texts, nexp


def load_arm(folder):
    runs = {}
    stems_by_kind = defaultdict(set)
    for p in folder.iterdir():
        if p.is_dir():
            continue
        m = re.match(r"^(.+?\.run\d+)\.(meta\.json|checks\.json|grade-(\d+)\.json|md)$", p.name)
        if not m:
            stems_by_kind["other"].add(p.name)
            continue
        stems_by_kind[m.group(2) if not m.group(3) else "grade-" + m.group(3)].add(m.group(1))
    for stem in sorted(stems_by_kind["meta.json"]):
        meta = json.loads((folder / f"{stem}.meta.json").read_text())
        grades = {}
        for g in (1, 2):
            gp = folder / f"{stem}.grade-{g}.json"
            grades[g] = json.loads(gp.read_text()) if gp.exists() else None
        cp = folder / f"{stem}.checks.json"
        checks = json.loads(cp.read_text()) if cp.exists() else None
        runs[stem] = {"meta": meta, "grades": grades, "checks": checks}
    return runs, stems_by_kind


def main():
    report = {}
    for part, module in PARTS.items():
        fams, fam_texts, nexp = family_numbers(module)
        res = {}
        for arm in ("tuesday", "alone"):
            folder = ROUND / MODEL / arm / f"part-{part}"
            runs, kinds = load_arm(folder)
            r = {"runs": len(runs)}
            r["file_kinds"] = {k: len(v) for k, v in kinds.items() if k != "other"}
            r["other_files"] = sorted(kinds.get("other", []))
            r["killed_dir"] = (folder / "killed").exists()
            # set aside: harness status not ok, or the older markers
            invalid = []
            for s, d in runs.items():
                m = d["meta"]
                h = (m.get("harness") or {}).get("status")
                if h != "ok" or m.get("error") or m.get("skill_fired") is False:
                    invalid.append((s, h, m.get("harness", {}).get("reasons"), m.get("error"), m.get("skill_fired")))
            r["invalid"] = invalid
            r["fire"] = dict(Counter(d["meta"].get("fire") for d in runs.values()))
            r["nudged"] = sum(d["meta"].get("triggered_unprompted") is False for d in runs.values())
            r["n_invocations"] = dict(Counter(len(d["meta"].get("invocations") or []) for d in runs.values()))
            r["via"] = dict(Counter(d["meta"].get("via") for d in runs.values()))
            r["layout"] = dict(Counter(d["meta"].get("layout") for d in runs.values()))
            r["room_writable"] = dict(Counter(d["meta"].get("room_writable") for d in runs.values()))
            r["meta_model"] = dict(Counter(d["meta"].get("model") for d in runs.values()))
            r["init_model"] = dict(Counter(inv.get("init", {}).get("model") for d in runs.values()
                                           for inv in d["meta"].get("invocations") or []))
            r["cli"] = dict(Counter(inv.get("init", {}).get("claude_code_version") for d in runs.values()
                                    for inv in d["meta"].get("invocations") or []))
            r["result_models"] = dict(Counter(k for d in runs.values() for inv in d["meta"].get("invocations") or []
                                              for k in ((inv.get("result") or {}).get("modelUsage") or {})))
            r["run_dates"] = dict(Counter(d["meta"].get("run_date") for d in runs.values()))
            r["grader_cli"] = dict(Counter(g.get("cli_version") for d in runs.values() for g in d["grades"].values() if g))
            r["grader_model"] = dict(Counter(g.get("grader_model") for d in runs.values() for g in d["grades"].values() if g))
            r["grader_prompt"] = dict(Counter(g.get("grader_prompt_version") for d in runs.values() for g in d["grades"].values() if g))
            r["grade_harness_invalid"] = sum(bool(g.get("harness_invalid")) for d in runs.values() for g in d["grades"].values() if g)
            # grade completeness
            missing_grade = [(s, g) for s, d in runs.items() for g in (1, 2) if d["grades"][g] is None]
            r["missing_grade_files"] = missing_grade
            short = []
            odd = []
            passes = verdicts = 0
            for s, d in runs.items():
                fid = d["meta"]["id"]
                for g in (1, 2):
                    gr = d["grades"][g]
                    if gr is None:
                        continue
                    vs = [v for v in gr.get("verdicts") or [] if v.get("verdict") in ("PASS", "FAIL")]
                    allv = gr.get("verdicts") or []
                    nums = [v.get("n") for v in vs]
                    if len(vs) != nexp[fid] or len(set(nums)) != len(nums) or len(allv) != len(vs):
                        short.append((s, g, len(vs), len(allv), nexp[fid], sorted(set(range(1, nexp[fid] + 1)) - set(nums))))
                    if len(gr.get("expected") or []) != nexp[fid] or gr.get("incomplete") or gr.get("missing") \
                            or gr.get("duplicates") or gr.get("invalid") or gr.get("regraded"):
                        odd.append((s, g, len(gr.get("expected") or []), gr.get("incomplete"), gr.get("missing"),
                                    gr.get("duplicates"), gr.get("invalid"), gr.get("regraded")))
                    passes += sum(v["verdict"] == "PASS" for v in vs)
                    verdicts += len(vs)
            r["short_verdicts"] = short
            r["odd_grade_fields"] = odd
            r["graded"] = (passes, verdicts)
            # family text appears in the grader's expected list where the clause numbers say
            text_mismatch = []
            for s, d in runs.items():
                fid = d["meta"]["id"]
                for fam, per_case in fams.items():
                    for g in (1, 2):
                        gr = d["grades"][g]
                        if not gr:
                            continue
                        exp = gr.get("expected") or []
                        found = [i for i, e in enumerate(exp, 1)
                                 if any(t[:80] in (e if isinstance(e, str) else json.dumps(e)) for t in fam_texts[fam])]
                        if sorted(found) != sorted(per_case.get(fid, [])):
                            text_mismatch.append((s, fam, g, found, per_case.get(fid)))
            r["family_text_mismatch"] = text_mismatch[:6]
            r["family_text_mismatch_n"] = len(text_mismatch)
            # truthfulness, two ways
            tr = {}
            for fam, per_case in fams.items():
                a_fail = a_graded = b_fail = b_graded = 0
                partial_runs = []
                for s, d in runs.items():
                    fid = d["meta"]["id"]
                    nums = per_case.get(fid, [])
                    if not nums:
                        continue
                    # way A: per expectation, fail if any grader FAIL, pass if both PASS, else partial
                    states = []
                    anyv = False
                    anyfail = False
                    for n in nums:
                        got = []
                        for g in (1, 2):
                            gr = d["grades"][g]
                            v = None
                            if gr:
                                v = next((x["verdict"] for x in gr.get("verdicts") or [] if x.get("n") == n
                                          and x.get("verdict") in ("PASS", "FAIL")), None)
                            got.append(v)
                        if "FAIL" in got:
                            states.append("fail")
                        elif all(v == "PASS" for v in got):
                            states.append("pass")
                        else:
                            states.append("partial")
                        anyv |= any(v is not None for v in got)
                        anyfail |= "FAIL" in got
                    if any(st in ("pass", "fail") for st in states):
                        a_graded += 1
                        a_fail += "fail" in states
                    if "partial" in states:
                        partial_runs.append((s, states))
                    # way B: any verdict on any family expectation counts as graded
                    if anyv:
                        b_graded += 1
                        b_fail += anyfail
                tr[fam] = {"strict": (a_fail, a_graded), "loose": (b_fail, b_graded), "partial_runs": partial_runs}
            r["truth"] = tr
            # checks: simple per-check failing runs / runs with a finding of that check
            per_check = defaultdict(lambda: [0, 0])
            no_checks = []
            for s, d in runs.items():
                c = d["checks"]
                if c is None:
                    no_checks.append(s)
                    continue
                f = c.get("checks") or []
                unchecked = set(c.get("unchecked") or [])
                for name in sorted({x["check"] for x in f}):
                    if name in unchecked:
                        continue
                    per_check[name][1] += 1
                    per_check[name][0] += any(x["check"] == name and x.get("verdict") == "FAIL" for x in f)
            r["per_check_with_finding"] = dict(per_check)
            r["no_checks"] = no_checks
            res[arm] = r
        # derived
        ta, al = res["tuesday"], res["alone"]
        res["graded_diff_points"] = 100 * ta["graded"][0] / ta["graded"][1] - 100 * al["graded"][0] / al["graded"][1]
        res["truth_p"] = {fam: {k: fisher(*ta["truth"][fam][k], *al["truth"][fam][k]) for k in ("strict", "loose")}
                          for fam in ta["truth"]}
        res["family_numbers"] = fams
        report[module] = res
    print(json.dumps(report, indent=1, default=str))


main()
