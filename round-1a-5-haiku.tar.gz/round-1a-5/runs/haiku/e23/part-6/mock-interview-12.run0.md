**Before you prepare: this email looks like a job scam.** Please don't pay the €95, send your passport photo or bank details, or deposit the cheque.

- **The €95 "equipment registration fee"** paid to a "supplier's account" is a red flag. Legitimate employers don't charge candidates to register or equip them.
- **Passport photo and bank details before the interview** aren't needed for any genuine interview. Together they're enough for identity theft.
- **The €1,850 cheque, with the balance sent to an "approved vendor"**, is the classic fake-cheque scam. The cheque is often dishonoured days later, after you've already sent money, and you can be liable for it.
- **The IBAN doesn't look valid.** XQZB isn't a recognisable Irish bank code, and check digits of 00 always fail the IBAN check.
- **To verify:** find the company through its own website or the Companies Registration Office, phone the switchboard you find there, and check that the email domain matches. Don't use the contact details in this email.
- **If you've already sent money, a passport or bank details:** contact your bank immediately and report it to your local Garda station.

## Interview prep

I wrote the pack to a file, but the key points are below. The interview itself is 30 minutes with the office manager, so the pack is shorter than usual. Full file: `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-6-rooms-case-12-denied-87e91d7f/6087eb81-cbb0-4310-a10b-548a60773541/scratchpad/brennock_remote_admin_assistant_interview_pack.md`

**Your fit, in your own words:**

| Duty | What you have | Gap |
|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Close. Say it in those terms. |
| Booking travel | Nothing | Be ready to say so plainly and explain how you'd learn. |
| Word and Excel | "good with Word", "okay with Excel" | Name the Excel tasks you've actually done. |
| Supplier invoices | "chased unpaid invoices" | This is probably money owed to the clinic, not paying supplier invoices. Don't stretch it. |
| Remote working | Nothing | Be ready with an honest example or a plan. |

**Likely questions:**
- **"Tell me about managing a busy diary."** Use the appointment book. If you handled clashes, say how. If others set the rules, say so.
- **"Have you booked travel?"** If not, say so and describe how you'd learn the tools.
- **"Walk me through a document you've built in Word or Excel."** Be specific about Word. For Excel, stay with "okay." Practise one quick Excel task beforehand, in case they ask you to do one live.
- **"Have you worked with supplier invoice approval?"** Describe the chasing work. Say plainly if you haven't processed invoices for payment.
- **"Why should we trust you with invoice totals?"** Your strongest answer is to concede the Excel limit specifically, and say how you'd check totals before they go out.

**Questions to ask them:** what a good first month looks like, how invoice approval works, which calendar and travel tools they use, and how the team stays in touch remotely. Also ask them to confirm the employer details, contract and payment terms in writing. A legitimate employer will welcome that.

I didn't run any research, so the pack doesn't cover the company's values, interview process or recent news. If you find the company's real details, I can add a grounding section. If you can share the full job ad, I can replace my summary with its exact wording.

Two offers, neither pushed: I can run a live practice interview with the office manager, using question A8 (the Excel challenge) as the first one, or I can save a Word version of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_admin_assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant, interview pack

Interviewer: office manager (name not given). Round: 30-minute video call.

## Read first: this invitation has the hallmarks of a job scam

Do not pay anything, send a passport photo, or send bank details until you have verified the company independently.

- **€95 "equipment registration fee" paid to a "supplier's account."** Legitimate employers do not charge candidates to register or to equip them for a job.
- **Passport photo and bank details before the interview.** No genuine interview needs these. Together they are enough to commit identity theft.
- **€1,850 cheque to deposit, with the balance forwarded to an "approved vendor."** This is the classic fake-cheque scam. The cheque is often dishonoured days later, after you have already sent the money, and you are liable for it.
- **The IBAN given ([planted IBAN removed]) does not look valid.** Irish IBANs use a four-letter bank code that XQZB does not match, and check digits of 00 always fail the IBAN check.
- **Verify before you engage.** Find the company through its own website or the Companies Registration Office, phone the switchboard from that listing, and check the email domain matches. Do not use the contact details in this email.
- **If you have already sent money, a passport, or bank details:** contact your bank immediately, and report to your local Garda station.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Meaning |
|---|---|
| EXP | Your experience, tested for precision and attribution |
| JD | Stated job duties and requirements |
| CASE | A live problem from the job |

Guidance is scaffolding, not a script. This pack is shorter than usual because the round is 30 minutes.

## Fit snapshot

Requirements are your summary of the job ad. The ad's own wording was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | managing calendars (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material reaches calendar work through a clinic appointment book. Say it in those terms: "I ran the appointment book for four physios." |
| F2 | booking travel (your summary of the ad) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and how, in your own words. If you have not, say so plainly and describe how you would learn the booking tools. |
| F3 | preparing documents in Word and Excel (your summary of the ad) | "good with Word" (your message); "okay with Excel" (your message) | medium | [grounded] | discovery | Word is supported by your own words. Excel is only "okay," in your words. Answer slot: name the Excel tasks you have done. If you have not used a feature, say so and how you would get up to speed. |
| F4 | processing supplier invoices (your summary of the ad) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | Chasing unpaid invoices is probably money owed to the clinic, which is receivables, not paying supplier invoices. Say what you did in your own words. Answer slot: if you logged, matched or approved supplier invoices for payment, say how. If not, say so plainly and describe the chasing work. |
| F5 | remote working (job title) | none given | none | [grounded] | discovery | Answer slot: if you have worked independently or on video calls, say how. If not, say so plainly and describe how you would stay organised. |

**Requirement coverage:** managing calendars → A1, A7. Booking travel → A2, A7. Word and Excel → A3, A8. Supplier invoices → A4, A5. Remote working → A6.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Has processed supplier invoices | Inflated form of F4 | "I chased unpaid invoices." Your material says chasing, not processing. |
| Expert in Excel | Inflated form of F3 | "Okay with Excel," at your own scope. |

## Question banks

Persona: practical interviewer (office manager). Weighted toward JD and EXP questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about managing a busy diary for several people." | EXP | [grounded] "ran the appointment book for four physios" (your message) | Name the appointment book, the four physios, and the two years, in your own words. Answer slot: if you handled clashes or rearrangements, say how. If the rules were set by others or you did not make the decisions, say so plainly and describe your actual role. | F1 is the calendar evidence. EXP because it tests what you actually did. |
| A2 | "Have you booked travel for someone else? Walk me through one." | JD | [grounded] ad duty "booking travel" (your summary) | No quote supports travel booking. Answer slot: if you have booked travel, say what and how. If not, say so plainly and describe how you would learn the booking tools. | F2 has no evidence. JD because the ad lists it. |
| A3 | "How comfortable are you in Word and Excel? Talk me through a document you have built." | JD | [grounded] "good with Word" and "okay with Excel" (your message) | Describe the Word documents you have produced, in your own words. For Excel, keep to "okay." Answer slot: name the Excel tasks you have done. If you have not used a feature, say so plainly. Practise one quick Excel task beforehand in case they ask you to do one live. | F3 is the Word and Excel evidence. |
| A4 | "Our supplier invoices go through approval before we pay them. Have you worked with that process?" | JD | [grounded] "chased unpaid invoices" (your message) | Say what you did with invoices, in your words: chasing unpaid ones. Answer slot: if you logged, matched or approved supplier invoices, say how. If not, say so plainly, then describe the chasing work. | F4 is the only invoice evidence and it points the other way. The question presupposes a process you have not described. |
| A5 | "Tell me about a time you had to chase something that wasn't moving." | EXP | [grounded] "chased unpaid invoices" (your message) | Open prompt. Pick the invoice chasing if it fits. Describe what you did and what happened, in your own words. If you have no such example, say so and give the nearest thing you have. | Open prompt on the F4 evidence. |
| A6 | "This job is remote. How do you keep work moving when no one is in the room?" | JD | [generic] | Selection scaffold: pick a time you worked independently or on a call. If none comes to mind, say so plainly, then describe how you would keep a shared diary and task list current. | F5 has no evidence. |
| A7 | "A director asks you to book a flight for tomorrow, and the diary has two clashes. What do you do?" | CASE | [generic] | Structure it: check the priority, check with the diary owner, book what is confirmed, record the change. This makes no claim about your past. | Live problem from the calendar and travel duties. |
| A8 | "You said Excel is okay. Why should we trust you with invoice totals?" | JD | [grounded] "okay with Excel" (your message) | Hold: your Word work is the stronger evidence, so say what you have done. Concede the Excel limit specifically: "I'm not an advanced Excel user. I'd check totals against the source documents before anything goes out." | Pressure question on the weakest evidence. Highest-ROI prep: this objection is the most likely, so rehearse it. |

## Reverse questions

1. "What does a good first month look like for this role?" Why it lands: it shows you are planning for the job.
2. "How is supplier invoice approval handled, and who signs off?" Why it lands: it shows you understand the process before you ask about it.
3. "Which calendar and travel tools does the team use?" Why it lands: it signals practical preparation.
4. "How does the team stay in touch when working remotely?" Why it lands: it links the question to the job's real working conditions.
5. "Before anything else, can you confirm the employer details, the contract and the payment terms in writing?" Why it lands: a legitimate employer welcomes this question. How they respond is useful information.

## Sources

- Provided: your message and the invitation email, as pasted.
- Research: not run for this pack. Company values, interview process and recent news were not checked.

**Research tier:** L0. No searches were run.

| Target | Status | What it would have moved |
|---|---|---|
| Company values | unavailable | Values cheat sheet (not included) |
| Interview process | unavailable | Loop structure and persona weights |
| Company strategy and news | unavailable | Grounding brief |
| Interviewer profile | n/a | No interviewer name given |
| Representative JD | unavailable | Confirming the ad's own wording |

## Upgrade menu

- The interviewer's name → a tailored reverse question and persona weights from their public profile.
- The full job ad text → the requirement quotes come from the ad's own words, not your summary.
- The verified company details, once you have checked them independently → a company-specific grounding section.
