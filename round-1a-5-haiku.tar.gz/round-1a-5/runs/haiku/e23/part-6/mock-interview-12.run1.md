I'll load the mock-interview skill first. Before any prep, the email you received has serious fraud signs that I want to flag.
**Stop before you pay or send anything.** This invitation has the signs of an advance-fee or overpayment scam:

- **A €95 "equipment registration fee"** paid to a supplier's account, before any interview. Employers don't charge candidates to be interviewed.
- **A passport photo and bank details** before the interview. That's enough for identity theft, and no interview needs it.
- **A €1,850 cheque to deposit**, with you sending the balance to a vendor. The cheque can bounce after you've sent real money, and you lose it.
- **The email domain is `brennock.example`.** `.example` is a reserved placeholder domain that can't belong to a real company. I couldn't check the company (web search was denied in this session), so I can't say whether Brennock Facilities Ltd exists.

**Do not pay the fee, send your passport or bank details, or deposit the cheque.** If you've already sent anything, contact your bank now. To check the company, use the official Companies Registration Office register and a phone number you find yourself, not one from this email. If you can't verify them, treat the role as unverified and don't prepare around it.

If the role turns out to be real, here is the prep pack built from your message. It's also saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-6-rooms-case-12-denied-231aefcd/21ce3e1e-1e9f-44f9-93e6-a64c7629df13/scratchpad/brennock_remote_admin_assistant_interview_pack.md`.

---

# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

**Role:** Remote Administrative Assistant
**Company:** Brennock Facilities Ltd (not verified)
**Interviewer:** office manager, name not given. Round: 30-minute video call.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: your past work, tested for accuracy.
- **JD**: whether you can do the listed duties.
- **CASE**: a live scheduling or admin problem.

Guidance is scaffolding, not a script. Say things in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says an appointment book for four physios, not calendars managed for an organisation. Bridge at that scope: "I ran the appointment book for four physios." Answer slot: if you have set or changed calendars for people outside the clinic, say whose and how; if not, say so and say how you would learn their calendar tools. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how; if not, say so and say how you would learn the process. |
| F3 | "preparing documents in Word and Excel" (your message) | "good with Word, okay with Excel" (your message) | medium | [grounded] | presentation | Your wording already reaches this. Say it as you put it: "I'm good with Word, and okay with Excel." Don't upgrade "okay." |
| F4 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | Chasing invoices is adjacent to processing them and does not show processing. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or paid supplier invoices, say what; if not, say so and say how you would learn the process. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed the company's calendars" | Inflated form of F1 | "I ran the appointment book for four physios." Your material does not show organisation-wide calendar management. |
| "Processed supplier invoices" or "managed accounts payable" | Inflated form of F4 | "I chased unpaid invoices." |
| "Advanced Excel" or "proficient in Excel" | Inflated form of F3 | "Okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks which duties you have done and which you haven't. | Highest. The ad lists four duties and your material directly covers two. | Rehearse gap answers until they're plain. Name what you did; say the rest is a learning plan. |
| Case | A live scheduling, travel or invoice problem. | High. Short admin interviews often include one practical problem. | Clarify, then structure, then decide. Say the steps aloud. |
| Conversational | Opens with your background and easy questions. | Medium. Easy questions are still scored. | Keep a 90-second background arc ready. |
| Pressure | Challenges whether clinic experience transfers. | Low to medium. A short call limits how hard it pushes. | Hold your stated position through two follow-ups; then concede the specific difference. |

## Question banks

**Skeptic (highest weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our role is mostly calendars, travel and invoices. Which of those have you done yourself?" | JD | [grounded] "I ran the appointment book for four physios"; [grounded] "chased unpaid invoices" | **Highest-ROI prep in this pack.** Start with the appointment book for four physios and the invoices you chased, in those words. Answer slot: if you have booked travel or processed invoices, say how; if not, say so plainly and describe how you would learn it. Hold through two follow-ups by returning to what you did. | F1, F2 and F4 are the gaps this targets. Expect it in some form. |
| B2 | "Why would you move from a physio clinic into this kind of role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Say what you did at the clinic, then what you want next. Stay with what you actually did and wanted. | Motivation probe. The clinic is the only background you've stated. |
| B3 | "We need someone quick in Excel from day one. How would you rate yourself?" | JD | [grounded] "good with Word, okay with Excel" | "I'm good with Word, and okay with Excel." Then the answer slot: name one Excel task you can do now and what you'd do to get faster. | F3 presentation gap. Keep "okay." |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" | Be honest: you chased invoices but haven't processed them. Answer slot: say which part of the invoice process is new and how you'd learn it. | Tests honest self-assessment. |
| B5 | "What would you do in your first week on travel bookings?" | JD | [generic] | Ask for the booking tools and travel policy, confirm approval limits, book one test trip with a second person checking. No claim about your past. | F2 gap, answered as a plan. |

**Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two directors need the boardroom on Thursday and their calendars clash. What do you do?" | CASE | [generic] | Clarify who has priority and who decides. Check room availability. Offer two options, confirm with both, record the decision. | Calendar management is the first duty. |
| C2 | "A supplier invoice shows as paid, but the bank shows nothing arrived. How would you handle it?" | CASE | [generic] | Check the remittance and bank record. Contact the supplier. Log findings. Escalate if unresolved. | Ties to invoices without claiming experience. |
| C3 | "Book a two-night trip for the managing director, Dublin to Cork, within a budget. Walk me through it." | CASE | [generic] | Check policy and budget, compare two options, book, confirm, share the itinerary. | Covers travel, which your material doesn't show. |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; [grounded] "I ran the appointment book for four physios" | A 90-second arc: the clinic, the appointment book, the invoices you chased, what you're good at. | Opening question. Built only from your sentences. |
| D2 | "What do you use day to day?" | JD | [grounded] "good with Word, okay with Excel" | Word first, then Excel as you put it. | Casual but scored against the Word and Excel duty. |
| D3 | "Any questions for me?" | reverse | [generic] | Ask at least two of the reverse questions below. | Rapport interviewers weight this heavily. |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've worked in a clinic. Why would we trust you with executive diaries?" | JD | [grounded] "I ran the appointment book for four physios" | Hold: a diary for four people is still a diary you kept. Concede one specific difference, such as scale. Don't fold on the core claim. | Tests a fair position held without getting defensive. |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| managing calendars | B1, C1 | |
| booking travel | B1, B5, C3 | No stated experience; covered by answer slots. |
| Word and Excel documents | B3, D2 | |
| processing supplier invoices | B1, B4, C2 | No stated experience; covered by answer slots. |

## Reverse questions

1. **"How is equipment supplied for remote staff?"** Why it lands: it tests the fee claim, and a legitimate employer will answer it easily.
2. **"Which calendar and travel tools does the team use?"** Why it lands: it shows you're planning for the real job.
3. **"Who approves supplier invoices, and what's the usual turnaround?"** Why it lands: it shows you know invoice work is a process.
4. **"What would someone excellent have done after six months?"** Why it lands: it shows you think in results.
5. **"How does the team check in with remote staff?"** Why it lands: it shows you know remote work needs structure.

## Upgrade menu

- The full advertisement text → the four requirement rows become verbatim quotes instead of your summary.
- The office manager's name, from a source you've checked independently → an interviewer read and reweighted personas. Don't share the name until the company is verified.

---

**Sources:** your message only. Web search was denied in this session, so no company values, interview structure or strategy are included. The pack contains no company-specific claims.

I'd also like to:
- Play the Skeptic on B1 in a live drill. It's the question most likely to come up.
- Save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two questions:
1. Can you paste the full text of the advertisement? I'd rather quote the requirements exactly than from your summary.
2. Have you verified the company yourself yet? If you haven't, please do that before anything else.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_admin_assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

**Role:** Remote Administrative Assistant
**Company:** Brennock Facilities Ltd (not verified; see the warning below)
**Interviewer:** office manager, name not given. Round: 30-minute video call.
**Changelog:** first version. Built from your message only. Web research was unavailable in this session, so no company content is sourced from outside your inputs.

> **Verification warning.** The invitation asks you to pay a €95 "equipment registration fee" to a supplier's account, send a passport photo and bank details before the interview, and deposit a €1,850 cheque and send the balance on to a vendor. Do not do any of these. Treat the job as unverified until you have confirmed the company independently.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: your past work, tested for accuracy.
- **JD**: whether you can do the listed duties.
- **CASE**: a live scheduling or admin problem.
- **VAL**: company values. None are sourced here, so none are included.
- **CO**: company knowledge. None is sourced here, so none is included.

Guidance is scaffolding, not a script. Say things in your own words.

## Fit snapshot

Requirements are quoted from your message, where you summarised the ad. If you paste the full ad, these rows can be re-quoted verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message, ad summary) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says you ran an appointment book for four physios, not calendars managed for an organisation. Bridge at that scope: "I ran the appointment book for four physios." Answer slot: if you have set or changed calendars for people outside the clinic, say whose and how; if not, say so plainly and say how you would learn their calendar tools. |
| F2 | "booking travel" (your message, ad summary) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what you booked and how; if not, say so plainly and say how you would learn the booking process. |
| F3 | "preparing documents in Word and Excel" (your message, ad summary) | "good with Word, okay with Excel" (your message) | medium | [grounded] | presentation | Your own wording already reaches this requirement. Say it as you put it: "I'm good with Word, and okay with Excel." Do not upgrade "okay" into a stronger claim. |
| F4 | "processing supplier invoices" (your message, ad summary) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices and does not show processing. Bridge at that scope: "I chased unpaid invoices." Answer slot: if you entered, matched or paid supplier invoices, say what you did; if not, say so and say how you would learn the invoice process. |

Confidence grades your evidence. Provenance grades what this pack says about it. F4 is `low` because the evidence is thin, and its bridge is `[inferred]` because it is this pack's derivation.

## Prohibited list

These are claims the pack will not coach. Each one stretches a sentence you actually said.

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed the company's calendars" | Inflated form of F1: your material says an appointment book for four physios. | "I ran the appointment book for four physios." The limit is this pack's observation: your material does not show organisation-wide calendar management. |
| "Processed supplier invoices" or "managed accounts payable" | Inflated form of F4: your material says you chased unpaid invoices. | "I chased unpaid invoices." |
| "Advanced Excel" or "proficient in Excel" | Inflated form of F3: your material says okay. | "Okay with Excel." |

## Persona table

No interviewer name was given, so there is no interviewer read. Weights use the relationship prior for a hiring-side admin round (Case and Skeptic), with the office manager's likely focus on day-to-day tasks.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks which of the duties you have actually done, and which you have not. | Highest. The ad lists four duties and your material covers two of them directly, so gaps will be probed. | Rehearse the gap answers until they are plain. Name what you did, and say the rest is a learning plan. |
| Case | Gives a live scheduling, travel or invoice problem. | High. A 30-minute call for an admin role often includes one practical problem. | Clarify first, then structure, then decide. Say the steps out loud. |
| Conversational | Opens with your background and a few easy questions. | Medium. Easy questions are still scored. | Keep a 90-second background arc ready. Treat casual questions about tools as scored. |
| Pressure | Challenges whether your clinic experience transfers to executive support. | Low to medium. A short call limits how hard it can push. | Hold your stated position through two follow-ups, then concede the specific difference. |

Depth follows weight. Skeptic gets 5 questions, Case 3, Conversational 3, Pressure 1. This is a thin pack for a 30-minute call on purpose.

## Question banks

### Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our role is mostly calendars, travel and invoices. Which of those have you done yourself?" | JD | [grounded] "I ran the appointment book for four physios"; [grounded] "chased unpaid invoices" | **Highest-ROI prep in this pack.** Start with what you did: the appointment book for four physios, and chasing unpaid invoices, in those words. Answer slot: if you have booked travel or processed invoices, say how; if not, say so plainly and describe how you would learn the process. Hold through two follow-ups by returning to the appointment book and the invoices you chased. | F1, F2 and F4 are the gaps this question targets. Expect it in some form. |
| B2 | "Why would you move from a physio clinic into this kind of role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Say what you did at the clinic, then what you want to do next. Keep it to what you actually did and wanted. | Motivation probe. The clinic is the only background you have stated. |
| B3 | "We need someone quick in Excel from the first day. How would you rate yourself?" | JD | [grounded] "good with Word, okay with Excel" | "I'm good with Word, and okay with Excel." Then the answer slot: name one Excel task you can do now and what you would do to get faster. | F3 presentation gap. Keep "okay" as you said it. |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" | Be honest. Invoices: you chased them, but you have not processed them. Answer slot: say which part of the invoice process is new to you and how you would learn it. | Tests honest self-assessment on the weakest duty. |
| B5 | "What would you do in your first week on travel bookings?" | JD | [generic] | Structure it: ask for the booking tools and travel policy, confirm approval limits, then book one test trip with a second person checking it. No claim about your past. | F2 gap. Answered as a plan, not a record. |

### Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two directors need the boardroom on Thursday and their calendars clash. What do you do?" | CASE | [generic] | Clarify who has priority and who decides. Check room availability. Offer two options. Confirm with both and record the decision. No claim about your past. | Calendar management is the first duty in the ad. |
| C2 | "A supplier invoice shows as paid, but the bank shows nothing arrived. How would you handle it?" | CASE | [generic] | Check the remittance and bank record. Contact the supplier with the details. Log what you found. Escalate if it is still unresolved. No claim about your past. | Ties to the invoice duty without claiming invoice experience. |
| C3 | "Book a two-night trip for the managing director, Dublin to Cork, within a set budget. Walk me through it." | CASE | [generic] | Check policy and budget. Compare two options. Book, confirm, and share the itinerary. No claim about your past. | Covers the travel duty, which your material does not show. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; [grounded] "I ran the appointment book for four physios" | A 90-second arc: the clinic, the appointment book for four physios, the invoices you chased, and what you are good at. Use your own words. | Opening question. The arc is built only from your sentences. |
| D2 | "What do you use day to day?" | JD | [grounded] "good with Word, okay with Excel" | Word first, then say Excel as you put it. | Casual, but scored against the Word and Excel duty. |
| D3 | "Any questions for me?" | reverse | [generic] | Use the reverse questions below. Ask at least two. | Rapport interviewers weight this heavily. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've worked in a clinic. Why would we trust you with executive diaries?" | JD | [grounded] "I ran the appointment book for four physios" | Hold: a diary for four people is still a diary you kept. Concede one specific difference, such as scale or the number of people you booked for. Do not fold on the core claim. | Tests whether you hold a fair position without getting defensive. |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| managing calendars | B1, C1 | |
| booking travel | B1, B5, C3 | No stated experience. Covered by answer slots. |
| preparing documents in Word and Excel | B3, D2 | |
| processing supplier invoices | B1, B4, C2 | No stated experience. Covered by answer slots. |

## Reverse questions

Each one is asked to the office manager.

1. **"How is equipment supplied for remote staff?"** Why it lands: it tests the fee claim in the invitation, and any honest employer will answer it easily.
2. **"Which calendar and travel tools does the team use?"** Why it lands: it shows you are planning for the real job.
3. **"Who approves supplier invoices, and what is the usual turnaround?"** Why it lands: it shows you know invoice work is a process.
4. **"What would someone excellent in this role have done after six months?"** Why it lands: it shows you are thinking about results.
5. **"How does the team check in with remote staff?"** Why it lands: it shows you know remote work needs structure.

## Upgrade menu

- The full text of the advertisement → the four requirement rows become verbatim quotes instead of your summary.
- The office manager's name, from a source you have checked independently → an interviewer read and reweighted personas. Do not share the name anywhere until the company is verified.
- Your outcome from B1 → if you confirm which duties you have actually done, the Skeptic bank can be made more specific.
