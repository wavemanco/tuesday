# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd (candidate: Aoife)

Interview: 30-minute video call with the office manager. Relationship: office manager, most likely a hiring-manager-style round; not confirmed.

**Before you reply to that email: this has several signs of a job scam.** See the warning in the message above this pack. Do not pay the €95 fee, do not send a passport photo or bank details, and do not deposit the €1,850 cheque. The interview prep below is for a genuine interview only; if you cannot verify the company, do not attend anything that requires payment or ID first.

Research tier: L0. The one web search for the company was refused, so nothing outside your material was checked.

## How to use + type key

- **Personas** = how a question is asked. **Types** = what is being scored.
- **EXP**: what you actually did. **JD**: stated duties. **CASE**: live problem. **CO** and **VAL** are not used here.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements come from your summary of the ad, not a full copy, so none are in quotation marks.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (your summary of the ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says you ran one shared appointment book for four people. Say it in those terms. Do not describe calendars you did not run. |
| F2 | Booking travel (your summary of the ad) | none given | none | — | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how, in your own words; if you have not, say so plainly and say how you would learn the company's booking tools. |
| F3 | Preparing documents in Word (your summary of the ad) | "good with Word" — your message | medium | [grounded] | none | No gap. Self-rated, so expect a test: have one concrete document you have produced ready to describe. |
| F4 | Preparing documents in Excel (your summary of the ad) | "okay with Excel" — your message | low | [grounded] | presentation | Your material says "okay", so keep the word. Do not describe spreadsheets you did not build. |
| F5 | Processing supplier invoices (your summary of the ad) | "chased unpaid invoices" — your message | low | [inferred] | transferability | Your material says you chased unpaid invoices; it does not say you processed supplier invoices. Keep the quote at its own scope. Answer slot: if you entered, matched or approved invoices, say what and how; if you did not, say so and say what you chased and how. |

Gate rows: none in the material.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices", at its own scope. The material says chasing, not processing. |
| Expert in Excel | Inflated form of F4 | "okay with Excel". |
| Managed the company's calendars | Inflated form of F1 | "ran the appointment book for four physios". |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two gaps: travel and supplier invoices | High (top weight). The ad lists both, and your material shows neither directly. | Answer both gaps plainly, then a concrete ramp plan. |
| Case / Strategist | Live admin problems: a cancelled flight, a clashing calendar, a mismatched invoice | Medium-high. Office managers often test judgement this way. | Clarify first, then say what you would check and in what order. |
| Conversational | Opens with "walk me through your journey" | Medium. Casual, but still scored. | Use a 90-second arc. |
| Data-Driven Prober | Asks how far your Excel went and how the appointment book avoided clashes | Medium. Word and Excel are both named in the ad. | Describe only what you did; say plainly when you did not do a step. |

## Question banks

Ordered by weight. Provenance carries the quoted sentences each guidance cell relies on.

### Skeptic (weight: highest, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role includes booking travel and processing supplier invoices. What's your experience with those?" | JD | [grounded] "chased unpaid invoices" — your message; [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | **Highest-ROI prep.** Hold: "I chased unpaid invoices at the clinic." Answer slot: if you booked travel or entered or matched invoices for anyone, say what and how, in your own words. If you did not, say so plainly, then say what you chased and what you would learn first. Hold through two follow-ups by returning to the chasing, never by adding to it. | F2 and F5 are the two biggest gaps and the ad names both. This objection is almost certain. |
| C2 | "Why would you leave a clinic reception job for an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Give your real reason in one or two sentences. Do not criticise the clinic. Point to the admin duties the ad names. | Motivation consistency is a standard probe for a career switch. |
| C3 | "What would you need to learn first about facilities administration?" | JD | [generic] | Name two or three things you would check in your first week, such as booking tools, approval steps and supplier terms. | A live question about the job, with no claim about your past. |
| C4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" — your message | Name the weakest part honestly, probably travel booking or invoice processing. Then give a concrete ramp plan. | Tests self-assessment. Naming a gap calmly scores better than bluffing. |

### Case / Strategist (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director's flight is cancelled the morning of a board meeting, and two of their calendar holds clash. What do you do?" | CASE | [generic] | Structure it: confirm the facts, decide what is urgent, tell the people affected, rebook, record the change. | Tests structure on a live problem from this role. |
| B2 | "Three supplier invoices arrive for the same job, and one has a different amount. How do you handle them?" | CASE | [generic] | Structure it: check each against the order and the agreed price, ask the supplier, do not pay twice, follow the company's approval rule, and say what you would ask before paying. | Covers invoice processing without assuming your past. |
| B3 | "What would you check first if a spreadsheet of supplier payments did not add up?" | CASE | [generic] | Name the checks in order: formulas and ranges, totals, and any copied or pasted rows. | Tests Excel reasoning without needing an Excel claim you cannot back. |

### Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message; [grounded] "ran the appointment book for four physios" — your message; [grounded] "chased unpaid invoices" — your message | 90-second arc: clinic reception, the appointment book for four physios, chasing invoices, why admin. Use your own words and stay within those three quotes. | A friendly opener that is still scored. |
| D2 | "What do you actually use in Word and Excel these days?" | JD | [grounded] "good with Word" — your message; [grounded] "okay with Excel" — your message | Be specific about what you use. Say "okay" for Excel. Name one Excel skill you would like to improve. | Tests honest self-assessment on the two named tools. |

### Data-Driven Prober (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You're okay with Excel. What's the most complex thing you've built in it?" | EXP | [grounded] "okay with Excel" — your message | Answer slot: name the most complex thing you have built or used in Excel, in your own words. If there was no such step, or it was not yours, say so plainly and describe what you did do. | F4 is the thinnest Excel evidence, so a follow-up is likely. |
| E2 | "Your appointment book covered four physios. How did you stop double bookings?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Answer slot: if you used a method, say what it was. If no step was yours, say so and describe how the book was kept. | F1 is the calendar evidence. This probes the method behind it. |

### Requirement coverage

| Requirement (your summary of the ad) | Covered by |
|---|---|
| Managing calendars | E2, B1 |
| Booking travel | C1, C4, B1 |
| Preparing documents in Word | D2 |
| Preparing documents in Excel | D2, E1, B3 |
| Processing supplier invoices | C1, B2, C4 |

## Reverse questions

Each lands for a reason. Ask two or three.

1. "What does a typical first month look like in this role?" Why it lands: shows you are planning ahead.
2. "Which of these duties is the team stretched on right now?" Why it lands: shows interest in where you would help most.
3. "Which booking tools does the team use for travel?" Why it lands: turns the travel gap into a concrete question.
4. "Who signs off on supplier invoices, and at what amounts?" Why it lands: shows you understand approval steps.
5. "How does the office manager prefer to receive updates on calendars and travel?" Why it lands: shows you plan to work well with them.

## Sources

- Provided documents: the recruiter's email and your summary of the ad and background, as pasted in this conversation.
- Research tier: L0. One query was sent and refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Would have set a values cheat sheet. Query "Brennock Facilities Ltd Ireland company" refused. |
| 2. `Brennock Facilities Ltd interview process` | unavailable | Would have set the loop structure. Same query, refused. |
| 3. `Brennock Facilities Ltd strategy / recent news` | unavailable | Would have checked the company is real and current. Same query, refused. |
| 4. Interviewer name | n/a | No name given, so there is no query to form. |
| 5. Representative JD | skipped | Your summary of the ad already fixes the fit snapshot. |

## Upgrade menu

- The full text of the job ad → replaces the summarised requirements with quoted ones and can upgrade F1 to F5.
- Any travel booking or invoice-processing experience you have, said in your own words → upgrades F2 and F5 from answer slots to grounded evidence.
- The office manager's name → a tailored reverse question and a reweighted interviewer read.
- Search permission for the company → would check the company's existence, registration and recent activity, and deepen the pack's research tier.
- The job board and listing you applied through → helps verify the company (see the warning in the message above).
