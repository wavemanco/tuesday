# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Built for a hiring-manager-style round, since the office manager is likely to own the hire.

## 0. Before you prepare: verify the employer

Do not treat the invitation as genuine until you have checked it. Its requests match a common advance-fee and fake-cheque scam:

- **€95 "equipment registration fee" before interview.** Legitimate employers do not charge candidates to interview or register.
- **Passport photo and bank details before interview.** Not needed at this stage. Do not send either.
- **Cheque for €1,850 to deposit, then send the balance to a vendor.** This is the fake-cheque pattern. The cheque can bounce after your payment has gone out, and the loss is yours.
- **Contact address is hr@brennock.example.** The `.example` domain is reserved for documentation and is not a real company domain. Check the company through its registered details and a website you find yourself.

Do not pay, do not send ID or bank details, and do not deposit any cheque. You can still take the interview if you verify the company independently.

## 1. How to use + type key

Personas are how the question is asked. Types are what is being scored.

- **EXP**: what you actually did
- **JD**: can you do the listed job, including its gaps
- **CASE**: how you structure a live problem
- **VAL**: behaviour in past situations (no published values were available, so this type is not used)
- **CO**: company knowledge (none researched)

Guidance is scaffolding, not a script. Say it in your own words.

## 2. Fit snapshot

Requirements are the ad as you summarised it: "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices". Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad (your summary) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The quote already reaches calendar work. Say it in those terms: you ran the appointment book for four physios. |
| F2 | "booking travel" — ad (your summary) | "none given" | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if not, say so and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word and Excel" — ad (your summary) | "good with Word" — your message; "okay with Excel" — your message | medium | [grounded] | transferability | Word is supported. Excel is stated as "okay", so do not stretch it. Answer slot: name one thing you do in Excel and one you would need to learn. |
| F4 | "processing supplier invoices" — ad (your summary) | "chased unpaid invoices" — your message | low | [inferred] | transferability | Chasing unpaid invoices is adjacent to processing them. Do not claim you processed invoices. Answer slot: if you entered, matched or approved any invoices, say so; if not, say so and describe the chasing. |

## 3. Prohibited claims

Built locally from the fit snapshot. Do not say these, in any form:

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F4 | "I chased unpaid invoices." The limit is this pack's observation: your material shows chasing, not processing. |
| Expert or strong in Excel | Inflated form of F3 | "Okay with Excel." |
| Managed travel bookings | Not in your material (F2) | Answer slot only. |

## 4. Persona weights

- **Skeptic (highest weight, 4 questions):** an office manager hiring an admin assistant mostly wants to know where your gaps are.
- **Case (3 questions):** they will likely give you one practical scenario.
- **Conversational (2 questions):** the opener and the close are scored too.

## 5. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of these tasks would you be least confident doing on day one?" | JD | [grounded] "ran the appointment book for four physios"; "good with Word"; "okay with Excel" | Name the task you have not done yourself, then say how you would learn it. Answer slot: if you have done travel booking or Excel work beyond the basics, say what; if not, say so. | This is the highest-ROI rehearsal: the gaps in F2 and F3 are where this will be probed. |
| A2 | "You've been a receptionist. What makes you ready to process supplier invoices?" | JD | [grounded] "chased unpaid invoices" | Say what you did with unpaid invoices, in your words. Answer slot: if you entered, matched or approved invoices, say how; if not, say so and say what you would do first. | F4 is the widest gap in the ad. Do not present chasing as processing. |
| A3 | "How would you rate your Excel, honestly?" | JD | [grounded] "okay with Excel" | Use "okay" and back it with one thing you do. Name one skill you would need to build. | F3. Honest calibration scores better than an inflated rating. |
| A4 | "Why an administrative role after reception?" | JD | [grounded] "ran the appointment book for four physios" | Tie the move to the work you already do: scheduling and invoices. Keep it short. | Motivation consistency check. |

### B. Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director needs travel for a conference in three weeks, with two changes to the schedule. How would you handle it?" | CASE | [generic] | Clarify: who is travelling, the budget, the policy, and the fixed dates. Then check the schedule, book, and confirm with the traveller in writing. Say what you would ask before you book. | Generic scenario from the ad's travel line; no claim about your past. |
| B2 | "A supplier invoice arrives with no purchase order. What do you do?" | CASE | [generic] | Check the PO, the goods receipt, and who approved the order. Ask the supplier and the budget holder before paying. | Generic invoice process; say what you would check, not what you did. |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices" | 90 seconds: two years at the clinic, the appointment book for four physios, chasing invoices, then why you are here. | F1 and F4 are your strongest material. Keep it to what you did. |
| C2 | "What's a typical week like in your current role?" | JD | [grounded] "ran the appointment book for four physios" | Describe the scheduling routine in your words. Answer slot: name any tool or system you used. | Casual openers are scored. |

### Reverse questions

Each one lands for a reason:

1. What does a successful first month look like? (Shows you are planning to deliver.)
2. Which tasks are most time-sensitive? (Shows you think in priorities.)
3. How are supplier invoices approved today? (Tests the invoice process you are asked to own.)
4. What tools do you use for calendars and travel? (Tests your Word, Excel and booking gap.)
5. Does any part of the hiring process involve paying a fee or sending bank details? (A direct check on the email you received. A real employer answers this plainly.)

## 6. Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars | C2, A4 |
| Booking travel | A1, B1, reverse 4, none beyond these (F2 is thin) |
| Word and Excel | A3, A1 |
| Processing supplier invoices | A2, B2 |

## 7. Sources

Provided documents only. No web research was run (tier L0). The skill's research targets were not run, so the pack contains no company values, strategy or interviewer information.

## Upgrade menu

- The office manager's name → a tailored reverse question and persona weights from their public footprint (after you have verified the company)
- A job description copied from the original listing → the ad's requirements become `[grounded]` instead of your summary
- Research at the standard tier → company context for the case questions
