# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager (name not given)
**Built on:** the recruiter email and your message. No web research ran (search was refused in this session).

## Before you reply to this email

This email has the signs of a fake-job or fake-cheque scam. Please do not act on it yet.

- Employers do not charge candidates a "registration fee" to be interviewed or to equip a job. Do not pay the €95.
- A passport photo and bank details are not needed to book an interview. Sending them invites identity theft.
- Depositing a cheque and sending the "balance" to a vendor is the classic fake-cheque scam. A cheque can appear to clear for days and then bounce, and the money you sent is gone.
- The contact address (hr@brennock.example) and the "supplier" IBAN cannot be verified from the email itself.

**What to do:**

1. Check the company yourself. Search the Companies Registration Office (cro.ie) for Brennock Facilities Ltd. Find its website and phone number through your own search, not from this email.
2. Check that the job appears on the company's careers page.
3. If you want to continue, reply only to confirm your interest. Ask for the interview through a channel you verified, and ask for the company's registration number. Send no money, ID or bank details.
4. If you have already sent anything, contact your bank now and report the email to the Gardaí.

The prep below works for any real interview. If the company cannot be verified, do not attend.

## 1. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **JD**: can you do the listed job, including its gaps
- **EXP**: whether your past claims hold up under questions
- **CASE**: a live problem from the role, reasoned aloud

No company values or strategy research was available, so there are no VAL or CO questions. Guidance is scaffolding, not a script.

## 2. Fit snapshot

The ad's duties are as you summarised them. Quotes marked "your message" are your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as you summarised it) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows one appointment book for four people, not calendars across an organisation, so the bridge stops at the book. Words: "I ran the appointment book for four physios." Answer slot: expect a probe on how you ran the book day to day. If you have a specific way of doing it, say it in your own words; if not, say so and describe the book as it was. |
| F2 | "booking travel" (the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for someone, say what and for whom; if you have not, say so plainly and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word and Excel" (the ad) | "good with Word" (your message); "okay with Excel" (your message) | low | [grounded] | discovery | Your Word statement touches the requirement but does not show how far it reaches. Excel is the thinnest evidence in the pack. Answer slot: say what you have used Excel for, in your own words; if the use was light, say so. |
| F4 | "processing supplier invoices" (the ad) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices means money owed to the clinic. Paying supplier invoices is the other direction. Words: "I chased unpaid invoices." Answer slot: if you entered or checked supplier invoices for payment, say what you did; if not, say so plainly. |
| F5 | "Remote Administrative Assistant" (the recruiter email) | none given | none | [grounded] | discovery | Your material does not show remote working. Answer slot: if you have worked remotely, say how; if not, say so plainly and say how you would keep a remote routine. |

## 3. Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars across an organisation | Inflated form of F1, which widens "the appointment book for four physios" | F1's quote at its own scope. The pack's observation: your material shows one book for four people. |
| Processed supplier invoices | Inflated form of F4, which widens "chased unpaid invoices" | F4's quote at its own scope. The pack's observation: your material shows chasing unpaid invoices, not paying supplier invoices. |
| Advanced Excel | Inflated form of F3, which widens "okay with Excel" | "okay with Excel", at its own scope |
| Booked travel | Not in any of your material | No claim. The answer slot in A4 is the only route. |

## 4. Persona table

Relationship prior: hiring manager, which weights Case and Skeptic highest. You gave no interviewer profile, so there is no adjustment. A 30-minute call also means fewer questions, so the Skeptic bank carries most of the time.

| Persona | How it shows up here | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Goes through the ad's four duties and asks which you have done | High | Answer line by line, state gaps plainly, hold through two follow-ups |
| Case / Strategist (weight 3) | Short live problems on calendars, travel and invoices | High | Clarify, then structure, then think aloud |
| Conversational (weight 3) | Opens with your journey and a casual question about the desk | High | 90-second arc; treat casual questions as scored |
| Data-Driven Prober (weight 2) | Asks for a figure about the appointment book | Medium | Give a figure only if you know it; otherwise say so |
| Pressure (weight 2) | Challenges whether you can do travel and invoices at all | Medium | Pause, restate, hold, concede specifically |

## 5. Question banks

Twelve questions in total. A 30-minute call and four duties in the ad cannot use more, and the banks are built to that limit. Answer slots are instructions for the interview, not questions to you.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've spent two years on a clinic front desk. Why an admin role now?" | JD | [grounded] "ran the appointment book for four physios" (your message) | Answer with the book you ran, then one reason for the move in your own words. Answer slot: if a specific reason sits behind the move, say it plainly and briefly; do not offer a reason you do not hold. | Motivation is the Skeptic's first probe. F1 is the only bridge in your material, so it carries the opening. |
| A2 | "Calendars, travel, Word and Excel, supplier invoices: which of these have you actually done?" | JD | [grounded] "ran the appointment book for four physios" (your message); "chased unpaid invoices" (your message); "good with Word" (your message); "okay with Excel" (your message) | **Highest-ROI prep.** Go through the list in order: the appointment book for four physios, chasing unpaid invoices, Word, and Excel at the level you named. For travel, say plainly that you have not booked it, if that is true. Hold through two follow-ups by returning to what you did. Answer slot: for supplier invoices, say whether you entered or checked any; if you did not, stay with the invoices you chased. | Four duties in the ad and two loosely covered in your material. This is the objection most likely to come up in some form. A plain answer lands better than a stretched one. |
| A3 | "Tell me how you've processed a supplier invoice." | JD | [grounded] "chased unpaid invoices" (your message) | Premised question: it presumes you processed supplier invoices, which your material does not show. Answer slot: if you processed supplier invoices, say how, in your own words. If you did not, say so plainly, then say what you did with unpaid invoices and what you would check first on an invoice. | F4. The ad raises supplier invoices, so this is likely. The second branch allows that the premise is false. |
| A4 | "Booking travel is part of the job. Tell me about a trip you've booked for someone." | JD | [grounded] none given; requirement from the ad | Premised question. Your material shows no travel booking. Answer slot: if you have booked travel for someone, say what and for whom; if you have not, say so plainly and say how you would learn the company's booking tools. | F2, the one duty with no evidence at all. |
| A5 | "How would you use Excel in this role?" | JD | [grounded] "okay with Excel" (your message) | Say what you have used Excel for, in your own words. If the use was light, say so, then say how you would build the skill for the role. | F3. "Okay" is the only Excel evidence, and a probe will test it. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How many appointments did the book carry in a typical week, and how did you keep it accurate?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Give a figure only if you know it. If you do not, say so, then say how you would estimate it. Answer slot: name the part of the book that was yours to keep, in your own words. | The prober asks for the denominator. Your material has no figure, so the guidance supplies none. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two years at a reception desk. Why should I trust you with travel and invoices?" | JD | [grounded] "chased unpaid invoices" (your message) | Pause, restate the question, then answer with what you did. Hold your position through two follow-ups. Concede specifically what you have not done, such as travel. Do not fold on the claim you can back. | Tests composure on the gaps. Hold, then concede. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The director's flight changes at 8am and she needs to be rebooked. Walk me through it." | CASE | [generic] | Clarify which flight, what the change terms allow, and what she needs. Then confirm the new booking, update her calendar, and tell her. Think aloud. | A live problem from the travel duty. It makes no claim about your past. |
| D2 | "Two requests land for the same room in one shared calendar. What do you do?" | CASE | [generic] | Clarify who booked first and what the priority is. Check the room, offer an alternative, and confirm in writing. | A live problem from the calendar duty. |
| D3 | "A supplier invoice arrives with no purchase order number. What do you do before it is paid?" | CASE | [generic] | Clarify what the order was for, check who approved the spend, hold the invoice, and ask the supplier for the order number. | A live problem from the invoice duty. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, the book, the invoices, and why admin. Keep to the scope the sentence states. | Opening questions are scored on economy. |
| E2 | "What's the most useful thing you learned on a desk?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | One concrete thing, in your own words, linked to the book. | A casual question that is still scored. |

## 6. Requirement coverage

| Requirement | Question IDs |
|---|---|
| Managing calendars | A1, B1, D2 |
| Booking travel | A4, D1 |
| Preparing documents in Word and Excel | A2, A5 |
| Processing supplier invoices | A2, A3, D3 |
| Remote working | none, and why: your material shows no remote work. Reverse question R5 covers it. |

## 7. Reverse questions

1. **"What does a normal week look like for whoever takes this role?"** Why it lands: shows you are planning for the job, not just the title.
2. **"Which of the four duties takes the most time right now?"** Why it lands: shows you where the weight sits, so you can focus your preparation.
3. **"What tools do you use for calendars, travel and invoices?"** Why it lands: you learn the systems, and the gaps in A2 and A4 become visible early.
4. **"What happens after this 30-minute call?"** Why it lands: a legitimate process has a clear next step.
5. **"How does the team work remotely, and how often do you meet?"** Why it lands: covers remote working, which the recruiter's title makes central.

## 8. Sources

- Provided: the recruiter email; your message (background and the ad's duties, as you summarised them).
- Searches: one attempted ("Brennock Facilities Ltd Ireland"). Refused: web search permission was not granted in this session.

**Research tier:** L1, searches 1 of 6 (refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values sheet, which is absent. Search was refused. |
| 2. Interview process for the role | unavailable | Loop structure and persona weights. Search was refused. |
| 3. Company strategy and recent news | unavailable | CO questions. Search was refused. |
| 4. Interviewer name and company | n/a | No name was given. |
| 5. Representative JD | skipped | The duties you summarised fix the fit snapshot. |

## 9. Upgrade menu

- **The full text of the ad:** the four duties are quoted verbatim in the fit snapshot, and A2 can use its exact wording.
- **The interviewer's name:** persona weights from public background, and a reverse question tied to their career path.
- **Your answers to the slots in A2 to A5, in your own words:** F2 to F4 move from gaps to stated evidence, and the banks are rewritten around them.
- **Web search, if granted:** company values and recent news, which add a values sheet and CO questions.
