Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-7-rooms-case-13-denied-54f94ad6/3406675b-1d13-4b27-8835-4268cd54d652/scratchpad/quillmoor_operations_coordinator_interview_pack.md`.

Web search was refused, so the pack has no company values and no information on the interview process. The call is tomorrow (Thursday 26 November), so the pack's triage section puts the SAP question first.

The three things most likely to come up:
- **SAP (question B2):** the advert names it and you've said you've never used it. Say "I've never used SAP" plainly, then give a plan for learning it. This is the highest-value prep in the pack.
- **The one-third drop in discrepancies (C1 to C4):** know how it was counted, what it depends on, and which part was yours.
- **Your reason for leaving (A2):** the office closing and the Reading offer, in your own words. The pack avoids adding anything about the employer.

I can rehearse B2 with you as the Skeptic. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

Two questions before tomorrow:
1. What's your notice period?
2. What's your current salary?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** 30-minute recruiter screen, by phone, Thursday 2pm (tomorrow, 26 Nov)
**Interviewer:** Hannah Lowther, Talent Partner
**Candidate:** Sam
**Built from:** the advert, your message, and Hannah's message. Web research was not run (search permission was refused), so this pack has no company values, no interview-process detail and no interviewer read.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **EXP** = your own past work, tested for accuracy. **JD** = the advert's requirements. **CO** = company knowledge (none in this pack). **CASE** = a live problem. **VAL** = values (none in this pack).
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Your call is tomorrow, so work in this order:

1. **B2 and F7: SAP.** Say the plain line "I've never used SAP" and your plan for learning it. This is the likeliest knock-out question.
2. **C1 to C4: the one-third figure.** Know how it was counted, what it depends on, and which part was yours.
3. **A3 and A5: pay and notice.** Have your numbers ready. A5 needs your notice period, which the pack does not have.
4. **A2 and B5: your reason for leaving**, said once aloud so it comes out plainly.
5. Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say the four years in those words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production planning or QA. Describe the delivery work and stop there. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. Your own words cover it: "chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" and "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. The figure will draw a probe on how it was counted (C1 to C4). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you produced a regular report on delivery timing, say what it measured and who read it. If you did not, say so, and say how you would set one up. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material says "spreadsheet", not Excel. Answer slot: name the tool you built it in, and what it did. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | none for SAP | [grounded] | capability | Words for you: "I've never used SAP." Then how you would learn it, as a plan, never as a past. Do not describe the in-house system as ERP experience. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Gate shown met by your own constraint. Say it as you said it. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Gate shown met: your target sits inside the advert's range. |

Notes: the advert does not mention notice period or right to work, so the pack has no row for them. Notice is covered in A5.

## Prohibited claims

Each entry says what this pack will not coach, and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling or QA coordination | Inflated form of F2 | "I schedule deliveries for our three depots." Your material shows the delivery work, not production planning. |
| Any SAP or ERP experience | Negative you stated (F7) | "I've never used SAP." Then your plan to learn it. |
| Built the stock count in Excel | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." The tool is an answer slot. |
| Sole credit for the one-third drop in discrepancies | Inflated form of F4 | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." Say what was yours, and say what others did if you know. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, logistics checks, motivation | **Top weight, 5 questions.** Recruiter screens run on this register; the risk is treating it as unscored. | Rehearse a 90-second background arc. Answer the logistics checks plainly. |
| Skeptic | Motivation and knock-out checks: SAP, Excel, dispatch reporting | **4 questions.** Recruiter screens check the advert's requirements and reason for moving. | Say the gap in one plain sentence, then your plan. Do not bluff. |
| Data-Driven Prober | Asks how the one-third figure was counted | **4 questions.** The figure is the CV claim most likely to be probed. | Know what you can say about the count. Name the weakest assumption before they do. Say plainly what you do not know. |
| Pressure | Challenges pay or the production-scheduling jump | **2 questions, low weight.** Recruiter screens rarely hold pressure. | Hold your number or your fact for two follow-ups. Concede only what is true. |
| Case / Strategist | A "what would you do" scenario | **3 questions, light.** Recruiter screens sometimes ask one live problem. | Clarify first, then give a short ordered plan. |

## Question banks

### Conversational (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, and what a normal week looks like." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc: four years in logistics coordination, the three depots, the supplier chasing, in your own words. | F1 and F3 are the evidence for the experience and supplier requirements. |
| A2 | "Why are you looking to move on?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the office closing and the relocation offer, in those words. Do not add anything about the employer or your colleagues. | Motivation check. The reason is clean and stated, so keep it that way. |
| A3 | "What are you hoping to earn?" | JD | [grounded] "I'm hoping for £42,000" (your message); "£38,000–£44,000" (advert) | Give £42,000. You may note you have seen the advert's range. If there is a figure below which you would not move, say it; if not, say so. | F9: the target sits inside the advert's range. |
| A4 | "Is two days a week in Avonmouth workable for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Yes, two days is fine. Three is your limit. Do not add commute times you have not given. | F8: the gate is met by your own constraint. |
| A5 | "What's your notice period?" | EXP | [generic] | Answer slot: say your notice period in your own words. The pack does not know it. | Knock-out check. The notice period is the input the pack is missing; see the questions in the closing message. |

### Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules with planning, the warehouse and QA. What's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots" (your message); "Coordinate production schedules between planning, the warehouse and QA" (advert) | Say the delivery work in its own terms. Answer slot: if you have scheduled production or coordinated with QA, say how; if you have not, say so, and say what you would do to learn it. | F2 is a transferability gap. The guidance stays inside the delivery scope. |
| B2 | "You've never used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP" (your message); "ERP experience (SAP or similar) a plus" (advert) | Plain line first: "I've never used SAP." Then a plan: the system you would learn, the first thing you would do. Do not describe the in-house system as ERP experience. | F7 is a stated gap. This is the highest-ROI prep in the pack: the advert names SAP and you have said you have not used it. |
| B3 | "Have you ever reported on on-time dispatch?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you produced a regular report on delivery timing, say what it measured and who read it. If you did not, say so, and say how you would set one up. | F5 is a discovery gap; the material is silent. |
| B4 | "What's the most complex thing you've built in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message); "confident with Excel" (advert) | Describe the rebuild in your own words. Answer slot: name the tool it was built in. If it was not Excel, say what it was. | F6 is a discovery gap. The question presumes the tool; the guidance does not. |

### Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was that discrepancy figure counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Answer slot: say how the count was taken, in your own words. If you do not know how it was counted, say so. | F4: a figure the candidate gave raises this slot. The pack does not supply a method. |
| C2 | "What assumption behind that figure would you defend least?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Name the weakest assumption you know of, before they do. Answer slot: if you cannot name one, say so. | F4: a metric question; the weakest-assumption move is the one that converts a probe into a credibility point. |
| C3 | "Which stock lines or depots did that figure cover?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Say the scope in your own words. Answer slot: if you do not know the scope, say so. | F4: keeps the figure attached to its own noun. |
| C4 | "What did the rebuild change, and how much of the improvement was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" (your message) | Say what you changed in the sheet. Answer slot: if others changed the count process, say so plainly. | Prober check on attribution. Pairs with the prohibited entry on sole credit. |

### Pressure (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why should we believe a logistics coordinator can run production scheduling?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Hold: "I've coordinated deliveries across three depots for four years and chased suppliers when orders slipped." Concede only what is true. Answer slot: if you have done production scheduling, say how; if not, say so. | F2 is a transferability gap; the hold stays at the delivery scope. |
| D2 | "Sixty seconds: why £42,000?" | JD | [grounded] "I'm hoping for £42,000" (your message); "£38,000–£44,000" (advert) | Give the number and the reason you gave in your message. Hold for two follow-ups. Answer slot: if there is a floor, say it; if not, say so. | F9 is met; the hold is the number you stated. |

### Case / Strategist (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier's delivery slips two days before a planned production run. What do you do first?" | CASE | [generic] | Clarify: what is confirmed, what stock is on hand. Then order the steps: tell planning and QA, check the warehouse, agree options with the supplier. | A live problem from the advert's supplier and planning lines. Pattern only; no claim about your past. |
| E2 | "A week's dispatch is running behind target. What do you check?" | CASE | [generic] | Check the order backlog, the warehouse capacity and the carrier schedule, in that order. | A live problem from the weekly on-time dispatch line. Pattern only. |
| E3 | "A stock count shows a shortfall against the system. What is your first check?" | CASE | [generic] | Check the count and the system record before changing either. Then trace the movements. | A live problem from the stock-accuracy line. Pattern only. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1, E1 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, C2, C3, C4, E3 |
| Report weekly on on-time dispatch | B3, E2 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B2 |
| Salary £38,000–£44,000 | A3, D2 |
| Hybrid, two days at Avonmouth | A4 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does success look like in the first three months?" | Shows you are planning the job, not just applying for it. |
| "Is the weekly dispatch report produced now, and who reads it?" | Tests the F5 gap from the other side and shows you read the advert. |
| "What systems will I use day to day, and how is stock tracked?" | Gives the SAP question a fair hearing without claiming experience. |
| "How do planning, the warehouse and QA usually share schedule changes?" | Puts the seam in front of them; it is the requirement you are least sure of. |
| "What are the next steps, and roughly what is the timing?" | Recruiters weight this as a signal of interest. |

## Sources

- Provided documents: the Operations Coordinator advert, Sam's message, Hannah Lowther's message.
- Searches sent: "Quillmoor Diagnostics values Avonmouth" and "Quillmoor Diagnostics Operations Coordinator recruitment interview process". Both were refused: web search permission was not granted.

Research tier: L1, searches 0 of 6 returned results, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet: omitted. Both calls refused. |
| 2. Quillmoor interview process, Operations Coordinator | unavailable | Round structure and persona weights: default priors used. Both calls refused. |
| 3. Company strategy or recent news | unavailable | Grounding brief: omitted. The inputs do not supply it. |
| 4. Hannah Lowther, public footprint | unavailable | Interviewer read and a tailored reverse question: omitted. No query was sent. |
| 5. Representative JD | skipped | The advert supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your notice period → A5 becomes a grounded line in your own words.
- Your current salary → A3 gains a line setting your ask against what you earn now.
- Permission to run web search → L1 research: the company's values (a values cheat sheet, only if the screen is values-led) and a check on the screen's format.
- The name of the tool you built the stock count in, and whether you produced a dispatch report → F5 and F6 move from answer slots to grounded lines.
- Hannah's public career path → one reverse question tuned to it. Optional.
- A `tuesday-dossier.md` from a job-underwriter run would add verified evidence and a prohibited-claims list.
