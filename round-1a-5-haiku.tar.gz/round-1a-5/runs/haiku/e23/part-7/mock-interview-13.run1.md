Your prep pack is saved here: `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-7-rooms-case-13-denied-499741a3/83e5a7cd-dd4d-434e-ac0a-9f219ea3a290/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It has the full fit snapshot, the question banks, the reverse questions and the prohibited claims. I built it from the advert, Hannah's message and your background. I did not run any web research on Quillmoor.

**Two things to fill in before Thursday:** your notice period, which Hannah will ask about and I don't have, and your lowest acceptable salary. Both are questions at the end.

**The four agenda answers** (say each in under 90 seconds):

- **Salary (A1):** "I'm looking for around £42,000." Then stop. The advert's range is £38,000 to £44,000, so this sits in the upper half.
- **Notice period (A2):** State it exactly as your contract says, in weeks or months.
- **Hybrid (A3):** "Two days at Avonmouth works from north Bristol. I'd want to keep it to two, and three at most." Then ask which days the team is on site. Check the commute from north Bristol at a peak time before the call.
- **Reason for moving (A4):** "The Bristol office is closing next year, and the only option offered is relocating to Reading, which doesn't suit me. I'm looking for a role in Bristol." Keep it neutral and don't add motives you haven't stated.

**Where you're most likely to be probed:**

- **The third (B2).** "Discrepancies fell by about a third over a year" is the figure most likely to be questioned. Be ready to say how it was counted, what it was measured against, and whether the drop came from your rebuild or from other changes that year. If you don't know how it was counted, say "I'd need to check how we counted." Don't explain the figure beyond what you can repeat.
- **SAP (B4).** Say: "I haven't used SAP. We run our own in-house stock system." Then give your plan for learning it. The advert says ERP is a plus, not a requirement.
- **Production and QA (B1).** The advert asks for production scheduling across planning, warehouse and QA. Your experience is scheduling deliveries across three depots. Describe that accurately and don't stretch it.
- **Weekly dispatch reporting (B3).** Nothing in what you've told me covers this. If you have produced regular reports, say what they tracked. If not, say so and say what you would track first.

**Questions to ask Hannah** (pick two or three): the budgeted salary range; which days the Avonmouth team is on site and whether that pattern is fixed; and the next steps and rough timing.

Two more things, in the same spirit as the pack:

- **Offers:** I can run a practice call with Hannah's questions, so you can rehearse the B2 follow-ups out loud. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- **Questions for you:**
  1. What is your notice period?
  2. What is your lowest acceptable salary, if you have one?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Call: Thursday, 2pm, 30 minutes, by phone to your mobile. Interviewer: Hannah Lowther, Talent Partner.
Built from: the advert, Hannah's LinkedIn message, and your background as you described it. No web research was run for this pack (tier L0).

## How to use this

- **Persona:** one recruiter screen. Hannah's agenda is pay, notice, hybrid pattern, reason for moving, then the team and next steps. Expect her to check deal-breakers first.
- **Types:** EXP = what you actually did. JD = whether you can do the listed job. PROC = recruiter logistics, not one of the five scored types.
- This is scaffolding, not a script. Say the answers in your own words.

## Prep triage

1. Fill the two gaps: your notice period and your lowest acceptable salary (questions below).
2. Say the four agenda answers out loud, each under 90 seconds: A1 to A4.
3. Rehearse B2, the stock-count figure. It is the likeliest probe.
4. Rehearse B4, the SAP answer.
5. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | high | [grounded] | none | No gap. Say the title and the four years. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows scheduling across three depots, not production scheduling and not QA. Keep the bridge at that scope. Answer slot: if you have coordinated with a team that controls a step you do not, say how you handled it. If you have not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message, "I ... chase suppliers when orders slip") | high | [grounded] | presentation | Your words already reach this. Say them as they are. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The quote reaches the requirement. The figure is approximate and its cause is not shown in the material. That is what B2 rehearses. |
| F5 | "weekly report on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: if you have produced regular performance reports, say what they tracked and for whom. If you have not, say so plainly and say what you would track first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [inferred] | discovery | A spreadsheet is not the same as Excel skill. The material does not show which tool or which features. Answer slot: say what the spreadsheet was built in and which features you used. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn SAP, said as a plan, never as a past. The ERP line is a plus, not a requirement. |

**Gate check:** none of the requirements is a hard gate. The hybrid pattern and salary are conditions Hannah will check, handled in A1 and A3.

## Prohibited claims

These are not to be coached, in any answer, under any follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've run production scheduling" or "I coordinated production" | Inflated form of F2. The material says deliveries across three depots. | Your F2 quote at its own scope. Your material says deliveries, across depots. |
| "I've used SAP or another ERP" | Stated absence, F7 | "I haven't used SAP." Then the plan for learning it. |
| "The rebuild cut discrepancies by a third" as a proven cause | Inflated form of F4. The quote says the drop happened over the year, alongside the rebuild. The cause is not shown. | "Discrepancies fell by about a third over a year, after I rebuilt the spreadsheet." Stop there unless you can show the link. |
| "I produced weekly dispatch reports" | Inflated form of F5. No quote supports it. | Answer slot under B3 only. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Screener (Hannah) | Checks pay, notice, hybrid and motive first, then basic fit | Certain. Her agenda names them. | Answer each in one or two sentences, then stop. Let her move to the next item. |

## Question banks

### Bank A: agenda items (Screener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | PROC | [grounded] "I'm hoping for £42,000." (your message) | Say the number first: "I'm looking for around £42,000." Then stop. If she asks for a range, say what you would accept. Your lowest figure is still open. See question 2 below. | The advert shows £38,000 to £44,000, so £42,000 is in the upper half of that range. Your number is yours to state. |
| A2 | "What's your notice period?" | PROC | none given | Answer slot: state your notice period exactly as your contract says it, in weeks or months. | Hannah has named notice as a topic. Fill this before Thursday. |
| A3 | "How would the hybrid pattern work for you?" | PROC | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | "Two days at Avonmouth works from north Bristol. I'd want to keep it to two, and three at most." Then ask which days the team works on site. | Hannah is checking a deal-breaker early. Your ceiling of three days is the honest version. Before the call, check the door-to-door commute from north Bristol at a peak time. |
| A4 | "What's prompting the move?" | PROC | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | "The Bristol office is closing next year, and the only option offered is relocating to Reading, which doesn't suit me. I'm looking for a role in Bristol." | A true and neutral reason. Do not criticise the employer or add a further motive you have not stated. |

### Bank B: role and experience (Screener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through what your scheduling work involves." | EXP | [grounded] "I schedule deliveries for our three depots" and "chase suppliers when orders slip" (your message) | Describe how the scheduling worked across the three depots and what you do when an order slips. Use your words. Answer slot: the advert asks for production scheduling across planning, warehouse and QA, so expect a probe on that. If you coordinated with a team that controls a step you do not, say how. If you did not, say so plainly and stay with the depot scheduling. | F2 is the transferability gap, and this is where a probe would land. |
| B2 | "Discrepancies fell by about a third after your rebuild. How much of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Defend the number in your own words. Say what you rebuilt and what was yours to do. Name the assumption you would defend least: that the drop came from the rebuild rather than from other changes over the year. Answer slot: if you know how the discrepancies were counted and against what baseline, say it. If you do not, say "I'd need to check how we counted." | F4 is the most probed figure on your CV. The quote gives the figure and the period only. |
| B3 | "The role runs a weekly report on on-time dispatch. What have you reported on?" | JD | [grounded] "weekly report on on-time dispatch" (advert) | Answer slot: if you produced a regular report, name what it tracked and how often. If you did not, say so plainly, then say what you would track first. | F5 is the one requirement with no quote. Hannah may not ask this, but the hiring manager will. |
| B4 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | "I haven't used SAP. We run our own in-house stock system." Then the plan: how you would learn SAP, such as courses or a shadowing period. Never claim ERP experience. | F7 is a stated absence. The advert calls ERP a plus, so you can name it without apology. |
| B5 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Say what you built and which features you used, in your own words. Answer slot: name the features you used, if you can name them. If you cannot, say so and say what you would learn first. | F6 is the evidence for Excel. The quote shows a spreadsheet rebuild, not which tool or features. |
| B6 | "Tell me about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | About 60 to 90 seconds: your title, the four years, the three depots, the supplier chasing, and the stock-count rebuild as one concrete example. | An opener sets the tone of the rest of the screen. |

### Requirement coverage

| Requirement (advert) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | B6 (F1) |
| Coordinate production schedules across planning, warehouse and QA | B1 (F2, transferability). Partly covered. |
| Track supplier deliveries, chase late orders | B1, B6 (F3) |
| Keep stock records accurate | B2 (F4) |
| Weekly on-time dispatch reporting | B3 (F5). Discovery gap. |
| Confident with Excel | B5 (F6) |
| ERP, SAP or similar (plus) | B4 (F7) |
| Salary £38,000 to £44,000 | A1 |
| Hybrid, two days at Avonmouth | A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What's the budgeted range for this role?" | Shows you read the advert's range and want to see where your figure sits. |
| R2 | "Which days would the Avonmouth team be on site, and is the two-day pattern fixed?" | Concrete logistics. It checks how much flexibility there is. |
| R3 | "Who would this role report into, and who would I coordinate with day to day across planning, warehouse and QA?" | Maps the cross-team coordination in the advert onto real people. |
| R4 | "How is on-time dispatch measured today, and who reads the weekly report?" | Shows you know the report matters, and tests the F5 gap. |
| R5 | "Which ERP does the team use today?" | The advert says "SAP or similar". The answer tells you how big the ERP gap is. |
| R6 | "What are the next steps, and roughly when would I hear about the next stage?" | Hannah has promised next steps. This confirms the timing. |

## Upgrade menu

- Your notice period → A2 becomes a real answer. Required before the call.
- Your lowest acceptable salary → A1 gets a walk-away line.
- Hiring manager's name → a tailored reverse question and an interviewer read.
- Research on Quillmoor (L1) → a grounding brief on the company and its process, and sharper reverse questions.
- Any focus areas Hannah names during the call → the banks reweighted for the next round.
