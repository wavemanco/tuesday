# Interview prep: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, Thursday 2pm, 30 minutes by phone, with Hannah Lowther (Talent Partner). Hannah will ring the mobile number on your application. Hannah's stated agenda: salary expectations, notice period, how the hybrid pattern works, reason for moving, then the team and next steps.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: `JD` (the advert's requirements), `EXP` (what you actually did), `CASE` (a live problem). Terms questions are not scored, so they sit in their own table with no type.
- Guidance is scaffolding, not a script. Say it in your own words.
- Quotes in the Provenance and Evidence columns are your own sentences, from your message to me. Nothing else is treated as your experience.
- **Answer slots** are instructions for the call, not questions to me. They tell you what to say if the question goes further than your material.

## Prep triage (30 minutes)

1. Say your salary line and your notice period out loud until they come easily (Terms table).
2. Rehearse Q2, the production, planning and QA question. It is the most likely push-back, because the advert leads with it and your material does not show it.
3. Rehearse Q4, the discrepancy figure: how it was counted and how much of it was yours.
4. Have your reason for moving in one sentence.

Everything else is insurance.

## Fit snapshot

Requirements are the advert's own words. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator at a building-supplies wholesaler. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows scheduling deliveries across three depots. It does not show production schedules or QA. Keep the bridge at that scope: "I schedule deliveries for our three depots." Answer slot: if you coordinated between planning, the warehouse or QA, say which and how, in your own words. If you did not, say so plainly and say what you would need to learn first. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. Say it as written: I chase suppliers when orders slip. |
| F4 | "keep stock records accurate" (advert) | "rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms. Reword only: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." Add no figure. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on delivery or dispatch timeliness, say what, how often, and to whom. If you have not, say so plainly and say what you would track first. |
| F6 | "confident with Excel" (advert) | "rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your quote shows a spreadsheet, not which tool or how deep you went. Answer slot: name the tool you used and the most involved thing you did in it, in your own words. |
| F7 | "ERP (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | high | [grounded] | capability | You have stated the absence. Words: "I haven't used SAP. We run our own in-house stock system." If it comes up, say how you would learn it, as a plan and never as a past. |

Your material does not establish production or regulated-QA experience. That is the pack's own observation, not words for you. It is why F2 is the row to rehearse.

## Prohibited list

These are wordings this pack will not coach, because your material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material shows deliveries across depots, not production scheduling. Q2's answer slot stays inside the deliveries. |
| The discrepancy drop was mine alone | Inflated form of F4 | F4's quote at its own scope. Your material does not show how much of the drop was yours and how much came from the wider team. Q4 asks you to say which. |
| Experience with SAP or ERP | Sourced entry: your own negative, F7 | The plain acknowledgment: "I haven't used SAP." No slot. |
| Advanced or expert Excel | Inflated form of F6 | F6's quote at its own scope. Name the tool and the work you did in it. |

## Your terms (Hannah's agenda)

These are not scored. They are the lines you will need on the call.

| Topic | Likely line from Hannah | Suggested words | Flag |
|---|---|---|---|
| Salary | "What are your salary expectations?" | Before giving a number, ask: "What's the budget for the role?" If she asks for yours: "The advert says £38,000 to £44,000, and I'm looking for the upper half of that." Your note reads "I'm hoping for £42,000", which is a source for this line. | £42,000 is already above the midpoint of the advert's £38k–£44k range. A single figure stated as a hope reads as the number you will accept. Say the range before the figure. |
| Notice period | "What's your notice period?" | "My notice period is {notice period}." | Needed from you before the call. See the question below. |
| Hybrid | "How would two days a week at Avonmouth work?" | Quote your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | "Two days is fine" settles the pattern. Do not offer three, and do not offer more until asked. |
| Reason for moving | "What's prompting the move?" | Quote your own words: "our Bristol office is closing next year." Then: "I want to stay in Bristol." | Do not volunteer that Reading is the only offer. It tells her you have no alternative and a deadline, which she can use on salary. Give Reading only if she asks directly. |

## Question bank: recruiter screen

Ordered by likely weight. The most likely objection is Q2, so it gets the deepest rehearsal.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Tell me about your background." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip" | A 60–90 second pitch built only from these three sentences, in your own words. Stop there and let her ask. Do not add a project or a result the sentences do not carry. | F1, F2 and F3 are the three strongest lines. The pitch should be a summary of them, not an extension. |
| Q2 | "This role coordinates production planning, the warehouse and QA. How does your experience fit that?" | JD | [grounded] "I schedule deliveries for our three depots" | Start with the quote: you schedule deliveries across three depots. Answer slot: if you coordinated between planning, the warehouse or QA, say which and how; if you did not, say so plainly and say what you would need to learn first. | F2 is the largest gap and the advert's headline line. It is the objection most likely to come up, so rehearse the plain answer until it is calm. |
| Q3 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Then say how you would learn it, as a plan. Do not claim the in-house system is equivalent. | F7 is your own stated negative. The honest answer is the acknowledgment plus a plan. |
| Q4 | "Discrepancies fell by about a third. How was that counted, and how much of it was yours?" | EXP | [grounded] "rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say how it was counted, in your words. Name the assumption you would defend least, before she does. Say which part was yours. Answer slot: if you did not track it, or others contributed, say so plainly. "I don't know exactly how it was counted" is an honest branch. | F4 is your headline figure and the likeliest place to be probed. Defend the number precisely; do not explain a method you cannot repeat under a second question. |
| Q5 | "Have you reported on on-time dispatch?" | JD | [grounded] "report weekly on on-time dispatch" (advert, supplied) | Answer slot: if you have reported on delivery or dispatch timeliness, say what, how often and to whom. If you have not, say so plainly and say what you would track first. | F5 is discovery. The advert raises it, and your material does not show it. |
| Q6 | "How confident are you with Excel?" | JD | [grounded] "rebuilt our stock-count spreadsheet" | Name the tool and the most involved thing you did in it, in your own words. Answer slot: if you were self-taught or used a tool other than Excel, say so. | F6. The advert asks for Excel directly, and your material shows only a spreadsheet. |

Coverage against the advert:

- "2+ years in operations or logistics coordination" → Q1
- "Coordinate production schedules between planning, the warehouse and QA" → Q2
- "track supplier deliveries and chase late orders" → Q1
- "keep stock records accurate" → Q4
- "report weekly on on-time dispatch" → Q5
- "confident with Excel" → Q6
- "ERP (SAP or similar) a plus" → Q3

## Reverse questions

Ask these at the end, once she has covered the next steps. Each one is there for a reason.

1. "What's the budget range for this role?" Why it lands: you hear the number before you state yours, which protects the salary line.
2. "What does a typical week look like across planning, the warehouse and QA?" Why it lands: it shows you read the advert's headline line and want the real picture.
3. "How is on-time dispatch measured and reported today?" Why it lands: it ties directly to F5, and the answer tells you what the weekly report would expect.
4. "Which systems does the team use day to day, and is there a plan to move anything onto SAP?" Why it lands: it tests the ERP line and shows you care about the tools, not just the title.
5. "How does the hybrid pattern work across the week, and is Avonmouth the only site?" Why it lands: it settles the two-day arrangement in practice.
6. "What happens between this call and a decision?" Why it lands: it gets the next steps in her words.

## Sources

- Provided documents: the advert text, Hannah's LinkedIn message, and your message to me.
- No searches or fetches were run in this pass. The pack relies only on the material above.

Research tier: L0 — provided documents only.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Quillmoor values | not run | Values cheat sheet. No values-style round was indicated, so the section is dropped either way. |
| 2. Quillmoor interview process | not run | Loop structure. Hannah's message already states the screen's agenda. |
| 3. Quillmoor strategy / recent news | not run | Grounding brief. Not needed for a recruiter screen about terms. |
| 4. Interviewer name | n/a | Hannah's name is known, but this is a screen, not a loop with an interviewer profile to read. |
| 5. Representative JD | skipped | The advert supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period → the Terms table gets a line you can say verbatim
- Your CV → F1 to F7 move from "your message" to "your CV", with more depth behind each quote, and Q4's figure can be checked
- Any dispatch reporting or Excel work you have done → Q5 and Q6 become story-mapped rather than answer slots
- Hannah's follow-up with the team's details → team and next-steps lines for the second conversation
