# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (Avonmouth, Bristol; hybrid, two days a week)
**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, 30 minutes by phone, Thursday 2pm. Hannah will call the mobile number on the application.
**Agenda Hannah set:** salary expectations, notice period, hybrid pattern, reason for moving, then the team and next steps.
**Assumptions this pack is built on:** the full advert and your background are the inputs. No web research was run (see Sources), so nothing here describes Quillmoor beyond the advert.

## How to use + type key

- Personas describe how a question arrives. Types describe what is being scored.
- **EXP** work-experience deep-dive. **JD** role-driven or screening knockout. **CO** company knowledge. **CASE** live problem. **VAL** values.
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage (30-minute call)

1. Have the three numbers ready: your salary figure, your notice period, and your answer on hybrid. Hannah asks for all three in the first ten minutes (L1, L2, L3).
2. Rehearse the Production-and-QA gap answer (B1). It is the question most likely to come up in some form, and the one your material is thinnest on.
3. Rehearse the plain reason for moving (L4).
4. Rehearse the discrepancy-figure question (C1). Know how you measured it, or say you don't.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Your message already says it. Lead with the title and the four years. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and nothing on QA. Say the delivery work at that scope. Answer slot: if you have worked alongside production, planning or QA in any role, say how; if you have not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message), "I schedule deliveries for our three depots and chase suppliers" (your message) | high | [grounded] | none | Your material matches this directly. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" (your message), "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. The figure has no stated method behind it, so expect a probe (see C1). |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material shows you built a spreadsheet, not your level in Excel. Describe what the spreadsheet does, not an adjective. Answer slot: which functions you used. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on dispatch or delivery timeliness, say what you reported and how often; if not, say so and say what you would track first. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't used SAP." Then say what you did use, and how you would learn SAP, as a plan. |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your message already answers it. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Sits in the upper half of the advert's range. |

Routing note: no requirement is a hard gate, so no row uses `hard_gate`.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or planned production schedules | Inflated form of F2. Your material says delivery scheduling. | "I schedule deliveries for our three depots." The limit is the pack's own observation: your material does not show production scheduling. |
| Cut discrepancies by a third | Inflated form of F4. Your material says discrepancies fell over a year, not that you caused it. | "Discrepancies fell by about a third over a year" after you rebuilt the spreadsheet, at that scope. |
| Advanced Excel | Inflated form of F5. Your material does not state a level. | Describe what you built in the spreadsheet. |
| Experience with SAP or ERP systems | Sourced negative, F7. | "I haven't used SAP." No slot. |

## Question banks

Recruiter screen weights: Conversational 4, Skeptic 3, Prober 1. Logistics questions are Hannah's named agenda, so they get their own bank.

### A. Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots" (your message) | A 90-second arc: role and years, what you schedule, who you chase, what changed over the four years. Use only those sentences. | F1 and F2 are the spine of the background. Expect this as the opener. |
| A2 | "What do you know about Quillmoor?" | CO | [generic] | Say what the advert tells you: a diagnostic-test manufacturer with about 400 staff, and the coordination role between planning, warehouse and QA. Say plainly if you have not researched more. | This is the only place the pack could drift into company detail it has not checked. Keep to the advert. |
| A3 | "What does a typical week look like in your current job?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Walk through deliveries for the three depots and chasing suppliers when orders slip. Use your own words. | F3 is the matched requirement. |
| A4 | "Tell me about the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message); "discrepancies fell by about a third over a year" (your message) | Say what you changed and the period it covered. Answer slot: how discrepancies were counted, and which assumption behind that figure you would defend least. If you cannot say, say so plainly. | F4 is an answer the interviewer will test. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Production planning and QA aren't in your background. Why would this work?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | The highest-ROI rehearsal in this pack. Bridge at the scope of the quote: scheduling deliveries across three sites and chasing suppliers when orders slip. Say plainly that you have not worked on the production or QA side. Answer slot: if you have worked alongside production, planning or QA in any role, say how, in your own words; if not, say so and say what you would learn first. Hold through two follow-ups by returning to the delivery work. | F2 is the requirement you are weakest against, and this is the objection most likely to be raised in some form. |
| B2 | "You haven't used SAP. How quickly could you pick it up?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | "I haven't used SAP." Then name the in-house system you did use and how you used it, in your own words. Give the learning plan as a plan, not as something you have done. | F7 is a stated absence, so the plain acknowledgment is enough. |
| B3 | "How would you rate yourself in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" (your message) | Describe what the spreadsheet did: the counts, the checks, the layout. Avoid adjectives. Answer slot: which functions you used. | F5 is thin, so the answer is a description, not a rating. |
| B4 | "The advert asks for weekly on-time dispatch reporting. Have you done that?" | JD | [generic] | Open prompt. If you have reported on dispatch or delivery timeliness, say what you reported and how often. If not, say so and say what you would track first. | F6 has no quote, so the honest answer is either branch. |

### C. Prober (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you measure the drop in discrepancies?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did this, say how, in your own words; if the count was not yours, say so plainly and describe the spreadsheet you rebuilt. | A figure you gave is a probe target. The pack does not supply a method. |

### L. Screen logistics (Hannah's named agenda)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." (your message) | "I'm hoping for £42,000." Ask what range Quillmoor has in mind, since the advert says £38,000–£44,000. Do not state a lower figure than the one you mean. | F9. The figure sits inside the advert's range. |
| L2 | "What is your notice period?" | JD | none given | Answer slot: say your actual notice period. The pack does not have it. | The material does not contain it, so this is a gap the pack cannot fill. |
| L3 | "How do you feel about the hybrid pattern?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | "Two days at Avonmouth is fine." Mention the three-day limit only if Hannah asks about more days. | F8. Your stated limit is real; do not volunteer it as a negotiating position. |
| L4 | "What's prompting the move?" | JD | [grounded] "our Bristol office is closing next year" (your message); "the only offer is relocating to Reading" (your message) | State the closure and the relocation offer, then say you would like to stay in north Bristol. Do not criticise the company. | Hannah asked this directly. A plain answer is better than a rehearsed one. |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A3 |
| Keep stock records accurate | A4, C1 |
| Confident with Excel | B3 |
| Weekly on-time dispatch reporting | B4 |
| ERP (SAP or similar) a plus | B2 |
| Salary, hybrid | L1, L3 |

Count: 13 questions. Guidance sizing: the pack is short on purpose, because a 30-minute screen is short. It is not padded to reach a session total.

## Reverse questions

1. **"What would the first 90 days look like in this role?"** Why it lands: it shows you are thinking about the job, not only the offer.
2. **"Day to day, who would I be working with: planning, the warehouse, or QA?"** Why it lands: it finds the seam where your gap is, and you can ask about it directly.
3. **"Which system would I be keeping stock records in, and how is it used day to day?"** Why it lands: it asks about SAP without assuming you have it.
4. **"How is on-time dispatch measured now, and where does the current figure sit?"** Why it lands: it shows you read the weekly-reporting line in the advert.
5. **"What are the next steps, and how long usually passes between them?"** Why it lands: Hannah has said she will cover next steps, so this confirms the timeline.
6. **"Which days are fixed on the Avonmouth pattern, and which are flexible?"** Why it lands: it turns the hybrid question into a practical one.

## Sources

**Research tier: L0.** No searches and no fetches were run for this pack. The default tier is L1; the target rows below say what each target would have moved.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have grounded a values answer and a "why Quillmoor" answer. Currently A2 is limited to the advert. |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | Would have confirmed the screen format and the next stage. |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Would have given A2 a current angle. |
| 4. Interviewer name search | n/a | Hannah's name is given, but the interviewer read is not run because this is a recruiter screen with no interviewer profile requested. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the requirement list. |

Provided documents: the advert text and your message. No CV was supplied, so the fit snapshot uses your message as the source for your background.

## Upgrade menu

- Your notice period → fills L2 so the answer is ready.
- Your current salary → lets L1 be checked against your current pay.
- Your CV → quotes your background from the document, not from the message.
- Research at L1 → a grounded "why Quillmoor" answer for A2, and a confirmed interview process.
- Your dispatch or delivery reporting, if any → upgrades B4 from an answer slot to a story.
