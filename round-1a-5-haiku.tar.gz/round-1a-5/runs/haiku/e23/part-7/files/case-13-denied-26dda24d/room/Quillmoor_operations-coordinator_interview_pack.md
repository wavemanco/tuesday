# Quillmoor Diagnostics: Operations Coordinator
Recruiter screen with Hannah Lowther (Talent Partner). Thursday 2pm, 30 minutes by phone, on the mobile number on your application. Prepared for Sam.

## 1. How to use and type key

Personas describe how a question is asked. Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and say only what you did.

- **VAL**: values alignment. Not used; no values round is indicated.
- **EXP**: experience deep-dive. Whether what you did holds up under a closer look.
- **JD**: the advert's own requirements. Whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge. Not used; company research did not run (see Sources).
- **CASE**: live problem. Not used; a recruiter screen does not set one.

## 2. Prep triage

The call is tomorrow. Roughly one evening's work, in this order:

1. Say your three logistics answers aloud: salary (C1), hybrid (A4, C3), notice (A5). Know your notice figure before the call.
2. B1, the production-scheduling gap. This is the objection most likely to come up. Rehearse it aloud twice, including the follow-up.
3. B2 (SAP) and B4 (Excel). Practise the plain "I haven't used SAP" and the tool question.
4. D1 and D2, the "about a third" figure. Know how the discrepancies were counted before she asks.
5. A3, your reason for moving, in one breath.

Everything else is insurance.

## 3. Fit snapshot

Requirements are the advert's own words, quoted. Your evidence is quoted from your message. Where the material is silent, the cell says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (JD) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. A title and a number have nothing inspected behind them, so expect a probe on what the work involved. Use the quote's own words and add no scope. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (JD) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows scheduling deliveries across three depots. It does not show production schedules, planning or QA, so the bridge stops at the quote's scope. Answer slot: if you coordinated anyone's work across planning, the warehouse or QA, say how, in your own words. If you did not, say so plainly and say what you would need to learn first. |
| F3 | "track supplier deliveries and chase late orders" (JD) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | The quote reaches the requirement in its own terms. Expect a probe on how you tracked deliveries; the material does not show that. |
| F4 | "keep stock records accurate" (JD) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The quote reaches the requirement: fewer discrepancies means more accurate stock records. "About a third" is a figure, so it raises the defend-the-number slots in D1 and D2. |
| F5 | "report weekly on on-time dispatch" (JD) | none given | none | [grounded] | discovery | Your material does not show any delivery-timeliness reporting. Answer slot: if you produced a regular measure of delivery timeliness, say what it measured and how often. If you did not, say so plainly and say how you would build one. |
| F6 | "confident with Excel" (JD) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material says spreadsheet and does not name the tool, so Excel is not shown. The [inferred] label marks this pack's own derivation that the spreadsheet may have been Excel. Answer slot: if you built it in Excel, say which features you used. If it was another tool, say which, and say honestly where your Excel level sits. |
| F7 | "ERP experience (SAP or similar) a plus" (JD) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated the SAP absence. Your material mentions an in-house stock system, which does not show ERP experience, and this pack does not claim it does. Words for you: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. |
| F8 | "two days a week at our Avonmouth site in Bristol" (JD) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own constraint, stated by you: two days is fine, and three is the ceiling you named. Met on the pattern you stated. |
| F9 | "£38,000–£44,000" (JD) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your stated figure sits inside the advertised range. Met on the figure you gave. |
| F10 | "your notice period" (Hannah Lowther's message) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a gate she will raise, so it is surfaced here, not bridged. The one question at the end of this message asks you for it. |
| F11 | "what's prompting a move" (Hannah Lowther's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | high | [grounded] | none | Your reason, in your own words. It is a constraint on your side, so it is high. No gap. |

## 4. Prohibited claims

These are claims this pack will not coach, and the basis for each. Each has an honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "Set production schedules" or "ran production planning" | Inflated form of F2. Your material says deliveries, not production. | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is this pack's observation, in analysis: your material does not show production planning. The slot in B1 stays inside deliveries. |
| "Used SAP" or "ERP experience" | Negative you stated (F7). | "I haven't used SAP." No slot. |
| "Advanced in Excel" | Inflated form of F6. | "I rebuilt our stock-count spreadsheet." Name the tool only if you name it. |
| "Cut discrepancies across the business" or "across all three depots" | Inflated form of F4. The scope grows beyond your sentence. | "Discrepancies fell by about a third over a year" on our stock-count spreadsheet, at that scope. |
| "Flexible on three days" or "any days" | Logical form. The stated ceiling is weakened into a preference. | "Two days at Avonmouth is fine, but I wouldn't want more than three." |
| "£42,000 is my minimum" | Logical form. A hope becomes a floor. | "I'm hoping for £42,000." |

## 5. Persona weights and reasoning

Recruiter screen prior: conversational, with a light skeptic. Relationship priors set the start, and no interviewer profile exists to adjust them. The depth rule gives the top persona 4–5 questions, mid-weight 3, low 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (weight 5) | Warm opener, "walk me through your background", "what's prompting the move" | High. A recruiter screen checks logistics, motivation and knockouts in a friendly register. Casual questions are still scored. | Have the 60–90 second background ready in your own beats. Treat motivation and notice as scored. |
| Skeptic (weight 4) | "Where's the production gap?", "SAP?", "what's the weekly report?" | High. The advert names two gaps (production scheduling, SAP) and one unshown report (on-time dispatch). Weighted 4, the top of mid, because the gaps sit here. | Rehearse B1 until it is plain. Bridge only from what you stated, then state the limit. |
| Pressure (weight 3) | Pushes on salary, the hybrid ceiling, and stability | Medium. The pay range is the recruiter's and the SAP gap is a fair point against you. | Hold the stated figure and constraint through two follow-ups, then concede only what is true. |
| Prober (weight 2) | "How was a third counted?" | Medium-low on a screen. The figure sits on a CV line, and recruiters often check it. | Say what you know and say plainly what you do not. |

Values/behavioral, case and peer personas are not touched. A recruiter screen does not usually run a values round, a live case or a peer seam, so no bank covers them.

Session total: 14 questions. This is below the usual 18–26 band, which is sized for a full loop. A 30-minute screen does not warrant more, and the depth rule, not the total, sets the depth.

## 6. Question banks

Provenance comes first in each row. Each quote is one of your sentences, exactly as it appears in the fit snapshot.

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message); "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Give a 60–90 second version in these beats: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Say it in your words, and stop there. | The opener is scored for consistency with the CV. F1, F3 and F4 are its beats. |
| A2 | "What does a normal week look like in that job?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Describe the week in those two beats: the deliveries you schedule across the three depots, and the suppliers you chase when orders slip. Do not add systems, meetings or volumes you have not stated. | The advert's "track supplier deliveries and chase late orders" is the line this answers (F3). JD because it scores the stated duties. |
| A3 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say it in those terms: the office closes next year, the only offer is relocation to Reading, and you don't want that. Stop there unless she asks more. Do not comment on the company or colleagues. | This is her own item, and F11 is your reason. Motivation consistency is scored, and a short plain answer matches the CV. |
| A4 | "The role is hybrid, two days a week at Avonmouth. How does that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Two days is fine, and you live in north Bristol. Keep the ceiling a ceiling: "I wouldn't want more than three." Do not offer flexibility beyond what you said. | F8 is a gate met on your own statement, and a knockout check. The wording has to match what you stated. |
| A5 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah Lowther's message) | Answer with your actual notice period. The pack cannot supply it, because your material does not establish it. The question at the end of this message asks you for it. | F10: a gate the material is silent on. JD is the nearest type. This is a knockout check rather than a scored type, and it belongs here because it can end the process. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. What's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | The highest-ROI prep in this pack. Say what you did in those terms: you schedule deliveries for three depots. Bridge only from that quote, and state the limit plainly: production planning and QA are not in what you have done. Answer slot: if you coordinated anyone's work across planning, the warehouse or QA, say how, in your own words. If you did not, say so plainly and say what you would need to learn first. Hold through two follow-ups by returning to the deliveries you did schedule. | F2 is the largest gap in the JD, and the one a skeptic presses. Name the limit first, then the learning plan. |
| B2 | "The role lists SAP or similar ERP as a plus. What's your experience with it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Say it plainly: "I haven't used SAP." Then say what the in-house stock system is and what you did in it, in your words. Then how you would learn an ERP, as a plan and not as a past. Do not describe any ERP. | F7 is a stated absence, so the acknowledgment is plain and nothing is added. JD because the advert names it, as a plus, and a skeptic will check. |
| B3 | "The role reports weekly on on-time dispatch. Have you produced a measure like that?" | JD | [grounded] "report weekly on on-time dispatch" (the advert) | Answer slot: if you produced any regular measure of delivery timeliness, say what it measured and how often. If you did not, say so plainly and say how you would build one. Never describe a report you did not produce. | F5 is discovery: nothing in the material shows timeliness reporting, so the question is answered as a slot, not bridged. JD because it scores the stated report. |
| B4 | "The advert asks for confidence with Excel. What did you build, and in what tool?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" (your message) | Say what the spreadsheet did and what you changed, in your own words. Answer slot: if it was Excel, name the features you used. If it was another tool, say which, and say honestly where your Excel level is. Do not claim advanced Excel. | F6 is low: your material names a spreadsheet, not Excel, so the link is this pack's derivation, and the label says so. JD because the advert names Excel. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The range is £38,000 to £44,000, and you've never used SAP. Why should we pay toward the top?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Hold the figure: "I'm hoping for £42,000." Hold through two follow-ups by returning to the figure and to what you do have. Concede where it is true: the SAP gap is real and you would expect to learn it. Do not drop the figure to ease the room, and do not present it as a floor. | Pay pressure with a knockout gap. Hold, then concede. The figure is a hope, not a floor (prohibited claims). The premise "toward the top" is hers, and the guidance does not adopt it. |
| C2 | "You've been four years at one employer. What's the risk you'd leave us within a year?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "the only offer is relocating to Reading, which I don't want" (your message) | Hold on the reason you are moving: the office closes next year, and the only offer is relocation to Reading, which you don't want. Do not promise a tenure. Concede only what is true: you cannot know how long any role will last. | Pressure on stability. Your reason is the closure, which is the stated reason, not restlessness. |
| C3 | "We'd need you in two days, and you've said no more than three. What if the pattern changed?" | JD | [grounded] "I wouldn't want more than three." (your message) | Hold: "two days is fine; I wouldn't want more than three." Concede only what is true: if the pattern moved past three, that is a different conversation, and you would want to talk it through. | Pressure on the hybrid ceiling. The ceiling is your own statement and stays a ceiling (prohibited claims). |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you count the discrepancies before and after?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Answer slot: say how the discrepancies were counted, in your own words. If you did not track the count before the rebuild, say so plainly. Do not describe a baseline you cannot repeat. | F4's figure raises the defend-the-number slot: how it was counted. The slot stops a method you did not use. EXP because it tests attribution. |
| D2 | "Which assumption behind 'about a third' would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Name the weakest assumption in your own words before she does. If you do not know how the figure was counted, say so. Answer slot: if you know what went into it, say it. If you do not, say plainly that you do not. | The second defend-the-number slot. The weakest-assumption move turns a gotcha into a credibility gain. |

### Requirement coverage

| Requirement (JD) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, A2 (F1) |
| Coordinate production schedules between planning, the warehouse and QA | B1 (F2) |
| Track supplier deliveries and chase late orders | A2 (F3) |
| Keep stock records accurate | D1, D2 (F4) |
| Report weekly on on-time dispatch | B3 (F5) |
| Confident with Excel | B4 (F6) |
| ERP (SAP or similar) a plus | B2 (F7) |
| Hybrid, two days a week at Avonmouth | A4, C3 (F8) |
| £38,000–£44,000 | C1 (F9) |
| Notice period (her item) | A5 (F10) |
| Reason for moving (her item) | A3, C2 (F11) |

## 7. Reverse questions

Each one should be asked at the end, when she invites your questions. Each has a reason it lands.

1. "What would I own in the first month, and which of the planning, warehouse or QA handoffs would it start with?" Why it lands: it turns the production gap into a scope question, and shows you read the advert.
2. "How is on-time dispatch measured now, and who reads the weekly report?" Why it lands: it names the advert's report and asks who reads it, which tells you what is scored.
3. "Which system do planning and stock records run on day to day?" Why it lands: it asks about SAP openly. The answer tells you how much learning to plan for.
4. "What are the next steps, and roughly how many stages until an offer?" Why it lands: she said she would cover next steps, so a timeline question shows you are planning.
5. "Where in the £38,000–£44,000 range would a new starter typically sit?" Why it lands: once she has named the range, asking where in it lets you frame C1 for the next round.

## 8. Sources

- **Provided documents:** Hannah Lowther's LinkedIn message (the booking and her agenda); the Operations Coordinator advert; your background notes in your message.
- **Searches and fetches sent:** "Quillmoor Diagnostics Avonmouth Bristol": refused (search permission was not granted). No fetches.
- **Dossier:** none present, so none consumed.

**Research tier: L1, searches 0 of 6 (one attempted and refused), fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet. Not built, because no values round is detected. No call was sent for it. Search permission was refused. |
| 2. Quillmoor interview process, operations coordinator | unavailable | Loop structure, which would set persona weights for the rounds after this screen. Search permission was refused. |
| 3. Quillmoor strategy / recent news | unavailable | The refused query above was sent for this target. It would have checked the Avonmouth site and recent moves for the reverse questions. |
| 4. Hannah Lowther, Quillmoor | unavailable | Her public professional footprint, which would tie a reverse question to her own path. No call was sent; search permission was refused. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions. |

## 9. Upgrade menu

- Your notice period → F10 becomes a usable row, and A5 carries your figure instead of an answer slot.
- Your actual discrepancy counts and how they were recorded → D1 and D2 say what you counted, instead of holding an answer slot.
- Your Excel level and the tool the spreadsheet ran in → B4 moves from [inferred] to [grounded].
- Whether you ever produced a delivery-timeliness measure → B3 becomes a story instead of an answer slot.
- Hannah Lowther's public professional profile → reverse questions tied to her own career path, and a check on the persona weights.
- Permission to search Quillmoor's values, recent news and the Avonmouth site → company research at L1. The search above was refused this run.
- Deep research (L2), offered once: up to six further searches and two page reads, which takes a few minutes. It adds a strategy brief, the interview process and role-family loop reports.
- Her next-stage schedule, if the screen leads to more than one round → a per-round prep pack.
