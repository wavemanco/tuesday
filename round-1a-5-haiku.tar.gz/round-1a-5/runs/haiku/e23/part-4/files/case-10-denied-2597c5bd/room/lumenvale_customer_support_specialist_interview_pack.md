# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Format:** text chat on Telegram with the support team lead (unnamed). Invitation came from Marcus Hale, talent team.
**Built from:** your note of the job ad (paraphrased, not its exact words), your background as you described it, and your message. No CV, no full ad text, no company research (web search was not permitted in this session).
**Changed since last version:** not applicable (first version).

## 1. How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and only the parts your own experience supports.

| Tag | Meaning |
|---|---|
| VAL | Values or behaviour: whether a past action shows a published value |
| EXP | Your own experience: whether what you said about your work holds up |
| JD | The job's stated requirements |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the role, answered in the chat |

## 2. Fit snapshot

Requirements are your note of the ad, not its exact words, so they are not in quotation marks. Quotation marks here mark only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your note of the ad) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | Your material meets this requirement. Say the three years and the volume in your own words. Expect a probe on what the 60 a day covered. |
| F2 | Zendesk or a similar ticketing tool (your note of the ad) | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a similar ticketing tool, so this reaches the requirement. It does not show Zendesk. Say Freshdesk, daily, and say nothing about Zendesk unless you have used it. Answer slot: if you have used Zendesk, say where and how, in your own words. |
| F3 | Clear written communication (your note of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails show written work. They do not show that it was clear. Answer slot: if a written reply of yours got a customer to resolution, say what it said, in your own words. If none comes to mind, say so, then describe how you would write a first reply. |
| F4 | Confidence handling escalations (your note of the ad) | "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Refund training is adjacent. It does not show an escalation. Answer slot: if you escalated a refund or case, say what, and how you decided. If you did not, say so plainly, then describe how you handled the refunds you were allowed to decide. |
| F5 | Software-company background (not in your note of the ad; included because you raised it, and it is the likeliest probe) | "I've never worked for a software company" — your message | none | [grounded] | capability | This is a stated absence. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |

**Gates:** your note names none, and your material is silent on location, right to work and schedule. No gate row is written. The one question in section 10 asks about them.

## 3. Prohibited claims

These claims are not coached anywhere in this pack, including in answer slots and drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2. Your material says Freshdesk. | "I use Freshdesk every day," at that scope. Your material says Freshdesk, not Zendesk. |
| Clear writing as a proven strength | Inflated form of F3. Your material says emails, not what they said. | The quote at its own scope. Your material says you answered emails. It does not say how clearly. |
| Handling escalations | Inflated form of F4. Your material says refund training, not escalation. | The refunds quote at its own scope. Your material says you trained others on refunds. It does not say you escalated. |
| Software-company experience | Sourced: a negative you stated (F5). | "I haven't worked for a software company." No answer slot. |

## 4. Persona weights

Relationship prior: a team lead running a text-chat round. That is a hiring-manager prior: case work plus a skeptic who checks the gaps. Your note has no interviewer profile, so no interviewer adjustments apply. Depth follows weight: the top persona gets the most questions.

| Persona | How it shows up in this chat | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case / Strategist | A live customer scenario, answered in writing | High. A text round makes the written reply the thing scored, and the ad is about handling live customers | Clarify, then reply, then state the next step. Keep each step to one line | 5 questions (A) |
| Skeptic | "You haven't worked in software — why should we believe you can learn it?" | High. F5 and F2 are the visible gaps | A plain answer first, then a learning plan. Hold through two follow-ups | 3 questions (B) |
| Conversational | A friendly opener, then a scored question | Medium. Chat openers are often short and still scored | A 90-second arc from quoted facts only | 2 questions (C) |
| Pressure | "Sixty seconds: why you over someone with software experience?" | Medium. Less common in text, but escalation pushback is a standard test | Hold the strengths. Concede the software gap plainly | 2 questions (D) |
| Data-driven prober | "How was the 60 a day counted?" | Medium. Your figure is "around", so a probe will find that | Say "around 60", and do not sharpen it | 2 questions (E) |

## 5. Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they say they were charged twice on their bill. Reply to them here, then tell me your next steps." | CASE | [generic] | Write a short reply: acknowledge, say what you will check, ask for the one detail you need. Then the next steps, one line each: confirm the duplicate, act within what you are allowed to do, escalate what is beyond that. | A live written case, and the chat itself is the scored answer. It makes no claim about your past. |
| A2 | "A customer says an agent promised a refund that you cannot see in the system. What do you write, and when do you escalate?" | CASE | [generic] | Say what you can verify, what you cannot, and what happens next, without blaming the agent. Name the escalation trigger in your own words. | Tests the escalation confidence the ad asks for (F4). A pattern for the problem, not a fact about you. |
| A3 | "Our tools are Zendesk-based. What would you need to learn in your first week?" | JD | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk and what you use it for. Then a week-one plan: ticket views, reply templates, the escalation path. It is a plan, not a claim. Do not say you know Zendesk. | Tests F2. The question presupposes the ad's tool, not anything about your past, so the answer is a plan. |
| A4 | "Write a reply to a customer who says the login has failed three times today." | CASE | [generic] | Short: acknowledge, one check, one question back. Invent no fix you have not been told about. | Written communication, live (F3). |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. What would you do in your first month to learn our product?" | JD | [grounded] "I've never worked for a software company" — your message | Start with the plain answer: "I haven't worked for a software company." Then the month: read the product documentation, shadow tickets, learn the escalation path. Hold through two follow-ups by returning to the plan. | The highest-return prep in this pack. F5 is the objection most likely to come up, and a plain, rehearsed answer beats a defensive one. |
| B2 | "Why move from energy into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message | Say, in your own words, what draws you to support work and what the energy role taught you that carries across. Use only that. | Motivation probe. F1 is the only past fact the answer uses. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one honest gap (the tool, or the product), then the plan to close it. Pick one, not a list. | A skeptic's stem. The answer names a gap and makes no claim. |

### C. Conversational / rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year" — your message | A 90-second arc: where you started, the energy role, the training you ran, where you want to go. Use only those beats. | An open prompt. The two quotes are the only past facts the arc carries. |
| C2 | "What part of support work do you enjoy most?" | EXP | [generic] | One honest answer, tied to one moment you can describe. | Casual in register, still scored for interest and communication. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone with software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" — your message | Hold the strengths: three years of contact volume, daily ticketing. Concede the software gap plainly. Hold through two follow-ups. Concede the gap, not the strengths. | A pressure stem. The hold-then-concede structure is the point. |
| D2 | "Your ad asks for Zendesk. How much of that do you actually have?" | JD | [grounded] "I use Freshdesk every day" — your message | Answer slot: if you have used Zendesk, say where and how, in your own words. If you have not, say so plainly, and say what you would do in week one. | Tests F2 under pressure. The question presupposes the ad's tool. The second branch allows that you have not used it. |

### E. Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the 60 contacts a day were counted. What was in that number?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say "around 60" and nothing firmer. The assumption you would defend least: the figure is approximate. Answer slot: if any contacts were counted or tracked, say what counted and how. If none were, say so plainly. | The defend-the-number question. The figure is "around", so the answer must stay that loose. |
| E2 | "On refunds: which cases did you escalate, and what decided it?" | JD | [grounded] "I trained four new starters on our refunds process last year" — your message | Describe the refund process you taught, in your own words. Answer slot: if you escalated a refund case, say which and what you decided. If you did not, say so plainly, and describe how you handled the refunds you were allowed to decide. | Tests F4. The second branch allows that no escalation was yours. |

**Coverage.** Two-plus years: F1, C1, D1. Zendesk or similar: F2, A3, B3, D2. Written communication: F3, A1, A4. Escalations: F4, A2, E2. Software background (not in the ad as you noted it): F5, B1, B2.

**Count.** This pack has 13 questions, below the usual 18 to 26. The material is thin: one ad summary and a short background. The upgrade menu says what would add more.

## 6. Reverse questions

Ask at least some of these. Each has a reason it helps.

1. "How does the team judge a good reply in the chat round, and is there a written scoring sheet?" Why it lands: shows you care what is scored, and it gives the team lead a reason to explain the process.
2. "What does a typical escalation look like, and who takes it from there?" Why it lands: shows you already expect to escalate, which is the ad's confidence requirement.
3. "What is the first ticket type a new hire handles?" Why it lands: a concrete question about the first week, which the interviewer can answer easily.
4. "How do product bugs reach the engineering team from support?" Why it lands: shows you understand support is part of a product process, which matters given the software gap.
5. "After this chat, how will the next step reach me: from a company email address?" Why it lands: a sensible question about the process, and it also confirms the contact channel (see the safety note above).

## 7. Sources

- Provided: your message (Telegram text from Marcus Hale); your note of the job ad; your background description.
- No CV, no full ad text, no dossier.

**Research tier:** L0. Searches 0 of 6, fetches 0 of 2. Web search was refused by a permission prompt in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company careers` (values) | unavailable | Query refused. Values cheat sheet dropped, since no published values are in hand |
| 2. `Lumenvale Software interview process customer support` | unavailable | No query sent. Loop structure stays at round-type priors |
| 3. `Lumenvale Software strategy / recent news` | unavailable | No query sent. Would have moved the CO bank, which is empty here |
| 4. `{interviewer name} Lumenvale` | n/a | No interviewer name given; the team lead is unnamed |
| 5. Representative JD | skipped | Your note of the ad already fixes the requirements |

Un-numbered: a search for Telegram-only recruitment with offers and onboarding in chat, refused. It would have checked whether that pattern appears in published scam warnings.

## 8. Upgrade menu

- The full text of the job ad → the requirements become exact quotes, and F1 and F2 can be checked against the wording.
- Your CV → F1 and F2 can be checked against an inspectable document, so they can rise above medium if the CV supports them.
- Examples of your written replies, with names removed → F3 moves from discovery, and A4 and E1 get real material.
- Any escalation you handled, described in a sentence → F4 moves from discovery, and A2 and E2 get real material.
- The team lead's name, if they give it → an interviewer read, and a tailored reverse question.
- Confirmation that the process is run from Lumenvale's own website and email → nothing in the pack changes, but the safety steps above can be closed off.
