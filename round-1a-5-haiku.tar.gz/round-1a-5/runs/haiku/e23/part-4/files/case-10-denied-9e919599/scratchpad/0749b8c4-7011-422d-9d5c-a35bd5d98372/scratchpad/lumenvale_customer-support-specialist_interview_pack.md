# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: text-chat interview on Telegram with the support team lead (name not given). Relationship: team lead, so treated as a hiring-manager round. Format: written, asynchronous-feeling, so answers are short and written as you would send them.
Basis: your message and the ad as you summarised it. No full job ad, no company research (see Sources).

## How to use

- Personas = how the question arrives. Types = what is being scored.
- Type key: **JD** = the role's listed requirements. **EXP** = what your past work actually shows. **CASE** = a live problem from the role. Each question carries one type.
- Guidance is scaffolding, not a script. Rehearse it aloud or in writing until the words are yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | The quote already reaches the requirement, in an energy supplier rather than a software company. Expect a probe on whether a customer service advisor role is the same work as support. Describe what the role involved, in your own words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a ticketing tool used daily, and the ad says "or a similar". Say Freshdesk, daily, in those words. Do not claim Zendesk. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your message shows volume and that emails were part of it. It does not show that your writing was clear. Answer slot: if someone has told you your written replies were clear, say who and what they said; if not, say that the volume is the evidence you have, and that this chat is where they can judge it. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show escalation handling, and you have not said you lack it. Answer slot: if you have handled an escalation, say what the customer needed, what you did, and where it went; if you have not, say so plainly and say how you would start. |
| F5 | Software-company experience: not in the ad as you described it, but a likely probe (role-family expectation) | "I've never worked for a software company" (your message) | none | [grounded] | capability | The gap you stated. Words: "I haven't worked for a software company." Then how you would learn their product, said as a plan and never as a past. |

## Prohibited claims

Built locally from the fit snapshot, because no dossier was provided. Do not say these, in an answer, a bridge or a reply in the chat.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or designed the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | The quote at its own scope. Your material says you trained others on the process, not that you set it. |
| Resolved about 60 contacts a day, or any satisfaction or resolution score | Inflated form of "answering around 60 calls and emails a day" | "Answering around 60 calls and emails a day", and nothing more. No resolution rate or score is in the material. |
| Expert in Zendesk | Inflated form of F2 | "I use Freshdesk every day." |
| Software-company experience of any kind | Negative you stated (F5) | "I haven't worked for a software company." Plain acknowledgment, sourced to your message. |

## Persona table

| Persona | How it shows up in this chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the software gap, escalations, and why leave a regulated supplier | Highest. Your message names the software gap yourself, and the ad names escalations, which your material does not show. A team lead buying support skill will probe both. | Rehearse the first objection until it is plain. Use only quoted facts for the bridge. Give the limit plainly where there is no evidence. |
| Case / Strategist | Live support scenarios: a refund, a login outage, an angry customer, a process change | High. A team lead for a support team tests judgement on real tickets. | Clarify first, then act. Write the reply as you would send it. |
| Data-Driven Prober | Asks how the 60-a-day figure was counted and what you set up in Freshdesk | Medium. The volume figure is the only number you gave, and it is the one a prober checks. | Know how you know the figure. Say plainly what was an estimate. |
| Conversational | Opens with "tell me about yourself" and a casual question about the day | Medium. Chat openers are scored too. | A 90-second arc from your own quotes. |
| Pressure | Asks for a two-sentence answer, or a choice between calls and emails | Lower. Text formats limit interruption, but short-answer demands are likely. | Give one clear answer, hold it once, then concede the gap in one sentence. |

Depth follows weight: Skeptic 5, Case 4, Prober 4, Conversational 3, Pressure 2.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never worked for a software company. Why would you do well in our support team?" | JD | [grounded] "I've never worked for a software company" (your message) | Open with the plain acknowledgment: "I haven't worked for a software company." Then the bridge from your quotes: "I've spent three years as a customer service advisor at an energy supplier, and I use Freshdesk every day." Then the plan for learning their product, as a plan. Do not call the transfer proof of fit. About 60 seconds. | F5 is the most likely first objection, and the negative is one you stated, so the acknowledgment has its source. |
| A2 | "Tell me about an escalation you handled that you could not close yourself." | JD | [grounded] "confidence handling escalations" (your message, the ad as you summarised it) | Selection scaffold: pick a time a customer's problem had to go above you. Say the stake, what you did yourself, and where it went. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the refunds process you taught), or how you would handle one. | F4 is the one requirement nothing you have given covers, so this is the highest-return rehearsal in the pack. Hold through two follow-ups by returning to what you did. |
| A3 | "Your experience is calls and emails. Our team works mostly in written tickets. Which is harder for you, and why?" | JD | [grounded] "answering around 60 calls and emails a day" (your message) | Answer both branches honestly. Say which channel is harder and why. Use the emails in your quote as the bridge to written work. Do not claim you have written tickets at volume unless you have. | F3: the written-communication requirement has no direct evidence, so the answer is the chat itself. |
| A4 | "Why leave a regulated energy supplier for a software company?" | JD | [generic] | Answer with the motivation you actually have, tied to what you want from this role. Do not invent enthusiasm for software you have not shown. | A motivation probe. It asks about your reasons, not your past, so there is no claim about your record to defend. |
| A5 | "What would be the hardest part of your first month?" | JD | [grounded] "I've never worked for a software company" (your message) | Name one concrete area, product knowledge most likely, and say what you would do about it. Plan language only. | A second-level probe on A1. It tests whether you can name a real gap without over-apologising. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says their refund is ten days late and they are going to their bank. Write your first reply in this chat." | CASE | [generic] | Acknowledge, check the order and refund status, say what you will do and when, and do not promise a date you cannot confirm. Keep it short. | A written-tone test on a generic refund case. No claim about your past. |
| B2 | "Many customers cannot log in after an update, and tickets are piling up. What do you do in the first hour?" | CASE | [generic] | Confirm the scope with a few checks, group the tickets, send a holding message, and escalate with reproduction steps. Tell the team lead what you know and what you do not. | Escalation judgement in a case form. Generic, so it makes no claim about your history. |
| B3 | "A customer writes in capitals and is furious. Reply in the chat, then tell me what you were trying to do." | CASE | [generic] | Acknowledge the feeling, name the next step, stay calm, and do not defend the company. Then say, in one sentence, why you wrote it that way. | Tests written de-escalation and whether you can explain your reasoning. |
| B4 | "Our refund policy changed yesterday and some macros are out of date. What do you do with the open tickets?" | CASE | [generic] | Check the new policy, ask the lead which rule applies, flag affected tickets, and do not guess. | Process change and coachability, both real parts of the role. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the around-60-a-day figure counted, and which part of it was yours to handle?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say how you know the figure: a report, a queue count, or an estimate. Name the weakest assumption you can see, and say that "around" is an estimate if it is one. Answer slot: if you took it from a report, say which; if it is an estimate, say so, and say which part of the volume was yours. Never give a resolution rate. | The volume is the only number in your material, so it is the one a prober checks. |
| C2 | "In Freshdesk, what did you set up yourself, and what did you only work in?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you set up views, macros or workflows, name them. If you only worked the queue, say that plainly. | Tests tool depth against the Zendesk line in the ad. |
| C3 | "The refunds process you trained people on: did you write it, or did you teach a process someone else wrote?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say what you did, in those words. Answer slot: if you wrote any of the process, say which part; if you did not, say so. | The prohibited inflated form, tested directly. A prober will ask this. |
| C4 | "What did training four new starters involve, and how did you know it worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Describe the training in your own words. Answer slot: if you checked their work, say how; if you did not check it, say so. | Tests whether the teaching claim survives "how do you know". |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself and what brought you to this application." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I trained four new starters on our refunds process last year" (your message) | A 90-second arc: the energy supplier, three years, the daily volume, Freshdesk, and training four starters. One sentence on your motivation. | A chat opener, still scored for communication and interest. |
| D2 | "What does a typical day look like in your current queue?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Describe your day in your own words. Anchor it on the volume you gave, and say which part of the day that covered. | Casual wording, but it tests whether your account is specific. |
| D3 | "How do you like to get feedback from a team lead?" | JD | [generic] | Say what you would want, written feedback or a weekly check-in, as a preference for the future and not a past. | Fits a chat-based team, and it shows how you would work with the lead. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two sentences: why should we hire you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company" (your message) | Hold the position with your quotes: three years of customer support, Freshdesk daily, training four starters. Concede the software gap in one sentence, and say how you would close it. Hold it once. | A time-boxed answer in text. Holding a position without folding is what it scores. |
| E2 | "Quick one: which was harder for you, calls or emails?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Pick one, give one reason, and stop. | A short-answer demand. Tests whether you can commit to a choice. |

## Requirement coverage

- 2+ years in customer support: D1, E1
- Zendesk or a similar ticketing tool: C2
- Clear written communication: A3, B1, B3
- Confidence handling escalations: A2, B2
- Software-company experience (not in the ad as you described it, likely probe): A1, A5
- Anything else in the ad: none, and why: you have not sent the full ad, so requirements beyond your summary are not covered.

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical first week look like for someone starting on the team?" | Shows you are picturing the job, not just the offer. |
| "How does the team handle escalations: who takes them, and how fast?" | Escalations are a stated requirement, and this is the lead's own process. |
| "What is the most common reason tickets get reopened here?" | Shows you think about quality, not only volume. |
| "How are product changes passed to the team: before or after launch?" | Shows you understand how a support team stays current. |
| "How do you give feedback on written replies?" | Ties back to the written-communication requirement and to chat as the medium. |

## Sources

Provided documents: your message, quoted above. Nothing else was used.

Research tier: L0. No research ran, because web search was not permitted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet, not produced. Would have mapped published values to your stories. |
| 2. Lumenvale interview process, support role | unavailable | Loop structure and persona weights. Persona weights above are priors only. |
| 3. Lumenvale strategy / recent news | unavailable | Grounding brief. Would have supplied current language for the company. |
| 4. Interviewer name and company | n/a | No name for the team lead was given. |
| 5. Representative support JD | skipped | Your summary of the ad fixes the requirement list used here. |

Not verified: that Lumenvale Software and Marcus Hale are who they say they are. This pack does not establish it.

## Upgrade menu

- The full job ad text → the requirement lines become quoted source text, and any requirement missed from your summary is covered.
- The team lead's name and public profile, if any → interviewer read and persona weights.
- Any location, time-zone or work-authorization requirement for the role → checks that gate, which this pack cannot assess.
- Any written test or task the team lead sends → a graded deliverable section.
- Company research, once web search is allowed → values cheat sheet, interview process, and recent company context.
