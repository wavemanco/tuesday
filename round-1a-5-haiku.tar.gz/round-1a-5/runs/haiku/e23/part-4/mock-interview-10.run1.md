Before you reply to Marcus, please check the following. I can't verify him or Lumenvale from here.

- **Check the job on Lumenvale's own website.** Confirm the Customer Support Specialist role is listed on their careers page. Find Marcus Hale on their official site or LinkedIn, and contact him through details you found there, not through a link or handle sent to you.
- **Be cautious about a Telegram-only process.** Interviews, offers and onboarding all happening in one chat is a common pattern in recruitment scams. Don't send ID documents, bank details or tax or National Insurance numbers in this chat yet.
- **Never pay for anything.** Equipment, "training" or a starter kit paid for up front is a serious warning sign. So is any request to deposit a cheque and send money back.
- **Ask for a video call or an email from their domain.** A real employer will normally agree to this. A refusal tells you something.

If the checks hold up, the prep below applies.

## Your interview pack

I saved the full pack as `/var/tmp/tuesday-measure/1a5/runs/haiku/e23/part-4/rooms/case-10-denied-71cb12de/lumenvale_customer_support_specialist_interview_pack.md`. It is built on your summary of the job ad, not the full text, and no web research was run. It includes the fit snapshot, persona weights, 17 questions with guidance, reverse questions, a prohibited-claims list and sources.

**Fit snapshot (your evidence, quoted exactly):**
- **2+ years in customer support:** strong match. "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"
- **Zendesk or similar:** partial match. "I use Freshdesk every day". Don't claim Zendesk experience.
- **Clear written communication:** thin evidence. Expect a written-reply test.
- **Escalation handling:** no evidence in your material. Prepare an honest answer that covers how you would decide to escalate.
- **Software company experience:** a stated gap. "I haven't worked for a software company." Pair it with a plan for learning the product.

**Highest-return prep:** the software-company question (A1 in the file). A team lead will most likely press on it. Say the gap plainly, then give your plan for week one.

**Other key questions:**
- **Refund scenario (B1):** a customer is angry about a refund that hasn't arrived. Structure: acknowledge, check status, say what you can promise, name who decides.
- **Refund training (C1, D2):** be ready to say exactly what you taught and whether you designed the process. You trained the new starters, but the file doesn't say you designed the process.

**Prohibited claims:** don't say you have Zendesk experience, have handled escalations, have worked in software support, designed the refunds process, or resolved most of your 60 daily contacts.

**Reverse questions:** the file has five, including "How do you decide when a ticket goes to a specialist, and who makes that call?"

I've weighted the interview toward a skeptical hiring-manager style, with case and written-reply questions as the next priority. The text format makes your written replies the thing being scored.

To sharpen the pack, I need two things:
1. Is the support team lead the person who would manage you, or a peer? Will anyone else join the chat?
2. Could you paste the full job ad? That would turn the summary requirements into exact wording.

I can also play the Skeptic on A1 so you can rehearse it live. And I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: support team lead (name not given). Round: text interview in Telegram chat. Recruiter: Marcus Hale, talent team.
Built on: your summary of the job ad (not the full text), your background note, and your message. No web research was run (tier L0).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Tag | Type | Meaning |
|---|---|---|
| VAL | Behavioral / values | Whether past behaviour shows customer-support values |
| EXP | Experience deep-dive | Whether your CV claims hold up under scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Not scored here; no company research was run |
| CASE | Live problem | Structure and reasoning on a support problem |

In a text interview, writing is the channel being scored. Slow, clear, complete replies count.

## Fit snapshot

Requirements come from your summary of the ad, so they are unquoted. The source is named in each row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (job ad, your summary) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | high | [grounded] | none | No gap on years. Expect a probe on how much of that was support rather than sales or billing; say which, in your own words |
| F2 | Zendesk or a similar ticketing tool (job ad, your summary) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material reaches the requirement in other terms. Bridge, reworded from that quote only: "I use Freshdesk every day." Zendesk is not in your material, so do not say you have used it |
| F3 | Clear written communication (job ad, your summary) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Volume touches this requirement without showing how clear your writing is. Answer slot: if a written reply of yours is an example, describe what made it clear; if none comes to mind, say so and describe how you check your own writing |
| F4 | Confidence handling escalations (job ad, your summary) | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have passed a case up or handled one that needed a manager's decision, say what you did; if not, say so and describe how you would decide when to escalate |
| F5 | Working in a software company's support (job ad, your summary, as a company-context requirement) | "I've never worked for a software company." — your message | none | [grounded] | capability | Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past |

Gap rows F3 and F4 are not claims you can make yet. Treat them as answer slots.

## Prohibited claims

These claims are not coached. Each one would overstate your material.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have Zendesk experience" | F2: your material names Freshdesk only | "I use Freshdesk every day, and I haven't used Zendesk." |
| "I have handled escalations" | F4: none given | Answer slot only, per F4 |
| "I have worked in software or SaaS support" | F5: you stated the absence | "I haven't worked for a software company." |
| "I designed the refunds process" | Your sentence is "I trained four new starters on our refunds process last year" | "I trained four new starters on our refunds process last year." |
| "I resolved most of my 60 contacts a day" | Your sentence states volume, not outcomes | "around 60 calls and emails a day" |

## Persona table

Relationship: a support team lead running a text interview. The team lead may be your future manager, which is not confirmed. Weights are shown so you can recalibrate.

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (JD) | Tests the gaps: software background, Zendesk, escalations | High | A team lead is buying capability and checking the gaps in your summary | Hold what you have, name the gap, give a plan for closing it |
| Case / Strategist | A live support problem, written out | High | Text interviews favour written problem-solving | Structure your reply: acknowledge, check facts, state what you can do, name who decides |
| Conversational | Motivation, rapport, how you would work with the team | Medium | Text chat still carries a rapport stage | Short, warm, specific; one reason tied to the ad |
| Pressure | Short, sharp challenge on a stated gap | Low-medium | Text limits interruption, but a terse challenge is possible | Pause, restate, hold once, then concede specifically |
| Data-Driven Prober | Asks how the 60-a-day figure was measured | Low-medium | Volume figures invite a numbers check | Say what the figure is and whether you know the split |
| Values / Behavioral | Customer-first and mistake questions | Medium | No published values were checked, so these are generic | Use a real example if you have one; otherwise say so |

## Question banks

### Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. What makes you think you'd ramp up quickly here?" | JD | [grounded] "I've never worked for a software company." | Hold: "I haven't worked for a software company." Then the parts of your work that touch this, as you stated them: "I use Freshdesk every day" and "answering around 60 calls and emails a day." Then the plan: learn the product first, and ask the team lead for the top issues in week one. Concede specifically: the product knowledge will take time. Hold through two follow-ups by returning to the plan | F5 is the highest-ROI prep in this pack. A team lead is most likely to press this one, and a plan you can say without flinching changes the interview |
| A2 | "Zendesk is what we use. How long would it take you to be comfortable in it?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day, and I haven't used Zendesk." Then: both are ticketing tools, so you would check its views, tags and automations in the first days. Answer slot: if you have set up views, macros or automations in Freshdesk, say which; if not, say you haven't | F2 is a presentation gap. The question names a tool you have not used |
| A3 | "Escalations are central to this role. Tell me about one you handled." | EXP | [grounded] none given. The question presumes an escalation you may not have handled | Answer slot: if you have passed a case up, or handled one that needed a manager's decision, say what you did and why. If not, say so, then describe how you would decide when to escalate | F4 is a discovery gap. The premise comes from the ad, and the honest branch is part of the answer |
| A4 | "Your CV says 60 contacts a day. What share were escalations?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the 60 is the volume you stated. If you know the split, give it. If you do not, say so. Do not estimate | F3 and F1 meet a numbers probe. A made-up split would be the first thing to break |

### Case / Strategist (weight: high, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: a refund they were promised hasn't arrived and they're threatening to cancel. Walk me through your first reply." | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure: acknowledge, check the refund status, say what you can promise and when, name who decides if it is beyond your authority. Use refund knowledge only as the training sentence states it. Answer slot: if your role let you approve refunds, state the limit; if it did not, say you would escalate | The refund scenario is the most likely live problem. The training sentence supports the refund beats only |
| B2 | "Reply to a customer who is wrong about how our product behaves. Keep it under 100 words." | CASE | [inferred] derived from F3 | State the fact first, then what the customer can do. No blame. Count your words. No claim about your past is needed | In a text interview the written reply is the scored channel. F3 is a low-confidence gap, so rehearse it |
| B3 | "A ticket needs engineering and the customer is waiting. What do you do?" | CASE | [generic] | Say who you contact, what you tell the customer, and when you follow up. No claim about past escalations is made | Tests escalation mechanics, which F4 leaves unshown. Generic because no quote carries it |

### Conversational (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about training new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the sentence states: four people, the refunds process, last year. Answer slot: what you taught them and how you knew it had landed. If you checked, say how; if not, say so | The one sentence about a completed activity. It shows you can teach, which matters for a support role |
| C2 | "What drew you to this role?" | VAL | [generic] | One real reason, tied to one line of the ad. Keep it short. Do not claim knowledge of their product that you lack | Rapport stage of a text chat. Generic: no quote carries a motivation |
| C3 | "What would you want to learn in your first month?" | JD | [generic] | Name one or two things about the product or the team, then one thing about how you would learn them | Shows you plan for F5 without claiming a past |

### Pressure (weight: low-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take someone with no software background over an internal candidate?" | JD | [grounded] "I've never worked for a software company." | Pause. Restate. "I haven't worked for a software company, and I won't pretend I have." Name what you bring from your material only: "I use Freshdesk every day." Hold once. Concede specifically: an internal candidate who knows the product would ramp faster | Hold-then-concede. Do not fold on the volume point |
| D2 | "How much of the refunds training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say exactly what you did in your own words. If the process was set by someone else, say so. Hold the training claim and concede that you did not design the process | Tests attribution. The training claim is real; the process ownership is not stated |

### Values / Behavioral (weight: medium, 2 questions)

No company values were checked, so these are generic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer's needs ahead of a rule." | VAL | [generic] | Scaffold: pick a time you bent a process for a customer. It needs a named rule, what you did, and what happened. If no such time comes to mind, say so, then give the nearest thing your material carries | Generic values probe. Your material carries no such story, so the honest branch is part of the answer |
| E2 | "Tell me about a mistake you made with a customer and how you handled it." | VAL | [generic] | Scaffold: a real mistake, what you did to put it right, and what changed afterwards. If none, say so and describe how you handle errors | Tests ownership. Do not invent a mistake |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 30 days look like for this role?" | Shows you plan beyond the interview and sets up F5 |
| R2 | "How do you decide when a ticket goes to a specialist, and who makes that call?" | Asks about escalation, which the ad names, and surfaces F4 |
| R3 | "Which ticketing tool does the team use day to day, and how is it set up?" | Puts the Zendesk question to the team lead early. Your answer then shapes A2 |
| R4 | "What is the most common reason customers contact support here?" | Shows interest in the customer side of the work |
| R5 | "How does the team check the quality of written replies?" | Asks about standards, which tests F3 from the other side |

## Upgrade menu

- The full job ad text → each F row gets its exact wording, and the JD questions use the ad's own phrasing.
- Whether the team lead is your future manager, and whether a second person will interview you → reweights the personas and shows which banks to deepen.
- Any Zendesk or ticketing-tool setup experience you have (views, macros, automations) → would move F2 from a presentation gap to a grounded quote, and sharpen A2.
- Company values or a representative job ad (a web search, L1) → adds a values cheat sheet and checks the requirements. Deeper research (L2) is available on request, with its time cost stated.
- A saved tuesday-dossier.md from the job-underwriter → would supply verified evidence and any prohibited-claim rules. Without it, this pack is complete as it stands.

## Sources

Provided documents: your message, your background note, and your summary of the job ad.

Research tier: L0. No searches or fetches were sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | Would add a values cheat sheet; not run at L0 |
| 2. Interview process for this role family | skipped | Would confirm the loop structure; not run at L0 |
| 3. Company strategy / recent news | skipped | Would add grounding; not run at L0 |
| 4. Interviewer name and profile | n/a | No name was given |
| 5. Representative job ad | skipped | You supplied a summary, so the fit snapshot uses it; not run at L0 |
