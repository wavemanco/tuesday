Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-3-rooms-case-9-canned-ae4c0f0d/61ceb047-3cdc-4fb2-8b1b-26e730a17e05/scratchpad/orrinsford_fourth_grade_teacher_interview_pack.md`, and I've sent it to you. I built it from your invitation and your message. I ran no web research, and I had no job description, so requirements come from the invitation only.

**What the pack says:**

- **Your license meets the requirement.** Your PEL endorsement covers grades 1–6, which includes fourth grade. You can say that plainly.
- **Your biggest exposure is "I've never taught fourth grade."** The panel will probably ask about it. Say it plainly, name what carries over from third grade, and give a concrete plan for your first thirty days. Don't claim fourth-grade experience. Rehearse this one most.
- **Second exposure is team leadership.** Describe the 2024 reading-curriculum move in your own words, and don't stretch it into having led the team.
- **Questions to rehearse** cover the reading curriculum, your reading club, your weekly family email, and a mid-year new-student case. The bank is short because the material is thin. A job description would add more.
- **Reverse questions** for the panel are in the file, including one for the peers about what a new person could do in their first month.

**Two things to check:**

- The Thursday after today is November 26, 2026, which is Thanksgiving. Confirm the date with HR.
- Your message included a Social Security number. I didn't use it, and interview prep doesn't need it. I also left out your IEIN. Don't share your SSN until HR formally requests it.

**I need a few answers to finish the pack (three questions):**

1. Do you have the job description? If not, I'll proceed without it.
2. Is Principal Vantongeren your future direct supervisor, and does the panel have any focus areas or expected deliverables?
3. May I run research on Halvering Elementary and Orrinsford's values and interview process? It would fill in the values and process sections.

Other options: I can run a drill where I play the principal and push on the fourth-grade gap, or save a `tuesday-dossier.md` to carry these gaps into later sessions. I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: orrinsford_fourth_grade_teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District (Halvering Elementary School)
**Format:** 45-minute panel interview, Thursday (see date note below)
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team
**Assumption:** No job description was supplied, so requirements come from the invitation only. Panel relationships are read as principal (manager-side) plus two peers.
**Research tier:** L0. No web research was run in this pass. Values, interview-process and strategy material are not in the pack.

**Date note:** Thursday after 2026-11-25 is 2026-11-26, which is Thanksgiving in the US. Confirm the date with HR before you plan around it.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **EXP**: work-experience deep-dive. Tests whether your CV claims hold up.
- **JD**: role-driven. Tests the stated requirements, including gaps.
- **VAL**: behavioral and values. Not run, since no published values were available.
- **CO**: company knowledge. Not run, since no research was run.
- **CASE**: live problem from the role.

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. The endorsement covers grades 1 through 6, which includes grade 4. Say so plainly if asked. |
| F2 | "for the Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | capability | Your material shows third grade, not fourth. Words: "I've never taught fourth grade." Then a plan for learning fourth-grade content, said as a plan and never as a past. |
| F3 | Team leadership, a likely probe (no requirement quoted; [generic]) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Then point to the closest real evidence, F4, at its own scope. |
| F4 | Leading change within a team, a likely probe (no requirement quoted; [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your message) | medium | [grounded] | presentation | The quote already reaches this in its own terms. Describe the move. Do not add figures or outcomes you have not given. |
| F5 | Family communication, a likely probe (no requirement quoted; [generic]) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Describe what the email covers. |
| F6 | Student support outside class, a likely probe (no requirement quoted; [generic]) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | No gap. Your material does not show club results. Answer slot: if you tracked results, say what you tracked. If you did not, say so. |

Confidence: "high" means a verifiable credential. "medium" means one CV or message line with nothing inspected behind it.

## Prohibited claims

Built locally from the fit snapshot. These claims will not be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | Inflated form of F2 | Your material shows six years of third grade. Say that. |
| Has led a grade-level team | Stated negative, F3 | Plain acknowledgment: "I haven't been a team lead." No slot. |
| Led the grade-level team | Inflated form of F4 | F4's quote at its own scope: you led the move to the new reading curriculum. Your material does not show that you led the team. |

## Question banks

Ordered by weight. Panel principal is weight 4. Peer team members are weight 3.

### Principal bank (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell us about yourself and why you want to move to fourth grade." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Open with your six years in third grade. Name what carries forward. Keep the reason in your own words. | Opening question and the bridge from third to fourth. |
| A2 | "You have never taught fourth grade. What makes you ready?" | JD | [grounded] "I've never taught fourth grade" (your message) | **Highest-ROI prep.** Hold: "I haven't taught fourth grade." Then name what carries over from third grade, and what you would do in your first thirty days to learn fourth-grade content. Hold through two follow-ups by returning to the plan. Concede specifically: "I'd be learning the fourth-grade content, and I'd rely on the team to show me how it's taught." | The most likely objection. Deepest rehearsal here. Never claim fourth-grade experience. |
| A3 | "You have not led a team. How would you work with a team that has been together for years?" | JD | [grounded] "I've never been a team lead" (your message) | Hold: "I haven't been a team lead." Then describe how you worked with colleagues on the reading move (F4). Answer slot: if you chose the approach, say how. If you did not, say so and describe what you did do. | Pressure-style probe on the team-lead gap. |
| A4 | "Tell us about the reading curriculum change you led in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your message) | Beats the quote carries: the move, the grade level, the year. Tell them in your own words. Answer slot: if you set the timeline or chose the materials, say which. If someone else did, say so. | Defend-the-role question on your strongest change-leadership evidence. |
| A5 | "How did you measure whether the new reading curriculum is working?" | EXP | [inferred] "I led our grade level's move to a new reading curriculum in 2024" (your message) | Say what you observed and from whom. Answer slot: if you counted or scored anything, say what. If you did not, say so plainly. Never describe a measure you did not track. | Defend-the-number probe. Your material does not show measures, so the honest answer is ready before the probe arrives. |

### Peer bank (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name the club, the two years, and who attends. Answer slot: if you tracked reading gains, say what. If not, say so. | Peers ask about extras to test follow-through. |
| B2 | "How do you keep families informed?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe what the weekly email covers. Answer slot: if families have replied or you changed the email based on responses, say how. | Family communication is a common peer probe. |
| B3 | "Tell us about a lesson or reading group that wasn't working. What did you change?" | EXP | [generic] | Selection scaffold: pick a real time a group or lesson stalled. Name what you noticed and what you changed. If no such time comes to mind, say so plainly, then describe how you would handle it. | Open prompt. No quote carries it, so the guidance is a scaffold. |
| B4 | "A new student joins mid-year reading well below grade level. What is your first week?" | CASE | [generic] | Structure it: assess first, talk with the student and the prior teacher, then plan small groups. Ask what the school's assessment tools are. | Live problem from the role. Asks about no past, so it claims nothing about you. |
| B5 | "What would you do with the fourth-grade reading standards in your first month?" | JD | [generic] | Structure it: learn the standards, review existing units with the team, and plan the first unit. Answer slot: name the standards you have read, if you have read any. | JD-style question. The requirement is generic. |

**Requirement coverage**

- Illinois PEL with elementary endorsement: none, and why. Met by F1. Probed only if asked.
- Fourth-grade teaching: A2, B5.
- Team collaboration and leadership: A3, A4.
- Reading curriculum: A4, A5.
- Family communication: B2.
- Student support outside class: B1.

## Reverse questions

Each one has a reason it lands.

1. "What does the fourth-grade team already do well that a new teacher should protect?" It shows you care about the team's existing practice.
2. "What would success look like in the first year for this role?" It asks for a clear standard for your work.
3. "How does the team plan reading instruction together?" It links to A4 and signals you already think about curriculum as a team.
4. "How does the principal support new team members in their first year?" It tests the support you will have.
5. "What is the current status of the reading curriculum, and what is the team focused on next?" It ties to A4 and lets you show you already know the work.
6. Peer reciprocity: "What could a new person do in their first month that would genuinely help your team?" It asks the peers what they need.

## Upgrade menu

- A job description → `[generic]` requirements become `[grounded]`, and more questions are added to the banks.
- The principal's and team's focus areas, or any deliverable the panel will expect → coverage tuned to what they will score.
- Permission to run research on Halvering and Orrinsford → values, process and strategy rows get filled in.
- A confirmed interview date and time → prep can be scheduled against the real window.
