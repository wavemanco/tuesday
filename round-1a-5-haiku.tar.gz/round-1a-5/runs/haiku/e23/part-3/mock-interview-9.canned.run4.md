Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-e23-part-3-rooms-case-9-canned-c82ee8fb/3a5ac0b5-8774-4960-896e-e119cd81213f/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`.

Two things before the pack itself:

- **Check the date.** Today is Wednesday, November 25, so "Thursday" is tomorrow, November 26, which is Thanksgiving. The invite gives no time either. Confirm both with HR.
- **I left your Social Security number out.** It isn't needed for interview prep. Keep it out of anything you send the school before an offer.

The pack is built from your invitation and resume only. I ran no searches, and I didn't have the job description, so the fourth-grade requirements are not quoted from a source. The top-priority prep is question A1, "You've never taught fourth grade. What makes you the lower-risk hire?" It's the gap the principal is most likely to press. Hold your position through two follow-ups, then concede specifically and give a first-month plan. Don't claim fourth-grade experience you don't have.

Two offers, neither pushed:
- I can play the Skeptic on A1 as a live rehearsal.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Questions:
1. Do you have the job description text? If so, paste it and I'll ground the fourth-grade requirements in it.
2. May I search public information on the district and on Principal Dolores Vantongeren? That would add an interviewer read and a tailored reverse question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Format: 45-minute panel. Panel: Principal Dolores Vantongeren, plus two members of the fourth-grade team. Time: "Thursday," no time given (Thursday is November 26, 2026, Thanksgiving; confirm the date and time with HR).
Research tier: L0. Built from your invitation and your resume only. No searches or fetches were run.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: EXP (your experience), JD (the role), CASE (a live problem), VAL (values), CO (company knowledge).
- The guidance is scaffolding for a spoken answer, not a script. Rehearse it aloud in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade and I've never been a team lead." (your message) | medium | [grounded] | capability | Your own words: "I've never taught fourth grade." Bridge at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Plan, not past: how you would learn the fourth-grade content. |
| F2 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it in the CV's terms: "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." |
| F3 | Grade-level reading instruction [generic] (role family; no quote in the invitation) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | none | The quote reaches reading instruction in role terms. It is one line, so expect a probe on what "led" meant. Say what you did, in your own words. |
| F4 | Family communication and reading support [generic] (role family) | "I've run the after-school reading club for the last two years" (your CV); "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Both lines are yours and can be quoted as written. |
| F5 | Team lead [generic] (not in the invitation) | "I've never been a team lead." (your message) | medium | [grounded] | capability | Your own words: "I've never been a team lead." Then how you would work with a team, said as a plan, never as a past. |

Your message is the source of the two negatives in F1 and F5. Your CV is the source of the rest. The invitation is the source of the license requirement and the position title.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated (F1) | "I've never taught fourth grade." Then the third-grade quote at its own scope. |
| Has been a team lead | Negative you stated (F5) | "I've never been a team lead." Then F3's quote, at its own scope. |
| Led the district's reading adoption | Inflated form of F3 | F3's quote as written: "I led our grade level's move to a new reading curriculum in 2024." Do not widen "our grade level" to the school or district. |

The pack's observation: your material shows a grade-level move, not what "led" involved in detail. The pack will not write that detail for you.

## Persona weights

| Persona | Who | Weight | Why |
|---|---|---|---|
| Skeptic | Principal Vantongeren | 5 | A panel with a principal weights the gap (fourth grade, team lead) and the motivation. The principal is the one who will press it. |
| Case / Strategist | Principal Vantongeren | 3 | A hiring-side panel gives a live classroom problem. |
| Peer Evaluator | Fourth-grade team members | 4 | Team members price what you add to their work and how you collaborate. |
| Data-Driven Prober | Fourth-grade team members | 3 | Team members check claims about the reading club. |
| Pressure | Panel, as a group | 2 | A 45-minute panel can press on the team-lead gap. |
| Conversational | Opener | 2 | The biography question is scored even when casual. |

Weights are the panel's priors, not evidence about these three people. Without a profile for each member, they are the round-type priors from the persona model.

## Question banks

### Skeptic (weight 5, deepest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you the lower-risk hire?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your message) | **Highest-ROI prep in this pack.** Hold the position through two follow-ups: "I haven't taught fourth grade." Then the adjacent fact: "For six years I taught third grade at a public elementary school in Joliet." Concede specifically: name what you do not yet know about the fourth-grade content. Then give the plan: what you would study or ask in the first month. Do not claim fourth-grade experience you do not have. | F1 is the gap the principal is most likely to press. The question presupposes your stated negative, so the plain acknowledgment is allowed. |
| A2 | "Why are you leaving Joliet, and why this school?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Story-mapped on F1: the six years are the fact. Answer slot: if your reason is in your own words, say it. If the reason is not yours to give, say what you looked for in the school. | A motivation probe is standard for a Skeptic. The quote supplies only the six years, not a reason. |

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Open prompt. Choose an instance. If a disagreement was part of the 2024 move, say what it was and how it was resolved. If none was, say so plainly and give the nearest thing you did. | F3 is the strongest line you have for collaboration. The team will test whether it holds up. |
| B2 | "What would you need from our team in your first term?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what the 2024 move involved, in those words, and what you would ask the team to share, such as their plans and materials. Ask about their work, not your need alone. | Peer reciprocity: a team member asks what you bring and what you need. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is reading two years below level in October. What do you do?" | CASE | [generic] | Structure it: what you would check first (assessment, the reading log, the student's history), what you would change in the classroom, and when you would bring in the team. This question makes no claim about your past. | A live problem from the role. Fourth-grade reading is the core of the job. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you measure the reading club's results over the two years?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you measured anything, say what and how. If you did not, say so plainly, and say what you would measure first. Never describe a measure you did not track. | F4 is the club, and a team member will ask what it showed. The quote does not show a result. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path into teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Prepare a 90-second arc: the path into teaching, the six years in third grade, the 2024 reading move, and the reading club. Use only what is quoted. | Casual openers are still scored. The arc should be ready before the first question. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You've never been a team lead. Why would we think you can lead this team?" | JD | [grounded] "I've never been a team lead." (your message) | Hold-then-concede. Hold: "I've never been a team lead." Then the one thing you did lead: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically: name what you have not led yet. Do not claim a team-lead role. | F5 is the gap the panel can press. A held position you cannot back is the one a second follow-up breaks. |

## Requirement coverage

- Illinois PEL with elementary endorsement (invitation) → F2. No question: the credential is met, and a question adds nothing.
- Fourth Grade Teacher position (invitation) → A1, A2, E1.
- Team lead (your message; not in the invitation) → P1.
- Fourth-grade team collaboration [generic] → B1, B2.
- Fourth-grade reading [generic] → C1, D1.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first semester look like for the person in this role?" | Shows you are planning for the job, not just the interview. |
| R2 | "How much of the fourth-grade reading plan is set by the curriculum, and how much do teachers adjust?" | Tests what your 2024 curriculum experience would carry over. |
| R3 | "What would a new team member do in their first month that would genuinely help your team?" | Reciprocity for the peer members of the panel. |
| R4 | "How does the school expect teachers to communicate with families?" | Connects your weekly email to the school's own practice. |
| R5 | "What have you seen work for new fourth-grade teachers here in their first year?" | Asks them to describe their own experience, which is the only one you can learn from. |

## Prohibited claims and sources

Sources: your invitation and your resume. No search or fetch was run. Research tier L0.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet (section not built; no values round detected). Would have added published values to map to stories. |
| 2. Interview process, fourth-grade panel | unavailable | Loop structure. Would have confirmed the panel's format and weights. |
| 3. District strategy / recent news | unavailable | Grounding brief. Would have supplied current reading and staffing priorities. |
| 4. Principal Dolores Vantongeren | unavailable | Interviewer read and a tailored reverse question. |
| 5. Representative fourth-grade teacher JD | unavailable | Would have labeled the F3 and F4 requirements [inferred] or [grounded] and added questions. |

## Upgrade menu

- The job description text → F3 and F4 become [grounded], and the coverage table gets its requirement lines.
- The principal's and team members' public background (with your consent to search) → an interviewer read and a tailored reverse question.
- The names of the two team members → persona weights per member.
- The recruiter's or HR's note on the format → coverage of any pre-declared focus areas.
- The time you have to prepare → a prioritized prep schedule.
