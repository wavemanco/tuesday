I'll use the mock-interview prep skill for this. I'm leaving the SSN out of the request because an interview prep pack doesn't need it.
Your SSN was in your message. I left it out: interview prep doesn't need it, and it shouldn't go into anything you send the school. Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/e23/part-3/rooms/case-9-canned-fb2ca1eb/Halvering_fourth-grade-teacher_interview_pack.md`. I built it from your résumé and the invite. No job posting was supplied, so the fourth-grade and team-lead requirements are labeled `[generic]`. I did not run any web research.

# Grace: Fourth Grade Teacher interview prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Format:** 45-minute panel, Thursday 2026-11-26: Principal Dolores Vantongeren and two members of the fourth-grade team
**Relationships:** principal = your future manager; team members = peers

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioral / values alignment
- **EXP**: deep-dive on your experience
- **JD**: a stated role requirement
- **CO**: company knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

## The fit snapshot

The only requirement text supplied is the invite's license line, so it is quoted. The fourth-grade and team-lead items are role-family requirements, labeled `[generic]`, because no posting was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." - invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" - your CV | high | [grounded] | none | No gap. Say the license and its date in those words. Bring a copy in case the panel asks. |
| F2 | Teaching fourth grade `[generic]` | "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I've never taught fourth grade" - your CV | medium | [grounded] | capability | Your material shows the stated absence: "I haven't taught fourth grade." The adjacent work stays at its own scope: six years teaching third grade. Answer slot: say how you would learn the fourth-grade content, as a plan and never as a past. |
| F3 | Leading team work in a grade level `[generic]` | "I've never been a team lead" - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | medium | [grounded] | capability | The stated absence is "I haven't been a team lead." Then the led move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not describe the move as team leadership. |
| F4 | Communicating with families `[generic]` | "I write a weekly email to families." - your CV | medium | [grounded] | none | The quote already reaches the requirement. Say what the email covers, in your words. |
| F5 | Reading instruction `[generic]` | "I led our grade level's move to a new reading curriculum in 2024" - your CV; "I've run the after-school reading club for the last two years" - your CV | medium | [grounded] | presentation | Reword only these two quotes; add no practice, figure or event. Your material shows a move and a club, nothing more. |

## Prohibited claims

These are not coached, in any answer, hold, or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've taught fourth grade" | Negative you stated, F2 | "I haven't taught fourth grade." No slot. |
| "I've been a team lead" | Negative you stated, F3 | "I haven't been a team lead." No slot. |
| "I ran the school's reading program" | Inflated form of F5's reading club | F5's quote at its own scope: "I've run the after-school reading club for the last two years." Limit, as the pack's observation: your material describes a club, not a school-wide program. |
| "I chose the new reading curriculum" | Inflated form of F5's move | F5's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Limit, as the pack's observation: your material says you led the move, not that you selected the curriculum. |

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the fourth-grade and team-lead gaps | Highest, 5 questions. The principal is the manager, and a hiring panel is checking your two stated gaps. | Concede each gap in your own words, then bridge only to what your CV says. |
| Case/Strategist | A live classroom or planning problem | Medium, 3 questions. The principal and the grade team both plan this kind of work. | Clarify, then structure, then answer. |
| Pressure | Interrupts on fit or on your curriculum role | Low-medium, 2 questions. Possible from the principal. | Pause, restate, hold for two follow-ups, then concede exactly. |
| Peer Evaluator | "Where do you fit, and what do you need from us?" | Medium, 4 questions. Team members are peers and will judge whether you add to their load. | Reciprocity: what you bring their team, then what you need from them. |
| Data-Driven Prober | Counts, and what you measured | Medium, 3 questions. Grade teams often look at data together. | Say what you counted and where the figure stops. |
| Conversational | An opening arc and a casual question | Low, 2 questions. Easy to treat as unscored. | A 90-second arc, and treat casual questions as scored. |

The panel blend takes the top two personas of each member's relationship: the principal's are Skeptic and Case/Strategist, and the team members' are Peer Evaluator and Data-Driven Prober.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. How would you do this job on day one?" | JD | [grounded] "I've never taught fourth grade" - your CV; "Six years teaching third grade at a public elementary school in Joliet." - your CV | The highest-ROI rehearsal in this pack. Open with "I haven't taught fourth grade." Then the third-grade years at their own scope. Then a plan: which fourth-grade materials you would read first, and whom on the team you would ask. Hold through two follow-ups by returning to the plan. | F2 is the largest gap, and the principal's most likely first probe. |
| A2 | "Your background is third grade. What would fourth grade ask of you that third grade did not?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV | Answer from what you know about the grade. If you do not yet know, say so and name what you would check first. Do not claim knowledge of fourth-grade demands you have not seen. | F2. The question presupposes nothing beyond your quoted third-grade years. |
| A3 | "You've never been a team lead. Why would this team trust you to lead anything?" | JD | [grounded] "I've never been a team lead" - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | Hold: "I haven't been a team lead." Then the curriculum move, described as what you led. Concede specifically: you would learn how the team runs before taking on any lead role. Do not stretch the move into team leadership. | F3. The hold-then-concede structure matters most here. |
| A4 | "Why would you leave a school where you've taught for six years?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV | Give your reason for wanting fourth grade and this team, in your own words. Do not criticize your current school. | Motivation is a standard skeptic probe. |
| A5 | "What is the weakest part of your application for this role?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." - your CV | Name the two gaps plainly, then the plan for each. Do not add a third. | Asks you to rank your own gaps, which is the honest answer the panel is listening for. |

### Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | Hold: what you bring is six years of elementary teaching and a curriculum move you led. Concede: the other candidate has fourth-grade experience you do not. Keep the concession short. | F2 and F5 under time pressure. |
| B2 | "That reading curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Answer slot: if you chose the curriculum or drove the decision, say how, in your own words. If the decision was made by the team or above you, say so plainly and describe what you led. | F5. The second branch allows that the decision was not yours. |

### Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your fourth-grade class is well behind in reading. What do you do first?" | CASE | [generic] | Clarify first: what the student's gap is, what the team has already tried, and what the data shows. Then structure: assess, talk with the team, plan small-group work. Make no claim about your own past. | Tests structure on a live problem from this role. |
| C2 | "A family emails you upset about a grade. How do you respond?" | CASE | [generic] | Structure the reply: listen, confirm the facts, explain the next step, follow up in writing. No claim about your past. | F4 is the family-communication rehearsal; the scenario does not need your history. |
| C3 | "Walk me through how you'd plan a week of reading for fourth graders." | CASE | [generic] | Structure the week: the goal, the whole-class block, the small groups, and how you would check progress. No claim about your past. | Live problem tied to F5's subject area. |

### Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where would you fit in on our team, and what would you need from us?" | JD | [grounded] "I write a weekly email to families." - your CV; "I've run the after-school reading club for the last two years" - your CV | Reciprocity: what you bring their team, using the two quotes at their own scope. Then what you would need from them. | F4 and F5 framed as what you offer the team. |
| D2 | "When you disagree with a colleague about how to teach something, what do you do?" | CASE | [generic] | Answer slot: pick a time you disagreed with a colleague about instruction. If no such time comes to mind, say so plainly, then say how you would handle it. | Team-seam probe. Your material does not show a disagreement, so the answer is a slot. |
| D3 | "When work spans teams, how do you share credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Name who was part of the move, in your own words, and what each person did. Do not name anyone you cannot describe. | F5 gives the credit-sharing example. |
| D4 | "What would you most want a new fourth-grade teacher to know in the first month?" | JD | [generic] | Answer with a question for the team. It shows you are listening for their practices. | Reciprocity framing for a peer. |

### Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did you judge whether the curriculum move went well, if you did?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Answer slot: if you tracked something, say what, from whom, and what you did with it. If you did not track anything formally, say so plainly, then say what you would measure next time. | F5. The question asks about a measure your CV does not show. |
| E2 | "How many students does your reading club serve, and what can you say about its effect?" | EXP | [grounded] "I've run the after-school reading club for the last two years" - your CV | Answer slot: if you have a count, say it and how it was taken. If you do not, say so plainly. Do not claim an effect you have not measured. | F5. A figure you give invites a probe on how it was counted. |
| E3 | "Which fourth-grade data would you look at first?" | CASE | [generic] | Name what you would look at, and why. No claim about past work. | Team-data probe. |

### Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your path to teaching." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" - your CV; "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV; "I've run the after-school reading club for the last two years" - your CV | A 90-second arc built only from these four quotes, in their order. Treat it as scored. | Opening arc. It covers F1 and F5 and sets up the panel's follow-ups. |
| F2 | "What are you looking forward to teaching this year?" | JD | [generic] | Answer honestly, in terms of what excites you. No claim about past work. | Rapport. Casual questions are still scored. |

**Requirement coverage.** License: F1 and F1's arc (F1). Fourth-grade teaching: A1, A2, B1. Team lead: A3, A5. Families: C2, D1. Reading: B2, E1, E2. Team members: D1, D4. Nothing uncovered.

## Reverse questions

Each one has a reason it lands.

1. "What does a strong first semester look like in this role?" Shows you are thinking about outcomes.
2. "How does the fourth-grade team plan and share work now?" Shows you are ready to join a team.
3. "Which reading materials does fourth grade use here?" Shows you know reading instruction matters to the role.
4. "How do you hope families stay informed about the fourth-grade year?" Ties to your weekly family email.
5. "What would you most want a new fourth-grade teacher to know in the first month?" Reciprocity for the team members.

No interviewer profile was supplied, so no reverse question is tied to a career path.

## Sources

Provided documents: the invite text; your résumé, as pasted in your message.

**Research tier: L0.** No searches or page fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering values or Orrinsford values | unavailable | Values cheat sheet. Not built: no values-style round was detected, and no published values were in hand. |
| 2. Interview process for fourth-grade teaching | unavailable | Loop structure. Persona weights use the panel prior instead. |
| 3. District strategy and recent news | unavailable | Company-knowledge questions. None were written. |
| 4. Dolores Vantongeren, Halvering | unavailable | Interviewer read and a reverse question tied to her path. A name was given, so the query can be formed. |
| 5. Representative fourth-grade teacher posting | unavailable | Would have labeled the fourth-grade and team-lead requirements `[inferred]`. |

## Upgrade menu

- **Full job posting text** → the fourth-grade and team-lead rows gain quoted requirements, and their `[generic]` labels become `[grounded]`.
- **Interviewer profile for Dolores Vantongeren** → persona weights from her public footprint, and a reverse question tied to her path.
- **Team members' names** → personas assigned per member.
- **L1 research** (district values, interview process, strategy) → the values cheat sheet if values are published, the loop structure, and company-knowledge questions.
- **Any deliverable HR named**, such as a demo lesson → a build section for it.

---

Two things would sharpen this:

1. Can you paste the full job posting? The fourth-grade and team-lead requirements would then be quoted rather than labeled `[generic]`.
2. Did HR say whether the panel expects a demo lesson or any other deliverable?

I can play the Skeptic on A1, the highest-priority question, as a drill whenever you want. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Grace: Fourth Grade Teacher interview prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Format:** 45-minute panel, Thursday 2026-11-26: Principal Dolores Vantongeren and two members of the fourth-grade team
**Relationships:** principal = your future manager; team members = peers

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioral / values alignment
- **EXP**: deep-dive on your experience
- **JD**: a stated role requirement
- **CO**: company knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

## The fit snapshot

The only requirement text supplied is the invite's license line, so it is quoted. The fourth-grade and team-lead items are role-family requirements, labeled `[generic]`, because no posting was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." - invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" - your CV | high | [grounded] | none | No gap. Say the license and its date in those words. Bring a copy in case the panel asks. |
| F2 | Teaching fourth grade `[generic]` | "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I've never taught fourth grade" - your CV | medium | [grounded] | capability | Your material shows the stated absence: "I haven't taught fourth grade." The adjacent work stays at its own scope: six years teaching third grade. Answer slot: say how you would learn the fourth-grade content, as a plan and never as a past. |
| F3 | Leading team work in a grade level `[generic]` | "I've never been a team lead" - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | medium | [grounded] | capability | The stated absence is "I haven't been a team lead." Then the led move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not describe the move as team leadership. |
| F4 | Communicating with families `[generic]` | "I write a weekly email to families." - your CV | medium | [grounded] | none | The quote already reaches the requirement. Say what the email covers, in your words. |
| F5 | Reading instruction `[generic]` | "I led our grade level's move to a new reading curriculum in 2024" - your CV; "I've run the after-school reading club for the last two years" - your CV | medium | [grounded] | presentation | Reword only these two quotes; add no practice, figure or event. Your material shows a move and a club, nothing more. |

## Prohibited claims

These are not coached, in any answer, hold, or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've taught fourth grade" | Negative you stated, F2 | "I haven't taught fourth grade." No slot. |
| "I've been a team lead" | Negative you stated, F3 | "I haven't been a team lead." No slot. |
| "I ran the school's reading program" | Inflated form of F5's reading club | F5's quote at its own scope: "I've run the after-school reading club for the last two years." Limit, as the pack's observation: your material describes a club, not a school-wide program. |
| "I chose the new reading curriculum" | Inflated form of F5's move | F5's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Limit, as the pack's observation: your material says you led the move, not that you selected the curriculum. |

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the fourth-grade and team-lead gaps | Highest, 5 questions. The principal is the manager, and a hiring panel is checking your two stated gaps. | Concede each gap in your own words, then bridge only to what your CV says. |
| Case/Strategist | A live classroom or planning problem | Medium, 3 questions. The principal and the grade team both plan this kind of work. | Clarify, then structure, then answer. |
| Pressure | Interrupts on fit or on your curriculum role | Low-medium, 2 questions. Possible from the principal. | Pause, restate, hold for two follow-ups, then concede exactly. |
| Peer Evaluator | "Where do you fit, and what do you need from us?" | Medium, 4 questions. Team members are peers and will judge whether you add to their load. | Reciprocity: what you bring their team, then what you need from them. |
| Data-Driven Prober | Counts, and what you measured | Medium, 3 questions. Grade teams often look at data together. | Say what you counted and where the figure stops. |
| Conversational | An opening arc and a casual question | Low, 2 questions. Easy to treat as unscored. | A 90-second arc, and treat casual questions as scored. |

The panel blend takes the top two personas of each member's relationship: the principal's are Skeptic and Case/Strategist, and the team members' are Peer Evaluator and Data-Driven Prober.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. How would you do this job on day one?" | JD | [grounded] "I've never taught fourth grade" - your CV; "Six years teaching third grade at a public elementary school in Joliet." - your CV | The highest-ROI rehearsal in this pack. Open with "I haven't taught fourth grade." Then the third-grade years at their own scope. Then a plan: which fourth-grade materials you would read first, and whom on the team you would ask. Hold through two follow-ups by returning to the plan. | F2 is the largest gap, and the principal's most likely first probe. |
| A2 | "Your background is third grade. What would fourth grade ask of you that third grade did not?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV | Answer from what you know about the grade. If you do not yet know, say so and name what you would check first. Do not claim knowledge of fourth-grade demands you have not seen. | F2. The question presupposes nothing beyond your quoted third-grade years. |
| A3 | "You've never been a team lead. Why would this team trust you to lead anything?" | JD | [grounded] "I've never been a team lead" - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | Hold: "I haven't been a team lead." Then the curriculum move, described as what you led. Concede specifically: you would learn how the team runs before taking on any lead role. Do not stretch the move into team leadership. | F3. The hold-then-concede structure matters most here. |
| A4 | "Why would you leave a school where you've taught for six years?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV | Give your reason for wanting fourth grade and this team, in your own words. Do not criticize your current school. | Motivation is a standard skeptic probe. |
| A5 | "What is the weakest part of your application for this role?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." - your CV | Name the two gaps plainly, then the plan for each. Do not add a third. | Asks you to rank your own gaps, which is the honest answer the panel is listening for. |

### Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV | Hold: what you bring is six years of elementary teaching and a curriculum move you led. Concede: the other candidate has fourth-grade experience you do not. Keep the concession short. | F2 and F5 under time pressure. |
| B2 | "That reading curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Answer slot: if you chose the curriculum or drove the decision, say how, in your own words. If the decision was made by the team or above you, say so plainly and describe what you led. | F5. The second branch allows that the decision was not yours. |

### Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your fourth-grade class is well behind in reading. What do you do first?" | CASE | [generic] | Clarify first: what the student's gap is, what the team has already tried, and what the data shows. Then structure: assess, talk with the team, plan small-group work. Make no claim about your own past. | Tests structure on a live problem from this role. |
| C2 | "A family emails you upset about a grade. How do you respond?" | CASE | [generic] | Structure the reply: listen, confirm the facts, explain the next step, follow up in writing. No claim about your past. | F4 is the family-communication rehearsal; the scenario does not need your history. |
| C3 | "Walk me through how you'd plan a week of reading for fourth graders." | CASE | [generic] | Structure the week: the goal, the whole-class block, the small groups, and how you would check progress. No claim about your past. | Live problem tied to F5's subject area. |

### Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where would you fit in on our team, and what would you need from us?" | JD | [grounded] "I write a weekly email to families." - your CV; "I've run the after-school reading club for the last two years" - your CV | Reciprocity: what you bring their team, using the two quotes at their own scope. Then what you would need from them. | F4 and F5 framed as what you offer the team. |
| D2 | "When you disagree with a colleague about how to teach something, what do you do?" | CASE | [generic] | Answer slot: pick a time you disagreed with a colleague about instruction. If no such time comes to mind, say so plainly, then say how you would handle it. | Team-seam probe. Your material does not show a disagreement, so the answer is a slot. |
| D3 | "When work spans teams, how do you share credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Name who was part of the move, in your own words, and what each person did. Do not name anyone you cannot describe. | F5 gives the credit-sharing example. |
| D4 | "What would you most want a new fourth-grade teacher to know in the first month?" | JD | [generic] | Answer with a question for the team. It shows you are listening for their practices. | Reciprocity framing for a peer. |

### Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did you judge whether the curriculum move went well, if you did?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" - your CV | Answer slot: if you tracked something, say what, from whom, and what you did with it. If you did not track anything formally, say so plainly, then say what you would measure next time. | F5. The question asks about a measure your CV does not show. |
| E2 | "How many students does your reading club serve, and what can you say about its effect?" | EXP | [grounded] "I've run the after-school reading club for the last two years" - your CV | Answer slot: if you have a count, say it and how it was taken. If you do not, say so plainly. Do not claim an effect you have not measured. | F5. A figure you give invites a probe on how it was counted. |
| E3 | "Which fourth-grade data would you look at first?" | CASE | [generic] | Name what you would look at, and why. No claim about past work. | Team-data probe. |

### Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your path to teaching." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" - your CV; "Six years teaching third grade at a public elementary school in Joliet." - your CV; "I led our grade level's move to a new reading curriculum in 2024" - your CV; "I've run the after-school reading club for the last two years" - your CV | A 90-second arc built only from these four quotes, in their order. Treat it as scored. | Opening arc. It covers F1 and F5 and sets up the panel's follow-ups. |
| F2 | "What are you looking forward to teaching this year?" | JD | [generic] | Answer honestly, in terms of what excites you. No claim about past work. | Rapport. Casual questions are still scored. |

**Requirement coverage.** License: F1 and F1's arc (F1). Fourth-grade teaching: A1, A2, B1. Team lead: A3, A5. Families: C2, D1. Reading: B2, E1, E2. Team members: D1, D4. Nothing uncovered.

## Reverse questions

Each one has a reason it lands.

1. "What does a strong first semester look like in this role?" Shows you are thinking about outcomes.
2. "How does the fourth-grade team plan and share work now?" Shows you are ready to join a team.
3. "Which reading materials does fourth grade use here?" Shows you know reading instruction matters to the role.
4. "How do you hope families stay informed about the fourth-grade year?" Ties to your weekly family email.
5. "What would you most want a new fourth-grade teacher to know in the first month?" Reciprocity for the team members.

No interviewer profile was supplied, so no reverse question is tied to a career path.

## Sources

Provided documents: the invite text; your résumé, as pasted in your message.

**Research tier: L0.** No searches or page fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering values or Orrinsford values | unavailable | Values cheat sheet. Not built: no values-style round was detected, and no published values were in hand. |
| 2. Interview process for fourth-grade teaching | unavailable | Loop structure. Persona weights use the panel prior instead. |
| 3. District strategy and recent news | unavailable | Company-knowledge questions. None were written. |
| 4. Dolores Vantongeren, Halvering | unavailable | Interviewer read and a reverse question tied to her path. A name was given, so the query can be formed. |
| 5. Representative fourth-grade teacher posting | unavailable | Would have labeled the fourth-grade and team-lead requirements `[inferred]`. |

## Upgrade menu

- **Full job posting text** → the fourth-grade and team-lead rows gain quoted requirements, and their `[generic]` labels become `[grounded]`.
- **Interviewer profile for Dolores Vantongeren** → persona weights from her public footprint, and a reverse question tied to her path.
- **Team members' names** → personas assigned per member.
- **L1 research** (district values, interview process, strategy) → the values cheat sheet if values are published, the loop structure, and company-knowledge questions.
- **Any deliverable HR named**, such as a demo lesson → a build section for it.
