# Halvering Elementary School — Fourth Grade Teacher — Panel Interview Prep

**Company:** Orrinsford Community School District (Halvering Elementary School)
**Role:** Fourth Grade Teacher
**Format:** 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team.
**Relationship:** Principal (manager-level) and two peers. Session 1 of this pack.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** values alignment · **EXP** your experience, checked for accuracy · **JD** the role's stated requirements · **CO** company and strategy knowledge · **CASE** a live problem from the job.
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Prep time was not stated, so no schedule is built. Start with **C1**, the highest-return item in the pack.

## Fit snapshot

Requirements come from your invite and the job title. No job posting was supplied, so most rows are role-family requirements labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your message (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | Met on your CV. Confirm the license and its date if asked. No bridge needed. |
| F2 | Fourth-grade classroom experience (job title) | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [generic] | capability | Your material does not show fourth-grade teaching, and you have stated it is absent. Words: "I haven't taught fourth grade." Then the adjacent experience, in your words: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: how you would learn the fourth-grade standards, said as a plan and never as a past. |
| F3 | Grade-team leadership (team members on the panel) | "I've never been a team lead" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [generic] | capability | You have stated you have not been a team lead. Words: "I haven't been a team lead." The 2024 move is leadership of a change, not of a team, and should not be described as team leadership. |
| F4 | Reading instruction (job title, role family) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [generic] | presentation | Your quotes reach reading instruction in other terms: a curriculum change and a two-year club. Bridge by rewording these quotes only. Do not add results you have not stated. |
| F5 | Family communication (job title, role family) | "I write a weekly email to families." — your CV | medium | [generic] | none | Your quote states the practice directly. Say what the email covers and how often you send it. |

## Prohibited claims

These are claims this pack will not coach, and why. Each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have been a team lead" or "I've led a team" | Inflated form of F3. Your material says you led a change, and you have stated you have not been a team lead. | F3's quote at its own scope. The limit is the pack's observation: your material shows leading a curriculum move, not leading a team. Say "I haven't been a team lead." |
| "I have taught fourth grade" or "I know the fourth-grade standards" | Negative you stated (F2). | "I haven't taught fourth grade." No claim of knowledge; describe a plan to learn. |
| "I designed" or "I chose" the reading curriculum | Inflated form of F4's quote "I led our grade level's move to a new reading curriculum in 2024". | The quote at its own scope: you led the move. Who selected the curriculum is an answer slot (C3). |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer evaluator (two fourth-grade team members) | Practical questions about the work: planning, the reading block, how you would fit in. | **High (about 40%).** Two of three panelists are peers, and they will judge how you would work with them. | Rehearse concrete examples from your own classroom, and say what you did, not what the team does. |
| Principal (manager-level) | Judgment and fit: why this grade, how you handle situations, your first 90 days. | **Medium-high (about 35%).** The principal sets the hiring decision and will weigh the grade-level gap against your six years. | Answer briefly and in order. Hold your position on the gap, then name what you would do first. |
| Skeptic | Direct probes on the two stated gaps and on claims you make. | **Medium (about 25%).** The two gaps are the most likely points of pressure. | Hold-then-concede: hold the adjacent experience, then concede the gap specifically. Never fold on the core claim. |

Weights are judgment, not a score. Your invite does not say which panelist asks which question. If you know more about the panel, the weights should change.

## Question banks

Coverage note: this pack has 13 questions, below the usual range. A job posting would add JD-tagged questions for the stated requirements.

### A. Peer evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You led your grade level's move to a new reading curriculum. Walk us through how that happened." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Tell the move in your own words: what changed, who was on the grade level, and the first step you took. Answer slot: if you chose the curriculum, say how you decided. If the choice was made above you and your part was carrying it out, say that plainly. | F4 is the reading bridge, and this question will test whether "led" holds up. Name the decision and your part in it, and keep to the sentence's scope. |
| A2 | "A new colleague is struggling with the reading block in fourth grade. What would you do in the first two weeks?" | CASE | [generic] | Structure it: observe first, ask what the colleague has seen, agree on a routine, and check back. This question makes no claim about your past, so the guidance makes none. | A live problem from the role. Peers test how you would handle a working relationship. |
| A3 | "You haven't taught fourth grade. What do you already know about the fourth-grade content?" | JD | [grounded] "I've never taught fourth grade" — your message; [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Start with "I haven't taught fourth grade." Then the third-grade experience, in your words. Then a specific plan for learning the standards. Do not claim fourth-grade knowledge you do not have. | F2. This question is asked as a fact-check; the honest answer is the negative plus the adjacent experience plus a plan. |
| A4 | "What did students get out of the after-school reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Describe who attended and what the club does. Answer slot: if you tracked reading results, say what you tracked. If you did not track results, say so and say what you would track. | F4. Peers will ask for outcomes. Only say what you measured. |
| A5 | "How do you keep families informed during the year?" | EXP | [grounded] "I write a weekly email to families." — your CV | Say what the weekly email covers and how families respond to it. Answer slot: if you know how families responded, say how. If you do not track responses, say so. | F5. This is your clearest strength; keep it concrete. |

### B. Principal (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "After six years in third grade, why move to fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Give your real reason in your own words. Keep it to what you know about the grade and the team. Do not invent a motive. | The principal asks about motivation to check consistency. |
| B2 | "A parent emails upset about a grade and wants a meeting by Friday. What do you do?" | CASE | [generic] | Structure it: acknowledge the concern in writing, gather the facts, involve the team as needed, then meet with a clear next step. | A live judgment problem. The principal wants process, not a story. |
| B3 | "A fourth-grade colleague disagrees with your reading plan. Walk us through what you do." | CASE | [generic] | Structure it: listen first, look at the evidence together, agree on a trial, and decide in writing. | A live problem on the team's core work. |
| B4 | "What is your first 90 days in this role?" | JD | [generic] | Structure it by phase: learn the team's routines, learn the fourth-grade standards, then contribute. Name one concrete thing you would do first. | Tests whether you have a plan for the gap in F2 and F3. |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| **C1** | "You've never taught fourth grade. Why would we take that risk?" | JD | [grounded] "I've never taught fourth grade" — your message; [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | **Hold, then concede.** Start with "I haven't taught fourth grade." Hold the adjacency: six years with the same age group one grade earlier. Follow-up 1 ("third grade is a different job"): agree that it is different, and name the specific part that carries over. Follow-up 2: concede the specific thing you would need to learn, and say how you would learn it. Answer slot: if you have worked with fourth-grade materials, say how. If you have not, say so. | **Highest-return prep in this pack.** This objection is the most likely to be asked in some form. F2 is the thinnest part of the material, so do not thicken it: the honest answer is the negative, the adjacency, and a concrete plan. |
| C2 | "How would you measure the reading club's impact?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say what you did in the club. Answer slot: if you measured anything, say what and how. If you did not measure impact, say so, and say what you would measure first. | F4. "Impact" presumes a measurement that may not exist. The honest answer is the club, then what you did or did not track. |
| C3 | "Who decided the reading curriculum change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say who made the decision and what your part was. Answer slot: if you chose the curriculum, say how you decided. If the decision was made above you, say that and describe what you did. | Probes the word "led" against the prohibited claim that you designed or chose the curriculum. |
| C4 | "You've never been a team lead. Why would the team accept you as their lead?" | JD | [grounded] "I've never been a team lead" — your message; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | **Hold, then concede.** Start with "I haven't been a team lead." Hold the change you led in 2024 as leadership of a change, not of a team. Concede the specific part of team leadership you have not done, and say how you would earn the team's trust. | F3. Do not describe the 2024 move as team leadership. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| Illinois PEL with elementary endorsement (invite) | none, and why | Gate shown met on your CV (F1). No probe expected beyond confirmation. |
| Fourth-grade experience (job title) | A3, B4, C1 | F2 |
| Grade-team leadership (panel composition) | C4, B3 | F3 |
| Reading instruction (role family) | A1, A4, C2, C3 | F4 |
| Family communication (role family) | A5 | F5 |

## Reverse questions

1. "What does a strong first year look like for someone joining the fourth-grade team?" *Why it lands:* signals you are planning for the job, not just for the interview.
2. "How does the team plan the reading block together?" *Why it lands:* shows you want to know the working routine before you arrive.
3. "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* a reciprocity question for the peers, asked as a peer would ask it.
4. "How does the school support teachers new to a grade level?" *Why it lands:* addresses the grade-level gap directly, through the principal's own responsibility.
5. "What do you hope the new hire brings that the team doesn't have yet?" *Why it lands:* turns the gap into a conversation about what you add.

## Sources

- Provided documents: your invite (Halvering Elementary interview, Fourth Grade Teacher), your CV summary, and your message about your experience.
- Research tier: **L0**. No searches or page fetches were run.
- Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering / Orrinsford values | unavailable | Values cheat sheet. Not run. |
| 2. Interview process for the role | unavailable | Loop structure and persona weights. Not run. |
| 3. Recent district strategy and news | unavailable | CO bank. Not run. |
| 4. Interviewer footprint (Dolores Vantongeren) | unavailable | Interviewer read and tailored reverse questions. Not run. |
| 5. Representative job posting for the title | unavailable | JD-tagged questions and [inferred] rows. Not run. |

## Upgrade menu

- The job posting text → rows F2 through F5 become [grounded], and JD questions are added for each stated requirement.
- The interviewer's public footprint (Dolores Vantongeren) → a tailored reverse question and persona weights based on her public record.
- A web check on the school and district values and reading program → a values cheat sheet and a strategy-grounded CO bank.
- Any announced teaching demo or sample lesson → a graded-deliverable build section.
