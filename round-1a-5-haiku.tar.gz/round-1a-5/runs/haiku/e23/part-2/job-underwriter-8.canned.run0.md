## Decision snapshot

**Decision: `no_go`.** Do not send anything to this employer. The job may be real, but the process is a known scam pattern, and no fit to the role changes that.

- **Fit:** strong on the posting's stated skills.
- **Hard gates:** pay floor at risk. The posting gives €26/hour plus unquantified commission and no salary. At 15–30 hours a week, base pay is about €20,300–€40,600 a year (`[grounded]`, arithmetic from the posting). Your €30,000 floor needs about 22+ hours every week, before commission.
- **Opportunity:** the payment and document requests are disqualifying on their own.

## Role reality

- **Stated:** remote order processing, 15–30 hours a week, €26/hour plus commission, training provided, Telegram-only hiring.
- **Market calibration:** not run. Research is at L0, so this stays unverified.
- **Contradictions:** "no experience needed" sits beside "confident with spreadsheets" and "good written English." That is ordinary for entry roles, so it is not a red flag on its own. The posting also withholds a fixed salary.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | Attention to detail | strong | high | none | Parcel courier, about 60 Zendesk tickets a day |
| 2 | must | Spreadsheets | strong | high | none | Maintains the team's weekly tracker in Excel |
| 3 | must | Good written English | likely | medium | discovery | Written CV; not tested |
| 4 | must | Quiet place to work | unknown | — | discovery | Not in your background; minor |
| 5 | preferred | Order or parcel processing | adjacent | medium | transferability | Parcel courier support |
| 6 | preferred | Training others | strong | high | none | Trained two new starters |

## Gap recovery queue

No material gaps. Your fit is not what is in question. Row 4 is the only open item, and it is minor.

## Opportunity risk register

| Class | Severity | Risk |
|---|---|---|
| Financial fraud | critical | You are asked to pay €349 by bank transfer to a third party for "equipment," refunded later. Upfront payments to an employer are a classic scam. |
| Overpayment scam / money mule | critical | You are told to deposit a €2,850 cheque, keep €350, and transfer the rest to "equipment partner." Cheques often bounce after the money is sent. You could also be drawn into moving criminal proceeds, which carries legal liability. |
| Identity theft | critical | Before any verified contact you are asked for your IBAN, PPS number and passport photo. A legitimate employer does not need these before an interview or offer. |
| Process | high | Telegram-only, no calls or video, and a "chat interview." Legitimate employers can be reached by phone and email at a company domain. |
| Failed attribution | high | The contact email domain (postmail.example) is not a company domain. Velloway Logistics is not verified. Research has not run. This is a standing entry and constrains the decision. |
| Pay mismatch | medium | Hourly rate with no salary and unquantified commission against a €30,000 floor. |

## Application plan

1. **Stop here.** Do not reply to @VellowayHiring, and do not paste your IBAN, PPS number or passport anywhere in this chat.
2. **Do not deposit any cheque, and do not transfer any money** to "equipment partners" or anyone else.
3. **Report it:** the Telegram account to Telegram, the listing to the jobs site, and the scam to the Gardaí (online at garda.ie or at your local station).
4. **If you want this kind of role,** find it on the employer's own careers page, reached by a search you run yourself. Ask for a written contract with a stated salary. Treat any request to pay for equipment as a warning sign.
5. **If you have already sent any documents or money,** contact your bank now, ask about identity protection and fraud handling, and keep the chat logs.

## Evidence status

**Research tier: L0 — no searches**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 tier, no research consent |
| 2. Role-family sweep | skipped | L0 tier, no research consent |
| 3. Hiring manager footprint | n/a | No name given |

## Dossier offer

I can write this assessment and the evidence map to a `tuesday-dossier.md` file if you want to keep it.

## Upgrade menu

- **Limited research (L1; up to 5 searches and 2 page fetches):** would check whether Velloway Logistics is a registered company and whether it has a live posting on its own domain. It would confirm or refine the verdict, but no finding would make the payment and document requests acceptable.
- **A live posting link from the company's own site:** would resolve the attribution entry.

## Questions

1. Have you sent anything yet, such as a document, bank details or money, to @VellowayHiring or anyone they named?
2. Do you want the L1 check (up to 5 searches and 2 page fetches) to confirm whether the company exists? Reply yes or skip, and I'll answer with the updated analysis.

Reply to each question by number, or type "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.