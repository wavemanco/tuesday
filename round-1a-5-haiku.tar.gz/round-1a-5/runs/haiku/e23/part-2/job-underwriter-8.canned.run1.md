**Decision: no_go. Do not send anything else to @VellowayHiring.** This matches the advance-fee and fake-cheque pattern, and the details you'd be asked to send are the ones fraudsters use.

**Decision snapshot**
- Decision: `no_go` (role and process; your fit is separate)
- Hard gates: pay terms fail your floor. The stated rate covers your €30,000 target only at about 22 hours a week, every week, before tax. Commission is unquantified. [grounded]
- Fit (your side): strong on the stated requirements. Zendesk volume, spreadsheet tracking, and training starters all map directly. Written English and a quiet workspace are unverified. [grounded]

**Why it's a scam, not just a bad offer**
- **Personal data before any interview:** IBAN, PPS number and passport photo, requested before the "chat interview." [grounded]
- **Upfront payment:** €349 to an "equipment partner" for a "refund with first wages." Legitimate employers supply equipment. [inferred]
- **Fake cheque:** they send you €2,850, you deposit it, keep €350, and forward the rest to "their partner." Cheques can bounce after you've sent the money, and you're liable for the transfer. [inferred]
- **Money-mule structure:** the role is moving money for them, which can make you a party to fraud. [inferred]
- **Process:** Telegram only, no calls, a job offer in a single chat, and an HR contact at a generic mail domain rather than a company domain. [inferred]

I didn't run web searches on Velloway Logistics in this pass, so I can't confirm the company doesn't exist. The fraud pattern holds regardless.

**What to do now**
1. Don't paste your IBAN, PPS number or passport anywhere in this conversation or in Telegram. Keep your IBAN out of any reply to them.
2. Don't pay the €349 and don't deposit or forward any cheque.
3. If you've already shared your IBAN, PPS number or passport, contact your bank's fraud line today, ask about monitoring your account, and report the PPS/passport exposure to the Department of Social Protection or Revenue.
4. Report the Telegram account and the posting to the jobs site, and to the Gardaí (Garda National Economic Crime Bureau).

**Upgrade menu**
- A live link to the posting on the jobs site, and the company's own careers page, would let me check whether Velloway exists. It won't change the decision.
- If you want, I can search for legitimate remote coordinator or customer-operations roles that fit your Zendesk and tracker experience, and vet those instead.

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file to keep with your job search.

**Questions**
1. Have you sent them anything yet, including the IBAN, PPS number, passport photo, or any money?
2. Have you received a cheque or any bank details from them yet?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.