**Decision snapshot: no_go.** Do not send anything to @VellowayHiring. Stop the conversation now.

- **Opportunity ledger:** this is a scam pattern, not a risky job. Every signal below comes from the posting and the messages you pasted, so it does not depend on research.
- **Candidate-fit ledger:** separate, and reasonable on its own terms. You have the core skills for this kind of role.
- **Hard gates:** one failed. The €30,000 floor is not met at the posted terms [grounded]. The posting says "up to €26/hour" for 15–30 hours a week, which is about €20,300 to €40,600 a year before commission. Reaching €30,000 at the top rate needs about 22 hours a week, and commission is unquantified.
- **Confidence:** high that this is fraudulent. The red flags are unambiguous, and nothing you have shown me suggests the employer is real.

**Role reality**
- Title and duties are generic back-office order processing. Nothing in the posting names a company registration, address, or real staff member.
- The hiring process is Telegram-only, with no call or video step, and the "interview" happens in chat.
- The pay is an hourly figure with an open-ended commission, and it is stated as "up to". That is the posting's own figure [grounded].
- The one contact address given, velloway.hr@postmail.example, is on a generic mail domain, not a company domain.

**Evidence map** (requirements only; the scam elements belong in the risk register)

| # | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|
| 1 | Attention to detail | Strong | Medium | none | Tracker upkeep; 60 tickets/day in Zendesk (self-reported, not verified) |
| 2 | Spreadsheets | Strong | Medium | none | Keeps the team's weekly Excel tracker (self-reported) |
| 3 | Written English | Strong | Medium | none | Customer-service and ticket work implies this (inferred) |
| 4 | Quiet workspace | Unknown | — | unverified | Not in your background; you would confirm it yourself |
| 5 | Pay ≥ €30,000/yr | Gap | High | hard gate | Posted terms reach €30k only at about 22 h/week with no commission [inferred from posting] |

**Opportunity risk register**

| Class | Severity | Signal |
|---|---|---|
| Advance-fee | Critical | €349 "equipment" payment to a third party before any wages |
| Overpayment / mule | Critical | €2,850 cheque to lodge, keep €350, forward €2,500 to an "equipment partner" (classic fake-cheque fraud: the cheque bounces after the money has gone out) |
| Identity harvest | Critical | IBAN, PPS number and passport photo requested before any interview |
| Process | High | Telegram-only; "passed screening" within minutes; job offered after one chat |
| Identity of employer | High | No verifiable company details; generic mail domain |

**Gap recovery queue**
- *Quiet workspace* closes only by your own judgement, and is irrelevant to whether this is safe.
- *Pay floor* cannot be closed by this posting. Only a written, confirmed contract with a fixed salary would change it.

**Application plan:** none. Do not apply through this channel. If you are looking for work like this, use a listing with a named employer you can check, and never pay an employer or forward money from a cheque.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Research not yet consented; the risk findings above do not depend on it |
| 2. Role-family pay sweep | skipped | Same reason |
| 3. Hiring manager footprint | n/a | No name was given |

Research tier: L0 — no searches

**Safety steps, if you have already sent anything**
- If you sent your PPS number, passport photo or bank details, contact your bank now. Ask them to flag the account and watch for unusual transfers. Consider a new account.
- If a cheque was deposited or any money was sent, report it to your bank immediately.
- Report the scam to the Gardaí and, where possible, to Telegram. Keep screenshots of the chat, the messages and the email address.
- Do not paste your IBAN, PPS number or passport into anything else.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md`, so any later job evaluation can reuse it. Say the word if you would like that.

**Upgrade menu**
- **L1 research** (up to 5 searches and 2 page fetches): I can check whether Velloway Logistics is a registered company and whether it has a real web presence. That would sharpen the employer-identity finding, though the existing findings already stand without it.
- **A link to the advertisement** on the jobs site, so I can check whether the same text appears elsewhere.

**Questions** (response mode: answer in prose, or skip any of them)
1. Have you already sent anything to @VellowayHiring, such as your PPS number, a passport photo, your bank details, or any money?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.