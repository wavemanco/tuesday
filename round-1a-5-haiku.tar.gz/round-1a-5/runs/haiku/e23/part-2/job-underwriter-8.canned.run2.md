**Don't go ahead. This is a job scam, and the cheque part is the most dangerous step.** Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit or transfer anything from that cheque.

I checked this against the posting and messages only, since I had no way to look up the company, so the verdict rests on what you've shared.

**Why it's a scam:**
- **Hiring only on Telegram, with no calls or video.** Legitimate employers almost always use email and a company domain, and interview on video.
- **Sensitive details before any real interview.** Asking for IBAN, PPS and a passport photo before a "chat interview" is identity theft in progress. Real payroll asks for these only after a signed contract, through a proper onboarding process.
- **Paying for your own equipment, refunded later.** Employers don't ask staff to buy their laptop.
- **The cheque.** They send you a cheque for more than the job pays, ask you to keep part and send the rest to a "partner." Cheques can show as cleared within days but bounce weeks later. When it does, the bank takes back the full amount from you, and any money you've already sent is gone. This is how people get drawn into money-laundering, too.
- **Vague pay with no experience needed**, plus "passed the interview" with no interview having taken place.

**What to do now:**
1. Stop replying to @VellowayHiring and don't send anything else.
2. If you've already sent any details, contact your bank today, tell them you may have been scammed, and ask them to add fraud monitoring or change your account details.
3. Report it to the Gardaí (garda.ie, or your local station), and report the Telegram account to Telegram.
4. Report the listing to the jobs site so others aren't caught.

**For the job search:** your background (Zendesk at volume, training new starters, keeping a team tracker in Excel) fits real remote customer-support and operations roles well. Look for them on the employer's own careers page, which you reach directly, not through a link in a message. I can help you check any specific listing before you reply to it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.