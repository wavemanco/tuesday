**Decision: no-go. This is a scam. Don't send anything, and don't paste your IBAN.**

I worked from the posting and messages only. I did no outside research, so I couldn't check whether Velloway Logistics exists.

**Why**

- **The cheque plan is the main danger.** You'd deposit a €2,850 cheque, keep €350, and transfer €2,500 to a "partner." Cheques often show as cleared before they're actually verified, and when a bounced cheque is reversed, the money you sent is gone. The fraudster keeps the money, and you're left owing your bank. Being asked to move money from a deposit to a third party is the classic money-mule setup.
- **You're asked to pay for the job.** The €349 "equipment" fee, to be refunded "with your first wages," is an advance fee. Legitimate employers supply their own equipment.
- **Your personal data is requested before any real interview.** IBAN, PPS number and passport photo, before a "chat interview," is identity-theft collection.
- **The pay is vague.** "Up to €26 an hour plus commission on every order you process" is hard to verify and a common lure.
- **Hiring runs only on Telegram, with no calls or video, and the contact uses a generic email domain** (`postmail.example`), not a company domain.

**The numbers don't meet your floor either.** At €26/hour with no commission, you'd reach €30,000 only at about 22–23 paid hours a week, every week, and the posting gives no salary figure. Your background (customer service, Zendesk, training new starters, Excel trackers) does fit this kind of role, so apply to Velloway's name only through a site or company page you've found independently, and only if they can show a real company.

**Do now**

- Don't send the IBAN, PPS number, passport photo, or the €349. Don't deposit any cheque.
- Block the account and report it on Telegram.
- If you've already sent your IBAN, PPS or passport: contact your bank to flag the account and watch for unusual activity. Report it to the Gardaí (garda.ie or your local station). Consider notifying the Department of Social Protection about your PPS number.
- If you've already sent money or received a cheque, tell your bank immediately.

Did you send anything yet, or have you only received the messages?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.