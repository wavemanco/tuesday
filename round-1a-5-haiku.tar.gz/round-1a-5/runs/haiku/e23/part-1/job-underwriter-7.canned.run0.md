**Yes, it's worth applying for: `conditional_go`.** On your CV you meet every essential requirement, and the open points are one structural gap (holding your own caseload), one desirable skill you lack (Doppler), and details the posting doesn't give. Nothing here fails a hard gate. The employer is unverified because I haven't run any searches yet.

**Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given, so checks against your own non-negotiables (pay floor, schedule, contract type) are unknown.

**Severe red flags:** none found.

**Fit ledger**

- **hard_gate:** direct R1 (NMC Adult registration), R2 (full UK licence), R3 (Halifax base)
- **must_have:** direct R4 (post-registration experience), R6a (pressure and surgical wounds), R7a (catheter care), R8a (insulin); adjacent R5 (holding a caseload), R6b (leg ulcers), R8b (care planning); unclear R7b (continence), R9 (end-of-life visits), R10 (written and electronic records)
- **preferred:** absent R11 (Doppler assessment, desirable)

The must-haves that are unclear are mostly silence on your CV rather than gaps. The caseload is the one real gap. Your discharge-to-assess visits were close to the job's home-based work, but you never owned a caseload.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax; district nursing for housebound adults | `[grounded]` JD |
| Mandate | Own a small caseload of housebound patients; wound, catheter, continence, insulin and end-of-life care at home | `[grounded]` JD |
| Support | A senior community nurse supports the caseload | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Scope read | Autonomous caseload work with supervision. Normal for a Band 5 community post | `[inferred]` from the JD's listed duties |
| Market calibration | Not established. No searches run, so no role-family pay or scope comparison | — |
| Unknowns | Starting caseload size, on-call and lone-working arrangements, Doppler training, the EPR system, the contract basis | — |
| Contradictions | None within the JD | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | high | none | PIN and active status stated | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Full UK category B stated | `[grounded]` CV | none |
| R3 | Based in Halifax | hard_gate | direct | high | none | You live in Halifax; the post is in Halifax | `[grounded]` CV, JD | none |
| R4 | At least one year post-registration | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5 | Holding a caseload of housebound adults | must_have | adjacent | medium | transferability | Your home visits were patient-specific and time-limited, not an ongoing caseload you owned | `[inferred]` from the discharge-to-assess role | gap queue G1 |
| R6a | Wound care, pressure and surgical | must_have | direct | high | none | Stated directly | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care is stated, but not leg ulcers specifically | `[inferred]` | gap queue G2 |
| R7a | Catheter care | must_have | direct | high | none | Stated directly | `[grounded]` CV | none |
| R7b | Continence care | must_have | unclear | low | discovery | Not in the CV | `[grounded]` silence | question Q1 is not this; carried as minor risk |
| R8a | Insulin administration | must_have | direct | high | none | Stated directly | `[grounded]` CV | none |
| R8b | Care planning | must_have | adjacent | medium | transferability | Discharge planning is close, but the CV doesn't say you planned ongoing care | `[inferred]` | gap queue G3 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not in the CV; ward experience may include it | `[grounded]` silence | gap queue G4 |
| R10 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | Not in the CV | `[grounded]` silence | gap queue G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not in the CV | `[grounded]` silence | gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload ownership (R5) | transferability | Patient-specific home visits in the first week after discharge | The post's core structure is a caseload you hold over time | Any time you planned follow-up or managed a patient's ongoing needs | A description of a typical week in the discharge-to-assess role | `[inferred]` |
| G2 | Leg ulcers and Doppler (R6b, R11) | transferability, then capability | Wound care is strong; leg ulcers and Doppler aren't in the CV | Desirable, and it shapes the first months | Any venous or vascular wound work | Training record or plan for Doppler | `[generic]` that Doppler training is often post-specific |
| G3 | Care planning (R8b) | transferability | Discharge planning | Ongoing care planning sits on the caseload | Discharge plans you wrote | An example care plan (anonymised) | `[inferred]` |
| G4 | End-of-life visits (R9) | discovery | Not stated | Core to the duties | Ward palliative care | A line on ward palliative care | `[grounded]` silence |
| G5 | Records on an EPR (R10) | discovery | Not stated | Explicitly required | Any EPR use | Name of the EPR you've used | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer existence and live posting unverified | unknown | medium | "Calderbrook Community Health CIC, Halifax" | The posting may be stale or the employer may not be as described | `[inferred]`: no searches run | Can you confirm this post is live and give me the CIC's registered details? | unresolved |
| RR2 | Caseload size and support unstated | unknown | medium | "hold a small caseload, supported by a senior community nurse" | A first caseload may be large, or support may be thin | `[grounded]` JD silence on numbers | What is a starting caseload, and how is a new post-holder supported in the first months? | unresolved |
| RR3 | On-call and lone working unstated | unknown | low | "visiting patients at home" | Lone working and out-of-hours cover may be heavy | `[inferred]` from home-based work | Is there on-call or out-of-hours cover, and how is lone working managed on home visits? | unresolved |
| RR4 | Doppler training unstated | unknown | low | "Desirable: Doppler assessment" | You may be expected to learn it on the job or be unsupported | `[grounded]` JD | Is Doppler training provided, and what's expected before a post-holder is trained? | unresolved |
| RR5 | Pay band stated; no market check | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent; whether it's fair is unchecked | `[grounded]` JD | (none needed; the figure is stated) | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting and employer details before investing effort | see RR1 | `[grounded]` RR1 | pending your go-ahead |
| A2 | Use the informal chat with Rhiannon Mabbott to ask the RR2–RR4 questions | The chat is offered in the JD | `[grounded]` JD | ready |
| E1 | Describe the discharge-to-assess role as home-based wound, catheter and insulin care in patients' homes, without calling it caseload work | Accurate; keeps the caseload gap honest | `[grounded]` CV | pending your approval |

Nothing above is written for you to send. Any CV or cover-letter wording needs your approval first.

## Evidence status

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would have confirmed the CIC exists and the posting is live (RR1) |
| 2. Role-family sweep | skipped | Would have set pay and scope against norms (market calibration row) |
| 3. Hiring manager's public footprint | n/a | No hiring manager named; the chat contact is a team lead |

Dossier offer: if you'd like, I can write this up as a `tuesday-dossier.md` file for later use.

**Upgrade menu**

- A link to the live posting, or the CIC's careers page, would confirm RR1 and let the employer check run.
- Research at L1 (up to 5 searches and 2 page fetches) would check the employer's existence, the role's pay against norms, and the posting's status.
- Your own answer to a question on caseload size or Doppler would move R5 or R11.
- An anonymised example care plan would raise R8b from `adjacent` toward `direct`.

**Questions**

1. (RR2, R5) What's a typical starting caseload size, and how is a new post-holder supported in the first months? Say "skip" if you'd rather not answer.
2. (RR4, R11) Is Doppler training provided, and what's expected before someone is trained?
3. (RR3) Is there on-call or out-of-hours cover, and how is lone working managed on home visits?

Reply in prose; answer any of them or skip them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.