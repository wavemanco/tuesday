**Status: `conditional_go`.** Worth applying, provided the posting checks out. Your essentials are met on the CV, and the one thing you have never done (holding your own caseload) is named in the advert as part of the role, so it will come up in interview. The employer exists, but I could not confirm that this specific post is live.

**Fit ledger**
- `hard_gate` — direct: R1, R2 · 
- `must_have` — direct: R3, R5a, R6a, R7 · adjacent: R5b · unclear: R4, R6b
- `important` — absent: R8 · adjacent: R9 · unclear: R10, R11
- `preferred` — absent: R12

R5b (leg-ulcer care, `adjacent`) is the bridge to name honestly. R8 (`absent`) is the largest gap and needs a discovery answer before anything else.

**Opportunity ledger.** The employer is real and stable: a CIC with an NHS contract, 410 staff and four locality hubs (RR3 is the positive pay signal). The posting is unverified (RR1), and the caseload size and support arrangements are unstated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live (RR1); (2) caseload size and clinical support are described concretely (RR2); (3) leg-ulcer work is framed as adjacent, not as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` calderbrookhealth.example/about |
| Role | District nursing caseload in patients' homes; wound, catheter, insulin, end-of-life and care-planning work on the EPR | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Median basic pay for a Band 5 community staff nurse is £34,300 (IQR £32,400–£36,600). The posted range sits around that median. 61% of respondents were paid mileage | `[generic]` Wardround 2026 UK Community Nursing Pay Guide, n=1,240 |
| Contradictions | The advert says the post is live, but the careers page at the address I tried does not exist, and a search for the posting returned nothing | `[grounded]` fetch and search results |
| Unknowns | Caseload size, on-call expectations, Doppler training provision, EPR training | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | high | none | Stated on the CV, registration active; revalidation due March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B, full | `[grounded]` CV | none |
| R3 | At least one year post-registration experience | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Not evidenced on the CV; the discharge role implies documentation but does not show its quality | `[inferred]` | Q2 |
| R5a | Wound care | must_have | direct | high | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound work carries over; leg-ulcer management is not on the CV. Limit: no leg-ulcer experience stated | `[inferred]` from R5a | G1 |
| R6a | Catheter care | must_have | direct | high | none | Stated on the CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Q2 |
| R7 | Insulin administration | must_have | direct | high | none | Stated on the CV | `[grounded]` CV | none |
| R8 | Holding a small caseload of your own | important | absent | none | discovery | Never held a caseload. Discharge-to-assess home visits are the closest bridge, but they were not caseload-holding | `[grounded]` CV | G2 |
| R9 | Care planning | important | adjacent | medium | transferability | Discharge planning for patients in their first week at home. Limit: not ongoing care planning for a caseload | `[inferred]` | G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Q2 |
| R11 | Electronic patient record | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Q2 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path: training, if the employer provides it | `[grounded]` CV | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | transferability | Pressure ulcers and surgical wounds, with no leg-ulcer work stated | A must-have at `adjacent`. Confirming leg-ulcer exposure would move it to `direct` | Any leg ulcers managed in the acute ward or in the discharge team | Ward or team wound-care audit, or a training record | `[inferred]` |
| G2 | Own caseload (R8, important) | discovery | No caseload-holding experience. The first-week home visits are the bridge | The advert names this as core to the role | Discharge follow-up plans you owned; patients you saw repeatedly across weeks | A discharge-team caseload summary, or a visit log | `[grounded]` CV |
| G3 | Doppler (R12, preferred) | capability | No evidence | Preferred only, so a risk rather than a blocker | Any vascular assessment, ABPI or similar training | A training certificate or an employer statement that it is provided in post | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed as live | risk_signal | low | "Current vacancies are listed on our careers page." | The advert may be stale, or the careers page may sit at another address. The employer itself is established | `[grounded]` my fetch of the careers address returned no page; search returned no posting | Is this post open, and where is it advertised? | unresolved |
| RR2 | Caseload size and support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" may mean different things in practice, and on-call duties are not stated | `[inferred]` from the advert's silence on numbers | How many patients would I hold at the start, and how is clinical support given day to day? | unresolved |
| RR3 | Pay range posted, with mileage | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent and sits around the market median | `[grounded]` advert; median `[generic]` Wardround 2026 | Where on the band would someone with five years' experience start? | noted |
| RR4 | Doppler training provision | unknown | — | "Desirable: Doppler assessment for leg ulcers." | Training may be provided in post, which would close G3 | `[inferred]` from the advert listing it as desirable | Is Doppler training provided for staff who do not yet hold it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting and any closing date before writing the application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Frame discharge-to-assess home visits as community-setting experience, with the limit stated: not a caseload you held | see R8, R9 | `[inferred]` R8/R9 | pending your approval |
| A3 | Describe wound care as pressure ulcers and surgical wounds. Do not claim leg-ulcer experience | see R5b | `[grounded]` CV | pending your approval |
| A4 | Book the informal chat with Rhiannon Mabbott and ask RR2 and RR4 verbatim | The chat is the cheapest way to check the caseload | `[grounded]` advert | pending your approval |

Nothing above has been sent or written anywhere. Each row needs your approval before it becomes application text.

## Evidence status

Verified: none yet. Everything on the CV is still your statement and has not been confirmed through a confirmation card.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned calderbrookhealth.example/about (fetched, confirmed the employer). Searched "Calderbrook Community Health Community Staff Nurse Band 5 Halifax job", which returned nothing. Fetched calderbrookhealth.example/careers, which returned no page. Result: employer confirmed, posting not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 NHS Agenda for Change", which returned Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | skipped | A name was given (Rhiannon Mabbott, a team lead and your named contact). I did not search for an individual's footprint, since the skill's people research is limited to public professional footprint and I had no confirmed reason to spend budget on it here. Can run on request |

## Upgrade menu

- A live posting link or a closing date → RR1 closes, and the employer-side claim is complete.
- The Rhiannon Mabbott chat, or written answers to RR2 and RR4 → caseload and Doppler rows resolve, which could move this to `go`.
- A training record or any leg-ulcer exposure → R5b moves toward `direct`.
- A deeper research pass on Calderbrook (regulator reports, CQC ratings, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

I can't create a dossier file for this run, but I can produce a `tuesday-dossier.md` if you want one to carry into other roles.

1. Q1 (RR1): Do you have the live posting link, or a closing date for the advert?
2. Q2 (R4, R10, R11): Have you ever done end-of-life visits, or documented on an electronic patient record in the discharge team? If so, what did it involve?
3. Q3 (R12): Do you have any vascular assessment training, such as ABPI, or any Doppler experience?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.