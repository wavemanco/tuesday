**Yes, it's worth applying, on conditions. Status: `conditional_go`.** You meet both essential registration and licence requirements and at least a year's post-registration experience. The gaps are your first own caseload, leg-ulcer work and Doppler, and the posting does not say how the records and end-of-life parts of the role would be handled.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R4, R6a, R7 · adjacent: R5, R10 · unclear: R6b, R8, R9, R11
- `preferred` — absent: R12

R5 (leg-ulcer care) and R10 (holding a caseload) are credible bridges with their limits named; R8, R9 and R11 are unclear until you answer the questions below.

**Opportunity ledger.** The employer checks out as described, and the posted pay sits across the middle of the market band; the posting also names support from a senior nurse (RR1, RR2). The open items are caseload size and how the senior support works (RR3), whether Doppler training is provided (RR5), and whether the post is live on the careers page, which I have not checked (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the records requirement (R11) is confirmed; (2) the leg-ulcer bridge (R5) is presented as adjacent, never as leg-ulcer expertise; (3) Doppler training is confirmed as available (R12).

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing and therapy under an NHS contract, Calderdale, 410 staff, four locality hubs | `[grounded]` official About page |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence, end-of-life visits, insulin, care planning, all on the EPR | `[grounded]` JD |
| Scope | A small caseload of your own with senior community nurse support; "small" is not quantified | `[grounded]` JD; `[inferred]` that the size is unknown |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Band 5 community staff nurse, England, 2026 survey (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% paid mileage. The posted range covers that interquartile range | `[generic]` Wardround 2026 pay guide |
| Unknowns | Caseload size; continence and end-of-life responsibilities; EPR expectations; Doppler provision; whether the post is live | — |
| Contradictions | None found between the JD and the About page. Halifax sits within Calderdale | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Your CV states active registration, revalidation March 2028. Self-reported, but checkable on the register | `[grounded]` CV | Check the live NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B, per your CV | `[grounded]` CV | none |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Wound care (pressure ulcers, surgical wounds) | must_have | direct | medium | none | Named in your CV | `[grounded]` CV | none |
| R5 | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure and surgical wound care carries over. Limit: no leg-ulcer assessment or management in your CV | `[inferred]` adjacency from R4 | Bridge case; see G1 |
| R6a | Catheter care | must_have | direct | medium | none | Named in your CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not in your CV | `[grounded]` CV silence | Question Q2 |
| R7 | Insulin administration | must_have | direct | medium | none | Named in your CV | `[grounded]` CV | none |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not in your CV | `[grounded]` CV silence | Question Q2 |
| R9 | Care planning for a caseload | must_have | unclear | low | discovery | Your discharge visits imply assessment work, but planning is not stated | `[inferred]` from discharge work | Question Q2 |
| R10 | Holding a small caseload of your own | must_have | adjacent | medium | transferability | Your home visits in the first week after discharge carry over. Limit: you have never owned a caseload, its prioritisation or its accountability | `[inferred]` adjacency from your home-visit work | Bridge case; see G3 |
| R11 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | Your CV does not mention records or the EPR | `[grounded]` CV silence | Question Q1 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler experience. Closure path below | `[grounded]` CV | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5) | transferability | Wound care is strong; leg ulcers are not claimed | A must-have on the JD; the bridge needs to be stated with its limit | Asking how the team splits leg-ulcer work; any leg-ulcer dressing or review you have done under supervision | `[inferred]` |
| G2 | Continence, end-of-life, care planning (R6b, R8, R9) | discovery | None of these appear in your CV | Each is a must-have; their answers could move the status | Answer Q2 | `[grounded]` CV silence |
| G3 | Own caseload (R10) | transferability | Home-visit work carries over; ownership does not | The most likely interview probe | Describe how you planned your visits and priorities in the discharge team | `[inferred]` |
| G4 | Records on an EPR (R11) | discovery | Not in your CV | Essential in the JD | Answer Q1 | `[grounded]` CV silence |
| G5 | Doppler (R12) | capability | No experience | Preferred; a closure path exists | Ask whether training is provided for new staff | `[grounded]` employer's public talk, which does not confirm this role's offer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer verifiable and consistent with the posting | positive_signal | — | "a community interest company running adult community nursing" | The posting describes a real employer with a defined service | `[grounded]` About page | Who will I be working alongside day to day? | noted |
| RR2 | Pay published and within market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The offer is in the expected range | `[generic]` band; `[grounded]` posted range | Is mileage paid at the standard rate? | noted |
| RR3 | Caseload size unstated | unknown | — | "a small caseload of your own" | Size may be large for a new caseload holder | `[generic]` that community caseloads vary widely | What is a typical caseload, and how is the senior nurse's support structured? | unresolved |
| RR4 | First own caseload with new-role support | risk_signal | low | "supported by a senior community nurse" | Support may be informal, with autonomy expected early | `[inferred]` from "supported by" against "never held my own caseload" | How often will I be supervised in the first three months? | unresolved |
| RR5 | Doppler training provision unstated | unknown | — | "Doppler assessment for leg ulcers" (desirable) | Training may be offered, given the team's public focus | `[inferred]` from a public talk by the team lead on Doppler training for new staff | Is Doppler training provided for staff without prior experience, and when? | unresolved |
| RR6 | Post liveness not checked | unknown | — | Posting as provided | The post may be filled or stale | — | Can you confirm the advert on the careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check your NMC register entry and revalidation date | see R1 | `[grounded]` CV | for you |
| P2 | Use the informal chat with Rhiannon Mabbott to ask about caseload size, supervision, Doppler and the leg-ulcer split | see RR3, RR4, RR5, R5 | `[grounded]` JD contact; `[inferred]` the questions' relevance from her public talk | for you |
| P3 | CV wording: state the 18-month home-visit work in outcome terms, with wound, catheter and insulin care as written. Add no leg-ulcer or caseload claim | see R4, R10 | `[grounded]` CV | pending your approval |
| P4 | Lead interview answers with wound care depth, insulin and home visiting; present leg ulcers as adjacent and the caseload as ready to learn, not experienced | see R5, R10 | `[grounded]` CV | for you |

## Evidence status

Verified: none yet. Your CV claims are self-reported leads; R1 and R2 can be verified against the NMC register and your licence. Unverified leads: none. Rejected inferences: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; the About page at calderbrookhealth.example/about confirms the employer. I did not fetch the careers page, so the post is not verified live (RR6) |
| 2. Role-family sweep | yes | Searched "Band 5 staff nurse community district nursing salary 2026/27 NHS Agenda for Change"; the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide) gives the `[generic]` band |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead"; her speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) confirms the role and her public focus on leg-ulcer clinics and Doppler training. Public professional footprint only |

## Upgrade menu

- A link to the careers-page posting, or a fetch of it → RR6 closes, and the post's liveness is verified.
- Your NMC register screenshot or confirmation → R1 moves to `high`.
- Answers to Q1 and Q2 → R6b, R8, R9 and R11 each resolve toward `direct` or `absent`.
- A deeper research pass on Calderbrook Community Health (leadership changes, staff reports, past recruitment patterns; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R11 — Have you written clinical records directly on an electronic patient record in your current role, and how did you keep entries timely?

R8, R9 — In your discharge-to-assess visits, did you plan ongoing care for patients, visit anyone at end of life, or assess continence?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you want, I can save this assessment as `tuesday-dossier.md`, a file you can carry into interview preparation later.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.