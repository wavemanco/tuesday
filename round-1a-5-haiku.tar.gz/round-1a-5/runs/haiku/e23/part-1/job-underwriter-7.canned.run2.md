The web tools are loaded, so I'll run the L1 research targets now: the employer's footprint, and the Band 5 community nursing pay norm. Neither query includes your personal details.
**Yes, apply.** Status: `go`. You meet every essential requirement on the evidence you've given me, and the role has no red flags. The main thing to prepare for is that you have never held a caseload.

**Fit ledger.**

- `hard_gate`, direct: R1 (NMC Adult registration), R2 (full UK driving licence)
- `must_have`, direct: R3 (one year's post-registration experience), R4 (insulin administration), R5 (catheter care), R6a (pressure and surgical wound care); adjacent: R6b (leg-ulcer care), R7 (care planning); unclear: R8 (clear, timely written records)
- `important`, unclear: R9 (own caseload), R10 (end-of-life visits), R11 (electronic patient record)
- `preferred`, absent: R12 (Doppler assessment)

R9 is the one to take seriously. Your discharge-to-assess visits are the closest thing you have to running your own patients, and it's a transferable bridge, not caseload experience.

**Hard gates:** none failed; R1 and R2 are `direct` on your word, and the NMC PIN is worth checking on the public register before you apply.

**Opportunity ledger.** Sound. The employer is a real, established community interest company running NHS adult community nursing in Calderdale (RR2 resolved). The advert's pay range sits around the market median, so it isn't underpaid. Nothing in the posting is a red flag. The open question is how much support the caseload gets (RR1).

**Evidence map (abridged to the rows that matter).**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | NMC Adult registration | hard_gate | direct | high | none | `[grounded]` your CV |
| R2 | Full UK driving licence | hard_gate | direct | high | none | `[grounded]` your CV |
| R3 | ≥1 yr post-reg experience | must_have | direct | high | none | `[grounded]` five years on a ward |
| R6a | Pressure and surgical wound care | must_have | direct | high | none | `[grounded]` your CV |
| R6b | Leg-ulcer care | must_have | adjacent | medium | transferability | `[inferred]` from pressure-ulcer work |
| R9 | Own caseload | important | unclear | low | transferability | `[grounded]` CV silent; discharge-to-assess visits |
| R12 | Doppler assessment | preferred | absent | none | capability | `[grounded]` CV silent |

**Role reality.**

- Organisation: Calderbrook Community Health CIC, Halifax, adult community nursing under an NHS contract, 410 staff across four hubs. `[grounded]` company About page.
- Pay: advert £31,050–£37,800 plus mileage. The 2026 pay guide for Band 5 community staff nurses gives a median of £34,300 (interquartile range £32,400–£36,600), and 61% of respondents were paid mileage. The advert's midpoint is about £34,400, so it sits at market. `[generic]` pay guide; `[grounded]` advert.
- Team lead: Rhiannon Mabbott has spoken publicly about nurse-led leg-ulcer clinics and about Doppler training for staff new to community work. `[grounded]` conference speaker page.
- The Doppler training point suggests the desirable criterion may be trainable on the job. `[inferred]`, not confirmed by the employer.

**Gap recovery queue.**

- R9 (caseload): The gap is independent caseload decisions. Your discharge-to-assess work is the bridge, and the limit is that you have never owned the outcome of a patient list. Closing it means showing a case where you set the plan and followed it through alone.
- R12 (Doppler): Capability gap with a closure path: ask about training during the interview, since the team lead has run Doppler training for new community staff. `[inferred]`.
- R10 (end-of-life) and R8 (written records): discovery gaps; you may have more than the CV shows.

**Opportunity risk register.**

- RR1 (unknown): How much support does a new caseload get from the senior community nurse? Verification question: "What does caseload supervision look like in the first three months, and who reviews a new nurse's plans?"
- RR2 (resolved): The employer is confirmed. The specific posting is not confirmed live, because I did not check the careers page. Verification question: "Is this vacancy still open, and what's the closing date?"

**Application plan (all pending your approval).**

- CV edit: surface the discharge-to-assess home visits as the closest thing you have to caseload work, with exact numbers if you have them. Do not describe them as caseload experience.
- Check your NMC PIN on the public register before applying.
- Do not claim Doppler or leg-ulcer experience you don't have. List it as a development area.

**Evidence status.**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "…careers community staff nurse"; fetched the About page (calderbrookhealth.example/about). Confirms the employer exists as described. The careers page was not fetched, so the posting's live status is unconfirmed. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 NHS pay scale", which returned the Wardround 2026 pay guide (wardround.example). Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the community nursing forum speaker page. Used only for the team's public work. |

**Upgrade menu.**

- The live posting or closing date → RR2 closes.
- An answer on caseload work → R9 moves to `adjacent` or `direct`.
- A leg-ulcer or end-of-life example → R6b and R10 move.
- A deeper research pass on the employer's careers page and recent news (up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like a reusable record of this assessment with the full evidence map, I can save it as `tuesday-dossier.md`.

Three questions:

**R9:** Think of a patient whose discharge plan you shaped on the discharge-to-assess team, with you deciding the next steps. What did you decide yourself, and what did you escalate?

**R10:** Have you cared for anyone at the end of life at home, or managed leg ulcers with compression or dressings? Even a few cases would help.

**R12:** Have you done any vascular assessment or ABPI training? If not, would you consider a short Doppler course before starting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.