**Yes, apply, on three conditions.** `conditional_go`. You meet every credential and location requirement on the advert. The main gap is that you've never held a caseload, and the role is built around one. The conditions are below.

## Decision snapshot

**Worth applying: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R7; adjacent: R5, R6, R8, R10; unclear: R9, R11
- `important`: absent: R12
- `preferred`: absent: R13

R5, R6 and R8 are adjacent. Your wound, catheter and home-visit experience is real, but the advert names leg-ulcer and continence work that your CV doesn't cover. R9 and R11 are unclear because the CV is silent, not because you lack them.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the caseload build-up and support model verify as workable (RR1); (2) the vacancy is confirmed live and the salary band is confirmed (RR4); (3) leg-ulcer work is described as adjacent, never as direct experience (R5)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` calderbrookhealth.example/about |
| Mandate | District nursing for housebound adults at home; you hold a small caseload, supported by a senior community nurse | `[grounded]` advert |
| Working pattern | Home visits; pool cars provided; Halifax base | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse, England, 2026 (survey of 1,240): median £34,300; middle half £32,400–£36,600; 61% paid mileage. This is England-wide, not Calderdale-specific | `[generic]` Wardround 2026 pay guide |
| Pay mismatch check | The advertised range covers the survey's middle half. No mismatch | `[grounded]` advert against `[generic]` band |
| Lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` communitynursingforum.example profile |
| Unknowns | Caseload size and build-up; out-of-hours and on-call expectations; contract type; records system; whether Doppler training is provided in post | — |
| Contradictions | None found. The careers page was not checked, so whether the posting is live is unverified | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | high | none | Active registration, revalidation March 2028 | `[grounded]` your CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B, full | `[grounded]` your CV | none |
| R3 | Based in Halifax | hard_gate | direct | high | none | You live in Halifax; the post is Halifax-based | `[grounded]` CV and advert | none |
| R4 | At least one year post-registration | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` your CV | none |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcer and surgical wound care are direct; leg ulcers aren't stated | `[inferred]` from your wound-care list | see G5 |
| R6 | Catheter and continence care | must_have | adjacent | medium | transferability | Catheter care is direct; continence care isn't stated | `[inferred]` from your CV | see G5 |
| R7 | Insulin administration | must_have | direct | high | none | Stated in CV | `[grounded]` your CV | none |
| R8 | Community home visiting | must_have | adjacent | medium | transferability | Visits in the first week after discharge, not ongoing housebound caseloads | `[inferred]` from discharge-to-assess secondment | see G1 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | see G2 |
| R10 | Care planning | must_have | adjacent | low | transferability | Discharge planning is implied, not described | `[inferred]` from secondment | see G2 |
| R11 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on documentation | `[grounded]` CV silence | see G3 |
| R12 | Holding a small caseload | important | absent | high | capability | Never held your own caseload | `[grounded]` your statement | see G1 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | high | capability | Never done one; desirable only | `[grounded]` your statement | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload (R12, R8) | capability | Discharge-to-assess visits were patient-by-patient, not a continuing list you owned | The role is a caseload; this is the main objection | Any period you were assigned a list of patients and managed it | Caseload or workload description from your secondment | `[inferred]` from the secondment |
| G2 | End-of-life and care planning (R9, R10) | discovery | Not in CV | Both are must-have duties | Palliative or end-of-life patients on the ward or at home; discharge plans you wrote | Examples you can describe | `[grounded]` CV silence |
| G3 | Records (R11) | discovery | Not in CV | Essential requirement, and the posting stresses it | Electronic records used on the ward and in discharge-to-assess | Records system name and what you documented | `[grounded]` CV silence |
| G4 | Doppler (R13) | capability | Never done | Desirable only; the lead has spoken on Doppler training for new community staff | Vascular or ulcer assessment training | Any course, or confirmation the post provides it | `[grounded]` your statement; `[inferred]` from the lead's public talk |
| G5 | Leg ulcers, continence (R5, R6) | transferability | Wound and catheter care described; leg ulcers and continence not | Two must-haves at adjacent | Any leg-ulcer dressing or compression work; continence assessment | A sentence on any of these | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload build-up and support not described | risk_signal | medium | "hold a small caseload of your own, supported by a senior community nurse" | First caseload may be large or unsupported in practice; the senior nurse may be a notional rather than a real support | `[inferred]` from the advert's silence on caseload size | How is a new community nurse's caseload built up over the first six months, and how often do you review it with the senior nurse? | unresolved |
| RR2 | Out-of-hours and on-call unstated | unknown | — | — | On-call or weekend work may be expected | `[generic]` community nursing pattern | What are the on-call and out-of-hours expectations for this post? | unresolved |
| RR3 | Posting status unverified | unknown | — | "Current vacancies are listed on our careers page" | The posting may be closed or filled | `[inferred]` careers page not checked | Is this post still open, and is £31,050–£37,800 the offered band? | unresolved |
| RR4 | Pay in line with market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Stated pay is within the surveyed middle half | `[grounded]` advert against `[generic]` band | Is mileage paid at the standard rate? | noted |
| RR5 | Doppler training provision | unknown | — | "Doppler assessment for leg ulcers" (desirable) | The post may provide Doppler training in role | `[inferred]` from the lead's 2025 talk | Is Doppler training provided to staff who don't yet hold the skill? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the discharge-to-assess home-visit work and your wound, catheter and insulin care | Strongest direct match to the caseload's core tasks | `[grounded]` CV | pending your approval |
| A2 | Describe leg-ulcer and continence work as adjacent, never as direct | Avoids an overclaim the interviewer will probe | `[grounded]` R5, R6 | pending your approval |
| A3 | Check the careers page to confirm the post is live before applying | RR3 | `[grounded]` RR3 | pending your approval |
| A4 | At the informal chat with Rhiannon Mabbott, ask RR1, RR2 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Prepare a plain account of your caseload-equivalent work | G1 | `[inferred]` G1 | pending your approval |

Nothing above adds to your CV or outreach yet. Any wording you want to use externally needs your approval first.

## Evidence status

Verified: none yet.

Your CV claims are your own statements, so they are leads until they're backed by something you can show, such as a reference, a training record, or a sample of your documentation.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The employer exists as described. The careers page was not checked, so RR3 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary 2026 NHS district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and the RR4 check |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the communitynursingforum.example speaker profile. Positioning and RR5 |

## Upgrade menu

- The live careers-page listing, or a link to it → RR3 and the posting-live check
- Your records system name, and one example of a documented discharge plan → R11 and R10 toward `adjacent` or `direct`
- Any leg-ulcer dressing work, or continence assessment → R5 and R6 toward `direct`
- A Doppler course, or confirmation the post provides one → R13 and RR5
- Your pay floor, hours, and contract-type preference → the hard-gate checks, which currently read unknown
- Deeper company diligence (funding, leadership churn, public reviews) and a recent-news sweep: up to 5 more searches and 2 more fetches. Say yes to run it, or no and I won't offer again.

I can also turn this into a `tuesday-dossier.md` for the mock-interview skill, if you want to rehearse the interview.

**Questions** (answer any, all, or say "skip"; silence counts as skip):

1. (R12, G1) Over your secondment, were specific patients assigned to you as your own list, and how did you manage that list day to day?
2. (R9, R10, G2) Have you supported a patient at end of life, or written a discharge plan you led?
3. (R11, G3) What electronic records system did you use on the ward and in discharge-to-assess, and how did you document visits in it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.