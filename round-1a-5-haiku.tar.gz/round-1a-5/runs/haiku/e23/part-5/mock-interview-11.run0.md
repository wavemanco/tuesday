Before we start on interview prep, I'd check this one carefully. Several things in that message match common job scams, and I'd want you to confirm it's real before you share anything personal.

**Red flags:**
- **Unsolicited contact from an unknown number**, with a generic "we found your profile online" line instead of a named company and role.
- **The whole process on WhatsApp.** Real recruiters usually use email and a video or phone call, and they'll name the company and the job.
- **Fast pace.** An interview tomorrow, with a contract to follow, for a remote role with vague details.
- **Scams often escalate later** by asking for ID, bank details, or a "background check" fee, or by asking you to pay for equipment or training. Some ask you to buy crypto or pay to "unlock" tasks.

Some real recruiters do message people this way, so this doesn't prove it's a scam. But you shouldn't rely on the contact details they gave you.

**Before you send anything personal, check:**
1. **Find the original application.** Which job board, company site, or agency did you apply through? Look at the listing and the company name yourself, not through this message.
2. **Verify the company independently.** Find its official website and main phone number, and ask whether it's hiring for that role and whether Jess works there. Check Jess's name on LinkedIn and see whether the profile looks real and matches the company.
3. **Ask for proof in your reply.** Something like: *"Thanks, Jess. Which company and role is this for, and which job ad did I apply to? Please send the interview by email or a video call, from your company email address."* A genuine recruiter will answer this without fuss. A scammer usually avoids it or pushes harder.
4. **Don't share** your passport, ID, bank details, National Insurance or Social Security number, or photos of documents, and don't pay anything, until the company is confirmed through its own channels.
5. **Search the phone number** with the word "scam" to see if others have reported it.

If it's a scam or you're unsure, block the number and report it in WhatsApp. You can also report it to your local fraud authority (Action Fraud in the UK, the FTC in the US, or your national equivalent).

**Once you've confirmed the role is real,** I'll run the mock-interview prep. It works best with:
- The job posting, or at least the job title and company
- Your CV
- Anything you know about how the interview will go

If you'd like, I can also draft the reply to Jess above so you can send it now.