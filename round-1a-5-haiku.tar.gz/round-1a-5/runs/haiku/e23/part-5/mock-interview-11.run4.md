Before we start, I want to flag the message itself. Several things match common job scams: an unknown number, a vague "remote position with flexible hours", an interview arranged within a day, and a process that avoids any call or video and moves everything into WhatsApp. I'll load the prep skill now, but I'd verify this recruiter before investing much time in it.
I can't build the prep pack yet. It needs at least a **company name and a role title**, and the WhatsApp message gives neither. Before you spend any more time on this, though, I'd check whether the job is real.

**The message has several common scam markers:**
- An unknown number that contacted you out of the blue, with no company named
- A vague "remote, flexible hours" role
- An interview set for tomorrow with no details
- The whole process, including the contract, moved to WhatsApp with no call or video
- A "recruitment consultant" who won't say who the client is

Some scams are designed to collect your ID, bank details or tax number, or to ask you to pay for "training" or equipment, or to receive and forward money. Don't send any of those, and don't pay anything, whatever the role is.

**Ways to check, before tomorrow:**
1. **Ask Jess for the client company's name and the job posting link or reference number.** A real recruiter can answer this straight away.
2. **Check the job on the company's own careers page or on the job board where you applied.** Don't use a link Jess sends you. If the role isn't there, be cautious.
3. **Search for Jess** on LinkedIn and check whether the agency exists on the Companies House or equivalent register in your country, and whether the company has a real website and contact details.
4. **Ask for a video call.** A legitimate recruiter will usually agree. Refusing or dodging is a warning sign.
5. **Ask whether you can reply to the company's official email address** rather than WhatsApp.

If the role checks out, come back with:
1. **The company name and the exact role title** (required to build the pack)
2. **The job description**, or the posting link, if you have it
3. **The interview format and who you'll speak to**, such as a recruiter screen or a hiring manager round, if Jess has said
4. Optionally, **your CV**, so the pack can draw on your real experience

I can then build the full prep pack. If you'd rather prepare without the company details, I can instead write general prep for remote-role screening calls, but the questions would be generic.