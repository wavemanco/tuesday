I'd hold off on prepping for this one until you've verified it. The message has several classic recruitment-scam markers, and I can't build a useful pack yet anyway because I don't know the company or role.

**Red flags in the message**

- **Contact came to you.** "We found your profile online" is a common opener. It doesn't mean they're legitimate.
- **Process is WhatsApp-only, with no calls or video.** Real recruiters, even agencies, usually use email from a company domain and video calls. Refusing all live contact is a strong warning sign.
- **No company or role named.** Vague "remote, flexible hours" offers are the usual bait.
- **Interview tomorrow from an unknown number.** Scammers move fast so you don't have time to check.

Scams like this often go on to ask for your passport or ID, bank details "for payroll", a fee for equipment or training, or to receive and forward money or parcels through your account. Don't send any of those.

**Verify before anything else**

1. Ask for the company name, the exact job title, the job posting link, and the recruitment agency's name and website.
2. Ask for a video call, or for the job to come from an email address at the company's real domain.
3. Look up the company independently: its official website, its careers page, and the national company register (e.g., Companies House in the UK). Check the listing exists there, not just in the message.
4. If you applied through a job board, check the application and recruiter details in your account there.

You could send something like:

> "Thanks for reaching out. Before I commit to a time, could you send me the company name, the job title, the posting link, and the agency you work for? I'd also like a video call or an email from the company's domain. I won't share personal details until the role is verified."

A legitimate recruiter will answer that without fuss. If Jess dodges it, pushes you to act fast, or asks for money or documents, treat it as a scam and don't reply further.

**Once you have a real role**

Send me:
- The company and role title (I need these to build the pack)
- The job description, if you have it
- Your CV or a short background summary
- The round type and who you'd be speaking with, if you know

I'll then build a prep pack with likely questions, answer guidance based on your real experience, and practice questions. I'll only work with details you give me. I haven't made up any company or role information.