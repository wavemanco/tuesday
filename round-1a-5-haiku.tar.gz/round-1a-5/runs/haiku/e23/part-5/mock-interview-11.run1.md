I haven't started the mock-interview prep yet. This message has several signs of a recruitment scam, and I'd check those before you spend time preparing or commit to tomorrow's slot.

**Red flags:**
- **Interview entirely over WhatsApp, with no call or video.** Legitimate recruiters for remote roles almost always use a call or video call at some stage.
- **No company or agency name.** Jess doesn't say who she works for or what the role is.
- **Unsolicited contact from an unknown number** with a line like "we found your profile online." Applying to lots of places makes this plausible, but it doesn't confirm it.
- **Vague appeal:** "flexible hours," "great match," and a very fast interview the next day.

Scams like this often go on to ask for ID documents, bank details, or tax/national ID numbers, or to request a payment for "training" or "equipment." Some ask you to receive and forward packages or money. Don't share any of those, and don't pay anything.

**Before you engage further:**
1. **Ask Jess for the company name, the agency name, the job title, a link to the posting, and her full name and LinkedIn profile.** A legitimate recruiter will answer these without fuss.
2. **Find the role yourself.** Search for the company's careers page directly, not through a link Jess sends, and check whether the position is listed. Confirm the company and agency exist.
3. **Ask for a video or phone call** instead of WhatsApp-only. Legitimate recruiters usually agree. A refusal or vagueness is a strong signal.
4. **Check the number and name** by searching them with "scam" or "recruiter." People often report these.
5. **Think about where this came from.** If you can't remember applying to this agency, treat the message with extra suspicion.

You could reply to Jess with something like: *"Thanks for reaching out. Before I commit to a time, could you send the company name, the job posting link, and your full name and LinkedIn? I'd also prefer a short video or phone call before the interview."*

**If it checks out**, or if you want prep for a genuine application anyway, send me the job description and your CV. I'll run the mock-interview prep pack on those, covering likely questions, answer guidance, gaps to address, and questions to ask them.