I'd hold off on the prep for this one until you've checked who's contacting you. Several things in that message match common recruitment scams:

- **Interview entirely over WhatsApp, with no call or video.** Legitimate employers almost always do at least one video or phone interview.
- **Contract over WhatsApp.** A real employer sends offers and contracts by email from a company domain, through an HR system, or via a recruiting platform.
- **"Found your profile online" from an unknown number.** Recruiters do reach out this way, but they'd normally use LinkedIn or email, and they'd name the company and role.
- **Vague offer, fast timeline.** "Remote, flexible hours" with an interview tomorrow and no company name is a pattern scammers use.

Scams like this often go on to ask for money for "training," equipment or background checks, or for your passport, bank details or national ID. Some ask you to receive payments and forward them, which can make you a money mule without your knowing it.

**Before you engage further, you could:**

1. **Ask for the company name, the recruiter's full name, and the job posting or reference number.** Be wary if they dodge this.
2. **Check the job itself.** Find the original listing on the job board or the company's careers page. If you can't find it, that's a problem.
3. **Verify the company independently.** Use the website you find by searching, not a link or number from the message. Check that the company exists and that Jess works there (LinkedIn is useful for this).
4. **Ask for a video call and an email from a company domain.** A genuine recruiter will normally agree. If they refuse or push back, treat that as a strong warning.
5. **Don't send any ID, bank details or money,** whatever the reason given.
6. **If it looks fake,** report and block the number in WhatsApp, and report it to your local fraud service (in the UK that's Action Fraud; in the US, reportfraud.ftc.gov).

If the company checks out and they agree to a video call, I'm happy to run the mock-interview prep. To tailor it, I'd need:

- The job description, or the listing you applied to
- Your CV or a summary of your background
- The company name and, if you have it, the interviewer's name

If you'd rather not wait on this, I can also run general prep for a remote role now, so you're ready for whichever real interview comes up.