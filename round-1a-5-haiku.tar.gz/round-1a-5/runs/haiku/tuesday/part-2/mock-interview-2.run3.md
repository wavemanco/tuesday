Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-2-denied-6b420c37/atlas-freight_operations-manager_interview_pack.md`.

I built it for a generic round with flat persona weights, since your note doesn't say who you're meeting or in what format. Web search was refused in this session, so the pack has no Atlas Freight values, interview format or strategy. Those sections are labeled as missing, not filled from memory.

What the pack does:
- **Fit gaps:** you have no Power BI and no stated experience at 12 supervisors or five years at leadership level. The pack treats these as the gaps most likely to come up.
- **Highest-ROI prep:** E2, "Your material shows three supervisors. This role leads twelve. How would you handle that step?" It has the deepest rehearsal in the pack.
- **Headline number:** expect the 40% mis-pick reduction to be probed (A1–A2, B2). Be ready to say how it was counted and which part was yours.

Say the word and I'll play the Skeptic on E2 for a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would change the most:
1. Who are you meeting, and what round is it: hiring manager, panel, peer or HR screen? The answer reweights every question bank.
2. Can you paste the full job description? The six lines you gave are an excerpt, and the full text may add requirements the fit snapshot doesn't cover yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep

Round, interviewer and format: not stated. This pack uses the generic fallback: flat persona weights, no company research (see Sources).

## How to use, and type key

Personas describe how a question is asked. Types describe what it scores.

- **EXP**: work-experience deep dive. Whether your claims survive scrutiny.
- **JD**: role-driven. Whether you can do the listed job, gaps included.
- **VAL**: behavioral. How you have acted, told as a short story.
- **CASE**: live problem. Structure and reasoning, worked out aloud.
- **CO**: company knowledge. None in this pack, because no company research ran.

Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds.

## Fit snapshot

Requirements are the JD lines as you pasted them. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD, as you pasted it) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your message shows warehouse and distribution ops and a shift role. It does not say whether you covered more than one site. Answer slot: if you covered more than one site, say which and how; if you worked one site, say so plainly and stay with the shift you ran. |
| F2 | "lead a team of 12 supervisors" (JD, as you pasted it) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | The quote says 3, the JD says 12. Stay with the number you have. Answer slot: say how you led the 3, and what you would need in place to lead more. |
| F3 | "5+ years operations leadership required" (JD, as you pasted it) | "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Your message does not give years at leadership level. Answer slot: state your years in a leadership role, in your own words. The derivation: your current title is the only leadership fact in your message. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD, as you pasted it) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Mis-pick is accuracy, not on-time delivery or cost per shipment, so the words stay at mis-pick. Answer slot: if you tracked on-time or cost per shipment, say what and how; if you did not, say so and stay with the mis-pick number. |
| F5 | "build reporting in Excel/Power BI" (JD, as you pasted it) | "solid Excel, never used Power BI" (your message) | low | [inferred] | discovery | "Solid Excel" reaches the tool, not reporting you built. The derivation: your Excel skill is read as a tool skill, not as a reporting record. Answer slot: if you have built reporting in Excel, name what it was and who used it; if not, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" (JD, as you pasted it) | "solid Excel, never used Power BI" (your message) | none | [grounded] | capability | Your message states that you have never used Power BI. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD, as you pasted it) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how you applied it: name the certifying body and anything you applied it to, if anything. |

Gap type follows the evidence, not the writer's sense of the row. F1, F2 and F4 are transferability: adjacent work that does not reach the requirement in full. F3, F5 are discovery: the material is silent. F6 is capability: you stated the absence. F7 is none.

**Gate check.** No requirement in the JD you pasted is a term such as location, pay, schedule or credential, so no gate row appears. The "5+ years" line is experience, graded on fit like any other requirement (F3).

## Prohibited claims

Built locally from the fit snapshot, since no dossier is present. Each entry is a stretched wording of something you said, or a negative you stated, with its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across all four sites | Inflated form of F1 | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors." The pack's own observation: your message does not say more than one site. |
| Leads 12 supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors" |
| Five-plus years leading operations | Inflated form of F3 | The F3 answer slot, with no figure supplied. |
| Cut on-time delivery or cost per shipment | Inflated form of F4 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. |
| Built the site's Excel reporting | Inflated form of F5 | "solid Excel, never used Power BI." Reporting built is an answer slot, not a claim. |
| Built Power BI reports; is experienced in Power BI | Negative you stated, F6 | "I haven't used Power BI." |
| Set the forecast and labour plan behind the peak season | Practice the role usually involves, attributed to you by "ran the site's peak-season surge plan" | "ran the site's peak-season surge plan two years running," at its own scope. Which parts were yours is an answer slot (A3). |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads your 40% and asks how it was counted and what it rests on. | 3 questions. Flat weight: no round or interviewer is known, so no persona outweighs another. | Know what you can and cannot say about the count. Say plainly when you do not know. Name the weakest assumption before they do. |
| Pressure / Stress | Challenges "how much was actually you," and time-boxes answers. | 3 questions. Flat weight, as above. | Pause, restate, and hold a position through two follow-ups before conceding anything real. |
| Values / Behavioral | Asks for stories of hard truths and hitting targets with a stretched team. | 3 questions. No published values were read, so these are persona stems, not mapped values. | Tell a story with "we" for context and "I" for what you did. Where your material has no story, say so and give the nearest one it does carry. |
| Case / Strategist | Live problems: a first 90 days, a drop in on-time performance, a peak with short staffing. | 3 questions. Flat weight. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Skeptic | Probes the team-size step-up, the Power BI gap, and whether the 40% carries to a bigger site. | 3 questions. Flat weight. The most predictable objection is the team-size gap (E2), so it gets the deepest rehearsal. | Rehearse the gap until it is boring. Concede what your quotes do not show, and give a ramp plan. |
| Conversational / Rapport | Friendly openers: "walk me through the journey," or a casual Excel or Lean question. | 3 questions. Flat weight. | Keep a 90-second arc. Treat casual questions on JD topics as scored. |

## Question banks

Each question is the interviewer's line. Provenance lists the candidate sentences the guidance rests on, quoted from your message or the JD lines you pasted.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how you measured it, in your words. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours. If you do not know how it was counted, say so plainly. | F4 is the evidence for the headline metric, so the defend-the-number slots apply. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption you would defend least, in your own words, before they do. Answer slot: if you did not set how the figure was counted, say so. | The weakest-assumption move, rehearsed on F4. |
| A3 | "You ran the site's peak-season surge plan two years running. What was in the plan, and which parts were yours?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Describe the plan's contents in your own words, and say which parts you decided. Answer slot: if a part was set elsewhere, say so and describe what you ran. | A premised question on the quote. It supports the "own daily terminal operations" requirement (F1). |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over an internal candidate for this role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 60-second arc from those two quotes, in order. Hold to them through two follow-ups. Answer slot: if the largest team you have led is bigger than three, say so; if not, say what you would need in place to lead twelve. | F1, F2 and F3 are all in play in one answer, and the 5+ years requirement sits under it. |
| B2 | "That 40%. How much of it was actually you?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold: say what you redesigned, in your words, and stay with it through two follow-ups. Concede specifically: name which part of the redesign was yours to decide, and which part was someone else's. Answer slot: if others set parts of the redesign, say which. | Pressure on a headline figure. The hold is only what your quote carries. |
| B3 | "Sixty seconds: what did you do in peak season, and how much of it was your call?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold to the quote's scope: you ran the plan two years running. Do not add results. Answer slot: if you measured how the plan performed, say what; if you did not, say so and say what the plan covered. | Peak work is the nearest evidence for daily operations at scale (F1). |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem | Pick a time you pushed back on a decision already made. Name the decision, what you said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | No published values were read, so this is a stem, not a mapped value. |
| C2 | "Tell me about a time you had to hit a target while your team was stretched." | VAL | [grounded] "drive on-time performance and cost-per-shipment down" (JD, as you pasted it); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pick a time a target and your team's load pulled against each other: name the target, what you did, and what gave. If you have no such time, say so, then give the mis-pick work. | The JD names the target. Your mis-pick work is the nearest thing the material carries. |
| C3 | "How have you led the supervisors who report to you?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Say how you run the three supervisors' shifts and what you have asked of them, in your words. Answer slot: if you have no example of how you led them, say so plainly and describe the routine you use. | Raised by the JD's team-of-supervisors line (F2). |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch your first 90 days across four sites. What do you need to know first?" | CASE | [generic] live problem; asks nothing about your past | Clarify, then set the objective, segment the four sites, lay out the approach, name the metrics, and state the risks. Think aloud. Challenge one premise, such as whether the four sites are alike. | Live problem from the JD's four-site line (F1). |
| D2 | "On-time performance has dropped at one of the four sites this quarter. How do you diagnose it?" | CASE | [generic] live problem; asks nothing about your past | Clarify how on-time is defined first. Then segment by lane, shift and carrier, and state the metric you would check first. | Live problem from the on-time line (F4). |
| D3 | "Peak volume starts next week and two sites are short on staff. How do you decide where labour moves?" | CASE | [generic] live problem; asks nothing about your past | Clarify the volume, the constraint and the cost of moving people. Then give the decision rule and what you would watch. | Live problem for the four-site line (F1) and the peak-season story (B3). |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" (your message); "build reporting in Excel/Power BI" (JD, as you pasted it) | "I haven't used Power BI." Then a plan for learning it, starting with whichever report you would be asked for first. Plan only, never a past. | F6 is the one gap you stated outright, so the plain acknowledgment fits. |
| E2 | "Your material shows three supervisors. This role leads twelve. How would you handle that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Concede specifically, without bluffing: "I'm currently over three supervisors." Then a ramp plan, in your words: what you would do first. Hold one follow-up. Answer slot: if you have led more than three, say how many and when. | Highest-ROI prep in this pack. The team-size gap is the objection most likely to come up in some form (F2), and the deepest rehearsal goes here. |
| E3 | "What would have to be true for that 40% to carry over to a bigger site?" | Skeptic | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the conditions in your own words. If you have not seen the result carry over, say so. | F4's figure, tested for scope. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc from those two quotes, in that order. Add nothing. | F1 and F2 are the story's spine. |
| F2 | "What are you playing with at the moment in Excel or reporting?" | JD | [grounded] "solid Excel, never used Power BI" (your message); "build reporting in Excel/Power BI" (JD, as you pasted it) | Excel, as your quote states it. Power BI: "I haven't used Power BI." Casual questions on JD topics are scored. | F5 and F6, asked casually. |
| F3 | "Which parts of Lean or Six Sigma have you put to work?" | JD | [grounded] "green belt certified" (your message) | "I'm Green Belt certified." Answer slot: if you applied it to a project, name the project; if not, say so. | F7. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, D1, D3 |
| "drive on-time performance and cost-per-shipment down" | A1, C2, D2 |
| "lead a team of 12 supervisors" | B1, C3, E2 |
| "build reporting in Excel/Power BI" | E1, F2 |
| "5+ years operations leadership required" | B1, E2 |
| "Lean/Six Sigma a plus" | F3 |

Total: 18 questions across six personas, three each.

## Reverse questions

Each lands for a reason. Ask whichever fits the room.

1. "What would a strong first 90 days look like for this role?" Lands because it shows you plan to the role's actual scoring.
2. "How do the four sites differ most in how they run day to day?" Lands because it shows you are thinking about four sites, not one.
3. "What reporting do the sites send up today, and what gets decided from it?" Lands because it tests the Excel and Power BI gap in context.
4. "Which of on-time performance and cost per shipment does this role own directly, and which sit with others?" Lands because it separates what the job owns from what it shares.
5. "What has made supervisors on this team succeed or struggle in the last year?" Lands because it shows interest in the people you would lead.
6. "What would make you say the hire was a good one at the 90-day check?" Lands because it asks for the success criteria in the interviewer's own words.

## Sources

Provided documents: your message only, containing your background and the six JD lines you pasted.

Searches sent, each refused by the host (permission not granted):

- "Atlas Freight regional logistics company values"
- "Atlas Freight interview process operations manager"
- "Atlas Freight logistics strategy news"

Research tier: L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Refused. Would have moved the values cheat sheet, and whether a values round exists. |
| 2. Interview process, operations manager | unavailable | Refused. Would have set the loop structure and replaced the flat persona weights. |
| 3. Strategy / recent news | unavailable | Refused. Would have fed the CO bank, which is absent here. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD lines you pasted fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your full job description** → the six lines above are an excerpt. The full text may add requirements that change the fit rows (F1 to F7).
- **The round and who you are meeting** → restructures the persona table. Flat weights are the generic fallback now.
- **Interviewer names** → persona weights from their public footprint, and a tailored reverse question.
- **Atlas Freight's values page and interview guide, pasted** → the values cheat sheet, and the actual loop structure in place of the fallback.
- **The recruiter's prep email** → coverage of any deliverable the recruiter names in advance.
- **Years at leadership level and your largest team** → moves F2 and F3 from answer slots to grounded rows.
- **How the 40% was counted** → moves A1, A2 and B2 from answer slots to grounded rows.
- **A deeper research pass (L2), offered once:** up to 6 more searches and 2 more fetches, several more minutes. Web search was refused this session, so it would need that permission first.
