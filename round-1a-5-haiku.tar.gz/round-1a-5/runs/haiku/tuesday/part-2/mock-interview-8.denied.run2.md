The outputs folder needs approval to create, so I'll save the pack to the session scratchpad, which the app can open.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-8-denied-1fe445d0/783295df-4d9b-4db1-9171-910a9fee2341/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. It covers all three rounds on 4 December. I couldn't create an outputs folder in your project, so it sits in the session scratchpad.

The pack is built around three things:

- **Your strongest material.** Six years in retail banking, the last three as a branch supervisor, the complaints log, the escalation script you trained tellers on, and the monthly spreadsheet your regional manager uses. Every guidance line rests on one of your own sentences, quoted exactly.
- **Your two stated gaps.** No contact-centre work, and no presenting above regional level. These are on the page as gaps, with plans instead of past claims. The Head of Member Services round is where those gaps get tested. B2 is the highest-return prep, and it is rehearsed as hold-then-concede.
- **The values.** None of your sentences carries a story for any of the four values, so each one has a selection scaffold with an honest branch. Before 4 December, pick two or three real moments for them, especially for Own the Fix and Members First.

I took the strategy from your summary and did no web research. The values, the loop and the strategy all came from what you pasted, so nothing was searched. The pack says so in its Sources section.

I used your own sentences as the evidence. Please check that the quotes match the wording you intend to use.

Two questions would sharpen the triage:

1. How much prep time do you have before 4 December?
2. Will the 20-minute escalation case come with written material beforehand, or on the day?

I can also run a drill as the Head of Member Services on B2, or save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds, 4 December 2026 (from the recruiter's email):**
- Round 1, 30 minutes with the recruiter.
- Round 2, 45 minutes with the Head of Member Services, your prospective manager, mostly behavioural.
- Round 3, 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case. The panel scores against the four published values.

**Interviewer names:** not yet assigned. Persona weights below rest on each round's relationship, not on named people.
**Pack type:** first build, session mode.

---

## 2. How to use, and the type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: values and behavioural alignment with the published values.
- **EXP**: a deep-dive on your work experience, checking what you actually did.
- **JD**: the listed job's requirements, including the gaps.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, worked out aloud.

Guidance is scaffolding, not a script. Quoted sentences are yours, taken from your message. An answer slot is an instruction for the interview: where your experience does not cover it, the honest branch is the answer. Guidance is written to be spoken in 90 to 120 seconds.

---

## 4. Fit snapshot

The requirements come from the job description you pasted. None of them is a gate such as a licence, credential or eligibility term, so no row is a hard gate. The four stated requirements are experience and skill, and each row grades them as such.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Your material covers this in its own terms: six years in retail banking, three of them as a branch supervisor. Say it as that sentence, and let the years carry it. Limit: it says retail banking and branch supervision, not contact-centre or wider customer operations (see F9). |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints. It does not say whether any of them carried a regulatory timescale or went to an external body. Answer slot: if any did, say which and what you did; if none did, say so plainly and say how the formal log was run. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated, and the material shows no presenting above regional level. Words for you: "I've never presented to anyone above regional level." Then how you would build that capability, as a plan and never as a past. Never describe a presentation to senior leaders. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The sentence reaches reporting in other terms: a monthly spreadsheet your regional manager uses. Use the sentence as written. The material does not name the tool, so do not name one you have not confirmed. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints. Your material does not say it counts volumes, or that it shows resolution times. Answer slot: if it recorded how long complaints took to close, say what it recorded and how; if not, say so and say what you would add first. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: one branch's log and the escalation script you trained tellers on. Say it at that scope. Limit: one branch, not the process end to end and not across branches. Any wider step is an answer slot inside that scope (see C5). |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers on the escalation script, and you were a branch supervisor. Limit: the material shows training tellers, not coaching supervisors. Say the tellers as they were, and the supervisor role as yours. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have worked with a digital team, or on a change to a self-service route, say what it was and your part in it. If you have not, say so, and say how you would learn the journey from the member's side. |
| F9 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated. Words for you: "I've never worked in a contact centre." Then how you would learn the contact-centre side, as a plan and never as a past. |

**How to read the snapshot.** Confidence grades your evidence. Provenance grades what this pack wrote about it. Gap type says what kind of gap each row is. Rows F3 and F9 are gaps you stated, so the pack may give you back those words. Rows F2, F5 and F8 are gaps the material is silent on, so their words are answer slots.

---

## 6. Grounding brief

This section is built from the July 2026 strategy brief as your notes describe it. Your notes are a summary, not the brief, so check the wording against the brief before you quote it back.

- **Digital shift:** 40% of member service to digital channels by 2028.
- **Network:** eight branches consolidated into five hubs over 2027.
- **Product:** a small-business lending launch in Q1 2027.
- **Competition:** app-only banks are named as the main pressure.

Vocabulary to use: "member service", "digital channels", "hubs", "self-service journeys" (the job description's own phrase). Say "hubs" when you discuss the consolidation, not "branches closing". The brief is under six months old, so its priorities are current.

---

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | A friendly walk-through of your career, then logistics: pay, notice, location, reason for leaving | High in round 1. A recruiter screen's prior is conversational, and the logistics are scored in a friendly register. | A 90-second arc in your own sentences (A1). Give each logistics answer in your own words, with no figure you have not decided on. |
| Values / behavioural | Scenario prompts mapped to the four published values; STAR-shaped stories | High in round 2, which is mostly behavioural, and in round 3, where the panel scores all four values. | One story per value where a quoted sentence carries one. Where none does, a selection scaffold with its honest branch (B1, B5, C1, C2). |
| Skeptic | Quiet probing of the two stated gaps: no contact-centre work, no presenting above regional level | High in round 2. Your two stated gaps are the first things a manager checks against the role. | Rehearse the single most predictable objection until it is calm (B2). Hold the position your material carries, then concede the gaps in plain words. |
| Case / strategist | A live escalation case, and questions on the consolidation and the digital shift | High in round 3. The panel's 20-minute case is a live problem by design. | Clarify, name one owner, check the timescale that applies, then land the member's next step (C3). Think aloud, one premise at a time. |
| Peer evaluator | Seam-splitting between branch and contact centre; "what would you need from me" | Medium in round 3. The panel are branch managers, so they meet your work at the seam. | Ask about the seam before you propose a fix (C5). Reciprocity: what you bring to their branches (reverse question 5). |
| Data-driven prober | "What does that spreadsheet count?" and "does it show resolution times?" | Medium in round 3. The monthly spreadsheet line on your CV invites a count question, and resolution times are a stated requirement. | Say what the spreadsheet counts and what it is sensitive to, in your own words. Say plainly where it does not show something (C4). |
| Pressure | Interruptions and time-boxing | Low across all three rounds. None of the stated relationships carries a pressure prior. | Pause before answering, restate the question, and hold a challenged position through two follow-ups before conceding anything real. |

Weights: round 3 is the deepest because it scores values and runs the case. Round 2 is next. Round 1 is shallowest, but it is the only round where the logistics are asked.

---

## 9. Question banks

Each bank is one interview round. Provenance is the sentence each cell rests on, quoted exactly. Guidance is in your own words, not a script.

### Bank A: Recruiter screen (round 1, 30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | Ninety seconds, in the order of your own sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Say each one as written. Add no title, team size or result. End on what you want from this role, in your own words. | F1 is the four-years requirement, and this answer covers it first. F2, F4 and F7 are the evidence the recruiter will check next. JD because the answer scores F1. |
| A2 | "What salary are you looking for?" | JD | [grounded] "30 minutes with me" — recruiter's email | Logistics slot. Give your own figure, or a range in your own words, or ask first what band the role carries. Give no figure you have not decided on. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a logistics slot. You stated no figure, so the pack supplies none. JD because it is the listed job's terms. |
| A3 | "What's your notice period, and when could you start?" | JD | [grounded] "30 minutes with me" — recruiter's email | Logistics slot. Give your actual notice period in your own words. Name a start date only if you have one. | Notice is a logistics slot. You stated none, so none is supplied here. |
| A4 | "Where would you be based, and could you work across more than one site?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief as you summarised it | Logistics slot. Name the locations you can work from and how you would get between them, in your own words. If you have not decided, say so and ask which hub the role sits in. | Location is a logistics slot. The hub plan makes it likely to come up. |
| A5 | "Why are you looking to move on?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Logistics slot. Give the reason in one or two sentences, in your own words, about the move rather than about the employer. Give only a reason you actually have. | Reason for leaving is a logistics slot. You stated none, so none is supplied. EXP because it tests whether your path holds together. |

### Bank B: Head of Member Services (round 2, 45 minutes, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you decided from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] published value "Members First, Always" — values page as you pasted it; nearest thing: "I handled the branch's formal complaints log" — your message | Selection scaffold with an honest branch. Pick a complaint where the member's view changed what you did. Say what the process said, what you did, and what happened next. Your material does not show such a decision. If none comes to mind, say so plainly, then give the nearest thing your material carries: how you handled one entry in the log, from its start, but only if that is what happened. | Members First is the value this manager is most likely to test first. No quoted sentence carries a story here, so this is a scaffold, not a mapped answer. F2 is the nearest evidence. |
| B2 | "You've never worked in a contact centre, and you've never presented to anyone above regional level. Why should we hire you to run this?" | JD | [grounded] "Never worked in a contact centre" — your message; "I've never presented to anyone above regional level" — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | Highest-ROI prep in this pack. Hold: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede in plain words: "I haven't worked in a contact centre, and I've never presented to anyone above regional level." Then the ramp, as a plan and never as a past: how you would learn the contact-centre complaint flow in the first weeks, and how you would prepare for a senior audience. Hold through two follow-ups by returning to the log and the script. Never claim contact-centre or senior-presenting experience. Follow-up one: "Which part of this job would you be weakest at on day one?" Follow-up two: "What does a complaint from the contact centre look like that you haven't seen?" Answer with the plan, not with a claim. | F3 and F9 are the two gaps you stated, and a manager tests exactly those. The hold-then-concede structure is the rehearsal. This is the single most predictable objection for you, so it gets the deepest prep. |
| B3 | "Tell me about a complaint that carried a regulatory timescale or an external referral. What did you do with it?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot. If one came your way, say which, what the timescale or referral was, and what you did, in your own words. If none did, say so plainly and say how the formal log was run. Do not call any complaint regulated unless one carried such a timescale or referral. | The JD asks for regulated complaints. Your material says formal complaints (F2). The honest branch is the answer that stops the claim drifting. |
| B4 | "Tell me about a time you coached someone on an escalation they got wrong." | JD | [grounded] "trained new tellers on our escalation script" — your message | Open prompt. The nearest thing your material carries is training new tellers on the escalation script. Say what the teller got wrong, what you changed in the teaching, and what happened afterwards, only as it happened. If you have not coached an escalation decision, say so, and say how you would coach a supervisor on one. | The JD asks you to coach branch supervisors (F7). Your evidence is tellers, so the story stays at that scope. |
| B5 | "Tell me about a problem you found that you kept hold of until it was solved." | VAL | [grounded] published value "Own the Fix" — values page as you pasted it | Selection scaffold with an honest branch. Pick a problem you found yourself and followed to its end: what you found, what you kept hold of, who you had to bring in, and how you knew it was solved. The nearest thing your material carries is the branch's formal complaints log. Say what you carried from first contact to close, only where that is what happened. If no problem comes to mind, say so plainly. | Own the Fix is a value the panel also scores. The word to test is "own": the answer must show what you held, not what you handled. |
| B6 | "Tell me about a time you worked with a team outside your branch on a change to how members get something done." | JD | [grounded] "work with digital teams on self-service journeys" — the job description | Open prompt, with a selection scaffold. Pick a change that involved a team outside your branch: what it changed for members, your part in it, and what you would do differently. If you have not done this, say so plainly, then say how you would find out what a member needs from a self-service journey. | Digital self-service is in the JD and in the 40% target. F8 is silent in your material, so this is a discovery slot, not a claim. |

### Bank C: Panel of two branch managers (round 3, 60 minutes, values and case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member needed something explained to them twice. What did you change?" | VAL | [grounded] published value "Plain Words" — values page as you pasted it; "trained new tellers on our escalation script" — your message | Selection scaffold with an honest branch. Pick a letter, form or call where a member came back with the same question: what you changed in the words, and whether the next explanation landed. The nearest thing your material carries is the escalation script you trained tellers on: say how you explained it to them, only if that is what happened. If no such time comes to mind, say so plainly. | Plain Words is the value the panel scores here. No quoted sentence carries a member story, so this is a scaffold. |
| C2 | "Tell me about a time you put a branch's members ahead of a target." | VAL | [grounded] published value "Neighbours, Not Numbers" — values page as you pasted it; "I built the monthly complaints spreadsheet our regional manager uses" — your message | Selection scaffold with an honest branch. Your one sentence about numbers works against this value, so do not reach for the spreadsheet as the story. Pick a moment when a local detail changed a decision: what it was and what you did. If no such moment comes, say so, then give the spreadsheet only as the fact it is: "I built the monthly complaints spreadsheet our regional manager uses." | Neighbours, Not Numbers is the value your spreadsheet line runs against. Mapping it there would be a stretch the panel would see. |
| C3 | "A member rings the contact centre about a fee dispute. Last week they were told a branch would call them back, and nobody has. You now own this complaint. What do you do in the next 24 hours, and who do you involve?" | CASE | [generic] role-family pattern for a complaint escalation; no claim about your history | Structure aloud, in 90 to 120 seconds. Clarify the facts, and name any timescale you need to check, without naming one you have not confirmed. Name one owner, yourself, and tell the member who that is. Get the record into one place so the branch and the contact centre stop passing it between them. Call the member with a plain account of what happens next and when. Agree who checks back, and when. Record what failed, so the seam can be fixed. | A live problem from the JD's end-to-end line (F6). The panel tests structure and ownership, and the case is generic because it does not come from your history. The 20-minute case is scored, so rehearse it aloud. |
| C4 | "Tell me what your monthly complaints spreadsheet counts, and whether it shows resolution times." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message; "report monthly on complaint volumes and resolution times" — the job description | Answer slot for the second half. Say what the spreadsheet counts, in your own words, and what it is sensitive to. If it shows resolution times, say how they were counted. If it does not, say so plainly and say what you would add first. Name the tool only as you used it. Do not describe a measure you did not track. | The JD asks for monthly volumes and resolution times (F5). Your sentence says monthly and spreadsheet, not what it counts. The prober tests the count, and the honest branch is the answer in your own words. |
| C5 | "Where is the handover between the branch and the contact centre hardest, today?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — the job description | Answer slot. Describe one handover you know, from your side of it, and where it was hard. Your material shows the branch side only (F6). If you have seen the contact-centre side, say what you saw. If you have not, say that, and say what you would map first. | The branch managers are testing whether you know where the seam is. The JD's end-to-end line assumes you do. |
| C6 | "Eight branches become five hubs over 2027. What happens to complaints raised at a branch that closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief as you summarised it | Plan, not a past. Name the first thing you would check: open complaints, the record, and the member's contact point. Then who tells the member, and what the member sees in the first week. Do not claim you have run a consolidation. | The consolidation changes the complaints flow more than anything else in the brief. These branch managers will live it. CO because it tests altitude. |
| C7 | "The plan moves 40% of member service to digital channels by 2028. What happens to complaints from members who don't use the app?" | CO | [grounded] "40% of member service to digital channels by 2028" — strategy brief as you summarised it | Plan. Say how you would keep the complaint route open for a member who does not use digital, and how digital complaints would appear in the same monthly report. Name one thing you would measure before the shift. Do not describe a digital project you have not worked on. | Tests whether you think at the strategy's altitude. It connects to F8 without claiming any digital experience. |

**Coverage.** Each stated requirement and each published value has at least one question, or a stated reason for none.

| Requirement or value | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | B3 |
| confident presenting to senior leaders | B2 |
| comfortable with Excel reporting | C4 |
| own the member complaints process end to end across branches and the contact centre | C5, C3, B2 |
| report monthly on complaint volumes and resolution times | C4 |
| coach branch supervisors on escalations | B4, C3 |
| work with digital teams on self-service journeys | B6, C7 |
| Members First, Always | B1 |
| Plain Words | C1 |
| Neighbours, Not Numbers | C2 |
| Own the Fix | B5 |

**Highest-ROI prep:** B2. It is the objection your two stated gaps make most likely, and it is where a calm, non-defensive answer changes the round most.

---

## 10. Values cheat sheet

The panel scores against all four values, and each is published on your values page. Your quoted sentences do not carry a story for any of them, so each row gives a selection scaffold with its honest branch. Pick two or three real moments before 4 December.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold in B1. If none comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | No quoted sentence carries a story. Scaffold in C1. Nearest sentence: "trained new tellers on our escalation script" — your message. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold in C2. Your spreadsheet sentence points the other way, so do not map it here. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence carries a story. Scaffold in B5. Nearest sentence: "I handled the branch's formal complaints log" — your message. Say what you carried to the end, and only if you did. |

---

## 11. Reverse questions

Each question has a line on why it lands. There is no interviewer profile, so none is tied to a path. The panel are peers, so one reciprocity question is included.

1. **To the Head of Member Services:** "What would you need to see from this role in the first 90 days to know it's working?" *Why it lands:* it asks for the manager's standard, which you can then score yourself against.
2. **To the Head of Member Services:** "How are complaints split today between branches and the contact centre, and which handover causes the most follow-up?" *Why it lands:* it shows you are already thinking about the seam this role owns (F6).
3. **To the Head of Member Services:** "As branches move into hubs in 2027, how do you expect complaints to change, both where they are raised and who resolves them?" *Why it lands:* it ties the strategy to the complaints work without quoting the brief back at them.
4. **To the Head of Member Services:** "What does a good monthly complaints report look like to you, and what decision should it drive?" *Why it lands:* it tests the reporting requirement against the use the manager actually makes of it.
5. **To the branch managers, reciprocity:** "What could a new person do in their first month that would genuinely help your branch teams?" *Why it lands:* rapport-style panels weight this answer heavily as a preparation signal.
6. **To the branch managers:** "When a complaint reaches you as an escalation, what do you wish had reached you earlier?" *Why it lands:* it surfaces the seam's pain from the peers' side, which is where your plan can meet it.

---

## 13. Prohibited claims

This pack will not coach these claims, built from the fit snapshot. Each has its basis and the honest form that replaces it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F6. The material says one branch's log. | F6's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is this pack's observation: your material shows one branch, not the whole process. |
| Handled regulated complaints | Inflated form of F2. "Formal" is not "regulated" in your material. | F2's quote at its own scope: "I handled the branch's formal complaints log." B3's slot covers what, if anything, was regulated. |
| Designed the escalation script | Inflated form of "trained new tellers on our escalation script." | That sentence at its own scope: you trained tellers on it. |
| Coached branch supervisors on escalations | Inflated form of F7. The material shows tellers. | F7's quote at its own scope. B4's slot covers any supervisor coaching, if it happened. |
| Presented to senior leaders | Stated negative: "I've never presented to anyone above regional level" — your message | The plain acknowledgment: "I've never presented to anyone above regional level." No slot. |
| Worked in a contact centre | Stated negative: "Never worked in a contact centre" — your message | The plain acknowledgment: "I've never worked in a contact centre." No slot. |
| Expert in Excel, or built Excel dashboards | Inflated form of "I built the monthly complaints spreadsheet our regional manager uses." The material does not name a tool. | The sentence as written. Name the tool only as you used it (C4). |

---

## 14. Sources

- **Provided, in your message:** the job description; your background; the recruiter's round structure (from their email as you describe it).
- **Provided, pasted:** the four values, copied on 25 November 2026 from ashgrovecu.org/about/values. This is the values source for section 10 and the VAL questions.
- **Provided, summarised:** the July 2026 strategy brief, as your notes describe it. It is under six months old. Check its wording against the brief itself.
- **Searches and fetches:** none sent. Every target below is answered by what you provided.

**Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove credit union values | skipped | The pasted values page fixes the four names and their wording. It feeds section 10 and the VAL rows. |
| 2. ashgrove credit union interview process, member services | skipped | The recruiter's email names the three rounds, their length, who runs each, and that the panel scores the values. That fixes the loop and the persona weights. |
| 3. ashgrove credit union strategy and recent news | skipped | The July 2026 brief, as you summarised it, is under six months old and fixes the current priorities that CO and grounding rows use. |
| 4. interviewer name and ashgrove credit union | n/a | No interviewer has been named. There is no query to form. Section 7 is therefore absent. |
| 5. representative member services JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 15. Upgrade menu

- **The names of the Head of Member Services and the two branch managers** → persona weights per named person, and a reverse question about their own path.
- **Real examples for the four values** → B1, B5, C1 and C2 become mapped answers. Each sentence you confirm is quoted and graded.
- **A confirmed answer to the slots in B3, B6, C4 and C5** (a regulatory timescale or referral; a change with a team outside your branch; what the spreadsheet counts; a handover you know) → those rows move from slots to grounded lines.
- **Whether the spreadsheet was built in Excel** → F4's bridge names the tool once you confirm it. Nothing is added before then.
- **Whether the 20-minute case comes with written material before 4 December** → the case moves from structure-only to a rehearsal on that material.
- **Your prep time before 4 December** → a prep triage section with what to do first.
- **The strategy brief itself, not your summary** → the grounding brief quotes exact wording, and A4, C6 and C7 check against it.
- **Any contact-centre work, however small or adjacent** → F9 moves from capability to transferability, with the evidence you give.
