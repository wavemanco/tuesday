Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-4-denied-e6d5a539/049d645e-716e-4026-8f47-ae701e54b31c/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md.

Thursday is tomorrow (26 November), and the dossier is from 14 August. Check the posting still matches it before you rely on it.

The pack is built on the dossier alone. Web search was refused in this session, so the company's values, interview loop and current strategy are missing, and the pack says so where it matters. The interviewer isn't named, so there's no read on them.

The biggest risk is the objection that you've never held the PM title or owned a roadmap (question A1). The pack rehearses it most: a plain acknowledgment, then the integration work with its limit named, then a ramp plan. It's the one to practise out loud.

Say the word and I'll play the Skeptic on A1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday (26 November 2026).
**Interviewer:** not named. **Relationship:** hiring manager.
**Built from:** tuesday-dossier.md (conditional_go, generated 2026-08-14). No web research reached this pack; see Sources.
**First version.** No changelog.

## How to use, and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

- **JD**: the listed role's requirements or responsibilities
- **EXP**: your own work and how much of it was yours
- **CASE**: a live problem from the role, delivered in the interview
- **CO**: company knowledge (none in this pack; see Sources)
- **VAL**: behavioral or values (not detected in this round; see Persona table)

## Fit snapshot

Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says what kind of gap it is. Rows follow the dossier's requirement IDs (R1 to R5); F7 is a responsibility the dossier flags.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | R1 "3+ years product management experience" (dossier role_profile, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | The adjacent work is integration leadership from the client side of the vendor's APIs. It is not product-management experience and is never described as such. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Pack's observation, not words for you: the material shows adjacent work, not product-management years. |
| F2 | R1 sub-claim: owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 (medium, expect a probe) | none | [grounded] | capability | The dossier records no credible evidence of roadmap ownership or prioritization authority. The input sessions are the nearest thing, and they stop at feeding evidence to product. Plain acknowledgment, sourced by the dossier's prohibited_claims and acknowledge_gap: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the input sessions at their own scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." The ramp plan is a plan, never a past. |
| F3 | R2 "Shipped API or platform products" (dossier high_priority_requirements; not graded in the handoff) | E1, as quoted in F1 — dossier verified_candidate_evidence 1 | high | [inferred] | transferability | This grading is the pack's own derivation, because the underwriter's evidence map is not in the handoff. Client-side integration of someone else's API is adjacent to shipping a platform product; it shows the consuming end. Limit, named: nothing in the material shows a platform product shipped. Answer slot: if you shaped what the vendor shipped, say how, in your own words; if you did not, say so and say what the integrations needed from the platform. |
| F4 | R3 "Technical fluency: API docs, schemas" (important) | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 (high, inspectable) | high | [grounded] | discovery | The playbook covers the documentation side. The material does not show schemas. Answer slot: if you defined or reviewed a schema in the integrations or the playbook, say which and how; if you did not, say so and say what you worked from instead. |
| F5 | R4 "Stakeholder management across engineering, sales, customers" (important) | E1 as quoted in F1 — dossier verified 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3 | medium | [grounded] | transferability | Customer-side stakeholder work is in the material. Engineering and sales are not. Answer slot: if you worked with engineering or sales on any of those integrations, say who and what you did; if you did not, say so and stay with the customer side. |
| F6 | R5 "Agile delivery experience" (preferred) | none given: no verified entry speaks to it | low | [grounded] | discovery | The dossier's strategy for this area is clarify, so nothing is quoted. Answer slot, using the requirement's own words as the probe: if you have run sprints or another Agile cadence, name what you ran and your part; if you have not worked that way, say so, then say what you would want to confirm about how this team defines Agile delivery. |
| F7 | Responsibility: "Define and track adoption metrics" (role_profile; dossier risk: no current baseline stated) | none given | none | [grounded] | discovery | Nothing in the verified evidence touches adoption measurement. Answer slot: if you tracked usage or adoption of anything, name it and how it was counted; if you did not, say so and say how you would set a baseline first. |

## Prohibited claims

Built before the banks, and binding on every cell below. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims (absolute) | Plain acknowledgment, sourced by prohibited_claims: "I haven't held a product manager title or role." Pack's observation, not words for you: the dossier reads this gap as transferability, not capability, because the adjacent work is real. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | F2's plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | F2's plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Integration leadership as product management | Inflated form of F1 | F1's quote at its own scope. Limit, as the pack's analysis: the material says client integrations, not product work. |
| Running partner discovery | Inflated form of E1: "scoping, requirements" is client-side integration work, not partner discovery | E1 at its own scope. Limit, as the pack's analysis: the material does not show discovery with partners. |

## Persona table

Hiring manager is the relationship prior: Case/Strategist and Skeptic dominate, because they are buying capability and testing gaps. The dossier names the objection the Skeptic will press.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | The PM-title objection; Agile; client-side versus platform-side | 5 | Hiring-manager prior, and the dossier names the most predictable objection | Plain acknowledgment, then the bridge with its limit, then a ramp plan as a plan |
| Case/Strategist | Live problems from the role: discovery, an adoption drop, a squad disagreement, a sales-driven request | 5 | Hiring-manager prior; the dossier says the role's authority is unverified | Clarify, structure, state one assumption; invent no metrics |
| Data-Driven Prober | The 30+ figure, the schema, the adoption baseline | 3 | Mid weight: headline figures and the measurement gap are where a probe lands | Defend-the-number slots; say plainly what you do not know |
| Pressure | "Sixty seconds over a PM"; "how much was actually you" | 3 | Mid weight: composure under the title question | Hold the bridge through two follow-ups; concede the PM gap specifically |
| Conversational | The opener; what you have been looking at recently | 2 | Low weight, but touched so it is not new live | A 90-second arc; treat casual questions as scored |

Not weighted: Values/Behavioral, because no values-style round is detected (no loop source establishes the loop, and the fallback archetype reads no) and no company values were read. Peer, because this is a hiring-manager round. **Loop:** not established by any loop source, so the fallback archetype is Generic, with flat weights said plainly. The weights above rest on the hiring-manager relationship prior, not on this company's documented process.

## Question banks

Provenance comes first on each row. A Provenance cell carries every sentence the guidance rests on, quoted exactly.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier prohibited_claims: "Having held a product manager title or role"; "Having owned a product roadmap" | The highest-ROI rehearsal in this pack. Acknowledge first, in your words: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the bridge, its limit named: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I wrote the internal integration playbook. That is integration work from the client side, not product management." Then a ramp plan, as a plan: name the first two things you would do with the squad leads. Hold the bridge through two follow-ups. Concede the PM gap specifically; never fold on the integration work. | The dossier named this objection. Its negatives are sourced by prohibited_claims, so the question is asked as the underwriter wrote it. F1 and F2 are the evidence. |
| A2 | "Tell me about your Agile delivery experience inside a product organization." | JD | [grounded] requirement R5 from dossier role_profile: "Agile delivery experience"; no verified entry speaks to it | Clarify slot. If you have run sprints or another Agile cadence, name what you ran and your part. If you have not worked that way, say so, then say what you would want to confirm about how this team defines Agile delivery. | F6 is discovery, low, clarify. The question presupposes experience the material does not show, so its second branch allows that it never happened. |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier prohibited_claims: "Having owned a product roadmap" | Name the product side in one sentence, plainly: "I haven't owned a product roadmap, so roadmap calls are where I'd be slowest." Then the integration side, quoted from F1. Then one thing you would learn first from the squad leads. | Persona stem. The answer is A1's acknowledgment, shorter. |
| A4 | "You led 30+ client integrations. Which of those decisions were yours, and which belonged to the client or the vendor?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified 1) | Story-mapped on E1: the five phases are the beats the quote states. Say which phases you led, in your words, and where the client or vendor decided. Answer slot: if you made a scope or architecture decision, say which and how; if the client or vendor decided, say so and stay with what you did. | R2 attribution probe. The quote carries the phases; this question tests whether "led" holds phase by phase. |
| A5 | "Your work has been on the client side of integrations. Why should a platform team trust your roadmap calls?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified 1) | Use the client-side view as an asset: say what the integrations showed you about partner needs, in the quote's terms. Name the platform-side decisions you would need to learn, and how you would learn them. Do not claim platform decisions. | Skeptic on the relationship axis. The quote supports "client" and nothing more. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd start partner API discovery in your first 90 days. What do you need to know first?" | CASE | [generic] | Structure: clarify which partners and which decision discovery serves; objective; segment the partners; approach; metrics; risk. Think aloud and state one assumption. Claim no past experience with partner discovery. | Live problem from the JD responsibility "Run discovery with integration partners." |
| B2 | "Partner adoption of the API dropped 20% last quarter. Diagnose it." | CASE | [generic] | Clarify what "adoption" counts and whether the drop is in the number of partners or in their usage. Then segment, and check onboarding, documentation and breaking changes, in that order. Name the metric you would trust least. Do not assume a baseline exists. | Case stem on the JD's adoption responsibility. The dossier says no baseline is stated, so the answer assumes none. |
| B3 | "Two squads disagree on the next API release. Who decides, and how?" | CASE | [generic] | Name the decision owner you would expect and what you would need to confirm about that. Propose a decision rule rather than claiming authority. Name what you would take from the squad leads' side and what you would take to customers. | Covers R4 (engineering) and the squad-authority unknown. Hypothetical, so it asks about no past. |
| B4 | "Which roadmap decisions would you make alone, and which would belong to the squad leads?" | JD | [generic] | Answer with a proposal, not an authority claim: the two or three decisions you would want to own, the ones that stay with the squad leads, and the one thing you would need confirmed first. If you do not know yet, say so and ask. Do not say you have made roadmap or prioritization decisions. | The dossier flags decision authority as asserted in the JD and not evidenced. A proposal the interviewer can test is the honest answer. |
| B5 | "Sales wants a partner-specific API feature to close a deal. How do you decide?" | CASE | [generic] | Clarify the deal's value and what the feature would cost the other partners. Weigh it against the roadmap. Name who you would bring in (sales, engineering) and what you would decline. Claim no sales experience. | R4's sales side. F5 shows customer-side work only. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified 1) | Defend the number in your own words: how you counted, what the count is sensitive to (what counts as end-to-end), the assumption you would defend least, and which part was yours. Answer slot: if you counted from a list or tracker, name it; if the count is approximate or was not kept, say so plainly. | Headline figure, so the defend-the-number slot is mandatory. The pack supplies no counting method. |
| C2 | "Tell me about a partner integration where the API docs or schema caused trouble. How did you handle it?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified 2) | Open prompt: choose one integration. The playbook is the documentation side you can speak to. Name a schema problem only if one happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the playbook and what it covered. | R3. The schema side is not in the material (F4). |
| C3 | "How would you set an adoption baseline for a partner-facing API?" | JD | [generic] | Clarify what "adopted" means (active partners, live integrations, calls) and which you would measure first. Name the baseline's weakest assumption, and what you would not trust. Do not describe a baseline you have set. | The JD's adoption responsibility. Asked without presupposing a baseline, because the dossier says none is stated (F7). |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over a PM with three years of the job?" | JD | [grounded] "I haven't held a product manager title or role" (dossier prohibited_claims); "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified 1) | Pause, and restate the question in your head. One sentence on the title, plain. Then the integration work, quoted, and the ramp. Hold through two follow-ups; concede the roadmap gap specifically. Do not describe the integration work as product management. | Pressure stem, testing composure more than content. |
| D2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified 1) | Hold: "led" is what the material says. Name the phases you led in your words, and concede specifically where the work was shared. Never add a phase the quote does not carry. | R2 attribution under pressure. The held position is the quote itself. |
| D3 | "Two squad leads will work with you on delivery. Why would they take roadmap direction from someone without a PM title?" | JD | [grounded] "Having held a product manager title or role" (dossier prohibited_claims) | Hold: the ask is a proposal, not an authority you have. Name what you would bring them: the integration knowledge in the quote and the playbook. Concede that the roadmap call is theirs until it is agreed. Hold through two follow-ups. | Pressure on the squad-authority unknown. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey to this role." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; "Wrote the internal integration playbook her team uses" (dossier verified 1, 2) | A 90-second arc: the integration work in the quote's words, the playbook, one plain sentence on the PM title, then why this role. Do not invent a start point or a turning point. | Opener. Casual, but scored. |
| E2 | "What's the most interesting API-platform problem you've looked at recently?" | EXP | [generic] | Open prompt: pick a real one from your own work. If the nearest is an integration problem, say so. If there is none, say so plainly. Do not name a platform problem you did not work on. | Casual register, scored. The honest branch is built in. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years PM | A1, A3, D1, E1 |
| R1 sub-claim: roadmap authority | A1, B4, D3 |
| R2: shipped API or platform products | A4, A5, D2 |
| R3: API docs, schemas | C2 |
| R4: stakeholders (engineering, sales, customers) | B3, B5, A4 |
| R5: Agile delivery | A2 |
| Responsibility: run partner discovery | B1 |
| Responsibility: write specs and drive delivery with two squads | B3 |
| Responsibility: define and track adoption metrics | B2, C3 |
| Responsibility: own the roadmap | B4 |

Session total: 18 questions (5, 5, 3, 3, 2).

## Reverse questions

Each one is seeded from the dossier's employer questions or risks, or is generic. No interviewer profile exists, so none is tied to the interviewer's path.

| # | Question | Why it lands |
|---|---|---|
| R-Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's employer question. It tests the authority unknown, which decides whether the role fits you. |
| R-Q2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's employer question. No baseline is stated, so the answer tells you what you would inherit. |
| R-Q3 | "Where does the PM role sit relative to the two squad leads on delivery?" | The dossier's risk: decision authority is asserted in the JD and not evidenced. This asks it live. |
| R-Q4 | "What would make the first six months a success for this role?" | Sets the bar you will be measured against, in the interviewer's words. |
| R-Q5 | "Which partner discovery conversations are already on the calendar?" | Shows how much of the discovery work is new and how much is already running. |

## Sources

- **Provided document:** tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14, stage interviewing. Consumed: role_profile (satisfies the JD tier), handoff_to_mock_interview (verified evidence, weak areas, the objection, risks, employer questions, prohibited claims), and decision (context only: conditional_go). Not present: evidence_map, risk_register, evidence_state. The dossier is 3 months and 11 days old; the posting may have changed.
- **Searches sent** (the host refused each: web search permission was not granted; not retried):
  1. "Quartzline values": refused
  2. "Quartzline interview process product manager platform APIs": refused
  3. "Quartzline strategy recent news": refused
- **Fetches sent:** none.
- **Research tier:** L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet not produced: no published values in hand, and the search was refused |
| 2. Quartzline interview process, product manager | unavailable | Loop not established, so the fallback archetype (Generic) applies and the persona weights rest on the relationship prior alone |
| 3. Quartzline strategy and recent news | unavailable | Grounding brief absent; no CO questions grounded in current strategy |
| 4. Interviewer name and Quartzline | n/a | No name given, so no query could be formed |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the JD-based fit snapshot |

## Upgrade menu

- **The interviewer's name** → a read of their public background, persona weights tuned to them, and a reverse question tied to their own path.
- **Quartzline's published values page, or your recruiter's email naming the values or the interview format** → a values cheat sheet, and a named loop in place of the generic fallback.
- **Permission for web search** → targets 1 to 3 run: values, loop structure, current strategy. A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) is also available if you want it. Search was refused this session, so it needs that permission first.
- **The underwriter's full evidence map** → grades R2 from the underwriter's evidence instead of this pack's inference (F3).
- **Your CV** → stories beyond the dossier's three verified entries, and stronger grounding for F4 and F5.
- **The hours you have before Thursday** → a prioritized prep schedule, with the highest-value items first.
