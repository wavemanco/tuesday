# Live Operations Producer, Saltmarsh Games: interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager from his title; confirm with the question in the message. Format: 60 minutes, Friday.

Built on: the JD and your background, both from your message. No CV, no company research (web search was not permitted in this session, see Sources).

## How to use, and the type key

Personas describe how a question is asked. Types describe what it is scoring.

- **VAL**: behavioral and values alignment
- **EXP**: your past work, probed for whether it holds up
- **JD**: what the listed job asks for, gaps included
- **CO**: company and strategy knowledge (none in this pack, because no research ran)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Prep triage

Prep time is about two days (today is Wednesday).

1. **B1** (the two-titles objection). Rehearse it aloud, with its follow-ups, until it is boring. This is the highest-return prep in the pack.
2. **E1** (the 90-second arc). Build it only from your own sentences.
3. **A2 and A5** (the retention diagnosis and the post-event review). Write out the structure you would use, and say it aloud.
4. **D1 and D3** (the 60-second answer and the checklist question).
5. Bring the release checklist and, only if your studio's rules allow it, a redacted calendar. Check first; do not assume.

Everything else is insurance.

## Fit snapshot

Requirements are the JD's own words. Evidence is your message's own words, or the JD's, quoted exactly. Every row rests on your message alone, so confidence tops out at medium.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Years and studio are your words. Your material does not say the title ran as a live-service game. Answer slot: if the title's content and events ran live over time, say how, in your own words; if not, say so, and say which part of the live-service work you did do. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap; the quote already says it in role terms. Medium because it is a confirmed claim with limited inspectable proof, so expect a probe on how the calendar was built and run. |
| F3 | "Plan and run the live-events calendar for two mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | The quote reaches one title. The material is silent on a second. Answer slot: if you planned or ran a calendar for a second title, say which and what you decided; if not, say so, and say what from the weekly calendar would carry over and what you would have to learn. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given (your message gives no quote on this) | none | [grounded] | discovery | Your material does not show this. Answer slot: if you coordinated one of those four teams on an update, say which, and what you did and did not decide; if not, say so, and say how you would set that coordination up. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | The quote carries presenting numbers, not owning a review or the KPIs behind it. Answer slot: if you chose the KPIs or ran a post-event review, say which and what changed afterwards; if the numbers came from KPIs someone else set, say so. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Say it in the quote's own terms: you wrote the release checklist, and QA still uses it. Do not turn "wrote" into "managed". The checklist is an inspectable artifact, so this row rises when you can show it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | discovery | The quote touches the requirement without showing how deep your command of the numbers goes. Answer slot: say what the retention numbers told the studio head and what you did with them; if you did not work the numbers yourself, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Say it in the quote's own terms: the written checklist is in use by another team. |

The JD does not name in-app purchases or monetisation, so no row covers them. Your stated negative about in-app purchases is handled in the prohibited list and in B4.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. The pack's own observations sit in this analysis, not in words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and the KPIs | Inflated form of F5 | "Presented the monthly retention numbers to the studio head." The pack's observation: your material says presented, not owned. |
| Managed the release checklist with QA | Inflated form of F6 | "Wrote the release checklist our QA team still uses." The pack's observation: your material says wrote, not managed. |
| Ran calendars for two live titles | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title for the last two years." The pack's observation: one main title. |
| Ran a live-service title | Inflated form of F1 | "4 years as an associate producer at a puzzle-game studio." The pack's observation: the material says puzzle-game studio, not live-service. |
| "I haven't led a team." | Negative you stated: "Never led a team" | Plain acknowledgment, usable when asked about leading. No slot. |
| "I haven't worked on a game with in-app purchases." | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment, usable when asked about in-app purchases. No slot. |

## Persona table

Weights are a shown judgment. There is no loop source, so the loop is the generic archetype: flat weights, said plainly, and no values round detected. The relationship prior is hiring manager, from his title.

| Persona | How it shows up | Likelihood, and why | Counter-strategy | Questions |
|---|---|---|---|---|
| Case/Strategist | Live problems from the JD | High. A hiring manager buys capability and tests it on the actual job. | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. | 5 (A1 to A5) |
| Skeptic | Contrast with your background, and "why you" | High. The gaps are visible in the fit snapshot: two titles, live-service, coordination without having led a team. | Rehearse B1 until it is boring. Hold, then concede specifically. | 4 (B1 to B4) |
| Data-Driven Prober | Counting and attribution of your numbers | Medium. The retention line is the one place numbers come up, but no figure was given, so probes stay on method. | Say what you know about how the count was made. Say so when you do not know. | 3 (C1 to C3) |
| Pressure | Interruptions, time limits, challenges to attribution | Medium. Composure is tested most on the one-title point. | Pause, restate, hold through two follow-ups, then concede once. | 3 (D1 to D3) |
| Conversational | Casual openers on JD topics | Medium. Casual questions on the JD's topics are still scored. | Use the arc in E1 from your own sentences. Treat E2 as scored. | 2 (E1 to E2) |
| Peer Evaluator | Seams with design and engineering | Low. A peer persona in a manager round; it touches the coordination line only. | Propose seam principles, not a seam you have not run. | 2 (F1 to F2) |
| Values/Behavioral | Scenario probes on published values | Not weighted. No values round was detected, so there is no VAL bank. Behavioral probes sit in the Skeptic and Pressure banks. | None separately. | 0 |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two live titles and a calendar that is slipping. What do you need to know before you change anything?" | CASE | [generic] | Clarify first: which title is behind, what is committed to players and to the studio, and what each team can actually ship. Then objective, segmentation by title and player cohort, approach, the metric you would watch, and the risk you would name first. Say the structure aloud before using it. | The core live-ops question for this JD. Generic because no research ran and the inputs do not describe the role's calendar. No past is claimed. |
| A2 | "Day-7 retention drops fifteen percent after an update. Walk me through the diagnosis." | CASE | [generic] | Clarify: which update, which cohort, and when the drop started. Check release against a control, and check the release checklist's own steps first. Segment by cohort, and separate the update's effect from the calendar's. Name the metric you would defend and the assumption behind it. | The JD's retention and KPI lines, made live. Generic: presupposes nothing about your past. |
| A3 | "Walk me through how you would coordinate design, art, engineering and community on a single update." | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure the update as a sequence: who decides what, what each team needs and by when, and where community hears it. Answer slot: if you coordinated any of those four teams on an update, say which and what you did and did not decide; if not, say so and set out how you would run it. | F4's requirement, asked as a decision. The JD line is the raising source. The slot holds the honest branch. |
| A4 | "Community is pushing back on a nerf in the next update. Who do you talk to, in what order, and what do you decide yourself?" | CASE | [generic] | Map the stakeholders. Separate what is decided from what is input. Bring the metric the nerf is meant to move, and name the one point you would not give up to community. | Community sits on the JD's coordination line. A live problem, no past claimed. |
| A5 | "Own the post-event review and the KPIs it reports. Our reviews run long and nobody acts on them. How would you run one that changes the next event?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Structure: the question the review answers, the KPIs set before the event, one owner per action, and the decision the next event will make differently. Answer slot: if you ran a post-event review, say what changed afterwards; if not, say so and give the structure you would use. | F5's requirement, asked as a live problem. Type JD; delivered as CASE. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run the content-drop calendar for your studio's main title. This role plans live events across two mobile titles. Why would that carry over?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Plan and run the live-events calendar for two mobile titles" (JD) | Hold: the calendar's mechanics carry over, in your words: the weekly cadence, and the two years you ran it. Hold through two follow-ups by returning to that calendar. Concede plainly on the second title. Answer slot: if you have planned or run a calendar for a second title, say which and what you decided; if not, say so, and name the part of the weekly calendar you think carries over and the part you would have to learn. Never describe a second title you did not run. | The most predictable objection, born from F3, and where the material is thinnest. Deepest rehearsal. The question presupposes one main title, which the quote carries. Highest-ROI prep. |
| B2 | "Your background is a puzzle-game studio. Which parts of a live-service producer's job did your title actually have?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say what live operations your title had, in your own words. Answer slot: name the parts of the live-service job your title had, and the parts it did not. Do not stretch "puzzle" into "live-service". | F1's gap, as a contrast. The presupposition is the quote's own words. |
| B3 | "You haven't led a team, and this role coordinates four of them without authority. How do you get them moving?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Start with the plain acknowledgment: "I haven't led a team." Then answer from a coordination you actually did, if one exists. If none, say so, and say how you would get four teams moving: one written plan, shared dates, and the decision each team owns. Concede without folding on the coordination line. | F4 and your stated negative together: the likeliest pressure from a hiring manager. |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Answer with a plan, not a past: name the one line where your material is thinnest, then the first 30 days to close it. If monetisation comes up, the plain acknowledgment is: "I haven't worked on a game with in-app purchases." | An open persona stem. The answer is a ramp plan. The quote is the only thing your material says about monetisation. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you built the count, say how, in your own words; if you took the figures as given, say so, and say what you did with them. Do not reconstruct a method you cannot repeat. | F7's discovery gap. No figure was given, so no defend-the-number slot applies. |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you know an assumption behind the numbers, name it before they do. If you do not know how they were built, say that plainly. | The weakest-assumption move. The material carries no assumption, so the slot cannot name one. |
| C3 | "Walk me through the release checklist. What's on it, and how did QA use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what the checklist covers, in your words, and how QA works from it. Answer slot: if you can show the checklist, say so; if QA shaped its contents, say that too. | F6, rehearsed as a walkthrough. The premise is the quote's. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pause, then restate the question. Hold the calendar through two follow-ups. Concede the second title once, specifically. Answer slot: say what you have run and what you have not, in those words. | B1's point in one breath. The stem is a persona stem, not a claim about you. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: say what you presented. Answer slot: if you built the numbers, say so; if you presented work others built, say that, and say what your part was. Do not upgrade "presented" to "owned". | Pressure on attribution. |
| D3 | "You wrote the checklist, and QA uses it. How much of what's on it came from QA?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: you wrote it. Concede specifically where QA's input shaped it. Answer slot: if QA's input shaped it, say where; if it was yours alone, say so. | Hold-then-concede on authorship. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" (all your message) | A 90-second arc built only from those four sentences, in that order: the studio, the calendar, the checklist, the retention presentation. Say the two negatives (led a team; a game with in-app purchases) only if asked. | A casual opener, and scored. The arc is the quotes, with nothing added. |
| E2 | "What are you actually playing in live service these days?" | JD | [generic] | Name one live title you have actually played, and one thing its live operations did that you noticed. If you have not played one recently, say so. Do not invent a favourite. | Casual, on a JD topic, so scored. Generic: a question about the market, not your history. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam between your calendar and design's schedule, and what happens when you disagree?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Propose seam principles: who owns the date, who owns the content, and what gets escalated. Answer slot: if you have disagreed with a design or engineering lead about a date, say what you did; if not, say so, and say how you would settle one. | A peer probe on F4's line. No disagreement story is in the material. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the others in the work and say what you did. Never claim a result you cannot attribute. | A peer probe on credit-sharing. Generic. |

## Reverse questions

1. "What does a good first 90 days look like for whoever runs the calendar?" Why it lands: it shows you are planning for the job, not just the interview.
2. "Of the two titles, which one is further behind its calendar, and what is driving it?" Why it lands: it tests the B1 gap live and tells you where to start.
3. "Who decides the post-event KPIs: the studio, each title team, or the live ops lead?" Why it lands: it answers the F5 ownership question from the employer's side.
4. "What did the last update that missed its KPIs change in how the team works?" Why it lands: it shows you want the learning loop, not the post-mortem.
5. "How does the release checklist get updated when QA finds something new?" Why it lands: it opens the QA relationship, which is the process you would own.

## Sources

Provided documents: the JD and your background, both in your message. No CV was supplied.

Searches, all refused (web search was not permitted in this session):
- "Saltmarsh Games values": refused (target 1)
- "Saltmarsh Games interview process Live Operations Producer": refused (target 2)
- "Saltmarsh Games mobile game studio news strategy": refused (target 3)
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused (target 4)

Fetches: none.

Research tier: L1, searches 4 of 6 (all refused), fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have moved the values cheat sheet, which is dropped without it. |
| 2. Saltmarsh Games interview process | unavailable | Refused. Would have set the loop. Without it, the loop is the generic archetype. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Refused. Would have moved the CO bank, which is absent for now. |
| 4. Tobias Wrenfield public footprint | unavailable | Refused. Would have set the interviewer read and a tailored reverse question. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Round agenda, or the recruiter's note on focus areas → reweights the banks, and says whether a presentation or take-home is coming. If one is, I build a section for it.
- Web search access → company values, the interview loop, strategy, and Tobias's public background. The pack then gets a values cheat sheet, an interviewer read, and CO questions.
- Your CV → quotes from it stand beside your message's sentences. Right now every row rests on the message alone.
- The release checklist, or a redacted calendar, if your studio's rules allow you to show them → F2 and F6 rise on evidence you can show, and B1's hold gets a document to point at.
- Whether you planned or ran any calendar for a second title → rewrites F3 and B1, the two highest-ROI rows.
