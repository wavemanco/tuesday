# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV with no slides, then Q&A. Ross will push on commercials.

Built with no web research (see Sources). The fit snapshot rests on your message and the recruiter's words as you quoted them. Interviewer profiles were not read, so both personas are weighted from role priors.

## 2. How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: **EXP** work-experience deep-dive (does your history survive scrutiny). **JD** the role's stated requirements. **CO** company and strategy knowledge (generic here, since no research ran). **CASE** a live problem. **VAL** values (none detected, so no VAL questions).
- Provenance labels: **[grounded]** traceable to your message, the recruiter's words as you quoted them, or a cited source. **[inferred]** derived from a typical role or a reasonable extension of a grounded fact, with the derivation named. **[generic]** a role-family pattern with no claim about you or Kelverton.
- Guidance is scaffolding, not a script. Speak it in your own words.

## 3. Prep triage (about 4 hours)

1. **POV build, 75 min.** Write the three theses in section 5 and their concessions, then the operator close. Say it aloud, timed to 15 minutes, twice.
2. **Pressure set, 45 min.** B1, C1, C2, C4. Practise hold-then-concede with someone who will interrupt you.
3. **Commercials, 45 min.** C2, C4, D1, D2, D3. Be able to say, in your own words, how the £4M was counted, and where that record lives.
4. **Gaps and motivation, 30 min.** B2, B3, B4. Rail, channel transfer, why you are moving, and no quota.
5. **Opening and reverse questions, 15 min.** E1, then R1 to R5 chosen for what you want to learn.
6. **Everything else is insurance.** Leave about 30 minutes spare.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter, via your message) | "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows channel work with software partners, not operators. Say it in the quote's terms: running the ISV channel, at a payments company. The POV has to carry the channel mechanics across and say where they stop. Answer slot: if any of the channel's mechanics were operator-facing, say which; if none were, say so and say what you would test first. |
| F2 | "Please land on what it means for the operators themselves." (recruiter, via your message) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material puts you on the consultant's side of operators, planning their networks. It does not put you inside an operator's buying or commercial decisions. Keep the bridge at that scope: "I know the operator world from the other side" is your sentence. Answer slot: if you had any contact with how an operator decides on or pays for planning or scheduling tools, say what and when; if not, say so and say what you would ask them first. |
| F3 | "Ross will push on commercials." (recruiter, via your message) | "Never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | medium | [grounded] | capability | The stated absence is a direct quota, so the words are: "I haven't carried a direct quota." Then the revenue at its own scope: "roughly £4M of influenced revenue." The pack's observation, not words for you: the material gives influenced revenue, not revenue you closed or were measured on. Answer slot: if you can say how that figure was counted (which deals, which attribution rule), say it in your own words; if you cannot, say you would need the attribution report before quoting it. |
| F4 | "they sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't sold into rail specifically." Then the nearest material you have, at its own scope: the operator-side planning work (F2) and channel sales at a payments company (F1). Say how you would learn the buyer, as a plan and never as a past. |
| F5 | "Senior Partnerships Manager" (role title, your message) | "took it from 6 partners to 40" (your message); "9 years in partnerships" (your message) | medium | [grounded] | none | The quote already reaches partner-channel management at scale. Lead with the count in the quote's own terms, because a named record beats an adjective. Expect a probe on how the count was made (D2, D3). |

**Requirement coverage.** The JD was not supplied, so these are the requirements the recruiter named, plus one inferred from the company description (F4).

| Requirement | Covered by | Note |
|---|---|---|
| POV on operator partnerships over 18 months | Section 5, A1, A2, A3, E1 | none missing |
| What it means for the operators themselves | Section 5 close, A5, F2 | none missing |
| Commercials pushback from Ross | A4, C1, C2, C3, C4, D1 | none missing |
| Selling into rail (inferred from company description) | B1, B3, F4 | none missing |
| Partner-channel scale | D2, D3, E1 | none missing |

## 5. Graded deliverable: the 15-minute POV

**Recruiter's requested close:** "Please land on what it means for the operators themselves." Your POV ends on that, in operator terms.

**Facts to build on** (each from the fit snapshot, quoted exactly):
- F2: "bus and light rail network planning, so I know the operator world from the other side"
- F1: "running the ISV channel"
- F5: "took it from 6 partners to 40"

Every thesis below is a [generic] argument about partnerships with operators. None is a claim about Kelverton's product or market. Kelverton's market report was not in this conversation, so I cannot say which of these is the consensus answer. See the upgrade menu.

**Thesis 1 (generic).** Operators adopt a partner when it changes their planning cycle, not their vendor list. Concession: operators with strong in-house planning teams may need a partner less than the POV assumes, so the partnership has to earn its place against doing the work internally.

**Thesis 2 (generic).** The partnership's first job is to make an outcome the operator already reports on measurable. Concession: I do not yet know which outcome a given operator reports on. The first 90 days find that out; they do not assume it.

**Thesis 3 (generic).** Partner-led delivery beats direct-sales-led delivery for operators who already buy through integrators. Concession: I have never sold into rail (F4), so this is the thesis most likely to be wrong for reasons I cannot see from outside. Say so before anyone else does.

**Differentiation against the consensus answer.** Unavailable. The market report is the consensus answer for anyone who read it, and I have not read it. Paste its headings and I will mark each thesis against it.

**Anti-pick (generic).** I would not build an operator partner programme until one operator has agreed a joint plan with us. Saying no to the rest is part of the job.

**Suggested 15-minute shape (generic):** framing (about 2 minutes), three theses with concessions (about 6), the operator close (about 5), what you would test first (about 2). Do not add a fourth thesis to fill time.

**Rehearsal rule.** Speak only what you did, in your own words. Where a thesis needs an example from your past, use F2, F1 or F5 and nothing else.

## 8. Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa (hiring-manager prior); Ross (executive prior) | Live problems on operators, 18-month sequencing, what the operator's commercial side would need | High. The POV is itself a case, and a hiring manager buys capability and tests gaps | Clarify, then structure, then name the metric. Say the framework once, not for every question |
| Skeptic | Deepa | Probes the rail gap, the channel transfer and why you are moving | High. The rail gap (F4) is the largest unbridged gap, and hiring managers test it first | Plain acknowledgment on rail, then the operator-side knowledge at its scope. Hold through two follow-ups |
| Pressure | Ross | Interrupts on quota and on the £4M, time-boxes answers | High. The recruiter said he will push on commercials | Pause, restate, hold the position you can back, concede the quota gap specifically |
| Data-Driven Prober | Ross | Asks how the figures were counted and which part was yours | Medium to high. The £4M is the headline figure, and it is influenced, not closed | Name the scope of the figure, say what you know about its counting, say plainly what you do not know |
| Conversational | Deepa | Opens with a warm question about your journey | Medium. A panel's first question is often this, and it is scored | A 90-second arc from your own sentences, nothing added |
| Values/Behavioral, Peer Evaluator | none | none | Not weighted. No values round was detected, and no peer sits on the panel | Not applicable |

**Weighting, shown.** Relationship priors are the starting point: Deepa is a hiring manager, so Case and Skeptic lead. Ross has no stated relationship, so I used the executive prior (Case and Pressure), plus Prober because the recruiter named commercials. Depth follows weight: Case 5, Skeptic 4, Pressure 4, Prober 3, Conversational 2. No interviewer profile was read, so nothing about either person's career tilts these weights.

## 9. Question banks

### Case/Strategist (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An operator's planning team says the partnership has added work without changing anything they plan. What do you do?" | CASE | [generic] | Clarify which work, which team and which decision they are trying to make. Then what you would look at before changing anything. No claim about your past | A live problem from the POV's operator close. Scores clarify before structure |
| A2 | "Which operator would you start with, and why that one?" | CASE | [grounded] "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter, via your message) | Pick the selection rule before the name: who buys, who signs, who uses. Say which assumption you would test first | The POV's first beat. The interviewer will ask for a choice and the reason for it |
| A3 | "Sketch the first 18 months of operator partnerships. What happens in months one to three?" | CASE | [grounded] "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter, via your message) | Learn, then test, then scale. Name one thing you would not do yet | Matches the 18-month frame the recruiter set |
| A4 | "What would an operator's commercial director need to see before they signed a partnership?" | JD | [grounded] "Ross will push on commercials." (recruiter, via your message) | Describe the outcome in the operator's terms: what their finance team or their regulator would ask. Do not invent an operator's figures | Prepares the operator-side commercial answer before Ross pushes on it |
| A5 | "What does a partnership add for an operator that buying the product alone does not?" | CO | [generic] | Name what the partner adds, in operator outcomes: delivery, support, a joint plan. Say what you would need to know about the product before claiming more | CO is generic here because no research ran. This is the POV's differentiation question |

### Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never sold into rail. Why would an operator take a partnership call from you?" | EXP | [grounded] "Never sold into rail specifically" (your message); "bus and light rail network planning, so I know the operator world from the other side" (your message) | Highest-ROI prep in this pack. Plain acknowledgment: "I haven't sold into rail specifically." Then the operator-side work at its own scope. Hold through two follow-ups by returning to what the planning work gave you. Concede specifically what you do not know about how rail buys | F4 is the largest gap and this objection is near-certain. F2 carries the bridge's limit |
| B2 | "Four years of payments and ISV partners. What transfers to rail, and what does not?" | JD | [grounded] "running the ISV channel" (your message) | Name the channel mechanics you ran, in your words, and say which you do not expect to carry. Answer slot: if you designed any mechanic yourself, say which; if you ran a process someone else set, say that | F1 is the transferability gap. The second branch covers a channel run rather than designed |
| B3 | "Why leave a payments company you have been at for four years?" | EXP | [grounded] "last 4 at a payments company" (your message) | Answer slot: your material does not give the reason. Say your actual reason in your own words. Do not borrow one | A motivation probe. The material is silent on the reason, so the pack does not supply one |
| B4 | "You have never carried a quota. How will we know you are worth the cost?" | JD | [grounded] "Never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I haven't carried a direct quota." Then the measure you did have, at its own scope. Answer slot: say what your influenced-revenue work was measured against, if anything; if nothing, say so. Propose a 90-day measure as a plan, never as a past | F3 is a capability gap. The answer names the measure without claiming a target |

### Pressure (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why would we trust someone who has never carried a quota?" | JD | [grounded] "Never carried a direct quota" (your message); "took it from 6 partners to 40" (your message) | Pause. Restate the question. Plain acknowledgment on quota, then hold the position you can back: the channel grew from 6 partners to 40 with influenced revenue. Hold through two follow-ups. Concede the quota gap specifically, never the whole position | Ross pushes on commercials. A held position has to be one your quotes carry |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); "took it from 6 partners to 40" (your message) | Hold the scope of the quote: influenced revenue, not revenue you closed. Name which part was yours, in your own words. Answer slot: if you can say how it was counted, say it; if you cannot, say you would need the attribution report. Hold through two follow-ups. Concede specifically | Attribution honesty is the probe this figure invites. Highest-risk figure in the pack |
| C3 | "Give me the revenue case for one operator partnership, in one number." | CASE | [generic] | No figure is supplied here. The only figure you have given is portfolio-level (the £4M above), not per operator. Say what you would need to build a per-operator case, and which input you would defend least | Pressure on commercials at the operator level. The pack will not supply a number |
| C4 | "Would those partners have bought anyway, without the channel?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: did you track whether a partner would have bought without the channel? If you did, say how; if you did not, say so plainly. Do not claim the counterfactual was measured | Attribution is where influenced revenue is weakest. Expect it from Ross |

### Prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What is the difference between influenced and sourced revenue, and which did you report against?" | EXP | [grounded] "Never carried a direct quota, only influenced revenue" (your message) | Say which you reported against, in your words. Answer slot: if you did separate the two, say how; if you did not, say you reported influenced revenue and did not split it | A defend-the-number probe on attribution |
| D2 | "Walk me through how you got from 6 partners to 40. What was yours?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Tell the growth as the quote states it. Answer slot: if you set the criteria for who joined, say what they were; if the criteria were set before you arrived, say so | A probe on attribution of the growth itself |
| D3 | "What is the difference between a partner you signed and a partner that sold?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say what counted as an active partner, if the count separated signed from active. If the count was signed partners only, say that and say why it was used | Ross will test how the count was made, the same as D1 |

### Conversational (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting" (your message); "9 years in partnerships" (your message); "last 4 at a payments company" (your message) | A 90-second arc in this order: the transport consulting, then nine years in partnerships, the last four at the payments company. Each beat is a sentence you said. Do not add a reason for moving (B3) | Likely to be the opening question. Scored even though it sounds casual |
| E2 | "What would you want to be known for in your first year here?" | JD | [generic] | Answer from what you actually want, tied to the POV's operator close. Do not invent a motivation | Warm-up in a conversational register. The answer should match your POV |

Total: 18 questions. Requirement coverage is in section 4.

## 11. Reverse questions

Each is for you to ask, not a claim.

- **R1, to Deepa:** "What would a strong first 90 days look like to you in this role?" Why it lands: it tests your POV against her expectations before you present it, or in the follow-up.
- **R2, to Deepa:** "Which operator relationship today do you most want the next person to deepen?" Why it lands: it turns the rail and operator gap into a shared problem.
- **R3, to Ross:** "How does the partnership channel currently get credit for revenue in your commercial reporting?" Why it lands: you learn the attribution rule before he asks about yours (C2, D1).
- **R4, to Ross:** "Where do you expect operator commercial terms to be hardest to agree?" Why it lands: it shows you have already thought about the commercial pushback.
- **R5, to Deepa:** "What did the last person in this role get right, and what would you have them do differently?" Why it lands: it reveals the bar without asking for it directly.

No reverse question is tied to an interviewer's own career path, because no profile was read.

## 13. Prohibited claims

Each entry names its basis and its honest form. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" | Sourced: stated negative, "Never sold into rail specifically" | "I haven't sold into rail specifically." No slot |
| "I carried a quota" or "I hit my number" | Sourced: stated negative, "Never carried a direct quota" | "I haven't carried a direct quota." No slot |
| "I know operators from the inside" or "I have been on the operator side of the table" | Inflated form of F2 | "bus and light rail network planning, so I know the operator world from the other side," at its own scope. The pack's observation, in analysis: the material shows consulting to operators, not operating or buying |
| "I owned the revenue" or "I drove the £4M" | Inflated form of F3 | "roughly £4M of influenced revenue," at its own scope. The material says influenced, not owned |
| "I built the partner programme" | Inflated form of F5 | "took it from 6 partners to 40," at its own scope. Whether you designed the programme is an answer slot (D2), not a claim |

## 14. Sources

- **Provided documents:** your message (your background, and the recruiter's email as you quoted it). Kelverton's internal market report was not in this conversation and was not read.
- **Searches and fetches:** two searches were sent and both were refused, because search permission was not granted in this session:
  - "Kelverton Rail scheduling software train operating companies": refused
  - "UK rail operators technology partnerships 2026 train operating companies software strategy": refused

**Research tier: L0** (provided documents only; searches 0 of 6 run, fetches 0 of 2, host refused search)

| Target | Status | What it would have moved |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet (section 10). No values round is detected, so it would only have been added as a reference |
| 2. Kelverton interview process, partnerships | unavailable | Loop structure, and whether a values round exists. Persona weights rest on relationship priors because of this |
| 3. Kelverton strategy or recent news | unavailable | Grounding brief (section 6). CO questions are generic because of this |
| 4. Deepa and Ross, with Kelverton | unavailable | Reading the interviewers (section 7) and personalised reverse questions |
| 5. Representative partnerships JD | unavailable | Requirement list for the fit snapshot. The recruiter's named items are used instead |

## Upgrade menu

- Your CV, pasted as text → the fit snapshot quotes your CV rather than your message, so F1 and F5 can be checked against where your claims actually live.
- The role's job description → requirements become [grounded] rather than the recruiter's three items, and the coverage table and JD questions tighten.
- Kelverton's market report, as pasted headings and key points → the POV's theses can be differentiated against its consensus answer. Section 5 is currently unable to say which thesis is common.
- Public profiles for Deepa and Ross, or search allowed → personas weighted from their careers, and reverse questions tied to their own paths.
- The attribution report or method behind the £4M → C2, C4 and D1 move from answer slots to a quoted method.
- Search permission granted in a later session → re-runs targets 1 to 3 and 5 above, and may move the CO questions from generic to grounded.
