# Interview prep pack: Engineering Manager, Larkfield Systems

**Mode:** Loop (three scheduled rounds). One shared fit snapshot and sources block, then a mini-pack per round.
**Rounds:**
- Round 1, Tuesday, 45 min: hiring manager, Director of Engineering (your would-be boss)
- Round 2, Thursday after, 60 min: panel, two staff engineers and a product manager
- Round 3, the following Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

**Interviewer names:** not given. No interviewer read is included; personas come from round-type priors.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words, and rehearse only what you actually did.

- **VAL** — behavioral and values alignment: whether past behavior shows the values
- **EXP** — experience deep-dive: whether your claims hold up under scrutiny
- **JD** — role-driven: whether you can do the listed job, gaps included
- **CO** — company and strategy knowledge: this pack has none researched (see Sources)
- **CASE** — live problem: structure and reasoning on a problem from the role

Provenance labels: `[grounded]` traces to your own words or a supplied document. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about you or this company.

## Fit snapshot (shared across all three rounds)

The requirement quotes come from your role summary, the only role text in hand. Evidence quotes are your sentences, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of six, for three years, in payments. Bridge, in your words: "For three years I was a team lead of six." Two squads and device-management services are not in your material. Answer slot: if you have led work across more than one team, say what it was and how you ran it; if not, say so and say how you would organise two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote reaches hiring in role terms. Bridge: "I run our hiring loop for backend roles." Limit to keep: backend roles, and the 40 interviews are yours to state, not the role's 11 engineers. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | none | The quote reaches delivery under pressure. Bridge: keep it as said. The 60% is a figure you gave, so expect a probe on how it was counted (see A6, A7). |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message | none given | none | [grounded] | discovery | Growth is not in your material. Answer slot: name an engineer you grew and what changed for them, in your own words; if you have not grown anyone, say so and describe how you would work on growth across eleven. |
| F5 | "partner with hardware and product on roadmap" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | This is a negative you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. Nothing added to make it smaller. |
| F6 | Team structure: two squads may have their own leads, so this role may manage them — `[inferred]` from the role summary, not quoted | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Your stated negative: you have not managed managers. Words: "I've never managed managers." Whether the role manages leads is not in the role summary; confirm it before the rounds (see upgrade menu). |
| F7 | Location, on-site and travel pattern for this role — `[generic]`: hardware-adjacent engineering roles often carry an on-site pattern | none given | none | [generic] | hard_gate | Your material does not establish whether this role's location or on-site pattern fits you. This is a gate, so it is surfaced, not bridged. The one question asked about it is in the closing questions. |

Seven rules the columns enforce are in `references/output-template.md`. In short: each evidence cell is either "none given" or your own sentences, and nothing in the bridges adds a practice, figure or event you did not state.

## Prohibited list

Claims this pack will not coach, because your material does not carry them. Each names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment. No slot. |
| Managed managers | Negative you stated, F6 | "I've never managed managers." Plain acknowledgment. No slot. |
| Ran hiring for eleven engineers | Inflated form of F2: your quote is the backend loop | "I run our hiring loop for backend roles." |
| Cut on-call burden 60% | Inflated form of F3: your quote says the team's burden dropped after you pushed a reliability quarter through | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: your material does not say how much of the team's work was yours to name. |

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights, with reasoning:** a hiring manager relationship prior puts Skeptic and Case/Strategist first. They are buying capability and de-risking gaps, and the gaps in the fit snapshot (F5, F6) are where they will press. Skeptic leads (three questions), Case/Strategist (two), Prober (two), Conversational (one, as the opener). No interviewer profile, so no adjustment.

**Highest-ROI prep, named:** A2 and A3. The most predictable objection is the hardware-adjacent roadmap (F5). Rehearse the plain acknowledgment and the plan until it is boring.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | A 90-second arc, in your words: nine years of engineering, three as a team lead of six, now at a payments company. Stop there and let the next question come. | F1 is the arc's only quote. Casual openers are still scored. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Hold the position in one plain sentence: "I've never owned a hardware-adjacent roadmap." Concede it specifically, then say how you would learn it: a plan, not a past. Hold through two follow-ups by returning to the sentence, not adding to it. | F5 is the biggest gap and the highest-ROI rehearsal in this pack. |
| A3 | "I don't see hardware or managing managers in your background. How would you handle that in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment, both negatives: "I've never managed managers and never owned a hardware-adjacent roadmap." Then an answer slot: a first-90-days plan for closing each gap, stated as a plan. | F5 and F6 are both stated negatives, so the question can name them. |
| A4 | "Sketch how you'd approach your first 90 days leading two squads on device-management services. What do you need to know first?" | CASE | [generic] | Clarify first: what the squads own, what the hardware constraints are, what has shipped. Then objective, approach, metrics, risks. Think aloud and challenge one premise respectfully. | A live problem from the role. It asks about no past, so the guidance makes no claim about you. |
| A5 | "A device-management metric drops 20% in a month. Diagnose it." | CASE | [generic] | Name what you would check before anything else: whether the metric's definition changed. Then segment, then name a hypothesis, then say what would confirm or kill it. | Case structure is what this persona scores. |
| A6 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: how the figure was counted, in your own words. If you know the method, say it. If you do not know exactly how it was counted, say so plainly. Name which part was yours: pushing the quarter through. | F3 is the headline figure and the likeliest to be probed. Never explain a method you cannot repeat. |
| A7 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name, in your own words, the assumption you would defend least before they do: for example, whether other changes overlapped the quarter. If you cannot name one, say so. | A figure raises the weakest-assumption slot, and this is the move that turns a gotcha into a credibility gain. |
| A8 | "Tell me about a hiring decision you were uncertain about." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Open prompt: pick one decision from the loop. Say what the loop told you and what you did with the doubt. If no decision stands out, say so, then say how the loop handles disagreement. | F2 is the evidence, so this hiring question sits on your real loop, not on eleven engineers. |

**Reverse questions, Round 1:**
- "What would success look like for the two squads six months in?" — shows you think about roadmap ownership, not just hiring.
- "Where does hardware input reach your squads' planning today?" — tests the F5 seam and shows you are thinking about it.
- "How are the two squads set up today, and who leads each?" — checks F6 and invites the structure question.
- "What have the last two people in these squads needed most that they did not get?" — shows you care about growth, which F4 needs.
- "What should I have decided by day 30 for you to feel I'm on track?" — makes the director's expectations concrete.

## Round 2: Panel (two staff engineers and a product manager), Thursday, 60 min

**Persona weights, with reasoning:** a panel takes the top two personas of each member's relationship. The staff engineers are peers, so Peer Evaluator and Prober. The product manager is a cross-functional partner, so Case/Strategist and Skeptic. Peer Evaluator (two questions), Prober (two), Case/Strategist (two), Skeptic (one), Conversational (one). Names are not known, so personas are assigned by role, not by person.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Propose seam principles, not a claim to know the seam. Then the disagreement: the quote says you pushed a quarter through against pressure, so say who disagreed and how it resolved. Answer slot: if you disagreed with a peer team, say how it resolved; if there was no such disagreement, say so. | F3 is your disagreement evidence, and the seam is what peers probe. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "3 as a team lead of 6" — your message | Open prompt: pick one piece of work that spanned teams and say who did what, in your words. If none comes to mind, say so, then give the nearest thing your material carries. | Credit probes are how peers test for turf. Your material has only a team-lead scope to draw on. |
| B3 | "Walk me through what the on-call burden counts: pages, minutes, or incidents?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: the unit the figure was measured in, if you know it. If you do not, say so plainly. Then the assumption you would defend least. | A denominator probe on the same figure, asked by a different interviewer. |
| B4 | "How would you know a device-management service is healthier after a quarter like that?" | CASE | [generic] | Name measures before tooling: incident rate, time to recover, deploy safety. Say which you would trust least and why. | Probers test whether a figure is the right one, not only whether it is correct. |
| B5 | "We have a roadmap bet and reliability debt. Which do you fund this quarter, and why?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold the position your quote carries: reliability over roadmap pressure. Give the trade-off you actually faced. Hold through two follow-ups, then concede the cost explicitly: what the roadmap lost. Do not fold on the core claim to restore harmony. | Pressure from a product partner. Hold-then-concede, on the one position your material supports. |
| B6 | "Walk me through how you'd prioritise two squads' backlog with product." | JD | [generic] | Clarify first: what product commits to, what engineering owns, where the two disagree. Then a simple prioritisation rule, stated out loud. | A roadmap question from the product seat. It asks about no past, so there is no claim about you. |
| B7 | "Hardware dependencies drive our roadmap. What have you shaped on a roadmap you did not own?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then an answer slot: the nearest roadmap you did shape, in your own words, if any. Do not name a hardware roadmap you did not own. | F5 from the product seat. The honest version is the acknowledgment plus the nearest thing. |
| B8 | "What part of backend hiring would you bring to two new squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Say what the loop did, in your words, and what carries across to new squads. Do not claim ownership of a hiring function you did not run. | F2 is the only hiring evidence. Low weight: a casual opener about a hot JD topic is still scored. |

**Reverse questions, Round 2:**
- "What could a new person do in their first month that would genuinely help your team?" — the reciprocity question a peer panel expects. It converts an interview into a working conversation.
- "Where is the biggest technical debt in the device-management services today?" — shows you are thinking about the squads' pain, from the staff seat.
- "How does product choose between a reliability quarter and a roadmap item today?" — tests roadmap pressure from the product seat.
- "Which hardware engineer would I need to meet in the first month?" — shows you already see the seam.

## Round 3: VP Engineering, the following Monday, 30 min

**Persona weights, with reasoning:** the recruiter named this round "values and leadership philosophy", which makes it a values-style round. The executive prior adds Case/Strategist and Pressure. Values/Behavioral leads (three questions), Pressure (two), Case/Strategist (two), Conversational (one). Strategy-heavy questions are generic, because no strategy brief was researched (see Sources).

**Values section:** the company's published values are not in hand, so the values cheat sheet is not built. C1 to C3 use stories from your material where a sentence carries one, and selection scaffolds where none does. Paste the published values to get the cheat sheet.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Story map from the one sentence that carries a story. Beats: the roadmap pressure, the quarter you pushed through, the 60% that followed. Answer slot: what you told leadership and how they responded, in your words. If the truth did not land, say so; do not supply an ending. | The sentence is the story's only spine. Do not add a conversation you did not state. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a user-facing outcome beat an internal number. If none comes to mind, say so plainly, then say whether the reliability quarter had a user-facing effect you saw. | Your material carries no customer story, so this is a scaffold with its honest branch. |
| C3 | "What is your leadership philosophy in one sentence, and where has it cost you?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Give the philosophy in your own words. For the cost, use the plain acknowledgment: "I've never managed managers." Do not claim managing managers as a cost you paid. | The VP is probing self-awareness. The stated negative is the honest cost. |
| C4 | "How would you explain the device-management strategy to the board in two minutes?" | CO | [generic] | No strategy is researched, so say what you would learn first: the company's current priorities and the device-management bet. Then a two-minute frame, stated as a frame, not a fact about Larkfield. | Altitude question. Generic by necessity, and labelled so. |
| C5 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Hold the position the sentence carries: nine years, three as a team lead, a payments company. Concede the limits: not two squads, no hardware roadmap. Hold through two follow-ups. | The pressure stem. Do not fold on the core claim. |
| C6 | "That result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: say what you pushed and what the team did, in your own words. Hold that you pushed the quarter through. If the team carried most of the work, concede it plainly. | Attribution is the probe. Honest attribution is the answer. |
| C7 | "Sketch how you'd set up two squads' reliability and roadmap rhythm in the first quarter." | CASE | [generic] | Clarify first, then propose a rhythm and say what would make you change it. No claim about your past. | A live problem from the role, at the VP's altitude. |
| C8 | "What did you learn leading six that changes how you'd lead eleven?" | VAL | [grounded] "3 as a team lead of 6" — your message | Name the change in your own words. Your material shows a team of six; eleven is the role's scale, not your experience. Do not say you have led eleven. | The scale jump is the VP's likely probe. Honest scale only. |

**Reverse questions, Round 3:**
- "How do you define a good engineering manager here, and how do you know one?" — values-led, and it shows you want the standard, not just the job.
- "Where have you seen the hardware, product and engineering seam go wrong?" — the VP's own seam, asked as a question.
- "What would you want the next six months to have proven?" — makes the expectations concrete for the next conversation.

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

Queries sent, with outcomes:
- "Larkfield Systems values" — refused
- "Larkfield Systems interview process engineering manager" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, section 10: dropped, because no published values are in hand. The round three values stories are scaffolds (C1 to C3). |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure: the three rounds come from your message and the recruiter's words, not a published loop. |
| 3. Larkfield Systems strategy / recent news | unavailable | CO bank: C4 stays generic. No call was sent, and the host search was refused for the other targets. |
| 4. Interviewer name + Larkfield | n/a | No names given, so there was no query to form. The interviewer read is absent. |
| 5. Representative Engineering Manager JD | unavailable | A representative JD would have marked requirements `[inferred]`. Your role summary is not full JD text, so requirement quotes come from it, not from a JD. |

## Upgrade menu

- Full JD text, pasted → requirement quotes in F1 to F7 become exact JD lines, and F7's gate gets its source. Without it, requirements are quoted from your role summary.
- Larkfield's published values, pasted → the values cheat sheet, and C1 to C3 gain mapped stories where a sentence of yours carries one.
- Larkfield's loop or the recruiter's round details, pasted → the round personas and round-level bank counts are checked against the real format.
- Interviewer names → persona weights from their public footprint, and at least one reverse question tied to each interviewer's own path.
- Larkfield strategy brief, pasted or from a deeper research pass → the CO bank (C4) is grounded in current priorities.
- Whether the role manages leads → F6 moves from `[inferred]` to a stated requirement.
- `tuesday-dossier.md` — a file that carries the gaps this prep exposed into later sessions. With none present, it adds verified leads for the next pass.
