# Interview prep pack: Operations Manager, Atlas Freight

**Changelog:** first version. Built for a hiring-manager round, since the round type and who you are meeting were not given. No web research ran (search permission was refused), so company values and strategy are not covered.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: EXP (your past work), JD (the listed job), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds.
- Anything in *italics after "Answer slot"* is an instruction for the interview, not a question for me.

## Persona table

Weights follow the hiring-manager prior: they are buying capability and checking the gaps. Adjust once you tell me the round.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operations problems on four sites and cost per shipment | High. The JD is operational, so a hiring manager tests this first | Clarify, then segment by site and shift before you recommend anything |
| Skeptic | Probes the 3-to-12 supervisor jump, the years of leadership, and Power BI | High. Your fit snapshot has three gaps this persona will find | Rehearse the span question until it is routine; say the unknown plainly |
| Data-Driven Prober | Asks how the 40% was counted and what was yours | Medium. You quoted one headline figure | Name the weakest assumption before they do |
| Pressure / Stress | Challenges "why you" and how much was really you | Medium. A hiring manager may press on scale | Pause, restate, hold two follow-ups, then concede only what is true |
| Conversational / Rapport | Opens with "walk me through your background" | Low to medium. Usually a warm-up, but scored | Give a 90-second arc from your own sentences |

## Fit snapshot

Requirements are quoted from the JD text you pasted. Evidence is quoted from your message, and nothing else is in the evidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows one site, at shift-manager level. Answer slot: how you would run daily operations across four sites. If you have run a routine across more than one site, say which. If not, say so and say how you would set it up. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [grounded] | discovery | Your material does not show on-time or cost-per-shipment figures. Answer slot: if you tracked either, say what and how it moved. If not, say so and name what you would measure first. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors. Answer slot: how you would lead twelve. If you have led a larger group, say which. If three is the largest, say so and say how you would scale your routine. |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [grounded] | discovery | Your material says seven years in operations. Leadership years are not stated. Answer slot: how many of those years were in a leadership role, and when it began. If fewer than five, say so and anchor on the operations years. |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | medium | [grounded] | discovery | Your material says Excel, not reports you built in it. Answer slot: which Excel reports you have built and who used them. If none, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. Expect a probe on what the certification was applied to. |

Seven things to keep in mind:

- The evidence column holds only your sentences. Anything the pack says about your past is one of those sentences, a plain acknowledgment, or an answer slot.
- F6 is the one plain negative you gave. The words "I've never used Power BI" are yours, so the pack may give them back.
- The Excel and Power BI row is split because "solid Excel" does not show reporting.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and no answer should assert them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | "currently a senior shift manager over 3 supervisors"; your material shows one site |
| Owned on-time and cost-per-shipment results | Inflated form of F2 | The material shows no such figures; the answer slot in F2 is the only route |
| Leads twelve supervisors | Inflated form of F3 | Three supervisors, as quoted |
| Has five-plus years of operations leadership | Inflated form of F4 | Seven years in operations, as quoted; leadership years are a slot |
| Has built Power BI reports | Negative you stated, F6 | "I've never used Power BI." No slot |

## Question banks

Eighteen questions in total. Weights: Case 5, Skeptic 5, Prober 3, Pressure 3, Conversational 2.

### A. Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four sites are running at different on-time rates. Where do you start in your first 30 days?" | CASE | [generic] | Clarify which measure matters most and which site is furthest off. Set the objective. Segment by site, shift and lane before you act. Name one risk. | Live problem from the four-site scope and the on-time requirement. No claim about your past. |
| A2 | "On-time dropped eight points at one site last month. Diagnose it." | CASE | [generic] | Ask for the cut: which shift, which lane, which dock. Form a hypothesis and say what would disprove it. | Tests the on-time requirement in the form the role asks for. |
| A3 | "Cost per shipment is up while volume is flat. What do you look at first?" | CASE | [generic] | Split cost into labour, transport and handling. Ask what changed in the same period. Say which number you would trust least. | Tests the cost-per-shipment requirement. |
| A4 | "How would you run a daily operations review across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | If you run a daily routine with your three supervisors, describe it in your own words. Answer slot: how you would carry that routine to four sites. If you have run a routine across more than one site, say which. If not, say so and say how you would set it up. | Covers the daily-operations requirement. F1 is the evidence and the likeliest probe. |
| A5 | "How would you lead twelve supervisors when you manage three today?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Say what you do with your three today, in your own words. Answer slot: what would change at twelve, and whether you have set supervisor standards across a larger group. If not, say so. | Covers the team-of-12 requirement. F3 is the evidence. |

### B. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors today. What breaks first at twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | **Highest-ROI prep in this pack.** Hold one named failure point, reasoned from your three. Hold through two follow-ups by returning to what you have run. Concede where your material is silent: "I haven't managed a span that large." Answer slot: if you have seen a span grow, say what happened. If not, say so and say what you would watch first. | F3 is the single most likely objection. The thin material is exactly where a pack is tempted to add detail, so the rehearsal keeps to the quote. |
| B2 | "The role asks for five-plus years of operations leadership. How many have you led?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | Start with the seven years, as quoted. Then give the leadership count in your own words. Answer slot: when your first leadership role began. If fewer than five, say so and anchor on the seven years. | F4. The requirement is a length-of-experience line, so it is graded on fit, not treated as a gate. |
| B3 | "Power BI is in the role's reporting. Where have you used it?" | JD | [grounded] "never used Power BI" — your message | Say it plainly: "I've never used Power BI." Then name the Excel you have used. Then how you would learn it, as a plan. | F6. The honest answer is the plain line, and it comes first. |
| B4 | "What have you built in Excel that someone relied on to make a decision?" | JD | [grounded] "solid Excel" — your message | Name the report, its audience and the decision it fed, in your own words. Answer slot: if you built none that a manager used, say so and say what you would build first. | F5. "Solid Excel" does not show reporting, so the answer slot does the work. |
| B5 | "What is a Green Belt for, and what would you apply it to here?" | JD | [grounded] "green belt certified" — your message | Say you are Green Belt certified. Name one process you would apply it to here. Hold to what you have done. If the certification was never applied, say so. | F7. Lean/Six Sigma is a plus, and a probe is likely. |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Defend the number: how it was counted, what it is sensitive to, and the assumption you would defend least. Answer slot: if you did this, say how, in your own words. If you do not know how it was counted, say so plainly. | Headline metric. Magnet for probers. |
| C2 | "Which part of that 40% came from the pick path redesign, and which would you not credit to it?" | EXP | [grounded] "by redesigning the pick path" — your message | Attribution. State the redesign as your sentence has it. If other changes were made in the same period, name them. If you cannot separate them, say so. | Tests what was actually yours. |
| C3 | "What did the peak-season surge plan do to on-time performance, if anything, and how would you know?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Say what you ran and for how long, in those words. Answer slot: if you measured an outcome, name the measure. If you did not, say so plainly. | Connects to F2. The surge plan is quoted, but no on-time figure is. |

### D. Pressure / Stress (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run more sites than you?" | JD | [generic] | Pause. Restate the question. Anchor in what you have run. Hold the position for two follow-ups, then concede the span gap without folding. | Pressure on F1 and F3. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold the part your sentence says: you cut the mis-pick rate. Concede what your material does not show. Answer slot: whether you designed the redesign or led it. | Pressure on the headline number. |
| D3 | "You've been a shift manager. Why is a site operations manager a step you're ready for?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Name what carries across, from the shift you run. Concede the part your material does not show. Answer slot: what you would need to learn in your first 90 days, said as a plan. | Motivation under pressure. F1 and F4. |

### E. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your seven years in warehouse and distribution." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message | A 90-second arc in the order your own sentences give: warehouse and distribution, then senior shift manager. Do not add a stage your material does not give. | Casual openers are scored too. |
| E2 | "How would you approach building operations reporting in Power BI, given where you are with it?" | JD | [grounded] "never used Power BI" — your message | Say it plainly first: "I've never used Power BI." Then the Excel you have used. Then how you would learn it, as a plan. | F6 in a friendly register. Same honest line as B3. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A4, B1, D1 |
| Drive on-time performance and cost-per-shipment down | A2, A3, C3 |
| Lead a team of 12 supervisors | A5, B1, D1 |
| Build reporting in Excel/Power BI | B3, B4, E2 |
| 5+ years operations leadership required | B2, D3 |
| Lean/Six Sigma a plus | B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a new operations manager's first 90 days look like across the four sites?" | Shows you are planning for the scope, not just the title. |
| R2 | "Which site is furthest from its on-time and cost-per-shipment targets right now, and why?" | Shows you think in the job's own measures. |
| R3 | "How is operations reporting built today: from the warehouse system, in Excel, or somewhere else?" | Tests the reporting gap without claiming you know Power BI. |
| R4 | "How are the twelve supervisors split across the sites, and how long have they been in post?" | Shows you understand span and tenure. |
| R5 | "What would make someone in this role clearly successful at six months?" | Gives you their success criteria in their words. |

## Prohibited claims check

Every line above was built from the quotes in the fit snapshot. None asserts the five prohibited claims.

## Sources

- **Provided documents:** your message (background summary) and the JD text as pasted in your request.
- **Searches sent, both refused by the host's permission:**
  - "Atlas Freight regional logistics company values operations": refused
  - "Atlas Freight operations manager interview process": refused

**Research tier:** L1 — searches 0 of 6, fetches 0 of 2 (both searches refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section 10). Not built, because no values-style round was detected. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure and persona weights. The hiring-manager prior was used instead. |
| 3. Atlas Freight strategy / recent news | unavailable | Company-strategy and CO questions. None are in this pack. |
| 4. Interviewer name | n/a | No name was given. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Who you are meeting and the round type → persona weights confirmed or reweighted, and a tailored reverse question.
- The Excel reports you have built, with who used them → F5 and B4 become a story-mapped answer, in your words.
- Your leadership start date → F4 and B2 become a grounded answer, not a slot.
- The on-time and cost-per-shipment figures you have, or can recall → F2 becomes a grounded row.
- The recruiter's prep email → coverage of any case or presentation they named.
- The interviewer's name → an interviewer read and a tailored reverse question.
- Web search permission → L1 research on Atlas Freight's values, interview loop and strategy; this run's searches were refused.
