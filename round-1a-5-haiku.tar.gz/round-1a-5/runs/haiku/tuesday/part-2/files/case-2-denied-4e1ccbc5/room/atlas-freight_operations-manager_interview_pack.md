# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (daily terminal operations, 4 sites, 12 supervisors)
**Company:** Atlas Freight (regional logistics, about 800 employees), as stated in your JD summary
**Interviewer:** not known. Round type and relationship not given.
**Built on:** your message and the JD summary you pasted. No company research ran (web search was not permitted in this session), so every statement about Atlas itself is `[generic]`.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

- **JD**: can you do the listed job, gaps included
- **EXP**: do your past claims survive scrutiny
- **VAL**: does past behaviour show the values (none detected here)
- **CO**: company knowledge (no research ran, so none asked)
- **CASE**: a live problem, structured out loud

Sections for graded deliverables, company brief, interviewer read, values cheat sheet and delivery coaching are dropped: none applies to what you have given me so far.

Weights are flat, because the round type is unknown: a generic screen, hiring manager and panel loop. The weights would shift if you tell me who you are meeting.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD, as you pasted it) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one shift with three supervisors, not four sites or a terminal. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have set or run a daily plan beyond one shift or site, say which and how; if not, say so, and say how you would learn four sites in your first month. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your result is a different measure: mis-pick rate, not on-time or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time or cost per shipment, name the figure and how it was counted; if you have not, say so and say what you would baseline first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three is a real leadership scope, and it is not twelve. Words: "I lead three supervisors." Answer slot: if you have led a larger group, say how many and how; if not, say so, and say how you would lead twelve across four sites. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | presentation | Your quote carries the seven years, not how many were leadership. Words: "I have seven years in warehouse and distribution operations." Answer slot: state how many of those years you have led people, in your own words; if fewer than five, say so and say when your leadership started. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | transferability | Excel skill is stated, but no report you built is. Words: "I'm solid in Excel." Answer slot: name a report you built in Excel, who used it, and what it changed; if you have none, say so. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | A tool you have not used. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. No claim to Power BI work. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Covered by the certification. Words: "I'm Green Belt certified." Expect a probe on applied projects; answer that in your own words, and only what you led. |

Rules applied: Gap type follows the evidence cell. F6 is `capability` because you stated the absence. F1 to F5 are not gates, since none is a licence, credential or legal term.

## Prohibited claims

Not coached, and why. Each is the stretched form of a sentence you did say, except the Power BI line, which is your own negative.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across 4 sites | Inflated form of F1 | "a senior shift manager over three supervisors." The limit is my observation: your material says one shift, not four sites. |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | "cut the mis-pick rate 40% by redesigning the pick path." |
| Led 12 supervisors | Inflated form of F3 | "I lead three supervisors." |
| Built Power BI reporting or has Power BI skills | Your own negative, F6 | "I haven't used Power BI." |
| Owned Six Sigma projects | Inflated form of F7 | "green belt certified" only. |
| The 40% was site-wide, or you ran the whole site's mis-pick programme | Scope inflation of your sentence | The 40% at the scope you stated. The baseline and period are not in your material. |

## Question banks

Each bank is ordered by weight. Depth: the top persona gets four questions, the others two or three.

### Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "This role runs daily operations across four sites, and you lead three supervisors today. What makes the jump work?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD "Own daily terminal operations across 4 sites" | Bridge from the three-supervisor scope you have, in your words. Answer slot: if you have set or run a daily plan beyond one shift or site, say which and how; if not, say so, and say how you would learn the four sites first. | F1 and F3 are the scope gap, and this is where it will be put to you directly. |
| S2 | "Which on-time or cost-per-shipment figure have you moved yourself?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); JD "drive on-time performance and cost-per-shipment down" | Hold the mis-pick result at its own measure: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you moved one of the two, name it and how it was counted; if you have not, say so plainly and say what you would baseline first. | F2 is the requirement the role is hired for, and the one with no figure in your material. |
| S3 | "The role builds reporting in Power BI. What's your experience there?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Plain acknowledgment: "I haven't used Power BI." Then pivot to what you have: Excel, in your own words. Then your plan to learn it, as a plan. | F6 is your stated absence, and the interviewer will test whether you claim more than you have. |
| S4 | "Five-plus years of operations leadership is required. How much of your seven years was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Highest-ROI prep in this pack. Say how many years you have led people, in your own words. Answer slot: if fewer than five, say so and say when your leadership started. Hold a true number through two follow-ups, then concede any year you cannot support. | F4 is the hard-requirement line and the one most likely to be asked first in some form. |

### Data-Driven Prober (weight: high, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number. Say how the baseline and period were measured, in your own words. Name the weakest assumption you would defend least. Answer slot: if you do not recall how it was counted, say so. Say what you changed in the pick path. | The headline figure is the one number on your side, and probers go to it first. |
| P2 | "What else could explain a 40% drop besides your redesign?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the confounder you know of, in your own words, before they do. If you know of none, say you have not separated the redesign's share from anything else. | Tests whether you know your own assumptions. Nothing is supplied for you. |
| P3 | "How would you find the on-time and cost-per-shipment baseline across four sites in your first month?" | CASE | [generic] | Structure it: agree the definitions, pull data per site, check the data source, then segment before you conclude. No claim about your past. | JD line on on-time and cost, asked as a method. |

### Case / Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one site dropped eight points last month. Diagnose it." | CASE | [generic] | Clarify definition and period first. Then segment by shift, lane, volume and staffing. Name the data you would check before the cause. Speak the structure aloud. | A live problem on the role's own metric. |
| C2 | "You have twelve supervisors across four sites, and two are underperforming. What do you do in week one?" | CASE | [generic] | Clarify which two and on what measure. Then talk to them and their sites before changing anything. Name what you would not do yet. | JD line on leading twelve, asked as a decision. |
| C3 | "Peak season is six weeks away across four sites. What's your first week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message); JD "4 sites" | Story map from the quote: the surge plan, run two seasons. Name what it covered and which parts were yours to set. Answer slot: if you set part of the plan, say which; if not, say so and stay with what you ran. | A strong prep area for you, since the plan is on your CV. Keep it to what you ran. |

### Pressure / Stress (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pr1 | "Sixty seconds: why you, over someone who has already run multiple sites?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold what you have done, and say it in one sentence. Concede multi-site explicitly, and do not fold on the 40%. | A stress stem on the scope gap. |
| Pr2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold your decision on the redesign. Name who else worked on it, in your own words. Concede what you cannot attribute. | Tests honest attribution under pressure. |
| Pr3 | "You lead three supervisors today. What changes at twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD "lead a team of 12 supervisors" | Hold the part you can defend, and concede the scale change plainly. Answer the scale question as a plan, not as a past. | Same gap as S1, under time pressure. |

### Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Cv1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc from warehouse ops to shift management, using only those two facts. | The opener is scored too. |
| Cv2 | "Where does Power BI fit in how you'd build reporting here?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | "I haven't used Power BI." Then how you would build the reporting in Excel first, and how you'd learn the tool. | Casual register, same gap as S3. |

### Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pe1 | "Your supervisors and the reporting team will share data. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles, such as one shared definition and one owner per number. Do not claim to know their seam. | A peer probe on the reporting requirement. |
| Pe2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the people involved in the pick-path work, in your words, and what each did. | Credit probes follow your best result. |

### Values / Behavioural (weight: low, 2 questions; no values round detected)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear, with a named stake. If none comes to mind, say so plainly, then give the nearest thing you have. | Kept small, since no values round is known. |
| V2 | "Tell me about a process change that did not land with the team. What did you do?" | VAL | [generic] | Pick a real change that stalled, what you did next, and what you would do differently. | As V1. |

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Daily terminal operations across 4 sites | S1, C2, C3, Pr3 | |
| On-time performance and cost-per-shipment | S2, P1, P2, P3, C1 | |
| Lead a team of 12 supervisors | S1, C2, Pr3 | |
| Reporting in Excel/Power BI | S3, Cv2, Pe1 | |
| 5+ years operations leadership | S4 | |
| Lean/Six Sigma a plus | none, and why | Covered by F7 with no gap, so no question is needed. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Hits the 5+ years and Power BI gaps | High: a hard experience line and a stated tool gap | Rehearse S4 until it is plain. Hold true numbers, concede the rest | 4 |
| Data-Driven Prober | Goes to the 40% | High: it is the one headline figure | Say how it was counted, and name your weakest assumption | 3 |
| Case / Strategist | Live site problems | Medium: ops manager roles are scored on live problems | Clarify, segment, then speak the structure | 3 |
| Pressure / Stress | "Why you?" and "how much was you?" | Medium: common in senior ops; not evidenced for this employer | Hold, then concede specifically | 3 |
| Conversational | The journey opener | Medium: a common opener | A 90-second arc from your own facts | 2 |
| Peer Evaluator | The reporting seam | Low to medium: only if one of the rounds is a peer | Propose seam principles, not a claimed seam | 2 |
| Values / Behavioural | STAR stories | Low to medium: no values round detected | Pick a real story, or say so | 2 |

## Reverse questions

Each has a one-line reason it lands.

1. "What does on-time performance look like across the four sites right now, and where is the gap?" Lands because it shows you are planning on their numbers.
2. "How is reporting built today, and who uses it?" Lands because it asks about the Excel and Power BI work directly.
3. "What did the last person in this role leave undone?" Lands because it signals you expect to own the job.
4. "How are the twelve supervisors split across sites, and who is newest?" Lands because it shows you are thinking about the team you would lead.
5. "What does success look like at the end of the first ninety days?" Lands because it gives you their definition to plan against.
6. "How does the peak-season plan work: is it rewritten each year, or carried over?" Lands because it links to your surge-plan experience.

## Sources

Research tier: L0. Web search was not permitted in this session, so no company research ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, which is dropped. Search refused: "Atlas Freight regional logistics company values". |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights, which stay flat. Search refused: "Atlas Freight operations manager interview process". |
| 3. Atlas Freight strategy or recent news | unavailable | Would have moved the CO questions, which are absent. No search sent. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative JD | skipped | The JD summary you pasted fixes the fit snapshot. |

Provided documents: your message, including the JD summary you pasted. No CV file and no dossier were provided.

## Upgrade menu

- The full JD text → turns the JD summary into quoted requirements, and makes the JD questions `[grounded]`
- Who you are meeting, and their round type → reweights the personas and retunes the reverse questions
- The interviewer's name → a reverse question tied to their career path, and persona weights from their public footprint
- A recruiter email on focus areas and any pre-declared exercise → coverage of anything they name
- Atlas's published values page → a values cheat sheet, with the values' own names
- Permission for web search → company values, loop structure and current strategy, so the CO questions are grounded
- Your on-time, cost-per-shipment or peak-volume figures → upgrades F2 and the defend-the-number questions
