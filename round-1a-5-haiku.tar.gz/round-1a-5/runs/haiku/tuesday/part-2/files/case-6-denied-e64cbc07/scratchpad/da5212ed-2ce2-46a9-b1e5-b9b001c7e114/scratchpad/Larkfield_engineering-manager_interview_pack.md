# Interview prep pack: Engineering Manager, Larkfield Systems

**Loop of three rounds.** Tuesday, 45 min, hiring manager (Director of Engineering). Thursday, 60 min, panel of two staff engineers and a product manager. Following Monday, 30 min, VP Engineering ("values and leadership philosophy"). Shared fit snapshot and prohibited list, then one mini-pack per round. Interviewer names are not known, so personas are weighted from round type and relationship only.

Sections dropped because their inputs are missing: prep triage (no prep time given), interviewer read (no names), values cheat sheet (no published values in hand), grounding brief (no deep research), graded deliverables (none declared), delivery coaching (no assessment).

## How to use and type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioral and values, whether past behavior shows the published values or leadership principles
- **EXP**: your own experience, whether your claims survive scrutiny and what was actually yours
- **JD**: the role's stated responsibilities, including gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, with no claim about your past

Guidance is scaffolding, not a script. Speak each answer in 90 to 120 seconds, in your own words, and only with what your quoted sentences carry. Where an answer slot appears, it is an instruction for the interview: answer the branch that is true for you.

## Fit snapshot (shared across all three rounds)

Evidence is quoted from your message, the only candidate material supplied. No CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads, and places you at a payments company, not in device work. Words: "I was a team lead of six for three years." Answer slot: if you have run work across more than one team at a time, say what it was and how you split it; if not, say so and say how you would split two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Hiring reaches loop ownership for backend roles. It does not show hiring decisions for a team you were accountable for, and the 11 engineers are not in your material. Words: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: if you have made a hiring decision for a team you were accountable for, say which; if you only ran the loop, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: say how you have grown an engineer, in your own words; if none comes to mind, say so and say how you would start with the first of the 11. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | none | The quote reaches delivery in role-relevant terms. The 60% is a single figure with no inspectable proof in the material, so expect a probe on it. Words: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: defend-the-number, as in A4. |
| F5 | "partner with hardware and product on roadmap" — your message | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote shows roadmap pressure from the product side. It shows nothing from hardware. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if hardware constraints were part of that quarter, say how; if they were not, say so. |
| F6 | "partner with hardware and product on roadmap" — your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap you stated, and the one the Director is most likely to test. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | Managing managers: not in the role summary; a derivation from "lead two squads" [inferred] | "I've never managed managers" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't managed managers." Then how you would learn it, said as a plan and never as a past. |

Seven rules these rows follow. Each gap row gives only words you can say truthfully. F3 has no quote, so its words are an answer slot. F6 and F7 are stated negatives, so their words are plain acknowledgments. The gap type follows the evidence cell, not my sense of the row.

## Prohibited list (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Stated negative, F7 | Plain acknowledgment: "I haven't managed managers." No slot. |
| Has owned a hardware-adjacent roadmap | Stated negative, F6 | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan for learning it, said as a plan. |
| Ran hiring for the company | Inflated form of F2 | F2's quote at its own scope: backend roles, about 40 interviews. B3 and E2 stay inside the loop you ran. |
| Owns the whole 60% | Inflated form of F4 | F4's quote at its own scope. E1 asks how the figure was counted and which part was yours. |
| Led two squads | Inflated form of F1 | F1's quote: one team of six, for three years. |

Your material says the round, the team and the figure. It does not say the pipeline, the company's hiring or the whole result. Those limits are my observation for your preparation. They are not words for you to say.

## Sources

Provided documents: your message (the role summary and your background). No CV was supplied. No `tuesday-dossier.md` was found in the working folder, so no dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0. All three searches were refused by the host (web search permission was not granted), so no company research ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable (refused) | Values cheat sheet, dropped. VAL questions G2 and I2 are scaffolds rather than mapped stories. |
| 2. `Larkfield Systems engineering manager interview process` | unavailable (refused) | Loop structure. Persona weights per round come from round type and relationship priors only. |
| 3. `Larkfield Systems industrial IoT device management strategy news` | unavailable (refused) | The CO question H2 is generic instead of tied to current strategy. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative `Engineering Manager` JD | unavailable | No search was sent. Your role summary stands in for the JD, so requirement rows are your summary's words, not the posting's. |

## Round 1: Hiring manager, Tuesday, 45 min

**Relationship and weights.** Hiring manager is the prior for Case/Strategist and Skeptic. The Director is also your likely future manager, so the Skeptic weight stays high. Case/Strategist: 4 questions (A1 to A4). Skeptic: 3 (B1 to B3). Pressure: 2 (C1 to C2). No interviewer signals, and no loop source, so these weights are priors only.

**Highest-ROI prep in the pack: B2.** The Director is most likely to test the hardware roadmap gap (F6) and the first managers gap (F7). Rehearse B2 until the concession is boring.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, one of them behind on rolling a fix out to the device fleet. What do you look at first?" | CASE | [grounded] "Lead two squads building device-management services" — your message | Live problem, no claim about your past. Clarify what "behind" means and what is at risk. Set the objective. Segment by squad and by device cohort. Propose a first move for the squad that is behind. Name the metrics and the risk you would escalate. | Tests the job itself. The theme comes from the role summary. |
| A2 | "Hardware says the slot you need is next quarter. Product wants it sooner. What do you do this week?" | CASE | [grounded] "partner with hardware and product on roadmap" — your message | Live problem. Separate each date's commitment from its preference. Talk to both owners before choosing. State what you would trade and what you would not. Name who decides. Answer slot: if you have sat between hardware and product before, say what you did; if not, say so and walk the plan. | Tests the seam where F5 and F6 sit. The hardware half is a gap, so the approach is what is scored. |
| A3 | "Your summary asks for delivery, hiring and growth for 11 engineers. Which of those would you hand to someone else on day one, and which would you keep?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | Name the two you would keep and why. Name the one you would hand off and to whom. Say what you would check at 30 days. No claim about the past. | Checks that you understand the scope. The quote alone carries it. |
| A4 | "Your on-call burden fell 60%. How was that counted, and what part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say how; if it was not yours to count, say so plainly and say what you pushed through. Do not offer a method you cannot repeat under a second question. | The headline figure gets the defend-the-number slots the coverage rule requires. |
| B1 | "You've never managed managers. Why is this the next step for you?" | JD | [grounded] "I've never managed managers" — your message; "9 years engineering, 3 as a team lead of 6" — your message | Plain acknowledgment: "I haven't managed managers." Then, in your own words, what you want next. Do not invent a motivation. | F7 is the gap the Skeptic is built to find. Meeting it plainly beats meeting it defensively. |
| B2 | "What have you never owned that this role needs on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message; "I've never managed managers" — your message | **Highest-ROI prep.** Say the concession first: "I haven't owned a hardware-adjacent roadmap." Then the first move: how you would work with hardware on the roadmap in the first 90 days. Hold through two follow-ups by returning to that plan. Follow-up one, "why would you be the one?": answer from the team of six. Follow-up two, "what would you do in 90 days?": answer with the plan. Concede the gap, never the answer. | F6 and F7 are the likeliest objections. This is the one most worth rehearsing aloud. |
| B3 | "Your 40 interviews were for backend roles. What changes when you hire for a hardware-adjacent team?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Name what you would test first in the loop: domain knowledge, the hardware-software seam, how candidates talk to hardware people. Answer slot: if you have hired outside backend, say which; if not, say so and name what you would change. | F2's transferability, asked as a plain question about the loop. |
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" — your message; "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Pause, then restate the question. Anchor in the two quotes and nothing more. Hold through two follow-ups. Never claim more than the quotes carry. | Pressure stem. The answer rests only on the candidate's own sentences. |
| C2 | "That reliability quarter. Did it cost you anything on the roadmap side?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold: you pushed the quarter through. Concede a specific cost only if you know one. If you know of none, say so plainly and say what you would check. Hold through two follow-ups and never fold on the quarter itself. | Tests whether you can hold a decision under pressure without becoming defensive. |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would a strong first 90 days look like to you?" | Shows you are planning in their terms, not hoping. |
| RA2 | "Which of the two squads is the bigger risk right now, and why?" | Asks for the real delivery picture, which you can then speak to. |
| RA3 | "How is the roadmap set today, between hardware and product?" | Opens the seam A2 and F5 depend on. |
| RA4 | "What would make you say in six months that this was a good hire?" | Turns the hiring manager's criteria into your checklist. |
| RA5 | "Where do you want the squads to be in a year?" | Shows you are thinking about outcomes, not tasks. |

## Round 2: Panel, Thursday, 60 min

**Relationship and weights.** The panel blends each member's relationship. Both staff engineers are Peer Evaluator and Data-Driven Prober. The product manager is Peer Evaluator and Case/Strategist. Peer Evaluator: 4 questions (D1 to D4). Data-Driven Prober: 3 (E1 to E3). Case/Strategist: 2 (F1 and F2). No member names are known, so the blend is assumed.

| Panel member | Persona blend | Likelihood and reasoning |
|---|---|---|
| Staff engineer 1 | Data-Driven Prober, Peer Evaluator | Staff engineers read the numbers and the seam. High: E1 and E3 are the likeliest probes. |
| Staff engineer 2 | Data-Driven Prober, Peer Evaluator | Same blend, with more weight on the seam between platform work and your squads. |
| Product manager | Peer Evaluator, Case/Strategist | Roadmap trade-offs are their native ground. High: D1 and F1. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Hardware and product both have a say in your roadmap. Where does that seam sit, and what happens when you disagree with them?" | JD | [grounded] "partner with hardware and product on roadmap" — your message; "I pushed a reliability quarter through against roadmap pressure." — your message | Propose seam principles rather than pretending to know theirs: who decides scope, who decides dates, how a disagreement is escalated. Then the quarter: the roadmap pressure, the quarter, the push, and the result. Answer slot: if you disagreed with hardware or product over that quarter, say who and how it ended; if not, say so and give the nearest disagreement you handled. | Peer register: the seam, asked in the role's own words. |
| D2 | "How do you handle credit when work spans teams?" | JD | [generic] | Selection scaffold: pick a time work spanned teams and you did the core of it. Say what you did and who shipped it. If no such time comes to mind, say so and give the nearest. | Peer stem. No quoted sentence carries a cross-team credit story, so the guidance is a scaffold. |
| D3 | "What would you need from us to make your first month useful, and what would you take off our plate?" | JD | [generic] | Name one thing you would need and one thing you would take off their load, both as plans. Do not claim what their team lacks. | Reciprocity framing. A peer weights what you bring as much as what you need. |
| D4 | "Tell us about a time you disagreed with a product lead and were right, and a time you were wrong." | EXP | [grounded] "partner with hardware and product on roadmap" — your message | Story-mapped from the role's words. Use the reliability quarter only as far as it goes: the roadmap pressure, the quarter pushed through. Answer slot: if you were wrong once, say what changed afterwards; if no such time comes to mind, say so and give the nearest. | Disagreement stories show spine and tact together. The second branch keeps it honest. |
| E1 | "Walk me through how the 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it, say how; if it was not yours to count, say so plainly and say what you pushed through. | Staff engineers are the likeliest to read the on-call data. Same figure as A4, asked by a different panel. |
| E2 | "Walk me through the 40 interviews. What was the loop, and what would you change about it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Describe the loop as the quote states it: backend roles, about 40 interviews last year. Answer slot: if you set the rubric or the stages, say which; if you ran a loop someone else designed, say so. What you would change is a plan, not a past. | Tests what you ran against what you set. |
| E3 | "Your six-person team: which decisions were yours alone, and which were shared?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | Name the decisions in your own words. Name the shared ones honestly, and your part in each. Never describe an authority you did not have. | Prober asks you to separate ownership from participation. |
| F1 | "A reliability quarter is on the plan, and product asks to swap it for a launch. What is the first thing you check?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Live problem using the quote's own pressure. Clarify what the launch is for and what the reliability work protects. Compare the cost of each in its own units. Name who decides. Propose a check before any decision. Say what you would not trade. No past claim. | Theme comes from your quote. The question asks about no past. |
| F2 | "Hardware says the sensor work needs two quarters. Product wants it in one. What do you do this week?" | CASE | [generic] | Clarify the constraint behind each date. Separate commitment from preference. Talk to both owners. Name what you would trade and what you would escalate. | Live hardware-product seam. Generic, because hardware timing is a pattern for the seam, not a fact about this company. |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RD1 | "What could a new engineering manager do in their first month that would genuinely help your team?" | Reciprocity framing for a peer panel. |
| RD2 | "Where do the platform and the device squads currently disagree most?" | Shows you want the real seam, not the org chart. |
| RD3 | "How do you decide when a reliability fix outranks a feature?" | Opens the trade-off that F1 turns on. |
| RD4 | "What do you wish the last engineering manager had done differently?" | Invites candid detail on what the role needs. |
| RD5 | "What would you want the product manager and I to agree on before the first roadmap review?" | Puts the PM's own priorities on the table. |

## Round 3: VP Engineering, Monday, 30 min

**Relationship and weights.** The recruiter's wording, "values and leadership philosophy", makes this a values-style round. Values/Behavioral: 4 questions (G1 to G4). Pressure: 2 (H1 and H2). Conversational: 2 (I1 and I2). No published values are in hand, so these are scaffolds where no story is quoted.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Story-mapped from the quote. The beats the quote states: roadmap pressure, the quarter, the push. Answer slot: if the truth you delivered was a specific one, say what it was and how it landed; if you did not deliver one against a wish, say so and give the nearest. Use "we" for context and "I" for your contribution. | Values-style stem. The quote carries the nearest story. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. Say what the number was and what you gave up. If no such time comes to mind, say so and give the nearest. | Your material shows no customer outcome. The on-call figure is an internal-team metric, which is my observation, not a claim to make. |
| G3 | "How do you grow engineers who are better than you at their own specialty?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | State one principle in your own words. Answer slot: if you have grown an engineer, say what you did and what changed for them; if not, say so and say how you would start with the first of the 11. | Growth has no quote (F3), so the answer is a principle plus an honest branch. |
| G4 | "What is your leadership philosophy, in one sentence, and where has it cost you?" | VAL | [grounded] "values and leadership philosophy" — your message (the recruiter's words) | One sentence, plan-first, not an invented philosophy. Answer slot: if it has cost you something, say what; if it has not, say so and name the cost you expect. | The recruiter's own phrase sets the round. |
| H1 | "Sixty seconds: why should we trust you with two squads when you haven't managed managers?" | JD | [grounded] "I've never managed managers" — your message; "9 years engineering, 3 as a team lead of 6" — your message | Hold: "I haven't managed managers." Then the team of six, in its own words. Hold through two follow-ups and concede exactly the gap, not the trust. | Pressure version of F7. |
| H2 | "What would you need to understand about our device-management business in your first 90 days?" | CO | [generic] | Name the three things you would learn first, such as customers, the device fleet and the hardware constraints, as a plan. Do not claim knowledge of their strategy. | Generic, because no company research ran. The upgrade menu names what would change it. |
| I1 | "So, walk me through the journey." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Pre-scripted 90-second arc: nine years, three as a team lead of six, the payments company, the hiring loop, the reliability quarter. Speak each as the quote states it. | Casual register, but scored. |
| I2 | "What has been the hardest part of the last year in your current role?" | VAL | [generic] | Selection scaffold: pick one hard stretch. Say what was hard, what you did and what it cost. If nothing comes to mind, give the nearest. | Rapport question. Generic, because no quote carries a hard stretch. |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RG1 | "What does a good engineering leader look like on this team?" | Shows you are thinking at their altitude. |
| RG2 | "Where do you want device management to be in two years?" | Asks for the strategy in their words. |
| RG3 | "How should engineering and hardware decide roadmap trade-offs?" | Opens the seam that F5 and F6 cover. |
| RG4 | "What have you seen go wrong when a new manager inherits a team?" | Invites candid detail on what they have learned. |
| RG5 | "What would you want me to have done in my first 90 days?" | Converts the close into a plan you can check. |

## Requirement coverage

| Requirement or theme (source) | Questions |
|---|---|
| "Lead two squads building device-management services" — your message | A1, B2, H2 |
| "own delivery" — your message | A3, A4, E1, G1 |
| "hiring" — your message | B3, E2, C1 |
| "growth for 11 engineers" — your message | A3, G3 |
| "partner with hardware and product on roadmap" — your message | A2, D1, D4, F1, F2, RG3 |
| "I've never owned a hardware-adjacent roadmap" — your message | B2, A2 |
| "I've never managed managers" — your message | B1, H1 |
| "values and leadership philosophy" — recruiter, via your message | G1, G2, G4, I2 |
| Peer seam, credit and reciprocity (panel) | D2, D3 |

Every stated requirement has at least one question.

## Upgrade menu

- **Full job description text** → the requirement rows switch from your summary to the posting's own words, and the managing-managers row (F7) can be checked against the posting.
- **Your CV** → F1 to F5 can rise above medium only with inspectable proof, and the CV's own sentences replace the summary's.
- **Interviewer names** (the Director, the two staff engineers, the product manager, the VP) → per-member persona weights and personal reverse questions in place of the assumed blends.
- **The recruiter's note on what each round scores** → reweights the panel and VP banks.
- **Larkfield's published values page** → the values cheat sheet, and G2 and I2 can move from scaffolds to mapped stories.
- **Web search permission** → company values, the loop structure and current strategy (targets 1 to 3 above). H2 and G2 would move from generic to grounded.
- **Any record of the reliability quarter** (the on-call data, the plan, a retrospective) → lets E1 and A4 be defended with the actual counting method rather than a slot.
