# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final, format and interviewers not yet known. Built without a CV, a job description or web research, so every evidence cell is empty and the question banks are generic. Upload your CV and the JD and this pack gets specific.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the shape, then answer in your own words.

- **JD**: tests a stated requirement. None is stated yet.
- **EXP**: tests whether your past work survives scrutiny.
- **VAL**: tests behaviour against published values. Not included: no values were verified (see Sources).
- **CO**: tests company and strategy knowledge. Not included: no research ran.
- **CASE**: a live problem from the role, scored on structure and reasoning.

Round format is unknown, so persona weights are flat: each persona gets 2 to 3 questions.

## Fit snapshot (worksheet variant)

No CV and no JD were provided, so the requirements below are role-family patterns, not Stripe's stated requirements. Every evidence cell is empty.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| W1 | Running cross-functional programmes or launches from start to finish (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Selection scaffold: pick a programme you ran or helped run that involved several teams; say what you owned and what you did not. If you have not run one, say so and say what you would do first. |
| W2 | Designing or fixing an operating process that other teams follow (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a process you changed; say what the old one did wrong, what you changed, and who adopted it. If none was yours to change, say so and describe how you worked within it. |
| W3 | Building metrics or dashboards and using data to decide (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a decision made from data; say the source, the denominator and the assumption you would defend least. If no decision came from data, say so and name the nearest one. |
| W4 | Briefing leadership and making trade-offs visible (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a moment you had to give a senior person a trade-off they did not want; say what you recommended and what happened. If you have not had one, say so. |
| W5 | Prioritising across many stakeholders with unclear ownership (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a time priorities conflicted across teams; say how you decided and who you had to persuade. If there was no such conflict, say so and describe how you would handle one. |

Gate rows: none, because no JD was supplied.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific programme, metric, outcome, team size or title | No quoted sentence exists yet, so nothing is listed as inflated | The pack's observation: the material says nothing about your past yet. No claim is coached until you quote one, from a CV or in your own words. Answer slots only. |
| Any number you cannot explain | Rehearsal rule | If a figure comes up, say how it was counted, or say plainly that you do not know. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: diagnose, plan, size | High. The round is final-stage, and product ops is judged on structure under live problems. | Clarify, then objective, then segmentation, then approach, then metrics, then risks. Think aloud. |
| Data-Driven Prober | Asks how a number was counted and what it depends on | Medium. Common in ops roles; weight rises if the interviewer is analytics-led. | Name the weakest assumption before they do. Say plainly when you do not know how a figure was counted. |
| Values / Behavioural | STAR-shaped prompts about past behaviour | Medium. Unknown whether a values round exists; flat weight. | One story per prompt, with I for your contribution and we for context. |
| Skeptic | Probes gaps and motivation | Medium-high at final stage. Motivation and fit are the usual final-round decision points. | Calibrated candour. Name what you would learn first. Do not bluff a gap. |
| Pressure | Interrupts, time-boxes, challenges your result | Medium. Common at senior levels. | Pause, restate the question, hold a position through two follow-ups, then concede only what is true. |
| Conversational | Friendly opener that is still scored | High at the start of any loop. | A 90-second arc, built from your own material once you have sent it. |
| Peer Evaluator | Seam between teams; disagreement; credit | Medium if a peer or cross-functional leader is on the panel. | Offer seam principles rather than pretending to know the seam. Show what you bring their team. |

## Question banks

Guidance is what you would say; the rationale is why the question is likely. No question here asks about a specific past event, because none is quoted yet.

### Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch slips two weeks and two teams disagree about the cause. What do you do first?" | CASE | [generic] | Clarify the decision and the deadline before proposing anything. Name what you would check first, who you would ask, and what would change your plan. | Live problem from the role; scores structure, not a right answer. |
| A2 | "A key operating metric drops 20 percent week on week. Walk me through how you would diagnose it." | CASE | [generic] | Segment before you hypothesise: by time, by region, by product, by change made that week. Name two checks that would rule out a data fault. | The Case persona's stock problem; tests metric logic. |
| A3 | "Sketch how you would set up an operating review for a new product line." | CASE | [generic] | Objective, then the decisions the review must make, then the inputs, then cadence and owners. Say what you would not include. | Tests whether you can design an operating system, not just run one. |

### Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you used data to change a decision. How was the data counted?" | EXP | [generic] | Selection scaffold: pick a decision that data changed; name the source, the denominator and one assumption you would defend least. If no decision was changed by data, say so and give the nearest one. | Open prompt on a common probe; the honest branch is the point. |
| B2 | "Think of a number you have put in front of a leader. Which assumption behind it would you defend least?" | EXP | [generic] | Answer slot: if you have such a number, name the assumption in your own words. If you have none, say so plainly and describe how you would make one defensible. | Prober's favourite move; rehearse the weakest-assumption answer. |

### Values / Behavioural (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to a leader." | VAL | [generic] | Selection scaffold: pick a time the truth landed, even if it cost you something. If the truth did not land, say how it went and what you learned. | Behavioural stem from the Values persona; no values were verified, so the prompt is generic. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer outcome and a target pulled apart. Say what you chose and what it cost. | Common behavioural stem; tests judgement under a target. |

### Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause. Restate the question. Answer with the reason you actually hold, in under 60 seconds. Hold through two follow-ups before conceding anything real. | Time-boxed challenge; scores composure, not content. |
| D2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: name the result, your part in it, and what others did. If the result was mostly someone else's, say so and describe your part. | Pressure stem on attribution; honest attribution is what is scored. |

### Skeptic (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the gap you can see, how you would learn it, and what you would do in your first 30 days. Do not claim a competency you lack. | Skeptic stem; the most predictable objection before a JD is in hand. |
| E2 | "Why leave where you are, and why this role now?" | EXP | [generic] | Give the reason in your own words, including what you want next. Do not invent a reason that sounds better. | Motivation consistency is a common final-round decision point. |

### Conversational (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: current role, what you did there, why the next step. Build it from your CV once it is shared. | Friendly opener that is still scored on communication economy. |

### Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | EXP | [generic] | Propose principles for the seam, such as who decides what and how disagreements escalate. Do not pretend to know their seam. | Peer stem on partnership fit. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you name others' contributions and what you do when credit is unclear. | Peer stem; tests collegiality. |

Session total: 14 questions, under the 18 target. The round format is unknown, so the bank is thin; the upgrade menu says what adds more.

## Requirement coverage

No JD was supplied, so this maps the role-family areas in the fit snapshot.

| Area | Questions |
|---|---|
| W1 cross-functional programmes | A3, F1 |
| W2 operating process | A3 |
| W3 metrics and data | A2, B1, B2 |
| W4 leadership trade-offs | D1, C1 |
| W5 prioritising with unclear ownership | A1, E1 |
| Stakeholder seams | G1, G2 |
| Values | none, and why: no values round is established, and the company's values were not verified |

## Reverse questions

Round format is unknown, so these are generic. Each one converts a scored moment into a conversation.

1. "What does success look like for this role in its first six months?" Why it lands: shows you plan to own outcomes.
2. "Which operating problem takes most of the team's time right now?" Why it lands: asks about real work, not the pitch.
3. "How do product operations and the teams it supports split decisions?" Why it lands: a seam question that signals you think about partnership.
4. "What would make you say in a year that this hire worked out?" Why it lands: shows you want a clear bar.
5. "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, most useful if the interviewer is a peer.

## Sources

Provided documents: the role title and company, from your message.

Searches and fetches: two searches were attempted, both refused because web search permission was not granted. Queries: "Stripe values operating principles stripe.com"; "Stripe interview process final round product operations manager". Nothing was fetched.

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10). Refused, so the section is absent. |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Refused, so weights are flat. |
| 3. Stripe strategy and recent news | unavailable | Company and strategy questions. No call was sent, so none are included. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given. |
| 5. Representative JD | unavailable | Would have turned the role-family rows into [inferred] JD rows. No call was sent. |

## Upgrade menu

- A pasted job description → the role-family rows become quoted [grounded] requirements, and JD-tagged questions get written.
- Your CV, or a list of the programmes and decisions you have run → the evidence cells fill with your own sentences, and stories map to them.
- The round format and who you are meeting → persona weights and the reverse questions get tailored.
- Web search allowed, or Stripe's values page and recent strategy pasted in → the values cheat sheet, the loop structure and company questions are added.
- Your recruiter's note on focus areas or any assignment → build sections for any deliverable.
- Prep time before the round → a prioritised schedule.
