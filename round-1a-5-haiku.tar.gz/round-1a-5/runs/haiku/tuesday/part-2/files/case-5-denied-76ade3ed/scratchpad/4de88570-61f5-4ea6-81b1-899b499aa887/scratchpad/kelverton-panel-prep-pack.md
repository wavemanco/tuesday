# Kelverton Rail — Senior Partnerships Manager, Round 2 panel prep

**Build basis:** your own words only (email quote, background summary). No JD text, no CV, no market report text, no public research. Web search was denied in this session, so nothing below about Kelverton or UK rail is sourced; anything that reads as market context is marked `[inferred]`.

## 1. Fit snapshot

| Requirement (from the panel brief) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Operator partnerships strategy, 18 months | "took it from 6 partners to 40" | Strong (domain-adjacent) | Sector gap | "I've built partner programmes at scale in payments; the operator version is a different buyer, and I've spent five years on the operator side of the table." |
| Understanding the operator world | "5 years in transport consulting (bus and light rail network planning…)" | Strong | None | Direct, usable. Say what you learned about how operators decide and budget. |
| Commercial ownership (Ross) | "roughly £4M of influenced revenue" | Moderate: influenced, not sourced or closed | Quota gap | "I've been accountable for influence, not a quota. Here is how I'd hold myself to a number and how I'd attribute it." |
| Rail sales experience | "Never sold into rail specifically" | None | Sector gap | Concede it plainly; bridge via operator-side knowledge and a 90-day plan. |

## 2. Prohibited claims (do not coach these)

- Any rail sales experience, or any TOC relationship you did not personally hold.
- Direct quota attainment or closed-won revenue. Use "influenced" every time.
- Knowledge of Kelverton's product roadmap, pricing or customer list beyond what the panel tells you.
- The £4M as yours alone. Name the attribution method you used, or say you'd need to check it.

## 3. Interviewer read

- **Deepa (VP Partnerships, future manager):** no profile supplied. Weight her toward partnership craft, operator motivations and how you'd run a team you don't yet know.
- **Ross (Commercial Director):** no profile supplied. Weight him toward economics, forecasting, pipeline and how influence becomes revenue.

## 4. Persona weights

- Deepa, 50%: operator outcomes, partner programme design, 18-month plan.
- Ross, 50%, and he pushes: quota, attribution, deal economics, partner margin.
- Loop is flat; expect Ross to interrupt the POV.

## 5. Question banks

**Deepa (manager)**

1. *How would you tell an operator their partnership is working in its first 90 days?*
   - Provenance: your own sentence, "took it from 6 partners to 40."
   - Guidance: describe the operator-facing proof you'd look for (adoption, planning-cycle time saved, fewer manual workarounds). Only describe what you did at ISV scale; say what you'd translate.
   - Rationale: tests whether you think in operator outcomes, not partner counts.

2. *Which of the 40 partners did you personally build, and which did you inherit?*
   - Provenance: "from 6 partners to 40."
   - Guidance: answer with the true split. If you inherited most, say so and say what you added.
   - Rationale: pressure on attribution; shrinking an inflated claim gracefully is the rehearsal.

**Ross (commercial)**

3. *Walk me through what "£4M influenced" means. How was it attributed?*
   - Provenance: "roughly £4M of influenced revenue."
   - Guidance: name the method (touchpoint, sourced-vs-influenced rule, who signed off). If you don't know the method exactly, say you'd want to check before quoting it.
   - Rationale: the commercial trap is treating influence as ownership.

4. *You've never carried a quota. How would you hold yourself to one here?*
   - Answer slot: give your own honest answer. Good shape: a forecast built from operator pipeline stages, a leading-indicator set, and a stated view on where partner-sourced vs direct revenue lands.
   - Rationale: the quota gap is the most likely objection. Rehearse the honest form.

**Hardest objection (deepest rehearsal):** "You've never sold rail and never carried a quota."
- Hold: "That's accurate. Here's what I'd bring instead, and here's how I'd close the gap in the first 90 days."
- Concede the gap in one sentence. Then bridge: operator-side knowledge from transport consulting, channel scaling from payments.
- Do not say you can "learn fast" without a specific plan. Name the first three things you'd do.

## 6. Reverse questions

- What did the operators you lost in the last year tell you they needed? *Why it lands: shows you think about operator outcomes.*
- How does the panel want partnership wins counted against the commercial forecast? *Why it lands: opens the attribution conversation on their terms.*
- What would the first 90 days need to deliver for you to call the hire a success? *Why it lands: frames the manager's expectation.*

## 7. The 15-minute POV: shape, not script

No market report text was supplied, so the operator problems below are `[inferred]` until you check them against the report.

1. **The operator's problem `[inferred]`:** operators are judged on punctuality and cancellations, and their planning cycles are long. A partner tool that saves planners time wins only if it shows up in the metrics they already report.
2. **What partnership should mean to an operator:** fewer manual timetable workarounds, faster disruption recovery, and a partner who knows the regulatory calendar.
3. **Three moves over 18 months:**
   - Build operator-outcome partnerships, with shared success metrics rather than resale margin.
   - Use partners who already know operator procurement as the route in, not just as resellers.
   - Instrument proof: one operator-facing value number per partner, reported monthly.
4. **What it means for operators, stated last:** less planner time on rework, and a clear line from the tool to a metric they answer for.
5. **Commercial shape for Ross:** tie partner economics to operator budget cycles and say what you'd forecast first.

Keep it to three moves. Expect Ross to interrupt around move 3.

## 8. Prep plan (about 4 hours)

- 45 min: check the POV against the market report; replace every `[inferred]` with a sourced point.
- 60 min: write the POV in your own words; rehearse it aloud twice, timed to 12 minutes.
- 60 min: drill the hardest objection and questions 3–4 out loud, once each.
- 45 min: prepare your three reverse questions and the 90-day plan in three bullets.
- 30 min: rest, and re-read the prohibited claims list.

## 9. Upgrade menu

- **JD text** (unlocks: exact requirement rows, replaces the `[inferred]` gap calls).
- **Market report bullets** (unlocks: sourced operator problems in the POV, a sharper Ross bank).
- **Any interviewer background you can find** (unlocks: a real interviewer read; drop nothing if none).
- **Web research permission** (unlocks: Kelverton and UK rail context, at the default tier).
