# Ashgrove Credit Union: Member Experience Lead, interview pack

**Rounds, all on 4 December 2026:** recruiter (30 min); Head of Member Services, your future manager (45 min, mostly behavioural); panel of two branch managers (60 min, scored against the four values, including a 20-minute complaint-escalation case). Interviewers beyond the roles are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

Type key:
- **VAL**: behavioural and values. Does past behaviour show a published value?
- **EXP**: experience deep-dive. Do your claims survive scrutiny?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge.
- **CASE**: live problem from the role. Makes no claim about your past.

Provenance labels: **[grounded]** traceable to your own sentences or a provided document; **[inferred]** a derivation, named where used; **[generic]** a pattern, with no fact about you or Ashgrove.

## Fit snapshot

Your sentences are quoted exactly. Everything the banks say about your past comes from these quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Use the quote's terms: "Six years in retail banking, the last three as a branch supervisor." Whether that counts as customer operations is for the interviewer to judge. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints and a log. It does not say whether a regulated process governed them. Answer slot: if rules or timescales governed the log, say which and what you did under them; if not, say so and describe the formal process as it was. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log. Words: "For my branch, I handled the formal complaints log." Limit, as this pack's observation: the material shows one branch's log, not the process end to end. Answer slot: if you set any step beyond the log, say which, in your own words; if you did not, say so. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | medium | [grounded] | capability | Words: "I've never worked in a contact centre." Then how you would learn the queue, stated as a plan, never as a past. |
| F5 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Add nothing to it. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] (derivation: the spreadsheet sentence does not say what it tracked) | discovery | Your material does not show whether the spreadsheet tracked resolution times. Answer slot: if it did, say how they were counted; if not, say so and say what it tracked. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] (derivation: your message says spreadsheet, not Excel) | discovery | Answer slot: if it was Excel, say so and what the spreadsheet did, in your own words; if it was another tool, say which. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Your material shows tellers, not supervisors. Answer slot: if you coached anyone past teller level on escalations, say how; if not, say so. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have worked with a digital team on a customer journey, say what it was; if not, say so and say how you would begin. |
| F10 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | medium | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would build the skill, as a plan, never as a past. |

**No gate rows.** None of the requirements is an eligibility term.

## Grounding brief

From your summary of Ashgrove's July 2026 strategy brief. The brief itself was not read, so every strategy claim below is only as accurate as your summary.

- **Digital shift** [grounded] "move 40% of member service to digital channels by 2028"
- **Branch consolidation** [grounded] "consolidate eight branches into five hubs over 2027"
- **Small-business lending** [grounded] "launch a small-business lending product in Q1 2027"
- **Competitive pressure** [grounded] app-only banks, per your summary

## Values cheat sheet

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Selection scaffold, question J1. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8: "trained new tellers on our escalation script." The sentence carries the teaching, not the outcome. Scaffold, question J2. |
| Neighbours, Not Numbers | Each branch is part of its town | No quoted sentence carries a story. Selection scaffold, question J3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log." It says you handled the log, not that you carried a case to closure. Scaffold, question J4. |

## Persona table

| Round | Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|---|
| 1, recruiter | Conversational | 6 | Friendly opener, then logistics checks | Recruiter-screen prior. Pay, notice, location and reason for leaving each get a row. | Scripted 90-second arc. Treat casual questions as scored. |
| 1, recruiter | Skeptic | 1 | One knockout-style check | Recruiter prior, light | Name the one real limit you have. |
| 2, Head of Member Services | Values/Behavioral | 5 | Scenario probes, STAR-shaped | Recruiter says the round is mostly behavioural. This adjusts the manager prior upward. | Map to a real case. "We" for context, "I" for the decision. |
| 2, Head of Member Services | Skeptic | 3 | Gap-finding on the JD's requirements | Manager prior: they are buying capability and checking the gaps. | Acknowledge gaps plainly, then give a plan. |
| 2, Head of Member Services | Case/Strategist | 3 | Live problems on complaint volumes and the strategy | Manager prior, plus the strategy in the brief you were sent | Clarify, then structure, then answer. Use Ashgrove's own terms. |
| 3, panel | Values/Behavioral | 4 | Four published values, scored | Panel is the values round, per the recruiter | One mapped story per value. Honest branch where none exists. |
| 3, panel | Pressure | 2 | Time-boxed challenges to your record | Two branch managers can test your claims hard | Hold the anchor through two follow-ups. Concede one point specifically. |
| 3, panel | Case | 1 | The 20-minute escalation case | Recruiter's stated structure | Clarify, plan, then name the risks. |

## Prohibited claims

Built from the fit snapshot. Each entry gives its basis and the honest form that replaces it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope. Observation, not words for you: the material shows one branch's log. |
| Handled regulated complaints | Inflated form of F2 | F2's quote. Observation: the material does not say a regulated process governed the log. |
| Reported resolution times | Inflated form of F6 | F5's quote. Observation: the material does not show that the spreadsheet tracked resolution times. |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope. |
| Used Excel | Inflated form of F7 | F5's quote. Observation: your message says spreadsheet. |
| Has worked with the contact centre | Your own negative, F4 | "I've never worked in a contact centre." |
| Has presented to senior leaders | Your own negative, F10 | "I've never presented to anyone above regional level." |

## Question banks

### Round 1: recruiter screen (persona A, Conversational)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds, in these words: six years in retail banking, the last three as branch supervisor. Then the formal complaints log and the monthly spreadsheet. Stop there. Depth comes in round 2. | F1 is the 4+ years requirement. The recruiter is checking the basics. |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | Name one thing from the brief you have read, in your own words: the digital shift or the hub consolidation. Say why it touches complaints work. Do not claim knowledge of internal plans. | A motivation check. The brief is in hand, so the question is scorable. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot, no figure given. Either ask for the band first, or give your own number. | Recruiter's logistics question on pay. |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | Recruiter's logistics question on notice. |
| A5 | "Can you work at this role's location?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Logistics slot. Answer with your real location constraint, in your own words. First ask where this role will sit, because the hub consolidation may change where it is based. | Location is a logistics slot. The brief sentence is the reason the question about the base matters. |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give the reason in one sentence, in your own words. The pack suggests none. | Reason for leaving is a recruiter logistics slot. |

### Round 1: skeptic (persona B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Is there anything in this role's description that would make you say no?" | JD | [grounded] "Never worked in a contact centre" | If you have a real limit, name it. The one limit in your material is the contact centre: "I've never worked in a contact centre." Name it as a limit, then the plan to learn the queue. | F4. The skeptic stem is the honest version of this question. |

### Round 2: Head of Member Services (persona C, Values/Behavioral)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint stayed open longer than it should have. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log"; published value "Own the Fix" | Open prompt on the Own the Fix value. Answer slot: if a complaint in your log stayed open longer than it should have, say how you handled it. If none did, say so and give the nearest case you handled. | The theme comes from a published value, and your only sentence is the log. The rest is your answer. |
| C2 | "Walk me through how you handled the branch's formal complaints log, from first contact to closure." | EXP | [grounded] "I handled the branch's formal complaints log" | Describe it in your words: what came in, who you passed it to, what closed it. Answer slot: if you set or ran any step beyond the log, say which. If not, say so. Do not describe steps you did not handle. | F3. The end-to-end line in the JD is the reason the question asks about closure. |
| C3 | "Which rules governed the formal complaints you handled, and what did you have to do under them?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log ran under regulated timescales or reporting, say which rules and what you did under them. If it did not, say so and describe the formal process as it was. | F2. The regulated-complaints requirement raises this question. The log sentence does not say it. |
| C4 | "How would you coach a branch supervisor whose escalations keep arriving late?" | JD | [grounded] "trained new tellers on our escalation script" | Start from what you did: you trained tellers on the script. Coaching supervisors is a different job. Describe how you would find out why escalations were late, in your own words. Answer slot: if you coached anyone past teller level on escalations, say how. If not, say so. | F8. The coaching requirement in the JD raises this question. |
| C5 | "Walk me through the monthly complaints spreadsheet. How did you count what went into it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | No figure is given, so none is supplied. Answer slots: which tool it ran in, if it was Excel; whether it tracked resolution times. If you quote a figure, be ready to say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. | F5, F6 and F7. The Excel and resolution-times lines in the JD raise these slots. |

### Round 2: Head of Member Services (persona D, Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Acknowledge plainly: "I've never worked in a contact centre." Then give a plan for learning the queue in the first month, labelled as a plan. Do not bluff. | F4. The single most likely objection to you. It gets the deepest rehearsal. Hold the plain acknowledgment through two follow-ups. |
| D2 | "How would you prepare to present to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: a rehearsal with your regional manager, and your first monthly report presented up. These are plans, not past events. | F10. Hold the acknowledgment. Do not describe presentations you have not given. |
| D3 | "Tell me about a time you shaped a customer journey you did not own, with a digital team." | JD | [generic] | Open prompt. If you have done this, give the beats in your own words. If not, say so and say how you would start with a digital team. Do not claim digital work. | F9. The material is silent, so the honest answer is the plan. |

### Round 2: Head of Member Services (persona E, Case/Strategist)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A branch's complaint volume doubled in one quarter. Diagnose it." | CASE | [generic] | Clarify first: what counts as a complaint, which products, which period. Then split by channel and complaint type, check whether resolution times moved too, and name the risk that the rise is a backlog or a reclassification. Speak it in ninety seconds. | A live problem from the JD's volume and resolution-times line. It needs no claim about your past. |
| E2 | "We are consolidating eight branches into five hubs over 2027. How would you keep complaint handling intact through it?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Plan: which complaints are open at each closing branch, which hub owns each one, and one named owner per case so nothing falls between sites. Do not claim you have managed a consolidation. | Strategy-tied CASE question. The brief sentence is the raising source. |
| E3 | "Forty per cent of member service moving to digital by 2028: what changes for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Name the complaint types that move with the channel, and what the monthly report would need to show to track them. Then ask whether the 40% target includes complaint handling. | The strategy differentiator. It also covers the digital-teams line of the JD. |

### Round 3: panel (persona J, Values/Behavioral)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter when the rule said otherwise." | VAL | [grounded] published value "Members First, Always: we decide from the member's side of the counter" | Selection scaffold, since no sentence of yours carries a story. Pick a time you put a member ahead of a rule or target. If none comes to mind, say so plainly, then give the nearest thing from your branch work. | Values round. The value is the raising source. |
| J2 | "Tell me about a time a member had to hear something twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold. If you taught the script and a teller had to hear it twice, say what you changed. If the script stayed hard to follow, say so. Do not say you rewrote it unless you did. | Plain Words. The nearest sentence is the teaching. |
| J3 | "Tell me about a time you looked at a complaint in its town, not just in the numbers." | VAL | [grounded] published value "Neighbours, Not Numbers: every branch is part of its town" | Scaffold. Pick a branch-level case that shaped how you treated local members. If none, say so and give the nearest thing from your branch work. | Neighbours, Not Numbers. No sentence of yours carries a story. |
| J4 | "Tell me about a complaint you kept until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold. Your sentence says you handled the log, not that you carried a case to closure. Pick one you kept to closure and say who else was involved. If none was yours to keep to closure, say so and give the nearest case. | Own the Fix. The honest branch is needed here. |

### Round 3: panel (persona K, Pressure)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why should we hire someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as branch supervisor" | Hold on the anchor: six years in retail banking, the last three as branch supervisor. Hold through two follow-ups. Concede the contact-centre point specifically: "I've never worked in a contact centre." Never fold on the six years. | F4 and F1. Hold-then-concede. |
| K2 | "How much of the complaints work you describe was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Separate what you did from the branch's process, in your own words. Hold the log and spreadsheet as yours to the extent your sentences say. Concede whatever was the branch's. | An attribution probe. Honest attribution is the answer. |

### Round 3: panel escalation case (persona L, Case, 20 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "A member comes into your branch. A card-fraud claim on their account was closed without a refund six weeks ago. Since then they have been moved between the branch and the contact centre, and they now say they will take it to the regulator. You have twenty minutes. Take us through what you do." | CASE | [generic] | Pacing: three minutes to clarify (what was decided, what the member was told, any deadline, anyone vulnerable). Five minutes to plan: one named owner today, a holding call with a stated next step, reopen the decision on the member's facts, check whether other members hit the same closure. Ten minutes with the panel's follow-ups. Two minutes to summarise. Ask which deadlines apply; do not invent a refund amount or a timeline. | A live problem with no claim about your past. The panel scores it against Own the Fix and Plain Words. |

## Reverse questions

Each one lands for a reason.

1. **To the Head of Member Services:** "What would a good first complaint decision look like in this role, to you?" Why it lands: it shows you are working to their standard.
2. **To the Head of Member Services:** "How are the monthly volume and resolution-time figures used above branch level?" Why it lands: it tests whether the reporting drives decisions.
3. **To the Head of Member Services:** "Where do complaints go while a branch is closing into one of the five hubs?" Why it lands: it ties to the brief and shows you read the consolidation.
4. **To the Head of Member Services:** "Does the 40% digital target include complaint handling?" Why it lands: it asks where the complaints team sits in the strategy.
5. **To the panel, a peer reciprocity question:** "What would a new person do in their first month that would genuinely help your branches?" Why it lands: it turns the panel from judges into peers, and it signals you are planning to help them.
6. **To the recruiter, or the panel:** "How is the values round scored, and against what written criteria?" Why it lands: it shows you want the bar stated, not guessed.

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | A1 | F1 |
| experience handling regulated complaints | C2, C3 | F2 and F3 |
| Own the member complaints process end to end across branches and the contact centre | C2, D1 | F3 and F4 |
| report monthly on complaint volumes and resolution times | C5, E1 | F5 and F6 |
| comfortable with Excel reporting | C5 | F7, a discovery row |
| coach branch supervisors on escalations | C4 | F8 |
| work with digital teams on self-service journeys | D3, E3 | F9, a discovery row |
| confident presenting to senior leaders | D2 | F10 |

## Sources

- **Provided:** the job description as pasted in your message; the values as copied on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email (the round structure and the values scoring); your summary of the July 2026 strategy brief; your background.
- **Searches and fetches:** none sent.
- **Not read:** the strategy brief itself. Its claims are as you summarised them.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values were pasted into this conversation, so the cheat sheet reads them directly. |
| 2. Ashgrove interview process, member experience lead | skipped | The recruiter's email fixes the three rounds, their lengths and the values scoring. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the brief supplies the figures the CO rows use. The brief itself was not read. |
| 4. Interviewer name | n/a | No interviewers are assigned yet. |
| 5. Representative JD | skipped | The job description was supplied. |

## Upgrade menu

- **The strategy brief itself, pasted as text:** the CO rows and A5 quote its wording instead of your summary.
- **The interviewers' names, once assigned:** persona weights for rounds 2 and 3, and a reverse question tied to each interviewer's career path.
- **Which rules governed your complaints log, regulated or not:** F2 becomes specific, and C3 gets a grounded answer.
- **Whether the spreadsheet was Excel, and whether it tracked resolution times:** F6 and F7 become specific, and C5's answer slots get answered.
- **Two or three complaint cases from your work, in your own words:** the values cheat sheet, C1 and J4 become story-mapped rows instead of scaffolds.
- **Deep research (L2), offered once:** a search for interviewer talks and recent Ashgrove news. It would take up to 6 further searches and 2 further fetches, and it adds the research targets the L1 accounting leaves out. Run only if you say so.
