# Priya: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** a single 60-minute peer conversation with Dan Kovac, Director of Sales Strategy. You and Dan report to the same VP.
**Built from:** your message only (JD highlights, your background, Dan's profile, your note on Northwind's priorities). No CV or full JD was supplied, and web research was refused in this session (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral / values alignment · **EXP** work-experience deep-dive · **JD** role-driven, against the listed requirements · **CO** company and strategy knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slots** are instructions for the interview, not questions to answer here. Where a slot says "if you did this, say how; if not, say so," the honest second branch is always allowed.

## Fit snapshot

Each requirement is set against the words you actually used. Quotes are exact.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Adjacent work, not GTM ownership. Say it at the quote's own scope: "Nine years in product strategy and ops at a consumer-tech company." Answer slot: if any GTM decision was yours to make, say which and how you decided; if none was, say that the product strategy is what you bring. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | An identified opportunity on one surface, credited with an ARR uplift. It is not a land, adopt, expand, renew map. Answer slot: if you mapped any lifecycle stage, say which and how; if none, say how you found the store-surface opportunity. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [grounded] | discovery | The sentence states a skill, not an analysis you ran end to end. Answer slot: if you have run an analysis from question to view in SQL and Tableau, say what it answered; if not, say the first query you would write. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Adjacent work: a revenue model used in negotiations, not a partner motion designed. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: what the model assumed about partner economics, and which part of a partner motion you would design first; if you designed none of the motion, say so and say what you would learn first. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches influence in role terms. Lead with it in its own words. Caveat: consensus is shared, so expect a probe on which part was yours. Targets are not quotas. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Use, not build. Words: "I use AI tools daily." Answer slot: which tools and what for in your work; if you have built anything with them, say what. |
| F7 | Not a JD line: a stated gap in your message | "No classic sales-ops or quota-setting experience." (your message) | high | [grounded] | capability | A stated negative, so the honest words are the plain acknowledgment: "I haven't set quotas or run sales ops." Then the plan: how you would learn quota mechanics in your first month. Never a claim to quota work. |

**Gate check:** no location, work-pattern, visa, pay or credential requirement appears in the material, so no row is a hard gate. If the recruiter lists one, it becomes a gate row with its own question.

## Reading the interviewer: Dan Kovac

- **Career pattern:** pricing and monetization roles, with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Practical implications:**
  1. Expect Prober questions on every metric. Count your numbers and name your weakest assumption before he does.
  2. Pricing, packaging and unit economics are his native language. Tilt case answers that way.
  3. The startup chapter means builder stories land with him, and he will probe whether big-company scale is hiding the scrappiness.
  4. As a peer, he is pricing what this hire costs and adds to his own work. Lead with reciprocity.
- **Mirror opportunity (shared domain, not shared identity):** his monetization career pairs with your sentence "built a partner-level revenue model used in carrier negotiations" (F4). Revenue models are common ground, so open there.
- **Public footprint:** not researched. No talks, posts or other public material were checked.

## Persona table

Weights follow the peer relationship prior, adjusted by Dan's profile. Depth follows weight: top personas get 4–5 questions, mid 3, low 2. Session total: 21.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators, counting method and assumptions; goes two levels deep | Top. Peer prior plus his self-described "relentlessly data-driven" raises it. Every headline number will be probed | Know how the $400M was counted, or say plainly you don't. Name the weakest assumption first. Offer to walk through your partner model | 5 |
| Peer Evaluator | Seam questions between teams; "what would you need from me"; credit and disagreement probes | Top. Peer prior. Same VP, so the seam is real and the cost of your hire to his load is the test | Reciprocity first: what you bring his team, then what you need. Propose seam principles, not facts about his team | 4 |
| Case / Strategist | Live problems: sequencing two lines, pricing against a bundle, profitability trade-offs | Mid. His pricing career makes pricing and unit economics the case tilt | Clarify, then objective, segmentation, approach, metrics, risks. Say the framework aloud once. Challenge one premise | 3 |
| Skeptic | Quiet probing of the quota and enterprise gaps | Mid. F7 and F3 are the gaps a peer will test, and the bundling threat makes the B2B question real | Rehearse the quota objection until it is boring. Calibrated candour, not a bluffed competency | 3 |
| Pressure / Stress | Interruptions, time-boxing, challenges to motive | Low. Peer conversation, but the 60 minutes is time-boxed and Dan may test composure | Pause, restate, hold a challenged position through two follow-ups, then concede specifically | 2 |
| Values / Behavioral | Cross-functional stories, unpopular truths, consensus | Low. No values round is detected: no loop source documents one, and no published values were read | Story from the quoted sentence where one carries it; scaffold where it does not | 2 |
| Conversational / Rapport | Friendly opener; "walk me through the journey" | Low, but scored. Casual questions on AI and the JD are still scored | Pre-scripted 90-second arc. Treat casual questions on hot JD topics as scored | 2 |

## Question banks

Each guidance cell is scaffolding: speakable in 90–120 seconds. Provenance carries the quoted sentence every claim about you rests on.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on the quote: you proposed the change, and the uplift is credited with it. Keep "credited with." Answer slot: how the figure was counted, in your own words. If you know the counting, say it. If you do not know how it was counted, say so plainly and say who would know | Headline CV metric, so the defend-the-number slot applies. Dan's style puts counting first. Tests attribution (F2) |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Weakest-assumption move: name the assumption you would defend least before he does, and what the figure is sensitive to. Answer slot: if you know an assumption behind the figure, say what it is. If you do not, say so and say what you would check first. Do not name an assumption the material does not give | The Prober stem. Converts a gotcha into a credibility point. Second level of the same metric probe |
| A3 | "A new product line has strong trial and flat expansion. Where do you look first, and what would you cut?" | CASE | [generic] | Structure aloud once: clarify what expansion means for this line; objective; segmentation by stage (land, adopt, expand, renew); metrics per stage; the first two cuts you would make; risks. State a hypothesis early. This question presupposes nothing about your past | Covers F2's whitespace requirement as a live problem. Dan's pricing and unit-economics tilt makes the cuts the probe |
| A4 | "What's the first query you would write to build the funnel for a product line?" | JD | [grounded] "skilled in SQL/Tableau" | Name the grain (accounts by stage, by month), the tables you would need, and the denominator you would check first. Answer slot: if you have built a query like this, say what it answered and what you checked on its output; if not, say the query you would write first and the check you would run on it | Covers the SQL and Tableau requirement and F3, the thinnest evidence row. The honest branch is rehearsed before the probe arrives |
| A5 | "A partner looks profitable on paper. How would you tell whether it is worth more than our direct channel?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on the quote: you built the model, and it was used in negotiations. Name the model's partner-economics assumption that matters most. Answer slot: which assumption you tested and what the test showed; if you tested none, say so and say what you would test first. Do not claim a negotiation outcome the material does not give | Covers the required partner-motion requirement. F4 is the nearest evidence, and the denominator question is Dan's native probe |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your team's work and mine, and what happens when we disagree on a number?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Propose a seam principle (who owns the number, who arbitrates it) rather than a fact about his team. Story-mapped on the quote: the targets, and the consensus step. Answer slot: a disagreement you had with an equal over a number, and how it was settled; if you did not settle one that way, say so and describe how you would handle it | Peer prior: the seam is how he weighs your load. F5 is the only evidence of influence over a number |
| B2 | "What would you need from me in the first month, and what would you bring back to my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity framing: what you bring his team is the revenue model you built, in its quoted terms. What you need from him is a read of his pricing assumptions. Name both plainly | Peer evaluators score whether the hire adds to or reduces their load. This is the reciprocity question the peer format requires |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on the quote: you proposed the change, and the uplift is credited to it. Answer slot: what you proposed, in its words; what others did on the surface, if you know; if you do not, say so | Peer stem on credit. The same headline quote is probed here for share, so keep the scope exact |
| B4 | "Enterprise expansion is one of Northwind's three priorities, and both our teams touch it. Where would a new product line collide with it?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your message, undated note) | Name the seam principle and the collision it prevents, using the priority in its own words. Say the collision point is your read, to be corrected by him | The only company-strategy question in the pack. It draws on your note, which is undated and unchecked, so confirm the priority before you lean on it |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches into a bundle fight. How would you price a new line against a bundled competitor?" | CO | [grounded] "bundling by a much larger platform vendor" (your message, undated note) | Clarify what the bundle includes and what buyers already pay. Objective: attach, not a price war. Segment by where bundling bites. Approach: price, packaging, partner terms. Metrics: attach, win rate, net revenue retention. Risks: cannibalizing the core. Challenge one premise: that the bundle is free to the buyer | Dan's native pricing and packaging. The threat is from your note, so verify it before the call |
| C2 | "How would you sequence go-to-market for two new product lines when one needs partners and one doesn't?" | CASE | [generic] | Clarify each line's buyer. Objective per line. Segment through land, adopt, expand, renew. Approach per line. Metrics and risks. Say which line you would launch first, why, and what would change your mind. Presupposes nothing about your past | Ties the two-line GTM requirement to the partner requirement in one live problem |
| C3 | "Profitability is one of the three priorities. How would you decide which line gets investment when both can't?" | CASE | [grounded] "reaching profitability" (your message, undated note) | Unit economics: payback, contribution margin, and the cost of each motion. Name the one metric you would rely on and why. Presupposes nothing about your past | Dan's monetization background is the native frame. Puts profitability in the room as a CO question |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't set quotas or run sales ops. Why should we believe you can own GTM targets for two new lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | Hold: return to what you did do, in its own words: "set annual volume targets with cross-org consensus." Say plainly that targets are not quotas. Concede specifically: "I haven't set quotas or run sales ops." Then the plan: how you would learn quota mechanics in your first month. Hold through two follow-ups; never fold on owning the GTM work | The single most likely objection, so the highest-ROI prep in this pack. The concession is the plain acknowledgment F7 supports. Rehearse three levels deep |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights) and "built a partner-level revenue model used in carrier negotiations" | Name partner-motion design as the area you would ramp first, honestly. Say what the revenue model covered, in your own words, then give the ramp. Answer slot: the partner-motion area you would ramp first, and the first partner data you would review | Persona stem for the Skeptic. The required partner-motion requirement is the gap the material shows most clearly, so the honest ramp is the answer |
| D3 | "Walk me through how you would run land, adopt, expand and renew for an enterprise product line." | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Live problem: structure by stage. Say which part of your product-strategy background transfers, in the quote's own words, and what is new to you. Answer slot: the stage you would own first and the data you would use; if you owned any stage before, say which; if none, say so and say what you would learn first | Covers the lifecycle requirement as a live problem. Asks nothing about enterprise B2B history, which the material does not show either way |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Hold: sixty seconds on the path, then why it fits both lines. Hold the path through two follow-ups. Concede specifically: enterprise lifecycle knowledge is the gap, and say what you would do about it first | Time-boxed challenge. Holding the path and conceding the lifecycle gap is the structure |
| E2 | "That result, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed it, and the uplift is credited to it." Concede uncertainty specifically: "I can't separate my share from the team's from memory, and I would check how it was attributed before I give a split." Do not fold on having proposed it | The composure test on the headline metric. The hold is exactly what the quote carries, no more |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A pre-scripted 90-second arc built on the quote, in your own words, ending on why the two lines fit. Do not add a role or result the quote does not carry | Casual openers are scored. A rehearsed arc is the defence against a rambling answer |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name two tools and one thing you use each for, in your own words. Answer slot: if you have built anything with them, say what it was; if not, say you use them and for what | The AI plus-skill asked casually, which is still scored. Use is the quoted claim; build is not |

### H. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you said something unwelcome to a senior person, with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | No values round is detected and no published values were read. Kept low-weight for cross-functional scoring. Presupposes no past event |
| H2 | "Tell me about a time you got two teams with different targets to agree on one number." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the quote: the targets, and the consensus. Answer slot: the sticking point between the teams and what you did about it; if nothing you did moved it, say so and say what settled it | Covers the cross-functional influence requirement. The quote carries the story's shape, not its middle |

### Reverse questions (you ask Dan)

| # | Question | Why it lands |
|---|---|---|
| R1 | "What did the early-stage chapter teach you about pricing that the monetization roles didn't?" | His path is pricing and monetization with one startup chapter. It turns a close into a peer conversation about his own path. Source: your message |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Signals you are thinking about his load, not only your offer |
| R3 | "Where does pricing end and the product-line owner's call begin?" | Names the seam directly. Dan will have a view, and his answer tells you where the decision rights sit |
| R4 | "When Compass launches, which numbers will your team be asked to explain first?" | Data-driven interviewer, and the copilot launch is one of Northwind's three priorities (your note). Shows you read the priorities |
| R5 | "Where has the bundling threat already shown up in deals, and how is the team responding?" | Company-strategy question on the named threat (your note). Lets him show the live problem, which is the strongest signal you can get in the room |

## Requirement coverage

| JD requirement | Covered by | Notes |
|---|---|---|
| own GTM strategy for two new product lines | C2, D1, D3 | — |
| identify whitespace across land/adopt/expand/renew | A3, D3 | — |
| run independent analysis in SQL and Tableau | A4 | — |
| partner-motion design experience required | A5, D2 | — |
| strong cross-functional influence | B1, H2 | — |
| AI experience a plus | G2 | — |

Defend-the-number slots for the $400M figure: A1, A2 and E2. Trade-off between seam and credit: B1 and B3.

## Prohibited claims

Built locally from the fit snapshot, because no dossier was supplied. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I designed the partner motion." | Inflated form of F4. The sentence is about a revenue model | F4's quote at its own scope. The pack's observation, in analysis only: the material says a revenue model used in negotiations, not a motion designed |
| "I owned the annual volume targets." | Inflated form of F5. The sentence says set with cross-org consensus | F5's quote at its scope. "Targets" is not "quotas"; never widen to quota ownership |
| "I drove the $400M." | Inflated form of the store-surface sentence | "credited with" kept verbatim. A1, A2 and E2 hold the scope |
| "I've run independent analysis in SQL and Tableau end to end." | Inflated form of F3 | "skilled in SQL/Tableau," and the A4 answer slot |
| "I built AI features." | Inflated form of F6 | "I use AI tools daily." Build only if you did, in your words |

Sourced negative, not a prohibited claim: F7's plain acknowledgment, "I haven't set quotas or run sales ops," is the honest form the pack gives you to say.

## Sources

**Provided documents:** your message, which carries the JD highlights, your background, Dan's profile and your note on Northwind's priorities. The note is undated, so its freshness is unchecked.

**Searches sent (all refused by the host):**
- "Dan Kovac Director of Sales Strategy Northwind Data": refused.
- "Northwind Data Compass AI copilot launch enterprise expansion strategy": refused.
- "Northwind Data company values principles": refused.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. No user links read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | All calls refused. Would have supplied published value names for VAL theming. Section 10 is not triggered, because no values round is detected |
| 2. Interview process, senior GTM | skipped | Your message fixes the loop: a single 60-minute peer conversation with Dan |
| 3. Northwind strategy / recent news | unavailable | All calls refused. Would have checked the freshness of your undated note, which feeds the CO questions B4, C1, C3, R4 and R5 |
| 4. Dan Kovac + Northwind | unavailable | All calls refused. Would have added public talks and posts, sharpening the interviewer read and the reverse questions |
| 5. Representative JD | skipped | JD highlights were supplied, so no representative JD was needed |

## Upgrade menu

- The full JD text → the mid-list requirements, and any named method or tool the highlights left out, become JD questions. Currently only the six highlights are covered.
- Your CV → F1 to F6 move from quoted-in-message to quoted-from-CV, and the $400M figure can be checked against its source document.
- Your own words on how the $400M was counted → A1 and A2 move from answer slots toward story-mapped guidance. Only share it if you are certain of it.
- Your own words on the quota negative → F7 moves from your message to your own sentence, which you can say in the interview.
- A SQL or Tableau artifact → F3 moves from low to medium confidence, and A4 can be rehearsed from something you can show.
- Dan's public footprint (talks, posts) → the reverse questions and the interviewer read sharpen. Needs search, which was refused here; it can be rerun if search is allowed.
- Web research allowed → values, interview-process and strategy-freshness checks, and the note's priorities confirmed.
- Any pre-declared deliverable from the recruiter → a graded-deliverable section. None is declared in the material.
