# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

Round: one 60-minute peer conversation with Dan Kovac, Director of Sales Strategy, who reports to the same VP. Built from your message. Web research did not run this session (search permission was refused), so every Northwind fact below is from your message or is labeled `[generic]`.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Type key:** VAL = behavioral and values fit. EXP = your past work, tested for attribution. JD = the job's stated requirements. CO = company and strategy knowledge. CASE = a live problem, no claim about your past.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- Provenance labels: `[grounded]` traces to your message or research note. `[inferred]` is derived, with the derivation named. `[generic]` is a role-family pattern with no claim about this company or you.
- Source names used below: "coach's notes" means the candidate summary in your message. "JD highlights" means the six requirement lines in your message. "research note" means your Northwind summary.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes); "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | transferability | The notes show adjacent work, a revenue model and volume targets, not a GTM plan you owned. Bridge at scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: a probe on GTM decisions for the two lines is likely. If you made any of those decisions, say which and how, in your own words. If you did not, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [inferred], derived from the JD line and from the absence of any sentence about whitespace or lifecycle stages in the notes | discovery | Nothing in the notes touches whitespace or the four lifecycle stages. Answer slot: if you have sized an unpenetrated segment or a lifecycle stage, say what it was and how, in your own words. If not, say so and say what you would look at first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | No gap, but a skill claim with nothing inspected behind it, so expect a probe. Say it in the notes' terms: "I'm skilled in SQL and Tableau." Answer slot: if there is one analysis you ran yourself, name it in your own words. If not, say so. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The notes carry partner-facing economics, not a partner motion you designed. Bridge at scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of a partner program, say which and how. If not, say so and say how the carrier model would inform one. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | presentation | The first quote already reaches the requirement in its own terms: consensus across orgs. Reword only: "I set annual volume targets with cross-org consensus." Add no meeting, stakeholder or reaction. The figure carries defend-the-number slots in A1, A5 and E2. Keep "credited with" in every sentence about it. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | The notes say use, not building. Bridge at scope: "I use AI tools daily." Answer slot: if you have built anything with AI, say what it was and your part in it. If not, say you use the tools. |
| F7 | `[generic]` quota-setting and sales-ops experience. A role-family expectation for a sales-strategy peer; not in the JD highlights | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | capability | The stated absence is the only words this row gives back: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, as a plan, never as a past. Never describe the volume-target work as quota setting. |

Gate check: none of the six highlights is a gate (no location, work-authorization, credential or pay term). The full JD may contain one. Upgrade menu, first line.

## Grounding brief

From your research note, quoted:
- Priorities: "enterprise expansion"; "an AI copilot launch ('Compass')"; "reaching profitability".
- Competitive threat: "bundling by a much larger platform vendor".

Flags: the note is undated and single-sourced, and no search confirmed it. Use the note's words. Confirm they are current before you say them out loud. Do not name the threatening vendor unless Dan does first.

## Reading the interviewer

Basis: your profile of Dan. His public footprint was not checked, because search was refused. Treat this read as your description, not as verified.

- **Career pattern:** your message gives his career spine as "pricing and monetization roles", with one "early-stage-startup chapter". He describes himself as "relentlessly data-driven".

Implications:
1. Expect every number to be tested for its inputs and its assumptions. Name the weakest assumption first. This is why the Prober bank is the largest.
2. Pricing, packaging and unit economics are his native language. Case questions tilt that way (bank C).
3. His startup chapter means he may probe big-company pace or scrappiness. Answer from what you did, and do not claim startup experience you do not have.
4. He is a peer, so reciprocity questions carry weight (reverse questions R2 and R4).

Mirror opportunity: a shared domain, not a shared jump. His "pricing and monetization" spine pairs with "built a partner-level revenue model used in carrier negotiations" (F4). No shared jump is established. Do not build one.

## Persona table

| Persona | Weight | How it shows up here | Why this weight | Counter-strategy | Bank |
|---|---|---|---|---|---|
| Data-Driven Prober | 5 | Each headline figure and the carrier model, tested for inputs and assumptions | Peer prior, raised one step by his self-description as "relentlessly data-driven" | Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted. Offer to walk one analysis end to end | A |
| Peer Evaluator | 4 | Seams between GTM and product, disagreement, credit across teams, what he would need from his team | Peer prior. A peer round is collegial and prices what the hire costs his team | Reciprocity first: what you bring his team. Propose seam principles, not claims about his org. Show spine and tact together in disagreement | B |
| Case/Strategist | 3 | Whitespace for enterprise expansion, a bundle against a standalone price, the Compass launch | Pricing and monetization spine tilts cases toward pricing and packaging | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise | C |
| Skeptic | 3 | GTM ownership, partner-motion design, the quota-setting absence | The JD's headline requirement sits where the notes are thinnest (F1, F4, F7) | Rehearse the single most predictable objection until it is plain. Bridges from adjacent evidence only. Calibrated candor | D |
| Pressure | 2 | A time-boxed "why you", and "how much of it was actually you" | Peer rounds rarely time-box, so the weight stays low, but the probe appears in every round | Pause, restate, anchor in the quote. Hold through two follow-ups, then concede specifically | E |
| Conversational | 2 | "Walk me through the journey", a casual question on AI | Casual register is still scored, especially on the plus items | A pre-scripted 90-second arc. Treat casual questions about JD topics as scored | F |
| Values/Behavioral | 2 | "Customer ahead of an internal metric", "an unpopular truth" | No values round is detected: no loop source names one, and your message gives one conversation with Dan. Touched at low weight so it is not met for the first time live | Selection scaffold ending in the honest branch. Say plainly when no example comes to mind | G |

Loop: your message establishes the loop, one session with Dan who is a peer. No archetype fallback applies, so the weights above rest on your round, not on a pattern.

## Question banks

Depth follows weight: Prober 5, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2, Values 2.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say what you know about how the figure was counted, in your own words. If you do not know the counting method, say that plainly and say what you would ask for first. Name the assumption behind the figure you would defend least before he asks. Answer slot: if you saw how it was calculated, say what it measured. If you did not, say so | F5 carries the figure, and a prober tests headline numbers first. EXP, because the test is attribution, not arithmetic |
| A2 | "Walk me through the partner-level revenue model: what were its inputs, and what was it most sensitive to?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped on F4: the model, and the carrier negotiations it was used in, in your own words. Name what it was most sensitive to, if you know. Answer slot: name the inputs you can name. If you cannot say how one was sourced, say that | F4 is the strongest partner-facing evidence, and a prober asks for inputs first |
| A3 | "What would have shown you the carrier model was wrong?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Open and hypothetical. Do not invent a validation step. If you compared the model with what happened, say what you compared. If no comparison was made, say so and name what you would compare first | Tests whether the candidate knows the model's assumptions and its own checks, the honest-attribution core of F4 |
| A4 | "Walk me through how the annual volume targets were set, and what they were measured in." | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-mapped on F5: the targets, the orgs, the consensus, which are the beats the quote states. Answer slot: if you can name the unit the targets were measured in, say it. If not, say so. Do not call them quotas (F7) | The nearest thing to quota setting in the notes, so the unit and the scope will be probed. F5 is the source for the cross-org influence requirement |
| A5 | "If the ~$400M figure were half as large under a different counting method, what would still hold?" | EXP | [grounded] "credited with a ~$400M ARR uplift" (coach's notes) | A hypothetical with no method claimed. Say what would still stand, in your own words, and what you would concede. Answer slot: if you do not know what the figure is sensitive to, say that plainly | The sensitivity branch of the defend-the-number slot for F5. Covers JD "run independent analysis" in its hardest form |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where would you draw the seam between GTM strategy and product, and what happens when the two of us disagree?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Propose seam principles, not claims about his org: who decides what, and how a disagreement is settled. For disagreement, use the consensus story at its scope: the targets, the orgs, the consensus. Answer slot: if you disagreed with a peer while reaching that consensus, say what it was and how it settled. If you did not, say so and give the nearest thing | Peer persona stem. JD-level because "strong cross-functional influence" is the scored behavior |
| B2 | "When work spans teams, how do you decide what to credit to whom?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Credit stays in the quote's words, "credited with". Say what you proposed, then the credit as it was given, in your own words, without claiming the uplift outright. Answer slot: if anyone else shaped the change, say what they did. If no one did, or you cannot separate the parts, say that | Credit-sharing is a peer probe. F5 is the only credit claim, and it stays at its scope |
| B3 | "What would you need from my team to start a GTM plan for one of the two new product lines?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Name three inputs you would ask for, in order: what the product team has decided, what data you would need, and who must sign off. Principles, not facts about his org | Reciprocity and first-step thinking. Covers the GTM requirement without any claim about your past |
| B4 | "How would you approach designing a partner motion?" | JD | [grounded] "partner-motion design experience required" (JD highlights) | Frame the design around partner economics and the carrier model in your own words, then the seam with direct selling. Answer slot: if you have designed any part of a partner program, say which and how. If not, say so and name what you would learn first from the partner team | F4's requirement in the peer's version of the question. Scores judgment where the notes cannot show design |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is a stated priority. Walk me through how you'd size the whitespace for a new product line inside enterprise accounts: what you'd need to know first." | CO | [grounded] "enterprise expansion" (research note) | Clarify first: what counts as enterprise, and what the line sells. Then objective, segmentation, approach, metrics, risks. Use the priority's own words. Name the data you would ask for. Do not assert knowledge of their accounts | Dan's pricing background tilts the case toward segmentation and unit economics. The whitespace requirement is the JD's, and the priority is the note's |
| C2 | "A much larger platform vendor is bundling. How would you price a standalone product against that bundle?" | CASE | [grounded] "bundling by a much larger platform vendor" (research note) | Clarify what the bundle includes and who buys it. Structure: the segments that buy standalone versus in-bundle, the price fence, the metrics (win rate, attach), and the risks (anchoring, erosion). Think aloud and challenge one premise | Pricing and packaging is his native register. The threat comes from the note, so the question stays at its scope |
| C3 | "The AI copilot launch is a priority. What would you need to believe for a product-line GTM plan to pay off in its first year?" | CO | [grounded] "an AI copilot launch ('Compass')" (research note) | Clarify the timeline and the product's job. Then state the beliefs (adoption, attach, price) and what would show each is false. Keep the copilot as the company's product, not yours | Covers the JD's "AI experience a plus" in a case form, and the Compass priority from the note |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What's the closest you've come to owning a GTM plan, and where would you start on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes); "set annual volume targets with cross-org consensus" (coach's notes) | **Highest-ROI prep in this pack.** The bridge uses only the two quotes: the carrier model and the consensus targets, each at its scope. Answer slot: if you have owned any part of a GTM plan, say which and how, in your own words. If you have not, say that in your own words, then give the first 30 days you would plan. Hold through two follow-ups by returning to the quotes. Follow-up ladder: what did you decide, what would you change, how would you know | F1 is where the headline requirement presses hardest and where the notes are thinnest, so this objection arrives in some form. JD because it scores the stated requirement |
| D2 | "Which requirement would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the weakest requirement yourself, and the closest sentence you have. Answer slot: if you have designed a partner program, say which and how. If not, say so and say what you would do first | Persona stem. F4 is transferability, and a skeptic asks for the honest weakest point. Choosing it yourself is the credibility move |
| D3 | "Your background has no classic sales-ops or quota-setting experience. Why should a sales-strategy team trust your numbers?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes); "set annual volume targets with cross-org consensus" (coach's notes) | Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the nearest work at its own scope: "I set annual volume targets with cross-org consensus." Do not call the targets quotas. Answer slot: say how you would check a number before a sales team relies on it, as a plan | F7 is the stated limit. Dan's own domain is sales strategy, so this is the peer's version of the same objection |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has owned a GTM plan?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Pause, restate the question, then answer in 60 seconds from what you carry: the carrier model and the consensus targets, each at its scope. Hold through two follow-ups. Answer slot on the GTM part: say where you are, in your own words. Do not argue that you are better than someone you have not met | Time-boxed challenge, the hold-then-concede structure. F1 and F5 carry the honest bridge |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold the sentence: you proposed the change, and the uplift is credited with it. Concede the part you cannot separate, specifically and in your own words. Do not fold on "proposed", and do not claim more | Pressure probe on F5's figure. EXP because it tests attribution under time |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A pre-scripted 90-second arc: two years in strategy consulting, then nine in consumer-tech product strategy and ops, then the carrier model and the consensus targets. Answer slot: say why this role, in your own words | Casual register, still scored. The arc keeps to the sentence's scope |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools you use and what you use them for, at that scope. Use, not building. Answer slot: if you have built anything with AI, say what it was and your part | A casual question on a plus item, scored. F6 gives the honest bridge |

### G. Values/Behavioral (weight 2)

No values round is detected, so these stay `[generic]`.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] selection scaffold from the persona stem; no quoted sentence raises it | Pick a time you chose a customer outcome over an internal target, with a named stake. Say the target and the outcome in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem, no published values found, no values round documented. Touched at low weight so it is not met for the first time live |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] selection scaffold from the persona stem; no quoted sentence raises it | Pick a time you told senior people something they did not want to hear, with a named stake. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem, low weight. Generic because the notes name no such moment |

### Requirement coverage

| JD highlight | Questions that cover it |
|---|---|
| own GTM strategy for two new product lines | B3, D1, E1 |
| identify whitespace across land/adopt/expand/renew | C1 covers expand only. No question covers land, adopt or renew: the highlights name the lifecycle once and the full JD is missing. Add it and this line gets its questions |
| run independent analysis in SQL and Tableau | A1, A2, A5 |
| partner-motion design experience required | B4, D2 |
| strong cross-functional influence | B1, B2, A4, E2 |
| AI experience a plus | C3, F2 |

## Reverse questions

Five, each with why it lands. R1 is tied to Dan's path. R2 is the peer reciprocity question.

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| R1 | "Your career spine is pricing and monetization. Which of those lessons carry into sales strategy?" | [grounded] "pricing and monetization roles" (your profile of Dan) | It converts a formal interview into a peer conversation about his own path, and shows you looked at him, not only at the role |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | [generic] reciprocity question for a peer | Shows you are thinking about what you add to his team, not only what you need from it |
| R3 | "Which of enterprise expansion, the Compass copilot launch, or reaching profitability is changing sales strategy most right now?" | [grounded] "enterprise expansion"; "an AI copilot launch ('Compass')"; "reaching profitability" (research note) | Shows you are current on the priorities. Confirm the note is current before you use it |
| R4 | "Where does your team's work meet the product teams on the two new lines, and where do you see friction?" | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Invites his view of the seam, which is a peer conversation and a test of the role's real scope |
| R5 | "How is the team thinking about the platform vendor's bundle?" | [grounded] "bundling by a much larger platform vendor" (research note) | Shows you read the competitive frame. If he does not want to discuss it, drop it and move on |

## Prohibited claims

What this pack will not coach. Built locally from the fit snapshot, since no dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a GTM plan for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's own observation: the notes say a revenue model and volume targets, not a GTM plan you owned |
| Designed a partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations", at its scope |
| Set quotas, or ran sales ops | Stated negative in F7; inflated form of F5 | "I don't have classic sales-ops or quota-setting experience." The volume targets at their own scope, never called quotas |
| Drove the ~$400M uplift | Inflated form of F5: "credited with" widened to "drove" | "proposed a store-surface change credited with a ~$400M ARR uplift", with "credited with" kept |
| Led cross-org alignment | Inflated form of F5: "with consensus" widened to "led" | "set annual volume targets with cross-org consensus" |
| Negotiated the carrier terms | Inflated form of F4: "used in carrier negotiations" widened to "set the terms" | "built a partner-level revenue model used in carrier negotiations" |
| Built AI features or products | Inflated form of F6: "uses AI tools daily" widened to "built" | "I use AI tools daily" |
| Ran independent SQL and Tableau analysis that drove decisions | Inflated form of F3: "skilled in SQL/Tableau" widened to decisions | "skilled in SQL and Tableau", at its scope |

## Sources

**Provided documents:** your message, which holds the role, the JD highlights, the coach's notes on the candidate, the profile of Dan, and the research note on Northwind.

**Searches and fetches sent:**

| Query | Result |
|---|---|
| Dan Kovac Northwind Data Director of Sales Strategy | refused (search permission not granted this session) |
| Northwind Data company values | refused (search permission not granted this session) |

**Research tier:** L1, searches 2 of 6, fetches 0 of 2.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Both calls were refused. Would have moved the values cheat sheet, which is not generated: no values round is detected |
| 2. Northwind interview process, sales strategy | unavailable | Search was refused. Would have checked the loop. Your message already establishes one 60-minute session with Dan, so the loop does not need an archetype fallback |
| 3. Northwind strategy and recent news | unavailable | Search was refused. Would have checked the research note's priorities and threat, which are undated and currently unconfirmed |
| 4. Dan Kovac, Northwind | unavailable | The one call was refused. Would have moved the interviewer read from public footprint and one reverse question |
| 5. Representative Director of Sales Strategy JD | skipped | The JD highlights you supplied fix the requirement list for this pack |

## Upgrade menu

- The full JD text → every stated requirement gets a question ID, the land, adopt and renew lines get their questions, and any location, authorization or credential term is checked as a gate
- Priya's CV, or her own sentences for the coach's-note lines → the quotes become her words, and the no-quota acknowledgment in F7 and D3 is confirmed as hers
- Search permission for this session → Dan's public footprint, a check of the research note's currency, and Northwind's values if a values round is documented. A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) is available once, on your say-so
- The recruiter's note on the 60 minutes → any focus areas or deliverable, which would reweight the banks
- Any talks or posts by Dan → sharper reverse questions and a stronger interviewer read
