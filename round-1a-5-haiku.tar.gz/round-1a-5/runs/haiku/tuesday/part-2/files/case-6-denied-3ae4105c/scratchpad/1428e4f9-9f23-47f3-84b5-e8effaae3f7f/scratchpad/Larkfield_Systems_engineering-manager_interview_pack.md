# Larkfield Systems, Engineering Manager: interview prep pack (loop mode, three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Round 1, Tuesday, 45 min: hiring manager, Director of Engineering
- Round 2, the Thursday after, 60 min: panel of two staff engineers and a product manager
- Round 3, the following Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

**Built on:** your message and the role description in it. No job description text, no interviewer names, and no company research (the web searches were refused; see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values and behaviour), EXP (your own experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.
- An **answer slot** is an instruction for the interview: it names an honest branch for you to take. It is not a question to answer here.
- Question IDs are per round: R1, R2, R3, then the persona letter and number.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (role description in your message) | "I run our hiring loop for backend roles — about 40 interviews last year" (your message); "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows a team of six and the backend hiring loop, not eleven engineers. Say the loop in its own terms: you run it, and about 40 interviews went through it last year. Answer slot: the requirement says growth, so expect a probe on it. If you planned development for engineers on your team, say how; if you did not, say so and say what you would do first. |
| F2 | "Lead two squads building device-management services" (role description in your message) | "3 as a team lead of 6" (your message) | low | [inferred] | discovery | The material shows one team of six. It does not show two squads. Answer slot: if you have led more than one team at once, say how the work was split; if you have led one team, say so and say how you would run two. |
| F3 | "partner with hardware and product on roadmap" (role description in your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Plain acknowledgment, from your own sentence: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F4 | [generic] delivery under roadmap pressure on a platform service (no quoted source) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | The sentence already reaches the requirement in role terms. The 60% figure raises the defend-the-number slots in R1-C1, R2-B1 and R2-B2: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| F5 | [generic] location and on-site pattern for this role (no quoted source) | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. Asked in the message that presents this pack. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or ran two teams | Inflated form of F2 | "3 as a team lead of 6," at its own scope. The pack's observation: the material shows one team of six. |
| Managed managers | Sourced negative you stated | Plain acknowledgment: "I've never managed managers." No slot about managing managers. |
| Owned a hardware-adjacent roadmap | Sourced negative you stated (F3) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." |
| Cut on-call by 60% on my own | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Your individual share is the question, not a given. |
| Ran hiring for eleven engineers | Inflated form of F1 | "I run our hiring loop for backend roles — about 40 interviews last year," at its own scope. |

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| own delivery, hiring and growth for 11 engineers | R1-A2, R1-A3, R3-A3 | Growth is covered in R3 as a development story |
| Lead two squads building device-management services | R1-A3, R2-A1 | |
| partner with hardware and product on roadmap | R1-A1, R1-B3, R2-A3, R2-C2 | |
| Location and on-site pattern (F5) | none, and why | A gate the material does not settle; asked in the message, not bridged |

---

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (4 questions) | Live problems on the partnership and the two squads | High. A hiring manager is buying capability and testing it on the actual roadmap (relationship prior) | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Skeptic (3) | The negatives you stated, and the motivation probe | High. A hiring manager derisks the gaps (relationship prior) | Rehearse the one objection until it is boring: R1-B2 |
| Data-Driven Prober (2) | The 60% figure | Medium. It is the headline number and the likeliest place to be probed | Defend-the-number, with the weakest assumption named |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Device management is slipping on one squad, and hardware wants a firmware window that product has not agreed. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which squad, what is slipping, what the window costs, who decides. State the objective aloud, then your segments. Name one premise you would challenge. No past claim is needed. | A live problem from the role's partnership line. It tests F3 without asking about your past. |
| R1-A2 | "Walk me through how you ran the backend hiring loop. How did you decide what a good hire looked like?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F1: the loop you run and the about 40 interviews. Answer slot: the question presumes you set the bar. If you set it, say what it was and how you tested it; if it came from elsewhere, say so and describe how you used it. | F1's hiring requirement is probed here. The premise "what a good hire looked like" presumes a bar the quote does not carry, so the second branch stays open. |
| R1-A3 | "Eleven engineers across two squads. How would you structure that, and where would you put the seam?" | JD | [generic] | No past claim. Name the seam between the squads first, then the lead layer, then how you would know the structure is working. If you have run two teams at once, say how, in your own words. If you have not, say so plainly and describe the structure you would set up. | F2's requirement, asked as a design. The honest answer is available either way. |
| R1-A4 | "Tell me about the hiring loop you run. Which part of it would you change first?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F1: the loop, the about 40 interviews. Answer slot: if you have changed the loop, say what changed and why; if you have not, say what you would change and how you would test it. Do not claim results you were not given. | A follow-on to R1-A2 that tests whether the loop is yours to change. |
| R1-B1 | "You have been a team lead for three years. Why is this the next step rather than a staff track?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" | Story-mapped on the quote: nine years, three as a lead of six. Your reasons for the move are yours, in your own words; the pack supplies none. Hold them to what you can say you want. | The Skeptic's motivation probe. The material gives the years and the team size, not the reason. |
| R1-B2 | "You have never managed managers. How would you lead leads when you haven't done it?" | JD | [grounded] "I've never managed managers" | Plain acknowledgment: "I've never managed managers." Then how you would learn it, said as a plan and never as a past. Name one thing you would do in the first month. Do not describe managing managers. | The most predictable objection to you, and the highest-ROI rehearsal in this pack. The negative is yours, so say it first and plainly. |
| R1-B3 | "You have never owned a hardware-adjacent roadmap. What would you get wrong first?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then name what you would check first with hardware and product, as a plan. No slot for a past hardware decision. | F3's capability gap. The question targets the weakest requirement, and the negative has a source. |
| R1-C1 | "Walk me through how the 60% on-call drop was counted. Which assumption would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slot: if you can say how it was counted, say it in your own words, then name the weakest assumption you know of. If you do not know how it was counted, say so plainly and name the assumption you suspect. | The headline metric draws a defend-the-number probe. The counting method is not in the material, so "I don't know" is an honest branch. |
| R1-C2 | "Which part of that reliability quarter was yours, and which part did your team do?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Attribution: "I pushed ... through" is your sentence. Say what you did in that quarter; if the work was your team's, say so. Do not widen "pushed through" into "designed" or "ran" the work. | An attribution probe on the same figure. The quote carries the push, not the design. |

### Reverse questions

1. "What would the first ninety days look like for this seat, and what would success be by day ninety?" Why it lands: it shows you are planning, and the answer tells you the real scope.
2. "How do the two squads split the device-management work today?" Why it lands: you test the seam before you walk into it.
3. "When hardware and product disagree on the roadmap, who decides, and how often does it get escalated?" Why it lands: the partnership is the hard part of this role, and the answer shows the decision rights.
4. "What has the hiring plan for the eleven engineers looked like over the last year, and where is it behind?" Why it lands: it treats the scope as a hiring problem, which is the job.
5. "At a six-month check-in, what would tell you this hire was the right call?" Why it lands: it draws out the Director's own bar.

---

## Round 2: Panel (two staff engineers and a product manager), Thursday, 60 min

### Persona weights

The panel members are not named, so the weights blend the top two personas of each member's relationship (the panel row of the relationship priors). Staff engineers: Peer Evaluator and Data-Driven Prober. Product manager: Peer Evaluator and Case / Strategist.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4) | The seam with the staff engineers, disagreement, what they would need from you | High. Peers price what the hire costs and contributes to their work | Reciprocity framing, seam principles rather than a claim to know the seam, a disagreement story with spine and tact |
| Data-Driven Prober (3) | The 60% figure again, from the staff engineers | High. Staff engineers read the numbers closely | Defend-the-number, weakest assumption named first |
| Case / Strategist (2) | Live fleet and sensor problems from the product manager | Medium. The product manager brings the roadmap trade-offs | Clarify before structuring |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Our staff engineers own the architecture. Where is the seam between your squads and theirs, and what happens when you disagree?" | JD | [generic] | Reciprocity: propose seam principles, not a claim to know the seam. Name who decides the architecture, how a disagreement gets resolved, and what you would do first. If you have had a real disagreement with a peer team, say it in your own words. If not, say how you would handle one. | The seam is the partnership requirement. No past claim is in the guidance. |
| R2-A2 | "Tell me about a time you pushed back on roadmap pressure. What did you hold?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the quote. Beats: the pressure, the reliability quarter, the on-call result. Answer slot: if you conceded something to get it through, say what; if you conceded nothing, say so. Do not add a stakeholder's reaction you were not given. | A peer probe on pushing back against product and hardware. The quote is the only story the material carries. |
| R2-A3 | "How do you bring product and hardware into a roadmap decision you disagree with?" | JD | [generic] | No past claim. Name the decision rights first, then the escalation path, then what you would want to learn from hardware before you argue. | The roadmap-partnership requirement, asked as a live judgement. |
| R2-A4 | "Where do the staff engineers and product most often disagree, and how does that get resolved?" | JD | [generic] | No past claim. Ask what you would need to know, name the forum where it gets settled, and say what you would bring to it. | A seam question posed as a judgement, aimed at the panel's own tension. |
| R2-B1 | "You said on-call dropped 60%. What was the baseline, and over what window?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slot: the baseline and window are not in the material. If you know them, say them in your own words. If not, say you do not have them to hand, and name the assumption you would check first. | A Prober probe on the headline figure. The quote does not carry the baseline or the window. |
| R2-B2 | "Which on-call pages were in that count, and which were left out?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slot: say which pages you can account for. If you cannot say, say so plainly; do not reconstruct a definition on the spot. | A second probe on how the figure was counted. |
| R2-B3 | "How much of that drop would have happened without the quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: the counterfactual is an assumption. If you can separate the quarter from other changes, say how. If you cannot, say so and name the other changes you know of. | The attribution check. The quarter's share of the drop is the assumption the figure rests on. |
| R2-C1 | "A firmware rollout doubled the failure rate on one device model. Walk us through how you would diagnose it." | CASE | [generic] | Clarify first: which model, which firmware, which regions, since when. Objective, then segmentation, then rollback against fix, then the metrics you would watch. Name one premise you would challenge. | A live fleet-reliability problem in the role's own domain. No past claim. |
| R2-C2 | "Hardware says the next sensor needs a six-month validation cycle; product wants three months. How do you decide?" | CASE | [generic] | Clarify what the validation protects against and what the three months would cost. Name who owns the decision, the trade you would propose, and the risk you would carry. Say what you would want from hardware before you argue. | F3's partnership gap, tested as a live judgement. The candidate's past is not touched. |

### Reverse questions

1. "What is the one thing about the device-management services you would change if you could?" Why it lands: it invites candour and shows you want the panel's own view of the system.
2. "What would a new engineering manager do in their first month that would genuinely help your teams?" Why it lands: a reciprocity question, which a peer panel weights heavily.
3. "Where do the staff engineers and product disagree most, and how does that get settled?" Why it lands: it shows you noticed the seam.
4. "How are the reliability and feature roadmaps traded off right now?" Why it lands: it lets the panel show you the trade-off you will inherit.
5. "What does a good roadmap conversation with hardware look like here?" Why it lands: it is the gap F3 names, and you learn the bar.

---

## Round 3: VP Engineering, Monday, 30 min

### Persona weights

The recruiter's words name a values and leadership round, so the round is a values-style round. Persona weights follow that: the dedicated values prior puts Values / Behavioural first, the skip-level prior adds Pressure, and the cross-functional prior adds Conversational.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural (4) | Scenario probes on principles and on leadership philosophy, often as STAR-shaped stories | High. The recruiter named the round | Map a story to each quote where one carries it. Use a selection scaffold with its honest branch where none does. "We" for context, "I" for what you did. |
| Pressure (2) | Time-boxed challenge on your strongest claim | Medium. Skip-level rounds test composure | Pause, restate the question, anchor in what you can back. Hold through two follow-ups; concede the uncertain part only. |
| Conversational (2) | The opener and the closing question, which are scored too | Medium. Casual questions are still scored | A 90-second arc built only from your quoted sentences |

No values cheat sheet is included: the company's published values were not retrieved, and the cheat sheet needs them. The values questions below use the recruiter's words as their raising source.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] scaffold; nearest material: "I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: pick a time you told leadership something they did not want to hear. It needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter you pushed through against roadmap pressure. Keep "we" for context and "I" for what you did. | A values-round stem. The material carries no unpopular-truth story, so the honest branch is written in. |
| R3-A2 | "What is your leadership philosophy, in a sentence, and where did it come from?" | VAL | [generic] | Say the sentence you actually hold, then name where it came from in one concrete instance. If you have not written one down, say so, and give the principle you use most. | The recruiter's "leadership philosophy" is the raising source. The answer is yours, so no guidance supplies one. |
| R3-A3 | "Tell me about someone you developed who went on to outgrow you." | VAL | [generic] scaffold | Selection scaffold: pick a person you developed who moved on or up. Name what you did to develop them, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it. | A growth question for the role's "growth" requirement. Your material has no development story, so the branch stays open. |
| R3-A4 | "Tell me about a time you said no to a team that needed something from you." | VAL | [generic] scaffold | Selection scaffold: a no with a stake on each side. Say what you refused, why, and what happened to the team. If you have not said no in a way that cost something, say so, then describe how you would decide. | A principles-under-pressure probe. The material carries no refusal story. |
| R3-B1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" | Pressure: pause, restate the question, anchor in what you can back. Hold the anchor: nine years, three as a lead of six. Hold through two follow-ups; concede only what is uncertain. Do not claim facts about the other candidates. | A pressure stem. Your answer is your own reason; the material holds no fact about any internal candidate. |
| R3-B2 | "Your 60%: how much of that was actually you?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Hold-then-concede: hold "I pushed a reliability quarter through against roadmap pressure" as your part. Concede the counting if you cannot give it. Do not fold on the quarter. | A pressure probe on attribution. The held position is one the quote carries, so the hold stays inside it. |
| R3-C1 | "So, walk me through the journey." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6"; "I run our hiring loop for backend roles — about 40 interviews last year" | Conversational: a 90-second arc in your words, from those two quotes: nine years, three as a lead of six, the hiring loop you run, then what you want next. Do not extend the arc past the quotes. | A casual opener is still scored. The arc is built only from your sentences. |
| R3-C2 | "What part of this job are you most looking forward to?" | VAL | [generic] | Name one part of the role the description gives and say why it draws you. Keep it to your own reason. Do not guess what they want to hear. | A closing question scored as motivation. The answer is yours. |

### Reverse questions

1. "What does leadership mean here in practice, not on the slide?" Why it lands: the recruiter used the phrase "leadership philosophy," and this lets the VP answer in their own words.
2. "What have you seen people get wrong when they move from leading a team to leading leads?" Why it lands: it opens the step up as a plan conversation, which is where the honest answer sits.
3. "What would you need to see from a new leader in the first six months to call the hire a good one?" Why it lands: it shows you are thinking about their criteria.
4. "How does the company decide when a delivery date should give way to a reliability fix?" Why it lands: it lets the VP speak to the trade-off in your F4 story.
5. "What is the leadership decision here you would most want the new person to take over first?" Why it lands: it asks for concrete ownership.

---

## Sources

**Provided documents:** your message, which holds the background and the role description. No job description text, no interviewer names, no values page, and no company material was provided.

**Searches sent (all refused):**
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT strategy news": refused

**Fetches sent:** none.

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search refused. The values cheat sheet is dropped; round 3's values questions use the recruiter's words instead. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Search refused. The round structure rests on your and the recruiter's descriptions of three rounds, and the persona weights follow those. |
| 3. Larkfield Systems strategy and recent news | unavailable | Search refused. Company knowledge (CO) questions are generic and labeled so. None is grounded in current strategy. |
| 4. Interviewer name with company | n/a | No interviewer name was given. |
| 5. Representative engineering manager JD | unavailable | No search sent. A representative JD would have grounded the requirement rows and their JD questions as [inferred]. |

## Upgrade menu

- The full job description text → the three requirement rows become [grounded] against the posting, and the JD questions can be checked against it
- The recruiter's note on what each round scores → persona weights and coverage in each round
- The names of the three interviewers, and the two panel members → a per-interviewer read, per-member persona weights, and tailored reverse questions
- The official values page, pasted → round 3's VAL questions get published values, and a values cheat sheet is added
- Search access in a later session → the three company targets above can be run; a deeper strategy pass (up to 6 more searches and 2 more fetches, several more minutes) can be offered then
- Any take-home or presentation the recruiter announced for any round → a graded deliverable section
- Your answers to the answer slots (F1 on growth, F2 on two squads, the 60% baseline and window) → those become quoted material, and the rows that draw on them regenerate
