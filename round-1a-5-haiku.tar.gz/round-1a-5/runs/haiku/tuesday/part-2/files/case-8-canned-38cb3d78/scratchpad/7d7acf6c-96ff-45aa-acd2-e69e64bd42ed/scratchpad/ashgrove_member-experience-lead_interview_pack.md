# Prep pack: Member Experience Lead, Ashgrove Credit Union

**Loop mode.** Three rounds on 4 December 2026: a 30-minute recruiter screen, a 45-minute behavioural round with the Head of Member Services (your future manager, not yet named), and a 60-minute panel of two branch managers (not yet named) that includes a 20-minute complaint-escalation case and scores the four values. One shared fit snapshot and sources block, then a mini-pack per round.

Built on: the three-round loop as the recruiter described it, the JD and values and strategy summary you pasted, and your background as you gave it. No CV, no dossier and no web research were used.

## How to use this pack and type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you did.

- **VAL**: behavioural and values alignment, whether past behaviour shows the published values.
- **EXP**: work-experience deep-dive, whether your claims survive scrutiny and what you personally did.
- **JD**: the role's stated responsibilities and qualifications, including the gaps.
- **CO**: company and strategy knowledge, thinking at their altitude.
- **CASE**: a live problem from the role, with no claim about your past.

Question IDs are lettered per round: A for round 1, B for round 2, C for round 3.

## 1. Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Length of experience is met on your account. Say it in your words: "6 years in retail banking, the last 3 as a branch supervisor." Expect a probe on whether a branch counts as customer operations in their sense. Your material does not show which of those six years, if any, was operations as the JD means it. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material says a branch's formal complaints log. It does not say the log was held to a regulatory standard. Words: "I handled the branch's formal complaints log." Answer slot: if the log was held to a rule or deadline you worked to, say which and how you tracked it. If it was not, say so plainly and describe how the log was run. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | medium | [grounded] | transferability | One branch's log is adjacent to the process the JD describes, not the same thing. You have also stated the contact-centre absence. Words: "I handled the branch's formal complaints log." For the contact centre: "I've never worked in a contact centre." Answer slot: if a complaint of yours ran across more than one branch or into another team, say how and what was yours. If not, say so plainly and say how you would set up the end-to-end view. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Monthly complaints reporting reaches the requirement. Resolution times are not in your words. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the spreadsheet tracked resolution times, say how they were counted. If it did not, say so plainly and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The spreadsheet is inspectable proof you can show in the interview, anonymised. Words: "I built the monthly complaints spreadsheet our regional manager uses." Expect a probe on which Excel features you used. Say only what you used. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Your material shows you trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or colleague through an escalation, say who and what changed. If you did not, say so plainly and describe your first step. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated, and the words cannot close it. Words: "I've never presented to anyone above regional level." Then your ramp plan, said as a plan and never as a past. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: if you have worked on a self-service journey, say what you did and where it stopped. If you have not, say so plainly and say how you would start with the digital team. |

No requirement in the JD is a gate under the evidence rules, so no row is `hard_gate`.

**Pack's observation (analysis, not words for you):** your material does not show a contact centre, presenting above regional level, a self-service journey, or resolution-time reporting. Those are the four places the panel is most likely to press.

## 2. Prohibited claims (built from the fit snapshot)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not the process across branches or the contact centre. B2's slot stays inside the log. |
| Worked in a contact centre | Negative you stated | "I've never worked in a contact centre." Plain acknowledgment, no slot. |
| Presented to senior leadership | Negative you stated (F7) | "I've never presented to anyone above regional level." Plain acknowledgment, no slot. |
| Owned the regional complaints reporting | Inflated form of F4 and F5 | "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material does not show who set the reporting cycle. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." The limit is the pack's observation: tellers, not supervisors. |

## 3. Round 1: recruiter screen (30 minutes, recruiter)

**Persona weights.** The recruiter-screen prior is Conversational with a light Skeptic. Logistics questions (pay, notice, location, reason for leaving) are the screen's scored slots, so they take most of the round. Weights: Conversational 3 (A1, A2, A8), logistics 4 (A4 to A7), light Skeptic 1 (A3).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc built only from those three sentences, in that order, in your own words. Stop there. | Conversational opener, but scored for communication economy. Built from F1, F2 and F4. |
| A2 | "Which of the four values do you hold yourself to most in a branch?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (provided values) | Pick one value and a moment from the complaints log where it applied. Selection scaffold: pick a time a value changed a decision on a complaint. If none comes to mind, say so plainly, then give the nearest thing your log carries, or how you would handle one. | Values are scored from the first contact. Only F2 carries a story-shaped sentence, and it does not state a decision. |
| A3 | "You've never worked in a contact centre. How would you approach one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level" (your message) | The premise is your stated negative. Plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan: what you would learn first from the team. No past claim. | Light Skeptic. F3's gap, rehearsed so the honest answer is ready. |
| A4 | "What are your pay expectations?" | JD | [grounded] recruiter's screen format; no figure in your material | Your material gives no figure, so this slot is yours. Either give the figure you have chosen, or ask for the band first: "I'd like to understand the band for this role first." Give no figure you have not chosen. | Logistics slot under the recruiter-screen rule. |
| A5 | "What's your notice period?" | JD | [grounded] recruiter's screen format; no notice period in your material | Give your actual notice period. | Logistics slot under the recruiter-screen rule. |
| A6 | "Where are you based, and how often could you be in an office?" | JD | [grounded] recruiter's screen format; no location in your material | Give your actual base and the office days you can commit to, in your own words. | Logistics slot under the recruiter-screen rule. |
| A7 | "What's the reason you're looking to leave?" | EXP | [grounded] recruiter's screen format; no reason in your material | State your reason in one sentence, in your own words. Do not add what you want next. If asked that separately, it is a separate answer. | Logistics slot. The recruiter will likely score it for consistency with the rest of the story. |
| A8 | "What's your read of the digital shift in member service?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message, summary of the strategy brief) | Keep to what the 40% goal changes for a complaints lead: which complaints move to digital, and which should not. Say it as your view, since the brief does not give one. | Strategy-fluency question from the brief. Shows you read it. |

**Round 1 reverse questions** (ask at least five):
- "What happens after the 4 December rounds?" Why it lands: it sets your timing and shows you are planning the process too.
- "How do complaints move today between branches and the contact centre?" Why it lands: it tests F3 quickly. Their answer tells you what the lead would inherit.
- "How are complaint volumes and resolution times reported to leadership now?" Why it lands: it links to F4 and shows you read the JD.
- "What does success look like at six months?" Why it lands: it signals that you think in outcomes.
- "How does the digital team's self-service work touch complaints?" Why it lands: it reaches F8, the requirement with no evidence yet.

## 4. Round 2: behavioural round with the Head of Member Services (45 minutes, future manager)

**Persona weights.** A manager's prior is Case and Skeptic. The recruiter said this round is mostly behavioural, so Case drops to one question and Values/Behavioral rises to a tie with Skeptic. Weights: Values/Behavioral 3 (B1, B6, B9), Skeptic 3 (B2, B3, B7), Data-driven Prober 2 (B4, B5), JD coaching 1 (B8), CO 1 (B10).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt from the values round; no candidate claim | Open prompt. Pick a time you carried a hard message up the line, with a named stake and a moment you didn't fold. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A behavioural opener. Your material has no instance above regional level (F7). |
| B2 | "End to end across branches and the contact centre, and you've handled one branch's log. What does owning that look like for you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "Never worked in a contact centre, and I've never presented to anyone above regional level" (your message) | **The highest-ROI rehearsal in this pack.** Hold with your one quote: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log, never by adding to it. Concede specifically: "I've never worked in a contact centre." Answer slot: if a complaint of yours ran across more than one branch or into another team, say how and what was yours. If not, say so plainly and say how you would set up the view across branches. | Named by the pack as the most predictable objection. It is F3's gap, and the JD's headline line presses on it. Expect it in some form. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level"; "Never worked in a contact centre" (your message) | Name the stated gaps in plain words: "I've never worked in a contact centre," and "I've never presented to anyone above regional level." Then give your ramp plan, said as a plan. Do not bluff a competency. | Skeptic, the direct version. F3 and F7. |
| B4 | "Walk me through how the monthly spreadsheet works." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it holds and who uses it, in your words. Answer slot: if it tracks resolution times, say how they are counted. If it does not, say so plainly. | Prober, mid-weight. Defends F4 and F5. |
| B5 | "How would you report monthly on volumes and resolution times to this team?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Describe the report you would build: its audience, cadence and the two measures. The spreadsheet is your proof of the monthly cadence. If you have not built a resolution-time measure, say that and describe it as a plan. | F4's gap, asked as a plan. |
| B6 | "When did you keep a complaint open until it was actually resolved?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | "Own the Fix" story. The quote states that you handled the log, so the beats are the log's, not an end-to-end resolution. Answer slot: if you kept a logged complaint open to the end, say which and what you did. If you did not, say so plainly and describe what you did. | Values round rehearsal. Your only story-carrying sentence is F2. |
| B7 | "You trained tellers on an escalation script. How did you know it worked?" | EXP | [grounded] "trained new tellers on our escalation script" (your message) | Premised on your quoted training. "Worked" presupposes a measure your material does not state. Answer slot: if you checked whether the script worked, say how. If you did not, say so plainly and describe what you saw. | Skeptic on the training claim. F6. |
| B8 | "How would you coach a branch supervisor through an escalation they've got wrong?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Structure the coaching: what you would see first, the conversation, the follow-up. Answer slot: if you coached a colleague through an escalation, say who and what changed. If you did not, say so and describe your first step. | F6's gap, asked as a live coaching problem. |
| B9 | "Tell me about a complaint where the number and the member disagreed." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" (provided values) | Selection scaffold: pick a complaint where the file said one thing and the member said another. Name the stake and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the spreadsheet, or how you would handle it. | Values round. The spreadsheet is the nearest story-shaped sentence, and it does not state a dispute. |
| B10 | "Where should the 2027 hub plan affect complaints, and where should it not?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message, summary of the strategy brief) | Name the complaint types that move with a branch and those that do not. Test your view against the value you already quoted: "every branch is part of its town." Do not say the brief tells you what it does not. | This is the tension between Neighbours, Not Numbers and an eight-to-five consolidation. Expect it to come up. |

**Round 2 reverse questions** (ask at least five):
- "What would you need the complaints lead to change in the first 90 days?" Why it lands: it sets what the first months should deliver.
- "Where do escalations from branch supervisors usually stall?" Why it lands: it reaches F6 and shows you are thinking about the supervisors' side.
- "Which self-service journey would you want fixed first?" Why it lands: it reaches F8.
- "How do you want the hub plan to change complaints handling?" Why it lands: it shows you read the brief and have a view.
- "What did the last person in this role do well, and what did they find hard?" Why it lands: it asks for the manager's honest read.

## 5. Round 3: panel of two branch managers (60 minutes, values scored, 20-minute case)

**Persona weights.** A panel blends the top two personas of each member's relationship. Branch managers are peers of the lead, so Peer Evaluator applies, alongside the case and the values scoring. Weights: Case/Strategist 3 (C1, C2, C6), Values/Behavioral 3 (C3, C4, C5), Peer Evaluator 3 (C7, C8, C10), Data-driven Prober 1 (C9). Case and Values are tied at the top. The panel is blended because the members are not yet named.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **20-minute case (illustrative scenario, the panel's own case will differ):** "A member has come back about the same disputed charge. The branch says it closed the complaint, and the member says it did not. Two branch managers disagree about whose process failed. What do you do?" | CASE | [generic] | Structure it in order: clarify what the member needs, state the objective, segment the complaint, set the approach, name the metrics, then the risks. Say who holds the complaint until it is solved, and what you check first. Do not claim how you handled a case like this. | The 20-minute case. Structure and reasoning are scored, not the answer. |
| C2 | "The member wants the money back and an apology in writing, and the policy says no. What do you do in the next 48 hours?" | CASE | [generic] | Clarify the policy and what the member can accept. Separate the decision from the communication. Name the one person who will hold the case until it is closed. | Tests a hold-and-explain decision under pressure. |
| C3 | "Read this out as the member would hear it: 'Your complaint has been considered and the outcome is that the charge stands.' Rewrite it." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" (provided values) | Rewrite in two sentences, with the outcome first. Add no reason you do not have. | Plain Words is scored in the rewrite, not in a story. |
| C4 | "Tell me about a time you decided from the member's side of the counter when process said no." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (provided values) | Selection scaffold: pick a time you took the member's side against a process. Name the stake and the decision. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the log you handled, or how you would handle it. | The first value. No story-carrying sentence for it in your material. |
| C5 | "How do you keep a complaint yours until it's solved, when it crosses two teams?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (provided values) | Answer slot: if you kept a complaint yours across two teams until it was solved, say which and what you did. If you did not, say so plainly and describe how you would hold it. | Values scoring on Own the Fix. |
| C6 | "How do you keep 'every branch is part of its town' true when a branch becomes a hub?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message, summary of the strategy brief); "Neighbours, Not Numbers — every branch is part of its town" (provided values) | Name how complaint routes stay local. Do not promise that branches stay open, since the brief does not say they do. Say your view. | Two branch managers may be close to this change. Expect the question in a live form. |
| C7 | "Where's the seam between a branch and the contact centre, and what happens when we disagree about who owns a complaint?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Name a seam principle, such as one owner per open file, rather than pretending to know their seam. Answer slot: if you have settled a dispute between two teams, say how. If not, say so and propose the principle. | Peer seam probe. F3's gap, from the other side of the table. |
| C8 | "What could a new person do in their first month that would genuinely help your branch?" | JD | [generic] peer reciprocity question | Name one concrete thing you could offer their branch, from work you have actually done. Do not offer what your material does not show. | Reciprocity question for a peer panel. |
| C9 | "Does the monthly spreadsheet count complaints as closed, and if so, by what rule?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if it counts closure, say the rule you used and what it is sensitive to. If it does not, say so plainly and say what it does count. | Prober. Defends F4 on the one definition the quote does not state. |
| C10 | "How do you handle credit when a complaint is solved by another team?" | VAL | [generic] persona stem on credit-sharing; no candidate claim | Selection scaffold: pick a time you shared or gave credit across teams. If none comes to mind, say so plainly, then describe how you would handle it. | Peer credit probe; scored under Own the Fix. |

**Round 3 reverse questions** (ask at least five):
- "Where does a complaint most often get lost between a branch and the contact centre?" Why it lands: it turns the seam probe into a shared problem.
- "When two branch managers disagree about a complaint, who calls it?" Why it lands: it asks about decision rights, which the lead would own.
- "What does a good escalation look like on the branch floor in your town?" Why it lands: it draws on Neighbours, Not Numbers.
- "What would you want the complaints lead to do first in a hub?" Why it lands: it links to the 2027 consolidation.
- "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it is the peer reciprocity question, and it signals that you think about their workload too.

## 6. Values cheat sheet

No value has a story-carrying sentence in your material, so each maps to a selection scaffold with an honest branch. That is the honest result, and it tells you what to prepare: real cases from your own work.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, not mapped. Pick a time you decided from the member's side when process said no. If none comes to mind, say so plainly, then give the nearest thing your material carries (F2), or how you would handle it. C4 and A2. |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold, not mapped. Pick a time you rewrote an outcome so a member understood it first time. If none, say so plainly, then give the nearest thing (the escalation script, F6), or how you would handle it. C3. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, not mapped. Pick a complaint where the number and the member disagreed. If none, say so plainly, then give the nearest thing (the spreadsheet, F4), or how you would handle it. B9, C6 and C10. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Answer slot. F2 carries "handled", not "kept hold until solved". If you kept a complaint open to the end, say which. If not, say so plainly and describe how you would hold one. B6 and C5. |

## 7. Grounding brief

Current vocabulary from the strategy summary you pasted, as provided. These are the terms to use:
- **Digital channels:** "move 40% of member service to digital channels by 2028" (your message).
- **Branch consolidation:** "consolidate eight branches into five hubs over 2027" (your message).
- **Small-business lending:** "launch a small-business lending product in Q1 2027" (your message).
- **Competitive pressure:** "the main competitive pressure is app-only banks" (your message).

The summary is from July 2026, about four months old. The upgrade menu offers a check for anything newer.

## 8. Sources

Provided documents: your message (JD text; the recruiter's email and round structure; the values copied from ashgrovecu.org/about/values on 25 November 2026; the strategy brief's headline points as you summarised them; your background). No CV, no dossier and no search were used.

Research tier: L0, no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values you pasted fix the values cheat sheet (section 6). |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds, their length and the 20-minute case, so the persona weights follow them (sections 3 to 5). |
| 3. Ashgrove strategy and recent news | unavailable | No search was run in this L0 pack. A search for news after July 2026 could move the CO questions A8, B10 and C6. Available as an L1 check on request. |
| 4. Interviewer name and Ashgrove | n/a | No names given. The Head of Member Services and the panel are not yet assigned, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 9. Upgrade menu

- The Head of Member Services' name, and the two branch managers' names → persona weights per panel member, and reverse questions tied to their career paths.
- Your CV, or the anonymised monthly spreadsheet → F1 to F5 move from your message to your CV as the source, and F5 can move to high confidence because the spreadsheet is inspectable.
- A description of the complaint categories you handled → F2 and B2 get concrete scope, so the answer does not rest on the word "formal".
- The 20-minute case brief, if the panel sends one in advance → C1 and C2 get rebuilt on the real scenario, not an illustrative one.
- A research pass, at L1 (six searches and two page fetches at most) → the strategy's news since July 2026 and the current values page are checked.
- Your own notes on a real escalation you ran → the value scaffolds in section 6 become mapped stories, with each beat quoted from your notes.
