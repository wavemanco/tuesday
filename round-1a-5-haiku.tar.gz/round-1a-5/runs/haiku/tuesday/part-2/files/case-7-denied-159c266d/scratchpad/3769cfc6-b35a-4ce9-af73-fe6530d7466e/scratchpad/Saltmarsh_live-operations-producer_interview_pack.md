# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not confirmed.
**Round:** 60-minute interview, Friday. Format not stated.
**Research:** No company research ran (see Sources). Company values, loop structure and strategy are absent from this pack.
**Changelog:** first version.

---

## 1. How to use, and the type key

Personas are how a question arrives. Types are what it scores.

- **JD**: can you do the listed job, gaps included
- **EXP**: do your past claims survive scrutiny, and what was actually yours
- **CASE**: structure and reasoning on a live problem from the role
- **VAL**: not used. No values-style round was detected.
- **CO**: not used. No company research ran.

Guidance is scaffolding, not a script. Speak it in your own words.

---

## 2. Prep triage

Prep time is not sized, so this is the full pack, in this order:

1. **A2 and A3.** These are the two places the material is thinnest against the JD: owning the post-event review and KPIs, and coordinating design, art, engineering and community. Rehearse each out loud twice.
2. **A1, A4, A5 and E1.** Your gaps as you stated them: no team led, no in-app purchase work. Rehearse the plain acknowledgment, then the plan, in that order.
3. **B1 and B2.** The two live problems most likely to be asked, one on release sign-off with QA, one on a retention drop.
4. **D1.** The 90-second arc from your own sentences, so the opener is never improvised.

Everything else is insurance.

---

## 3. Fit snapshot

JD requirements are quoted from your message. Your evidence is quoted from your message. Where the material is silent, the cell says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Words: "I ran the weekly content-drop calendar for our main title for the last two years." The material shows one title and content drops, not live events across two titles. Answer slot: if any live events sat on that calendar, say which and what you decided for them; if none did, say so and say how the drops were planned. |
| F2 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Words: "I presented the monthly retention numbers to the studio head." The material shows presenting numbers, not owning a review or the KPIs. Answer slot: if you chose which KPIs went in front of the studio head, or ran any review of a result, say which and how you decided; if you did not, say so plainly and say what you did with the numbers. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap in the quote. Expect a probe on how the handoff with QA ran day to day. Answer it from what happened, not from a summary. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with those teams. Answer slot: if you ran the handoffs for a drop, name the teams and what each needed from you, in your own words; if someone else coordinated them, say so plainly and describe what you did. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Words: "4 years as an associate producer at a puzzle-game studio." The material does not say the game was live-service, and your title was associate producer. Answer slot: if the puzzle title ran content drops after launch, say how often and for how long; if it did not, say so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap in the quote. The sentence is your own and reaches the requirement in its own terms. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Words: "I presented the monthly retention numbers to the studio head." No figure was given, so no defend-the-number slot applies. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." One written artifact is the only evidence here. |

**Gate check.** None of the JD requirements is a term (authorisation, licence, location, schedule, pay). "3+ years" is an experience requirement, so it is graded on fit, not treated as a gate. No `hard_gate` rows.

**Stated negatives, not JD requirements.** Two things you told me are absent, and neither is a JD requirement: "Never led a team" and "never worked on a game with in-app purchases." They are not rows above. They are used in the banks because the interviewer may raise them, and each has a plain acknowledgment in its bank entry.

---

## 4. Prohibited claims

Built locally from the fit snapshot. None of these may be asserted, implied or softened in any guidance, slot, or rehearsal.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live calendar for two titles | Inflated form of F1: your sentence covers one title and a content-drop calendar | F1's quote at its own scope. Material shows one title and content drops, not two titles of live events. |
| Owned post-event reviews or KPIs | Inflated form of F2: your sentence covers presenting numbers | F2's quote at its own scope. Material shows presenting, not owning. |
| Led a team, or coordinated teams as a manager | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot about leadership you did not do. |
| Worked on in-app purchase titles or planned around purchase paths | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| Coordinated design, art, engineering or community on updates | Silence in the material, not a stated negative. Not listed here | Not a prohibited claim. It is an answer slot (F4), with a second branch that allows the practice never existed. |

---

## 5. Persona weights

Relationship prior: hiring manager, so Case/Strategist and Skeptic dominate. The interviewer read is absent (no public footprint was researched). The loop is unknown, so weights are a flat fallback and are labelled as such.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes F5, F4, and your two stated gaps | High. A hiring manager buys capability and derisks gaps; your sentences show the gaps plainly | Rehearse the plain acknowledgment first, then the plan. Hold the calendar and checklist as the strongest evidence | 5 (bank A) |
| Case/Strategist | Live problems on the live-events roadmap | High. Expected from a hiring manager for this role | Clarify, then structure, then metrics. Name the first assumption aloud | 5 (bank B) |
| Data-Driven Prober | Retention numbers on your record | Medium. The retention sentence is the only metric evidence; a prober will try it | Say what you know about how the numbers were produced, and say when you do not know | 4 (bank C) |
| Conversational | Opener and "any questions" | Medium. Casual openers are scored | The 90-second arc from your sentences | 2 (bank D) |
| Pressure | Attribution challenge and comparison with a monetised-title candidate | Low to medium. Plausible on your purchase-side gap | Hold the plain fact, then the calendar. Concede specifically | 2 (bank E) |

Total: 18 questions. This is the floor for coverage, not a target to exceed.

---

## 6. Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is a puzzle-game studio. What from it carries over to a live-service title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Name what carries over, in your own sentences: "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses." Then name what does not: "I haven't worked on a game with in-app purchases." Keep the two parts separate. | F5 is the requirement a skeptic reads first. This is where your stated purchase-side gap is most likely to surface. |
| A2 | "The role owns the post-event review and the KPIs it reports. What has been your part in reviewing how a result landed?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Story from one sentence: "I presented the monthly retention numbers to the studio head." Say what you presented, in your own words. Answer slot: if you chose which KPIs went in front of the studio head, or ran any review of a result, say which and how you decided; if you did not, say so plainly and say what you did with the numbers. Hold through two follow-ups by returning to that sentence, never by adding to it. | **Highest-ROI prep.** F2 is the requirement with the least evidence and the JD's own ownership line. This objection will arrive in some form. The honest answer is the rehearsal. |
| A3 | "The role coordinates design, art, engineering and community on each update. Which of those teams did you coordinate on a drop, and what did you need from each?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start with the calendar you ran. Answer slot: if you coordinated any of those four teams on a drop, name them and what each needed from you, in your own words; if you did not, or someone else did it, say so plainly and describe the calendar's own handoffs. | F4 has no quote. The question is the JD's and a likely probe. The second branch allows the absence. |
| A4 | "You haven't had a team of your own. How would you coordinate people who don't report to you?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then answer as a plan, not a past: how you would get what you need from teams that do not report to you. Do not describe leadership you did not do. | The skeptic's natural gap probe, aimed at a negative you stated. The question's premise is your own negative, so it is lawful. |
| A5 | "Your material has no in-app purchase work in it. How would you learn what a purchase path needs before you plan an update around one?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the learning plan, as a plan: who you would ask and what you would read first. No claim about past purchase work. | In-app purchases are not in the JD, so this is likely only if the interviewer raises monetisation. Included because you stated the gap and a skeptic reads CVs for exactly this. |

### Bank B: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's Thursday. A content update for one title ships Monday, and QA sign-off on the release checklist is still open. What do you do?" | CASE | [generic] | Clarify first: what blocks sign-off, who owns each open item, what can ship without it. Then decide, communicate and record. Name the one decision you would escalate. No claim about your past. | The release checklist with QA is a JD line. Live problem from the role. |
| B2 | "Retention dropped two weeks after a live event. Where do you start?" | CASE | [generic] | Clarify the metric's definition and cohort first. Check event timing against other releases. Segment before you conclude. Name the weakest assumption in your first read before anyone asks. | Retention metrics are a JD requirement. The weakest-assumption move is the one this question scores. |
| B3 | "Plan the next six weeks of live events for one title: which two you would protect and which one you would drop, and why." | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the calendar you ran and the cadence it set. Answer slot: if you chose what went into a given week, say what you weighed; if you did not choose it, say so and describe how the cadence was set. Keep to six weeks. No outcome figures. | Covers the calendar requirement in a live form. |
| B4 | "Two live titles need updates in the same fortnight, and design, art and engineering are needed for both. How do you sequence them?" | CASE | [generic] | Clarify capacity and each update's dependencies first. Sequence by dependency and risk to retention, not by who asks loudest. Name the trade you would make and who must agree. | Covers "two of our mobile titles" and "each update" coordination. JD-derived. |
| B5 | "An event ran two days late, and its post-event review is not scheduled. What do you do this week?" | CASE | [generic] | Book the review with the owners first. Decide which KPIs must be in it. Name what you would produce and who signs off. | Post-event review is a JD line. |

### Bank C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The monthly retention numbers you presented: if someone asked how they were counted, what would you say?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you set how they were counted, say how, in your own words. If the counting was not yours, or you do not know, say so plainly and say who you would ask. | F7 is the metric evidence, and a prober will go to the counting. No figure was given, so the slot asks about method only as the probe would. |
| C2 | "For a live title, which retention definition would you defend least?" | JD | [generic] | Name one retention definition you can explain in one sentence, and the assumption it depends on. Typical pattern: what counts as returning, and when a cohort starts, can move the number. Use no figures of your own here. | Retention metrics requirement, asked as a generic judgment. |
| C3 | "When retention moved after an update, how did you separate the content effect from a release effect?" | JD | [generic] | Name the controls you would use: same-period cohorts, release-date segmentation, a holdout where the team can run one. Say which you have used yourself and which you have only read about. | Retention metrics requirement. The second half of the guidance is the honest branch. |
| C4 | "What would you put in a post-event review, and which KPI would you expect to be gamed?" | JD | [generic] | Name three measures tied to what the event was for, and one you would distrust, with the reason. Describe what you would measure. Make no claim about past reviews. | Post-event review and KPI requirement, asked as a design question. |

### Bank D: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc built from your sentences, in order: the four years at a puzzle-game studio; the weekly content-drop calendar for the last two years; the release checklist QA still uses; presenting monthly retention numbers to the studio head. Add nothing between them. | Casual openers are scored. The arc is your own sentences, so it cannot drift. |
| D2 | "What are you playing right now, and what would you change about how it runs its events?" | JD | [generic] | Name one game you play and one event-side change you would make, from what you have noticed. No research claims about the game. | Rapport question on a JD topic, asked casually. |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you over someone who has run a monetised live title?" | JD | [grounded] "never worked on a game with in-app purchases" | Hold with the plain fact: "I haven't worked on a game with in-app purchases." Then the strongest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups. Concede specifically (the purchase side is new to you). Do not fold on the calendar. | Pressure: hold, then concede a specific gap, never a core claim. |
| E2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold with the sentence: "I presented the monthly retention numbers to the studio head." Say which part you did yourself. If you did not do the analysis, say so and do not claim it. Concede where the numbers were not yours; do not fold on presenting them. | Attribution challenge. The rehearsal is precision about what was yours. |

---

## 7. Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | B3, B4, A3 |
| Coordinate design, art, engineering and community teams on each update | A3, B4 |
| Own the post-event review and the KPIs it reports | A2, B5, C4 |
| Manage the release checklist with QA | B1, A1 |
| 3+ years producing live-service games or apps | A1 |
| Experience running a content calendar | B3, D1 |
| Comfortable with player-retention metrics | B2, C1, C2, C3, E2 |
| Clear written communication | none, and why: a writing requirement is best rehearsed against a writing sample. The release checklist is the only one in your material, and D1 carries it. |

---

## 8. Reverse questions

Hiring manager, so no peer reciprocity question. No interviewer profile, so none is tied to his path.

1. "What would a good first 90 days look like on the calendar, and what would you measure it by?" *Why it lands:* shows you plan to KPIs from day one.
2. "Which of the two titles needs the most attention right now, and why?" *Why it lands:* signals you want the actual roadmap, not a generic brief.
3. "How are post-event reviews run today, and who owns the KPIs they report?" *Why it lands:* tests F2 from his side without claiming anything.
4. "Where does the release checklist with QA slip most today?" *Why it lands:* ties to the checklist you wrote, and shows you read the process as a producer.
5. "How are purchase-side decisions made when an update is planned?" *Why it lands:* puts the purchase gap to him as a question, and shows you learn who decides.
6. "What has made past live events miss their targets?" *Why it lands:* surfaces risk early and signals you expect to own a review.

---

## 9. Sources

**Provided documents:** your message (the JD text and your background).

**Research tier:** L1 — searches 4 of 6, fetches 0 of 2; user links read 0.

Four search calls were sent. Each was refused: permission to use WebSearch had not been granted in this session. No page was fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section 10). Not built: the condition for it was not met, and no values-style round was detected. Query refused: "Saltmarsh Games values" |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. Persona weights are a flat fallback (archetype: generic), not based on this company's loop. Query refused: "Saltmarsh Games interview process Live Operations Producer" |
| 3. Saltmarsh Games strategy / recent news | unavailable | Grounding brief and CO bank. Both absent, so the pack has no CO questions. Query refused: "Saltmarsh Games mobile studio news" |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, and a personal reverse question. All absent. Query refused: "Tobias Wrenfield Saltmarsh Games Live Operations" |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

**Sections dropped:** values cheat sheet, grounding brief, interviewer read, graded deliverables. Each has an unmet condition. Delivery coaching: no assessment was provided.

**Citations:** none used. No outside claims are made in this pack.

---

## 10. Upgrade menu

- **Permission to run web search** → reruns the four company targets above. Would ground the values, loop structure, recent strategy and Tobias's public footprint, and would turn the generic CO and persona weights into company-specific ones.
- **The round's format from your recruiter** (panel, case, presentation, or one conversation) → confirms the session shape, and adds a graded-deliverable section if one was announced.
- **A writing sample you can describe** (for example, a page you wrote that others used) → the written-communication requirement gets its own question and a grounded row.
- **One sentence describing any post-event review you ran, in your words** → F2 gets a quoted sentence, and A2 becomes a story map rather than a slot.
- **Whether the puzzle title ran content drops after launch, and for how long** → F5 moves from transferability toward grounded.
- **Your current release checklist, described** (not shared) → C-bank and B1 get the actual steps, so the QA answer is yours, not generic.
- **A tuesday-dossier.md** would add verified evidence and prohibited claims to this pack, and is optional.
