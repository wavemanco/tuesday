# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer
**Company:** Saltmarsh Games
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (see the question in the message). No public profile was retrieved.
**Changes:** first pass.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: EXP (your past work, checked closely), JD (the listed job), CASE (a live problem), CO (company knowledge, not researched here), VAL (values, not detected).
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slots** are instructions for the interview. They tell you what to say when the honest answer is "I did not do that." They are not questions to me.

## Prep triage

Interview is Friday. Roughly two days.

1. Rehearse **B1** out loud until it is boring. It is the most likely objection and the highest-return prep here.
2. For each item in **F1, F4 and F5**, write one sentence on what was yours to decide and what was not. Use only what you actually did.
3. Run **E1** (the journey, under 90 seconds) and two reverse questions aloud.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted, or marked [generic] where no source supports them. Evidence is quoted from your message. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar. It does not say two titles or live events. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned across two titles, say how; if not, say how you would split the calendar between them. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | Covered by the quote. Expect a probe on cadence and on what slipped. Say the quote as it stands. |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material does not show coordinating those four teams on an update. Words: "I haven't led a team." Answer slot: if you coordinated any of those groups on a release or event, say which and what you did; if none, say so, and say how you would set up the first update. |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned the review or chose the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or wrote a review, say which and how; if not, say so and stay with the numbers you presented. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote it, and QA still uses it. Words: "I wrote the release checklist our QA team still uses." Do not add that you ran sign-off. Answer slot: if you ran release sign-offs with QA, say how; if not, say how you would run them. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | low | [inferred] | discovery | The years line up. Your material does not say whether the puzzle title was live-service. Answer slot: say how the main title was run after launch, in your own words; if you cannot say, say so. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | Covered by the quote. Your material gives no retention figure, so a probe on a number has nothing to defend yet. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | transferability | Checklist writing is written work for an operations audience. Your material does not show writing for design, art or community readers. Answer slot: if another team acted on a piece of writing of yours, name it; if not, say which writing you would send first. |
| F9 | Monetised live-game experience — [generic] mobile live-ops roles often involve purchase-driven events; the JD you pasted does not name monetisation | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Your own negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. Never a claim to monetisation work. |

**Gate rows:** none. The JD you pasted states no location, right-to-work or pay term.

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. Pack observation, not words for you: your material says one title. |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope. Pack observation: your material says presenting the numbers. |
| Ran release sign-off with QA | Inflated form of F5 | F5's quote. Pack observation: your material says you wrote the checklist. |
| Has live-service experience | Inflated form of F6 | F6's years, at their own scope. Pack observation: live-service is not shown. |
| Led a team | Negative you stated, F3 | Plain acknowledgment: "I haven't led a team." No slot. |
| Worked on a monetised game | Negative you stated, F9 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Weights come from the hiring-manager prior: Case/Strategist and Skeptic. The JD's KPI and retention lines raise the Prober to mid-weight. There is no interviewer profile and no loop data, so no further adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: retention drop, event plan, team conflict | Top. The hiring-manager prior, and the JD is a list of live problems | Clarify, then structure, then metrics, then risks. Think aloud. |
| Skeptic | Probes the gaps: no live-service claim, no leadership, no monetisation | Top. The fit snapshot's gap rows are where this persona finds its questions | Rehearse the predictable objection until it is plain. Acknowledge the negative exactly, then give a plan. |
| Data-Driven Prober | Asks how figures were counted and what would falsify them | Mid. The JD's KPI and retention lines, and your retention readout | Say what you can and cannot say about a count. Name the weakest assumption before they do. |
| Pressure | Interrupts and time-boxes, to test composure | Low. No relationship or profile signal, so only a secondary weight | Pause, restate, hold one position, concede one thing exactly. |
| Conversational | Casual openers that are still scored | Low. A friendly first question is still a scored answer | Prepare a 90-second arc. Treat casual questions about the JD's topics as scored. |

## Question banks

### A. Case/Strategist (top weight: 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Retention on one of your titles dropped over three weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what changed: a release, an event, a cohort, a platform. Split by cohort and segment. Check whether the drop follows a content drop or an event. Name two or three hypotheses, then say what you'd check first. | Live problem from the retention line. Asks nothing about your past, so it cites nothing. |
| A2 | "Plan the next six weeks of live events for one of your two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start with questions: current KPIs, what is already in the pipeline, design, art, engineering and community capacity, QA release windows. Then a cadence. If you draw on the calendar, use its own words: "I ran the weekly content-drop calendar for our main title." Add nothing about how it was planned. | Covers the calendar and content-calendar requirements (F1, F2). |
| A3 | "Design wants the same release window as engineering, and community wants it the week before. What do you do?" | CASE | [generic] | Name the decision owner. Name the constraint, such as QA capacity. Propose a sequencing rule. Decide with a date. Write the decision down for all four teams. Say this as a plan, not as something you have done. | Tests coordination without claiming coordination history (F3). |
| A4 | "Walk me through the checklist: where would you add a gate, and where would you remove one?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what the checklist covers in your words. Then the gate question. Answer slot: if the checklist changed after you wrote it, say what changed and why; if it did not, say so, and say what you would review first. | Release checklist requirement (F5). Scored as a live problem on your own artifact. |
| A5 | "Write the two-paragraph update you'd send design, art and community after an event misses its target." | CASE | [generic] | Lead with the result and its size, then what you'd do next and who decides. Short sentences. No blame. Write it out if asked. | Tests the written-communication requirement directly (F8). |

### B. Skeptic (top weight: 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. Why is a live-ops role the right next step?" | JD | [grounded] "never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Open with the acknowledgment in the exact words: "I haven't worked on a game with in-app purchases." Then the plan: what you would read first, who you would ask, what you would watch in the first 30 days. Hold through two follow-ups by returning to the plan. Concede the monetisation mechanics plainly, in your words. Never fold on the retention and events work. | This objection will come in some form. The acknowledgment is your own negative, so it can be said as-is. |
| B2 | "Your strongest line is presenting numbers. Did you own the KPIs?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, in those words. Answer slot: if you chose which KPIs were reported, say which and how; if not, say so and stay with the numbers you presented. Do not claim the review. | F4's gap. A premised question that asks only what the quote carries. |
| B3 | "Tell me about a time the release checklist stopped a release. What happened?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt. Choose a release where a check mattered. Answer slot: if no such release comes to mind, say so plainly, then describe the nearest check the checklist covers, and what it would have caught. | Open prompt on the QA requirement. It names no event, so it presupposes none. |
| B4 | "You've never led a team. What would make you the one to get four teams through an update?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then how you would coordinate without line authority: a written plan, one owner per team, a decision rule. Describe the setup as a plan. Hold once. Concede that it is a real stretch, and name the first 30 days. | F3's gap, the second-most likely objection. |
| B5 | "Your four years were on a puzzle game. Was it live-service, and what did you run after launch?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | State the years in those words. Answer slot: say how the main title was run after launch, in your own words. If you cannot say whether it was live-service, say so plainly. Do not claim live-service. | F6's gap, against the years requirement. |

### C. Data-Driven Prober (mid weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you can say about the count. If you cannot say how it was counted, say so plainly. Answer slot: if you calculated the figure, say how; if someone else built it, say so and say what you presented. Name the assumption you would defend least, in your words. | F7. Premised only on the quote's own "retention numbers". |
| C2 | "Which retention metric would you watch first on a new event, and what would make you distrust it?" | JD | [generic] | Name a cohort-based day-one or day-seven measure. Name the denominator. Name the confound: players who were already active when the event started. | Tests the retention line on a live problem. Generic pattern, no claim about you. |
| C3 | "The post-event review says the event lifted day-seven retention. How would you check that?" | JD | [generic] | A holdout or comparison group, a fixed window, and what result would falsify the claim. Keep it short. | Tests the post-event review and KPI requirement (F4). |

### D. Pressure (low weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who hasn't run a monetised live game over someone who has?" | JD | [grounded] "never worked on a game with in-app purchases" | Pause. Restate. Hold: "I haven't worked on a game with in-app purchases." Then the calendar and the checklist, in your own words. Concede one thing exactly. Do not describe other candidates. | Rehearses the B1 position under time pressure. |
| D2 | "That content calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Name what you ran, in those words. Answer slot: if the cadence or scope was set by someone else, say so, then say what you decided. | Attribution probe on the calendar. |
| D3 | "You've never led a team. Why won't you be a bottleneck?" | JD | [grounded] "Never led a team" | "I haven't led a team." Then name one decision you would own and how you would hand off the rest. Hold once. Concede the gap where it is real. | F3 under pressure. |

### E. Conversational (low weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc: the studio, the calendar, the checklist, the retention readout, why live ops now. Use only quoted material. | The biography question is scored. Keep it to what you have actually done. |
| E2 | "What are you playing right now, and what would you change in it?" | JD | [generic] | Name one game, one change, tied to retention. Make no claim about the studio's own titles. | Casual, but tests the player-retention line. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, F1 |
| Content calendar experience | A2, F2 |
| Coordinate design, art, engineering and community | A3, B4, D3 |
| Own the post-event review and KPIs | B2, C3 |
| Manage the release checklist with QA | A4, B3 |
| 3+ years producing live-service games or apps | B5, F6 |
| Comfortable with player-retention metrics | A1, C1, C2 |
| Clear written communication | A5, F8 |
| Monetisation (not in the JD; a mobile live-ops pattern) | B1, D1 |

**Totals:** 17 questions. Slightly under the roughly 18 target, because there is no interviewer profile to weight the banks against.

## Reverse questions

Each one: why it lands.

1. "What does a normal week on your two titles look like for the live-ops producer, and what breaks it most often?" Why it lands: shows you are thinking about the calendar as the job, not as a slide.
2. "How is the post-event review set up now, and who reads it?" Why it lands: tests whether the producer owns the KPIs, which is the JD line.
3. "Which team is the usual bottleneck on an update: design, art, engineering, QA or community?" Why it lands: asks about the coordination requirement directly, and signals you expect it to be hard.
4. "What would you want the first 90 days of this role to prove?" Why it lands: makes the success measure theirs.
5. "Which of the two titles has the harder retention question right now?" Why it lands: shows you read the retention line, with no claim about company strategy.
6. "What happens after this round, and is there a second conversation?" Why it lands: a process question that gives you the next prep step.

## Sources

**Provided documents:** your message (your background and the JD).

**Research tier:** L1. Searches 4 of 6, all refused (the search permission was declined). Fetches 0 of 2.

Searches sent, all refused:
- "Saltmarsh Games mobile studio"
- "Saltmarsh Games values"
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations"
- "Saltmarsh Games interview process live operations producer"

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, not built. Company values are not established here. |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure, not established. Persona weights use relationship priors only. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Not sent, because the search permission was declined. Would have moved the CO bank. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read, not built. Would have moved the persona weights and a tailored reverse question. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Questions in the banks are generic where the table above says so. No company claim in this pack comes from research.

## Upgrade menu

- Permission to search, or a pasted copy of the company's values page → a values cheat sheet, company-specific CO questions, and the loop structure.
- Tobias's public profile, pasted or searched → an interviewer read, persona weights from his footprint, and a tailored reverse question.
- Whether your main title ran live content after launch → F6 moves from [inferred] to [grounded], and B5 gets a concrete answer.
- Whether the recruiter named focus areas or an assignment → coverage for any announced deliverable.
- `tuesday-dossier.md` from an earlier session → verified evidence in place of the quotes in this pack, if you have one.
