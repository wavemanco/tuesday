# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not named. Relationship assumed to be **hiring manager** (your note said "likely"; see the question in the message that presents this pack).
**Round:** not stated. Built as a single hiring-manager session.
**Version:** first version. Research did not run (see Sources).

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** `CASE` = live problem from the role, scored on reasoning. `EXP` = your past experience, scored on whether it survives scrutiny. `JD` = a stated requirement of the job.
- Guidance is scaffolding, not a script. Speak it in your own words, in about 90 to 120 seconds.
- Every claim about your past comes from a quoted sentence of yours, or is labelled as a question or a plan. Nothing here adds a figure, event or outcome you did not give.

---

## Fit snapshot

Requirements are quoted from the job description you sent. Your evidence is quoted from your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows one shift over three supervisors, not four sites. Say it at that scope: "I'm a senior shift manager over three supervisors." Answer slot: if you have worked across more than one site, or with another site's team, say how, in your own words; if you have not, say so plainly and say how you would learn the four. |
| F2 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors. Say that number and the scope you led them at. Answer slot: if you have led a larger group or a layer above supervisors, name the largest group and how you ran it; if not, say so and say how you would structure twelve. |
| F3 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick result touches accuracy, not on-time performance or cost; whether it reaches either is not shown. Answer slot: if you have moved an on-time or cost measure, say which and how it was counted; if you have not, say so plainly and say what you would measure first. |
| F4 | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | medium | [grounded] | presentation | Your quote reaches the Excel half in its own terms. Bridge: "I'm solid in Excel." Add nothing about what you built in it. |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as past use. |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [grounded] | hard_gate | Your material establishes seven years in warehouse and distribution operations. It does not establish five years in leadership, so this gate is not shown met. Surfaced, not bridged. Your material is silent on how many of those years were leadership; the question about it is in the message that presents this pack. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | high | [grounded] | none | The quote reaches the requirement: you hold a Green Belt. Lead with the certification in those words. Expect a probe on applied use (Q3). |

---

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope: a senior shift manager over 3 supervisors. The limit is the pack's observation: your material describes one shift, not four sites. |
| Leads twelve supervisors | Inflated form of F2 | F2's quote: 3 supervisors. |
| Has moved on-time performance or cost-per-shipment | Inflated form of F3 | Only the 40% mis-pick result is in your material. |
| Has used Power BI, or built Power BI reporting | Negative you stated (F5) | "I haven't used Power BI." No slot. |
| Five years of operations leadership | Gate F6 not shown met | Your quotes at their own scope. Your own number, in the message, is the only answer to this gate. |
| Redesigned the pick path alone | Inflated form of "cut mis-pick rate 40% by redesigning the pick path" | The quote as written. Which part was yours is an answer slot (P2). |
| Delivered Lean or Six Sigma project results | Inflated form of F7 | "green belt certified" and nothing beyond it. |

---

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: sites, scale, leadership years, Power BI, why this role | **Top.** A hiring manager is buying capability and derisking the gaps in F1, F2, F5 and F6. | Rehearse the leadership-years objection (S3) until it is plain. Name each gap yourself before it is raised. |
| Case / Strategist | Live terminal problems: throughput, on-time, peak volume | **Top.** The JD is a list of operating problems; a hiring manager tests how you structure them. | Clarify, then structure aloud, then metrics, then risks. Challenge no premise you were not given. |
| Data-Driven Prober | Asks how the 40% was counted and what it is sensitive to | **Mid.** The mis-pick figure is the one number on your material that will be checked. | Know how it was counted, in your own words. If you do not know, say so. |
| Pressure / Stress | Time-boxed challenges, comparisons with a larger candidate, "how much was actually you" | **Mid.** Likely in a hiring round where scope is the open question. | Pause, restate, hold a position through two follow-ups, concede specifically. |
| Conversational / Rapport | Friendly opener, casual questions on Excel and Power BI | **Low.** A hiring round usually opens formally; casual questions are still scored. | A 90-second arc from your own sentences. |
| Values / Behavioral | Leadership STAR prompts about the three supervisors | **Low.** No values-style round is established for this company (no loop source was read; see Sources). | Stories with three supervisors' context. Say so when no story fits. |
| Peer Evaluator | Seam and credit-sharing probes | Not weighted: the relationship is a hiring manager, not a peer. | n/a |

Depth follows weight: Skeptic 5 questions, Case 4, Prober 3, Pressure 3, Conversational 2, Values 2.

---

## Question banks

### Case / Strategist (weight: top, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose on-time is slipping at several of the four terminals and cost-per-shipment is climbing. Where do you start?" | CASE | [generic], raising source: JD "drive on-time performance and cost-per-shipment down" | Clarify what slipping means (which sites, which lanes, against what target). Split by cause, pick the two largest, and name the metric you would check first. Say the structure aloud before you use it. No claim about your past is made here. | Covers the JD's on-time and cost line in a live form. Pure reasoning, so no past claim is needed. |
| A2 | "Peak volume is up 30% in six weeks. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: volume by lane and shift, labour against forecast, and the risk that peak breaks the on-time target. If you draw on the surge plan you ran, use that sentence's words and what you did within it. Add no figure, timeline or outcome the quote does not carry. Answer slot: if any part of the plan was yours to set, say which and how you decided; if not, say so and describe the reasoning you followed. | The peak plan is your most relevant story for this role. The quote limits what can be said about it. |
| A3 | "What would you need to know in your first 30 days before changing how a terminal runs?" | CASE | [generic], raising source: JD "Own daily terminal operations across 4 sites" | Listen-first: the current measures per site, the constraints the managers work under, and what has already been tried. Name the two data sources you would need before proposing anything. | Tests the balance of listening and acting that hiring managers score on day one. |
| A4 | "Lean is a plus here. Where in terminal flow would you apply a Lean tool first?" | CASE | [grounded] "green belt certified" | Name one flow (inbound, pick, dock or outbound), the waste you would look for in it, then the tool. Answer slot: if you have applied a Lean tool to a real problem, name the tool and the problem in your own words; if not, say so plainly and describe the first tool you would reach for and why. | Turns F7 into a live problem. The certificate is the only thing the quote carries, so no applied project is claimed. |

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The job leads twelve supervisors. You lead three. How would you get from one to the other?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold: "I'm a senior shift manager over three supervisors." Then how you would structure a larger group: the span, the supervisors you would rely on, and what you would change first. Answer slot: if you have led people across a larger group or a layer above supervisors, name the largest and how you ran it; if not, say so and say how you would learn it. Hold through one follow-up by returning to the three. Concede that twelve is a step you have not taken; never claim it. | F2 is the first gap a hiring manager reaches for. |
| S2 | "This role covers four sites. Which part of your experience carries over, and which does not?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Lead with what the quote carries: a shift over three supervisors. Name what carries over, in your own words, and say plainly what does not (multi-site scope). Answer slot: if you have worked across more than one site, say how; if not, say so and name the nearest thing you have done. | F1 as a fit question. |
| S3 | "The job asks for five years of operations leadership. How many of your years have been leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Give two numbers separately, in your own words: years in operations (your material puts this at seven) and years leading people (only you can give this number). Do not repeat the first to cover the second. If the second is short of five, say so plainly and name the nearest thing: "a shift over three supervisors." Hold through two follow-ups. Concede the gap; do not soften it into a larger number. | F6 is the gate most likely to decide this round. Rehearse it until it is boring. Your answer to the (d) question in the message is what this row rests on. |
| S4 | "Power BI is in the job description. Where are you with it?" | JD | [grounded] "never used Power BI" | Acknowledgment: "I haven't used Power BI." Then the plan: what you would learn first and how you would apply it to terminal reporting. Describe it as a plan, never as past use. | F5, a stated absence. The only sentence you say to this gap is one you actually said. |
| S5 | "Why leave a senior shift role for this one?" | JD | [generic] | Selection scaffold: give the reason you actually have, in your own words, and tie it to what this role adds. Your material states no reason, so the pack supplies none. | Motivation consistency is a hiring-manager probe; the reason has to be yours. |

### Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how you counted the 40% drop in mis-picks." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number slots: how it was counted (period, baseline, what was included), what it is sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words. If you cannot say how it was counted, say so. The pack supplies no baseline or method. | The one figure in your material that will be checked; a prober's first move. |
| P2 | "The pick path redesign: which part was yours, and which part was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say what you decided and what you did. If others owned a step, say so. The quote says "redesigning" and does not say whose; do not claim the redesign alone. | Attribution honesty on your strongest result. |
| P3 | "Describe a spreadsheet you have used to make a decision, and what the decision was." | JD | [grounded] "solid Excel" | Selection scaffold: pick one spreadsheet you used or built for a decision; say its inputs and what the decision was. Answer slot: if you have built reporting, say what it reports and to whom; if you have not, say so. | Covers the Excel half of the reporting requirement with a concrete example. |

### Pressure / Stress (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why you over someone who runs four sites today?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Hold: state what you have that is specific, from your own sentence. Concede the scope difference plainly. Do not argue about the four sites. | Composure under a comparison you cannot win on scope. |
| Q2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: say what was yours, the decision and the work. Hold through two follow-ups by returning to what you did. Concede the part that was a team's. Do not fold on your core claim just to restore harmony. | The pressure stem the quote carries directly. |
| Q3 | "Your Green Belt: what have you actually applied it to?" | EXP | [grounded] "green belt certified" | Hold: the certification, in those words. Answer slot: if you have applied a tool to a real problem, name the problem; if not, say so plainly and say what you would do first. Do not invent a project. | Pressure on F7, the one gap-free Lean requirement. |

### Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So: walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors"; [grounded] "cut mis-pick rate 40% by redesigning the pick path"; [grounded] "ran the site's peak-season surge plan two years running" | A 90-second arc, each beat a clause from one of these sentences: seven years in warehouse and distribution operations; now a senior shift manager over three supervisors; the pick path redesign that cut mis-picks 40%; the peak plan run two years running. Tell it in your own words. Add no beat (title, site, promotion) the quotes do not carry. | Casual register, still scored. |
| V2 | "Where are you with Excel and Power BI these days?" | JD | [grounded] "solid Excel"; [grounded] "never used Power BI" | On Excel, "solid Excel." On Power BI, "I haven't used Power BI," then the learning plan. Do not imply any Power BI experience. | Casual version of F4 and F5. |

### Values / Behavioral (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you led a group through a change they did not want." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Open prompt: pick one real instance with your three supervisors. Structure: the change, your step, the pushback, the result. Answer slot: if no such change came up, say so and give the nearest thing you did. Do not describe a group larger than three. | Tests leading people, the JD's F2 requirement, at your real scope. |
| B2 | "When did a supervisor push back on your plan, and what did you do?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Open prompt: choose a disagreement you actually had. Say how it was resolved, in your own words. Answer slot: if you cannot name one, say so and give the nearest thing. | Behavioral probe on the same scope. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A3, S2, F1 (slot in S2) |
| Drive on-time performance and cost-per-shipment down | A1, A2 |
| Lead a team of 12 supervisors | S1, B1, B2 |
| Build reporting in Excel/Power BI | P3, S4, V2 |
| 5+ years operations leadership required | S3 (gate; see F6) |
| Lean/Six Sigma a plus | A4, Q3 |

---

## Reverse questions

No interviewer profile exists, so none is tied to a career path. Each question includes why it lands.

1. "What does success look like at 90 days in this role?" Why it lands: it shows you plan to a measure.
2. "Which of the four sites is furthest from its on-time target today, and what is behind it?" Why it lands: it shows you read operations, not only the org chart.
3. "How is reporting built today, and which tools do the terminal managers use?" Why it lands: it turns the Power BI gap into a learning question, not a claim.
4. "How are the twelve supervisors grouped across the sites?" Why it lands: it asks about the scope you have not run, in the interviewer's own terms.
5. "What is the biggest operational risk you expect in the next peak season?" Why it lands: it shows you think about the calendar the business runs on.

---

## Sources

**Provided documents:** your message (the job description and your background).

**Research tier: L1, attempted, not completed. Searches 0 of 6 completed (3 attempted, all refused); fetches 0 of 2.**

Queries sent, all refused (WebSearch permission was not granted in this session):
- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight logistics strategy news 2026": refused

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have set the values cheat sheet. Not built: no values-style round is established, so none was detected. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have set the loop structure and persona weights. Weights here are the hiring-manager prior, flat, and labelled as such. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have fed the Case bank with current strategy (CO). A1 to A4 are generic in consequence. |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative `Operations Manager` JD | skipped | The job description you sent fixes the fit snapshot and the JD-tagged questions. |

Company facts in this pack are therefore `[generic]` or taken from your job description. Nothing about Atlas Freight's values, loop, or strategy is asserted from memory.

---

## Upgrade menu

- The interviewer's name and title → a tailored reverse question, and persona weights from their public footprint (research permitted).
- Years leading people, as distinct from years in operations → F6 moves from hard_gate to grounded; S3 gets your own number.
- Web search allowed → rerun the three L1 targets: values (for the values cheat sheet, if a values round is established), interview process (loop structure and persona weights), and strategy (the CO bank).
- Any multi-site experience, however small → F1 moves from transferability toward presentation; S2 gets your own sentence.
- Team sizes above three → F2 and B1 get your own scope.
- How the 40% was counted → P1's defend-the-number slots filled in your own words.
- Any Power BI-like exposure (a dashboard tool, a shared report you built) → F5 and S4 get your own sentence; nothing is added that you did not say.
- The recruiter's prep email → confirms the round format (panel, presentation, or a single session).
