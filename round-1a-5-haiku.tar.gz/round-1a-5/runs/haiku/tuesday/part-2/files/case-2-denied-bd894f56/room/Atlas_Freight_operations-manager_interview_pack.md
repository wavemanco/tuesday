# Atlas Freight, Operations Manager: interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not given
**Round:** hiring-manager-level, assumed. The round type is not confirmed.
**Research:** web search was refused this session. Nothing about Atlas Freight itself is verified (values, interview loop, recent news). See Sources.

## How to use

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words, and rehearse only what you actually did.

Type key:

- **JD**: can you do the listed job, gaps included
- **EXP**: did you actually do what your record says
- **CASE**: a live problem from the role, delivered aloud
- **VAL**: past behavior against values (no values-style round detected; see Persona table)
- **CO**: company and strategy knowledge (not included; research did not run)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one shift-manager role over three supervisors, and one site's surge plan. Four-site daily scope is not in it. Bridge, at its own scope: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have run or planned daily operations across more than one site, say how, in your own words. If you have not, say so plainly, then say how you would cover four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a mis-pick result. It does not show on-time performance or cost per shipment. Bridge, at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved an on-time or cost measure, name it and how. If not, say so, and name the lever you would try first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Bridge: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have set direction for more people than that, say how many and what you set. If not, say so. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | presentation | Length of experience is not a gate, so this is fit by evidence. The quote gives seven years of operations, and a current supervisory role. It does not give leadership years on their own. Bridge, from the quote: "I have 7 years in warehouse and distribution ops." Leadership years are asked in A5. |
| F5 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Lead with it: "green belt certified." Expect a probe on what you used it for. A certificate in view would raise this to high. |
| F6 | "build reporting in Excel/Power BI" (JD, Excel) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid Excel" is a vague claim, so the pack does not assert reporting experience from it. Answer slot: say what you have used Excel for, in your own words. If no reporting was yours to build, say so, and say what you would build first. |
| F7 | "build reporting in Excel/Power BI" (JD, Power BI) | "never used Power BI" (your message) | none | [grounded] | capability | A stated gap. Words: "I've never used Power BI." Then how you would learn it, said as a plan, never as a past. |

## Prohibited claims

Not coached in any answer, slot, hold or bridge in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | F1's quote at its own scope. Your material says a shift-manager role over three supervisors. It does not show multi-site scope. |
| Leads 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors." |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | The quote is the mis-pick rate, and only that. |
| Built Excel reporting for an operation | Inflated form of F6 ("solid Excel" widened to a practice) | "Solid Excel", at its own scope. Reporting appears only as an answer slot (A4). |
| Has used Power BI | Negative you stated (F7) | Plain acknowledgment: "I've never used Power BI." No slot. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Scale and gap probes: four sites and 12 supervisors against three | High. Hiring-manager prior. The JD's span sits beside a three-supervisor record (F1, F3). | Rehearse A1 until it is boring. Name the span gap before it is raised. | 5 |
| Case / Strategist | Live diagnoses on cost and on-time | High. Hiring-manager prior. The JD names daily operations and cost. | Clarify, then objective, segments, approach, two metrics, one risk. | 4 |
| Data-Driven Prober | The 40% figure, and the on-time line | Medium-high. The 40% is a headline figure on your record (F2). | Defend the number in your own words. Name the weakest assumption first. | 3 |
| Pressure | Challenges to fit and to attribution | Medium. Hiring-manager rounds often include one. | Hold through two follow-ups. Concede specifically, never fold on the core claim. | 3 |
| Conversational | Opener and "walk me through" | Low-medium. Scored casually. | A 90-second arc built only from your quoted sentences. | 2 |
| Values / Behavioral | Scenario questions | Low. No values-style round detected. | Open prompt, with the honest branch. | 2 |

Weights rest on the hiring-manager prior and the generic archetype. No loop source establishes this company's loop, so they are not this company's documented process.

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role runs daily terminal operations across four sites and leads 12 supervisors. You're over three today. What makes you ready for that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Don't argue scale. Start from the sentence as it stands: "I'm a senior shift manager over 3 supervisors." Then say what that job already covers, in your own words. Answer slot: if you have run or planned daily operations across more than one site, say how and what you were responsible for. If you have not, say so plainly, then say how you would take on four sites in your first 90 days, as a plan and not as experience. Hold through two follow-ups by returning to the sentence. Concede whatever part of the scale is genuinely new, in one line, then return to it. | Highest-ROI prep in the pack. F1 and F3 are the largest span gaps, and the JD's own numbers make the scale objection near-certain. Deepest rehearsal here. The limit is named before it is asked for: the material shows one role over three supervisors. |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Name the weakest part first. The span gap is the honest answer: twelve supervisors and four sites are wider than the three you lead. Say what you would do in the first two weeks to close it. Don't offer a strength dressed as a weakness. | Persona stem. F3's span gap is the obvious answer, and naming it first is the move. |
| A3 | "Power BI is part of the reporting here. Have you used it?" | JD | [grounded] "never used Power BI" (your message) | Say it plainly: "I've never used Power BI." Then the plan, as a plan: which report you would rebuild first and how you would learn the tool. Don't name a course you have not taken or a skill level you do not have. | F7 is a stated gap. The question is the JD's, and a plain negative is said, not softened. |
| A4 | "How would you build the weekly operations report for four sites in Excel today?" | JD | [inferred] "solid Excel" (your message); a lead to test, not a claim | Answer slot: say what you have used Excel for, in your own words, and who read it. If no reporting was yours to build, say so, and say how you would structure a first version for four sites. | F6 is low confidence, so the pack asserts nothing about reporting experience. The question is where that gets tested. |
| A5 | "You have seven years in operations. How many of them have you led people?" | EXP | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer from your own record, in years and in role: the seven years as stated, then how many of them you led anyone. Answer slot: if the leadership years are fewer than the total, say so with the number you have. | F4. The JD asks for 5+ years of operations leadership. The material gives total years and a current supervisory role, not leadership years on their own. |

### Bank B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Cost per shipment is up at one of your four sites. Walk me through how you'd diagnose it in your first two weeks." | CASE | [generic] | Clarify first: what "up" means and against which baseline. Then the objective, then segments (shift, lane, labor against volume), an approach, two metrics and one risk. Think aloud. Don't invent site data to fill the case. | A live problem from the JD's cost line, delivered as a case. It asks about no past, so it claims nothing about you. |
| B2 | "Mis-pick rate fell 40% after you redesigned the pick path. How would you carry that method to on-time performance?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Take the sentence at its own scope: the pick path, the mis-pick rate, the 40%. Then one transfer step, as a question you would ask: what in on-time performance has the same kind of cause? Don't say the redesign moved on-time performance. | F2. The method is the bridge; the outcome does not transfer on its own. |
| B3 | "One of your sites has a shift that misses its daily plan two days in five. What do you change first?" | CASE | [generic] | Structure: is the cause capacity, labor, process or volume, and what would you check first. Name one change and the measure that would show it worked. | A live problem from the JD's daily-operations line. No past claimed. |
| B4 | "Which Lean tool would you reach for first on a site with rising errors, and why?" | JD | [grounded] "green belt certified" (your message) | Name one tool and why it fits errors, in your own words. The Green Belt gives you a method to name, not a project to claim. Don't describe a project you did not run. | F5. The quote supports the method at its own scope and nothing more. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how it was counted, in your own words: the period, the base, and what counted as a mis-pick. Answer slot: if you know the baseline and the period, say them. If you do not know how it was counted, say so plainly. Then name the assumption you would defend least, before they do. | A headline figure on your record. Defend-the-number slot. |
| C2 | "Which part of that 40% was yours, and which came from the team or the system?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: name the part you did, in your own words. If the redesign was someone else's, say so plainly and say what you did around it. Don't claim the whole figure. | Attribution is where this figure gets probed. |
| C3 | "Which of your four sites would you look at first for on-time performance, and why?" | JD | [generic] | Structure, not a claim: the measure, the site comparison, the test for cause. Your mis-pick result is evidence of method, not of on-time results. Don't use it as one. | JD line on on-time performance, asked as a site decision. |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone managing three supervisors over an internal candidate who runs four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | Pause, then restate the question. Answer from the two sentences as they stand: the shift role, and the surge plan run two years. Hold through two follow-ups. On the second, concede the scale question in one line, in your own words, and return to the surge plan. | Pressure stem. The position held is one your quotes carry, and nothing stronger. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the sentence: you cut the rate by redesigning the pick path. Answer slot: say which part of the redesign was yours. If the redesign was the team's, say so and say your part. | Same attribution probe as C2, delivered as pressure, so composure is rehearsed too. |
| D3 | "Your surge plan ran two years. Did it work, or did you just get lucky with volume?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold: the plan ran two years, as stated. Answer slot: if you measured its results, name the measure in your own words. If you did not measure it, say so plainly. Concede what you do not know about volume, in one line. | A success claim the quote does not carry. The pack holds to the quote. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc from those two sentences, in order: the seven years, then where you are now. Add no milestones you did not give. | Casual openers are scored. The arc uses only quoted beats. |
| E2 | "What are you actually playing with in Excel these days?" | JD | [inferred] "solid Excel" (your message); a lead, not a claim | Say what Excel does for you now, in your own words. If the honest answer is less than "solid", say that. | The JD's plus-tool asked casually. F6 stays a lead until you say more. |

### Bank V: Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic] | Pick a time you raised a problem to someone above you. It needs a named stake, a moment you did not fold, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Open prompt. Kept at low weight because no values-style round is detected. |
| V2 | "When have you put a customer ahead of an internal number?" | VAL | [generic] | Same shape: pick a time, name the stake and the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Second open prompt, so the persona is not met for the first time live. |

Session total: 19 questions.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C3 |
| Lead a team of 12 supervisors | A1, A2 |
| Build reporting in Excel/Power BI | A3, A4, E2 |
| 5+ years operations leadership required | A5, E1 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

1. "What would you need to see from someone running a multi-site terminal team by day 90?" Why it lands: it turns the scale objection into a plan conversation.
2. "Which of the four sites is furthest from its on-time target today, and what is behind the gap?" Why it lands: it shows you read the on-time line and want the real problem.
3. "How are the supervisors measured, and what do they own versus what the terminal manager owns?" Why it lands: it tests the leadership structure you would inherit.
4. "How is operations reporting produced today, which tools, and who builds it?" Why it lands: it shows you know the Excel/Power BI gap is real, and asks where it sits.
5. "What would make the first six months clearly successful for you?" Why it lands: it gets their success criteria in their own words, which you can then plan against.

## Sources

Searches sent, all refused by the host (permission not granted):

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight logistics strategy news": refused

Provided documents: the JD text and your background, as pasted in your message.

Target accounting:

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The values section and whether a values round exists. Both are absent from this pack. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure and persona weights. Weights here rest on the archetype. |
| 3. Atlas Freight strategy / recent news | unavailable | The CO questions and any grounding brief. None written. |
| 4. Interviewer name | n/a | No name given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name and title → a tailored reverse question, and persona weights from their public footprint.
- Your recruiter's note on the round format → confirms whether this is a hiring-manager round or a panel, and reweights every bank.
- A CV → each fit row's evidence moves from your message to an inspectable line, and the bank quotes come from it.
- Your Green Belt certificate → lifts F5, and B4 with it, from medium to high.
- A sample of an Excel report you built, with identifiers removed → upgrades F6 from low, and lets A4 rest on it.
- A working web search → Atlas Freight's values, interview loop and recent news, all refused this run. That adds the values section, loop-specific weights and the CO questions.
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and the objections to rehearse, carried in directly.
