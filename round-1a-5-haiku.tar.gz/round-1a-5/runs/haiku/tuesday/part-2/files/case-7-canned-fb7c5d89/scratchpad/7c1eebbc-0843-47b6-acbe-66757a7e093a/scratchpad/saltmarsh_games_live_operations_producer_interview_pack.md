# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, per the company's interviewing page. Round: one 60-minute "Outage Hour" (a live-incident tabletop, then a values conversation). Built on the first pass; no changelog.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your own work, **JD** the listed job, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Say things in your own words. Speakable in 90 to 120 seconds.
- Answer slots (instructions, not questions) tell you what to say when the material does not carry the answer. Both branches are honest.

## Fit snapshot

Requirements are the JD's own words. Evidence is quoted from your message, which is the only source about your history here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned across more than one title, say which and how you decided; if you planned one, say so and describe what you would carry over to two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none given | [grounded] | discovery | The material does not show coordinating those four teams. "Never led a team" is about leading, not coordinating; keep them apart. Answer slot: pick an update that reached two or more of those teams; say who you coordinated, how, and what you did yourself. If someone else coordinated it, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning KPIs; it does not show you set them or ran a review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you set any of the reported measures, say which; if you presented numbers someone else set, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Lead with the checklist in your words. Expect a probe on how it is kept current; the material does not say. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years meet the requirement's length. Whether the work was live-service is not stated. Bridge: "Four years as an associate producer at a puzzle-game studio." Length of experience is graded, not a gate. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Reaches the requirement directly. Use the cadence (weekly) and the length (two years) in those words. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Expect a probe on how the number was counted (D1, D2). |
| F8 | "clear written communication" (JD) | none given | none given | [grounded] | discovery | No writing sample is in the material. Answer slot: name the written thing you produced most often, and what a reader could do with it. |

Two stated limits are not JD rows and are not gates: "Never led a team" and "never worked on a game with in-app purchases" (your message). The Skeptic bank handles both. Neither is coached as experience.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I led a team" | Stated negative, your message | "I haven't led a team." |
| "I have worked on a game with in-app purchases" | Stated negative, your message | "I haven't worked on a game with in-app purchases." |
| "I owned the post-event review and its KPIs" | Inflated form of F3 | F3 at its own scope: "I presented the monthly retention numbers to the studio head." |
| "I ran the calendar for two titles" | Inflated form of F1 | F1 at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." |

The pack's own observation, in analysis only: the material says one title, presenting numbers, and a checklist. It does not say more.

## Persona table

Weights are shown so you can recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood | Why | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live incident and calendar problems from the role | 35% | The company's loop is a live-incident tabletop, the strongest documented signal | Clarify, then structure, then decide; think aloud |
| Values/Behavioral | Scenarios mapped to the three published values | 30% | The Outage Hour ends in a values conversation (company careers page) | Map each value to a quoted sentence; where none fits, say so |
| Skeptic | Stated gaps: team leadership, in-app purchases, coordination | 15% | Hiring manager's job is to derisk gaps (relationship prior) | Plain acknowledgment, then what you did, then a concrete ramp |
| Data-Driven Prober | Retention numbers and how they were counted | 10% | Your CV carries a figure-like claim | Say how it was counted only if you know; name the weakest assumption |
| Pressure | Interruption on your one held position | 5% | Low for a 60-minute hiring-manager round | Hold, then concede the specific gap |
| Conversational | Opening "walk me through" | 5% | Casual openers are still scored | Pre-scripted 90-second arc from your quoted sentences |

## Reading the interviewer

Public footprint only (search snippets, not opened pages):

- Career pattern: previously a QA lead at a console studio, now Head of Live Operations (GDC 2026 talk listing).
- Self-described theme: "a live team is judged by how often its patch notes describe what actually shipped" (the talk's own abstract).
- Implications: the release-checklist story (F4, B2, B3) lands with this interviewer. Be exact about what shipped versus what was planned. Do not claim anything about how the checklist affected releases.
- Mirror opportunity: his QA background and your checklist work are both about release quality. That is a shared professional theme, not a career jump, so it is offered as a reverse-question opening only.

## Values / principles cheat sheet

Detected: the company's own loop source documents a values conversation inside the Outage Hour.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1 row, "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if a drop moved for players, say what and why; if the calendar held, say so and what you would check next time. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 row, "Wrote the release checklist our QA team still uses." Selection scaffold: if a release's announcement and its shipped build did not match, say what each was; if none comes to mind, say so and describe what the checklist is for, in your words. |
| Leave the Build Greener | Every release leaves the codebase and checklist better | F4 row, "Wrote the release checklist our QA team still uses." Say only that you wrote it and that QA still uses it. Nothing more is in the material. |

## Question banks

Ordered by persona weight. Provenance carries every sentence the guidance rests on.

### A. Case/Strategist (35%, top weight: 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event goes down twenty minutes into a Friday evening. Walk me through your first ten minutes." | CASE | [generic] | Structure: confirm scope and who is affected; name who owns the call; decide roll back or hotfix; decide what players see and when; set the next checkpoint. No claim about your past. | The Outage Hour's live-incident tabletop, per the company's careers page. [generic]: a pattern for the problem, not a fact about this team. |
| A2 | "Project Larkspur moves two titles onto one shared events calendar from February 2027. What changes in your first quarter?" | CO | [grounded] Company news, "one shared events calendar from February 2027" (saltmarshgames.com/news/project-larkspur). Your own: "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the cadence you ran (weekly, two years). Then name what you would settle first: who owns the shared calendar, how the two titles' drops sit together, and what the season-pass cadence does to drop timing. Those are your plan, not claims about your past. | The company's current strategy, from the L1 news sweep. Expected at a hiring-manager round for this role. |
| A3 | "Plan and run the live-events calendar for two of our mobile titles. How would you structure one calendar across both?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD). "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Start from the one calendar you ran, at its own scope. Answer slot: if you planned across more than one title, say which and how you decided; if you planned one, say so and describe what you would carry over. | JD line is the headline requirement; F1 is the transferability gap. |
| A4 | "Walk me through an update where design, art, engineering and community all had to move at once." | EXP | [grounded] "coordinate design, art, engineering and community teams on each update" (JD). "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Selection scaffold ending in its honest branch: pick an update that reached two or more of those teams. If none comes to mind, say so plainly, then give the nearest thing your material carries (the weekly content drop) and how you would run it across four teams. | F2 is the gap; this is the likeliest place for a probe. Open prompt, theme from the JD. |
| A5 | "A live event's retention came in under plan. Tell me how you would run the post-event review." | CASE | [generic] Your own: "Presented the monthly retention numbers to the studio head." (your message) | Say what you check first (the cohort and the baseline), what you separate from the event, who reviews it, and which KPIs you report and to whom. If you have run a review like this, say what it found; if not, say so and say how you would run it. | JD line on post-event review; F3 is transferability. |

### B. Values/Behavioral (30%: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans" (company values page). "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Map to the weekly calendar at its own scope. Answer slot: if a drop moved because of players, say what and why; if the calendar held, say so and what you would check next time. | Detected values round, first value. |
| B2 | "Describe a release where what was announced and what shipped didn't match." | VAL | [grounded] "Ship the Patch Not the Promise" (company values page). "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: if such a release comes to mind, say what was announced and what shipped; if none does, say so, then say what the checklist is for, in your words. | Second value. The checklist is the nearest sentence you have. |
| B3 | "What did you leave behind that the next release relied on?" | VAL | [grounded] "Leave the Build Greener" (company values page). "Wrote the release checklist our QA team still uses." (your message) | Say that you wrote the checklist and that QA still uses it. Stop there; the material has nothing further. | Third value. Keep it to the sentence. |
| B4 | "How do you decide that a patch note describes what actually shipped?" | JD | [inferred] Derived from Tobias Wrenfield's GDC 2026 talk, "Patch Notes Are a Promise" (search snippet). "Wrote the release checklist our QA team still uses." (your message) | No claim about you beyond the checklist sentence. Describe the check you would run, and say whether the checklist covers it, only if you know. | His published theme. The [inferred] label names the talk as its derivation. |

### C. Skeptic (15%: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never led a team. Why should we hire you to coordinate four disciplines?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold, then concede. Plain acknowledgment: "I haven't led a team." Then say what you would do first to coordinate four disciplines on one update, as a plan. Concede the gap explicitly; do not add experience. | **Highest-ROI prep in this pack.** A stated gap that sits on a JD line (F2). Deepest rehearsal: two follow-ups, the concession worded once and exactly. |
| C2 | "You haven't worked on a game with in-app purchases. How would you handle purchase events on these two titles?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn the purchase calendar: ask for the title's monetization owners and read the event KPI definitions. A plan, not a past. | The JD does not name monetization, so this surfaces only if the interviewer raises it. |
| C3 | "Most of your calendar was one title. Why do you think two is the same job?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Stay at that sentence's scope. Answer slot: if you planned across more than one title, say how; if you did not, say so and say what you would check first. | F1 is the gap, asked as a skeptic's challenge. |

### D. Data-Driven Prober (10%: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot: if you know how it was counted, say how in your own words; if you did not build that count, say so plainly. Weakest-assumption move: name the assumption you would defend least, only if you know one. | F7; the figure is the probe's target. |
| D2 | "Which retention cut would you trust least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | If you know the cuts, name the one you trust least and why. If you did not calculate them, say so. | Same number, different angle. Honest branch is "I presented it; I did not count it." |
| D3 | "What did players get from the calendar you ran, and when?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Describe a drop, what it contained and when it landed, in your words. If you cannot name specifics, give the cadence and say that is what you have. | F5 and F6: the calendar is your strongest fact. Do not invent drop contents. |

### E. Pressure (5%: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message). "Wrote the release checklist our QA team still uses." (your message) | Pause. Hold the one thing in your material, the checklist. Concede the team-leadership gap in one plain sentence. Do not extend the held point beyond the checklist. | Stress interviewer: composure, not content. Two follow-ups. |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: "I wrote it, and QA still uses it." If QA changed parts after you wrote it, say which parts were yours and which were theirs. | Attribution probe. Stay with the sentence. |

### G. Conversational (5%: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message). "I ran the weekly content-drop calendar for our main title for the last two years." (your message). "Wrote the release checklist our QA team still uses." (your message). "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc: the four years, the calendar, the checklist, the retention presentation, each in your words. Nothing added between them. | Casual register, still scored. |
| G2 | "What live game are you playing right now, and what has its team done well?" | JD | [generic] | Name a title you actually play and one thing its live team did, in your own words. Keep it short; this is rapport, not a case. | Conversational probe on live-service fluency. |

## Coverage: JD requirement to questions

| Requirement | Covered by |
|---|---|
| Plan and run the calendar for two titles | A3, C3, F1 |
| Coordinate design, art, engineering and community | A4, C1, F2 |
| Own the post-event review and the KPIs | A5, D1, F3 |
| Manage the release checklist with QA | B2, E2, F4 |
| 3+ years producing live-service games or apps | D3, F5 |
| Experience running a content calendar | A2, D3, F6 |
| Comfortable with player-retention metrics | D1, D2, F7 |
| Clear written communication | none, and why: no question tests a writing sample in a spoken round; the upgrade menu asks for one |

## Reverse questions

At least five, each with why it lands.

1. "What did the post-event review look like on the last event, and which KPIs did it report?" Why it lands: it shows you are already thinking about the KPI ownership the JD names.
2. "How is Project Larkspur changing the per-title teams, and who will own the shared calendar?" Why it lands: it uses the company's own announcement and asks about the role's real scope.
3. "When a patch note and the shipped build disagree, who decides which one is right?" Why it lands: it reflects the interviewer's published theme.
4. "What did you carry over from QA into live operations?" Why it lands: it ties to his public path, a QA lead who moved into live operations, and turns a motivation check into a conversation.
5. "What would the first ninety days look like for someone running the calendar for two titles?" Why it lands: it asks about the role's first deliverables, not about perks.

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

Queries sent, with what came back:

- "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched; three values named.
- "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing. Fetched; loop is one 60-minute Outage Hour.
- "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur (September 2026). Search snippet only; not opened.
- "Tobias Wrenfield Saltmarsh Games": returned a GDC 2026 talk listing for "Patch Notes Are a Promise" by Tobias Wrenfield. Search snippet only; the talk page was not opened.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh games values | yes | Values cheat sheet: three values by official name |
| 2. saltmarsh games interview process Live Operations Producer | yes | Loop: one 60-minute Outage Hour, no take-home; the loop is established by the company page. Persona weights follow it |
| 3. saltmarsh games strategy / recent news | yes | Project Larkspur (September 2026) moves A2 (CO) and reverse question 2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read and B4; the talk is known from the listing snippet only |
| 5. representative live operations producer JD | skipped | Your JD fixes the fit snapshot and the JD questions |

Attribution note: the company pages are on the company's own domain. The talk attribution rests on the listing snippet, which names Tobias Wrenfield and his title at Saltmarsh Games.

## Upgrade menu

- The recruiter's note on the Outage Hour's format or scoring → the likely incident scenario and what the tabletop scores (A1, B-bank weights).
- The KPI definitions from the post-event review you presented → turns D1 and D2 into rehearsed answers instead of honest branches.
- Any post-launch patch notes you wrote, with the title name → examples for B2 and F5, and a stronger "live-service" line.
- A writing sample, such as a checklist page or a patch note → row F8 moves from discovery to grounded.
- The full text of Tobias Wrenfield's talk → checks the B4 derivation against what he actually argued.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on Saltmarsh's strategy and recent org changes → sharper A2 and reverse questions. Want it?
- A `tuesday-dossier.md` recording the gaps this prep exposed → carries C1 and C2 into later sessions.
