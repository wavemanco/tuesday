# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday 2026-11-26
**Interviewer:** not named. Relationship: hiring manager (from your note).
**Built from:** the job-underwriter dossier (`dossier_version` 1.1, generated 2026-08-14), consumed sections `role_profile`, `handoff_to_mock_interview` and `decision`. No research ran (see Sources).
**Stale check:** the dossier is more than three months old. Before you rely on the employer questions, confirm the posting still says what `role_profile` says.

## How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored: **JD** (a stated requirement), **EXP** (what you actually did), **CASE** (a live problem from the role).
- Guidance is scaffolding, not a script. Say it in your own words, in about 90 to 120 seconds.
- Quotes in the Provenance and evidence columns are the dossier's verified entries, word for word. `dossier V1` to `dossier V3` are the three `verified_candidate_evidence` entries in order.

## 3. Prep triage

Prep time was not stated, so this assumes tonight.

1. Say the answer to **A1** aloud three times. It is the objection the underwriter named, and the one most likely to be asked in some form.
2. Work **D1**: know how the 30+ was counted, and the assumption you would defend least.
3. Rehearse the hold in **C1** and **C2**, including the one concession you are willing to make.
4. Pick two reverse questions from section 11, starting with the two the underwriter flagged: **RQ1** and **RQ2**.
5. Skim the rest once.

Everything else is insurance.

## 4. Fit snapshot

Your evidence is quoted verbatim from the dossier. Gap type is decided by the evidence cell, not by how the row reads.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1a | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | Bridge at the quote's own scope: "I haven't held the product manager title. What I have done is lead client integrations of the vendor's REST APIs, from scoping through go-live." The limit is the pack's observation: the material shows integration leadership, not product management years. Do not state a year count (see the note below the table). |
| R1b | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to dossier prohibited_claims ("Having owned a product roadmap" and "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then a plan, never a past: "In the first quarter I'd learn how your squad leads set priorities and what evidence they use." No answer slot. |
| R2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | The quote is integration work from the integrating side. Say that side: "I led integrations of the REST APIs." The limit is the pack's observation, not words for you: the material shows integrating the APIs, not shipping them. Never say "shipped" or "owned the product." The dossier gives no allowed strategy for R2; this row is bridged under the routing rule, and the underwriter should confirm it. |
| R3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook" — dossier V2 | low | [inferred] | discovery | The material does not show docs or schema work. Answer slot: "If you wrote or checked API docs or schemas, say what and how. If you did not, say so plainly, and say what you have read or used." |
| R4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3; "UAT, go-live" from dossier V1 | medium | [grounded] | transferability | Customers and product are covered by V1 and V3 at their own scope, with the medium-confidence caveat named: "I ran the input sessions; that was limited evidence, and I can walk you through it." Engineering and sales appear in no quote. Answer slot for both. |
| R5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | Clarify, as the dossier allows: ask what they mean (sprint cadence, backlog ownership, how squads are staffed), then answer only on the one you have run. Nothing in the material speaks to it directly. |

**Note on years.** The dossier's decision summary says "seven years of integration leadership." No verified entry carries that figure, so it is not a basis for any answer. Use a number only once you can tie it to a sentence in your own record.

**Hard gates:** none (the dossier's `hard_gates` is empty).

## 5. Prohibited claims

Built from the dossier's `prohibited_claims` and the fit snapshot. These are not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't held the product manager title." |
| Having owned a product roadmap | Sourced: dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't set priorities for an engineering squad." |
| Shipped API or platform products as the owner | Inflated form of R2 (widens dossier V1 from integrating to shipping) | V1 at its own scope. The limit is the pack's observation, not a first-person negative. |
| Set the roadmap through the input sessions | Inflated form of R4 (widens dossier V3 from feeding evidence to deciding) | V3 at its own scope: "feeding client evidence to product." |

## 6. Personas and weights

| Persona | Weight | How it shows up here | Reasoning | Counter-strategy | Questions |
|---|---|---|---|---|---|
| Skeptic | Top | The PM-title objection, the missing roadmap, "where would you be weakest on day one" | Hiring-manager prior, plus the underwriter named this objection | Rehearse the objection until it is dull. Hold the integration-side strength through two follow-ups, then concede the prioritization gap specifically | 5 (A1 to A5) |
| Case / Strategist | High | Live problems on the squad and partner roadmap | Hiring-manager prior: they are buying capability and will test it on their own roadmap | Clarify, then objective, then segmentation, approach, metrics, risks | 4 (B1 to B4) |
| Pressure | Mid | Time-boxed challenges to the integration-side claim | Mid weight: the dossier's medium-confidence seam (V3) and the 30+ figure invite it | Hold, then concede the one gap, never the core claim | 3 (C1 to C3) |
| Data-Driven Prober | Mid | Denominators for the 30+ figure, what adoption was measured as | Mid weight: the 30+ figure is a headline number, and adoption has no stated baseline | Say how it was counted, and name the assumption you would defend least | 3 (D1 to D3) |
| Conversational | Low | A friendly opener asking for your journey | Low weight, but casual questions are still scored | A 90-second arc built on the verified entries | 2 (E1 and E2) |
| Peer Evaluator | Low | The seam with the two squad leads | Low weight for a hiring manager, but the squad seam is in the role | Propose seam principles, not claims about the squads | 2 (F1 and F2) |

Total: 19 questions, inside the 18 to 26 range. No loop source was found, so no loop adjustment applies.

## 7. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the product manager title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook" (dossier V2); plain acknowledgment from dossier prohibited_claims: "Having held a product manager title or role" and "Having owned a product roadmap" | Hold: "I haven't held the product manager title, and I haven't owned a product roadmap." Then the record at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live," and "I wrote the integration playbook." Then the ramp, as a plan: "In the first quarter I'd learn how you set priorities and what evidence you use." Do not compare yourself with a PM who has three years of the role. Concede once, specifically: "Prioritization is the part I'd be learning." | The underwriter named this as the most likely objection, so it gets the deepest rehearsal. R1a and R1b. JD type because it scores a must-have. The question's negatives are sourced to the dossier, so the question is asked as written. |
| A2 | "What's the closest you've come to setting priorities for a product team?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Plain acknowledgment first, if you are asked to rank yourself: "I haven't set priorities for a product team." Then V3 at its scope: "I ran the quarterly input sessions, which fed client evidence to product." Answer slot: "If you chose which client evidence reached a product decision, say how. If you only collected it, say so plainly." | V3 is the closest adjacent evidence, and its confidence is medium, so the caveat is volunteered. R1b. |
| A3 | "Which side of an API product have you worked on: the team building it, or the teams integrating it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer on the integrating side, in V1's words. Answer slot: "If you also shaped any part of the product itself, say which part and how. If you did not, say so plainly." Do not describe the product side. | The question asks for the relationship, which is where inflation is most likely. R2. |
| A4 | "The role owns adoption metrics for partner APIs. What have you defined?" | JD | [generic] The JD's "Define and track adoption metrics" (dossier role_profile responsibilities) | Answer slot: "If you defined an adoption measure, say what it counted and what it was sensitive to, in your own words. If you did not, say so plainly, and say how you would set a baseline first." No metric is supplied here. | The role's responsibility raises this, and the material is silent. The honest branch is the one you will need. |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier prohibited_claims ("Having owned a product roadmap") and uncertain_or_weak_areas acknowledge_gap | Answer: "Owning the roadmap. I haven't done that." Then the ramp: "In the first quarter I'd learn how the squad leads set priorities." Do not name a second weakness you have not discussed. | Persona stem. Answers R1b directly, so you say it before it is extracted. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squad leads disagree about shipping a partner-requested endpoint this quarter. Partner adoption is flat. How do you decide?" | CASE | [generic] A live problem from the role's squad and partner responsibilities (dossier role_profile). Asks about no past. | Clarify what the decision is for, and who owns each squad's cost. State the objective, segment the partners, then test the approach against adoption and delivery risk. Name one premise you would challenge. Say nothing about your own past here. | A live problem from the squad-and-partner responsibility. |
| B2 | "Partner API adoption is falling. Diagnose it." | CASE | [generic] The role's "Define and track adoption metrics" responsibility (dossier role_profile) | Clarify the measure and its baseline first. Then segment by partner type and by integration stage. Give two hypotheses, each with the metric that would confirm or rule it out. | The adoption responsibility raises the case. The honest first move is to ask for the baseline, which is also the dossier's open risk. |
| B3 | "What would you measure in the first 30 days, and what baseline would you need before you set a target?" | CASE | [generic] The role's adoption responsibility (dossier role_profile) | Answer with the measure and the baseline, and say what you would not set a target on until the baseline exists. Make no claim about measures you have set before. | The baseline is the dossier's second open risk, so this is where it is probed. |
| B4 | "Map the stakeholders for a change to a partner-facing API: engineering, sales, customers. Where do you start?" | CASE | [grounded] The role's stakeholder requirement, quoted from dossier role_profile R4: "Stakeholder management across engineering, sales, customers" | Start with the decision owner, then the customers who will feel the change. Name engineering and sales as the two you would need to align with, and say how you would find out what each needs. Do not claim to have run this before. | R4 is partly covered by V1 and V3. The case tests it without asking for history. |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); plain acknowledgment from dossier prohibited_claims ("Having held a product manager title or role") | Pause. Restate the question. Then: "I haven't held the product manager title. What I'd offer is the integration side: I led 30+ client integrations from scoping through go-live." Hold through two follow-ups on the integration side. Concede once, specifically: "Owning the roadmap is what I'd be learning." | Pressure persona. The hold-then-concede structure matters more than the content. R1a. |
| C2 | "That's integration work. How much of the outcome was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Keep to what V1 says you led: scoping through go-live. Name the phases you led and say that the client's own team owned theirs, only if that is true. If you do not know who owned which phase, say so. | The attribution probe. Keep your share exact, and do not promote "led" into "delivered" or "owned." |
| C3 | "You're telling us you'd learn roadmap ownership. Why should we bet on a learning curve?" | JD | [grounded] "I haven't owned a product roadmap" (plain acknowledgment, dossier prohibited_claims) | Hold: the bet is on the parts you have done, V1 and V2. Name what the first quarter would show: how the squad leads set priorities and what evidence they use. Concede that this is a bet, not a record. | Pressure on a plain acknowledgment. The answer is a plan, not a past. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | Defend-the-number slot: "Say how you counted, in your own words. Name the assumption you would defend least. If you do not know how the count was kept, say so plainly." | The headline figure is the probe magnet. The dossier gives no count method, so none is supplied. |
| D2 | "Of the 30+, which parts were yours on each one: the whole thing, or some phases?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: "Say which phases you led on each one. If on some you led only part, say which part." Keep to the phases V1 lists. | The attribution follow-up to D1, kept at V1's scope. |
| D3 | "Did the playbook or the roadmap-input sessions ever produce a measurement of anything? Which?" | EXP | [grounded] "Wrote the internal integration playbook" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Answer slot: "If one did, name what it measured. If none did, say so plainly, and say what you would measure first." | The adoption-metric risk, asked about your past. The honest answer may be no. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] Dossier V1, V2, V3 | A 90-second arc in this order: V1 (the integrations, with the 30+ attributed to you), V2 (the playbook), V3 (the input sessions, with the medium-confidence caveat named). Use "I" for contribution. Do not mention years. | Casual register, still scored. The arc keeps you on the three verified entries. |
| E2 | "What's your current hands-on work with API docs or schemas, if any?" | JD | [grounded] Dossier V2: "Wrote the internal integration playbook" | Answer slot: "If you have written or checked API docs or schemas, say which. If not, say so plainly, and say what you have read or used." | R3, which the material does not show. The question does not presume hands-on work. |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our squad leads sit side by side with product. Where's the seam between you and them, and what happens when you disagree?" | JD | [grounded] The role's "Write specs and drive delivery with two engineering squads" (dossier role_profile) | Propose seam principles: decision rights, who writes the spec, how disagreements escalate. Answer slot: "If you have disagreed with an engineering lead, say how it resolved, in your own words. If you have not, say the principle you would use." | The squad seam is in the role and is where R4 meets engineering, which no quote covers. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | Use "we" for the team's work and "I" for what you led. Answer slot: "Say what you led and what the other teams owned, only where you know it." | Persona stem. The attribution is V1's, and the other teams' share is not yours to name. |

## 8. Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 (3+ years product management) | A1, C1, E1; limit stated in the fit snapshot |
| R1 sub-claim (roadmap and prioritization) | A2, A5, C3; RQ1 |
| R2 (shipped API or platform products) | A3, C2 |
| R3 (API docs, schemas) | E2 |
| R4 (stakeholders across engineering, sales, customers) | B4, F1, F2 |
| R5 (agile delivery, preferred) | Clarify slot in the fit snapshot, and RQ6. No banked question; the requirement is preferred and the material is silent. |
| Responsibility: adoption metrics | A4, B2, B3, D3 |
| Responsibility: discovery with partners | RQ4 |

## 9. Reverse questions

Each carries its "why it lands." This is a hiring-manager round with no interviewer profile, so no question is tied to the interviewer's path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it tests the decision-authority risk the underwriter flagged, and the answer decides whether R1b is a ramp or a mismatch.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: it tests the baseline risk the underwriter flagged, and tells you whether B2 and B3 will be asked as they are.
3. **"What does discovery with integration partners look like in a typical month, and who attends?"** Why it lands: it shows how close the role is to the input sessions in V3.
4. **"Where does agile delivery run here: sprint cadence, backlog ownership, or both?"** Why it lands: it resolves R5 so you can answer the clarify slot on their terms.
5. **"What would make the first six months a clear success for you?"** Why it lands: it gives you their success criteria before you are judged on them.
6. **"Which of the four responsibilities is hardest to do well right now?"** Why it lands: it shows you where the role is under strain, and it is the question an interviewer remembers.

## 10. Values cheat sheet

Not included. No values round was detected, and no research ran to find the company's published values.

## 11. Delivery coaching

Not included. No working-style assessment was provided.

## 12. Grounding brief

Not included. Deep research did not run.

## 13. Prohibited claims

See section 5 above.

## Sources

**Provided documents**

- The job-underwriter dossier (`dossier_version` 1.1), pasted in the request. Consumed: `role_profile`, `handoff_to_mock_interview`, `decision` (context only). Major version 1 is known to this skill, so the envelope was read as written.

**Searches and fetches sent**

- "Quartzline company values": refused (the host had not granted search permission).
- "Quartzline Product Manager Platform APIs interview process": refused.
- "Quartzline partner API platform strategy news": refused.

No fetches were sent.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. Search was refused, so no research result was used.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. "Quartzline company values" | unavailable | Would have set up the values cheat sheet. No values round was detected, so the section is dropped either way. |
| 2. "Quartzline interview process Product Manager" | unavailable | Would have set loop structure and persona weights. Weights here are the hiring-manager prior, unadjusted. |
| 3. "Quartzline strategy / recent news" | unavailable | Would have grounded the company-knowledge bank. There is no CO question; the CASE questions are `[generic]`. |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the requirements, so a representative JD would move nothing. |

## Upgrade menu

- **The posting's full text** → the requirement rows become checked against the source, rather than resting on the dossier's `role_profile`. Right now the requirement lines are the underwriter's, and that is why the stale check above matters.
- **Search permission** → the three refused research targets run. Values, loop structure and current strategy would then be grounded, and a company-knowledge bank with a strategy question would be possible.
- **The interviewer's name** → a tailored reverse question, and persona weights from their public footprint.
- **Your CV or resume** → each `dossier V` quote can be checked against the sentence it came from, and the 30+ figure can be defended against your own record.
- **Deep research (L2)** → up to six further searches and two fetches, for interviewer talks and role-family loop reports. Offered once; it runs only when search is available and you ask for it.
- **`tuesday-dossier.md`** → records the gaps this prep exposed, for later sessions.
