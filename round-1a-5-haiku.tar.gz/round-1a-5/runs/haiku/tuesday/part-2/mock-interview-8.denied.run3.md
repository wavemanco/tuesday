Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-8-denied-e433658c/72b8f545-25df-49cc-a3e3-c8d58ef95acf/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. I built it as a loop across all three rounds, since your recruiter's email gave the structure. It has a question bank for each round, a values sheet, and a list of claims the pack won't coach you to make.

The highest-return prep is B6, and its panel version C8. The likely objection is that you have never worked in a contact centre and never presented above regional level. Rehearse the plain statement of each gap, then your plan for closing it. Don't add to your record in the answer.

Say the word and I'll play the Skeptic on B5 or the Pressure interviewer on B6 as a drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Rounds, 4 December 2026 (loop mode, three scheduled rounds):**
- Round 1, 30 min: recruiter screen
- Round 2, 45 min: Head of Member Services, your prospective manager, mostly behavioural (name not yet given)
- Round 3, 60 min: panel of two branch managers, including a 20-minute complaint-escalation case; scored against the four values (names not yet given)

**Built from:** the JD you pasted, the values you copied on 25 November 2026, your recruiter's round outline, your summary of the July 2026 strategy brief, and your background note. No CV was supplied, so every quote below is from your message.

---

## 2. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioural | Whether past behaviour shows the four published values |
| EXP | Work-experience deep-dive | Whether what you did survives scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you can talk at the bank's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Question IDs: A for round 1, B for round 2, C for round 3.

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: decide in advance what you will say on each branch, and say whichever is true.

---

## 4. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Say the years and the sector in your own words: six years in retail banking, three as a branch supervisor. Whether that is the JD's "financial-services customer operations" is the interviewer's call, so do not restate the sentence as more than it says. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal, not regulated. Answer slot: say what made the log formal and what rules it had to follow. If rules governed it, name them and how you applied them. If none did, say so plainly and stay with the log you handled. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Stay at the log's scope: one branch's formal complaints log. Anything across branches or the contact centre is an answer slot: if you did any of it, say which part, in your own words; if you did not, say so plainly. |
| F4 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, which is not the same as a stated absence. Answer slot: if you worked with a digital team on any journey, say which part was yours; if you did not, say so plainly and say how you would start. |
| F5 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn contact-centre complaint work, said as a plan and never as a past. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Coaching supervisors is a different audience from training tellers. Say what you did with tellers, in those words. The script is the bank's, so do not say you wrote it. Describe supervisor coaching as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The sentence shows a monthly spreadsheet. It does not show resolution times. Answer slot: if it tracked how long complaints took to resolve, say how that was counted; if not, say so and say what you would add first. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Confidence is medium because nothing has been inspected. A copy of the spreadsheet, with member data removed, would raise it to high. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan. Never claim presenting above regional level, or any senior forum. |

Gap types follow the routing rule in the template: F5 and F9 are capability because you stated the absence; F2, F4 and F7 are discovery because your material is silent on the part that matters; F3 and F6 are transferability because the adjacent work is real but does not reach the requirement; F1 is presentation because the quote already carries the years and sector.

---

## 6. Grounding brief (from your summary of the strategy brief)

You said the recruiter sent the July 2026 brief. I have not seen the document; everything here is from your summary, so check the figures against the brief before you quote them.

- Member service moves 40% to digital channels by 2028 (your summary, [grounded]).
- Eight branches consolidate into five hubs over 2027 (your summary, [grounded]).
- A small-business lending product launches in Q1 2027 (your summary, [grounded]).
- The main competitive pressure is app-only banks (your summary, [grounded]).

Vocabulary to use: "digital channels", "hubs", "member service".

Reasoning drawn from this material, labelled as reasoning:
- The channel shift changes which complaints reach a complaints lead, and by what route. [generic]
- The hub plan puts the "Neighbours, Not Numbers" value under direct test. [inferred] from the brief and the value wording.
- A small-business lending product may add complaint types the current process was not built for. [inferred] from the brief.

The brief is about four months old, so it is inside the six-month freshness window.

---

## 8. Persona weights by round

Depth follows weight: top persona 4 to 5 items, mid 3, low 2. The panel blends the top two personas of each member, since the members are not yet named.

| Persona | Round 1 (recruiter) | Round 2 (Head of Member Services) | Round 3 (panel) | Why the weights | Counter-strategy |
|---|---|---|---|---|---|
| Conversational / rapport | Top: 6 items (A1, A3 to A7), with the logistics rows in the recruiter's register | Low: touched in the arc of B1 | None; a panel does not open with small talk | Recruiter priors put logistics and motivation first. Casual questions are still scored. | A 90-second arc for the opener. Treat every casual question as scored. |
| Skeptic | Light: 2 items (A2, A8) | High: 3 items (B5, B8, B9) | Not a panel blend; the stated absences come back through C8 | You have two stated absences, contact centre and presenting above regional level. A manager who is buying capability will go straight at them. | Rehearse the plain acknowledgment until it is boring, then the plan. Never bluff the competency. |
| Values / behavioural | Not weighted | Top: 4 items (B1 to B4) | Top for member 1: 4 items (C3 to C6) | The round is mostly behavioural, and the panel scores against the four values. | STAR-shaped answers. "We" for context, "I" for what you did. Where no story exists, say so and give the nearest thing. |
| Pressure / stress | Not weighted | Low: 2 items (B6, B11) | Blended with peer for member 2: 2 items (C7, C8) | Composure under challenge. B6 is the single highest-ROI item in the pack. | Pause, restate, hold through two follow-ups, then concede the specific thing you do not know. |
| Case / strategist | Not weighted | Not weighted | Top for member 1: 3 items (C1, C2, C10) | The 20-minute case is the single largest scored block of the day. | Clarify, then structure, then work. Think aloud and challenge one premise. |
| Peer evaluator | Not weighted | Not weighted | Blended with pressure for member 2: 2 items (C9, C11) | The branch managers run branches that your complaints work will touch. | Reciprocity: what you bring their branches, not just what you need. |
| Data-driven prober | Not weighted (touched by A8) | Low: 1 item (B7), touched only once | Low: 1 item (C12) | Spreadsheet questions will be checked for assumptions. | Name the weakest assumption before they do. Say plainly what you do not know about how a figure was counted. |

---

## 9. Question banks

### Round 1: recruiter screen (A1 to A8)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Give the arc in those four beats, in that order, in your own words. Stop at the spreadsheet. Do not add a title, a scope or an outcome. | The Conversational opener. It is scored, so use the same sentences you will use in round 2. |
| A2 | "You've never worked in a contact centre. Why would a role that covers the contact centre suit you now?" | JD | [grounded] "Never worked in a contact centre"; "trained new tellers on our escalation script" | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing: the escalation training, in those words. Then your reason for the move, in your own words. Your material gives no reason, so that part is yours to give. | F5 is the gap. The premise is your own stated negative, so expect it back. |
| A3 | "What are your salary expectations?" | JD (pay) | [generic] the recruiter's standard question | Logistics slot, no figure. Either ask what the band is for this role first, or give your own number. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a logistics row. Your material states no figure, so none is supplied here. |
| A4 | "What's your notice period?" | JD (notice) | [generic] the recruiter's standard question | Logistics slot: give your actual notice period. If you have not confirmed it, say so and say when you will. | Your material states no notice period. |
| A5 | "Where would you be based, and how would you travel between sites?" | JD (location) | [generic] the recruiter's question; [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Logistics slot: give your actual location and travel limits in your own words. The hub plan makes travel likely to come up. Say what is true for you. | Your material states no location constraint. |
| A6 | "Why are you looking to move on?" | EXP | [generic] the recruiter's standard question; no candidate sentence states a reason | Answer slot: say your real reason, in your own words. If the honest reason is about your current bank, say so plainly and keep it brief. | Reason for leaving is a logistics row. No reason is supplied here. |
| A7 | "What's drawn you to Ashgrove, given what we're moving toward?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Name one move from the brief in your own words and say what it changes for a complaints role. Your reason for wanting this role is an answer slot: say what you want from it, in your own words. | The one CO item in round 1. The brief is the strongest material for it. |
| A8 | "What do you use the monthly spreadsheet for, and who reads it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it is for and who uses it, in those words. Answer slot: if it tracked how long complaints took to resolve, say how that was counted; if not, say so plainly. | Covers the Excel requirement and, through its answer slot, the resolution-times requirement (F7, F8). |

### Round 2: Head of Member Services (B1 to B11)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you kept hold of until it was fixed." | VAL (Own the Fix) | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint you found and stayed with until it closed. Say what you did at each step, and when it left your hands. Honest branch: if none comes to mind, say so plainly, then give the nearest thing your material carries: the log you handled, and how a case stayed with you. | Own the Fix has no quoted story. The log is the nearest carrier, not the story itself. |
| B2 | "Tell me about a time an explanation didn't land and you had to say it differently." | VAL (Plain Words) | [grounded] "trained new tellers on our escalation script" | Scaffold: a time a member or a teller needed something explained twice, and you changed the wording. Honest branch as in B1, with the training sentence as the nearest thing. | Plain Words has no quoted story. |
| B3 | "When did you decide something from the member's side of the counter, when the branch's own needs pulled the other way?" | VAL (Members First) | [grounded] "I handled the branch's formal complaints log" | Scaffold: name the decision, what the member needed, what the branch needed, and what you chose. Honest branch as in B1. | Members First has no quoted story. Members First is the value the panel will test most in round 3, so keep the trade-off concrete. |
| B4 | "Tell me about a decision where it mattered that a branch sits in its town." | VAL (Neighbours, Not Numbers) | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Scaffold: a time local knowledge changed what you did. Honest branch as in B1, with the branch-supervisor years as the nearest thing. Watch the trap: the spreadsheet (F8) makes you sound like someone who counts. The value asks about places. | Neighbours has no quoted story, and the hub plan will test it. |
| B5 | "You've never presented to anyone above regional level. What would you do in front of a senior leadership group?" | JD (presenting) | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would prepare, in what order, and what you would ask before you walked in. Describe a plan, never a past event. | Capability gap F9. Rehearse with B6. |
| B6 | "Sixty seconds: why should senior leaders trust a complaints lead who has never worked in a contact centre or presented above regional level?" | JD (presenting; contact centre) | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pressure version. Pause, restate the question, then hold: the material supports the branch complaints log and the teller training, in your words. Concede specifically: "I haven't worked in a contact centre, and I haven't presented above regional level." Do not fold into claiming a capability the sentences do not carry. Hold through two follow-ups by returning to the log and the training, never by adding to them. Then give the plan. | **The highest-ROI prep in this pack.** This objection is very likely in some form, and it is aimed where your material is thinnest. Its premise is your own stated negatives. |
| B7 | "Walk me through the monthly complaints spreadsheet. What does it count, and how would you check it?" | EXP (defend the number) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name, before they find it, the assumption behind the spreadsheet you would defend least. Answer slot: say what it counted. If it counted time to resolve, say how; if not, say so plainly. | Prober item on the Excel and reporting requirements. |
| B8 | "A supervisor keeps escalating things they should close. How would you coach them?" | JD (coach supervisors) | [grounded] "trained new tellers on our escalation script" | Answer slot: if you have coached a supervisor on escalations, say how, in your words. If not, say so plainly and describe how you would start: what you would look at first and what you would ask the supervisor. The training sentence is about tellers, so say that. | F6's bridge. |
| B9 | "What made the formal complaints log formal? What rules did it have to follow?" | JD (regulated complaints) | [grounded] "I handled the branch's formal complaints log" | Answer slot: say what the rules were, in your words, and how you applied them. If none governed the log, say so plainly and stay with the log you handled. | F2 is discovery. The pack does not name a regulator, and neither should you unless you can point to one you worked to. |
| B10 | "Tell me about a time you worked with a digital team, or on a self-service change." | JD (digital) | [grounded] JD: "work with digital teams on self-service journeys" (the raising source) | Open prompt with an honest branch. If you did, say what your part was, in your own words. If you did not, say so plainly and say how you would start. | F4 is silence. This is the one place it gets asked. |
| B11 | "Sixty seconds: what is the first thing you would change about how a branch handles complaints?" | JD (monthly reporting) | [grounded] JD: "report monthly on complaint volumes and resolution times" | Pressure, time-boxed. Name one thing you would check or test first, and how you would know it worked. If you do not yet know their current process, say that first. Hold through one follow-up. | Tests the plan-not-past habit under a clock. |

### Round 3: panel (C1 to C12)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Case, 20 minutes: "A member's complaint about a loan decision has moved between a branch and the contact centre for two weeks. They now say they will take it outside the credit union. You have the file. What do you do in the next 24 hours?" | CASE | [generic] | Clarify what was decided, what the member asked for, and which rules set the timing; ask for them rather than assume. Name one owner today (Own the Fix). Give the member a plain answer. Fix the immediate problem, escalate what needs escalating, send the root cause back to the branch, and record it. Think aloud. Challenge one premise: the threat to go outside changes urgency, not ownership. Rough timing: 3 minutes to clarify, 5 to structure, 8 to work the case, 4 to recommend and record. | A live problem drawn from the JD's end-to-end line. It presumes nothing about your past. |
| C2 | Case follow-up: "The branch manager says the decision was right. The contact centre says the branch never answered. Who decides, and how?" | CASE, JD (end to end) | [generic]; [grounded] "I handled the branch's formal complaints log" (nearest only) | Separate facts from positions. Name who decides and on what evidence. Hold one position through one follow-up. Answer slot: if you have settled a dispute between a branch and another team, say how; if not, say so and describe the decision path. | Covers the end-to-end requirement across branch and contact centre (F3, F5). |
| C3 | "Tell me about a complaint that passed between two teams. Who kept hold of it?" | VAL (Own the Fix) | [grounded] "I handled the branch's formal complaints log" | Scaffold: name the complaint, the two teams, and the moment you held it. Honest branch as in B1. | Second Own the Fix item. |
| C4 | "Give an example where you decided from the member's side, even when the branch's numbers pulled the other way." | VAL (Members First) | [grounded] "I handled the branch's formal complaints log" | Scaffold: the decision, the member's need, the number that pulled the other way, and what you chose. Honest branch as in B1. | Second Members First item. The value's wording sets the trade-off. |
| C5 | "Tell me about a time you changed how something was said because members didn't get it first time." | VAL (Plain Words) | [grounded] "trained new tellers on our escalation script" | Scaffold: a time the wording changed because it did not land. Honest branch, with the training sentence as the nearest thing. | Second Plain Words item. |
| C6 | "Tell me about a decision that needed local knowledge a head office would not have had." | VAL (Neighbours, Not Numbers) | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Scaffold: a decision where local knowledge mattered. Honest branch, with the branch-supervisor years as the nearest thing. | Second Neighbours item. The hub plan makes this the probe to expect. |
| C7 | "Eight branches become five hubs. Why should branch managers believe a complaints lead can protect their towns?" | Pressure, CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Hold: you cannot promise to protect a town. What you can say is what you would do so that complaints do not fall between a branch and a hub. Concede specifically: you do not yet know what the consolidation means for a given town, and you would ask before deciding. Do not fold into promising. | The question presupposes the consolidation, which your brief summary raises. This is the CO item in round 3. |
| C8 | "You've never presented above regional level. Give us your sixty-second version of a complaints trend for the board." | JD (presenting) | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if the spreadsheet showed a trend you can describe, say what it showed. If not, say what you would show first and why. Do not invent a board. | Panel version of B6. |
| C9 | "How would you coach a supervisor whose escalations reach the contact centre without a summary?" | JD (coach supervisors) | [grounded] "trained new tellers on our escalation script" | Answer slot: if you have coached a supervisor, say how. If not, say so plainly and describe the first conversation you would have. | Second coaching item. Peer persona: the seam between branch and contact centre. |
| C10 | "Where would you start on a self-service journey with a digital team that doesn't yet know what members complain about?" | CASE, JD (digital) | [generic]; JD: "work with digital teams on self-service journeys" (the raising source) | Structure: what complaints tell you about where a journey fails; who you would ask; a small test before a build. No past claim. If you have worked on a journey, say what your part was instead. | The digital requirement, asked live. |
| C11 | "Branch managers own their complaint numbers. How would you work with us without taking those numbers off us?" | JD (volumes and resolution times); peer seam | [grounded] JD: "report monthly on complaint volumes and resolution times" | Reciprocity: what you would bring to their branches, not just what you need from them. Propose a seam principle, such as who holds the numbers and who holds the case. Do not pretend to know their seam. | Peer evaluator item. The panel members run the branches your reports describe. |
| C12 | "What do you do when a spreadsheet's numbers look wrong?" | EXP (defend the number) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name the check you ran, if you ran one. Answer slot: if you have found a figure wrong, say what you did; if not, say so and say how you would check it. | Prober item. The sentence supports the spreadsheet, not a checking practice. |

### Requirement coverage

Each JD requirement, and each value, maps to at least one question. The coverage check is against the JD's own list.

| JD requirement | Covered by | Note |
|---|---|---|
| 4+ years in financial-services customer operations | A1 (EXP), B6 (JD) | F1 |
| Experience handling regulated complaints | B9 (JD), B1 (VAL) | F2 |
| Own the complaints process end to end across branches and the contact centre | C2 (CASE, JD), A2 (JD) | F3, F5 |
| Report monthly on complaint volumes and resolution times | A8 (JD), B7 (EXP), C11 (JD), C12 (EXP) | F7 |
| Coach branch supervisors on escalations | B8 (JD), C9 (JD) | F6 |
| Confident presenting to senior leaders | B5 (JD), B6 (JD), C8 (JD) | F9 |
| Comfortable with Excel reporting | A8 (JD), B7 (EXP), C12 (EXP) | F8 |
| Work with digital teams on self-service journeys | B10 (JD), C10 (CASE, JD) | F4 |
| Values: Members First, Always | B3 (VAL), C4 (VAL) | Section 10 |
| Values: Plain Words | B2 (VAL), C5 (VAL) | Section 10 |
| Values: Neighbours, Not Numbers | B4 (VAL), C6 (VAL) | Section 10 |
| Values: Own the Fix | B1 (VAL), C3 (VAL) | Section 10 |
| Strategy (CO) | A7 (CO), C7 (CO, Pressure) | Section 6 |

---

## 10. Values cheat sheet

The panel scores against these four values, so each has a story or a selection scaffold. None has a quoted story in your material. Each row gives the nearest sentence you do have and the honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold | Honest branch |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a member-side decision. Scaffold: a complaint where your decision was made from the member's side, and what changed for the member. Nearest thing: F3, "I handled the branch's formal complaints log." | If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | No quoted sentence carries it. Scaffold: a time the wording changed because it did not land. Nearest thing: F6, "trained new tellers on our escalation script." | As above. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Scaffold: a decision where local setting mattered. Nearest thing: F1, "6 years in retail banking, the last 3 as a branch supervisor." | As above. Analysis, labelled [inferred]: the hub plan tests this value directly, and the spreadsheet (F8) makes you sound like someone who counts. Prepare for the numbers trap. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence carries it. Scaffold: a complaint you found and kept until it closed. Nearest thing: F3, "I handled the branch's formal complaints log." | As above. |

---

## 11. Reverse questions

Each has a "why it lands". The panel members are branch managers, so RQ5 is also a reciprocity question. No interviewer profile exists yet, so none ties to an interviewer's own path.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which complaints would this role own on day one, and which would stay with branches?" | Tests the JD's end-to-end line against the 2027 hub plan. It asks for a boundary rather than a pitch. |
| RQ2 | "As branches move into the five hubs during 2027, who owns a complaint that started in a branch that has been consolidated?" | Shows you read the brief and the Neighbours value, and asks the question the hub plan makes live. |
| RQ3 | "What does the monthly complaints report get used for, and what question should it answer that it does not answer today?" | Lands on the Excel requirement and the reader, not just the file. |
| RQ4 | "What would make the first three months in this role clearly successful?" | Standard, but in this loop it gives the Head of Member Services a chance to name the scoring standard. |
| RQ5 | "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" | Reciprocity for the panel. It shows you are thinking about their work, not only yours. |
| RQ6 | "When a branch escalates a complaint, what does the contact centre need from the branch to act on it?" | A practical seam question. It lets you show the supervisor-coaching thinking in a form the panel can use. |

---

## 13. Prohibited claims

These are not to be coached, in any cell or any drill. Each one names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end across branches and the contact centre" | Inflated form of F3 | The quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says one branch's log. |
| "Handled regulated complaints to regulator timelines" | Inflated form of F2 | The quote at its own scope. Your material says formal, not regulated. |
| "Wrote the escalation script" or "set the escalation process" | Inflated form of F6 | "trained new tellers on our escalation script." The script is the bank's. |
| "Coached branch supervisors on escalations" | Inflated form of F6 | "trained new tellers on our escalation script." Tellers, not supervisors. |
| "Reported resolution times every month" | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." What it tracked is an answer slot. |
| "I have presented to senior leaders" or any presenting above regional level | Negative you stated, F9 | Plain acknowledgment: "I haven't presented to anyone above regional level." |
| "I have worked in a contact centre" | Negative you stated, F5 | Plain acknowledgment: "I haven't worked in a contact centre." |

The digital requirement (F4) and the supervisor-coaching requirement beyond tellers are silences, not stated negatives. They are answer slots, not entries here.

---

## 14. Sources

**Provided documents, all in hand:**
- The JD, as you pasted it.
- The values, as you copied them on 25 November 2026 from ashgrovecu.org/about/values. The page was not fetched by me.
- The round outline in your recruiter's email (three rounds, lengths, who runs each, the values scoring).
- Your summary of the July 2026 strategy brief. The brief itself was not seen.
- Your background note. No CV was supplied.

**Searches and fetches sent:** none.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values are in hand as your paste, so the inputs fix the names and definitions. No check was sent. |
| 2. Ashgrove interview process | skipped | Your recruiter's email establishes the loop: three rounds, lengths, who runs each, and the values scoring. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the current priorities. A news sweep would have moved only CO wording. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given for rounds 2 or 3. The recruiter's name was not given either. |
| 5. Representative JD for this title | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Your summary of the brief is the only source for the strategy figures. Check them against the document before you quote them in the room.

---

## 15. Upgrade menu

- The names of the round 2 manager and the two round 3 panel members, if you learn them → persona weights from their public footprint, a tailored reverse question, and panel assignments per member.
- Whether the 20-minute case comes with a written brief, and what data you may use → the round 3 case section, rebuilt around the real material.
- A copy of the monthly complaints spreadsheet, with all member data removed → F8 moves from medium to high, and the defend-the-number items (B7, C12) rest on what the file actually shows.
- Whether the formal complaints log followed set rules, and which → F2 moves from discovery to grounded, and B9 becomes a concrete answer.
- Whether you have coached a supervisor, worked with a digital team, or presented above regional level → the bridges for F4, F6, F9, and the answer slots in B8, B10, C8 and C9.
- The brief itself, as a PDF → the grounding section checks the document, not your summary.
- Your CV → the medium rows rest on a document as well as your message.
- How much prep time you have before 4 December → a prep triage schedule, sized to that time.
- A deeper research pass on Ashgrove's public material: up to 6 more searches and 2 more fetches, several more minutes. Want it?
