Your prep pack for all three rounds is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-6-denied-d7616f79/79ba83ae-4d21-4329-bc04-d39c51118131/scratchpad/Larkfield_engineering-manager_interview_pack.md`. Web search was refused this session, so the pack has nothing on Larkfield's values, loop or strategy. It is built from your message alone.

The shared section covers the fit gaps. The one you'll be asked about most is that you've never owned a hardware-adjacent roadmap. The pack has the plain acknowledgment, what you did do, and a plan for learning it, and it names that as the highest-ROI prep. Each round then has its own persona weights and question bank. The Director round leans on the live roadmap problem and the hardware gap. The panel mixes a staff-engineer depth probe with a product roadmap trade-off. The VP round is values-style, based on the recruiter's wording. Each round also has reverse questions. For every claim about your past, the pack quotes your own sentences. Where the material is silent, it leaves an answer slot instead of supplying the answer.

I'd also check the 60% figure before Tuesday. Be ready to say how it was counted, what you'd defend least, and which part was yours. That's the number a probing interviewer will test first.

Would you like a drill with the Director as the Skeptic on the hardware-roadmap question? Or should I save a `tuesday-dossier.md` to carry these gaps into later sessions? I can also convert the pack to Word if you'd like it that way.

Is the role on-site, hybrid or remote, and is that a fixed requirement you couldn't meet? The pack can't say, and if it's a hard requirement, it changes what I'd prepare you to say first.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager interview prep pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Two squads building device-management services; delivery, hiring and growth for 11 engineers; roadmap partnership with hardware and product.

**Mode:** Loop. Three scheduled rounds, each with its own mini-pack below. The fit snapshot and prohibited list are shared.

| Round | When | Format | Who |
|---|---|---|---|
| 1 | Tuesday, 45 min | Hiring manager | Director of Engineering (name not given) |
| 2 | The Thursday after, 60 min | Panel | Two staff engineers and a product manager (names not given) |
| 3 | The following Monday, 30 min | Values and leadership philosophy | VP Engineering (name not given) |

## How to use this pack

Personas describe how a question arrives. Types describe what it scores: **VAL** behavioral and values, **EXP** work-experience deep-dive, **JD** role requirement, **CO** company and strategy, **CASE** live problem. Guidance is scaffolding for a spoken answer, not a script. Quoted text is your own words from your message unless the row says otherwise. Answer slots are instructions for the interview: "if you did this, say how; if not, say so." They are not questions to you here.

No web search ran this session (see Sources). This pack uses your message and nothing about Larkfield's values, loop or strategy beyond what you wrote.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role, your message) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | medium | [grounded] | transferability | Your material shows one team of six. Say it at that scope: "3 as a team lead of 6." Expect a probe on team size. Answer slot: if you have ever led more than one team at once, say how, in your own words; if not, say so and name what carries across from one team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role, hiring clause) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap on hiring as such. Say the loop in the sentence's terms: backend roles, about 40 interviews last year. Expect a probe on which parts of the loop were yours to set (answer slot in the banks). |
| F3 | "own delivery, hiring and growth for 11 engineers" (role, delivery clause) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | This is delivery of one reliability quarter, not delivery across two squads. Say it at its own scope: "I pushed a reliability quarter through against roadmap pressure." The 60% figure is a defend-the-number slot. Expect a probe on it. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role, growth clause) | none given | discovery | [grounded] | discovery | Your message says nothing about growing engineers. Answer slot: if you can name an engineer you grew and what changed for them, say it in your own words; if not, say so and say how you would start with 11 people. |
| F5 | "partner with hardware and product on roadmap" (role, hardware clause) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Stated absence, so these are words you can say: "I've never owned a hardware-adjacent roadmap." Follow with how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F6 | "partner with hardware and product on roadmap" (role, product clause) | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material reaches roadmap decisions under pressure, not partnership with product or hardware on a roadmap. Say the quote at its scope. Answer slot: if you have worked with product or hardware on what went on a roadmap, say how, in your own words; if not, say so. |
| F7 | Managing managers (your note; the posting does not say it) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Stated absence. Words: "I've never managed managers." Then how you would learn it, said as a plan. Expect the Director and the VP to ask about it. |
| G1 | Location or on-site pattern ([generic] role-family pattern; not a line in your message) | none given | none | [generic] | hard_gate | Your material does not establish whether you can meet an on-site or hybrid pattern. Not bridged. See the one question at the end of this pack. |

## Prohibited claims (shared, built before the banks)

| Not coached | Basis | Honest form |
|---|---|---|
| "I have led more than one team at once" or "I've run two squads" | Inflated form of F1 | "3 as a team lead of 6," at its own scope. Observation, in analysis only: your material shows one team of six. |
| "I designed the hiring process" or "I set the interview bar" | Inflated form of F2 (the loop, widened to its design) | "I run our hiring loop for backend roles," at its scope. Which parts were yours is an answer slot. |
| "I cut on-call burden by 60%" | Inflated form of F3 (causation widened from "after") | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." Whether the drop was yours alone is an answer slot. |
| "I have owned a hardware-adjacent roadmap" or "I've partnered with hardware on a roadmap" | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| "I have managed managers" | Negative you stated (F7) | "I've never managed managers." Plain acknowledgment, no slot. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads (F1) | B3, K1, A1 |
| Delivery for 11 engineers (F3) | C1, C2, K1 |
| Hiring (F2) | E2 (round 2) |
| Growth for 11 engineers (F4) | I3 (round 3) |
| Hardware and product partnership on roadmap (F5, F6) | A1, A4, B1, G1, G2, K2 |
| Hardware-adjacent roadmap (F5) | B1, B2 |
| Managing managers (F7) | A3, B2, J1 |
| Location or on-site pattern (G1) | None, and why: it needs your answer, not a bank question |

---

## Round 1: Tuesday, hiring manager (Director of Engineering), 45 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problem on the device-management roadmap and the hardware dependency | High. A hiring manager is buying capability and wants to see live problems on the actual roadmap. Top weight: 4 questions. | Clarify, then structure, then answer. Name the first question you would ask before proposing anything. |
| Skeptic | "Why you, when you've never owned a hardware roadmap?" | High. The role's own hardware line plus your stated gap. Weight: 3 questions. | Plain acknowledgment first, then what you did do, then how you would learn the rest. |
| Data-Driven Prober | The 60% figure, taken apart | Medium. The figure is a magnet for probing, which is why it gets its own slots. Weight: 2 questions. | Say how the figure was counted only if you know, and say so plainly if you do not. |
| Conversational | The opener, and the walk-through of your path | Medium. Friendly openers are still scored. Weight: 2 questions. | Prepare a 90-second arc for the biography question. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Two squads ship device-management services, and a hardware team changes its device firmware contract next quarter. What do you do in the first two weeks? | CASE | [generic] | Clarify what changes for each squad, then which decisions are time-bound, then who you talk to first (hardware leads, product, the two squads), then the risks. Name what you would not decide yet. This is a live problem and asks nothing about your past. | Raising source: the posting's "partner with hardware and product on roadmap" (F5, F6). `[generic]` because it is a pattern for the problem, not a fact about Larkfield. |
| A2 | What does your first ninety days look like, and what do you leave alone? | JD | [generic] | Order the decisions: learn before changing anything; name the one thing you would change first and why. | Raising source: the role's "lead two squads" and "delivery" lines. No claim about your past. |
| A3 | Two squads will have their own leads. How do you manage the people who lead them? | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment first, in your words: "I haven't managed managers." Then the plan: how you would learn it, and how you would find out from the squad leads what they need. Hold through two follow-ups by naming the plan, not a past. | F7. The strongest honest answer is the acknowledgment plus a plan; any claim about past management is out of bounds. |
| A4 | How would you decide between a reliability item and a feature product wants, on a roadmap the hardware teams depend on? | CASE | [generic] | Name the decision criteria you would use, who decides, what you would check with hardware before committing, and what you would tell product if the answer is no. | Raising source: "partner with hardware and product on roadmap." This is the live version of F6. |
| B1 | You've never owned a hardware-adjacent roadmap. Why should we believe you'll be good at it? | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI prep in this pack.** This objection will come in some form. Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then what you did do: "I pushed a reliability quarter through against roadmap pressure." Then how you would learn it, in a plan. Hold through two follow-ups by returning to the plan. Concede one specific thing: name the part of the hardware side you do not yet know, and how you would find out in week one. Never claim expertise you have not stated. | F5, the biggest gap and the role's own line. Deepest rehearsal: three follow-up levels. |
| B2 | Which part of this job would you be weakest at on day one? | Skeptic stem | [grounded] "I've never owned a hardware-adjacent roadmap." and [grounded] "I've never managed managers" | Name the two stated gaps in your own words, the hardware roadmap and managing managers, then one plan for each. Do not add a third. | F5 and F7 cross-examined. The honest answer is the two named gaps. |
| B3 | Two squads for one manager, and you've led six. Why is that not a stretch? | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Accept that it is a step: "I haven't run two squads." Then say what you would check first and what would tell you it's working. Do not argue it is no stretch. | F1, transferability. The honest move is to accept the step and show the plan. |
| C1 | Walk me through how the on-call burden number was counted. | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped: the reliability quarter, the roadmap pressure, pushed through, and the 60% after. Those are the beats the sentence states; tell them in your words. Answer slots: how the figure was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly. | F3. Every headline metric gets a defend-the-number question, with the four slots. |
| C2 | What else changed that quarter that could move on-call burden? | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if something else changed, name it and say what you did about it; if you know of nothing else that changed, say so. Do not split the result into shares you cannot back. | F3, attribution. The question presupposes only that other things might have changed. |
| D1 | So, walk me through the last few years. | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | 90-second arc: nine years in engineering, three as a team lead of six, now at a payments company, and what you want from a role with two squads. Stick to those beats; add nothing. | Conversational opener, scored. F1 carries the arc. |
| D2 | What have you read or built that touches device management? | JD | [generic] | Answer slot: if you have touched device management, say what, in your own words; if not, say so, name what you have read, and say what you would start with. | Raising source: the posting's "device-management services" line. Your material does not show device-management work; that is the pack's observation, not words for you. |

### Reverse questions (round 1)

| # | Question | Why it lands |
|---|---|---|
| R1-1 | What would make you say, twelve months from now, that this hire worked? | Turns the interview into a success conversation. |
| R1-2 | How is the scope split between the two squads today, and which one carries more of the hardware dependency? | Shows you read the posting. |
| R1-3 | Where does hardware's input reach the roadmap: at planning, or mid-quarter? | Tests how partnership actually works, which is the gap you need to close. |
| R1-4 | What did the last person in this role get right, and what would you change? | Gets an honest history from the person who knows it. |
| R1-5 | What hiring decision would you want the new manager to make in the first month? | Connects to your hiring experience (F2) without claiming it. |

---

## Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

### Persona table

Panel prior: blend the top two personas of each member's relationship. No names were given, so weights are per seat, not per person.

| Seat | Persona blend | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Staff engineer (first) | Data-Driven Prober, then Pressure | Technical depth checks on your decisions; follow-ups two levels deep | Peer prior: Prober and Peer Evaluator. Depth probes are most likely from staff engineers. Weight: 3 questions. | Say what you would delegate to them and how you would verify it, without claiming to write the code. |
| Staff engineer (second) | Peer Evaluator, then Data-Driven Prober | Seams between device services and hardware; disagreement with equals | Peer prior. Weight: 3 questions. | Reciprocity first: what you bring their team, not only what you need. |
| Product manager | Case/Strategist, then Peer Evaluator | Roadmap trade-offs and product partnership | Cross-functional prior is Values and Conversational. The posting's roadmap line pushes Case up for this seat. Weight: 2 questions for Case, 2 for Conversational. | Structure the trade-off, name the criteria, and say what you would ask product first. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | How do you tell a sound technical decision from a fashionable one when you are not writing the code day to day? | JD | [generic] | Name your checks: the decision record, the review, and what would reverse the decision. Answer slot: if you have evaluated a technical decision you did not make, say how; if not, say so. | Staff-engineer depth probe on a role line about delivery. No claim about your past is presupposed. |
| E2 | You run the backend hiring loop. Walk me through what you decide in it, and what you don't. | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F2: backend roles, about 40 interviews last year. Answer slot: say what you decide in the loop and what the other owners decide; if none of the decisions is yours, say so. | F2. The question's premise is the quoted "run". |
| E3 | Which assumption behind that 60% would you defend least? | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption in your own words, if you know one. If you do not know how the figure was counted, say that plainly, then the beats the sentence states. | F3, the weakest-assumption move. |
| F1 | Where is the seam between your services and the hardware teams, and what happens when you disagree? | JD | [generic] | Name the seam as a principle, not a fact you cannot verify. Say how you would handle a disagreement: decide the disagreement's owner first, then resolve it. | Raising source: the posting's "partner with hardware" line. |
| F2 | Tell me about a time you disagreed with a peer team. | Persona stem | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Selection scaffold ending in the honest branch: pick a disagreement with a peer team, with a named stake and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, the roadmap pressure, and how you pushed it through. Do not add a peer team that your material does not name. | F6. The open prompt's theme comes from the persona stem. |
| F3 | What would you need from my team before you let a service change ship? | JD | [generic] | Name two or three decision points where you would want their input, and what you would bring their team back. | Peer reciprocity. No claim about your past. |
| G1 | A device fleet's update rollout is failing on one hardware variant, and product wants the feature date. What do you do? | CASE | [generic] | Clarify which variants and which customers are affected, state the objective (fleet health before the date), segment, propose an approach, name the metrics, then the risks. Say the stake before the date. | Live problem from the posting's roadmap line; no claim about your past. |
| G2 | The roadmap has three asks: a reliability item, a hardware-dependent feature and a new customer request. How do you prioritize? | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Say the criteria. The reliability quarter is the one time your material shows you making this kind of call; say it in its own words, then the criteria you would use now. | F6. |
| H1 | What's the one roadmap question you'd ask us that nobody else has? | Conversational | [generic] | Pick one real question and ask it. Do not ask about something the posting already answers. | Casual register, still scored: a sign of how you think about product. |
| H2 | So, how did you end up on a payments team? | Conversational | [grounded] "currently at a payments company." | Give a 60-second answer in your own words, using only what you have stated. Do not add a story about why the payments move was a choice you made unless you did. | Casual opener, still scored. |

### Reverse questions (round 2)

| # | Question | Why it lands |
|---|---|---|
| R2-1 | What could a new person do in their first month that would genuinely help your team? | Reciprocity question for a peer panel. Peer evaluators weight it heavily. |
| R2-2 | Where do the staff engineers and product disagree most about the device-management roadmap? | Shows you listened and that you want the real seam. |
| R2-3 | How does a hardware change get into a device-management release today? | Tests the partnership model from the people who live in it. |
| R2-4 | What does a good technical design review look like here, and who attends? | Shows you care about the decision path, not only the outcome. |
| R2-5 | What is one thing the last manager here did that you would keep? | Gets an honest history from peers. |

---

## Round 3: Monday, VP Engineering (values and leadership philosophy), 30 min

The recruiter's own words, "values and leadership philosophy," make this a values-style round. No published values were in hand, so there is no values cheat sheet; the VAL rows raise their themes from the recruiter's words and the role's growth line.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership and growth | High. The round is named as values and leadership. Top weight: 4 questions. | Scaffold from a decision in your material; name the principle after the decision. |
| Pressure | Interruptions and time-boxed answers, testing composure | Medium. Skip-level prior is Case plus Pressure; the time box is 30 minutes. Weight: 2 questions. | Pause, restate, hold the position you can back through two follow-ups, then concede the specific thing. |
| Case/Strategist | Altitude questions about how the company decides | Medium. The skip-level prior is strategy-heavy. Weight: 2 questions. | Clarify, then name the criteria at the VP's altitude. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | What's your leadership philosophy, and where did it come from? | VAL | [generic] | Name two principles, and for each, one decision from your own material. Drop any principle that has no decision behind it. Do not name the principle before the decision. | Raising source: the recruiter's "leadership philosophy." |
| I2 | Tell me about a time you delivered an unpopular truth to leadership. | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Selection scaffold ending in the honest branch: pick a time you told leadership something they did not want to hear, with a named stake and what you said. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, the roadmap pressure, and how you pushed it through. Do not add a dissent you did not voice. | Persona stem, and the closest of your stated sentences. The honest answer may be the nearest, not the ideal. |
| I3 | How do you tell a manager is growing engineers rather than keeping them? | VAL | [generic] | Name what you would look for in a manager's growth of an engineer, and how you would check it. Answer slot: if you have grown an engineer you can name, say what changed for them; if not, say so and say how you would start. | Raising source: the posting's "growth for 11 engineers" line. F4 is discovery, so this stays an answer slot. |
| I4 | How do you decide when reliability work and roadmap commitments conflict? | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3: the reliability quarter, roadmap pressure, pushed through. Say the decision in those beats. Then name the principle, if you can back it from that decision. The 60% stays a slot: how it was counted, if you know. | F3. The question is a values question; the answer is the decision, then the principle. |
| J1 | Sixty seconds: why should we hire someone who has never managed managers? | Pressure | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold the position you can back: "I haven't managed managers." Then what you have: "3 as a team lead of 6." Hold through two follow-ups. Concede one specific thing: you do not yet know how the manager layer will feel from above, and you would find out with the people who would be leading each squad. | F7. The premise is the quoted negative. |
| J2 | That reliability result: how much of it was actually you? | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what was yours: that you pushed the quarter through. Concede the part you cannot separate from the rest, specifically. Do not defend the whole 60% as yours. | F3, attribution. The hold is the part your quote carries. |
| K1 | Two squads are behind on a device-management delivery. Diagnose it for me. | CASE | [generic] | Clarify, then the objective, segmentation (which squad, which service, which customer), approach, metrics, risks. Name the first question you would ask the squads. | Live problem for the role's delivery line. No claim about your past. |
| K2 | Hardware can't ship on your timeline, and product wants a date. What do you say? | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Clarify the constraint first. Say what you would commit to and what you would not, and what you would tell product and the VP. Hold the difference between a date you can keep and one you cannot. | F6. The quote supplies the pressure, nothing more. |

### Reverse questions (round 3)

| # | Question | Why it lands |
|---|---|---|
| R3-1 | How do you want managers to decide when reliability and the roadmap pull in different directions? | Asks for the principle the VP holds, so your answer can meet it. |
| R3-2 | What has this company said no to recently, and who said it? | Shows you care about values in action, not on the wall. |
| R3-3 | Which values would you expect a new manager to show in the first ninety days? | Ties the values question to the job. |
| R3-4 | What is one decision you would reverse about how engineering works here? | Candor from the VP's side. |
| R3-5 | What would you want a new manager to stop doing in their first quarter? | Practical, and shows you expect to learn. |

---

## Sources

**Provided documents:** your message. It supplies the role summary, the three rounds, your background, and every quoted sentence in the fit snapshot. Not supplied: a full posting, a CV, interviewer names, Larkfield's published values, and any loop or strategy document.

**Calls sent (both refused: search permission was not granted this session):**
1. "Larkfield Systems company values": refused.
2. "Larkfield Systems industrial IoT device management engineering": refused. Not a declared target; counted here.

**Research tier:** L1, searches 2 of 6, fetches 0 of 2. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search refused. Would have fixed the value names for round 3 and allowed a values cheat sheet. None included. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | No search was run for this target; search was not permitted. Would have checked whether the three rounds match Larkfield's documented loop. The rounds above rest on your message. |
| 3. Larkfield strategy or recent news | unavailable | No search was run for this target. Would have fed CO questions. None are included, so no question is grounded in strategy. |
| 4. Interviewer name | n/a | No interviewer names were given, so there was no query to form. |
| 5. Representative JD | skipped | Your role summary fixes the requirement rows in the fit snapshot. |

**Not declared target, refused:** "Larkfield Systems industrial IoT device management engineering" (unavailable). Would have checked the product area behind F5 and F6.

**Not in this pack, and why:** no values cheat sheet (no published values in hand); no grounding brief (no strategy research ran); no reading of the interviewer (no names); no graded deliverable (none declared); no delivery coaching (no assessment provided).

## Upgrade menu

- **Larkfield's published values page, pasted** → a values cheat sheet for round 3, with I1, I2 and I4 mapped to the named values, not the recruiter's words.
- **The full posting text** → F1 to F6 quote the posting's own lines instead of your summary; the JD-tagged rows move from your summary to `[grounded]` on the posting's wording.
- **Interviewer names for the three seats** → a persona for each interviewer, and reverse questions tied to their career paths.
- **Recruiter's email on the panel format and any take-home** → confirms the Thursday panel's shape and whether anything is graded in advance.
- **Search permission turned on** → runs targets 1 to 3 (values, loop structure, strategy). The rows marked unavailable would move to yes.
- **How the 60% was counted, and which part was yours** → new quoted material. It moves F3 and the answers to C1, C2, E3 and I4 from slots to rehearsed answers. Say it outside a drill for it to count.
- **Your answer to the location question below** → resolves G1, whichever way it goes.
