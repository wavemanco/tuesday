I'm running the mock-interview module now. I'll read its playbook first, then the files it names at each step.
Step 1 says to read the files that name each step before I write. I'll load them, and the search tool, in one batch.
I've read the playbook and the files it names for the steps so far. Next I'll run the L1 research targets (values, loop structure, the named interviewer) and read the dossier handoff, which the offer step requires.
The searches were refused on permission, so the research targets came back unavailable. I'll build the pack from your notes and say so in the Sources section. Writing the pack file now.
I put the offers and the question inside the saved file, but the playbook keeps those out of it. Removing them now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-1-denied-82143446/northwind_senior-gtm-strategy-lead_interview_pack.md`. I built it for a peer round, since you said this is one conversation with Dan, who reports to the same VP as Priya.

It has 19 questions across five personas, weighted toward the Data-Driven Prober (5), then Peer Evaluator (4), with a pricing tilt on the Case questions. Every question has a type tag and a rationale, and the candidate quotes come from your notes.

Three things to check before anyone rehearses from it:

- **Your notes are the only evidence.** I had no CV text or full JD, so every candidate quote is from your notes. Priya's own CV wording would make the guidance stronger.
- **Research didn't run.** The three searches (Northwind values, interview process, Dan's public footprint) were refused, so the values and loop facts are missing. The strategy priorities come from your research note, which is undated and unverified.
- **"No quota-setting experience" is unconfirmed.** It's in your notes, not something Priya has said. The pack gives her no plain acknowledgment on it until she confirms.

The highest-ROI prep is D2, "Which part of this JD would you be weakest at on day one?". Partner-motion design is the requirement the material doesn't show, so that answer needs the most rehearsal. The pack also flags the $400M uplift (A1 to A3, E2) as the likeliest probe.

I can play Dan on D2 as a live drill, save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

Does the posting state any hard terms, such as office location or days in office, work authorization, travel or a start date? Your highlights don't mention any. If it does, I'll restructure the fit snapshot around them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Round:** One 60-minute conversation, peer round, with Dan Kovac (Director of Sales Strategy). Dan and Priya would report to the same VP.
**Version:** First version. No earlier pack to change.

**Built on:** your message (JD highlights, company description, Dan's profile, your research note) and the coach's notes on Priya's background. No full JD text and no CV text were supplied, so every candidate quote below comes from the coach's notes. Check each quote against Priya's own CV before she rehearses from it.

**Research:** not run. The three searches were refused, so no value, loop or footprint fact comes from outside your notes.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** experience deep-dive, **JD** requirement-driven, **CO** company and strategy knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse only what Priya actually did, in her own words.
- Question IDs are letter-by-persona (A1, B2 and so on) so you can cite them in drills.

---

## 2. Fit snapshot

Requirements come from your message. Evidence is quoted verbatim from the coach's notes. Source labels follow each quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Your notes say product strategy and operations, not go-to-market. Words: "I spent nine years in product strategy and operations at a large consumer-tech company." Answer slot: if Priya set go-to-market for any launch, she says which parts and how she decided. If none was hers, she says so and stays with the strategy and operations work. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | low | [grounded] | discovery | Your notes show no lifecycle work. The revenue model touches revenue but does not show whitespace. Answer slot: if she has sized growth at any stage of land, adopt, expand or renew, she says which stage and how. If not, she says so and says how she would look for it first. |
| F3 | "run independent analysis in SQL and Tableau" (your message) | "skilled in SQL/Tableau" (the coach's notes) | medium | [grounded] | none | The quote reaches the requirement. Caveat: no inspected analysis is in the notes, so expect a probe. Lead with one analysis she ran herself (A5). |
| F4 | "partner-motion design experience required" (your message) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | low | [grounded] | discovery | Your notes show partner economics, not how partners were designed to sell. Answer slot: if she designed how partners got deals, she says how. If she worked only on the economics, she says so and says what she would design first. |
| F5 | "strong cross-functional influence" (your message) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." Add no practice. Caveat: the consensus was across orgs, so expect a probe on how it was reached. |
| F6 | "AI experience a plus" (your message) | "uses AI tools daily" (the coach's notes) | low | [grounded] | transferability | Daily use is not product work. Words: "I use AI tools daily." Answer slot: she names what she uses them for. She makes no claim of AI product or launch work. |
| F7 | Headline metric on the CV, no JD line (the coach's notes) | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No requirement gap. The defend-the-number slots apply (A1 to A3, E2). Words: "I proposed a store-surface change." The uplift is credited to it. How it was counted is an answer slot. |
| F8 | Role-family probe on quota-setting and sales operations, not a JD line [generic] | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | capability | Stated absence in the coach's notes, not yet confirmed by Priya. The pack gives no plain acknowledgment until she confirms it (upgrade menu). D3 covers the adjacent ground. |
| F9 | "B2B data-infrastructure SaaS" (company description, your message) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Consumer product work carries over. B2B buyers and enterprise motions are not in her notes. Answer slot: she names one piece of product strategy or operations work that maps to a B2B buyer. If none does, she says so and says how she would learn it. |

**Gate rows:** your material states no hard gate (location, work authorization, travel or start date). Step 1 asks about this (see the question at the end of the message). Until it is answered, the pack treats no row as a gate.

---

## 3. Prohibited claims

These claims are not coached in any answer, hold, bridge or reverse question. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for new product lines | Inflated form of F1 ("product strategy & ops") | The quote at its own scope: "9 at a large consumer-tech company in product strategy & ops." Pack observation, not words for Priya: your notes say product strategy and operations, not go-to-market. |
| Set quotas or sales capacity | Inflated form of F5 and F8 ("set annual volume targets") | The quote at its own scope: "set annual volume targets with cross-org consensus." Pack observation: volume targets, not quotas. |
| Designed partner motions | Inflated form of F4 ("built a partner-level revenue model") | The quote at its own scope. Pack observation: the notes show a revenue model, not motion design. |
| Drove the ~$400M ARR uplift | Inflated form of F7 ("proposed ... credited with") | The quote at its own scope. The credit was assigned to the change. Who else shaped the figure is the question, not a claim. |
| Shipped or led AI products or launches | Inflated form of F6 ("uses AI tools daily") | The quote at its own scope: "uses AI tools daily." |
| No classic sales-ops or quota-setting experience | Coach's note, a stated absence not yet confirmed by Priya | No first-person negative until Priya confirms it. Then she gives the acknowledgment in her own words. |

---

## 4. Grounding brief (from your research note, not verified)

Your note states three priorities: "enterprise expansion", "an AI copilot launch ('Compass')", and "reaching profitability". It names the main competitive threat as "bundling by a much larger platform vendor". The note is undated and nothing was checked, because search was refused.

Use this as vocabulary, not as fact to repeat in the room. Confirm each priority with Dan or the recruiter before Priya cites it.

---

## 5. Reading the interviewer

**Public footprint only, from your profile.** Career pattern: pricing and monetization, plus one early-stage startup chapter. Self-described: "relentlessly data-driven". No talks or writing were found, because search was refused.

Practical implications:
- Every number Priya gives will be probed back to its assumptions. Expect the Prober and the Peer Evaluator to overlap.
- Case questions lean toward pricing, packaging and unit economics, which is Dan's native language.
- The startup chapter means builder stories land well. Expect scrappiness probes about big-company pace.
- **Mirror opportunity:** a shared professional domain, revenue modeling and monetization. Priya's "built a partner-level revenue model used in carrier negotiations" (F4) sits in the same territory as Dan's career. This is a professional overlap, not shared identity, so it is fair to use.

---

## 6. Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks for the denominator, the method and the weakest assumption; follows two levels deeper | **5.** Dan's self-described "relentlessly data-driven" raises this persona. The $400M figure (F7) is the magnet. | Know what you can and cannot say about how each number was counted. Say plainly when you do not know. Name the weakest assumption you know before he does. |
| Peer Evaluator | Seam-splitting between teams, credit-sharing, "what would you need from me" | **4.** The relationship is a peer round, the top prior. | Frame reciprocity: what Priya brings to Dan's team, not only what she needs. Propose seam principles rather than pretending to know the seam. |
| Case / Strategist | Live GTM and sizing problems on Northwind's own priorities | **3.** Dan's pricing career tilts case questions toward pricing and packaging. | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud. Make no claim about past work in a case. |
| Skeptic | Background mismatch: consumer-tech to B2B, and GTM ownership | **3.** Gap rows F1, F2, F4, F8 and F9 are where a skeptic looks. | Rehearse the single most predictable objection until it is calm (B2 and D2). Bridges come only from quoted adjacent work, with the limit stated. |
| Pressure / Stress | Time-boxed challenge, "how much was actually you" | **2.** Not the default for a peer round, but Dan may test composure once. | Pause, restate the question, anchor in what is quoted. Hold a position through two follow-ups before any concession. |
| Conversational / Rapport | Casual opener, "walk me through the journey", the AI question asked casually | **2.** Peer rounds often open this way, and the casual questions are still scored. | Keep a 90-second arc built only from quoted sentences. Treat the casual AI question as scored. |
| Values / Behavioral | Not weighted | **0.** No loop source documents a values round, and your message describes one conversation. No archetype fallback applies, because your own words establish the loop. | None. Recheck if the recruiter names a values round. |

---

## 7. Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Say what the notes say and no more: she proposed the change, and the figure is credited to it. Answer slot: if she knows how the uplift was counted, she says how, in her own words. If she does not, she says so plainly and says what she can account for. | F7 is the headline metric. Probers test it first. EXP because it tests what was actually hers. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Weakest-assumption move: name, in her own words, the assumption she would defend least before Dan does. Answer slot: if she knows the assumptions behind the figure, she names the weakest. If not, she says so and names what she would check first. | The weakest-assumption move turns a gotcha into a credibility gain. Metric questions carry it by rule. |
| A3 | "Your figure is credited to a change you proposed. Who else's work is in that number?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Attribution. She says her part is the proposal. Answer slot: if others' work is in the figure, she names it and what she did alongside it. If no one else's work is in it, she says so. She does not claim the uplift as hers. | F7 credit probe. The Prober's attribution follow-up is likely once the figure is quoted. |
| A4 | "Walk me through how you built the partner-level revenue model." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Story-mapped on F4: she tells the build (the model) and the use (carrier negotiations), in those words and that order. Answer slot: if she can name the inputs and how she checked the model, she says so. If someone else supplied the inputs, she says whose. | The most direct analytic story in the notes. Dan, with a pricing career, will test its inputs. |
| A5 | "Show me the last analysis you ran end to end in SQL and Tableau." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes); raising source: "run independent analysis in SQL and Tableau" (your message) | Open prompt on the JD's analysis line. She names one analysis she did herself, from question to chart. Answer slot: if she cannot name one that used both tools, she says so and names the nearest analysis she did. She claims no depth beyond what she can walk through. | F3: the skill is stated but not shown, so the probe is likely. JD because it scores a stated requirement. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between yours and mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes); raising source: "strong cross-functional influence" (your message) | Propose seam principles rather than pretending to know the seam. Answer slot: if she has disagreed with an equal, she says what it was and how it ended. If the notes show none, she says so and gives the principle she would use. | F5 is the requirement; the peer seam is the probe. Disagreement with equals is scored in this persona. |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Credit is what others assigned. Priya names how the credit was assigned, in the notes' words, without claiming it as her own. Answer slot: she names who else's work sat behind the change, if anyone's did. | Credit-sharing is a peer-round probe. The "credited" wording is already in the notes. |
| B3 | "What would you need from my team to set go-to-market for a new line?" | JD | [generic] | Name the inputs she would need, such as the roadmap and pricing and packaging inputs. She does not claim to have run these. | Reciprocity framing for a peer. Generic because it is a role-family pattern, not a fact about her. |
| B4 | "Where would you rely on a partner-motion team you don't own?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes); raising source: "partner-motion design experience required" (your message) | Speak to what the model did: partner economics in carrier negotiations, in her words. Answer slot: if she designed how partners got deals, she says how. If she worked only on the economics, she says so and says what she would design first with a partner team. | F4 discovery. The JD requirement is not in the notes, so this is an answer slot. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the go-to-market plan for a new data product line. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics and risks. Lean on pricing and packaging early. Think aloud. She makes no claim about her past. | The JD's GTM-ownership line (F1). Dan's pricing career tilts it. Scores structure, not history. |
| C2 | "Across land, adopt, expand and renew, where would you look for whitespace for a new line, and how would you size it?" | CASE | [grounded] "enterprise expansion" (your research note); raising source: "identify whitespace across land/adopt/expand/renew" (your message) | Structure first: lifecycle stage, then segment, then sizing method and the data needed. Use the note's priority, enterprise expansion, in her framing. She cites no sizing she has done. | Covers all four lifecycle stages in the JD line. F2 is a discovery gap, so no whitespace work is claimed. |
| C3 | "Compass, the AI copilot, is launching. Which pricing or packaging question would you ask first?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Clarify the launch's target and what is being packaged. Her first question is who pays, and what changes for existing customers. She claims no AI launch experience. | Tests altitude on a current strategy term. Pricing tilt. Covers the AI plus through a question, not a claim (F6). |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is consumer-tech. What carries over to this role?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Transferability, with its limit. The product strategy and operations work carries over, not enterprise selling. Answer slot: she names one piece of that work that maps to this role. If none does, she says so and names how she would learn it. | F1 and F9. The most likely background-mismatch probe. The question asks only about what was quoted. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes); raising source: "partner-motion design experience required" (your message) | **The highest-ROI rehearsal in this pack.** Hold-then-concede: partner-motion design is the requirement the notes do not show. Answer slot: if she has designed partner motions, she says so. If not, she says that is the part she would ramp first, and gives a ramp plan. Hold through two follow-ups. Concede exactly the gap, not the revenue model. | F4 is the biggest gap and the likeliest objection. Deepest rehearsal by design. |
| D3 | "How would you set annual volume targets for a new line, and what would you need to make them hold?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Premised on the quote, which says she set volume targets. She names the inputs and the cross-org step. Answer slot: if she set the targets, she says how consensus was reached, in her words. If the consensus step was not hers, she says so. She does not call it quota-setting. | F5 and F8. Tests the adjacent ground without claiming quotas. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm" (the coach's notes); [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Pause, restate, anchor in the two quoted sentences. Hold through two follow-ups. Concede specifically: GTM ownership and partner-motion design are not shown in her notes. Answer slot: if she owned any GTM work, she says so. If not, she concedes that part and holds the strategy and operations record. | Composure test. The held position is only what is quoted. |
| E2 | "That result, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold-then-concede: "I proposed the change; the figure is credited to it." Hold through two follow-ups. Concede exactly what she does not know: how the uplift was counted. She never folds on "proposed". | Premised on F7. A stronger claim than "proposed" is the one the second follow-up breaks. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (the coach's notes); [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes); [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | A 90-second arc: consulting, then nine years of product strategy and operations, then the revenue model. Use only these sentences. End by linking to the role. | Casual, but scored. Pre-scripted arc. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes); raising source: "AI experience a plus" (your message) | Name the tools and what she uses them for, in her own words. She does not describe AI product work. | Casual form of the AI plus line. Scored. |

---

## 8. Requirement coverage

| Requirement (your message) | Covered by |
|---|---|
| own GTM strategy for two new product lines | C1, B3, D2 (gap F1) |
| identify whitespace across land/adopt/expand/renew | C2 (all four stages); gap F2 |
| run independent analysis in SQL and Tableau | A5 (F3) |
| partner-motion design experience required | B4, D2 (gap F4) |
| strong cross-functional influence | B1, B2 (F5) |
| AI experience a plus | G2, C3 (F6) |
| Not in the JD highlights: quota-setting probe (F8) | D3, plus the prohibited entry |

---

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You went from pricing into an early-stage startup. What did that change about how you thought about price?" | Tied to Dan's own path. Turns a probe into a peer conversation and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Shows you are thinking about his load, not only your needs. |
| R3 | "Where does sales strategy hand off to the GTM team for a new line today?" | Probes the seam on the role's own terms. Shows you know where the work splits. |
| R4 | "How is Compass expected to change packaging for existing customers?" | Uses the note's launch term. Tests strategy altitude, and he can answer it. |
| R5 | "How are you thinking about the bundling threat from the larger platform for the new lines?" | Uses the note's main threat. Shows you know the competitive frame. |
| R6 | "Which of the three priorities gets the most of your team's time this year?" | Sets altitude on the three stated priorities without repeating them back. |

---

## 10. Sources

**Provided documents:** your message (JD highlights, company description, Dan's profile, research note); the coach's notes on Priya's background (quoted in your message, not CV text).

**Searches sent, all refused:**
1. "Northwind Data company values": refused
2. "Northwind Data interview process sales strategy director loop": refused
3. "Dan Kovac Northwind Data Director of Sales Strategy": refused

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Calls refused. The values cheat sheet is dropped, because no values are in hand. |
| 2. Interview process | unavailable | Calls refused. The loop is set by your words: one 60-minute conversation with Dan. No archetype fallback applies. |
| 3. Strategy / recent news | skipped | Your research note supplies the priorities. It is undated and unverified. |
| 4. Dan Kovac footprint | unavailable | Calls refused. The interviewer read uses your profile only. Talks and writing would have supplied recurring themes. |
| 5. Representative JD | skipped | Your highlights fix the fit snapshot and the JD-tagged questions. |

Sections dropped, by rule: values cheat sheet (no values in hand), graded deliverables (none declared), delivery coaching (no assessment), prep triage (prep time not given).

---

## Upgrade menu

- **Priya's CV text, verbatim** → the F rows move from the coach's-note quotes to her own sentences, and the [grounded] guidance then rests on her wording.
- **Full JD text** → replaces the highlights, unlocks quoted lines for mid-list requirements (named methods, tools), and tests the coverage table.
- **Priya's confirmation on quota-setting** → lets the pack give her plain words for F8 and the prohibited entry, in her own voice.
- **Dan's talks, posts or writing** → recurring themes become questions and reverse-question material.
- **Recruiter's prep email** → confirms the round format and any named focus areas, and would check the loop.
- **Search permission for a re-run** → the three refused targets (values, process, Dan's footprint) rerun at L1. A deeper strategy pass (L2) is offered once: up to 6 more searches and 2 more fetches, several more minutes. Say if you want it.
- **A tuesday-dossier.md carrying Priya's verified evidence** → upgrades the grounded rows and lets the pack set the limits from confirmed claims.
- **The hard gates** (location, days in office, work authorization, travel, start date) → the gate rows are added to the fit snapshot and the pack is restructured around them.

