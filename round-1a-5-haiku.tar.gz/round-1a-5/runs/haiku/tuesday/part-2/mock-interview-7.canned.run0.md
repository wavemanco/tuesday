Your prep pack is saved at /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-7-canned-a5814478/saltmarsh_live-operations-producer_interview_pack.md.

Two things from the research that shape the prep:

- **The round is one 60-minute "Outage Hour" with the hiring manager.** The company's interviewing page describes a live-incident tabletop, then a values conversation. The values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. The pack maps your material to each.
- **Project Larkspur.** A company news item (seen in search results, not opened) says two titles move to a season-pass model and one shared events calendar from February 2027, with per-title event teams folded into one live-ops group. Expect the interview to touch on that. Your "never worked on a game with in-app purchases" is a real gap against it.

The highest-ROI prep is B1, "You have never led a team. What makes you ready to coordinate design, art, engineering and community on every update?" Your material has no quoted coordination beyond QA. The honest answer is to say "I haven't led a team," name whatever cross-team work you did, and give a plan for the first week. Don't stretch the checklist into leadership.

Would you like me to play the Skeptic on B1 in a drill? I can also save a tuesday-dossier.md with the gaps this prep exposed, or convert the pack to Word.

Is Friday's 60 minutes the Outage Hour with Tobias alone, or is there a second session? That changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer at Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: a single 60-minute hiring-manager session, the Outage Hour (live-incident tabletop, then a values conversation), per the company's interviewing page.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience, probed), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Speak it in your own words.
- Answer slots (lines that begin with "Answer slot:") are instructions for the interview. They are not questions to me.

## Fit snapshot

Requirements are quoted from the job description you pasted, unless the source says otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Keep the words as you said them. Confirmed claim with limited inspectable proof, so expect a probe on how much of the calendar you set. |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title. Two titles is adjacent work, not shown. Say it at its own scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever planned across a second title or a shared calendar, say which and how; if you did not, say so plainly and say how you would set up two. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Derivation: the only team named in your material is QA. The other four are not in it. Answer slot: name any other team you coordinated a content drop with and what you did with them; if none, say so plainly and say how you would open that work with design, art, engineering and community in week one. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran a review after a content drop, say what it measured and what changed; if you did not, say so and say how you would structure one. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | discovery | Presenting the numbers does not show how they were counted. Answer slot: if you chose or checked how retention was defined, say how; if you did not, say so plainly and name the figure you would check first. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Your quote reaches the requirement in other terms. Reword only that: "I wrote the release checklist, and our QA team still uses it." Do not add a release you ran or a sign-off you held. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Length is met on its own terms, not a gate. Whether the puzzle title was live-service is not in your material. Answer slot: if it ran content after launch, say how; if its work was not live-service, say so and point to the calendar in F1. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | none | Your checklist is written work used by a team. No writing sample is in your material, so the claim stays at low confidence. The upgrade menu names the artifact that would raise it. |
| F9 | Season-pass monetisation for two titles, from the company's September 2026 news item (web research, search result, not fetched) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. The link between that model and season-pass is this pack's inference, not a fact about your history. |

Limits the pack observes, in its own analysis: your material shows one title, one checklist and one retention presentation. It does not show a review, a second team, or a team you led.

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" | "I haven't led a team." No slot. |
| Has worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." No slot. |
| Owned the two-title live calendar | Inflated form of F2: your quote is one title | "I ran the weekly content-drop calendar for our main title." A2 and E2 stay inside that scope. |
| Owned retention reporting or KPIs | Inflated form of F5: your quote is that you presented the numbers | "I presented the monthly retention numbers to the studio head." |
| Managed the release process with QA | Inflated form of F6: your quote is that you wrote the checklist | "I wrote the release checklist, and our QA team still uses it." |

## Reading the interviewer

Public footprint only. A search result (not fetched) lists a GDC 2026 talk, "Patch Notes Are a Promise", by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. Its argument, as the listing states it: a live team is judged by how often its patch notes describe what actually shipped.

- **Career pattern:** QA lead to Head of Live Operations.
- **Practical implications:** expect questions on release accuracy and QA discipline. F6 is the place to be precise, not expansive. Expect the Outage Hour's tabletop to carry his live-incident habits.
- **Mirror opportunity:** release discipline, using F6's quote. No shared jump is offered, because your path is not a QA-to-live-ops move, and the pack does not treat the checklist as one.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: a failing reward claim, two titles competing for the same weekend, a retention drop | High (5 questions). The loop source names a live-incident tabletop, and a hiring manager buys capability against the roadmap. | Clarify, then structure, then state metrics and risks. Say the framework aloud once. |
| Skeptic | Probes on the gaps: no team led, no in-app purchase experience, one title not two | High (5 questions). The gaps in F2, F3, F4 and F9 are where a hiring manager will press. | Rehearse B1 until it is plain. Acknowledge the negative in one sentence, then bridge only from quoted evidence. |
| Data-Driven Prober | How retention was counted, what a figure assumed | Medium (3 questions). The JD names retention metrics, and F5 is the only quoted metric. | Say plainly what you can and cannot say about a count. Name the assumption you know of before it is named for you. |
| Values / Behavioral | The Outage Hour's values conversation, mapped to published values | High for this round (3 questions). The loop source names a values conversation, so a values-style round is detected. | Map a quoted story to each value where one exists, and use the honest branch where none does. |
| Pressure / Stress | Time-boxed challenges to fit and to how much was yours | Medium (2 questions). A hiring manager may test composure on the single-title record. | Pause, restate, hold the quoted position through two follow-ups, then concede the specific gap. |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 7:40pm on launch night for a content drop, and the reward claim is failing for some players. Walk me through the first ten minutes." | CASE | [generic] | Clarify scope: which players, which platforms, how many. Decide whether to pause the event. Name who you call (engineering on-call, QA, community). Decide what players hear and when. Note it for the post-event review. Makes no claim about your past. | The loop source names a live-incident tabletop, so this is the format. Generic because it is a pattern for the problem. |
| A2 | "Two titles want the same weekend for their events. How would you decide the calendar?" | CASE | [generic] | Clarify each event's goal and the cost to players of a collision. Then a tie-break rule, a sign-off owner and a fallback date. Use "players before plans" only as the published value it is. | F2 is the requirement this tests, and the premise is the JD's two-title calendar, not a fact about your past. |
| A3 | "Lay out how you would run a content drop from design sign-off to launch, with design, art, engineering and community." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Give the sequence with named gates. Anchor on your calendar: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: which of those gates were yours to set; if none were, say so and describe the sequence you would set. | F3 is thin, so the other-team gates are an answer slot, not a supplied story. |
| A4 | "Retention dropped 8% in week two after a content drop. Diagnose it." | CASE | [generic] | Clarify the cohort definition and what changed. Split by segment and platform. Check release timing against the event. Name the baseline assumption you would test first. Then decide what to keep. | Retention is a JD requirement (F5). Generic because the figure is hypothetical. |
| A5 | "How would you set up the post-event review for a title that has never had one?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Structure: a goal, KPIs fixed before the event, one owner, dated actions. Answer slot: if you ran a review, say what it measured and what changed; if you did not, say so and give the structure. | F4 is the silence in your material, so the honest branch is the one that gets rehearsed. |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never led a team. What makes you ready to coordinate design, art, engineering and community on every update?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment: "I haven't led a team." Then an answer slot: name any team you coordinated with on a content drop and what you did with them; if your coordination was with QA only, say so. Then your ramp: how you would open the four-team work in week one. Hold through two follow-ups by returning to the calendar and the checklist. Concede: "I haven't led a team, and the four-team coordination is what I would learn first." | Highest-ROI prep in the pack. It combines your stated negative with the JD's coordination line, so it will almost certainly be asked. The honest answer is a limit, not a defence. |
| B2 | "Why is this a step up from associate producer, and why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say the reason in your own words. The pack supplies none. Anchor the step in the calendar you ran for two years, using the quote only. | Motivation probe. F7 and F1 carry the only evidence for the step. |
| B3 | "Which monetisation model have you worked under, and how did it shape your calendar?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then describe the pacing constraint of the puzzle title in your own words, if there was one, at the scope of F1. Then how you would learn the model, as a plan. | F9. The honest answer is a stated gap with a learning plan. |
| B4 | "Your background is one puzzle title. Two live titles is a different job. What is the first thing that breaks?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name what you would check first: overlapping calendars and shared capacity. Then say what you know from one title, in your words. Make no claim about two titles. | F2's scope question, asked as a problem. |
| B5 | "Where would you draw the line between what the calendar promises and what the release can ship?" | JD | [grounded] "manage the release checklist with QA" (JD); "Wrote the release checklist our QA team still uses" (your message) | Answer from F6: "I wrote the release checklist, and our QA team still uses it." Answer slot: if you decided what to cut from a release, say so; if not, say so and describe the cut rule you would use. | F6 is the strongest evidence, and this question tests whether you overstate it. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you chose or checked how the figures were counted, say how; if you did not, say so and name what you would check first. | F5. The question presumes only that you presented them. |
| C2 | "Which assumption behind a retention figure would you defend least?" | JD | [generic] | Name the weakest assumption you know, only if you know one. If none comes to mind, say so plainly. | Metric-assumption move from the rubric. No figure is supplied, so no defend-the-number slot applies. |
| C3 | "How would you tell whether a content drop moved retention?" | JD | [generic] | Name the comparison: a control cohort, a time window, what else changed that week. Say what you would not claim from one drop. | Asked as a method, so it presumes no outcome of your past. |
| C4 | "Which KPI in a post-event review would you be least comfortable being judged on?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name one KPI you would report carefully and why. Answer from your own experience; if you have none, say so. | F4. The question takes the JD's ownership line as given, so the honest branch is a KPI you can explain, not one you were given. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a player's experience and the calendar disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Open prompt, themed on "Players Before Plans". Pick a time the calendar had to bend for players. If none comes to mind, say so plainly, then give the nearest thing your material carries: the calendar you ran. | Values round detected from the loop source. The published value is the raising source. |
| D2 | "Tell me about a release where what you announced and what shipped did not match." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Open prompt, themed on "Ship the Patch Not the Promise". Pick a time it did not match. If none comes to mind, say so, then give the nearest thing your material carries: the checklist and how QA uses it. Do not supply the ending. | Mirrors his talk's argument, which the pack names but does not quote. |
| D3 | "What have you left in a release process that the next person would find easier?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Open prompt, themed on "Leave the Build Greener". Describe what the checklist does. Claim only what you recorded or saw. If you did not change anything, say so. | Values cheat sheet item 3. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over a candidate with live-service experience?" | JD | [grounded] "3+ years producing live-service games or apps" (JD); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Restate the question. Anchor in your calendar. Hold through two follow-ups. Concede specifically: "I haven't worked on a game with in-app purchases." | The JD's length line is what the question presses. |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: say which parts you set and which you ran. If you set none of a step, say so. Hold the calendar you ran; do not expand it. | The attribution probe. Honest answers are the strongest answers here. |

## Values and principles cheat sheet

Source: the company's values page, fetched. The round is a values conversation by the loop source.

| Value (official name) | Working meaning (paraphrased from the page) | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | D1. Your material carries the calendar you ran. Selection scaffold: pick a time the calendar bent for players; if none, say so. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | D2. Your material carries the checklist QA uses. Selection scaffold: pick a release where announcement and shipment differed; if none, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | D3. Your material carries the checklist you wrote. Selection scaffold: say what you changed and what you did not. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B4 |
| Coordinate design, art, engineering and community on each update | A3, B1 |
| Own the post-event review and the KPIs it reports | A5, C4 |
| Manage the release checklist with QA | B5, D2 |
| 3+ years producing live-service games or apps | E1, B3 |
| Experience running a content calendar | D1, E2 |
| Comfortable with player-retention metrics | A4, C1, C2, C3 |
| Clear written communication | none, and why: your material holds no writing sample beyond the checklist, so no question tests it; the upgrade menu names the sample |

## Reverse questions

Hiring-manager round, so no reciprocity question is included.

1. "In the Outage Hour, what does a strong first ten minutes look like to you?" Why it lands: shows you prepared for the format the loop names.
2. "You moved from QA lead to Head of Live Operations. What did that change about how you judged a release?" Why it lands: tied to his own path, from the public talk listing. It turns a probe into a conversation.
3. "The company's September 2026 news item moves two titles to one shared calendar from February 2027. What does the first quarter look like for this role?" Why it lands: shows you read the strategy, from the search result.
4. "When the title teams and the live-ops group disagree on the post-event KPI set, who decides?" Why it lands: tests the ownership line of the JD.
5. "What did the last person in this role spend their first ninety days on?" Why it lands: gets the real scope from the person who knows.
6. "How would you like the release checklist to change under one shared calendar?" Why it lands: connects F6 to the company's direction.

## Sources

Provided documents: the job description and background as pasted in your message. No CV was provided.

Every search and fetch, by query:

1. "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched it: three values named.
2. "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing. Fetched it: loop is a recruiter call, then the Outage Hour, a single 60-minute hiring-manager interview. No take-home.
3. "Saltmarsh Games strategy news": returned the Project Larkspur news item (search result only, not fetched).
4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": returned a GDC 2026 talk listing (search result only, not fetched).

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet, section 10: three values by name |
| 2. saltmarsh interview process | yes | Loop: one session, the Outage Hour; no archetype fallback needed |
| 3. saltmarsh strategy / recent news | yes | Project Larkspur item: reverse question 3, and the JD's "two of our mobile titles" context |
| 4. interviewer name and company | yes | Reading the interviewer, persona weights, reverse question 2 |
| 5. representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A writing sample or a short document you wrote → F8 moves from `[inferred]` to `[grounded]`, and the clear-written-communication row gets a real artifact.
- The post-event review you ran, if any → F4 becomes an answer you can give, not a slot.
- Whether the puzzle title ran content after launch → F7 is settled either way.
- The other teams you coordinated with on a content drop → F3 moves from `[inferred]` to `[grounded]`.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, covering the company's strategy brief, the interviewer's talks and writing, loop reports from candidates, and recent org changes. Want it?
- A `tuesday-dossier.md` would carry the gaps this prep exposed (B1, B3, F4, F9) into later sessions.
