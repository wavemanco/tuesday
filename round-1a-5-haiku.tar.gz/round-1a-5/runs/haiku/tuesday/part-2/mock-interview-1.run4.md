The prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-1-denied-884928a7/ee0d918b-457d-4871-8469-70a12da6c6ad/scratchpad/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer round, as your brief said, and from your notes and research note alone.

**What's in it:** a fit snapshot (8 requirement rows), a prohibited-claims list, a persona table, 19 questions across six personas, five reverse questions, a requirement-coverage map, and the sources and upgrade menu.

**Weighting:** Dan's "relentlessly data-driven" profile puts the Data-Driven Prober first (5 questions), then the Peer Evaluator (4). The pricing background tilts the case questions toward packaging and unit economics.

**Highest-ROI prep (D1):** Dan asks which parts of enterprise selling Priya would need to learn. Her notes are silent on enterprise or B2B selling, so the answer has to name that gap first and then give a concrete learning plan.

**Attribution risk (A1–A3, E2):** The $400M figure is "credited with" in her notes. The pack keeps her verb at "proposed" and includes answer slots for how it was counted and which parts were hers. It doesn't supply a counting method.

**Quota gap (D2):** "Annual volume targets" is adjacent to quota work, not the same thing. The pack has her say plainly that she hasn't done sales-ops or quota-setting, and it never calls the targets quotas.

**Things to know:**
- **No CV.** Every quote comes from your summary in the notes, so the pack treats them as medium confidence. Her CV would let me replace those with her own sentences.
- **Web search was refused**, so Dan's public talks and writing are not in the interviewer read. The reverse questions rest on your profile alone.
- **Your research note isn't verified.** I took the priorities and the bundling threat as you wrote them.
- **No gate rows.** The JD highlights don't mention location, travel, authorization or pay. If the full JD does, those need checking.
- **Dropped sections:** no values cheat sheet (not a values-style round) and no delivery coaching (no assessment provided).

Drill, dossier and Word offers are in the chat message. I can run the drill with me as the Skeptic on D1 whenever she's ready.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: **peer** (you and Dan would report to the same VP). Format: one 60-minute conversation.
**Changelog:** first build, no earlier pack.

---

## How to use this pack

- **Personas** describe how a question arrives: its register and style.
- **Types** describe what is being scored.
- Type key: **VAL** behavioral/values alignment · **EXP** work-experience deep-dive · **JD** role and JD-driven · **CO** company and strategy knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in 90 to 120 seconds, in your own words.
- Provenance labels: **[grounded]** traces to a provided document (your notes, the JD highlights, your research note); **[inferred]** derived from something adjacent, with the derivation named; **[generic]** a pattern with no claim about you or Northwind.
- An **answer slot** ("if you did this, say how; if not, say so plainly") is an instruction for the interview. It asks nothing of you here.

**Input note.** Your background arrived as a summary in the coach's notes, not as a CV. Every quoted line below is from that summary. Sending your CV upgrades these rows (see the upgrade menu).

---

## Fit snapshot

Requirements come from the JD highlights and your research note. Each evidence cell holds only quoted sentences and their source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The notes place your nine years in product strategy and ops at a consumer-tech company, not in GTM for a product line. Say it at that scope. Answer slot: if you made a go-to-market call for a new product line, say which and how you decided; if you did not, or it was not yours, say so and stay with the product strategy and ops you did. |
| S2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes; "No classic sales-ops or quota-setting experience." — the coach's notes | medium | [grounded] | transferability | Annual volume targets are adjacent to whitespace work, not the same work. Plain acknowledgment, from your own note: "I haven't done classic sales-ops or quota-setting work." Answer slot: say which targets you set, what they counted, and how you would find whitespace across all four stages. |
| S3 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | You built the model and it was used in negotiations. The notes do not show that you designed a partner motion. Keep the verbs at the quote's scope. Answer slot: if you designed partner terms or a partner motion, say which; if the model served other people's negotiations more than yours, say that. |
| S4 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | "Skilled" is vague and nothing is inspected. Derivation: the notes name both tools and no artifact, so no story is asserted from them. Answer slot: name one analysis you ran yourself in SQL or Tableau and what it changed; if nothing you ran changed a decision, say so and give the nearest one. |
| S5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Consensus across orgs is influence in other words. Reword only that quote and add no practice. |
| S6 | None in the JD highlights; a headline figure in the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The figure will be tested. Your notes say "credited with", which is an attribution, so keep the verb at "proposed" and do not present the figure as your result. Defend-the-number slots: A1 to A3, and E2. |
| S7 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Daily use is user-level, not AI product work, so the JD's "a plus" is not reached by it. Say it at that scope, and do not carry "built" or "launched" into an AI answer. Answer slot: name the tools and the work you do with them. |
| S8 | "enterprise expansion" — your research note (a stated Northwind priority) | none given | none | [grounded] | discovery | Silence, not a negative: the notes say nothing about enterprise or B2B selling. Answer slot: if you have worked on enterprise or B2B selling, say what and how; if you have not, say so and say how you would learn the enterprise motion. |

**Gate rows:** none. The JD highlights state no location, travel, authorization or pay term. If the full JD does, those become gate rows (see the upgrade menu).

---

## Prohibited claims

What this pack will not coach, and why. Built here from the fit snapshot, because no dossier was supplied. A candidate reaches for these under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned GTM for a product line" or "ran GTM strategy" | Inflated form of S1: widens "product strategy & ops" into the JD's line | S1's quote at its own scope. The limit is the pack's observation, not words for the candidate: the notes say product strategy and ops, not GTM for a product line. D1's slot stays inside that scope. |
| "Designed the partner motion" or "negotiated with carriers" | Inflated form of S3: "used in carrier negotiations" becomes a role in them | S3's quote at its own scope. A4's slot asks only which decision the model informed. |
| "Set quotas" or "ran sales ops" | Negative the candidate stated, S2 | The plain acknowledgment from S2: "I haven't done classic sales-ops or quota-setting work." No slot. |
| "The volume targets were quotas" | Inflated form of S2: "annual volume targets" becomes a quota | S2's quote at its own scope. Never call the targets quotas (D2). |
| "I drove the $400M" or "I owned the uplift" | Inflated form of S6: "proposed" and "credited with" become result and ownership | S6's quote at its own scope. E2's hold uses "proposed". |
| "Expert in SQL or Tableau" or "built the dashboards leadership used" | Inflated form of S4: "skilled" becomes expertise and an artifact | S4 is low-confidence. Its words are a clarify note only, not a story. |
| "Built or launched AI products" | Inflated form of S7: daily use becomes product work | "uses AI tools daily", at its own scope. |

Not listed: B2B or enterprise experience. Your notes are silent on it, and silence is an answer slot (D1, S8), not a prohibited claim.

---

## Reading the interviewer

**Dan Kovac.** Director of Sales Strategy. Career pattern, from your profile note: pricing and monetization roles, with one early-stage startup chapter. Self-described: "relentlessly data-driven." Public footprint: not established (see Sources).

Practical implications:

1. **Pricing, packaging and unit economics are Dan's native language.** The case bank (C1 and C3) tilts there. Use that vocabulary when the JD or your research note uses it, not otherwise.
2. **Every number gets taken to its assumptions.** A1 and A2 are the first rehearsal.
3. **The startup chapter means builder stories land, and Dan may test whether big-company pace is real.** Pace claims must be the quoted ones, not invented ones.
4. **Shared professional path (domain, not identity).** Dan's pricing and monetization roles and your revenue model are the same domain. The mirror pairs Dan's public path with S3, quoted exactly: "built a partner-level revenue model used in carrier negotiations." Use it as a domain overlap. Do not build rapport on it.

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | "Walk me through how that number was counted"; "which assumption would you defend least"; asks for the artifact behind SQL and Tableau | **High.** Dan's self-description raises the prior, and the headline figure (S6) and the skill line (S4) are the probe surfaces. | 5 (A1 to A5) | Know what you can and cannot say about how the figure was counted. Name the weakest assumption before Dan does. Offer to walk through analysis you ran. |
| Peer Evaluator | Seam questions with GTM and product; "what would you need from my team"; credit when work crosses orgs | **High.** This is the peer prior. Dan will price what you cost and add to Dan's own work. | 4 (B1 to B4) | Reciprocity framing: what you bring to their team, not only what you need. Propose seam principles, not a map of their teams. |
| Case/Strategist | The three-priority trade-off; the bundling threat; discounting in a land-and-expand deal | **Medium-high.** The pricing and monetization spine tilts cases to packaging and unit economics, and the research note supplies live material. | 3 (C1 to C3) | Clarify, then structure out loud once. Challenge one premise per case. |
| Skeptic | The enterprise objection; volume targets against quotas; a store change against a B2B line | **Medium-high.** The gaps in S1, S2 and S8 are exactly where this persona lands. | 3 (D1 to D3) | Rehearse D1 until it is boring. Name the gap before it is named for you. Give a plan, not a bluff. |
| Pressure | "Why you over someone who has run enterprise GTM?"; "how much of that was actually you?" | **Low-medium.** A peer round seldom stresses, but the $400M figure invites a hold test. | 2 (E1 to E2) | Pause. Hold through two follow-ups. Concede in exact words. |
| Conversational | A journey opener; a casual question about AI | **Medium.** Unstructured openers are scored, and the AI line is a JD plus. | 2 (F1 to F2) | Use a prepared 90-second arc. Treat casual questions as scored. |
| Values/Behavioral | Not in the bank | **Low.** No values-style round was detected and no published values are in hand. VAL questions are conditional on both. | 0 | None. See the upgrade menu. |

---

## Question banks

Session total: 19 questions. Weights follow the persona table.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Story map from S6: you proposed a store-surface change, and it was credited with the uplift. Say the proposal in your own words first. Answer slot: if you know how the uplift was counted, say the method in your words; if you do not, say so plainly and then say what you can speak to. Do not describe a counting method you were not shown. | The headline figure is the likeliest probe for a data-driven peer. EXP because it tests what was yours. S6 is the only quote the figure rests on. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Weakest-assumption move: name, in your words, the assumption you would defend least, before Dan does. Answer slot: if you can name one, name it and what you would check; if you cannot, say so rather than inventing one. Keep the wording at "credited with". | Dan's profile makes every metric a probe into its assumptions. A named weak point turns a gotcha into a credibility gain. Raised by the figure in S6. |
| A3 | "Of that change, which decisions were yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Story map: "proposed" is the verb you keep. Beats: the change, your proposal, the outcome as it was credited. Answer slot: name each decision that was yours; if the rest was decided elsewhere, say so. Never turn "proposed" into "designed", "decided" or "led". | Separates your share of the work from the attribution. A drift to "led" is the thing this probe finds. |
| A4 | "Walk me through the partner-level revenue model you built. What was it used to decide in those negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Story map: built; partner-level; used in carrier negotiations. Say the model, then its use, in those words. Answer slot: if the model informed a decision in the negotiations, say which decision in your own words; if it served someone else's decision more than yours, say that and describe what the model contained. | The partner-motion requirement (S3) is the JD's line, and this is the nearest evidence. "Used" is the weakest verb in it. |
| A5 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [inferred] "skilled in SQL/Tableau" — the coach's notes (low confidence; derivation: the JD's run-independent-analysis line, with no artifact in the notes) | Open prompt, so you choose the instance. Selection scaffold: pick an analysis you ran yourself, with the question it answered, the data it used and the decision it changed. If none changed a decision, say so plainly and give the nearest one you ran in SQL or Tableau. Name no tool detail you cannot repeat under a follow-up. | The JD asks for independent analysis in SQL and Tableau (S4). A data-driven peer will ask for the artifact, and the notes give none. Labeled [inferred] because the confidence is low, so no story is asserted from it. JD type, prober delivery. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where would the seam between GTM and product sit, and what happens when you disagree?" | EXP | [generic] peer seam pattern; [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Propose seam principles, not a map of Dan's team: who owns the decision, who owns the metric, how a disagreement gets settled. Say the principle first. Use your product strategy and ops work, at its own scope, as the nearest seam you have worked. | The Peer Evaluator stem. The product reference rests on S1's sentence, not on any claim about Dan's team. |
| B2 | "When an outcome is shared across orgs, how do you describe your part?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story map: the targets, set across orgs, by consensus. Beats: what you proposed, whom you needed to agree, how agreement was reached. Use "we" for the group and "I" for your contribution. Answer slot: name the part you played in the consensus; if you were one voice among several, say so. | Cross-functional influence is a JD line (S5). The question puts the audit's relationship and verb axes into the interview. |
| B3 | "A partner disagrees with a revenue model's numbers. What do you do first?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Generic first move: check the inputs with the other side before arguing from the model. Answer slot: if a disagreement over that model happened, say what it was and how it resolved, in your words; if none did, say how you would handle one. The disagreement is hypothetical in the question, not a fact about you. | The partner-motion line (S3) carried into peer collegiality. The question presupposes nothing about partners in your past. |
| B4 | "What would you need from my team to do this job well, and what could your team need from yours?" | EXP | [generic] peer reciprocity pattern; [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Reciprocity framing: name what you would bring to Dan's team's work before the inputs you would ask for. Answer slot: name one thing your product strategy and ops work gave a neighbouring team, if one did; if not, name the input you would ask for and what you would return. | The Peer Evaluator's "what would you need from me" stem. Reciprocity is the peer prior, and it is the strongest signal this round can send. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches, and a much larger platform vendor bundles a comparable AI feature into its suite. How would you decide where a standalone product still wins?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note; framework [generic] | Clarify first: what the bundle includes, who buys it, what it costs. Then objective, the segments where the bundle is weakest, price and packaging, and risks. Name one premise you would challenge. Tilt toward packaging and unit economics. | Case/Strategist is the prior for a peer with a pricing spine, and this is the research note's live threat. The question presupposes nothing about you. The threat comes from your note and has not been checked against Northwind's pages. Carries CO delivery. |
| C2 | "Northwind has three priorities: enterprise expansion, an AI copilot launch and reaching profitability. For the next two quarters, which one leads your GTM line, and why?" | CASE | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | Clarify the line's objective and the time frame. Choose one. Say what the other two cost you in the choice. Name the metric that would tell you the choice was wrong. Pick by what your line can move, not by which priority sounds biggest. | Tests altitude and whether you can trade priorities out loud. The CO depth rests on the note's own words only, so keep to them. |
| C3 | "A land-and-expand deal comes with a steep first-year discount. How would you tell whether the discount buys adoption or just cheaper revenue?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights; the discount scenario [generic] | Name what adoption looks like before the discount: usage, seats, the trigger for expansion. Then propose one test that separates adoption from cheaper revenue, such as the renewal price once the discount ends. Name the risk of each reading. No claim about your past is made here. | Pricing tilt: pricing and monetization is Dan's native domain, and this is the JD's land-to-renew line in a case. Presupposes nothing about you, so the guidance makes no claim about you. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have spent nine years in consumer tech. Which parts of selling to enterprises would you need to learn first, and how would you learn them?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | **Highest-ROI prep in this pack.** Say the honest form first. If you have worked on enterprise or B2B selling, say what, in your own words. If you have not, say so plainly, then give the first three things you would learn and how, with no timeline you cannot defend. Concede one specific gap, never a soft one. Follow-up levels to rehearse: (1) "Which of those would you learn in the first month?" (2) "Who on the enterprise side would you ask to check the plan?" Answer slot: the second branch allows that no enterprise selling was yours. | S8 and S1 are the biggest gap in the snapshot, and this is where the objection lands. The question names no experience you lack. Your notes say nothing about enterprise selling, so the question carries no negative. The limit is the pack's own observation: the notes are silent, not negative. Skeptic persona, the deepest rehearsal in the pack. |
| D2 | "You set annual volume targets. With no quota-setting background, why should I believe a target you set would hold?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." — the coach's notes | Plain acknowledgment first: "I haven't done classic sales-ops or quota-setting work." Then the targets at their scope: annual, volume, set with cross-org consensus. Say, in your words, what made the consensus hold. Answer slot: if you can say what a target was measured against, say it; if not, say so and say what you would check. Never call the targets quotas. | Skeptic: the negative is one you stated, so the acknowledgment is yours to give. The target is the quoted sentence. The land-to-renew requirement (S2) is what a target would need to support. |
| D3 | "A consumer store change is a different kind of launch from a B2B product line. What would carry over, and what would you do differently?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Bridge at transferability: name what carries over, at the quote's scope. You proposed the change; describe the mechanics you actually took part in. Answer slot: name any part of that work that maps to a B2B line; if none does, say so and say what you would do first. | The B2B line is the JD's GTM requirement (S1). The bridge stays at the store change's scope, with S6's "proposed" carried through. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run enterprise GTM?" | JD | [generic] pressure stem; [grounded] "9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, then restate the question in your own words. Hold the position the quotes carry: nine years of product strategy and ops, and a revenue model used in negotiations. Hold through two follow-ups. Concede in these words, or close to them: "Enterprise GTM is the part I would have to prove. Here is how I would prove it." | Pressure scores composure, not content. The concession names the gap as something to prove, which is a plan and not a negative you have not stated. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold: "I proposed the change. The figure is the one it was credited with." Hold through two follow-ups by returning to the proposal; never move to "I drove it". Concede specifically: "I cannot give you my share of that figure, and I would rather say so than guess." Answer slot: if you know your share, give it in your words; if you do not, concede it as above. | The hold is only what the notes carry: "proposed" is the one verb they support. The concession names the uncertainty exactly, which is what a second follow-up tests. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: consulting, then consumer tech, and now this?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Prepared 90-second arc using only the quote's beats: two years of strategy consulting, then nine in product strategy and ops, then what you want next, in your own words. Answer slot: say why this role, in your own words; the notes give no reason, so do not invent one. | Casual openers are still scored. The arc uses only beats the quote states. "Why now" is an answer slot because the notes give none. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" — the coach's notes (low confidence, so it is a clarify note and no story) | Name the tools you use daily and the work you put them to, in those terms. Do not describe building, deploying or launching anything with AI. If Compass comes up, say what you have used, not what you would build. | The casual register still scores the "AI experience a plus" line (S7). Low confidence means the notes support daily use only. |

---

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (JD) | D1, C2; S1 |
| "identify whitespace across land/adopt/expand/renew" (JD) | C3, D2; S2 |
| "run independent analysis in SQL and Tableau" (JD) | A5; S4 |
| "partner-motion design experience required" (JD) | A4, B3; S3 |
| "strong cross-functional influence" (JD) | B2; S5 |
| "AI experience a plus" (JD) | F2; S7 |
| "enterprise expansion" (research note) | D1, C2; S8 |
| Compass and reaching profitability (research note) | C1, C2 |

---

## Reverse questions

Five, each with a one-line reason it lands. Two tie to Dan's path. One is a reciprocity question, since the interviewer is a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You had an early-stage startup chapter before the pricing and monetization roles. What did pricing decisions look like in the startup, compared with the monetization work you have done since?" | Ties to Dan's own path and turns an interrogation into a peer conversation. It also shows you researched Dan, not only the company. |
| R2 | "What could someone in this role do in the first month that would genuinely help your team?" | Reciprocity, as a peer question. Signals you are planning to give back, not only to ask for inputs. |
| R3 | "Where is the pricing decision on Compass still open?" | Names the research note's live product and invites Dan's expertise on the exact decision a pricing lead owns. |
| R4 | "When enterprise expansion and the profitability target pull against each other in a deal review, which one usually wins, and who decides?" | Tests decision rights, which is what a GTM strategy lead needs to know before accepting the role. |
| R5 | "Where do the sales strategy and product seams cause the most friction today?" | A seam question that Dan can answer from experience, and it sets up B1's ground for the conversation. |

---

## Sources

**Provided documents.** Your message: the JD highlights, the coach's notes on Priya's background, Dan's profile summary, and your research note on Northwind. No CV, no full JD text, no dossier, no working-style assessment. User links read: 0.

**Searches sent.** One standard search, refused by the host: "Dan Kovac Director of Sales Strategy Northwind Data" (refused).

**Not established.** Dan's public talks and writing. Whether Northwind's public pages match your research note. Neither was checked, so the note is treated as provided, not verified.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | The values cheat sheet is not emitted. No values-style round was detected, so no output draws on it. |
| 2. Interview process | skipped | The brief fixes a single 60-minute peer conversation. No loop, so nothing to weight. |
| 3. Strategy and recent news | skipped | Your research note in hand fixes the three priorities and the bundling threat (C1, C2). |
| 4. Dan Kovac, Northwind | unavailable | The one search was sent and refused, so nothing was established. It would have moved the interviewer's public talks and writing, and R1 and R5. |
| 5. Representative JD | skipped | The JD highlights in hand fix the fit snapshot's requirements. |

---

## Upgrade menu

- **Your CV, or the full JD text** → your background quotes become your CV's own sentences, so S1 to S5 and S7 can be upgraded from the coach's summary. The full JD may add requirement rows and gate rows (location, travel, authorization, pay) that the highlights do not show.
- **A work sample: a SQL query or a Tableau view you built** → S4 moves from [inferred] to [grounded], and A5 gets an artifact to rehearse.
- **The $400M analysis, or the partner revenue model, if you can share either** → A1 to A4 get inspectable evidence in place of answer slots.
- **A search for Dan Kovac's public talks and writing** (refused in this run) → a sharper interviewer read, and R1 and R5 tied to Dan's published themes.
- **Deep research (L2), offered once:** a Northwind strategy brief, Dan's public talks, and recent org context. About six more searches and two fetches, if the host allows searching. Run only on your yes.
- **Northwind's published values or the interview process**, if you want a values round rehearsed. This round is not values-style, so none is in the pack.
