I have the playbook. This is a final round with a known company and role, but no CV, JD or interviewer name yet. Next I'll run the L1 research targets (values, loop structure, recent strategy) before drafting.
Web search was refused by the permission system on all three calls. I won't retry them. The pack will be built without any Stripe-specific research, and I'll say so in the Sources section. Next I'll write the pack file.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-3-denied-6e6dcf43/992acfba-ad97-4c66-8575-62672d626a98/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round with the interviewers unknown, and with no CV or posting. The pack has 23 questions, and its requirements are typical product-operations patterns, not Stripe's published ones.

Web search was refused by the permission system on all three calls, so the pack says nothing about Stripe's values, interview loop or strategy. If you allow search, I can run that research and fold it in.

Two questions would reshape the pack:

1. Who will you meet in the final round, and is it one conversation or several? Has the recruiter said whether any session involves a presentation, case or take-home?
2. Can you paste the job posting and your CV, or a few lines on your product-ops work? Without them the fit snapshot has no evidence in it, and every answer stays a scaffold.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. And I can run a live drill: I'd play the Skeptic on B1, the question I'd rehearse hardest, since nothing in the material answers it yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

**Round:** final round. Interviewers and session count not yet known. Persona weights are flat, which makes this pack weaker than one built on a known loop.
**Built on:** the company and role you gave, and nothing else. No CV, no posting, no interviewer name. Web search was refused in this session, so nothing here about Stripe's values, loop or strategy comes from a source.

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **EXP**: your past work and whether it holds up under questions
- **JD**: the role's stated or typical responsibilities
- **CO**: company and strategy knowledge (none here is research-grounded)
- **CASE**: a live problem, worked out loud
- **VAL**: past behaviour against a company's values (no values round detected)

Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.

## Fit snapshot

No posting and no CV were supplied, so every row is a worksheet row. The requirements are typical product-operations patterns, labelled `[generic]`, not quotes from Stripe. Every evidence cell reads `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Launch and process design across functions (role-family pattern; no posting supplied) | none given | none | [generic] | discovery | Answer slot: if you have designed or launched a process that crossed teams, say what it was, which part you set, and how you knew it worked. If you have not, say so and say how you would scope a first one. |
| F2 | Operating cadence and prioritisation (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a time you ranked competing work for a shared team, and name the criteria you used and what you dropped. If none comes to mind, say so plainly, then give the nearest thing you did, or how you would handle it. |
| F3 | Metrics and measurement (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name one measure you have defined or tracked, how it was counted, and its weakest assumption. If you have not defined one, say so and say what you would measure first. |
| F4 | Stakeholder management across product, engineering, finance and support (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: a disagreement with a team that did not report to you; what was at stake, what you did, what you would change. If none comes to mind, say so, then give the nearest one. |
| F5 | Escalation and issue handling (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: a process that broke under load; who noticed, what you did first. If none comes to mind, say so, then give the nearest one. |
| F6 | Tooling and data analysis (role-family pattern) | none given | none | [generic] | discovery | Answer slot: the tools you use day to day, and which ones you have only read about. Say which is which. |
| F7 | Working with limited data and ambiguity (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: a decision you made before the data was in; what you assumed and how you checked it. If none comes to mind, say so, then give the nearest one. |

Where the answer would make the pack better, the upgrade menu says so.

## Prohibited claims

Built locally, since there is no evidence to draw on yet. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any metric, count or outcome from your past that you have not stated in this conversation | No candidate sentence exists yet | A figure you give, with how you counted it. "I don't have a figure for that" is a valid answer. |
| Owning a launch, programme or decision that your group ran | The role's usual shape, not a sentence you wrote | Your part, in your words. Say where the group's part ended. |
| Any claim about Stripe's current values, strategy or interview format | Search refused, so nothing is attributable | What you have read yourself, named as such. Otherwise, ask the question. |

## Persona weights

No loop source establishes the loop, so this pack falls back to the generic archetype: flat weights, said plainly. A final round can be several sessions, so the weights below blend them.

| Persona | How it shows up | Likelihood, and why | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | High. Process and operations roles are usually tested on a live problem. | Clarify, then objective, approach, measures, risks. Think aloud; challenge one premise. | 5 |
| Skeptic | Quiet probing of the gaps and the "why here, why now" | Moderate-high. With no evidence yet, the gaps are the whole pack. | Rehearse the one predictable objection until it is ordinary. Give a ramp plan, not a bluff. | 4 |
| Data-Driven Prober | Asks how a number was counted and what it assumes | Moderate. Likely if you cite any figure. | Name the weakest assumption before they do. Say plainly what you do not know. | 4 |
| Peer Evaluator | Seams between teams, credit, disagreement | Moderate. Common in a final round with a peer or cross-functional partner. | Reciprocity: what you bring their team. Propose seam principles, not a guessed seam. | 3 |
| Pressure / Stress | Interrupts, time-boxes, questions your motive | Moderate. Depends on the interviewer. | Pause, restate, hold a position through two follow-ups, concede only what is true. | 3 |
| Values / Behavioural | Scenario probes on how you work | Low to moderate. No values round detected. | Story with the hard truth in it. Where you have none, say so, then give the nearest. | 2 |
| Conversational | Friendly openers that are still scored | Low. Casual questions still count. | 90-second arc for the biography. Treat casual JD questions as scored. | 2 |

## Question banks

Provenance is `[generic]` throughout: no candidate sentence exists yet, so no guidance claims anything about your past. Stems for the probes come from the persona set, not from your history.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for rolling out a new internal process to three functions. What do you need to know first?" | CASE | [generic] | Clarify the goal, who is affected, and what already exists. Then state the approach, how you would measure it, and the main risk. Name one assumption you would test first. | The most likely case shape for this role. F1 is the row it tests. |
| A2 | "A key operating metric dropped 20% last week. Diagnose it." | CASE | [generic] | Ask what changed. Check the measure itself before the cause. Split by segment and time. Propose two checks before a conclusion. | Diagnosis under pressure; covers the escalation row F5. |
| A3 | "You have three process problems and one engineer-month. Which do you fix?" | CASE | [generic] | State the criteria (cost of delay, reversibility, who is blocked). Choose one and say what you would drop. | Prioritisation with a fixed budget. F2 and F7. |
| A4 | "What would you do in your first 90 days in this role?" | JD | [generic] | Map before changing. Pick one recurring pain, a measure for it, and one small fix to ship. | Tests whether you plan rather than promise. F1. |
| A5 | "Which trade-off between speed and control would you push on in this process?" | CASE | [generic] | Name who owns each side. Pick a default and the trigger that would reverse it. | Judgement under ambiguity. F2. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name one specific area, the first thing you would do about it, and how you would know it was working. Answer slot: if you have done work near that area, name it in your own words. If you have not, say so and give the ramp plan. Hold through two follow-ups: ask how you would know, then what you would give up to learn it. Concede the gap; do not bluff a strength. | Nothing in the material yet answers this, so it is the most predictable probe. It reaches F1 to F7 together. |
| B2 | "Why this role, and why now, from your side?" | EXP | [generic] | Describe the work you want in the role's own terms. Make no claim about the company you have not read yourself. | Motivation is always probed; you need an answer that does not lean on claims you cannot source. |
| B3 | "Tell me about a process you were part of that failed. What did you do?" | EXP | [generic] | Pick one. Name your part and what you would change. If none comes to mind, say so plainly, then give the nearest one. | An open prompt. Rehearses candour about failure. F5. |
| B4 | "What would make you the wrong hire for this team?" | JD | [generic] | Name one real limit and what you do about it. Do not use a humble-brag. | Tests self-assessment; the Skeptic's favourite close. F4. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your last role and walk me through how it was counted." | EXP | [generic] | If you have one: define it, its source, what it is sensitive to, and the assumption you would defend least. If you do not have one, say so; do not build one now. | Defend-the-number probe. F3. |
| C2 | "Which assumption behind your favourite measure would you defend least?" | EXP | [generic] | Name it before they do. Say what you would change if it were wrong. | Converts a gotcha into a credibility gain. F3. |
| C3 | "What did you build yourself, and what did you use from someone else?" | EXP | [generic] | Separate the two. Name the tools you used and the ones you built. | Attribution honesty. F6. |
| C4 | "How did you know a process change worked?" | EXP | [generic] | Name the before and after measure, the comparison, and its weakness. If you did not measure, say so and say what you would measure. | Checks whether a claimed win has a method behind it. F3. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose a seam principle (who decides scope, how escalation works) rather than guessing their seam. If you have a disagreement story, tell it in your words. | Peer probe on turf and collaboration. F4. |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the principle: credit the people who did the work. If you have an example, tell it. If not, say so, then state how you would do it. | Credit-sharing is a peer's hidden test. F4. |
| D3 | "What would you need from my team to do this job well?" | JD | [generic] | Ask for specific inputs. Do not claim to know their process. | Reciprocity framing. F4. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over a candidate with more product-ops years?" | JD | [generic] | Hold-then-concede. Say where they have more. Hold the one point you can defend, in your words. Do not fold on the core claim under the second follow-up. | The most common final-round pressure question. F1 and F7. |
| E2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Separate your part, the team's part, and timing. Hold through two follow-ups, then concede exactly what was not yours. | Attribution under challenge. F3. |
| E3 | "Why are you leaving where you are?" | EXP | [generic] | Say it in positive, true terms, in your own words. No bashing of a past employer. | Motive probe. |

### Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Name the truth, the stake, how you said it, and the outcome, good or bad. If you have none, say so, then give the nearest one. | Open prompt; no values round detected, so it is a general behavioural probe. F4. |
| F-V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Tell one example in your words. If none comes to mind, say so, then give how you would handle it. | Common behavioural stem; no company value is assumed. F3. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: each role in one sentence, then what changed. Make no claim you cannot give an example for. | Casual openers are scored. Sets up every later answer. |
| G2 | "What tools are you actually using day to day?" | JD | [generic] | Name the real tools. Say which you have only read about. | Tests tooling honesty. F6. |

### Requirement coverage

| Requirement (role-family pattern) | Question IDs |
|---|---|
| Launch and process design across functions (F1) | A1, A4, E1 |
| Operating cadence and prioritisation (F2) | A3, A5, B3 |
| Metrics and measurement (F3) | C1, C2, C4, E2, F-V2 |
| Stakeholder management (F4) | D1, D2, D3, B4, F-V1 |
| Escalation and issue handling (F5) | A2, B3 |
| Tooling and data analysis (F6) | C3, G2 |
| Ambiguity and limited data (F7) | A3, B1, E1 |

Session total: 23 questions.

## Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none is tied to an interviewer's career path.

1. **"How many sessions are in the final round, and what does each one assess?"** Lands because it shows you are planning around their process, and it is a fair question to ask.
2. **"What does a strong first 90 days look like here?"** Lands because it shows you think in outcomes rather than tasks.
3. **"Which process problem takes up most of your team's time right now?"** Lands because it shows interest in the real work.
4. **"How do product operations and the product teams decide what gets a process and what stays informal?"** Lands because it surfaces the scope boundary, which is where this job is most often unclear.
5. **"What would make you say, six months in, that this hire was the right one?"** Lands because it asks for their success criteria, which you can then answer against.
6. **"What have you seen work, and fail, when a process change has to cross three teams?"** Lands because it invites a judgement you can build on.

## Sources

- **Provided documents:** none. The company and role were given in the message; no posting, CV or other document was supplied.
- **Searches sent (all refused by the permission system):**
  1. "Stripe company values principles": refused
  2. "Stripe interview process product operations manager final round": refused
  3. "Stripe strategy recent news 2026": refused
- **Fetches:** none.
- **Dossier:** none present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet absent. Search refused. |
| 2. Stripe interview process, product operations | unavailable | Loop structure unknown, so persona weights are flat. Search refused. |
| 3. Stripe strategy and recent news | unavailable | CO questions are generic. Search refused. |
| 4. Interviewer name and Stripe | n/a | No name given; there is no query to form. |
| 5. Representative product operations manager posting | unavailable | Would have grounded requirements F1 to F7 as `[inferred]`. Not sent, because search was refused. |

## Upgrade menu

- The final round's format, and who you will meet → loop structure, and a mini-pack per session if the final is several sessions.
- The job posting → the requirement rows become quoted, and any gate in it appears.
- Your CV, or a few lines on your product-ops work → the worksheet rows gain quoted evidence, and the answer slots become story maps.
- Stripe's values page, pasted → a values cheat sheet, and a check on whether a values round exists.
- A recent Stripe strategy note, pasted → grounded CO questions.
- Permission to use web search → the three refused research targets, which would otherwise stay blank.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
