Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-8-canned-efe3f098/7da7b140-fc2e-463a-8f90-e995a4373cf6/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it in loop mode, with one mini-pack per round, since all three rounds are on 4 December.

The three things to rehearse first:

- **B5, the contact-centre objection.** The JD sets it up and you have stated the gap yourself. Rehearse the plain acknowledgment and your learning plan until they come out flat. A7 is the same objection in the recruiter screen.
- **B6, senior presenting.** You've never presented above regional level. Answer with the acknowledgment and a plan, never with a presentation you didn't give.
- **C5, the 20-minute escalation case.** Think aloud and clarify before you structure. The case is generic, so it makes no claim about your past.

I've also kept the values round to what your material supports. None of the four values has a story your record carries yet, so each one is a scaffold with an honest branch.

Two things I chose: I took your strategy summary as the brief for now, and I did no web research because your provided material already covered every target. The upgrade menu at the end lists what would sharpen the pack, including the brief itself and the panel's names.

I can play the Skeptic on B5 if you want a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you'd like that.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

Loop mode. Three rounds, all on 4 December 2026:

- Round 1: recruiter screen, 30 minutes
- Round 2: Head of Member Services, 45 minutes, mostly behavioural, your future manager
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case, scored against the four published values

Built on: the job description, the values as copied from ashgrovecu.org/about/values on 25 November 2026, the recruiter's round description, your summary of the July 2026 strategy brief, and your background. Nothing else was used.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

Provenance labels:

- [grounded]: traces to a sentence you wrote, a provided document, or a fetched source
- [inferred]: a derivation from a provided source, with the derivation named
- [generic]: a role-family pattern with no claim about you or Ashgrove

Type key:

- VAL: behavioural and values alignment
- EXP: your own work, tested under questioning
- JD: the listed job, including its gaps
- CO: company and strategy knowledge
- CASE: a live problem, worked aloud

## The fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your sentences only. None of the requirements is a gate: no term in the JD leaves you unable to meet it on paper, so every row is graded on fit and gap type.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Your sentence reaches the years and the branch side. Expect one probe: whether branch work counts as customer operations. Answer it with what the branch handled day to day, in your words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material shows complaints handled, not that they were regulated. Answer slot: if a regulatory rule applied to any complaint in the log, say which rule and what you did at each step; if none did, say so and say what the formal log was for. |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The adjacent work is one branch's log. Say that and nothing wider. Answer slot: if you ever followed a complaint beyond the branch, say where it went and what you did; if it stopped at the branch, say so. |
| F4 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | medium | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your sentence already reaches monthly reporting in other terms. Use it as written. Do not add that anyone senior received it. |
| F6 | "report monthly on complaint volumes and resolution times" — JD | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked resolution times. Answer slot: if it did, say what it counted and how; if it did not, say so and say how you would start measuring them. |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors. Say the teller training and its limit. Answer slot: if you coached a colleague on an escalation decision, say who and what you did; if no such step came up, say so and return to the teller training. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you worked with any team on a change to how members serve themselves, say what the change was and your part; if you did not, say so plainly and say how you would work with digital teams from the branch side. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | medium | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then your plan for presenting to senior leaders, said as a plan. |
| F10 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | none | Your sentence reaches it, with one limit: it shows you built and maintained a monthly spreadsheet, not how deep your Excel goes. A probe on the spreadsheet is likely. |

Gap types here follow the evidence cells, not a judgement about the row. Confidence grades your evidence; provenance grades what this pack wrote about it.

## Prohibited claims

These are the claims this pack will not coach. Each entry gives its basis and the honest form. Nothing in any round asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F3 | "I handled the branch's formal complaints log" at its own scope. Your material shows one branch's log, not a process across branches. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Whether any were regulated is the answer slot in B10. |
| Coached branch supervisors on escalations | Inflated form of F7 | "trained new tellers on our escalation script" |
| Designed the escalation script | Inflated form of F7 | "trained new tellers on our escalation script." Your sentence says you trained on it, not that you wrote it. |
| Reported complaint trends to senior leaders | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." Your sentence says your regional manager uses it. |
| Has contact-centre experience | Negative you stated, F4 | Plain acknowledgment: "I've never worked in a contact centre." No slot. |
| Has presented above regional level | Negative you stated, F9 | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |

## Grounding brief

Your sources for the company: the values as published on 25 November 2026, the three-round structure from the recruiter, and your summary of the July 2026 strategy brief. Use the names below exactly; they are Ashgrove's.

- The four values, as published: "Members First, Always — we decide from the member's side of the counter." "Plain Words — if a member needs it explained twice, we wrote it wrong." "Neighbours, Not Numbers — every branch is part of its town." "Own the Fix — whoever finds the problem keeps hold of it until it is solved."
- Strategy, from your summary of the July 2026 brief: "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "launch a small-business lending product in Q1 2027"; the main competitive pressure is app-only banks.
- You relayed a summary, not the brief. Quote the brief directly before the interview, since the interviewers will.
- Stale framings: none found in the provided material.

## Sources

Provided documents:

- Job description, as pasted in your message
- Values, copied from ashgrovecu.org/about/values on 25 November 2026, as pasted in your message
- Recruiter's round description, as relayed in your message (the loop source: three rounds, their lengths, who runs each, and the values scoring)
- Strategy brief, July 2026, as summarised in your message (not the document itself)
- Your background, as stated in your message

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page answers it. The values section names the four values as published. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's note gives the three rounds, their lengths, who runs each, and the values scoring. It establishes the loop, so loop mode runs without a fallback. |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief is under six months old and answers it. It feeds B7 and B8. |
| 4. Interviewer public footprint | n/a | No interviewer was named, so no query could be formed. |
| 5. Representative JD | skipped | The JD was supplied, and the fit snapshot rests on it. |

## Round 1: recruiter screen, 30 minutes

Relationship: recruiter. Persona weights follow the recruiter-screen prior, conversational with a light skeptic. Nothing else in the material reweights them.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Open career walk, motivation, and the four logistics | High. A recruiter screen opens with the arc and closes on logistics. | A ninety-second career arc. Logistics answered in your own figures only. |
| Skeptic (light) | Your two stated gaps, asked plainly | Medium. Knockout-style checks on what you have said about yourself. | Plain acknowledgment first, then your plan. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career to date." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F1: six years, the last three as a branch supervisor, in your own words. Name what the branch handled day to day, once, and stop. | The opening question. It is where your years are first read against the JD's customer-operations line. |
| A2 | "What draws you to Ashgrove, given that it is member-owned?" | CO | [generic] the JD's own words, "member-owned" | Name one thing from the published values you would act on, and one thing from the JD. A sentence each. | A motivation check with a recruiter. It asks about the company's model, not about you. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. The pack supplies no figure. | Pay is the first logistic a recruiter screens. Only your number belongs in the answer. |
| A4 | "What notice period would you need to give?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. The material does not state it. | Same logic as pay: one fact, from you. |
| A5 | "Where could you work from, and how often would you need to be on site?" | JD | [generic] | Logistics slot: name the places and the pattern you can work, in your own words. The material states no office pattern. | Location is a knockout for a role spanning branches and a contact centre. |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your reason in your own words, short and true. The material states none. | Reason for leaving is a recruiter logistic and a motivation check. |
| A7 | "This role runs across the branches and the contact centre. Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the nearest true thing, the branch log, in its own words, and your plan for the contact-centre side. Hold on the branch work; concede the contact centre in one breath. | The screening version of B5. A hedge here reads as a bluff, so rehearse the acknowledgment until it is flat. |
| A8 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level" | Name one of the two gaps you stated, in your words, then your plan for it. Pick one, not both. | A skeptic's stem. The answer should name a gap you have stated, not a new one. |

Reverse questions for this round:

- "Which of the four values does the panel test most often through the case?" Why it lands: it shows you have read the values and want to spend the 60 minutes where they will be scored.
- "How soon after 4 December would you expect to hear?" Why it lands: it shows you are planning around timing and gives the recruiter an easy answer.

Highest-ROI prep for this round is A7, the same objection that appears in full as B5. Rehearse it here first.

## Round 2: Head of Member Services, 45 minutes

Relationship: hiring manager and future manager. Your round note says mostly behavioural, which moves the hiring-manager prior from case and skeptic toward values and behaviour.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Stories with a decision in them, under the values | High. The note says mostly behavioural. | A story with a decision, your part in it, and where it stopped. |
| Skeptic | The contact-centre gap, the presenting gap, and digital | High for the first two, which you stated yourself. Medium for digital. | Plain acknowledgment, then a plan. |
| Data-Driven Prober | The spreadsheet and the regulated-complaints line | Medium. A manager who will read your monthly reporting will ask what it counts. | Say what the figure counts, and what you are not sure of. |
| Case / Strategist | One live problem on the hub move | Low to medium. One question, since the round is behavioural. | Name the owners and stop. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a decision your manager made about a complaint." | EXP | [generic] | Pick a case where you disagreed, and say what you did next, in your words. If you never disagreed in the room or in writing, say so and give the nearest case: what you did, and what you would do now. | A behavioural prompt for a mostly-behavioural round. Generic because no sentence of yours carries a disagreement, so the honest branch is built in. |
| B2 | "Tell me about a time an explanation you gave a member didn't land first time." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. The nearest sentence is the teller training. Say what you explained, what did not land, and what you changed. If you did not check whether it landed, say so. Anything past the training needs your own example. | Ashgrove's test is whether a member had to hear it twice. Your closest sentence is the training. |
| B3 | "Tell me about a time you were wrong about what a member needed." | VAL | [generic] | Members First, Always. Pick a case where your first read was off, and say what changed it. If none comes to mind, say so plainly, then give the nearest case where the member's side changed the outcome. | No sentence of yours is about a member's need, so the honest branch is the answer. |
| B4 | "Tell me about a time you pulled another team in to get a complaint solved." | VAL | [generic] | Own the Fix. Name the team, why you needed them, and how the complaint ended. If you did not pull anyone in, say so, and describe how you held the complaint yourself. | Whoever finds the problem keeps hold of it. The panel scores the same value. |
| B5 | "You've never worked in a contact centre. This role owns the complaints process through one. What would you do in your first month to learn that side?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then a plan, not a past: who you would meet on the contact-centre side, which escalations you would read, and what you would ask in your first week. Hold on the branch work you can state. Concede the gap in one breath. Deepest rehearsal: when a follow-up comes, answer with the plan, not with a new example. | Highest-ROI prep in this pack. It is the objection the JD sets up, a gap you stated yourself, and the one a manager is paid to test. The plan should be ready before the question lands. |
| B6 | "I don't see a record of you presenting above your regional manager. Senior leaders will expect that from this role. How would you handle it?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare, starting from the monthly complaints picture you already build. Never describe a presentation you did not give. | A requirement with a stated absence. The question's premise is the one you gave, and the honest answer is the acknowledgment plus the plan. |
| B7 | "Work with digital teams on self-service journeys. What have you done there?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you worked with any team on a change to how members serve themselves, say what the change was and your part. If you did not, say so plainly and say how you would work with digital teams from the branch side. | F8 is silent in your material. Your summary of the brief sets 40% of member service into digital by 2028, so expect this probe. |
| B8 | "Eight branches are moving into five hubs over 2027. A complaint arrives from a branch that is closing. Walk me through your first week on it." | CASE | [inferred] "consolidate eight branches into five hubs over 2027", from your summary of the July 2026 brief | Think aloud. Clarify what was promised and by whom; set the objective (the member's fix and a record they can trust); name the owners across branch, hub and contact centre; start with a call to the member; say what you would watch; name the risk the closure adds. Make no claim about your past. Challenge one premise, such as the closing date, before committing. | CO and CASE tied to the strategy. The case is live and scored on structure, so the reasoning is the answer. |
| B9 | "Walk me through the monthly complaints spreadsheet. What does it count, and what does it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Weakest-assumption move: name, in your own words, the assumption you would defend least. Say what the spreadsheet counted. If you are not sure how a figure was counted, say so. Answer slot: if it counted resolution times too, say what it counted and how; if it counted only volumes, say that. | Covers the Excel requirement and the resolution-times gap in one question. A prober asks for the denominator, so have the honest answer ready. |
| B10 | "Did your log treat any complaint as regulated? If so, what changed in how you handled it?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if a rule applied to any complaint in your log, say which rule and what you did at each step. If none did, say so plainly and say what the formal log was for. Use the word "regulated" only if a rule applied. | F2 is discovery, not capability. The probe is on which complaints were regulated, so answer it the way it is true. |

Reverse questions for this round:

- "How will complaints from branches moving into the five hubs be handled during the change?" Why it lands: it shows you have read the strategy and are asking about the member's side of it.
- "What would owning the fix look like in this role after 90 days?" Why it lands: it takes the fourth value into the job rather than onto the slide.
- "Which complaint measure do you watch first: volumes, resolution times, or repeat complaints?" Why it lands: it tests your monthly reporting against the manager's own priority.
- "How far does this role go into self-service journeys: setting the requirements, or the branch side of the change?" Why it lands: it places you on digital scope without claiming any digital experience.

## Round 3: panel of two branch managers, 60 minutes

Relationship: two branch managers, who would be your peers across the branches and the contact centre. The loop note says the panel scores the four values and includes a 20-minute escalation case. Values-style round is documented by the loop source, so values are guaranteed in this round.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Each of the four values scored | High. The loop note names the values scoring. | Values cheat sheet below. Open prompts, a story you can say in ninety seconds, and the honest branch where no story exists. |
| Case / Strategist | The 20-minute escalation case | High. The case is in the loop note. | Clarify before you structure. Think aloud. |
| Peer Evaluator | The seam between branches and the contact centre | Medium. Branch managers are peers across the same seam. | Seam principles, not a claimed seam. Reciprocity: what you bring their branches. |
| Pressure | "how much of that was actually you" | Medium to low. Panels probe attribution. | Hold through two follow-ups, then concede the limit you can state. |
| JD | Coaching supervisors on escalations | Low, asked in the JD's own terms. | Answer slot. |

Values cheat sheet. No value has a story your material carries, so each is a scaffold with its honest branch. Answer each from a case you can state.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold on C1. Nearest sentence: "I handled the branch's formal complaints log." No sentence shows a decision taken from the member's side, so if none comes, say so and give the nearest log entry. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Scaffold on C2. Nearest sentence: "trained new tellers on our escalation script." Honest branch: if you did not check whether an explanation landed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold on C3. Nearest sentence: "I built the monthly complaints spreadsheet our regional manager uses." Honest branch: if the spreadsheet never showed the local picture, say so and say what you would add. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold on C4. Nearest sentence: "I handled the branch's formal complaints log." Honest branch: if no complaint ran to a close with you holding it, say so and describe the nearest handover. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] the values page, "we decide from the member's side of the counter"; your sentence: "I handled the branch's formal complaints log" | Scaffold, per the cheat sheet. Pick one log entry where the member's side changed the answer. If none does, say so, and give the nearest entry and what you weighed. | Members First, Always, scored by the panel. Open prompt, with the theme from the published value. |
| C2 | "Tell me about a time an explanation you gave didn't land first time." | VAL | [grounded] the values page, "if a member needs it explained twice, we wrote it wrong"; your sentence: "trained new tellers on our escalation script" | Scaffold, per the cheat sheet. Say what you explained, and how you knew whether it landed. If you did not check, say so. | Plain Words. The teller training is your nearest sentence; anything beyond it needs your own example. |
| C3 | "Tell me about a time a figure you reported missed what was happening in one branch." | VAL | [grounded] the values page, "every branch is part of its town"; your sentence: "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold, per the cheat sheet. If you can, pick a figure from the spreadsheet and say what it missed about the town it came from. If the spreadsheet never showed that, say so and say what you would add. | Neighbours, Not Numbers. The panel tests whether you read numbers as places. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] the values page, "whoever finds the problem keeps hold of it until it is solved"; your sentence: "I handled the branch's formal complaints log" | Scaffold, per the cheat sheet. Pick one log entry you followed to a close. If none ran to close with you holding it, say so and describe the nearest handover. | Own the Fix. The panel is looking for whether you stayed with it, not whether you knew the phrase. |
| C5 | Case (20 minutes): "A member's written complaint says a fix promised at their branch has not happened in three weeks. The branch supervisor says it is waiting on the contact centre. Walk us through the first 20 minutes." | CASE | [generic] a live problem about a member complaint; it presupposes nothing about you | Think aloud. Clarify what was promised, by whom, and whether any deadline applies. Set the objective: the member's fix and a record they can trust. Name the owners across branch and contact centre, and who holds the fix. Approach: the member first, then the two owners. Metrics: time to fix and volume of repeats. Risks: the handover itself. Challenge one premise before committing. | The round's case. Scored on structure and reasoning more than on the right answer, so think aloud and say what you would ask first. |
| C6 | "Branch supervisors send us escalations, and the contact centre takes the rest. Where does your seam sit, and what happens when two of us disagree about who owns a complaint?" | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Propose seam principles, such as who holds the member until a named owner takes it. Do not pretend to know their seam. Make no claim about your past. | Peer Evaluator. The raising source is the JD's own line. Collegial, and scored for partnership fit. |
| C7 | "That complaint log work — how much of it was actually you?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold: restate the sentence and stay with the branch's log through two follow-ups. Concede in your words where your work stopped: the branch's log, not the wider process. | Pressure stem on F3. The hold is the sentence you gave; the concession is the limit it already has. |
| C8 | "How would you coach a branch supervisor on an escalation?" | JD | [grounded] JD: "coach branch supervisors on escalations"; your sentence: "trained new tellers on our escalation script" | Answer slot: if you coached a colleague on an escalation decision, say who and what you did. If no such step came up, say so and say how you would start, as a plan. Name no method you have not used. | F7 is transferability: the adjacent work is teller training. The answer is the honest limit plus the plan. |

Reverse questions for this round:

- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it is the reciprocity question for a peer panel, and it turns the interview toward what you would bring.
- "Where do escalations most often stall on the way to the contact centre?" Why it lands: it shows you are already thinking about the seam they run.
- "Which branch moves into a hub first, and what has been decided about its open complaints?" Why it lands: it asks about the strategy's consequences for the panel's own work.

## Requirement coverage

Every JD requirement maps to at least one question. None goes uncovered.

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | B10 |
| Own the member complaints process end to end across branches | C6, C7, C5 |
| and the contact centre | A7, B5, C5 |
| report monthly on complaint volumes and resolution times | B9 |
| coach branch supervisors on escalations | C8 |
| work with digital teams on self-service journeys | B7 |
| confident presenting to senior leaders | B6 |
| comfortable with Excel reporting | B9 |
| The four published values | C1 to C4; B2, B3, B4 |

## Upgrade menu

- The brief itself, not your summary → direct quotes replace the paraphrased strategy lines in B8 and the grounding brief, and the stale-framing check runs against the real document
- The panel members' names → persona weights per panel member and a tailored reverse question for each, from their public footprint
- The Head of Member Services' name → round 2 persona weights and a tailored reverse question
- An anonymised copy of the complaints spreadsheet, headers and formulas only, with no member data → F10 and B9 could rest on an inspectable artifact, so the Excel evidence could move from medium toward high
- Any contact-centre exposure, even as a referral process you watched → F4 moves from capability to transferability, and B5 and A7 gain a grounded answer
- Any presentation above branch level, even a team or regional slide pack → F9 gains a story, and B6 changes from a plan to a rehearsed answer
- Your notice period, pay expectations, location and reason for leaving, in your words → A3 to A6 are answered in your own figures; without them those slots stay as instructions
- The recruiter's brief for the 20-minute case, if one exists → C5 becomes a specific case instead of a generic one
- A tuesday-dossier.md from an earlier run → the prohibited list would rest on a confirmed record, not only on this material
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → recent organisational context and any published loop reports for this role family; say yes once if you want it
