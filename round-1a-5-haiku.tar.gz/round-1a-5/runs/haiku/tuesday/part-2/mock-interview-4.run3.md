Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-4-denied-c0a61559/quartzline_product-manager-platform-apis_interview_pack.md`.

It's built on the dossier you pasted, which is dated 14 August, more than three months ago. If the posting has changed, paste the current JD and I'll regenerate the fit snapshot. Web search was refused in this session, so the pack has no company values, interview-process or strategy research. Those sections are marked unavailable in its Sources.

Say the word and I'll play the Skeptic on A1, the objection your dossier named as the highest-ROI prep. I can also add a `pack_feedback` section to `tuesday-dossier.md` after a drill, but I'll write nothing until you ask. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Interviewer:** not named. **Round:** hiring-manager conversation, 45 minutes, Thursday. **Built on:** your job-underwriter dossier (generated 2026-08-14, dossier_version 1.1). **Changelog:** first pack.

## How to use + type key

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script.

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: role-driven; the stated responsibilities and qualifications, gaps included
- **CO**: company and strategy knowledge (not built: research did not run, see Sources)
- **CASE**: live problem from the role, delivered in the room

Labels: `[grounded]` traces to your dossier or the posting; `[inferred]` is derived from a low-confidence entry or the dossier's analysis; `[generic]` is a pattern with no claim about you or Quartzline.

Shorthand: **V1**, **V2**, **V3** are the dossier's `verified_candidate_evidence` entries 1 to 3, in order. **R1** to **R5** are the dossier's `role_profile` requirements, whose text stands as the posting's lines.

## Prep triage

Prep time is tonight; the interview is Thursday.

1. **A1**, aloud, three times, with its follow-ups. It is the objection the dossier named.
2. **A2** and **C1**: the two claims the hiring manager will check first, shipped products and the 30+ count.
3. **B1**: a 90-day sketch in the Case order (clarify, objective, segmentation, approach, metrics, risks).
4. Ask **RQ1** and **RQ2** in the room.

Everything else is insurance.

## 4. Fit snapshot

No hard gates: the dossier's `hard_gates` is empty.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | The material shows integration work, not product management time. Bridge at V1's own scope: "I led 30+ client integrations of the vendor's REST APIs, from scoping to go-live." Limit, said as the pack's observation: the material says integration work, not a product management role. Derivation: V1 at its own scope; the band is the dossier's grading of R1. |
| F2 | "Owning a roadmap and prioritization authority" — dossier R1 sub-claim, acknowledge_gap | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's `prohibited_claims` item "Having owned a product roadmap" and its `uncertain_or_weak_areas` acknowledge_gap entry: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past. No bridge. |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 is the integrating side of a vendor's APIs, not a platform built or shipped. Bridge at that scope only: "I led client integrations of the vendor's REST APIs." Observation, not words for you: the material does not show a product on the platform side. The dossier does not list R2 as uncertain; flagged for the underwriter to confirm. |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Wrote the internal integration playbook her team uses" — dossier V2 | high | [grounded] | discovery | The playbook may reach docs; the material does not show whether it covers schemas. Answer slot: what the playbook covers, and whether it reaches schemas or endpoint docs. If it does, say which; if it does not, say so and say what you would check first. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1, "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Client and product stakeholders are in your material; sales is not. Bridge at scope, with V3's caveat named: confirmed, limited inspectable proof, expect a probe. Answer slot on sales: if you worked with sales on any integration, say how; if not, say so. |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [inferred] | discovery | Clarify. The material shows no agile work either way; no verified entry speaks to R5 directly. Answer slot: "Agile delivery inside a product org." If you worked that way, say how; if not, say so and say what you would want to confirm about how this team defines it. Derivation: the dossier grades R5 low, so no claim is asserted. |

## 8. Persona table

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic. No interviewer profile exists, so no interviewer-signal adjustments apply. The loop is your own account of one 45-minute conversation, so no archetype fallback is used. Depth follows weight: 5, 4, 3, 3, 2, 2, 0.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the PM title, the roadmap, the shipped-product claim | High, 5 questions. The dossier's named objection is the Skeptic's most predictable line, and a hiring manager is buying derisked capability | Rehearse A1 until it is boring; bridges only from quoted entries, with the limit named |
| Case/Strategist | Live roadmap problems from the posting | High, 4 questions. The posting gives the roadmap, two squads and adoption metrics as live work | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |
| Data-Driven Prober | Counts the 30+ integrations; asks how the sessions worked | Medium, 3 questions. The two headline claims, V1 and V3, are the probe targets | Say what you can and cannot say about how each was counted |
| Pressure | "How much of that was actually you?" | Medium, 3 questions. A hold-then-concede test; lower prior for this round than the Skeptic | Hold through two follow-ups; concede the specific part, never the core claim |
| Values/Behavioral | Open prompts on stakeholder work | Low, 2 questions. No values round is detected; one behavioral theme comes from the posting's stakeholder line | Selection scaffold ending in its honest branch; "we" for context, "I" for what you did |
| Conversational | Casual opener; casual questions on the posting's topics | Low to medium, 2 questions. Openers are scored | A 90-second arc built only from quoted entries |
| Peer Evaluator | Seam and credit probes | Not weighted: this is not a peer round | None |

## 9. Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap"; dossier acknowledge_gap, R1 sub-claim; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Highest-ROI rehearsal. Open with the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge at its own scope, limit spoken: "I led 30+ client integrations of the vendor's REST APIs, from scoping to go-live." Then a ramp plan, said as a plan: what you would do in your first 90 days on the roadmap. Hold the bridge through two follow-ups by returning to the integrations; never add to it. Answer slot on the sessions: if you set any priorities from them, say which; if you did not, say so plainly. | The dossier named this objection. Its negatives are the dossier's own prohibited items and acknowledge_gap entry, so it is asked as written. The bridge is R1 at bridge strategy, never roadmap ownership. |
| A2 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you did in those words: you led client integrations of the vendor's REST APIs. Describe no product on the platform side. Answer slot: if you shipped any API surface yourself, say what it was and who it served; if you did not, say so and say which of those integrations is closest to it. | F3, must_have R2. The limit is the integrating side of an API, not a built product. |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `prohibited_claims`: "Having owned a product roadmap"; posting line "Define and track adoption metrics" | Name roadmap ownership first, since that is the acknowledged gap, then A1's plain acknowledgment. Then name adoption metrics and a plan to get a baseline, said as a plan. | Stem from the Skeptic persona; tests honest self-assessment. The adoption line is from the dossier's posting lines. |
| A4 | "How have you worked with agile delivery inside a product org?" | JD | [inferred] derived from dossier R5, graded low; no verified entry speaks to it | Clarify. Answer slot: if you worked in an agile product team, say how; if you did not, say so, and say what you would want to confirm about how this team defines agile. Quote nothing. | R5 is preferred and graded low. Clarify strategy: the evidence may exist but was not established. |
| A5 | "How would you know whether partner API adoption is working?" | JD | [grounded] "Define and track adoption metrics" — posting line | Say how you would define adoption and what you would check first, which is the baseline. Make no claim about a current metric. Answer slot: if you have defined adoption metrics before, say which; if not, say so and name the baseline you would ask for first. | The posting names adoption as a responsibility, and the dossier has no current baseline. |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch your first 90 days owning the partner-facing API roadmap. What do you need to know first?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" — posting line | Clarify, objective, segmentation (which partners, which integrations), approach, metrics, risks. Ask first who holds the sequencing decision and what the adoption baseline is. Presupposes nothing about your past. | The posting's first responsibility, as a live problem. No claim about you, so the label stands alone. |
| B2 | "Partner API adoption fell 20% over one quarter. Diagnose it." | CASE | [generic] hypothetical; the 20% is a case figure, not a fact about Quartzline | Clarify whether the 20% is of active partners or of calls. Segment by partner tier and integration age. Separate a real drop from a change in how adoption is counted. Say what you would check first. Invent no baseline. | Tests the posting's adoption metrics. The dossier records no current baseline, so the first question is the baseline. |
| B3 | "Two engineering squads want different sequencing for the same partner integration. Whose call is it?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" — posting line | Do not propose a sequence first. Ask who holds the sequencing decision, then say how you would bring a recommendation to them. Do not claim you have decided squad sequencing. | Decision authority is the dossier's unverified question, and the conditional_go depends on it. The guidance asserts no squad prioritization. |
| B4 | "Pick one adoption metric for a partner-facing API. What would it hide?" | CASE | [grounded] "Define and track adoption metrics" — posting line | Name the metric and its denominator. Then say what it hides: partners who connected and stopped, and integrations that work but go unused. | Metric discipline for the Case persona. No claim about you. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30+ integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slot, in your own words: how you counted them, what the count is sensitive to (what counts as end-to-end), the assumption you would defend least, and which of those integrations you led. The pack supplies no counting method. | The headline figure. A prober's first target. |
| C2 | "Walk me through how the quarterly roadmap-input sessions worked, and how you would know whether they had any effect." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell it in the quote's terms: quarterly, client evidence, to product. Answer slot: if you can name a decision the evidence changed, say which; if you cannot, say so plainly. Medium confidence: expect the probe on whether any effect can be shown. | V3 is medium and the question presupposes no outcome. |
| C3 | "How do you know the integration playbook is in use, and what would you count to find out?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say it is the playbook your team uses, in the quote's words. Answer slot: what you would count to find out whether it is in use; if you have measured it, say what. Never describe a measure you did not track. | Probes the playbook, the inspectable proof for F4. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold: the integrations, in the quote's words, as the work you can show. Concede: the PM title and roadmap ownership, plainly, in A1's acknowledgment words. Never fold the integration claim. | A time-boxed version of A1 with the same hold. |
| D2 | "That's 30+ integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold: you led them, from scoping to go-live, in the quote's word. Concede only the parts that were not yours, named in your own words. If none were, say you led them. Answer slot: which of scoping, requirements, architecture, UAT and go-live you ran yourself. | Attribution pressure. The slot names only the quote's beats. |
| D3 | "If you and a squad lead disagree on what ships next, whose call is it?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" and "Write specs and drive delivery with two engineering squads" — posting lines | Hold a position: the recommendation you would bring, and who you would want to decide. Concede where the decision sits if the squad leads own it. Never claim you decide. Hold through two follow-ups. | Decision authority again, under pressure. The guidance asserts no squad prioritization. |

### E. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to get engineering and customers to agree on scope." | VAL | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration. Tell it in the quote's beats in order: scoping, requirements, UAT, go-live. Answer slot: if the scope disagreement was with engineers or with customers, say which; if none came up, say so and give the nearest integration. "We" for context, "I" for what you did. | Stakeholder theme from R4. An open prompt, so its theme comes from the posting. No values round is detected. |
| E2 | "Tell me about a time a client's request and your team's plan conflicted." | VAL | [generic] selection scaffold: pick a time a client pushed back on scope, with a named stake, a point you did not fold, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest integration your material carries, or how you would handle it. | Selection scaffold. No claim about you. | No quoted sentence carries this story, so it is a scaffold, not a mapping. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integrations (V1), the playbook (V2), the roadmap-input sessions at medium confidence (V3). If asked about the PM title, give A1's acknowledgment. Do not open with a title. | A casual opener is scored. The arc is built from quotes only. |
| F2 | "What are you working with in API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: say whether the playbook reached docs or schemas, in your own words; if it did not, say so. | R3, asked casually and scored. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1, 3+ years PM experience | A1, A3, F1 |
| R1 sub-claim, owning a roadmap | A1, A3, D3 |
| R2, shipped API or platform products | A2, D1 |
| R3, API docs and schemas | C3, F2 |
| R4, stakeholder management | E1, B3, D3 |
| R5, agile delivery | A4 |
| Posting: own the partner-facing roadmap | B1 |
| Posting: two engineering squads | B3, D3 |
| Posting: define and track adoption metrics | A5, B2, B4 |
| Posting: run discovery with integration partners | none, and why: no quoted entry touches partner discovery; it is listed under the prohibited list |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's first employer question. It tests decision authority, the one thing the conditional_go requires you to verify. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | No baseline is on record. The answer tells you whether the adoption line is a number or a hope. |
| RQ3 | "Which integration partners matter most over the next two quarters, and what is blocking them?" | Shows you would start from partner problems, which is the discovery the posting describes. |
| RQ4 | "Where do handoffs between the two squads on partner work tend to slow down?" | Tests the squad structure behind the two-squad line, from the people who live with it. |
| RQ5 | "What would you want the person in this role to have finished in their first six months?" | Surfaces the success criteria, which the posting does not state. |

## 13. Prohibited claims

Built from the dossier's `prohibited_claims` and `uncertain_or_weak_areas`, and from the inflated forms this pack found. Every cell in this pack is held to this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment from the dossier's own item: "I haven't held a product manager title or role." No slot. |
| Having owned a product roadmap | Dossier `prohibited_claims` and acknowledge_gap | "I haven't owned a product roadmap." Then a ramp plan, said as a plan. |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." No slot names it. |
| Shipped API or platform products | Inflated form of V1 | V1 at its own scope. Observation, not words for you: the material says integrating a vendor's APIs, not shipping a platform. No first-person negative. |
| Ran partner discovery | Inflated form of V3, widened from the posting's "Run discovery with integration partners" | V3 at its own scope. Observation: the material says roadmap-input sessions with client evidence, not partner discovery. |

## 14. Sources

- **Provided documents:** your `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14), pasted into this conversation. Consumed sections: `role_profile`, `handoff_to_mock_interview`, and `decision` as context. The dossier is over three months old, and the posting may have changed since.
- **Searches sent (all refused; the search permission was not granted):** "Quartzline values"; "Quartzline interview process product manager platform APIs"; "Quartzline strategy news." No fetches were attempted.

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | No values cheat sheet. No values round is detected, so this would have moved only VAL theming. The search was refused. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure. Your own account establishes one 45-minute conversation with the hiring manager, so the persona weights rest on that. A loop source would confirm it. The search was refused. |
| 3. Quartzline strategy and recent news | unavailable | The CO bank and the strategy-grounded differentiator questions. None were written, so no CO questions appear. The search was refused. |
| 4. Interviewer name with Quartzline | n/a | No interviewer name was given. |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` fixes the requirements and the JD-tagged questions. |

Sections dropped by condition: interviewer read (no interviewer), values cheat sheet (no values round), grounding brief (no research ran), graded deliverables (none declared), delivery coaching (no assessment).

## 15. Upgrade menu

- **Web search permission for this session:** runs L1 research on values, the interview process and strategy. The CO questions move from `[generic]` to `[grounded]`, and the loop is confirmed by a source.
- **Deeper research, offered once:** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief for the CASE questions.
- **The interviewer's name:** a tailored reverse question, and persona weights from their public footprint.
- **The current posting, if it has changed since 14 August:** regenerates the fit snapshot and the coverage rows for R1 to R5.
- **Your CV or resume:** gives E1 and E2 grounded stories beyond the dossier's three entries, and tests whether F1 can carry more.
- **Any note on what the 45 minutes will cover:** reweights the persona table. A technical deep dive, for example, moves the Prober up.
