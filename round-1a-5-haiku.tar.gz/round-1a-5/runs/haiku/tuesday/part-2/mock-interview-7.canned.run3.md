Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-7-canned-e8cdc716/47166ad2-6b18-4f4e-bbb8-507cb5102da4/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for the 60-minute hiring-manager round, since the company's careers page says that's the format: a live-incident tabletop, then a values conversation.

The main things to prepare:

- **B2 is the highest-ROI prep.** The JD asks you to coordinate design, art, engineering and community on each update. Your material doesn't show that. Have an honest answer ready for the last update you coordinated, or say plainly that you haven't yet and how you'd set one up.
- **Don't claim leadership.** You've said you never led a team, so coordinate without ever saying you led. The same goes for owning the KPIs: you presented the retention numbers, which is not the same as owning the post-event review.
- **Use the checklist.** Tobias's public GDC 2026 talk (from a search snippet, not a full read) argues that patch notes should describe what actually shipped. Your release checklist is the strongest link to that, so bring it into your answers in your own words.
- **Name the in-app purchase gap yourself.** Say "I haven't worked on a game with in-app purchases" and then how you'd learn it. Don't wait to be asked.
- **Values:** the company's three values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. You have a quoted story for the checklist. For Players Before Plans, you don't yet, so decide now what you'd say if asked.

Things I didn't do: I didn't ask you any questions, because nothing you could answer would change the pack. Prep time wasn't given, so there's no schedule. Research was L1: four searches and two page fetches. The values and interview-process findings came from the company's own pages. The interviewer and strategy results are search snippets only, and I didn't claim anything from them beyond what the snippets say.

Offers: I can play Tobias on B2 or the Outage Hour, and I can save a tuesday-dossier.md recording the gaps this prep exposed. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is also available if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**For:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (hiring manager)
**Round:** One 60-minute "Outage Hour" with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home (saltmarshgames.com/careers/interviewing).
**Built on:** your message, the JD you pasted, and L1 research (below). This is a first build; there is no prior version to regenerate.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: CASE (live problem), JD (role requirement), VAL (published value), EXP (your past work), CO (company knowledge).
- Guidance is scaffolding, not a script. Speak it in your own words, and rehearse out loud.
- Question IDs are letter-by-persona (A1, B2 and so on). Answer slots are instructions for the interview: they are not questions to answer here.

## Fit snapshot

Requirements are the JD's own words. Evidence is your own sentences, quoted from your message. Gap types follow the routing rule in the template.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title and content drops, not live events on two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything beyond content drops, or handled more than one title, say what and how; if you did not, say so and say how you would plan two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none given | [grounded] | discovery | Your material does not show cross-team coordination on an update. Answer slot: describe the last update you coordinated across those teams, in your own words; if you did not coordinate one, say so and describe how you would. Do not describe it as leading those teams: you have said you never led a team (F9). |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning the review and the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers were reported, or ran any review of an event, say what and how; if not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The checklist is in use by QA, which is the requirement's own shape. Lead with the checklist in your words: you wrote it, and QA still uses it. Expect a probe on what it has caught. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Years and a producing title are adjacent. Your material does not say the title was live-service by name. Words: "I was an associate producer at a puzzle-game studio for four years." Do not describe the title as live-service unless you can say why in your own terms. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on how the calendar was decided. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote shows exposure to retention numbers at the studio-head level. Its bridge rewords only that quote. Do not describe your comfort with the metric's method beyond what you did with it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Written artefact in daily use. No written exercise is announced for this round; the checklist is your evidence. |
| F9 | "Never led a team" (your message) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own stated absence. Words: "I haven't led a team." Then how you would coordinate without line authority, said as a plan. |
| F10 | in-app purchases (not in the JD; your stated absence) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Your own stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the economics, said as a plan. |

Gate check: no requirement in the JD is a term you can fail on location, authorisation, pay or schedule. None is marked hard_gate.

## Prohibited claims

Not coached in any slot, answer or drill feedback. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one main title's content-drop calendar. This limit is the pack's observation, not words for you. |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the numbers. |
| Led design, art, engineering and community | Inflated form of F2, plus F9 | Say you coordinated, if you did. Never say you led. |
| Has run in-app purchase economics | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No slot. |
| Describes the puzzle title as live-service | Inflated form of F5 | F5's quote at its own scope. |

## Interviewer read

- **Tobias Wrenfield**, Head of Live Operations at Saltmarsh Games. A search snippet (not fetched) describes a GDC 2026 talk, "Patch Notes Are a Promise", and notes Tobias was previously a QA lead at a console studio. The talk's argument: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  - Tobias's public argument lines up with your release checklist (F4). Bring the checklist into your answers, in your own words, as the place where "what shipped" gets checked.
  - Tobias came up through QA. Expect precise questions about the release gate and about what QA signs off on.
  - Do not build on any shared background. Speak to the work.
- **Mirror opportunity (professional path only):** Tobias moved from QA into live operations. Your release-checklist work sits on the QA side of that path. Quote F4 exactly in any reference to it; do not summarise it.

## Persona table

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead (the template's relationship priors). The Outage Hour loop source documents a values conversation, so Values/Behavioral is weighted up from the prior. Interviewer signals adjust Case toward release and QA mechanics.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and questions |
|---|---|---|---|---|
| Case/Strategist | A simulated outage during a live event, then a plan | High: the Outage Hour is a live-incident tabletop (company page) | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud | 5, so A1 to A5 |
| Values/Behavioral | A values conversation mapped to the three published values | Certain: the loop source documents it | Map to a value with a quoted sentence where one exists; a selection scaffold with an honest branch where none does | 5, so C1 to C5 |
| Skeptic | Probes the gaps: two titles, coordination, leading teams, in-app purchases | High: the JD and your stated gaps are the obvious probes | Rehearse the single most predictable objection (B2) until it is boring. Concede precisely | 4, so B1 to B4 |
| Pressure | Time-boxed challenge to a headline claim | Medium: a hiring manager may test composure on the retention figure | Pause, restate, hold two follow-ups, then concede specifically | 2, so D1 and D2 |
| Conversational | A friendly opener that is still scored | Medium: typical opener | Pre-scripted 90-second arc from your quotes | 2, so E1 and E2 |

## Question banks

### Persona A: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running, and a reward grant is applying twice to some players. Walk me through the first thirty minutes." | CASE | [generic] | Clarify scope and who is affected. Set the objective: stop the bleed, then fix. Name who you bring in: engineering on the grant, QA on the checklist, community on the message. Name the metric you watch. Say the risk of rollback before you say it. No claim about your past. | The outage tabletop from the company's process page. Generic because it is a pattern for the problem. |
| A2 | "The release is tomorrow and QA finds a blocker on the checklist. Who decides, and what do you tell the community team?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify who owns the go or no-go. State your default, then the exception. Tell community what is built, not what is hoped. Answer slot: if you have held a release over a checklist blocker, say what happened; if not, say how you would decide. | F4 is the checklist; the decision is the interview's, so the answer slot stays inside F4's quote. |
| A3 | "The JD asks for a calendar for two titles. What would you need to know before planning the first season?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Ask about each title's cadence, the teams each drop needs, and the metrics that would tell you it worked. Say what you would not decide until you knew them. Do not assume the two titles' details. | The JD line is the raising source. Context from the company's September 2026 news (a shared events calendar from February 2027) is background in the rationale only, not asserted as the role's facts. |
| A4 | "A live event came in a few points under its retention target. Walk me through your post-event review." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name the review's inputs, the denominator, the cohort, and the assumption you would test first. Say what you would change in the next event. Speak to the review as a process you would run, not one you ran. | F3 is the adjacent evidence, so this stays a plan, not a past. |
| A5 | "Walk me through the content-drop calendar you ran: how did you decide what went into each week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: the calendar, the two years, the weekly cadence. Answer slot: if you set the criteria for what went in, say what they were; if the calendar was set by others, say so plainly and describe your part. | Premised on F6's quote only: the calendar existed. How it was decided is not in the quote, so it is an answer slot. |

### Persona B: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for two titles. Which would you run first, and what would you need to know?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Choose one, say why, and name the two things you would need to know. Do not claim two titles of experience. | F1's gap, rehearsed as a choice rather than a confession. |
| B2 | "The JD asks you to coordinate design, art, engineering and community on each update. Walk me through the last update you coordinated across those teams." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | **Highest-ROI prep in this pack.** This objection is near-certain in some form. Answer slot: if you coordinated an update across those teams, say which teams, what you asked of each, and what you did yourself; if you did not, say so plainly and describe how you would set up the first one. Hold through two follow-ups by returning to what you did, not by adding to it. | F2 is discovery: your material is silent on coordination, so the second branch must be honest. Deepest rehearsal here. |
| B3 | "You have said you have never led a team. This role coordinates four. What is the difference, and where would you struggle?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Concede the gap in one sentence, then move to how you coordinate without line authority: decisions in writing, a named owner per workstream. | F9, the stated absence. The concession is exact; never a claim of leadership. |
| B4 | "You have not worked on a game with in-app purchases. What would you want to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Acknowledge once: "I haven't worked on a game with in-app purchases." Then name what you would learn first (the economy, the drop cadence against spend). Say it as a plan. | F10. The company's season-pass move (news item) is background only: do not claim it as this role's fact. |

### Persona C: Values/Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you chose the players over the calendar." | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (values page) | Selection scaffold: pick a time a planned drop and player feedback disagreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No quote of yours carries this story. | Players Before Plans is a published value; no sentence of yours supports a story, so the honest branch is the open-prompt form. |
| C2 | "Tell me about the release checklist you wrote and how it's used now." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F4, to Ship the Patch Not the Promise and Leave the Build Greener. Beats: you wrote it; QA still uses it. Answer slot: if it caught something, say what; if you don't know, say so. | The values page: "every release leaves the codebase and the checklist better than it found them." |
| C3 | "Tell me about a time an announcement got ahead of what was built." | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (values page) | Selection scaffold: pick a time a message promised more than shipped. If none comes to mind, say so, then give the nearest thing your material does carry (C2's checklist), or how you would handle it. | Tobias's public talk theme; the value is the one the interview tests. |
| C4 | "Tell me about a time you had to say no to a team on an update." | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (values page) | Selection scaffold: pick a time you held a line against a team's preference for the player's sake. Name the stake and what you did. If none applies, say so and give the nearest case. | Covers the values page's player-first principle from a second angle; no past claim is supplied. |
| C5 | "Tell me about a time a player-facing number moved the wrong way after an update. What did you do?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Story-mapped on F7: the numbers you presented. Answer slot: how the number was counted, the assumption you would defend least, and which part was yours. If you did not act on the number, say so plainly. | Premised on F7's quote, so the number exists; its method is not in the quote, so it is a slot. |

### Persona D: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a live-events calendar for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause. Restate: one main title, two years, weekly content drops. Hold through two follow-ups. Concede exactly: you have not run two titles. | F1 under time pressure. Hold on what you did, concede on the one gap. |
| D2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: you presented the numbers. Answer slot: how the figure was counted, the assumption you would defend least, and what part was yours. If it was not yours, say so plainly. | F7. Premised on the quote's presenting, not on owning the result. |

### Persona E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Ninety-second arc: the studio, the calendar, the checklist, the retention numbers. Say "I" for what you did and "we" for the team. Stop at the number. | Casual register, scored against JD requirements R5 and R6. |
| E2 | "What's the most interesting live-ops problem you've seen this year?" | JD | [generic] | Pick one, state the problem, the decision, the result you can defend. Keep it short. No claim you cannot repeat. | Generic opener; scored for communication economy. |

## Values cheat sheet

Values from the company's official page (saltmarshgames.com/values). Mapping uses the fit-snapshot rows.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your quotes carries a player-first decision. Selection scaffold, C1, with its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4: "Wrote the release checklist our QA team still uses." C2 and C3 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: the checklist. C2 |

## Reverse questions

1. "The Outage Hour is a tabletop during a live event. What is the one decision in it you most want candidates to get right?" Why it lands: shows you read the format and want to be judged on the decision, not the answer.
2. "You came into live ops from QA. What did that change about how you want a producer to bring you an update?" Why it lands: ties to Tobias's own path, turning a motivation probe into a peer conversation.
3. "The JD asks for two titles. Which decision on the calendar is still open?" Why it lands: names the role's central problem and asks for the open decision, not a sales pitch.
4. "What does Ship the Patch Not the Promise look like in a planning meeting here?" Why it lands: asks for the value in practice, which is the thing the values round tests.
5. "What would make the first ninety days in this role a success for you?" Why it lands: a hiring-manager question that shows you think about outcomes, not tasks.

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, B1, D1 | |
| Coordinate design, art, engineering and community teams on each update | A1, B2, B3 | |
| Own the post-event review and the KPIs it reports | A4, C5, D2 | |
| Manage the release checklist with QA | A2, C2 | |
| 3+ years producing live-service games or apps | E1, B4 | Years are a fact; the live-service qualifier is not in your material |
| Experience running a content calendar | A5, D1 | |
| Comfortable with player-retention metrics | C5, D2 | |
| Clear written communication | C2 | No written exercise is announced; the checklist is your evidence |

## Sources

**Provided documents:** your message (background, gaps, and the five sentences quoted above); the JD text you pasted.

**Research tier: L1; searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh games values | yes | Values cheat sheet: three published values by name, from the fetched official page |
| 2. saltmarsh games interview process live operations producer | yes | Round structure: one 60-minute Outage Hour with the hiring manager, a tabletop then a values conversation; no take-home. Documents a values round, so the values bank is included. Persona weights follow it |
| 3. saltmarsh games strategy news | yes | Background for A3 and B4 only: a September 2026 item on a shared events calendar from February 2027 for two named titles (search snippet, not fetched). Not asserted as this role's titles |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read: a GDC 2026 talk title and role (search snippet, not fetched) |
| 5. representative live operations producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

Queries sent, each returned a result: "Saltmarsh Games values" (official page returned); "Saltmarsh Games interview process live operations producer" (official careers page); "Saltmarsh Games strategy news" (official news item); "Tobias Wrenfield Saltmarsh Games" (one result, a talk listing). Fetched: saltmarshgames.com/values; saltmarshgames.com/careers/interviewing.

## Upgrade menu

- Your own event numbers, and how each was counted → defend-the-number slots on F3 and F7, and sharper answers to A5, C5 and D2
- Any live-event work beyond content drops, or any update you coordinated across design, art, engineering and community → F2 and F1 move from discovery and transferability to grounded, and B2 gets a story
- Any post-event review you ran yourself → F3 gets a grounded quote and A4 a story
- Whether the Friday interview is the only session → confirms session mode; if there is a second round, a per-round pack
- L2 deep research, offered once: a strategy brief, Tobias's other talks and writing, and role-family loop reports. Up to 6 more searches and 2 more fetches, several more minutes. Want it?
- Named-interviewer footprint is already in; more of Tobias's talks would make the interviewer read sharper

## Drill and dossier offers

Drill: I can play Tobias on B2, the highest-ROI question, or on the Outage Hour (A1), with follow-ups that react to what you say.
Dossier: I can save a tuesday-dossier.md recording the gaps this prep exposed (F2, F9, F10) for later sessions.
