I've built a first-pass prep pack, but it is generic. I couldn't research Stripe, so nothing in it about their values, interview loop or strategy is verified.

Web search was refused in this session, so three searches returned nothing. I also don't have your CV or the job description, so every question is a general Product Operations question rather than one tied to your history or the posting.

The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-3-denied-c0b41064/34fda316-6b09-4568-ab0b-3997cf7261bc/scratchpad/stripe_product_operations_manager_interview_pack.md`. It has 20 questions across six interviewer styles, with reverse questions and a source log.

Where to start, even before the pack is complete:
- **Live operations problems.** Final rounds often include one, so rehearse a launch slipping, a queue doubling and a metric dropping, saying your clarifying questions aloud first.
- **Your own metrics.** For any number you cite, know how it was counted and which assumption you'd defend least.
- **"What would you be weakest at on day one?"** This is the most likely hard question. Name one real gap and how you'd close it.

Three questions so I can make the pack specific:
1. Who is in the final round, and what is their relationship to you (hiring manager, peer, cross-functional partner, a panel)? Is it one session or several?
2. Can you paste the job description and your CV? Or say "go without," and I'll keep the generic version.
3. Does the posting state any location, work-authorization or schedule requirements?

If you allow web search, I can retry the Stripe research (values, interview process, current strategy) next turn.

Want a live drill? Name a persona and I'll run it with follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round. Interview prep pack

**Changelog:** first version. Built with no CV, no job description and no research, because web search was refused in this session. Every question is `[generic]`; nothing here is about Stripe specifically.

## 1. How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Guidance is scaffolding, not a script. Rehearse in your own words.
- Type tags: **CASE** live problem · **EXP** your past work · **JD** the stated role · **CO** company knowledge · **VAL** published values.

## 2. Fit snapshot (worksheet variant)

No CV or job description was supplied, so no row has an evidence quote. Every evidence cell is `none given`, so the table holds the role-family requirements only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Define and track operating metrics for a process (role family) | none given | none | [generic] | discovery | Answer slot: name one metric you defined and tracked, how you defined it, and what it was sensitive to. If you have not defined one, say so and say how you would define it first |
| F2 | Design a cross-functional process that several teams use (role family) | none given | none | [generic] | discovery | Answer slot: name one process you designed or ran with more than one team, and say which part was yours. If none was yours, say so and describe how you would approach it |
| F3 | Keep a process working as volume grows (role family) | none given | none | [generic] | discovery | Answer slot: name one time a process you were responsible for had to scale, and what you changed. If there was no such time, say so and describe what you would watch for first |
| F4 | Work with product, engineering, finance and legal without direct authority (role family) | none given | none | [generic] | discovery | Answer slot: name one disagreement with a team that did not report to you, and how it ended. If there was none, say so and describe how you would handle one |

Gate rows (location, work authorization, schedule) are not included, because no posting was supplied to show whether Stripe states any. See question (3) in the message.

## 3. Persona table

Relationship is unknown and the round structure is unknown. Weights are therefore flat, which is noticeably weaker than a pack built from the real loop. The final may be several sessions, so the weights are blended across them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live ops problem: a launch slipping, a queue doubling | High. Ops finals commonly include a live problem. This is a role-family pattern, not a fact about this loop | Clarify the goal, then structure, then answer. Name the metric you would watch |
| Data-Driven Prober | Asks how a number was counted and what it assumed | High. Anyone can be asked about a metric they cite | Say how you counted, and name the weakest assumption before they do |
| Peer Evaluator | Seams between teams, disagreement, credit | Medium. Common when an ops role sits between teams | Offer what you bring their team, not only what you need |
| Skeptic | Quiet probing of where you are weakest | Medium. Always worth rehearsing, since the skeptic's question lands hardest on the weakest area | Give one specific weakness and a plan to close it. Do not bluff |
| Values / Behavioral | Scenario questions about past behavior | Low to medium. No values page was read, so no values round is detected | Use "we" for context and "I" for what you did |
| Pressure | Interrupts, time-boxes, challenges a claim | Medium. Final rounds sometimes test composure | Pause, restate the question, hold a position through two follow-ups, then concede only what is actually uncertain |
| Conversational | Friendly openers that are still scored | Medium. Casual questions are scored too | Have a 90-second arc ready for "walk me through your path" |

## 4. Prohibited claims

No candidate sentences were supplied, so no quote exists to stretch. There are no inflated-form entries and no negatives to acknowledge. This list will be built once a CV is in. Until then, do not say you led, owned, built or reduced anything unless you can point to it.

## 5. Question banks

Each row's Provenance is `[generic]` because none of these questions rests on a claim about you. The guidance does not supply any fact about your history.

### Case / Strategist (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is two weeks from go-live and a dependency has slipped. What do you do?" | CASE | [generic] | Clarify what the launch must do and what slipping costs. Lay out options (cut scope, delay, ring-fence the critical path). Name who decides, and what you would watch once it ships | Typical ops live problem. Tests structure before answer |
| A2 | "An internal request queue doubled in one quarter. Diagnose it and propose a plan." | CASE | [generic] | Ask what changed: volume, mix, or time to close. Segment before you propose. Name one measure you would add | Tests segmentation and whether you clarify first |
| A3 | "Fifteen teams send you requests. How would you decide what gets done this quarter?" | CASE | [generic] | State the criteria first (impact, effort, risk), then the intake and review rhythm. Say what you would say no to | Tests prioritization and the judgment to decline |
| A4 | "A key metric dropped 15 percent week over week. Walk me through how you would diagnose it." | CASE | [generic] | Check whether the drop is real: definition change, data gap, or seasonality. Then segment, then test one hypothesis at a time | Tests metric diagnosis, the most common ops probe |

### Data-Driven Prober (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you chose to track. How did you define it, and which assumption would you defend least?" | EXP | [generic] | Pick a metric you actually tracked. Give its definition, the denominator, and the weakest assumption in your own words. Answer slot: if you did not define it yourself, say so plainly and describe how you would define one | Open prompt. Tests whether you know your own numbers |
| B2 | "Which number from your last role would an analyst question first, and why?" | EXP | [generic] | Name a number you can explain end to end. Say where it could be wrong before they say it | Open prompt. Tests self-critique |
| B3 | "How would you know whether a process you put in place actually worked?" | EXP | [generic] | Name the before-and-after measure and the comparison you would use. Answer slot: if you did not measure it, say so and say what you would measure | Open prompt. Tests evaluation thinking |
| B4 | "Tell me about a decision you made on incomplete data. What did you check?" | EXP | [generic] | Choose a real decision. Say what you checked, what you could not check, and how you would revisit it | Open prompt. Tests judgment under uncertainty |

### Peer Evaluator (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our engineering and data teams sit side by side. Where is the seam with your work, and what happens when you disagree?" | JD | [generic] | Propose principles for the seam (who owns intake, who decides priority) rather than claiming to know it. Give one disagreement and how it ended | Peer probe. Tests turf awareness and disagreement style |
| C2 | "How do you handle credit when a process spans three teams?" | JD | [generic] | Name the teams and what each contributed. Say how you made their part visible | Peer probe. Tests collaboration habits |
| C3 | "What would you need from my team to make your work easier, and what could you bring to it?" | JD | [generic] | Give one specific need and one specific offer. Keep the offer to what you would really do | Reciprocity. Peers weigh whether a hire adds to their load |

### Skeptic (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area specifically. Say what you would do to close it in the first month. Do not bluff competence you lack | The most likely objection to any candidate. Highest-ROI rehearsal in a pack with no CV |
| D2 | "Why are you leaving your current role, and why this one, now?" | EXP | [generic] | Give your own reason in your own words. Keep it to what you would say to a colleague. Do not criticize a past employer | Motivation consistency. Rehearse one clean answer |
| D3 | "Ops work often has a trust gap with product teams. How would you build trust with a team that does not report to you?" | JD | [generic] | Describe a method: shared goals, a fast first win, a standing check-in. Say how you would know it was working | Tests influence without authority. The premise is a generic role pattern, not a fact about this team |

### Values / Behavioral (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a real instance. Say what the truth was, how you delivered it, and how it landed. Say "we" for context and "I" for what you did | Open prompt. No published values were read, so this is a generic behavioral probe |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose one real example. Name the metric you gave up and why. If none comes to mind, say so and describe the nearest case | Open prompt. Generic. A values page would sharpen it |

### Pressure (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has already done this exact job?" | JD | [generic] | Pause. Restate the question. Give the strongest honest case in your own words. Hold through two follow-ups. Concede only what is actually uncertain | Composure test. Hold-then-concede structure |
| F2 | "That's a big claim. How much of it was actually you?" | EXP | [generic] | Answer with what you did, not the team's result. Name the part that was yours and the part that was not. Do not inflate to win the exchange | Attribution honesty under pressure |

### Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your path into operations." | JD | [generic] | A 90-second arc: where you started, what you ran, what you would do next. Keep it to what you actually did | Casual opener that is still scored |
| G2 | "What process tool have you been reading about lately?" | CO | [generic] | Name one tool you have actually used or evaluated, and say what you would want to test first | Casual, but it probes genuine interest and current practice |

**Coverage line.** No job description was supplied, so there are no requirements to map. Add the JD to produce this table.

## 6. Reverse questions

Each has a one-line "why it lands." No interviewer profile exists, so none is tied to a career path.

- **R1.** "What does a strong first 90 days look like in this role, and how will it be measured?" *Why it lands:* shows you think in outcomes, not tasks.
- **R2.** "Which decision in this team's last quarter would have gone differently with better operations support?" *Why it lands:* turns a generic question into a specific one about their work.
- **R3.** "How are operations requests prioritized across product, finance and support?" *Why it lands:* tests your grasp of intake, the seam most ops roles live in.
- **R4.** "What is the hardest thing this team is trying to get right over the next six months?" *Why it lands:* invites them to name the real problem.
- **R5.** "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* a reciprocity question. Peers weigh whether a hire adds to their load.
- **R6.** "What would make you say in a year that hiring me was the right call?" *Why it lands:* asks for the success criteria directly.

## 7. Sources

**Provided documents:** none. The message named the company and role only.

**Searches and fetches sent:**

- "Stripe company values principles": refused (permission not granted).
- "Stripe interview process final round operations manager": refused (permission not granted).
- "Stripe strategy 2026 news": refused (permission not granted).

No result came back from any call. Nothing in this pack about Stripe's values, loop, or strategy is established.

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2. All three searches were refused, so none returned.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Not built: no published values in hand |
| 2. `Stripe interview process` | unavailable | Loop structure and persona weights. The weights here are flat, a generic fallback |
| 3. `Stripe strategy` / recent news | unavailable | CO bank and grounding brief. The CO question here is generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have supplied fit-snapshot requirements and JD-tagged questions. No search was sent |

## 8. Upgrade menu

- **Your CV or résumé text** → the fit snapshot gets real quotes, the bank questions get grounded guidance, and the defend-the-number slots appear for any metric you cite.
- **The job description** → JD-tagged questions, a requirement-coverage line, and any location, work-authorization or schedule terms as gate rows.
- **Round structure (how many sessions in the final, and who is in each)** → session-level mini-packs with persona weights set by each interviewer's relationship to you.
- **Web search permission** → Stripe's values, interview loop, and current strategy, the three targets this run could not reach. Allow search and the next turn can run them.
- **Interviewer names** → tailored reverse questions and persona weights read from their public footprint.
- **A `tuesday-dossier.md` from an earlier session** → verified evidence and prohibited claims, if you have one.

---

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
