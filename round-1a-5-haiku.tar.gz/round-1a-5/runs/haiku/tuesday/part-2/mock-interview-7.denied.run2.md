I couldn't run web research in this session because search permission wasn't granted. The pack is built from the job description and your background only, so it has no company values, interview loop, or strategy. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-7-denied-71ad1545/Saltmarsh_live-operations-producer_interview_pack.md`.

The most useful prep is the two-title question. Your material shows one title's content-drop calendar, and the JD asks you to run live events across two. The pack gives that objection the deepest rehearsal, and the honest answer is to hold the calendar you ran and concede the second title. The other gaps it covers are that you haven't led a team, haven't worked on an in-app-purchase game, and that your live-service experience isn't stated in your material.

I can also do these:
- Play the Skeptic on that two-title question as a live drill.
- Save a `tuesday-dossier.md` with the gaps this prep exposed, for later sessions.
- Convert the pack to a Word document.

Is Tobias your future manager, a skip-level, or one of several interviewers? Did the recruiter name any focus areas or a take-home? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer interview prep pack

Prepared for Femi. Interview: Friday, 60 minutes. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship and round type were not given, so this is built as a hiring-manager round, with the weights shown below. No web research ran in this session, so the pack contains no company values, interview loop or strategy. Everything about the company comes from the job description you pasted.

## Contents

- How to use and type key
- Fit snapshot
- Prohibited claims
- Persona table
- Question banks and requirement coverage
- Reverse questions
- Sources
- Upgrade menu

## How to use and type key

Personas describe how a question arrives. Types describe what it scores.

- **EXP**: work-experience deep-dive. Does what you did survive scrutiny?
- **JD**: the listed job and its requirements, gaps included.
- **CASE**: a live problem from the role, scored on structure and reasoning.
- **CO**: company and strategy knowledge. Not in this pack, because no research ran.
- **VAL**: behavioural and values alignment. Not in this pack, because no values-style round was detected.

Guidance is scaffolding, not a script. Sentences in quotation marks are yours, quoted from your message or the job description. Everything else is the pack's analysis.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one main title's content-drop calendar. It does not say two titles or live events. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned or tracked more than one title, say which and how, in your own words. If you have not, say so plainly and say what you would learn about the second title first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating design, art, engineering or community on an update. Answer slot: if you have, say which teams, which update, and what you decided. If you have not, say so plainly and say how you would start on the first update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material shows you presented retention numbers. It does not show you owned a post-event review or chose the KPIs it reports. Words: "Presented the monthly retention numbers to the studio head." Answer slot: if you set which KPIs a review reported, say which and how you decided. If you did not, say so plainly and say what you would put in a review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap. Words: "Wrote the release checklist our QA team still uses." Expect a probe on how the checklist is kept current with QA. Answer from what you know, in your own words. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [grounded] | transferability | Your material shows four years at a puzzle-game studio. It does not say the work was live-service. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the work included live-service elements such as events, drops or retention work, name them. If it did not, say so plainly. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your material already puts retention in front of leadership, and the bridge rewords only that. Words: "Presented the monthly retention numbers to the studio head." If asked how the numbers were counted, answer from what you know. If you did not set the definition, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | Your material does not show written communication for this role. The one written work it names is a checklist. Answer slot: if you wrote something else that someone acted on, name it and what it changed. If nothing comes to mind, say so plainly and point to the checklist. |

## Prohibited claims

The pack will not coach these. Each entry gives its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars across two titles | Inflated form of F1. Your material names one title's content-drop calendar | F1's quote at its own scope. The pack's observation: your material says one title, not two |
| Owned the post-event review and the KPIs it reports | Inflated form of F3. Your material says you presented retention numbers | F3's quote at its own scope. The pack's observation: presenting is what your material shows |
| Managed the release process with QA | Inflated form of F4. Your material says you wrote the checklist | "Wrote the release checklist our QA team still uses." No slot names a wider role |
| Produced live-service games | Inflated form of F5. Your material says a puzzle-game studio | "4 years as an associate producer at a puzzle-game studio." The live-service part is an answer slot, not a claim |
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot asks you to supply one |
| Worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan for learning it, never a past |

## Persona table

No relationship priors were given, so the weights use a hiring-manager prior. The weights would change if Tobias is a peer or a skip-level.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the calendar and the update process | 4 questions. A hiring manager buys capability and tests it on the actual roadmap | Clarify before structuring. Think aloud. Name what you would ask first |
| Skeptic | Probes the one-title calendar, the team gap and the IAP gap | 4 questions. The hiring-manager prior, and your gaps are specific and predictable | Rehearse the single most likely objection until it is plain. Concede the gap in your own words, then give a ramp plan |
| Prober | Asks how the retention figure and the calendar were counted, and who owned what | 4 questions. Your metric line and your calendar are the two places attribution will be tested | Say how it was counted, in your words. Name the assumption you would defend least. Say plainly what was not yours |
| Pressure | Time-boxes the calendar-to-two-titles answer and the team lead gap | 3 questions. Lower than a hiring manager's usual, but a live role-fit challenge is likely | Pause and restate. Hold the one thing your quotes carry. Concede the limit once, specifically |
| Conversational | Opens with the journey and a casual question about mobile games | 2 questions. Casual openers are scored | Keep a 90-second arc to what you wrote. Name a game you play, without claiming knowledge of theirs |
| Peer | Seam and credit questions with design and art | 2 questions. Covers the case where Tobias works alongside the teams you would coordinate | Propose seam principles, not a map of their teams. Offer reciprocity |
| Values / Behavioral | None | 0 questions. No values-style round was detected, because no loop source was read | Not applicable in this pack |

## Question banks and requirement coverage

### Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Plan the next six weeks of events across two mobile titles. What do you need to know first?" | CASE | [generic] | Clarify before planning: each title's goals, what the team can absorb, the QA windows, and which dates are fixed. Then sequence the events, name the metric each one is judged by, and name one risk. Think aloud. | A live problem from the JD's first line (R1 in the coverage table). [generic] because it is a pattern for the problem, not a fact about the company. |
| C2 | "A retention drop lands the week after a big content drop. How would you diagnose it?" | CASE | [generic] | Separate the drop's timing from the drop itself. Ask which cohorts left, whether anything else changed that week, and what the retention figure counts. Name the assumption you would check first. | Tests retention reasoning in the JD's own terms (R3 and R7). No claim about your past. |
| C3 | "Design, art and engineering each want the next release slot. How do you decide?" | CASE | [generic] | Clarify what each delay costs and who owns each call. Put the trade-off to those owners, decide on the option you can defend, and record the decision. | A coordination problem from the JD's update line (R2). No claim about your past. |
| C4 | "What would you put in a post-event review so the next team can act on it?" | JD | [generic] | Name the outcome measure, the comparison you would use, what went wrong, what you would change, and who receives the review. | Tests the review the JD makes this role own (R3). [generic] because it asks for a method, not a fact about you. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your experience is one title's content calendar. Why would running live events across two titles work?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | HOLD: the calendar you ran was for one title, and say so first. Carry across only what you did: the weekly cadence, and the two years you ran it. Answer slot: if you planned around more than one title, or held two calendars in view, say how, in your own words. If you have not, say so plainly and say what you would learn about the second title first. Hold through two follow-ups by returning to the calendar you ran. Concede the second title as the limit. Never stretch the first. | This is the single most predictable objection to this candidate. The two-title line of the JD presses hardest on the thinnest part of the material (F1). Highest-ROI prep in this pack. |
| S2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message) | Name the gap in your own sentence: "I haven't led a team." Then give the ramp plan as a plan: your first steps with design, art, engineering and community on the first update. Do not name a past coordination. Hold one follow-up before conceding anything more. | The Skeptic's standard question. The honest answer is the candid gap plus a plan. |
| S3 | "You've never worked on a game with in-app purchases. How would you read retention on a title that has them?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say how you would learn it: which monetisation measures you would ask for in your first weeks, and what you would check them against retention. Never describe a monetisation review you did. | A stated negative. The JD does not raise in-app purchases, so expect this only if Tobias does. Rehearse it so the honest answer is ready. |
| S4 | "How would you describe the four years at the puzzle studio, in live-service terms?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say what the studio's work was, in your own words, and whether it had live-service elements such as events, drops or retention work. Answer slot: if it did, name them. If it did not, say so plainly. Do not call it live-service unless you can describe it that way. | The JD requires "3+ years producing live-service games or apps". Your material gives the years, not the live-service part, which is the gap. |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say how each figure was counted, in your own words. Name the assumption you would defend least before it is named for you. Answer slot: if you chose the definition, say which and why. If you did not, say so plainly and say what you would check first. Never describe a definition you did not use. | Defend-the-number slot on your one retention line (F3, F7). The prober's first move. |
| P2 | "Which parts of the content calendar were yours to set, and which came from elsewhere?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Separate what you decided from what came from elsewhere, in your own words. Answer slot: if you set the cadence or the slots, say which and how you decided. If they came from others, say so plainly and stay with the calendar you ran. | Attribution honesty on the calendar (F6). The JD's "plan and run" line makes this probe likely. |
| P3 | "Walk me through the release checklist you wrote. Which parts does QA still use as you wrote them?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what you wrote and what QA still uses, in the terms of the quote. Answer slot: if you know which parts changed after you wrote them, say which. If you do not, say so. | Tests F4 at its own scope. The JD asks you to manage the checklist with QA, so expect a probe on who owns each step. |
| P4 | "Describe one week of the content-drop calendar, from plan to release." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Describe one week in order: what was planned and what shipped. Use only the steps you ran. Answer slot: if a step was not yours to run, say so. | A concrete version of P2. The JD's "plan and run" line raises the probe. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why hire someone from a puzzle studio to run live events on two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pause, restate the question, then answer from the calendar you ran. Hold the position through two follow-ups. Concede the limit once, specifically: you have run one title's calendar, not two. Never fold on the one thing your quotes carry. | The pressure time-box. The position held is one your quotes carry. |
| R2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Pause. Say what you did: you presented the monthly numbers to the studio head. Answer slot: if you produced or checked the figures, say how, in your own words. If you presented figures you did not build, say so plainly. Hold the presenting, and concede the rest. | A pressure question on the one retention line (F7). The honest answer is attribution, not defence. |
| R3 | "You've never led a team. Why should we give you coordination across design, art and engineering?" | JD | [grounded] "Never led a team" (your message) | Acknowledge first: "I haven't led a team." Answer slot: if you have coordinated across functions, say how. If you have not, say so plainly and describe how you would start on the first update. Hold through two follow-ups. Concede the lead gap explicitly. | A stated negative. The JD asks for coordination, not team leadership, so the probe will press on the boundary between them. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through your path so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the studio, the four years, the calendar you ran, the checklist, and the retention presentation. Only those, in your own words. Add no titles or scope. | A casual opener that is still scored. The arc uses only what you wrote. |
| K2 | "What are you actually playing at the moment?" | JD | [generic] | Name one mobile game you play, and say what you notice about its events and updates. Do not claim knowledge of the company's titles. | A casual question on the JD's mobile focus. Scored, but it needs nothing about your past. |

### Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our design and art teams sit next to yours. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who decides a slot, how a disagreement goes to its owner, and how the decision is recorded. If you have a disagreement with a team on a schedule, tell it in your own words. If none comes to mind, say so plainly and say how you would handle it. | The seam question lands on the coordination line (F2). |
| E2 | "How do you handle credit when a release needs three teams?" | JD | [generic] | Say what you would credit and to whom, then what you would ask of the other teams. Offer reciprocity: say what you would bring their team, not only what you need. | Peer-weight question on the coordination line. Reciprocity framing. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | C1, S1, R1 |
| Coordinate design, art, engineering and community teams on each update | C3, S2, R3, E1, E2 |
| Own the post-event review and the KPIs it reports | C4, C2, P1 |
| Manage the release checklist with QA | P3 |
| 3+ years producing live-service games or apps | S4, R1 |
| Experience running a content calendar | P2, P4, K1 |
| Comfortable with player-retention metrics | P1, C2, R2, S3 |
| Clear written communication | None, and why: the interview is spoken, and the release checklist (P3) is the written record you can point to |

## Reverse questions

| Question for Tobias | Why it lands |
|---|---|
| "How do the two titles split design and engineering time in a normal month?" | It shows you are weighing the constraint behind the calendar, not only the calendar itself. |
| "What does a post-event review report to leadership today, and which KPI does it lead with?" | It goes straight to the review and KPI ownership in the JD. |
| "How is the release checklist run with QA now, and what has broken it recently?" | It signals you will inherit a working process, not invent one. |
| "Which retention measure do you hold a live event to, and how far out do you read it?" | It asks for their metric in their own terms, so you can match it. |
| "What decisions sit with the Live Operations producer, and which need your sign-off?" | It finds the boundary the coordination requirement depends on. |
| "What would the first 90 days need to look like for someone coming from a single-title team?" | It shows you know the gap and want a ramp, not a pitch. |

No interviewer profile was available, so none of these ties to Tobias's own career path.

## Sources

Provided documents: the job description and your background, both in your message. Nothing else was read.

Research tier: L1, searches 4 of 6, fetches 0 of 2. Every search was refused by the host, because search permission was not granted this session.

| Query sent | Result |
|---|---|
| Saltmarsh Games values | refused |
| Saltmarsh Games interview process Live Operations Producer | refused |
| Saltmarsh Games strategy news | refused |
| Tobias Wrenfield Saltmarsh Games | refused |

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section 10). Not built, because no values-style round was detected |
| 2. Saltmarsh Games interview process, Live Operations Producer | unavailable | Loop structure. The persona weights are a hiring-manager prior, not a loop |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company and strategy questions. None written, so the CASE questions stay generic |
| 4. Tobias Wrenfield with Saltmarsh Games | unavailable | Reading the interviewer, and one reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Tobias's relationship to you, and whether the round is a panel → reweights the persona table and the reverse questions.
- The recruiter's note on focus areas, or any take-home → a build section for any deliverable they declared.
- The hours you have before Friday → a sized prep schedule, with the most valuable items first.
- Search permission for this session → the values page, the interview loop, current strategy and Tobias's public footprint (targets 1 to 4). A deeper research pass is available on your consent after that.
- The company's values page, pasted → a values cheat sheet, if the round turns out to be values-style.
- A `tuesday-dossier.md` → would record the gaps this prep exposed, so later sessions start from them.
