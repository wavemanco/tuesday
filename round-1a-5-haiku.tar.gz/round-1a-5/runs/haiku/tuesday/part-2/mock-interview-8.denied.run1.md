Your prep pack is saved at /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-8-denied-18654a2f/Ashgrove_member-experience-lead_interview_pack.md. I built it as one loop across your three rounds, since you gave all three. I ran no searches: the values, the process and the strategy came from what you sent.

The highest-ROI prep is 2S1, the contact-centre gap. You have never worked in one, and that is likely to come up in all three rounds. Rehearse the plain acknowledgment ("I haven't worked in a contact centre") and then the plan for learning it, until they are boring.

Say the word and I'll play the Skeptic on 2S1 and push back on your answer.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Which country is the role in, and can you work there and from the hub it sits in? The JD names neither, so I've left the right-to-work and location gate open until you tell me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Rounds (4 December 2026):**
1. Recruiter, 30 minutes
2. Head of Member Services (your prospective manager), 45 minutes, mostly behavioural. Name not given.
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel also scores the four values. Names not yet assigned.

**Built:** 25 November 2026. First version, so no changelog.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it is scoring.
- Type key: **VAL** behavioural and values alignment. **EXP** work-experience deep-dive. **JD** role and job-description driven. **CO** company and strategy. **CASE** hypothetical or live problem.
- **Guidance is scaffolding, not a script.** Every claim about your past is one of your own sentences, quoted. Where your material does not show something, the pack says so and gives you an honest branch.
- **Answer slot:** an instruction for the interview, not a question for me. It tells you what to say if the interviewer goes there.
- **Highest-ROI prep: 2S1.** The contact-centre gap comes up in all three rounds. Rehearse the plain acknowledgment and the plan until they are boring.

---

## Fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message. Gate rows are marked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's log, not an end-to-end process across branches. Bridge at that scope: "For the branch, I handled the formal complaints log." Answer slot: if you set any step from complaint to decision, say which and how you decided. If those steps were set by policy or by others, say so and say what you ran. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past: how you would learn how a complaint moves through one, and who you would ask first. |
| F3 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Bridge at the quote's scope: "For the branch, I built the monthly complaints spreadsheet our regional manager uses." Medium because nothing has been inspected. The spreadsheet is the artifact that would raise this: an anonymised copy with no member data would do it. |
| F4 | "resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether resolution times were tracked. Answer slot: if the spreadsheet tracked how long complaints took to resolve, say what it counted. If it did not, say so and say what you would add first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Bridge at scope: "For the branch, I trained new tellers on our escalation script." Tellers are not supervisors. Answer slot: if you coached anyone on an escalation, say whom and what you did. If no coaching was yours, say so and say how you would start with supervisors. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your quote reaches the requirement in role-relevant terms. Words, in your vocabulary and not the JD's: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material does not show which complaint rules that log followed. Bridge at scope: "For the branch, I handled the formal complaints log." Answer slot: name the rules that applied to that log, in your own words. If none were named to you, say so and say how the log was kept. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't presented to anyone above regional level." Then a plan, said as a plan: how you would prepare to present to a senior group. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material names a spreadsheet, not Excel, and not what you did in it. This bridge is the pack's own derivation, not a claim about Excel. Answer slot: say what you used Excel for, if it was Excel. If it was another tool, name it and say what it did. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with digital teams. Answer slot: if you worked with anyone on a digital or self-service change, say what you did. If you did not, say so, and say how you would start. |
| F11 | Right to work in the country the role is in, and the role's location. Neither is stated in the JD. (gate, prose) | none given | none | [generic] | hard_gate | Your material does not establish either, and the JD does not state them. Nothing here is bridged. The one question the pack allows asks whether the gate is met, and it sits in the message that presents this pack. |

**Note on F2 and F8:** both are stated absences from your own message. They are the two gaps most likely to be pressed, and the pack gives each the plain acknowledgment and no more.

---

## Grounding brief

The strategy brief reached me as your summary of it (July 2026, under six months old). I have quoted only the lines you wrote.

| Brief line, from your message | What it affects in this pack |
|---|---|
| "move 40% of member service to digital channels by 2028" | 2D1 (CO), reverse question R2-3, and F10's answer slot |
| "consolidate eight branches into five hubs over 2027" | 2C1 (CASE), 1C4 (location), F11 (gate) |
| "launch a small-business lending product in Q1 2027" | Not used. No question here needs it. Mention it only if the interviewer raises it. |
| "the main competitive pressure is app-only banks" | Not used in a question. Do not claim knowledge of how members choose between Ashgrove and an app-only bank. Nothing in your material covers it. |

---

## Personas and round weights

The loop is three named rounds, so the pack runs in loop mode: one shared fit snapshot, then a mini-pack per round with its own weights.

| Round | Persona | Weight | Reasoning |
|---|---|---|---|
| 1. Recruiter, 30 min | Conversational / rapport | Top: 5 questions, four of them logistics slots | The recruiter's friendly opener hides a scored screen. Pay, notice, location and reason for leaving are each a logistics slot. |
| 1. Recruiter | Skeptic (light) | 2 questions | Your contact-centre gap and your supervisor-to-this-role move will be checked at screen stage. |
| 2. Head of Member Services, 45 min | Skeptic | Top: 4 questions | F2 and F8 are the reasons this round exists. The recruiter said "mostly behavioural", so the Skeptic runs through behavioural questions. |
| 2. Head of Member Services | Values / behavioural | 3 questions | "Mostly behavioural" puts the values lens into this round too. |
| 2. Head of Member Services | Case / strategist | 2 questions | Branch closures and digital shift are the strategy the brief names. |
| 2. Head of Member Services | Data-driven prober | 1 question | Your spreadsheet is the one number in the material. |
| 2. Head of Member Services | Pressure | 1 question | Built on F8's stated absence, to test the hold-then-concede structure. |
| 3. Panel, 60 min | Values / behavioural | Top: 4 questions, one per value | The panel scores the four values, and the rubric needs at least one question per value. |
| 3. Panel | Case / strategist | 3 questions, including the 20-minute case | The panel's case is the scored exercise. |
| 3. Panel | Peer evaluator | 2 questions | Two branch managers are close to peers. Their questions will test the seam between branches and the contact centre. |
| 3. Panel | Pressure | 1 question | Stacked on F2 and F8, asked by the panel as a group. |

---

## Question banks

### Round 1: Recruiter, 30 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "So, walk me through your path to here." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Ninety-second arc from that sentence: six years in retail banking, the last three as a branch supervisor. Add one sentence on the complaints log and training tellers, in your own words. Stop there. | Opener for a conversational screen. Covers F6. |
| 1C2 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. If you would rather know the band first, say so. Do not guess a figure. | Recruiter logistics. No claim about you. |
| 1C3 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot: give your own number, or ask for the band first. Do not state current pay. If asked what you earn now, say you would rather focus on the range for this role. | Pay is a logistics slot. This pack supplies no figure. |
| 1C4 | "Where would you be based, and how many days in the office?" | JD | [generic] | Logistics slot: answer for the location you can work from, in your own words. If the hub is not decided, say so and ask which hub the role covers. | Location is gate row F11. The 2027 hub consolidation makes it live. |
| 1C5 | "Why are you leaving your branch supervisor role?" | EXP | [generic] | Logistics slot: your reason, in your own words. If you would rather not give it, say so briefly. The material holds no reason for you to give. | Reason for leaving is a logistics slot. You have not stated a reason, so the pack has none to quote. |
| 1S1 | "You've never worked in a contact centre. What makes you think you can run complaints across one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment first: "I haven't worked in a contact centre." Then the plan, as a plan: how you would learn the route a complaint takes through one, and who you would ask first. Do not describe contact-centre work you have not done. | Covers F2 in its screen form. The premise is your own quote, so the acknowledgment is yours to say. |
| 1S2 | "Why would you move from supervising a branch to a role like this?" | EXP | [grounded] "the last 3 as a branch supervisor" (your message) | Give the reason in your own words, and name the part of the job that is new to you. Do not add a reason you have not given. | Motivation check. The answer has to hold in round two. |
| 1C6 | "What is one thing you would change about how a branch handles complaints?" | VAL | [generic] | Open prompt on Members First, Always, the value the panel will score. Pick one change you have seen was needed. If none comes to mind, say so plainly, then name the nearest thing from your log. | Light and friendly, and scored. The values lens shows in the answer. |

**Round 1 reverse questions**

| Question | Why it lands |
|---|---|
| "What does the next step look like after the three rounds?" | Shows you are planning the process. The answer tells you how close a decision is. |
| "Which hub or branch would this role sit in, and when does that change?" | The location gate (F11) and the 2027 hub consolidation are both live. The answer tests both. |
| "How many complaints a month does the team handle today?" | Gives you a number to anchor the rest of the conversation. |

### Round 2: Head of Member Services, 45 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2S1 | "You've never worked in a contact centre. How would you run complaints that go across branches and the contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment first: "I haven't worked in a contact centre." Then the plan: how you would learn the contact-centre route, what you would ask the team in week one, and how you would check the handoff. A plan, never a past. | **Highest-ROI prep.** F2 is the gap the Skeptic will press. It is asked in round one, round two and round three. |
| 2S2 | "Tell me about a complaint from the branch log you would want back." | EXP, JD | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt on the log. Pick one case from it. Say what happened, what you decided and what you would change. Describe a decision as yours only where you made it. If none comes to mind, say so plainly, then give the nearest case from the log. | Tests F1's scope. The log is the story, and the interviewer will ask what was yours. |
| 2S3 | "How much of that complaints process was actually yours?" | EXP, JD | [grounded] "I handled the branch's formal complaints log" (your message) | Hold to the log: "I handled the branch's formal complaints log." Then the honest split: which steps you decided, and which were set by policy or by others. Answer slot: if you set any step from complaint to decision, say which and how. If those steps were set by policy or by others, say so and say what you ran. Hold through two follow-ups by returning to the log. | F1 is where a prober presses. The honest answer is a limit, not a confession. |
| 2S4 | "Walk me through the escalation script you trained tellers on." | EXP | [grounded] "trained new tellers on our escalation script" (your message) | Describe the script in your own words: what it covered and how you taught it. Answer slot: if you ever changed or enforced the script, say when and how. If you only trained on it, say so. | Premised on the quoted script. A supervisor interviewer will check the training is real. |
| 2V1 | "Tell me about a time you put a member's view ahead of a procedure." | VAL | [generic] and "I handled the branch's formal complaints log" (your message) | Scaffold: pick a time a member's side of the counter changed the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the log you handled. | Members First, Always is the raising source. The scaffold is the honest branch. |
| 2V2 | "Describe a time someone needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: pick a time an explanation did not land and what you changed. If none, say so, then give the nearest: how you taught the script to tellers. | Plain Words is the raising source. The nearest thing is the script training. |
| 2V3 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a problem you found and stayed with to the end. Say whether it was solved and what it took. If none, say so plainly, then give the nearest from the log, stated at its own scope. | Own the Fix is the raising source. Your only sentence on the subject is the log. |
| 2C1 | "If a branch closes into a hub, what happens to the complaints open at that branch?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Structure, do not recite. Clarify which complaints are open, the member's route after the move, who owns each case through the change, and what the reporting shows. No claim about your past. | Brief-led CASE question. The words are the interviewer's. |
| 2D1 | "Member service is moving 40% to digital by 2028. Which complaints should never move to a self-service journey?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" (your message) | Structure: name the complaint types that need a person, why, and how you would check the self-service route keeps them. If asked whether you have worked on a digital change, use F10's answer slot. | Covers the JD's self-service line through the company's own strategy. |
| 2P1 | "Walk me through how the numbers in your monthly complaints spreadsheet were counted." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend the number in your own words: what the spreadsheet counts and from what source. Name the assumption you would defend least. If you cannot say how a column was counted, say so. "I don't know how it was counted" is an honest branch. If it tracked resolution times, say how. If it did not, say so. | A Data-Driven Prober checks the count, not the build. Also covers F4 and F9. |
| 2X1 | "Why should the team trust someone who has never presented above regional level with this role?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Hold: your branch-level work carries over. That is the log, the training you gave tellers, and the spreadsheet your regional manager uses. Concede plainly: "I haven't presented above regional level, and I would plan to learn it first." Hold through two follow-ups. Do not fold on the core. | Pressure question on F8's stated absence. The hold is what your material carries, and nothing more. |

**Round 2 reverse questions**

| Question | Why it lands |
|---|---|
| "What would the first 90 days need to deliver?" | A manager's answer is the job brief you will be measured against. |
| "Which complaint measure matters most to you this year: volumes, resolution times or repeat complaints?" | Names the monthly reporting the JD asks for, and tells you where the priority sits. |
| "Where do you expect the digital shift to change what reaches this role?" | Connects your question to the 40%-by-2028 line in the strategy brief. |

### Round 3: Panel of two branch managers, 60 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "A member comes to your branch. A complaint about a fee went to the contact centre two weeks ago, and no one has called back. You have the file. Walk me through the next 20 minutes." | CASE, JD | [generic] | Structure: clarify the facts (the fee, the dates, the account). Name the complaint rules that apply in the country the role is in, and the member's response deadline. Then the approach: take ownership, call back today, decide the escalation and record it. Then the metric you would watch and the risk of a missed deadline. Think aloud. | The panel's 20-minute case. Raising source: the JD's "coach branch supervisors on escalations" and the panel's stated case. No claim about you. |
| 3C2 | "The fee problem affects 300 accounts across three branches. What changes?" | CASE | [generic] | Step up from one case to a pattern. Ask about root cause before the fix. Ask who owns the fix across three branches, what the monthly report would show, and who needs to hear it. Name the risk of fixing cases one by one. | Follows the case. Tests whether you think of reporting and root cause, which the JD names. |
| 3C3 | "A branch supervisor has handled five escalations this month, and the same complaint is back. How do you coach them?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Describe the coaching you would do, in your own words: how you would review the five, what you would check with the supervisor, and what you would measure next month. The nearest thing your material carries is the teller training: say what the script covered and how you taught it. If you have never coached a supervisor, say so plainly. | Coaching supervisors is in the JD (F5). The answer names the nearest thing, not a claim to have coached supervisors. |
| 3V1 | "Tell me about a decision you made from the member's side of the counter when it cost you something." | VAL | [generic] | Scaffold: pick a decision where the member's view cost you something. If none comes to mind, say so plainly, then give the nearest thing from your log. | Members First, Always. The scaffold names no story about you. |
| 3V2 | "When did you last have to explain something to a member, or a teller, twice? What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold as in 2V2. If none comes to mind, the nearest is the script training. | Plain Words. |
| 3V3 | "Tell me about a time a branch's numbers hid something about its town." | VAL | [generic] and "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Scaffold: pick a time a number told you one thing about a branch and the local picture said another. If none, say what your spreadsheet did and did not show about one branch, in your own words. If you do not know, say so. | Neighbours, Not Numbers. Your spreadsheet is numbers, so this is the value it will be tested against. |
| 3V4 | "Tell me about a problem you found and stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold as in 2V3. The log is the only sentence you gave; state it at its own scope. Anything about keeping hold to the fix is an answer slot. | Own the Fix. |
| 3E1 | "Our branches send complaints to the contact centre and get them back. Where's the seam, and what happens when we disagree about who owns a complaint?" | JD | [generic] | Propose a seam principle rather than pretending to know theirs. For example: one named owner per complaint until it is closed. Ask where the handoff stalls today. Do not claim knowledge of the contact centre. | Peer seam probe. Raising source: the JD's "across branches and the contact centre". |
| 3E2 | "How do you handle credit when a complaint is closed by someone else's branch?" | VAL | [generic] | Name what you would give them: a clear handoff note, the member's history, a call before closure. Say how you would share credit in a team. | Peer reciprocity. No claim about your past. |
| 3X1 | "You've never worked in a contact centre, and you've never presented above regional level. Why are you the person for this panel?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level" (your message) | Hold: your branch-level work carries over. That is the complaints log, the training you gave tellers, and the spreadsheet your regional manager uses. Concede plainly: "I haven't worked in a contact centre or presented above regional level, and I would plan to learn both first." Hold through two follow-ups. | Pressure, stacked on F2 and F8. The concession is the plain acknowledgment. The hold is the branch work. |

**Round 3 reverse questions**

| Question | Why it lands |
|---|---|
| "What could a new person do in their first month that would genuinely help your branches?" | Reciprocity for peers. Shows you are thinking about them, not only about yourself. |
| "When a complaint moves from a branch to the contact centre, where does it usually stall?" | Asks the seam question directly and gives you a concrete place to start. |
| "How do the two of you decide who owns a complaint that spans both branches?" | Tests the seam, and shows what the panel does when they disagree. |

### Requirement coverage

| JD requirement | Question IDs that cover it |
|---|---|
| Own the complaints process end to end across branches (F1) | 2S2, 2S3, 3E1 |
| ...and the contact centre (F2) | 1S1, 2S1, 3E1, 3X1 |
| Report monthly on complaint volumes (F3) | 2P1 |
| Resolution times (F4) | 2P1, as an answer slot |
| Coach branch supervisors on escalations (F5) | 3C3, 3C1 |
| Work with digital teams on self-service journeys (F10) | 2D1, with F10's answer slot |
| 4+ years in financial-services customer operations (F6) | 1C1 |
| Experience handling regulated complaints (F7) | 3C1, 2S2 |
| Confident presenting to senior leaders (F8) | 2X1, 3X1 |
| Comfortable with Excel reporting (F9) | 2P1 |
| Right to work and location (F11, gate) | 1C4, and the one question in the message that presents this pack |

---

## Values cheat sheet

Values are taken from the copy you pasted from ashgrovecu.org/about/values on 25 November 2026. The panel scores against them, so this section applies.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Selection scaffold: pick a decision you made from the member's side. If none comes to mind, say so plainly, then give the nearest thing from your log, which is F1's "I handled the branch's formal complaints log". |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | F5: "trained new tellers on our escalation script". The story is the script you taught. Scaffold: pick a time an explanation did not land and what you changed. If none, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Selection scaffold: pick a time a branch's number hid something local. Your spreadsheet (F3) counts complaints. If you cannot say what it missed about one branch, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F1: "I handled the branch's formal complaints log", at its own scope. Anything beyond the log, such as keeping hold until solved, is an answer slot. Scaffold: pick a problem you found and stayed with. If none, say so. |

---

## Prohibited claims

Each entry has its basis. These are wordings this pack will not coach. None of them appears in an answer, a hold or a bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: your material says the branch log, not a process across branches. 2S3 stays inside the log. |
| Has worked in a contact centre | Negative you stated (F2) | "I haven't worked in a contact centre." No slot. |
| Has presented to senior leaders | Negative you stated (F8) | "I haven't presented to anyone above regional level." No slot. |
| Excel reporting expertise | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not name Excel. |
| Coached branch supervisors on escalations | Inflated form of F5 | "trained new tellers on our escalation script", at that scope. |

---

---

## Sources

**Provided documents (in your message):**
1. The JD text.
2. The values copied from ashgrovecu.org/about/values on 25 November 2026.
3. The recruiter's email on the process (three rounds, durations, the panel's values scoring and the case).
4. The strategy brief, as you summarised it (July 2026).
5. Your background, as stated in your message. No CV was supplied.

**Searches and fetches:** none sent.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The four values in the values cheat sheet came from the copy you pasted on 25 November 2026. The pasted page fixes that output, so no search was sent. |
| 2. Ashgrove interview process, member-services role family | skipped | The recruiter's email fixes three named rounds, their durations, and the panel's values and case. The loop structure and persona weights rest on it. |
| 3. Ashgrove strategy and recent news | skipped | The strategy brief you summarised (July 2026, under six months old) fixes the grounding brief. A quick check of the pasted summary was not run. |
| 4. Interviewer name and Ashgrove | n/a | No name given for the Head of Member Services or the two branch managers, so there was no query to form. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

**Not in this pack, and why:** an interviewer read (no names), delivery coaching (no assessment), graded deliverables (none declared), and prep triage (prep time not stated).

---

## Upgrade menu

- **The country the role is in** → F7's answer can name the complaint rules that apply there, and 3C1's structure can name them too. F11's right-to-work gate becomes checkable. Naming the rules would take a search outside this tier's targets, so say if you want it run.
- **An anonymised copy of your spreadsheet, with no member data** → F3 can move from medium toward high, and F9 becomes checkable: the pack can then say what the sheet actually does, not what it might.
- **The names of the Head of Member Services and the two branch managers** → persona weights set per person, an interviewer read, and reverse questions tailored to their paths.
- **The recruiter's note on what the panel's 20-minute case covers** → 3C1 and 3C2 tuned to the actual brief.
- **How many hours you have before 4 December** → a prep triage, in the order that matters, sized to that time.
- **A deeper research pass (L2)**, up to 6 more searches and 2 more fetches, several minutes. It would add the Head of Member Services' public footprint once you give a name, role-family loop reports (forum claims labelled inferred), and recent organisation news. Offered once. Want it?
