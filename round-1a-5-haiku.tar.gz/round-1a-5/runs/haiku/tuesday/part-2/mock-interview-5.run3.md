Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-5-denied-6bd55daf/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It covers the POV build, a question bank weighted to Ross's commercial pressure and Deepa's fit probes, the stated gaps (no rail sales, no direct quota), and a four-hour schedule.

Three things shaped it:

- **Research didn't run.** The search tool was refused on every call, so nothing about Kelverton's values, interview loop or strategy is in the pack. The CO and values material is generic and labelled as such. The recruiter's email is the one loop source, so the panel format is taken from it.
- **I haven't seen the market report.** The POV's differentiation can't be checked against it yet.
- **The strongest prep item is A1,** Ross's "why hire someone who has never carried a quota". The pack gives a hold-then-concede structure, and the hold uses only your own sentence about the influenced £4M.

I can rehearse the POV or run a drill as Ross whenever you're ready.

Two things would sharpen it:

- Can you paste the JD or the recruiter's role spec? It would confirm whether there are gates, and it would turn the generic rows into quoted ones.
- Can you paste the market report's headline claims, or its section headings? Then the POV can depart from the consensus visibly, rather than just avoid it.

Want the drill offer or a dossier saved? The drill would let you rehearse A1 against Ross's persona. A `tuesday-dossier.md` would record the gaps this prep exposed for later rounds.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second round, panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: first 15 a spoken point of view on operator partnerships over 18 months, no slides; the rest Q&A, with Ross pressing on commercials.

Research did not run: every search was refused (see Sources). Company facts below are therefore not established, and nothing about Kelverton's values, loop or strategy is used. The interviewer read is absent because only first names and titles are known.

## 1. How to use + type key

Personas describe how a question arrives; types describe what is scored. The guidance is scaffolding, not a script.

- **JD**: role and requirement fit
- **EXP**: your past work, tested for attribution
- **CO**: company and strategy knowledge (none established here)
- **CASE**: a live problem, delivered in the room
- **VAL**: published values (none established here)

## 2. Prep triage (about 4 hours)

1. **60 min: build the POV skeleton.** Write three spoken beats and one concession per thesis in Section 5. Say it aloud and time it. It must run 12 to 14 minutes with room for a pause.
2. **30 min: the number.** Write out how the £4M influenced figure was counted, in your own words. Write the assumption you would defend least. If you cannot answer how it was counted, that is the answer you rehearse. Covers A2 and B1 to B4.
3. **45 min: Ross's commercial drill.** Run A1 to A5 out loud, with two follow-ups each. A1 is the most important question in this pack.
4. **30 min: Deepa's fit drill.** Run C1 to C4 and D1 to D4.
5. **30 min: reverse questions and the 90-second opener.** Practise E1 and the reverse questions in Section 9 until they sound like yours.
6. **Remaining time: buffer.** Re-record the POV once and compare it with the skeleton.

Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted. No JD was supplied, so no gate is established. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter) | "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | medium | [grounded] | transferability | Your partnerships were ISV partners, not operators. Say what you did with the ISV channel in the quote's own terms. Any step from there to operators is an answer slot, not a claim. |
| F2 | "what it means for the operators themselves" (recruiter) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | You were on the consultant side of operators' planning, not the operator side. Say "from the consultant side" every time. Do not say "I've worked for an operator." |
| F3 | "Ross will push on commercials" (recruiter) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | none | [grounded] | capability | Your stated absence: "I've never carried a direct quota." The number you can defend is the influenced figure, quoted at its own scope. |
| F4 | rail and operator sales experience (generic: no JD supplied) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Your stated absence: "I haven't sold into rail." Then a ramp plan, said as a plan and never as a past. |

Your message gives no further evidence for commercial accountability or for operator-side selling, so there are no other rows.

## 4. Prohibited claims

These will not be coached, and each is built from the snapshot above.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operator partnerships | Inflated form of F1 | "took it from 6 partners to 40" in the ISV channel. The limit is the pack's observation: your material shows ISV partners, not operators. |
| Operator-side experience | Inflated form of F2 | "I know the operator world from the other side", meaning the consultant side. |
| Owned or drove the £4M | Inflated form of F3 | "roughly £4M of influenced revenue", at its own scope. "Influenced" stays in the sentence. |
| Sold into rail, or carried a quota | Negative you stated, F3 and F4 | "I haven't sold into rail." "I've never carried a direct quota." No slot, no softening. |

## 5. Graded deliverable: the operator point of view (15 minutes, spoken)

Declared by the recruiter: a short spoken POV on where you would take operator partnerships over 18 months, landing on what it means for the operators themselves.

**Grounded facts to build on:** F1 and F2, quoted above. Build no claim on anything else.

**Theses (pick one, or two at most):**

- **T1. Planning-led partnership.** Operators need timetable change to reach the day safely, so the partner's value sits where planning meets operations, not in the licence. *Mandatory concession:* "I've been on the consultant side of planning, not inside an operator. I don't yet know how a TOC's planning and operations teams split the buying decision, and I'd test that in the first month."
- **T2. Outcome-sold partnership.** Sell the operator a measurable outcome, and let partners carry implementation. *Mandatory concession:* "Partner-led selling was my experience on the ISV side. Whether operators buy through a partner or direct is the thing I don't know yet."
- **T3. Anti-pick: fewer, deeper operator partnerships.** Choose three or four operator relationships over a long list. *Mandatory concession:* "Fewer partners means less reach, and I'd need evidence operators will commit before I'd narrow it."

**Differentiation.** I have not seen the internal market report, so I cannot tell you what the consensus answer is. Before you rehearse, check each thesis against it: if a strong candidate who read the same report would say the same thing, switch to T3 or write your own.

**Requested close (customer benefit).** End with what changes for the operator, stated as a hypothesis: "For a planning team, the change I'd test first is…". The operator roles that feel it first are [generic] industry pattern and not established for this company.

**Watch for:** the POV must not claim operator experience. Keep every "I" sentence inside F1 and F2.

## 6. Reading the interviewers

No interviewer profile is available. Only the first names and titles from the recruiter's email are known. Persona weights below come from the panel's stated roles, not from research.

## 7. Persona table

Panel: blend the top two personas of each member's relationship.

| Persona | Member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure | Ross | Interrupts on commercials, time-boxes answers, questions motive | Highest. Recruiter wrote "Ross will push on commercials", and it is the one area your stated absences sit in | Pause, restate the question, hold through two follow-ups, concede specifically |
| Data-Driven Prober | Ross | Asks how the £4M was counted and what the number rests on | High. The figure is the only commercial number you have, so it draws follow-ups | Name how it was counted if you know, or say you don't. Name the weakest assumption before he does |
| Case / Strategist | Deepa | Live problem on operator partnerships, with the POV as the opening | High. A POV and a 60-minute panel are a case-led format | Clarify, then structure, then answer. Say the framework aloud once |
| Skeptic | Deepa | Quiet probes on rail sales, fit and the move | Medium-high. Your stated absences are the obvious place for it | Plain acknowledgment, then a ramp plan |
| Conversational | Deepa | Opening "walk me through" and the reverse-question slot | Medium. Casual questions are still scored | 90-second arc, and a real reverse question |

## 8. Question banks

Ordered by persona weight.

### Ross: Pressure (A) and Prober (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sixty seconds: why should we hire a partnerships leader who has never carried a quota?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause. Restate: "You're asking whether I can carry a number." Hold: "I haven't carried a direct quota. The number I can defend is the influenced figure: took it from 6 partners to 40, roughly £4M of influenced revenue." Hold through two follow-ups. Concede specifically: "Direct quota is a real gap. Here is how I'd learn it: the first quarter, I'd carry a shared number with the sales lead and ask for the quota-bearing deals I'd influence." | **Highest-ROI prep in this pack.** F3 is the objection that will come in some form. A rehearsed, non-defensive hold changes the room. The hold is only what your quote carries. |
| A2 | "That £4M: how much of it would have happened without you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say how the influenced figure was counted, in your own words. If you know the rule, state it. If there was no written rule, or you don't know it, say so plainly. Name the assumption you would defend least. | Defend-the-number slot for a figure you gave. The pack does not supply a method. |
| A3 | "What does an operator pay for, and why would they sign?" | CO | [generic] | Answer from the ISV side and name the translation gap in one sentence. Do not claim operator-buyer knowledge. | Recruiter says Ross will push on commercials. This is the generic commercial question for a company whose strategy is not established. |
| A4 | "A TOC asks for a fixed-fee rollout. What would you give up?" | CASE | [generic] | Structure it: the price, the term, the scope, and what you would not trade. Name one thing you would not give up. | A live commercial problem. It needs no claim about your past. |
| A5 | "Your partners' revenue went through their paper, not yours. Why is that a sales skill?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Hold: "Channel-led selling is influence on a deal you didn't sign. I can defend the influence, and I won't claim the signature." Concede the point if pressed a second time: "Fair. It's influence, not ownership." | Pressure on the same objection through a different door. |
| B1 | "Walk me through how the 6-to-40 number was counted. Partners signed, live, or revenue-generating?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say which definition applied, in your words. If you don't know, say so. Name the weakest assumption in the count. | Defend-the-number slot. The figure's definition is the easiest place to be caught out. |
| B2 | "What share of the £4M came through partners you recruited, versus partners who came to you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: give the share only if you know it. If you don't know, say so and say how you would find out. | An open prober question that the quote does not presuppose. |
| B3 | "Influenced revenue has no attribution rule. Which one did your company use?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot. Branch one: name the rule you worked to. Branch two: if there was no written rule, say so. Do not invent one. | A premised question. Its premise, that a rule existed, is not in the quote, so the second branch must be allowed. |
| B4 | "Which part of that £4M was your decision, and which was the partner's?" | EXP | [grounded] "took it from 6 partners to 40" | Answer in your words, one decision at a time. Say what was yours and what was not. | Attribution. Ross is testing whether you can tell the two apart. |

### Deepa: Case / Strategist (C) and Skeptic (D), with Conversational (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you'd grow our operator partnerships over 18 months. What do you need to know first?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter) | Clarify first: which operators, which products, what the 18-month target is. Then objective, segmentation, approach, metrics, risks. | The POV's live follow-up. Recruiter's words are the raising source. |
| C2 | "A TOC's planning team says it won't change tools mid-timetable. How do you get a partnership in?" | CASE | [generic] | Structure: the planning team's constraint first, then the entry point, then what you would pilot without touching the live timetable. | A live problem. No past claim. |
| C3 | "What does this mean for the operators themselves, beyond the commercial case?" | CO | [grounded] "what it means for the operators themselves" (recruiter) | Say what you saw from the consultant side, in your own words: quote F2 at its own scope and stop there. Anything further is a hypothesis to test, labelled as one. | F2 is the bridge. It says "consultant side", not "operator side". |
| C4 | "Name one operator segment you would not partner with, and why." | CASE | [generic] | Name one, and give the reason in one sentence. | An anti-pick. Deepa will test whether you can say no. |
| D1 | "I don't see rail sales in your background. How would you handle that on day one?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I haven't sold into rail." Then a ramp plan: which two operator conversations you would shadow, which of Kelverton's live operators you'd learn from first. | Highest-ROI objection on the Deepa side. The plain acknowledgment is yours, so it is allowed. |
| D2 | "Your last four years were a channel. Why does a direct operator relationship suit you?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Motivation in your own words. Do not invent a reason the quote does not carry. If the honest answer is that you want to move closer to the customer, say it plainly. | Motivation consistency. |
| D3 | "Why this role, and why now?" | JD | [generic] | Answer slot: say why this role, in your own words. The material does not say why you are looking, so do not supply a reason. | A skeptic's standard close. |
| D4 | "How would you show progress on operator partnerships in your first 90 days?" | JD | [generic] | Give three measures, each one you could defend. Name what you would not measure yet. | A plan, not a past. |
| E1 | "So, walk me through the journey." | Conversational | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" and "5 years in transport consulting" | 90-second arc: transport consulting (planning), then 9 years in partnerships, then the ISV channel, then why this. Keep it to the quotes. | Casual questions are still scored. Rehearse the arc until it takes 90 seconds. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1, operator partnerships over 18 months | C1, A3, A5 |
| F2, what it means for operators | C2, C3, C4 |
| F3, commercials and quota | A1, A2, A4, B1, B2, B3, B4 |
| F4, rail and operator sales | D1, D4 |

## 9. Reverse questions

At least five, each with why it lands. No interviewer profile exists, so none is tied to a career path.

1. "What would make you say in six months that this hire was the right call?" *Why it lands:* it asks Ross and Deepa to define success, which turns an interview into a planning conversation.
2. "Which operator relationship would you most want protected in the first 90 days?" *Why it lands:* it shows you are thinking about operators, not just the pitch.
3. "How is commercial target-setting split between partnerships and direct sales?" *Why it lands:* it tests the quota question from the other side.
4. "Who owns an operator pitch today: partnerships, sales, or the operator's own commercial team?" *Why it lands:* it shows you understand that the buying decision may not sit where you expect.
5. "What did the last partnerships lead learn that the ISV model didn't teach?" *Why it lands:* it asks what they have already found, and gives them room to talk about the work.

Do not answer "I think you've covered everything" to the reverse-question slot.

## 10. Delivery coaching

No assessment was provided, so this section is dropped.

## 11. Prohibited claims

Built locally from the fit snapshot. See Section 4.

## 12. Sources

Provided documents: the recruiter's email, as quoted in your message, and your background summary.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet, not built: no published values in hand, and no values-style round detected |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Loop structure. The recruiter's email establishes this session's loop, so persona weights come from it |
| 3. `Kelverton Rail strategy train operating companies scheduling software` | unavailable | CO bank would be specific. Without it CO questions are generic |
| 4. Deepa, VP Partnerships, and Ross, Commercial Director, at Kelverton Rail | unavailable | Interviewer read and reverse questions tied to their paths. Not searched: the search tool was refused |
| 5. representative JD for the title | unavailable | Fit snapshot rests on the recruiter's words, not a JD. Not searched: the search tool was refused |

Search calls, all refused by the host: `Kelverton Rail values`, `Kelverton Rail interview process partnerships`, `Kelverton Rail strategy train operating companies scheduling software`.

## 13. Upgrade menu

- A pasted JD → gate check, and the generic rows become grounded
- The internal market report's headline claims → the POV can depart from it visibly, not just avoid it
- Search permission, or the company's values and careers pages pasted → values cheat sheet and a loop-structure check
- Deepa's and Ross's surnames, with search permission → a public-footprint interviewer read and tailored reverse questions
- Your attribution rule for the influenced figure → A2, B1, B2 and B3 become grounded answers rather than slots
