Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-6-denied-cb727939/d5721d00-717b-490c-9766-0b99d2672c1a/scratchpad/larkfield-systems_engineering-manager_interview_pack.md. I built one loop pack: a shared fit snapshot, then a mini-pack for each of your three rounds, with 25 questions in total. Web search was refused this session, so nothing about Larkfield's values, interview loop or strategy comes from the web. Round 3's values questions use selection scaffolds rather than published values until you can supply the values page.

The two gaps you flagged are handled as stated gaps, not inflated ones. "Never managed managers" and "never owned a hardware-adjacent roadmap" are answered with a plain acknowledgment and a learning plan, with no slot that could stretch them. The highest-return rehearsal is A2: "What have you led at the size of two squads?" (hiring manager round). Your honest answer is "For three years I was a team lead of six," and the pack's guidance is to hold that line and not add to it.

I can run a live drill on A2 with the Skeptic persona, and I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job posting and your CV? The pack is built on your summary of the role, and the posting would ground the mid-list requirements.
2. Do the 11 engineers report through leads, or directly to you? That decides whether the "managed managers" question is a live one.
3. Did the recruiter say what each round tests, or ask for a presentation or take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: interview prep pack (loop mode, three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Candidate:** Yusuf
**Rounds:**
- **Round 1, Tuesday, 45 min:** hiring manager, a Director of Engineering (your would-be boss). Persona set: Case/Strategist, Skeptic, Pressure.
- **Round 2, the Thursday after, 60 min:** panel of two staff engineers and a product manager. Persona set: Peer Evaluator, Data-Driven Prober, Case/Strategist.
- **Round 3, the following Monday, 30 min:** VP Engineering, described by the recruiter as "values and leadership philosophy". Persona set: Values/Behavioral, Pressure, Case/Strategist.

Interviewer names are not known, so no interviewer read is included. First build; nothing has changed yet.

---

## How to use this pack, and the type key

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script. Every answer slot is an instruction for the interview, not a question to me.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values the company publishes, or the leadership philosophy the recruiter described |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Not used: company research did not run (see Sources) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Tags shown as `JD, CASE` mean the primary type is first.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from your role description as you gave it to me. Evidence is quoted from your message. This is a summary-level role description, not the posting; see the upgrade menu.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Words: "For three years I was a team lead of six." Answer slot: if you have led anything across two groups, say what and how you decided, in your own words; if not, say so and say how you would split the work across two squads. |
| F2 | "partner with hardware and product on roadmap" — your role description | "I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Adjacent: you have roadmap pressure in your material, not hardware. Words: "I pushed a reliability quarter through against roadmap pressure." Hold to that sentence. Answer slot: if product or hardware had a stake in that quarter, say who and how you worked with them; if not, say so. |
| F3 | "partner with hardware and product on roadmap" — your role description (the hardware half) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Hiring is in your material: backend hiring loop, about 40 interviews. Delivery and growth for eleven people are not in it. Words: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: if you have owned a team's delivery, or someone's growth plan, at this size, say what and how; if not, say so and say what you would do first. |

**Reading the table:** confidence grades your evidence, provenance grades this pack's statement. Your scale (team of six, backend loop) is medium because it is specific and yours, with no inspectable artifact behind it yet.

**Not in the table, on purpose:** whether any of the 11 report through leads or managers is not in your role description, so it is not a requirement here. Your sentence "I've never managed managers" is covered in the prohibited list below, and the upgrade menu asks about the reporting structure.

---

## Prohibited claims (built here, before the banks)

These are the claims this pack will not coach. Each entry names its basis, and each has one honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" or any manager layer | Negative you stated: "I've never managed managers" | Plain acknowledgment: "I haven't managed managers." No slot. |
| Owning a hardware or hardware-adjacent roadmap | F3, negative you stated | "I've never owned a hardware-adjacent roadmap." No slot. |
| "I led two squads" | Inflated form of F1: "3 as a team lead of 6" | F1's quote at its own scope: "For three years I was a team lead of six." Limit, as this pack's own observation: your material shows one team, not two. |
| "The 60% on-call drop was my work" or "I drove it" beyond the push | Inflated form of F2: "I pushed a reliability quarter through" | The quote at its own scope. Limit, as this pack's observation: your material shows the drop followed a quarter you pushed through; it does not show what else changed or who else did what. |
| "I scaled hiring for 11" or "I owned delivery and growth for eleven" | Inflated form of F4 | The quote at its own scope. Limit, as this pack's observation: your material shows a backend hiring loop, not ownership of a team's delivery or growth. |
| Any hardware or product partnership you did not state | Inflated form of F2 and F3 | Only the quote in F2. Hardware is absent from your material. |

---

## Round 1: hiring manager, Director of Engineering (Tuesday, 45 min)

**Persona weights** (relationship prior: hiring manager → Case/Strategist and Skeptic, because they are buying capability and checking gaps against their roadmap; Pressure included because the round is short):

| Persona | Weight | Depth | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Top | 4 | They will put a live problem from the two-squad roadmap in front of you. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise, respectfully. |
| Skeptic | Mid | 3 | F1, F3 and F4 are the gaps they can see on the page. A hiring manager will press them. | Rehearse the predictable objection until it is calm. Bridge only from what you stated. Concede the limit plainly. |
| Pressure | Low | 2 | The 45 minutes is time-boxed, so they may interrupt to test composure. | Pause, restate the question, anchor in what you stated, hold through two follow-ups. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 (Case) | "Two squads, eleven engineers, and a roadmap you share with hardware and product. What do you need to know before you change anything?" | CASE | [generic] | Clarify first: what the squads are building now, who the partners are, and how the roadmap is decided today. Then structure. Make no claim about your past. | A live problem the role itself raises. Presupposes nothing about you. |
| A2 (Skeptic, highest-ROI) | "What have you led at the size of two squads?" | JD | [grounded] "3 as a team lead of 6" (your message) | Hold: "For three years I was a team lead of six." Answer slot: if you have led anything across two groups, say what and how you decided; if not, say so and say how you would split the work across two squads. Hold through two follow-ups by returning to the six, never by adding to it. | F1 is the most predictable objection, and the one the round is built to test. This is the highest-return rehearsal in the pack. |
| A3 (Case) | "Walk me through how you'd own delivery, hiring and growth for eleven engineers in the first six months." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Story-map: the hiring loop and its scale, in your own words. Then the plan for delivery and growth, as a plan. Answer slot: if you have owned a team's delivery, or someone's growth plan, say how; if not, say so and say what you would measure first. | F4. The hiring half is yours to tell; delivery and growth are for the plan. |
| A4 (Case) | "Take a live call on a device-management squad where hardware and product disagree on the next release. Sketch it." | CASE | [generic] | Clarify the objective, the segments of the work, the options, the metrics, the risks. Challenge one premise. Claim no hardware experience. | Partnership with hardware and product is the role's own line. |
| A5 (Skeptic) | "Hardware is in this job. Where would you be weakest on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan. Never a claim to hardware work. | F3, a gap you stated. The honest answer is the one that holds. |
| A6 (Pressure) | "Sixty seconds: why should I hire you over someone who has already run a bigger team?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Say the nine years and the three in order, then the team of six. Hold through two follow-ups. Concede the scale gap specifically: "I haven't run more than six." | The Pressure version of F1. Composure, not content. |
| A7 (Pressure) | "Have you ever managed managers?" | JD | [grounded] "never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then what you would do to learn the layer, as a plan. | A negative you stated; it is in the prohibited list as a plain acknowledgment. |
| A8 (Skeptic) | "What would make me believe the roadmap side of this job won't be a surprise to you?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Say what you pushed through and how you handled the roadmap pressure, in your words. Answer slot: if hardware or product had a stake in that quarter, say who and how you worked with them; if not, say so. | F2. The strongest real roadmap evidence you have. |
| A9 (Case) | "Show me how you'd sequence the first quarter's roadmap across both squads." | CASE | [generic] | Structure: clarify the current work, rank by value and risk, state the assumptions, name what you would check first. | A live problem. Presupposes nothing about you. |

**Reverse questions for this round** (each with why it lands):
- "Which of the two squads needs the most change in the next two quarters?" Why it lands: shows you read the role, not just the job ad.
- "How do hardware and product set priorities with these squads today?" Why it lands: asks about the seam you will have to run.
- "What does a good first 90 days look like, from where you sit?" Why it lands: lets them describe the bar in their own terms.

---

## Round 2: panel, two staff engineers and a product manager (Thursday, 60 min)

**Persona weights** (relationship prior: peer → Peer Evaluator and Data-Driven Prober; the product manager adds Case, for the roadmap seam):

| Persona | Weight | Depth | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | Top (two of the three panelists) | 4 | Two staff engineers are pricing what you cost and contribute to their work, and the PM is testing the seam. | Reciprocity: say what you bring to their teams. Propose seam principles rather than pretending to know the seam. Disagree with spine and tact together. |
| Data-Driven Prober | Mid | 3 | Your headline numbers will get asked for their denominators and assumptions. | Know how each figure was counted, or say plainly you do not know. Name your weakest assumption before they do. |
| Case/Strategist | Low | 2 | The PM's questions will be roadmap cases. | Clarify, structure, state the trade-off, challenge one premise. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 (Peer) | "Our teams sit side by side. Where would the seam between your squads and ours be, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who decides what, and how you escalate. Do not pretend to know their seam. Say what your squads would bring to theirs. | Peer stem for partnership. Presupposes nothing about you. |
| B2 (Peer) | "How do you handle credit when work spans two teams?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Name the decision you made yourself, then who else worked on the quarter. Answer slot: if other teams carried part of it, say who and how; if not, say so. | The reliability quarter is your strongest cross-team story, if there was one. |
| B3 (Peer) | "Which of your reliability calls would you want my team to challenge first?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Name the call you would defend least, in your own words, before they do. | Converts a challenge into a credibility gain. |
| B4 (Prober) | "Walk me through how the 60% was counted, and which assumption you'd defend least." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Defend-the-number slot: if you counted it, say how, in your own words; if you did not, say so. Name the weakest assumption you know of. Then say which part was yours: the push. | Every headline number gets probed. Precise attribution is the rehearsal. |
| B5 (Prober) | "Which numbers from your hiring loop would you show us, and how were they counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Story-map the loop and its roughly 40 interviews in your words. Answer slot: say how the count was made, and which steps were yours. | F4 is the hiring half of the role. |
| B6 (Prober) | "How did you know your team of six was on track in any given week?" | EXP | [grounded] "3 as a team lead of 6" (your message) | Say what you looked at, from your own experience. Answer slot: if you tracked delivery against a plan, say how; if not, say so and say what you would use for eleven. | Delivery for eleven is the part of the role your material is thinnest on. |
| B7 (Case, PM) | "Product wants a feature this quarter and the reliability backlog is growing. How do you decide?" | CASE | [generic] | Clarify what the feature buys, what the backlog risks, who decides, and what evidence you would need. Propose a decision rule. Challenge one premise. | The PM's own roadmap seam. Presupposes nothing about you. |
| B8 (Case, PM) | "The hardware timeline and the squads' timeline don't match. Sketch the trade-off for me." | CASE | [generic] | Clarify the constraint from the panel's own words, then structure. Claim no hardware experience. | Partnership with hardware, as the role names it. |
| B9 (Peer) | "Tell me about a time roadmap pressure and reliability work were in direct conflict." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt, so choose the instance. Story-map the reliability quarter. If no other time comes to mind, say so plainly, then give the reliability quarter as you told it to me. | An open prompt on the role's own partnership line. |

**Reverse questions for this round:**
- "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: reciprocity, which is the peer signal panels weight most.
- "Where does the reliability work get decided between your teams and the PM's?" Why it lands: keeps the seam conversation concrete.

---

## Round 3: VP Engineering, values and leadership philosophy (Monday, 30 min)

**Values-style round:** detected, because the recruiter's own words name "values and leadership philosophy". No published company values are in hand, so no values cheat sheet is included. Every VAL question uses a selection scaffold with its honest branch, as the rules require.

**Persona weights** (relationship prior: skip-level and executive → Values/Behavioral and Case, with Pressure; the recruiter's words make Values/Behavioral the top weight):

| Persona | Weight | Depth | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Top | 4 | The recruiter named this round. Past behavior, in STAR shape, is the scoring. | "We" for context, "I" for your decisions. Choose a story where the hard part actually landed, and say plainly when the material shows none. |
| Pressure | Mid | 2 | Thirty minutes at this altitude tests composure, and the reliability quarter will be pressed on attribution. | Hold a position through two follow-ups. Concede uncertainty specifically, without folding on the core claim. |
| Case/Strategist (strategy-heavy) | Mid | 2 | An executive will test how you would think about the business, not just the team. | Clarify the goal before answering. Structure the trade-off, name the metrics, state the risks. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 (Values) | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt, so choose the instance. Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and what happened after. If no such time comes to mind, say so plainly, then give the reliability quarter as you told it to me. | The round's theme. The honest branch is the point. |
| C2 (Values) | "What is your leadership philosophy, in one sentence you'd stand behind?" | VAL | [generic] | Answer in your own words, in a sentence that you can back with something you actually did. Do not borrow a published value, because none is in hand. | The recruiter's own phrase. Presupposes nothing about you. |
| C3 (Values) | "When did you put a team's health ahead of a deadline?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-map the reliability quarter: the roadmap pressure, and what you pushed through. Answer slot: if you know how the roadmap side responded, say so; if not, say so. | The quarter is the story your material carries for this theme. |
| C4 (Values) | "Tell me about a hire you're proud of, and what you did to make it work." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. Story-map the hiring loop, in your words. Answer slot: name one specific hire and what you did; if no such hire comes to mind, say so. | F4. The round weights growth and people, so a specific hire helps. |
| C5 (Pressure) | "That reliability quarter: how much of it was actually you?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" and "My team's on-call burden dropped 60%" (both your message) | Hold: "I pushed it through." Through two follow-ups, return to the push. Concede precisely: name the parts you did not decide, and do not add a credit you did not state. Answer slot: which parts were yours to decide. | The attribution probe. Hold-then-concede, never a fold on the core. |
| C6 (Pressure) | "Sixty seconds: what would you be worst at, in a job where hardware is half the roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the learning plan, as a plan. | F3, a gap you stated. |
| C7 (Case) | "How would you decide between two roadmap items you want done this quarter?" | CASE | [generic] | Clarify the goal and the constraints. Structure the trade-off, name the metrics, state the risks, challenge one premise. | A live problem. Presupposes nothing about you. |
| C8 (Case) | "Our device business has to grow while hardware cycles slow. What would you ask me first?" | CASE | [generic] | Ask for the goal, the constraint and the timeline before you answer anything. Claim no knowledge of the company's strategy, because none was researched. | Strategy-heavy, and the one place the pack cannot draw on company research. |

**Reverse questions for this round:**
- "What leadership behavior do new managers here most often misjudge in their first year?" Why it lands: asks for the real bar, in their words.
- "What would make you say in six months this was the right hire?" Why it lands: makes the success measure theirs, which the VP will answer.

---

## Requirement coverage

| Requirement (your role description) | Questions |
|---|---|
| Lead two squads building device-management services | A1, A2, A9, B7 |
| Own delivery, hiring and growth for 11 engineers | A3, B5, B6, C4 |
| Partner with hardware and product on roadmap | A4, A8, B1, B7, B8, C3 |
| The hardware-adjacent roadmap (the gap you stated) | A5, C6 |
| Values and leadership philosophy (recruiter's words, Round 3) | C1, C2, C3, C5 |

Session total: 25 questions across three rounds (9, 9, 8). Within the 18–26 range.

---

## Sources

**Provided documents:** your message, which gave the role description, your background, the three rounds and the recruiter's "values and leadership philosophy" phrase. No CV, full posting or company document was provided.

**Target accounting**

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. The values cheat sheet is not included. The VAL questions use selection scaffolds with honest branches. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. The loop is established by your own words (three rounds, durations, who runs each), so the persona weights follow your rounds, not a verified company process. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Every call was refused. The CO bank is absent; C8 is generic and says so. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so no query could be formed. |
| 5. representative role JD | skipped | Your role description fixes the fit snapshot and the JD-tagged questions. It is a summary, not the posting. |

**Searches sent, all refused:**
- "Larkfield Systems values" (target 1): refused.
- "Larkfield Systems interview process engineering manager" (target 2): refused.
- "Larkfield Systems strategy industrial IoT device management" (target 3): refused.

No fetches were sent. Nothing in this pack comes from a web source.

---

## Upgrade menu

- **The full job posting, pasted** → six requirements read from your summary become grounded in the posting's own words, and the mid-list requirements get JD questions. This also tests whether the posting says anything about managers, hardware or the 11 people.
- **Your CV, pasted** → the medium rows gain an inspectable artifact to name, and the defend-the-number slots can point at a document rather than your memory.
- **Whether the 11 engineers report through leads or directly to you** → settles the manager-layer question, and turns the "never managed managers" entry from a plain acknowledgment into a live slot about the structure you would be walking into.
- **The interviewers' names** → per-round persona weights from their public footprint, and a reverse question tied to each person's path.
- **The recruiter's format note for each round** (any presentation, take-home, or what each session tests) → graded-deliverable sections, if any were declared.
- **A company values page, pasted or linked** → Round 3 VAL questions map to the published values, and a values cheat sheet is built.
- **Permission for web search** → reruns targets 1 to 3 (values, loop, strategy), which would fill C2 and C8 with company-specific guidance. A deeper research pass is also available once that works: up to six more searches and two more fetches, several more minutes. Want it?
- **Any roadmap contact with hardware or product, even informal** → F2 can carry it, and A8 and C5 get a stronger story.
