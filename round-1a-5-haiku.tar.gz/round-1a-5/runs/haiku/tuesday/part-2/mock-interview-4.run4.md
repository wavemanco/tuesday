Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-4-denied-78b3bb00/354e3c5d-51af-421c-a352-3f066a5bf121/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md, and I've sent it to you to render. I built it for the hiring-manager round, using your dossier.

Web search was refused in this session, so the pack has nothing on Quartzline's values, interview loop or current strategy. Those sections are absent rather than guessed. The Sources section records the refusals.

The most important part is the Skeptic bank. Question S1 is the objection your dossier names, "why hire you into a PM role instead of a PM with three years of the job." Rehearse it until the wording is dull. Hold on the integration work and the playbook. Then state the limit: you haven't held a PM title or owned a roadmap. Concede that specifically, and give a ramp plan framed as a plan, not as a past.

Two offers, one line each:
- I can run a live drill with me as the Skeptic on S1, then give feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions. Your dossier is dated 14 August, so if the posting has changed since, it may be out of date.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Quartzline: Product Manager, Platform APIs. Hiring-manager prep pack

**Role:** Product Manager, Platform APIs
**Company:** Quartzline
**Round:** Hiring manager, 45 minutes, Thursday
**Interviewer:** not named (the persona weights below are round priors, not an interviewer read)
**Built from:** the underwriting dossier (decision conditional_go, generated 2026-08-14). Sections used: role_profile, handoff_to_mock_interview, decision. No CV or research beyond the dossier was available.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types used here: **JD** (the listed job, including its gaps), **EXP** (what you actually did, and how much of it was yours), **CASE** (a live problem from the role). CO (company strategy) and VAL (values) are absent: no strategy was retrieved, and no values round is detected.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.
- An **answer slot** is an instruction for the interview, not a question to me. It has two honest branches.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, via dossier R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | low | [grounded] | transferability | The material shows client integration work, not a PM role. Bridge with the limit: "I led client integrations of the vendor's REST APIs. I haven't held a product manager title." Answer slot: if any part of those integrations was yours to decide, say which and how you decided; if none was, say so and stay with the integration work. |
| F2 | "Own the roadmap for the partner-facing API platform" (JD, via dossier role_profile) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's prohibited_claims and acknowledge_gap entries: "I haven't owned a product roadmap." Then a ramp plan, said as a plan, never as a past. Never a claim to roadmap work. |
| F3 | "Shipped API or platform products" (JD, via dossier R2) | none given | low | [grounded] | discovery | The dossier does not grade this requirement, and the material is silent on it. Answer slot: if you shipped an API or platform product, say what it was and your part in it; if you did not, say so and describe the nearest integration work you led, without calling it a shipped product. |
| F4 | "Technical fluency: API docs, schemas" (JD, via dossier R3) | "Wrote the internal integration playbook her team uses" (dossier verified evidence 2) | high | [grounded] | discovery | The playbook carries the documentation claim. It does not show API reference docs or schemas. Answer slot: if you wrote or reviewed API reference docs or schemas, say which and what you did; if you did not, say so and say what the playbook covers, in your own words. |
| F5 | "Stakeholder management across engineering, sales, customers" (JD, via dossier R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence 3); "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | medium | [grounded], confirmed with limited inspectable proof: expect a probe | discovery | The quotes reach clients and product. They do not show engineering or sales. Answer slot: if you worked with engineering or sales on any of this, say what happened and what part was yours; if you did not, say so and stay with the roadmap-input sessions. |
| F6 | "Agile delivery experience" (JD, via dossier R5) | none given | low | [inferred] | discovery | Clarify strategy. Answer slot: if you ran delivery in sprints or with a product team, say how it worked; if you worked another way, say how you define delivery and what you would want to confirm about their process. |
| F7 | "Define and track adoption metrics" (JD, via dossier role_profile) | none given | none | [grounded] | discovery | Adoption is named as a responsibility, and no current baseline is stated anywhere. Answer slot: if you defined or tracked an adoption measure, say which and what it counted; if you did not, say so and say what you would measure first. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title." Sourced acknowledgment. |
| Having owned a product roadmap | dossier prohibited_claims | "I haven't owned a product roadmap." Sourced acknowledgment. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Sourced acknowledgment. No slot names it. |
| Owned the partner API platform | Inflated form of F1 and E1 (built locally) | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's own observation: your material says integrations, not the platform. |
| Ran the product roadmap | Inflated form of dossier verified evidence 3 (built locally) | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: your material says the sessions, not the roadmap. |

## Question banks

**Persona weights (round prior, not interviewer-read).** The hiring-manager prior is Case/Strategist plus Skeptic, which sets the weights below. No loop source establishes Quartzline's loop, so the archetype fallback is generic: flat weights, stated plainly. Expect a conversation, not a panel.

### A. Skeptic (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1); "Having held a product manager title or role" and "Having owned a product roadmap" (dossier prohibited_claims) | Highest-ROI prep in this pack. Hold on the integration work: "I led client integrations of the vendor's REST APIs," and the playbook if asked. Then the limit: "I haven't held a product manager title, and I haven't owned a product roadmap." Hold through two follow-ups by returning to the integration work. Concede specifically: the PM title and roadmap authority are not proven yet. Then a ramp plan, said as a plan. Do not add years. | The underwriter named this objection. It is aimed at F1 and F2, the two thinnest areas, so the wording must stay at the quote's scope. |
| S2 | "Owning the roadmap for the partner-facing API platform is the job. Which part would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (JD, via dossier role_profile) | Name the roadmap gap plainly: "I haven't owned a product roadmap." Then one concrete ramp step, said as a plan. | F2. This is the Skeptic's favourite opening and it asks for the gap, not a bluff. |
| S3 | "Three years of product management is the requirement. How would you handle that gap?" | JD | [grounded] "3+ years product management experience" (JD, via dossier R1); "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | Bridge with the limit named: the integration work is adjacent, not the same job. Say that in those words. Then a ramp plan: for example, pairing with a PM on the first spec. | F1, transferability. The bridge is the integration work at its own scope. |
| S4 | "The role defines and tracks adoption metrics. What have you measured?" | JD | [grounded] "Define and track adoption metrics" (JD, via dossier role_profile) | Answer slot (F7). If you defined or tracked an adoption measure, say which and what it counted. If you did not, say so plainly and say what you would measure first. | F7. No baseline is stated for this role, so the question also tests whether you ask for one. |
| S5 | "Name an API or platform product you shipped, and your part in it." | JD | [grounded] "Shipped API or platform products" (JD, via dossier R2) | Answer slot (F3). If you shipped one, say what it was and your part. If you did not, say so and return to the integration work, without calling it a shipped product. | R2 is a must-have, and the dossier does not grade it. Expect this to be asked directly. |

### B. Case / Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A partner needs an endpoint the roadmap doesn't have. Walk me through how you'd decide." | CASE | [generic] | Clarify, then objective, then segmentation (which partners, how many integrations need it), then approach, then metrics, then risks. Think aloud. Name the adoption measure you would watch. Make no claim about your own past. | Tests the JD line on discovery with partners. Generic pattern, so it carries no claim about you. |
| C2 | "Adoption of the partner API dropped 20% last quarter. Diagnose it." | CASE | [generic] | First ask for the baseline and how adoption is counted. Then segment: which partners, which endpoints, which months. Then propose one check per hypothesis. | F7 and the dossier's open risk: no current baseline is stated. Asking for it is the strong move. |
| C3 | "Two engineering squads disagree on sequencing: one wants stability fixes, the other a new endpoint. What do you do?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (JD, via dossier role_profile) | Structure: what each squad is optimising for, what the partners need, and who decides. Say that you need to know who decides before you answer for it. Do not claim squad authority. | The JD's squad line. Decision authority is unknown, so a reverse question covers it. |
| C4 | "A large customer and the sales team want different API terms. Which do you back?" | CASE | [generic] | Structure: what each side is protecting, the adoption effect of each, and a stated rule for deciding. Make no claim about past negotiations. | JD stakeholder line (F5). Generic, so no claim about you. |
| C5 | "Walk me through how you deliver work with engineers: cadence, roles, and where agile fits." | JD | [inferred] "Agile delivery experience" (JD, via dossier R5) | Answer slot (F6). If you ran delivery in sprints or with a product team, say how it worked. If you worked another way, say how you define delivery and what you would want to confirm about their process. | F6, clarify strategy. The dossier rates this low, so the answer uses only what you can say. |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that integration count was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | Answer slot, since the figure raises a defend-the-number slot. Say how the count was kept, in your own words. If it was not kept as a count, say so and say what you can account for. | The 30+ figure is the most likely target for a prober. |
| P2 | "Which assumption behind that 30+ would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | Name the assumption you would defend least, in your own words, before the interviewer does. If you do not know how it was counted, say so. | Weakest-assumption move. It turns a gotcha into a credibility gain. |
| P3 | "What did the integration playbook cover: API docs, schemas, or neither?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified evidence 2) | Answer slot (F4). If you wrote or reviewed API docs or schemas, say which. If neither, say what the playbook does cover, in your own words. | R3 is tested here. The playbook is strong evidence for documentation work, but not for schemas. |

### D. Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "That result. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1) | Pause, restate the question, then answer from the integrations you led. Hold through two follow-ups. Concede only the specific limit: which parts you can and cannot account for, in your own words. | Tests composure. Hold, then concede specifically, never fold on the core claim. |
| PR2 | "You're asking me to own a roadmap you've never owned. Why should I believe you can?" | JD | [grounded] "Having owned a product roadmap" (dossier prohibited_claims) | Concede the gap plainly: "I haven't owned a product roadmap." Then the ramp plan, as a plan. Do not argue that the integration work equals roadmap work. | The Pressure version of S1. Holding the position means holding the limit, not inflating it. |
| PR3 | "Tell me about a time you pushed back on an engineering or sales priority." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence 3) | Open prompt (raised by JD R4). If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the roadmap-input sessions, and what fed into them. | Honest branch built in. The material does not show a pushback, so do not supply one. |

### E. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CV1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified evidence 1); "Wrote the internal integration playbook her team uses" (dossier verified evidence 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence 3) | A 90-second arc using only the three quotes, in order: the integrations, the playbook, the roadmap-input sessions. Then one clause on the PM gap. | Casual questions are still scored. Keep it to the three verified claims. |
| CV2 | "What are you playing with in APIs these days?" | JD | [generic] | Name the API you worked with most, only if you can name it. Otherwise say which part of the integration work you know best. | R3 asked casually. It is scored like any other. |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1: 3+ years product management | S1, S3, PR2 |
| Own the roadmap | S2, S1, PR2 |
| R2: Shipped API or platform products | S5 |
| R3: Technical fluency, API docs, schemas | P3, CV2 |
| R4: Stakeholder management | C3, C4, PR3 |
| R5: Agile delivery | C5 |
| Run discovery with integration partners | C1 |
| Write specs and drive delivery with two squads | C3 |
| Define and track adoption metrics | S4, C2 |

Session total: 18 questions.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Persistent probing of the PM gap and the roadmap gap | High. The hiring-manager prior, plus two named gaps in the dossier | Rehearse S1 until it is boring. Bridges at the quote's scope, and the limit said plainly |
| Case / Strategist | Live problems on the partner roadmap | High. Hiring managers buy capability and test it on live problems | Clarify, then structure, then metrics. Ask for the baseline first |
| Data-Driven Prober | The 30+ figure and the playbook's scope | Medium. Prober weight rises only if the interviewer is data-driven, and nothing says so | Answer the defend-the-number slots in your own words |
| Pressure | Challenges to the PM gap | Medium. The objection is the one most likely to be pressed | Hold the limit, concede the specific gap, do not inflate |
| Conversational | A casual "walk me through" | Low. Casual openers are still scored | A 90-second arc from the three verified claims |

## Reverse questions

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the JD asserts this authority and nothing in the material evidences it. Asking it reads as diligence and answers what you need before accepting. (dossier questions_for_employer)
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: adoption is named as a responsibility, and no baseline is stated. The answer tells you whether the metric exists. (dossier questions_for_employer)
3. **"What does success look like at the end of the first 90 days for this role?"** Why it lands: it anchors your ramp plan in their definition instead of yours.
4. **"Which integration partners matter most to the roadmap this year?"** Why it lands: it tests the discovery responsibility and shows you intend to do it.
5. **"What would make you say the first six months went well?"** Why it lands: it sets the outcome you will be measured on, and it reads as a peer question.

## Sources

- **Provided documents:** the underwriting dossier (decision conditional_go, 2026-08-14). Sections used: role_profile, handoff_to_mock_interview, decision.
- **Searches sent:** three. All three were refused, because web search permission was not granted in this session:
  - "Quartzline values operating principles": refused
  - "Quartzline interview process product manager platform APIs": refused
  - "Quartzline strategy news": refused

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet. Refused, so none. No values round is detected either. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure. Refused, so the loop is the generic fallback with flat weights, stated above. |
| 3. Quartzline strategy / recent news | unavailable | CO bank. Refused, so no CO questions. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the JD. |

## Upgrade menu

- **Permission for web search** → the values, loop and strategy targets above. This would add CO questions and a values cheat sheet if a values round exists.
- **The interviewer's name** → persona weights from public footprint, and a reverse question tied to their own path.
- **Full JD text** → checks the dossier's requirement lines against the posting's own wording. Currently the requirement lines are the dossier's copies.
- **Your CV** → story beats beyond the three verified claims. Would upgrade F3 and F7 if it carries a shipped product or a tracked metric.
- **An adoption baseline, or the recruiter's focus areas** → recalibrates C2 and S4 and the reverse questions.
- **Any recruiter note on the round format** → coverage of the 45 minutes.
