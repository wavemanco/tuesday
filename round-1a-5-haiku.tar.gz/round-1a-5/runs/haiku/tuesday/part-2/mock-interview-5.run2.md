I couldn't run web research: the search tool was refused in this session, so I've built the pack from your message and the recruiter's email alone. Writing the pack file now.
Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-5-denied-77f87a03/kelverton-rail_senior-partnerships-manager_interview_pack.md. It's built for the panel from the recruiter's email and your background only. Web search was refused in this session, so there is no company, values, or interviewer research in it, and the internal market report isn't included.

Say the word and I'll play the Skeptic on B1, the rail question the pack names as the highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later rounds.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD text? If not, I'll work from the recruiter's wording, but the requirement rows will stay as they are until the posting is in.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep pack

**Role:** Senior Partnerships Manager
**Company:** Kelverton Rail (UK rail-tech, about 600 staff; sells scheduling software to train operating companies, as you described it)
**Round:** Second-round panel, 60 minutes. First 15 minutes: a spoken POV on where to take operator partnerships over 18 months, no slides, landing on what it means for the operators themselves. Then Q&A, with commercials pressed.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
**Built on:** the recruiter's email as you quoted it, and your background message. No job description was supplied, and web research was refused in this session, so the requirements come from the recruiter's words and no company, interviewer or market facts are used. Nothing here is about the internal market report, which is not in this session.

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **CASE**: a live problem, structured out loud
- **EXP**: a deep-dive on something in your background, testing what you actually did
- **JD**: a question on the role's stated needs, including its gaps

Not used in this pack: CO (no company research was available) and VAL (no values-style round is named, see section 8).

Guidance is scaffolding, not a script. Each cell is written to be said in 90 to 120 seconds.

## 2. Prep triage (about 4 hours)

1. **75 min: build the POV.** Write it as three spoken beats: the operator's problem, two theses each with its concession, and the close on what it means for operators. Say it aloud twice, timed to 15 minutes. (Section 5.)
2. **60 min: drill the three hardest moments.** B1 (never sold into rail), B2 and C3 (influenced revenue, not sold). Take two follow-ups on each.
3. **45 min: the commercials.** C1, C2, C5. Write down the inputs you would need before naming any price. Do not write a number.
4. **30 min: the figure.** D1 and D2. Only what you can say from your own knowledge of how the number was built.
5. **30 min: reverse questions.** Section 11, which you can tailor once the JD or the strategy report is in.

Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted. No gate rows are listed: no JD was supplied, and the email names no eligibility term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows a channel of partners at a payments company, not operators. Words: "At the payments company I was running the ISV channel, and I took it from 6 partners to 40." Answer slot: what carries over from that channel to operators, and what does not. Say it in your own words. |
| F2 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Network planning is adjacent to operator work, and the material does not show whether your clients were operators. Words: "Five years in transport consulting, on bus and light rail network planning." Answer slot: say who the clients were. If they were operators, say what that work showed you about how they plan change. If they were not, say who they were. |
| F3 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | The figure reaches commercial terms, but its scope is influenced, not sold, and the bridge keeps that word. Words: "The channel I ran was roughly £4M of influenced revenue." |
| F4 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota, only influenced revenue." Then how you would take ownership of a number, said as a plan, never as a past. |
| F5 | "our operator partnerships" (recruiter email) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't sold into rail." Then how you would learn the buyer, said as a plan. Do not add rail credentials to close the gap. |

**Pack observation, not words for you:** your material shows commercial influence and channel growth. It does not show direct revenue ownership or any sale into rail.

## 4. Persona weights for this panel

No interviewer profile was readable, so the weights rest on the relationship and the recruiter's words.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Turns the POV into a live problem; asks what you would do first and why | High. Deepa is the hiring manager, and the recruiter asked for a POV on the operator plan. The POV is a case, and Q&A extends it. | Structure before answer: say what you need to know, then the one thing you'd start with and why. |
| Skeptic (Deepa) | Quietly presses the rail gap and the quota gap | High on F5 and F4. A hiring manager is buying capability and derisking gaps, and these are the two largest gaps the snapshot shows. | Rehearse the rail objection until it is plain. Plain acknowledgment, then a plan. |
| Pressure (Ross) | Time-boxed challenges on commercials; questions whether the figure is yours | High. The recruiter wrote that Ross will push on commercials, and this is the commercial director's usual register. | Pause, restate the question, hold the sentence's scope, and concede only what you cannot defend. |
| Data-Driven Prober (Ross) | Asks how the £4M and the 40 partners were counted | Medium-high. Both figures sit on your CV, and a prober starts there. This weight comes from the recruiter's line, not from any read of Ross. | Name the weakest assumption before the panel does. Say plainly what you don't know. |
| Values / Behavioral | Not weighted | Not detected. The recruiter's email names no values round, and the email establishes this session's content, so no archetype fallback applies. | None |

## 5. The 15-minute POV (graded deliverable)

**The brief, as the recruiter wrote it:** "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." And: "Please land on what it means for the operators themselves."

**Facts to build on:** F1 and F2, quoted above. Nothing else about your past goes into the POV.

| Thesis | Provenance | Concession | Rationale |
|---|---|---|---|
| 1. Operators buy an outcome they can run their timetable on, not a scheduling product. | [generic] a hypothesis about the market, not a fact about this employer | "I haven't sold into rail, so I don't yet know which operator measures a scheduling tool moves. If they don't touch scheduling, this thesis is wrong." | Gives the panel a claim to test. |
| 2. A few deeper operator partnerships beat a wider list. | [generic] a hypothesis about the market | "Depth costs your engineering and success capacity. I haven't seen Kelverton's numbers, so I can't say what the depth costs here." | Turns the ISV playbook into a question the panel can argue with. |
| 3. Start the 18 months with planning change, the timetable and network changes operators already have to run. | [grounded] "bus and light rail network planning" (your message), at its own scope | "That work may not have been with operators (F2's slot). Check that before you use it as a reason." | The one thesis that draws on your background. |

**Consensus answer and differentiation:** the consensus is a partner-led scale-up, which is the playbook behind F1. Differentiate by saying why that playbook counts partners, not operator outcomes. **Anti-pick:** do not pitch channel expansion as the operator strategy. Say so, with the reason.

**Requested close:** "what it means for the operators themselves." Close on what changes for an operator, in the terms their own planning team would use. Answer slot: name that one thing in your own words. If you cannot name it, say what you would measure first.

**Rough timing:** operator problem, 2 min. Thesis 1 with concession, 4 min. Thesis 2 with concession, 3 min. Thesis 3 with concession, 3 min. Operator close, 3 min.

## 6. Reading the interviewers

Not built. The search for Deepa and Ross was refused, so there is no public footprint to read. Upgrade menu, section 15.

## 7. Question banks

Requirement coverage:

| Requirement | Covered by |
|---|---|
| "our operator partnerships over the next 18 months" | A1, A3, A4, section 5 |
| "what it means for the operators themselves" | A2, A3, section 5 close |
| "Ross will push on commercials" | C2, C5, D2, D3 |
| "Never sold into rail specifically" (F5) | B1 |
| "never carried a direct quota, only influenced revenue" (F4) | B2, C3 |
| The 60-minute format and the 15-minute POV | Section 2, section 5 |

**Highest-ROI prep: B1.** It is the rail objection (F5) and the most likely hard moment. Deepest rehearsal goes here.

### Bank A: Deepa, Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | Say what you need to know first: which operators, what they buy, what success looks like to them. Then the one thing you would start with, and why. Name the trade-off you are choosing. | The POV question, asked as a probe after your 15 minutes. Tests whether your structure survives a follow-up. |
| A2 | "What does this mean for an operator's planning or operations team, day to day?" | CASE | [generic] | Speak to one operator role at a time: the person who redoes the timetable, the one who carries the disruption. Say what changes for them and how you would know. Do not describe any real operator's internal structure. | The recruiter asked you to land on operators. Deepa will test whether you can describe the operator's day. |
| A3 | "Which operators would you start with, and what would make you stop with the first one?" | CASE | [generic] | Segment before you pick: fleet size, how often they change timetables, appetite for a pilot. Name a stop condition before you start. | Tests whether your pick has a reason. Segment criteria are a pattern, not a claim about these operators. |
| A4 | "Give me the 18 months in three steps. What do you stop doing?" | CASE | [grounded] "took it from 6 partners to 40" (your message) | The stop-doing step is the one most candidates skip. Name one motion from the channel playbook you would not repeat with operators, and say why. The quote is partner count, so say what that playbook measured. | Deepa is looking for judgment about what not to do. The channel story is the most available answer, and this turns it into a limit. |
| A5 | "What would you need from this team in the first 90 days to make the plan real?" | CASE | [generic] | Name two or three dependencies: data, product access, a first operator pilot. Say which one you would ask for first. | Hiring-manager question about delivery. It also sets up the reverse questions. |

### Bank B: Deepa, Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What would you get wrong first?" | JD | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep.** Plain acknowledgment: "I haven't sold into rail." Answer slot: name the first assumption you would check with an operator, and how you would learn the answer. Hold through a second follow-up by returning to what you would check, not by listing rail credentials. | F5, the largest gap, and the objection the panel will not let go of. |
| B2 | "You never carried a quota. Why should we trust you with the revenue line?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I've never carried a direct quota, only influenced revenue." Then say what you can point to. Answer slot: if you know how the influenced figure was counted, say so. If you don't, say so plainly. | F4's stated absence. The honest answer is the sentence plus a credible plan for taking ownership. |
| B3 | "Is your £4M sold revenue or influenced? Which part did you close?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the sentence's scope: the figure is influenced. Answer slot: if you closed any of it, say which and what you did. If you closed none, say so and describe what you did to influence it. Never restate the figure as sold. | F3's attribution probe. The reframe that fails is "£4M" drifting into "I delivered £4M". |
| B4 | "Your partners were software firms. Operators are customers. What carries over?" | JD | [grounded] "took it from 6 partners to 40" (your message); [grounded] "running the ISV channel" (your message) | Name what carries over: recruiting and enabling partners. Name what does not: the buyer is different. Do not claim operator buyer experience. | Deepa will test whether the transfer is real. The answer that names the seam is the credible one. |

### Bank C: Ross, Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why would an operator trust someone from a payments company with their timetable?" | JD | [grounded] "so I know the operator world from the other side" (your message); [grounded] "at a payments company running the ISV channel" (your message) | A 60-second arc in three beats: your transport consulting on the operator side (quote), the channel you ran (quote), and one thing you would do first with an operator. Do not claim operator experience you do not have. | Pressure question on the pivot. The arc is the answer, and it rests only on sentences you wrote. |
| C2 | "Give me the number you'd put on an operator partnership in year one." | JD | [grounded] "Ross will push on commercials" (recruiter email) | Do not invent a figure. Say what you would need first: what the operator pays today for the work this replaces, your cost to serve, the contract term. Name one assumption you would test first. | The commercials push will come as a number request. A figure invented here is the quickest way to lose the panel. |
| C3 | "Your £4M is influenced. Isn't that just the partner's revenue with your name on it?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the position: the figure is influenced, and the sentence says what it says. Hold through two follow-ups. Concede specifically: the part of the count you cannot defend without the method, if you don't know it. Never fold on the figure's scope. | Pressure on attribution. The held position is the one your sentence carries. |
| C4 | "What did you actually decide in that channel, and what did someone above you decide?" | EXP | [grounded] "running the ISV channel" (your message) | Answer slot: say which decisions were yours, in your own words. If none were yours, say so plainly. Do not claim decisions the sentence does not carry. | Attribution probe. The honest answer depends on what you decided. |
| C5 | "Walk me through how you'd price an operator contract." | JD | [generic] | Name the inputs before any number: what the operator pays today for the work this replaces, your delivery cost, the term. Name the decision you would make before setting a price. Use no figure from memory. | A commercial director's usual question. You have no Kelverton pricing, so the honest move is to name the inputs and the test. |

### Bank D: Ross, Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 40 partners were counted, and what counted as active." | EXP | [grounded] "took it from 6 partners to 40" (your message) | Say how partner count was taken and what counted as active, in your own words. Name the assumption you would defend least. Answer slot: if a definition of active existed, say it. If you did not set it, say so. | Partner counts are the easiest number for a prober to pull apart. |
| D2 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name it in your own words, before the panel does. If you do not know how the figure was counted, say that plainly. | The defend-the-number slot. Your figure raises it, and nothing else does. |
| D3 | "How would you know an operator partnership was working after six months?" | CASE | [generic] | Name one operator-side measure and one Kelverton-side measure, and say which you would trust more. Do not pick a rail metric you have not seen. | Measurement is the commercial director's second test. The pattern is general, not a fact about Kelverton. |
| D4 | "What would you stop tracking from the ISV model?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name one ISV metric that would not carry to operators, and why. Stay with partner count. Do not claim operator metrics you have not tracked. | Follow-on from D1. Links the commercial question to the playbook. |

## 8. Values / principles

Not built. The recruiter's email names no values round, and it establishes this session's content, so no values-style round is detected (research-checklist, values definition). The company's values page could not be read.

## 9. Graded deliverables (see section 5)

The POV is the one announced deliverable. Its build section is above.

## 10. Reverse questions

Each one has a "why it lands". No interviewer profile was readable, so none is tied to a career path. Ross and Deepa are one panel, so there is no peer-reciprocity question.

1. "What would a good first six months look like for this role?" Why it lands: Deepa will answer with the first success, which shows you what the hire is for.
2. "How do partnerships and the commercial team split ownership of an operator deal?" Why it lands: Ross's territory, and it shows you know where influenced revenue stops and sold revenue starts.
3. "When a partnership and a sale disagree about an operator, who decides?" Why it lands: tests the seam, and gives you the answer that shows judgment.
4. "What would the POV have to cover that it didn't?" Why it lands: an invitation to refine it live, and a sign you treat it as a draft.
5. "What would make you say this hire worked, in 12 months?" Why it lands: a question for the manager, and a way to find the measure the role is held to.

## 11. Delivery coaching

Not built. No working-style assessment was provided.

## 12. Prohibited claims

Built here from the fit snapshot. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I own the £4M" or "I drove £4M in revenue" | Inflated form of F3 | "roughly £4M of influenced revenue", at its own scope. The pack's observation: your material says influenced, not sold. |
| "I've sold into rail" or "I know how operators buy" | Inflated form of F5 and F2 | "I haven't sold into rail." For the transport work: "bus and light rail network planning" and "so I know the operator world from the other side", as you wrote them. |
| "I carried a quota" | Negative you stated, F4 | "I've never carried a direct quota, only influenced revenue." Plain acknowledgment. |
| "I've run scheduling software" | Inflated form of F2 | "bus and light rail network planning", at its own scope. |
| "I scaled operator partners" | Inflated form of F1 | "the ISV channel, from 6 partners to 40", at its own scope. |

## 13. Sources

- **Provided:** the recruiter's email, as you quoted it in your message; your background message.
- **Not in this session:** the internal market report you read. Its content is not used here.
- **Research tier:** L1, searches 6 of 6 (all refused), fetches 0 of 2. The host refused the web search permission, so no call returned anything.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values principles` | unavailable | Would have set the values cheat sheet. Not detected as a values round in any case. Query refused. |
| 2. `Kelverton Rail interview process Senior Partnerships Manager` | unavailable | Would have confirmed the loop. The recruiter's email already establishes this session. Query refused. |
| 3. `Kelverton Rail strategy news operators scheduling software` | unavailable | Would have moved the CO bank and the POV's current context. Query refused. Pasting the strategy report would substitute for it. |
| 4. `Deepa VP Partnerships Kelverton Rail`; `Ross Commercial Director Kelverton Rail` | unavailable | Would have set the interviewer read and persona weights. Both queries refused. |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have grounded the requirement rows. Query refused. |

## 14. Upgrade menu

- **The JD text** → the requirement rows in section 3 move from the recruiter's words to the posting's words, and the gate check becomes possible (location, travel, right to work).
- **The internal market report, pasted** → the POV can differentiate from its consensus items instead of reciting them. Anti-pick and consensus rows in section 5 get checked against it.
- **Deepa's and Ross's public footprint**, once the search permission is granted → interviewer read, persona weights for each panel member, and a tailored reverse question.
- **The recruiter's reply on the POV format** (written or spoken, length limits, whether a values or competency round is planned) → confirms or changes the values cheat sheet and the POV build.
- **Your clients in the transport consulting years** (operators, or authorities and others) → upgrades F2 from transferability to a grounded claim, or sets the honest form of thesis 3.
