Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-8-canned-16e89b6f/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it in loop mode, one section per round, because the recruiter's email gives each round's length and format. It's built from your message, since no CV was supplied.

Say the word and I'll play the Head of Member Services on 2K1, the question the pack names as its highest-ROI prep: presenting above regional level, which the JD asks for and your background doesn't yet show.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

Built 25 November 2026 for three rounds on 4 December 2026. Loop mode: one shared fit snapshot, then a mini-pack for each round. Built from your message, since no CV was supplied. Interviewers beyond the recruiter and the Head of Member Services are not yet assigned, so the panel's persona weights rest on the recruiter's description of the round.

## How to use and type key

- **Personas** are how a question arrives. **Types** are what it scores.
- Type tags: VAL behavioural and values; EXP your own experience; JD the role's listed requirements; CO company and strategy; CASE a live problem.
- Provenance labels: `[grounded]` traces to a document you supplied or a sentence you wrote; `[inferred]` is a derivation, named in the cell; `[generic]` is a pattern for this kind of role, not a fact about Ashgrove.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: give your true answer in whichever branch applies. It asks nothing of you here.

## Sources and research

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values, copied 25 November 2026 from the values page and pasted in your message, fix the names and wording. No search. |
| 2. Interview process | skipped | The recruiter's email fixes the loop: three rounds on 4 December, their lengths and formats, and the 20-minute complaint-escalation case. It is a loop source that establishes the loop, so no archetype fallback applies. |
| 3. Strategy and recent news | skipped | Your summary of the July 2026 strategy brief fixes the priorities. It is a summary, not the document, so the grounding brief uses only the figures in it. |
| 4. Interviewer footprint | n/a | No interviewer is named. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Provided documents used: the JD text, the recruiter's email, the values copy, the strategy brief summary, and your background in your message. No web search or fetch was sent.

The recruiter's email documents a values-style round: the panel scores against the four values. So the values cheat sheet and the VAL questions in round 3 are built.

## Fit snapshot

Every quote is verbatim. The source is your message unless the row says otherwise. No requirement in the JD is a gate under the evidence conventions: "4+ years" is a length-of-experience requirement, graded on fit.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your message reaches the years and the sector, and the words stay there: "Six years in retail banking, the last three as a branch supervisor." Whether a branch role counts as customer operations is the interviewer's call, so nothing is added to it. |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log is not an end-to-end process across branches, and the bridge stays with the log: "I handled the branch's formal complaints log." Answer slot: if you ran any step beyond the log, such as intake, decision or closure, say which step and how you decided it; if you did not, say so and stay with the log. |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this absence, so it is the words you give back: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] derived from F2's quote, since your message does not say whether the log was regulated | discovery | Answer slot: if the log ran to a regulatory timetable or an outside referral route, say which and what was yours within it; if it did not, say so and describe the timetable you did work to. |
| F5 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your message reaches monthly complaint reporting in other words. Say it in those words, with no figure or measure added. |
| F6 | "resolution times" — JD | none given | none | [grounded] | discovery | Nothing you said shows resolution times. Answer slot: if you have measured or reported resolution times before, say how you counted them and what you reported; if you have not, say so and say what you would define first. |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | none | Your message says spreadsheet, not Excel, but a monthly complaints spreadsheet reaches the requirement in role terms. Expect a probe on what you built. The spreadsheet itself is the artifact that would raise this row (upgrade menu). |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this absence, so the words are yours to give back: "I've never presented to anyone above regional level." Then how you would build that skill, as a plan. |
| F9 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and the bridge stops there: "I trained new tellers on our escalation script." Answer slot: if you coached any supervisor on an escalation, say what you did; if not, say so and say how you would approach it. |
| F10 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you had any part in a digital change to a member journey, say which and what was yours; if none, say so and say how you would find out what the digital teams are building now. |

## Prohibited list

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and the pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F2 | F2's quote at its own scope. Observation, for you and not as words to say: your material shows one branch's log. |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. Observation: your material does not show whether the log was regulated. The answer slot stays inside the log. |
| Worked in a contact centre | Negative you stated, F3 | "I've never worked in a contact centre." No slot. |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot. |
| Trained supervisors on escalations | Inflated form of F9 | F9's quote at its own scope: tellers. |
| Wrote the escalation script | Inflated form of F9 | Your words are "our escalation script", which is the branch's script. |
| Reported complaint figures to senior leaders | Inflated form of F5 | The spreadsheet is one your regional manager uses. Say that and nothing more. |

## Persona weights

| Round | Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter screen | Conversational | top, 4 questions | Recruiter prior: logistics and motivation in a friendly register | Prepare a 90-second background arc; treat casual questions as scored |
| 1 | Skeptic, light | 2 questions | The screen is where the contact-centre gap surfaces first | Plain acknowledgment, then a plan |
| 2 Head of Member Services (your manager) | Values/Behavioral | top, 5 questions | The hiring-manager prior is Case and Skeptic, but the recruiter says the round is "mostly behavioural", which moves values to the top | STAR-shaped stories; selection scaffolds where your material is silent |
| 2 | Skeptic | 3 questions | Your manager is checking the two gaps the JD names: presenting above regional level and the contact centre | Hold, then concede specifically |
| 2 | Case/Strategist | 2 questions | Strategy questions on hubs and digital | Clarify before structuring |
| 3 Panel of two branch managers | Values/Behavioral | top, 4 questions | The recruiter says the panel scores against the four values | One story per value, or the honest branch where none exists |
| 3 | Case/Strategist | 2 questions | The 20-minute complaint-escalation case | Clarify, objective, segmentation, approach, metrics, risks |
| 3 | Pressure | 2 questions | The panel can time-box and press the contact-centre gap | Pause, restate, hold through two follow-ups |
| 3 | Panel members | not assigned | Weights blend each member's top two personas once names are known | Upgrade menu |

## Grounding brief

From your summary of the July 2026 strategy brief. The brief itself was not checked, so quote only these figures:

- 40% of member service moved to digital channels by 2028.
- Eight branches consolidated into five hubs over 2027.
- A small-business lending product launched in Q1 2027.
- The main competitive pressure is app-only banks.

Working vocabulary: member service, digital channels, branch, hub, small-business lending. Nothing in the material is stale or contested.

## Values cheat sheet

Working meanings are paraphrased from the values copy. None of your quoted sentences carries a finished story for any value, so each row gives a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: pick a time you decided from the member's side against a process or a branch's convenience, and say what it cost you. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled (F2). |
| Plain Words | If a member needs it explained twice, the writing was wrong | Scaffold: pick a time a member needed something explained twice and say what you changed. If none, say so plainly, then give the nearest thing your material carries: training new tellers on the escalation script (F9). |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: pick a time a local issue changed how a branch ran. If none, say so plainly, then give how you would keep a branch part of its town when service moves, drawing on six years in retail banking (F1). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: pick a problem you found and kept until it was closed. If none, say so plainly, then give the nearest thing your material carries: the monthly complaints spreadsheet you built (F5). |

## Round 1: recruiter screen (30 minutes)

Conversational leads (1C1 to 1C4), light Skeptic follows (1K1, 1K2), and the four logistics slots close the round (1L1 to 1L4).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Walk me through your background in a couple of minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Say the six years, the three as supervisor, the complaints log and the tellers, in that order, in your own words. Nothing beyond those beats. | The most predictable screen opener. The beats are the only facts on record (F1, F2, F9). |
| 1C2 | "What do you know about Ashgrove beyond the advert?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" | Name two points from the strategy summary and say what each would mean for complaints work. If you have read only a summary of the brief, say so. | The recruiter is checking whether you have done the reading. Two named points beat a list. |
| 1C3 | "Which part of this role would you find hardest to picture yourself doing?" | JD | [grounded] "across branches and the contact centre" | Name the contact-centre part plainly, and say what you would do in the first month to learn it. This is the honest version of F3. | Puts the largest gap on the table early, so the later rounds do not have to find it. |
| 1C4 | "Is there anything you'd like us to know before we pass you on?" | JD | [generic] | Use it for one line you want the next round to hear: the branch complaints log, in one sentence. Do not add an achievement you have not stated. | A closing slot. The label is generic because it is a convention, not a fact about the role. |
| 1K1 | "I can't see a contact centre anywhere in your background. Why would this role be different?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the plan: what you would learn about the contact-centre side in the first month. Hold the branch work in its own terms: "I handled the branch's formal complaints log." | The skeptic's version of F3. A plain acknowledgment with a plan is the honest form. |
| 1K2 | "Your monthly spreadsheet: what does your regional manager use it for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say what your regional manager uses it for, as far as you know. If you do not know, say so. | Premised on your own sentence, quoted whole. The probe is attribution, so the answer should stay inside what you know. |
| 1L1 | "What are your salary expectations?" | JD | [generic] | Instruction: give a figure only if you have settled one. If you have not, say you would like the band for the role first. | Pay is a logistics slot. No figure is in your material, and nothing here suggests one. |
| 1L2 | "What notice would you have to give?" | JD | [generic] | Instruction: give your actual notice period in your own words. | Notice is a logistics slot. None is in your material. |
| 1L3 | "Where are you based, and which locations could you work from?" | JD | [generic] | Instruction: name the locations you can work from, in your own words. Ask the recruiter in the same call which sites the role covers. | Location is a logistics slot. The hub plan is why the site question matters, and no site is in your material. |
| 1L4 | "Why are you looking to move on from your current role?" | EXP | [generic] | Instruction: give your own reason in one or two sentences, true to your situation and not about Ashgrove. | Reason for leaving is a logistics slot. No reason is in your material, so the slot is yours to fill. |

**Round 1 reverse questions** (one line each, why it lands):
- "What does success look like in the first 90 days?" Shows you are planning the role's real scope.
- "Which of the four values do candidates most often find hardest to show?" Shows you have read the values.
- "What is the next step after this round, and how long does it take?" Gives you the timing to plan around.

## Round 2: Head of Member Services, your manager (45 minutes)

Mostly behavioural, so values questions lead (2B1 to 2B5). Skeptic follows (2K1 to 2K3), and the Case/Strategist questions close (2G1, 2G2).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [grounded] "mostly behavioural" (recruiter's email) | Selection scaffold: pick a time you told someone senior something they did not want to hear, and say what it cost you and whether the relationship held. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly spreadsheet your regional manager uses (F5). | No sentence in your material carries an unpopular truth, so this is a scaffold, not a story. |
| 2B2 | "When did you put a member ahead of an internal target?" | VAL | [grounded] "we decide from the member's side of the counter" (values copy) | Selection scaffold: pick a time you decided from the member's side against a target, and say what the target was and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled (F2). | Members First is the first value. The manager will weight it, and the panel scores it. |
| 2B3 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2: the log, in your own words, with the one step you can name as yours. Answer slot: if the log ran to a regulatory timetable or an outside referral route, say which and what you did within it; if it did not, say so and describe the timetable you did work to. | The premise is your own sentence. The regulated-complaints probe (F4) gets settled in this answer slot. |
| 2B4 | "How would you coach a branch supervisor after an escalation that went badly?" | JD | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" | Answer slot: if you coached a supervisor after an escalation, say what you did. If you trained people on the escalation script, say what that training involved. If you did not coach a supervisor, say so and describe how you would open that conversation. | F9 is the row. The answer must not stretch "trained tellers" into supervisor coaching. |
| 2B5 | "Walk me through a monthly complaints report you'd put in front of me." | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD); "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F7: the spreadsheet you built and who uses it. Answer slot: if you have counted resolution times before, say how and what you reported; if not, say so and say what you would define first. | Covers the Excel and monthly-reporting requirements. Resolution times are not in your material, so no counting method is supplied here. |
| 2K1 | "Your experience is at regional level. How would you present a complaints trend to our senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" | The most likely objection and the highest-return prep in the pack. Plain acknowledgment: "I've never presented to anyone above regional level." Hold, through two follow-ups, to what your material carries: the monthly report your regional manager uses. Concede specifically: you have not presented above regional level. Then give a first step, as a plan. Never describe a presentation you did not give. | F8 is a requirement the JD states and your message denies. Hold-then-concede is the way through it. |
| 2K2 | "You haven't worked in a contact centre, and this role runs across branches and the contact centre. What happens to a complaint when it moves?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then a plan: what you would want to learn about who holds a complaint when it changes channel. Answer slot: if you have seen a complaint move between a branch and another team, say what happened and what was yours. | The skeptic's version of F3, aimed at a handover. The JD raises the handover, so the question may ask about it. |
| 2K3 | "Which parts of the spreadsheet were your design, and whose were the rest?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say which parts were your design, in your own words. If anything else was someone else's, say whose. If you designed all of it, say so. | An attribution probe on a sentence you wrote. Both branches are honest. |
| 2G1 | "Eight branches become five hubs in 2027. How do you keep complaint handling close to each town?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify first: which complaints move to a hub and which stay local. Structure: members who lose a branch, what they still need, and how a hub handles a complaint from a town it no longer sees. Metrics: repeat complaints, time to reply, complaints from a closed branch's area. Risk: the member who cannot travel. Say "Neighbours, Not Numbers" where it fits. No claim about experience. | The strategy's most direct effect on complaints. A generic structure built on the brief's facts. |
| 2G2 | "40% of member service moves to digital by 2028. What would you watch in complaints as that happens?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" | Structure: which members move and which do not, where digital complaints come from (failed journeys, unclear messages), who cannot switch, and which metric shows the shift working. Name one metric you would stop trusting first, and why. No claim about digital work you have done. | A live problem from the strategy. The no-claim line is the guardrail, since your material is silent on digital (F10). |

**Round 2 reverse questions**:
- "How do you want complaints handling to change as digital takes a larger share of member service?" Puts the strategy to the manager's own plan.
- "What did the last person in this role find hardest?" Shows candour, and tells you what the first months will test.
- "Where would you expect this role to work with the digital teams first?" Ties your answer on F10 to a real starting point.

## Round 3: panel of two branch managers (60 minutes, with a 20-minute escalation case, scored on the values)

Values questions come first (3V1 to 3V4), then the escalation case (3G1, 3G2), then pressure (3P1, 3P2). Members are not named, so the personas blend once you know who they are.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3V1 | "Tell me about a problem you found and kept until it was solved." | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values copy) | Selection scaffold: pick a problem you found, kept and closed, and say who else was involved and where you handed it on. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly spreadsheet you built, and what it was for (F5). | Own the Fix. The panel scores it, and no sentence in your material carries a story for it. |
| 3V2 | "How do you keep a branch part of its town when its service moves somewhere else?" | VAL | [grounded] "every branch is part of its town" (values copy); "consolidate eight branches into five hubs over 2027" | Selection scaffold: pick a time a local issue changed how a branch ran, and say what you did. If you have no such time, say so, then give the nearest thing your material carries: six years in retail banking, the last three as a branch supervisor (F1), and what you would keep from it. | Ties Neighbours to the hub plan, which a branch manager on this panel may be living through. The hub plan is context here, not your experience. |
| 3V3 | "Tell me about an explanation you had to rewrite for a member." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values copy) | Selection scaffold: pick a letter, script or explanation you changed because a member did not follow it, and say what you changed. If none, say so, then give the nearest thing your material carries: training new tellers on the escalation script (F9), and what you checked when you trained them. | Plain Words has no sentence in your material that carries a rewriting story. |
| 3V4 | "A member says the answer is wrong, and the process says the case is closed. What do you do?" | VAL | [grounded] "we decide from the member's side of the counter" (values copy) | Scenario, not a past. Decide from the member's side, check what the process allows, and keep the case open until it is resolved. Do not describe a time you did this unless you did. | A values scenario that needs no claim about your past, so no slot is needed. |
| 3G1 | "A member's complaint has been escalated, and they have had two different answers, from the branch and from the contact centre. They say they will go outside the bank tomorrow. Talk us through the next 24 hours." | CASE | [generic] for the scenario; [grounded] "across branches and the contact centre" (JD) for the cross-channel element | Clarify: what the member was told, by whom, and what they asked for. Objective: one owner and one answer. Segmentation: vulnerability, what is still open, what each channel promised. Approach: one named owner who holds the case until it is solved, and a plain-words reply that states the answer once. Metrics: time to first contact, repeat contacts, time to resolution. Risks: an outside referral, a timetable you have not checked, staff contradicting each other. If a regulatory timetable applies, check it first, and do not treat any timetable as a fact you know. | The 20-minute case from the recruiter's email. The scenario is generic and claims nothing about your past. |
| 3G2 | "Escalations from the branches rose by a fifth after a hub move. How would you diagnose it?" | CASE | [generic] for the diagnosis; [grounded] "consolidate eight branches into five hubs over 2027" for the hub move | Clarify whether the rise is in volume or in escalation rate. Structure: which hub, which complaint type, which members (travel, language, vulnerability), and whether the escalations are new. Propose one test that separates a hub effect from a seasonal one. Say what you would not yet conclude. | A second case. The rise is a hypothesis in the question, not a fact to accept. |
| 3P1 | "Sixty seconds: why should a branch manager trust a candidate who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Pause before answering, and restate the question in your own words. Anchor in what you did: "I handled the branch's formal complaints log." Hold that anchor through two follow-ups. Then concede specifically: "I have never worked in a contact centre, and I would need to learn its handovers before I could own them." Add no contact-centre claim. | The Pressure stem, on your stated gap. Hold-then-concede is the structure. |
| 3P2 | "Name the one thing in your complaints work you would defend least." | EXP | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name, in your own words, the part of the log or the spreadsheet you could not defend if asked, before the panel asks. If nothing stands out as weakest, say so, and name the part you did not see the inside of. | Pressure in a form that rewards naming the weak part first. The question carries no figure. |

**Round 3 reverse questions**:
- "When a complaint moves from a branch to the contact centre, who holds it until it is solved?" Tests Own the Fix in operations.
- "How do the branch managers on this panel see escalations coming out of their own branches?" Opens the conversation to the people who will work with you.
- "What would make a branch manager say this role has helped their branch?" Gives you the measure the panel will use.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | 1C1 |
| experience handling regulated complaints | 2B3 |
| Own the member complaints process end to end across branches | 2K2, 3G1 |
| across branches and the contact centre | 1C3, 2K2, 3G1, 3P1 |
| report monthly on complaint volumes | 2B5 |
| resolution times | 2B5 |
| coach branch supervisors on escalations | 2B4 |
| work with digital teams on self-service journeys | 2G2, reverse question on digital in round 2 |
| confident presenting to senior leaders | 2K1 |
| comfortable with Excel reporting | 2B5, 2K3 |

No JD requirement is without a question.

## Upgrade menu

- The panel members' names → a persona weight for each panelist, and a tailored reverse question for each.
- Whether the branch log ran to a regulatory timetable or an outside referral route → settles F4 and turns 2B3's answer slot into a story.
- Whether you coached any supervisor, or only trained tellers → moves F9 from transferability to a grounded coaching story.
- Any part in a digital change to a member journey → moves F10 from discovery to a grounded row.
- A redacted copy of the monthly complaints spreadsheet, with all member, branch and customer data removed under your employer's rules → lifts F7 from medium to high, with the artifact inspected.
- The strategy brief as a document, not your summary → the grounding brief is checked against the text.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes → would add the interview loop's public reports and the strategy's competitive detail.
- Which sites the role covers → answers the location slot and sharpens the hub questions.
- Any pre-declared deliverable, such as a presentation or take-home → a build section for it. None has been stated so far.
