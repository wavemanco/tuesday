Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-7-canned-049c22ec/e90572a7-7942-43c2-98bd-a2f236852130/scratchpad/saltmarsh_live-operations-producer_interview_pack.md.

Three findings from research shape it most:

- **The format is a live-incident exercise.** Saltmarsh's careers page describes every loop as a recruiter call, then one 60-minute "Outage Hour" with the hiring manager: a tabletop on a simulated outage during a live event, then a values conversation. Expect to be walked through a live problem, not only asked about your history.
- **Tobias has published on release notes.** A GDC 2026 talk listing by him argues that a live team is judged by how often its patch notes describe what actually shipped. I read only the search listing, not the talk. Your release checklist work is your closest material here.
- **Project Larkspur changes the job.** Per the September 2026 news, Tidepool Tactics and Lantern Row move to one shared events calendar from February 2027, with per-title event teams retired. That is a season-pass model, and you have never worked on a game with in-app purchases. I've treated the two titles in the JD as probably these two, and marked that as an inference.

The hardest question is likely "You've never led a team. Why would we trust you to coordinate four of them?" (B1). The pack has you open with a plain "I haven't led a team," then return to what you actually did: you wrote the release checklist QA still uses. Rehearse that answer most.

Tell me two things before Friday and I'll tighten the pack:

1. Is Tobias the hiring manager for this Outage Hour, or a senior reviewer? That changes the persona weights.
2. Do you want a deeper research pass on Larkspur and his talks? It's up to 6 more searches and 2 more fetches, several more minutes. I'll run it only if you say yes.

I can also drill any persona on a question you pick, or save a `tuesday-dossier.md` recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Whether he is the hiring manager is not yet confirmed; the pack assumes he runs the session (see the question in the message).
**Round:** 60-minute session. Saltmarsh's careers page describes every loop as a recruiter call followed by a single 60-minute "Outage Hour" with the hiring manager: a live-incident tabletop, then a values conversation.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **CASE** live problem · **JD** role requirement · **EXP** your past work, tested for attribution · **VAL** published company values · **CO** company and strategy knowledge.
- Guidance is scaffolding for a spoken answer, not a script. Only rehearse what you actually did, in your own words.

## 2. Fit snapshot

No line of the JD is a gate (no location, schedule, licence or credential), so nothing here is a hard-gate row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title's weekly drop calendar, not two titles or live events. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned a second title's calendar or set event timing, say so in your own words; if not, say that and how you would carry the calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordinating these teams on an update. Plain acknowledgment you gave: "I haven't led a team." Answer slot: if you coordinated any of these teams on a drop, say which and how; if not, say so and say how you would get four teams to agree a calendar. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is not owning the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the KPIs or wrote the review, say which; if the numbers were set for you, say whose they were. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." Expect a probe on who maintains it now. |
| F5 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the numbers were counted (see D1). |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement. |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Length is met. Your title was associate producer, and "live-service" is not a word you used; the drop calendar suggests it. Words: "I was an associate producer at a puzzle-game studio for four years." |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The checklist is a written artefact other teams use. |

Confidence grades your evidence. Provenance grades what this pack says about it. Medium means you confirmed it, but there is little you can show as proof, so expect a probe.

## 3. Prohibited claims

Built locally from the fit snapshot. These are the stretched versions a candidate reaches for under pressure, and what each one is allowed to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have led a team" | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| "I ran live events" or "I ran the calendar for both titles" | Inflated form of F1's quote | F1's quote at its own scope. The limit (one title) is this pack's observation. |
| "I owned the KPIs" | Inflated form of F3's quote | F3's quote at its own scope. |
| "I have worked on a game with in-app purchases" | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

Not on the list, and not coached either: anything about how you coordinated the four teams. No quote covers that, so it is an answer slot (F2), not a claim.

## 4. Reading the interviewer

Public footprint only. The one item found is a GDC 2026 talk listing, "Patch Notes Are a Promise," by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. The argument as listed: a live team is judged by how often its patch notes describe what actually shipped. This comes from the search listing only; the talk itself was not opened.

Implications:
- He is likely to probe what release notes promise versus what shipped. Your release checklist is the nearest material to that (see C2 and D3).
- Your QA-facing checklist work is a professional mirror: it sits on the same release path he came up through. Use it as a fact, not as rapport.
- His QA background means he will test your release checklist in detail. Know exactly what it covers.

## 5. Persona table

| Persona | How it shows up | Likelihood and weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop during a live event | High, weight 5. The careers page names a live-incident tabletop as the core of the session. | Clarify, then impact, then decide, then communicate. Think aloud. |
| Values / Behavioral | The "values conversation" in the same hour | High, weight 4. The loop source names a values conversation, so a values round is detected. | Map a story to each value where your quotes carry one. Say honestly where none does. |
| Skeptic | "You've never led a team" | High, weight 4. This is the most likely objection (see B1). | Acknowledge it plainly. Hold on what you did. Concede leadership without folding. |
| Data-Driven Prober | Retention numbers, how they were counted | Medium, weight 3. Your retention line will be probed. | Name the weakest assumption before he does. Say what you don't know. |
| Pressure | Time-boxed challenge, "how much of that was you" | Medium, weight 2. Common in a 60-minute session. | Pause. Restate. Hold through two follow-ups before conceding anything real. |
| Conversational | Casual opener, "walk me through the journey" | Low, weight 2. Casual questions are still scored. | A 90-second arc, built only from your quotes. |
| Peer Evaluator | Not plausible for this round as stated. Dropped. | None | None |

## 6. Question banks

Each row's Provenance carries every sentence the guidance rests on. Question IDs are by persona.

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running, and a patch shipped yesterday breaks progression on one platform. Walk me through the first hour." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" — careers page | Clarify scope: which players, which platform, since when. Decide rollback versus hotfix on evidence. Say what the player message will claim, and only what is confirmed. | The Outage Hour's core format. The problem is generic; it asserts nothing about you. |
| A2 | "Players report the event reward is wrong. Community says display bug; engineering says it is real. What do you do?" | CASE | [generic] | Separate the two claims. Confirm with data before picking a side. Name one owner per claim. Keep the public message to what is confirmed. | Tests coordination across the teams the JD names (F2), without a claim about your past. |
| A3 | "The event ends and retention dips two days later. Which KPI do you check first, and what goes in the post-event review?" | CASE | [generic] | Define the metric and its baseline. Split by segment before reading a trend. Put the review's owners and dates in the write-up. | Covers the post-event review and KPI ownership in the JD (F3). |
| A4 | "You have two titles and one calendar. If two events clash, which one goes first?" | CASE | [grounded] "one shared events calendar from February 2027" — Saltmarsh news, Project Larkspur | State the rule first: players before plans (a published value). Then the trade-off, and what you would need to know about each title. | Uses the company's current direction, so it is grounded in research rather than generic. |
| A5 | "Design wants a Friday drop; engineering wants a Monday build freeze. Walk me through the call." | CASE | [generic] | Ask what the freeze protects. Check what the checklist requires. Decide with QA in the room. | Tests the release checklist the JD names (F4) as a decision, not as a record. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never led a team. Why would we trust you to coordinate four of them on every update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | **Highest-ROI prep in this pack.** Start with the plain line: "I haven't led a team." Then return to what you did: "I wrote the release checklist our QA team still uses." Answer slot: if you coordinated design, art, engineering or community on a drop, say which and how in your own words; if not, say so plainly, and say how you would get four teams to agree one calendar. Hold through two follow-ups by returning to the checklist. Concede the leadership gap explicitly. Never fold into "I led." | F2 is the gap the JD's requirement sits on. The objection will come in some form. A rehearsed, calm acknowledgment changes the room. |
| B2 | "The job you did was one title's weekly drops. Two titles and live events is a different job. Why is that not a stretch?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Concede the difference: one title, not two. Keep the quote's scope: weekly, for two years. Answer slot: if you planned a second title or set event timing, say so; if not, say how you would carry the calendar across. | F1's transferability gap. |
| B3 | "Your background is a puzzle game. Have you worked on a game that earns from in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, not a past: how you would learn the link between spend and retention. | A likely probe given Project Larkspur's season-pass model (see R2). |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD | Answer from the quotes: the two-title scope (F1) and the coordination (F2). Do not add a claim that is not in the fit snapshot. | A direct test of honest self-assessment. |

### C. Values / Behavioral (4)

Values come from Saltmarsh's published page: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Players Before Plans" — Saltmarsh values page. No candidate sentence carries a story here. | Scaffold: pick a time a planned drop served players badly, and what you changed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar you ran for two years, and how a change to it was handled. | No candidate sentence carries this story, so this is a selection scaffold, not a mapped answer. |
| C2 | "When has a release gone out with notes that promised more than shipped?" | VAL | [grounded] "Ship the Patch Not the Promise" — Saltmarsh values page | Scaffold: pick a release where the notes and the build disagreed. If none, say so. If you can, say what your checklist checks that would catch it, and only items you actually wrote. | Ties to Tobias's published argument (see section 4). |
| C3 | "How have you left a process better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Story: you wrote the checklist and the QA team still uses it. Say what you changed and why, only if you changed something. Do not claim it improved on a predecessor's version unless you know that. | Maps the value Leave the Build Greener to your one quoted artefact. |
| C4 | "When did you put a player ahead of an internal metric?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Scaffold: a time a metric and a player's experience disagreed. If none, say so, then say how you would weigh one against the other. | Values-style probe with no quote carrying the story; the honest branch is required. |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How were the retention numbers you presented counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what you know about the count, in your own words. If you did not build the count, say who did. Do not explain a method you cannot repeat under a second question. | F5. A defend-the-number slot: how it was counted, and which part was yours. |
| D2 | "Which assumption behind that retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name the weakest assumption you know of before he does. If you do not know one, say so. | The weakest-assumption move for a headline metric. |
| D3 | "Walk me through what your release checklist covers." | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | List only the items you can name. If you did not write a given item, say so. | Tests a release artefact he will know well. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has led a live team?" | JD | [grounded] "Never led a team" — your message | Pause. Acknowledge the gap in plain words. Hold on the calendar and checklist work you did. Concede leadership without folding on the work. | Pressure on the most likely objection. |
| E2 | "That result — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Separate presenting from analysing. Hold what you actually did. Concede what was not yours. | Attribution under pressure. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A 90-second arc: the puzzle studio, the content-drop calendar, the checklist, the retention numbers. Use only those quotes. | Casual openers are scored. |
| F2 | "What are you playing right now, and what does its event cadence tell you?" | JD | [generic] | Name one game. Say one thing about its event cadence that you actually noticed. Do not claim expertise you do not have. | Casual, but it probes live-service fluency. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | B2, A4, B4 |
| Coordinate design, art, engineering and community | A2, A5, B1 |
| Own the post-event review and KPIs | A3, D1, D2 |
| Manage the release checklist with QA | A5, D3, C3 |
| 3+ years producing live-service games or apps | F1, B3 |
| Experience running a content calendar | B2, F1 |
| Comfortable with player-retention metrics | D1, D2, E2 |
| Clear written communication | D3 (the checklist as an artefact) |

Totals: 20 questions. Depth follows persona weight.

## 7. Values cheat sheet

Values-style round detected: the loop source (careers page) names a values conversation in the Outage Hour.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win. | None of your quotes carries this story. Scaffold in C1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | None of your quotes carries this story. Scaffold in C2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | Partly: F4/F8's quote "Wrote the release checklist our QA team still uses." Say only what you changed. Scaffold in C3. |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through QA before live ops. What does that change about how you run a release?" | Ties to his public path (GDC listing: previously a QA lead). Turns an interview into a peer conversation. |
| R2 | "Project Larkspur puts two titles on one calendar from February 2027. Which title's calendar will be hardest to merge?" | Shows you read the company's own news. |
| R3 | "Does this role's KPI set already exist, or does the person in it define it?" | Tests whether the post-event review is owned or inherited. |
| R4 | "How does the Outage Hour's tabletop feed into the post-event review?" | Shows you think about the loop, not just the hour. |
| R5 | "What would a good first 90 days look like for whoever runs this calendar?" | Standard, but it shows you are planning, not waiting to be told. |

## 9. Prohibited claims (repeated for reference)

See section 3. No answer, bridge or reverse question above asserts any item in it.

## 10. Sources

**Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet (section 7), three values by name |
| 2. Interview process | yes | Loop structure: one 60-minute Outage Hour, no take-home. Persona weights follow it. |
| 3. Strategy / recent news | yes | Project Larkspur (September 2026): season-pass model, one shared calendar from February 2027, per-title event teams retired. Feeds A4, R2 and B3. Read from the search snippet, not fetched. |
| 4. Interviewer footprint | yes | GDC 2026 talk listing. Feeds section 4 and R1. Read from the search snippet, not fetched. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions. |

Queries sent:
- "Saltmarsh Games values": returned the values page (fetched).
- "Saltmarsh Games interview process live operations producer": returned the careers page (fetched).
- "Tobias Wrenfield Saltmarsh Games": returned the GDC 2026 listing.
- "Saltmarsh Games strategy 2026 live games": returned the Project Larkspur news.

Provided documents: the JD and your background, as you wrote them in your message.

## 11. Upgrade menu

- Confirmation that Tobias runs the Outage Hour as hiring manager → confirms the persona weights in section 5.
- The JD's two titles named → if they are Tidepool Tactics and Lantern Row (the titles in the Larkspur news), the Larkspur rows move from inferred to grounded. Right now the link is an inference.
- The full GDC talk → checks whether the talk says what the listing says before you quote it back to him.
- A deeper research pass (L2) on the Larkspur strategy and on his talks and writing → sharper A4 and R2 and more of his public themes.
