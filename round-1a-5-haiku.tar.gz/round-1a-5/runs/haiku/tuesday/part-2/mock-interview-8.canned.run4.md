Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-8-canned-22042259/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has 22 questions across the three rounds, a values cheat sheet, and a fit snapshot. The main points:

- **Biggest risk: presenting to senior leaders (B7).** The JD asks for it, the monthly reporting depends on it, and your own message says you haven't done it above regional level. Rehearse the plain acknowledgment, then the plan, and don't claim experience you don't have.
- **Second risk: contact centre (B6, A6, C1).** The role runs complaints across branches *and* the contact centre. Say "I've never worked in a contact centre" once, then give your scope and a concrete plan.
- **Escalation case (C1).** It's a practice version, since I don't know the panel's actual case. The guidance is to give the member one owner and one next date, fix the stall itself, and stay on it until the member has a final answer. Don't invent a regulatory deadline; use the one the case gives you.

I didn't run any web searches. The values are from the text you pasted, the round structure is from the recruiter's email, and the strategy points are from your summary, not the brief itself. Check any figure against the brief before you use it in the room. The upgrade menu lists what would tighten the pack, including a deeper research pass if you want one.

Want me to play the Skeptic on B7 so you can rehearse the presenting objection out loud? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Three rounds on 4 December 2026: the recruiter (30 min), the Head of Member Services (45 min, mostly behavioural, your future manager), and a panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). No interviewers are named yet, so persona weights rest on round type and on your recruiter's own description of each round.

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: VAL (values and behaviour), EXP (your own record), JD (the listed job), CASE (a live problem). CO (company knowledge) has no question of its own here; strategy comes in through B8 and the grounding section.
- Every guidance cell is scaffolding, not a script. Say each sentence in your own words. Where a cell quotes you, those are the words you can stand behind.
- The provenance column shows what each question rests on: a quote from your message, a label, or both.

## Fit snapshot

Requirements are quoted from the JD or the recruiter's email. Your evidence is quoted from your message, which is the only background material I had.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on years. Say it in your words. Expect a probe on whether branch work counts as customer operations; F7 covers the contact-centre side. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." Your material says formal complaints, not regulated ones, and does not name the rules the log followed. Answer slot: the JD raises regulated complaints, so expect a probe on which rules and timescales applied. If the log followed regulatory timescales or referrals, say which and what you did with them, in your own words; if it did not, say so plainly and stay with the log as you ran it. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan and never as a past. Do not stretch "regional" into senior leaders, and do not claim presenting experience above regional level. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Your material says spreadsheet, not Excel. Name the program only if it was Excel, and name formulas, pivots or charts only if you used them. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material supports monthly complaints reporting but not resolution times. Answer slot: if the spreadsheet tracked how long complaints took to close, say what it tracked and over what period; if it did not, say so plainly and say what you would add first. |
| F6 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | transferability | Words: the quote at its own scope, "I handled the branch's formal complaints log." Your material describes one branch's log. It does not describe end to end, or across branches. |
| F7 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then a plan for learning contact-centre complaint routes, stated as a plan. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" and "the last 3 as a branch supervisor" (your message) | low | [inferred] | transferability | Words: "I trained new tellers on our escalation script." Your material shows training tellers, not coaching supervisors. Answer slot: if you coached a supervisor or another manager on escalations, say what you did; if you did not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your message says nothing on digital or self-service work. Answer slot: if you have worked with a digital or self-service team, say what the journey was and your part in it; if you have not, say so plainly and say how you would start. |

## Grounding brief

Source: the strategy brief as you summarised it in your message. I have not checked it against the document itself, so use these phrases as you have them and verify any figure before quoting it in the room.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

Use the brief's own words for the digital and hub plans, and do not coach yourself to correct any framing the interviewers use.

## Persona weights

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Recruiter, 30 min | Conversational | Logistics and a friendly walk-through of your record | High. The recruiter's prior is conversational with logistics knockouts. Treat casual questions as scored. | Practise a 90-second arc from your own sentences; give each logistics answer in your own words. |
| Recruiter, 30 min | Skeptic (light) | One gap check on the contact centre | Medium. Your message gives one clear knockout gap. | Say the plain acknowledgment once, then your scope and your plan. |
| Head of Member Services, 45 min | Values / Behavioural | Scenario and story questions tied to the four values | High. Your recruiter said this round is mostly behavioural, which moves it ahead of the usual hiring-manager prior (case and skeptic). | STAR-shaped stories from quoted sentences only; say which part was yours. |
| Head of Member Services, 45 min | Skeptic | Probes on contact centre and senior presenting | High. These are the two requirements where your own message says you have not done the thing. | Acknowledge once, hold on what you did, concede precisely. |
| Head of Member Services, 45 min | Case / Strategist | Hub consolidation as a live problem | Medium. The brief makes it the live issue of 2027. | Clarify first, then structure; name assumptions. |
| Panel of two branch managers, 60 min | Values / Behavioural | Each of the four values scored | High. Your recruiter wrote that the panel "score against the four values." | Map one story per value where your sentences carry one; otherwise say so and give the honest branch. |
| Panel of two branch managers, 60 min | Case / Strategist | The 20-minute escalation case | High. It is a scored case with a time box, so it carries pressure too. | Clarify, decide, then defend; stay with the member until someone owns the next step. |
| Panel of two branch managers, 60 min | Peer Evaluator | Seams between branches and digital; disagreement | Medium. Branch managers are peers on the work you would coordinate. | Principles for the seam, not claimed history. |
| Panel of two branch managers, 60 min | Data-Driven Prober | Spreadsheet counts and resolution times | Medium. Your spreadsheet is the one number-bearing item in your material. | Say what it counts, who set that, and what it does not track. |

## Question banks

Depth follows weight: the top persona in each round has the most questions. Provenance comes before the guidance. In each row, the quoted sentences are the only things the guidance says about your past.

### A. Recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Tell it in three beats, in your words: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; the monthly complaints spreadsheet your regional manager uses. Stop there. Do not add a title, a team size or a result. | F1, F2 and F4 are the three beats. The arc should take under 90 seconds. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot. Give the figure you actually need, in your own words, or say you would like to see the band for this role first. Give no figure you have not decided. | Pay is a logistics topic. Your message gives no figure, so this cell asks for your answer and writes none for you. |
| A3 | "What notice would you need to give your current employer?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | A knockout check. Your message gives no notice period. |
| A4 | "Where are you based, and what working pattern can you do?" | JD | [generic] | Logistics slot. Say the working pattern you can actually do, in your own words. | Location is a knockout. The brief's hub plan may make travel a live question later, so keep this answer exact. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give the reason in your own words, and keep to the one that is true. | The recruiter will check it against your three years as a branch supervisor. |
| A6 | "Your background is in branches. What's your exposure to a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then your scope: "I handled the branch's formal complaints log." Then your plan, stated as a plan: how you would learn how contact-centre complaints arrive and are routed. Do not describe contact-centre work you have not done. | F7 is the gap. Say it once in these words, then the plan. |

### B. Head of Member Services (45 min, your future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a formal complaint that went through your log, from first contact to answer." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Tell one complaint in order: how it reached the log, what you recorded, what you did next, how it closed. Keep each beat to what you did. Name the member's outcome only if you know it. Answer slot: if you made the decision on the outcome, say what you decided and why; if someone else decided and the log only recorded it, say so plainly and describe your part. | F2 is the requirement this tests, and the log is the only process your material describes. |
| B2 | "Tell me about a time you decided something from the member's side of the counter when the rule pointed the other way." | VAL | [generic] scaffold; nearest: "trained new tellers on our escalation script" (your message) | Pick a time a member's outcome turned on a choice of yours and you could see the rule was wrong for them. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained new tellers on, and say honestly how far it reached the member's side. | Members First is the value this story is scored on. Your material carries no such decision, so the honest branch is written in. |
| B3 | "Tell me about a problem you found that nobody had asked you to fix. What did you do with it?" | VAL | [generic] scaffold; nearest: "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If the spreadsheet started from a problem you saw, say what the problem was. If it was asked for, say so and say what you added. If neither fits, say so, then tell the spreadsheet's story as it happened. Do not say it solved anything unless you can show it. | Own the Fix asks you to keep hold of a problem. The honest answer may stop at noticing it. |
| B4 | "Tell me about a time you explained a branch decision to the town it affected." | VAL | [generic] scaffold; no quoted sentence carries a town story | If you have such a time, tell it. If not, say so, then say how you would approach a closure: tell the town early what changes for them, and say what you would keep honest. This is a plan. | Neighbours, Not Numbers. Your material has no town story, so the honest branch is the plan. |
| B5 | "A member tells you they've read our letter twice and still don't understand it. What do you do?" | VAL | [generic]; raising source: the published value "Plain Words — if a member needs it explained twice, we wrote it wrong." (ashgrovecu.org values, copied 25 November 2026) | Work through it in order: find the sentence that failed, rewrite it, check the rewrite with a member before it goes out, then fix the next letter the same way. Answer as a plan. | The scenario is scored as a values answer. The value's own sentence is what the question draws on. |
| B6 | "You've never worked in a contact centre, and this role runs complaints across one. How would you run it from day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then your scope: "I handled the branch's formal complaints log." Then the plan: in the first weeks, learn how contact-centre complaints arrive, are routed and closed before you change any process. Hold the plan, not any experience. | F7 is the gap. The premise, complaints across a contact centre, is the JD's own line. |
| B7 | "The role needs confident presenting to senior leaders. You've never presented above regional level. Why would they trust you in that room?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Level 1: "I haven't presented to anyone above regional level." Then the plan, as a plan: how you would prepare the first monthly report, with a rehearsal and a reviewer. Level 2, if they say "that's a long way from regional": hold on what you built: "The report I know is the monthly complaints spreadsheet our regional manager uses." Level 3, if they say "so why you?": concede precisely: "I can't show you presenting to senior leaders yet. I can show you the work the report depends on and how I would get ready." Do not fold on the complaints work, and do not claim senior experience. Answer slot: if you have presented to regional leaders, say what and to whom, in your words. | Highest-ROI prep in this pack. The JD names this requirement, the monthly report depends on it, and your own sentence is the negative. The hold is the spreadsheet you built, not a presentation you did not give. |
| B8 | "Eight branches become five hubs over 2027. A town loses its branch, and complaints from that town rise. What do you do in the first 30 days?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message, summarising the strategy brief) | Clarify first: which complaints rose, which members are affected, what the hub changes for them. Then order it: members first, then what the complaints say, then one owner and one fix. Name what you would check, and do not invent figures. Answer as a plan. | A live problem with no claim about your past. The premise is the company's plan as you summarised it, so check the date against the brief before you quote it. |

### C. Panel of two branch managers (60 min, includes a 20-minute escalation case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's complaint has been open for weeks. The branch has passed it up twice, and the member now asks for a manager and says they will take it outside the bank. Walk us through what you do." | CASE | [generic] | This is a practice version; the panel's case will differ. Clarify what the member is owed and by when, and use any regulatory timescale the case gives you; do not invent one. Give the member one owner and one next date, the same day. Fix the stall itself, not only this case. Coach the supervisor who passed it up twice (C8). Stay on it until the member has a final answer and you have named who holds it. Time it: about three minutes to clarify, ten to decide, seven to defend. | An escalation case is a live problem with no claim about your past, so nothing here needs a quote. |
| C2 | "Tell me about a problem you stayed with until it was solved." | VAL | [generic] scaffold; nearest: "I handled the branch's formal complaints log" (your message) | Pick one problem you kept hold of through to a fix. If none comes to mind, say so plainly. The log is the nearest thing: it shows handling, not solving, so do not stretch "handled" into "solved". | Own the Fix. The nearest quote stops at handling. |
| C3 | "Tell me about an explanation that didn't land the first time. What did you change?" | VAL | [generic] scaffold; nearest: "trained new tellers on our escalation script" (your message) | Pick an explanation you gave that had to be repeated, and say what you changed. If you changed nothing, say so. The training is the nearest thing your material carries, and it only fits if you saw an explanation fail. | Plain Words. The honest branch is written in. |
| C4 | "Which number have you trusted that the people behind it would have disagreed with?" | VAL | [generic] scaffold; nearest: "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Pick a number you relied on and say what it left out, in your own words. If none comes to mind, say so. The spreadsheet is numbers, so this value needs you to name its limits. | Neighbours, Not Numbers. The nearest carrier is a numbers item, so the honest answer is the limit. |
| C5 | "Which of the four values would be hardest to keep in this role, and what would you do when it was tested?" | VAL | [generic] | Pick one value and name the situation where it is hardest to keep. Answer as a plan. | The panel scores all four values. This asks you to rank them, and the cheat sheet supports that. |
| C6 | "Digital is building self-service journeys. Where's the seam between your branches and their team, and what happens when you disagree?" | JD | [generic]; raising source: the JD line "work with digital teams on self-service journeys" | Name a seam as a principle, for example who owns a complaint when a journey fails. Do not claim history you do not have. If no disagreement comes to mind, say so and say how you would settle one, with the member's outcome as the test. Say what the branches bring that digital can use. | A peer question. F9 is discovery, so keep the answer to principle, not history. |
| C7 | "What does the monthly complaints spreadsheet count, and who decided that?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if you set what it counts, say what it counts and why; if your regional manager or the bank set the definitions, say so plainly. Name the program only if it was Excel. If it tracks resolution time, say what and over what period; if it does not, say so. | F4 and F5. The prober's probes on Excel and resolution times live here, and the honest answer may be "not me". |
| C8 | "A supervisor in one of your branches keeps passing complaints up without resolving them. How do you coach them?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Start with the case: what the supervisor passes up and why. Coach the decision the supervisor makes, not the escalation itself. Answer slot: if you coached a supervisor or another manager on escalations, say what you did; if you did not, say so and say how you would start. | F8. The quote is tellers, not supervisors, so the coaching is a plan unless you can show more. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, B1 |
| experience handling regulated complaints | B1, C1 |
| confident presenting to senior leaders | B7 |
| comfortable with Excel reporting | C7 (Excel itself is not asked directly; it surfaces here) |
| Own the member complaints process end to end across branches and the contact centre | B6, C1 |
| report monthly on complaint volumes and resolution times | C7, B7 |
| coach branch supervisors on escalations | C8, C1 |
| work with digital teams on self-service journeys | C6 |

## Values cheat sheet

Your recruiter wrote that the panel scores against the four values, so this section applies. The value names and wording are from the values page you copied on 25 November 2026.

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Nearest carrier: F8, "trained new tellers on our escalation script." That is training, not a member decision. Selection scaffold in B2: pick a time a member's outcome turned on your choice. If none comes to mind, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | No quoted sentence carries this. Selection scaffold in C3: pick an explanation that had to be repeated and say what you changed. If you changed nothing, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a town story. The spreadsheet (F4) is numbers, so C4 asks you to name what it leaves out. If you have a town story, use B4. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Nearest carrier: F2, "I handled the branch's formal complaints log." That quote stops at handling, not solving. Selection scaffold in C2: pick a problem you stayed with to a fix. If none comes to mind, say so. |

## Reverse questions

Each one has a "why it lands". Round 3 is a peer panel, so one reciprocity question is included.

1. "What does a good month look like for the complaints numbers, and who reads them?" Why it lands: it shows you read the monthly reporting requirement as a working tool, not a formality.
2. "How do branches and the contact centre hand complaints to each other today?" Why it lands: it shows you are already looking at the seam the role has to close.
3. "What would the first 90 days need to deliver for you to call the appointment a success?" Why it lands: it asks the manager to define ownership, which is the hardest thing to ask in a manager round.
4. "Which self-service journeys are on the digital team's list for 2027, and where does complaints data feed them?" Why it lands: it ties the JD's digital line to the brief's 40% goal, in the brief's own words.
5. "Which of the four values do you see tested most often in complaints, and where do you see it slip?" Why it lands: it asks the panel where their own standard is hardest to meet, which invites a real answer.
6. Reciprocity, for the panel: "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it turns the peer round into a working conversation and shows you are thinking about their branches, not only your application.

## Prohibited claims

What this pack will not coach, and why. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F6 and F7 | The quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not a claim for you to make: your material describes one branch's log and no contact centre. |
| Presented to senior leaders | Negative you stated, F3 | The plain acknowledgment: "I haven't presented to anyone above regional level." No answer slot. |
| Built reporting in Excel | Inflated form of F4 | The quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit: your material says spreadsheet, not Excel. |
| Trained branch supervisors on escalations | Inflated form of F8 | "I trained new tellers on our escalation script." The limit: tellers, not supervisors. |
| Reported resolution times | Inflated form of F5 | Nothing asserted. The F5 answer slot asks what the spreadsheet tracked, and allows that it did not track resolution time. |
| Handled regulated complaints | Inflated form of F2 | The quote at its own scope: "I handled the branch's formal complaints log." The limit: your material says formal complaints, not regulated ones. |

Digital and self-service work is not on this list. Your message says nothing about it, so F9 is an answer slot, not a claim to refuse.

## Sources

Provided documents:
- The JD, as pasted in your message.
- Your recruiter's round description, as pasted in your message.
- The values page text, as you copied it on 25 November 2026.
- The strategy brief, as you summarised it in your message. I have not seen the brief itself.
- Your background, as written in your message. This is not a CV.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrovecu.org values | skipped | The values text you copied fixes the names and wording used in the cheat sheet. |
| 2. Interview process, Member Experience Lead | skipped | Your recruiter's email names the three rounds and says the panel scores against the four values. That establishes the loop, so no archetype fallback was needed. |
| 3. Ashgrove strategy and recent news | skipped | The strategy points in your message fix the grounding brief and B8. They are your summary, not the brief, and the upgrade menu says what checking the brief would add. |
| 4. Interviewer name and company | n/a | No interviewer is named for round 2 or round 3, so there was no query to form. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Names for the Head of Member Services and the two branch managers → persona weights from their public footprint, and a reverse question tied to their own career path.
- The monthly complaints spreadsheet, opened by you → its columns show what it counts and tracks, which answers C7 with a fact and can raise F4 toward high confidence. It is the artifact that would do this.
- Your CV, or its text → sentences for F6 and F8 that currently rest on your message alone.
- The strategy brief pasted in full → the exact wording and figures for B8 and the grounding section, in place of your summary.
- The complaint rules your branch worked under → the real timescales for C1 and F2, in place of the case's own statement.
- Your hours before 4 December → a prioritised schedule. B7 and B6 come first, then C1 and C8.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It would add a check of the strategy brief, public footprints of the interviewers once named, and recent loop reports for this role family. Want it?
