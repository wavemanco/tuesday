Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-1-denied-c158874f/2977730d-cefd-422e-a497-244375dbbbed/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md. I built it for a peer round, since you described Dan as a peer under the same VP. I ran no web searches, because you said you have everything you need. Dan's public talks and writing would sharpen the reverse questions if you want that research pass.

The pack has 19 questions across six personas: Data-Driven Prober (5), Peer Evaluator (4), Case/Strategist (3), Skeptic (3), Pressure (2) and Conversational (2). Each question is tagged by type, with its answer guidance and rationale. It also has a fit snapshot, a prohibited-claims list, five reverse questions and a requirement-coverage table.

Three things to check before you use it:
- **Highest-ROI prep is D1**, the "consumer product background, partner motion for a B2B business" question. Your material has a partner-level revenue model but no partner-motion design, so the rehearsal is the concession, not a story.
- **The quota/sales-ops negative comes from your notes, not from Priya.** Confirm it in her own words before she rehearses it.
- **The $400M figure has no supporting document.** If she has the proposal or its measured result, that would make A1 and E1 much stronger.

I left out the values cheat sheet and the delivery-coaching section because neither applies to this round.

Would you like me to run a drill as Dan's Skeptic on D1? I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products (Northwind Data)

**Round:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a peer: you would both report to the same VP.
**Candidate:** Priya.
**Changelog:** first version.

---

## How to use this pack

- **Personas** describe how a question arrives (its style and register). **Types** describe what is being scored.
- **Type key:** **JD** = can she do the listed job, gaps included. **EXP** = do her past claims survive scrutiny, and what exactly was hers. **CO** = company and strategy knowledge. **CASE** = a live problem, reasoned aloud. **VAL** = values alignment (not weighted here; see Persona table).
- **Guidance is scaffolding, not a script.** Each guidance cell is speakable in about 90 to 120 seconds. Words in quotation marks come from your own material. Anything in an answer slot is for you to answer in your own words, from what actually happened.
- **Provenance** labels: `[grounded]` traces to your material or the research note you gave me. `[inferred]` is my derivation, named in the cell. `[generic]` is a role-family pattern with no claim about this company or you.

---

## Persona table

Weights follow the relationship prior for a peer round, adjusted by Dan's public profile. Dan's pronouns are not stated, so this pack uses "they."

| Persona | How it shows up | Likelihood and why | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Goes two levels under each number. Asks for denominators, assumptions and what was actually yours. | Very likely. A peer prior, plus Dan's self-described "relentlessly data-driven," means every metric will be taken to its assumptions. | Know what you can and cannot say about how each number was counted. Say plainly when you do not know. Name the weakest assumption before Dan does. | 5 (A1 to A5) |
| Peer Evaluator | Seams between your team and theirs, credit-sharing, what you would need from them. | Very likely. The peer prior is the strongest in the relationship table, and both of you sit under one VP. | Frame reciprocity: what you bring their team, not only what you need. Propose seam principles rather than pretending to know the seam. | 4 (B1 to B4) |
| Case / Strategist | A live problem on the research note's priorities: bundling, a new product line, Compass. | Likely. Dan's pricing and monetization career points the cases toward pricing and packaging. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case. | 3 (C1 to C3) |
| Skeptic | Quiet probing of the gaps: partner-motion design, consumer-to-B2B, quotas. | Likely. The partner-motion requirement is the thinnest part of your material, and that is where a skeptic presses. | Rehearse the single most predictable objection until it is ordinary. Build bridges only from what you actually stated. Concede limits plainly. | 3 (D1 to D3) |
| Pressure / Stress | Time-boxed challenges on the $400M figure and on how much was yours. | Possible. Nothing in Dan's profile marks them as a stress interviewer, but the $400M claim invites a credit challenge. | Pause, restate the question, anchor in what you stated, and hold through two follow-ups before conceding anything real. | 2 (E1, E2) |
| Conversational / Rapport | An opener such as "walk me through the journey," and casual questions on hot JD topics. | Possible. A 60-minute peer round often opens this way. Casual questions are still scored. | Keep a 90-second arc ready. Treat casual questions on AI as scored. Never answer the reverse-question slot with "I think you've covered everything." | 2 (F1, F2) |
| Values / Behavioral | Scenario probes mapped to published values. | Not weighted. No values-style round is detected: your material describes one conversation with a peer, and no loop source documents a values round. | None needed for this round. | 0 |

**Total questions: 19**, within the 18 to 26 range. Depth follows weight.

---

## Reading the interviewer

**Public footprint only.** The details below are from your message. I ran no search on Dan.

- **Career pattern:** a pricing and monetization spine, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven."

**Implications:**
1. **Prober up.** Expect every figure you give to be taken to its assumptions. A1, A5 and E1 are where that lands.
2. **Pricing lean.** Dan's native language is pricing and packaging. C1 and C3 are the cases most likely to tilt there.
3. **Startup chapter.** A builder story can land well with someone who has worked that way. Dan may also probe big-company pace. R1 uses the startup chapter as a reverse question.
4. **Shared vocabulary, not a shared jump.** Dan's pricing and monetization path pairs with your revenue-modelling work: "built a partner-level revenue model used in carrier negotiations" (F4). Use this as vocabulary, not as a claim of shared history. Dan's startup chapter does not match your path, so there is no similar-jump mirror to offer.

---

## The fit snapshot

Requirements come from the JD highlights you gave me, not from the full posting. Quotes are your words. "JD highlights" means your summary of the posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not a go-to-market line you owned, so keep the words at that scope: "For nine years, at a large consumer-tech company, I worked in product strategy and ops." Answer slot: if you set a go-to-market plan for anything, say what it was and which decisions were yours; if there was no such step, or it was not yours, say so plainly and say how you would build the first plan. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model is adjacent to whitespace, not the same work. Say what it sized and no more: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if the model sized any stage of a customer relationship, name the stage and how; if it did not, say so and say how you would find the whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | "Skilled in" has nothing inspected behind it, so it may not be said as your story. Answer slot: if you can name an analysis you ran yourself in SQL or Tableau, name the question, the table and the output; if none comes to mind, say so plainly and say how you would scope the first query. |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The model reaches the partner side, not the design of a partner motion, so keep it at its own scope. Answer slot: if any part of a partner motion was yours to design, say which and how you decided; if none was, say so plainly and say what you would design first. |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Use the line's own terms: "annual volume targets, set with cross-org consensus." Whether you set them yourself or the team did is not in your material. Answer slot: if you set them, say which part; if the team did, say what you contributed. |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Daily use is use, not building. Say it at that scope. Answer slot: if you built, specified or shipped anything that used AI, say what and which part was yours; if not, say so plainly. |
| F7 | "B2B data-infrastructure SaaS" — company context, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | Your material says consumer tech and does not show enterprise selling, so no bridge is written from silence. Answer slot: if you have worked with business customers, name them and your role; if not, say so and say what from your consumer work transfers to an enterprise data business. |
| F8 | none given as a JD line; expected probe on quota and sales-ops experience — the coach's notes | "No classic sales-ops or quota-setting experience." — the coach's notes | medium | [grounded] | capability | Plain acknowledgment from your notes: "I haven't had classic sales-ops or quota-setting experience." Confirm it in your own words before you rehearse it. The nearest thing your material carries is F5: annual volume targets set with cross-org consensus. Give that as a path, not as a past. |
| F9 | none given as a JD line; headline metric on the CV — your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The line already says what you did: you proposed the change, and the figure is credited to it. The probe is attribution, not wording. Keep "credited with" as written. Do not turn it into "drove" or "led." |
| F10 | none given as a JD line; background arc — the coach's notes | "2 years strategy consulting at a top firm" — the coach's notes | medium | [grounded] | none | Background for the opener. Use it as stated: two years in strategy consulting, then nine in consumer tech. |

**Gate rows:** none. The JD highlights name no location, pay, authorization or schedule term. If the full posting has one, it becomes a gate row (see the upgrade menu).

---

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or reverse question below asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the go-to-market strategy for a product line | Inflated form of F1 | F1's quote at its own scope. Pack observation, not words for Priya: your material says product strategy and ops, not a go-to-market line. |
| Sized whitespace across land, adopt, expand and renew | Inflated form of F2 | F2's quote. Pack observation: your material says a revenue model, not whitespace sizing. |
| Ran independent SQL and Tableau analysis end to end | Inflated form of F3 | F3's quote. Pack observation: your material says "skilled in," and shows no analysis. |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. |
| Led or built the ~$400M ARR uplift | Inflated form of F9 ("credited with") | F9's quote as written. Pack observation: "credited with," not led. |
| Built AI products | Inflated form of F6 ("uses AI tools daily") | F6's quote. Pack observation: use, not building. |
| Set the volume targets alone | Inflated form of F5 (the subject is not stated) | F5's quote, with its answer slot. |
| Ran sales ops or set quotas | Sourced negative, F8 | The plain acknowledgment from F8: "I haven't had classic sales-ops or quota-setting experience." Use it only after Priya confirms it in her own words. |

---

## Question banks

### Persona A: Data-Driven Prober (weight 5, deepest bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Defend-the-number, in your own words. Answer slot: if you know how the figure was counted, say it in one sentence; if you do not, say so plainly. Name the assumption you would defend least before Dan does. Say which part was yours: the proposal, in your words. | F9 is the headline figure and the likeliest prober target. EXP because it tests what was actually yours. |
| A2 | "Walk me through the partner-level revenue model you built. What did it show, and what was it sensitive to?" | EXP, JD content | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Story-mapped on the quote: you built it, and it was used in carrier negotiations. Name what it showed in one sentence. Answer slot: name the input it was most sensitive to and say why you think so; if you did not build the inputs, say so and say whose they were. | F4 and F2 both rest on this model. It is the partner-side evidence the JD asks for, so Dan will test whether it holds. |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau: the question, the data, and the output." | JD, EXP | [inferred] "skilled in SQL/Tableau" — the coach's notes | Open prompt, themed by the JD's "run independent analysis in SQL and Tableau." Answer slot: if you can name one, give the question, the table and the output in that order; if none comes to mind, say so plainly and say how you would scope the first query. | F3 is low-confidence. A3 is where the requirement will be tested, so the honest answer should be ready before the probe. |
| A4 | "Walk me through how the annual volume targets were set, and who had to agree." | EXP, JD | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story-mapped on F5: the targets and the consensus, which are the beats the quote states. Answer slot: if you set the targets, say which part; if the team set them, say what you contributed. If Dan asks whether these were quotas: "I haven't had quota-setting experience. These were annual volume targets." | F5 is the consensus evidence for cross-functional influence. Dan will probe it because it sits next to the quota question. |
| A5 | "What could the store-surface change not account for?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Attribution limit, in your own words. Name what the change could not have caused alone, if you know it. Answer slot: if you cannot name a confounder, say so plainly and say what you would check first. | F9 again, from a different side: a prober who has seen the first answer will look for what the figure cannot show. |

### Persona B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Propose seam principles, not a seam you have not seen. Disagreement story: answer slot. The consensus behind the volume targets is the nearest story your material carries. Say how it closed; if nothing was resolved that way, say so and describe how you would handle a disagreement with a peer team. | F5 is the cross-functional evidence. The peer prior makes this a seam question, not a case. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Name who did what in the quote's own terms: you proposed the change. If others built or decided parts, name them without being asked. Do not claim a credit split you cannot stand behind. | F9's "credited with" is the phrase a peer will test. Credit is also where peer trust is won or lost. |
| B3 | "What would you need from my team to design a partner motion that works?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Reciprocity: name what you would bring their team, using the model's use, and what you would need from them. Do not claim partner design you have not done. Answer slot: if you have designed any part of a partner motion, say which; if not, say so and name the inputs you would ask their team for. | F4 is the partner-motion requirement. The reciprocity framing is what a peer scores. |
| B4 | "Where would you look first for whitespace across land, adopt, expand and renew? What data would you need?" | JD, CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Live approach, not a past claim: where you would look first and which data you would need. Keep the model as adjacent, not as whitespace work. Clarify the question before you structure your answer. | F2 is the whitespace requirement, which has no direct evidence. The question tests the approach, not the record. |

### Persona C: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a similar capability into its suite. How would you think about our response? What do you need to know first?" | CASE, CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your message (research note) | Clarify, then objective, segmentation, approach, metrics and risks. Name the premise you would challenge first. Pricing and packaging are the natural lens for this interviewer. The guidance is generic framework; it makes no claim about your past. | The bundling threat is in the research note you provided, so the question is grounded in it. Dan's pricing lean makes this the most likely case. |
| C2 | "Walk me through how you would take a new product line to market. What do you decide first?" | JD, CASE | [grounded] "own GTM strategy for two new product lines" — JD highlights, your message | Live approach, reasoned aloud: who the line is for, what you decide first, what you would measure. Do not describe a launch you did not run. Answer slot: if you have taken a product to market, name the step you set; if not, say so and walk through the order you would take. | F1 is the go-to-market requirement, with transferability only. The question tests how you would do the job, not your record. |
| C3 | "Compass is about to launch. Where would you sell it first, and what would make you stop?" | CO, CASE | [grounded] "three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your message (research note) | Clarify the launch objective, then segment, then name the metric that would make you stop. Use the note's three priorities as your frame. Keep the answer tied to the note, not to anything you know about Compass beyond it. | Compass is in the research note, so the question is grounded in it. It tests whether you think at the company's altitude, and how to tie it to pricing and expansion. |

### Persona D: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep in this pack.** "Your background is in consumer product strategy. What makes you the right person to design a partner motion for a B2B data business?" | JD, EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Hold: name the partner-level work in its quoted terms: you built a partner-level revenue model used in carrier negotiations. Name what transfers from that model. Concede specifically where the quotes are silent: say which part of partner design you have not done, and how you would learn it. Hold through two follow-ups by returning to the model, not by adding to it. Answer slot: if you have designed any part of a partner motion, say which and how you decided; if you have not, say so plainly. | F4 is the required partner-motion requirement, and F7 is the consumer-to-B2B seam. Together they are the objection most likely to be asked. It is aimed exactly where the material is thin, so the rehearsal is the concession, not the story. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" — JD highlights, your message | Pick the requirement you know least well and say so. The guidance is a ramp plan: what you would do in the first two weeks to close it. Do not name a gap you have not checked against your material. | Persona stem for the Skeptic. It invites honest self-assessment, and the requirement that is "required" is the natural one to name. |
| D3 | "I don't see quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." — the coach's notes | Plain acknowledgment, if you confirm it: "I haven't had classic sales-ops or quota-setting experience." Then the path, as a plan and never as a past: the volume-target consensus in F5 is the nearest thing you have. Do not describe quota work you have not done. | F8 is the expected probe, and the negative has to be confirmed by you before you use it. The honest answer is the acknowledgment plus a plan. |

### Persona E: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That's a big number. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold-then-concede. Hold: "I proposed the change." Hold through two follow-ups, returning to what you proposed. Concede specifically: say what part of the figure you cannot split, in your own words. Do not fold on the core claim to restore harmony. | F9's "credited with" is the phrase a stress interviewer will test. The hold is what the quote carries, so there is nothing to stretch. |
| E2 | "Sixty seconds: why you over someone who has run partner programs at a B2B company?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes; [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Sixty seconds, three beats from the quotes: the partner model, the consumer-tech years, and the volume-target consensus. No superlatives. Name the trade-off plainly: your strength is the partner-side model, not a partner program you ran. | The comparator is hypothetical. It tests composure and framing under a time box. |

### Persona F: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" — the coach's notes; [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | A 90-second arc in three beats from the quotes: two years in strategy consulting, nine in consumer-tech product strategy and ops, then the partner-level model. Stop at the last beat and let Dan ask. | The biography opener is scored for economy. The arc is pre-scripted so it does not improvise the middle. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" — the coach's notes | Speak to use at its own scope: you use AI tools daily. Answer slot: if you have built, specified or shipped anything that used AI, say what and which part was yours; if not, say so plainly. | F6 is the AI plus-skill, asked casually. Casual questions on a JD topic are still scored. |

---

## Requirement coverage

| JD highlight | Question IDs covering it |
|---|---|
| own GTM strategy for two new product lines | C2, D2 |
| identify whitespace across land/adopt/expand/renew | B4, F2 (fit row only) |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | A2, B3, D1, E2 |
| strong cross-functional influence | A4, B1, B2 |
| AI experience a plus | F2 |
| Headline metric (store-surface change, ~$400M ARR) | A1, A5, B2, E1 |

Every stated requirement has at least one JD-tagged question. No requirement is left uncovered.

---

## Reverse questions

Ask any five or so, and choose the two that fit the conversation. Each has a "why it lands."

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent time at an early-stage startup. What did that teach you about pricing a product before the market had set its price?" | Ties to Dan's own path: the startup chapter. It turns the interview into a peer conversation about pricing, which is Dan's native subject. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer-round question. It signals you are thinking about what you add, not only what you need. |
| R3 | "Where does the partner motion sit today: with your team, with product, or somewhere else?" | Shows you have thought about scope. The answer tells you which side of the seam you would be on. |
| R4 | "Of the three priorities, enterprise expansion, Compass and profitability, which does this new line most need to serve?" | Tests the trade-off the research note leaves open. It invites Dan to think at the level of the strategy, not the feature. |
| R5 | "When a larger platform vendor bundles something similar, where do you first see it in your deals?" | Shows you read the bundling threat in the note, and asks for an observation Dan has, not a generic answer. |

---

## Values / principles cheat sheet

Dropped. No values-style round is detected, and no published values were supplied. The values section is conditional on both.

---

## Delivery coaching

Dropped. No working-style assessment was provided.

---

## Sources

**Provided documents**
1. JD highlights, your message: six requirements, not the full posting.
2. Candidate background, the coach's notes: career summary and a plain negative on sales ops and quota setting.
3. Research note, your message: three stated priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability) and the main competitive threat (bundling by a much larger platform vendor). The note carries no date.
4. Interviewer details, your message: Dan Kovac's title, peer relationship, career pattern and self-description.

**Searches and fetches:** none sent. You said you have everything you need, so I read that as a choice of L0 (provided material only).

**Research tier: L0, no searches**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | skipped | The values cheat sheet is dropped. The loop your message describes is one peer conversation, and no values round is detected from it. |
| 2. `Northwind Data interview process, senior GTM` | skipped | Your message fixes the loop: one 60-minute conversation with a peer, so persona weights follow that round. |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the three priorities and the bundling threat, which fix the CO and CASE questions. The note is undated, so freshness is an upgrade-menu item. |
| 4. `Dan Kovac Northwind Data` | unavailable | L0 chosen by you. Public talks and writing would have tuned the persona weights and the reverse questions. |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | Your JD highlights are supplied, which fixes the requirement list used throughout. |

---

## Upgrade menu

- **The full JD text** → the six highlight rows (F1 to F6) move from your summary to the posting's own words. Any location, pay or work-authorization term becomes a gate row, surfaced before any bridge.
- **Priya's own words on sales ops and quota setting** → F8, D3 and the prohibited entry on quotas stand on her word, not on your notes.
- **Any document showing the store-surface proposal and its measured result** → F9, A1 and E1 gain an inspectable artifact, and their confidence can rise to high.
- **The partner-level revenue model, or a one-page summary of what it sized and who used it** → F2 and F4 gain an inspectable artifact.
- **A dated check of the research note** → C1 to C3 get a freshness label.
- **Dan's public talks or writing** → a richer interviewer read and tuned reverse questions. This is a deeper research pass, up to 6 more searches and 2 more page fetches, several minutes. Say if you want it; it runs only on your say-so.
- **A tuesday-dossier.md** → a record of the gaps this prep exposed, for later sessions.
