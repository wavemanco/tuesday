Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-3-denied-67deae04/042351fc-c6ee-49db-af2b-23072ce02c49/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for an unspecified final-round interview, since your note didn't say who you're meeting or what the round covers. The pack has no Stripe-specific content yet: web search was refused in this session, so I couldn't pull Stripe's values, interview structure, or recent strategy. Every requirement is a general product-operations pattern, labeled `[generic]`, and the persona weights are flat.

Say the word and I'll play the Pressure interviewer on B1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and what kind of round is it: hiring manager, a peer, a panel, or a values-style interview? The answer reweights every question bank.
2. Can you paste the job posting and your CV? Without them, the pack can't quote your experience or the posting's requirements. I can rebuild it on them in one pass.
3. Does the posting require on-site days or a specific location, and do you need sponsorship to work there? I can't tell from the material whether you meet those conditions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

First version. Built with no CV, no job posting and no Stripe research (web search was refused in this session). Every requirement is a role-family pattern marked [generic]. Persona weights are flat because the round type is unknown.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (behavioral and values), JD (role requirement), CASE (live problem). This pack has no CO questions, because company research did not run, and no EXP questions, because there is no CV to probe.
- Guidance is scaffolding, not a script. Each guidance cell can be spoken in 90 to 120 seconds.
- Answer slots and scaffolds ask you for your own experience. Where your experience is not in the material, the cell says so instead of supplying it.

## Fit snapshot

No CV and no posting were provided, so every evidence cell is `none given`. The requirements are common product-operations patterns, not Stripe's own list, and each is labeled [generic]. Replace them with the posting's exact wording once you paste it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running the planning and review cadence for a product area (role-family pattern) | none given | none | [generic] | discovery | Answer slot: if you have run a planning or review cycle, say how, in your own words, and which part of it was yours to set. If you have not, say so plainly, and say how you would first learn the team's cadence. |
| F2 | Coordinating launches or process changes across engineering, finance, legal and go-to-market (role-family pattern) | none given | none | [generic] | discovery | Scaffold: pick a launch or process change that crossed three or more functions. It needs a named stake, the step you personally moved, and how it ended. If none comes to mind, say so plainly, then say how you would handle one. |
| F3 | Defining and reporting metrics that teams act on (role-family pattern) | none given | none | [generic] | discovery | Scaffold: pick a metric you defined or reported. Say what it counts, what it is sensitive to, and which part was yours. If you have not defined one, say so, and say what you would measure first. |
| F4 | Designing internal processes and tooling that people adopt (role-family pattern) | none given | none | [generic] | discovery | Scaffold: pick a process you changed. Say what was there before, who had to change how they worked, and how you know it stuck. If you have not changed one, say so, and say how you would find the process that most needs changing. |
| F5 | Influencing people without formal authority and escalating disagreements (role-family pattern) | none given | none | [generic] | discovery | Scaffold: pick a time you disagreed with someone more senior and did not drop the point. Name the stake and the relationship at the end. If no such time comes to mind, say so plainly, then say how you would handle it. |
| G1 | Office pattern and location the role requires (gate; no posting provided) | none given | none | [generic] | hard_gate | Your material does not establish whether you can meet the office pattern. Not bridged here. See question 3 in the message. |
| G2 | Right to work and sponsorship for the role's location (gate; no posting provided) | none given | none | [generic] | hard_gate | Your material does not establish this. Not bridged here. See question 3 in the message. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| none yet | No sentence about your past is in the material, so no inflated wording can be built from it | Once your CV is in, this list is built from its sentences. Until then, do not describe a project, metric or role that you have not told me about; the pack will not supply one. |

## Persona table

Round type and relationship are unknown, so every persona has a flat prior. Each persona gets 3 questions, except Conversational, which gets 2. A pack built on a known round is sharper than this one.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Follow-ups that ask for the counting method and the assumptions behind a figure | Flat: no relationship known | Name the weakest assumption yourself, before they do | A1 to A3 |
| Pressure / Stress | Interruptions, time limits, challenges to your position | Flat: no relationship known | Hold a position through two follow-ups; concede only the specific uncertainty | B1 to B3 |
| Values / Behavioral | Scenario prompts asking for past decisions | Flat: no values round is established, and none is assumed | Story with a named stake, your own part, and an honest ending | C1 to C3 |
| Case / Strategist | A live operations problem | Flat: no relationship known | Clarify, then structure, then test, out loud | D1 to D3 |
| Skeptic | Probes on the gaps the fit snapshot shows | Flat: no relationship known | A plain answer to the gap, and a ramp plan; no bluffing | E1 to E3 |
| Peer Evaluator | Seams between your team and theirs; credit and disagreement | Flat: no relationship known | Offer seam principles and say what you need from them | F1 to F3 |
| Conversational | Friendly openers that are still scored | Flat, and lower depth | A 90-second arc; treat casual questions as scored | G1 to G2 |

## Question banks

Question IDs are letter-by-persona, so the drill and the coaching can refer to them. Provenance is [generic] throughout, because no candidate sentence is in the material.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you measure whether a process change actually worked?" | JD | [generic] | Name the first metric you would use, what it is sensitive to, and the assumption you would defend least. If you have measured a process change before, say how it was counted, in your own words. If you have not, say so and say what you would measure first. | Covers F3. The weakest-assumption move is the part probers test most. |
| A2 | "When have you reported a metric that other people acted on?" | JD | [generic] | Open prompt. Pick one instance. Say what the metric counts, what it is sensitive to, and which part of the reporting was yours. If none comes to mind, say so plainly, then describe how you would build one. | Covers F3. Open prompt, so the candidate picks the instance. |
| A3 | "How would you tell whether a process you designed is actually being used?" | JD | [generic] | Name the usage signal you would check first, and what you would do if it is low. Answer slot: if you have checked adoption before, say how, in your own words; if you have not, say so. | Covers F4. A prober asks how you know, not whether you tried. |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over someone who has done this job before?" | JD | [generic] | Pause, restate the question, then name the one thing you can do that the experienced candidate may not. If the honest answer is that you have less direct experience, say so and name the ramp you would take. Hold through two follow-ups. | Highest-ROI prep in this pack. It is the question most likely to be asked in some form, and the honest answer is the one that survives. |
| B2 | "That answer sounds like a framework. What did you actually do?" | JD | [generic] | Hold the step you actually took, stated once, in your own words. Concede the specific point you are unsure of. Do not fold on the core claim to restore the mood. | Hold-then-concede structure. The concession is named and specific, so it does not read as a collapse. |
| B3 | "Give me one decision you have made in your career, and tell me how much of it was yours." | VAL | [generic] | Open prompt. Pick one decision. Say what you decided, what others decided, and where the line sits. If none comes to mind, say so, then give the nearest one. | Tests the same attribution honesty as A1 under time pressure. |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the hard truth changed a decision. Name the stake, your part, and the relationship at the end. If no such time comes to mind, say so plainly, then say how you would handle it. | A persona stem. No company value is cited, because none was established. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's need and the internal number pointed different ways. Say what you chose and what it cost. If none comes to mind, say so, then say how you would weigh the two. | A persona stem. Scored on the decision, not on the slogan. |
| C3 | "Tell me about a process you changed where people pushed back. What did you do?" | VAL | [generic] | Open prompt. Pick one change. Say who pushed back, what you did about it, and what happened to the process. If you did not change one, say so, then describe how you would handle the pushback. | Covers F4 and F5 together. |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A product team's launch reviews keep slipping by two weeks. What do you do first?" | CASE | [generic] | Clarify what slipping means, sort the causes, and name the one check you would run first. Think aloud. Challenge one premise of the question. | Covers F2. Scores the order of your thinking, not the answer. |
| D2 | "You inherit a planning process across eleven teams with no shared metrics. Sketch your first thirty days." | CASE | [generic] | Clarify scope and who owns what. Then list what you would learn, what you would change, and what you would leave alone. | Covers F1 and F4. A live problem, so it asks for no claim about your past. |
| D3 | "A metric your team owns dropped 20 percent this week. Diagnose it." | CASE | [generic] | Segment before you guess. Name the two or three checks that separate a data problem from a real drop. State what would change your mind. | Covers F3. Generic metric diagnosis. |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the one area where your direct experience is thinnest, then a concrete ramp for it. Do not claim the area is strong because it is adjacent unless you can say how. If you cannot name it, say what you would check first. | Covers F1 and F2. The Skeptic's favourite opener. |
| E2 | "How would you run your first planning cycle if you had never run one?" | CASE | [generic] | Name the steps you would take in the first two weeks, in order, and who you would ask. Say plainly what you would not do until you had learned the team. | Hypothetical, so it presupposes nothing about your past. |
| E3 | "Why this role, and why now?" | VAL | [generic] | Answer in your own words. Say what you want next and why this role serves it. Keep the answer to one minute. | A motivation probe. Keep it consistent with what you say in the other rounds. |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between product operations and the teams it supports, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know this team's seam. Say how you would decide who owns a disagreement. Name what you would bring to their team, not only what you need. | Peer persona stem. Reciprocity framing scores well here. |
| F2 | "How do you handle credit when work spans several teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work. Say how you named the people who did the work, and where you were the one who did the coordinating. | Covers F2 and F5. |
| F3 | "What would you need from me in your first month?" | JD | [generic] | Name two or three specific things, and what you would offer in return. Do not ask for a list you cannot defend. | Peer reciprocity. |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey into operations." | VAL | [generic] | Pre-scripted 90-second arc: one role you held, one thing you changed, what you want next. Use your own sentences. | Casual, but scored. Rehearse the arc until it is boring. |
| G2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name one tool you have used, what you did with it, and where your use stopped. If you have not used one, say so, and say what you have read about. | A casual question about a likely topic. Treat it as scored. |

**Requirement coverage.** No posting was provided, so there are no stated requirements to cover. Against the role-family rows: F1 is covered by D2, E1 and E2. F2 by D1, F2 and E1. F3 by A1, A2 and D3. F4 by A3, C3 and D2. F5 by B2, C1 and F2. G1 and G2 are gates, not questions; they are asked in the message.

## Reverse questions

Each one carries a reason it lands. None needs an interviewer profile, so none is tied to a path.

1. "What would a strong first six months look like in this role, and how would you tell it was going well?" It makes them name success criteria, which most interviewers can answer.
2. "Which planning or review cycle would this role own, and who relies on its output?" It shows you understand operations as a cadence, not a project.
3. "Where do product operations and the teams it supports most often disagree about process, and how is that decided?" It surfaces the seam, and their answer tells you how the team handles conflict.
4. "What has the team changed about how it works in the last year, and what did that change cost?" It invites a candid answer about tradeoffs.
5. "When you think about people who did this job well, what did they do that the job description does not say?" It asks for the unwritten part of the role.

## Sources

Provided documents: none. The request named the company and the role only.

Searches sent, all refused (the search tool was not permitted in this session):
- "Stripe values operating principles": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description": refused

Fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; 4 calls refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. Would have moved the values cheat sheet (section 10), which is therefore absent, and the values questions. |
| 2. Stripe interview process, product operations | unavailable | Refused. Would have moved the loop structure and the persona weights. Flat weights are used. |
| 3. Stripe strategy / recent news | unavailable | Refused. Would have moved the company-strategy questions (CO) and a grounding brief. Neither is in the pack. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative product operations JD | unavailable | Refused. Would have moved the requirement rows, which are now [generic]. |

## Upgrade menu

- Round type and who you are meeting → reweights every persona and tells us which bank to lead with
- Posting text pasted → the five role-family rows become JD-tagged questions with quoted requirements, and the coverage line becomes real
- Your CV pasted → the fit snapshot gets quoted evidence, and the open prompts become story-mapped answers
- Your recruiter's note on the round → establishes what the round holds, and whether it has a values part
- Interviewer's name → a public-footprint read, persona tilts, and a reverse question about their path
- Web search allowed in a new session → reruns the company values, the interview process, and the recent strategy; a values cheat sheet and a strategy-based question become possible
- Round schedule, if the final is several sessions → one mini-pack per session
