Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-7-canned-6bf69e02/da853f0e-9de0-45da-bd47-fd8b3c56b859/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md. I built it on the assumption that Tobias is the hiring manager, since Saltmarsh's careers page says the Outage Hour is a single 60-minute interview with the hiring manager.

The most important thing to prepare is the in-app purchases gap (B1). Saltmarsh's news says two titles are moving to a season-pass model from February 2027, so expect that question. The second is the leadership gap (B2). Your rehearsal should be a clean "I haven't" followed by a concrete plan.

Say the word and I'll play the Skeptic on B1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or someone you'd work beside? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, assumed. Saltmarsh's careers page says every loop ends with "a single 60-minute interview with the hiring manager", and you describe this as a 60-minute interview with Tobias. Confirm in the question at the end of the delivery message.
**Round:** one session, the Outage Hour. Saltmarsh's careers page describes it as "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."
**Mode:** session (one upcoming conversation). No loop schedule is needed.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Name | What it tests |
|---|---|---|
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what you personally did |
| VAL | Behavioral / values | Whether your past behavior shows Saltmarsh's three published values |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you know where Saltmarsh is heading |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words. Quoted sentences come from your message, from the JD, or from Saltmarsh's own pages, and each one is named.

## 4. Fit snapshot

No requirement in the JD is a gate in the sense of a legal, credential, location or schedule term. "3+ years" is graded on fit, not treated as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. Say it in your own terms: the weekly content-drop calendar, for your main title, for two years. Caveat: one sentence and no artifact yet. Bring the calendar itself to make this high. |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title, so the bridge stops there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned or ran a calendar for a second title, say which and what you did; if you did not, say so and say how you would plan two. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years match the requirement's number. "Live-service" and "producer" are not in your sentence, so do not add them. Give the years and the studio type as stated, describe the content drops, and let the interviewer judge the fit. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Rewords only that sentence: "I presented the monthly retention numbers to the studio head." Presenting a number is not defining it; the defend-the-number slots in section 9 apply. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The sentence reaches the requirement. Caveat: the checklist is the artifact a probe would ask for. Bring a copy. Do not turn "wrote" into "managed". |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given for cross-team coordination. The only related line: "Never led a team" (your message) | none | [grounded] | discovery | Nothing in your material shows coordinating across these four disciplines. Plain acknowledgment, if asked about leading: "I haven't led a team." Answer slot: if you coordinated with any of those four disciplines on a release or update, name the one and what you did; if you did not, say so and say how you would. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | The sentence touches KPI reporting but does not show ownership or a post-event review. Derivation: F4's sentence read against this requirement. Answer slot: if you set which KPIs were reported, or wrote a post-event review, say so; if you presented numbers someone else set, say that plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The checklist is written work a team uses daily. Point to it. Same caveat as F5. |
| F9 | Monetised live titles, implied by the season-pass move in Saltmarsh's news (not in the JD; plain prose) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the purchase side, said as a plan and never as a past. |

Seven rules hold here. No cell claims a capability beyond its quote. F9 is the stated absence, and its words come only from your own sentence.

## 7. Reading the interviewer

Public footprint is thin. One search returned a GDC 2026 talk listing Tobias as Head of Live Operations at Saltmarsh. The link pointed to a reserved example domain and I did not open it, so nothing from it is used here.

What this means for the pack:

- Persona weights come from the Outage Hour's documented structure (a live-incident tabletop, then a values conversation) and from the hiring-manager relationship, not from Tobias's own writing.
- No career-jump mirror is offered, because nothing public establishes Tobias's path.

## 8. Persona table

Weights are relationship priors (hiring manager: Case/Strategist plus Skeptic) adjusted by the loop. The Outage Hour's live tabletop raises Case. Its values conversation makes a values-style round detected (Saltmarsh's careers page documents one), so Values is guaranteed here.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (top, 5 questions) | A live incident and a live-events plan | High. The Outage Hour is documented as a live-incident tabletop | Clarify, then structure, then speak the first hour out loud |
| Skeptic (4 questions) | "Never led a team" and "never worked on a game with in-app purchases" | High. Both stated gaps are the Skeptic's material, and the hiring-manager prior puts this persona second | Plain acknowledgment, then a credible plan. Never claim what you did not do |
| Values/Behavioral (3 questions) | The three published values, asked as STAR-shaped prompts | High. The loop documents a values conversation | Map each value to a quoted sentence where one carries a story; otherwise choose a time and name the honest branch |
| Data-Driven Prober (3 questions) | The retention numbers on your CV line | Medium. Presenting a headline metric draws this persona | Say how it was counted if you know; say plainly if you do not |
| Pressure (2 questions) | Challenges on attribution and on the checklist | Low to medium. No source puts Pressure in this round, so depth is 2 | Hold the quoted work through two follow-ups; concede only the specific part |
| Conversational (2 questions) | A casual opener and a casual question on a hot topic | Low. Casual questions are still scored | Pre-scripted 90-second arc from quoted sentences |
| Peer Evaluator (2 questions) | Seams with QA and credit across teams | Low. A hiring manager is not a peer, but QA is a real seam | Reciprocity framing; propose seam principles, not facts |

Total: 21 questions, inside the 18 to 26 range.

## 9. Question banks

Each guidance cell is speakable in 90 to 120 seconds. Provenance quotes every candidate sentence the guidance rests on.

### A. Case/Strategist (top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is the second evening of a live event. Players say a reward-claim bug locks them out of the shop. It is confirmed, and the fix is two days away. What do you do in the first hour?" | CASE | [generic] | Clarify scope: how many players, which platforms, whether a workaround exists. Name the objective: stop the damage without a promise you cannot keep. Work the triage with engineering, decide what players hear now and when, and say what the post-event review will check later. Think aloud. | The Outage Hour is documented as a live-incident tabletop. The scenario is generic and makes no claim about your past. |
| A2 | "Day three: participation is 20 percent below plan. Diagnose it." | CASE | [generic] | Clarify the metric definition first. Segment by new and returning players, platform and region. Check what changed: content, schedule, economy, bugs. Say what you would need from analytics before concluding. Challenge one premise. | Case format in the same round. The plan figure is invented for the exercise. |
| A3 | "Project Larkspur moves two titles to one shared events calendar from February 2027. What does your first 90 days of planning look like?" | CO / JD | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, search snippet, not opened) | Speak the sequence: learn each title's cadence and dependencies, map QA freeze dates, agree the calendar with design, art, engineering and community, and name the biggest unknown first. Answer slot: if you have planned for more than one title, say which; if not, say so, then give the sequence. | F2's transferability sits here. This is the CO question from the strategy target. Read the news page yourself before the round. |
| A4 | "Two teams want the same release slot. How do you decide?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure: what each team loses, the player impact, who must be in the decision, and the rule you would write down. Answer slot: if you have settled a slot conflict between teams, say how and what you did; if you have not, say so and walk through the decision. | F6 is discovery; the JD's coordination line is the raising source. No claim about your past. |
| A5 | "The event ended with mixed KPIs. Walk me through the post-event review you would run." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Structure: the review question first, then the data cut, then who attends, what gets written down and by whom, then decisions and owners. Answer slot: if you ran a post-event review, say what it covered; if you did not, say so and walk through one. | F7 is discovery. Nothing here asserts that you owned a review. |

### B. Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. What would you do in your first month here?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, not a past: how you would learn the purchase side, and from whom. Hold through two follow-ups by returning to the plan. Concede specifically: "I don't yet know how purchase data reaches live-ops here. I would ask first." Never claim purchase-side experience. | Highest-ROI prep. F9 is a stated gap, and a clean acknowledgment with a credible plan is the strongest answer you can give. Deepest rehearsal in the pack. |
| B2 | "You've never led a team. How would you coordinate design, art, engineering and community on one update?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment: "I haven't led a team." Then the coordination method you would use, as a plan. Answer slot: if you coordinated across any of those disciplines on an update, name it and what you did; if not, say so. Hold the method through two follow-ups. Concede the lack of authority, not the method. | F6 is discovery, and the stated leadership gap sits beside it. A mid-list JD item the Skeptic will use. |
| B3 | "Your calendar covered your main title. This role plans two. Which part can you not yet picture?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Name one honest unknown: the second title's cadence or team. Do not claim a second title. Answer slot: if you have worked on more than one title's calendar, say which. | F2 is transferability. The question asks for the limit openly, so the honest answer is the strong one. |
| B4 | "Why would you move from a puzzle studio into live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "live-service games or apps" (JD) | Say your reason in your own words. The material does not state one, so this is a slot, not a script. If you have not yet put the reason into words, do that before the round. Name what you would bring from the content calendar, not a claim you cannot back. | Skeptic's motivation probe. The material is silent on motive, so the answer is yours to give. |

### C. Values/Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a player's experience beat a planned date." | VAL | [grounded] "Players Before Plans" (Saltmarsh values page); nearest candidate sentence: "Presented the monthly retention numbers to the studio head." (your message) | Open prompt. Choose a time one player-facing outcome beat a planned date: name the stake, the decision you made, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented, or the content calendar. | Values page's first value. No sentence of yours carries a decision, so this is a selection scaffold with its honest branch, not a story map. |
| C2 | "Tell me about a time you shipped less than was promised, and why." | VAL | [grounded] "Ship the Patch Not the Promise" (Saltmarsh values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Map to the checklist: you wrote it, and QA still uses it. Those are the beats the sentence states. Answer slot: if the checklist ever stopped a release or changed what was announced, say what; if it did not, say so and describe what it gates in your own words. Do not invent a release you pulled. | The value asks whether you announce what is built. The link between checklist and announcement is the interviewer's inference, not your claim. |
| C3 | "When did you leave a build better than you found it?" | VAL | [grounded] "Leave the Build Greener" (Saltmarsh values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Map to the checklist as the thing you left behind: you wrote it, and it is still in use. Answer slot: if you changed the checklist after a release and can say what, name it; if not, say so and say what you left. | Second mapping of the same sentence. Keep the limit visible. |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot. If you know how the figure was counted, say it in your words. If you presented numbers you did not calculate, say so plainly. Never supply a method. | F4. EXP because it tests what was yours. |
| D2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Weakest-assumption slot. If you know an assumption behind the figures, name it before they do. If you do not, say you do not know how they were counted. | Metric questions include the weakest-assumption move. |
| D3 | "Which post-event KPI would you distrust first, and why?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name one metric family, say what would make it misleading, and say what you would check before trusting it. Your own figures are not part of this answer. | Generic pattern answer; the JD line is the raising source. |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a live team?" | JD | [grounded] "Never led a team" (your message) | Pause, restate the question, then answer with the calendar, the checklist and the retention numbers, in your words. Hold through two follow-ups. Concede precisely: "They have led a team and I have not. Here is what I would bring from the first day." | F6. The hold is only the quoted work. |
| E2 | "That checklist: how much of it was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: "I wrote it, and QA still uses it." Answer slot: if others edited it, name who and what they changed; if you wrote it alone, say so. Hold through two follow-ups, and concede specifically on any part others changed. | Attribution pressure. The hold is the quote, nothing more. |

### F. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "Wrote the release checklist our QA team still uses." (your message); "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc. Each beat is one of the quoted sentences, in order. Add nothing between them. | Casual openers are scored. |
| F2 | "What live game have you been playing lately, and what has its team done well?" | CO | [generic] | Name one game you have played, one thing its live team did well, and why it worked for players. Keep to what you have actually played. | Casual question on a hot topic. Generic because no source names a title. |

### G. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The release checklist is run with QA. Where is the seam between your checklist and theirs, and what happens when you disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Reciprocity: what you bring to QA, not only what you need. Propose seam principles: one owner per check, and a written decision when you disagree. Answer slot: if QA changed what you wrote, say how; if not, say so. | Peer probe on the release-checklist requirement (F5). |
| G2 | "How do you handle credit when a release spans design, art and engineering?" | JD | [generic] | Name the rule you would use: credit the person who did the work, and say so in the release notes. Raise disagreement early and in writing. Give your own example only if you have one. | Generic pattern. |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, B3 |
| Coordinate design, art, engineering and community teams on each update | A4, B2 |
| Own the post-event review and the KPIs it reports | A5, D3 |
| Manage the release checklist with QA | G1 |
| 3+ years producing live-service games or apps | B4 (fit row F3) |
| Experience running a content calendar | none needed: F1 closes it with a quoted sentence |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | none: F8 uses the checklist as evidence; rehearse one written summary in a drill |

## 10. Values / principles cheat sheet

A values-style round is detected: Saltmarsh's careers page documents a values conversation in the Outage Hour.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No sentence of yours carries a decision of this kind. Selection scaffold with its honest branch: see C1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F5: "Wrote the release checklist our QA team still uses." See C2 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5: same sentence. See C3, where the limit stays visible |

## 11. Reverse questions

Each one carries a "why it lands" line. Tobias's own path is not established by a source I trust, so none of these ties to it.

1. "Saltmarsh's values page says that when the calendar and the players disagree, the players win. Can you give me the last call that settled that?" Why it lands: turns a published value into a real example and shows how they decide.
2. "Project Larkspur moves two titles to one shared events calendar from February 2027. What will the first quarter of that plan need to settle?" Why it lands: shows you read the news, and their answer shows what they worry about.
3. "Who reads the post-event review here, and what happens after it is read?" Why it lands: tells you how far the KPIs travel, which scopes the role.
4. "How does QA's sign-off fit with the live calendar today?" Why it lands: connects to the checklist you wrote and signals you will work with QA.
5. "What would the first 90 days have to deliver for you to call this hire a success?" Why it lands: makes the hiring manager state the bar, so you can aim at it.

## 13. Prohibited claims

Each entry carries its basis and its honest form. No answer, hold, bridge or rationale in this pack asserts or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led a team" or "I managed a team" | Stated negative: "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." |
| "I've worked on live-service games" | Inflated form of F3. "Live-service" is not in your sentence | Your years and studio as stated: "4 years as an associate producer at a puzzle-game studio." |
| "I've worked on a game with in-app purchases" or "I've run monetised titles" | Stated negative: "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| "I ran the release checklist" or "I managed release sign-off with QA" | Inflated form of F5. "Wrote" became "ran" | "I wrote the release checklist our QA team still uses." |
| "I owned the KPIs" or "I defined the retention metric" | Inflated form of F4 and F7 | "I presented the monthly retention numbers to the studio head." |
| "I ran the content calendar for two titles" | Inflated form of F2. The sentence says your main title | "I ran the weekly content-drop calendar for our main title for the last two years." |

Inflated-form entries carry no first-person negative. The limit is this pack's own observation: your material says the main title, not two titles.

## 14. Sources

**Provided:** your message, with the JD text, the interview description, the interviewer's name and title, and your background. No CV was supplied, so your background is taken from your message.

**Searches and fetches:**

1. "Saltmarsh Games values": fetched https://saltmarshgames.com/values. Official page, three values by name: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.
2. "Saltmarsh Games interview process producer": fetched https://saltmarshgames.com/careers/interviewing. Official page: one recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager (a live-incident tabletop, then a values conversation), no take-home.
3. "Tobias Wrenfield Saltmarsh Games": one result, a GDC 2026 talk listing Tobias as Head of Live Operations at Saltmarsh. Its link uses a reserved example domain. Not opened; nothing from it used.
4. "Saltmarsh Games live operations 2026 news": one result, https://saltmarshgames.com/news/project-larkspur, read as a search snippet only (not opened). The snippet says that from February 2027 Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar and a single live-ops group. The two titles in your JD are probably these, which is an inference.

**Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 10: three values by name |
| 2. `Saltmarsh Games interview process` | yes | Loop: one 60-minute Outage Hour with the hiring manager, a live tabletop plus a values conversation. The pack prepares for that single session |
| 3. `Saltmarsh Games strategy` / recent news | yes | Snippet only: Project Larkspur. Feeds A3 and reverse question 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Confirmed his title; the talk link was not usable. Interviewer read stays thin |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

L2 was not run and was not offered in this delivery.

## Upgrade menu

- Your CV or the release checklist itself → makes F1 and F5 high-confidence, and lets the defend-the-number answers rest on the sheet
- The retention deck you presented → lets D1 and D2 be rehearsed against the real definitions
- Any calendar you planned for a second title → turns F2 from transferability to grounded
- Whether Tobias is your hiring manager → confirms the persona weights (currently assumed)
- The recruiter's note on the Outage Hour → confirms the loop structure and whether a recruiter call came first
- Any live-service or purchase-adjacent work you have done, even small → changes F3 and F9
- A `tuesday-dossier.md`, if you have one → carries verified evidence and rehearsal gaps into this pack
