Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-5-denied-4ed5519b/Kelverton_senior-partnerships-manager_interview_pack.md`. I built it for a panel with a POV, weighting the Skeptic and Pressure personas as the top two for Deepa and Ross. It has a POV build section with three theses, each with its concession, and 18 questions across the four personas.

The web searches were refused by permission, so the pack has no company research: no values, no interview structure, no strategy, and no read on Deepa or Ross. The POV is therefore built without knowing the consensus answer. The fastest fix is to paste the strategy team's market report, which I can't see from here. With it, the POV can depart from the report's shortlist, which is what the recruiter's setup rewards.

The highest-value rehearsal is B1, "You haven't sold into rail. Why would an operator take a call from you?" Rehearse the hold and the concession until they are plain. Ross's C1 to C3 and the commercial questions D1 and D2 come next.

Would you like a live drill on the POV or on B1? Either one takes about ten minutes.

**Question:** Can you paste the job description, if you have it? It would turn the requirements from my inference into quotes and show whether any gate applies.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a spoken point of view (POV), no slides. Remaining time: Q&A, with commercials pressed.
**Panel:** Deepa, VP Partnerships (your future manager). Ross, Commercial Director.
**Build:** no job description supplied and no research run (see Sources). Built from your message and the recruiter's email quoted in it. Labels show what each line rests on.

---

## How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored.
- Type key: **CASE** live problem · **JD** the role's stated work · **EXP** your own history, attribution under test · **CO** company knowledge (none researched yet) · **VAL** values (no values-style round detected).
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage (about 4 hours)

1. **60 min: draft the POV.** Pick 2 theses from section 5, each with its concession written out. Speak it aloud once, timed.
2. **45 min: commercials.** Answer D1 and D2 in your own words. Write down the one assumption behind the 6-to-40 and the £4M figures that you would defend least.
3. **45 min: the rail gap.** Rehearse B1 with the hold and concession. This is the question most likely to be asked in some form.
4. **30 min: two full POV run-throughs** at 15 minutes each, no notes.
5. **20 min: Ross's pressure set** (C1 to C3). Hold two follow-ups, then concede the specific point.
6. **20 min: reverse questions.** Choose 3 from the list at the end.

Everything else is insurance.

---

## Fit snapshot

Requirements come from the recruiter's email, quoted, and from your message where it describes the company. No JD was supplied, so no gate can be confirmed.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." (your message) | medium | [grounded] | presentation | Your material gives you the operator-side view, from network planning. Say it in those terms: "Five years in transport consulting, on bus and light rail network planning, so I know the operator world from the other side." Nothing about how operators buy is in your material. |
| F2 | "what it means for the operators themselves" (recruiter email) | "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." (your message) | low | [inferred] | discovery | Your material does not show an operator outcome you helped change. Answer slot: if you have seen a planning decision change for passengers, say what changed and whose decision it was; if you have not, say so and say what you would test first. |
| F3 | "Ross will push on commercials" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | medium | [grounded] | transferability | Partner growth and influenced revenue are adjacent to commercial ownership, not the same thing. Say the figures at their own scope: influenced, not booked. Do not restate them as revenue you closed. |
| F4 | "they sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't sold into rail." Then how you would learn it, said as a plan for the next 90 days, never as a past. |
| F5 | direct quota ownership (role-family, not quoted) | "never carried a direct quota" (your message) | none | [grounded] | capability | Stated absence. Words: "I've never carried a direct quota." Then the measure you would propose for the role, said as a plan. |

**Confidence** grades your evidence. **Provenance** grades what this pack says about it.

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail sales experience | Negative you stated (F4) | "I haven't sold into rail." No slot. |
| Carried a quota, or hit one | Negative you stated (F5) | "I've never carried a direct quota." No slot. |
| Owned or drove the £4M | Inflated form of F3; the material says influenced | The figure at its own scope: "roughly £4M of influenced revenue." The limit is this pack's observation: the material says influenced, not booked. |
| Designed the ISV channel's strategy | Inflated form of "running the ISV channel" | Running it, at that scope. |
| Knows how operators buy scheduling software | Inflated form of F1 | Operator knowledge from network planning only. |
| A method for counting partner growth or influence | Not in your material | Answer slot D1 only. |

---

## Graded deliverable: the 15-minute POV

Pre-declared by the recruiter: "present a short POV on where you'd take our operator partnerships over the next 18 months... Please land on what it means for the operators themselves."

**Consensus answer:** not established. No research ran, and the strategy team's market report is not in this workspace. Paste it (see upgrade menu) and section 5 can be rebuilt to depart from its shortlist, not repeat it. Until then, treat the theses below as the candidates to test, not the consensus to beat.

**Grounded facts to build on:**
- F1: "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F3: "took it from 6 partners to 40, roughly £4M of influenced revenue."

**Thesis 1: start from the operator's planning problem, not the partner list.**
- Argument: partnerships should begin with a specific operational decision the operator makes, then widen from there.
- Concession: "I have not sold into rail, and I don't yet know how operators choose or fund a scheduling vendor."
- Differentiation: the entry point is the planner's decision, which F1 lets you speak to; most partnership answers start with the vendor's product.
- Close: name one planner decision on a bad day that a partner would change, and what the passenger would notice.

**Thesis 2: fewer, deeper operator alliances, not a wider partner count.**
- Argument: the ISV model (6 to 40) is the wrong shape for operators: fewer buyers, longer cycles, more regulation.
- Concession: "My growth yardstick was partner count, from payments, and I may be wrong to carry it across."
- Differentiation: an anti-pick: say which kind of partner you would decline, and why that protects operator outcomes.
- Close: one operator outcome the first alliance would be judged on.

**Thesis 3: commercial terms tied to operator outcomes, not influenced revenue.**
- Argument: influenced revenue (F3) will not survive operator procurement; tie part of the commercial structure to a measured operational result.
- Concession: "I haven't negotiated an operator procurement cycle, so the structure I'm describing is untested in rail."
- Differentiation: a pilot-to-contract path, stated as a plan.
- Close: what the operator's own board would need to see to approve it.

**Mandatory close, not optional:** the last sentence of the POV must answer "what it means for the operators themselves." Say it as the planner's or the passenger's change, not the company's.

---

## Persona table

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa, Ross | The POV, then a live problem on operator partnerships | High. Both are reviewing altitude and structure; the POV is the case | Clarify the operator's decision first, then structure, then metrics. Say the framework aloud once. |
| Skeptic | Deepa | Quiet probing of the rail and quota gaps | High for Deepa. Your stated gaps are the obvious probe for a manager hiring into rail | Rehearse B1 until it is plain. Hold the true position, concede the specific gap, then give the ramp plan. |
| Pressure | Ross | Time-boxed challenges to the commercial claim | High for Ross. He has said he will push on commercials | Pause, restate, anchor on the quoted figure, hold through two follow-ups. |
| Data-Driven Prober | Ross | Asks how the 6-to-40 and £4M were counted | High. The figures are headline numbers | Say how you counted them, or say plainly you do not know. Name the weakest assumption before he does. |

**Weighting shown:** the panel blends the top two personas of each member, as the relationship priors give. No interviewer profile was found, so these weights rest on the relationship and the recruiter's note, not on either person's record.

---

## Question banks

### Persona A: Case/Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | This is the POV. Use the three theses in section 5: one operator decision, one fewer-deeper alliance, one commercial structure. | The recruiter named the prompt; it is the graded deliverable. |
| A2 | "What would an operator's planner notice first if this worked?" | CASE | [grounded] "what it means for the operators themselves" (recruiter email) | Name the planner's day. Answer slot from F2: if you have seen a planning decision change for passengers, say what changed and whose decision it was; if not, say so and say what you would test first. | F2 is the discovery gap the recruiter's phrase points at. |
| A3 | "Which operator would you not work with, and why?" | CASE | [generic] | The anti-pick. State a partner type you would decline and the operational reason. | Scores judgment and whether you can say no; no claim about your past. |
| A4 | "What would you stop doing from the current partner model?" | CASE | [generic] | Name one assumption from the partner model that does not carry to operators, and what you would change first. | Tests whether you can depart from a model you ran. No claim about your history is made. |
| A5 | "Which part of how an operator plans its network would you check before recommending anything?" | CASE | [grounded] "so I know the operator world from the other side" (your message) | Name one planning constraint from your network-planning years, in those terms. Do not claim knowledge of procurement. | F1 is the only source for operator-side knowledge. |

### Persona B: Skeptic, Deepa (weight: mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You haven't sold into rail. Why would an operator take a call from you?" | JD | [grounded] "Never sold into rail specifically" (your message) | Hold: "I haven't sold into rail." Then what you can point to: "so I know the operator world from the other side." Hold through two follow-ups by returning to the operator-side view. Concede the specific gap: rail buying cycles, not operator needs. Then the 90-day plan, as a plan. | F4 is the gap most likely to be raised; the question presupposes only the stated negative. Rehearse until the concession is plain. |
| B2 | "Your last four years were partner count and influenced revenue. Why is that the right yardstick here?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | Concede that influenced revenue is not quota. Say what you would measure with operators instead, as a plan. | F3 at its own scope; the concession keeps the figure honest. |
| B3 | "What did transport consulting teach you that would change how you'd talk to a planning director?" | EXP | [grounded] "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." (your message) | Open prompt. Pick one thing from network planning and say what it changes in your approach. | F1 is the source; the answer is yours to choose. |
| B4 | "Which part of this role would be weakest on day one?" | JD | [grounded] "Never sold into rail specifically" (your message); "never carried a direct quota" (your message) | Name rail and quota, plainly, then the ramp: what you would learn first and from whom. | Mid-weight Skeptic stem. The answer is the stated gaps, in order. |

### Persona C: Pressure, Ross (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should I trust a channel builder with operator revenue?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | Pause. Restate. Anchor on the quoted figure at its own scope. Hold two follow-ups. Concede that influenced revenue is not operator revenue. | Pressure tests composure. Do not defend the claim beyond the quote. |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue." (your message) | Answer slot: if you can say which deals or partners you were in, say so in your own words; if it was shared with others, say so plainly. | The honest branch is the whole answer. Do not invent a share. |
| C3 | "You've never carried a quota. What makes you think you can hit one?" | JD | [grounded] "never carried a direct quota" (your message) | Plain acknowledgment: "I've never carried a direct quota." Then the measure you would propose, as a plan. Hold through two follow-ups. | F5. The question presupposes only the stated negative. |
| C4 | "Train operating companies run on thin margins. Why would one pay for a partnership with you?" | CASE | [generic] | State what you would need to know about an operator's budget before answering, and the first test you would run. Do not assert their margins. | A pattern about the industry, not a fact about this employer. |
| C5 | "Give me one commercial number for operator partnerships in 18 months, and tell me how you got it." | JD | [generic] | Decline to invent a number without operator data. Say what data would produce one, and the first pilot that would test it. | Pressure on an invented figure. The honest answer is the test. |

### Persona D: Prober, Ross, commercials (weight: mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 6-to-40 growth was counted." | EXP | [grounded] "took it from 6 partners to 40" (your message) | Defend-the-number slot: say how you counted partners in your own words. If you did not track it a particular way, say so. Name the assumption you would defend least. | A figure you gave raises this slot. The method is yours to state, not supplied here. |
| D2 | "Of the £4M, what would have happened without the partners?" | EXP | [grounded] "roughly £4M of influenced revenue." (your message) | Answer slot: name the attribution assumption behind influenced revenue, and say how you would defend it. If you do not know how it was attributed, say so. | Prober's counterfactual. The weakest assumption, named first. |
| D3 | "What does an ISV partner's revenue look like in year one against year three?" | CASE | [generic] | Describe the pattern in ISV channels generally, labeled as a pattern. Anything from your own channel must be quoted from your message. | Pattern question; no claim about your history. |
| D4 | "What would you need in the first 90 days to put a number on operator revenue?" | JD | [generic] | List the data and the operator access you would need, in order. | Converts the commercial question into a plan the panel can judge. |

---

## Reverse questions

Pick at least five. Each has a "why it lands."

1. "What have operator partners asked for that the product does not yet do?" Why it lands: it shows you are thinking from the operator's side.
2. "How are commercial targets set for partnership revenue here: influenced or booked?" Why it lands: it goes straight to the gap Ross will press, and the answer tells you the scoring.
3. "Which operator relationship would you most want this role to repair first?" Why it lands: it reveals the real priority and invites a plan.
4. "What would a good first six months look like from your side?" Why it lands: it asks Deepa to define the job, which you need to know before you commit to a plan.
5. "Where does the partnerships team stop and the product team start on an operator request?" Why it lands: it shows you know the seams between teams, without naming any.

---

## Prohibited list: the reminder

The list above is binding on every bank and on the POV. No answer should say you sold into rail, carried a quota, owned the £4M, or know how operators buy.

---

## Sources

- **Provided documents:** your message (background, gaps, the format). The recruiter's email, as quoted in your message. The strategy team's market report: mentioned in your message, but not in this conversation or workspace, so it was not read.
- **Searches sent:** six, all refused, so no results came back.
  - "Kelverton Rail values": refused.
  - "Kelverton Rail interview process partnerships": refused.
  - "Kelverton Rail strategy news": refused.
  - "Deepa VP Partnerships Kelverton Rail": refused.
  - "Ross Commercial Director Kelverton Rail": refused.
  - "Senior Partnerships Manager rail technology train operating companies job description": refused.
- **Fetches:** none sent.

**Research tier: L1 — searches 6 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail` values | unavailable | Would have set the values cheat sheet, but no values-style round is detected, so the section is dropped anyway. |
| 2. `Kelverton Rail` interview process, partnerships | unavailable | Would have confirmed whether this round is a panel of the same shape; the persona weights rest on the recruiter's note. |
| 3. `Kelverton Rail` strategy / news | unavailable | Would have fed the CO bank and the POV's consensus answer. Those are the largest gaps in this pack. |
| 4. Interviewers (Deepa, Ross) | unavailable | Would have produced the interviewer read and personalized persona weights. |
| 5. Representative JD for the title | unavailable | Would have produced `[inferred]` requirements for the fit snapshot. |

---

## Upgrade menu

- **The job description text** → the requirements become `[grounded]`, and the gate check and JD-tagged questions get sharper.
- **The strategy team's market report, pasted** → the POV can depart from its shortlist instead of guessing at the consensus. This is the most useful thing you can add.
- **Web research permission granted** (the searches above were refused) → strategy, values and interviewer footprint can be checked. Say if you want the research retried.
- **Deepa's and Ross's public profiles or talks, pasted** → an interviewer read, and reverse questions tied to their own paths.
- **Your CV, if different from your message** → the evidence cells can quote it directly.
