Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-2/rooms/case-4-denied-f4518871/quartzline_product_manager_platform_apis_interview_pack.md`. I built it for a hiring-manager round, from your dossier.

Three things to know before you open it:

- **Web search was refused in this session**, so the pack has no company values, interview loop or current strategy. Those parts are marked unavailable in the Sources section.
- **The dossier's must-have R2 ("shipped API or platform products") is not in its weak-areas list.** Your verified entries show integration delivery through go-live, not an API product you shipped. I've treated R2 as a transferability gap with the limit named. It's worth checking against the dossier.
- **The dossier's "seven years of integration leadership" line is not a verified entry**, so the pack doesn't use it. If it's true and you can show it, it would strengthen the bridge.

The likeliest hard question is the one the dossier names: why hire you into a PM role without the title or a roadmap. Question A1 in the pack has the most rehearsal. It opens with a plain acknowledgment, then your verified integration work, then a ramp plan, and it never claims PM experience.

I need nothing else from you to finish the pack.

Would you like me to play the skeptic on A1 so you can rehearse it? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and a Word version of the pack is available on request.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Interviewer:** hiring manager, name not given. **Round:** 45-minute hiring-manager conversation, Thursday. **Built on:** your `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Web research was refused in this session, so the pack has no company values, interview loop or current strategy.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what it scores:

- **VAL**: behavioral and values alignment (not used here, no published values in hand)
- **EXP**: your experience, and whether you can say exactly what was yours
- **JD**: the role's stated requirements, including the gaps
- **CO**: company and strategy knowledge (not used here, research did not run)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Where guidance refers to your past, it uses only the quoted sentences in that row. "Dossier" below means the verified evidence and prohibited-claims entries in your dossier unless a row says otherwise.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | high | [grounded] | transferability | Bridge, with the limit named. Your verified work is integration delivery, carried from scoping through go-live. Say it as "I've led integrations end to end." Do not say it as product management. The material shows no product management role, and that limit is this pack's observation, not a sentence for you to say. |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas, R1 sub-claim | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | none | [grounded] | capability | Acknowledge, then ramp. Words, sourced to prohibited_claims: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan. The session quote is input to product, not authority over the roadmap; if asked, say it at that scope. |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | high | [grounded] | transferability | Bridge, with the limit named. This row is the pack's reading and is not in the dossier's weak-areas list: your verified work is integrating the vendor's APIs for clients through go-live. It does not show an API product you shipped. Words: "I've taken integrations to go-live." Answer slot: if you shipped something to users yourself, say what it was and your part in it; if not, say so and stay with the integrations through go-live. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Wrote the internal integration playbook her team uses" — dossier verified evidence | high | [grounded] | discovery | The playbook is the nearest entry, but the material does not show whether it covered API docs or schemas. Answer slot: if you have written or reviewed API docs or schemas, say which and your part; if not, say so and say what you would read first. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | medium | [grounded] | discovery | Customers and product appear in your entries; engineering and sales do not. Answer slot: if you worked with engineering or sales on an integration or a roadmap input, say who and how; if not, say so and say how you would bring them in. Expect a probe on the sessions (medium confidence, limited inspectable proof). |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred; dossier uncertain_or_weak_areas, clarify | none given | low | [grounded] | discovery | Clarify. No entry speaks to agile delivery directly. Interviewer's likely probe: what agile delivery looked like where you worked. Answer slot: if your teams ran it, say how in your own words; if they did not run it that way, say so and say what you would want to confirm about how they define it. |

## 8. Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the R1 and R2 gaps and the roadmap authority question | Top weight, 5 questions. Hiring managers buy capability and derisk gaps. The dossier names an objection in this persona's style, and two must-have requirements sit in the gap zone | Rehearse the objection until the acknowledgment and the bridge are boring. Name the weakest part before it is pulled out of you |
| Case/Strategist | Live problems on the partner API roadmap, adoption and partner discovery | Top weight, 4 questions. The role's responsibilities are live problems and the hiring manager will likely use one | Clarify, then structure: objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case |
| Data-Driven Prober | Asks how the 30+ figure was counted and what the roadmap-input sessions changed | Mid weight, 3 questions. No interviewer profile to raise it further, but the figure and the sessions are the likeliest numbers to be pushed | Say how the figure was counted, in your own words, or say plainly you do not know. Name your weakest assumption before the probe |
| Pressure | Interrupts or time-boxes on "why you" and "how much was actually you" | Mid weight, 3 questions. The authority question is where composure is tested | Pause, restate, hold through two follow-ups, then concede the specific uncertainty without folding on the core claim |
| Conversational | Friendly opener, "walk me through the journey," a casual question on API docs | Low weight, 2 questions. Casual questions are still scored | Keep a 90-second arc built only from verified entries |
| Peer Evaluator | Seam between product and the two squads, credit when work spans teams | Low weight, 2 questions. Not a peer round, but the seam with the squads is in the JD | Propose seam principles rather than pretending to know the seam. Show reciprocity: what you bring to their teams |

## 9. Question banks

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role" and "Having owned a product roadmap" — dossier prohibited_claims; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Hold, don't argue. Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a roadmap." Then the verified work in its own words: "I've led integrations end to end, from scoping through go-live." Then the ramp, as a plan: what you would learn first about the roadmap and the two squads, and who you would ask. Never claim the PM experience as yours. Hold through two follow-ups; concede that the decision authority is open for you and say how you would confirm it. | The underwriter named this objection, so it gets the deepest rehearsal. It sits on F1 and F2, and its negatives come from prohibited_claims, so the plain acknowledgment is sourced. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Having owned a product roadmap"; "Having set prioritization for an engineering squad" — dossier prohibited_claims | Name the roadmap and squad prioritization as the weakest part, in those words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then the ramp plan. Do not add a bridge you cannot back. | F2 is the one capability gap, and this question asks for it directly. |
| A3 | "How would you run planning with two engineering squads and the roadmap at the same time?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence; "Having owned a product roadmap" — dossier prohibited_claims | Start with what you have actually done near planning: the quarterly roadmap-input sessions, at their scope. Then the honest gap: you have not run squad planning as the owner of a roadmap, so say how you would learn each squad's cadence first. Agile answer slot (F6): if your teams ran agile delivery, say how; if not, say you would want to confirm what they mean by it. | Covers R5 and the roadmap sub-claim (F2, F6). Tests whether you can plan without overclaiming planning. |
| A4 | "Tell me about an API or platform product you've taken to users. If none comes to mind, say so and tell me the nearest thing." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Selection scaffold: pick a time you took something to users; it needs a named release or go-live and your part in it. If none comes to mind, say so, then give the nearest thing your material carries: integrations through go-live. Answer slot: if you shipped something to users yourself, say what and your part in it; if not, say so plainly. | Open prompt on the must-have requirement in F3. The honest branch is part of the answer. |
| A5 | "A PM with three years in this job applies against you. What would they do better on day one?" | JD | [grounded] "Having held a product manager title or role" — dossier prohibited_claims; "Wrote the internal integration playbook her team uses" — dossier verified evidence | Name it honestly: a PM who has run a roadmap already knows how to set priorities without a ramp. Then say what you would bring that is on the record: integrations through go-live, and the playbook your team uses. Do not claim the PM experience. Hold once, concede once. | A comparison probe. It tests whether you hold the line on the title without arguing against the interviewer's view of it. |

### B. Case/Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How would you decide what the partner API platform builds next, given partner requests and two engineering squads?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | Clarify, then structure: objective, segmentation of requests, approach, metrics, risks. Name the premise you would test first: whether partner demand or squad capacity is the constraint. Think aloud. This is a live problem and makes no claim about your past. | The role's roadmap responsibility is the one most likely to be tested live. Gives you the structure without any claim about your history. |
| B2 | "Partner API adoption dropped for one integration partner last quarter. Diagnose it." | CASE | [grounded] "Define and track adoption metrics" — dossier role_profile responsibilities | Clarify what adoption means first: calls, active integrations, or go-lives. Say you would ask how it is measured today. Then one or two hypotheses, and what data would separate them. | The adoption metric is a named responsibility, and the dossier lists its current baseline as unknown. Asking about the baseline is part of the answer. |
| B3 | "How would you define partner API adoption, and what would you baseline first?" | JD | [grounded] "Define and track adoption metrics" — dossier role_profile responsibilities | Propose one definition, name its weakest assumption in your own words, then say what you would baseline before setting any target. | Tests the same responsibility from the metric side. Presupposes nothing about the current state. |
| B4 | "A partner wants a feature you won't build. Walk me through your discovery with them." | JD | [grounded] "Run discovery with integration partners" — dossier role_profile responsibilities | Structure: the problem the partner has, what they would do without the feature, what evidence settles it, and what you would say no to and why. Speak to the partner's side of the decision. | Covers R4 with an external stakeholder, and the discovery responsibility. Makes no claim about your past. |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30 integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Say how the count was made and what "end-to-end" meant for it, in your own words. Say which part was yours. Answer slot: if no count was kept, say so plainly. Name the assumption behind the figure that you would defend least, before they do; if you cannot name one, say you have not checked the count. | A headline figure raises the defend-the-number slots. The count is the first thing a prober asks for. |
| C2 | "Which assumption behind that 30+ would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Give the assumption in your own words, first. If you do not know how it was counted, say so. Do not supply an assumption the material does not carry. | The weakest-assumption move for the same figure. Converts a gotcha into a credibility point. |
| C3 | "Show me one roadmap-input session that changed what product did. If none comes to mind, say so." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Open prompt. If one comes to mind, name the session, what it fed in, and what you contributed. If none does, say so, and say what the sessions did carry. Medium confidence: expect this probe, and do not stretch the session beyond its quote. | F5 and F2 both rest on this quote. The honest branch matters more than a story here. |

### D. Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Wrote the internal integration playbook her team uses" — dossier verified evidence | Pause. Restate the question to yourself. Give 60 seconds from the two verified entries. If pressed on the title or roadmap, use the plain acknowledgment and do not argue it. Hold on the integrations through two follow-ups. | A time-boxed challenge, testing composure. The answer is the same as A1, shorter. |
| D2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Hold: you ran the sessions and fed the client evidence in, as the quote says. Answer slot: if product's decisions came from the sessions and were theirs, say so. Concede only the specific part you do not know, in your own words. | Pressure on a medium-confidence claim. Hold, then concede the exact limit. |
| D3 | "You're asking me to believe you can run a roadmap without the title. Convince me." | JD | [grounded] "Having held a product manager title or role" — dossier prohibited_claims; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Do not argue the title. Give what you have done: integrations led end to end through go-live. Then the plain acknowledgment: "I haven't owned a roadmap, and I would want to be explicit about how I'd learn it." Hold once, then concede. | Pressure on R1 and the roadmap sub-claim. The position held is only what the quotes carry. |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Wrote the internal integration playbook her team uses" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Ninety-second arc in this order: the integrations, the playbook, the roadmap-input sessions. Stop there. Close with what you are looking for in the role, in your own words. | Casual, but scored. The arc is built only from verified entries, so it cannot drift. |
| E2 | "What have you read or written on API docs or schemas?" | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified evidence | Answer slot: if you have written or read API docs or schemas, name them and your part. If not, say so and say what you would read first. | Covers R3 casually. The question presupposes nothing about the answer. |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our squads sit beside product — where's the seam, and what happens when you disagree with a squad lead?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | Propose seam principles rather than pretending to know the seam: decision rights written down first, then capacity against partner requests. Disagreement: selection scaffold. Pick a time you disagreed with a peer or a lead; it needs a stake, a position you held, and a relationship intact afterwards. If none comes to mind, say so, then give the nearest thing your material carries: the roadmap-input sessions, and what you brought to them. | Covers R4 with the squads. The disagreement story is the scaffold case, so the honest branch is part of the answer. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | Use "we" for the team's or client's work and "I" for what you led: scoping, requirements, architecture, UAT, go-live. Answer slot: if a credit question came up on an integration, say how it was settled; if none did, say so. | Credit is a peer's probe. The verified entry already carries the we-and-I split. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1, 3+ years PM experience (must) | A1, A5, D3 |
| R2, shipped API or platform products (must) | A4, C1 |
| R3, technical fluency: API docs, schemas (important) | E2 |
| R4, stakeholder management (important) | B4, F1 |
| R5, agile delivery experience (preferred) | A3, held as the clarify slot in F6 |
| Roadmap and prioritization authority (R1 sub-claim) | A2, A3, D3 |
| Partner API adoption metrics (responsibility) | B2, B3 |
| The 30+ figure on your record | C1, C2 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Resolves the decision-authority unknown from the dossier, and reads as diligence on the JD. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Shows whether adoption is a defined target or a metric still to define. The dossier names this as an unknown. |
| 3 | "How do the two squads plan with product today?" | Tests the agile-delivery requirement from the employer's side (F6), and gives you the planning cadence you would need to learn. |
| 4 | "What would make this role a success at six months?" | Frames the scoring for the decision and gives you their definition to hold yourself to. |
| 5 | "What would a new PM do in their first month that would genuinely help your team?" | A reciprocity question. Signals you are thinking about their team's load, not only your own ramp. |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment, sourced to prohibited_claims: "I haven't held a product manager title or role." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims | Plain acknowledgment, sourced to prohibited_claims: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment, sourced to prohibited_claims: "I haven't set prioritization for an engineering squad." No slot. |
| Owned the API product, or decided what product built from client evidence | Inflated form of F1, F2 and F5, built locally | The quotes at their own scope: integrations led end to end, and roadmap-input sessions feeding client evidence to product. The limit is this pack's observation: the material says integrations and inputs, not product decisions. No first-person negative is written for this entry. |
| Shipped an API platform to users | Inflated form of F3, built locally | The integration quote at its own scope, through go-live. Answer slot as in F3. |

## 14. Sources

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2

Provided documents: `tuesday-dossier.md`, pasted into this conversation (dossier_version 1.1, generated 2026-08-14). Sections consumed: `role_profile` (satisfies the JD input tier, and its requirement text is treated as the supplied JD's lines), `handoff_to_mock_interview` (verified evidence, weak areas, likely objection, risks, employer questions, prohibited claims), and `decision` (context only; its "seven years of integration leadership" line is not a verified entry and is not used). The pasted dossier carries no `evidence_map`, `risk_register` or `evidence_state`. The dossier is from August; the requirement text is the dossier's, not a fresh read of the posting.

Searches sent, each refused by the host's permission setting:
- "Quartzline company values principles": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline partner API platform news strategy": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have moved the values cheat sheet, and only if the round proved values-style. Not built |
| 2. Quartzline interview process, product manager | unavailable | Would have moved the loop structure and persona weights. Weights here use round-type priors |
| 3. Quartzline strategy and recent news | unavailable | Would have moved the CO bank and a grounding brief. Neither built |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions |

## 15. Upgrade menu

- Your CV or resume → lets the fit-snapshot rows quote your own wording beyond the dossier's entries. Today every quote comes from the dossier.
- A release note or go-live record for an API product you took to users → moves F3 and A4 from transferability to a shipped claim, quoted from that record.
- A dated list of the 30 integrations → gives C1 and C2 a checkable figure instead of a count you have to defend from memory.
- Web search allowed in a later session → fills the three unavailable targets: the company values sheet, the interview loop (persona weights from the named rounds), and the strategy brief for the CO bank.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- The hiring manager's answer to reverse question 2 → B2 and B3 can use the stated adoption baseline.
- "Seven years of integration leadership" from the dossier's decision line, if it is true and you can show it → it becomes verified evidence and can carry a bridge that is not written around the 30 integrations alone.
