Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-8-denied-06a06a8f/e992040a-f2c8-4409-8872-d747881badfd/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as a loop: one shared fit snapshot, then a mini-pack per round.

Rehearse these first:
- **The contact-centre gap (B3).** The JD's first requirement names the contact centre, and you've never worked in one. This is the highest-ROI prep in the pack.
- **Presenting above regional level (B4, F2).** The JD asks for confidence presenting to senior leaders. Your material says you've never done it above regional level, so the answer is a plan, not a past.
- **The 20-minute escalation case (D3).** It's generic, because the recruiter gave only the format.

Your material gives you no story for three of the four values, so those rows are scaffolds with honest branches. The web searches were refused in this session, so the values and strategy rest on what you pasted and summarised.

Say the word and I'll play the Skeptic on B3.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:
Is the 20-minute case a written complaint file sent in advance, or described live?
Have you ever spent time in a contact centre, even briefly, such as shadowing or a project?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Changelog:** first version.

- **Role:** Member Experience Lead (member-owned, about 900 staff)
- **Company:** Ashgrove Credit Union
- **Date:** 4 December 2026 (nine days from 25 November)
- **Round 1:** 30 minutes, recruiter
- **Round 2:** 45 minutes, Head of Member Services (your future manager), mostly behavioural
- **Round 3:** 60 minutes, panel of two branch managers, including a 20-minute complaint-escalation case; the panel scores against the four values
- **Interviewers for rounds 2 and 3:** not yet assigned. Their weights are round priors, with no interviewer read.
- **Format:** loop mode. One shared fit snapshot, then one mini-pack per round.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Types:** VAL = behavioural/values alignment. EXP = work-experience deep-dive. JD = role/JD-driven. CO = company and strategy knowledge. CASE = live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud until it sounds like you.
- An **answer slot** is an instruction for the interview, not a question to me. Where the material has nothing, the slot gives an honest branch: "if you did this, say how; if not, say so."
- Provenance labels: **[grounded]** traces to your message, the JD, the recruiter's email, the values page you pasted, or your summary of the strategy brief. **[generic]** is a pattern with no claim about you or Ashgrove.

---

## Fit snapshot

Your material is thin on the JD's specifics. Everything below draws on the quoted sentences in the evidence column and on nothing else.

No gate rows: the JD sets no licence, credential, location or schedule term. Pay, notice and location are round-1 logistics, not JD gates.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | medium | [grounded] | transferability | For the branch's formal complaints log: "I handled the branch's formal complaints log." The material shows the log, not the end-to-end process and not the contact centre. Say the contact-centre limit yourself: "Never worked in a contact centre." Answer slot: if you set how a complaint moved from first contact to closure, say which steps and how you decided; if it was set for you, say so and stay with the log you handled. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | The material says "formal", not "regulated". Answer slot: if the formal complaints ran to a regulatory timescale or needed a response to a regulator, say which and where it came from; if not, say so and describe how the formal process ran. |
| F3 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Reword only the quote: "I've spent six years in retail banking, the last three as a branch supervisor." Do not claim "customer operations" as your title. Let the panel judge that fit. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaint reporting in other terms. The material does not say what it counts or whether it tracks resolution time. Those questions sit in banks B5 and E2. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The material does not name the tool. Answer slot: say which tool you built it in and which parts you built yourself; if it was not Excel, say what it was. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | "I trained new tellers on our escalation script." The material says tellers, not supervisors. Answer slot: if you coached anyone beyond tellers on escalations, say who and how; if not, say so and describe how you would coach a branch supervisor. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. Claim no presenting work above regional level. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or self-service team on any journey, say which and what you decided; if not, say so and say how you would start. |

---

## Prohibited claims

These are not coached anywhere in the pack, and each has a basis. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F1: the JD's scope line widens "the branch's formal complaints log" | "I handled the branch's formal complaints log." Limit, in my analysis only: your material says the log, not the process or the contact centre. |
| Has regulated-complaints experience | Inflated form of F2: "formal" is not "regulated" | The formal-complaints quote at its own scope. Limit, in my analysis only: the material does not say regulated. |
| Has coached branch supervisors on escalations | Inflated form of F6: "trained new tellers" is not supervisors | "I trained new tellers on our escalation script." |
| Excel expertise | Inflated form of F5: "built the monthly complaints spreadsheet" names no tool | "I built the monthly complaints spreadsheet our regional manager uses." |
| Has presented to senior leaders | Negative you stated, F7 | Plain acknowledgment: "I've never presented to anyone above regional level." No answer slot asks about past senior presenting. |
| Has worked in a contact centre | Negative you stated, F1 | "Never worked in a contact centre." |
| Any pay, salary history, notice period or location you have not given | No figure is in the material | Instructions only; see the logistics rows A2 to A5. |

---

## Persona table

No interviewer is named, so weights are round priors. Each persona is touched in at least one round.

| Persona | Rounds and weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | Round 1, top (5) | Friendly arc, then logistics: pay, notice, location, reason for leaving | High. Recruiter screens cover logistics and motivation first. | Pre-scripted 90-second arc. Treat logistics as scored, even in a chatty register. |
| Skeptic | Round 1 (2); round 2 (3) | Contact-centre gap, presenting gap, and "how do we know your numbers" | **High.** F1 and F7 are the two JD lines your material does not reach. Round 2 is where the manager tests them. | Rehearse the contact-centre objection until it is boring (B3, the highest-ROI prep). Bridge only from the log you handled. |
| Values / behavioural | Round 2 (4); round 3 (4) | Behavioural stories tested against the four values | High. The recruiter says round 2 is mostly behavioural and round 3 scores the values. | Map a story to each value where a quote carries one; otherwise use the selection scaffold and its honest branch. |
| Case / strategist | Round 2 (2); round 3 (1) | Digital shift and hub consolidation; the 20-minute escalation case | Medium. The strategy brief is the likely source of round 2 live problems. | Clarify, then structure aloud. Name the value in the room's frame (Neighbours, Not Numbers). |
| Pressure | Round 2 (1); round 3 (1) | "Why you over someone with contact-centre experience?" and "trust you with the whole process?" | Medium. Two JD lines with a stated gap invite a challenge. | Hold through two follow-ups, then concede specifically, in the words you already gave. |
| Data-driven prober | Round 3 (2) | "Walk me through how that is counted." | Medium. The spreadsheet is the only metric artefact in the material. | Name what the spreadsheet counts, or say plainly you do not know how a count was made. |
| Peer evaluator | Round 3 (1) | Seam between branches and contact centre; disagreement | Low to medium. The branch managers are peers of your future team. | Reciprocity: what you bring the contact centre's seam, not only what you need. Propose seam principles, not a claimed seam. |

---

## Question banks by round

**Loop mode:** round 1 has seven questions, round 2 has ten, and round 3 has nine, for 26 in total. Depth follows weight: top 4 to 5, mid 3, low 2 or fewer.

### Round 1: recruiter screen (30 minutes)

Recruiter persona weights: Conversational 5, Skeptic 2.

#### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." / "I handled the branch's formal complaints log" / "trained new tellers on our escalation script" | Ninety-second arc. Six years, the last three as a branch supervisor. Then the formal complaints log you handled and the teller escalation script you trained on, each in your own words. End on why this role, in one sentence. | F3 and F1 are the arc's only quotes. EXP because the arc is the CV's claims. |
| A2 | "What pay are you looking for?" | JD | [generic] screen logistics pattern; no figure from you | Logistics slot. Give your own figure, or ask to see the band first: "I'd like to see the band for this role before I give a figure." If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a logistics row. The pack supplies no figure and no range. |
| A3 | "What's your notice period?" | JD | [generic] screen logistics pattern | Logistics slot. Give your actual notice period, in your own words. | Notice is a logistics row. |
| A4 | "Where can you work from, and how often would you need to be on site?" | JD | [generic] screen logistics pattern | Logistics slot. Say where you can work from and how often, in your own words. Do not guess which hub the strategy will use. | Location is a logistics row. The hub plan is a round-3 factor. |
| A5 | "What's making you look at a move now?" | EXP | [generic] screen logistics pattern; no reason from you | Logistics slot. Give your reason in one or two sentences, in your own words. The pack supplies none. | Reason for leaving is a logistics row. EXP tests motivation consistency. |

#### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a branch person. Where's the contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Answer slot: if you have seen one run (shadowing, a project, a visit), say what you saw; if not, say so and say how you would learn the contact-centre side. | F1's limit, first raised in the screen. |
| B2 | "The JD asks for confidence presenting to senior leaders. How do you see that?" | JD | [grounded] "confident presenting to senior leaders" (JD) / "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare for a senior audience. Answer slot: if you have presented anything to regional level, say to whom and what happened; if not, say so. | F7 is a capability gap. The screen will check it early. |

### Round 2: Head of Member Services, 45 minutes, mostly behavioural

Round 2 persona weights: Values/behavioural 4, Skeptic 3, Case 2, Pressure 1.

#### Values / behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to give a member an answer they didn't want." | VAL | [generic] selection scaffold; no quoted sentence carries a member-facing decision | Pick a time a member pushed back on a decision you had to explain. Say what you said, what they did next, and what you would keep. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the escalation script, the log), or how you would handle it. | Stem from the values persona. The material shows no member-facing decision, so this is a scaffold with its honest branch. |
| C2 | "Tell me about the formal complaints log you handled. How did a complaint move through it?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Tell it in the quote's own terms: the log you handled. Answer slot: if you set the stages a complaint moved through, say which and how you decided; if the stages were set elsewhere, say so and describe the part you handled. | F1 is transferability. The JD's end-to-end line makes this probe likely. |
| C3 | "What timescales applied to formal complaints in your branch, and who set them?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) / "experience handling regulated complaints" (JD) | Answer slot: if a timescale applied, say which and where it came from; if none was set, say so and describe how the formal process ran. The question does not presume regulation. | F2 is discovery. It asks about the JD's regulated line without assuming the answer. |
| C4 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" (your message) | Story map from the quote: you trained new tellers on the escalation script. Answer slot: if you coached anyone beyond tellers on escalations, say who and how; if not, say so and describe how you would coach a branch supervisor on escalations. | F6. The JD asks about supervisors; tellers are the adjacent case. |

#### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "The role covers the contact centre as well as the branches, and you've never worked in one. Why would I bet on you?" | JD | [grounded] "Never worked in a contact centre" (your message) / "I handled the branch's formal complaints log" (your message) | **Deepest rehearsal.** Hold: "I've never worked in a contact centre." Then what you can show: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log. Concede on the second, specifically: "I haven't run a contact centre. Here's how I would learn it." The plan is a plan, not a past. Never say the branch and the contact centre are the same work. | This is the highest-ROI prep in the pack. The JD's first line names the contact centre, and it is your biggest gap. |
| B4 | "You've never presented above regional level. How would you present to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare, named. Answer slot: if you presented anything to regional level, say what and how it landed; if not, say so. | F7 is a capability gap. The plan is the answer. |
| B5 | "Walk me through what the monthly complaints spreadsheet counts." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what each count covers, in your own words, and which tool it sits in. Answer slot: if you set the counts, say which and how you decided; if the regional manager set them, say so and say what you built. The material has no figures, so none are given here. | F4 and F5. This is the JD's reporting line, tested as a skeptic's "how do we know". |

#### Case / strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The branches are going to five hubs during 2027. Where does complaints handling sit in that?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief). Structure: [generic] | Clarify: which complaints are open at a branch that is consolidated, who owns them after the move, what the member in that town is told. Objective: no complaint lost or re-opened in the move. Segment by branch and by open age. Approach. Metrics: volume and resolution time per hub. Risk: a complaint with a deadline that lands during the move. Speak the structure aloud, and keep Neighbours, Not Numbers in view. | The strategy is your summary, not the brief itself. Wording follows your summary. |
| D2 | "Forty percent of member service moves to digital by 2028. What changes for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief). Structure: [generic] | Plan, not past. Which complaints start in a digital channel, and how a member reaches a person when a digital journey goes wrong. Then which measure you would watch first. Do not claim digital work you have not done. | Ties the JD's self-service line to the strategy. |

#### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over someone with contact-centre experience?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) / "6 years in retail banking, the last 3 as a branch supervisor." (your message) / "Never worked in a contact centre" (your message) | Pause, restate, then sixty seconds: six years, three as a branch supervisor, and the formal log you handled. Hold through two follow-ups. Concede in your own words: "They would have more contact-centre depth than I do." | Pressure stem. The concession matches your own quoted sentence, nothing more. |

### Round 3: panel of two branch managers, 60 minutes, with a 20-minute case

Round 3 persona weights: Values/behavioural 4, Case 1, Prober 2, Pressure 1, Peer 1.

#### Values / behavioural (values round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "When did you put a member's need ahead of a target or a rule?" (Members First, Always) | VAL | [generic] selection scaffold; no quoted sentence carries this story | Pick a time you decided from the member's side of the counter when a rule or target said otherwise. Say what the member needed, what you decided, and what you would defend. If no such time comes to mind, say so plainly, then give the nearest thing you did and what it cost. | No candidate sentence carries a member-side decision, so this is a scaffold with its honest branch. |
| C6 | "Tell me about a time a member needed something explained twice. What did you change?" (Plain Words) | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold. Pick a time a member or a teller did not understand the first explanation. Say what was unclear and what you changed. If the escalation script is the nearest case, say what the tellers got wrong on it and what you changed; if you changed nothing, say so. | The value is Plain Words. The script quote is the nearest thing in the material. |
| C7 | "How does a complaint from a small-town branch differ from one in a city branch, and what did you do about that?" (Neighbours, Not Numbers) | VAL | [generic] selection scaffold; no quoted sentence about towns | Pick a time local context changed how you handled a case, or say none. If none, say how you would treat a complaint from a town whose branch is consolidated into a hub. | No candidate sentence speaks to towns. The hub plan adds the live pressure. |
| C8 | "Tell me about a problem you didn't let go of until it was solved." (Own the Fix) | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold. The log is the nearest sentence, and it carries handling, not resolution. Pick a complaint you held until it closed, and say what you did with items that stayed open. If you let items go, say so and what changed. If no such time comes to mind, say so plainly, then give the nearest thing the log carries. | The quote carries handling, not resolution, so it is not a story for this value. |

#### Case (20-minute escalation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "A member's complaint has been escalated to you. The branch says it's closed and the member says it isn't. Talk me through the next twenty minutes." | CASE | [grounded] "a 20-minute case on a complaint escalation" (recruiter's email). Scenario and structure: [generic] | Clarify: what "closed" means, what the member has been told, the dates on the file. Objective: the member has a clear answer, and the decision would stand up if checked. Decide ownership: keep hold until it is solved (Own the Fix). Decide the next step. Tell the member in plain words (Plain Words). Record the decision, and what you would check across branches for a pattern. Speak the structure aloud. | The recruiter's announced format. The scenario is generic and makes no claim about you. |

#### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the monthly complaints figures are counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what each count includes and where it came from. Answer slot: name the weakest assumption you know of, or say plainly that you do not know how a given count was made. | Premised on the quoted artefact only. No figure is in the material, so only the counting slot applies. |
| E2 | "Which resolution-time measure, if any, is in that spreadsheet?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) / "report monthly on complaint volumes and resolution times" (JD) | Answer slot: if it tracked resolution time, say how it was measured and which part you would defend least; if it did not, say so and say what you would measure first. | The JD's resolution-time line. The question asks whether a measure exists without assuming one. |

#### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F2 | "What's the case for trusting you with the whole process rather than the log?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) / "Never worked in a contact centre" (your message) | Hold: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to what you did with it. Concede specifically: "I haven't run the whole process or a contact centre." | Hold-then-concede on the JD's scope line. |

#### Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The contact centre and the branches are separate teams. Where's the seam, and what happens when you disagree?" | JD | [grounded] "across branches and the contact centre" (JD) / "Never worked in a contact centre" (your message) | Propose seam principles, not a claimed seam. For example: "I'd want the contact centre's view on the seam before I settle it. The principle I'd start from is one owner per complaint from first contact to closure." Answer slot: if you have disagreed with another team on a complaint, say how it resolved; if not, say so. | Peer prior. Reciprocity framing is the strongest move here. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | C2, B3, F2, G1, D3, reverse questions 2 and 3 |
| Report monthly on complaint volumes and resolution times | B5, E1, E2, reverse question 1 |
| Coach branch supervisors on escalations | C4 |
| Work with digital teams on self-service journeys | D2, reverse question 4 |
| 4+ years in financial-services customer operations | A1 (F3 quote); no separate question. Round-2 probing is through C2 |
| Experience handling regulated complaints | C3, reverse question 3 |
| Confident presenting to senior leaders | B2, B4 |
| Comfortable with Excel reporting | B5, E1 (the tool slot in F5) |

Strategy (D1, D2) and values (C5 to C8, D3) are covered above. Deliverables: none were declared, so there are no build sections.

---

## Values cheat sheet

Values are quoted from the copy you pasted from ashgrovecu.org/about/values on 25 November 2026. The panel scores against them.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted story. Scaffold, C5. Honest branch included. |
| Plain Words | If a member needs it explained twice, the wording was wrong | No quoted story. Nearest quote: F6, "trained new tellers on our escalation script." Scaffold, C6. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted story. Scaffold, C7. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest quote: F1, "I handled the branch's formal complaints log." It carries handling, not resolution. Scaffold, C8. |

---

## Reverse questions

Each one has a reason it lands. There is no interviewer profile yet, so none ties to an interviewer's path.

1. **"What does the monthly complaints report look like to you today, and what would make you change it?"** Why it lands: it shows you think about the report the role will own.
2. **"When the eight branches become five hubs, who owns a complaint opened at a branch that is consolidated?"** Why it lands: it shows you have read the brief and reaches the operating detail the JD depends on.
3. **"Which timescales apply to complaint handling here, and who sets them?"** Why it lands: it opens the regulated-complaints requirement without you claiming it.
4. **"How do self-service journeys and complaints connect today, if they do?"** Why it lands: it turns the JD's digital line into a question the team has to answer.
5. **"What could a new person do in their first month that would genuinely help your team?"** Why it lands: reciprocity for the peer panel. It converts the seam question into a joint problem.

---

## Sources

**Provided documents**

- Your message: the JD text, your background, the three round descriptions, your summary of the July 2026 strategy brief, and the values as pasted from ashgrovecu.org/about/values.
- The recruiter's email, as you pasted it. The round details and the values-round line come from it.
- The strategy brief itself was not pasted. Only your summary is used.
- No CV was provided. Evidence rests on your message.
- Dossier: none present.

**Research calls (L1)**

| Query sent | Outcome |
|---|---|
| "Ashgrove Credit Union values Members First Always Plain Words Neighbours Not Numbers Own the Fix" | refused |
| "Ashgrove Credit Union interview process Member Experience Lead panel" | refused |
| "Ashgrove Credit Union 2026 strategy digital hubs small business lending" | refused |

Fetches: none sent. User links read: 0.

**Research tier: L1, searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | unavailable | The check was refused. The values cheat sheet rests on your pasted copy, which the check would have confirmed. |
| 2. Ashgrove Credit Union interview process, Member Experience Lead | unavailable | The check was refused. The loop rests on the recruiter's email, a loop source, so the weights follow the three named rounds. |
| 3. Ashgrove Credit Union strategy / recent news | unavailable | The check was refused. Questions D1 and D2 rest on your summary of the brief. No current news was checked. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name yet. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- Interviewers' names for rounds 2 and 3 → personas weighted to their public footprint, plus a tailored reverse question.
- Your CV → turns the medium-confidence rows (F1, F2, F3, F4, F6) into inspectable ones, and checks the "6 years" line.
- The monthly complaints spreadsheet, or a screenshot of its columns → F4 and F5 can move toward high, and the defend-the-number questions can be written against real figures. None are in the material yet.
- The recruiter's note on the 20-minute case format → replaces the generic D3 with the panel's own format.
- The full strategy brief, not your summary → D1 and D2 move from your summary to quoted wording.
- Hours of prep before 4 December → adds a prep-triage section with a schedule.
- A story for any value (Members First, Plain Words, Neighbours, Own the Fix) → the scaffold rows become story maps.
- Any contact-centre exposure, such as shadowing or a project → B1 and B3 gain a quotable beat.
- A `tuesday-dossier.md` would carry the gaps this prep exposed into later sessions.
