Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-8-denied-e3aca76d/459b789f-ee52-4aab-a373-ac62353d7075/scratchpad/Ashgrove_member-experience-lead_interview_pack.md`. Because there are three rounds on 4 December, it's built in loop mode: one shared fit snapshot, then a mini-pack per round, with 23 questions in total.

The main thing to prepare is the gaps. Your material says you haven't worked in a contact centre and haven't presented above regional level, and the job asks for both. The pack gives you honest lines for each: state the gap in your own words, then describe how you would learn or prepare, framed as a plan. It never gives you a past experience you don't have. Two other gaps are in the pack too: nothing in your material shows regulated complaints work or tracking resolution times. The contact-centre question is the highest-value prep. I used the values and strategy you pasted, so no web searches ran.

Two things to check before you rehearse:
- The strategy quotes come from your summary of the July brief, not the brief itself. If you can get the brief, the pack can quote it directly.
- Interviewer names aren't known yet. Once you have them, the panel's questions can be tuned to each person.

I haven't run a drill yet, because it needs your answers. I can start one now as the Skeptic, on the contact-centre question, if you want.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for your next session. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Rounds:** three, on 4 December 2026 (loop mode, one shared fit snapshot and one mini-pack per round)
**Interviewers:** names not yet assigned; relationships come from the recruiter's email
**Loop source:** the recruiter's email of 25 November 2026 (round lengths, relationships, and the values scoring in the panel)

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values alignment; **EXP** your own work, probed for attribution; **JD** the listed job; **CO** company and strategy knowledge; **CASE** a live problem.
- The guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds.
- Where a cell says "answer slot", it is an instruction for the interview. It asks nothing of you in this conversation.
- Where a cell says "logistics slot", give your own answer in your own words. The pack supplies no figure, reason or range.

## Persona weights

| Round | Relationship | Weights | Why |
|---|---|---|---|
| 1, 30 min recruiter screen | Recruiter | Conversational (lead); light Skeptic | Relationship prior for a recruiter screen; the recruiter's email calls it a screen, so logistics checks come first |
| 2, 45 min Head of Member Services (your manager) | Hiring manager | Values/Behavioral (lead); Skeptic (second); Case/Strategist (lighter) | The manager prior is Case and Skeptic, but the email says "mostly behavioural", so Values/Behavioral moves to the top and Case drops to a lighter tilt |
| 3, 60 min panel of two branch managers | Peer panel, scored on values | Values/Behavioral (lead); Case/Strategist (second, the 20-minute escalation case); Peer Evaluator (third); Data-Driven Prober (low) | The email says the panel scores against four values and includes the case; the peer prior blends in. Branch managers would work alongside the role, so Peer Evaluator is the third persona |

Interviewer names are not known, so no interviewer read is included. Persona weights apply per round.

## Grounding brief

Built from your note of Ashgrove's July 2026 strategy brief. The brief itself was not pasted, so the quotes below are your summary, not the brief's text.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Published values are in the values cheat sheet below.

## Fit snapshot

Requirements are quoted from the job description you supplied. Evidence is quoted from your own messages or from the job description. Confidence is set by what can be inspected, and everything here is `medium` at best because nothing has been inspected.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Say it as written: "Six years in retail banking, the last three as a branch supervisor." Limit: your material says retail banking, not customer operations in the JD's sense. Say the banking and the branch work, not the label. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | Answer slot: if a regulatory timescale, referral route or other requirement shaped the log, say which and how you worked to it; if none did, say so plainly, then say how the log was run. Your material is silent on regulation. |
| F3 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Bridge: "I trained new tellers on our escalation script." Limit: that was tellers, not supervisors. Make the transferable case, then name coaching supervisors as the step beyond it. |
| F4 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Say it as written: "I built the monthly complaints spreadsheet our regional manager uses." Limit: the sheet goes to your regional manager; the material does not say it reported upward. |
| F5 | "resolution times" (JD) | none given | none | [grounded] | discovery | Answer slot: if the spreadsheet counted how long complaints took to close, say which measure and what it was sensitive to; if it did not, say so and say what you would add first. |
| F6 | "own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Bridge: "I handled the branch's formal complaints log." Limit: one branch, and the material does not show end to end. |
| F7 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn the contact centre's complaint routes, said as a plan and never as a past. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I haven't presented above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Excel is not named in your material. Answer slot: say which tool the spreadsheet ran in and what you built in it, in your own words; if it was not Excel, say so. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked on a digital or self-service change, say what it was and what your part was; if you have not, say so, and say how you would start with the digital teams. |

**Gates.** None of the JD's requirements is a gate: the four it names are experience, handling, presenting and Excel, not a credential or a term. Nothing here is a hard gate.

## Prohibited list

Not coached in any cell in this pack. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F6 | "I handled the branch's formal complaints log." The material says one branch's log. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." The material says tellers. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." The material does not say the log was regulated. |
| Built the report that tracks resolution times | Inflated form of F4 and F5 | "I built the monthly complaints spreadsheet our regional manager uses." The material does not say it counted resolution times. |
| Used Excel | Inflated form of F9 | "the monthly complaints spreadsheet." Name Excel only if it was. |
| Worked in a contact centre | Negative you stated (F7) | Plain acknowledgment: "I haven't worked in a contact centre." No answer slot here. |
| Presented to senior leaders | Negative you stated (F8) | Plain acknowledgment: "I haven't presented above regional level." No answer slot here. |

## Round 1: recruiter screen, 30 minutes

Persona weights: Conversational (lead), light Skeptic.

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Ninety seconds. Open with six years in retail banking and the last three as a branch supervisor. Then the formal complaints log. Then training new tellers on the escalation script. Each beat is a clause your sentences state; tell them in your own words. | The open question reads the CV back, so F1 and F2 get said first, at their own scope. |
| A2 | "What are your notice terms?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | The recruiter's logistics check. You gave no figure, so none is supplied here. |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the band for this role first. The pack gives no figure and no range. | The recruiter's pay check. The only safe answer is yours. |
| A4 | "Where are you based, and can you work across sites?" | JD | [generic] | Logistics slot: state where you can work and how often you can get to an office, in your own words. | The consolidation in the strategy brief may make location come up, but the recruiter has not raised it. |
| A5 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your own reason in your own words. The pack has none to offer. | The recruiter's reason-for-leaving check. Nothing about your reason is in the material. |
| A6 | "Why Ashgrove, a member-owned credit union?" | CO | [grounded] "Members First, Always — we decide from the member's side of the counter." (values page, pasted) | Pick the value that matches your own experience, from the cheat sheet. Say what that means to you in your own words. Do not recite the values page. | Motivation probe. The values page is the published frame the recruiter will check against. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does the 4 December day look like in order, and who runs each round?" | Confirms the round order and the panel's format before you spend prep time on the wrong thing. |
| "Do you know the panel members' names yet?" | If the answer is yes, the pack can be tuned per member. |

## Round 2: Head of Member Services, 45 minutes

Persona weights: Values/Behavioral (lead), Skeptic (second), Case/Strategist (lighter).

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you made a complaints decision from the member's side." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Selection scaffold. Pick one complaint in your log where the member's side changed what you did. If none did, say so plainly, then give the nearest thing your log carries: how you handled the complaints in it. | Members First, Always is scored in the panel as well. Your sentence says you handled the log; it does not say a member's side decided anything, so the honest branch is written in. |
| B5 | "How would you coach a branch supervisor whose escalations keep coming back?" | JD | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "trained new tellers on our escalation script" (your message) | Structure first: what you would look at before you coach. If you have coached someone on an escalation, say who and what you did, in your own words. If not, say so and say what you would check first. | This is the JD's coaching line. Your training of tellers is the nearest thing your material carries, and the guidance stops there. |
| S1 | "You've never worked in a contact centre. How would you run complaints that come in there?" | JD | [grounded] "Never worked in a contact centre" (your message); plain acknowledgment: "I haven't worked in a contact centre." | Hold: "I haven't worked in a contact centre." Then how you would learn the contact centre's complaint routes, as a plan, not as a past. Hold through two follow-ups by returning to the plan. If pressed on a specific, concede that specific plainly. | Highest-ROI prep in this pack. The JD names the contact centre as part of the job, and your material says you have not worked there. Expect this probe in some form. |
| S2 | "Who is the most senior person you've presented to, and how did it go?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I haven't presented above regional level." Then how you would prepare for a senior audience, as a plan. Do not describe a senior presentation you did not give. | The JD names senior presenting, and your material says you have not done it above regional level. |
| S3 | "The role asks for regulated complaints handling. Which requirements, if any, shaped how your branch's log ran?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if a regulatory timescale, referral route or other requirement shaped the log, say which and how you worked to it; if none did, say so plainly, then say how the log was run. | The JD's regulated complaints line, asked with "if any" so the answer can be no. |
| C2 | "If forty percent of member service moved to digital, what would you check first about complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your note of the strategy brief); "the main competitive pressure is app-only banks." (your note) | Name the check in your own words: what share of complaints come through digital today, and where a self-service route would send a complaint. Name the pressure the brief names, app-only banks, without reciting the brief. | The strategy-altitude question. Your note of the brief gives the frame; the answer must be your own. |
| C4 | "How would you work with a digital team building a self-service complaint route?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Structure: what you would need from them and what they would need from complaints data. If you have worked on a digital or self-service change, say what it was and your part; if you have not, say so and say how you would start. | The JD's digital line, with no claim about your past. F10 is the row behind it. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would a strong first ninety days look like across the branches and the contact centre?" | Turns a behavioural interview into a conversation about the work and shows you have read the JD closely. |
| "How does the monthly complaints report reach senior leaders today?" | The answer shows what the report must do for the manager, and tests your F4 and F5 rows against the real use. |

## Round 3: panel of two branch managers, 60 minutes including a 20-minute case

Persona weights: Values/Behavioral (lead), Case/Strategist (second), Peer Evaluator (third), Data-Driven Prober (low). The panel scores against the four values. Values cheat sheet below.

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "Tell me about a time someone needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Selection scaffold. Pick a time you explained something that had to be made clearer. If none comes to mind, say so plainly, then give the nearest thing your material carries: training new tellers on the escalation script. | Plain Words is scored by the panel. Your material has no explanation-twice story, so the honest branch is written in. |
| B3 | "When did a figure hide something about one branch's customers?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." (values page); [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Selection scaffold. Pick a time a count left something out about a branch or its customers. If none did, say so, then say what your spreadsheet leaves out. | Neighbours, Not Numbers is the value most likely to be tested against a number you built. The honest branch is the one that matters. |
| B4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Selection scaffold. Pick a complaint you held until it was resolved. If the log recorded complaints without following each one to close, say so. | Own the Fix is scored by the panel. Your material shows handling a log, not following a fix to its end, so the limit is written in. |
| C1 | 20-minute case: "A member has escalated the same fee complaint twice, once at a branch and once through the contact centre. They now say they are closing their account. What do you do?" | CASE | [generic] | Clarify first: what the complaint is, what the record shows, and which complaint timescale applies, checked rather than assumed. Then one owner, one fix, and the member's answer. Then the measures you would track and the risks, such as the member leaving and the complaint reopening. Think aloud, and challenge one premise respectfully. | A live problem from the JD's escalation line. It asks about no past of yours, so it needs no claim about you. |
| C3 | "If a branch were moving into a hub, what would you check about the complaints still open that day?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your note of the strategy brief) | Structure first: which complaints are open, who owns each, what the member is told, and what gets handed over. Say the hub move in your own words. | Conditional phrasing, so no premise about the move. Your note of the brief gives the context. |
| P1 | "Branches send escalations to the contact centre. Where's the seam, and what happens when we disagree about who owns a complaint?" | Peer | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Propose seam principles rather than pretending to know the seam: one owner per complaint, the rule for disagreement, and who decides. Make no claim about a seam you have seen. | The panel's peer probe on the JD's branch-and-contact-centre line. |
| P2 | "Branch supervisors already handle escalations. What would you take off their plate, and what would you leave with them?" | Peer | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "trained new tellers on our escalation script" (your message) | Name a principle for the split. Your training of tellers is the only coaching your material shows; say that and no more. | Collegial packaging of the coaching objection. |
| P3 | "How do you handle credit when a complaint fix takes three teams?" | Peer | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Name who did which step, in your own words. If the fix was shared, say so. Do not credit yourself with a step you did not take. | Credit-sharing is a peer probe. Your sentence says what you handled, and the answer must stay at that scope. |
| D1 | "How was the monthly complaints spreadsheet counted, and which figure would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: if you did this, say how, in your own words; if there was no such step, or it was not yours, say so plainly and return to the spreadsheet's use by your regional manager. Name the assumption you would defend least before they do, if you know it. | The defend-the-number probe for a figure you built. The pack does not name a counting method. |
| D2 | "What does a complaint volume count include, and what does it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: if you can say what the count includes and leaves out, say so in your own words; if you cannot, say you do not know how it was counted, and what you would check. | Prober follow-up on the same sheet. "I don't know how it was counted" is an honest answer. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does a strong answer to the 20-minute case look like to you, and what do you see most often fall short?" | Converts the case into a conversation with the people who score it. |
| "What could a new person do in their first month that would genuinely help your branch?" | Reciprocity with peers. It turns a probe into shared work. |

## Values and principles cheat sheet

Values are quoted from the values page you pasted on 25 November 2026. The panel scores against these four.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2 quote: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: pick one complaint in your log where the member's side changed what you did. If none did, say so, then give the nearest thing the log carries. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F3 quote: "I trained new tellers on our escalation script." Selection scaffold: pick a time something had to be made clearer. If none comes to mind, say so, then give the training. |
| Neighbours, Not Numbers | Every branch is part of its town. | F4 quote: "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold: pick a time a count left out something about a branch or its customers. If none did, say so, then say what the spreadsheet leaves out. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F6 quote: "I handled the branch's formal complaints log." Selection scaffold: pick a complaint you held until it was resolved. If the log only recorded complaints, say so. |

## Sources

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0.

**Provided documents.** Your message (role, job description, your background, the three rounds, the strategy brief summary); the values page, pasted as copied from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email (round structure and values scoring). The strategy brief itself was not pasted, so its quotes are from your note.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the four value names and wording, so the cheat sheet needs no search. |
| 2. Interview process | skipped | The recruiter's email establishes the loop: three rounds, their lengths, their relationships, and the values scoring in the panel. |
| 3. Strategy and recent news | skipped | Your July 2026 brief summary is under six months old and answers the CO questions. |
| 4. Interviewer name and profile | n/a | No interviewer names were given; panel members are not assigned. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

No searches were sent. The values, the loop and the strategy frame came from the documents above.

## Upgrade menu

- Panel members' names and roles → per-member personas, an interviewer read, and reverse questions tailored to each panel member
- The 20-minute case's brief or data, if one is sent in advance → grounded facts for C1, not only the scaffold
- Your notice period, pay expectations, location and reason for leaving, in your own words → the logistics slots A2 to A5 become your own answers
- Which tool your monthly complaints spreadsheet ran in, and whether it counted resolution times → F5 and F9 become answers you can give directly
- The full job description, if it runs beyond the lines above → any further requirement gets a fit row and a question
- The strategy brief itself, not your summary → C2 and C3 can quote the brief's own words
- A tuesday-dossier.md from a prior session → replaces the inferred highest-ROI objection with one the evidence derives
