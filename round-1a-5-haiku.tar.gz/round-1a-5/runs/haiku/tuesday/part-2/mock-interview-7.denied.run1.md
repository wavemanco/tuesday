Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-7-denied-312356ec/4619b537-5558-4a79-a4a5-e9636a8cea0b/scratchpad/Saltmarsh_Games_live-ops-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has no Saltmarsh-specific facts: no values, no interview structure, nothing about Tobias. Every company-level line is labeled generic.

The pack's hardest question is S5: "You haven't led a team. What makes you the right person to coordinate four of them on each update?" Your honest answer is to say "I haven't led a team" first, then either describe any real cross-team coordination or say plainly how you'd set it up. Don't reach for a leadership story you don't have.

I can play the Skeptic on S5 for a drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-ops-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Role: Live Operations Producer
Company: Saltmarsh Games (mobile studio, about 350 people)
Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; your note did not say. Persona weights below rest on that assumption.
Round: 60 minutes, format not stated.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Rehearse the shape, then answer in your own words, using only what you actually did.

Type key:
- **VAL**: behavioral, tests whether past behavior shows the company's published values. Not used: no values-style round was detected.
- **EXP**: work-experience deep-dive, tests whether your claims hold up under scrutiny.
- **JD**: role-driven, tests whether you can do what the posting lists, gaps included.
- **CO**: company and strategy knowledge. Not used: no company research ran (see Sources).
- **CASE**: live problem from the role, scored on structure and reasoning.

Answer slots: where the material does not show a practice, the guidance gives you two honest branches, one for "I did this, here is how" and one for "it was not mine, or it did not happen". Use whichever is true.

## Fit snapshot

Requirements come from the job description you pasted. Evidence comes from your message, the only background material in this session; there is no CV. No requirement in the posting is a gate (no licence, location, right-to-work or credential term), so no gate row appears. The posting's "3+ years" is a length requirement and is graded on fit like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles or live events. Bridge stays at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the posting asks for two titles, so expect a probe on the second. If you planned a second title or any live event, say how; if you have planned one title's drops only, say so and describe how you would take on a second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Nothing in your material shows this coordination. Answer slot: if you coordinated any of those four teams on an update, say which and how; if you did not, say so plainly and describe how you would set up that coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not owning the review or the KPIs, and the bridge does not stretch it. Answer slot: if you chose what was measured or ran a post-event review, say how; if you presented numbers someone else defined, say that plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA still uses it. "Wrote" is not "manage", so the bridge stays with the quote. Answer slot: if you have changed the checklist or run sign-off with QA since writing it, say how; if you have not, say so. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the metric in other terms. Comfort is a trait your material does not state, so the bridge does not claim it. No figure is given, so no defend-the-number slot arises here; the probe is on what the numbers measured (P1, P2). |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years, an associate title, and a puzzle-game studio. Your material does not say the work was live-service in the posting's sense, so the bridge does not say it. Answer slot: if the work on your main title was live-service, say how (content drops were live); if it was not, say so and say what the nearest live work was. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Lead with it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The checklist is written work that another team relies on. It shows the work was used, not that it was clear, and the bridge does not claim clarity. Answer slot: if you have written material another team relied on and can describe its clarity, say what it was; if you have not, say so and offer the checklist as the example to bring. |

## Prohibited claims

Built from the fit snapshot before the question banks. These are the claims this pack will not coach, each with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran the live-events calendar for two titles." | Inflated form of F1 (the posting's two-title scope) | Quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation, not words for you: your material says one title and content drops. |
| "I owned the post-event review and the KPIs." | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The limit is this pack's observation: presenting is not owning. |
| "I managed the release checklist with QA." | Inflated form of F4 ("wrote" widened to "manage") | "Wrote the release checklist our QA team still uses." |
| "I have three or more years of live-service production." | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." |
| "I've led a team." or any leadership claim | Negative you stated: "Never led a team" | Plain acknowledgment, which you may say: "I haven't led a team." No slot about leading. |
| "I've worked on a game with in-app purchases." | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment, which you may say if it comes up: "I haven't worked on a game with in-app purchases." The posting does not raise it, so no question below is built on it. |
| "I'm comfortable with retention metrics, so I can own them." | Widening of F5 into a trait and an ownership claim | "Presented the monthly retention numbers to the studio head." |

## Persona table

Relationship prior for a hiring-manager round is Case/Strategist plus Skeptic: the manager is buying capability and checking the gaps. The posting adds a Prober, because it names player-retention metrics and the KPIs the review reports. The 60-minute length and a likely opener add a Conversational register. No public information about the interviewer was available, so no interviewer-signal adjustments apply.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Quiet cross-examination of the gaps: two-title scope, coordinating four teams, KPI ownership, and the stated lack of team leadership | High. The posting's coordination and ownership lines, plus your own notes on leadership, are the likeliest openings | Rehearse the most predictable objection until it is plain. Say the gap first, then the plan. Never bluff a competency | S1 to S5 (5) |
| Case/Strategist | Live problems on the role: plan a calendar, diagnose a retention drop, decide between two titles, handle a QA gate | High. A hiring manager with a live roadmap expects a live problem | Clarify, then objective, then constraints, then approach, then metrics, then risks. Think aloud | C1 to C5 (5) |
| Data-driven Prober | Probes the retention line and the review's KPIs, asking what the numbers measured | Medium. Retention is a named requirement, and your material says you presented it. No figure is given, so the probe is on definitions | Say what the metric measured, in your words. Say plainly when you do not know how a figure was set | P1 to P4 (4) |
| Conversational | Opens with a journey question and closes with an invitation to ask questions | Medium. A 60-minute round usually opens and closes this way, and casual questions are still scored | Practise a 90-second arc. Treat casual questions on the posting's topics as scored. Have real reverse questions ready | V1 to V3 (3) |

## Question banks

Count: 17 questions. This is one under the usual floor, because the pack does not pad: the posting's two-title and coordination lines are covered by S1 to S3 and C1 to C3.

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've run one title's content drops. What would you do on day one with a second live title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, in those words. Then give the day-one plan as a plan: read the second title's calendar, ask who owns each drop, list what you do not know. Answer slot: the posting asks for two titles. If you have planned for more than one title, say how; if you have planned for one, say so and stay with your plan. | F1 is the scope gap the posting is most likely to press. A plan is allowed; a past for the second title is not. |
| S2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name coordinating four teams on an update as the part you have least direct evidence for. Say what you would do first: ask each lead for their constraints before any date is set. You may say "I haven't led a team." Do not raise in-app purchases unless asked. | A persona stem. It lets you name the gap before it is named for you. |
| S3 | "Tell me about a time you coordinated design, art, engineering and community on an update." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (job description) | Selection scaffold: pick the update where you had to get the most teams to agree on a date. If none comes to mind, say so plainly, then give the nearest thing your material carries, the content-drop calendar you ran for two years, and how you would run the four-team version. | F2 is silence in your material. The honest branch is the point of the answer. |
| S4 | "Post-event reviews and the KPIs they report are yours in this role. What have you owned end to end?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in those words. Answer slot: if you chose what was measured, or ran a post-event review, say how; if you presented numbers someone else defined, say that plainly. | F3 is low confidence and the premise is the posting's. Do not turn presenting into owning. |
| S5 | "You haven't led a team. What makes you the right person to coordinate four of them on each update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-return rehearsal in this pack. Hold: open with "I haven't led a team." Then the answer slot: if you coordinated any of the four teams on an update, say which and how; if you did not, say so and describe how you would set up the coordination in your first month. Hold through two follow-ups by returning to that plan. Concede the specific gap: the leadership and the four-team coordination are what you would learn first. Never say you are a natural leader. | The single most predictable objection to this candidate. It is aimed at F2 and at the stated negative, and it is where the material is thinnest, so it gets the deepest rehearsal. |

### Case/Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the next eight weeks of live events for one of our titles. What do you need to know first?" | CASE | [generic] | Clarify first: which metric the events serve, what the current cadence is, what QA gates exist, what engineering can absorb. Then objective, approach, metrics, risks. Speak it in about 90 seconds. | JD: plan and run the live-events calendar. CASE scores structure before answers. |
| C2 | "Day-7 retention dropped after the last content drop. Diagnose it." | CASE | [generic] | Clarify the size of the drop and which cohort it hit. Check release timing against other changes. Segment by platform and cohort. Name the weakest assumption: what the baseline is and whether it is comparable. | JD: comfortable with player-retention metrics. |
| C3 | "Two titles want the same engineering sprint for their next update. How do you decide?" | CASE | [generic] | Clarify what slipping each date costs. Talk to the engineering leads rather than assume their capacity. Propose two options with trade-offs. Say who decides and how the decision is recorded. | JD: coordinate four teams and two titles. A decision problem, not a claim about your past. |
| C4 | "QA says the build is not ready three days before a live event. What happens next?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Use the checklist as the anchor for what gates a date. Decide: cut scope or move the event, and name who makes that call. Record the decision. Answer slot: if you have had to move an event on a QA gate, say what happened; if you have not, say so and describe how you would decide. | JD: manage the release checklist with QA. F4 is the honest anchor. |
| C5 | "Walk me through the post-event review you would run after a live event." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A framework, not a past: plan against actual, KPI movement, cohort effects, what to change, and an owner for each action. Anchor the reporting end in your retention presentation, in those words. No claim about a review you have run. | JD: own the post-event review and the KPIs it reports. F3 is low confidence, so the framework does the work. |

### Data-driven Prober (weight: mid-high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "What did the monthly retention numbers you presented actually measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the metric measured, in your own words. If you can say how it was defined, say it. If someone else set the definition, say so. No figure is given, so do not supply one. | F5. The probe tests whether you know what the number is. |
| P2 | "Which assumption behind your retention reporting would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name one only if you know one. If you do not know how the figure was set, say that plainly. A pack-supplied assumption would be invention. | Persona stem for the Prober. Naming the weakest assumption first converts a gotcha into credibility. |
| P3 | "Retention went up in the week of an event. How do you know the event caused it?" | JD | [generic] | Separate novelty from lift: a holdout group or a comparable cohort. State the limit of whatever you would use. | JD: comfortable with player-retention metrics. A method for the problem, not a fact about you. |
| P4 | "You've reported retention monthly. What would make you change how a KPI is defined partway through the year?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the kind of change that would justify it and who approves it. If you have never changed a definition, say so. | JD: own the KPIs the review reports. Tests judgment about KPI governance. |

### Conversational (weight: low-mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc whose beats are clauses from those two quotes: the studio and the years; the content-drop calendar; the checklist QA still uses; the retention reporting; then the gap you are taking on. Do not add beats. | An opener that is scored. Keep it to what your quotes carry. |
| V2 | "Which live-service game has the best event calendar you've seen, and why?" | JD | [generic] | Name one game and one specific thing about its cadence you can describe. Do not say you have worked on it. | A casual question on a topic the posting cares about. No research ran, so no game is pre-chosen. |
| V3 | "Tell me about the last content drop you ran, and what it did." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Name one drop from the calendar and describe its scope. Answer slot: if you tracked what the drop did, name the measure in your words; if you did not track it, say so. | The question presupposes a drop, which the quote states. It does not presuppose a result. |

## Reverse questions

Five are needed, and the pack gives six. No interviewer profile exists, so none is tied to the interviewer's own path.

1. "What would a strong first six months look like for the two titles' calendars?" Why it lands: sets the bar for the role and shows you are planning, not only asking.
2. "When QA and a live date disagree, who decides, and how often does that happen?" Why it lands: tests the gate's authority and shows you have thought about the release checklist.
3. "Which of the two titles needs the most attention right now?" Why it lands: shows triage thinking and tells you where the role starts.
4. "Which KPIs does the studio head review after each event, and who sets their definitions?" Why it lands: links to KPI ownership and shows you will ask about definitions before you own them.
5. "What did the last live event that missed its target teach the team?" Why it lands: invites candour and shows you care about how the post-event review is used.
6. "How are the four teams' updates scheduled against each other?" Why it lands: shows you already see the coordination problem the posting describes.

## Sources

Provided documents: the job description and your background, both in your message. No CV was supplied.

Searches attempted in this session. Each one was refused because web search permission was not granted; none returned a result, and none was retried.
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- "Saltmarsh Games mobile studio news": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read: none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section dropped. Its search was refused. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. The pack assumes a generic hiring-manager round, and no loop source establishes it. Persona weights rest on that assumption. |
| 3. Saltmarsh Games strategy and news | unavailable | Grounding brief and CO questions. Their search was refused. The pack has no company facts, so every company-specific line is labeled generic. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read dropped. Reverse questions are role-generic. Its search was refused. |
| 5. Representative Live Operations Producer JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

Nothing in this pack about Saltmarsh Games is sourced from outside your message. Every company-level statement is generic.

Sections not included, and why: prep triage (no prep time was stated), graded deliverables (none declared), grounding brief (no research), interviewer read (no public information), values cheat sheet (no values-style round detected), delivery coaching (no assessment provided).

## Upgrade menu

- A web search permission grant, and I will re-run the four searches → company values, the interview loop and the interviewer's public footprint, which would set the persona weights and tailor a reverse question
- Tobias's public talks or posts, pasted → recurring themes to rehearse, and a reverse question tied to his path
- The recruiter's note on the round's format (one conversation or a panel, and whether a case or presentation is set) → coverage of any announced deliverable, and loop structure
- A real example of coordinating across teams on an update → F2 and S3 become grounded, and S5's answer slot gets a story
- What the monthly retention numbers measured, in your words → P1 and P2 get firmer ground and the weakest-assumption slot becomes an answer you can give
- A deeper research pass, up to 6 more searches and 2 more fetches, several minutes → a strategy brief for the CO and differentiator questions
- A tuesday-dossier.md file, if you carry this pack into later sessions → the gaps this prep exposed, carried forward
