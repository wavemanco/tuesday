Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-2-rooms-case-3-denied-257c78ec/d293cf0c-b06c-43ef-b727-3a5e2ee55b0d/scratchpad/stripe_product-operations-manager_interview_pack.md`. I built it without your CV, the job description, or any Stripe research, because the web searches were refused in this run. Every requirement and question is a general Product Operations pattern, not a fact about Stripe. The fit snapshot is a worksheet until I have your CV.

The pack has 20 questions across seven personas, a requirement-coverage table, reverse questions, and a sources section. The highest-ROI prep is D1, "Which part of this role would you be weakest at on day one?" Most final rounds ask some form of it.

Three things would sharpen it:
- **Who you're meeting and what kind of round it is** (hiring manager, peer, cross-functional, or panel), plus any focus areas or prep notes from the recruiter.
- **Your CV and the job posting**, pasted here. Then the worksheet rows become quoted evidence and the question guidance can use your real stories.
- **Work location and work authorization** for the role. I couldn't tell from what you've shared whether this is a gate.

Once you've answered, I can also run a live drill: say the word and I'll play the Skeptic on D1. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions. And if you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

**Role:** Product Operations Manager. **Company:** Stripe. **Interviewer:** not given. **Round:** final round; relationship to the interviewer not given, so persona weights are flat and marked as such.

**Built without:** a CV, a job description, a named interviewer and web research (both search calls were refused in this run). Every requirement below is role-family pattern, labeled `[generic]`. Nothing here is a fact about Stripe.

## How to use

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only the things you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral: past behavior, judged on the behavior |
| EXP | Experience: what you actually did, and how far it reaches |
| JD | Role: can you do the listed job, gaps included |
| CO | Company: strategy and context (none in this pack; no research ran) |
| CASE | Live problem: structure and reasoning on a problem from the role |

## Fit snapshot (worksheet variant)

No CV or JD was supplied, so every evidence cell is `none given`. Each row's bridge is what to bring once you send your CV: an answer slot, not a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a recurring operating cadence, such as planning or business reviews (role-family pattern) | none given | none | [generic] | discovery | Answer slot: if you have run a recurring review or planning cycle, say what it covered and which parts were yours to set. If you have not, say so plainly and describe how you would set one up. |
| F2 | Align engineering, finance and go-to-market teams on shared priorities (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name one cross-functional decision you moved, the teams involved, and your part in it. If none, say so and describe how you would get agreement. |
| F3 | Build metrics and decision-ready dashboards for leadership (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name one metric you reported, how it was counted, and what it was sensitive to. If you have not reported one, say so and say what you would measure first. |
| F4 | Plan and run a launch of a process or tooling change (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name one launch you were part of, your role, and how you knew it worked. If none, say so and describe your approach. |
| F5 | Prioritize an intake queue and make trade-offs explicit (role-family pattern) | none given | none | [generic] | discovery | Answer slot: say how you decided what waited when the queue was full, or say you have not run one and describe the criteria you would use. |
| F6 | Write clear memos and documentation for executives (role-family pattern) | none given | none | [generic] | discovery | No question covers this yet. Send a writing sample or name a document you wrote and it becomes a bridge. |
| G1 | Work location and work authorization for the role (posting not supplied) | none given | none | [generic] | hard_gate | Your material does not establish this, because no posting was supplied. The gate is asked in the message, not bridged here. |

## Graded deliverables

Not included: no deliverable was declared by the recruiter.

## Prohibited claims

No candidate sentences exist yet, so no inflated-form entry can be built from your own wording. These entries are built locally from the usual pressure pattern for this role. The honest form of each is the limit stated plainly.

| Not coached | Basis | Honest form |
|---|---|---|
| A metric or outcome you cannot explain the counting of | Generic prober pattern for this role | "I don't know exactly how it was counted. Here is what I can say about it." |
| Knowledge of Stripe's internal metrics, roadmap or team structure | No research ran, so nothing about Stripe is sourced | "I haven't seen internal data. Here is how I would learn it in the first month." |
| Ownership of a process you only observed | Generic pattern: "ran" and "watched" get confused under pressure | Say what your role in it was, in those words. |

## Persona table

Relationship is unknown, so the weights are flat within a final-round pattern and the archetype is generic. Reasoning is a pattern, not a fact about this loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the operating work of the role | Top weight. A live problem is a common final-round format, a general pattern and not a fact about Stripe | Clarify, state the objective, segment, then approach and metrics. Think aloud. |
| Peer Evaluator | Seam questions between teams, credit, disagreement | High. Peers in final rounds test how the hire adds to their load | Offer principles for the seam rather than pretending to know it. |
| Data-Driven Prober | Asks how a number was counted and which assumption you would defend least | High. Operations roles are measured on metrics, so probes follow them | Name your weakest assumption before they do. Say plainly when you do not know. |
| Skeptic | Quiet probing of gaps: why this role, weakest area on day one | High. Every final candidate faces this, and it is the likeliest objection | Name the weakest area, then the ramp plan. Claim no experience you have not stated. |
| Values / Behavioral | Scenario and STAR-style prompts | Mid. No Stripe values were read, so themes are generic behavioral stems, not company values | Choose a story where the hard truth landed. Say "we" for context and "I" for your part. |
| Pressure / Stress | Interrupts, time-boxes, questions motives | Lower. Likely in a skip-level or executive final, which the role may or may not have | Hold the position through two follow-ups, then concede only what is true. |
| Conversational / Rapport | Casual openers and "walk me through the journey" | Lower, but the casual question is still scored | Have a 90-second arc ready. Never answer the reverse-question slot with "I think you've covered everything." |

## Question banks

Provenance is `[generic]` throughout, since no candidate sentence is in the material. A question's guidance rests on nothing about you, so no candidate sentence is quoted.

### Case / Strategist (weight: top, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch of a new internal process is behind schedule two weeks before go-live. Walk me through what you do." | CASE | [generic] | Clarify what slipped and why. State the objective (go-live quality or date). Segment the blockers, pick the one that moves the date, name the decision you would ask for. Answer slot: if you have handled a slipped launch, say what slipped and what you did; if not, say so and walk the plan. | Tests F4 and F1. Most likely live problem for an operations role. |
| A2 | "A team's review backlog has doubled this quarter. How would you diagnose it?" | CASE | [generic] | Clarify whether the backlog is volume, cycle time or staffing. Segment by team and request type. Propose one test before changing anything. | Tests F5 under a live problem. |
| A3 | "Sketch the first 90 days of an operating cadence for a team that has none." | JD | [generic] | Start with what decisions the cadence must support, then the review rhythm, then the owners. Answer slot: if you have set up a cadence, say which parts you set. If not, say so and give the sequence. | Tests F1 directly. |
| A4 | "What would you need to know before proposing a change to how a team plans its work?" | CASE | [generic] | List what to learn first: current plan, who is affected, what has been tried. Name the decision that would make the change worth doing. | Shows whether you ask before you structure. |

### Peer Evaluator (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns the decision and how disagreements are escalated. Do not claim to know their seam. | Tests F2 in collegial form. |
| B2 | "How do you handle credit when a process change spans several teams?" | VAL | [generic] | Name the shared outcome, then the people who did the work. Say how you record contributions. | Tests cross-team credit, a common peer probe. |
| B3 | "What would you need from my team in the first month?" | JD | [generic] | Name two or three concrete inputs and why each one matters. Ask for them, not for a favour. | Tests reciprocity in the peer's own terms. |

### Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you reported. Walk me through how it was counted." | EXP | [generic] | Name the metric and the definition. Say what was counted and what was excluded. Answer slot: if you reported one, say how it was counted in your own words. If you did not, say so and describe what you would count first. | Tests F3. Prober's first move. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before they do, and say how you would test it. If you do not know, say so plainly. | The defend-the-number move. |
| C3 | "What is the smallest version of the data you would need before trusting a dashboard?" | JD | [generic] | List the source, the refresh, the owner and one check against a known figure. | Tests F3 without asking about a figure you did not give. |

### Skeptic (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name the weakest area without hedging. Then give the ramp plan: who you would ask, what you would read, what you would deliver by day 30. Do not claim adjacent experience you have not stated. | Almost every final round asks some form of this, and the honest answer is the one that survives it. |
| D2 | "Why this role, and why now?" | JD | [generic] | Tie the answer to the work in the posting, in terms you can defend. Keep the motive to what you actually want to do. | Motivation consistency is scored in every final. |
| D3 | "Tell me about a process you tried to change that did not stick. Why?" | VAL | [generic] | Pick a real instance. Name the cause as you saw it, what you would do differently, and what changed afterwards. If you have none, say so and give the nearest case. | Open prompt on a failed change, the likeliest Skeptic follow-up to F4. |

### Values / Behavioral (weight: mid, 3 questions)

No Stripe values were read, so these are generic behavioral stems, not company-value questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the truth actually landed. Say "we" for context and "I" for what you did. Answer slot: if you have such a story, tell it; if not, say so and give the nearest one. | Standard behavioral stem. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Name the metric, the customer, and the trade-off. Say what you gave up and what you kept. | Standard stem for operators who report metrics. |
| E3 | "Tell me about a decision you made with incomplete information." | VAL | [generic] | Say what you knew, what you did not, the decision, and how you would check it. | Open prompt on judgment under uncertainty. |

### Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Answer in three parts: what you bring, what you have not done, and why you would be the better hire. Hold the first point through two follow-ups. Concede only what is true. | Tests composure under time pressure. |
| F2 | "Pick the result you are most proud of. How much of it was actually you?" | EXP | [generic] | Name the result, your part, and the others' parts, in that order. Hold your part through two follow-ups. | Attribution under challenge. |

### Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | VAL | [generic] | A 90-second arc: where you started, what you learned, what brought you here. | Casual openers are scored. |
| G2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name one tool you use, what you do with it, and what you would change. Keep it specific. | Casual question on a likely JD topic. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 operating cadence | A3, A4 | |
| F2 cross-functional alignment | B1, B2, B3 | |
| F3 metrics and dashboards | C1, C2, C3 | |
| F4 launch management | A1 | |
| F5 intake queue trade-offs | A2 | |
| F6 executive writing | none, and why | No written artifact is named in the material; the upgrade menu asks for one |
| G1 location and authorization | none, and why | A gate, asked in the message rather than in a bank |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for this role?" | Shows you plan the work, not just the title. |
| R2 | "Which operating decision is the team working through this quarter that you would most want help with?" | Ties your question to live work. |
| R3 | "How does this role split between building processes and running them?" | Names a real trade-off and shows you have thought about the role's shape. |
| R4 | "What have the last few people in this role struggled with?" | Gets candid context on the role's hard part. |
| R5 | "How is success for this role measured, and by whom?" | Shows you want the measure before the work. |

If the round turns out to be a peer conversation, add one reciprocity question: "What could a new person do in their first month that would genuinely help your team?"

## Sources

- Provided documents: none, beyond the request itself.
- Web searches sent in this run: `Stripe company values operating principles` (refused), `Stripe interview process product operations manager final round` (refused). Both refused means no results: the values and loop targets are unestablished.

**Research tier: L1, searches 2 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Refused, so not detected and not used. |
| 2. `Stripe interview process product operations` | unavailable | Loop structure and persona weights. Refused, so the archetype is generic and flat. |
| 3. `Stripe strategy` / recent news | unavailable | Would have moved the CO bank. No call sent: the search was not run in this host. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | unavailable | Would have set the requirement list. No call sent; search was refused for the other targets. |

## Upgrade menu

- Your CV → rows F1 to F5 move from `none given` to quoted evidence, and bank C1 and E1 get story maps.
- Your JD text → six `[generic]` rows become `[grounded]`, and G1 becomes sourced.
- The round type and your relationship to the interviewer → persona weights and the reverse questions are recomputed. Right now they are flat.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- The recruiter's prep email → any focus areas or deliverables the round will test.
- Web search allowed, if you want to retry → Stripe's published values and interview-process pages would add the values cheat sheet and a loop-based persona weighting.
- Prep time available → a prioritized schedule (section 3).
- A `tuesday-dossier.md` from an earlier session → verified evidence and the objections already found, which would sharpen D1 and the prohibited list.
