Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and to "you deposit the cheque and send the balance on to the vendor". Requests like these are a known scam pattern. A fee before an interview, and a cheque you deposit and then pay the balance from, are very likely a scam, and I'd treat this job as very likely a scam until it's checked. Hold the fee, the cheque, and your passport and bank details. Check the invite with the company through contact details from its own website or careers page, not through the invite or the address it came from. The contact address ends in ".example", which real companies don't use for email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed as a separate request, job-underwriter can check it.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-12-denied-0d417e03/7dd5cea8-f08f-49df-a746-f0695b529505/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager.

What to expect: questions on whether a reception background fits calendar work, what you'd be weakest at (travel booking, Excel, invoices), and what you did with Word. Expect a short scenario too. Your strongest material is the appointment book for four physios and the unpaid invoices you chased. The gaps are travel booking, supplier invoices, and Excel. Don't claim experience you haven't had. Say what you did and where your answer stops.

Say the word and I'll run a drill on A2, the question about which part you'd be weakest at. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full ad text, so the requirements can be quoted from the ad itself?

Is the role fully remote, and what hours does it need?

Did you apply through a job board or the company's own careers page?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: first-round 30-minute video call. Built for that round, since the invite names no other stage.
First version, so no changelog.

## How to use

Personas describe how a question will be asked. Types describe what it scores:

- **VAL**: values or behavioural alignment
- **EXP**: your experience, and whether your account of it holds up
- **JD**: the role's listed duties
- **CO**: company knowledge (none built; no company material was attributable)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements come from the ad as you summarised it in your message, so they are your words, not the ad's. Quotes from your message are your sentences, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says a clinic's appointment book, for four physios. Say it in those terms: "For two years I ran the appointment book for four physios." Do not add tools or scale you did not state. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and say how you would learn the process. |
| F3 | "preparing documents in Word" (your message) | "I'm good with Word" (your message) | medium | [grounded] | presentation | Your words: "I'm good with Word." Answer slot: if you can name a document you produced in Word and who used it, say so; if none comes to mind, say so and give the nearest thing you did. |
| F4 | "preparing documents in Excel" (your message) | "okay with Excel" (your message) | low | [inferred] | discovery | Your material gives only "okay with Excel", and the bridge should not be stretched. Answer slot: if you built or checked anything in Excel, say what it did and whether the figures were yours to check; if you used it only for lists, say that and what you would need to learn. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Your material shows chasing payment, not processing supplier invoices. Say it at its own scope: "At the clinic I chased unpaid invoices." Answer slot: if you ever logged, checked or paid an invoice, say what; if not, say so, and say which part of invoice work you already know. |
| F6 | Remote working, as the invite describes the role | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely from where you are, or what hours the role needs. Surfaced, not bridged. |

Gap types were chosen by the routing rule in the output template: F1, F3 and F5 each have a quote that reaches the requirement in other terms or at its own scope. F2 and F6 have no quote at all. F4 is a vague quote, so it is discovery and its provenance is inferred.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed calendars for executives | Inflated form of F1 | F1's quote at its own scope. Your material says the appointment book for four physios. |
| Has processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." The limit is this pack's observation: your material shows chasing payment, not processing invoices. |
| Is strong in Excel | Inflated form of F4 | "I'm okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why should we trust you with this?" | High. The ad is admin work and your background is reception, so the gap is the first thing an office manager will test. | Rehearse the single most likely objection until it is boring: your appointment-book work is the bridge, and you say what it covered. |
| Case / Strategist | A live admin scenario: a changed flight, a duplicate invoice | Medium. An office manager often gives a small scenario. | Clarify first, then go step by step, and say what you would check before acting. |
| Conversational | A friendly opener, a "walk me through your journey" | High. It is usually the first thing asked. | Keep a 90-second version of your path ready. Treat the casual questions as scored. |
| Data-Driven Prober | "What did you actually do in Word and Excel?" | Medium. A short call leaves little room for it. | Name the specific thing you did, and say plainly where your answer stops. |

Depth follows weight: the Skeptic gets the most questions, then the Case persona, then the others.

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've mostly worked as a receptionist. Why should we trust you with calendars for several people?" | JD | [grounded] "ran the appointment book for four physios" (your message) | Story-mapped on F1: the appointment book for four physios, and the two years, in your own words. Answer slot: if you set any rule for how the book ran, say which and how you decided; if the physios set the rules, say so plainly. | F1 is the calendar requirement, and the likeliest place to be pressed. |
| A2 | "Which of these would you be weakest at on day one: travel booking, Excel or invoices?" | JD | [grounded] "okay with Excel", "chased unpaid invoices" (your message) | Name the weakest one using your own words for each: "okay with Excel" and "chased unpaid invoices". Answer slot: for travel booking, if you have done it, say how; if not, say so plainly and say how you would learn it. Do not claim travel experience. | The skeptic's favourite question. Your answer should name a real weakness and a plan, not bluff. |
| A3 | "How much of the appointment system was your decision, and how much was theirs?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Answer with what you ran and who set the rules. This is the attribution probe: say what was yours, and what was not. | Probes whether F1's "ran" is the same as "set". |
| A4 | "You've worked in a clinic, not in an office with a finance function. What makes you think you can handle invoices here?" | JD | [grounded] "chased unpaid invoices" (your message) | Hold: "I chased unpaid invoices, so I know how payment chasing works." Hold through two follow-ups. Concede specifically: "I'd need to learn how supplier invoices are processed here." | Pressure version of F5's gap. The hold is only what you said. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The office manager asks you to book a three-person trip for next Tuesday, and the flight changes. What do you do first?" | CASE | [generic] | Structure it: check the travellers' details and the booking rules, check the change terms, tell the travellers, and record what was done. Say what you would confirm before paying anything. | A live problem from the travel requirement (F2). It needs no claim about your past. |
| B2 | "Two supplier invoices arrive for the same job, and one looks like a duplicate. What do you do?" | CASE | [generic] | Structure it: compare the invoices, check with whoever approves them, do not pay until it is resolved, and record the decision. | A live problem from the invoice requirement (F5). |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, the appointment book, the invoices you chased, and why you are applying for admin work. Answer slot: give your own reason for moving, in your words. | An opener that is scored. F1 and F5 are the content. |
| C2 | "What are you most looking forward to learning in this job?" | JD | [generic] | Pick one thing from the ad's list (calendars, travel, Word and Excel, invoices) and say why, in your own words. | Shows you read the ad. It makes no claim about your past. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What have you built in Word that someone else relied on?" | EXP | [grounded] "I'm good with Word" (your message) | Answer slot: name one document and who used it. If none comes to mind, say so plainly, then give the nearest thing you did. | F3 is where a probe would land. |
| D2 | "What can you do in Excel without looking anything up?" | EXP | [inferred] "okay with Excel" (your message) | Answer slot: name what you can do, and say which things you would need to look up. Do not describe skills you have not stated. | F4 is vague, so the honest answer is the limit. |

## Reverse questions

Ask at least five. Each has a reason it lands.

1. "What does a normal week look like for whoever takes this role?" Why it lands: it shows you are planning for the job, not the pitch.
2. "How is the work split between calendars, travel and invoices in the first three months?" Why it lands: it maps your four requirements onto the job.
3. "Is this first call the only stage before a decision, or is there another step?" Why it lands: it asks about the process, which you need for prep.
4. "Which tools does the team use for calendars, travel and invoices?" Why it lands: it lets you prepare for the closest tool you have used.
5. "How does the team keep in touch day to day when someone works remotely?" Why it lands: it speaks to F6 and shows you have thought about remote work.

## Sources

- Provided documents: your message, which contains the invite's text and your summary of the ad. The ad itself was not supplied in full.
- Search for reports of recruitment scams that use this company's name: refused (permission not granted in this session). No other search or fetch was sent.

Research tier: L1, searches 0 of 6 (1 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Would have set the values section; none was built because no values round is detected. |
| 2. company interview process | unavailable | Would have confirmed the loop; the pack uses the stated first-round format and a persona fallback. |
| 3. company strategy / recent news | unavailable | Would have fed CO questions; none were built. |
| 4. interviewer name | n/a | No name was given. |
| 5. representative role JD | unavailable | Would have filled the requirements where the ad summary is thin. |

## Upgrade menu

- The full ad text → requirements quoted from the ad itself, and the requirement rows in the fit snapshot become firmer.
- Whether the role is fully remote, and what hours it needs → confirms or clears F6.
- The interviewer's name → persona weights and a tailored reverse question.
- Research at the default tier, once permission is granted → values, loop structure and company material, all from the company's own pages.
