Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-5/rooms/case-9-canned-45b7311d/Halvering_fourth-grade-teacher_interview_pack.md. I built it for a panel round, with the principal and two fourth-grade team members weighted as a blend.

Two things to check first:

- **The date.** "Thursday" could mean tomorrow, 26 November, which is Thanksgiving. Confirm the date with HR.
- **Your Social Security number.** You don't need it for interview prep, so I haven't used it and it isn't in the pack. Keep it off your resume and any application materials you send to the district.

The pack's main points:

- **The gaps.** You've never taught fourth grade and you've never been a team lead. The principal is most likely to press the fourth-grade gap, so that's the question with the deepest rehearsal (B1). The rehearsal is to hold on your six years in third grade, then concede plainly that you haven't taught fourth grade. Don't claim any fourth-grade experience under follow-up.
- **The license.** Your PEL's elementary endorsement covers grades 1–6, so it covers fourth grade. Confirm it's active on the state's educator license lookup before the panel.
- **Your strongest material.** The 2024 reading curriculum move and the reading club are your best examples. The pack keeps each claim at the scope of your own sentence, so you won't be coached to say you designed the curriculum or that the club raised scores.
- **The principal.** A public forum profile says she has been principal since 2022, was a reading specialist before that, and gave a 2025 talk on weekly reading conferences in grades 3 to 5. Expect reading-focused questions, and use the reverse question about those conferences only if you've read the talk.
- **Research.** I searched briefly. I found no public values page for the school. The district's careers page says teacher panels are 45 minutes and ask about reading instruction, classroom routines and working with families. Those topics shape the question banks.

Two questions would sharpen the pack:

1. Did HR say what the panel will focus on, or ask you to bring anything, such as a sample lesson?
2. Do you have the full job posting? If so, paste it, and I'll replace the invite-level requirements with quoted posting text.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Format:** 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given).
**Date:** "Thursday" in the invite. Thursday, 26 November 2026 is Thanksgiving, so confirm the date with HR.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values and behavior), EXP (your experience, probed), JD (the role itself), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse it aloud, in your own words.
- Every quote in the pack comes from your CV or your message, or from the invite or the public sources listed in Section 11.

## 2. Fit snapshot

Requirements come from the invite (quoted) or from what you raised yourself. No full job posting was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Fourth Grade Teacher position" (invite, HR) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Words: "I've taught third grade for six years at a public elementary school in Joliet." That is adjacent work, not fourth grade. Answer slot: expect a probe on how grade four differs from grade three. If you have studied the fourth-grade year, say what you know. If you have not, say so and say how you would learn it. |
| F2 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite, HR) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met as stated. The grades 1–6 endorsement covers grade four. Say it once. Confirm the active status on the state educator license lookup before the panel, since the CV is the only evidence here. |
| F3 | "two members of our fourth-grade team" (invite, HR) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | Words: "I led our grade level's move to a new reading curriculum in 2024." That is the nearest evidence of working with a grade team. Add nothing to it: no outcomes, no reactions, no roles you did not state. |
| F4 | Team lead (your message, a gap you raised; not an invite requirement) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Then how you would contribute to a team without a formal lead role, said as a plan and never as a past. |
| F5 | Reading instruction (role-family, not in the invite) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Words: "For the last two years I've run the after-school reading club." |
| F6 | Family communication (role-family, not in the invite) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Words: "I write a weekly email to families." That already says what the requirement asks. |

## 3. Prohibited claims

Each entry names its basis. Nothing in the banks below asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated: "I've never taught fourth grade" (your message) | Plain acknowledgment: "I've never taught fourth grade." No answer slot. |
| Having been a team lead | Negative you stated: "I've never been a team lead" (your message) | Plain acknowledgment: "I haven't been a team lead." |
| Leading the grade team, or leading the grade level as a whole | Inflated form of F3: "I led our grade level's move to a new reading curriculum in 2024" | F3's quote at its own scope. The limit is my observation, not words for you: your material says you led one move, not the grade level. |
| Designing the reading curriculum | Inflated form of F3: your material says you led the move, not that you designed the curriculum | F3's quote at its own scope. |
| The reading club improved test scores | Outcome not in your material | None. If asked, answer from what you actually observed, in your own words. |

## 4. Persona weights

The panel is blended from the relationship priors in the persona model. Principal and team members are weighted separately below.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | Both team members | Collegial questions about shared planning, seams between teams, credit | Highest, because two of three panelists are peers on the grade team and the team's day-to-day matters most | Reciprocity: say what you would ask of the team and what you would contribute. Propose principles, not claims about how they work. |
| Skeptic | Principal | "Why you, for a grade you have never taught?" and "Have you led anyone?" | High. The two gaps (F1 and F4) are the most predictable objections. | Hold on the third-grade years, then concede the gap plainly. |
| Values / Behavioral | Principal | Scenario questions about student needs, hard truths, changing your mind | High for the principal. Her published work is on reading conferences, so expect a reading-focused version. | STAR-shaped stories; choose a true example and say when none exists. |
| Data-Driven Prober | Team members | "How would you know it worked?" and "What did you track?" | Moderate. Your CV has no figures, so the probe will be about method, not numbers. | Say what you can show and what you cannot. Do not invent a measure. |
| Conversational | Either team member, as an opener | "Walk me through your journey." | Moderate. Casual openers are still scored. | Keep a 90-second arc ready. |

Depth follows weight: Peer Evaluator 5 questions, Skeptic 4, Values 4, Prober 3, Conversational 2.

## 5. Question banks

Types: VAL, EXP, JD, CO, CASE.

### A. Peer Evaluator (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our grade-four team plans together. What would you need from us in your first month?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name one thing you would ask the team for, and one thing you would contribute. Use the curriculum move as your example of working with a grade team, in your own words. Answer slot: if decisions in that move were shared with colleagues, say how, and whose they were. If not, say so and stay with what you did. | Reciprocity question, which the peer persona calls for. F3 is the nearest evidence. |
| A2 | "When you and a colleague see a student's needs differently, what do you do?" | VAL | [generic] | Open prompt: pick a time you disagreed with a colleague about a student or a plan, and one that got resolved. Answer slot: if the 2024 move involved a disagreement, say how it was handled. If it did not, say so and give the nearest true case. | Peer persona. Generic: no claim about your past. |
| A3 | "How do you handle credit when a plan you helped build gets used by the whole team?" | VAL | [generic] | Say who built what, in those words. Answer slot: if a shared plan of yours was used by others, say whose it was and what you contributed. If none exists, say how you would credit a team's work. | Peer persona's credit-sharing probe. |
| A4 | "Walk me through the reading curriculum move you led in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped on F3: the move, the grade level and the year are the beats the quote states. Tell it in your own words. Answer slot: name each decision in the move that was yours, and each that was the team's or the school's. If a part was not yours to set, say so plainly. | Premised on F3's own quote. The most likely probe on credit. |
| A5 | "What does a fourth grader need from a reading block that a third grader does not?" | JD | [generic] | No claim about your past. Answer from what you know of the grade's reading demands, then say how you would check your view against the team's practice. | Reading is the centre of the invite's panel topics (see Section 11). |

### B. Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade for six years. Why should we trust you with fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); [grounded] "I've never taught fourth grade" (your message) | **Highest-ROI prep in this pack.** Hold: return to the six years in third grade, in your words, for two follow-ups. Concede: "I've never taught fourth grade." Then a plan, not a past: how you would learn the fourth-grade year in your first month. Do not claim fourth-grade experience under any follow-up. | F1 is the gap the principal is most likely to press, and the panel will ask it in some form. |
| B2 | "You haven't been a team lead. What would you do on a grade team with no formal lead?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold on the curriculum move at its own scope. Concede: "I haven't been a team lead." Then a plan for contributing without a title. | F4 is the stated gap. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the fourth-grade year itself, which is F1's gap. Say it plainly, then the plan. Do not bluff. | Skeptic persona's day-one probe. |
| B4 | "Why are you leaving third grade, and why this school?" | EXP | [generic] | Give your reason in your own words. Answer slot: the material does not state a reason for leaving, so say it yourself. Name one thing about this school that is true for you, drawn from the public sources in Section 11 only if you read them. | Motivation-consistency check. |

### C. Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to a leader." | VAL | [generic] | Open prompt. Pick a time you raised a concern and it was heard. Answer slot: if you raised a concern about the 2024 move, say what and when. If you did not, say so and give the nearest true case. | Persona stem for the values round. |
| C2 | "Tell me about a time a student's need changed what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Story-mapped on F5: the club and its two years are the beats the quote states. Answer slot: a specific time a student's need changed what you did in the club. If there is none, say the club is the example and say what it is for. | Reading-club evidence is your strongest student-facing material. |
| C3 | "How do you keep families informed about what happens in class?" | VAL | [grounded] "I write a weekly email to families" (your CV) | Story-mapped on F6: weekly, to families. Answer slot: an example of a family who responded, if there is one. If not, say what the email is for. | Family communication is a panel topic in the public sources (Section 11). |
| C4 | "Describe a time you changed your mind after seeing evidence." | VAL | [generic] | Selection scaffold: pick a time student work changed how you taught something. If none comes to mind, say so plainly, then give the nearest thing your material carries. | Values probe about learning from evidence. |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you know whether a reading curriculum move was working? What did you track for yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you tracked anything, say what and how. If you did not, say so and say what you would track. Do not name a measure you did not use. | Premised on F3. Probes method, not figures. |
| D2 | "Which students attend the reading club, and how do you know it helps them?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: name what you observed about the club and how you observed it. If you did not record it, say so. | Likely probe on the club's effect. |
| D3 | "If someone asked whether the 2024 move worked, what could you show and what could you not?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you can show and what you cannot, in those words. No figures unless you have them. | Weakest-assumption move, without a figure to defend. |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to teaching." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: the license (F2), six years of third grade (F1), the curriculum move (F3), the club (F5). Stop there. | Opener. Casual questions are still scored. |
| E2 | "What are you playing with in reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: name what you have actually tried in the club. If nothing recent, say so and name one thing you would test. | Reading is the principal's focus in the public sources. |

## 6. Reverse questions

Each one has a reason it lands.

1. "What does a strong first semester look like for a new fourth-grade teacher here?" Lands because it shows you are planning to be measured by their bar.
2. "How does the grade-four team plan reading instruction together?" Lands because it asks about the team you would join, which is the peer panel's own territory.
3. "What would you most like a new teacher to bring to the team?" Reciprocity question for the peer members. Lands because it turns the interview into a planning conversation.
4. "The weekly reading conferences you talked about in grades 3 to 5: how do they work in grade four?" Lands because it draws on the principal's public talk (Section 11) and shows you read it. Use it only if you have read the talk.
5. "What has the team changed in the last year, and what is still open?" Lands because it shows you expect the team to be in motion.

## 7. Interviewer read

Public footprint only (Section 11).

- **Principal Dolores Vantongeren:** principal since 2022, after nine years as a reading specialist. A 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5.
- **Implications:** expect reading questions from her, and expect her to test the reading examples in your answers. Your reading club and your curriculum move are a shared professional path in reading. That is fair game. It is not a shared identity, so do not build on anything personal.
- **The two team members:** no public footprint was found, so they are not profiled. Their personas follow the peer prior.

## 8. Requirement coverage

| Requirement (source) | Questions | Note |
|---|---|---|
| Fourth Grade Teacher position (invite) | B1, B3, E1, A5 | |
| Valid PEL with elementary endorsement (invite) | None, and why: the gate is met as stated in F2. A gate the material shows met asks nothing. | |
| Two members of the fourth-grade team (invite) | A1, A2, A3, A4, D1 | |
| Team lead (your own gap, F4) | B2 | |
| Reading instruction (role-family) | E2, C2, D2, A5 | |
| Family communication (role-family) | C3 | |

## 9. Values cheat sheet

Dropped. No published school values were found, and no values-style round was detected.

## 10. Delivery coaching

Dropped. No working-style assessment was provided.

## 11. Sources

**Provided documents:** the invite, and your CV and message.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary values` | yes | The search returned no results for the school and district together. Values not established; nothing used. |
| 2. `Orrinsford Community School District teacher interview panel fourth grade` | yes | Found the district's careers page snippet: teacher hiring is one 45-minute building panel (principal and two grade-level teachers), asking about reading instruction, classroom routines and working with families, with references taken after the panel. This confirmed the loop structure and the topics in B and E. |
| 3. `Orrinsford Community School District strategy` / recent news | unavailable | Not searched; the budget went to the higher-priority targets. Would have moved the CO questions. |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | A forum speaker profile: principal since 2022, nine years as reading specialist, a 2025 talk on weekly reading conferences in grades 3 to 5. Moved the interviewer read and reverse question 4. |
| 5. Representative fourth-grade teacher JD | unavailable | Not searched; the invite serves as the requirement source. Would have added requirements to F-rows. |

Un-numbered: none.

Nothing was fetched.

## 12. Upgrade menu

- A full job posting, if you have it → the requirements become quoted text instead of invite-level, and more fit rows become grounded.
- The two team members' names, if you know them → their personas and the peer questions become specific.
- Anything HR said about the panel's focus, or anything they asked you to bring (a lesson plan, a sample) → graded deliverables section added.
- Permission to run a deeper public check on the district's values and strategy → CO questions and the values cheat sheet.
