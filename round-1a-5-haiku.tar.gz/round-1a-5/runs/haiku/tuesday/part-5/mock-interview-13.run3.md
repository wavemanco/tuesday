Your screen pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-5/rooms/case-13-denied-dc5374ca/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It is built from the advert and your message only: my one web search for Quillmoor was refused by the permission prompt, so the values and process sections are absent. The pack's main points:

- **Pay, notice, hybrid, reason:** each has a logistics answer in your own words, quoted from your message. Your £42,000 and your "two days at Avonmouth is fine, but I wouldn't want more than three" are quoted whole.
- **Biggest prep item (B2):** you have no production-planning or QA experience, and the advert asks for both. Rehearse the non-defensive answer until it is dull.
- **SAP:** say "I've never used SAP", then describe the in-house stock system in your own words. Don't claim ERP experience.
- **Excel and dispatch reporting:** your material shows a spreadsheet and deliveries, but not Excel or a weekly dispatch report. The pack has answer slots for both.
- **Defend the one-third figure:** be ready to say how the discrepancy count was done, which assumption you'd defend least, and which part was yours.

I took the request as a recruiter-screen prep pack. The pack has 15 questions, below the usual floor, because a 30-minute screen can't use more.

Offers, not run:
- A short mock drill with Hannah. Say the word and I'll start with her first question.
- A `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Question for you: **what is your notice period?** Hannah will ask it, and your material doesn't say. Give it in the units your contract uses, and I'll put your answer into the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the listed requirements), EXP (what you actually did), CASE (a live problem), and a logistics tag for pay, notice, location and the reason for leaving.
- Guidance is scaffolding, not a script. Say things in your own words, using only what you actually did.
- She told you the topics: salary expectations, notice period, how the hybrid pattern works for you, and what is prompting the move. Then she covers the team and next steps. Those four topics are the core of the call.

## Fit snapshot

Requirements are quoted from the advert or from Hannah's message. Your evidence is quoted from your message. Nothing outside those quotes is claimed about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Lead with the four years and the job title, in those words. Expect a probe on what the role covered. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and nothing about QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: say what the scheduling involved, in your own words. If you had any contact with planning, the warehouse or QA, say what it was; if you did not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. Lead with the supplier-chasing in those words. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The figure is yours and gets the defend-the-number slots (C1). Give the sentence as written. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none given | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you reported on delivery timings in any form, say what was counted and how often; if you did not, say so plainly and say how you would set one up. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material says a spreadsheet, not which software. Answer slot: name the tool you used and what you built in it; if it was not Excel, say which one. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | medium | [grounded] | transferability | The SAP part is a stated negative: "I've never used SAP." The in-house stock system is adjacent work, not an ERP claim. Say what it covers, in your own words. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own constraint, stated and confirmed. Quote it whole (B4 and A4). |
| F9 | "your salary expectations" (Hannah's message) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your own figure. Quote it whole (A5). No other figure, range or flexibility is in your material. |
| F10 | "your notice period" (Hannah's message) | none given | none given | [grounded] | hard_gate | Your material does not establish your notice period. Answer slot: give your actual notice period, in the units your contract uses. |
| F11 | "what's prompting a move" (Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own reason, stated. Quote it whole (A3). |
| F12 | Location: "Avonmouth site in Bristol" (advert) | "I live in north Bristol" (your message) | high | [grounded] | none | Your own fact. Quote it whole (A4). |

Confidence grades your evidence. Provenance grades this pack's statement. F10 is a term the material is silent on, so it is a hard_gate: surfaced, not bridged.

## Prohibited claims

Each entry names its basis and its honest form. None of these may be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Production-scheduling experience | Inflated form of F2: "deliveries" is not "production schedules" | F2's quote at its own scope. Pack's observation, not words for you: your material says deliveries for three depots. |
| Excel proficiency | Inflated form of F6: your material says a spreadsheet | F6's quote at its own scope. |
| Any use of SAP or an ERP | Negative you stated, F7 | "I've never used SAP." Then the in-house system, in your own words. |
| The one-third fall was all down to you | Inflated form of F4: the sentence states the fall, not its whole cause | F4's quote as written. C1 asks only what you were responsible for. |

## Question banks

Session persona weights: Conversational top (5 questions), Skeptic mid (4), Prober low (2), Pressure low (2), Case low (2). A recruiter screen is a short call, and the risk is treating it as unscored. Logistics questions are asked in a friendly register and still scored.

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener; pay, notice, hybrid and reason asked in turn | Top weight: recruiter screens are logistics in a chatty register | Use a 90-second arc from your own sentences; answer logistics in your own words |
| Skeptic | "This is a manufacturer; what is the transferable part?" | Mid weight: F2, F6 and F7 are the gaps the advert leaves open | Plain acknowledgment where you stated one; adjacent evidence only |
| Prober | "Walk me through how that third was counted" | Low weight for a screen; the figure is on your CV | Say how you counted, what it is sensitive to, and which part was yours |
| Pressure | "Sixty seconds: why you for a manufacturer?" | Low weight; a short challenge | Pause, restate, hold through two follow-ups, concede specifically |
| Case | A supplier slips; a dispatch report | Low weight; scenario questions from the advert | Clarify, then structure. No claim about your past |

**A. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc in your own words: four years, the three depots, the supplier chasing. Use only those beats. | F1, F2, F3 are the sentences this answer rests on. Opening arc. |
| A2 | "What's your notice period?" | JD (logistics) | [grounded] "your notice period" (Hannah's message). Your figure is not in your material. | Logistics slot. Give your actual notice period, in the units your contract uses. If it is not yet known, say so and say when you will know. | F10. Hannah's question; the one question this pack asks you (see upgrade menu). |
| A3 | "What's prompting the move?" | EXP (reason for leaving) | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot. Say it in those words. If asked about Reading, your own words were: "the only offer is relocating to Reading, which I don't want." | F11. Nothing here asks what you want next. |
| A4 | "How would two days a week at Avonmouth work for you?" | JD (location and hybrid) | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot. Your own words were: "two days at Avonmouth is fine, but I wouldn't want more than three." Do not add a commute plan. | F8 and F12. |
| A5 | "What are your salary expectations?" | JD (pay) | [grounded] "I'm hoping for £42,000" | Logistics slot. Quote your figure whole: "I'm hoping for £42,000." | F9. The advert's band is a fact about the role, not words for you to say. |

**B. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists ERP, SAP or similar, as a plus. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment: "I've never used SAP." Then: "We run our own in-house stock system," and what it covers, in your own words. Then how you would learn SAP, as a plan and not a past. | F7. A stated negative, so the plain acknowledgment is yours to give. |
| B2 (highest-ROI) | "This is a manufacturer with a QA function. Your background is deliveries for depots. What is the transferable part?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Hold: the transferable part is the scheduling and supplier-chasing, in those words. Answer slot: if you had any contact with planning, the warehouse or QA, say what it was; if you did not, say so plainly. Hold through two follow-ups by returning to deliveries. Concede that the manufacturing side is new to you. | F2 is the largest gap in this pack and the objection most likely to be asked in some form. Rehearse the non-defensive answer until it is dull. |
| B3 | "We report weekly on on-time dispatch. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you reported on delivery timings in any form, say what was counted and how often; if you did not, say so plainly and say how you would set one up. | F5. The advert raises the report; your material does not show it. |
| B4 | "You're hybrid in Avonmouth, two days a week. Is that workable?" | JD (location) | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot. Your own words, whole. | F8. The Skeptic checks that the constraint is real. |

**C. Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the discrepancies fell by about a third." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you measured it, say how; if you did not, say so plainly. | F4. The figure is yours and draws defend-the-number slots only. |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name it before they do. If you do not know, say so plainly. | F4. The weakest-assumption move. |

**D. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give production scheduling to someone whose background is deliveries?" | JD | [grounded] "I schedule deliveries for our three depots" | Pause. Restate the question. Hold through two follow-ups with your deliveries work. Concede specifically that production is new to you. Do not fold on the core claim. | F2. Pressure tests composure on the same gap. |
| D2 | "If the warehouse and QA disagree on the schedule, who decides?" | JD | none given | Answer slot: say what you would do first, and who you would ask. If you have dealt with a clash between two teams, say what happened and what part was yours. If not, say so and stay with the approach. | F2 and F5. The advert's scheduling line raises this. No claim about your past. |

**E. Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier's delivery for a production run slips two days. What do you do?" | CASE | [grounded] "track supplier deliveries and chase late orders" (advert) | Clarify: what is at stake for the run, and what stock is on hand. Then: contact the supplier, check the alternatives, tell planning. No claim about your past. | A live problem from the advert's supplier line. |
| E2 | "What would you put on a weekly on-time dispatch report?" | CASE | [grounded] "report weekly on on-time dispatch" (advert) | Structure it: dispatches on time against plan, late ones by cause, and who owns each. No claim about your past. | Live problem from the advert's reporting line. |

**Coverage of the advert's requirements**

| Requirement | Covered by |
|---|---|
| 2+ years operations or logistics coordination | A1, B2 |
| Production schedules across planning, warehouse and QA | B2, D1, D2 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, C2 |
| Weekly on-time dispatch reporting | B3, E2 |
| Confident with Excel | none, and why: the advert's Excel line is covered by F6 as a gap; add a question once you name the tool |
| ERP (SAP or similar), a plus | B1 |
| Pay (salary expectations) | A5 |
| Hybrid, Avonmouth | A4, B4 |
| Notice period | A2 |
| Reason for moving | A3 |

Session total: 15 questions. That is under the usual 18 floor because a 30-minute screen cannot use more. The floor is set for full loops.

## Reverse questions

Each has a "why it lands."

1. "What does success look like in this role at three months?" Why it lands: shows you are thinking about the job, not only the offer.
2. "When planning, the warehouse and QA disagree on a schedule, how is that usually settled?" Why it lands: ties to B2 and D2, and tests the seam you would sit in.
3. "Which stock or ERP system does the team use day to day?" Why it lands: tests the SAP gap and shows you want to learn the system.
4. "What does the weekly on-time dispatch report look like now, and who reads it?" Why it lands: shows you have read the advert's reporting line closely.
5. "On the hybrid pattern, which days does the team usually sit together at Avonmouth?" Why it lands: makes the two-day constraint a practical question.

## Sources

- Provided documents: the advert (quoted above), Hannah Lowther's LinkedIn message, and your message about your background and reasons.
- Research tier: L1 — searches 1 of 6, fetches 0 of 2; user links read 0. The one search was refused by the host's permission prompt, so no outside claim is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet. Not produced: the search was refused and no values page was pasted. |
| 2. Quillmoor Diagnostics interview process | unavailable | Loop structure. Hannah's message describes this call only. |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable | Grounding brief and CO questions. Not produced; the pack uses only the advert and your message. |
| 4. Interviewer name and Quillmoor | n/a | No interviewer name was given beyond the recruiter. |
| 5. Representative operations coordinator JD | skipped | The advert fixes the fit snapshot and the JD questions. |

Not produced: sections for graded deliverables, grounding brief, values cheat sheet, interviewer read and delivery coaching, since none of their conditions held.

## Upgrade menu

- Your notice period, as a figure → turns A2 and F10 from an answer slot into your own words.
- The Excel tool you used → upgrades F6 from discovery to grounded and rewrites B4 and the Excel coverage line.
- A dispatch report, or any delivery timings you tracked → upgrades F5 and B3 from discovery.
- Quillmoor's values or interview process, pasted → adds a values cheat sheet and grounds the loop.
