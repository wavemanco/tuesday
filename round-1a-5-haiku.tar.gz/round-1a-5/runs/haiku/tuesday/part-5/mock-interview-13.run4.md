Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-5/rooms/case-13-denied-9c2a6bd9/quillmoor_operations_coordinator_interview_pack.md. It's built for the recruiter screen with Hannah, using only the advert and your notes. The web search was refused, so there's no company research in it.

The pack's core is the four logistics answers, each in your own words:
- **Pay:** "I'm hoping for £42,000." Nothing added. Your figure sits inside the advertised £38,000–£44,000.
- **Hybrid:** "two days at Avonmouth is fine, but I wouldn't want more than three." This is the limit you set, so it doesn't need reopening.
- **Reason for leaving:** the Bristol office closing and the Reading-only offer, as you wrote it.
- **Notice period:** you didn't give one, so the pack doesn't supply a figure. If you tell me yours, I'll write it into the pack.

The highest-value prep is the production gap. The advert asks for production scheduling across planning, warehouse and QA. Your experience is delivery scheduling for three depots and chasing suppliers. Expect her to ask how you'd bridge that. The pack gives you an honest bridge and an answer for the case where you haven't touched production or QA at all. Rehearse that one most.

On SAP, the honest line is "I haven't used SAP." Don't describe your in-house stock system as ERP experience.

I didn't find any warning signs in the invite. A chat-scheduled call from a recruiter on your application's number is normal.

Would you like me to play Hannah for a short drill on the production question, with feedback after?

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). She will call the mobile number on the application.
**Candidate:** Sam (they/them)
**Built from:** the advert, Hannah's LinkedIn message, and Sam's notes. No web research ran (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your own experience), JD (the listed job), CO (company knowledge), CASE (a live problem).
- The guidance is scaffolding, not a script. Say the answers in your own words, and only the things you did.
- Every question below is tagged with where its guidance comes from. Grounded means it rests on a sentence you wrote. Inferred means it is a reasoned extension. Generic means a pattern for this kind of call, with no claim about you or Quillmoor.

## The fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your own messages and CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Your material gives four years in this exact role. Say it in those words; nothing needs adding. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling, and nothing about QA. Say the delivery work in those words. The planning, warehouse and QA side is an answer slot: if you have dealt with production planning or a QA hold, say how; if you have not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the requirement. Say what you chased, and when, in your own words. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Say the rebuild and the figure as you gave them. The figure raises the defend-the-number slot (A2 and C1): how it was counted, and which part was yours. |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [grounded] | discovery | Your material shows a spreadsheet rebuild. It does not show which Excel functions you use. Answer slot: name what you built and what you used it for, in your words. If you cannot name the functions, say so. |
| F6 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | Words: "I haven't used SAP." Then say how you would learn it, as a plan and never as a past. Do not describe your in-house stock system as ERP experience. |
| F7 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Gate met on your own stated limit. Say the limit in your words. |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Gate met: your figure sits inside the advertised band. Say your figure in your words, nothing added. |
| F9 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on dispatch timeliness, say what you reported and how often. If you have not, say so plainly and say how you would measure it. |

**Notes on this snapshot**

- F2 is the weakest fit: your material is distribution and delivery work, and the advert is production planning with QA. This is the likeliest objection (see the highest-ROI note below the banks).
- F6 is a stated gap, so it gets a plain acknowledgment, not a bridge.
- Your material does not establish the gaps in F5 and F9. The pack records that as an observation. The words for the call are the answer slots above.

## Prohibited claims

What this pack will not coach, and why. These are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2. The advert says production scheduling; your material says delivery scheduling | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is this pack's observation: your material shows deliveries, not production. |
| SAP or ERP experience, or familiarity with SAP | Negative you stated (F6) | Plain acknowledgment: "I haven't used SAP." No slot asks you to describe SAP work. |
| Managed or owned supplier relationships | Inflated form of "chase suppliers when orders slip" (F3) | The quote at its own scope: you chased suppliers when orders slipped. |
| Sole credit for the discrepancy drop | Inflated form of F4 | The quote with the figure as given: discrepancies fell by about a third over a year after the rebuild. |

Pay: this pack does not coach a range, floor, flexibility or current pay. Question A4 covers the one figure you gave.

## Persona table

Relationship prior for a recruiter screen: Conversational plus light Skeptic (`personas.md`). No interviewer profile exists and no loop source was found, so no adjustments apply.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Opens with your background, then runs the four logistics items in a friendly register | High: pay, notice, location and reason for leaving are this call's stated agenda | A 90-second opener; each logistics item answered in your words, the same as the one you gave Hannah |
| Skeptic (light) | "Your experience is deliveries and suppliers. How does that cover production and QA?" and "You have not used SAP" | Medium-high: F2 and F6 are the visible gaps for this advert | Rehearse the F2 bridge and the plain acknowledgment on F6 until they are boring |
| Data-Driven Prober | Asks how the "about a third" figure was counted | Medium: a figure on the CV is a probe target | Say what you know about the count, and say plainly what you do not know |
| Pressure / Stress | Not weighted for a recruiter screen | Low, per the relationship prior | Pause, restate the question, answer from what you stated |

## Question banks

Ordered by weight. Depth follows weight, and this is a 30-minute screen, so the bank is short on purpose.

### Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, starting with the last four years." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" — your message; "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | A 90-second arc in your words. Beats, in order: four years as a logistics coordinator; scheduling deliveries for three depots; chasing suppliers when orders slip. Stop there unless asked for more. | F1 and F2 are the opening evidence. An open prompt, so you choose the instance. |
| A2 | "Tell me about the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | Say what you rebuilt, what it tracks and what the change was, then the figure over the year as you gave it. Answer slot: how the figure was counted, what it depends on, and which part was yours. If you do not know how it was counted, say so. | F4 is your strongest accuracy claim, and the figure raises the defend-the-number slot. |
| A3 | "Which depots do you schedule deliveries for, and how does that work day to day?" | EXP | [grounded] "I schedule deliveries for our three depots" — your message | Name the three depots and describe the daily scheduling in your words. If someone else set the sequence, say so. | F2's own scope: delivery scheduling, described as you did it. |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." — your message | Logistics slot. Say it in your words: "I'm hoping for £42,000." Add nothing: no range, no flexibility, no reason. If asked about your current pay: "I'd rather focus on the range for this role." | The pay figure fills this slot (F8). No other bank challenges it. |
| A5 | "What is your notice period?" | JD | [generic] | Logistics slot, with no figure yet. Give your actual notice period as it stands in your contract. Do not estimate it. If you are not sure, say so and say when you will confirm. | Notice is not stated in your material, so the pack cannot supply it. |
| A6 | "Are you comfortable with the hybrid pattern, two days a week at Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" — your message | Logistics slot, already filled. Say it in your words. If asked about the commute, your own words were: "I live in north Bristol, so two days at Avonmouth is fine." | F7's gate is met on your stated limit. |
| A7 | "Why are you looking to move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | Logistics slot. Say the office closure and the Reading offer in your words. If asked what you want next, answer in your own words; your material says only that you do not want the Reading relocation. | The reason is yours and stated. Do not add reasons beyond it. |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our role is production scheduling across planning, the warehouse and QA. Your experience is deliveries and suppliers. How would you bridge that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | **Highest-ROI prep in this pack.** Hold the bridge at the quote's scope: you schedule deliveries and chase suppliers. Answer slot: if you have dealt with production planning or a QA hold, say how; if you have not, say so plainly and say what you would learn first. Hold through a second follow-up by returning to deliveries. | F2 is the biggest gap against the advert, and the likeliest objection. Rehearsing an honest bridge is what stops a non-answer. |
| B2 | "You list ERP as a plus. You haven't used SAP, have you?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." — your message | Plain acknowledgment: "I haven't used SAP." Then how you would learn it, as a plan. You can also say you run an in-house stock system. Do not call it ERP experience. | F6 is a stated gap, so the words are yours and the bridge is the learning plan. |
| B3 | "How confident are you with Excel? What do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" — your message | Name what you built, what it tracks and what you used it for, in your words. Answer slot: which Excel functions you used, if you can name them. If you cannot name them, say so. | F5 is discovery: your material does not show the level. |
| B4 | "Have you reported on on-time dispatch? How often, and to whom?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you have reported on dispatch timeliness, say what, how often and to whom. If not, say so plainly and say how you would measure it. | F9 is discovery: dispatch reporting is not in your material. |

### Data-Driven Prober (touch)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the discrepancy figure counted, and which part of the drop was yours?" | EXP | [grounded] "discrepancies fell by about a third over a year" — your message | Say how the figure was counted in your words. Name the assumption you would defend least. Say which part was yours and which was the year's activity. If you do not know how it was counted, say so. | F4 is the figure a prober will test; this is the defend-the-number slot in your own words. |

**Coverage check against the advert:** every requirement has at least one question: 2+ years (A1), production scheduling (B1), supplier deliveries and late orders (A1, B1), stock records (A2, C1), weekly dispatch reporting (B4), Excel (B3), ERP (B2), pay band (A4), hybrid Avonmouth (A6). The total is short of the usual 18 to 26 because a 30-minute screen cannot carry more; B1 and B2 are the two to rehearse.

## Reverse questions

Ask these in your own words. Each one is there for a reason.

1. **"What does a typical week look like across planning, the warehouse and QA?"** Why it lands: it shows you are weighing the cross-functional side the advert stresses, which is the gap in B1.
2. **"Which systems would I use day to day, and what does onboarding on them look like?"** Why it lands: it asks about the ERP question without claiming any SAP experience (B2).
3. **"How is on-time dispatch measured and reported today?"** Why it lands: it tests the weekly reporting duty (B4) and shows you read the advert.
4. **"Which two days are on-site, and does the team plan together on those days?"** Why it lands: it turns the hybrid logistics into a question about how the team works, not a limit to negotiate.
5. **"What happens after this call, and roughly how long until the next stage?"** Why it lands: it signals you are planning around the process, and she will tell you about the team and next steps anyway.

## Sources

**Provided documents:** the advert text (Quillmoor Diagnostics, Operations Coordinator); Hannah Lowther's LinkedIn message; Sam's notes.

**Searches and fetches:**

- "Quillmoor Diagnostics Avonmouth Bristol operations careers": **refused** (the web search permission was not granted). No other search was sent after this one.

**Target accounting**

Research tier: L1 — searches 0 of 6 (1 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The one search sent (above) was refused. Would have checked for published values and whether the screen is values-style. No values section is built. |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | No call sent after the refusal. Would have set the round's structure and persona weights beyond the relationship prior. |
| 3. `Quillmoor Diagnostics strategy` / recent news | skipped | No CO or CASE question is built for a recruiter screen, and the advert's own text is the only strategy input in hand. |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | A name was given, so a query could be formed, but no call was sent after the refusal. Would have produced an interviewer read and a tailored reverse question. |
| 5. representative `Operations Coordinator` JD | skipped | The advert was supplied, so it fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your notice period, in your words** → A5 gets a stated figure, quoted in its own row, and the slot resolves.
- **Hannah's written guidance on what the screen covers** → confirms the logistics items and any pre-declared deliverable. None is expected for a recruiter screen.
- **Quillmoor's published values or a careers page, pasted** → a values cheat sheet, if the process turns values-style.
- **Hannah Lowther's public profile, if you share a link** → an interviewer read and a reverse question tied to her career path.
- **Deep research (L2)**, offered once: company strategy, recent news and interview-process reports, up to 6 further searches and 2 fetches. It needs web search enabled, which was refused this run.
- **A `tuesday-dossier.md`** would carry this pack's gaps (F2, F5, F6, F9) into later sessions, so the next prep starts from them.
