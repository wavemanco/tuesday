# Interview prep pack: Customer Support Specialist, Lumenvale Software

Remote role. Interview is a text chat with the support team lead (relationship: hiring manager). Interviewer name not given. Built from your summary of the ad and your background; the full ad text was not supplied.

## How to use + type key

Personas describe how a question arrives in chat. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only about what you did.

| Tag | Meaning |
|---|---|
| **JD** | Stated requirement from the ad: can you do the listed job |
| **EXP** | Your past work: does it hold up under scrutiny |
| **CASE** | Live problem from the role, answered as a structured reply |
| **EXP** / **JD** | Dual tags are normal; the first is primary |

## Persona weights

| Persona | How it shows up in chat | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no software background, Zendesk, escalations | **High**: a team lead is buying capability and checking gaps. The ad's Zendesk and escalation lines, and your "never worked for a software company", are where they will press | Rehearse the software question until it is plain. Say the gap once, then the part that carries over, then a plan |
| Case / Strategist | A support scenario to triage in writing | **Medium-high**: support leads test triage and writing in chat | Clarify, then steps in order, then what the customer hears next |
| Conversational | An opening "walk me through" and casual questions about your tools | **Medium-low**: casual in chat, still scored | 90-second arc; treat casual tool questions as scored |
| Pressure | Interruptions and time-boxing | **Low**: a text chat rarely time-boxes, so not weighted | n/a |

Weights: Skeptic 4 questions, Case 3, Conversational 2.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have used Zendesk" | Inflated form of the Zendesk line; your material names only Freshdesk | "I use Freshdesk every day." Zendesk is covered only by the slot in A2 |
| "I have handled escalations" | Inflated form of the escalation line; your material is silent on it | Answer slot in A3 only |
| "I designed the refunds process" | Inflated form of your refunds sentence | "I trained four new starters on our refunds process last year." |
| "I have worked in software" | Negative you stated | "I've never worked for a software company." Plain acknowledgment, no slot |

The pack's own observation, in analysis only: your material shows volume and tools, not escalation work and not written-quality evidence.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message (summary of the ad) | "3 years as a customer service advisor at an energy supplier" — your message | high | [grounded] | none | No gap. Say it in your own words, keeping the quote's terms: "3 years as a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message (summary of the ad) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Freshdesk is a ticketing tool, and the ad allows "a similar ticketing tool." Words: "I use Freshdesk every day." Nothing added. Slot: see A2 |
| F3 | "clear written communication" — your message (summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Volume is not clarity, and the bridge should not be stretched. Answer slot: if a written reply you sent is one you would point to as clear, say which and what made it clear; if none stands out, say so plainly |
| F4 | "confidence handling escalations" — your message (summary of the ad) | none given | none | [grounded] | discovery | The pack observes that your material does not show escalation work. Answer slot: if you handled escalations, say which and what you did, in your own words; if you did not, say so plainly and describe how you would handle one |

Your stated negative, "I've never worked for a software company.", is not a requirement in the ad summary. It is handled as a plain acknowledgment in A1.

## Question banks

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. What would make you effective with our product?" | JD | [grounded] "I've never worked for a software company." — your message | Plain acknowledgment: "I've never worked for a software company." Then how you would learn their product, stated as a plan and never as a past. Name the part of your work that carries over, in your own words. Do not claim knowledge of their product | Highest-ROI prep: this objection is the most likely one. The question presupposes your own stated negative, which is a plain acknowledgment with its source. See F1 for the transferable part |
| A2 | "The ad asks for Zendesk or a similar ticketing tool. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" — your message | Say the Freshdesk line in those words. Answer slot: if you have used Zendesk, say where and what you did in it, in your own words; if you have not, say so plainly and say how you would get up to speed on it | F2 is the Zendesk gap. The question's premise is the ad's, not your material's, so both branches are open |
| A3 | "Tell me about an escalation you handled. What did you do?" | JD | [grounded] "confidence handling escalations" — your message (summary of the ad) | Answer slot: if you handled an escalation, say what it was and what you did, in your own words; if you did not, say so plainly and describe how you would handle one | F4 is silent. The question presupposes an event the material does not carry, so the second branch must be open |
| A4 | "Around 60 calls and emails a day. How did you count that, and which part of it would you defend least?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Defend-the-number: say how you know the figure, in your words. Name the assumption you would defend least. If you do not know how it was counted, say so plainly | F3 rests on this figure, and a number invites a probe. Answer in your own counting, never a method supplied here |

### Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says their refund has not arrived after ten days and is angry. What do you do first?" | CASE | [generic] | Structure: confirm the case and refund status; decide what you can resolve yourself; name what needs escalating and to whom; tell the customer what happens next and when they will hear again. Speak the steps in your own order | Live problem from the escalation line (F4). Makes no claim about your past |
| B2 | "A ticket describes a bug, not a question. How do you route it?" | CASE | [generic] | Structure: check the steps to reproduce, check for a known issue, route to the right queue or team lead with a clear summary, then tell the customer what happens next | Tests escalation judgment. Makes no claim about your past |
| B3 | "Write a reply to a customer who has waited three days for an answer. Keep it under 80 words." | JD | [generic] | Structure: acknowledge the wait, apologize once, say what you have done and when they will hear next, and make one clear request if you need something from them | Tests written clarity (F3) in the form the role uses. Makes no claim about your past |

### Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | 90-second arc: the energy supplier role, the daily volume, the refunds training. Quote each beat in your own words and add nothing | Casual opener, still scored. Draws on F1 and F3 |
| C2 | "What do you use Freshdesk for day to day?" | JD | [grounded] "I use Freshdesk every day" — your message | Say what you actually do in it, in your own words. Answer slot: name the parts you use; if you use only the basics, say so | Casual tool question that is really the Zendesk gap (F2) asked gently |

Pack total: 9 questions. This is below the usual range because only a summary of the ad was supplied. The full ad would add coverage (see the upgrade menu).

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in customer support | C1. No further question: F1 is a direct match |
| Zendesk or a similar ticketing tool | A2, C2 |
| Clear written communication | A4, B3 |
| Confidence handling escalations | A3, B1, B2 |

## Reverse questions

Each has a "why it lands" line. None asks the interviewer to check the invite.

1. "What does a new starter's first two weeks look like on the ticket queue?" Why it lands: shows you are planning the first month, not just the interview.
2. "How do escalations reach you, and what turnaround do you expect?" Why it lands: gets the escalation rules you will be judged on, so you can prepare against them.
3. "Which tools will I use besides the ticketing system?" Why it lands: tests your software familiarity from the other side and shows you have thought about the gap.
4. "Is this interview one chat, or a series of written questions you answer in your own time?" Why it lands: sets how you prepare for the format. It is a process question, not a check.
5. "What does the process look like from here, including when I would hear about next steps?" Why it lands: shows you are planning your timeline, and gives you the schedule to plan against.
6. "What did the most successful person in this role do differently in their first month?" Why it lands: asks for the role's real bar in its own words.

## Sources

- Provided: the invite text, and your summary of the ad and your background, as this turn's input.
- Search: "Lumenvale Software customer support careers" — refused (permission not granted). No other searches or fetches were attempted.
- Research tier: L1 — searches 0 of 6, fetches 0 of 2 (the one search was refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Values cheat sheet: not built. Search refused |
| 2. `Lumenvale Software interview process customer support` | unavailable | Loop structure and persona weights: not confirmed. Search refused |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Grounding brief: not built. No call sent |
| 4. `{interviewer name} Lumenvale Software` | n/a | No name was given, so there was no query to form |
| 5. Representative `Customer Support Specialist` JD | unavailable | Would have added a representative ad. No call sent |

## Upgrade menu

- The full ad text → F1 to F4 can be checked against the complete requirement list, and the question banks can be checked against all of it
- The team lead's name, if you know it → persona weights from their public footprint, and a tailored reverse question
- Whether you have used Zendesk, or how you have handled an escalation → F2 and F4 move from slot to stated evidence
- Permission to search → company values, interview structure and recent news added to the pack
- A `tuesday-dossier.md` from an earlier session, if you have one → sharpens the Skeptic bank
