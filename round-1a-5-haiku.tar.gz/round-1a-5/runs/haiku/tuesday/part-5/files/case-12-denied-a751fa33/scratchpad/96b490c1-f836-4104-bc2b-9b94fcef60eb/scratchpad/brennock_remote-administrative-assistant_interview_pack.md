# Remote Administrative Assistant, Brennock Facilities Ltd: interview prep pack

**Round:** 30-minute video call with the office manager.
**Relationship:** not stated. Persona weights assume a hiring-manager round; the office manager may be a screener instead (see upgrade menu).
**Research:** none run for this pack (Sources). Company values, process and strategy are not stated here.

## How to use

Personas describe how a question is asked. Types describe what is being scored: EXP (your past work), JD (the listed duties), CASE (a live problem), CO (company knowledge), VAL (values). Guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (your summary of the ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material shows a clinic appointment book, not calendars for managers or a team. Words: "I ran the appointment book for four physios." Answer slot: if you arranged anyone's calendar beyond the clinic, say whose and how; if you did not, say so plainly and say how you worked the book |
| F2 | Booking travel (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not mention travel. Answer slot: if you have booked travel for someone, say what you booked and how; if you have not, say so, and say how you would learn the company's booking process |
| F3 | Preparing documents in Word (your summary of the ad) | "I'm good with Word" — your message | medium | [grounded] | presentation | Words: "I'm good with Word." Answer slot: name one document you prepared in Word, if you did |
| F4 | Preparing documents in Excel (your summary of the ad) | "okay with Excel" — your message | low | [inferred] | discovery | Your material says "okay", which is vague. Do not describe it as stronger. Answer slot: name the Excel tasks you have done and what you did in them; if they were basic, let "okay" stand |
| F5 | Processing supplier invoices (your summary of the ad) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices, not the same work. Words: "I chased unpaid invoices." Answer slot: if you handled supplier invoices (receiving, checking, recording or paying them), say what you did; if not, say so and say what you would check first |
| F6 | Remote working (the invite's title, "Remote Administrative Assistant") | none given | none | [grounded] | hard_gate | Your material does not establish that you can work remotely on the role's hours. Surfaced here, not bridged. The one question that asks about this is in the message that presents this pack |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed calendars for managers or a team" | Inflated form of F1 | F1's quote at its own scope. Pack observation, not words for you: the material shows a clinic book, not executive or team calendars |
| "Processed supplier invoices" | Inflated form of F5 | F5's quote at its own scope. Pack observation: the material shows chasing unpaid invoices, not processing supplier invoices |
| "Advanced or strong Excel" | Inflated form of F4 | The quote "okay with Excel", unchanged |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: why you, why remote, what you have not done | High. The fit snapshot's gaps (F1, F2, F5, F6) are where a hiring manager will probe first | Rehearse the objection until it is plain. Return to what you did; concede only what the quotes do not cover | A1 to A5 |
| Case / Strategist | Live admin problems: a clash, an invoice, a cancelled trip | Medium. A common format for an admin screen | Clarify first, then say the order you would act in, and what you would record | C1 to C4 |
| Conversational | Friendly opener and casual questions about Word and the job | Medium. Casual questions are still scored | A 90-second arc built only from your own sentences | B1 to B3 |
| Pressure | Short answers, challenged claims, "how much of that was you" | Low to medium. Short calls with a single interviewer often include one | Hold what is true. Concede plainly on what is not | P1 to P3 |

## Question banks

### Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What did you actually do in those two years at the clinic?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Say it in those words, then the beats the quote states. Answer slot: if any rule or priority of the book was yours to set, say which and why; if none was, say so and describe how you worked the book | F1 is the evidence for calendars and the likeliest first probe |
| A2 | "Calendars for a team are different from a clinic book. What have you managed beyond the clinic?" | JD | [grounded] "ran the appointment book for four physios" (your message) | Use the clinic as your nearest example. If you have managed nothing beyond it, say that plainly and say how you would handle a team's calendar | F1 is at its own scope; the question asks for more than the quote holds |
| A3 | "You're a receptionist applying for an admin job. Why should we believe you can do the whole role?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message); [grounded] "chased unpaid invoices" (your message) | Highest-ROI rehearsal in this pack. Hold: "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios." Answer slot: for each duty you have not done (travel booking, supplier invoices), say whether you have and how; if not, say so plainly and say how you would learn it. Hold through two follow-ups by returning to the book | This objection will come in some form. F1, F2 and F5 are where the gaps sit |
| A4 | "Your Excel is 'okay'. What do you use it for?" | EXP | [inferred] "okay with Excel" (your message; low confidence, so coached as a clarify note, not asserted) | Use your own word for it and name the tasks. If they are basic, say so | F4 is thin evidence; the answer should show its size |
| A5 | "Working remotely means nobody checks over your shoulder. How do you keep a day organised on your own?" | JD | [grounded] "Remote Administrative Assistant" (the invite's title) | Answer from your real routine: name a tool or check you use. If you have no routine for remote work yet, say what you would set up first | F6 is a gate the material does not establish; the answer shows how you would work, not a claim about past remote work |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two managers book overlapping trips, and one calendar has a double-booked meeting. What do you do?" | CASE | [generic] | Clarify who is senior and what is fixed (the flight or the meeting). Contact both. Record the change. Say what you would tell each person | A live problem from the calendar and travel duties; it asks for no claim about your past |
| C2 | "Set up a supplier invoice tracker in Excel. What columns would it have, and what would you check each month?" | CASE | [generic] | Name the columns you would use (supplier, invoice number, date received, amount, due date, status, approver). Name two checks: duplicate invoice numbers and totals against supplier statements | Covers the invoice duty and the Excel requirement without asking about your past |
| C3 | "An invoice arrives with no purchase order and is marked urgent. What do you do?" | CASE | [generic] | Check the approval rule first. Do not pay around it. Send it to whoever approves, with a note on why it is late | Tests judgment about controls, not experience |
| C4 | "A traveller's flight is cancelled the night before a client meeting. Walk me through it." | CASE | [generic] | Clarify the traveller and the meeting. Book the next best option. Tell the traveller and the meeting's host. Keep the receipts for any change | Covers the travel duty as a live problem |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through your background." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, what you ran there, why you are moving to admin. For "why", give your own reason in one sentence; no reason is supplied here | Opening question; casual but scored for clarity |
| B2 | "What are you using Word for these days?" | JD | [grounded] "I'm good with Word" (your message) | Name a document type you have prepared. If you have not prepared one, say what you would start with | F3 is the Word requirement; the answer should name a document |
| B3 | "Anything you'd like to ask us?" | CO | [generic] | Ask one of the reverse questions below. Never answer with a flat "no" | The reverse-question slot is weighted by rapport interviewers |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why this role rather than an office job?" | VAL | [generic] | One honest sentence in your own words. The pack does not supply the reason | Short-answer motivation check |
| P2 | "Your message says 'okay' on Excel. Show me you're more than okay." | JD | [inferred] "okay with Excel" (your message; low confidence) | Hold: if "okay" is true, keep it. Do not upgrade it under pressure. Concede plainly on what you cannot do yet, and say how you would learn it | F4 is the place a stretched answer is most likely |
| P3 | "Give me one admin task you got wrong. What changed afterwards?" | EXP | [generic] | Answer from a real error. If you have none you can name, say so plainly and describe the check you run now, if you run one | Tests honesty about errors; does not supply an error |

## Reverse questions

Each is one line of why it lands.

1. "What does a normal week look like, and which tasks take the most time?" Lands: shows you are scoping the job.
2. "Which tools does the team use for calendars, travel and invoices?" Lands: tests the fit with Word and Excel.
3. "How do you normally set up new remote staff: hours, check-ins, equipment?" Lands: the remote gate, asked as a process question.
4. "What would success look like for this role after 90 days?" Lands: shows you are planning for the job.
5. "Is this 30-minute call the only stage before an offer, or is there a next step?" Lands: a process question, which an interviewer can answer.

## Sources

- Provided documents: the invite (pasted in your message); your summary of the ad (your message); your background (your message).
- Research: none run for this pack. The tier is L0.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet. Not included: no values round is detected |
| 2. Company interview process | unavailable | Loop structure. Persona weights assume a hiring-manager round |
| 3. Company strategy / recent news | unavailable | CO questions |
| 4. Interviewer name and company | n/a | No name was given |
| 5. Representative JD | unavailable | The ad's full text would supply the requirements in quotes |

## Upgrade menu

- The office manager's role in the hiring (hiring manager or screener) → persona weights recomputed for that round
- The full ad text → the requirement rows become exact quotes, marked [grounded]
- A document or spreadsheet you have built, if you can share one → F3 and F4 move up on confidence
- The office manager's name, if you have it → persona weights from their public footprint, and one tailored reverse question
- A search of the company's own website and careers page → values and process rows, and the CO questions
- A tuesday-dossier.md, if you keep one → it would carry the gaps this prep exposed into later sessions
