# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Covers, per the recruiter's message:** salary expectations, notice period, the hybrid pattern, reason for moving, then the team and next steps.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring.

- **EXP**: work-experience deep-dive. Tests whether what is on your CV survives questions about what you did.
- **JD**: role and advert driven. Tests whether you can do the listed job, gaps included.
- **CASE**: a live problem from the role. Tests structure and reasoning.
- **CO**: company and strategy knowledge. None in this pack: web research was not available (see Sources).
- **VAL**: behavioural and values alignment. None in this pack: no values-style round is detected.

The guidance is scaffolding, not a script. Say things in your own words, and only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (the advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Confirmed, with limited inspectable proof, so expect a probe. Say what the four years covered, in your own words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (the advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules. The words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on cross-functional scheduling likely. If you coordinated across a warehouse, planning or QA team, say which and how. If your scheduling did not reach them, say so plainly and say how you would learn the production side. |
| F3 | "track supplier deliveries and chase late orders" (the advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | No gap. Lead with the sentence as written. |
| F4 | "keep stock records accurate" (the advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | No gap. A headline figure with limited inspectable proof, so expect a probe on how it was counted. Lead with the sentence as written. |
| F5 | "report weekly on on-time dispatch" (the advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. That is the pack's observation, not a claim about you. Answer slot: the advert raises it. If you have reported on delivery timeliness, say what you counted and how often. If you have not, say so plainly and say how you would set it up. |
| F6 | "confident with Excel" (the advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The quote reaches Excel in other terms. Say it as written: "I rebuilt our stock-count spreadsheet." Name any functions you use, and only those. |
| F7 | "ERP experience (SAP or similar) a plus." (the advert) | "Never used SAP — we run our own in-house stock system." (your message) | high | [grounded] | capability | A stated absence. Words: "Never used SAP." Then how you would learn SAP, said as a plan, never as a past. Nothing added to make the gap feel smaller. |
| F8 | pay: "£38,000–£44,000." (the advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advert's range. Logistics slot, D1. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." (the advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Gate met as you stated it. Logistics slot, B4. |
| F10 | Right to work in the UK (not stated in the advert; role-family prose) | none given | none | [generic] | hard_gate | Your material does not establish it, and the pack says nothing about your status. Asked once, in the message that delivers this pack. |

## Prohibited claims

The pack will not coach these. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling across planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says deliveries, not production schedules. B1's slot stays inside the deliveries. |
| Owned supplier performance and delivery KPIs | Inflated form of F3 | "I schedule deliveries for our three depots and chase suppliers when orders slip." |
| Cut discrepancies through a controlled count method | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1 asks only how the count was taken. |
| Experience with SAP | Stated negative, F7 | "Never used SAP." A plain acknowledgment, with no slot. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Conversational / rapport | An opening biography, a week-in-the-life question | High. A recruiter screen is weighted to this persona. Friendly register, but scored | Keep the biography to what you did, in about 60 seconds | A1 to A5 (5) |
| Skeptic | Probes the stated gaps: production scheduling, SAP, dispatch reporting. Motivation checks | High. Recruiter screens also check knockouts and motivation | Rehearse the production-scheduling probe until it is plain. Hold the stated gaps without bluffing | B1 to B6 (6) |
| Data-Driven Prober | Asks how the one-third figure was counted | Medium. The CV carries one headline figure, and that is where probes land | Say what you know about the count, and say plainly what you do not | C1 to C4 (4) |
| Pressure | Pay, reason for leaving, start date | Medium. These are logistics checks, but pay is scored | Give your own figures and reasons, no more | D1 to D3 (3) |

## Question banks

Provenance comes before the guidance. Each row's guidance rests only on the quoted sentences in its Provenance cell.

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Open with the four years and the wholesaler, then the depots, in your own words. Keep to what you did: "I schedule deliveries for our three depots and chase suppliers when orders slip." Speakable in about 60 seconds. | F1 is the opening fact for the 2+ years requirement. Conversational in register, but scored. |
| A2 | "What does a normal week look like in your current role?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Describe the scheduling and the chasing as the sentence states them. Do not add volumes, counts or tools you did not give. If asked for a figure you do not have, say you would need to check it. | F3. Tests whether your account matches your CV. |
| A3 | "Which tools do you use day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Name the spreadsheet you rebuilt. Answer slot: if you use lookups, pivot tables or other functions, name them. If not, name the tools you did use and say how confident you are with Excel, in your own words. | F6. The Excel requirement. |
| A4 | "What's the hardest part of a coordinator's job?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer from what you have found hard. The chasing of late supplier orders is the part your material shows. Do not offer a general view you have not formed. | Open question on the role. Your answer should stay within your own experience. |
| A5 | "Why this role?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name the parts of the advert your material shows you have done, using the sentence. Say nothing about the company's products or mission: nothing about them is in your material. | A motivation probe. It keeps the answer to what you can stand behind. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is deliveries across depots. Production scheduling between planning, the warehouse and QA is different. How would you handle that?" | JD | [grounded] "I schedule deliveries for our three depots"; the advert: "Coordinate production schedules between planning, the warehouse and QA" | Hold: "I schedule deliveries for our three depots." Answer slot: say which of planning, the warehouse or QA your scheduling touched, and how. If none did, say so plainly and say how you would learn production scheduling. | F2, the largest gap between your material and the advert. The highest-return prep in this pack, because the advert's own line makes this probe likely. |
| B2 | "Do you have SAP or any ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "Never used SAP." Then describe the in-house stock system in your own words, as far as you know it. Then how you would learn SAP, as a plan. | F7. A stated negative, so the words are yours. |
| B3 | "The advert asks for a weekly report on on-time dispatch. What have you reported?" | JD | [grounded] the advert: "report weekly on on-time dispatch" | Answer slot: if you have reported on delivery timeliness, say what you counted and how often. If you have not, say so plainly and say how you would set it up. | F5. The advert raises it. |
| B4 | "How do you feel about the two-day pattern at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: "Two days at Avonmouth is fine, but I wouldn't want more than three." If asked whether that limit is firm, your own words were: "I wouldn't want more than three." Nothing added. | F9. Gate met as stated. |
| B5 | "A supplier's order is late and the warehouse is waiting. What do you do?" | CASE | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Structure it: who you contact first, what you tell the warehouse and planning, and what you record. Use the chase you actually did, as the sentence states it. Answer slot: if a late order has held up a dispatch, say what you did and what you would change. If not, say so and give the structure only. | A live problem from the role. The answer slot keeps it inside your material. |
| B6 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name SAP in your own words: "Never used SAP." Then say how you would close that in the first month, as a plan. Do not claim any SAP exposure. | F7. The stated gap, answered plainly. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Restate the sentence as written. Name, in your own words, the assumption behind the figure that you would defend least. Answer slot: if you know how the count was taken, say how. If you do not, say so plainly. | F4. The defend-the-number slot the figure raises. |
| C2 | "How much of that third was you, and how much was shared with others?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: "I rebuilt our stock-count spreadsheet." Answer slot: say which part of the improvement was yours and which was shared, in your own words. If you cannot separate them, say so. | F4. Attribution, the second defend-the-number slot. |
| C3 | "What do you check to know a stock record is accurate?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name any check the rebuilt spreadsheet did. If it did none you can describe, say so and say what you would check first. | The advert's "keep stock records accurate" requirement. |
| C4 | "How do you make sure a late supplier order gets resolved?" | JD | [grounded] "chase suppliers when orders slip" | Describe the chase in your own words, as the sentence states it. Answer slot: if you tracked deliveries against a schedule, name the sheet or tool. If the chase was ad hoc, say so. | The advert's "track supplier deliveries and chase late orders" requirement. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: give the figure in your own words, "I'm hoping for £42,000." Give no range, floor or flexibility you did not give. If asked what you earn now: "I'd rather focus on the range for this role." | F8. Pay is a term, and your figure sits inside the advert's band. |
| D2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, in your own words, as the sentence states it: the office closing, and the only offer being relocation. Do not add a reason you did not give. | The reason-for-leaving slot the recruiter named. |
| D3 | "What's your notice period, and when could you start?" | JD | [generic] no candidate claim: your message gives neither figure | Logistics slot: give your actual notice period and your earliest start date, in your own words. The pack holds no figure for either. | Notice is a term the recruiter named and your message does not state it. |

## Coverage

| Advert requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, B5 |
| Track supplier deliveries and chase late orders | A2, C4 |
| Keep stock records accurate | C1, C3 |
| Report weekly on on-time dispatch | B3 |
| Confident with Excel | A3 |
| ERP experience (SAP or similar) a plus | B2, B6 |
| Pay, £38,000–£44,000 | D1 |
| Hybrid, two days a week at Avonmouth | B4 |
| Notice period (named by the recruiter, not in the advert) | D3 |
| Reason for leaving (named by the recruiter) | D2 |
| Right to work in the UK (not in the advert) | none, and why: the question is asked in the delivering message, not scored here |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work alongside day to day across planning, the warehouse and QA?" | It is the advert's own three-way split, and shows you read it. |
| R2 | "What does the weekly on-time dispatch report look like, and who reads it?" | It shows you have read the reporting duty and want to know what it is for. |
| R3 | "How is the two-day pattern at Avonmouth usually set up, and which days are fixed?" | It gets logistics clarity without reopening your stated limit. |
| R4 | "What are the next steps after this call, and how long does each one take?" | The recruiter said they would cover next steps. This asks for them directly. |
| R5 | "What does someone in this role spend most of their time on?" | It shows whether the work leans towards scheduling or towards QA. |

## Sources

- **Provided:** the advert, pasted in your message. Your background summary and salary, location and reason-for-leaving statements, all from your message. The recruiter's LinkedIn message.
- **Searches sent this engagement:** four, all refused by the host's permission check, so none returned a result.
  - "Quillmoor Diagnostics values": refused
  - "Quillmoor Diagnostics interview process operations coordinator": refused
  - "Quillmoor Diagnostics news strategy": refused
  - "Hannah Lowther Quillmoor Diagnostics talent partner": refused
- **Research tier:** L1, searches 4 of 6, fetches 0 of 2.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have fed the values section, which needs a values-style round. None is detected, so nothing in this pack is lost. |
| 2. Quillmoor Diagnostics interview process | unavailable | Would have shown the loop beyond this screen. The persona weights here rest on the recruiter-screen prior alone. |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Would have fed a strategy-grounded CO question. The coverage rule asks for one, and this pack has none. |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have informed a recruiter read. No interviewer read is included. |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your notice period and earliest start date → D3 holds your own figures in place of an instruction.
- Your answer on the right to work in the UK → F10 moves from surfaced gate to stated status.
- How the one-third figure was counted, and what part was yours → C1 and C2 hold your own words.
- Any dispatch reporting you have done → B3 holds a quoted line in place of the answer slot.
- Web search permission → targets 1 to 4 (values page, interview process, recent news, the recruiter's public footprint). That would add a strategy-grounded CO question and sharpen R4.
