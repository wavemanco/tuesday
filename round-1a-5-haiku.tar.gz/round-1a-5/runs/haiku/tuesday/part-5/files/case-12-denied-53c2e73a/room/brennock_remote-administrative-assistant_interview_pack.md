# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Built from your message only; the full ad text was not supplied, so the requirements below are your summary of it.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioural and values alignment
- **EXP**: a deep-dive into your own experience
- **JD**: the role's stated duties
- **CO**: company knowledge (none researched here)
- **CASE**: a hypothetical or live problem from the job

The guidance is scaffolding, not a script. Answer slots are instructions for the interview: answer from your own experience, or say plainly that the practice was not yours.

## Fit snapshot

Requirements quoted from your message's summary of the ad. Evidence quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says the appointment book for four physios. Bridge: "I ran the appointment book for four physios." Answer slot: if you used a named calendar tool, say which; if the book was paper, say so. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how, in your own words; if not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" (your message) | "I'm good with Word" (your message) | medium | [grounded] | presentation | Bridge: "I'm good with Word." Name the documents you have prepared, only if you prepared them. |
| F4 | "preparing documents in Word and Excel" (your message) | "okay with Excel" (your message) | low | [inferred] | discovery | "Okay" is a self-rating, and your material does not show which Excel tasks you have done. Answer slot: name the Excel tasks you have done, if any; if none, say so, and say how you would get to the level the role needs. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing them, not the same work. Bridge: "I chased unpaid invoices." Limit: your material does not show you checked, approved or paid supplier invoices. Answer slot: if any of that was yours, say which; if none was, say so plainly and say what you did with invoices. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Practical scenarios from the job: travel, diaries, invoices | High. An office manager hiring for an admin role usually tests how you would handle the work. Weight: top, 4 questions | Clarify first, then take the steps in order, and say what you would check before you act |
| Skeptic | Probes the travel, Excel and invoice gaps | High. These are the rows where your material is thinnest. Weight: 4 questions | Hold what you did, concede what you did not, and say how you would learn it |
| Conversational | A "walk me through your background" opener | Medium. Casual, but scored. Weight: 2 questions | Keep a 90-second arc built from your own sentences |
| Data-Driven Prober | Asks for numbers: appointments per week, invoices chased | Medium. Figures in an admin CV get checked. Weight: 2 questions | Give a figure only if you know it; otherwise say so |
| Pressure | Time-boxed "why should we take you" challenges | Low to medium. Weight: 2 questions | Pause, restate, hold the core claim, concede gaps precisely |

## Question banks

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A director needs flights and a hotel for three people, and two of them fly on different days. How would you handle it?" | CASE | [generic] | Clarify the budget and any travel policy, check each traveller's constraints, confirm before booking, and keep a record of what was booked. Makes no claim about your past | A live problem from the travel duty. F2 is the row it tests, and the answer needs no experience you have not stated |
| A2 | "Two meetings have been double-booked on the same afternoon. What do you do?" | CASE | [generic] | Find out which meeting has the stronger claim, contact both organisers, move the weaker one, and confirm the change in writing. Makes no claim about your past | Tests the calendar duty in F1 as a decision, not a record |
| A3 | "A supplier invoice does not match its purchase order. What happens next?" | CASE | [generic] | Hold the invoice, check the order and the delivery record, contact the supplier, and send it to the approver with a note. Makes no claim about your past | Tests the invoice duty in F5 as a live problem |
| A4 | "A Word document needs a table of figures from an Excel sheet. How would you build it?" | JD | [grounded] "okay with Excel" (your message) | Name the steps in order: check the source figures, build the table, check it against the sheet, and say what you would do if a figure does not match. Answer slot: if you have done this, say how, in your own words; if not, say so plainly and describe how you would learn it | F3 and F4: your Word claim is medium, your Excel claim is low, so the steps are the answer |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have chased unpaid invoices. Have you processed supplier invoices yourself, from receipt through to payment?" | JD | [grounded] "chased unpaid invoices" (your message) | The highest-return rehearsal in this pack. Hold: "I chased unpaid invoices." Answer slot: if any part of processing supplier invoices was yours (checking, approving or paying), say which, in your own words. If none was, say so plainly and say what you did with invoices. Hold through two follow-ups by returning to what you chased; never add to it | F5 is the thinnest link to a named duty and the most likely probe. Its limit is the pack's own observation, not words for you |
| B2 | "Have you booked travel for anyone?" | JD | [grounded] "booking travel" (your message); no evidence quoted | Answer slot: if you have booked travel for anyone, say what and how, in your own words. If not, say so plainly and say how you would learn the booking tools | F2 has no evidence. Silence is a discovery gap, so the answer is yours to give |
| B3 | "How would you rate your Excel, and what have you built in it?" | EXP | [grounded] "okay with Excel" (your message) | Say "okay", then name the Excel tasks you have done, if any. Answer slot: if you have built nothing in Excel, say so and give your plan to learn it. Never upgrade the word "okay" | F4: the probe lands on the self-rating, so the word you use stays the word you gave |
| B4 | "Why leave a clinic role for a remote admin post?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Give your own reason in your own words. Answer slot: if the honest reason is that you want different work, say so, and say which part of this role appeals to you | Motivation is probed in every loop; your material does not state a reason, so the reason is yours to give |
| B5 | "Which calendar and booking tools have you used?" | JD | [grounded] "managing calendars" (your message) | Answer slot: name the tools you have used. If the appointment book was paper or a single clinic system, say which. If you have used none, say so | F1: the duty names tools, and your material names none |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" (your message) | A 90-second arc in this order: the clinic and the two years; the appointment book for four physios; the invoices you chased; Word and Excel at the level you rate them; why this role. Use your own sentences, with no added adjectives | Opens the call. Every line of the arc is one of your quoted sentences |
| C2 | "How did you stop four physios' diaries from clashing?" | JD | [grounded] "ran the appointment book for four physios" (your message) | Describe the method you used, in your own words. Answer slot: if there was a rule for double-booking, say it only if you set or followed it. If you had no method, say so | F1: the calendar duty, asked casually and scored |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many appointments did you book in a typical week, and how did you check for double-bookings?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Give a number only if you know it. If you do not, say so plainly and do not estimate on the spot. Name one assumption behind the figure you would defend least | F1: a number invites a probe into how it was counted |
| D2 | "How many unpaid invoices did you chase, and what came of them?" | EXP | [grounded] "chased unpaid invoices" (your message) | Give a count only if you tracked it. Otherwise say so, then say what happened in the cases you do remember | F5: the prober tests whether the invoice claim is measured or remembered |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you over someone with office-admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold: what you bring is the appointment book for four physios and the invoices you chased. Concede the gaps (travel, Excel depth) plainly. Do not fold on the core claim | F1 and F5 carry the position. A held position must be one your quotes back |
| E2 | "You said okay with Excel. Why would we trust you with spreadsheets?" | JD | [grounded] "okay with Excel" (your message) | Hold the honest level. Concede the specific limit, then give your learning plan as a plan, not as a past | F4: the second follow-up breaks any claim you cannot back |

Session total: 15 questions. This is below the usual range because the material is thin. The upgrade menu says what would add more.

Requirement coverage:

| Requirement (source) | Covered by |
|---|---|
| "managing calendars" (your message) | B5, C2, D1 |
| "booking travel" (your message) | A1, B2 |
| "preparing documents in Word and Excel" (your message) | A4, B3, E2 |
| "processing supplier invoices" (your message) | A3, B1, D2 |

## Reverse questions

Ask any five or so. Each has a reason it lands.

| Question | Why it lands |
|---|---|
| "What does the first month look like for whoever holds this role?" | Shows you are thinking about the job, not just about being hired |
| "Which systems do you use for calendars, travel bookings and supplier invoices?" | Tells you which tools to rehearse before the next stage |
| "How are supplier invoices approved before they are paid, and who signs off?" | Shows you know the invoice chain has approvers. Asks about process, not about your fit |
| "Is this call the only stage, or is there a next step before an offer?" | Lets you prepare for the stages that follow. It asks about the process itself |
| "How does the team usually work day to day when people are remote?" | Shows you understand the remote setup the ad describes |
| "What would make someone successful in this role after three months?" | Gives you the interviewer's own measure of the job |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I processed supplier invoices" | Inflated form of F5: "chased unpaid invoices" is not processing | "I chased unpaid invoices," at its own scope. Your material says chasing, not processing |
| "I'm advanced in Excel" | Inflated form of F4: your word is "okay" | "Okay with Excel," as you put it |
| "I managed calendars for the whole office" | Inflated scope of F1: your material says four physios | "I ran the appointment book for four physios" |

## Sources

- Provided material: your message (the ad as you summarised it, and your background). No CV, dossier or full ad text was supplied.
- Search: a check for the employer's existence and for public reports of recruitment scams that use its name. Refused (search permission was not granted in this session).
- Research tier: L1, searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Section on values would apply only if a values round were detected; search refused |
| 2. interview process, role family | unavailable | Would have set the loop structure and persona weights; weights here follow the round type instead. Search refused |
| 3. company strategy and recent news | unavailable | Would have moved the company-knowledge questions. Search refused |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative role JD | unavailable | Would have moved the requirement quotes; your summary is not the full ad. Search refused |
| Un-numbered: scam reports and existence check | unavailable | Refused. Would have moved the warning sent with the pack, not the pack's content |

## Upgrade menu

- The full ad text → turns the requirement rows from your summary into quoted lines from the ad
- Your CV → the evidence rows would rest on your document, not only on your message
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- Whether the ad states working hours, location or a required setup → the gate rows, which are none yet
- A tuesday-dossier.md → verified evidence and a strategy for the travel and Excel rows
