Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also describes a "cheque for €1,850 to buy a laptop and desk from our approved vendor", which you would deposit while sending the balance on. A fee before an interview, passport and bank details before an offer, and a cheque to deposit are a known scam pattern, and the fee and the cheque are very likely a scam. Hold all of those until you have checked the invite with the employer through a phone number or address from its own website or careers page, not from this email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-12-denied-da0409a7/8dd62ea9-11dc-45d3-8e3c-39f6abe1eaf3/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md`. I couldn't run web searches in this session, so it uses only what you told me.

For the call itself, expect the office manager to check your gaps first: supplier invoices (A3), travel (A4) and Excel (A2). Rehearse A3 until it is boring. Your strongest true material is the appointment book for four physios and chasing unpaid invoices, so start there.

Want a drill? I can play the Skeptic on A3. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word if you'd like it that way.

1. Can you paste the full posting text? That turns the four duties into exact wording, and the JD questions can rest on it.
2. Does the posting say where you need to be based, what hours you'd work, or what equipment you supply?
3. Is the office manager the person you'd report to, or someone else on the team? That changes how the interview is weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager. Interviewer name not given.
**Built on:** the posting duties you summarised, and your background as you described it. No full posting text, no research (see Sources).

## How to use, and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and where a line has an answer slot, give the branch that is true for you.

- **JD**: can you do the listed duties, including the gaps
- **EXP**: does your own work history hold up when someone asks about it
- **CASE**: a live problem from the role, answered out loud; it asks nothing about your past
- **CO**: company knowledge (none included: no research was run)
- **VAL**: values (none included: no values were found or given)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (posting, as you summarised it) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Words: "I ran the appointment book for four physios." The bridge is the quote and nothing more. "Calendar" is the posting's word, not yours, so do not use it about your own history. |
| F2 | "booking travel" (posting, as you summarised it) | none given | none | [grounded] | discovery | Silence, not a negative. Answer slot: if you have booked travel for anyone, say what, for whom, and how, in your own words. If you have not, say that plainly and walk through how you would handle a first request. |
| F3 | "preparing documents in Word and Excel" (posting, Word half) | "I'm good with Word" (your message) | medium | [grounded] | none | The quote reaches the Word half in role-relevant terms. Expect a probe, since it is a self-rating with nothing inspected behind it. |
| F4 | "preparing documents in Word and Excel" (posting, Excel half) | "okay with Excel" (your message) | low | [inferred] | discovery | Derivation: a self-rated skill with no example behind it. Words are an answer slot, not a claim: name what you have done in Excel. If it was basic, say so. |
| F5 | "processing supplier invoices" (posting, as you summarised it) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Adjacent work. Chasing unpaid invoices is payment follow-up, not processing supplier invoices. Words: "For the clinic, I chased unpaid invoices." The wider step is an answer slot inside that scope: if you have handled supplier invoices, say what you did; if you only chased payment, say that. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran executives' calendars | Inflated form of F1 | "I ran the appointment book for four physios." The material shows an appointment book, not executive calendars. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." The material shows chasing, not processing. |
| Advanced Excel | Inflated form of F4 | "okay with Excel." The material shows a self-rating and nothing more. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The gap is probed: invoices, travel, Excel | High. An office manager hiring for this duty list will check the duties you did not show. Weight 4. | Rehearse A3 until it is boring. Hold the true scope, and concede the gap by name. |
| Case / practical | Live office problems: a double-booking, an invoice with no purchase order | High. Admin roles are screened on handling a live problem. Weight 4. | Structure aloud: check the rule, check the person, record it. |
| Prober | Asks how you checked your work and what Excel you have used | Medium. Weight 3. | Say your checks in order, and say which ones you already do. |
| Conversational | A short opener and a casual question about your background | Medium. Casual questions are scored. Weight 3. | Use a 90-second arc built only from your own sentences. |
| Pressure | Interrupts and questions why you, from a receptionist background | Lower for a 30-minute call. Weight 2. | Pause, hold what you did, then concede the specific gap. |

The total is 16 questions. That is below the usual range because a 30-minute call cannot rehearse more than this, and the pack is sized to that.

Requirement coverage: managing calendars covered by B3, C1; booking travel covered by A4, B1; Word and Excel covered by A2, B4, C2, C3; processing supplier invoices covered by A3, B2, R3.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You spent two years at a clinic reception desk. Why move into an admin role now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Say what the clinic work taught you that you want to do more of, in your own words. If the answer is something you have not yet done, say that. | Skeptic checks motivation consistency. Your history is the one thing this question must match. |
| A2 | "You're good with Word and okay with Excel. What have you actually built in Excel?" | JD | [grounded] "I'm good with Word"; "okay with Excel" (your message) | Answer slot: if you built or changed a spreadsheet, name it and what it did. If your use was simpler, say so plainly, then name the first thing you would learn. Do not describe it grander than that. | F4 is where the Word-and-Excel line presses hardest. |
| A3 | "This role processes supplier invoices. You've chased unpaid ones. Which part of that have you done?" | JD | [grounded] "chased unpaid invoices" (your message) | Say "I chased unpaid invoices," in those words. Answer slot: if you have handled supplier invoices, such as checking, coding or paying, say what you did. If you only chased payment, say that and say what you would learn about the supplier side first. Hold through two follow-ups by returning to the chasing. | Highest-ROI prep in this pack. F5 is the closest-sounding claim with the widest gap, and the probe sits in the step between chasing and processing. |
| A4 | "Booking travel isn't in your background. How would you handle your first request?" | JD | [grounded] "booking travel" (posting, as you summarised it) | Answer slot: if you have booked travel for anyone, say what and for whom. If you have not, say so plainly and walk through how you would handle a first request, such as what you would confirm before booking. | F2 is silence in the material, so the answer is yours to give. |

### Case / practical (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director double-books you: two external meetings in different cities, the same afternoon. What do you do?" | CASE | [generic] | Structure aloud: check which meeting the director prioritises, move the other, tell both parties, and check the travel consequences. Make no claim about your past. | A live problem from the calendar and travel duties. It presupposes nothing about you. |
| B2 | "A supplier invoice arrives with no purchase order. Talk me through what you'd do." | CASE | [generic] | Structure aloud: check the approval rule, find the budget holder, hold payment until the invoice is matched, and record the query. | A live problem from the invoice duty. It presupposes nothing about you. |
| B3 | "Tell me about a time you had to keep a busy diary straight." | EXP | [grounded] "ran the appointment book for four physios" (your message) | Story from the appointment book: four diaries, one book, how you kept them apart. Answer slot: if a clash happened, say what you did about it; if none did, say how you kept the book accurate, in your own words. | An open prompt that draws on F1, the calendar evidence. |
| B4 | "Show me a document you've prepared in Word from scratch. What was it for?" | JD | [grounded] "I'm good with Word" (your message) | Name the document, who it was for, and what you did in Word to it. Answer slot: if you mostly edited existing templates, say so. | F3's Word half. A concrete example outweighs the adjective. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you know the appointment book was right each day?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Answer slot: if you had a check, say what it was. If you had none, say so, and say what you would put in place. | Tests the attribution behind F1. |
| C2 | "What would you check in a Word document before it went out?" | JD | [grounded] "I'm good with Word" (your message) | Describe your own checks in order, and say which you already do. | Prober tests method, not adjectives. |
| C3 | "You're okay with Excel. What's the largest sheet you've used, and what did it do?" | JD | [inferred] "okay with Excel" (your message); derivation: a probe on a self-rated skill | Name the sheet and what it did. If you used Excel only lightly, say so. | F4 is low-confidence, so this asks for the example instead of asserting one. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word"; "okay with Excel" (your message) | A 90-second arc: the clinic, the appointment book, chasing invoices, Word and Excel, then why this role. Each beat is only what the quotes carry. | A friendly opener is still scored. |
| D2 | "What does a normal day look like in your current job?" | EXP | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" (your message) | Walk through one day in those two tasks. | Rapport opener that leads into B3. |
| D3 | "What part of this job would you most want to do?" | JD | [grounded] "managing calendars" (posting, as you summarised it) | Name one of the four duties and why, only if it is true for you. | Casual questions about the posting's duties are scored. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've got a receptionist background and this is an admin job. Why should I believe you can do it?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold: "I ran the appointment book for four physios." Hold through two follow-ups. Concede the specific thin spot, travel or invoices, by name. | Tests composure, not content. |
| E2 | "Sixty seconds: why you over someone with an office admin background?" | EXP | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" (your message) | Keep to those two quotes. Do not compare yourself with other candidates. If you have no answer for travel, say so and say how you would learn it. | Time-boxed challenge. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like for whoever is in this role?" | Shows you are planning, and gets the real scope. |
| R2 | "Which calendar and travel tools does the team use day to day?" | Shows you are thinking about the duties as work. |
| R3 | "How are supplier invoices approved and paid here, and who signs off?" | Tests whether the invoice duty is real processing work or only follow-up. |
| R4 | "How many requests a week does this role usually handle?" | Gives you a real volume to plan around. |
| R5 | "What would you hope the person in this role has sorted by the end of the first quarter?" | Shows you are aiming at the priorities, not the job title. |

No interviewer profile exists, so no reverse question is tied to their path.

## Sources

**Provided documents:** the invite text and your background, both from your message. The duties come from your summary of the posting, not the posting itself.

**Searches and fetches sent:**
1. Company presence search for the employer named in the invite: refused.
2. Search for reports of recruitment scams that use this company's name: refused.

**Target accounting**

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Would have moved the values cheat sheet, only if a values-style round exists. The invite names none, so no values section is included. |
| 2. interview process | unavailable | Would have moved the loop structure and persona weights. The pack uses the hiring-manager prior instead, and says so. |
| 3. strategy / recent news | unavailable | Would have moved CO questions. None are in this pack. |
| 4. interviewer name | n/a | No name was given. The invite names only the office manager. |
| 5. representative JD | unavailable | Would have moved the JD-tagged rows. Your duties summary fixes the requirements but not the exact wording, so the rows quote your summary. |

## Upgrade menu

- The full posting text → the four duties become verbatim [grounded] requirements, and the JD questions rest on the exact wording.
- The office manager's name → persona weights from their public footprint, and a tailored reverse question.
- The employer's careers or contact page, found by you → the interview process and loop structure. Until then, persona weights rest on the hiring-manager pattern, not this employer's documented process.
- Whether you have booked travel or handled supplier invoices → moves F2 or F5 from discovery to evidence.
- Working hours, time zone and equipment, if the posting names them → gate rows.
- tuesday-dossier.md, if you keep one, with the gaps this prep exposed.
