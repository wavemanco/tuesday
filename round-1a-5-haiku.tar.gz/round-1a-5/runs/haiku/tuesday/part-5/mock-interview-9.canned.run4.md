Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-9-canned-c89b7a28/78502464-32b7-4add-9ab4-f6045593b4fb/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. I built it for a hiring-manager round with the principal and peer rounds with the two team members, since the invite gives the panel's makeup but not its roles.

Your message included a Social Security number. You don't need it for this prep, so I haven't used it or repeated it, and I'd keep it off anything you send to the school.

The highest-return prep is the fourth-grade gap. The principal is likely to open with "You haven't taught fourth grade," so rehearse saying "I haven't taught fourth grade" plainly, then bridge from your six years of third grade and give a concrete plan for learning the content. The pack also covers the team-lead gap and the 2024 reading-curriculum move, which is your strongest story. Keep it to what you actually did.

Say the word and I'll play the principal on the fourth-grade question, or run a drill with a persona of your choice. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:
1. Did HR say what the panel will focus on, or ask for a demonstration lesson or written piece?
2. Can you paste the full job posting? I built this from the invite and your resume only.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Fourth Grade Teacher, Halvering Elementary School: panel interview prep

- **Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
- **Interview:** 45-minute panel with Principal Dolores Vantongeren and two fourth-grade team members. Built on a hiring-manager round for the principal and peer rounds for the two team members, since the invite gives the panel's makeup but not its roles. Tell me if that is wrong.
- **Logistics:** Thursday is November 26, Thanksgiving Day. Confirm the date, time and format (in person or video) with HR.
- **Built on:** the invite and your resume as you pasted them. No job posting text and no web research this run.

## How to use

Personas are how a question is asked. Types are what it scores: **JD** (a stated requirement of the role), **EXP** (what you actually did, checked closely), **CASE** (a live problem from the job). Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: give whichever honest branch fits your own experience.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | The gate is met on your statement. Say it as written: "registered and active through June 30, 2029." Check the license on the state's lookup before Thursday, since a panel can check the record. |
| F2 | Teaching fourth grade (the position title; not a listed requirement) | "I've never taught fourth grade" (your CV), "Six years teaching third grade at a public elementary school in Joliet" (your CV) | none | [grounded] | capability | The plain acknowledgment: "I haven't taught fourth grade." Then the adjacent years at their own scope: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: how you would learn the fourth-grade content, said as a plan, never as a past. |
| F3 | Working with a fourth-grade team (the panel's makeup; not a listed requirement) | "I've never been a team lead" (your CV), "I led our grade level's move to a new reading curriculum in 2024" (your CV) | none | [grounded] | capability | The plain acknowledgment: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not stretch that into a team role. |
| F4 | Communicating with families (not a listed requirement) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Say it as written: "I write a weekly email to families." Nothing added. |

Gap types: F2 and F3 are `capability` because you stated the absence yourself. Nothing else in the snapshot needs a bridge.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated (F2) | "I haven't taught fourth grade." No slot. |
| Has led a team | Negative you stated (F3); also an inflated form of "I led our grade level's move" | "I haven't been a team lead." The curriculum move at its own scope. The material shows the move, not a team role. |
| Designed the reading club or the reading program | Inflated form of "I've run the after-school reading club for the last two years" and "I led our grade level's move to a new reading curriculum in 2024" | Each quote at its own scope. Your material says you ran the club and led the move; it does not show you designed either. |

## Personas

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet probing of the fourth-grade gap and the team-lead gap | Highest weight (5). The invite's requirement is met, so the two stated absences are where a principal looks first | Make the plain acknowledgment boring, bridge only from the third-grade years, and follow with a concrete plan |
| Pressure | Principal | Time-boxed challenge: why you over a fourth-grade teacher | Mid weight (3). Principals often time-box the first question | Pause, restate, hold the curriculum move through two follow-ups, concede the fourth-grade gap plainly |
| Case / Strategist | Principal | A live classroom problem | Mid weight (3). Hiring managers test judgment on a situation | Clarify, diagnose, plan, then name the team you would use |
| Peer Evaluator | Two team members | Seam questions: what you need from them, how you would disagree, what would land on their plates | Mid-high weight (4). Peers price the hire by what it costs their own work | Reciprocity first: what you bring, then what you need. Propose principles, not claims about their seam |
| Data-Driven Prober | Team members | How you know the reading work did anything | Mid weight (3). Peers read the CV line by line | Name the measure you actually used, or say you did not set one |

## Question banks

Ordered by weight within each persona.

### A. Skeptic (principal), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What makes you ready for it?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Start with "I haven't taught fourth grade." Then the third-grade years in those words. Then a plan: which fourth-grade content you would learn first and how. Answer slot: if you have taught or planned fourth-grade lessons, say how; if not, say so and give the plan. | This is the highest-return prep in the pack. F2 is the gap the position title makes unavoidable, and a principal will lead with it |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your CV) | Name one part, plainly: "I haven't taught fourth grade." Then the part you would learn first, as a plan. Calibrated, not a list of every gap | A Skeptic's standard opener. One honest answer beats a defensive list |
| A3 | "You haven't been a team lead. What would you need to learn to run a grade-level team?" | JD | [grounded] "I've never been a team lead" (your CV) | "I haven't been a team lead." Then what you would learn, as a plan. Answer slot: if you have led colleagues in any setting, say what it was; if not, say so, then give the plan | F3. The panel includes a team, so the probe is likely |
| A4 | "What did you lead in the 2024 reading curriculum move, and who decided what?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you led, in those words. Answer slot: if you chose the materials or set the timeline, say which and how you decided; if the team or the district decided, say so and describe your part within that | Probers ask who decided. The quote is the scope of the answer |
| A5 | "Why fourth grade, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Motivation in your own words. The material gives no reason, so the pack supplies none. Answer slot: give the reason you actually have for fourth grade, and what it draws from your third-grade years | A Skeptic's consistency probe. The answer has to be yours |

### B. Pressure (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never taught fourth grade" (your CV) | Pause and restate. Open with the curriculum move in its own words. Hold it through two follow-ups. Concede the fourth-grade gap plainly: "I haven't taught fourth grade." Do not fold on the move | Hold-then-concede. The position you hold is the one your material carries |
| B2 | "Your reading club is after school. Why should I believe that prepares you for a full day with fourth graders?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | "I've run the after-school reading club for the last two years." Hold that it is reading work with students. Concede that it is not a full school day. Answer slot: name any part of the club you would carry into the school day; if none, say so | Tests whether the club is inflated into classroom experience |
| B3 | "You said you led the curriculum move. Which part of it would you not defend?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer in your own words: what you led, and the part you would defend least. Hold the move itself through two follow-ups; concede the specific part you are unsure of | A weakest-assumption probe, asked of a claim you did make |

### C. Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together. What would you need from us, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Lead with what you would bring, at the quote's scope: the grade-level reading move. Then what you would need, asked as a question: their pacing plans and shared assessments | Peers price the hire by what it adds to their work. Reciprocity first |
| C2 | "How do you handle a disagreement with a colleague about how to teach a unit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Pick a real disagreement from grade-level work. If none comes to mind, say so plainly, then give the nearest thing your material carries, the reading move, or how you would handle it | An open prompt. The theme comes from the peer persona, and the honest branch is built in |
| C3 | "How do you keep families informed, and what would you do differently on this team?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe the weekly email in your own words, at its scope. The second half is a plan, so give it as one | F4. A strength to state plainly, not to inflate |
| C4 | "Where would you expect the seam between your class and ours, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, not a claim about how their seam works. On disagreement, say you would raise it with the team first | A peer seam probe. The pack does not know their seam, so the guidance does not pretend to |

### D. Data-Driven Prober (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you judge whether the new reading curriculum was doing its job?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the measure you actually used, before they ask. Answer slot: if you tracked a measure, say what it was and who chose it; if none was set, say so and say what you would track first. Give no score you cannot name | A prober's first probe on any reform claim |
| D2 | "Tell me about a result from the reading club you can point to, and how you checked it." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Pick a result you can name. Answer slot: if you tracked one, say what it was and how you counted it; if you did not, say so and say what you would track | An open prompt on the club's outcomes. The honest branch is built in |
| D3 | "What is one number you would check in your class in the first month, and how would you count it?" | CASE | [generic] | Name the number, the counting rule, and the weakest assumption in it. No past claim is made here | A live problem. A prober checks whether your numbers have denominators |

### E. Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A student is reading two years below grade level in October. Walk me through your first two weeks." | CASE | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Clarify what you know about the student and what you would check. Then plan, and say who on the team you would bring in. If it fits, you may say "I've run the after-school reading club for the last two years" and describe only what you saw there | The live case for this role. The club is the one place your material touches it |
| E2 | "Reading and science share your class's block. What do you protect, and why?" | CASE | [generic] | Decide by what the standards require, then check with the team. Name the trade-off aloud | A live planning problem from the job |
| E3 | "The district replaces your reading program in your second year. What do you do first?" | CASE | [generic] | Understand the reason and the timeline first, then what the team needs, then your classroom | Tests sequence, not a past event. Asks about no past claim |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Illinois Professional Educator License with elementary endorsement | None, and why: the gate is met on your statement (F1). No question needed |
| Fourth-grade teaching (position title) | A1, A2, A5 |
| Team leadership (not listed; implied by the panel) | A3, A4 |
| Working with the fourth-grade team (panel) | C1, C2, C4 |
| Families (not listed) | C3 |

## Reverse questions

1. To the team members: "What would help a new fourth-grade teacher most in the first month?" Why it lands: reciprocity. It shows you are asking about their load, not only your job.
2. To the team members: "How does the team plan units together, and where do you see a new person fitting?" Why it lands: it asks about the seam without asserting one.
3. To the principal: "What would make this hire a success a year from now?" Why it lands: you learn the success measure, and A1 and A3 can target it.
4. To the principal: "What does the first ninety days look like for this role?" Why it lands: it invites a plan, which is the answer A1 and A3 give.
5. To the principal: "How does the grade team communicate with families, and what would you want from the weekly family emails?" Why it lands: it ties your one family-facing record (F4) to their practice.

## Sources

- Provided: the invite and your resume, as pasted in your message.
- **Research tier: L0.** No searches or fetches ran this turn.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering values | unavailable | Values cheat sheet, if a values-style round is detected |
| 2. Halvering interview process, fourth-grade role | unavailable | Loop structure and persona weights |
| 3. Orrinsford or Halvering strategy and recent news | unavailable | Company and strategy questions, none written yet |
| 4. Dolores Vantongeren, Halvering | unavailable | Interviewer read and a tailored reverse question |
| 5. Representative fourth-grade teacher posting | unavailable | JD-tagged questions beyond the one requirement the invite gives |

## Upgrade menu

- The full job posting, or any HR note on what the panel will focus on → the requirement coverage table gets checked against the full list, and any new requirement gets its own question.
- Whether the panel expects a demonstration lesson or a written piece → a build section for it.
- The team members' names, if you know them → per-member persona weights.
- Research at L1 on the school's values and the district's reading program → a values section if values are published, and company-grounded questions.
- For the 2024 reading move: the materials, who chose them, and what you tracked → turns the answer slots in A4, B3 and D1 into rehearsed answers, in your own words.
