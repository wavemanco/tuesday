Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says you "deposit the cheque and send the balance on to the vendor." Paying a fee, depositing a cheque and sending passport or bank details before an offer are a known scam pattern, and this invite is very likely a scam. Hold all three until you have checked the invite with the employer, using a phone number or address from the company's own website or careers page, not the email or contact details in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-12-denied-c319f1b3/22245826-4b6f-43cb-8352-fd9cd0d2c905/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager. No name was given, so the interviewer read is missing.

**What to expect**
- Live admin problems rather than a chat about you: a travel booking, a double-booking, an invoice with no purchase order.
- Your strongest line is the appointment book for four physios. Your weakest is supplier invoices. You chased unpaid ones, but your material doesn't show you processing supplier invoices, so expect that to come up.
- Expect a request for a Word or Excel example. Have one ready, or say plainly that you don't have one.
- Expect a travel question. Your material has nothing on booking travel, so say that and say how you'd learn it.

**How to prepare**
1. Rehearse question B2 out loud until "I chased unpaid invoices" and your concession come out in your own words.
2. Practise A1 to A4 out loud, about 90 seconds each.
3. Prepare one real Word or Excel example, or decide how you'll honestly say you don't have one.
4. Pick three reverse questions from the pack to ask at the end.

I couldn't run web searches in this session, so I haven't checked whether Brennock Facilities Ltd exists. The pack has 15 questions, fewer than usual, because a 30-minute call can't cover more.

Want a drill? Tell me which question and I'll play the office manager. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.

Can you paste the full advert text? The pack currently quotes your summary of it, and the full text would let me check hours and location too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Remote Administrative Assistant, Brennock Facilities Ltd: interview pack

Interviewer: office manager (name not given). Round: 30-minute video call. Relationship: hiring manager. No values round, graded deliverable, or interviewer profile was given, so those sections are left out.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is scored.
- Type key: **VAL** values; **EXP** work experience; **JD** role requirement; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Say answers in your own words.

## Fit snapshot

Requirements are the duties in your summary of the advert. Quotes are your own words, with their source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words already reach calendar work. Bridge: "I ran the appointment book for four physios." Nothing added. |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: if you have booked travel for someone, say what and for whom, in your own words; if not, say so plainly and say how you would learn the booking steps. |
| F3 | "preparing documents in Word and Excel" — your message | "good with Word" — your message; "okay with Excel" — your message | low | [inferred] | discovery | Both are self-ratings with no example behind them, so the pack asserts no skill level. Answer slot: name one document you prepared in Word and one thing you did in Excel, and what each did; if you have none, say so plainly and say what you would practise first. |
| F4 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is the nearest thing, but it is not processing supplier invoices. Bridge stays at your scope: "I chased unpaid invoices." Answer slot: if you ever entered, matched or paid a supplier invoice, say how, in your own words; if not, say so plainly and name the step you would learn first. |
| F5 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Your material says nothing about remote working. Answer slot: if you have worked remotely with calendars, travel or documents, say how; if not, say so plainly and say what you would set up first. |

Your material does not show the role's location, hours or schedule. Those are checked against the full advert (see the upgrade menu).

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live admin problems: a travel booking, a double-booking, an invoice with no purchase order | High. The office manager runs these tasks, and a hiring-manager round for a duties-based role tests them | Clarify, then structure: check, options, confirm |
| Skeptic | "I don't see supplier invoice processing in your background" | High for that bank. Invoices are the duty your material touches least | Hold one sentence, concede the gap plainly |
| Data-Driven Prober | Asks for an Excel example or a count | Medium. Your Excel claim is self-rated and unshown | Name what you built; say when you do not know |
| Conversational | Opener and close | Medium. A 30-minute call starts and ends with easy questions, and they are still scored | 90-second background; treat casual questions as scored |
| Pressure | Not weighted | No signal in the material. A 30-minute call may still bring one | Pause, restate, hold through two follow-ups |

Weights: Case 5 questions, Skeptic 4, Prober 3, Conversational 3. The total is 15, below the usual range, because a 30-minute call cannot rehearse more. The upgrade menu lists what would add depth.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A director needs a flight to Cork for a client meeting on a Thursday, and her calendar is already full. How would you handle it?" | CASE | [generic] | Clarify the budget, the travel policy and whether times can move. Offer two options with the cost and trade-off of each. Confirm with the traveller before booking. Say what you would check first. | A live booking problem from the travel and calendar duties. [generic] because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Two meetings are double-booked for the same person tomorrow morning. What do you do?" | CASE | [generic] | Decide which meeting has priority. Contact both organisers before anything moves. Record the change where the diary is kept. | Calendar management is the first duty in the advert. Your material has no double-booking, so the answer is process. |
| A3 | "A supplier invoice arrives with no purchase order number. Walk me through what you do." | CASE | [generic] | Hold it. Check the purchase order list and who approves. Match the supplier against the vendor list before anything is paid. Ask the supplier for the number. | Covers the invoice duty directly. The rationale is the process, not your history. |
| A4 | "You have two days to prepare a board pack in Word and Excel. What is your plan?" | CASE | [generic] | Clarify the format and template first. Ask for inputs early. Build a checklist and leave time for one review. | Covers the Word and Excel duty, asked as a plan. |
| A5 | "A supplier emails asking you to change its bank details. What do you do?" | CASE | [generic] | Do not act on the email. Confirm the change by phone, using a number already on file, and get it approved before anything changes. | A standard invoice control. A strong answer here shows you would catch this. The answer is a control, not your history. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" — your message | Start from the sentence your material holds: "I chased unpaid invoices." Then name the step you would learn first. Answer slot: if you have entered, matched or paid a supplier invoice, say how, in your own words; if not, say so plainly. | F4 is where the duties are thinnest, and the honest answer is the limit plus a plan. |
| B2 | "I don't see supplier invoice processing in your background. How would you handle that part of the role?" | JD | [grounded] "chased unpaid invoices" — your message | Highest-ROI prep in this pack. Hold with "I chased unpaid invoices." Hold through two follow-ups by returning to that sentence, not by adding to it. Concede the gap in one line, without folding. Answer slot: if you have processed supplier invoices, say how and when; if not, say what you would learn first and how. | The gap a skeptic presses is the invoice duty, and your material is thin there. A plain, limited answer lands better than a stretched one. |
| B3 | "Why leave a receptionist job for an admin role?" | EXP | [generic] | Answer slot: give your actual reason, and what you want from the next role, in the words you would use. The pack does not supply one. | Every skeptic runs this check. Your material does not say why you are moving, so the answer has to come from you. |
| B4 | "Have you booked travel for anyone? Tell me about it." | JD | [grounded] "booking travel" — your message | Answer slot: if you have booked travel for someone, say what and for whom, in your own words; if not, say so plainly and say how you would learn the booking steps and approvals. Do not describe a booking you did not make. | Booking travel is a stated duty with no quote in your material. It is a gap to name, not to bridge. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you describe your Excel? What have you actually built in it?" | JD | [grounded] "okay with Excel" — your message | Use your own words: "I'm okay with Excel." Then name one thing you built or changed. If nothing comes to mind, say so plainly and say what you would practise first. Do not claim more than "okay". | The Excel claim is self-rated and unshown, so a prober will ask for an example. |
| C2 | "How many bookings did you handle a week in the appointment book, and how did you know?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Answer slot: if you know the number, give it and how you counted it. If not, say so plainly and say what you could see. Do not estimate a figure you cannot back. | A count you did not give raises no number. The honest answer is the one you can defend. |
| C3 | "How would you match a list of supplier invoices against a list of payments in Excel?" | CASE | [generic] | Name the approach: a lookup against a shared reference column, then a check that the totals agree. Say which functions you know. If you do not know them, say so and name how you would learn them. | A spreadsheet task from the invoice duty. No past claim is made. |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | A 90-second arc: the two years, the appointment book for four physios, the unpaid invoices you chased, Word and Excel, then why this role. Use only those facts, in your own words. | A friendly opener that is still scored. The arc uses only what you have given. |
| D2 | "What did the appointment book involve day to day?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Describe the tasks you did, in your own words. Add nothing you did not do. | Premised on your own sentence, so it is a fair question. Your answer is the calendar evidence for F1. |
| D3 | "What did chasing unpaid invoices involve?" | EXP | [grounded] "chased unpaid invoices" — your message | Describe the steps you took, in your own words. If you did not chase them yourself, say so. | The nearest thing to invoice work in your material. This is where a follow-up on F4 will start. |

Requirement coverage:

| Requirement | Questions |
|---|---|
| managing calendars | A1, A2, D2 |
| booking travel | A1, B4 |
| preparing documents in Word and Excel | A4, C1, C3 |
| processing supplier invoices | A3, A5, B1, B2, D3 |

## Prohibited claims

Built locally from the fit snapshot. No answer, hold or rationale may assert these.

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F4: "chased unpaid invoices" widened to the duty | F4's quote at its own scope: "I chased unpaid invoices." Your material says chasing, not processing. |
| Booked travel, or managed a director's diary | Inflated form of F1 and F2: "the appointment book" widened to executive travel, which is not in the material | "I ran the appointment book for four physios." Nothing on travel. |
| Strong Excel or advanced Word | Inflated form of "okay with Excel" and "good with Word" | Your own words: "okay with Excel", "good with Word". |

## Reverse questions

Each one lands for a reason:

1. "What does a normal week look like for whoever holds this role?" Shows you are interested in the work itself.
2. "Which of the four duties would I own from day one, and which would I shadow?" Shows you are planning your start.
3. "How is a supplier invoice checked and approved before it is paid?" Shows you know approval controls matter in this work.
4. "What tools do you use for calendars, travel bookings and documents?" Shows you want to get up to speed quickly.
5. "What would make the first three months a success for you?" Lets the office manager describe the job as they see it.

## Sources

- Provided: your message (the advert as you summarised it, your background, and the invite's own words).
- Searches: none run. Web search was not permitted in this session, so I could not check whether the company or its website exists.
- Research tier: L0, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Values cheat sheet, not included |
| 2. Interview process for this role family | unavailable | Loop structure; persona weights use relationship priors instead |
| 3. Company strategy and recent news | unavailable | Company and strategy questions; none included |
| 4. Interviewer name and profile | n/a | No name was given, so there was no query to form |
| 5. Representative JD for the title | skipped | The advert summary fixes the requirements |

## Upgrade menu

- The full advert text → the fit snapshot quotes the advert's own words instead of your summary, and the hours and location can be checked.
- One sentence on any Word or Excel document you have made → F3 gets a grounded line in place of an answer slot.
- The interviewer's name → a reverse question tailored to the office manager's path, and persona weights from their public footprint.
