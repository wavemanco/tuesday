Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-9-canned-b654e7f9/9ed56998-dea4-4719-a718-83204006cf5f/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. It's built from the invite and your notes. I did not run web research, so the school's values and interview format aren't in it.

You also included your Social Security number. I didn't use it or repeat it, and interview prep doesn't need it. Keep it off résumés and emails you send to employers.

**The main thing to prepare:** you haven't taught fourth grade, and the panel will likely ask about it first. Say it plainly, in your own words: "I haven't taught fourth grade." Then describe your six years of third grade and your plan for learning the fourth-grade year. Don't defend the gap, and don't claim any fourth-grade experience.

**Other points:**
- **Your license meets the requirement on your materials.** Check its status on the state's educator license lookup before Thursday.
- **Story for the values and collaboration questions:** the 2024 move to the new reading curriculum. Know what you did and where your part ended.
- **Be ready to be asked about outcomes.** Your reading club and weekly family emails are strong, but the pack found no measured results for either. If you tracked anything, say what. If you didn't, say so.
- **Don't claim team-lead experience.** You told me you haven't been a team lead, so the pack doesn't coach any version of it.
- **Reverse questions:** the pack has five, including one for the team members about what a new teacher could do in the first month.

Would you paste the full job posting? It would let me add questions tied to the posting's own requirements and check that every requirement is covered. Also, would you like me to run a quick check on the principal, Dolores Vantongeren, from her public professional profile? That would add an interviewer read and adjust the question weights.

I can also play the principal's skeptical questions in a practice round, and save a `tuesday-dossier.md` with the gaps this prep found, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Interview: 45-minute panel on Thursday. Panel: Principal Dolores Vantongeren, plus two members of the fourth-grade team.
Built on: the invite and your resume and notes. No posting text and no web research were used this run, so requirements, values and process are marked `[grounded]` (from your documents) or `[generic]` (role-family pattern).

## How to use

- **Personas** describe how a question will be asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the posting's requirements), CO (company knowledge), CASE (a live problem).
- The guidance is scaffolding, not a script. Say things in your own words.

## Prep triage

1. Rehearse A2 out loud until you can say the fourth-grade gap in one plain sentence without hedging. This is the question most likely to come up in some form.
2. Rehearse A3 and B1 once each with a real story and a real limit.
3. Prepare 4 or 5 reverse questions (section 9).
4. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met on your material. Confirm the status on the state's educator license lookup before Thursday, since the invite treats it as a gate. |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says third grade, for six years. It does not show fourth grade, so the bridge stops at third grade. Answer slot: if you have taught any fourth-grade content, say which; if you have not, say so plainly and say how you would learn the year's content first. |
| F3 | "two members of our fourth-grade team" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan, never as a past. |

**Pack's observation (analysis, not words for you):** your material does not show any fourth-grade teaching, any team-lead role, or any measured result from the 2024 curriculum move or the reading club.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Team lead, or leading the fourth-grade team | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV), plus your stated negative "I've never been a team lead" (your message) | The 2024 move, at its own scope. Plain acknowledgment: "I've never been a team lead." No slot about leading the team. |
| Fourth-grade teaching experience | Your stated negative "I've never taught fourth grade" (your message) | Plain acknowledgment: "I haven't taught fourth grade." |
| Improved reading results from the curriculum move or the club | Inflated form of the 2024 move and the club. No outcome is quoted anywhere | The move and the club, at their own scope. Say what you tracked if you tracked anything; if you did not, say so. |

## Persona weights

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | "You haven't taught fourth grade. Why should we take the risk?" | High: the panel's first job is to check the fourth-grade fit, and you have stated the gap yourself | Say the gap plainly, then the plan. Do not defend the gap. |
| Values / Behavioral | Principal | Stories of change and working with colleagues | Medium: a panel for a public-school position often scores against a competency framework. No framework was found, so this is an assumption | STAR-shaped story from your 2024 curriculum move |
| Peer Evaluator | Team members | How you would fit in, collaborate and disagree | High: two team members will ask about working with them | Describe how you work with a team, in your own words, with the 2024 move as the example |
| Data-Driven Prober | Team members | How you know reading work or family emails are working | Medium: your CV has a club and a weekly email, and neither has an outcome in it | Say what you counted, if anything; if nothing, say so |
| Case / Strategist | Any | A fourth-grade reading scenario | Medium: the role is a classroom role | Structure: assess, involve the team, check progress, tell the family |

## Question banks

### Principal (Skeptic and Values)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What would make fourth grade different for you?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Start from the six years of third grade. Say what carries over, then what you would need to learn about the fourth-grade year. Answer slot: if you have taught any fourth-grade content or standards, say which; if not, say so plainly and name how you would learn them first. | F2 is the bridge this question tests |
| A2 (highest ROI) | "You haven't taught fourth grade. Why should we take the risk?" | JD | [grounded] "I've never taught fourth grade" — your message; [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Say the negative in your own words: "I haven't taught fourth grade." Then the six years of third grade, in those terms. Hold through two follow-ups by returning to your plan for learning the year, never by adding to your experience. If pressed, concede specifically: "You're right that I would be learning the year's content." | F3 is the stated gap, and this is its most likely form |
| A3 | "Tell me about a time you worked with colleagues on a change that was hard." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Story from the 2024 move: a grade-level move to a new reading curriculum. Answer slot: if there was disagreement among colleagues, say what it was and what you did; if there was none, say so and describe how the move went as far as you know it. | Open prompt on a theme the panel is likely to score; the quote is the only story the material carries |
| A4 | "A parent is upset that their child was placed in a reading group. What do you do first?" | CASE | [generic] | Structure: what you would look at first, who you would involve, and what you would document. The question makes no claim about your past | A live problem of the kind a principal asks, `[generic]` because it is a pattern, not a fact about this school |

### Team members (Peer and Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you know your after-school reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say what you saw during the two years. Answer slot: if you counted attendance or reading levels, say what was counted; if you did not track outcomes, say so and say what you would track. | A Prober's question on a claim with no outcome quoted |
| B2 | "Tell us how you handled a disagreement with colleagues about instruction." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Use the 2024 move. Answer slot: if you disagreed with a colleague during it, say what the disagreement was and how it ended; if you did not, say so and describe how you worked the decision through. | A Peer's seam question, asked through the same story as A3 |
| B3 | "What do families get from your weekly emails, and how do you know?" | EXP | [grounded] "I write a weekly email to families" — your CV | Say what the email contains and how you know families read it, only if you have a way of knowing. If you do not, say so. | Prober's follow-up on a claim that has no evidence beyond the act of writing |
| B4 | "A fourth grader reads well below level in October. What do you do?" | CASE | [generic] | Structure: assess, talk with the team and what they have seen, monitor progress, and bring the family in. Name one thing you would check first | Live problem from the fourth-grade team's own work, `[generic]` |

Coverage: F1 is covered by no question, since the gate is met on your material. F2 is covered by A1 and A2. F3 is covered by A2. Team-lead and reading-result claims are covered by the prohibited list and by A3 and B1, which do not assert them.

## Reverse questions (5 required)

1. "How does the fourth-grade team plan together each week, and where does the principal come in?" Why it lands: it shows you want to know how the team works before you join it.
2. "Which reading program does fourth grade use now?" Why it lands: you have led a reading curriculum move, and this asks what is in place without assuming a version.
3. "What has worked best for students who are reading below grade level here?" Why it lands: it asks for the team's knowledge, not yours.
4. "What would a successful first year look like for this role?" Why it lands: it gives the panel a chance to name its own expectation.
5. Peer reciprocity, for the team members: "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" Why it lands: it asks what you would bring to them.

## Upgrade menu

- The full posting text → JD-tagged questions and a complete requirement-coverage check (the invite alone names only the license and the role)
- Research on the district's competency framework or values, if published → a values cheat sheet, which this pack cannot build without it
- The principal's and team members' names → persona weights from their public footprint (the principal's name is in your invite; research was not run this turn)
- Any note from HR on what the panel will focus on → coverage of those areas
