Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-5/rooms/case-9-canned-aa096e5f/halvering_fourth-grade-teacher_interview_pack.md`. It's built from the invitation and your resume, with no job posting and no research behind it.

Your resume block includes your Social Security number. I haven't used it, and the interview doesn't need it. Keep it off any resume or application you send.

The pack's main points:

- **Lead with the plain line.** You've never taught fourth grade, and you haven't been a team lead. Say each as a fact, then give your plan: the grade's standards, the team's unit sequence, what you'd observe in your first week. The principal is the most likely to press on this, so it's the question to rehearse hardest (A1 and A2).
- **Your strongest material is the 2024 reading curriculum change and the reading club.** Stay within those sentences. Don't describe them as team leadership or a reading program, and don't add outcomes you can't back. The team members will likely ask how you know the club works (B3). Have an answer ready, even if it's "I didn't track it formally."
- **Panel shape:** the principal will likely run the skeptic and case questions, and the two team members the peer and data questions. Your family email is a one-line claim, so expect a probe on whether it reaches families (D2).
- **Reverse questions** are in the pack. Ask about the team's reading unit planning and what a new teacher should do in the first month.

The pack has 14 questions, short of the usual 18 to 26, because I didn't have the posting. If you paste it, I'll add the requirements it names.

Drill: I can play the principal and run A1 with follow-ups, then give feedback against that question's guidance.

Dossier: I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Three questions:
1. Can you paste the full job posting?
2. Is Thursday's panel in person or by video? Did HR name any focus areas or a sample lesson?
3. How much time do you have before Thursday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District)

Panel, 45 minutes, Thursday. Principal Dolores Vantongeren, plus two members of the fourth-grade team. Built from the invitation and your resume as you wrote it. No job posting was supplied and no research was run, so there are no values, loop-structure or district-specific sections.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your experience), JD (the role), CASE (a live problem), VAL (values), CO (company knowledge). No VAL or CO questions appear because no research was run.
- Guidance is scaffolding, not a script. Say everything in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "the Fourth Grade Teacher position" (invitation) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Words: "I haven't taught fourth grade." Then how you would learn it, as a plan: the grade's standards and the team's unit sequence, which you would ask to see first. Never a claim to fourth-grade experience. |
| F2 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. State the license, endorsement and expiry in those words. |
| F3 | Reading instruction in an elementary grade (role family, no quoted requirement) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Your material already reaches reading instruction. The bridge only rewords these two sentences. It adds no outcome, figure or event the material does not state. |
| F4 | Leadership on a grade team (role family, no quoted requirement) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Then the nearest true thing, at its own scope: "I led our grade level's move to a new reading curriculum in 2024," described in your words. |
| F5 | Communication with families (role family, no quoted requirement) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | The quote already reaches it. One CV line with nothing shown behind it, so expect a probe (D2). |

The invitation names no other requirement. The panel's questions may go beyond it, and the question banks cover those.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Presses the fourth-grade gap and the team-lead gap | Highest. The principal is the hiring-manager type, and F1 and F4 are the two gaps any panel would see first | Say the plain line first, then the plan. Hold the bridge to what you did in third grade |
| Case / Strategist (principal) | Live problems from a fourth-grade classroom and team | Medium-high. Hiring managers usually test the job with a scenario | Clarify, then structure, then name a first step. Cite the reading club only in its own words |
| Peer Evaluator (team members) | Where the seam is, what you would need from them, disagreement | High. Peers price what a new person costs their work | Reciprocity: name one real need and one thing you would bring |
| Data-Driven Prober (team members) | Asks how the reading club and the family email were measured | Medium. Neither has a figure on the page, so probes go to the evidence behind them | Say what you tracked. If nothing, say so and say what you would track |
| Conversational (opener) | "Tell us about your path" | Medium. Panels often open this way | A 90-second arc in your own sentences |

Weights are relationship priors only. No interviewer profile was researched, and no team member names were given.

## Question banks

### Persona A: Skeptic (principal, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth-grade teaching in your background. How would you handle that in this role?" | JD | [grounded] "I've never taught fourth grade" (your message) | Open with the plain line: "I haven't taught fourth grade." Then the plan: the grade's standards and the team's unit sequence, which you would ask to see in your first week, and what you would observe in the classroom. Adjacent work only: "Six years teaching third grade at a public elementary school in Joliet" (your CV), with no claim that it equals fourth grade. | F1 is the gap most likely to be raised and the highest-return prep in this pack. Rehearse the plain line until it comes out without apology. |
| A2 | "You haven't been a team lead. What would you do in your first term on a grade team?" | JD | [grounded] "I've never been a team lead" (your message) | Say "I haven't been a team lead." Then the nearest true thing: "I led our grade level's move to a new reading curriculum in 2024" (your CV), described in your own words. Answer slot: if you set the steps or ran the meetings, say which and how you decided. If you did not, say so plainly and describe how you would contribute to the team's decisions. | F4 is a stated negative and the most likely probe from the principal. |
| A3 | "Why fourth grade, and why this school?" | JD | [generic] | Answer slot: if you have a specific reason for moving to fourth grade, give it in your own words. If not, say what draws you to the grade and what you know about the school from its public materials. Supply no reason for them. | A motivation probe. The question makes no claim about your past. |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name the fourth-grade content and the team's unit planning as the honest gap, then your learning plan. | F1 again, in the Skeptic's form. Naming the gap first is better than having it named for you. |

### Persona C: Case / Strategist (principal, medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A group of your fourth graders is well behind on reading comprehension by January. What do you do in the first two weeks?" | CASE | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Clarify first: what the data shows, which assessment, which students. Then small groups, the team's common assessments, and a check at two weeks. Mention the reading club only in those words, if at all. | A live problem from the role. It makes no claim about your past beyond the quoted club. |
| C2 | "Our grade team is adopting a new math program next fall. How would you bring the team along?" | CASE | [generic] | Structure it: what the team already uses, who has concerns, and a pilot unit before full adoption. | A case-led question with no claim about you. |
| C3 | "Tell us about the 2024 reading curriculum change. What was your part in it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold that sentence's scope: a grade-level move you led. Answer slot: if you chose the program, set the timeline or ran the training, say which and how you decided. If you did not, say so plainly and describe your part. | Built on F3's own quote. The answer slot lets the honest branch be the answer. |

### Persona B: Peer Evaluator (team members, medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where would you need the most help from our team, and what could you bring to it?" | JD | [grounded] "I write a weekly email to families" (your CV) | Need: name one real gap, such as the fourth-grade unit sequence. Bring: the weekly family email, described as your practice, offered as something the team may want. Not as a finished contribution. | Reciprocity. The peers are pricing what you add to their work. |
| B2 | "Tell me about a time you disagreed with colleagues on how to teach something." | EXP | [generic] | Open prompt. Pick a real disagreement. If the nearest instance is the 2024 change, describe only what its quote carries: a grade-level move. If no real disagreement comes to mind, say so plainly, then describe how you would handle one with equals. | A seam probe from the peer stem. |
| B3 | "How would you tell whether the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything, such as attendance, reading levels or reports, name it in your own words and say what it could not show. If you tracked nothing formally, say so and describe what you would track next. | The club is your strongest evidence and its effect is not stated, so the probe lands there. |

### Persona D: Data-Driven Prober (team members, lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which numbers from your classroom would you defend if asked how they were counted?" | EXP | [generic] | Answer slot: the material shows no classroom figures. If you have one, say how it was counted and which assumption you would defend least. If you have none, say so and name the measure you would use first. | The prober's stem. A CV with no figures still gets probed. |
| D2 | "How do you know whether your weekly family email reaches the families it's for?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Answer slot: if you have seen replies, opens or any effect on attendance, say which. If not, say so and say what you would ask families. | The line makes a claim the probe will test. |

### Persona E: Conversational (opener, lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, tell us about your path into teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc, in this order: Joliet, six years of third grade, the 2024 reading change, the reading club, then one sentence on why fourth grade. Use only those sentences. | An opener is still scored. A tight first answer sets the tone for the rest. |
| E2 | "Is there anything about your classroom you'd like us to know that isn't on your application?" | EXP | [generic] | Answer slot: give one thing from your own experience. Do not invent one. | Rapport openers score the close. |

Session total: 14 questions. That is under the usual 18 to 26, because the posting was not supplied and no research was run, so the banks cover only what the invitation and your resume give.

## Requirement coverage

- Illinois PEL with elementary endorsement (invitation): F2, no question. The material shows it met.
- Fourth Grade Teacher position (invitation): A1, A4.
- Grade-team leadership (role family): A2, C3.
- Reading instruction (role family): C1, C3, B3.
- Family communication (role family): B1, D2.
- Team and panel: B1, B2, reverse questions below.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Stated negative (F1) | "I haven't taught fourth grade." No slot. |
| Leading the grade team | Inflated form of F4. The 2024 change was a curriculum move, and the material does not show team leadership | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Limit, in analysis: your material says the move, not team leadership. |
| Running a reading program, or reading specialist | Inflated form of F3. Your material shows a curriculum change and an after-school club | Both quotes at their own scope, with nothing added. |

## Reverse questions

1. "How does your fourth-grade team usually plan reading units?" Why it lands: it shows you are planning around their process, not asking for a job description.
2. "What would a new teacher on the team do in the first month that would help you most?" Why it lands: a peer reciprocity question. It asks what you can give, not only what you need.
3. "How did the school choose its current reading curriculum, and who has to agree to change it?" Why it lands: it connects to your 2024 change, asked as their process.
4. "What does a strong first semester look like in this position?" Why it lands: it answers the day-one probe from their side.
5. "How does the principal support teachers who are new to a grade?" Why it lands: it is aimed at the principal and at the gap in F1, and it asks about support, not about your weakness.

## Sources

- Provided documents: the invitation; the resume in your message.
- Research tier: L0. No search or fetch was run for this pack. The values, interview-process, strategy, interviewer and representative-JD targets were not run.

## Upgrade menu

- The full posting for Fourth Grade Teacher → real requirement lines in place of the invitation's two, so more rows become `[grounded]` and new JD questions appear.
- Any focus areas or sample lesson HR gave → coverage of anything they announce.
- Public research on Orrinsford Community School District and Halvering Elementary (L1) → district values, the reading program's language and the panel's likely structure. Currently absent.
- Public background for Principal Dolores Vantongeren → a tailored reverse question and persona weights from public information.
- The team members' names and roles → per-member persona weights.
- The figures and how they were counted for the reading club or the 2024 change → the answer slots in B3, C3 and D1 become grounded answers.
