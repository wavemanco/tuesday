Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-9-canned-cb0807c5/503ce3b4-533d-4ced-a509-b67dcc56f665/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md.

Your resume lines included a Social Security number. I didn't use it or repeat it, since interview prep doesn't need it. Remove it from any resume you send.

The district's hiring page says Orrinsford panels are 45 minutes with the principal and two grade-level teachers, and that they ask about reading instruction, classroom routines and how you work with families. Your two stated gaps, never teaching fourth grade and never being a team lead, are the likeliest probes, so rehearse questions A1 and A4 first. Your license requirement is met on your CV, so bring a copy.

Say the word and I'll run a drill with the principal as the Skeptic on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word if you want it.

Does the school give a written list of panel questions or a scoring sheet?
Do you have the full text of the posting? It would tighten the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Changelog: first version.

Panel: 45 minutes on Thursday with Principal Dolores Vantongeren and two fourth-grade team members (names not given).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience, checked for accuracy), JD (the role's listed duties), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say answers in your own words.

## Research used

- Searches: 2 of 6 (L1 default). Fetches: 1 of 2.
- Source: https://orrinsfordschools.example/careers/how-we-hire-teachers says: "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel."

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. Bring a copy of the license or its ISBE lookup page, since the panel may ask. |
| F2 | "Panels ask about reading instruction" (district hiring page) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Your two lines already reach reading instruction. Say what each one was in your own words. |
| F3 | "how you work with families" (district hiring page) | "I write a weekly email to families" (your CV) | medium | [grounded] | presentation | Your line says the email, not what it covers. Bridge uses only that sentence. Answer slot: if you can say what the weekly email contains, say it in your own words. |
| F4 | Fourth-grade teaching experience (invite: "Fourth Grade Teacher position") | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan, never as a past. |
| F5 | Team leadership (inferred from panel with grade-level team) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Then how you would work with a team, said as a plan. |
| F6 | "classroom routines" (district hiring page) | none given | none | [grounded] | discovery | Your material does not show routines. Answer slot: if you can describe a routine you ran in your own classroom, say it; if not, say so and describe how you would learn the grade's routines. |

Note: F4 and F5 are gaps you stated. Your six years of third grade (below) is adjacent work, so it bridges to fourth grade only as "Six years teaching third grade at a public elementary school in Joliet", stated at its own scope.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F4 | "I haven't taught fourth grade." No slot. |
| Has led a team | Negative you stated, F5 | "I haven't been a team lead." No slot. |
| Led reading adoption for the district | Inflated form of F2 | Your line at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material says your grade level, not the district. |
| Measured reading outcomes | Silence, not listed; F6 covers it as an answer slot | Not coached. If you tracked a result, say what and how you counted it. |

## Persona weights

- **Principal (Dolores Vantongeren):** Case/Strategist and Skeptic, because the principal is buying capability and checking the two gaps. Reasoning: the panel's fourth-grade and team-lead gaps are for the principal to judge.
- **Two team members (names not given):** Peer Evaluator and Data-Driven Prober, because grade-level teachers price what a new hire does to their planning. Reasoning: a grade-level team sees the reading curriculum from the inside.
- No public footprint was found for Principal Vantongeren. The interviewer read is absent; the upgrade menu says what a name would unlock.

## Question banks

### A. Principal (Case/Strategist and Skeptic, weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What would your first month look like?" | JD | [grounded] "I've never taught fourth grade" (your message) | Open with "I haven't taught fourth grade." Then a plan: the first week's observations, the grade's standards and the team's planning. Say the plan as a plan, not a past. | F4 is the likeliest objection; rehearse it until it's plain. |
| A2 | "Tell me about the new reading curriculum your grade level adopted." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Tell the move in your own words: what it was, when (2024), and that you led your grade level's move. Answer slot: if you did specific steps (training, pilot, rollout), name them and say how you decided; if a step was not yours, say so. | F2 is the strongest evidence for reading instruction; EXP because it tests what you actually did. |
| A3 | "A fourth grader reads at a second-grade level and the team disagrees on the plan. What do you do?" | CASE | [generic] | Structure: what you would look at first, who you would ask, how you would decide, what you would record. Make no claim about your past. | A live problem from the reading topic on the district page. |
| A4 | "You haven't led a team before. How would you work with two colleagues who have taught this grade longer?" | JD | [grounded] "I've never been a team lead" (your message) | Open with "I haven't been a team lead." Then how you would ask them about the grade's practice first, and how you would share planning. Say as a plan. | F5 is a stated gap; the question is fair and expected. |
| A5 | "How do you keep families informed about their child's reading progress?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe the weekly email in your own words: its purpose and what you include. Answer slot: if the email shows progress, say what it shows; if it does not, say so. | F3 is thin: the email is evidence, the content is not in your material. |

### B. Team members (Peer Evaluator and Data-Driven Prober, weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How are you deciding whether the new reading curriculum is working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you tracked, in your own words. Answer slot: if you tracked a measure, name it and how you counted it; if not, say so plainly and say what you would track first. | A prober's likely follow-up on F2. |
| B2 | "Our team plans together every week. What would you need from us in your first month?" | CO | [generic] | Name what you would need: the planning calendar, the shared materials, the grade's pacing. Ask it back as a question, not as a demand. | Peer reciprocity: what you bring the team, not just what you need. |
| B3 | "What does your after-school reading club look like week to week?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe the club in your own words: format, students, and what you do. Answer slot: if you have counts or results, say how you counted them. | Premised on your CV line; the prober will ask for the detail. |
| B4 | "When your team disagreed on a reading approach, how did you handle it?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with colleagues about instruction, say what you proposed, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | Tests collaboration; the answer must be a real occasion, not a claim. |
| B5 | "How do you keep families informed when a child is struggling?" | VAL | [grounded] "I write a weekly email to families" (your CV) | Describe what the weekly email does for a struggling child, only if you did it. If not, say how you would reach families. | Tests family communication from the district page; F3's answer slot applies. |

### C. Pressure (weight low, one question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire someone who has never taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Hold: "Six years teaching third grade at a public elementary school in Joliet" is your strongest line. Concede: "I haven't taught fourth grade." Do not fold on the six years. | Hold-then-concede on F4. |

### D. Conversational (weight low, one question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your journey to here." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Keep to 90 seconds: third grade in Joliet, then the reading work and the club, then why fourth grade. | Panels open casually; the answer is scored. |

## Reverse questions

1. "What does a typical week of reading instruction look like across the fourth-grade team?" Why it lands: shows you want the real routine.
2. "How does planning get split across the grade, and where would a new teacher fit?" Why it lands: it's the question a team member can answer.
3. "What has worked for family communication across the grade?" Why it lands: ties to the district page's topic.
4. "What would a strong first semester look like to you, Principal Vantongeren?" Why it lands: asks for the principal's own standard.
5. "What support does the district give a teacher new to a grade?" Why it lands: it shows you plan for the gap you stated.
6. Peer reciprocity: "What could a new person do in the first month that would genuinely help your team?" Why it lands: it asks what you can bring, not only what you need.

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Illinois PEL with elementary endorsement | none, and why: met on your CV, so the panel is not expected to probe it | F1 |
| Reading instruction | A2, B1, B3, A3 | F2 |
| Working with families | A5, B5 | F3 |
| Classroom routines | none, and why: no quote in your material shows routines | F6 is an answer slot only |
| Fourth-grade teaching | A1, C1 | F4 |
| Team leadership | A4, B4 | F5 |

## Sources

- Provided documents: the invite text, your resume lines and your message.
- Search: "Halvering Elementary School Orrinsford Community School District": no results.
- Search: "Orrinsford Community School District fourth grade teacher interview": returned the district hiring page.
- Fetch: https://orrinsfordschools.example/careers/how-we-hire-teachers: read.

Target accounting: rows 1 and 2 (values, interview process) yes; row 3 (strategy/news) skipped, because nothing the panel needs would change; row 4 (interviewer name) n/a for the team members, and no public footprint found for Principal Vantongeren; row 5 (representative JD) skipped, because you have the invite and no JD.

## Upgrade menu

- A copy of the posting or JD → six [grounded] requirements become exact and the coverage table fills out
- The team members' names → a read of each member's public footprint and tailored reverse questions
- Any panel question list or scoring rubric → the question banks check against it
- Principal Vantongeren's public footprint → persona weights for the principal
