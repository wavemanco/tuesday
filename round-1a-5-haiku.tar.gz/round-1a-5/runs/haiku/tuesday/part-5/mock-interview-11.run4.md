Before the prep, one thing in the invite. It says "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed," and it came from a number you don't recognise. A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked, don't pay anything, send documents, or share bank details through this chat.

To check, find the company yourself through the contact details on its own website or careers page, not anything in the message. Ask them whether they're recruiting for this role and whether Jess works for them.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Which company and which role was this for? I need both to build the prep pack, and I'll start on it as soon as you tell me.