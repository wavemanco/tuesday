Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-tuesday-part-5-rooms-case-13-denied-2a65c1e2/af7f179e-a394-4243-af0a-7667718b7785/scratchpad/Quillmoor-Diagnostics_operations-coordinator_interview_pack.md`.

The four topics Hannah named, with your own words from your message:
- **Pay:** "I'm hoping for £42,000." That sits inside the advertised £38,000 to £44,000.
- **Hybrid:** "Two days at Avonmouth is fine for me. I wouldn't want more than three."
- **Reason for moving:** "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say that, then stop.
- **Notice period:** your material doesn't include it, so the pack gives you no figure. Give your actual notice period.

On the SAP gap: say "I've never used SAP," then describe your in-house stock system without stretching it into an ERP. The bigger risk is production scheduling across planning, warehouse and QA. Your experience is delivery scheduling across three depots, so rehearse the answer that says that plainly and names what you'd do first. That is the highest-return prep in the pack.

The pack is shorter than my usual target because a 30-minute recruiter screen covers a narrow set of topics. I didn't run web research for this, so it doesn't include anything about Quillmoor beyond the advert.

Two offers, neither pushed:
- I can run a live drill with me playing Hannah, starting with the production-scheduling question.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Question:** What's your notice period, in weeks or months?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor-Diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics (recruiter screen)

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). Relationship: recruiter. She has said she will cover salary expectations, notice period, how the hybrid pattern would work, the reason for moving, then the team and next steps.

## How to use this pack

Personas are how a question arrives. Types are what is being scored: **JD** (the listed job's terms and requirements), **EXP** (what you actually did), **CASE**, **VAL**, **CO**. Guidance is scaffolding, not a script. Where a cell says "your own words", say it the way you said it to me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | None needed. Words: "I've had four years as a logistics coordinator." |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots" (your message); "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Covered at the scope you gave. Limited inspectable proof, so expect a probe on volume. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" (your message); "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Covered. The one-third figure raises a defend-the-number slot (B3). |
| F4 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | Your material says a spreadsheet, not Excel skills as such. Words: "I rebuilt our stock-count spreadsheet." Name any specific Excel features you used only if you actually used them (C3). |
| F5 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Delivery scheduling across depots is adjacent to production scheduling; it is not the same work. Words at its own scope: "I schedule deliveries for three depots." Any wider step is an answer slot (B1). |
| F6 | "ERP (SAP or similar) a plus" (advert) | "Never used SAP" (your message) | none | [grounded] | capability | A stated absence, so the words are a plain acknowledgment: "I've never used SAP." Not bridged. |
| F7 | "ERP (SAP or similar)" (advert) | "we run our own in-house stock system" (your message) | low | [inferred] | transferability | Adjacent to an ERP, but the material does not say it plans or purchases as well as stocks. Words at its own scope: "We run our own in-house stock system." Wider scope is an answer slot (B2). |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own constraint, met by the posting. Words: "Two days at Avonmouth is fine for me. I wouldn't want more than three." |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advertised range. Words: "I'm hoping for £42,000." |
| F10 | Notice period (recruiter's own words: "your notice period") | none given. Your material does not establish your notice period. | none | [grounded] | hard_gate | Surfaced, not bridged. The one question in this pack asks for it (see the upgrade menu). |
| F11 | Reason for moving (recruiter's own words: "what's prompting a move") | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own reason, in your own words. Nothing to add. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any SAP or ERP experience | Negative you stated (F6) | "I've never used SAP." No slot. |
| Owning production scheduling across planning, warehouse and QA | Inflated form of F5. Your material says delivery scheduling for three depots. | "I schedule deliveries for three depots." The limit is this pack's observation, not a line for you to say. |
| The in-house system as an ERP that plans or purchases | Inflated form of F7 | "We run our own in-house stock system." |
| The one-third reduction as company-wide, or as yours alone | Inflated form of F3 | "Discrepancies fell by about a third over a year." |

## Personas

| Persona | How it shows up in this call | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Opens with "talk me through your background" and the pay and notice questions in a friendly register | High. A recruiter screen is run this way, and the logistics answers are scored | Rehearse the 90-second background; treat the logistics answers as scored, not as small talk |
| Skeptic | Probes the production-planning gap and the SAP gap, and asks why you are leaving | Medium. The two gaps are the most likely reasons a recruiter would not put you forward | Hold the facts, concede the gaps plainly, do not bridge past what you did |
| Data-Driven Prober | Asks how the one-third figure was counted and what was counted per depot | Medium. One headline number, stated in a CV-style line | Say what you know about how it was counted, and say so when you do not |
| Pressure / Stress Interviewer | Pushes on fit with only two of the listed requirements well covered | Low for a recruiter screen, but worth one rehearsal | Restate, hold the core claim through two follow-ups, concede the specific gap |

## Question banks

### Conversational / Rapport Builder (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots" (your message) | Open with the role and the years, then the three depots, in those words. About 90 seconds. | Opener; covers F1 and F2 |
| A2 | "What does your current role involve day to day?" | JD | [grounded] "chase suppliers when orders slip" (your message) | Describe the scheduling and the supplier chasing in your own words, and stop there. | F2 is the requirement for supplier deliveries and late orders |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Logistics slot. Give your figure in your own words: "I'm hoping for £42,000." If asked what you earn now: "I'd rather focus on the range for this role." Do not add a reason, a floor or flexibility. | Pay is a logistics slot. Your figure sits inside the advertised £38,000 to £44,000 range |
| A4 | "What's your notice period?" | JD | [grounded] "your notice period" (recruiter's own words, Hannah's message) | Logistics slot, and an instruction: give your actual notice period in weeks or months. Your material does not contain it, so the pack supplies no figure. | F10 is a term your material does not establish |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Logistics slot. Say it as your message says it, including the three-day limit. | F8 is your own constraint, met by the posting |

### Skeptic (weight: mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules across planning, the warehouse and QA. Where is that in your experience?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Name the delivery scheduling in those words. Answer slot: if you have coordinated timing across more than one team, say how, in your own words. If you have not, say so plainly and say what you would do first. | Highest-ROI prep in this pack. F5 is the gap, and the posting raises it directly |
| B2 | "The role uses SAP or a similar ERP. What have you used?" | JD | [grounded] "Never used SAP" and "we run our own in-house stock system" (your message) | "I've never used SAP. We run our own in-house stock system," then what it does, in your words. Answer slot: if the in-house system also handled planning or purchasing, say so; if it handled stock only, say that plainly. | F6 and F7. The SAP gap is a stated absence and is not bridged |
| B3 | "What did the discrepancy figure measure?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Say what was counted and over what period. Name the assumption you would defend least, in your own words. If you do not know how it was counted, say so. | Defend-the-number slot for the one headline figure on your material |
| B4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Logistics slot, quoted whole. If asked whether you would consider Reading: "which I don't want." Add nothing. | F11. The reason is yours and it is already complete |

### Data-Driven Prober (weight: low, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How many depots and deliveries did you schedule each week?" | EXP | [grounded] "I schedule deliveries for our three depots" (your message) | Say three depots, then the weekly count only if you know it. If you do not, say so. | Premise is only your three depots. No number is supplied |
| C2 | "Weekly on-time dispatch reporting is part of this role. Have you tracked on-time delivery?" | JD | none. Your material does not show it. | Answer slot: if you tracked on-time delivery, say how and how often. If you did not, say so plainly and say what you would track first. | JD requirement with no quote, so discovery |
| C3 | "What did you do in Excel, specifically?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Say what you rebuilt, in those words. Answer slot: name any specific Excel features you used. If your part was narrower than rebuilding it, say which part. | F4 |

### Pressure / Stress Interviewer (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You match only part of this role. Why should we go further?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Hold the core: four years of coordination and the delivery and supplier work. Pause, then hold through two follow-ups. Concede the production-planning and SAP gaps specifically, in the words of B1 and B2. | Hold-then-concede; the position held is one your quotes carry |
| D2 | "What's the weakest part of your fit?" | JD | [grounded] "Never used SAP" (your message) | Name the SAP gap first, plainly. Do not add a second gap you have not raised. | Honest self-assessment under pressure |

## Requirement coverage

| Stated requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules across planning, warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A2 |
| Keep stock records accurate | B3, C3 |
| Weekly on-time dispatch reporting | C2 |
| Confident with Excel | C3 |
| ERP (SAP or similar), a plus | B2 |
| Hybrid, two days at Avonmouth | A5 |
| Pay, £38,000 to £44,000 | A3 |
| Notice period (recruiter's topic) | A4 |
| Reason for moving (recruiter's topic) | B4 |

## Reverse questions

Each one has a reason it lands. Ask two or three; the rest are backup.

1. **What does the first month look like for this role?** Why it lands: it shows you are already planning the job.
2. **How do planning, the warehouse and QA share schedules today, and where do the handoffs usually slip?** Why it lands: it asks about the work you would be coordinating, not about yourself.
3. **Which system does Quillmoor run day to day for scheduling and stock?** Why it lands: it lets you learn the ERP picture without claiming SAP experience.
4. **What does the hybrid pattern look like in practice: which two days, and is Avonmouth the only site?** Why it lands: it checks the pattern against your three-day limit.
5. **How is on-time dispatch measured in the weekly report?** Why it lands: it turns the JD's weekly reporting line into a question you can answer on the day.
6. **What are the next steps and who would I meet?** Why it lands: she has said she will cover this, and it shows you are listening.

## Sources

- Provided documents: the advert text, your message (background and constraints), and Hannah Lowther's message (the call plan).
- Research tier: L0. No searches were run in this turn, so the pack uses only the documents above.
- Target accounting:
  1. Company values: unavailable. Not run this turn. Would have moved the values cheat sheet, which is dropped because no values-style round is detected.
  2. Interview process for the role family: unavailable. Not run this turn. Would have moved the round's expected structure.
  3. Company strategy and recent news: skipped. The advert and your message fix the role's terms.
  4. Interviewer name: n/a. The recruiter's public footprint is not part of this pack.
  5. Representative JD: skipped. The advert you supplied fixes the requirements.
- No tuesday-dossier.md was present in this turn.

## Upgrade menu

- Your notice period in weeks or months → fills the A4 slot with your own figure.
- Any production-planning or ERP exposure you actually have, described in your words → upgrades B1 and B2 from answer slots to rehearsed answers.
- Any on-time dispatch figures you tracked → upgrades C2 from a slot to a rehearsed answer.
- A tuesday-dossier.md, if you have one → would replace the inferred rows F5 and F7 with verified evidence.
