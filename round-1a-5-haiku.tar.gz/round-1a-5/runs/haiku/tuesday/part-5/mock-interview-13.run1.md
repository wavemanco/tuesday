Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/tuesday/part-5/rooms/case-13-denied-7f986021/Quillmoor_Operations-Coordinator_interview_pack.md`.

The biggest gap for this call is the SAP/ERP question. The advert lists it as a plus, and you've said you've never used SAP. The pack has you say that plainly, then describe your in-house stock system, and not claim anything beyond it.

Two things you'll want to fill in before Thursday:

- **Notice period.** You didn't mention it, so the pack has no figure for it. Hannah will ask, so it's worth having the number ready.
- **Excel and dispatch reporting.** Your message says "spreadsheet" but not Excel, and the advert asks for weekly on-time dispatch reporting. If you can tell me what the spreadsheet ran in and whether you ever reported on delivery timing, the pack can give you a real answer for each rather than a prompt.

Web search was refused in this session, so the pack has no company research on Quillmoor's values, interview process or strategy. If you grant search permission, I can rerun those checks.

The pack is sized to a 30-minute screen, so it has 8 questions rather than the usual 18 to 26.

I can play Hannah for a practice round on the SAP question (B1), since that's the one most likely to trip you up. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like a Word version of the pack, say so and I'll convert it.

What's your notice period?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_Operations-Coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30 minutes by phone, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Candidate:** Sam

This pack is sized to a 30-minute logistics call, so it has 8 questions instead of the usual 18 to 26. The call covers pay, notice, location and the reason for leaving, so depth beyond that would not be rehearsed.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and use only the sentences quoted in the Provenance column.

Type key:

- **VAL** (behavioural and values): not used. No values round is detected for this screen.
- **EXP** (your experience, tested for attribution): whether what you did survives a follow-up.
- **JD** (the role's requirements and terms): what the listed job asks, including pay, notice and location.
- **CO** (company knowledge): not used. Company research did not run (see Sources).
- **CASE** (live problem): not used. A screen does not usually include one.

## Fit snapshot

Each requirement is quoted from the advert. Each piece of evidence is quoted from your own message or CV. Gap types are chosen by the routing rule in `references/output-template.md`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Your message reaches this requirement. Say it in those terms: "4 years as a logistics coordinator at a building-supplies wholesaler." Limit: the material shows wholesale logistics, not manufacturing. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling, not production scheduling. Bridge stays at that scope: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether you worked with any of them. If you did, say which and what you coordinated. If you did not, say so plainly and stay with the depot deliveries. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | The quote reaches the requirement. Say it as you wrote it. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. It contains a figure, so the defend-the-number slots in B3 apply. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your message says spreadsheet and does not name Excel. Answer slot: if the spreadsheet was built in Excel, say what you built in it. If it was another tool, say which. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | low | [grounded] | transferability | Plain acknowledgment, which you have stated: "I haven't used SAP." Adjacent work: "We run our own in-house stock system." Answer slot: say what that system covers, in your own words. Do not claim SAP or ERP work. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: if you reported on delivery timing, say what it counted and how often. If you did not, say so plainly. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own constraint, met as you stated it. Say it as you wrote it. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advertised range. Say it and stop there. |

## Persona table

| Persona | How it shows up in this screen | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Opens with your background, then asks pay, notice, location and the reason for leaving | Highest. The recruiter's own message names these topics, and she has said the call covers them | Give a 90-second background answer. Answer each logistics topic in your own words, with nothing added |
| Skeptic (light) | Knockout checks against the advert: SAP or ERP, Excel, and whether the figure in your CV holds up | Medium. The advert's requirements are the source of these checks | Hold to what you have stated. Say plainly what you have not used |
| Pressure / Stress | Rarely used in a recruiter screen. Not weighted | Low. The recruiter named no pressure topic | The hold-then-concede move in B1 covers it |

Weights: Conversational 5 questions (A1 to A5), Skeptic (light) 3 questions (B1 to B3). The Pressure persona has no separate bank.

## Question banks

### Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background." | EXP, JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | About 90 seconds, in order: the role and the four years, then the three depots and the suppliers. Use the quoted sentences as you wrote them. Add nothing about production, planning or QA. | F1 and F3 cover the advert's experience and supplier requirements. It is the opening question, so keep it short. |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Say your figure in your words: "I'm hoping for £42,000." Stop there. If asked what you earn now, you can decline without giving a figure: "I'd rather focus on the range for this role." | F9 is the logistics slot for pay. The figure fits the advertised range, so nothing else needs saying. |
| A3 | "What's your notice period?" | JD | [grounded] the recruiter's own words, "your notice period" | Give your actual notice period in your own words. Your message does not state it, so this pack has no figure for it. If it is in your contract, read the figure from there. | A logistics slot the candidate has not yet filled. Asked as a closing question below. |
| A4 | "How would two days at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as you wrote it. If asked about the commute, the words stay the same: "I live in north Bristol." Add nothing about how you would travel. | F8 is the location slot. The candidate has already stated the constraint, so the answer stays at that scope. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year"; "the only offer is relocating to Reading, which I don't want" | Say the two facts in your words: "our Bristol office is closing next year", and "the only offer is relocating to Reading, which I don't want." If asked to say more about the Reading offer, go back to those same words. | The recruiter named this topic directly. The answer is your own reason, so nothing is added to it. |

### Skeptic (light, weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Do you have any SAP or ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Highest-ROI prep in this pack. Hold the plain acknowledgment: "I haven't used SAP." Then say what your in-house system does, in your own words: "we run our own in-house stock system." Answer slot: if you entered stock or ran reports in it, say which. If not, say so plainly. Hold through two follow-ups by returning to "I haven't used SAP." Concede specifically: say how you would learn SAP, as a plan and never as a past. | F6 is the advert's ERP line, and it is a knockout check. The candidate has stated the negative, so the plain acknowledgment has its source. |
| B2 | "How confident are you with Excel?" | JD | [inferred] derived from "I rebuilt our stock-count spreadsheet" | Answer slot: if the spreadsheet was in Excel, say what you built in it, in your own words. If it was another tool, say which one. Do not claim Excel skill beyond what you built. | F5 is low confidence, so the answer is a slot and not an assertion. |
| B3 | "How did the discrepancies come down, and how did you measure that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence as you wrote it. Weakest-assumption move: name, in your own words, the assumption behind "about a third" that you would defend least. Answer slot: how the discrepancies were counted, and which part was yours to change. | F4 carries a figure, and a figure raises the defend-the-number slots. The pack does not supply a method. |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | B2 |
| ERP experience (SAP or similar) a plus | B1 |
| Coordinate production schedules between planning, the warehouse and QA | none, and why: the recruiter named no production topic. F2's answer slot is where it would surface |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | B3 |
| Report weekly on on-time dispatch | none, and why: the recruiter named no reporting topic. F7's answer slot is where it would surface |
| Hybrid, two days at Avonmouth | A4 |
| £38,000 to £44,000 | A2 |

## Prohibited claims

These are claims this pack will not coach. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling across planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." The pack's own observation: your material says deliveries, not production schedules. |
| SAP or ERP experience | Negative you stated (F6) | "I haven't used SAP." Plus: "we run our own in-house stock system." No slot. |
| Confident with Excel, as a claimed skill | Inflated form of F5 | The pack's own observation: your material names a spreadsheet, not Excel. B2's answer slot asks which tool. |
| Cut discrepancies by a third through my own work | Inflated form of F4 | "discrepancies fell by about a third over a year." Say it at that scope. |
| Weekly dispatch reporting | Requirement no quoted sentence speaks to | Not listed. F7's answer slot asks what, if anything, you reported. |

## Reverse questions

Each one has a reason it lands.

1. "Who would this role report to, and what does their team look like?" It lands because the recruiter said she would tell you about the team, so the question follows her own agenda.
2. "What happens after this call, and roughly when would I hear?" It lands because she named next steps as the last item, so it shows you were listening.
3. "Which days would the Avonmouth team be on site, and are those days fixed?" It lands because it tests the hybrid pattern against the two-day limit you stated.
4. "How is on-time dispatch reported today, and who reads the weekly figure?" It lands because it tests the dispatch-report requirement directly, and it shows you care about measures.
5. "What would someone in this role need to have sorted in their first three months?" It lands because it asks for the team's own priorities, not a generic list.

## Sources

Provided documents:

- Hannah Lowther's LinkedIn message, as the candidate quoted it.
- The Quillmoor Diagnostics advert, as the candidate pasted it.
- The candidate's background, as stated in their message.

Every search and fetch sent, refused ones included:

- "Quillmoor Diagnostics values": refused. Permission to use web search has not been granted in this session.
- "Quillmoor Diagnostics interview process operations coordinator": refused.
- "Quillmoor Diagnostics strategy news Avonmouth": refused.

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have checked for a values round. None is detected for a recruiter screen, so nothing in the pack depends on it |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Search refused. Would have shown the loop, and so the persona weights. The weights here use the recruiter-screen prior |
| 3. Quillmoor Diagnostics strategy and news | unavailable | Search refused. Would have supplied a company-knowledge question. None is in this pack |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Not sent, because web search was refused on the three calls above. Would have moved the interviewer read, which is absent |
| 5. Representative operations coordinator JD | skipped | The advert was supplied and fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 gets your figure, in your words.
- The tool you used for the stock-count spreadsheet, and what you built in it → F5 and B2 move from a slot to a quoted answer.
- Whether you ever reported on delivery timing → F7 gets your quote, or a plain acknowledgment.
- Web search permission for a rerun of the three refused searches → the values, process and strategy targets would ground any company-knowledge answer.
- A tuesday-dossier.md from an earlier run, if you have one → verified evidence for F2, F5 and F7.
