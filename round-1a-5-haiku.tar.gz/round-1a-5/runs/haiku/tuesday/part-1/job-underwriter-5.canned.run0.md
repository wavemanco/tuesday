**Worth applying to, once one quick check comes back clean. Status: `conditional_go`.**

Your technical fit is strong on the requirements as written. The main gap is BigQuery, and it's recoverable. The open question is whether this employer is what the posting describes.

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or Denver office)
- `must_have`: direct: R1 (5+ years data engineering), R2 (strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (orchestration with Airflow or similar), R5 (data quality testing)
- `important`: adjacent: R8 (a dbt-modelled warehouse in BigQuery); unclear: R6 (ingestion from the app and CRM), R7 (data contracts analysts depend on)

R8 — you have dbt and warehouse work on Snowflake, but no BigQuery; R6 and R7 — your background doesn't mention them.

**Opportunity ledger.** The posting is specific and internally consistent: a defined scope, a stated salary inside the market band, and a live page on the company's own domain. One standing entry is open: the employer is described only on its own pages, so RR1 caps the decision at `conditional_go` until a second source confirms it. No red flags were found.

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** RR1 verifies clean (a recruiter email from pellucidlearning.com, plus an independent trace of the Series C or the company); R9 is confirmed as met; you frame BigQuery as an adjacent bridge, not direct experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` the company's own About page; no independent source found |
| Scope | Owns the pipelines behind one platform's reporting: ingestion, a dbt warehouse, data contracts | `[grounded]` JD; `[generic]` that this is one domain with no direct reports |
| Seniority | "Senior" at 5–8 years; your 6 years sit inside that range | `[generic]` Datawright 2026 report, n=2,310 |
| Compensation | Posted $148,000–$166,000 plus equity. Base median for this title is $151,000; IQR $139,000–$163,500. The posted band sits in line with that, and the top end is above the IQR | `[grounded]` JD; `[generic]` the band, from the report you sent |
| Equity | Stated, with no terms, valuation, or vesting | `[grounded]` absence in JD |
| Unknowns | Hiring manager (not named); equity terms; team structure; ingestion and contracts ownership | — |
| Contradictions | None between the JD and the live careers page | `[grounded]` careers page fetched |

## Evidence map

Your background is prose, so every claim sits at `medium` at most until you attach an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, as you stated | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, as you stated | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake; Snowflake counts as a cloud warehouse | `[grounded]` your background; requirement text | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, as you stated | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up your team's Great Expectations test suite | `[grounded]` your background | none |
| R6 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background is silent on ingestion sources | `[grounded]` absence | Ask (Q2) |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned; may exist under another name | `[grounded]` absence | Ask (Q3) |
| R8 | BigQuery warehouse (responsibility, not a requirement) | important | adjacent | medium | transferability | dbt and warehouse transfer; BigQuery's own tooling and cost model are untested | `[inferred]` adjacency from R3 | Bridge statement (plan row A1) |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't stated, so the gate is not established | `[grounded]` JD; no candidate statement | Ask (Q1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | dbt and warehouse work on Snowflake; no BigQuery | An interviewer will probe it, though it's a responsibility, not a stated requirement | Any SQL-dialect or cost-tuning work on another warehouse; a migration; a dbt adapter change | A small BigQuery project, or a short Snowflake-to-BigQuery mapping note | `[inferred]` bridge from R3; `[generic]` that interviewers probe warehouse-specific gaps |
| G2 | Ingestion (R6) | discovery | Not in your background | A must-have-level responsibility in the JD | Ingestion from product databases or a CRM API; schema-change handling | A pipeline diagram or DAG | `[grounded]` absence |
| G3 | Data contracts (R7) | discovery | Not in your background | Named in the JD as an analyst dependency | Schema agreements, breaking-change rules, owners on call | A contract doc or a changelog | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer described only on its own pages | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | Two searches found only the company's own About page. The entity may be small or new, or the page may not match a real hiring company. Its own posting is live on its domain and consistent with the pasted text | `[generic]` pattern for companies of this size; not a claim about this one | Which address will the recruiter write from, and can you point me to a public announcement of the Series C? | unresolved |
| RR2 | Hiring manager not named | unknown | — | (no name in posting) | Could be a central data team or a product-side owner | `[inferred]` from the posting's silence | Who would I be interviewing with, and which team owns the reporting pipelines? | unresolved |
| RR3 | Equity unvalued | unknown | — | "Salary ... plus equity" | Equity may carry little value at this stage, or may be a standard grant | `[inferred]` from the posting's silence on terms | What is the equity grant, vesting schedule, and valuation basis? | unresolved |
| RR4 | Scope and pay consistent with market | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Scope is defined and pay sits in the band | `[generic]` band; `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A0 | Before applying, check the recruiter's email domain and the company's public Series C coverage | Clears RR1, the only open condition on go | `[grounded]` RR1 | pending your approval |
| A1 | Bridge statement for BigQuery: "I built and maintain a dbt project of about 180 models on Snowflake. I haven't run BigQuery in production; my dbt and warehouse work transfers, and I'd expect to get the BigQuery specifics up to speed quickly." | Names the limit, so the adjacency stays honest in an interview | `[inferred]` from R8; reviewed against your own sentences | pending your approval |
| A2 | Ask the recruiter for the hiring manager's name and team | Clears RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet. Your background is prose, so it counts as CV-equivalent leads until you attach an artifact.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" company Series C funding" (returned only pellucidlearning.com/about). Fetched pellucidlearning.com/careers/senior-data-engineer: live, matching the pasted posting. Moved the posting to live and consistent, and set RR1: the only independent footprint is the company's own site |
| 2. Role-family sweep | skipped | The Datawright report you sent already fixes the band and the scope norm for this title |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A recruiter email from the company's domain, or a public Series C announcement → RR1 closes, and `conditional_go` becomes `go`.
- The hiring manager's name → RR2 closes, and the application plan can be aimed at that reader.
- The equity terms → RR3 closes, and the pay comparison becomes complete.
- A small BigQuery project, or a Snowflake-to-BigQuery mapping note → R8 moves from `adjacent` to `direct`.
- A deeper research pass on Pellucid Learning (leadership, funding coverage, hiring patterns, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also write `tuesday-dossier.md` for this role, with the full evidence map, register, and handoff keys, if you want it saved.

1. **Q1 (R9):** Are you based in the US, and is fully remote work workable for you, or would the Denver office be required?
2. **Q2 (R6):** Have you built ingestion from a product database or a CRM API? If so, which sources, and how did you handle schema changes?
3. **Q3 (R7):** Have you set up a data contract or a schema agreement with analysts or another downstream consumer? If so, who was on the other side, and what happened when a change broke something?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.