**Yes, it's worth applying, on conditions. Status: `conditional_go`.** Your analytics core matches the posting closely. The open parts are healthcare data (a stated plus), clinician work, and mentoring, and the posting leaves pay, location and contract basis unstated. Web research was refused in this run, so I could not verify the employer.

## Decision snapshot

- **Fit ledger.**
  - `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (metrics layer)
  - `important`: adjacent: R7 (PM partnership) · unclear: R8 (clinician partnership), R9 (mentoring)
  - `preferred`: adjacent: R10 (HIPAA data)
  - R2, R3 — daily Snowflake SQL and 30+ tests a year back the SQL and experiment rows; R6 — metric-definition ownership is not yet claimed; R10 — your consent-model work is the bridge; R8 and R9 — neither clinician work nor mentoring is in your background.
- **Opportunity ledger.** The scope is concrete (RR4), but pay, location and contract basis are absent (RR2), the employer and live posting are unverified (RR1), and healthcare data scope is unknown (RR3).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) employer and live posting confirmed on Harborlight's own careers page (RR1); (2) pay, location and contract basis checked against your limits (RR2); (3) healthcare framed as adjacent, not as HIPAA experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your message; not checked publicly |
| Mandate | Own product analytics for the care-navigation app; define and maintain the metrics layer; design and analyze A/B tests; self-serve Looker dashboards; partner with PMs and clinicians; mentor two junior analysts | `[grounded]` JD |
| Scope read | Ordinary senior IC scope with mentoring | `[inferred]` from the responsibilities list |
| Market calibration | Not established: the role-family search was refused, so there is no pay band. I won't give one from memory | — |
| Unknowns | Pay, location, working pattern, contract type, reporting line, what patient data the role touches | — |
| Contradictions | None visible in the material you gave me | `[grounded]` JD and your message |
| Stage | Evaluating (assumed; no stage given) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated in your message; no artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is direct; "expert" is a level no artifact shows yet | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test behind an 11% retention lift. The lift's basis (relative or absolute, sample, guardrails) is not stated | `[grounded]` your background | pin the 11% basis (A3) |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentation to VP Product | `[grounded]` your background | none |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed dashboards suggest definitional work; ownership of canonical definitions is not claimed | `[inferred]` from the dashboard claim | Q1 |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Experiment program and VP Product readouts; no PM-level roadmap call stated | `[inferred]` from the readouts | G4 |
| R8 | Partner with clinicians | important | unclear | low | discovery | No clinical or care-team work in your background | `[inferred]` from silence | G2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Not in your background | `[inferred]` from silence | G2 |
| R10 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model. No PHI, HIPAA controls or clinical data stated. Consumer rules are not HIPAA | `[grounded]` your background; `[generic]` that HIPAA and consumer privacy rules differ | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed dashboards; no claim that you owned definitions | A must-have; a yes would move R6 to direct | Owning metric definitions, a metrics dictionary, semantic-layer decisions | A metrics doc, dictionary entry or model excerpt | `[inferred]` from the dashboard claim |
| G2 | Clinicians and mentoring (R8, R9, important) | discovery | Neither appears in your background | Both are in the mandate | Work with care-team or clinical stakeholders; managing or training analysts | Team plan, feedback notes, a mentoring example | `[inferred]` from silence |
| G3 | HIPAA data (R10, preferred) | transferability | Consent-state model and consumer PII work | The bridge to a plus item; its limits are named | A privacy review or data-access process you ran | Sanitized consent-model description, privacy review summary | `[grounded]` background; `[generic]` on HIPAA differences |
| G4 | PM roadmap influence (R7, important) | transferability | Experiment readouts to VP Product; no PM decision named | Narrows the adjacency to a direct claim | One case where your analysis changed a PM's roadmap call | A readout, or a PM's written decision | `[inferred]` from the readouts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and contract basis unstated | unknown | — | (no pay, location or contract line in the posting) | Pay may be withheld or set below this seniority's band; location or contract may conflict with your limits | `[inferred]` from the posting's silence | What is the base salary range, where is the role based, and is it permanent? | unresolved |
| RR3 | Healthcare data scope | unknown | — | "care-navigation app"; "partner with … clinicians" | The role may touch identifiable patient data under HIPAA, with access rules that differ from the consumer PII rules you know | `[inferred]` from the clinical language; `[generic]` that HIPAA access rules differ from consumer privacy rules | What member or patient data would this role query, and what access approvals and HIPAA controls apply to analysts? | unresolved |
| RR4 | Concrete, owned responsibilities | positive_signal | — | "Own product analytics for our care-navigation app; define and maintain the metrics layer" | Scope is defined rather than vague | `[inferred]` from the responsibilities list | Which metric definitions does this role own outright, and which are agreed with product or clinical leads? | noted |

No request in the material asks anything of you (no fees, deposits or early bank details), so no routine-step or hold entries apply.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers page; ask who you would interview with | RR1 | `[grounded]` RR1 | proposed |
| A2 | Ask for the pay band, location and contract basis before investing in the loop | RR2 | `[grounded]` RR2 | proposed |
| A3 | Be ready to state the 11% basis: relative or absolute lift, sample size, test length, guardrails | R3; a probe will ask | `[grounded]` R3 | proposed |
| A4 | Describe healthcare work as adjacent (consent model, consumer PII), never as HIPAA experience | R10 | `[grounded]` R10 | pending your approval (wording) |

## Evidence status

Verified: none yet. Your background is intake prose, which counts as a CV: leads for verification, not proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (company page, careers listing) were refused by the tool permission, so nothing ran; I did not retry. Would have moved RR1: whether the employer exists as described and whether the posting is live |
| 2. Role-family sweep | unavailable | One search (senior product analyst pay and scope in digital health) was refused; not retried. Would have set the pay band and moved RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your pay floor, location and schedule limits (see the question below) → RR2 and RR3 close, and the hard-gate line gets real checks.
- The live posting link or Harborlight's careers page → RR1 closes.
- Search permission, if you want it: this run's search was refused. Allow it and I can rerun the employer and pay checks; each search counts against the same budget.
- A write-up of the 11% pricing test (readout memo or sanitized excerpt) → R3 moves to an inspectable proof.
- A sanitized SQL sample or metrics dictionary entry → R2 and R6 move up.
- A Looker dashboard screenshot or governance doc → R4 moves to an inspectable proof.
- A sanitized privacy review or consent-model description → R10 moves up.

I can also write this assessment to a `tuesday-dossier.md` for you to keep and reuse, if you want.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q1 (R6):** Did you own the canonical metric definitions at your company, the ones the exec memo used? If so, where did they live?

**Q2 (R9):** Have you mentored or managed junior analysts? How many, and what did you own in that?

**Q3 (RR2, RR3):** What are your non-negotiables: location or remote, your pay floor, and whether you need permanent employment?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.