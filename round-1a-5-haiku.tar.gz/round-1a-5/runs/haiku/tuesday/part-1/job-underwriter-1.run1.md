**Arjun, yes, apply, on conditions.** Your core requirements are your strongest ground: 6 years, daily SQL, experiment design, and Looker. The gaps are the metrics-layer ownership, clinician partnership, and healthcare data. **Status: `conditional_go`.**

**Research did not run.** Web search was refused permission in this session, so I could not verify Harborlight Health, the live posting, or the market pay band. That leaves the employer unverified, which caps this at `conditional_go`.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (define and maintain the metrics layer), R6 (partner with clinicians on roadmap decisions)
- `important`: direct: R7, R9 · unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R10 (healthcare data, HIPAA)

R5 and R6 are the two must-haves that aren't yet direct. The metrics layer may be a separate team's remit, and clinician work is absent from your background. Your consent-state and PII work carries over to HIPAA, but the regimes differ.

- **Hard gates:** none stated in the posting; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the metrics-layer ownership is what you'd expect (RR2, R5).

**Role reality.** The posting names no pay, location, or contract basis. Those are unknowns, not risks. Market calibration: not run (research refused).

**Evidence map.** Everything below is your own statement, not yet inspected, so confidence is `medium` at most.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one subscription company. Years of experience is not a gate. | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is your judgment, not an artifact. | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test with the 11% retention lift. | `[grounded]` your statement | a test write-up would raise this (upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ governed dashboards. | `[grounded]` your statement | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards imply metric definitions, but you haven't said you owned canonical definitions. | `[inferred]` from the dashboards | Q1 |
| R6 | Partner with PMs and clinicians on roadmap decisions | must_have | adjacent | medium | transferability | Monthly VP Product presentations and exec memo cover PMs. Clinicians are not in your background. | `[grounded]` PM/exec; `[inferred]` transfer | G2 |
| R7 | Written communication to non-technical stakeholders | important | direct | medium | none | The monthly exec metrics memo. | `[grounded]` your statement | none |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not in your background. | — | Q2 |
| R9 | Self-serve dashboards in Looker | important | direct | low | none | Your dashboards were governed, but you haven't said they were self-serve. | `[inferred]` | none |
| R10 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | The consent-state model and GDPR/CCPA work carry over. HIPAA's regime differs. | `[grounded]` your work; `[generic]` on HIPAA | G3 |

**Gap recovery queue.** No questions here; the questions are in the closing block.

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G2 | Clinician partnership (R6) | transferability | PM and exec partnership is clear; clinical stakeholders are not | Clinicians may gate what ships in a care-navigation product | Work with ops, legal, or finance partners where the analysis had to survive a non-analyst's review | A stakeholder example with a clinical or regulated flavor | `[inferred]` bridge; `[generic]` that clinical buy-in is the likely objection |
| G3 | HIPAA / PHI (R10) | transferability | Consent and PII work, no PHI | Preferred, not a gate; a bridge, not a block | Consent-state design, access controls, data minimization | A data-handling policy excerpt, sanitized | `[grounded]` your work; `[generic]` on regime differences |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Research could not confirm the company or this posting. It may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me to this role on your careers page, and who would I interview with?" | unresolved |
| RR2 | Metrics-layer ownership unclear | unknown | — | "define and maintain the metrics layer" | A central semantic-layer team may own definitions, which would shrink the remit. | `[inferred]` from the JD | "Who owns canonical metric definitions today, and does this role change them?" | unresolved |
| RR3 | Clinician influence unclear | unknown | — | "partner with product managers and clinicians" | Clinician input may gate which analyses ship. | `[generic]` | "How do clinicians influence which analyses reach the roadmap?" | unresolved |
| RR4 | Pay and location not in the posting | unknown | — | Not stated in the JD you pasted | Pay and location may be set later. | `[grounded]` absence in the JD | "What is the base range, and where is the role based?" | unresolved |

**Decision.** The unverified employer caps the decision at `conditional_go`. If RR1 clears and RR2 confirms you'd own the definitions, the status moves to `go`.

**Application plan** (every row pending your approval):

- P1: Ask the recruiter for the live posting link and the team's reporting line.
- P2: Lead with your metrics-layer or definitions work if you have any. This is a presentation fix, not a new claim.

**Evidence status.** Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches refused by permission. Would have confirmed the company and the live posting (RR1, role reality). |
| 2. Role-family sweep | unavailable | Refused. Would have set the pay and scope calibration (RR4). |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Upgrade menu.**

- A link to the live posting or the company's careers page → RR1 closes; the decision moves toward `go`.
- Your pay floor, location or remote needs, and any contract constraint → sets the hard-gate checks, currently unknown.
- A sanitized metric dictionary or semantic-layer excerpt → R5 rises from `low`.
- A write-up of one experiment, such as the pricing test → R3 rises to `high`.
- Re-enabling web search → the company check (RR1) and pay band (RR4) would run.
- The hiring manager's name → positioning for that reader.

If you'd like this kept, I can write it up as a `tuesday-dossier.md` file you can reuse.

**Questions.**

- Q1 (R5, RR2): Did you own the canonical metric definitions at your company, or did you consume a layer someone else maintained? Give one metric you defined and what happened when it moved.
- Q2 (R8): Have you formally managed or mentored junior analysts? How many, for how long, and what did you do for them?
- Q3 (constraints): Do you have hard constraints (a pay floor, a location or remote requirement, or work authorization) you want checked against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.