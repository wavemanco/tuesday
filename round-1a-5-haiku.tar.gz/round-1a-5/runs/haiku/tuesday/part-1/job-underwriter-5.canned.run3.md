**Status: `hold_pending_answers`.** On the requirements, yes, worth applying to. Two gate answers you haven't given me yet decide it: your pay floor and your location. Both gates are unchecked because you haven't stated constraints.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (pay: $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: direct: R11 (owns a domain's pipelines) · adjacent: R8 (BigQuery warehouse) · unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R3–R7 are all `direct` at `medium`, because the evidence is your self-report. R8 is the one real gap, and it is recoverable. R9 and R10 are not in your intake, so I can't yet tell whether they are gaps.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (pay: $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger:** sound. The salary sits inside the senior band (RR1), and the posting makes no requests of you. Open items are RR2, RR3 and RR4.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page, fetched; matches your paste |
| Mandate | Ingestion, a dbt warehouse in BigQuery, and data contracts for analysts | `[grounded]` posting, fetched |
| Scope read | One domain's pipelines plus contracts. Matches the senior norm of 5–8 years with no direct reports | `[generic]` Datawright 2026 report (you supplied it) |
| Pay | $148,000–$166,000 against a Series B–D senior base median of $151,000 (IQR $139,000–$163,500). The range covers the median and the upper-middle of the IQR | `[grounded]` posting; `[generic]` band from the report |
| Working pattern | Remote US, or the Denver office | `[grounded]` posting |
| Unknowns | Hiring manager, equity terms, whether ingestion and contracts are greenfield or inherited | — |
| Contradictions | None between the posting and the careers page | `[grounded]` fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote US or Denver | hard_gate | unclear | none | hard_gate | No location given | `[grounded]` posting | Q1 |
| R2 | Pay: $148k–$166k plus equity | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` posting; `[generic]` band | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; length requirement, not a gate | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake | `[grounded]` your intake | none |
| R6 | Orchestration (Airflow or similar) | must_have | direct | medium | none | Airflow orchestration | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your intake | none |
| R8 | BigQuery warehouse (in the posting body) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery not used | `[grounded]` never used BigQuery; `[inferred]` transfer from Snowflake | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake | `[inferred]` from absence | G2 |
| R10 | Data contracts analysts rely on | important | unclear | low | discovery | Not in your intake | `[inferred]` from absence | G3 |
| R11 | Owns a domain's pipelines end to end | important | direct | medium | none | Ownership of the dbt project and its Airflow orchestration | `[grounded]` your intake; `[generic]` senior scope | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt, no BigQuery | Named in the posting body; the largest technical gap | Any GCP work, a course lab, a BigQuery cost or partitioning exercise | A repo or lab note | `[grounded]` intake; `[inferred]` transfer |
| G2 | Ingestion from app and CRM (R9) | discovery | Not in intake | Core to the role's first months | Loads from a product database or Salesforce or HubSpot | A pipeline repo or design doc | `[inferred]` |
| G3 | Data contracts (R10) | discovery | Not in intake | The posting names it as an analyst dependency | Schema agreements, breaking-change handling, owned interfaces | A contract spec or a test suite | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay inside the senior band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is competitive for the stage | `[generic]` band | — | noted |
| RR2 | Hiring manager not named | unknown | — | (silent) | The role may be a team of one | `[inferred]` from absence | "Who would I report to, and who else is on the data team?" | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity could be small or non-standard | `[inferred]` | "What is the equity grant, its vesting, and its strike price?" | unresolved |
| RR4 | Series C rests on the company's own site | unknown | — | "Series C ($52M, February 2026)" | Only one search, which returned only the company's own page | `[grounded]` search result | "Can you point me to the Series C announcement or the lead investor?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send Q1's answers before you apply | Gates decide the status | `[grounded]` R1, R2 | pending your answer |
| A2 | Lead with dbt, Airflow and Great Expectations on Snowflake; state BigQuery as adjacent, not as experience | Keeps the claim honest where R8 is thin | `[grounded]` R5, R6, R7, R8 | pending your approval |
| A3 | Ask RR2–RR4 in the first recruiter call | Those answers are the interview preparation | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your claims are self-report at the `medium` intake ceiling.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C"; fetched the careers page and the About page. The posting is live and matches your paste. Entity attribution holds through the company's own site. Contradictions: none |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied already fixes the band and the 5–8-year senior norm |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can save this as `tuesday-dossier.md` if you want it kept.

**Upgrade menu**

- Any BigQuery or GCP work, even a lab → R8 and G1 move toward `direct`
- The hiring manager's name → RR2 and a more specific scope read
- The equity grant terms → RR3 closes
- A deeper pass on Pellucid's funding and leadership (up to 5 more searches and 2 more fetches) → RR4 and the risk register. Say the word and I'll run it.

**Questions**

Q1 (R1, R2): Is your pay floor at or below $148,000, and are you based in the US, in Denver or able to work remotely from where you live?

Q2 (G2, R9): Have you built ingestion from an application database or a CRM into a warehouse? Which source, which loader, and who owned the source schemas?

Q3 (G3, R10): Describe a schema or interface contract you defined that analysts or another team relied on. What enforced it, and what happened when it changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.