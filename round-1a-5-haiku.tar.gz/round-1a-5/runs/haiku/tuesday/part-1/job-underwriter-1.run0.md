**Yes, apply, once the posting checks out on Harborlight's own careers page.** You meet the five must-haves on your own account (R1, R2, R3, R4 and R5), and the gaps are healthcare and the clinician and mentoring parts of the job. Status: `conditional_go`.

- **Fit ledger.** `must_have`: direct: R1, R2, R3, R4, R5. `important`: direct: R7a (PM and exec partnership); adjacent: R6 (the metrics layer); unclear: R8 (mentoring two analysts); absent: R7b (clinician partnership). `preferred`: adjacent: R9 (healthcare data).
- **Opportunity ledger.** The posting is concrete about what the job delivers (RR5). Pay, location and contract type are not in the pasted posting (RR1, RR2). The employer and posting are unverified because the web search was refused (RR3). Who owns warehouse pipelines is unclear (RR4).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting appears on Harborlight's own careers page (RR3); (2) the metrics-layer ownership (R6) and clinician and mentoring scope (R7b, R8) hold up in interviews; (3) your location, authorization, pay floor and contract terms are checked against the role (none were given).

Confidence is capped at `medium` on every row about you, because everything here is your own description and nothing has been checked against a document yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` the posting's own claim; not checked |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` posting |
| Scope read | An analytics owner with a mentoring remit, a metrics layer and self-service BI; concrete rather than broad | `[inferred]` from the listed responsibilities |
| Market calibration | None. The role-family search was refused, so there is no band | — |
| Compensation | Not in the pasted posting | — |
| Unknowns | Pay, location and remote terms, contract type, who owns the warehouse, clinician-facing scope | — |
| Contradictions | None found, but only the pasted posting was read; the careers page was not | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; no artifact yet | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; a sanitized query would raise it | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test stated; expect a probe on whether the 11% was relative, and its baseline and significance | `[grounded]` your statement | prepare the answer (P2) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards | `[grounded]` your statement | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product presentation; a memo excerpt would raise it to high | `[grounded]` your statement | work sample (P4) |
| R6 | Define and maintain the metrics layer | important | adjacent | low | transferability | Governed dashboards and the memo are adjacent; you have not said you owned canonical definitions | `[inferred]` from R4 and R5 evidence | G1 |
| R7a | Partner with PMs and execs on roadmap decisions | important | direct | medium | none | Monthly VP Product presentation; the roadmap effect is not stated | `[grounded]` your statement | none |
| R7b | Partner with clinicians | important | absent | none | discovery | No clinician-facing work stated | `[grounded]` absence in your statement | G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Not mentioned; may exist | `[grounded]` absence in your statement | G3 |
| R9 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and the consent-state model are adjacent; no PHI or HIPAA obligations | `[inferred]` from stated privacy work | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R6, important) | transferability | Governed dashboards and the memo; no statement of owning canonical metric definitions | Decides whether the "define and maintain" line is a claim you can make | Defining a KPI that the exec team then used; settling a conflict between two definitions | A metric dictionary, or a governance doc you wrote | `[inferred]` adjacency; `[generic]` that this is the likeliest interview probe |
| G2 | Clinician partnership (R7b, important) | discovery | No clinician or care-staff work stated | A responsibility in the posting with no evidence either way | Work with dietitians, care teams or customer-care leads that changed a decision | A brief, or an example of an analysis a non-analyst acted on | `[grounded]` absence; `[generic]` that healthcare panels probe clinical stakeholders |
| G3 | Mentoring (R8, important) | discovery | Not mentioned | Two junior analysts are part of the job | Onboarding or reviewing a colleague's analysis | A review checklist or a onboarding plan | `[grounded]` absence |
| G4 | Healthcare data (R9, preferred) | transferability | Consumer privacy work, not health data | Preferred, so a limit to state, not a blocker | Consent-state rules applied to a sensitive field | A one-page description of the consent model | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (none in the posting) | Pay may sit below the usual band for this seniority, or be left to the offer | `[generic]` pattern; no band, since the search was refused | What base salary range is budgeted for this role? | unresolved |
| RR2 | Location and contract type not stated | unknown | — | (none in the posting) | These may be set later in the process | `[inferred]` from the posting's silence | Is this role permanent, and is it remote, hybrid or on-site? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; unresolved because the search was refused, not because the employer looks doubtful | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Warehouse and pipeline ownership unstated | unknown | — | "build self-serve dashboards in Looker" | Analytics may carry pipeline upkeep, or data engineering may own it | `[inferred]` from silence on data engineering | Which team owns the warehouse pipelines, and how much of this role is pipeline work? | unresolved |
| RR5 | Concrete deliverables named | positive_signal | — | "define and maintain the metrics layer… design and analyze A/B tests" | Scope is specific and measurable | `[inferred]` from the named deliverables | What would success look like at six months, and how would it be measured? | noted |

RR3 caps the decision at `conditional_go`: verify the employer before spending application effort on it.

## Application plan

Nothing here is final until you approve it. Each row is a proposal.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find this role on Harborlight's own careers page before applying | RR3 | `[grounded]` RR3 | pending your approval |
| P2 | Have the pricing test's baseline, relative-or-absolute lift and significance ready, and lead with the 30+ test program and the Looker build | R3, R4 | `[grounded]` your statements | pending your approval |
| P3 | Describe GDPR/CCPA and consent-state work as adjacent to HIPAA, never as health-data experience | R9 | `[grounded]` R9 | pending your approval |
| P4 | Write a scrubbed memo excerpt as a work sample | R5 | `[grounded]` R5 | pending your approval |
| P5 | Prepare a clinician-partnership example before any interview | R7b | `[generic]` healthcare panels often probe clinical stakeholder work | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is your own description and has not been probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three search calls were sent and all were refused. Would have checked that Harborlight exists as described and that the posting is live (RR3) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the scope and pay band for this title, labeled `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Allowing web search would let me run the careers-page check (RR3) and the role-family sweep (RR1 and the market calibration), with up to 5 searches and 2 fetches.
- If you paste the live posting link or the careers-page text, I can read it. That is an input, not research, so it doesn't use the budget.
- A deeper pass on Harborlight (funding, leadership changes, recent news) is available once search works, at up to 5 more searches and 2 more fetches. I'm offering it once.
- A budgeted salary or contract type closes RR1 and RR2.
- A scrubbed memo excerpt, or a sanitized query sample, moves R5 or R2 from `medium` to `high`.
- A one-page readout of the pricing test (baseline, lift basis, significance) moves R3 to `high`.
- The hiring manager's name would open target 3 and shape which story to lead with.

If it helps, I can write this up as a `tuesday-dossier.md` you can reuse.

Q1: Before anything else, are there constraints I should check against this role, such as location or remote terms, work authorization, a pay floor or a contract type you won't take? If none, say so.

Q2 (G1): Did you own the metric definitions themselves, or did you build dashboards on definitions someone else set? If you owned them, what did you decide, and who signed off?

Q3 (G2): Have you worked directly with clinicians, dietitians or care staff? If so, what did you change because of an analysis?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.