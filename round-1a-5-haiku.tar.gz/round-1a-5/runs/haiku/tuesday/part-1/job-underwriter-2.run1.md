**Not a waste of your time, but a stretch: `conditional_go`.** Apply if the posting verifies and you can give one concrete example of a product decision you shaped. The titled-PM requirement is the main risk.

**Fit ledger.**

- `must_have`: direct: R3 (API docs and schemas), R4 (partner discovery), R6 (cross-team stakeholders) · adjacent: R1a (product-adjacent years), R2 (shipped API products), R5 (roadmap and specs) · absent: R1b (titled PM years)
- `important`: direct: R8 (launch coordination) · unclear: R7 (adoption metrics), R9 (agile delivery)

R1a, R2 and R5 are bridges, each with its limit named. R1b is the gap a literal screen would catch. R7 and R9 are unknowns the CV doesn't answer.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Opportunity ledger.** Mostly unknowns, no red flags. Authority over the roadmap across two squads and sales is unstated (RR1), and so is salary (RR3). The 3+ year titled requirement may be screened literally (RR2). The scope and outcomes are specific (RR4). The employer is unverified (RR5).

**What would change this:**
- The posting is confirmed on Quartzline's own careers page (RR5). That is the first condition.
- You can name one product decision you shaped, with its outcome (R5, RR1). That is the second.
- The bridge is framed as product-adjacent, with no PM title implied. That is the third.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your message; not verified this run |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery; write specs; drive delivery with two squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | End-to-end product ownership of one platform, with a 3+ year bar that reads like a mid-level ask | `[inferred]` from the JD's scope and its stated years |
| Market calibration | Not run: web search was refused this session | — |
| Unknowns | Decision rights across squads, sales and support; salary; reporting line; success metrics | — |
| Contradictions | None found in the material provided | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management (product-adjacent years) | must_have | adjacent | medium | transferability | About seven years in product-facing implementation and requirements work; no roadmap ownership | `[grounded]` CV, unprobed | Q1 |
| R1b | 3+ years as a titled PM | must_have | absent | medium | transferability | You have never held a PM title; the adjacent work above is the bridge | `[grounded]` your statement | Q2; RR2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Delivered 30+ REST API integrations end to end; did not own the API product | `[grounded]` CV | Q1 |
| R3 | Reads API docs; discusses schemas | must_have | direct | medium | none | Postman, OpenAPI, SQL and integration architecture on the CV; no artifact yet | `[grounded]` CV | Work sample: an annotated spec would raise to high |
| R4 | Discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and quarterly feedback sessions sit inside implementation bullets | `[grounded]` CV; `[inferred]` that this is discovery | E1 |
| R5 | Own roadmap; write specs; drive two squads | must_have | adjacent | medium | transferability | Wrote requirements documents and coordinated engineers; fed roadmap input without owning prioritization | `[grounded]` CV | Q1 |
| R6 | Stakeholders across engineering, sales, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs; sales-side work is not on the CV | `[grounded]` CV | none |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | Q3 |
| R8 | Launch coordination with sales and support | important | direct | medium | presentation | UAT, go-live, and a playbook the team uses | `[grounded]` CV | E1 |
| R9 | Agile delivery | important | unclear | low | discovery | CV names no methodology | `[grounded]` CV silence | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it |
|---|---|---|---|---|
| G1 | Titled PM years (R1b) | transferability | Years of product-adjacent work, no PM title | A product decision you shaped, with its outcome; a stated limit in your pitch |
| G2 | Shipped products (R2) | transferability | Integrations built on the API, not the API product | A client requirement that changed how the API was designed or shipped |
| G3 | Roadmap ownership (R5) | transferability | Roadmap input, not prioritization | A roadmap call you made or argued for, and who decided |
| G4 | Adoption metrics (R7) | discovery | CV silent | Any integration success measure you tracked after go-live |
| G5 | Agile delivery (R9) | discovery | CV silent | Whether you worked in sprints, and with what backlog |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights unstated | unknown | — | "own the roadmap for our partner-facing API platform" | The role may own the roadmap without authority over priorities across two squads and sales | `[inferred]` from ownership language against silence on decision rights | Which roadmap decisions does this role make alone, and which need engineering or sales sign-off? | unresolved |
| RR2 | Titled-years requirement | risk_signal | medium | "3+ years product management experience" (must-have) | A literal screen may exclude candidates without a PM title | `[generic]` pattern for titled-years requirements, not a claim about this employer | Would you consider product-adjacent platform experience in place of titled PM years, and what would that look like? | unresolved |
| RR3 | Salary unstated | unknown | — | (no compensation in the posting) | Pay may sit outside your expectations | `[inferred]` from the posting's silence | What is the budgeted base range for this role? | unresolved |
| RR4 | Specific scope and outcomes | positive_signal | — | "adoption metrics", "launch coordination" | The role has defined responsibilities | `[grounded]` JD | What adoption metrics will this role be measured on in year one? | noted |
| RR5 | Employer not established | risk_signal | medium | the posting's own identifying language | This run could not verify the employer or posting. The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a hiring employer; none is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Quartzline's own careers page, and who would I interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's careers page before investing effort | RR5 | `[generic]` standing entry | proposed |
| A2 | Lead with one product-facing story, not the integration count | R2, R5 | `[inferred]` from your CV; needs your confirmation | pending your approval |
| E1 | Keep "roadmap-input sessions" as written; do not turn "collected client feedback for product" into "owned the roadmap" | R4, R5 | `[grounded]` CV; reframing audit | `resume_edits_pending_approval` |
| A3 | Ask the recruiter whether the 3+ years is a literal screen before the loop | RR2 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your CV and your message, which are unprobed.

Unverified lead: a note from earlier conversation says you built an internal request-triage tool that support agents adopted. It is unconfirmed, so I have used it only as the basis for Q2, never as evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because web search permission was not granted in this session. Would have checked that Quartzline exists as described and the posting is live (RR5) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market band for title and pay |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you allow web search, I can rerun the two blocked checks, and I can write this up as a `tuesday-dossier.md` you keep.

## Upgrade menu

- A live posting link or Quartzline's careers page → RR5 closes; a clean verification could move the decision toward `go`.
- An annotated OpenAPI spec or an integration playbook excerpt, redacted → R3 to `high`.
- One concrete example of a product decision you shaped, with its outcome → R1a and R5 could move to `direct`.
- The salary band the company budgets → RR3 closes.
- Permission to rerun the two blocked web searches → the employer check and the market band.

**Questions**

Q1 (R5, RR1): Think of one product decision you shaped at your current or last job, such as a client request that changed a roadmap item or a spec. What did you propose, who decided, and what shipped?

Q2 (R1b, memory lead): Did you build an internal request-triage tool that support agents adopted? If so, what did you own, and how did you know it was used?

Q3 (R7, R9): After an integration goes live, how have you measured whether it succeeded? And have you worked in sprints with a backlog?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.