**Yes, it looks worth applying to, on conditions. Status: `conditional_go`.** Your six years and Airflow, dbt and Great Expectations experience cover most of the must-haves. The BigQuery gap is closable. Two things need checking before you invest in the loop: the posting itself, which I could not verify, and your location and pay terms, which you have not given me.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver office), R2 (base salary $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R6 and R7 read `direct` on your self-reported background. R8 is a credible bridge with its limit named. R9 and R10 are open questions. R1 and R2 are hard gates you have not answered.

**Opportunity ledger.** The stated pay sits inside the market band (RR3). RR1, employer not established, caps the status at `conditional_go` until the posting verifies. RR2, RR4 and RR5 are unknowns to put to the employer.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) RR1 clears: the posting appears on Pellucid's own careers page and you can name the hiring contact. (2) R1 and R2 are checked against your location and pay floor. (3) R8 is framed as adjacent, not as BigQuery experience. If R9 or R10 turn out not to be your work, the fit ledger weakens but the status does not change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the About text you pasted; not fetched |
| Mandate | Build and run the pipelines behind tutoring reporting: ingestion from app and CRM, a dbt warehouse on BigQuery, data contracts | `[grounded]` JD |
| Scope read | One platform's reporting pipelines, no reports named | `[inferred]` from the JD's scope language |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500; "Senior" typically means 5–8 years; typical scope is one domain's pipelines with no direct reports. Your stated range's midpoint is $157,000, inside the IQR | `[generic]` Datawright 2026 pay report (n=2,310), as relayed by your recruiter; `[grounded]` the posted range |
| Unknowns | Equity amount and vesting; team size and decision rights; hiring manager; ingestion ownership | — |
| Contradictions | None between the JD and the About text you pasted. The careers page was not fetched, so none was checked against it | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No location constraint given | `[grounded]` JD | Q1 |
| R2 | Base salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported. Length of experience is not a gate | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, self-reported | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and a cloud warehouse carry over from Snowflake; BigQuery itself never used | `[grounded]` your intake; `[inferred]` that Snowflake experience bridges | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[grounded]` JD; CV silent | G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[grounded]` JD; CV silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | dbt and Snowflake experience; no BigQuery | The posting names BigQuery specifically; the gap is platform detail, not the dbt pattern | BigQuery use in any form; a Snowflake-to-other-warehouse migration | A small BigQuery dbt project or sandbox run | `[inferred]` bridge from Snowflake work; `[generic]` that a hands-on project narrows a warehouse gap |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Nothing in the material | Named first in the responsibilities | Pipelines pulling from a product database, a CRM API, or event streams | A pipeline diagram or ingestion design doc | `[grounded]` JD; CV silent |
| G3 | Data contracts (R10, important) | discovery | Nothing in the material; GE test suite is the nearest thing | Analysts depend on these, so they are a visible commitment | Written producer–consumer schemas, schema-change alerts, consumer sign-offs | A contract or schema doc | `[grounded]` JD; CV silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" (About text) | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager not named | unknown | — | (no hiring manager named in the posting) | Reporting line and team are unknown | `[grounded]` posting silence | Who would this role report to, and which team's roadmap does it sit in? | unresolved |
| RR3 | Stated pay sits inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The stated midpoint of $157,000 is inside the IQR and near the median | `[grounded]` posted figure; `[generic]` band from the 2026 pay report | Is this base the budgeted band for the role? | noted |
| RR4 | Equity not quantified | unknown | — | "plus equity" | Grant size and vesting are unstated | `[grounded]` posting silence | What equity is offered for this role, and on what vesting schedule? | unresolved |
| RR5 | Team scope and decision rights not stated | unknown | — | "build and run the pipelines behind our tutoring platform's reporting" | Ownership may be shared with other engineers, or may be one domain alone | `[inferred]` from scope language against silence on team; `[generic]` typical senior scope is one domain, no reports | Which pipelines would I own alone, and who else works on them? | unresolved |

**Severe red flags:** none found. The material asks nothing of you (no payment, deposit or bank details, no chat-only process).

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the posting on Pellucid's own careers page yourself, and note the hiring contact | Verifies RR1; my search was refused | `[grounded]` RR1 | pending your approval |
| P2 | Ask the recruiter for the hiring manager, the budgeted base, and the equity grant | RR2, RR3, RR4 | `[grounded]` register | pending your approval |
| P3 | Before the first screen, build a small dbt model on BigQuery, even in a sandbox project. Do not claim BigQuery experience until you have it | G1 and R8 | `[generic]` that a short hands-on project narrows a warehouse gap | pending your approval |

No CV edits are proposed. Your evidence already shows up in role-relevant terms.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent, "Pellucid Learning online tutoring K-12 Denver" and "Pellucid Learning senior data engineer job BigQuery dbt". Both were refused by the host's permission setting, so no page was fetched. Would have moved RR1 (employer exists, posting live) and the contradictions row |
| 2. Role-family sweep | skipped | The 2026 pay report figures you relayed fix the market calibration line and RR3 |
| 3. Hiring manager's public footprint | n/a | No name in the posting or your intake |

Your intake claims are self-reported and not yet probed, so none is verified.

I can write this up as a `tuesday-dossier.md` if you want to carry it into interview prep.

## Upgrade menu

- Permission to run the employer searches, or your own check of the careers page (paste the text or the link): RR1 closes or stays open, and the contradictions row fills in.
- Your location and base-pay floor: R1 and R2 close, and the decision either holds or changes.
- Any ingestion or data-contract work you have done, even outside your CV: R9 and R10 rise from unclear.
- A BigQuery project or artifact you build: R8 moves toward direct.
- The hiring manager's name: RR2 closes, and the positioning for this reader can be set.

Q1 — R1 and R2: Are you based in the US, would remote or the Denver office work for you, and what base salary is your floor?
G2 — R9: Have you built ingestion from a production app or a CRM? Which sources and tools, and who owned schema changes?
G3 — R10: Have you defined data contracts, meaning written agreements between a producer and the analysts who consume a table, with some enforcement?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.