**Not worth pursuing as posted. Status: `no_go`.** Your fit is strong, but the posting fails both of your hard constraints, and its own wording says those terms are not negotiable. Your instinct is right: the flags below explain the "something feels off."

**Fit ledger**
- `hard_gate`: failed: R1 (base pay), R2 (on-site location)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM), R6 (end-to-end revenue growth)
- `important`: unclear: R7 (SEO/content), R8 (brand and PR), R9 (partnerships), R10 (sales ops)

R1 and R2 are your two gates, and both fail. R3–R6 are direct on your CV at `medium`, since nothing has been inspected yet. R7–R10 are unclear because your background doesn't show them.

**Opportunity ledger.** The posting has no severe red flags. Its risk signals are the always-on expectation (RR1), a Head-of title with a team-of-one scope (RR2), undefined success metrics (RR3), and a base that sits far below the seniority the posting asks for (RR4). The employer could not be verified (RR5).

- **Hard gates:** failed: R1 (base pay), R2 (on-site location). Met: none.
- **Severe red flags:** none found.
- **Why `no_go` and not a hold:** a failed gate caps the decision, and the posting states both terms as firm ("no exceptions"). Nothing you could answer would change either row.
- **What would have to differ:** the role would need to be remote and carry a base at or above $150k. As written, it is neither.

**Role reality**
| Element | What it is | Provenance |
|---|---|---|
| Mandate | Own all revenue growth: paid, SEO, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team | "Team of one to start," explicitly no bench | `[grounded]` JD |
| Pay | $70–85k base, equity unquantified | `[grounded]` JD |
| Location | Austin on-site five days a week, no exceptions | `[grounded]` JD |
| Company | Series A, profitable since day one, as the posting claims | `[grounded]` JD only; unverified |

Your $150k floor sits about $65k above the posted midpoint. That gap is arithmetic on two stated figures, not a market claim. I couldn't check the market band (see Evidence status).

**Evidence map**
| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | Base at least $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | `[grounded]` your statement vs JD |
| R2 | Remote-only, Portland (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | `[grounded]` your statement vs JD |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | `[grounded]` your history |
| R4 | Paid acquisition | must_have | direct | medium | none | `[grounded]` your history |
| R5 | Lifecycle/CRM (Braze) | must_have | direct | medium | none | `[grounded]` your history |
| R6 | End-to-end revenue growth ($8M→$40M ARR) | must_have | direct | medium | none | `[grounded]` your history |
| R7 | SEO/content | important | unclear | low | discovery | `[grounded]` absence from your history |
| R8 | Brand and PR | important | unclear | low | discovery | `[grounded]` absence from your history |
| R9 | Partnerships | important | unclear | low | discovery | `[grounded]` absence from your history |
| R10 | Sales ops | important | unclear | low | discovery | `[grounded]` absence from your history |

**Risk register**
| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Evenings and weekends may be routine, not occasional | `[inferred]` from the JD's wording | How often do evenings and weekends come up in a typical month? | unresolved |
| RR2 | Title and scope mismatch | risk_signal | medium | "Head of Growth," "team of one," "no bench" | Accountability for every channel with no team or budget committed | `[inferred]` from the JD's scope against its title | Which channels will someone else own in year one, and what budget and headcount are committed? | unresolved |
| RR3 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may come without a fixed definition of success | `[inferred]` from the JD's silence on targets | What three numbers define success at six and twelve months? | unresolved |
| RR4 | Base below seniority | risk_signal | medium | "8+ years" against $70–85k base | Pay may sit well below market for this seniority | `[inferred]` from JD figures; band not verified (search refused) | What is the approved base range for this role? | unresolved |
| RR5 | Employer not verified | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A)" | Research was refused, so the employer could not be checked. This is not a finding against the company | `[generic]` pattern for early-stage postings, not a claim about this employer | Can you point me to the live role on Novaline's own careers page? | unresolved |

**Application plan**
| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting as written | R1 and R2 fail | `[grounded]` gate rows | pending your approval |
| P2 | If you still want to look, check Novaline's own careers page for this role before anything else | RR5 | `[generic]` pattern | pending your approval |
| P3 | Put the effort into remote roles with a stated base at or above $150k | Your two constraints | `[grounded]` your stated constraints | pending your approval |

**Evidence status**
Verified: R1 and R2 (your own stated constraints, confirmed by you). Everything else is your prose self-report, unverified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was declined. This would have confirmed Novaline exists and whether the role is live (RR5) |
| 2. Role-family sweep | unavailable | Search was declined. This would have set the market band for R3–R6 and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**
- Search access, or a link to Novaline's careers page → target 1 clears or confirms RR5.
- Search access → target 2 sets a market band for RR4. Until then, the pay gap rests only on the posted figures.
- A live posting that changes the on-site and pay terms → R1 and R2 would be re-underwritten.
- A work sample for SEO, PR or partnerships → R7–R9 would move from `unclear` to `direct` or `adjacent`.

I can write this up as a `tuesday-dossier.md` you can keep if that would help.

No questions this turn: the decision is stable, and asking would not change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.