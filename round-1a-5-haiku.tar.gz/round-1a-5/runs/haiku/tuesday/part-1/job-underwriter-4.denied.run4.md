**Yes, it's worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6, R7a, R8a · adjacent: R7b (monitor rating models), R8b (recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (pet-insurance product)

R4 — GLM confirmed, the core skill; R7b — "maintained" is not "monitored", and the cadence is unstated; R8b — underwriting audience only so far; R10 — motor rating transfers, pet risk does not; R1 — your location and right to work are not stated.

**Opportunity ledger.** Sound on the role's terms: the responsibilities are concrete (RR3, positive). Pay is withheld (RR4), the employer and live posting are unchecked (RR2), and line-management expectations are unstated (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: UK base and right to work. If not, this becomes `no_go`. (2) The posting confirmed live on Brindlemoor's own careers page (RR2). (3) Line-management scope answered (RR1). If the role carries a team, that is a new gap you would need to address plainly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: rating models, price tests, recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A specific analytics remit; management is not mentioned | `[inferred]` from the JD's responsibilities against its silence on management |
| Market calibration | Not established: no search ran, so there is no band | — |
| Unknowns | Pay; line-management scope; employer and posting status; monitoring duty; product audience | — |
| Contradictions | None within the JD as pasted; not checked against the careers page | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK (base and right to work) | hard_gate | unclear | none | hard_gate | Nothing stated about your location or right to work | `[grounded]` JD term; no candidate statement | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior; stated at intake, no inspectable proof yet | `[grounded]` your intake statement | Attach CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no sample yet | `[grounded]` your intake statement | Request an anonymised query or script |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; specific, no artifact yet | `[grounded]` your intake statement | Anonymised model summary would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to head of underwriting; no actuarial audience claimed | `[grounded]` your intake statement | none |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests with the underwriting team last year | `[grounded]` your intake statement | Anonymised write-up would raise to high |
| R7a | Building rating models | important | direct | medium | none | Built the young-driver GLM | `[grounded]` your intake statement | none |
| R7b | Monitoring rating models | important | adjacent | medium | discovery | "Maintained" is near monitoring; cadence and metrics not stated | `[inferred]` from "maintained" set against "monitor" | Q2 |
| R8a | Recommendations for underwriting | important | direct | medium | none | Quarterly review to head of underwriting | `[grounded]` your intake statement | none |
| R8b | Recommendations for product | important | adjacent | medium | transferability | Underwriting audience only so far | `[inferred]` from "underwriting and product" in the JD | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer; insurance, not pet | `[grounded]` your intake statement | none |
| R10 | Pet-insurance product knowledge (not a stated requirement; implied by "our pet-insurance product") | preferred | adjacent | medium | transferability | No pet work. Motor rating carries over; pet risk drivers and claims behaviour do not | `[grounded]` "never worked on pet insurance"; `[generic]` that pet risk drivers differ from motor | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring the GLM (R7b, important) | discovery | "Maintained" is stated; cadence, metrics and drift response are not | Decides whether R7 reads direct across build and monitor | Routine performance checks on the model, drift investigations, reports you produced on it | A monitoring pack or model-review note | `[inferred]` from the JD's "build and monitor"; `[generic]` that monitoring is a standard GLM-owner duty |
| G2 | Pet-insurance context (R10, preferred) | transferability | No pet work; motor rating mechanics stated | A pet-specific interviewer will probe where motor stops applying | Any non-motor pricing work, claims-frequency analysis on another line, vet-cost or companion-animal data | An anonymised pricing paper from any line | `[grounded]` intake; `[generic]` that pet risk drivers differ from motor |
| G3 | Product audience (R8b, important) | transferability | Recommendations to underwriting only | The JD names product as a recipient | A product or cover-change recommendation you fed into | A product paper or decision note | `[inferred]` from the JD's "underwriting and product" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line-management expectation unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | A senior title may carry team or people-leadership expectations the posting does not state | `[generic]` senior-title pattern; `[grounded]` JD silence on management | "Does this role line-manage anyone now or planned, and what does the senior scope include beyond analytics?" | unresolved |
| RR2 | Employer and live posting not checked | unknown | — | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The posting may be live and the employer as described; this has not been checked | `[grounded]` research refused, so nothing was established either way | "Can you point me at this role on Brindlemoor's own careers page, and who would I be interviewing with?" | unresolved |
| RR3 | Concrete analytics scope | positive_signal | — | "Build and monitor rating models … design and read price tests" | The scope is specific, not a vague mandate | `[inferred]` from the JD's responsibilities | "Which of these rating models would this role own from day one, and which already exist?" | noted |
| RR4 | Pay withheld | unknown | — | No salary in the posting as pasted | The band cannot be calibrated; pay may be left open for negotiation | `[grounded]` JD silence; `[generic]` on negotiation practice | "What is the base salary range for this role?" | unresolved |
| RR5 | Pet-domain ramp-up | risk_signal | low | "our pet-insurance product" | Pet risk drivers and claims behaviour differ from motor, so early months may be slower than a motor-to-motor move | `[generic]` pattern for moves between lines; `[grounded]` no pet work | "What pet claims data and pricing documentation would I have access to in the first three months?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the GLM build, the 14 price tests and the underwriting review | The most specific must-have claims | `[grounded]` R4, R5, R6 | pending your approval |
| P2 | Frame motor pricing as the bridge to pet pricing, with the limit named in the first sentence | A bridge with no stated limit overreaches | `[grounded]` R10; `[generic]` the limit | pending your approval |
| P3 | Confirm UK base and right to work before investing in the application | Hard gate unconfirmed | `[grounded]` R1 | pending your approval |
| P4 | Check the live posting on Brindlemoor's careers page and note who would interview you | RR2 | `[grounded]` RR2 | pending your approval |
| P5 | Put RR1 and RR4 to the employer, verbatim | Both are unknowns that can change the decision | `[grounded]` register | pending your approval |
| P6 | Prepare a plain account of what "maintained" covered | R7b is adjacent until this is answered | `[inferred]` from R7b | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All three search calls were refused by this session's permissions. Nothing was checked and no call was retried. Would have moved RR2 and whether the employer exists as described |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a market pay band for RR4 |
| 3. Hiring manager's public footprint | unavailable | Same refusal. You gave the name Odile Varga; would have informed positioning for this reader |

If you want a record of this, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- An anonymised model summary or validation note for the young-driver GLM → R4 to `high`.
- An anonymised write-up of one of the 14 price tests → R6 to `high`.
- Permission to run web search this session → the three checks above (employer and posting, pay band, the hiring manager's public footprint), capped at 5 searches and 2 fetches. I'd ask before running them.
- Your CV, pasted → checks the intake against the document. It does not raise any band without an artifact.
- A pet-adjacent example (Q3) → R10's bridge.

## Questions

**Q1 — R1:** Are you based in the UK, and do you have the right to work there without sponsorship?

**Q2 — R7b:** When you maintained the young-driver GLM, how often did you check it, which metrics did you watch, and what did you do when they drifted?

**Q3 — R10:** What pricing exposure do you have that is close to pet? For example: any companion-animal or livestock work, claims-frequency work on another non-motor line, or vet-cost data.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.