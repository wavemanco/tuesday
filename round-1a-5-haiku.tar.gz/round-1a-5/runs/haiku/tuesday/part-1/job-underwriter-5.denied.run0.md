**Probably worth applying to, but the call waits on one answer: are you eligible to work from a US location, remote or in Denver? Status: `hold_pending_answers`.** If the answer is yes, it becomes `conditional_go` on the conditions below. If the answer is no, it becomes `no_go`.

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote US or Denver office)
- `must_have`: direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4 (dbt and a cloud warehouse), R5 (orchestration with Airflow or similar), R6 (data quality testing)
- `important`: adjacent: R7 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R1 is the gate to clear. R7 is a transfer to frame honestly. R8 and R9 are unexamined, since your intake doesn't mention them.

**Opportunity ledger.** Pay is stated and overlaps the middle and top of the Senior band's interquartile range (RR2, positive). The employer is unverified because research was unavailable (RR1, `severity: medium`). Team size and the hiring manager are open (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** For `conditional_go`: R1 confirmed; the live posting confirmed on the employer's careers page (RR1); BigQuery framed as adjacent, never as experience you have (R7). For `no_go`: R1 answered no.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` company's own about page, not verified |
| Mandate | Pipelines behind tutoring reporting: app and CRM ingestion, dbt models in BigQuery, data contracts | `[grounded]` JD |
| Working pattern | Remote US or Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Market calibration | Senior data engineers at Series B–D: base median $151,000, IQR $139,000–$163,500. "Senior" usually means 5–8 years, with one domain's pipelines and no direct reports. Your 6 years fit, and the posted range spans the median and reaches just above the IQR top | `[generic]` band from the pasted Datawright report; `[grounded]` its figures |
| Unknowns | Whether pay is base or total; equity size; team size; contract type; hiring manager | — |
| Contradictions | None in what you shared | `[grounded]` JD against the about page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in what you shared, so the gate isn't settled | `[grounded]` JD term | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported and uninspected | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use for six years, self-reported | `[grounded]` your intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, self-reported | `[grounded]` your intake | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in use, self-reported | `[grounded]` your intake | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R7 | BigQuery warehouse (in the role description) | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery-specific cost and access patterns are unexercised, and you've never used it | `[grounded]` your statement; `[inferred]` that Snowflake transfers | G1 |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your intake | `[inferred]` from the role's scope | G2, Q2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your intake | `[inferred]` from the role's scope | G2, Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Snowflake and dbt experience; no BigQuery | Named in the role's scope; the likeliest objection | A small BigQuery dbt project you can show. Frame it as transferable with limits | `[inferred]` transfer; `[grounded]` your statement |
| G2 | Ingestion and data contracts (R8, R9, important) | discovery | Neither is in what you shared | Two responsibilities; I can't tell whether you have them | Named source systems (app database, CRM) and one contract analysts used | `[inferred]` these are what the role probes |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (research unavailable) | risk_signal | `severity: medium` | "Build and run the pipelines behind our tutoring platform's reporting" | Existence and posting liveness are unconfirmed. Companies this size may be too new, have stale postings, or not hire directly | `[generic]` pattern for companies of this size, not a claim about this one | "Can you confirm this role is open on your careers page, and who I would interview with?" | unresolved |
| RR2 | Pay stated | positive_signal | — | "$148,000–$166,000 plus equity" | Transparent pay in the band; base or total is unclear | `[grounded]` JD; `[generic]` band | "Is the $148,000–$166,000 base, and what is the equity worth?" | noted |
| RR3 | Team scope unstated | unknown | — | "Build and run the pipelines…" | Ownership of one domain is typical; team size and on-call are not stated | `[inferred]` from silence on team | "Who else is on the data team, and what does on-call cover for these pipelines?" | unresolved |
| RR4 | Hiring manager not named | unknown | — | (none named) | Unknown | `[grounded]` posting | "Who would I report to, and who owns the hiring decision?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1 on location | R1 gate | `[grounded]` R1 | your answer |
| A2 | Check the live posting yourself, then put RR1's question to the employer | RR1 | `[grounded]` RR1 | your call |
| A3 | Lead with the Snowflake dbt scale and the test suite, and say BigQuery is new: "I built a dbt project of about 180 models on Snowflake and set up the Great Expectations test suite. I haven't run BigQuery yet; I'd expect the dbt work to carry over." | R4, R6, R7 | `[grounded]` your sentences | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent and both were refused by the session's permissions, so nothing returned. Would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | skipped | The pasted Datawright report already fixes the market band and the Senior scope read |
| 3. Hiring manager's public footprint | n/a | No name was given, and the posting names none |

I can write this up as `tuesday-dossier.md` so the next pass starts from it.

**Upgrade menu**

- Your location answer → R1 closes, and the status moves to `conditional_go` (yes) or `no_go` (no).
- A CV or repo excerpt → R2–R6 move from `medium` to `high` only with an inspectable artifact, such as a sanitized dbt or test-suite excerpt.
- A small BigQuery dbt project → R7 strengthens from adjacent toward direct.
- A sanitized ingestion or contract example → R8 and R9 can be assessed.
- Whether pay is base or total, and the equity size → RR2 closes.
- A live check of the company and posting, which needs web search enabled in this session → RR1 closes or stays open.

**Questions**

R1 — Can you work from a US location for this role, either remote in the US or from Denver?

R8, R9 — Have you built ingestion from an app database and a CRM, or owned a data contract analysts relied on? Name the systems and what you owned.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.