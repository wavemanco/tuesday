**Yes, apply, but as a conditional go.** Your pipeline, renewal and Salesforce work covers most of the role. The two must-haves you can't yet claim are owning the forecast and working with billing data, and the posting doesn't tell us how much of either this role would actually own.

**Decision snapshot**

- **Status: `conditional_go`.** Apply once the conditions below hold.
- **Fit ledger:**
  - `hard_gate`: unclear: R9 (Bristol, two office days a week), R10 (£61,500–£67,000 salary)
  - `must_have`: direct: R1 (4+ years RevOps or sales ops), R2 (Salesforce admin), R3 (SQL) · adjacent: R4 (spreadsheet modelling), R5 (owning a forecast), R6 (finance on billing or revenue data)
  - `important`: direct: R7 (pipeline and renewal reporting) · absent: R8 (owning billing data)
  - R5 and R6 are the two that bear on the decision.
- **Hard gates:** none failed; unconfirmed: R9 (Bristol, two office days a week), R10 (£61,500–£67,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The forecast is shared with the CFO and this role is not sole owner of the number (RR1).
  2. The billing data scope is something you can learn, not something you're expected to already run (RR2).
  3. Bristol two days a week and the salary both work for you. Neither is in what you've told me yet.
- **What would change this:** if the forecast is the role's to sign off and billing is core from day one, the fit moves toward a hold, and a hard-gate answer on location or pay could move it to `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: UK invoicing and payments software for builders' merchants, founded 2018 in Bristol, 96 staff, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (web research) |
| Scope | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Market calibration | UK B2B software revenue-ops lead: median base £64,200, interquartile range £57,800–£70,400 (n=438) — the posting's £61.5k–£67k sits inside that range, near the middle | `[generic]` Ledgerline 2026 pay guide; not this employer's offer |
| Hiring manager | Tamsin Achebe: Head of Revenue Operations at Quillfield; previously four years in sales operations at Corvane Payments | `[grounded]` public professional profile (web research) |
| Contradictions | None found between the posting and what I could verify | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 4+ years RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, two running RevOps. Your employer was a B2B payments company, close to software but not the same | `[grounded]` your statement; `[inferred]` payments-to-software match |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet seen | `[grounded]` your statement |
| R3 | Strong SQL | must_have | direct | medium | none | SQL weekly, self-reported | `[grounded]` your statement |
| R4 | Spreadsheet modelling | must_have | adjacent | low | transferability | Excel daily, but nothing yet on building models or forecasts in it | `[grounded]` your statement; `[inferred]` daily use is not modelling |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which feeds forecasts. Limit: finance owned the company forecast, not you | `[grounded]` your statement |
| R6 | Working with finance on billing or revenue data | must_have | adjacent | low | transferability | Renewal and pipeline dashboards are revenue data. No billing data and no described work with finance on it | `[grounded]` your statement |
| R7 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt both dashboards | `[grounded]` your statement |
| R8 | Own billing data (implied by "own our CRM and billing data") | important | absent | none | discovery | No billing evidence yet; you may have touched it as a user | `[grounded]` your statement, silence on billing |
| R9 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | Your constraints weren't given | `[grounded]` posting |
| R10 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your salary floor wasn't given | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO signs it off | `[inferred]` from "with the CFO" | Who holds the final forecast number, and what does this role own versus finance? | unresolved |
| RR2 | Billing data scope unclear | unknown | — | "own our CRM and billing data" | Billing may sit with finance systems, and the role may own only CRM data | `[inferred]` from the scope line against silence on who runs billing | What billing data would this role own day to day, and who owns the billing system? | unresolved |
| RR3 | Posting source not confirmed on the employer's own site | unknown | — | Posting on tallyboard.example | The posting may be aggregated or stale; my search found Quillfield's About page but not a careers listing | `[generic]` pattern for job-board reposts | Is this role advertised on Quillfield's own careers page, and who is the hiring manager? | unresolved |
| RR4 | Hiring manager's background matches yours | positive_signal | — | Public profile: sales operations at a payments company, then Head of RevOps | Your path may be familiar to her | `[grounded]` public profile | How did the RevOps role at Quillfield develop from sales operations? | noted |

The employer exists (About page), so the standing "employer not established" entry does not fire. RR3 stays an open unknown, not a cap.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pipeline and renewal dashboards and the monthly pipeline review, not with forecasting | R5, R7 | `[grounded]` your statements | pending your approval |
| A2 | Proposed wording: "I rebuilt our pipeline and renewal dashboards and run the monthly pipeline review with our sales director. I haven't owned a forecast; I've supplied its pipeline inputs, and I want to learn the finance side of revenue data." | Honest about R5 and R6 | `[grounded]` your statements; reframing audit: no clause beyond them | pending your approval |
| A3 | Ask RR1, RR2 and RR3 in the first call or interview | Register doubles as prep | `[grounded]` register | pending your approval |
| A4 | Check the Salesforce certificate is current and ready to show | Moves R2 toward high | `[grounded]` your statement | pending your approval |

**Evidence status**

Verified: none yet. Every claim above is your statement or public web material, not inspected evidence.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company". Returned quillfield.co.uk/about (entity: founded 2018, Bristol, 96 staff, Series A). No careers listing surfaced, so RR3 stays open |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK 2026". Returned the Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example), which set the market band |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield". Returned her public professional profile (linkedin.example) |

**Dossier offer:** I can save this as `tuesday-dossier.md` for the next steps, if you'd like.

**Upgrade menu**

- Your Salesforce certificate → R2 moves from medium to high.
- Any billing or invoice data you've used, even as a user, or any work with finance on revenue reporting → R6 and R8 could move up.
- Concrete forecast inputs you've supplied (for example, stage conversion or renewal rates you tracked) → R5 gets stronger without claiming ownership.
- The live Quillfield careers link, or the recruiter's email domain → RR3 closes.
- Your floor on salary and your position on Bristol → R9 and R10 resolve.

**Questions**

- R9 and R10: Can you do Bristol two days a week, and is £61,500–£67,000 above your floor? Answer in text or say skip.
- R8 and R6: Have you ever worked with billing or invoice data, even as a user, or with finance on revenue reporting? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.