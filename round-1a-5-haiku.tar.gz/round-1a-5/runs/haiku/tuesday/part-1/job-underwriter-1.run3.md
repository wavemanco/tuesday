**Yes, you fit the core of this role, and it's worth applying to once the employer checks out: `conditional_go`.** The posting is specific and your stated background covers its must-haves. The gaps are clinician work, mentoring, and healthcare data. The company checks didn't run (see Evidence status), so the employer is unverified.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5 (define and maintain the metrics layer)
- `important`: direct: R7 · adjacent: R8 (partner with clinicians) · unclear: R9 (mentor two junior analysts)
- `preferred`: adjacent: R10 (healthcare data experience, HIPAA)

Reading the rows: R5 is inferred from your dashboard and memo work, not stated; R8 is non-clinical stakeholder work only; R9 has no mentoring stated either way; R10 is consumer PII, not PHI.

**Opportunity ledger.** The posting is specific about scope and outcomes (RR3, positive). It states no pay (RR2), and the employer is not verified (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight's live posting found on its own careers page (RR1); (2) your location, pay floor, authorization and start date checked against the role (Q1); (3) R8 and R9 acceptable to you, or confirmed as covered in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, as stated in the posting you pasted | `[grounded]` JD; not checked against the company's site |
| Mandate | Product analytics for the care-navigation app | `[grounded]` JD |
| Scope read | Metrics layer, A/B tests, Looker, PM and clinician partnership, mentoring two analysts: senior, with people leadership | `[inferred]` from the listed responsibilities |
| Market calibration | Not run; the role-family search was refused, so there is no pay band | — |
| Unknowns | Pay, location, contract type, team structure, clinician reporting line | — |
| Contradictions | None visible within the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one subscription company, as stated; no artifact yet | `[grounded]` your stated background | upgrade menu |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, as stated; "expert" is a level claim nothing inspectable supports yet | `[grounded]` stated | SQL sample (upgrade menu) |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift, as stated; the 11% is that test's result, not a program-wide figure | `[grounded]` stated | test readout (upgrade menu) |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards, as stated | `[grounded]` stated | dashboard screenshot (upgrade menu) |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and a monthly memo imply metric definitions; no statement that you owned a shared definitions layer | `[inferred]` from stated dashboard and memo work | Q3 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec memo and presents monthly to the VP Product, as stated | `[grounded]` stated | memo excerpt (upgrade menu) |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | PM and VP-level work is stated; the link from analysis to a specific roadmap decision is implied, not stated | `[grounded]` stated | none |
| R8 | Partner with clinicians | important | adjacent | medium | transferability | Non-clinical stakeholders only (executives, PMs); no clinician work stated | `[grounded]` stated | G2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Nothing stated either way | `[grounded]` absence in your background | Q2 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI, no HIPAA controls, no clinical data | `[grounded]` stated | G3 |

Every `medium` above is your own statement with no inspectable artifact yet; each one is expected to draw a probe in interviews.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | transferability | Dashboards and memo work; no stated ownership of shared metric definitions | A must-have; it is the objection most likely in the first screen | Defining a metric once for several dashboards; resolving two teams' disagreement on one number; versioning a definition | A metric-definitions doc or list you maintained | `[inferred]` from R5's basis |
| G2 | Clinician partnership (R8, important) | transferability | Non-clinical stakeholders only | Clinicians are the stakeholder group the JD names next to PMs | Working with a domain expert (a pricing or logistics ops lead) to reach a decision | A case where a domain expert changed your analysis | `[generic]` that domain-expert partnership is probed in this role family |
| G3 | Healthcare data (R10, preferred) | transferability | Consumer PII and consent work; no PHI or HIPAA | Preferred, so a minor risk; the bridge is real but limited | Consent-state design under GDPR/CCPA, data minimization, access controls | Any written consent or access policy you worked on, sanitized | `[grounded]` stated background |
| G4 | Mentoring (R9, important) | discovery | Nothing stated | Mentoring two analysts is explicit in the JD | Onboarding or reviewing an analyst's SQL; running a team's analysis review | Q2's answer | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company checks did not run, so this records an unverified employer, not a finding about it. The posting may be stale or aggregated, or the company may be too new or small to have a footprint. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me to this role on your careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay in the posting) | The band may sit below what this scope usually pays, or the company may not publish pay | `[inferred]` from the posting's silence on pay | "What is the base salary range for this role?" | unresolved |
| RR3 | Outcomes and scope named | positive_signal | — | "Own product analytics for our care-navigation app: define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | Scope is concrete and matches your stated experience | `[grounded]` JD | "Who owns the metrics layer today, and where does it sit?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your experience bullets with the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, in your own words | R3; the numbers stay attached to their nouns | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | Describe the consent-state model as GDPR/CCPA consumer work; don't describe it as HIPAA or clinical | R10; avoids a healthcare claim you can't support | `[grounded]` stated background; reframing audit | resume_edits_pending_approval |
| A1 | Verify the live posting on Harborlight's own careers page before you invest in the application | RR1 | `[inferred]` from RR1 | proposed |
| A2 | Hold the application until Q1 is answered, so the hard-gate checks run before you invest | Constraints unknown | `[grounded]` the snapshot's hard-gates line | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and the role were refused. They would have checked that the company exists as described and that the posting is live, which decides RR1 |
| 2. Role-family sweep | unavailable | The search was refused. It would have set the pay band for market calibration and the scope norm for this title |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Both `unavailable` rows are a permission issue, not a judgement that the search wasn't worth running.

Your background is self-report, so every claim above rests on your word until you show an artifact.

## Upgrade menu

- A sanitized Looker dashboard screenshot or a SQL sample from your warehouse → R2 and R4 from `medium` to `high`.
- A sanitized experiment readout or design doc → R3 from `medium` to `high`.
- A sanitized excerpt of the monthly metrics memo → R6 from `medium` to `high`.
- A metric-definitions list or docs you maintained → R5 from adjacent toward direct.
- The live posting link, or the recruiter's answer on pay → RR1 and RR2 resolve.
- Permission to rerun the three company searches. They were refused here; if allowed, I'll run them and record the results.
- A deeper company pass (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you'd like to keep this, I can save it as `tuesday-dossier.md` for reuse in interview prep.

1. **Q1 (constraints):** Which of these are non-negotiable for you: work location or pattern, a pay floor, work authorization for the country this role sits in, and your earliest start date?
2. **Q2 (R9, mentoring):** Have you mentored or managed junior analysts, formally or informally? If so, how many, over what period, and what did you own: hiring, reviews, growth plans, or only day-to-day pairing?
3. **Q3 (R5, metrics layer):** In your warehouse, did you own the metric definitions behind the dashboards and memo, such as a shared, versioned definitions layer, or did another team own them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.