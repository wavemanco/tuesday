**No, applying isn't a waste of time, but the 3+ years product-management line is the real objection and the application should be built around it.** `conditional_go`

**Fit ledger.**

- `must_have`: direct: R3, R4, R5, R6 · adjacent: R1a (3+ years product management, product-adjacent work), R2 (shipped API or platform products) · absent: R1b (3+ years product management, titled ownership)
- `important`: adjacent: R9 (launch coordination with sales and support) · unclear: R7 (agile delivery), R8 (adoption metrics)

R1a — product-adjacent work, no titled ownership; R2 — integration delivery, not product ownership; R1b — no product-manager years on the CV; R7 — agile delivery not stated; R8 — adoption metrics not evidenced; R9 — sales and support launch work not stated.

**Opportunity ledger.** The posting is concrete: named ownership of a partner API platform, two squads, and year-one adoption metrics (RR3). Product authority over squad priorities is not stated (RR1), and pay and location are withheld (RR2). The years bar is a common screening line, so it may end the application before the work is read (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name roadmap or priority decisions you made or co-made, which settles R1b and RR1; (2) pay and location are confirmed before you invest in interviews (RR2); (3) the product-adjacent story is told as adjacent, with its limits, never as titled product experience (R1a, RR4).

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` your description of the JD |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launch coordination | `[grounded]` JD |
| Scope read | Owning a platform roadmap plus two squads is a senior IC-to-lead step, not an entry PM role | `[inferred]` from the JD's scope against the listed duties |
| Market calibration | Not run; no search was permitted | — |
| Unknowns | Decision rights over squad priorities; pay; location; reporting line | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

**Evidence map.** Confidence grades your CV claims, which are self-reported and unprobed, so `medium` is the ceiling.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management: product-adjacent work | must_have | adjacent | medium | transferability | Requirements, roadmap-input sessions and PM coordination are product-adjacent; no product-owner title or decision rights stated | `[grounded]` CV | Q1 |
| R1b | 3+ years product management: titled ownership | must_have | absent | none | discovery | No PM title on the CV. The years line is not a legal gate, so it is graded on fit, not treated as disqualifying | `[grounded]` CV silence | Q1; if no product years exist, see RR4 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end; these were client deliveries, not a product you owned | `[grounded]` CV | Bridge: integration delivery as platform evidence. Limit: no product ownership |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI and integration architecture are stated; no inspectable artifact yet | `[grounded]` CV | Upgrade menu: an integration architecture doc would raise to `high` |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | presentation | Coordinated engineers, client engineers and PMs on custom builds; sales not stated | `[grounded]` CV | Lead with the coordination example; claim no sales work |
| R5 | Discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and quarterly roadmap-input sessions collecting client feedback | `[grounded]` CV | E1 |
| R6 | Write specs and drive delivery | must_have | direct | medium | presentation | Requirements documents and go-live for 30+ builds | `[grounded]` CV | E1 |
| R7 | Agile delivery | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Upgrade menu |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metrics on the CV; the triage-tool lead is unconfirmed | `[grounded]` CV silence; memory lead unconfirmed | Q2 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination; no sales or support launch on the CV | `[grounded]` CV | Bridge with limit named |

**Gap recovery queue.** These rows say what each gap is and what would close it. Their questions are in the closing block.

- **G1 (R1a, R1b):** The gap is product decision rights. Closes with a named decision you made or co-made.
- **G2 (R8):** The gap is adoption metrics. The triage-tool lead, if confirmed, could carry it.
- **G3 (R7):** The gap is agile cadence. Closes with a sprint board, backlog export or a described ceremony cadence.

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership asserted, squad priority authority not stated | unknown | — | "own the roadmap" | Role may own the roadmap while squad priorities sit with engineering leads | `[inferred]` from "own the roadmap" against silence on squad priorities | Who sets the priority order across the two squads, and which decisions does this role make alone? | unresolved |
| RR2 | Pay and location withheld | unknown | — | (not stated) | The posting may withhold pay as a policy; the band is unknown | `[inferred]` from the posting's silence | What is the base range for this role, and where is it based? | unresolved |
| RR3 | Concrete scope and metrics | positive_signal | — | "define and track adoption metrics" | Success is measurable, so ownership can be tested | `[grounded]` JD | What adoption metric is this role accountable for in year one? | noted |
| RR4 | Years bar may be screened literally | risk_signal | medium | "3+ years product management experience" | A literal screen could end the application before the adjacent work is read | `[generic]` pattern for PM screening, not a claim about this employer | Would you consider a candidate whose product work came through integration delivery, if they can show owned roadmap decisions? | unresolved |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reword the discovery and spec bullets to say what you did: "Ran quarterly roadmap-input sessions with client integration teams and fed their feedback into product planning." | Claims no title and no decision rights | `[grounded]` CV sentences | pending your approval |
| A1 | Address the years line in the cover note directly: state the product-adjacent years and the decisions you did make | RR4, R1a | `[generic]` screening pattern | pending your approval |
| Q1 | Ask RR1 and RR2 in the first recruiter call | Both decide whether to invest in interviews | `[grounded]` register | pending your approval |

The `resume-tailor` module can draft E1 and A1 as a full edit ledger if you want it.

**Evidence status.** Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused for lack of permission. Would have checked that Quartzline exists as described and that the posting is live. Until then, the employer is unverified, which is why the decision stays at `conditional_go` |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market band for pay and scope, which would clear RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu.**

- Permission to run the refused searches → checks Quartzline's existence and the posting, and sets the pay band for RR2.
- A product artifact (a roadmap, spec, adoption metric, or the triage tool write-up) → R1b and R8 move.
- A sprint board or backlog export → R7 moves.
- An integration architecture doc, sanitized → R3 to `high`.
- Your constraints (location, work authorization, pay floor, contract type) → the hard-gate checks run.

Questions:

- R1a, R1b (G1): Which roadmap or priority decisions did you make on the integration work, and whose sign-off did they need?
- R8 (G2): Did you build an internal request-triage tool that support agents adopted? If so, what did it do, who decided to build it, and how did you measure use?
- Candidate constraints: What are your non-negotiables for this role, including where you can work from, any work-authorization limit, your pay floor, and contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

I can also write a `tuesday-dossier.md` that carries this assessment into later sessions.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.