**Not a waste of time, but a stretch on the part of the job that matters most. Status: `conditional_go`.** Apply if you can answer the first condition below with a real product decision you drove. Your strongest matches are technical fluency, stakeholder work and client launches. The weakest is owning a roadmap, and the posting's first requirement is a literal 3+ years of PM experience you don't have.

**Fit ledger.**

- `must_have`: direct: R3, R4 · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products), R9 (own the roadmap) · unclear: R6 (agile delivery)
- `important`: direct: R5, R8 · unclear: R7 (adoption metrics)

R9 — roadmap ownership, the job's core, is input without decisions; R1 — no PM-titled years; R2 — integrations shipped for clients, not product calls; R6 — no agile evidence yet; R7 — adoption metrics, `low`, a lead only.

**Opportunity ledger.** The scope is concrete and stated (RR4); pay, location and the employer's own existence are unknown (RR2, RR3); and the literal 3+ years line may act as a screen before a person reads your CV (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name a product decision that was yours end to end (R9, R1); (2) you have a concrete agile or metrics example (R6, R7); (3) the posting is confirmed on Quartzline's own careers page (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` posting |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs for two engineering squads; define and track adoption metrics; coordinate launches | `[grounded]` posting |
| Scope read | One platform, two squads, named metrics: a defined remit for a product manager | `[inferred]` from the listed responsibilities |
| Market calibration | Not run. The salary and role-family search was refused (see research table) | — |
| Unknowns | Pay, location, reporting line, whether decision rights sit with you or with product leadership | — |
| Contradictions | None visible within the posting | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | Seven years of solutions and implementation work, no PM-titled years. A length-of-experience bar, graded here, not a gate | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client REST integrations shipped end to end. You did not own the product those ran on | `[grounded]` CV | G1 |
| R3 | Reads API docs, discusses schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI named; integration architecture led | `[grounded]` CV | Expect a probe in interview |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs. Sales is not named | `[grounded]` CV | Name sales work if it is real |
| R5 | Partner discovery | important | direct | medium | none | Scoping workshops and quarterly client roadmap-input sessions | `[grounded]` CV | none |
| R6 | Agile delivery with engineering squads | must_have | unclear | low | discovery | Requirements documents written; no sprint, squad or release cadence named | `[grounded]` CV silence | G3 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | No metric in the CV. An unconfirmed lead exists; it is a question basis, not evidence | `[grounded]` CV silence; memory lead | G2 |
| R8 | Coordinate launches with sales and support | important | direct | medium | none | Owned UAT and go-live for client integrations. Support is not named | `[grounded]` CV | none |
| R9 | Own the roadmap for the partner API platform | must_have | adjacent | medium | transferability | Ran roadmap-input sessions that fed product. You contributed input; the CV does not show you setting priorities | `[grounded]` CV | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product decisions (R9, R1, R2) | transferability | Influence on the roadmap through client feedback; no decision recorded as yours | This is the job's core. The bridge's limit is decision rights | Any scope cut, priority call or release you made, even if product signed off on it | A roadmap or release note; your feedback-session summary | `[inferred]` bridge from the roadmap-input sessions; `[generic]` that PM interviews probe decision rights |
| G2 | Adoption metrics (R7) | discovery | Silent in the CV; an unconfirmed lead | The posting names metrics; a confirmed example moves R7 | Any integration or internal tool where you tracked uptake or usage | An adoption figure or dashboard export | `[grounded]` CV silence |
| G3 | Agile delivery (R6) | discovery | Specs and requirements, no cadence named | A must-have. A clear answer could move R6 to `direct` | Sprint planning with an engineering team, backlog ownership, releases on a cadence | A sprint board or a description of the ceremonies you ran | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Literal years bar may screen before a human reads | risk_signal | medium | "3+ years product management experience (must-have)" | Screens often apply a stated years bar literally, so your CV may not reach a person | `[generic]` pattern for must-have experience bars, not a claim about this employer | "Would you consider PM experience gained in adjacent roles, and what would count?" | unresolved |
| RR2 | Pay and location not stated | unknown | — | No compensation or location in the posting | The figures may be withheld or may sit outside the text provided | `[grounded]` posting silence | "What is the base salary range, and where is the role based?" | unresolved |
| RR3 | Employer and live posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Unverified in this run: the search that would check it was refused | `[grounded]` refused search, no result | "Can you point me to this posting on your careers page, and who would I interview with?" | unresolved |
| RR4 | Concrete scope and authority stated | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Scope is defined: one platform, two squads, named metrics | `[grounded]` posting | "Which two decisions would this role make without sign-off?" | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting on Quartzline's own careers page before you spend effort on it | RR3 | `[grounded]` RR3 | Advice; your call |
| P2 | Lead with the 30+ integrations and the roadmap-input sessions, framed as shaping product input rather than as a product manager's title | R9, R1 | `[grounded]` CV | Pending your approval |
| P3 | Draft one plain answer to the 3+ years line: seven years in adjacent roles, no titled PM years, and what overlaps | R1, RR1 | `[grounded]` CV | Pending your approval |
| P4 | Leave the triage tool off your materials until you confirm it and its adoption | R7 | `[grounded]` memory lead, unconfirmed | Pending your approval |
| P5 | Look for a referral to a current employee before applying cold | RR1 | `[generic]` pattern: referred applications tend to get a human read at small companies | Pending your approval |

## Evidence status

Verified: none yet. Every claim above is your CV self-report, pending a probe. Unverified leads: the triage tool that support agents adopted (agent memory, unconfirmed). Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Quartzline and its posting were refused by the session's permissions. The employer and the live posting are unverified (RR3) |
| 2. Role-family sweep | unavailable | One search for role scope and salary was refused. Market calibration and the salary band did not run (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Enabling web search and sending me a posting link would close two of these. I can then rerun the checks.

Want me to save this as `tuesday-dossier.md`, so the next session can pick up from it?

**Upgrade menu**

- Web search permission granted → reruns target 1 and 2 checks, which settle RR3 and RR2 and give the salary band.
- The posting's link → closes RR3 and may close RR2.
- A roadmap, PRD or release note you shaped → moves R9 and R1 up from `adjacent`.
- Adoption figures from the triage tool or any integration → moves R7 from `low` to at least `medium`.
- A sprint board or a description of the ceremonies you ran → could move R6 to `direct`.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip)

- G1 — Think of a product decision in the last seven years that was effectively yours. What did you choose, what did you cut, and what happened?
- G2 — Did you build an internal tool or integration where you tracked adoption? If support agents used a triage tool you built, who used it, how did you know, and what changed?
- G3 — Have you worked inside a sprint or Kanban cadence with an engineering team? What was your role in it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.