## Decision snapshot

Yes, probably worth applying, as `conditional_go`. Your must-haves R3, R4, R5, R6 and R7 each read `direct` on what you've told me. The platform gap is BigQuery (R10, `adjacent`). Three things are unchecked: whether the posting is live, your location, and your pay floor.

**Fit ledger.**

- `hard_gate`: unclear: R1, R2
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R10 · unclear: R8, R9

R1 and R2: location and pay floor not given; R8 and R9: app/CRM ingestion and data contracts not in your background; R10: BigQuery, adjacent through your Snowflake dbt work.

**Opportunity ledger.** RR1: the employer and live posting are not verified here (`risk_signal`, medium), and that caps the decision at `conditional_go`. RR2, RR3 and RR5: scope, equity and hiring manager are unknown. RR4: the stated salary sits inside the market band (positive).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the posting is live on Pellucid's own careers page and the employer matches the About page; (2) R1 and R2 are met against your location and pay floor; (3) R10 is presented in interviews as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` About page as pasted; not checked against an outside source |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts analysts depend on | `[grounded]` JD |
| Scope read | Three areas (ingestion, warehouse, contracts) rather than one domain's pipelines | `[inferred]` from the JD's list against the typical scope below |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500; "senior" usually means 5–8 years; typical scope is one domain's pipelines, no direct reports | `[generic]` Datawright 2026 report (n=2,310), as sent by your recruiter; not checked against the source |
| Stated pay against band | Posted $148,000–$166,000; the midpoint ($157,000) sits inside the IQR and above the median | `[grounded]` JD range; `[inferred]` from comparing it with the band |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Equity terms; contract basis (permanent or fixed-term) not stated; hiring manager not named; whether this role owns the whole reporting stack | — |
| Contradictions | None found between the JD, the About page and the pay report | `[grounded]` the pasted material |

## Evidence map

Your background is self-report, so every claim tops out at `medium` at this stage.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location given, so the fit is not established | `[grounded]` JD term | Q1 |
| R2 | Salary $148,000–$166,000 plus equity (your pay floor) | hard_gate | unclear | none | hard_gate | No floor given; the posted range is calibrated in role reality | `[grounded]` JD term | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in your message; no artifact | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code sample | `[grounded]` your intake | A sanitized query or pipeline sample would raise this to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models | `[grounded]` your intake | A sanitized project outline would raise this to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, stated | `[grounded]` your intake | none |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing in your background names app or CRM sources; your payroll company's sources may match | `[inferred]` from the JD against your background | Q2 (G1) |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | No contracts mentioned; Great Expectations is quality testing, not a contract with consumers | `[inferred]` from the JD against your background | Q2 (G1) |
| R10 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery never used. Limit: platform specifics (cost model, partitioning, GCP access) not exercised | `[inferred]` adjacency; `[generic]` that these platform differences are the usual objection | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R8, R9, important) | discovery | Snowflake dbt, Airflow and Great Expectations are named; app/CRM sources and consumer contracts are not | Two named responsibilities, and the likeliest interview probe | Any source system that fed your warehouse and that you built or ran; freshness or schema agreements with analysts, even informal | A pipeline or DAG list, or a sanitized contracts doc | `[grounded]` background silence; `[inferred]` that interviews probe this |
| G2 | BigQuery warehouse (R10, important) | transferability | Snowflake dbt project of about 180 models; BigQuery never used | Named in the responsibilities; a probe is likely | dbt modelling and testing; Airflow orchestration | A small dbt project on BigQuery would narrow the limit | `[inferred]` bridge; `[generic]` that platform specifics are the usual objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified here | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | The posting may be stale or aggregated, or the employer may be too new or small for a findable footprint. Neither possibility is ranked as likely. This records no search result: the two searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | "Can you confirm this role is open on your careers page, and who I would be interviewing with?" | unresolved |
| RR2 | Scope may exceed one domain | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own the whole reporting stack with no team to share it | `[inferred]` from the JD's three-part list against the typical scope | "Which of these pipelines does this role own end to end, and who else is on the data team?" | unresolved |
| RR3 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity" | The equity value could be material or minor; terms are unknown | `[grounded]` posting text | "What is the equity grant: type, size, vesting schedule and valuation basis?" | unresolved |
| RR4 | Stated salary sits inside the band | positive_signal | — | "Salary $148,000–$166,000" | The figure is disclosed and falls inside the IQR | `[generic]` band; `[inferred]` from the comparison | "Is this base range fixed for the level, and how is it set?" | noted |
| RR5 | Hiring manager not named | unknown | — | Posting names no hiring manager | Reporting line unknown, which affects the scope read | `[grounded]` posting | "Who is the hiring manager, and who would I work alongside?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the posting is live on Pellucid's careers page before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Check the location and base against your constraints before spending application time | R1, R2 | `[grounded]` JD terms | pending your approval |
| E1 | CV line for the dbt work, using your own words: "Built our dbt project on Snowflake — about 180 models" | R5 | `[grounded]` your intake | resume_edits_pending_approval |
| P1 | Interview phrasing for BigQuery: "I haven't used BigQuery. My dbt work is on Snowflake, about 180 models, and I'd expect the modelling and testing to carry over." | R10 | `[grounded]` your sentences; "expect to carry over" is `[inferred]` | pending your approval |
| Q-prep | Ask RR2, RR3, RR5 verbatim in the first screen | Register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your message, which is self-report.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the permission prompt, so nothing returned. A check would have confirmed the entity and that the posting is live; that result moves RR1 and the cap on go |
| 2. Role-family sweep | skipped | The Datawright report you sent fixes the band and the scope norm, which are the only outputs this target feeds; the report itself is unchecked |
| 3. Hiring manager's public footprint | n/a | No name given; the posting names none |

## Upgrade menu

- Search permission granted: target 1 runs (up to 5 searches, 2 fetches), and RR1 either clears or hardens.
- Your location and pay floor: R1 and R2 move from unclear to met or failed. A failed gate would move the status to `no_go`.
- A sanitized pipeline or DAG list, or contracts doc: R8 and R9 move from unclear, and R5 can go to `high`.
- A small BigQuery dbt project: R10's limit narrows.
- Equity terms and the hiring manager's name: RR3 and RR5 close.
- Deeper research on Pellucid (funding, hiring patterns, recent news; up to 5 more searches and 2 more fetches): offered once. It also needs search permission.

Want this saved as `tuesday-dossier.md`? I can emit it from this assessment.

**R1 and R2:** Can you work remotely from the US or from Denver, and does a $148,000 base meet your floor?

**G1:** Have you built or owned ingestion from an app or CRM source, or agreed data contracts that analysts relied on? Say what the source was, what you owned, and who depended on it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.