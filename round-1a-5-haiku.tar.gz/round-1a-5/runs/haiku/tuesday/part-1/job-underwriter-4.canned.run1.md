**Yes, it's worth applying, but confirm the location before you do.** The posting contradicts itself: the JD says fully remote (UK), and the company's careers page says Leeds, four days a week. Your evidence fits well. Status: `conditional_go`.

**Decision snapshot**

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote UK vs Leeds four days a week)
- `must_have` — direct: R3 (GLM experience), R4 (4+ years pricing analytics), R5 (strong SQL and Python), R6 (presenting to underwriting leads), R7 (designing and reading price tests) · adjacent: R2 (build and monitor rating models; motor, not pet)
- `important` — direct: R8a (recommendations for underwriting) · unclear: R8b (recommendations for product)
- `preferred` — direct: R9 (insurance experience)

R2 — motor rating models only, pet product not yet touched; R8b — product recommendations not evidenced.

**Opportunity ledger.** Solid scope on the careers page, with the reporting line to the Director of Pricing stated (RR4). The location contradiction is a medium risk signal (RR1). The pet-product context is unknown (RR2), and the salary is not shown in the material (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK vs Leeds four days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location is confirmed as workable for you (RR1, R1); (2) the pet-product gap is named honestly in the application (R2, RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, with a live careers page on its own domain | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| People management | Not stated in the JD or the careers page; the role is not a people-management post as written | `[grounded]` absence in both |
| Working pattern | Contradictory: "Fully remote (UK)" in the JD, "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | Individual-contributor senior analyst scope with a defined product | `[inferred]` from the mandate and reporting line |
| Market calibration | UK pricing analytics pay survey 2026 (n=612): median £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 survey, a band not this employer's offer |
| Unknowns | Salary, the actual location pattern, the pet-product data and rating structure | — |
| Contradictions | Remote versus Leeds four days a week | `[grounded]` both sources |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: fully remote UK, or Leeds four days a week | hard_gate | unclear | none | hard_gate | The JD and the careers page disagree; your constraint is not given, so it cannot be checked | `[grounded]` both sources | Q1 |
| R2 | Build and monitor rating models | must_have | adjacent | medium | transferability | You built and maintained a GLM rating model for a motor young-driver book. Limit: not pet, and "maintained" is not the same as "monitored" | `[grounded]` your intake answer | E2 |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; limited inspectable proof so far | `[grounded]` your intake answer | Offer a sanitised model note |
| R4 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst | `[grounded]` your intake answer | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use; "strong" is your own word, so the claim is self-assessed | `[grounded]` your intake answer | none |
| R6 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake answer | none |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your intake answer | Offer a test readout |
| R8a | Recommendations for underwriting | important | direct | medium | none | Underwriting is where your test and review work landed | `[grounded]` your intake answer | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in the material shows product-side recommendations | `[grounded]` absence | Q2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer, five years | `[grounded]` your intake answer | none |

**Gap recovery queue** (questions sit in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product recommendations (R8b) | discovery | Underwriting-side evidence only | Could move R8b from unclear to direct | Any product decision you shaped through pricing work, such as a rate change or a product-rule change | A product memo, a launch note, a before/after readout | `[grounded]` absence; `[inferred]` that this is where the gap sits |
| G2 | Pet or non-motor rating (R2) | transferability | Motor rating only | The biggest distance between your CV and this JD | Any home, travel or other non-motor rating work, even partial | Rating-factor list or model summary | `[grounded]` CV scope; `[generic]` that pet rating differs from motor |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts itself | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two may be stale, or the post may have changed after publication | `[inferred]` from two contradictory sources | "Is this role fully remote, or Leeds four days a week? Which applies to this post?" | unresolved |
| RR2 | Pet-product context | unknown | — | "Insurance experience a plus"; "our pet-insurance product" | Pet rating may have structures or data that motor work does not cover | `[generic]` pattern for pet-versus-motor rating | "What does rating for the pet product look like today, and what would a motor-trained analyst need to learn first?" | unresolved |
| RR3 | Salary not shown | unknown | — | Neither the JD nor the careers page shows pay | The budget may sit inside the survey band, or the company may not publish it | `[inferred]` from the withheld figure, against `[generic]` band | "What is the budgeted salary for this post?" | unresolved |
| RR4 | Clear reporting line and scope | positive_signal | — | "reports to the Director of Pricing" | The role is defined and sits in the Director's own area | `[grounded]` careers page | "What would success look like at six months on the pet rating models?" | noted |

**Application plan** (all proposed; approval needed before any text goes out)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the young-driver GLM you built and maintained, and the 14 price tests run with underwriting | Matches R3, R7 | `[grounded]` your intake answer | pending your approval |
| E2 | Name the pet gap yourself: no pet experience, the motor rating work transfers, here is what you'd learn first | Avoids the gap being found in interview | `[grounded]` R2; `[generic]` that employers usually probe this | pending your approval |
| E3 | Do not write "monitored" for the models unless you did; "maintained" is what you can stand behind | Reframing audit | `[grounded]` your intake answer | pending your approval |
| A1 | Confirm the location before applying | RR1 and R1 | `[grounded]` RR1 | pending your approval |

**Evidence status**

Verified: none yet. Your claims are intake prose, so they are leads until you confirm them with an artifact.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results); fetched brindlemoor.co.uk/careers/senior-pricing-analyst, which is live and says Leeds four days a week. Moved RR1 and the working-pattern row |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK motor insurance salary", which returned Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey. Moved the market calibration band (`[generic]`) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a profile naming her as Director of Pricing at Brindlemoor, a 2025 Insurance Pricing Forum talk on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re. Moved the positioning in E1 and RR4 |

**Upgrade menu**

- A sanitised GLM model note or validation summary → R3 to `high`
- A price-test readout from the 14 tests → R7 to `high`
- Any non-motor rating work, even partial → R2 gap closes or narrows
- The location answer → R1 resolves, and the status can move to `go` or `no_go`
- The budgeted salary → RR3 closes against the band
- A deeper research pass on Brindlemoor (leadership, past hiring, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also emit a `tuesday-dossier.md` for this role at the end of the session.

**Questions**

Q1 (R1): Is the role fully remote, or based in Leeds four days a week? Can you work that pattern?

G1 (R8b): Have you ever shaped a product decision, such as a rate change or a product rule, through your pricing work? What did you own, and what happened?

G2 (R2): Have you done any non-motor rating, even partially, such as home or travel?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.