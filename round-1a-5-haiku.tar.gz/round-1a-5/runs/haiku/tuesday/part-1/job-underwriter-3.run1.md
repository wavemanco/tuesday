**No — both of your hard constraints fail: R1 (base pay) and R2 (location). Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: failed: R1 (base pay of at least $150k), R2 (remote-only, Portland)
- `must_have`: direct: R3 (8+ years growth leadership), R4a (paid acquisition and lifecycle, owned end to end); unclear: R4b (SEO/content, brand, PR, partnerships, sales ops)
- `important`: direct: R5 (SQL, GA4, Braze); adjacent: R7 (team of one to start); unclear: R6 (ambiguity and evolving metrics)

R1 and R2 are the reason. Your experience is a strong fit on the requirements that could be checked, but the two gates are terms the posting sets, not things wording can close. Only the employer changing both terms would change this, and the posting says on-site is "no exceptions."

Hard gates: failed: R1 (base pay of at least $150k), R2 (remote-only, Portland). Your constraints were given, so every gate has a check.

**Opportunity ledger.** Two red flags are about the terms: pay is $70–85k against your $150k floor (RR1), and the role is on-site five days a week (RR2). The posting also signals always-on work (RR5) and a scope that begins as a team of one (RR4). One entry runs the other way: the Series A and profitability claims are stated but unverified (RR7).

- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** written confirmation from Novaline that the role is remote and base pay is at least $150k. That would mean dropping two explicit terms, so I would not expect it.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims, unverified |
| Mandate | All revenue growth end to end, with sales ops, team of one to start | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting; below the $150k floor by $65–80k |
| Location | On-site Austin, five days a week, "no exceptions" | `[grounded]` posting |
| Market calibration | Not run. The posted figure already settles the gate without a market band | — |
| Contradictions | None found in the posting itself. Its company claims could not be checked (see research) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Posting says $70–85k. Your floor is your own confirmed statement | `[grounded]` posting and your stated constraint |
| R2 | Remote-only, Portland (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Posting requires on-site Austin, five days, "no exceptions" | `[grounded]` posting and your stated constraint |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth. Stated in prose, no artifact yet, so the claim is held at medium | `[grounded]` your account, caveat: expect a probe |
| R4a | Paid acquisition, lifecycle/CRM, revenue ownership | must_have | direct | medium | none | Owned paid, lifecycle and experimentation. Scaled one company from $8M to $40M ARR with a budget you controlled | `[grounded]` your account |
| R4b | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Not mentioned in your account. Unknown whether you have owned these | `[grounded]` absence from your account |
| R5 | SQL, GA4, Braze | important | direct | medium | none | Stated tools, no artifact yet | `[grounded]` your account |
| R6 | Thriving on ambiguity, evolving success metrics | important | unclear | low | discovery | Nothing in your account on operating without defined metrics | `[grounded]` absence from your account |
| R7 | Solo start, no team to lean on | important | adjacent | medium | transferability | You built teams of 3–7, so you have led people, not worked alone. Limit: solo hands-on start not evidenced | `[inferred]` from your team history against the posting's "no bench" |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay far below the stated floor | red_flag | high | "$70–85k base plus meaningful equity upside" | The offer is below your floor by $65–80k; equity does not replace base for your constraint | `[grounded]` posting against your constraint | What base salary is budgeted for this role? | confirmed |
| RR2 | On-site five days in Austin, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Incompatible with remote-only | `[grounded]` posting | Is there any remote arrangement for this role? | confirmed |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A ...)" | Pattern for companies of this size, not a claim about this one: too new or small, a stale posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Novaline's own careers page, and who would I interview with? | unresolved (research refused) |
| RR4 | Team of one, no bench | risk_signal | low | "You will be a team of one to start — we believe in players who don't need a bench" | Solo scope may be a poor fit for a leader whose record is built on teams | `[inferred]` from the posting against your team history | What decision rights and budget does this role hold, and who would report in? | unresolved |
| RR5 | Evenings and weekends as the norm | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Always-on expectations, stated as culture | `[inferred]` from the posting's wording | How often has the Head of Growth worked outside hours in the last year, and why? | unresolved |
| RR6 | Success metrics undefined on a demanding mandate | risk_signal | low | "success metrics will evolve as we learn" | Accountability without a stated definition of success | `[inferred]` from the posting | What revenue number will this role be measured on at 12 months? | unresolved |
| RR7 | Series A and profitability claims | positive_signal | — | "Series A, profitable since day one" | If true, a real signal of stability | `[grounded]` the posting's own claim, unverified | What was the last full year's revenue growth and burn? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply | R1 and R2 fail. Your effort is better spent on openings that meet your floor and location | `[grounded]` R1, R2 | recommended |
| A2 | If you still want to test it: one written question to Novaline, through its own careers page, asking whether a remote role at $150k base is possible | Low chance of a yes, and cheap to ask | `[generic]` pattern for posted terms of this kind | optional, pending your approval; nothing has been sent |

**Evidence status**

Verified: R1 and R2 (your own constraints, high), R3, R4a and R5 (your account, medium, no artifacts). Unverified: everything Novaline says about itself, including the Series A and profitability claims (RR7). Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one search was refused because permission was not granted. It would have checked whether Novaline exists and whether the posting is live. RR3 stays unresolved |
| 2. Role-family sweep | skipped | The posted $70–85k against your $150k floor already settles R1. A market band would show how far below norm the offer sits, not whether the gate fails |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Research was not completed. The `no_go` rests on the posting's own terms and your stated constraints, not on anything found about the company.

**Dossier offer.** I can write this up as a `tuesday-dossier.md` for later reference if that helps.

**Upgrade menu**
- Permission to run the company-verification search, which would settle RR3 (up to 5 searches, 2 fetches)
- Your CV or a work sample, which would move R3 and R4a from medium to high
- Confirmation from Novaline on pay and location, which is the only thing that would reopen R1 and R2

I have no questions. The decision does not depend on anything you could add.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.