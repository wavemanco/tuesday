Running the job-underwriter module. First I'll read its playbook in full.
**Yes, apply, with conditions: `conditional_go`.** The core of the job is work you already do. The two must-haves you can't yet claim are forecast ownership and billing or finance data, and both are recoverable if your answers hold up.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

## Decision snapshot

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (Bristol, hybrid, two days in office), R2 (salary £61,500–£67,000 plus share options)
  - `must_have` — direct: R3 (4+ years in revenue, sales ops or analytics), R5 (HubSpot or Salesforce administration), R6 (strong SQL); adjacent: R4 (B2B software company), R8 (owning a forecast); unclear: R7 (spreadsheet modelling), R9a (working with finance on revenue data); absent: R9b (billing data)
  - `important` — direct: R10 (pipeline and renewal reporting), R11 (owning CRM data)

  R4 — a credible bridge, its limit named; R8 — pipeline review is real forecast input, but you have not owned the number; R9b — no billing work; R7 and R9a — unconfirmed, waiting on your answers.

- **Opportunity ledger.** RR1 (the forecast is run with the CFO, so ownership is split) and RR2 (reporting line and team unclear) are unresolved. RR3 (pay disclosed and in band) and RR4 (employer established) are positive.
- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two days in office), R2 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `conditional_go`: (1) you can name a real forecast-adjacent contribution (R8); (2) you can work the Bristol pattern and the pay clears your floor (R1, R2); (3) RR1 comes back as a shared forecast with a real RevOps role in it. It moves to `hold_pending_answers` if R1 or R2 can't be checked. It moves toward `no_go` if the forecast turns out to be wholly finance-run with nothing for this role to own.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A £11M, April 2025 | `[grounded]` Quillfield About page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | One 2026 UK pay guide (n=438) puts revenue operations leads at median £64,200, interquartile range £57,800–£70,400. The posted range sits inside that interquartile range | `[generic]` one pay guide; `[grounded]` posted range |
| Scope read | A lead-level role spanning three functions (CRM and billing data, reporting, forecast). The forecast is the broadest part of the scope | `[inferred]` from the posting's responsibility list |
| Team | Hiring manager is Head of Revenue Operations at Quillfield, with a background as a sales operations manager at a payments company | `[grounded]` public professional profile |
| Unknowns | Who signs the forecast figure; the reporting line; team size; which billing system | — |
| Contradictions | None between the posting and the company's About page | `[grounded]` both fetched or read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in office | hard_gate | unclear | medium | hard_gate | Your location and schedule constraints weren't given | `[grounded]` posting | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | medium | hard_gate | Your pay floor wasn't given | `[grounded]` posting | Q1 |
| R3 | 4+ years in revenue ops, sales ops or analytics at a B2B software company (years and function) | must_have | direct | medium | none | Five years in sales ops, the last two running revenue ops for the UK team. Self-reported, not yet inspected | `[grounded]` your intake | none |
| R4 | B2B software company (sector) | must_have | adjacent | medium | transferability | Your employer was a B2B payments company, not a software product business. Limit: the software-sales motion may differ | `[inferred]` from your stated employer type | Make the bridge with its limit named |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified | `[grounded]` your intake | Keep the certificate ready |
| R6 | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | Keep a sanitised query ready |
| R7 | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily, but your intake doesn't say whether it is modelling | `[grounded]` your intake, which is silent on modelling | Q1 covers this ask; see G3 |
| R8 | Owning a forecast (the quarterly revenue forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, but finance owned the company forecast | `[grounded]` your intake; `[inferred]` that pipeline review is forecast input | Q2; see G1 |
| R9a | Working with finance on revenue data | must_have | unclear | low | discovery | Your intake covers revenue dashboards but not finance collaboration | `[grounded]` your intake | Q3; see G1 |
| R9b | Working with finance on billing data | must_have | absent | medium | transferability | You have never worked on billing data. Adjacent: renewal and pipeline data | `[grounded]` your intake | see G2 |
| R10 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | none |
| R11 | Owning CRM data | important | direct | medium | none | Salesforce admin, with the CRM rebuilt | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast and finance (R8, R9a) | transferability | You have run pipeline reviews. Finance owned the company forecast, and you have not described finance collaboration | Two must-haves at adjacent or unclear. The forecast is the role's headline responsibility | Pipeline-to-forecast calls in your monthly review; any figure you fed into a finance number; renewal forecasts you shared with finance | A pipeline review deck, a forecast-input sheet, a note from a finance counterpart | `[grounded]` intake; `[inferred]` that this is the decision's main gap |
| G2 | Billing data (R9b) | transferability | No billing work. Adjacent: renewal and pipeline data, with invoice-level data as the limit | A must-have and a stated responsibility ("own CRM and billing data") | Renewal and invoice-linked reporting; any query touching payment or invoice status at your payments company | A sanitised billing or renewal query | `[grounded]` intake |
| G3 | Spreadsheet modelling (R7) | discovery | Daily Excel use, with no modelling described | A must-have, and it pairs with the forecast | Pipeline scenario models; quota or renewal models | A model you built, sanitised | `[grounded]` intake; the rest is `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may be co-owned with finance, so the role may own the pipeline inputs rather than the number | `[inferred]` from the posting's wording against its silence on who signs the figure | Who signs off the forecast figure, and what does this role own versus finance? | unresolved |
| RR2 | Reporting line and team | unknown | — | "Revenue Operations Lead" | The hiring manager is Head of Revenue Operations; the role's scope and team are unclear | `[grounded]` public title; `[inferred]` the reading | Who would I report to day to day, and who else is on the team? | unresolved |
| RR3 | Pay disclosed and in range | positive_signal | — | "£61,500–£67,000 plus share options" | A disclosed range inside the market band | `[grounded]` posting; `[generic]` band | Is there flexibility within the range for someone building billing-data skills? | noted |
| RR4 | Employer established | positive_signal | — | "Quillfield" | A funded, established Bristol company consistent with the posting | `[grounded]` About page | Can you link the live role on your careers page? | noted |
| RR5 | Posting source | unknown | — | Hosted on Tallyboard Jobs | The company's own careers page did not turn up in search | `[inferred]` from search results | Is this role also live on Quillfield's careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor against R1 and R2 before applying | Two hard gates are unchecked | `[grounded]` R1, R2 | your call |
| A2 | Prepare a real forecast-adjacent example from your pipeline review, claimed only as far as the evidence goes | R8 is the main gap | `[grounded]` G1 | your call |
| A3 | Put RR1 and RR2 to the recruiter before the loop | They decide the conditions | `[grounded]` register | your call |
| A4 | Have the Salesforce admin certificate and a sanitised SQL query ready | Turns R5 and R6 from self-report into inspectable proof | `[grounded]` R5, R6 | your call |

Nothing here proposes CV wording yet. Any wording needs your approval first.

## Evidence status

Verified: none yet. Everything above is your self-report, at `medium` at most.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers" → quillfield.co.uk/about: Bristol, founded 2018, 96 staff, Series A £11M (April 2025). Confirms the employer exists and matches the posting. The careers page itself did not come up in search, so RR5 stays open |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol" → Ledgerline 2026 UK Revenue Operations Pay Guide: median £64,200, interquartile range £57,800–£70,400. Moved the market calibration (`[generic]`) |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → professional profile: Head of Revenue Operations at Quillfield; previously sales operations manager at a payments company for four years. Moved the scope read and RR2. Used for role and career pattern only |

## Upgrade menu

- A pipeline-to-forecast example, sanitised, or a forecast-input sheet → R8 and G1 move toward `direct`
- A Salesforce admin certificate or screenshot → R5 to `high`
- A sanitised SQL query or a billing-adjacent query → R6 and G2 close
- Your Bristol pattern and your pay floor → R1 and R2 become checkable
- The recruiter's answers on RR1 and RR2 → the conditions resolve
- Deeper research on Quillfield (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches). Say the word and it runs

If you'd like, I can save this as `tuesday-dossier.md`, so the register and the questions carry into any later prep.

Three questions, each tagged to its row:

- **R1, R2:** Can you work from Bristol two days a week, and is £61,500 above your pay floor?
- **R8:** Have you ever put a number into a forecast that someone else used, or called a pipeline-to-forecast figure yourself? What did you decide, and what happened?
- **R9a:** Have you worked with finance on revenue figures, such as ARR, reconciliation, month-end, or invoice totals, even as a dataset you only queried?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.