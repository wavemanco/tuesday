**Yes on the skills. Hold on the location until you've answered one question.** Status: `hold_pending_answers`.

- **Hard gates:** none failed; unconfirmed: R1 (Office location and schedule, against "fully remote"); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if you can work from the Leeds office four days a week, this moves to `conditional_go`. If you can't, and Brindlemoor won't flex, it's a `no_go` on the posting as written.

**Fit ledger**
- `hard_gate`: unclear: R1 (Office location and schedule)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7 · adjacent: R9 (Pet-insurance product knowledge)
- `preferred`: direct: R8

R9 — a credible bridge from motor, its limit named (no pet data or claims exercised); R1 — the location conflict, unresolved.

**Opportunity ledger.** The careers page is live, but I found no footprint for the company beyond it (RR2). The salary is withheld (RR3). The JD and the careers page disagree on location (RR1). The hiring manager's public work lines up with what the role asks (RR4).

---

**Research tier: L1 — searches 4 of 5, fetches 1 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor "Senior Pricing Analyst" careers" and "Brindlemoor insurtech pet insurance" (no results). Fetched https://brindlemoor.co.uk/careers/senior-pricing-analyst: posting is live, and it says "Leeds office four days a week", which contradicts the JD's "Fully remote (UK)" (R1, RR1). No company footprint found beyond this page (RR2). |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey): median base £58,400, IQR £52,100–£64,900, n=612. Market calibration `[generic]`, not this employer's offer. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a public profile (linkedin.example/in/odile-varga): Director of Pricing at Brindlemoor; previously head of pricing analytics at Calloway Re for six years; 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models in small books. Moved the positioning for R7. |

---

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD and careers page |
| Role | Senior Pricing Analyst, reports to the Director of Pricing; owns pricing analytics for one product | `[grounded]` JD and careers page |
| Working pattern | Conflicting: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Line management | Neither source asks for it | `[grounded]` absence in both |
| Salary | Not stated | `[grounded]` absence |
| Market calibration | Median £58,400, IQR £52,100–£64,900 | `[generic]` Pricewell 2026 survey; not this employer's offer |
| Stage | Assumed evaluating | Assumed; say so |

**Evidence map**

Confidence is capped at `medium` because your background came in as prose, not as an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Office location and schedule ("Fully remote (UK)" vs Leeds four days a week) | hard_gate | unclear | none | hard_gate | Sources contradict; your constraint wasn't given, so there's nothing to grade it against | `[grounded]` JD and careers page | Ask you (Q1); verify with the recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior; self-reported | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver motor book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained one; monitoring is the part the hiring manager has spoken about publicly | `[grounded]` your background and the talk; `[inferred]` that monitoring is what they'll probe | Prepare one monitoring example |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge (from "our pet-insurance product") | important | adjacent | medium | transferability | Motor rating and testing carry over; no pet data, claims or product exercised | `[inferred]` from the JD's product line against your motor history; `[generic]` that pet books differ in claim patterns | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor GLM and price-testing work; nothing on pet claims, breed or vet-cost factors | This is the one real gap, and the most likely interview probe | Any rating model where you built or tested on a new product with thin history; any pricing work on claims frequency or severity you didn't own from scratch | A sanitized model note from the young-driver GLM showing how you built and monitored it | `[inferred]` transfer from motor work; `[generic]` that pet books differ in claim patterns |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location and schedule conflict | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The posting may be out of date, or the role may be hybrid | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in Leeds four days a week, and which posting is current? | unresolved |
| RR2 | Company footprint beyond its careers page not found | risk_signal | medium | "Accepting applications" (careers page) | Too new or small to have a footprint, a stale posting, or not a real hiring employer; none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this role, and where is the pet product live? | unresolved |
| RR3 | Salary withheld | unknown | — | "salary on application" (JD) | The budget may sit below the band, or they may not publish salaries | `[inferred]` from the withheld figure against the `[generic]` band | What salary is budgeted for this post? | unresolved |
| RR4 | Hiring manager's public work matches the monitoring responsibility | positive_signal | — | 2025 talk "Small Books, Loud Errors" | The role is about monitoring models, which is the part you'd want to lead with | `[grounded]` the talk; `[inferred]` about the fit | How is monitoring done today: which metrics, how often, and who acts on them? | noted |

**Application plan** (all proposed; nothing is sent without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter about location before you apply | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the monitoring example for this reader | see R7, RR4 | `[inferred]` from the talk | pending your approval |
| A3 | Describe motor work as transferable to pet, with the limit named; do not claim pet experience | see R9, G1 | `[grounded]` R9 row | pending your approval |
| A4 | Ask the employing entity and the pet product's live page before investing effort | see RR2 | `[generic]` pattern for companies of this size | pending your approval |

---

**Evidence status**

Verified: none yet.

**Upgrade menu**
- Brindlemoor's answer on location → R1 and RR1 close; the decision moves to `conditional_go` or `no_go`.
- An anonymised monitoring write-up from the young-driver model → R7 moves toward `high`.
- A sanitized model note on any non-motor or new-product rating work → G1 narrows.
- The budgeted salary → RR3 closes, set against the £52,100–£64,900 band.
- The employing entity and a live link to the pet product → RR2 closes.
- A deeper research pass on Brindlemoor (funding, leadership, reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

Would you like this written up as a `tuesday-dossier.md`, so the register and questions travel with you into the next round?

**Questions**

Q1 (R1): Could you work from the Leeds office four days a week, if that is what the role turns out to be?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (G1): Have you worked on any pet, or any other non-motor, pricing data, even a pilot, a benchmark or a sample you could describe?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.