**Not worth pursuing.** The posting fails both of your hard constraints as written. Status: `no_go`.

- **Fit ledger.**
  - `hard_gate`: hard_gate_fail: R1 (base pay $70–85k), R2 (on-site Austin, 5 days a week)
  - `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM) · unclear: R6 (SEO/content)
  - `important`: adjacent: R10 (e-commerce enablement) · unclear: R7 (brand, PR), R8 (partnerships), R9 (sales ops)

  R1 is $65k under your floor even at the top of the range. R2 says "no exceptions". R3–R5 are your strongest rows, medium on your account alone. R6–R9 are functions your stated experience doesn't cover. R10 is a transfer from B2C subscription work.
- **Opportunity ledger.** The posting bundles seven functions under a "team of one" Head title (RR1), expects evenings and weekends (RR2), leaves success undefined (RR4), and withholds equity size (RR5). Pay also doesn't square with that scope (RR3). One entry runs the other way: Series A and "profitable since day one" is a stated positive (RR6), unverified. Your sense that something is off is pointing at the right things.
- **Hard gates:** failed: R1 (base pay $70–85k against your $150k floor), R2 (Austin on-site, five days a week against remote-only).
- **Severe red flags:** RR7 (`severity: high`), the pay and location conflict with your two constraints.
- **What would change this:** both R1 and R2 would have to change. The base would need to reach your floor and the employer would need to accept remote work. The posting says "no exceptions" on location, so that is unlikely.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting, self-description, unverified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Structure | Reports to the CEO, dotted line to the board; "team of one to start" | `[grounded]` posting |
| Working pattern | On-site Austin 5 days a week, "no exceptions"; evenings and weekends | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` posting |
| Scope read | Seven functions under one head with no team | `[inferred]` from the list against "team of one" |
| Market calibration | Not run. The role-family search was refused, so there is no band to compare the pay against | — |
| Unknowns | Equity size, budget, success metrics, what "profitable" means, current runway | — |
| Contradictions | "Head of" title and 8+ years required, against "team of one to start". This is tension, not proof of anything | `[inferred]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Your $150k floor is $65k above the top of the range. Nothing in the posting flexes it | `[grounded]` posting; your floor is your own statement | none; only a changed base resolves it |
| R2 | On-site Austin, 5 days/week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Conflicts with remote-only, Portland; the posting rules out exceptions | `[grounded]` posting; your constraint is your own statement | none; only a changed location term resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years stated, prose only | `[grounded]` your statement | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned at two companies; no artifact yet | `[grounded]` your statement | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Braze and lifecycle owned; no artifact yet | `[grounded]` your statement | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Not in your stated experience | `[grounded]` absence | only if you have owned it |
| R7 | Brand and PR | important | unclear | low | discovery | Not in your stated experience | `[grounded]` absence | only if you have owned it |
| R8 | Partnerships | important | unclear | low | discovery | Not in your stated experience | `[grounded]` absence | only if you have owned it |
| R9 | Sales ops | important | unclear | low | discovery | Not in your stated experience | `[grounded]` absence | only if you have owned it |
| R10 | E-commerce enablement | important | adjacent | medium | transferability | B2C subscription growth carries over (lifecycle, paid, retention). Limit: no merchant-facing work stated | `[inferred]` adjacency from your B2C background | a case study of a B2C-to-merchant project would narrow the limit |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Bundled functions (R6–R9) | discovery | None of SEO, brand/PR, partnerships or sales ops appears in your account | Decides how much of the role is real on day one | Named examples of any of these you have owned | `[grounded]` absence; `[generic]` that bundled roles usually need a team for these |
| G2 | E-commerce (R10) | transferability | B2C subscription background, no merchant-side work stated | Matters only if the gates are cleared | A case study of a B2C-to-merchant project | `[inferred]` |

The queue has no decision impact at present, since R1 and R2 decide it.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seven functions under one team-of-one head | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops." | Scope that usually needs several people is being placed on one hire | `[generic]` pattern for roles this broad, not a claim about this employer; posting text `[grounded]` | "Which of these functions have people or budget behind them today, and which would I build from zero?" | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours are the default, not the exception | `[grounded]` posting text; the reading is `[generic]` | "How often do evenings and weekends come up in a normal quarter?" | unresolved |
| RR3 | Pay may sit below the scope | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base may be low for a Head-level remit. Not calibrated, since the market search was refused | `[inferred]` from the posted range against the title and scope | "What is the budgeted base for this role, and how was the range set?" | unresolved |
| RR4 | Success left undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a defined bar | `[generic]` pattern for early-stage growth roles; posting text `[grounded]` | "What three numbers define success at six and twelve months?" | unresolved |
| RR5 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity could be token | `[inferred]` from the missing figure | "What are the grant size, strike price and vesting schedule?" | unresolved |
| RR6 | Stated stage and profitability | positive_signal | — | "Series A, profitable since day one" | Would lower financing risk if true | `[grounded]` posting claim, unverified | "What is your current revenue run-rate and runway?" | unresolved |
| RR7 | Pay and location conflict with your constraints | red_flag | high | "$70–85k base" and "On-site in our Austin office 5 days a week — no exceptions" | Both terms conflict with your non-negotiables (see R1, R2) | `[grounded]` posting; your constraints are your own statement | "Would you consider remote work and a base at or above $150k?" | confirmed |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply | R1 and R2 both fail | `[grounded]` R1, R2 | pending your approval |
| P2 | If you want certainty before deciding, send one question: are the base range and the Austin on-site both negotiable? | Only a change to both would move the decision | `[inferred]` | pending your approval |

## Evidence status

Verified: R1 and R2 (your own stated constraints, high). The experience in R3–R5 and R10 is your account in this message, medium until probed. Unverified leads: none. Rejected inferences: none.

The employer's existence is unchecked. The lookups that would have tested it were refused, so this is not a finding that the company is fake, and no standing entry was recorded for it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two company searches were refused by the search permission. Would have tested whether Novaline exists as described and whether the posting is live |
| 2. Role-family sweep | unavailable | One salary search was refused. Would have set the market band for this title and scope, calibrating RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

Want me to write this up as a `tuesday-dossier.md` you can keep for any recruiter reply?

## Upgrade menu

- Search permission granted: re-run the refused company and salary searches. That would test whether the employer exists and the posting is live (RR6 and the standing employer check), and set the market band (RR3).
- A recruiter's answer that both the base and Austin on-site are negotiable: R1 and R2 would need to change. The decision would move only if both did.
- Named examples of SEO, brand/PR, partnerships or sales ops work: R6–R9 and RR1 would move from unclear.

No questions this turn, since the decision is already stable.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.