**Not a waste of time, but not a yes yet: `hold_pending_answers`.** Your integration work is real evidence for this role. The posting's must-have is a product-management title that you don't hold, and whether you can answer for product decisions decides how the application reads. Three answers would settle it.

**Research did not run.** Every search call was refused for lack of permission, so I could not check that Quartzline exists as described or that the posting is live. Everything about the company below is from your JD text.

## Decision snapshot

**Status: `hold_pending_answers`.** The hold waits on three things: whether you built and owned a product (the request-triage tool, if real), whether your roadmap-input sessions ever made priority calls, and whether the employer checks out.

**Fit ledger.**

- `must_have` — direct: R3, R4, R5 · adjacent: R1, R2 · unclear: R6 (Owning the roadmap for a partner-facing API platform)
- `important` — adjacent: R7, R10 · unclear: R8 (Agile delivery experience), R9 (Defining and tracking adoption metrics)

R1 (`medium`) and R2 (`medium`) are adjacent with their limits named; R6 turns on the Q-decisions answer.

**Opportunity ledger.** The posting is specific: it lists five concrete duties (RR4). It omits pay, location and work model (RR1), and the employer is unverified because search was refused (RR2). The 3+ years product-management bar may be a screen (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** A clear yes on Q-tool, or on Q-decisions naming a call you made, moves this toward `conditional_go` (conditions: the employer verifies; pay and location are workable). A clear no on both leaves you at `no_go` for a PM-titled role. Fit would still hold for platform, solutions-product or integrations-product roles, which are a better target. Those are judgments, not labels from the research.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your JD text; not verified |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A platform PM owning a partner API product with two squads is a product-ownership role, not an integration-delivery role | `[generic]` role-family pattern for this title |
| Market calibration | Not established: the role-family sweep did not run | — |
| Unknowns | Pay, location, remote terms, reporting line, whether the 3+ years bar is a hard screen | — |
| Contradictions | None visible within the JD text you gave | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years of product-facing work (roadmap-input sessions, requirements) with no PM title. Length-of-experience is graded, not gated. Limit: not product management | `[grounded]` CV | see Q-decisions |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST API integrations end to end and wrote the playbook. Limit: you delivered the integrations; you did not own the platform as a product | `[grounded]` CV | see Q-tool |
| R3 | Discovery with integration partners | must_have | direct | medium | none | Scoping workshops and requirements documents with client engineers | `[grounded]` CV | none |
| R4 | Fluency with API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI named; integration architecture work. Self-reported, so expect a probe | `[grounded]` CV | none |
| R5 | Stakeholder management: eng, sales, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds. Sales is not named | `[grounded]` CV | none |
| R6 | Owning a platform roadmap | must_have | unclear | medium | discovery | Ran quarterly sessions collecting client feedback for product. Not stated whether you set priorities or carried input | `[grounded]` CV; the answer decides this row | see Q-decisions |
| R7 | Specs and delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents and go-live coordination. No backlog or squad planning named | `[grounded]` CV | offer: a spec sample |
| R8 | Agile delivery | important | unclear | low | discovery | Resume is silent on sprints, backlogs and cadence | `[grounded]` CV silence | upgrade menu |
| R9 | Defining and tracking adoption metrics | important | unclear | none | discovery | No metric on the resume; go-live work may have produced numbers | `[grounded]` CV silence | see Q-metrics |
| R10 | Launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination with clients. No sales or support handoff named | `[grounded]` CV | upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1, R2, R6) | discovery | The resume shows delivery and input, not decisions | This is the must-have bar | Any prioritization or scope call you made; the triage tool if you scoped it | A roadmap, a backlog, a decision log | `[grounded]` CV; `[inferred]` that this moves the status |
| G2 | Adoption metrics (R9) | discovery | Nothing measured on the resume | Platform PMs are judged on adoption | Time to first call, go-live duration, integrations still live | A dashboard or report you built | `[grounded]` CV silence |
| G3 | Agile delivery (R8) | discovery | Cadence not named | Squad-based delivery is in the JD | Sprint planning with engineers, backlog grooming | A delivery calendar or a sprint page | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, location and work model absent | unknown | — | (no pay or location in the JD text) | The terms may come later, or the posting may be incomplete | `[inferred]` from the JD's silence | What is the base range, and where is this role based? | unresolved |
| RR2 | Employer unverified | unknown | — | "Quartzline … Series B" | Not checked: search was refused | `[generic]` pattern: unverified employers need a check before effort | Which team is this posting filed under on your careers site? | unresolved |
| RR3 | 3+ years PM bar may be a screen | risk_signal | medium | "3+ years product management experience (must-have)" | The bar may filter on title before anyone reads the work | `[inferred]` from must-have wording | Is three years of product management a screen, and would you weigh product ownership from integration delivery in its place? | unresolved |
| RR4 | Concrete duties listed | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Scope is defined, so the role is specific enough to evaluate | `[grounded]` JD | Which of these duties does the hire own from day one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the integration-to-platform bridge: "Led 30+ client REST API integrations end to end; wrote the integration playbook the team uses." Do not write "owned the roadmap" | Your sentences as written; the roadmap wording would claim a decision you have not confirmed | `[grounded]` CV | pending your approval |
| A2 | Hold the roadmap-input wording at "ran quarterly roadmap-input sessions collecting client feedback for product" | Stronger than "drove the roadmap", which is not yet confirmed | `[grounded]` CV | pending your approval |
| A3 | Ask the recruiter whether the 3+ years bar is a screen or a preference | RR3 | `[inferred]` from the JD | pending your approval |
| A4 | Verify the posting and employer on Quartzline's own careers page before applying | RR2 | `[grounded]` posting; `[generic]` verification practice | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool your support agents adopted. It comes from earlier-conversation memory and is not evidence until you confirm it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and the posting were refused. Would have checked RR2 and the posting's live status |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the PM-title band and the compensation calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Confirming the triage tool (scope, who prioritized it, how you measured adoption) → R1 and R2 could move from adjacent toward direct.
- Details of any decision you made in the roadmap sessions → R6 closes one way or the other.
- Integration metrics you tracked → R9 moves from unclear.
- A delivery-cadence line for your squad work → R8 moves from unclear.
- Allowing web search → RR2 gets checked, and the market calibration can be run.
- The posting's pay and location → RR1 closes.
- A dossier of this analysis, `tuesday-dossier.md`, if you want to keep it for later.

R1–R10 and the register's questions stay the same without these inputs.

Q-tool (R1, R2): Did you build the request-triage tool that support agents adopted? If so, what did you decide to build and cut, who set its priorities, and how did you know agents used it?

Q-decisions (R6): In the quarterly roadmap-input sessions, did you ever decide what went onto the roadmap, or did you only carry client feedback to product? Name one call that was yours, if there was one.

Q-metrics (R9): Did you track any numbers on integrations, such as time to first successful call, go-live duration, or how many stayed live? Which ones, and where did the numbers come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.