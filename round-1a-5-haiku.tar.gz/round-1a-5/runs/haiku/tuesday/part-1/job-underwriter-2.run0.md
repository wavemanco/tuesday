**Decision: `conditional_go`.** You're not wasting your time, but the screen will test one must-have you can't argue your way past. Apply only after the employer check below, and frame everything as adjacent experience, never as PM experience.

**Fit ledger**
- `must_have`: direct: R4, R5a, R6, R7a · adjacent: R1a (PM work without the title), R2 (shipped API products), R3 (owning the roadmap), R5b (driving delivery with two squads) · unclear: R7b (sales stakeholder management), R8 (adoption metrics) · absent: R1b (3+ years as a PM)
- `important`: adjacent: R9 (launches with sales and support) · unclear: R10 (agile delivery)

R1b is absent and is the row the screen will test first. R1a, R2, R3 and R5b are adjacent, with their limits named in the map. R7b, R8 and R10 are unclear, and Q3, Q1 and Q2 below are the questions that could move them.

- **Opportunity ledger:** The posting is concrete on scope and resourcing (RR5, positive). It leaves pay unstated (RR1), gives no success target for adoption (RR3), and I could not verify the employer (RR2, the standing check). RR4 is a pattern about titled-PM screening, not a claim about this employer.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Why not `no_go`:** there is no hard gate, and the one absent must-have (R1b) has a closure path over time or through a PM-titled role. Capability gaps across several must-haves would be needed for `no_go`, and you don't have them.
- **Conditions for go:** (1) the employer and live posting are verified on Quartzline's own careers page (RR2); (2) your answer to Q1 is positive, which would move R8 and R3; (3) every line about your background reads as adjacent, never as a PM title (R1b).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` your message |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; drive delivery with two engineering squads; define and track adoption; coordinate launches | `[grounded]` JD |
| Scope read | Platform-level ownership with two squads is a normal scope for a senior PM post at this stage | `[inferred]` from the JD's scope against its resourcing |
| Market calibration | Not run. The search was refused, so there is no pay band or role-family norm | — |
| Unknowns | Pay, success target for adoption, whether sales is a partner of this role or a stakeholder, whether you would lead the squads or sit beside them | — |
| Contradictions | None visible, but only one source (your paste) was checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM work without the title | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions and requirements documents. Limit: you supplied input, you did not set priorities | `[grounded]` CV; `[inferred]` adjacency | Q1 and Q2 |
| R1b | 3+ years as a PM | must_have | absent | medium | capability | No PM title, by your statement. Length of experience is not a legal gate, so it is graded, not disqualifying | `[grounded]` your statement | Closure path: a PM-titled role, or carry as material risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ REST integrations end to end. You delivered a client's build; you did not ship the platform | `[grounded]` CV | Name one integration where your requirements changed what shipped |
| R3 | Own the roadmap for a partner-facing API platform | must_have | adjacent | medium | transferability | Product input, not roadmap ownership | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R4 | Run discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and requirements gathering with client teams. The CV calls it implementation, not discovery | `[grounded]` CV | Repositioning E1 |
| R5a | Write specs | must_have | direct | medium | none | Requirements documents and integration architecture | `[grounded]` CV | none |
| R5b | Drive delivery with two engineering squads | must_have | adjacent | medium | transferability | You coordinated your engineers, client engineers and PMs on custom builds. No squad or sprint ownership stated | `[grounded]` CV; `[inferred]` adjacency | Q2 |
| R6 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs read, integration architecture | `[grounded]` CV | none |
| R7a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated engineers, client engineers, PMs on custom builds | `[grounded]` CV | none |
| R7b | Sales stakeholder management | must_have | unclear | low | discovery | The CV is silent on sales | `[grounded]` CV silence | Q3 |
| R8 | Define and track adoption metrics | must_have | unclear | low | discovery | The CV is silent. SQL is a plausible route, not evidence | `[grounded]` CV silence | Q1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT per client, plus an integration playbook the team uses | `[grounded]` CV; `[inferred]` adjacency | Q1 covers the support side |
| R10 | Agile delivery | important | unclear | low | discovery | The CV does not name agile practice | `[grounded]` CV silence | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years as a PM (R1b) | capability | No titled PM years | This is the screen's first test, and it may be applied literally | A PM-titled internal role; a PM title at a smaller company | Job titles and dates | `[grounded]` your statement; `[generic]` on how PM screens work |
| G2 | Roadmap ownership, adoption metrics (R3, R8) | discovery | Product input only | Central to the role | An internal tool you shaped (see Q1) | Roadmap doc, adoption numbers | `[grounded]` CV; `[inferred]` |
| G3 | Sales (R7b) | discovery | Silent | The JD names sales | Pre-sales scoping, deal-close involvement | A deal or renewal you shaped | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | "Own the roadmap…" (no pay line) | Pay may sit below what you'd expect, or simply not be published | `[inferred]` from the posting's silence | What is the budgeted base range for this role? | unresolved |
| RR2 | Employer not verified (search refused) | risk_signal | medium | Your message names Quartzline only | The posting may be stale, the company small or new, or not hiring for this exact role. Not verified, and not found to be false | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I interview with? | unresolved |
| RR3 | No adoption target | unknown | — | "define and track adoption metrics" | Success may be undefined, meaning you would set the target | `[inferred]` from the posting's silence on a target | What adoption level would count as success in year one, and who set it? | unresolved |
| RR4 | Titled-PM screening | risk_signal | low | "3+ years product management experience (must-have)" | Literal screening on titles is common in PM hiring | `[generic]` pattern for PM hiring | Would you consider a candidate with platform delivery and no PM title, and what would you need to see? | unresolved |
| RR5 | Named scope and resourcing | positive_signal | — | "two engineering squads" | Scope is concrete and resourced | `[grounded]` JD | Which two squads, and do they report to this role? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Quartzline's own careers page, and find the pay range, before applying | RR2, RR1 | `[grounded]` the register | your action |
| E1 | Replace your current CV bullet with: "Ran scoping workshops and quarterly roadmap-input sessions with client integration teams, feeding requirements to product; led 30+ client REST API integrations end to end" | R4, R2. The word "discovery" comes from the JD, so it stays out of your own history | `[grounded]` your CV sentences | `resume_edits_pending_approval` |
| A2 | Lead with your integration record in your summary, and leave PM out of your title | R1b | `[inferred]` reading of R1b | pending your approval |

**Evidence status**
Verified: none yet. Everything above rests on your message (CV-equivalent, not probed). Unverified lead: an earlier note suggests you may have built an internal request-triage tool that support agents adopted. It is unconfirmed, so it is the basis for Q1 only and is not evidence.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused permission. Quartzline's existence and the posting are unchecked (RR2) |
| 2. Role-family sweep | unavailable | One search was refused. No pay band or norm for this role |
| 3. Hiring manager's public footprint | n/a | No name was given |

Closing:

Dossier offer: If you want this kept, I can write it to `tuesday-dossier.md` so the next session starts from it.

Upgrade menu:
- Your answer to Q1 → R8 and R3 may move up, and RR3 can close.
- Your answer to Q2 → R5b and R10 can move.
- Your answer to Q3 → R7b can move.
- Checking the posting on Quartzline's careers page, and the pay range → RR2 and RR1 close.

Questions:
- **Q1 (R8, R3, R9):** I have an unconfirmed note that you may have built an internal request-triage tool that support agents adopted. Did you? If so, what did you decide to build and what did you leave out, who set its priorities, and how did you know agents used it, with any numbers?
- **Q2 (R5b, R10):** On the custom builds, how was work planned with the engineers: a sprint cadence, a backlog someone owned, or project plans? Did you run planning or review with an engineering team?
- **Q3 (R7b):** On deals or renewals where an integration was involved, did you work with sales on what was promised, and did you ever decide what a client got versus what was deferred?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.