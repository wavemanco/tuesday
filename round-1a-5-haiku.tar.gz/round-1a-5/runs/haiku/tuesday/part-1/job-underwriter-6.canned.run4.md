**Worth applying, if two things hold: Bristol two days a week and the £61,500 base.** Status: `hold_pending_answers`. You can settle both in a minute. If they hold, I'd move to `conditional_go`.

**Fit ledger**
- `hard_gate`: unconfirmed: R1 (Bristol, two office days a week), R2 (base pay £61,500–£67,000)
- `must_have`: direct: R3 (4+ years), R4 (Salesforce admin), R5 (SQL and Excel) · adjacent: R6 (forecast ownership), R7 (finance on billing or revenue data)
- `important`: direct: R8 (pipeline and renewal reporting)

R6 — you've run the pipeline review that feeds a forecast, but never owned the forecast. R7 — revenue data yes, billing data no.

**Opportunity ledger.** Quillfield exists and looks established (RR4 positive: pay, office pattern and outcomes are stated). Two things are unknown: whether the forecast is moving from finance to this role (RR2), and whether this posting is live on Quillfield's own careers site (RR1). I didn't find it there.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days a week), R2 (base pay £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** if both gates clear, `conditional_go` on two conditions: the forecast scope is confirmed in interview (RR2), and the billing-data scope is real (RR3). If you can't do Bristol twice a week, `no_go`.

**Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1**

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (returned quillfield.co.uk/about: Bristol, founded 2018, 96 staff, Series A £11M in April 2025, from the search snippet). Searched "Quillfield Revenue Operations Lead job" (no results). Fetched quillfield.co.uk/careers: no page at that address. I tried only that one path, so this isn't exhaustive. Moved: employer established; role not confirmed on their site. |
| 2. Role-family sweep | yes | Searched "revenue operations lead UK salary B2B software": Ledgerline 2026 UK RevOps pay guide (snippet only, not fetched). Moved: market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield": a LinkedIn profile (snippet). Moved: scope read and positioning. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A £11M (April 2025) | `[grounded]` employer's about page (search snippet) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week in Bristol | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations | `[grounded]` LinkedIn profile (snippet) |
| Scope read | Probably sits alongside or under a Head of RevOps who runs the same function; reporting line unstated | `[inferred]` from her title against the posting |
| Market calibration | UK RevOps lead, B2B software: median £64,200, IQR £57,800–£70,400 (n=438). The posted band sits inside the IQR, around the median. | `[generic]` Ledgerline 2026 guide, snippet |
| Unknowns | Forecast handover from finance; billing-data access; reporting line; whether the posting is live on their site | — |
| Contradictions | None found between the posting and Quillfield's about page | `[grounded]` |

Your background comes from your message, not a CV, so every claim below sits at `medium` or lower.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | medium | hard_gate | Your constraint isn't in the material | `[grounded]` posting; your constraint not given | Q1 |
| R2 | Base £61,500–£67,000 | hard_gate | unclear | medium | hard_gate | Your floor isn't in the material; the band sits near market median | `[grounded]` posting; `[generic]` market band | Q1 |
| R3 | 4+ years in RevOps, sales ops or similar at B2B software | must_have | direct | medium | none | 5 years, last 2 in RevOps. Your employer is a payments company; whether that counts as B2B software is for you to confirm | `[grounded]` your background | none |
| R4 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet inspected | `[grounded]` your background | attach the certificate |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. Modelling (as opposed to reporting) isn't separately evidenced | `[grounded]` your background | none |
| R6 | Owning a revenue forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director; finance owned the forecast itself | `[grounded]` your background; `[inferred]` that a pipeline review is an input, not the forecast | G1 |
| R7 | Working with finance on billing or revenue data | must_have | adjacent | low | discovery | Revenue data (renewals, pipeline) yes; no billing data; finance collaboration unstated | `[grounded]` your background | Q3 |
| R8 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt both dashboards; no artifact yet | `[grounded]` your background | attach a sanitised dashboard |

**Gap recovery queue** (questions are in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | You run the pipeline review; finance held the forecast | The must-have most likely to be probed | Any forecast you built, even team-level, that fed finance's number; a forecast-vs-actual you explained | A sanitised forecast-vs-actual, or the pipeline-review pack | `[grounded]` your background; `[generic]` that this is the likeliest probe |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | The listing may be a repost or stale, or the role may sit on a different page | `[generic]` pattern for job boards | Is this role live on Quillfield's own careers page, and what is the reporting line? | unresolved |
| RR2 | Forecast handover from finance | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the number while the CFO signs off, or the forecast may be moving from finance to RevOps | `[inferred]` from "with the CFO" against your note that finance held it | Does this role own the forecast number or prepare it for the CFO's sign-off, and is that moving from finance? | unresolved |
| RR3 | Broad scope: four areas in one lead role | risk_signal | low | "own our CRM and billing data … build the pipeline and renewal reporting … run the quarterly revenue forecast" | Scope may be wider than one lead can carry | `[inferred]` from the posting's list of owned areas | Which of these four would I own on day one, and which would be handed off? | unresolved |
| RR4 | Pay, office pattern and outcomes stated | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posting is transparent on the terms that matter | `[grounded]` posting | What do the share options look like at this stage? | noted |

**Application plan** (every row needs your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter whether the role is live on Quillfield's careers page, and whether the forecast moves from finance | RR1, RR2 | `[inferred]` | pending your approval |
| E1 | Lead your CV with the dashboards and the Salesforce admin certificate; don't list forecast ownership | R4, R8 | `[grounded]` | pending your approval |
| E2 | If it's true, say your pipeline review fed finance's forecast; don't say you owned it | R6 | `[grounded]`; the wording is yours to confirm | pending your approval |

**Evidence status**

Verified: none yet.

**Upgrade menu**
- A Salesforce admin certificate → R4 to `high`.
- A sanitised pipeline or renewal dashboard screenshot → R8 to `high`.
- A forecast-vs-actual or pipeline-to-forecast handoff you ran → R6 to `direct`, if it's real.
- A revenue or billing reconciliation with finance → R7 to `direct`.
- The recruiter's answer on RR1 and RR2 → the forecast and posting questions close.
- Deeper research on Quillfield (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can emit all of this as `tuesday-dossier.md`, which you could keep and add to later.

Q1 — R1, R2: Can you work in Bristol two days a week, and is £61,500 base above your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 — R6: Have you ever prepared or owned a revenue forecast, even one that fed finance's number? Who made the final call, and what did you do when it missed?

Q3 — R7: Have you ever pulled, reconciled or checked revenue or billing numbers with finance, even as the person doing the pulling? Which numbers, and how did you know they were right?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.