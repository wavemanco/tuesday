**Not yet. Hold off applying until you know whether fully remote working is a must for you: `hold_pending_answers`.** On the skills, you'd be a strong fit. The open question is location: the posting you pasted says fully remote (UK), but Brindlemoor's own careers page says Leeds office four days a week.

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (work location and schedule)
  - `must_have` — direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (price tests), R6 (rating-model monitoring), R7 (presenting to underwriting leads)
  - `important` — adjacent: R9 (pet-insurance product knowledge); unclear: R8 (recommendations for product)
  - `preferred` — direct: R10 (insurance experience)

  R1 — the two sources disagree and your constraint isn't given; R9 — motor pricing carries over, pet-specific knowledge isn't shown yet; R8 — underwriting recommendations are evidenced, product ones aren't.

- **Opportunity ledger.** The employer is established on its own careers domain, so no failed-attribution entry. The register holds one risk signal (RR1, location), three unknowns (RR2 pet expectations, RR3 salary, RR4 direct reports), and no red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Work location and schedule); candidate constraints not given — checks against them unknown.

- **Severe red flags:** none found.

- **What would change this:** the answer to the question below, plus the employer confirming the working pattern (RR1). If remote is a must and Leeds is confirmed, the gate fails and the status becomes `no_go`. If remote isn't a must, or the posting is confirmed remote, it becomes `conditional_go`, conditional on the salary and the pet bridge.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` careers page, brindlemoor.co.uk |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | Contradiction: fully remote (UK) in your posting; Leeds office four days a week on the careers page | `[grounded]` both sources |
| Scope read | Owns pricing analytics for one product line | `[inferred]` from the JD's scope language |
| Market calibration | UK senior pricing analyst: median £58,400, IQR £52,100–£64,900 (Pricewell 2026 survey, n=612, insurers and insurtechs) | `[generic]` role-family sweep; not this employer's offer |
| Unknowns | Base salary; whether the role manages anyone; what pet-product knowledge is expected on day one | — |
| Hiring manager | Odile Varga: previously head of pricing analytics at Calloway Re; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books | `[grounded]` public profile |

## Evidence map

Your intake prose is self-report, so every claim sits at `medium` at most. I haven't seen a CV.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location and schedule: fully remote, UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Sources conflict; no statement of your own constraint yet | `[grounded]` both sources | Your answer to the question below; employer confirmation (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst; self-reported | `[grounded]` your intake | Share a CV to raise to high |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your intake | Same |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your intake | Model documentation or review as artifact |
| R5 | Designing and reading price tests | must_have | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your intake | Test summary as artifact |
| R6 | Building and monitoring rating models | must_have | direct | medium | none | Built and maintained; monitoring described, not shown | `[grounded]` your intake | Monitoring pack as artifact |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | Review deck as artifact |
| R8 | Turning results into recommendations for underwriting and product | important | unclear | low | discovery | Underwriting side evidenced through tests and reviews; no product-side recommendation mentioned | `[grounded]` intake; product gap `[inferred]` | G2 below |
| R9 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over; no pet evidence | `[inferred]` from the product named against your intake | G1 below |
| R10 | Insurance experience ("a plus") | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake | None |

Your management experience isn't a row: neither the JD nor the careers page asks for people management. Whether the role has direct reports is an unknown (RR4), not a gap.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-product knowledge (R9, important) | transferability | Motor GLM and pricing work; nothing pet-specific | The role owns this product's pricing | Pricing a new segment inside a motor book; monitoring a young-driver model's assumptions | A one-page note on what transfers and what you'd have to learn | `[inferred]` bridge; `[generic]` that pet pricing has its own loss drivers |
| G2 | Product-side recommendations (R8, important) | discovery | Underwriting recommendations are evidenced; product ones aren't mentioned | The JD says "and product" | A price or feature change that came out of your tests and went to product | A slide or note from that recommendation | `[grounded]` intake |
| G3 | Work location (R1, hard_gate) | hard_gate | Two sources conflict; your constraint isn't stated | Could end the application outright | — | The employer's written working pattern | `[grounded]` both sources |

The question for G3 is in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts between posting and careers page | risk_signal | medium | "Fully remote (UK)" / "Leeds office four days a week" | One source is out of date; the working pattern isn't settled | `[grounded]` both sources; hypothesis `[inferred]` from the conflict | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pet-product knowledge expected | unknown | — | "Own pricing analytics for our pet-insurance product" | The team may expect pet-specific knowledge from the start | `[inferred]` from the product named against your intake | What pet-pricing knowledge would a new hire need in the first 90 days? | unresolved |
| RR3 | Salary not published | unknown | — | The careers page gives no salary | The figure may be withheld, or set outside the band | `[grounded]` page; band `[generic]` | What is the base salary for this role? | unresolved |
| RR4 | Direct reports not mentioned | unknown | — | Neither source names people management | The role may or may not manage anyone | `[grounded]` absence in both texts | Does this role line-manage anyone? | unresolved |
| RR5 | Director's public topic overlaps your monitoring work | unknown | — | Talk: "Small Books, Loud Errors" | The Director may probe monitoring in small books | `[inferred]` from the talk title | How do you tell a real signal from noise in a small rating book? | unresolved |

No employer-attribution entry: the careers page sits on the company's own domain and names the role.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the employer before applying | See RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the base salary | See RR3 | `[grounded]` RR3 | pending your approval |
| A3 | Lead with GLM ownership (R4) and the 14 price tests (R5) | The JD names both | `[grounded]` JD; R4, R5 | pending your approval |
| A4 | Write a one-page note on motor-to-pet transfer and its limits | See R9, G1 | `[inferred]` | pending your approval |

No resume language is proposed yet: I haven't seen a CV.

## Evidence status

Verified: none yet. Your intake is self-report and hasn't been probed or evidenced.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst" (returned brindlemoor.co.uk/careers/senior-pricing-analyst); fetched that page. Moved: the contradictions row (location) and employer attribution |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst insurance UK salary GLM"; returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; returned their public profile (linkedin.example/in/odile-varga). Moved: role reality's scope read and RR5 |

I'm assuming you're at the evaluating stage, since you didn't say otherwise.

A tuesday-dossier.md can keep this assessment and take your answers as they come in, if you'd like one.

**Upgrade menu**
- Your answer on location → R1 and RR1 close, and the status moves to `go`, `conditional_go` or `no_go`.
- A CV, a pricing review deck or a price-test summary → R2–R7 move from `medium` toward `high`.
- One product-side recommendation you made → R8 resolves or stays open.
- The posted salary → RR3 closes against the band above.
- Deeper research on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — offered once; say the word and it runs.

**Question**

G3 — Is fully remote working a must for you, or could you work from the Leeds office four days a week? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.