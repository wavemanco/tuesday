**Yes, it's worth applying to: `conditional_go`.** Your background matches the must-haves. Two open items only you can answer: whether you're eligible for the location, and whether the $148,000 base clears your floor.

**Fit ledger.**
- `hard_gate`: unclear: R1 (remote US or Denver), R2 (base salary against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R9: Snowflake dbt work carries over, but BigQuery itself is unexercised. R10 and R11: nothing in your background establishes them yet. R3, R4, R5, R6, R7 and R8: stated, not yet inspected, so `medium`.

**Opportunity ledger.** The posting is live on the company's own careers page, matches the JD, and agrees with the about page (RR4). Its open items are unknowns, not warnings: equity is unvalued, and no hiring manager, team size or reporting line is named (RR1, RR2).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver), R2 (base against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you are eligible for remote US or the Denver office; (2) R2: the base clears your floor; (3) R9: the BigQuery gap is stated as adjacent, never as direct experience.
- **What would change this:** a no on R1 or R2 would make this `no_go`, since both are gates. A yes on both, plus a clean answer on RR1 and RR2, would support a plain `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company about page, fetched |
| Role | Build and run ingestion from the app and CRM, a dbt warehouse in BigQuery, and analyst-facing data contracts | `[grounded]` JD; careers page fetched and matches |
| Scope read | Ownership of one reporting domain's pipelines and contracts, with no direct reports stated | `[inferred]` from the JD's wording |
| Pay | $148,000–$166,000 base plus equity | `[grounded]` JD |
| Market calibration | Datawright median base $151,000, IQR $139,000–$163,500. The posted midpoint of $157,000 sits between the median and the upper-quartile boundary. Equity is not valued | `[generic]` band from the pay report you supplied; `[grounded]` posting figures |
| Working pattern | Remote US, or the Denver office | `[grounded]` JD |
| Unknowns | Team size, reporting line, hiring manager, equity value | — |
| Contradictions | None between the JD and the careers page, or between the careers page and the about page | `[grounded]` both fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No candidate statement of location was given, so nothing settles it | `[grounded]` JD | Q1 |
| R2 | Base salary $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | No floor was given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported | `[grounded]` intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` intake statement | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models built on Snowflake, self-reported | `[grounded]` intake statement | none |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake | `[grounded]` intake statement | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow used, self-reported | `[grounded]` intake statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` intake statement | none |
| R9 | Warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over. Your BigQuery experience is none, and its cost and partitioning model is unexercised | `[inferred]` from R5 and R6 | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Your background is silent on it | `[grounded]` JD; background silent | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on contracts; the Great Expectations work may be a partial bridge | `[grounded]` JD; background silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9) | transferability | Snowflake dbt work; no BigQuery | This is the one tool the posting names that you have not used | Any warehouse migration or dialect port; any cost-based query tuning | A dbt project README or model list, if you can share one | `[inferred]` bridge from R5 and R6 |
| G2 | Ingestion from app and CRM (R10) | discovery | Nothing in the background | Ingestion is the first thing the role names | Syncs from a product database or a CRM; incremental loads; schema-change handling | A pipeline diagram or a sanitized DAG | `[grounded]` JD; background silent |
| G3 | Data contracts (R11) | discovery | Nothing in the background; the Great Expectations suite may bridge | Analysts rely on these; the posting names them as a core duty | Schema agreements with downstream consumers; breaking-change process | A contract document or test spec | `[grounded]` JD; background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity not valued | unknown | — | "plus equity" | The equity may be a meaningful share of pay or may be small | `[inferred]` from the posting's silence on grant size | What is the grant size, vesting schedule and strike price? | unresolved |
| RR2 | No hiring manager, team or reporting line named | unknown | — | "Build and run the pipelines" | The role may carry the pipelines without a team around them | `[inferred]` from the posting's silence on resourcing | Who would I report to, and what team sits around this role? | unresolved |
| RR3 | Posted pay against the pay report | positive_signal | — | "$148,000–$166,000" | The range sits at market centre and above, though the median is $151,000 | `[generic]` band from the supplied report, for this title | Is the range negotiable within the posted band? | noted |
| RR4 | Company facts consistent across sources | positive_signal | — | "Series C ($52M, February 2026)" | The company is an established, funded employer with a live hiring process | `[grounded]` company's own site | Which team owns the reporting pipelines today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location against remote US or the Denver office before applying | R1 | `[grounded]` JD | pending your approval |
| A2 | Check the base against your floor before the first call | R2 | `[grounded]` JD | pending your approval |
| A3 | Ask the recruiter for the equity value and reporting line before the loop | RR1, RR2 | `[grounded]` register | pending your approval |
| A4 | BigQuery wording, if asked: "I built a dbt project of about 180 models on Snowflake and have not used BigQuery." Only your own facts appear | R9 | `[grounded]` intake statement | pending your approval |

No CV was supplied, so no resume edits are proposed.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched the careers page (pellucidlearning.com/careers/senior-data-engineer) and the about page (pellucidlearning.com/about), both checking pasted material. Confirmed the posting is live and matches the JD, and that the company facts agree. Moved RR4 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you supplied fixes the market band and the scope norm for this title, so no search was needed |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- **A CV or resume:** would let R3 to R8 move from `medium` to `high` once a document inspects them.
- **Your location and base floor:** resolves R1 and R2 from unclear, and settles the conditions for go.
- **A short description of app and CRM ingestion you built:** resolves or narrows R10.
- **One data contract you defined, with its consumers:** resolves or narrows R11.
- **The recruiter's answer on equity and team:** closes RR1 and RR2.
- **The hiring manager's name:** would let the scope read draw on that person's public professional footprint.
- **A deeper pass on Pellucid Learning** (funding and leadership changes, hiring patterns, public employee reports): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want this as a saved file, I can write `tuesday-dossier.md` from it.

1. **R1:** Are you based in the US, and would remote US or the Denver office work for you?
2. **R2:** What is your base floor, and would equity need to count toward it?
3. **G2:** Have you built ingestion from a product database or a CRM? What did you own: the sync, the schema, or the failure handling?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.