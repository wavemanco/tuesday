**Yes, apply, on conditions.** You fit the analytics core of this role. The open questions are the metrics-layer ownership, the people-management and clinician sides, and whether the posting checks out. `conditional_go`

- **Fit ledger.**
  - `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6, R8a · unclear: R8b
  - `important` — unclear: R7
  - `preferred` — adjacent: R9

  R1–R5 are direct, with the claims confirmed but no inspectable artifact yet. R6 (define and maintain the metrics layer) and R8a (partner with PMs on roadmap decisions) are adjacent, with the nearest evidence named. R8b (partner with clinicians) is unclear because no clinician work is stated. R7 (mentor two junior analysts) is unclear because no mentoring is stated. R9 (healthcare data, HIPAA) is adjacent as a bridge only.
- **Opportunity ledger.** Pay (RR2) and location or remote terms (RR1) are not stated, so they are unknowns. Two risk signals: subscription-retention metrics may not carry over to care outcomes (RR3), and tests on care pathways may need clinical review (RR4). The employer and posting are unverified (RR5). Scope is explicit (RR6), which is a positive.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live posting and employer verify (RR5), which caps this at `conditional_go` until then; (2) pay and location are compatible with your constraints (RR1, RR2); (3) mentoring (R7) and clinician work (R8b) hold up in interviews.
- **What would change this:** if your non-negotiables rule out the stated location or pay, the status drops toward `no_go`. If the posting cannot be confirmed live, it stays at `conditional_go` with that condition open.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, as stated | `[grounded]` JD header; not verified (search refused) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, two mentees | `[grounded]` JD |
| Scope read | A senior IC role with two mentees, and "define the metrics layer" suggests the analytics function is still being built | `[inferred]` from the responsibility list against its silence on existing infrastructure |
| Market calibration | Not run | `unavailable`, see Evidence status |
| Unknowns | Location and remote policy, pay, employment type, whether a metrics layer exists, clinical data sources | — |
| Contradictions | None found in the material provided; no second source to check against | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, self-reported; no artifact yet. Expect a probe on scope | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake; "expert" depth is not shown | `[grounded]` your background | Sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ tests a year, including the pricing test behind an 11% retention lift. Scale is subscription, not clinical | `[grounded]` your background | Sanitized test readout would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance, 40+ governed dashboards | `[grounded]` your background | Dashboard list or screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents monthly to the VP Product | `[grounded]` your background | Memo excerpt, sanitized, would raise to high |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards are the nearest evidence. No statement that you owned canonical metric definitions | `[inferred]` adjacency from the Looker governance work | G1 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Not mentioned | `[grounded]` absence from your background | G2 |
| R8a | Partner with PMs to turn analysis into roadmap decisions | must_have | adjacent | medium | transferability | The exec memo and VP Product readouts are roadmap-facing. PM partnership is not stated | `[inferred]` from the memo and readout | G4 |
| R8b | Partner with clinicians on analysis | must_have | unclear | none | discovery | No clinician work stated | `[grounded]` absence | G3 |
| R9 | Healthcare data experience, HIPAA (preferred) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and the warehouse consent-state model are adjacent. No PHI or HIPAA-covered work | `[grounded]` your background; `[inferred]` adjacency | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | transferability | Governed dashboards and warehouse work; no stated ownership of metric definitions | A must-have; ownership would turn adjacent into direct | Writing or approving metric definitions; a metric dictionary; resolving disputes between two teams' numbers | A metric dictionary, a definitions doc, or a governance proposal | `[inferred]` bridge from the Looker work; `[generic]` that this is the likeliest objection |
| G2 | Mentoring (R7, important) | discovery | Nothing stated | Named as part of the role; two mentees | Onboarding or reviewing a junior analyst's SQL; training PMs on Looker | A review checklist or a training outline | `[grounded]` absence |
| G3 | Clinician partnership (R8b, must_have) | discovery | No clinician work stated | Must-have, and the one interviews are likely to probe | Working with clinical leads, ops or care teams on a metric; translating a result for a non-analyst audience | Any project brief that involved a non-product group | `[grounded]` absence; `[generic]` that clinical partners probe this |
| G4 | PM roadmap influence (R8a, must_have) | transferability | Exec memo and VP Product readouts; PM partnership not stated | Roadmap influence is the job's stated outcome | A test result that changed a PM's roadmap decision | One decision your analysis moved | `[inferred]` from the memo and readout |
| G5 | Healthcare data (R9, preferred) | transferability | Consumer PII under GDPR/CCPA; consent-state model | Preferred, so minor; the limit must be stated | Any work touching regulated data; consent or access controls | Consent-model design note, sanitized | `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location and work pattern not stated | unknown | — | (JD silent) | Location or remote terms may conflict with your constraints | `[grounded]` absence | Is this role remote, hybrid or on-site, and in which location? | unresolved |
| RR2 | Pay not stated | unknown | — | (JD silent) | The band cannot be compared with your floor | `[grounded]` absence | What is the base range for this role? | unresolved |
| RR3 | Retention metrics may not carry to care outcomes | risk_signal | medium | "care-navigation app"; "clinicians" | Subscription retention experience may need a different metric set and longer read windows | `[inferred]` from the care scope against your background | Which outcome metrics do experiments here optimize, and how are clinical outcomes measured? | unresolved |
| RR4 | Tests on patient-facing pathways | risk_signal | medium | "A/B tests" alongside clinician partnership | Patient-facing tests may need clinical or ethics review that subscription tests did not | `[generic]` pattern for regulated health products, not a claim about this employer | How are experiments that touch patient-facing care pathways reviewed before launch? | unresolved |
| RR5 | Employer and posting unverified | unknown | — | "Harborlight Health" | Posting liveness and employer scale are unconfirmed because the search was refused | `[grounded]` the search did not run | Can you confirm this posting is live on your careers page, and who would I interview with? | unresolved |
| RR6 | Scope named concretely | positive_signal | — | "define and maintain the metrics layer"; "self-serve dashboards" | Real analytics authority is implied by the scope | `[grounded]` JD | Which metric definitions does this role own outright, and which go through PMs or clinical leads? | noted |

No severity is `high`, so there are no severe red flags.

## Application plan

These are proposed language. Each block is pending your approval. The bullets trace to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation line, verbatim: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | Covers R3 with your own words | `[grounded]` your sentence | resume_edits_pending_approval |
| A2 | Use "Built the company's Looker instance from scratch — 40+ governed dashboards" | Covers R4 | `[grounded]` your sentence | resume_edits_pending_approval |
| A3 | For R9, say "handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse." Do not write "HIPAA" or "healthcare data" | Keeps the adjacency honest | `[grounded]` your sentence | resume_edits_pending_approval |
| A4 | Ask RR3 and RR4 verbatim in the interview | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A5 | Before applying, confirm the posting is live and get pay and location (RR5, RR2, RR1) | Clears the conditions | `[grounded]` register | pending your approval |
| A6 | For R7 and R8b, name any real coaching or cross-team work precisely. If there is none, say so | Candor holds up under follow-up | `[generic]` interview practice | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported at intake (medium ceiling), and no claim has been probed or matched to an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health Senior Product Analyst care-navigation careers". The call was refused because web search permission was not granted. It would have moved RR5 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Looker experimentation". Refused the same way. It would have set the market calibration line and the pay check (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you have a live posting link, a salary range, or web search enabled, I can run the two declared checks.

If you want this written up, I can emit it as `tuesday-dossier.md`, which mock-interview can read when you prepare for this role.

## Upgrade menu

- The live posting link, or the careers page → RR5 closes, and the cap to `conditional_go` lifts.
- A base-salary range → RR2 closes, and the figure is set against the role-family band (needs web search).
- Your remote or hybrid preference and location → RR1 closes, and the hard-gates line can run its checks.
- Your non-negotiables (location, pay floor, contract type) → the hard-gates line runs its checks.
- One sanitized memo, query sample or test readout → R5, R2 or R3 moves to high.
- Web search enabled → up to 3 more L1 searches and 2 fetches for the two checks above. A deeper company diligence pass (funding, leadership, recent news; up to 5 more searches and 2 more fetches) is available, offered once, and runs only on your go-ahead.

## Questions

1. Constraints: what are your non-negotiables on location or remote work, pay floor, and contract type?
2. G1 — Did you own the metric definitions (a metric dictionary or semantic layer), or did you use definitions others set? Which ones, and who signed off?
3. G2 — Have you managed, coached or formally reviewed the work of junior analysts? Name one case: what you did and what happened.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.