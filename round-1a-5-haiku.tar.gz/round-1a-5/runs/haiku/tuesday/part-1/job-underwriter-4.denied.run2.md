**Yes, worth applying, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2 (4+ years pricing or actuarial analytics), R3 (strong SQL and Python), R4 (GLM experience), R5 (design and read price tests), R7 (presenting to underwriting or actuarial leads); unclear: R6 (Build and monitor rating models)
- `preferred`: direct: R8 (Insurance experience)

R1 — location and right to work not stated; R6 — monitoring unconfirmed, see Q2; R9 — motor background, pet product unproven (`important`, below); R5 — 14 tests run, no artifact yet.

**Opportunity ledger.** The scope is concrete (RR6, positive signal). Three unknowns are open: line management (RR1), salary and contract basis (RR2), and how mature the pet product is (RR4). The employer is not verified (RR5, `severity: medium`), because web search was not available in this session.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR5: the posting is live on Brindlemoor's own careers site; (2) RR1: you can accept the line-management scope the role turns out to have; (3) R9: the pet gap is framed as transferable method, not pet expertise.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the posting names a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Outputs are named; decision rights and team are not | `[inferred]` from the JD's silence on both |
| Market calibration | Not run. No pay band is given, and I won't supply one from memory | — |
| Unknowns | Line management, salary, contract basis, pet-product maturity, the hiring manager's footprint | — |
| Contradictions | None checkable: no careers page could be reached | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK: your location and right to work | hard_gate | unclear | none | hard_gate | Nothing stated yet, so there is no claim to grade | `[grounded]` JD | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst; your statement, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your background | upgrade: sanitised code sample |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver motor book. The method carries across products | `[grounded]` your background; `[inferred]` that the method carries across | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | upgrade: sanitised test readout |
| R6 | Build and monitor rating models | must_have | unclear | low | discovery | Building is shown; monitoring after launch is not stated | `[grounded]` your background | Q2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting; actuarial leads not covered | `[grounded]` your background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` JD and your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | low | transferability | Not stated in the JD as a requirement; implied by "our pet-insurance product". Motor pricing carries over; claims, species and breed effects and vet-cost dynamics are not exercised | `[inferred]` from the product name; `[generic]` that pet pricing differs from motor | see G1 |

Confidence follows the intake ceiling: your statements are CV-equivalent, so nothing reaches `high` without an inspectable artifact.

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9) | transferability | Motor pricing, GLMs, price tests; no pet work | The likeliest objection from a pet-product team | Any pricing work on a non-motor product, or a rating factor that behaves differently by customer type | A short note on a motor rating-factor decision, written so the reasoning transfers | `[inferred]` bridge; `[generic]` that pet pricing differs |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management unstated | unknown | — | "Own pricing analytics" (no team named) | The role may be an individual-contributor senior post, or may carry reports the posting does not name | `[inferred]` from the JD's silence on team | Does this role line-manage anyone now, or within the next year, and who would I work with? | unresolved |
| RR2 | Salary and contract basis not stated | unknown | — | No salary or contract type in the posting | Pay may sit below the role-family band, or it may simply not be published | `[inferred]` from the posting's silence | What is the salary band, and is the role permanent or fixed-term? | unresolved |
| RR4 | Pet-product maturity unknown | unknown | — | "our pet-insurance product" | If the product is new, there is little pricing history to build on, and the model work may start from scratch | `[generic]` pattern for new product lines | How long has the pet product been live, and how much claims history does the model use? | unresolved |
| RR5 | Employer not established (standing entry) | risk_signal | medium | "Brindlemoor (insurtech)" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research could not run, so this is unverified, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Scope is concrete | positive_signal | — | "design and read price tests, and turn the results into recommendations" | The role has defined outputs, which makes success measurable | `[grounded]` JD | Which of these outputs does the role finalise without underwriting sign-off? | noted |

Severe red flags: none found. This caps the decision at `conditional_go` until RR5 is verified.

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Brindlemoor's own careers site before spending application effort | RR5 | `[generic]` standing entry | pending your approval |
| A2 | Ask the recruiter whether the role has direct reports and what the contract basis is | RR1, RR2 | `[inferred]` from those rows | pending your approval |
| A3 | Positioning, proposed wording: "Built and maintained the GLM rating model for a young-driver motor book; ran 14 price tests last year with the underwriting team." Each clause traces to your sentences: "built and maintained the GLM rating model for our young-driver book", "ran 14 price tests last year with the underwriting team" | R4, R5 | `[grounded]` your sentences | pending your approval |
| A4 | Interview framing for the pet gap, proposed wording: "The rating method and test design carry over; pet claims and species effects I haven't worked on yet." | R9 | `[inferred]` on what carries over | pending your approval |
| A5 | If asked whether you have managed people: answer plainly that you have not line-managed, then give the closest real example of leading work without reports | RR1 | `[grounded]` your statement | pending your approval |

**Evidence status.**

Verified: none yet.

Research tier: L1 — searches 5 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search returned no result. It would have settled whether Brindlemoor exists as described (RR5), whether the posting is live, and whether the JD matches the careers page |
| 2. Role-family sweep | unavailable | The search returned no result. It would have set the pay band (RR2) and whether line management is normal for this title (RR1) |
| 3. Hiring manager's public footprint | unavailable | A name was given (Odile Varga), so the search was possible but returned no result. It would have informed the scope read and which story to lead with for a Director of Pricing |

Closing sections:

Dossier offer: I can save this as a `tuesday-dossier.md` file for your interview prep later, if you want it.

**Upgrade menu:**
- A link to the live posting on Brindlemoor's careers page, or the recruiter's email domain → RR5 closes
- The salary band and contract type → RR2 closes, and the decision could move to `go`
- A sanitised test readout, or a model-documentation extract with no client data → R5 and R4 rise to `high`
- A sanitised SQL or Python sample → R3 rises to `high`
- Any pet or non-motor pricing exposure, however small → R9 narrows
- Web search enabled in your session → the three unavailable targets run

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

R1 — Are you based in the UK, with the right to work there?

R6 — For the young-driver model, what did you track after launch: performance monitoring, recalibration, or both, and how often?

RR1 — Would a role that includes line-managing a team be a deal-breaker for you, or is it acceptable?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.