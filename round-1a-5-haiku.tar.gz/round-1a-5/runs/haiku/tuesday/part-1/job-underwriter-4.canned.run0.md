**Probably yes on fit, but hold until the location question is answered.** You match the four must-haves on your intake (R2, R3, R4 and R5), and the posting's location terms decide it. Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote UK, versus Leeds four days a week)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R8 (pet-insurance pricing) · unclear: R7 (product-facing recommendations)
- `preferred` — direct: R9 (insurance experience)

R2, R3, R4 and R5 are direct at `medium`, stated at intake and not yet probed. R8 is the pet-insurance gap: the bridge is motor pricing, and its limit is that you have no pet-book experience.

R1 is the gate that decides it. If Leeds four days a week is not workable, this moves to `no_go`.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK, versus Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger.** RR1 (location conflict), RR2 (pay withheld) and RR3 (line management not stated) are open. RR4 is positive: the posting is live, with its scope and reporting line named.
- **What would change this:** the awaited answers are R1 (which location terms are current, and whether Leeds four days a week works) and your pay floor. A workable location with a band-level salary moves this to `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the posting names its pet-insurance product | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | Careers page: Leeds office four days a week. Your JD copy: fully remote (UK). Contradiction, unresolved | `[grounded]` both sources |
| Compensation | Not stated on the careers page or in your JD copy | `[grounded]` both sources |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median £58,400, interquartile range £52,100 to £64,900 (n=612). This is a pattern, not this employer's offer | `[generic]` Pricewell 2026 pay survey, read from search snippet |
| Scope read | Ownership of models and tests is a full analyst remit; no direct reports are stated | `[inferred]` from the mandate and reporting line |
| Employer footprint | A broad search for Brindlemoor returned nothing beyond its careers page. Stage, size and pet-book size are not established | `[grounded]` search result |
| Unknowns | Location, pay, line management, pet-book size and product age | — |
| Contradictions | Location (above) | `[grounded]` both sources |

The standing "employer not established" entry does not apply. The careers page sits on the company's own domain and matches the posting; the thin footprint is an unknown (RR5), not a standing risk.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK; posting terms conflict | hard_gate | unclear | none | hard_gate | No location constraint from you to grade. Sources disagree | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in motor pricing analytics, two as senior analyst, stated at intake; not yet probed | `[grounded]` intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book | `[grounded]` intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review presented to the head of underwriting | `[grounded]` intake | none |
| R6 | Design and read price tests | important | direct | medium | none | Fourteen price tests last year with the underwriting team | `[grounded]` intake | none |
| R7 | Turn results into recommendations for product | important | unclear | low | discovery | Intake covers recommendations to underwriting only; product is silent | `[grounded]` intake silence | G1 |
| R8 | Pet-insurance pricing | important | adjacent | medium | transferability | Motor pricing carries over: GLMs, testing, monitoring. No pet book stated, and pet risk drivers differ from motor; the limit is named here | `[inferred]` requirement from the mandate line; `[generic]` that pet books price on different drivers | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer | `[grounded]` intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-facing recommendations (R7) | discovery | Underwriting recommendations are in the intake; product recommendations are not | Half of the mandate's recommendation line is product-facing | Any result that changed a product decision: a feature, an eligibility rule, a cover change | A product deck or a launch note | `[grounded]` intake silence; `[generic]` that this comes up in interviews |
| G2 | Pet-book pricing (R8) | transferability | Motor is the only book stated | The main objection to your fit | Non-motor pricing, claims frequency or severity work outside motor | A sample analysis or a pricing note | `[inferred]` adjacency; `[generic]` pet risk drivers |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location differs between sources | risk_signal | medium | "Fully remote (UK)" / "Leeds office four days a week" | The terms may have changed, or one advert may be stale | `[generic]` pattern for postings that differ across sources | Is this role fully remote, or Leeds four days a week, and which advert is current? | unresolved |
| RR2 | Compensation withheld | unknown | — | No salary on the careers page | The budget may sit below the band, or pay may simply not be published | `[inferred]` from the posting's silence, against the `[generic]` band in role reality | What base salary is budgeted for this role? | unresolved |
| RR3 | Line management not stated | unknown | — | "reports to the Director of Pricing" | The role may or may not line-manage; you have not managed people | `[inferred]` from the reporting line against the silence on direct reports | Does this role line-manage anyone now, or is that planned in year one? | unresolved |
| RR4 | Live posting with named scope | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Scope and reporting are concrete | `[grounded]` careers page | Which rating models does this role own end to end? | noted |
| RR5 | Footprint thin beyond careers page | unknown | — | Broad search returned no other results | Stage, size and pet-book size are not established | `[generic]` pattern for small insurtechs | How many pet policies are in force, and how long has the product been live? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the GLM build and maintenance on the young-driver book, in your own words | R4 is your strongest must-have | `[grounded]` intake | pending your approval |
| E2 | Connect your monitoring story to the mandate's "build and monitor" line. Odile Varga's 2025 talk was on monitoring rating models in small books. Do not claim small-book or pet experience | Shows you read the mandate without overclaiming | `[inferred]` from the talk snippet and the mandate | pending your approval |
| E3 | Ask the recruiter, through the careers page contact, the location and pay questions before investing in the loop | R1 and RR2 | `[grounded]` RR1, RR2 | pending your approval |

## Evidence status

Verified: none yet. Everything you've given is intake, so every claim sits at `medium` until a question probes it. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst careers" (returned brindlemoor.co.uk/careers/senior-pricing-analyst). Fetched that page: the posting is live, Leeds four days a week, reports to the Director of Pricing. Moved the contradictions row and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Read from the search snippet, not the fetched page. Moved market calibration `[generic]` and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example/in/odile-varga). Read from the snippet, not fetched: Director of Pricing at Brindlemoor; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years. Moved E2 |

Every search and fetch above is named with its page, and the snippet-only reads are marked as such.

I can save this assessment as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Which location terms are current → R1 and RR1 close, and the status likely moves to `conditional_go` or `no_go`.
- Your pay floor → RR2 is set against the band in role reality.
- The budgeted salary, from the recruiter → RR2 closes.
- A pet-insurance or non-motor pricing artifact → R8 moves toward `direct`.
- A product-facing recommendation, such as a deck or note → R7 moves to `direct`.
- A deeper research pass on Brindlemoor (funding, pet-book size, leadership changes; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **R1:** Is Leeds four days a week workable for you, and which location terms are current: the careers page or the fully remote line in your copy? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **Constraints:** What base pay would you need, and is there anything else you won't trade (location, contract type, start date)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **R7 and R8:** Have you done any pricing work outside motor, such as a pet, home or other product, or a result that changed a product decision, even in a side project? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.