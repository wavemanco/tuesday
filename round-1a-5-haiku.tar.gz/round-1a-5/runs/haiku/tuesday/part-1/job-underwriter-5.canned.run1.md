**Yes, it's worth applying, on conditions: `conditional_go`.** Your six years of dbt, Airflow, Python and data-quality work cover every must-have. The open items are your location eligibility, which I can't check until you answer, and whether the role owns ingestion and data contracts.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver location)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery as the warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R2–R6 — direct, on your six years, Python and SQL, Snowflake dbt, Airflow and Great Expectations; R7 — adjacent, the BigQuery gap; R8, R9 — the ingestion and contracts scope is unestablished.

**Opportunity ledger.** The posting is transparent on pay and outcomes, and the pay sits inside the market band (RR3). The main unknowns are the employer's footprint, which search didn't confirm (RR1), and whether the role's scope is wider than a typical senior post (RR2). Equity and on-call terms are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work from a US state or Denver (R1); (2) the role's ingestion and contracts ownership is concrete when you ask (R8, R9, RR2); (3) the BigQuery gap is stated plainly, not papered over (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 staff; Series C $52M, Feb 2026 | `[grounded]` your pasted about page; not independently confirmed (see RR1) |
| Mandate | Build and run pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts | `[grounded]` JD, matches the careers page |
| Scope read | Spans three domains (ingestion, warehouse, contracts); a typical senior post in the pay report owns one domain's pipelines | `[generic]` the report's norm; `[grounded]` the JD text |
| Seniority | 5+ years required; your six sit in the report's typical 5–8 years for "Senior" | `[generic]` the report |
| Market calibration | Median base $151,000; IQR $139,000–$163,500. The posting's midpoint, $157,000, is above the median and inside the IQR | `[generic]` the pasted Datawright report's band; `[grounded]` the posting's figure |
| Unknowns | Equity terms, on-call expectations, hiring manager, team size, how much BigQuery work exists | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No constraint given, so nothing settles it | `[grounded]` JD; constraint not stated | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years stated; self-report, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow set up and used for orchestration | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your background | none |
| R7 | BigQuery as the warehouse (JD's responsibilities) | important | adjacent | medium | transferability | dbt and warehouse work carry over; no BigQuery use | `[inferred]` from the JD's named warehouse | G1 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background; may exist | `[grounded]` JD; CV silent | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background; may exist | `[grounded]` JD; CV silent | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Snowflake dbt work, no BigQuery | Named in the JD's responsibilities; the most likely objection | Any BigQuery exposure, including as a consumer or in a side project | A BigQuery dbt project, or a cost or partitioning note | `[inferred]` bridge from R4; `[generic]` that the objection is likely |
| G2 | Ingestion and contracts (R8, R9, important) | discovery | Silent on both | Decides whether the role is the scope you want | Source pipelines from an app database or CRM; contracts with downstream analysts | A schema doc, a contract spec | `[grounded]` JD and CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not established by search | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The employer may be too new or small to have a footprint, the posting stale, or not a real hiring employer. The live careers page on its own domain narrows this | `[generic]` pattern for companies of this size, not a claim about this one | Who is the hiring manager for this role, and how big is the team? | unresolved |
| RR2 | Scope wider than a typical senior post | risk_signal | low | "Ingestion from our app and CRM, a dbt-modelled warehouse … and the data contracts our analysts depend on" | The role may own three domains where the typical senior owns one | `[generic]` the report's norm; `[grounded]` the JD's three domains | Which of these pipelines does this role own end to end, and which sit with other teams? | unresolved |
| RR3 | Pay in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Midpoint sits above the median and inside the IQR | `[generic]` the report's band; `[grounded]` the posting's figure | Where in the band would a candidate with six years on Snowflake dbt be placed? | noted |
| RR4 | Equity and on-call terms unstated | unknown | — | "plus equity" | Equity size and run or on-call expectations are unspecified | `[inferred]` from the posting's silence on both | What is the equity package, and what does the on-call rota look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with dbt on Snowflake (about 180 models), Airflow and Great Expectations. Do not claim BigQuery work | R4, R5, R6, R7 | `[grounded]` your background | pending your approval |
| A1 | Ask the recruiter RR1, RR2 and RR4 verbatim before investing the full application | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A2 | Confirm location eligibility (R1) before investing effort | Hard-gate check | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" and got no results, so the company is not established from third-party sources. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the posting is live and its text matches the JD you pasted. Moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The pasted Datawright report already fixes the band and scope norm, so no search was needed |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you decide to go ahead, I can write this up as a `tuesday-dossier.md` for the loop.

## Upgrade menu

- A recruiter's confirmation of the hiring manager and team size → RR1 closes; the scope read sharpens.
- The equity package and the on-call rota → RR4 closes.
- Any BigQuery exposure, even a consumer role or a side project → R7 moves from adjacent toward direct.
- Your location and authorization → R1 becomes checkable.
- A deeper research pass on Pellucid Learning (funding, leadership, staff reports, news; up to 5 more searches and 2 more fetches). Say the word and it runs. The first search found nothing, so it may also come back thin.

## Questions

Q1 (R1): Are you authorized to work in the US, and can you work remotely from a US state or from Denver?
Q2 (R8, R9): Have you owned source ingestion from an app database or CRM, or published data contracts that analysts relied on? Which, and what did you own?
Q3 (R7): Have you used BigQuery at all, even as a consumer or in a side project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.