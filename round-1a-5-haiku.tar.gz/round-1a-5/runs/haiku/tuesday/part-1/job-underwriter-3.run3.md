**No, don't pursue this as posted.** R1 (base pay) and R2 (on-site Austin) both fail your hard constraints, so the status is `no_go`. Your sense that something is off is supported by the posting's own terms.

Research did not run this session. The three web searches were refused by the tool permission, so the employer, the live posting and the market band are all unchecked.

## Decision snapshot

**Not worth applying to as posted. R1 and R2 fail. Status: `no_go`.**

**Fit ledger.**
- `hard_gate` — hard_gate_fail: R1 (base pay), R2 (on-site location)
- `must_have` — direct: R3a (paid and lifecycle), R4 (growth leadership) · unclear: R3b (SEO, brand, PR, partnerships, sales ops), R5 (solo start, no bench)
- `important` — unclear: R6 (ambiguity, evolving metrics), R7 (CEO and board reporting)

R1 and R2 fail, which caps the decision. R3a and R4 are where your profile is strong. R3b and R5 are unknown, and resolving them would not reverse a failed gate.

**Opportunity ledger.** The scope is strained and the terms are one-sided: pay (RR1), one person for seven functions (RR4), always-on hours (RR3), and no defined success metrics (RR5). The employer is also unestablished this run (RR6).

- **Hard gates:** failed: R1 (base pay), R2 (on-site location).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **Conditions for go:** none. The failed gates set the status, not conditions.
- **What would change this:** a written base of $150k or more, and a role that is remote-eligible from Portland. Both are the posting's own terms, so only Novaline changing them in writing reopens it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable since day one | `[grounded]` your posting excerpt; not checked online |
| Mandate | All revenue growth end to end, team of one to start, reporting to the CEO with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus equity; your floor is $150k, so the posted top is 57% of it | `[grounded]` posting and your floor |
| Scope read | Seven functions on one person with no stated budget is a bundled-specialization pattern | `[inferred]` from the scope list against "team of one" |
| Market calibration | Not run; no band can be placed against this seniority this session | — |
| Unknowns | Whether $70–85k is the approved budget; success metrics; reporting and board expectations; whether the posting is live | — |
| Contradictions | "Team of one" against seven owned functions, and "8+ years" leadership against a team-of-one start | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay: $70–85k posted | hard_gate | hard_gate_fail | high | hard_gate | Posted top is $85k against your $150k floor. Confidence grades your floor, your own statement | `[grounded]` posting; your stated floor | none; only a written change to base resolves it |
| R2 | On-site Austin, 5 days, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Posting rules out remote; your constraint is remote-only from Portland | `[grounded]` posting; your stated constraint | none; the posting says no exceptions |
| R3a | Own paid acquisition and lifecycle/CRM | must_have | direct | medium | none | Your profile says you owned both, with Braze. Intake prose, not inspected | `[grounded]` your profile | none |
| R3b | Own SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | none | discovery | Your profile is silent on all five | `[grounded]` profile silence | G1 |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | Nine years; growth lead, then Head of Growth | `[grounded]` your profile | none |
| R5 | Operate as a team of one, no bench | must_have | unclear | low | discovery | Your evidence is building teams of 3–7; solo hands-on execution is not described | `[grounded]` profile silence | G2 |
| R6 | Thrive on ambiguity; metrics will evolve | important | unclear | low | discovery | Your ARR run was budgeted with defined targets; nothing on operating without them | `[inferred]` from profile | carried as RR5 |
| R7 | Report to CEO, dotted line to board | important | unclear | low | discovery | Your profile does not mention board exposure | `[grounded]` profile silence | question for the recruiter |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Five named functions (R3b, must_have) | discovery | Profile covers paid and lifecycle only | A third of the mandate is unclaimed; it sets how much of this role is a stretch | A campaign brief or program you ran end to end in one of these areas | `[grounded]` profile silence |
| G2 | Solo execution with no bench (R5, must_have) | discovery | Team leadership is evidenced; hands-on solo work is not | This is the posting's stated working model | A channel or program you launched with no team behind it | `[grounded]` profile silence; `[generic]` that solo-start roles are judged on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base sits well below your $150k floor (R1). Equity does not change the base | `[grounded]` posting against your floor | What base salary is approved for this role? | confirmed |
| RR2 | On-site, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Rules out remote; conflicts with your remote-only constraint (R2) | `[grounded]` posting | Is this role on-site in Austin five days a week in practice, with no remote days at any stage? | confirmed |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine, not occasional | `[grounded]` quote; the always-on reading is `[generic]` pattern | What does "when it matters" look like in a normal month? | unresolved |
| RR4 | Seven functions, one person | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | Scope may outrun one person's capacity | `[inferred]` from the scope list against the team size | Which of these areas have budget and a named owner today? | unresolved |
| RR5 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a fixed definition of success | `[inferred]` from the posting | What three numbers define success at six and twelve months, and who sets them? | unresolved |
| RR6 | Employer not established | risk_signal | medium | "Head of Growth — Novaline (e-commerce enablement startup, Series A …)" | Research did not run, so the employer is unverified. Possible reasons: too new or small for a public footprint, a stale or aggregated posting, or the posting not representing a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Novaline's own careers page, and who would I interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't submit on the posted terms | R1 and R2 fail as written | `[grounded]` R1, R2 | pending your approval |
| A2 | If you still want the conversation, ask for the base and the on-site policy in writing, from Novaline's own careers page | Only a written change to R1 or R2 reopens the decision | `[grounded]` decision rule | pending your approval |

## Evidence status

Verified: R1 and R2, your own stated constraints. R3a and R4 are profile claims, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Novaline's company profile; its Head of Growth posting) were refused by the tool permission. Would have moved RR6 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search (Head of Growth base salary at Series A, remote) was refused. Would have set the market band for RR1 as `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can write `tuesday-dossier.md` with this assessment and its verification questions, so they travel with the application.

## Upgrade menu

- **Search access.** Approving research would check whether Novaline exists, whether the posting is live, and what Head of Growth base pay looks like at this stage. That would move RR1's market calibration and RR6. It would not change R1 or R2, which the posting's own terms settle.
- **The recruiter's written answer on base and on-site policy.** R1 and R2 close only if those terms change in writing.

## Questions

1. **R1 and R2.** Are the $70–85k base and the five-day Austin requirement still what Novaline's own careers page says today? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **RR6.** Can you link the live posting on Novaline's own careers site? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.