**No. As posted, this role fails both of your hard constraints: on-site in Austin five days a week, and $70–85k base against your $150k floor. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site Austin, 5 days a week), R2 (base $70–85k)
- `must_have` — direct: R3 (paid acquisition, lifecycle/CRM), R5 (8+ years growth leadership); unclear: R4 (SEO/content, brand, PR, partnerships, sales ops)
- `important` — unclear: R6 (thrive on ambiguity)

Your fit is strong on the must-haves you can evidence. The posting's terms are what rule it out.

**Opportunity ledger.** The posting has three risk signals and one unknown. RR1 is the always-on wording, RR2 is a scope that puts six functions on one person with no team, and RR3 is pay that sits well below what the seniority and scope ask for. RR4 is the employer itself: I could not verify Novaline, its Series A, or its profitability, because web search was refused in this session.

- **Hard gates:** failed: R1 (on-site Austin, 5 days a week), R2 (base $70–85k); constraints given, both checked.
- **Severe red flags:** none found.
- **What would change this:** only the posting's terms changing would change the status: remote or Portland-compatible, and base at $150k or more. A change on your side to either constraint would be your call; I can't offer a workaround for a hard gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims; not verified (RR4) |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Structure | Team of one to start; reports to CEO, dotted line to board | `[grounded]` posting |
| Working pattern | On-site Austin, 5 days; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run; no search completed | — |
| Unknowns | Employer and posting status; budget and decision rights; what "when it matters" means | — |
| Contradictions | Team of one, yet owning every growth channel including sales ops and PR | `[grounded]` posting, internal tension (RR2) |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only, Portland, not relocating: specific and self-stated, so high. The posting rules it out. | `[grounded]` posting; your statement | none; only the employer changing terms resolves it |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k base, self-stated. The top of the posted band is $65k below it. | `[grounded]` posting; your statement | none |
| R3 | Paid acquisition, lifecycle/CRM | must_have | direct | medium | none | You owned both at two B2C subscription companies; prose only, nothing inspected yet, so the caveat stays: expect a probe. | `[grounded]` your background | none now; a channel dashboard or Braze program summary would raise to high |
| R4 | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Your background does not say whether you ran these. Silence is not absence. | `[grounded]` absence in your background | none for this decision; it would matter only if the gates changed |
| R5 | 8+ years growth leadership | must_have | direct | medium | none | Nine years; growth lead, then Head of Growth; built and managed teams of 3–7; scaled $8M to $40M ARR. | `[grounded]` your background | none |
| R6 | Thrive on ambiguity; metrics will evolve | important | unclear | low | discovery | Not evidenced. Your scaling was done with a budget you controlled, which is structured work, not an ambiguous mandate. | `[inferred]` from your background against the posting's wording | none for this decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Five non-core channels (R4, must_have) | discovery | Your background names paid and lifecycle, not SEO, PR, brand, partnerships or sales ops | Would matter only if the gates changed | Any SEO or content ownership, a PR or partnership program you ran, a brand refresh you led | Channel plans or a results summary per channel | `[grounded]` absence in your background |
| G2 | Ambiguity tolerance (R6, important) | discovery | Your scaling was budgeted and structured | Affects positioning, not eligibility | A launch where you set metrics from scratch | A pre-launch plan with metrics you chose | `[inferred]` from the posting's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "Evenings and weekends when it matters is just who we are" | After-hours work is the norm, not the exception | `[inferred]` from the wording | How often did the team work evenings or weekends last quarter, and is that expected of the Head of Growth personally? | unresolved |
| RR2 | Responsibility without authority or resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | Accountable for six functions with no budget or decision rights | `[inferred]` from the scope list against the team-of-one line | What budget and decision rights come with this role, and who owns sales ops and PR today? | unresolved |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | Stated pay sits well below what this seniority and scope usually command | `[generic]` pattern for this title; market sweep did not run | How was the $70–85k base set for a Head of Growth with this scope? | unresolved |
| RR4 | Employer and posting not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Not checked here; web search was unavailable | `[grounded]` the posting's own claims; research not run | Can you point me at this role on Novaline's own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting on its current terms | R1 and R2 fail as stated | `[grounded]` R1, R2 | pending your approval |
| P2 | If you still want to look at Novaline, ask for the role on its own careers site and put the on-site and pay questions there | RR4, RR1–RR3 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: R1 and R2 constraints, your own statements (`high`). R3 and R5 claims are specific and user-stated, but nothing has been inspected, so they are not yet verified. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline were refused, so no permission was granted. Would have verified RR4 and the posting's live status. |
| 2. Role-family sweep | unavailable | One salary search was refused. Would have set the market band for RR3. |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given. |

Dossier offer: I can write this up as a `tuesday-dossier.md` for your records; say the word.

## Upgrade menu

- The live Novaline posting or careers-page link → RR4 and the posting-status check (target 1).
- Web search enabled for this session → runs targets 1 and 2: employer verification and the market band for RR3.
- An inspectable artifact for paid or lifecycle work, such as a channel dashboard or a Braze program summary → R3 to `high`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.