**Yes, probably worth applying, with the forecast and billing gaps in view. `conditional_go`.** Two checks are still open: Bristol hybrid and the pay range against your own limits, which you haven't told me yet.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days a week), R2 (salary £61,500–£67,000 plus share options)
- `must_have` — direct: R4 (HubSpot or Salesforce administration), R5a (strong SQL); adjacent: R3 (4+ years RevOps or sales ops at a B2B software company), R6 (experience owning a forecast); unclear: R5b (spreadsheet modelling), R7 (working with finance on billing or revenue data)
- `important` — direct: R8a (own CRM data), R9 (pipeline and renewal reporting); adjacent: R8b (own billing data)

R1, R2 — your limits, not yet checked; R3 — a payments company, not software; R5b, R7 — no evidence either way; R6 — pipeline review, not forecast ownership; R8b — payments data is the nearest bridge to billing.

**Opportunity ledger.** The posting holds up: RR1 (salary inside the market band) and RR2 (employer checks out) are positive; RR3 and RR4 are unknowns on share terms and forecast sign-off; RR5 is the one risk signal, billing scope against no billing history.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 fit your own limits; (2) you can give a verifiable forecast example for R6; (3) you have a billing or finance story for R7 and R8b, or you accept billing as a ramp-up gap.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 employees; Series A (£11M) April 2025 | `[grounded]` Quillfield About page (search snippet, not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options. Market band for a UK RevOps lead at a B2B software company: median £64,200, IQR £57,800–£70,400 (n=438) | Posting: `[grounded]`. Band: `[generic]` Ledgerline 2026 pay guide (search snippet) |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` LinkedIn profile (search snippet, not fetched) |
| Scope read | One lead carrying CRM, billing and forecast; the reporting line is not stated | `[inferred]` from the posting's responsibilities against the title |
| Unknowns | Share option terms; who signs off the forecast; reporting line; who owns the billing system | — |
| Contradictions | None found between the posting and the About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | No location claim from you yet | `[grounded]` posting | Question 1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated; posted figure sits inside the band | `[grounded]` posting; `[generic]` band | Question 1 |
| R3 | 4+ years RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years, two as RevOps, at a payments company; years meet it, payments is not software | `[grounded]` your intake | G4 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` your intake | none |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily; modelling not described | `[grounded]` your intake | G3 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Runs monthly pipeline review; never owned the company forecast, finance did | `[grounded]` your intake | G1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Finance collaboration not described; no billing data work | `[grounded]` your intake and posting | G2, Question 3 |
| R8a | Own CRM data | important | direct | medium | none | Salesforce admin | `[grounded]` your intake | none |
| R8b | Own billing data | important | adjacent | low | transferability | Payments-company data is the nearest bridge; billing schedules and invoices not handled | `[inferred]` bridge from payments work | G2 |
| R9 | Pipeline and renewal reporting | important | direct | medium | none | Rebuilt pipeline and renewal dashboards; not inspected | `[grounded]` your intake | Upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6) | transferability | Monthly pipeline review with the sales director; no forecast ownership | Must-have, and the posting names the forecast twice | Pipeline-to-forecast inputs, commit categorisation, forecast variance reviews | Forecast worksheet, commit definitions | `[grounded]` intake; `[inferred]` bridge |
| G2 | Billing and finance data (R7, R8b) | discovery | No billing work; finance collaboration not described | Owns billing data in the role | Bookings-to-invoice reconciliation, renewal billing timing, month-end with finance | Reconciliation example | `[grounded]` intake |
| G3 | Spreadsheet modelling (R5b) | discovery | Excel used daily; no model described | Must-have, modelling is the test | Scenario or cohort models built for pipeline or renewal | A workbook you built | `[grounded]` intake |
| G4 | Software experience (R3) | transferability | Payments company, B2B | The posting says software | Product and data that resemble SaaS subscription data | Product description | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated, inside band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay sits mid-band | `[grounded]` posting; `[generic]` band | — | noted |
| RR2 | Employer attributable | positive_signal | — | Quillfield About page | Established, funded company consistent with the posting | `[grounded]` search snippet, not fetched | — | noted |
| RR3 | Share option terms unstated | unknown | — | "plus share options" | Option value unknown; could move the package | `[inferred]` from silence on terms | What are the vesting period, strike price and exercise window? | unresolved |
| RR4 | Forecast sign-off authority | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO owns the number | `[inferred]` from "with the CFO" against silence on sign-off | Who signs off the final forecast, and what does this role own in that process? | unresolved |
| RR5 | Billing scope against no billing experience | risk_signal | medium | "own our CRM and billing data" | Billing ownership is a day-one ask with no billing history | `[inferred]` from the posting against your intake | Is billing data ownership in the first year's objectives, or does it sit with finance? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter: hybrid days, whether Bristol is fixed, share option terms | R1, R2, RR3 | `[grounded]` posting silence | pending your approval |
| A2 | Prepare a verifiable forecast example from pipeline-review work | R6, RR4 | `[grounded]` intake | pending your approval |
| A3 | Prepare a billing or finance reconciliation example, or a ramp plan for billing | R7, R8b, RR5 | `[grounded]` posting | pending your approval |
| A4 | Surface the Salesforce certification and dashboard work on the CV | R4, R9 | `[grounded]` intake | pending your approval; the CV wording needs a separate pass, which resume-tailor can do |

All four rows are proposals, and none is applied until you approve it.

## Evidence status

Verified: none yet. Unverified leads: Tamsin Achebe's four years at Corvane Payments (search snippet, not confirmed by you). Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol"; returned quillfield.co.uk/about (snippet). Careers page not fetched. Moved: employer attributable, so the failed-attribution entry does not apply |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software 2026"; returned Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example, snippet). Moved: market band, RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; returned linkedin.example/in/tamsin-achebe (snippet). Moved: role reality scope read; the story to lead with (sales operations at a payments company) |

User links read: the posting, fetched (jobs.tallyboard.example).

## Upgrade menu

If you want this kept for interview prep, I can write it up as a tuesday-dossier.md.

- An anonymised screenshot of a pipeline or renewal dashboard you built → R9 to `high`.
- An anonymised forecast worksheet or pipeline-to-forecast reconciliation → R6 toward `direct`.
- An anonymised billing or invoice reconciliation example → R7 and R8b.
- Your location and pay floor → R1 and R2 resolve from `unclear`.
- The recruiter's answers on share terms and reporting line → RR3 and RR4 close.
- A deeper pass on Quillfield (leadership, funding, hiring patterns; up to 5 more searches and 2 more fetches) — say the word and it runs.

1. R1, R2 (hard gates): Is Bristol hybrid, two office days a week, workable for you, and is £61,500–£67,000 plus share options above your floor?
2. G1 (R6): Have you ever used pipeline data to set or check a forecast number? What did you own, and how did finance use it?
3. G2 (R7): Have you reconciled bookings, invoices or renewal billing with finance? Describe one example and what you owned.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.