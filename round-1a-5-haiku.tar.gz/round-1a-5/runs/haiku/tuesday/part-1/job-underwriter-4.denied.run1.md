**Yes, apply, but first check the posting is live on Brindlemoor's own careers site. Status: `conditional_go`.**

Your pricing record matches most of the JD's requirements directly. The open points are one employer check I could not run, whether the role manages people, and pay and location, which you haven't given me.

**Research tier: L1, searches 3 of 5, fetches 0 of 2.** All three searches were refused, so no employer, pay or hiring-manager check ran. Nothing below depends on a search result.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based role)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads)
- `important`: direct: R6 (designing and reading price tests), R7 (building and monitoring rating models); adjacent: R8 (pet-insurance product)
- `preferred`: direct: R9 (insurance experience)

R2 — 5 years, last 2 senior, `medium`; R4 — GLM for the young-driver book, `medium`; R8 — motor, not pet, `medium`, bridge limit named.

**Opportunity ledger.** The posting is clear about scope, but it is thin on people, pay and employer detail. RR1 (employer not established from attributable sources) caps the decision at `conditional_go` until it verifies. RR2 (whether the role manages people) is the unknown most likely to change the call.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based role); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting confirmed on Brindlemoor's own careers site (RR1); (2) the people-management scope confirmed (RR2); (3) your location and pay floor checked against the role (R1, RR4)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your JD text only; not checked externally |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; public footprint not checked |
| Scope read | Senior analytical ownership; the posting names no team | `[inferred]` from "own" and "senior" with no team stated |
| Market calibration | Not run; no pay band | — |
| Unknowns | People management, pay, contract type, start date, team size | — |
| Contradictions | None found within the posting as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based role | hard_gate | unclear | none | hard_gate | Your location and right-to-work position weren't given, so the gate is not established | `[grounded]` JD; no candidate claim | G2 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior; CV-equivalent, no artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your message | offer: a query or script sample |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM for the young-driver book | `[grounded]` your message | offer: model documentation, anonymised |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your message | offer: one test read-out, anonymised |
| R7 | Building and monitoring rating models | important | direct | medium | none | Same GLM work as R4, plus monitoring | `[grounded]` your message | none |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing carries over; no pet work | `[inferred]` from R4 and your statement | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R8, important) | transferability | Motor GLM and price-test work; no pet product | The JD names the pet product, so the bridge will be tested | GLM segmentation and frequency/severity work on a young-driver book; price tests with underwriting | An anonymised rating-factor summary or test read-out | `[inferred]` bridge from R4; `[generic]` that pet books usually price on different drivers than motor |
| G2 | Location and right to work (R1, hard gate) | hard_gate | Your location and eligibility weren't given | Fully remote UK is a term the role sets; it is unchecked | none | Your own statement of location and eligibility | `[grounded]` JD; no candidate claim |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer. This is because the search was refused, not because the employer was found to be absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Whether the role manages people | unknown | — | "Own pricing analytics for our pet-insurance product" | `[inferred]` from "own" and "senior" with no team named; the role may carry people leadership you haven't done | `[inferred]` from the posting's silence on team size | Does this role line-manage anyone, and if so how many people? | unresolved |
| RR3 | Pet-book ramp | risk_signal | medium | "our pet-insurance product" | The first months may rely on pet-specific data you haven't worked with | `[generic]` that pet books price on different drivers than motor | What data does the pet book hold, and what would the first 90 days on it look like? | unresolved |
| RR4 | Pay not stated | unknown | — | none in the posting | Pay isn't stated, so no band can be checked against it | `[grounded]` the JD carries no pay | What is the salary range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's careers site before spending application time | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare an answer on people management for the screen | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Lead with GLM, price tests and underwriting presentations; say "motor, not pet" plainly | see R4–R6, R8 | `[grounded]` your message; the audit keeps it to your own sentences | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at intake, so it stays at `medium`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor insurtech pet insurance careers Senior Pricing Analyst"; refused. Would have settled RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary GLM pricing analytics"; refused. Would have set market calibration and the pay band |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have set which story to lead with |

## Dossier offer

I can write this up as `tuesday-dossier.md` so you can carry it into interview prep later.

## Upgrade menu

- **Brindlemoor's careers-page link for this role** → RR1 closes, and the decision can move to `go`.
- **Your location, eligibility, pay floor and contract type** → R1 and RR4 close, and the hard-gate line gets checked.
- **Permission for web search** → I can rerun the three L1 targets: the employer check, the pay band and the hiring manager's footprint.
- **An anonymised GLM write-up or price-test read-out** → R4 and R6 move from `medium` toward `high`.
- **A description of the pet book's data** → RR3 and G1 narrow.

## Questions

1. Can you paste the posting link from Brindlemoor's own careers page, and tell me who the recruiter is? This is for RR1.
2. Does this role line-manage anyone, and if so how many people? This is for RR2.
3. What are your hard limits: where you're based and can work from, your pay floor, and whether you need permanent or fixed-term work? This is for R1 and RR4.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.