**Yes, worth applying to, with three things checked first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (base pay $148,000–$166,000), R10 (remote US or Denver office)
- `must_have`: direct: R1 (5+ years data engineering), R2 (SQL and Python), R3 (dbt and a cloud warehouse), R4 (Airflow or similar), R5 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R7 (ingestion from app and CRM), R8 (data contracts analysts rely on)

R6 — a Snowflake dbt build with its BigQuery limit named; R7, R8 — no evidence in what you've shared.

**Opportunity ledger.** The pay sits inside the market band and the scope is explicit, which are the posting's strengths (RR2, RR4). Two things are unverified: that the posting is open and the employer is real (RR1, standing entry), and the equity, which is unpriced (RR3).

- **Hard gates:** none failed (R9 and R10 are unclear, not failed); unconfirmed: R9 (base pay $148,000–$166,000), R10 (remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed open and the employer is checked through its own careers page or the recruiter's email domain (RR1); (2) your base floor is below $148,000 and the location works (R9, R10); (3) BigQuery is presented as transferable with its limit, never as experience (R6).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` pasted about page, not independently checked |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting |
| Scope read | Ownership of a domain's pipelines plus contracts, with no direct reports named | `[inferred]` from the posting's scope language, against the typical senior scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500, "senior" usually 5–8 years | `[generic]` pasted Datawright 2026 pay report (US, n=2,310) |
| Pay against market | Posting's $148,000–$166,000 has a midpoint of $157,000, inside the IQR and above the median; equity unpriced | `[grounded]` posting; `[generic]` band |
| Unknowns | Whether the posting is open; hiring manager (none named); equity size and vesting; which CRM and app sources are in scope | — |
| Contradictions | None between the posting and the about page | `[grounded]` both pasted |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in prose; no artifact yet | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models; the warehouse is Snowflake, so the cloud-warehouse part is met | `[grounded]` your background | none |
| R4 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow stated; no artifact yet | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | Great Expectations suite stated; no artifact yet | `[grounded]` your background | Offer a sanitized suite excerpt (upgrade menu) |
| R6 | BigQuery warehouse | important | adjacent | medium | transferability | Same dbt modelling on a different cloud warehouse; BigQuery itself never used, so the limit is platform-specific | `[inferred]` adjacency from the Snowflake work | Name the limit whenever the bridge is used |
| R7 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing in the material on app or CRM sources | `[grounded]` silence | Question Q1 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in the material on contracts | `[grounded]` silence | Question Q1 |
| R9 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor was not given, so the gate is not established | `[grounded]` posting | Question Q2 |
| R10 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Location not given | `[grounded]` posting | Question Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | dbt on Snowflake; no BigQuery | The posting names the warehouse, so the objection is likely | Any warehouse migration or dialect work; cost or partitioning decisions on Snowflake | A BigQuery sandbox exercise or a course project | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Ingestion and contracts (R7, R8) | discovery | Nothing on app, CRM or contract ownership | Two of the posting's five responsibilities are unestablished | Pipelines pulling from a product database or a CRM API; a schema agreement with analysts | A sanitized pipeline diagram or a contract doc | `[grounded]` silence in the material |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The posting may be stale or the employer's footprint may be thin; neither is checked | `[grounded]` no search ran; `[generic]` pattern for companies of this size, not a claim about this one | Is this requisition open, and which team and hiring manager would I interview with? | unresolved |
| RR2 | Pay inside market band | positive_signal | — | "$148,000–$166,000 plus equity" | Base is at or above the typical senior band; no mismatch | `[grounded]` posting; `[generic]` band | Is the base range firm, and is there a level band or bonus? | noted |
| RR3 | Equity unstated | unknown | — | "plus equity" | Total pay cannot be compared without grant size and vesting | `[inferred]` from the posting's silence on grant size | What grant size and vesting schedule come with this role? | unresolved |
| RR4 | Scope explicit | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is defined in the text; no authority gap visible | `[inferred]` from the posting's scope language | Which of these pipelines and contracts would I own end to end, and who approves contract changes? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is open on the careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put the RR1 and RR3 questions to the recruiter | the register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Frame BigQuery as transferable, with the Snowflake dbt work and its limit stated, not as BigQuery experience | see R6 | `[grounded]` R6 | pending your approval |

**Evidence status**

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for the posting was refused, so the posting's liveness and the employer's footprint are unchecked; RR1 stays open |
| 2. Role-family sweep | skipped | The pasted Datawright pay report already fixes the band |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer.** I can write this up as a `tuesday-dossier.md` you can keep and add to as answers come in.

**Upgrade menu**

- Permission to search, which would verify the posting and employer for RR1, a stated check.
- A sanitized Great Expectations suite excerpt or a dbt project listing, which would move R5 and R3 toward `high`.
- Your answer to Q1, which would move R7 and R8 out of `unclear`.
- A BigQuery sandbox exercise, which would narrow G1.
- Your pay floor and the equity terms, which would close R9 and RR3.
- A hiring manager's name, which would sharpen the scope read and the positioning.
- A deeper research pass on Pellucid (funding, leadership changes, past postings; up to 5 more searches and 2 more fetches) if you want it, once search is permitted.

**Questions**

Q1 (R7, R8): Have you built ingestion from a product app or a CRM, or owned a data contract analysts depended on? Which, and what did you own?

Q2 (R9, R10): Does a $148,000 base clear your floor, and will you be working from the US?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.