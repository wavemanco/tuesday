**Yes, apply: `conditional_go`.** Your fit is strong on the tooling and the years, and the two gaps are both about finance-side work: the forecast and billing data. Neither is a deal-breaker, but both should be checked before you invest in the full loop.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office), R7 (salary against your floor)
- `must_have`: direct: R3 (Salesforce or HubSpot administration), R4 (SQL and spreadsheet modelling); adjacent: R2 (B2B software experience), R5 (owning a forecast), R6 (billing or revenue data with finance)
- `important`: direct: R8 (pipeline and renewal reporting)

R2 — years direct, company type adjacent (payments, not software); R5 — pipeline review is an input to a forecast, not ownership of one; R6 — revenue and renewal data yes, billing data no.

Items for the fit ledger: R1 and R7 — your constraints, not yet stated; R2 — payments company, not software; R5 — you have not owned the forecast; R6 — no billing data yet.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R7 (salary against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The posting is clear and reasonably scoped (RR4 positive, RR3 positive); the open questions are who owns the forecast (RR1) and how much of the job is billing data (RR2).
- **What would change this:** conditions for go: (1) RR1 — the forecast sits with this role, not only with finance; (2) RR2 — billing is a minority of the work, or you're comfortable learning it; (3) R1 and R7 — Bristol two days a week and the pay band work for you.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; founded 2018 in Bristol, about 96 staff, Series A (£11M) in April 2025 | `[grounded]` company about page (search result, not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | Median £64,200 for UK revenue operations leads at B2B software companies, interquartile range £57,800–£70,400; the posting's range sits inside it, and its midpoint is near the median | `[generic]` 2026 pay guide sample (n=438), searched this session |
| Unknowns | Whether the forecast is owned or only prepared here; the billing-data share of the job; whether the posting is live on Quillfield's own careers page | — |
| Contradictions | None found between the posting and the company's public pages | `[grounded]` |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | No statement of your location or commute tolerance in the material | `[grounded]` posting | Confirm you can meet this |
| R2 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Years and function direct (five years sales ops, two running RevOps); company is B2B payments, not software | `[grounded]` your intake; company type `[inferred]` | Name the software-adjacent work in your CV |
| R3 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified, rebuilt pipeline and renewal dashboards; certificate not yet inspected | `[grounded]` your intake | Share the certificate to raise to high |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; modelling depth (forecast-style models) not yet shown | `[grounded]` your intake | Share a sanitised model or query |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review and have never owned the company forecast; finance owned it | `[grounded]` your intake; the link to forecasting `[inferred]` | See G1 |
| R6 | Experience working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Revenue and renewal data yes; billing data no; finance collaboration not described | `[grounded]` your intake | See G2 |
| R7 | Salary £61,500–£67,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not stated | `[grounded]` posting | Confirm your floor |
| R8 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt pipeline and renewal dashboards, monthly pipeline review | `[grounded]` your intake | Share one dashboard screenshot |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | Monthly pipeline reviews with the sales director; no forecast ownership | The JD makes forecast ownership a must-have and it is the likeliest objection | Pipeline-to-forecast bridges, commit or best-case calls in the pipeline review, any number that went to leadership | A pipeline review deck, a forecast-vs-actual note | `[inferred]` bridge from pipeline review to forecast; `[generic]` that this is the likeliest objection |
| G2 | Billing data and finance work (R6, must_have) | transferability | Revenue and renewal data; no billing work | A must-have, and the JD leads with billing data | Any reconciliation of renewals to invoices, subscription or revenue reports you used | A reconciliation example, a finance-facing report | `[grounded]` posting; `[inferred]` the bridge |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the forecast outright, or prepare inputs while the CFO signs off | `[inferred]` from the JD's wording against its finance pairing | Does this role own the quarterly forecast, or prepare the inputs that finance signs off? | unresolved |
| RR2 | Billing data share unclear | risk_signal | medium | "you will own our CRM and billing data" | Billing may take a large share of the week and be a steep learning curve for you | `[inferred]` from the JD's wording against your intake | How much of the week goes to billing data versus CRM and pipeline reporting? | unresolved |
| RR3 | Hiring manager's background is close to yours | positive_signal | — | Head of Revenue Operations, formerly sales operations at a payments company | Shared background may make the interview about specifics rather than fit | `[grounded]` public profile search result (Tamsin Achebe) | Which current reports will this role replace first? | noted |
| RR4 | Pay stated and inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is transparent and in line with the typical range | `[grounded]` posting; `[generic]` band | — | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting on Quillfield's own careers page before applying | Only the aggregator listing is confirmed | `[grounded]` posting host | pending your approval |
| P2 | Ask the recruiter or Tamsin Achebe RR1 and RR2 directly | They decide the forecast and billing questions | `[grounded]` register | pending your approval |
| P3 | Confirm Bristol attendance and your pay floor before the first call | R1 and R7 are unconfirmed | `[grounded]` rows R1, R7 | pending your approval |

No CV language is proposed in this reply. If you want edits, say so and I'll draft them for approval.

**Evidence status.**

Verified: none yet. Your intake statements are leads until you confirm them specifically.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol"; the company's about page (quillfield.co.uk/about) confirms the entity, its Bristol base and its size. The careers page was not checked, so the posting is confirmed only on the aggregator |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software 2026", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide); market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile (linkedin.example/in/tamsin-achebe) listing her as Head of Revenue Operations at Quillfield; role reality's scope read |

**Dossier offer:** If you want, I can write this up as a `tuesday-dossier.md` that carries the map, register and questions forward for the interview stage.

**Upgrade menu:**

- A Salesforce certificate or a sanitised pipeline or renewal dashboard → R3 and R8 to high
- A pipeline review deck or a forecast-vs-actual note → R5 from adjacent toward direct
- A billing or renewal reconciliation example → R6 from adjacent toward direct
- Quillfield's own careers page for the role → confirms the posting (P1)
- A deeper research pass on Quillfield (leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G1:** When you ran the monthly pipeline review, did you contribute a forecast number that went to leadership, or only pipeline and renewal figures?
2. **G2:** Have you worked with any billing, invoice or subscription data, even as a report consumer?
3. **R1 and R7:** Can you commute to Bristol two days a week, and what's your pay floor?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.