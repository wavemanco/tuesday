**Not yet: `hold_pending_answers`.** On fit, the role looks worth applying to. But the posting contradicts itself on location, and that is a hard gate for you.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Work location)
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R7 (Monitoring rating models)
- `important`: direct: R6
- `preferred`: direct: R8 · adjacent: R9 (Pet-insurance product)

R1 — the one gate, unresolved; R7 — maintained GLM, monitoring not yet shown; R9 — motor, not pet.

**Opportunity ledger.** RR1 is a location contradiction (risk signal, medium); RR2 is the withheld salary; RR3 is direct reports, which the posting doesn't state; RR5 is a thin independent footprint for the company; RR4 is a positive signal, since the hiring manager has published on monitoring rating models.

- **Hard gates:** none failed; unconfirmed: R1 (Work location); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** The hold waits on R1. If the role is Leeds four days a week and you can't do that, the gate fails and the status becomes `no_go`. If it is confirmed fully remote, the status likely moves to `go` or `conditional_go`, pending the salary answer (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the careers page shows the role live and reporting to the Director of Pricing | `[grounded]` careers page |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests | `[grounded]` JD |
| Working pattern | Contradiction: JD says "Fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` both sources |
| Scope read | Individual-contributor analytics; no direct reports stated | `[inferred]` from silence on reports |
| Market calibration | Senior pricing analyst, UK: median £58,400, interquartile range £52,100–£64,900 (n=612). The posting gives no salary, so this is what to expect, not this employer's offer | `[generic]` Pricewell 2026 survey |
| Unknowns | Salary, direct reports, contract basis, whether monitoring is part of the job in practice | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

Your claims come from your message, so every confidence is capped at `medium` until you give an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: "Fully remote (UK)" vs "Leeds office four days a week" | hard_gate | unclear | none | hard_gate | Posting contradicts itself; your location isn't given, so nothing settles it | `[grounded]` both sources | Q1; RR1 to recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, self-reported | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported; expect a practical test | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver book (motor) | `[grounded]` your message | Model doc would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6 | Design and read price tests (responsibility) | important | direct | medium | none | 14 tests last year; outcomes not stated | `[grounded]` your message | One readout would raise to high |
| R7 | Build and monitor rating models | must_have | adjacent | medium | transferability | You maintained a GLM; monitoring as a practice isn't described | `[inferred]` maintenance is nearest to monitoring | G1 |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product (inferred from product context; not a JD requirement) | preferred | adjacent | medium | transferability | Motor pricing is the nearest work; no pet work | `[inferred]` from product context | G2 |

Not made into a row: managing people. The posting doesn't require it, so it's a question (RR3), not a gap.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Build and monitor rating models (R7, must_have) | transferability | GLM maintenance is evidenced; monitoring routines aren't | A must-have at adjacent; a monitoring example narrows it | Drift or A/E checks on the young-driver model; periodic model reviews | A monitoring pack or review deck, anonymized | `[inferred]` bridge from your maintenance work; `[generic]` monitoring is the likeliest probe |
| G2 | Pet-insurance product (R9, preferred) | transferability | Motor pricing only | Preferred, but the product is pet | Any non-motor pricing work, however small | None that would change the status | `[generic]` role-family pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction (R1) | risk_signal | medium | "Fully remote (UK)"; "Leeds office four days a week" | The listing may be stale, or on-site may be the real expectation | `[grounded]` both sources quoted | Is this role fully remote, or does it require the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (absent from the posting as pasted) | The band in role reality may or may not match the budget | `[grounded]` absence; `[generic]` band | What salary is budgeted for this post? | unresolved |
| RR3 | Direct reports not stated | unknown | — | (silence) | The role may or may not line-manage | `[inferred]` from silence | Does this role line-manage anyone, and what is the team size? | unresolved |
| RR4 | Hiring manager's published talk on monitoring rating models | positive_signal | — | "Small Books, Loud Errors", 2025 Insurance Pricing Forum (search snippet; not fetched) | Your GLM maintenance is the nearest published topic to their interests | `[grounded]` search snippet; `[inferred]` on relevance | How do you monitor a rating model in a small book, and what breaks first? | noted |
| RR5 | Thin independent footprint for the company | unknown | — | (one search for Brindlemoor found no independent coverage) | Young insurtechs often have thin press; the careers page confirms the posting is live | `[generic]` pattern for companies of this age | Which carrier or reinsurer underwrites the pet book? | unresolved |

The standing "employer not established" entry is not triggered: the company's own careers page confirms the posting.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm the location term before investing in the loop | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the salary band and whether the role has direct reports | RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Lead with GLM ownership and the 14 price tests; don't claim pet experience or monitoring beyond "maintained" | R4, R6, R7 | `[grounded]` your message | pending your approval |
| A4 | Ask the RR4 question in the loop | Shows you've read their published work | `[inferred]` relevance | pending your approval |

## Evidence status

Verified: none yet. Your claims are from your message: leads for verification, not proof.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results). Fetched brindlemoor.co.uk/careers/senior-pricing-analyst: live, "Leeds office four days a week." Moved: role reality contradictions; RR1, RR5 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing," which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration `[generic]`; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing," which returned a public profile (linkedin.example/in/odile-varga) and the forum talk listing. Not fetched. Moved: RR4, A4 |

Your message is the only source for your claims, so nothing is `[grounded]` on the candidate side beyond what you wrote.

I can write the full `tuesday-dossier.md` for this role on your go-ahead.

**Upgrade menu**

- A sanitized GLM monitoring pack or model review → R7 moves toward `direct` and R4 to `high`.
- One price-test readout with its outcome → R6 to `high`.
- The recruiter's answers on location and salary → RR1 and RR2 close; the status likely moves to `go` or `no_go`.
- A deeper pass on Brindlemoor (funding, leadership, press, reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Can you work from the Leeds office four days a week, or is fully remote the only arrangement you'd take?

Your own limits: what's your pay floor, and is there any location or contract-type term you won't trade?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.