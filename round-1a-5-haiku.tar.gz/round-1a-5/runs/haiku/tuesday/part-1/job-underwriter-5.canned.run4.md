**Watch-out:** A summary line here can contradict the evidence table. Before you act on a count, an "only" or an all-clear, check it against the table's rows.

Short answer: yes, apply. The role fits you well on the must-haves, and the open items are a few questions you can settle before investing much time.

**Decision snapshot: `conditional_go`**

Yes, you'd be a credible applicant: R3, R4, R5, R6 and R7 (the five must-haves) are all `direct`. The main unknowns are your location and pay constraints, which you haven't given me yet, and BigQuery.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (remote-US or Denver), R2 (pay against your floor)
  - `must_have`: direct: R3 (5+ years data engineering), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
  - `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (data contracts)

  R8 is a credible bridge with its limit named. R9 has no evidence in what you've shared yet, so it's waiting on your answer.
- **Opportunity ledger.** Mostly positive. It's a Series C employer with a live posting on its own domain, and the stated pay sits in the upper half of the market band. Open: no hiring manager is named (RR1), and the data-contract scope is undefined (RR2).
- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver), R2 (pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and pay match your constraints (R1, R2); (2) you're comfortable ramping on BigQuery (R8, RR3).
- **What would change this:** a location or pay mismatch would move it to `no_go` on that gate. A data-contract scope that's mostly analyst-facing rather than ownership would lower R9.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, Denver, 264 employees | `[grounded]` company About page, matches your paste |
| Scope | Pipelines for reporting, ingestion from app and CRM, a dbt warehouse, data contracts | `[grounded]` posting |
| Scope read | Ownership of one domain's pipelines with no direct reports, which is the usual shape for this title | `[generic]` Datawright report |
| Pay | $148k–$166k posted (midpoint $157k) against a median of $151k and IQR of $139k–$163.5k: upper half of the band | `[grounded]` posting; `[generic]` band |
| Unknowns | Hiring manager; contract type; data-contract ownership | — |
| Contradictions | None between the posting and the company page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint | Ask (Q3) |
| R2 | Pay $148k–$166k | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor | Ask (Q3) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated in your background; no artifact yet | Probe in interviews |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | Probe in interviews |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180 dbt models on Snowflake, stated | Name Snowflake explicitly |
| R6 | Airflow or similar | must_have | direct | medium | none | Airflow orchestration, stated | — |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | — |
| R8 | BigQuery warehouse (responsibilities) | important | adjacent | medium | transferability | dbt and a Snowflake warehouse carry over; BigQuery specifics don't | G1 |
| R9 | Data contracts for analysts | important | unclear | low | discovery | Not in your background | G2 |

`[inferred]` for R8's adjacency, from the Snowflake work you described.

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Provenance |
|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience; no BigQuery | The posting names it as the warehouse, so an interviewer will probe it | `[grounded]` posting; `[inferred]` the transfer |
| G2 | Data contracts (R9) | discovery | Not mentioned | The posting names it as a responsibility | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | (no name in posting) | Who would I be reporting to, and who owns this pipeline? | unresolved |
| RR2 | Data-contract scope undefined | unknown | — | "the data contracts our analysts depend on" | Are contracts yours to define and enforce, or mostly consumed by analysts? | unresolved |
| RR3 | BigQuery needed from day one? | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | Is BigQuery fluency required on day one, or is a ramp expected? | unresolved |
| RR4 | Employer confirmed on its own domain | positive_signal | — | Company About page and careers page | — | noted |

The employer-not-established entry doesn't apply: the posting is live on the company's own domain and matches your paste.

**Application plan**

| # | Action | Why | Status |
|---|---|---|---|
| A1 | Confirm location and pay floor before investing time | R1, R2 | pending your answer |
| A2 | Describe BigQuery as adjacent (dbt and Snowflake transfer), not as experience you have | R8 | pending your approval |
| A3 | Ask RR1–RR3 in the first screen | Register doubles as interview prep | pending your approval |

**Evidence status**

Verified: none yet, beyond what you stated in your message. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers" (result: pellucidlearning.com/careers/senior-data-engineer, live) and "Pellucid Learning live online tutoring K-12 Denver Series C" (result: pellucidlearning.com/about, matches your paste). Confirms the entity and posting. The Series C detail comes only from the company's own About page, so it is not independently confirmed |
| 2. Role-family sweep | skipped | The Datawright pay report you supplied fixes the market band |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** If you want, I can write a `tuesday-dossier.md` with this analysis, which you can update as the answers come in.

**Upgrade menu**
- Answers to Q1–Q3: they settle R1, R2 and RR2, and the decision likely moves to `go` or `no_go`.
- A deeper research pass on Pellucid (funding, leadership changes, past hiring; up to 5 more searches and 2 more fetches): say the word and I'll run it.
- A BigQuery project or migration you've touched (even small): would move R8 to `direct`.

**Questions**

- **Q1 (R8, G1):** Have you used BigQuery at all, even in a side project, a migration you scoped, or a cost review? If not, how quickly have you ramped on new warehouses before?
- **Q2 (R9, G2):** Have you defined data contracts with downstream consumers, such as schema agreements, SLAs or breaking-change rules? Who enforced them?
- **Q3 (R1, R2):** Are remote-US and Denver both workable for you? What's your pay floor, and is $148k at the low end of what you'd accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. I'll research nothing further unless you ask.