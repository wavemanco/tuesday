**Probably worth applying to, but not yet: `hold_pending_answers`.** R3–R8 (the must-haves) read `direct` from your intake. R1 (location) and R2 (pay floor) are unconfirmed because your location and pay floor weren't in what you sent. The employer is also unverified, because web search was refused in this session.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (salary $148,000–$166,000)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R11 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3–R8 — direct on your intake, with no artifact yet; R11 (`medium`) — a Snowflake-to-BigQuery bridge, its limit named; R9, R10 — absent from your background, so unknown rather than missing.

**Opportunity ledger.** Mostly unknowns: equity is unquantified (RR1), no hiring manager is named (RR2), and ownership scope is unstated (RR3). RR4 caps the decision at `conditional_go` until the employer is verified. RR5 (the stated Series C) and RR6 (the posted pay sits inside the role-family band) read positive.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if your pay floor is above $166,000, R2 fails and the status becomes `no_go`. If your location doesn't fit the US-remote or Denver terms, R1 fails the same way. If both clear and RR4 verifies, the status moves to `conditional_go`: apply, with R9 and R10 answered in the first recruiter screen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016 in Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` About page as you pasted it; not checked elsewhere |
| Role | Build and run reporting pipelines: ingestion from app and CRM, dbt models in BigQuery, data contracts analysts rely on | `[grounded]` posting as pasted |
| Scope read | Reporting pipelines on one platform; "senior" with no direct reports stated | `[inferred]` from the duties |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years | `[generic]` Datawright 2026 report as you summarised it; not re-checked |
| Pay read | The posted range's midpoint ($157,000) sits above the median and inside the IQR | `[grounded]` posted figure; `[generic]` band |
| Unknowns | Equity size and terms; reporting line; team and ownership scope; your location and pay floor | — |
| Contradictions | None between the posting and the About page as pasted | `[grounded]` both pasted sources |

## Evidence map

Your background is self-reported at intake, so nothing reaches `high` yet, and nothing is `verified`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | You didn't state where you are based, so the gate isn't settled | `[grounded]` posting | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given; the posted range sits inside the market IQR | `[grounded]` posting; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; expect a probe | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models on Snowflake, self-reported | `[grounded]` your intake | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; self-reported | `[grounded]` your intake | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production, self-reported | `[grounded]` your intake | G3 artifact would raise this |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Your background is silent on source ingestion | `[grounded]` background silence | G1 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Dbt and GX tests are adjacent, but you didn't mention contracts with consumers | `[grounded]` background silence; `[inferred]` adjacency | G2 |
| R11 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery is untested. `[generic]` that BigQuery's cost and partitioning models differ from Snowflake's | `[grounded]` "never used BigQuery"; `[generic]` platform differences | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Silent on source ingestion | Core to the duties; the interview will probe it | Pulling from an app database or event stream; syncing a CRM into a warehouse; handling late or changed source records | A pipeline diagram or DAG, sanitized | `[grounded]` silence; `[inferred]` that interviews probe it |
| G2 | Data contracts (R10, important) | discovery | Dbt tests and GX suites, but no mention of agreements with consumers | Analysts depend on it, so it is a named duty | Schema agreements with a downstream team; breaking-change handling; a documented table consumers relied on | A contract or schema doc, sanitized | `[grounded]` silence; `[inferred]` adjacency |
| G3 | BigQuery warehouse (R11, important) | transferability | Snowflake dbt work, no BigQuery | Named as the platform in the duties | Any dbt project on a cloud warehouse; BigQuery sandbox work | A BigQuery sandbox dbt project, or a Snowflake-to-BigQuery migration plan | `[grounded]` "never used BigQuery"; `[generic]` platform differences |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity" | Equity could be a large or a token share of pay; no size, instrument or vesting is given | `[inferred]` from the posting's silence on equity | What equity is offered: grant size, instrument, vesting, and strike price? | unresolved |
| RR2 | No hiring manager named | unknown | — | Posting names no manager | Reporting line and team size are unknown, which shapes the scope read | `[inferred]` from the posting's silence | Who would this role report to, and who else works on these pipelines? | unresolved |
| RR3 | Ownership scope unstated | unknown | — | "build and run the pipelines behind our tutoring platform's reporting" | The role may own these pipelines alone or as one of a team | `[inferred]` from the duties; `[grounded]` typical scope in the pay report summary | Do I own these pipelines end to end, and who reviews the data contracts? | unresolved |
| RR4 | Employer not established | risk_signal | medium | Posting and About page as pasted | Three possibilities, none ranked: too new or small for a footprint; a stale or aggregated posting; or not a real hiring employer. No search ran, so this is unchecked, not disproven | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Series C stated | positive_signal | — | "Series C ($52M, February 2026)" | A resourced company, if accurate | `[grounded]` the About page as pasted; self-reported, unchecked | What does this hire unlock in the next twelve months? | noted |
| RR6 | Posted pay inside the role-family band | positive_signal | — | "$148,000–$166,000" | The posted range is in line with the typical band, not below it | `[generic]` band; `[grounded]` posted figure | Is the range base salary, and does it include bonus? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location against the US-remote or Denver terms | see R1 | `[grounded]` posting | pending your approval |
| A2 | Check your pay floor against the posted range | see R2 | `[grounded]` posting | pending your approval |
| A3 | Verify the posting on Pellucid's own careers page before investing effort | see RR4 | `[grounded]` register | pending your approval |
| A4 | Ask RR1–RR3 verbatim in the first recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A5 | Bridge line for BigQuery: "My dbt and warehouse work is on Snowflake. I haven't run BigQuery in production; here is how I'd ramp it." | see R11 | `[grounded]` your sentences; no BigQuery claim added | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused (permission not granted), so the careers page and the posting's live status are unchecked. The About page and posting you pasted are the only sources. Would have moved RR4 and the organization row |
| 2. Role-family sweep | unavailable | Same refusal. The pay band comes from your summary of the Datawright report, labeled `[generic]`, not re-checked. Would have moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can write this up as `tuesday-dossier.md`, which keeps the map, register and questions for a later turn or a prep session.

## Upgrade menu

- **Search access.** If you allow WebSearch, I can run targets 1 and 2 with up to 2 more searches and 2 fetches (the three refused calls already count). That would check the careers page and the Datawright band directly, and would settle RR4.
- **Your location and pay floor** (Q1, Q2). R1 and R2 close, and the status moves to `go` or `no_go`.
- **A BigQuery sandbox dbt project**, or a note on any BigQuery query you've run. R11 moves from adjacent toward direct.
- **A sanitized DAG or pipeline diagram** from your Snowflake work. R7 moves to `high`, and it gives G1 and G2 something to show.
- **The live posting link.** Sent as a link you want read, it counts as a user link and doesn't use the search budget.

## Questions

Q1 (R1): Are you based in the US? Would the Denver office work, or does it need to be remote?

Q2 (R2): What is your base-pay floor for this role?

Q3 (R9, R10): Have you built ingestion from an app database or a CRM, or a data contract that analysts relied on? Name the source and what happened.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.