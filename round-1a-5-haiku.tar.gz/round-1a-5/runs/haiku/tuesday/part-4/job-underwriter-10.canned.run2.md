**Yes, worth applying for, on conditions. Status: `conditional_go`.** The company checks out on its own pages, and nothing in the WhatsApp message asks you for money, bank details or anything before an offer. Ronan's message is ordinary scheduling by chat for a call held elsewhere, so it's routine. The one thing to check is that the emailed invite comes from fernquay.example.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea kayak surf schools" and "Fernquay product designer job Galway"; fetched https://fernquay.example/careers/product-designer and https://fernquay.example/about. The company exists as described and the posting is live and matches the posting you pasted. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned Ronan's public profile (linkedin.example/in/ronan-kehoe). Public professional footprint only. |

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3 (3+ years of product design), R4 (Strong Figma), R5 (Has run own user research), R6 (Works directly with engineers) · adjacent: R7 (Research calls with school owners), R8 (Owns the booking flow end to end)
- `important` — direct: R10 (One real project, not a polished deck) · adjacent: R9 (First designer, no design peers)

R7 — research with school owners, which is new ground for you; R8 — booking-flow ownership, which you have only at checkout; R9 — a sole design seat, with no direct history; R2 — your pay floor, which decides this gate.

**Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.

**Opportunity ledger.** RR1 is a positive signal: the employer is established. RR4 is a positive signal: the posted pay sits inside the market band. RR2 is a risk signal: a sole design seat. RR3 is unknown: the contract type isn't stated.

**Severe red flags:** none found.

**Conditions for go:** (1) your pay floor sits at or below €52,000 (R2); (2) you frame school-owner research honestly as new, not as experience (R7); (3) you ask who reviews design work day to day (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software (product "Kelproster") for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; funded by its customers | `[grounded]` fernquay.example/about, fetched |
| Ronan's public footprint | Co-founder and CEO; before that, product lead for five years at a Galway travel-software company | `[grounded]` LinkedIn profile, search result |
| Posting | Live on the company's careers page; pay, hybrid pattern and "one real project" wording match the pasted posting | `[grounded]` careers page, fetched |
| Market calibration | Ireland, 3–5 years: median base €57,000, interquartile range €51,500–€62,000 (one survey, n=520, not Galway-specific). The posted range's midpoint is €56,000. | `[generic]` Tillerby 2026 |
| Unknowns | Contract type; whether design decisions have a review step; whether Saoirse's CTO role (per the recruiter) is the same as the co-founder listed on the About page | — |
| Contradictions | None between the posting and the careers page. The About page names Saoirse as co-founder and the recruiter calls them CTO; these aren't in conflict. | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You've said you moved back to Galway; that's self-report, not verified | `[grounded]` your intake message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | medium | hard_gate | Your pay floor wasn't given, so the gate can't be settled | `[grounded]` posting; `[generic]` band | Ask: is €52,000 above your floor? |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; a length requirement, graded on fit | `[grounded]` your intake message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your intake message | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; no artifact yet | `[grounded]` your intake message | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your intake message | none |
| R7 | Research calls with school owners | must_have | adjacent | medium | transferability | Your research was with travel-booking customers, not small-business owners. The bridge: the same user-research method. The limit: the participants and the domain. | `[inferred]` from your research description | G1 |
| R8 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout inside a squad; end-to-end ownership isn't stated | `[grounded]` your intake message | G2 |
| R9 | First designer, with no design peers | important | adjacent | medium | transferability | You've never been the only designer; squad experience is adjacent | `[inferred]` from posting and your background | G3 |
| R10 | One real project, not a polished deck | important | direct | medium | presentation | The checkout case study got a positive response from the recruiter, so you have a project. It may read as polished. | `[grounded]` recruiter's message | Check whether the case study shows real trade-offs |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | School-owner research (R7) | transferability | Your research is with travel-booking customers | A must-have; the most likely objection | Any user interview you ran where the participant ran a business; a survey or support-call review | Interview guide or a session summary | `[inferred]` bridge from your research description |
| G2 | End-to-end booking flow (R8) | transferability | Checkout only | A must-have; the limit is clear | Any decision you owned across search, confirmation or changes | The checkout case study, with decisions marked | `[grounded]` your intake message |
| G3 | Sole designer (R9) | transferability | No solo design history | Affects daily working life, not eligibility | Design decisions you made with engineers and no design review | Examples of decisions you made without a peer | `[inferred]` from posting and your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established from attributable sources | positive_signal | — | "Six people, based in Galway" | The company is small, as stated, and its pages match the posting | `[grounded]` about page and careers page, fetched | Who would I be reviewing with day to day? | noted |
| RR2 | Sole design seat, no design peer | risk_signal | low | "our first designer" | A first design hire may have no one to review design work. `[generic]` pattern for first hires at small companies, not a claim about this one. | `[generic]` | Who reviews design work day to day, and who decides design direction when I'm unsure? | unresolved |
| RR3 | Contract type not stated | unknown | — | Posting is silent | The post may be fixed-term | `[inferred]` from posting silence | Is this a permanent contract, and is there a probation period? | unresolved |
| RR4 | Posted pay sits inside the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The offer is in line with the market for this experience | `[generic]` Tillerby, plus `[grounded]` posting | Is the salary fixed, or open to negotiation? | noted |

The standing entry for an unattributed employer does not apply, because the employer was attributed.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before replying to the invite, check that its sender address ends in fernquay.example, and reply through the emailed invite | Scheduling by chat is routine; this is a simple check | `[grounded]` careers page domain | advice |
| P2 | Prepare to say that school-owner research is new ground for you | R7, G1 | `[grounded]` your research description | pending your approval |
| P3 | Lead with the checkout redesign and the monthly usability sessions, and name what you didn't own | R5, R8, G2 | `[grounded]` your intake message | pending your approval |
| P4 | Consider using mock-interview to prepare for the 45-minute call | Sibling module, named once | — | advice |

Proposed wording for P2 (pending your approval): "I've run monthly usability sessions with customers, but they were travel-booking users, not small-business owners, so school-owner research would be new ground for me." Every clause traces to your own sentences, except the limit, which needs your confirmation.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and update after the call.

## Upgrade menu

- Your pay floor → R2 closes and the gate resolves.
- The checkout case study → R8 and R10 can be checked against what you owned.
- Any school-owner or small-business research notes → R7 moves from `medium` to `high` if they're specific.
- A confirmed contract type from the recruiter → RR3 closes.
- A deeper research pass on Fernquay (funding, hiring history, reports from past applicants; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Evidence status

Verified: none yet. Your background is self-report and stays unverified until you confirm specifics.

## Questions

R2 — Is €52,000 above your pay floor, and what's your floor?

R7 — Have you ever run a research session with someone who runs a small business? If so, what did you learn?

RR2 — When you were in a squad, who reviewed your design work, and did you ever make a decision without a peer?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.