## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Worth applying to, probably, once one question is answered. Status: `hold_pending_answers`.** Your SQL, Power BI and on-time-delivery work match the core of this role. The hybrid three-day Rotterdam office is unconfirmed for you, and the employer is unchecked.

- `hard_gate` · unclear: R1 (Rotterdam office, three days a week)
- `must_have` · direct: R2, R3, R4
- `important` · direct: R5, R7a · adjacent: R7b (route changes with depot managers) · unclear: R6 (temperature compliance)
- `preferred` · adjacent: R8 (Dutch a plus)

R6 has no evidence in your background. R7b is adjacent: you ran the route review, but the posting doesn't say you decided route changes.

- **Hard gates:** unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a yes on the Rotterdam schedule moves it to `conditional_go`, with two conditions: confirm the employer and live posting on Duinvaart's own careers page, and show evidence for temperature compliance or accept it as a gap you'd have to learn.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam. Existence not checked (search refused). | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet; weekly Power BI dashboards; route-change work with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Pay | Not stated in the posting | `[grounded]` absence in JD |
| Scope read | A defined analyst remit covering measurement and advice on routes; decision rights not stated | `[inferred]` from the duties listed |
| Market calibration | Not run; no role-family sweep, so no pay band | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week, Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated whether this works | `[grounded]` JD | Q1 |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, no artifact yet | `[grounded]` your background | Confirm with CV |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use; self-reported | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | Share a dashboard screenshot to raise to high |
| R5 | Track on-time delivery | important | direct | medium | none | Your on-time delivery dashboard covered the same measure | `[grounded]` your background | none |
| R6 | Track temperature compliance, refrigerated fleet | important | unclear | low | discovery | Nothing in your background on temperature or cold-chain measures | `[inferred]` from absence | Q2 |
| R7a | Weekly dashboards | important | direct | medium | none | Your weekly dashboards were used by depot managers | `[grounded]` your background | none |
| R7b | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the route-performance review; not stated that you decided changes | `[inferred]` | Confirm whether you proposed or approved route changes |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; limit: depot-manager conversations in Dutch | `[grounded]` your background | Name the limit |

**Gap recovery queue**
- R1 (hard gate): closes only with your yes or no on the Rotterdam schedule.
- R6 (discovery): closes if you have tracked any compliance measure beyond delivery timing.
- R7b (transferability): the limit is that you may not have decided route changes yourself.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Route-change decision rights unstated | unknown | — | "work with depot managers on route changes" | The role may advise depot managers rather than approve changes | `[inferred]` from "work with" against silence on decision rights | Does this role approve route changes, or recommend them to depot managers? | unresolved |
| RR2 | Employer not checked | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Entity and live posting unconfirmed. A thin footprint is common for small firms. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay not stated | unknown | — | (no pay in posting) | Pay may be set later, or withheld | `[inferred]` from absence in JD | What is the salary range for this role? | unresolved |
| RR4 | Scope concrete and consistent | positive_signal | — | "Track on-time delivery and temperature compliance…" | Defined, measurable scope | `[grounded]` JD | What does the current dashboard cover, and who maintains it? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Answer Q1 before applying | R1 decides the status | `[grounded]` R1 | pending your approval |
| P2 | Find the posting on Duinvaart's own careers page | RR2 | `[generic]` pattern | pending your approval |
| P3 | Lead with the on-time dashboard story, stating only what you built | R5, R7a | `[grounded]` R5, R7a | pending your approval |

---

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

**Not worth applying to now. Status: `no_go`.** The role's core is three to four years of FMCG planning, a planning system and fluent Dutch. You have none of the planning years and conversational Dutch. Several must-haves are absent, and nothing in this application can close them.

- `hard_gate` · unclear: R1 (on-site in Utrecht)
- `must_have` · adjacent: R2 (fluent Dutch), R6 (run weekly S&OP) · absent: R3 (3+ years FMCG planning), R4 (own a 13-week supply plan), R5 (balance production capacity against forecast) · unclear: R7 (advanced Excel), R8 (SAP IBP or similar)

- **Hard gates:** unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to differ:** three or more years of FMCG planning, or a planning-tool track record. Neither can be added to this application.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht. Existence not checked (search refused). | `[grounded]` JD header |
| Mandate | Own a 13-week supply plan for a chilled ready-meals range; balance capacity against forecast; run weekly S&OP | `[grounded]` JD |
| Working pattern | On-site, Utrecht | `[grounded]` JD |
| Scope read | A single-owner planning role with a standing weekly meeting | `[inferred]` from the duties listed |
| Market calibration | Not run | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on location | `[grounded]` JD | Q1 |
| R2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; limit: not fluent for planning meetings | `[grounded]` your background | Name the limit |
| R3 | 3+ years FMCG supply or demand planning | must_have | absent | medium | transferability | Zero planning years by your account; adjacent ops analytics is the only bridge; its limits are no forecasting and no FMCG | `[grounded]` your background | none |
| R4 | Own a 13-week supply plan | must_have | absent | medium | capability | No planning ownership; no credible adjacent evidence for this | `[grounded]` your background | none |
| R5 | Balance production capacity against forecast | must_have | absent | medium | capability | No capacity or forecast work in your background | `[grounded]` your background | none |
| R6 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review; S&OP is a cross-functional planning meeting, a different kind of work | `[inferred]` | none |
| R7 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned in your background | `[inferred]` from absence | Q3 |
| R8 | SAP IBP or a similar planning system | must_have | unclear | low | discovery | Not mentioned in your background | `[inferred]` from absence | Q3 |

**Gap recovery queue**
- R1 (hard gate): closes with a yes or no on Utrecht.
- R7 and R8 (discovery): close if you have built forecast or capacity models, or used a planning system, even partly.
- R3, R4, R5 (absent): no closure in this application.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role mandate concrete | positive_signal | — | "Own the 13-week supply plan" | Clear ownership and cadence | `[grounded]` JD | Who sets the forecast the plan is balanced against? | noted |
| RR2 | Employer not checked | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Entity and live posting unconfirmed. A thin footprint is common for small firms. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Skip for now; keep the posting on file | R3, R4, R5 absent | `[grounded]` register | pending your approval |

---

**Evidence status (both postings)**

Verified: none yet. Your background claims are self-reported, so every row stays at `medium` at most.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company site and careers page, Duinvaart | unavailable | Search refused by the session's permissions, so I did not retry. Would have checked the entity and the live posting (RR2). |
| 2. Role-family sweep, Duinvaart | unavailable | Would have set the pay and scope band. No search was sent. |
| 3. Hiring manager's footprint | n/a | No name given |
| 1. Company site and careers page, Kroonhaven | unavailable | Search refused, as above. Would have checked the entity (RR2). |
| 2. Role-family sweep, Kroonhaven | unavailable | Would have set the pay and scope band. No search was sent. |
| 3. Hiring manager's footprint | n/a | No name given |

**Dossier offer:** I can write both assessments to a `tuesday-dossier.md` file if you want to keep them.

**Upgrade menu**
- A screenshot of your on-time dashboard, or any artifact from it, raises R4 and R5 to `high`.
- Web search access, if you grant it, would settle RR2 for both employers and would set pay bands.
- A salary figure from either employer closes RR3 for Duinvaart.
- Any planning-tool or forecasting work, even small, moves R7, R8 and R5 for Kroonhaven.

**Questions**

1. Q1 (R1, both postings): Is three days a week in Rotterdam, or on-site in Utrecht, workable for you?
2. Q2 (R6, Duinvaart): Have you tracked any compliance measure beyond delivery timing, such as temperature excursions, SLA breaches or audit findings? What did you measure, and did you own the reporting?
3. Q3 (R7, R8, Kroonhaven): Have you built a forecast or capacity model, even in Excel, or used a planning system such as SAP IBP, Oracle, or a similar tool?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.