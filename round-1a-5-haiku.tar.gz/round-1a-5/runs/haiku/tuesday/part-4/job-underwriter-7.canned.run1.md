**Yes, probably worth applying for, with three things to check first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5a, R6, R8 · adjacent: R5b (leg-ulcer care) · unclear: R7 (continence care), R9 (care planning), R10 (end-of-life visits) · absent: R11 (holding your own caseload)
- `preferred`: absent: R12 (Doppler assessment)

R4 — the essential records requirement is not evidenced in your CV, so it is the one to close; R5b — leg-ulcer care is adjacent to the pressure-ulcer and surgical-wound work you have, with the limit named; R11 — you have never held your own caseload, which is the main structural difference from your current role; R12 — Doppler is a closable gap through training.

**Opportunity ledger.** Calderbrook Community Health is established as a real CIC with an NHS contract (RR1 aside, the employer checks out). Open: whether the posting is still live (RR1), what support a first caseload comes with (RR2), and the mileage terms (RR3). Two entries run the other way: the lead's public focus on leg-ulcer clinics and Doppler training (RR4), and pay that sits near the market median (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. Both gate rows rest on your own statement, not on a check: confirm your NMC register entry and driving licence yourself.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live (RR1); (2) you can evidence timely records on an electronic system (R4); (3) the caseload support on offer is acceptable (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a CIC founded 2015, 410 staff, four locality hubs, adult community services under an NHS contract in Calderdale | `[grounded]` the organization's About page |
| Mandate | District nursing for housebound adults; wound, catheter, continence, insulin, end-of-life and care-planning work; a small caseload with senior support | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage. Survey median for Band 5 community staff nurses is £34,300 (IQR £32,400–£36,600), so this is mid-range | `[generic]` Wardround 2026 survey, n=1,240, self-reported; `[grounded]` posting figures |
| Unknowns | Posting status, caseload support, mileage rate, records system | — |
| Contradictions | None found between the posting and the sources I could reach | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | high | none | Your own specific statement; registration active, revalidation March 2028 | `[grounded]` your CV | Check your NMC register entry yourself |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B, full; stated, not checked | `[grounded]` your CV | Confirm against your licence record |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse; self-reported, no inspectable artifact yet | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on records or any electronic system | `[grounded]` CV silence | G1 |
| R5a | Wound care (pressure ulcers, surgical wounds) | important | direct | medium | none | Stated in CV; no artifact | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound-care work carries over; leg ulcers are a separate aetiology you have not stated treating. Limit: venous and arterial assessment not exercised | `[inferred]` from R5a | G2 |
| R6 | Catheter care | important | direct | medium | none | Stated in CV | `[grounded]` your CV | none |
| R7 | Continence care | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | G2 |
| R8 | Insulin administration | important | direct | medium | none | Stated in CV | `[grounded]` your CV | none |
| R9 | Care planning | important | unclear | low | discovery | Home visits after discharge likely involved planning, not stated | `[inferred]` from visit work | G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | No end-of-life work stated | `[grounded]` CV silence | G2 |
| R11 | Holding a small caseload of your own | important | absent | medium | transferability | You have never held one. Bridge: discharge-to-assess visits; limit: you did not own the patient list | `[grounded]` your statement | G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | high | capability | You have not done one. Closure path: a Doppler training course | `[grounded]` your statement | Name a course in your application plan |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Records (R4, must_have) | discovery | Nothing on electronic records or note timeliness | An essential requirement; the posting names it | A written note or redacted record sample you produced | `[grounded]` posting essential list |
| G2 | Leg-ulcer, continence, care planning, end-of-life (R5b, R7, R9, R10) | transferability / discovery | Wound and catheter work is stated; these four are not | Each is a duty you would be expected to carry on day one | A care plan or visit note you wrote | `[inferred]` mapping from CV |
| G3 | Own caseload (R11) | transferability | No caseload history | Your largest structural gap | Any patient list you kept during discharge visits | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The advert may have closed or been reposted under another title | `[inferred]` from the failed careers-page fetch | Is this post still open, and is it the current advert for the Halifax team? | unresolved |
| RR2 | First-caseload support not stated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Support may be informal or the caseload may grow quickly | `[inferred]` from the posting's silence | What caseload size and supervision would I start with in the first three months? | unresolved |
| RR3 | Mileage terms not stated | unknown | — | "plus mileage" | Rate or allowance could differ from the pool-car arrangement | `[grounded]` posting | What is the mileage rate, and roughly how many miles a week should I expect? | unresolved |
| RR4 | Team lead's public focus on leg-ulcer clinics and Doppler | positive_signal | — | Rhiannon Mabbott's 2025 forum talk | The team may value Doppler learning for new staff | `[inferred]` from a public talk | Is Doppler training provided for new community staff, and when? | noted |
| RR5 | Pay near survey median | positive_signal | — | £31,050–£37,800 | Pay is in a normal range for this band | `[generic]` survey band | none | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting is live on the careers page before applying | RR1 | `[grounded]` RR1 | advice |
| P2 | Ask the team lead at the informal chat the three questions in RR1, RR2 and RR3 | The register doubles as interview preparation | `[grounded]` register | advice |
| P3 | Do not claim leg-ulcer, continence or end-of-life experience until you have confirmed it | Truthfulness; see R5b, R7, R10 | `[grounded]` the audit rule | advice |
| P4 | Name Doppler training as a planned step, not as experience | R12 | `[grounded]` R12 | pending your approval |
| P5 | Draft any CV line for records only once the G1 answer is in hand | R4 | `[grounded]` R4 | pending your approval |

**Evidence status**

Verified: R1, R2, R3, R5a, R6, R8 claims (your CV, confirmed in this conversation as stated; none inspected). Verified is about the claim, not the fit. Unverified leads: none. Rejected inferences: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" → calderbrookhealth.example/about (CIC, founded 2015, 410 staff, NHS contract, Calderdale). Fetched calderbrookhealth.example/careers: no page returned. Moved: employer established; RR1 opened |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026 nurse salary range" → Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration `[generic]`, pay line |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead" → communitynursingforum.example/speakers/rhiannon-mabbott (leads Halifax district nursing team; 2025 talk on leg-ulcer clinics and Doppler). Moved: RR4, and which story to lead with for this reader |

**Upgrade menu**

- An electronic-record sample or note from your current role → R4 can move from `unclear` to `direct`, and the decision likely moves to `go`.
- A leg-ulcer, continence or care-plan example from your discharge visits → R5b, R7 and R9 firm up.
- The live posting link, or the team's answer on caseload support → RR1 and RR2 close.
- The mileage rate → RR3 closes.
- A deeper research pass on Calderbrook (leadership changes, staff reports, past advertisements; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can save this as `tuesday-dossier.md` so the map carries into later sessions.

Three questions, each tagged to its gap row. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Which electronic record have you written notes in, and how quickly did you usually complete them on a busy list? Can you share a redacted example?

G2 — Have you ever led a care plan from assessment through review, or done end-of-life or continence visits, even as part of a team? What did you personally own?

G3 — On discharge-to-assess, did you ever hold a list of patients you were accountable for, or did you only visit as part of a team?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.