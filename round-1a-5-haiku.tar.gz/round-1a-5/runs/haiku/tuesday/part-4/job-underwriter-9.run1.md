Yes, that is normal. After a written offer that names the role and the pay, asking for bank details, a PPS number and right-to-work documents is routine onboarding, so none of it counts as a red flag. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R2 · unclear: R1 (Limerick office two days a week), R3 (right to work in Ireland)
- `must_have`: direct: R4, R6, R7 · unclear: R5 (working knowledge of Irish PAYE, PRSI and USC)
- `important`: direct: R9, R10 · adjacent: R8 (monthly run for 240 staff) · unclear: R12 (answering staff payroll queries) · absent: R11 (pension changes)

R4, R6 and R7 are the three must-haves you can show now. R5 is the statutory knowledge still to confirm. R11 is the one row with no evidence.

**Opportunity ledger.** RR1 (employer not yet verified, `severity: medium`) caps the decision at `conditional_go`. RR2 (who runs pension changes) is an unknown. RR3 is a positive signal: the €40,000 offer sits inside the posted €38,000–€42,000 band.

- **Hard gates:** none failed (R2 `direct`); unconfirmed: R1 (Limerick office two days a week), R3 (right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears: the vacancy appears on Marrowgate's own careers page and the reply address matches its website; (2) R1 and R3 are confirmed by you; (3) RR2 is answered in writing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` posting; not checked from outside (see Evidence status) |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` posting |
| Working pattern | Permanent, hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Pay | Posted €38,000–€42,000; offered €40,000 | `[grounded]` posting and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | The posting covers the whole payroll cycle, including reconciliation, so this is a full-cycle role rather than a slice | `[inferred]` from the listed duties |
| Market calibration | Not run; web search was refused | — |
| Unknowns | Whether the vacancy is live on their site; who runs pension changes and with which provider; start date | — |
| Contradictions | None found between the posting and the offer | `[grounded]` posting and offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work in the Limerick office two days a week | hard_gate | unclear | none | hard_gate | Your location and availability were not given, so the gate is not established. The on-site interviews point the same way but do not settle it | `[grounded]` posting; `[inferred]` from the interviews | Q3 |
| R2 | Pay within the posted band | hard_gate | direct | none | none | The €40,000 offer sits inside €38,000–€42,000. You gave no pay floor, so the band grades nothing about you | `[grounded]` posting and offer | none |
| R3 | Right to work in Ireland, without sponsorship | hard_gate | unclear | none | hard_gate | The posting is silent. The offer's right-to-work check makes it a gate. Your status was not given | `[grounded]` offer | Q3 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, self-reported, no artifact yet | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background names no statutory deductions. The 2024 certificate may cover them, but nothing you gave says so | `[grounded]` absence from your background | Q2 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily pivot tables and XLOOKUP | `[grounded]` your background | none |
| R7 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, not yet shown | `[grounded]` your background | attach the certificate |
| R8 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Fortnightly payroll for 90 staff is the same work on a different cycle and scale. Limit: no monthly run at 240 | `[inferred]` from your cycle and headcount | state the limit in any application |
| R9 | Starters and leavers | important | direct | medium | none | Named in your background | `[grounded]` your background | none |
| R10 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Monthly reconciliation at the hotel group | `[grounded]` your background | none |
| R11 | Process pension changes | important | absent | none | discovery | You have not done them; your manager did. Whether you watched or supported that work is unknown | `[grounded]` your account | Q1 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background does not mention staff-facing queries | `[grounded]` absence from your background | none; carried as a minor point |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R11, important) | discovery | You have not processed them; your manager did | Named in the role's duties | Any joiner, opt-out or contribution change you saw, checked or prepared | Your manager's process note, or the provider's schedule | `[grounded]` posting and your account |
| G2 | Irish statutory deductions (R5, must_have) | discovery | Certificate and payroll work, but no deductions named | Named as working knowledge in the requirements | Calculating PAYE, PRSI or USC on a payrun; Revenue reporting; resolving a deduction query | Certificate syllabus; a sample payrun with personal details removed | `[grounded]` requirement; `[generic]` that certificate syllabuses vary by provider |
| G3 | Scale and cycle (R8, important) | transferability | Fortnightly, 90 staff | Monthly for 240 is a different load | Any larger or monthly run | None needed; state the limit | `[inferred]` from the two cycles and headcounts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from outside | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. None is ranked; none has been checked, because web search was refused | `[generic]` pattern for employers at this stage of checking, not a claim about this one | Can you point me to this vacancy on Marrowgate's own careers page, and confirm that people@marrowgatehousing.ie is the address your People Team uses? | unresolved |
| RR2 | Pension scope unclear | unknown | — | "process starters, leavers and pension changes" | Pension changes may go to an outside provider or to someone outside this post | `[inferred]` from the listed duty against your absent evidence (R11) | Who runs pension changes day to day, which provider is used, and would this post process them? | unresolved |
| RR3 | Offer sits inside the posted band | positive_signal | — | "the permanent post … at €40,000 a year" | The offer and the posting agree, which is a specific and transparent term | `[grounded]` posting and offer | Is €40,000 the full package, including any pension contribution? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before replying, find the vacancy on Marrowgate's own careers page and check that the reply address matches its website | RR1 | `[generic]` standard check on any new offer | pending your approval |
| A2 | Enter bank, PPS and right-to-work details only in the portal at the address the employer's own website gives, not by replying to the email | Routine onboarding; this is the one check that matters | `[grounded]` offer's portal step; `[generic]` on the check | pending your approval |
| A3 | Expect to bring the original passport on day one; keep a copy and the portal confirmation | Routine right-to-work check | `[grounded]` offer | pending your approval |
| A4 | Ask in writing who runs pension changes and which provider, before accepting | RR2, G1 | `[grounded]` RR2 | pending your approval |
| A5 | Ask whether €40,000 is the full package, including any pension contribution | RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches for Marrowgate Housing were refused by the host's permission, so nothing came back. Would have settled RR1: whether the vacancy is live and whether the contact address matches the employer's site |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market band for €38,000–€42,000 and the scope read |
| 3. Hiring manager's public footprint | unavailable | Name given (Declan Garvagh, Finance Manager). Not attempted once the first two were refused. Would have moved positioning only |

The employer, the posting and the market band have therefore not been checked from outside. The assessment above rests on the posting, the offer and your account.

If you want, I can write this up as a `tuesday-dossier.md` that you keep and update as answers come in.

## Upgrade menu

- A live link to the vacancy on Marrowgate's own careers page → RR1 closes, and the decision could move to `go`.
- Your answers on pension changes → R11 and RR2 move.
- The 2024 certificate attached, or a sample payrun you calculated → R7 and R5 move toward `high`.
- Permission for web search → targets 1 to 3 run: the employer check, the market band for €40,000, and Declan Garvagh's public footprint.

## Questions

Q1 (R11): Have you checked, prepared or watched pension changes (joiners, opt-outs, contribution changes) under your manager? If so, what did you touch?

Q2 (R5): Which of PAYE, PRSI and USC have you calculated or reported to Revenue yourself, and does your 2024 certificate cover them?

Q3 (R1 and R3): Can you work two days a week in the Limerick office, and do you have the right to work in Ireland without sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.