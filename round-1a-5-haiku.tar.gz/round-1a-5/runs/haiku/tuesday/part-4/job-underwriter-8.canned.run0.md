**Short answer: no. Don't send anything, don't pay anything, and don't deposit the cheque.** I can't establish the firm from here, and the requests in these messages are very likely a scam. Keep your IBAN, PPS number and passport to yourself.

**Decision snapshot**

**Not worth applying to on these terms. Status: `no_go`.**

Fit ledger:

- `hard_gate`: unclear: R1 (pay against your €30,000 floor), R2 (hours against the 15–30 a week)
- `must_have`: adjacent: R3 (spreadsheet tracking); R4 (attention to detail)
- `important`: unclear: R5 (written English), R6 (quiet place to work)
- `preferred`: adjacent: R7 (order processing)

R3 and R4 are real strengths, but they don't outweigh the requests in the register. R1 and R2 are unresolved, not failed, because the posting says "up to €26 an hour" and you haven't given your hours.

Opportunity ledger: four severe red flags (RR1 to RR4), each confirmed by the messages. Any one is enough for `no_go`. The standing employer-not-established entry (RR5) is also unresolved.

- **Hard gates:** none failed; unconfirmed: R1 (pay floor against "up to €26 an hour" for 15–30 hours), R2 (hours not given); candidate constraints partly given, hours checks unknown
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the employer would have to stop asking for these things, and you would have to confirm that through contact details you find on its own website. Only then could this move past `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; no web presence found in two searches | `[grounded]` search result, empty |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Pay arithmetic | At €26 an hour, 30 hours a week is about €40,500 a year before commission; reaching €30,000 needs roughly 23 hours a week at the top rate | `[inferred]` from the posting's figures |
| Hiring process | Telegram only, no calls or video | `[grounded]` posting and messages |
| Unknowns | Real employer; contract type; commission basis; what the "equipment partner" is | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay meets your €30,000 floor | hard_gate | unclear | high | hard_gate | Your floor is your own confirmed constraint. The posting's pay doesn't settle it | `[grounded]` your stated floor; `[inferred]` arithmetic | Ask for the guaranteed hours and rate, in writing, on the employer's own site |
| R2 | Hours fit your availability | hard_gate | unclear | low | hard_gate | No availability given | `[grounded]` posting | Tell me your weekly hours |
| R3 | Spreadsheet tracking | must_have | adjacent | medium | presentation | You keep a weekly Excel tracker. No file to inspect yet | `[grounded]` your intake message | None yet |
| R4 | Attention to detail | must_have | adjacent | medium | transferability | 60 Zendesk tickets a day, a customer-service record. Not order processing | `[inferred]` bridge from your intake | None yet |
| R5 | Good written English | important | unclear | medium | discovery | You wrote this in English; not tested | `[grounded]` your message | None |
| R6 | Quiet place to work | important | unclear | low | discovery | Not asked | `[grounded]` posting | None |
| R7 | Order processing | preferred | adjacent | medium | transferability | Parcel courier work, not order processing | `[inferred]` | None |

**Gap recovery queue.** R1 and R2 are the only real gaps, and both depend on the employer's own terms. R3 and R4 need no recovery, and R5 to R7 are minor.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment before work | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Money goes out before any work or pay, and the refund is a promise, not a term | `[generic]` pattern for this kind of request | Does the company require new hires to pay for equipment, and can you confirm that on your own website? | confirmed |
| RR2 | Cheque deposit with money sent back | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner" | Overpayment of this kind is a known scam pattern: the cheque can bounce after you have already sent money on | `[generic]` pattern | Do you issue cheques to new hires to pay equipment suppliers? | confirmed |
| RR3 | Bank, PPS and passport details before an offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Requested before any written offer, at the screening stage | `[grounded]` the message's timing | Do you collect bank or ID details before a written offer? | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The interviews and the offer happen only in chat, which makes the employer hard to verify | `[grounded]` posting | Can you arrange a call through the company's main phone line listed on its own website? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

Hold: Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not send your IBAN, PPS number or passport, and do not pay or deposit anything | RR1 to RR3 | `[grounded]` messages | pending your approval |
| A2 | Find Velloway's own website yourself and check whether this role is listed there | RR5 | `[grounded]` search returned nothing | pending your approval |
| A3 | If the role is genuine, ask the employer the RR1 to RR4 questions through its own contact details | the register doubles as your questions | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Everything above about you is your own intake statement, which counts as a lead until you confirm specifics.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics Remote Order Processing Coordinator scam Telegram equipment fee cheque". Both returned no results, so the employer is not established. RR5 stays unresolved |
| 2. Role-family sweep | skipped | The four severe red flags fix the status alone; a pay band would not change it |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can save this as `tuesday-dossier.md` if you want a record of it.

**Upgrade menu**

- The employer's own careers page or a live posting on its own domain → RR5 closes or stays open
- A written offer on the company's own domain naming the role, pay and hours → R1 and R2 can be assessed; RR1 to RR4 still need answers
- Your weekly hours and minimum pay → R1 and R2 close

Questions (answer in text, or say skip):

1. Can you find Velloway's own website yourself, and does it list this role? (RR5)
2. How many hours a week can you work? (R2)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.