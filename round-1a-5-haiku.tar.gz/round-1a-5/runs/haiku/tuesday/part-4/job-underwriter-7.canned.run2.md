**Yes, Aoife, this is worth applying for: `conditional_go`.** You meet both essential licence checks and the one-year bar. The real gaps are caseload ownership, leg-ulcer care, Doppler, and the records and planning evidence the CV doesn't show. The condition is confirming the post is live.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5a, R6a, R7 · adjacent: R5b (leg-ulcer care), R8 (caseload ownership) · unclear: R6b (continence), R9 (care planning), R10 (end-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R5b — a credible bridge through wound assessment, its limit named; R8 — home-visit work is the bridge, the never-held-a-caseload limit named; R4 — the records question is open; R11 — preferred, with a training path.

**Opportunity ledger.** The employer is established and the pay is published, with a named contact (RR3, positive). Two unknowns stay open: the post's live status (RR1) and the pay's position against the survey band (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live on the employer's own careers page (RR1); (2) your NMC register entry and driving record show as active and valid (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; 410 staff, four locality hubs | `[grounded]` employer's about page |
| Role | District nursing for housebound adults, small own caseload with senior community nurse support, EPR-recorded | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` posting |
| Market calibration | Survey of 1,240 England community staff nurses, Band 5: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage. The posted band straddles the median; its floor sits below the survey's lower quartile. The official Agenda for Change scale was not retrieved | `[generic]` Wardround 2026 guide |
| Location | Posting says Halifax; you live in Halifax | `[grounded]` posting and your message |
| Unknowns | Whether the post is live; caseload size at start; on-call and out-of-hours; EPR use | — |
| Contradictions | None between the posting and the employer's about page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated in your CV, active, revalidation March 2028. Stated, not checked | `[grounded]` CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as category B. Stated, not checked; expiry not given | `[grounded]` CV | You check your licence record for expiry and endorsements |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse; length of experience is not a gate, so it is graded like any requirement | `[grounded]` CV | none |
| R4 | Clear, timely written records; EPR use | must_have | unclear | low | discovery | CV is silent on records and EPR | `[grounded]` CV silence | Question below |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound assessment carries over; leg-ulcer compression and venous care are not stated. Limit named | `[inferred]` from R5a | Gap G3 |
| R6a | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not stated; catheter work is the nearest evidence | `[grounded]` CV silence | Gap G5 |
| R7 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R8 | Small own caseload | important | adjacent | medium | transferability | Home visits in the discharge-to-assess secondment are the bridge. You have never held your own caseload, and visits in the first week after discharge are not caseload ownership. Limit named | `[inferred]` from the secondment | Question below |
| R9 | Care planning | important | unclear | low | discovery | Only discharge planning is implied, not stated | `[grounded]` CV silence | Gap G6 |
| R10 | End-of-life visits | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Question below |
| R11 | Doppler assessment | preferred | absent | medium | transferability | You confirmed you have never done one. Wound assessment is the nearest adjacency | `[grounded]` your message | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload ownership (R8) | transferability | Secondment home visits; no caseload held | The most likely interview probe | Visit lists you set, escalations you made alone, patients you followed across visits | A visit log or a sanitised caseload sketch | `[inferred]` bridge; `[generic]` that interviewers probe autonomy |
| G2 | Records and EPR (R4) | discovery | Silent | A must-have, and the posting names EPR | Any EPR use, timely entries, handover notes | A sanitised record entry | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b) | transferability | Wound care only | Named in the posting's first duty | Leg-ulcer dressings, compression, reviews | A wound plan or a training record | `[inferred]` |
| G4 | Doppler (R11) | transferability | Never done | Preferred; a training path is possible | ABPI or Doppler training, supervised practice | A course certificate | `[grounded]` your message; the speaker page below suggests Doppler training for new community staff, which is not established as this employer's offer |
| G5 | Continence (R6b) | discovery | Catheter work only | Named in the posting's duties | Continence assessments, pads and products | Any continence assessment record | `[grounded]` CV silence |
| G6 | Care planning and end-of-life (R9, R10) | discovery | Not stated | Both named in the duties | Discharge plans you wrote, end-of-life visits | Any plan or visit note | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post live status not verified | unknown | — | "Join our district nursing team" | The post may be filled or closed | `[generic]` pattern for posts found only through an advert | Is this vacancy live on your careers page, and what is the closing date? | unresolved |
| RR2 | Pay position against the survey band | unknown | — | "£31,050–£37,800 a year plus mileage" | Start pay may sit in the lower half of the survey range | `[generic]` survey band | Where in the band does a new post-holder usually start? | unresolved |
| RR3 | Published pay, named contact, concrete duties | positive_signal | — | "For an informal chat… contact Rhiannon Mabbott" | Scope is defined and the employer is open to a conversation | `[grounded]` posting | How is caseload allocated, and how is senior support arranged for a new community starter? | noted |

Standing entry — employer not established: not triggered. Research attributed the employer to a real entity (established, 410 staff, NHS contract, Calderdale).

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask for the live posting link before applying | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Check your NMC register entry and licence record yourself | R1, R2 | `[grounded]` CV | pending your approval |
| P3 | Lead the CV with the home visits in the secondment, in your own words; name the wound assessment as wound assessment, not leg-ulcer work | R8, R5b | `[inferred]` from your CV | resume_edits_pending_approval |
| P4 | Ask in interview about Doppler or ABPI training for new community staff; do not claim the skill | R11 | `[generic]` pattern for community posts | pending your approval |
| P5 | If you want the CV edit drafted, resume-tailor can do it | R8, R5b | `[grounded]` | pending your approval |

Your National Insurance number isn't needed for this assessment, so I haven't used it.

**Evidence status.** Verified: none yet. Your CV and message are self-report, so every claim sits at `medium` at most.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health community staff nurse band 5 jobs"; read calderbrookhealth.example/about. The guessed careers address returned no page, so the live post could not be confirmed. Moved: the employer is established; RR1 stays open |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change pay scales band 5 2026/27"; it returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide), not the official scale. Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Halifax"; it returned a 2025 forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the scope read, and the Doppler question in P4. Rhiannon's role as hiring manager is not confirmed |

Upgrade menu:
- A visit log or caseload sketch from the secondment → R8 can move to `direct`.
- A leg-ulcer or compression record → R5b moves to `direct`.
- An ABPI or Doppler training certificate → R11 moves off `absent`.
- The live posting link → RR1 closes.
- Your own NMC and DVLA checks → R1 and R2 move from stated to checked.
- An EPR or records example → R4 moves off `unclear`.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

I can save this as a `tuesday-dossier.md` file if you want to keep it.

Questions:
- R4 — Have you written records on an electronic patient record, and how do you keep your notes timely?
- R8 — In the secondment, how many home visits did you make in a typical week, and did you decide your own visit order?
- R10 — Have you done end-of-life visits, or sat with families at home?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.