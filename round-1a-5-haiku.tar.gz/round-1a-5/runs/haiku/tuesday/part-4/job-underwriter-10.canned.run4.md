**Yes, it's worth pursuing, and the company checks out as a real employer. Status: `conditional_go`.** The posting is live on the company's own site, the co-founder is public, and the interview invite is routine. Whether the role suits you depends on two answers only you can give (pay floor and office days) and on how you'd handle being the only designer.

**Hard gates:** none failed; unconfirmed: R1 (pay within €52,000–€60,000), R2 (two office days a week in Galway); candidate constraints not given — checks against them unknown.
**Severe red flags:** none found.
**Conditions for go:** (1) R1: €52,000 meets your floor; (2) R2: two office days a week in Galway work for you; (3) RR2: in the call, they describe concretely who decides on the booking flow and what design support exists.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway; makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` About page |
| Posting | Live on the careers page; pay, hybrid pattern and "first design hire" match your JD | `[grounded]` careers page |
| Scope | Own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Contact route | Email invite with video link, then a WhatsApp message from Ronan. Scheduling by chat is routine. Nothing asks for money, a deposit or bank details | `[grounded]` your message; routine by the module's rules |
| Market calibration | Irish product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posted range sits inside it | `[generic]` Tillerby 2026 survey, n=520, not Galway-specific |
| Footprint | Sparse online presence is normal for a six-person company. The employer is attributable, so the standing "not established" entry does not apply | `[generic]` pattern |
| Unknowns | Equity value; Saoirse's title (About says co-founder, the WhatsApp says CTO) | — |
| Contradictions | None between JD and careers page | `[grounded]` |

## Evidence map

Confidence is capped at `medium` because nothing you've said is inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay €52,000–€60,000 | hard_gate | unclear | medium | hard_gate | No floor given | `[grounded]` posting | Q1 below |
| R2 | Two office days a week in Galway | hard_gate | unclear | medium | hard_gate | You live in Galway; willingness to commute to the office is unstated | `[grounded]` your background | Q2 below |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years, self-reported | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | Own user research | must_have | direct | medium | none | Monthly customer usability sessions | `[grounded]` your background | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Redesigned checkout inside a squad, not as owner of the whole flow | `[inferred]` from checkout work | G1 |
| R8 | Booking-flow knowledge | must_have | adjacent | medium | transferability | Travel-booking checkout is close, not the same domain | `[inferred]` | G2 |
| R9 | First designer, no design team | must_have | adjacent | medium | transferability | Never the only designer; squad experience is the bridge | `[grounded]` your background | G1 |
| R10 | One real project, not a polished deck | important | direct | medium | none | Checkout case study, which Ronan cited | `[grounded]` WhatsApp | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First-designer scope (R7, R9) | transferability | You've shipped inside a squad with a team around you; the CV shows no solo ownership | Ownership is the main objection they will raise | Any project where you set direction or made calls with no one to review them | The checkout case study, with decisions you made marked | `[inferred]` from your background |
| G2 | Booking domain (R8) | transferability | Checkout is close to booking, but not the same flow | The product is booking for schools, not travel | Any booking, scheduling or payment flow you shaped | Checkout case study | `[inferred]` |

Bridge limits: you haven't owned a product area with no design team; you haven't worked on school or activity bookings.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay inside calibrated band | positive_signal | — | "€52,000–€60,000" | Pay is within the typical range for this experience | `[generic]` band; `[grounded]` posted figure | Is this range the budgeted figure for the hire? | noted |
| RR2 | Scope without a design team | risk_signal | medium | "You would be our first designer" | You may own the booking flow without design review or research support | `[inferred]` from "first designer" against silence on design team | Who decides design on the booking flow, and what research budget and tooling does this role get? | unresolved |
| RR3 | Equity unvalued | unknown | — | "0.5–1% equity" | Value depends on share class, vesting and dilution, none stated | `[inferred]` from the posting | What share class, vesting schedule and cap table does the 0.5–1% refer to? | unresolved |
| RR4 | Company and posting check out | positive_signal | — | Careers page and About page | Real, live employer with consistent details | `[grounded]` fetched pages | Who on the team would I work with day to day? | noted |
| RR5 | Saoirse's title | unknown | — | About: co-founder; WhatsApp: CTO | Title may be informal, or it may have changed | `[grounded]` both sources | What is your role and what does it own? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, decide your pay floor and your office days | R1, R2 gate on your answer | `[grounded]` gap rows | pending your approval |
| P2 | Bring the checkout case study and mark the decisions you made versus the squad's | G1, R9 | `[grounded]` R7 | pending your approval |
| P3 | Ask RR2, RR3 and RR5 on the call | They decide the conditions | `[grounded]` register | pending your approval |

Rows are proposals; you approve what you use. The sole-designer answer should be honest: "I've never been the only designer, and here's what I did on the squad." Don't claim solo ownership you haven't had.

## Evidence status

Verified: none yet. Your background is self-report until we inspect something.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea-kayak surf schools Galway" and "Fernquay Product Designer job Galway careers". Fetched About Fernquay (fernquay.example/about) and Product Designer — Fernquay careers (fernquay.example/careers/product-designer). Employer attributable; posting live and consistent with JD |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience Galway", which returned Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe co-founder Fernquay", which returned a public profile (linkedin.example/in/ronan-kehoe): co-founder and CEO. Confirms the WhatsApp sender matches a named co-founder; nothing else was checked |

## Upgrade menu

- The checkout case study as an inspectable file or link → R7 and R10 can move from `medium` toward `high`.
- The offer's equity terms → RR3 closes.
- The call's answers on who decides design (RR2) and Saoirse's role (RR5) → the scope and conditions update.
- Any deeper research on Fernquay (funding, past hires, employee reports; up to 5 more searches and 2 more fetches) — say the word and I'll run it.

If you want, I can write this up as `tuesday-dossier.md` to keep.

**Questions**

Q1 (R1) — Does €52,000 meet your base-salary floor, or is it below it?

Q2 (R2) — Can you work from the Galway office two days a week on a regular basis?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.