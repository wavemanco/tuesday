**No, don't go ahead.** This job is very likely a scam, and I can't establish the firm from here. Send nothing: no money, no cheque, no bank, PPS or passport details.

**Decision snapshot**

- **Status: `no_go`.** Four confirmed severe red flags, below.
- **Fit ledger.**
  - `hard_gate`: unclear: R1 (pay floor of €30,000 a year, your own constraint)
  - `must_have`: direct: R2 (confident with spreadsheets); adjacent: R3 (customer order handling)
  - `important`: unclear: R4 (good written English)
  - R3 is a credible bridge, its limit named. R2 is confirmed and has a limited inspectable artifact. Your fit is not the problem; the requests are.
- **Hard gates:** none failed; unconfirmed: R1 (pay floor: the posting says "up to €26 an hour" plus commission, no guaranteed figure).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **Opportunity ledger.** The requests in these messages are the decisive signals (RR1 to RR4). The employer check is unresolved (RR5).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Stated pay | Up to €26 an hour plus commission | `[grounded]` posting |
| Hours | 15–30 a week | `[grounded]` posting |
| Pay arithmetic | At €26 an hour, 15–30 hours a week is about €20,300–€40,600 a year before commission. Reaching €30,000 at that rate needs about 22 hours a week. "Up to" makes these ceilings. | `[inferred]` arithmetic from the posting |
| Process | Telegram only; no calls or video interviews | `[grounded]` posting and messages |
| Employer | Not established from search (see evidence status) | `[grounded]` search results |
| Unknowns | Contract type, commission basis, any written offer | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay floor of €30,000 a year | hard_gate | unclear | high | hard_gate | Posting gives "up to €26/hour" plus commission; no guaranteed figure | `[grounded]` posting; your stated constraint | Pay figure in writing from the employer, via its own website's contacts |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | Weekly Excel tracker you keep; not inspected | `[grounded]` your statement | None |
| R3 | Customer order handling | must_have | adjacent | medium | transferability | Three years of parcel-courier customer service, about 60 Zendesk tickets a day. Limit: no order-processing or fulfilment work recorded | `[inferred]` adjacency from courier customer service | Name the order-handling work you did, if any |
| R4 | Good written English | important | unclear | low | discovery | Zendesk ticket work implies written English; nothing inspected | `[grounded]` your background | None yet |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | The request asks you to pay for your own kit before any job starts | `[generic]` pattern for requests like this | Does your company ask new starters to pay for equipment before their first wage? | confirmed |
| RR2 | Cheque deposit and forwarding | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | Cheque deposits with onward transfers are a known way to lose money | `[generic]` pattern for requests like this | Does your company ever ask staff to lodge cheques and forward money to a third party? | confirmed |
| RR3 | Bank, PPS and passport details before interview | red_flag | high | "before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | Identity and bank details are requested before any written offer | `[generic]` pattern for requests like this | Do you collect bank, PPS or passport details before an interview or a written offer? | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer happen only in chat | `[grounded]` messages | Do you hire through calls or video interviews with a named interviewer? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

**Hold.** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers", "Velloway Logistics Remote Order Processing Coordinator" and "Velloway Logistics"; all three returned no results. Employer not established (RR5). No domain came from the results, so no page was fetched. |
| 2. Role-family sweep | skipped | The posting's own stated pay, set against your €30,000 floor, already gives the pay read. A market band could not change the `no_go`, which rests on RR1 to RR4. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send no payment, no cheque and no bank, PPS or passport details, and paste none of them into the chat | RR1 to RR3 | `[grounded]` the requests in the messages | Your decision |
| P2 | Check the posting through the employer's own website contacts, not the chat or the email address the messages gave | RR5 and the hold | `[grounded]` the hold | Your decision |
| P3 | If the employer confirms the role, ask for the pay in writing | R1 | `[grounded]` R1 | Your decision |

**Dossier offer.** At the natural end of this, I can write the whole assessment up as a `tuesday-dossier.md` for you to keep.

**Upgrade menu**

- A live posting on the employer's own careers page, with the contact details it lists → RR5 can move. The `no_go` stays, because RR1 to RR4 are confirmed.
- A written offer from the employer's own domain, naming the role, the pay and a start date, with a named interviewer you can reach through its website → R1 can be assessed. RR1 to RR3 would still need to be withdrawn.
- A deeper company check (up to 5 more searches and 2 more fetches). It would deepen the employer check and would not reverse the call.

**Question**

RR5 — can you find this role on the company's own careers page and tell me whether it's listed there?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.