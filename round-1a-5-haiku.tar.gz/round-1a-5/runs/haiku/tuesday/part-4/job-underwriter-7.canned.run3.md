**Yes, worth applying, on conditions. Status: `conditional_go`.** Aoife meets both essential credential gates and most of the essential clinical list. The real gaps are holding a caseload and Doppler assessment, and the posting itself could not be confirmed as live.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4a, R5a, R6 · adjacent: R4b · unclear: R5b, R9
- `important`: adjacent: R8 · unclear: R7
- `preferred`: absent: R10

R4b (leg-ulcer work) is adjacent to ward wound care, with its limit named. R8 (own caseload) is adjacent through discharge visits; caseload holding has never been done. R9 (written records) and R5b (continence) are unclear because the CV is silent on both. R10 (Doppler) is absent.

**Opportunity ledger.** The employer exists as described and the pay band sits inside the sector survey's range (RR2, positive). Open: whether this post is still advertised (RR1), whether Doppler training is provided (RR3), and the caseload size at start (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the post is confirmed open (RR1); (2) Doppler training is confirmed in post or accepted as a learning need (RR3); (3) any caseload claim is framed as adjacent, never as held.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract across Calderdale, founded 2015, 410 staff, four locality hubs | `[grounded]` the employer's about page (search snippet) |
| Mandate | Own small caseload of housebound adults, supported by a senior community nurse; wound, catheter, continence, insulin, end-of-life, care planning, EPR records | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` posting |
| Market calibration | Band 5 community staff nurse, 2026 survey (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage | `[generic]` role-family sweep; this is a pattern, not this employer's offer |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead, leads the Halifax district nursing team | `[grounded]` posting and a public speaker page |
| Unknowns | Whether the post is open; caseload size; supervision and cover; Doppler training; continence and end-of-life volume | — |
| Contradictions | None found between the posting and the employer's about page. The vacancy itself was not found. | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Stated as active with revalidation due March 2028; registration not checked by me | `[grounded]` CV, stated not checked | Aoife checks the NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, stated; the licence itself is not inspected | `[grounded]` CV, stated | Aoife confirms status on the licence |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds on a ward; wound care in discharge visits | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care transfers. No leg-ulcer work is claimed, so the claim is limited to the general wound work | `[inferred]` from R4a, limit named | see G1 |
| R5a | Catheter care | must_have | direct | medium | none | Stated on the ward | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | none | discovery | Not in the CV | `[grounded]` CV silence | see G2 |
| R6 | Insulin administration and care planning | must_have | direct | medium | none | Insulin stated; care planning is not separately stated | `[grounded]` CV | none |
| R7 | End-of-life visits | important | unclear | none | discovery | Not in the CV | `[grounded]` CV silence | see questions |
| R8 | Holding a caseload | important | adjacent | medium | transferability | Never held a caseload. Discharge-to-assess home visits in the first week are the nearest work | `[grounded]` CV, her statement that the caseload was never held | see G3 |
| R9 | Clear, timely written records on the EPR | must_have | unclear | none | discovery | CV silent on records and the EPR system | `[grounded]` CV silence | see G2 |
| R10 | Doppler assessment (desirable) | preferred | absent | high | capability | Her own statement: never done | `[grounded]` her statement | closure path in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4b, must_have) | transferability | General wound care on a ward; no leg-ulcer work named | A must-have row at adjacent; a specific example narrows the objection | Any leg-ulcer dressing or compression work, on the ward or in discharge visits | A case note or care-plan extract, anonymised | `[inferred]` bridge from R4a; `[generic]` that a community panel will ask for leg-ulcer specifics |
| G2 | Records and continence (R9, R5b) | discovery | Silent on the EPR and on continence | Both are must-haves with no evidence | The ward or discharge EPR, including direct entries; continence assessments | Screenshot of a record, a training certificate | `[grounded]` CV silence |
| G3 | Caseload holding (R8, important) | transferability | Discharge visits are the nearest work; no caseload held | Bridge only; the limit must be stated | First-week discharge visits and the plans made for them | Discharge plan example, anonymised | `[inferred]` bridge; limit is hers and it is named |
| G4 | Doppler assessment (R10, preferred) | capability | Never done | A closure path rather than a blocker, since it is preferred | Training in leg-ulcer assessment or the employer's in-post training | Course or training record | `[inferred]` from the posting's desirable line and a 2025 speaker page on Doppler training for staff new to community work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5" | The advert may be closed, or the careers page may have moved; the vacancy was not found | `[inferred]` from the failed careers fetch and no search hit | Is this post open now, and where is it advertised on your careers site? | unresolved |
| RR2 | Pay band and mileage | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The band covers the survey's interquartile range, and mileage is common in this sector | `[grounded]` posting; `[generic]` survey | Where in the band does a new Band 5 start, and how is mileage paid? | noted |
| RR3 | Doppler training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training may be provided in post; the speaker page suggests the employer has run it | `[inferred]` from the desirable line and the speaker page | Is Doppler training provided in post, and how soon? | unresolved |
| RR4 | Caseload size and support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The first caseload may be large or the supervision thin | `[inferred]` from the word "small" against no stated number | What size is the caseload at start, and how is supervision and cover arranged? | unresolved |

Severe red flags: none. The posting asks for nothing from the candidate before an offer, so no request-type entry applies. The standing "employer not established" entry does not apply, because the employer is established.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV's community-facing section with the discharge-to-assess home visits, stated as they happened | Closest match to home-based work | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Describe caseload work only as "never held; discharge visits are the closest" | Avoids a claim that the caseload was held | `[grounded]` her statement | `resume_edits_pending_approval` |
| Q1 | Ask Rhiannon Mabbott RR1, RR3 and RR4 in the informal chat | The advert's contact is the natural route to the open questions | `[grounded]` posting | pending your approval |
| Q2 | Before applying, confirm the post on the employer's own careers page | Verifies RR1 without relying on the chat | `[inferred]` | pending your approval |

Every row above is a proposal. The first two change the CV and need your approval before anything is sent.

## Evidence status

Verified: none yet. The CV claims are self-report, so they remain leads until confirmed.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" (about page, calderbrookhealth.example/about, from the result snippet) and "Community Staff Nurse Band 5 Calderbrook Community Health vacancy"; fetched calderbrookhealth.example/careers, which returned no page. Moved: the employer is established (RR2 context); the posting is not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 Halifax community nurse salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the Doppler training lead (RR3); public professional footprint only |

## Upgrade menu

- The live posting's URL or the employer's careers page → RR1 closes.
- An anonymised leg-ulcer example, or any leg-ulcer work → R4b moves from adjacent toward direct.
- Continence or end-of-life experience → R5b and R7 move.
- Records on the ward or discharge EPR → R9 moves from unclear.
- Your pay floor and mileage needs → the hard-gate check against constraints becomes possible.
- A deeper company pass (funding, leadership changes, staff reports): up to 5 more searches and 2 more fetches. Say the word and it runs.

Do you want me to save this as `tuesday-dossier.md`?

Questions, tagged to their gap rows:

- G1: Have you done any leg-ulcer dressings or compression work, on the ward or in discharge visits? If so, what did you do, and was it your patient?
- G2: Which electronic record system did you use on the ward and in discharge-to-assess, and did you document visits on it directly?
- G2: Have you done continence assessments or end-of-life visits, even as part of a team?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.