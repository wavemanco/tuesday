**Decision snapshot**

**Duinvaart Cold Chain, Operations Analyst: worth applying. Status: `conditional_go`.** Your on-time delivery dashboard, daily SQL and Power BI, and depot-manager work match most of the posting. The temperature-compliance side is new to you.

**Kroonhaven Foods, Supply Planner: not worth your time as posted. Status: `no_go`.** Its two planning must-haves, 3+ years of FMCG planning and running a capacity-versus-forecast plan, are ones you have said you have never done. Fluent Dutch is also a must-have, and you have conversational Dutch.

**Duinvaart fit ledger**

- `hard_gate`: unconfirmed: D1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: D2, D3, D4, D5
- `important`: adjacent: D7 (work with depot managers on route changes); absent: D6 (temperature compliance across refrigerated fleet)
- `preferred`: adjacent: D8 (Dutch a plus)

D5 is direct, but the CV buries it. D7 is a bridge with its limit named. D6 has no cold-chain evidence in what you sent.

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Rotterdam three days a week is workable for you (D1); (2) you can state your own part in the on-time dashboard and route review (D5, D7); (3) the employer's live posting is confirmed on its own site, because I could not check that it exists as described; (4) cold-chain work is framed as adjacent learning, never as cold-chain experience (D6)

**Kroonhaven fit ledger**

- `hard_gate`: unconfirmed: K1 (On-site in Utrecht)
- `must_have`: absent: K2 (3+ yrs supply or demand planning in FMCG), K3 (own 13-week supply plan, balance capacity against forecast), K6 (SAP IBP or similar planning system); adjacent: K4 (run weekly S&OP meeting), K7 (fluent Dutch); unclear: K5 (advanced Excel)

K2 and K3 are absent with no closure you can make before applying. K4 has a real but partial bridge. K6 and K5 are unknown rather than missing, so one question covers them.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** real planning or forecasting work, even informal, moves K2 and K3 from absent to discovery and could reopen this as a hold. Or the employer would need to drop the 3-year bar and accept conversational Dutch.

**Opportunity ledger.** Duinvaart's posting is concrete and realistic in scope (RR3 positive, RR1 unknown); its salary is withheld (RR2). Kroonhaven's scope is clear (RR5 positive), and its salary is also withheld (RR4). Neither posting's pay is stated, so pay is unverified for both.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: scope | Track on-time delivery and temperature compliance; weekly dashboards; depot-manager route changes | `[grounded]` posting |
| Kroonhaven: scope | 13-week plan for chilled ready meals; capacity against forecast; weekly S&OP | `[grounded]` posting |
| Market calibration | Not run; both salary searches were refused | — |
| Contradictions | None found within the postings | `[grounded]` |

**Duinvaart evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, 3 days a week, Rotterdam office | hard_gate | unclear | none | hard_gate | Your schedule and location limits were not in what you sent | `[grounded]` posting | Q1 |
| D2 | 2+ yrs logistics or ops analysis | must_have | direct | medium | none | 4 yrs as ops analyst, parcel carrier; self-reported, no artifact yet | `[grounded]` your background | upgrade: dashboard screenshot |
| D3 | Strong SQL | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` | none |
| D5 | Track on-time delivery | must_have | direct | medium | presentation | The depot managers' on-time dashboard is your closest match, but your part in it is unstated | `[grounded]` | E1 (pending approval) |
| D6 | Temperature compliance, refrigerated fleet | important | absent | none | transferability | Dashboard skills carry over; cold-chain data and rules don't | `[inferred]` background vs posting | G1 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the route-performance review; not shown that you proposed or made changes | `[inferred]` | Q2 |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` | none |

**Kroonhaven evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Constraints not given | `[grounded]` posting | Q1 |
| K2 | 3+ yrs FMCG supply or demand planning | must_have | absent | none | capability | You have never worked in planning; route analytics is not planning | `[grounded]` your statement | G3 |
| K3 | Own 13-week plan, balance capacity vs forecast | must_have | absent | none | capability | No capacity or forecast work stated | `[inferred]` | G3 |
| K4 | Run weekly S&OP meeting | must_have | adjacent | medium | transferability | Weekly review cadence; no supply or production decisions | `[inferred]` | limit named |
| K5 | Advanced Excel | must_have | unclear | none | discovery | Not stated | — | Q3 |
| K6 | SAP IBP or similar planning system | must_have | absent | none | discovery | Not stated | — | Q3 |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, below the fluent bar | `[grounded]` | G4 |

**Gap recovery queue** (no questions here; the questions are in the closing block)

- **G1 (D6, transferability):** Closure path: any temperature-log or cold-chain data you have handled. Limit: you have no cold-chain rules experience.
- **G2 (D7, transferability):** Closure path: an example of a route change you proposed or made. Without one, carry it as a limit.
- **G3 (K2, K3, capability):** No closure before applying. A demand-planning or analyst role at an FMCG company would be a scoped-down target.
- **G4 (K7, transferability):** Closure path: a formal Dutch level test and months of study. Not closable for this application.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Concrete scope and outputs named | positive_signal | — | "track on-time delivery and temperature compliance" | Success is measurable and the role is defined | `[grounded]` posting | Who owns the temperature data today? | noted |
| RR2 | Salary withheld (Duinvaart) | unknown | — | (not stated) | Pay may sit below the band, or may not be published | `[inferred]` from silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | This role may propose route changes rather than decide them | `[inferred]` | Does this role approve route changes itself, or propose them to depot managers? | unresolved |
| RR4 | Salary withheld (Kroonhaven) | unknown | — | (not stated) | As RR2 | `[inferred]` | What salary is budgeted for this post? | unresolved |
| RR5 | Clear mandate, 13-week plan and S&OP named | positive_signal | — | "own the 13-week supply plan" | Defined scope with clear ownership | `[grounded]` posting | Which decisions does this role make alone? | noted |

Standing check: I could not confirm that either employer exists as described or that either posting is live. The search attempts were refused, so this is unverified, not a finding against either company. It is why Duinvaart is capped at `conditional_go`.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead Duinvaart's CV with: "the on-time delivery dashboard depot managers use", and state your part in it if you built or maintained it. If you did not, say what you did (query, report or review work). | D5 | `[grounded]` your sentence | pending your approval (`resume_edits_pending_approval`) |
| A1 | Apply to Duinvaart only after you confirm the live posting on its own careers page | Existence check (standing) | `[grounded]` | pending your approval |
| A2 | Do not apply to Kroonhaven as posted | K2, K3, K7 | `[grounded]` | pending your approval |

**Evidence status**

Verified: none yet. Your claims are self-reported; no artifact has been inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (Duinvaart and Kroonhaven). Would have moved: whether each employer exists as described, and whether each posting is live. |
| 2. Role-family sweep | unavailable | Both salary searches were refused. Would have moved: the market band for each title, labelled `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed. |

**Upgrade menu**

- Your location and right to work in the Netherlands → resolves D1 and K1, the gate both postings depend on
- Live posting links and each employer's own careers page → the existence check; clears the cap on Duinvaart
- Any temperature or cold-chain data you have handled → D6 moves from absent to adjacent, which could move Duinvaart's conditions
- A screenshot of the on-time dashboard, with client names removed → D2 to D5 from medium to high
- Web search, once permitted → the company and pay-band checks, up to 5 searches and 2 fetches; say the word and I run them

If you want the full analysis kept as a file, I can save it as `tuesday-dossier.md`.

**Questions**

Q1 (D1, K1): Can you commit to three days a week in the Rotterdam office and to on-site work in Utrecht, and do you have the right to work in the Netherlands without sponsorship?

Q2 (D7): Did you propose or make route changes with depot managers, or did you review performance and pass the findings on?

Q3 (K5, K6): Have you ever built or maintained a forecast or supply plan, even informally in a spreadsheet, or used a planning tool such as SAP IBP?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.