## Decision: no-go as posted. Don't send anything.

**Fit (candidate side, confidence bands):** Your background matches the stated requirements well. Customer service in a courier setting, Zendesk, training new starters and Excel tracking all map to the role. Confidence is high for those four, since they come from your own account.

**Opportunity (separate ledger):** The posting and the hiring process have several red flags, all quoted from what you've shared:

- **Upfront personal data.** Before any interview, the sender asked for your IBAN, PPS number and a passport photo. A written offer from an employer would normally come after that step, not before.
- **Payment demanded from you.** You were asked to pay €349 to an "equipment partner" for a laptop and headset, refunded later. Employers don't normally charge candidates for work equipment.
- **The cheque instruction.** You were told to deposit a €2,850 cheque, keep €350, and forward the rest to a third party. Forwarding money from a cheque before it clears is the core of the overpayment-cheque pattern, and that is where candidates lose money: the cheque is later returned, and the money sent out is gone.
- **Hiring wholly by chat.** The whole process runs on Telegram, with no call, video or verifiable company contact.

I'm not making a claim about who this sender is. The terms are the problem, and they make the posting unsafe to continue with.

**Pay vs. your floor:** The posting says "up to €26/hr", with commission of unstated size. At €26/hr, 15–30 hours a week comes to roughly €20k–€40k a year before commission, and the €26 is a ceiling, not a guarantee. Your €30k floor would need about 23 hours a week at the top rate. This is a hard-gate-style mismatch on pay, separate from the red flags. Posting figures are `[grounded]`; the arithmetic is mine.

**What to do now:**
- Don't send your IBAN, PPS number, passport photo or any payment, and don't deposit any cheque they send.
- If you already shared ID or bank details, contact your bank and consider reporting it to your national police (Garda) or fraud reporting channel.
- Keep the Telegram messages as a record.

**Research tier: L0, no searches.** The decision doesn't depend on research, since the red flags are in the messages themselves. I haven't checked whether Velloway Logistics exists.

**Dossier offer:** If you'd like, I can write a `tuesday-dossier.md` summary of this assessment for your records.

**Upgrade menu** (what would change the picture):
- A link to the live posting on the company's own careers page, which would show whether the role is real.
- The written pay terms, including how commission is calculated.
- Research at L1 (up to 5 searches and 2 page fetches) to check the company and typical pay for this role in Ireland.

**Questions:**
1. Do you have a link to the posting on the company's own website?
2. Do you want me to run the L1 research check on the company and role pay?

Reply with your answers, or "skip" to leave either one open.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.