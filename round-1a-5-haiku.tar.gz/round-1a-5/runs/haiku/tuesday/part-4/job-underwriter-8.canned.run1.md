**No, don't go ahead, and send nothing yet. Status: `no_go`.** Three requests in these messages are very likely a scam: paying €349 for equipment, depositing the cheque, and sending most of its value on to the "equipment partner." The bank, PPS and passport request, made before any offer, is also a red flag.

**Decision snapshot**

- **Fit ledger:** Your background fits this role on its own terms. The fit side is not what is stopping this.
  - `must_have` — direct: R1 · adjacent: R2
  - `hard_gate` — unclear: R3 (pay floor against the posting's hourly rate)
- **Opportunity ledger:** The posting's own terms are the problem. Confirmed severe red flags are RR1 to RR4, and the employer could not be found (RR5).
- **Hard gates:** none failed; unconfirmed: R3 (€30k+ pay floor; posting gives "up to €26/hr", no base salary).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer confirming through its own website's contact details that these requests are genuine and no payment is needed, and an offer arriving from its own domain.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; no public footprint found | `[grounded]` search returned nothing |
| Pay | "Up to €26/hr plus commission." At 15–30 hrs a week that is about €20,300–€40,600 a year before commission, and only if hours are fixed | `[inferred]` arithmetic on the posting |
| Market band | Pennoral 2026 Ireland guide: median base €31,200, IQR €28,400–€34,100 for coordinator roles (salaried only) | `[generic]` role-family sweep |
| Process | Entirely on Telegram, no calls or video, offer by chat | `[grounded]` posting and messages |

**Evidence map (abbreviated)**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Attention to detail, spreadsheets | must_have | direct | medium | none | Your Excel tracker and training of starters, stated in prose, not inspected | `[grounded]` your intake | none |
| R2 | Order processing, written English | must_have | adjacent | medium | transferability | Parcel-courier ticket work carries over; no order-processing role or system named | `[inferred]` from your background | none |
| R3 | Pay at your €30k+ floor | hard_gate | unclear | high | hard_gate | Your floor is your own stated constraint; the posting withholds base pay | `[grounded]` your constraint; `[grounded]` posting | ask for the base salary in writing |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "pay €349 by bank transfer to our equipment partner" | The equipment charge would be the cost to you, with a refund promised later | `[grounded]` the message | Does Velloway require candidates to pay for equipment? | confirmed |
| RR2 | Bank, PPS and passport details before an offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Personal and ID data requested before any written offer | `[grounded]` the message | Does Velloway collect bank, PPS or passport details before a written offer? | confirmed |
| RR3 | Cheque deposit and onward transfer | red_flag | high | "lodge it to your account, keep €350 … transfer the rest to our equipment partner" | Depositing a cheque and sending part of it on before it clears is a known pattern | `[generic]` pattern of cheque-overpayment requests | Does Velloway send cheques for candidates to deposit and forward? | confirmed |
| RR4 | Whole hiring process run by chat | red_flag | high | "Our whole hiring process runs on Telegram" | Interview and offer happen only in chat, with no independent place to check them | `[grounded]` posting and messages | Can you confirm the interview and offer through your own careers page and email domain? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Possible reasons, none ranked as likely: too new or small to have a footprint; a stale or aggregated posting; or the posting may not come from a real hiring employer | `[generic]` pattern for employers of this size | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

**Hold, and your call.** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan (proposed, pending your approval)**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't pay, deposit a cheque, or send your IBAN, PPS or passport to these messages | RR1 to RR4 | `[grounded]` | pending your approval |
| A2 | Keep the messages as a record | Useful if you check with the employer or report it | `[generic]` | pending your approval |
| A3 | Find the employer's real contacts on its own website and ask RR1 to RR4 there | The only route that doesn't go through the sender | `[grounded]` RR table | pending your approval |
| A4 | If Velloway answers and the role checks out, ask for base pay and hours in writing before any step | R3 and RR4 | `[grounded]` | pending your approval |

**Evidence status:** Verified: none yet. Your background is your own account and is unconfirmed.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers Remote Order Processing Coordinator"; both returned no results. Employer not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland"; Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration |
| 3. Hiring manager's public footprint | n/a | No person's name given; @VellowayHiring is a handle |

**Dossier offer:** If you'd like, I can write this assessment to a `tuesday-dossier.md` file for your records.

**Upgrade menu**
- The employer's own careers page, with a recruiter's email on its domain → clears RR5; RR1 to RR4 still need the employer's own answer.
- Base pay and hours in writing → closes R3 and shows whether €26/hr can reach €30k.
- A deeper check on Velloway (leadership, past hiring, reports from other candidates; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.