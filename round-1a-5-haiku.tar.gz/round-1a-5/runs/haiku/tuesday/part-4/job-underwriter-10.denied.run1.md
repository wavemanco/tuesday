**Worth taking the call: `conditional_go`.** Your fit is strong on Figma, user research and working with engineers. The open questions are whether you're comfortable as the only designer and whether the booking-flow ownership holds up. Nothing in the posting or the WhatsApp message asks for money or bank details, and scheduling a video call over WhatsApp is routine. I could not verify Fernquay as an employer, though. My web searches were refused, so the company is unchecked, not failed.

### Decision snapshot

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Fit ledger**
  - `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
  - `must_have` — direct: R3, R4, R5 · adjacent: R6 (Owns booking flow end to end) · absent: R7 (Sole designer, no design peers)
  - `important` — direct: R8 (Works directly with engineers)
  - R6 — adjacent, with its limit named: checkout, not end to end; R7 — absent, the first-designer condition; R2 — needs your floor to read.
- **Opportunity ledger:** No severe red flags. Decision rights (RR1) and equity terms (RR3) are unstated. The employer is unchecked (RR2, medium). The posting does name its scope, reporting line and CTO (RR4).
- **Severe red flags:** none found.
- **What would change this:** Conditions for go: RR2 verifies (the role is on Fernquay's own careers page and the invite comes from a Fernquay address); your salary floor sits inside €52,000–€60,000; you're comfortable as the sole designer.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools; you would be the first designer | `[grounded]` posting text, not checked externally |
| People | Works most closely with co-founder Ronan Kehoe; CTO Saoirse is in the interview | `[grounded]` posting and WhatsApp message |
| Scope | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run; the salary search was refused, so there is no band to compare against | — |
| Scope read | A defined remit, but one designer with no design peer at a six-person company | `[inferred]` from headcount and "first designer" |
| Unknowns | Who decides booking-flow priorities; equity instrument and terms; your floor; sender of the calendar invite | — |
| Contradictions | None found in the posting text; no external page to compare | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from Galway, hybrid two days a week | hard_gate | direct | medium | none | You moved back to Galway last year. Your own statement, nothing to inspect | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given, so the fit cannot be read | `[grounded]` posting | Q2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; CV-level, not inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no file yet to inspect | `[grounded]` your background | none |
| R5 | Runs own user research | must_have | direct | medium | none | Monthly usability sessions with customers; method matches. Audience differs: travel-booking customers, not school owners | `[grounded]` your background | none |
| R6 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of booking, inside a squad of four engineers. End-to-end ownership is not shown | `[inferred]` adjacency from the checkout work | Q3 |
| R7 | Works as the sole designer, with no design peer | must_have | absent | medium | discovery | You have never been the only designer anywhere; this is your own statement | `[grounded]` your statement | Q1 |
| R8 | Works directly with engineers | important | direct | medium | none | Squad of four engineers | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R6, must_have) | transferability | Checkout redesign inside a squad, not the whole flow | This is the core of the job and the strongest bridge | Booking decisions beyond checkout: availability, cancellations, payment failure, group bookings | Your checkout case study | `[inferred]` bridge from the checkout work; `[generic]` that interviewers test this line |
| G2 | Sole designer (R7, must_have) | discovery | Team experience only, no solo work | Decides whether the role fits | Side projects, freelance work, or any product you designed alone | Any project you led alone | `[grounded]` your statement |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights over priorities not stated | unknown | — | "own the booking flow end to end" | You may own the flow's design without deciding what ships first | `[inferred]` from scope against silence on decision rights | Who decides which booking-flow changes ship, and how much time goes to research before build? | unresolved |
| RR2 | Employer not yet established | risk_signal | medium | "six people in Galway making booking software" | Research did not run, and your own search found little. Possible reasons: too new or small for a footprint, a stale posting, or a posting not from the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Fernquay's own careers page, and who would I be interviewing with? | unresolved |
| RR3 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The instrument, vesting and exercise terms are missing, so the equity's value can't be read | `[inferred]` from posting silence on terms | Is the equity options or shares, and what are the vesting and exercise terms? | unresolved |
| RR4 | Scope, reporting line and CTO named | positive_signal | — | "works most closely with our co-founder, Ronan Kehoe" | A named reporting line and a named CTO in the loop suggest a defined scope | `[grounded]` posting and WhatsApp message; `[inferred]` from the named people | What would a good first six months on the booking flow look like? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before replying, check the role on Fernquay's own site, and check the invite's sender address | RR2 | `[grounded]` posting | yours to do |
| P2 | Decide your salary floor before the call | R2 | `[grounded]` posting | yours to do |
| P3 | Prepare the checkout case study: name what you decided and what the squad decided; don't present it as end-to-end booking | R6, G1 | `[grounded]` your background | proposed |
| P4 | Ask RR1 and RR3 verbatim on the call | Register doubles as interview prep | `[grounded]` register | proposed |
| P5 | Reply to Ronan confirming the time | Outreach text | `[grounded]` WhatsApp message | pending your approval |

### Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay and its careers page were refused by a permission prompt, so no result came back. Would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | The salary and scope search was refused. Would have moved the market band for €52,000–€60,000 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, but no search was sent. Would have moved the positioning for that reader |

I can save this as `tuesday-dossier.md`, with the full tables and the JSON envelope, if you want a file to keep.

### Upgrade menu

- Grant web search and I'll rerun the three L1 targets (up to 5 searches, 2 fetches). That would settle RR2 and check the salary band.
- Fernquay's live posting on its own careers page: closes RR2.
- The calendar invite's sender domain (domain only): shows whether it comes from a Fernquay address. This is a check for you, not a verdict.
- Your salary floor: resolves R2.
- The checkout case study, as a link or screenshot: raises the evidence behind R5 and R6.
- Deeper company research (funding, leadership, past candidate reports; up to 5 more searches and 2 more fetches). I'm offering it once; say the word if the first pass works.

Q1 — Have you ever been the only designer on a team? If not, how would you get design critique on your own work? (R7)
Q2 — What is your salary floor for this role? (R2)
Q3 — In your checkout redesign, which decisions did you make yourself, and which did the squad make? (R6)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.