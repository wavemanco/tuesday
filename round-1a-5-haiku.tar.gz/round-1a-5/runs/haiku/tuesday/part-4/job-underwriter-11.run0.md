**1. Operations Analyst, Duinvaart Cold Chain (Rotterdam): worth applying, if the Rotterdam office days work.** `conditional_go`

**Fit ledger**
- `hard_gate`: unclear: R1 (three days a week in the Rotterdam office)
- `must_have`: direct: R2 (2+ years in logistics or operations analysis), R3 (strong SQL), R4 (Power BI or Tableau)
- `important`: direct: R5 (on-time delivery tracking), R7 (weekly dashboards, route work with depot managers); unclear: R6 (temperature compliance across the refrigerated fleet)
- `preferred`: adjacent: R8 (Dutch)

R2, R3 and R4 are your three must-haves, all covered by your own account at `medium`. R6 is the one responsibility your background doesn't touch. R1 is the gate to confirm first.

**Opportunity ledger.** The scope is concrete: a named fleet, named outputs, named tools (RR1, positive). Open: pay isn't stated (RR2), it's unclear whether this role decides route changes or advises on them (RR3), and the employer is unverified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 confirmed workable; (2) RR4 cleared on Duinvaart's own careers page; (3) RR3 answered in your first interview.
- **What would change it:** a no on R1 stops it. R6 being open doesn't stop it by itself, because the row is `important`, not `must_have`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Three office days a week, Rotterdam | hard_gate | unclear | none | hard_gate | Your constraint isn't stated, so the posting's term can't be checked | `[inferred]` from posting | Question 1 |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use, your statement; no artifact yet | `[grounded]` your background | Upgrade menu |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | none |
| R5 | Track on-time delivery | important | direct | medium | none | The on-time dashboard depot managers used | `[grounded]` your background | none |
| R6 | Temperature compliance, refrigerated fleet | important | unclear | low | discovery | Nothing in your background mentions temperature or cold chain | `[inferred]` from silence | Question 2 |
| R7 | Weekly dashboards; route changes with depot managers | important | direct | medium | none | Ran the weekly route-performance review | `[grounded]` your background | none |
| R8 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your statement | Question 3 |

**Risk register**

| # | Signal | Class | Source quote | Hypothesis | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Concrete scope | positive_signal | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Outputs are specific, so you'd know what you're judged on. `[inferred]` from posting specificity | Which of these outputs is judged first in the first 90 days? | noted |
| RR2 | Pay not stated | unknown | (no pay line) | Could be a publishing choice, not a signal. `[inferred]` from silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Route-change authority | unknown | "work with depot managers on route changes" | "Work with" may mean advise, or may mean decide. `[inferred]` from the verb | When a route change is proposed, who makes the final call? | unresolved |
| RR4 | Employer unverified | unknown | "Duinvaart Cold Chain, Rotterdam" | Not checked in this run because search was refused. This is not a finding about the employer | Can you point me to this role on your careers page, and who would I interview with? | unresolved |

**Application plan (pending your approval)**
- P1: Lead with the on-time dashboard depot managers used (R5, R7). `[grounded]` your background. Pending your approval; I need your CV text to draft the wording.
- P2: Before applying, check the posting on Duinvaart's own careers page (RR4).

---

**2. Supply Planner, Kroonhaven Foods (Utrecht): not worth your time now.** `no_go`

The posting is clear. The gap is the core of the job.

**Fit ledger**
- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: adjacent: R2 (3+ years of supply or demand planning in FMCG), R5 (weekly S&OP meeting), R6 (fluent Dutch); unclear: R3 (advanced Excel), R4 (SAP IBP or a similar planning system); absent: R7 (balance production capacity against the forecast)

R2 and R5 are operations work near planning, with no planning cycle behind them. R6 is conversational against a fluent bar. R7 has no production or capacity evidence at all.

**Opportunity ledger.** The mandate is clear: a named 13-week plan and a named weekly meeting (RR1, positive). Open: pay isn't stated (RR2), the employer is unverified (RR3), and how much production authority the role holds is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Why `no_go`:** this is a fit call, not an opportunity call. Several must-haves are open with no closure path that fits a job search. Two of those are inferred from your background: planning years can't be learned in a course, and fluent Dutch takes months.
- **What would change it:** planning experience in demand, supply or S&OP that you haven't mentioned, or a fluent-Dutch level you haven't stated.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site, Utrecht | hard_gate | unclear | none | hard_gate | Your constraint isn't stated | `[inferred]` from posting | Confirm (upgrade menu) |
| R2 | 3+ years planning, FMCG | must_have | adjacent | medium | transferability | No planning years. Adjacent: on-time and route performance work. Limit: no forecast, capacity or production | `[grounded]` background; `[inferred]` adjacency | Name the limit in any interview |
| R3 | Advanced Excel | must_have | unclear | low | discovery | Not in your background | `[grounded]` silence | Confirm your level |
| R4 | SAP IBP or similar | must_have | unclear | low | discovery | Not in your background. Power BI and SQL are not planning systems | `[inferred]` | Confirm any planning-system use |
| R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review. S&OP covers supply and demand, which that review did not | `[grounded]` background; `[inferred]` adjacency | Sanitized review pack (upgrade menu) |
| R6 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational is short of the bar. Closing the gap takes months | `[grounded]` your statement; `[inferred]` timing | None closable in a search |
| R7 | Balance production capacity against forecast | must_have | absent | none | capability | No production, capacity or forecast work in your background | `[grounded]` silence | Closure path: a planning role first |

**Risk register**

| # | Signal | Class | Source quote | Hypothesis | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Clear mandate | positive_signal | "Own the 13-week supply plan" | Scope is defined. `[inferred]` from posting | Which decisions in the plan does this role own alone? | noted |
| RR2 | Pay not stated | unknown | (no pay line) | Could be a publishing choice. `[inferred]` from silence | What is the budgeted salary? | unresolved |
| RR3 | Employer unverified | unknown | "Kroonhaven Foods, Utrecht" | Not checked: search refused. Not a finding about the employer | Can you point me to this role on your careers page? | unresolved |
| RR4 | Production authority | unknown | "balance production capacity against the forecast" | Could mean the role sets capacity, or only reports it. `[inferred]` from the verb | Which production-capacity decisions does this role make, and who signs off changes to the 13-week plan? | unresolved |

**Application plan:** None this round. If you test the planning move later, the nearest step is a logistics or transport planning role, where your route and on-time work is the job. `[inferred]`, not checked.

---

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht ready meals". Both refused, so neither employer's existence, posting or pay was checked. Would have moved RR4 and RR3 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Power BI SQL 2026" and "supply planner FMCG Netherlands salary S&OP SAP IBP 2026". Both refused. Would have set the salary band for both roles |
| 3. Hiring manager's public footprint | n/a | No name was given |

No outside facts are used above. Everything about the postings is `[grounded]` in the posting text, or `[inferred]` or `[generic]` as labeled. Verified: none yet.

**Dossier offer:** I can write both assessments to a `tuesday-dossier.md`, so the verification questions travel with you as you apply.

**Upgrade menu**
- Permission to run web search: confirms both employers exist as described (RR3, RR4) and sets the salary band (RR2). Without it, both assessments stay unverified.
- A posted salary, or your floor: closes RR2 for Duinvaart.
- Your CV text: lets me draft the lead-bullet wording for Duinvaart (P1), pending your approval.
- A sanitized SQL query or dashboard screenshot: raises R3 and R5 for Duinvaart to `high`.

**Questions**
1. R1 (Duinvaart): Are three office days a week in Rotterdam workable for you, given where you'd be commuting from?
2. R6 (Duinvaart): Has any of your work touched temperature or compliance monitoring, even as a data source or a report?
3. R8 (Duinvaart): How often did you use Dutch at work, and with whom: depot managers, drivers, or only the occasional call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.