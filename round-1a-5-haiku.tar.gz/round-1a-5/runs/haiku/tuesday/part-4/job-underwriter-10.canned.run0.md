**Yes, apply, with three things to settle first.** Fernquay looks like a real company with a real opening, and your background matches most of the posting. `conditional_go`

- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2 (base pay against your floor)
  - `must_have`: direct: R3, R4, R5a, R6 · adjacent: R5b, R7
  - `important`: unclear: R8 (working as the only designer)
  - R5b (school-owner research) is a credible bridge with its limit named. R7 (booking flow end to end) is evidenced only as checkout. R8 is the one thing your background cannot speak to yet.
- **Opportunity ledger.** Checkable and mostly sound. The company site, the about page and the careers page agree on the role, the pay band and the Galway hybrid terms (RR3). The base sits inside the market band (RR4). Two entries need answers: a first design hire with no design peer (RR1) and equity with no stated terms (RR2). Ronan's WhatsApp message is a routine scheduling step, so it gets no register entry.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Base pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your base floor is at or below €52,000 (R2); (2) equity terms are stated in writing (RR2); (3) you have a clear answer on design review as the first designer (RR1, R8).

**Your question about the WhatsApp message:** messaging a candidate to schedule a video call, with the invite sent by email, is routine for a small team. The name matches the public co-founder, but I can't verify the number from here. Check that the calendar invite comes from the company's own domain. The call itself is the step to watch: it should cover the design work, not only logistics.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` about page |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting and careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` careers page |
| Scope read | First design hire at a six-person company: a broad remit with no design team around it | `[inferred]` from "first designer" and team size |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, interquartile range €51,500–€62,000. Sample is Ireland-wide, not Galway-specific | `[generic]` Tillerby 2026 salary report; this is a pattern, not Fernquay's offer |
| Unknowns | Equity value, vesting and instrument; whether the base is the budget or a starting point; who reviews design work | — |
| Contradictions | None found between the posting, the careers page and the about page. The CTO title for Saoirse comes from Ronan's message only; the about page names her as a co-founder | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; self-report, no artifact | `[grounded]` your statement | none |
| R2 | Base pay €52,000–€60,000 against your floor | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you have not stated yet. Fit is unclear because your floor is unknown | `[grounded]` posting | Ask your floor (question 1) |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years as a product designer, self-reported | `[grounded]` your CV | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, self-reported | `[grounded]` your CV | none |
| R5a | Runs own user research | must_have | direct | medium | none | Monthly usability sessions with customers at your travel-booking company | `[grounded]` your CV | none |
| R5b | Research with school owners (B2B) | must_have | adjacent | medium | transferability | Same method, different users: consumer travel customers, not school owners. Limit: no B2B or operator interviews | `[inferred]` adjacency from R5a | G1 |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your CV | none |
| R7 | Owns booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, which is part of booking. End-to-end ownership is not stated | `[grounded]` your CV; `[inferred]` adjacency | G2 |
| R8 | Works as the only designer | important | unclear | low | discovery | Never been the only designer. Not a stated requirement, but implied by "first designer" | `[inferred]` from the posting's framing | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | School-owner research (R5b, must_have) | transferability | Monthly research with travel customers; nothing with B2B or operators | The bridge is the objection most likely to be raised | Any interviews with trade or operator customers, even informal; any feature decision you shaped from operator feedback | A research summary or a sanitized interview guide | `[inferred]` bridge from R5a; `[generic]` that this is the likeliest objection |
| G2 | End-to-end booking ownership (R7, must_have) | discovery | Checkout redesign is evidenced; the rest of the flow is not | The role says "end to end", which is the strongest ask | Decisions you made across search, selection, payment and confirmation; calls with users about the whole flow | The checkout case study, or a flow map of what you owned | `[grounded]` your CV; `[inferred]` that "end to end" is the stated scope |
| G3 | Working as the only designer (R8, important) | discovery | No experience without a design peer | Predicts how the first year feels; it is what the call will probe | How you ran reviews or critique alone; how you chose which decisions to ask engineers about | A review process you set up or followed | `[generic]` that first-design roles often probe this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First design hire, no design peer | risk_signal | medium | "you would be our first designer" | Design quality may depend on your own review, with no second opinion day to day | `[inferred]` from the posting's framing against team size | Who reviews design work day to day, and which decisions would I make without a design review? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Equity value, vesting and instrument are not stated, so the total package is unknown | `[generic]` early-stage postings often omit these terms | What is the vesting schedule, the instrument (options or shares), and the valuation basis? | unresolved |
| RR3 | Terms consistent across posting, careers page and about page | positive_signal | — | "Hybrid, two days a week at our Galway office" | The company is what it says, with a live role and stated terms | `[grounded]` site and posting agree | What did the booking flow look like at launch, and what has changed since school feedback? | noted |
| RR4 | Base sits inside market band | positive_signal | — | "€52,000–€60,000" | The band matches the role-family median for this experience | `[generic]` Tillerby 2026 median €57,000; not an offer from this employer | Is €52,000–€60,000 the budget for this role, and where does the offer usually land? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Build a sanitized write-up of the checkout redesign and one usability study, for the application | Shows research and an owned project; the posting asks for a "messy real project" | `[grounded]` your CV, R5a, R7 | pending your approval |
| A2 | Ask RR1 and RR2 verbatim on the call | The register doubles as your interview questions | `[grounded]` register | pending your approval |
| A3 | Name the travel-to-school bridge in your answer, not claim school experience | Keeps R5b at adjacent | `[inferred]` from R5b | pending your approval |

## Evidence status

Verified: R3, R4, R5a, R6 claims (sources: your CV; the user-confirmed checkout and usability details). R1 is a self-report with no artifact, so its band stays `medium`. Unverified leads: none. Verified: no claims yet beyond the CV's own statements.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea-kayak surf schools" and "Fernquay Product Designer job Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and "About Fernquay" (fernquay.example/about). Entity established; role, pay and hybrid terms consistent; no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway mid senior 2026"; result "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder"; result "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Public footprint only: co-founder and CEO, previously product lead at a Galway travel-software company for five years. Moved the positioning in A3 |

## Upgrade menu

- A stated pay floor → R2 closes; the hard-gates line then reads "met" or "failed" rather than "unconfirmed".
- Your checkout case study, sanitized → R7 can move toward `direct` once it is inspected.
- Equity terms in writing (vesting, instrument, valuation basis) → RR2 closes.
- Deeper company diligence on Fernquay (funding, leadership, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also write this up as a `tuesday-dossier.md` you can keep and build on, if that would help.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

1. R2 — Does a base of €52,000 meet your minimum, or do you need the upper part of the range?
2. G2 — Have you owned the booking flow end to end, or only parts of it such as checkout? What did you decide, and what did you hand off?
3. G3 — Have you made design decisions without a design peer reviewing them? How did you handle that, and what would you need to keep quality up?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.