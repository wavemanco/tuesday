**Decision snapshot:** Don't proceed. Send nothing (no IBAN, PPS number, passport photo, payment or cheque deposit) and stop replying to @VellowayHiring until the company is verified through channels you find yourself.

- **Fit (candidate side):** Strong on skills. Zendesk at volume, training new starters and Excel tracking all match the posting, and this is `[grounded]` from your background as you stated it.
- **Hard gates:** Pay is unverified. €26/hr at 15–30 hours a week comes to roughly €20k–€40k before commission, and the posting doesn't guarantee a figure. At the low end it sits below your €30k floor. Not confirmed as failed.
- **Opportunity (red flags, `severity: high`, quoted from the messages):**
  1. Your IBAN, PPS number and passport photo were requested before any interview or offer.
  2. You were asked to pay €349 by bank transfer to an "equipment partner" for a laptop and headset, to be refunded later.
  3. A €2,850 cheque is to be deposited, with €350 kept and the rest sent to that same partner.
  4. The whole process runs on Telegram, with no call or video step.

  A legitimate employer doesn't normally ask for these in this order. Requests to pay for equipment, deposit a cheque and forward money, or give bank details before an offer are what this decision turns on, whatever the sender's intent.
- **Why the cheque matters:** If a deposited cheque is later returned, the bank can debit the money you sent from your own account, and you carry the loss.

**Research tier: L0, no searches.** Nothing above is verified against the outside world.

**Application plan:** None until the employer is verified. If it checks out, the first step is a written offer from a company email domain that matches its website, with no payment or cheque involved.

**Already-shared details:** You haven't sent anything, which is the best position. Keep your IBAN, PPS number and passport private. If you do end up sharing any of them, tell your bank and watch your account.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so the findings stay with you.

**What would change this:**
- A link to the live posting on Velloway's own careers page, not only the jobs site.
- A company registration number you can check on the Irish CRO register (cro.ie), with an address that matches.
- A written offer from an email domain matching the company's website, with a process that doesn't involve paying or pre-employment bank details.

**Questions** (reply to any, or "skip"):
1. Did you first see the posting on the jobs site only, or also on Velloway's own website?
2. Do you have a registration number or postal address for Velloway?
3. Has the recruiter given you any email address? Does its domain match a website you can find yourself?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.