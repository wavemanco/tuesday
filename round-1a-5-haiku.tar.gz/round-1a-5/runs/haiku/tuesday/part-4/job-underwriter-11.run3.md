## Duinvaart Cold Chain: Operations Analyst, Rotterdam

**Yes, it's worth your time, with conditions. Status: `conditional_go`.** Your core tools and years line up closely with this posting. Two hard gates are unconfirmed, and the employer hasn't been verified.

**Fit ledger.**
- `hard_gate`: unclear: DH1 (hybrid, three days a week in the Rotterdam office), DH2 (right to work in the Netherlands)
- `must_have`: direct: DR1 (2+ years in logistics or operations analysis), DR2 (strong SQL), DR3 (Power BI or Tableau)
- `important`: direct: DR4 (track on-time delivery), DR6 (work with depot managers on route changes); unclear: DR5 (track temperature compliance across the refrigerated fleet)
- `preferred`: adjacent: DR8 (Dutch a plus)

DR5 is the one real gap, and it's still a question rather than a known absence. DR8 is adjacent because your Dutch is conversational.

**Opportunity ledger.** The scope is clear and the tools are named (DRP1). The employer is not yet verified (DRR1), and pay is not stated (DRR2).

- **Hard gates:** none failed; unconfirmed: DH1 (Hybrid, three days a week in the Rotterdam office), DH2 (Right to work in the Netherlands); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) DH1 and DH2 confirmed (Q1); (2) DRR1 cleared by finding the role on Duinvaart's own careers page; (3) DR5 answered (Q3), or DRR3 confirmed as not requiring you to set or enforce thresholds.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst remit covering reporting and recommendations; whether the role approves route changes is unclear | `[inferred]` from "work with depot managers on route changes" |
| Market calibration | Not run; the role-family search was not permitted | — |
| Unknowns | Pay; who sets temperature thresholds; who decides route changes | — |
| Contradictions | None in the posting | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| DH1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | No statement from you on this yet | `[grounded]` posting | Q1 |
| DH2 | Right to work in the Netherlands | hard_gate | unclear | none | hard_gate | Posting is silent; your status not given | `[inferred]` standard employer gate | Q1 |
| DR1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier; stated, not yet inspected | `[grounded]` your background | none |
| DR2 | Strong SQL | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| DR3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, stated | `[grounded]` your background | none |
| DR4 | Track on-time delivery | important | direct | medium | none | The dashboard depot managers use matches this directly | `[grounded]` your background | none |
| DR5 | Track temperature compliance, refrigerated fleet | important | unclear | none | discovery | Nothing in your background covers temperature data | `[grounded]` silence in your background | G1, Q3 |
| DR6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| DR8 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent; the limit is named | `[grounded]` your statement | G2 |

**Gap recovery queue** (questions are in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (DR5, important) | discovery | On-time tracking is documented; temperature data is not | It is the posting's second headline metric | Sensor or logger data, cold-storage handling checks, threshold alerts in any reporting | A dashboard screenshot or its column list | `[grounded]` silence; `[generic]` that temperature is usually sourced from loggers or telematics |
| G2 | Dutch (DR8) | transferability | Conversational; not fluent | Preferred here, but it sets how you describe yourself | A Dutch-language interview, a language certificate | Your stated level, written plainly | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established: no research ran | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale, or the employer too new or small to show online | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| DRR2 | Pay not stated | unknown | — | Posting gives no pay | Pay may sit below the market band, or the employer may not publish it | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| DRR3 | Threshold ownership | unknown | — | "temperature compliance across our refrigerated fleet" | The role may track compliance without setting or enforcing thresholds | `[inferred]` from scope against silence on thresholds | Who sets the temperature thresholds this role tracks, and does this role act on breaches? | unresolved |
| DRR4 | Route-change decision rights | unknown | — | "work with depot managers on route changes" | The role may recommend route changes rather than approve them | `[inferred]` from "work with" wording | Which route decisions does this role make, and which stay with depot managers? | unresolved |
| DRP1 | Clear scope, named tools | positive_signal | — | "Track on-time delivery and temperature compliance ... build weekly dashboards in Power BI" | Responsibilities and tools are defined and measurable | `[grounded]` posting | What does a good week look like for this dashboard, and who reads it? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Phrase the dashboard bullet around its real subject: on-time delivery, used daily by depot managers, built in Power BI. Do not add temperature or cold-chain experience. | DR4 | `[grounded]` your stated facts | pending your approval |
| E2 | Describe your Dutch as conversational in the application | DR8 | `[grounded]` your statement | pending your approval |
| A1 | Find this posting on Duinvaart's careers page before you apply | DRR1 | `[generic]` | pending your approval |

---

## Kroonhaven Foods: Supply Planner, Utrecht

**No, not as a priority: `no_go`.** Your operations background transfers in part, but this role's core is three years of supply planning, SAP IBP and FMCG. Those are absent or only adjacent for you, and no realistic closure exists before this application.

**Fit ledger.**
- `hard_gate`: unclear: KH1 (right to work in the Netherlands), KH2 (on-site in Utrecht)
- `must_have`: adjacent: KR1 (3+ years of supply or demand planning in FMCG), KR5 (fluent Dutch), KR6 (run the weekly S&OP meeting); unclear: KR3 (advanced Excel); absent: KR2 (FMCG experience), KR4 (SAP IBP or a similar planning system)

**Opportunity ledger.** The scope is clear and the tool is named (KRP1). Pay is withheld (KRR1), and the employer is not yet verified (KRR2).

- **Hard gates:** none failed; unconfirmed: KH1 (Right to work in the Netherlands), KH2 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Q2 showing real planning ownership, such as forecast or capacity work, FMCG clients, or a planning system. That would move it to `hold_pending_answers`, and possibly `conditional_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning owner role; whether production decisions sit here is unclear | `[inferred]` from "balance production capacity against forecast" |
| Market calibration | Not run; the role-family search was not permitted | — |
| Unknowns | Pay; decision rights over production schedules | — |
| Contradictions | None in the posting | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| KH1 | Right to work in the Netherlands | hard_gate | unclear | none | hard_gate | Posting silent; your status not given | `[inferred]` standard employer gate | Q1 |
| KH2 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on this yet | `[grounded]` posting | Q1 |
| KR1 | 3+ years supply or demand planning in FMCG | must_have | adjacent | medium | transferability | No planning years; the adjacency is route-performance and delivery-volume analysis; the limit is no forecast or capacity ownership | `[grounded]` your history; `[inferred]` adjacency | G1 |
| KR2 | FMCG experience | must_have | absent | none | discovery | Client sectors of the parcel carrier are not described | `[grounded]` silence | Q2 |
| KR3 | Advanced Excel | must_have | unclear | none | discovery | Not mentioned in your background | `[grounded]` silence | Upgrade menu |
| KR4 | SAP IBP or a similar planning system | must_have | absent | none | discovery | No planning system is named | `[grounded]` silence | Q2 |
| KR5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; the limit is named | `[grounded]` your statement | G2 |
| KR6 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Your weekly route-performance review is a recurring cross-team review; the limit is no supply or demand decisions | `[grounded]` your role; `[inferred]` adjacency | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning years and S&OP (KR1, KR6) | transferability | Weekly review and volume analysis are documented; no forecast or capacity ownership | The bridge narrows the objection most likely to be raised | Any volume forecast, capacity estimate or weekly planning meeting you ran, even informal | A planning or review deck, a forecast sheet | `[inferred]` bridge from your route review |
| G2 | Fluent Dutch (KR5) | transferability | Conversational; not fluent | A must-have here, so the level matters | A Dutch-language conversation with the hiring manager | A language certificate, or a short Dutch sample | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KRR1 | Pay not stated | unknown | — | Posting gives no pay | Pay may sit below the market band, or the employer may not publish it | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| KRR2 | Employer not established: no research ran | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The posting may be stale, or the employer too new or small to show online | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| KRR3 | Production decision rights | unknown | — | "balance production capacity against the forecast" | The role may recommend schedules rather than set them | `[inferred]` from scope against silence on decision rights | Does this role approve production schedules, or recommend them to operations? | unresolved |
| KRP1 | Clear scope, named tool | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting"; "SAP IBP or a similar planning system" | Responsibilities and tools are defined | `[grounded]` posting | How is the 13-week plan's forecast accuracy measured today? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A2 | Apply to Duinvaart first; hold Kroonhaven until Q2 is answered | KR1, KR2, KR4 | `[inferred]` from the map | pending your approval |
| A1 | Find this posting on Kroonhaven's careers page before you apply | KRR2 | `[generic]` | pending your approval |

---

## Evidence status (both postings)

Verified: none yet. Your background is stated in prose, so every claim sits at `medium` until you confirm it in a specific answer.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Web search was not permitted in this session, so neither employer or posting was checked. This would settle DRR1 and KRR2. |
| 2. Role-family sweep (both titles) | unavailable | Would set the market band for each title against the missing pay (DRR2, KRR1). |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

---

**Dossier offer:** If useful, I can write both assessments up as a `tuesday-dossier.md` you can keep and add to as answers come in.

**Upgrade menu**
- Web search permitted in this session → DRR1 and KRR2 resolve, and the market band for both titles can be set.
- The pay range for each posting → DRR2 and KRR1 close.
- Your right-to-work status and location answers → DH1, DH2, KH1 and KH2 close; the decisions sharpen.
- The data source behind your dashboard (telematics, logs or manual entry) → DR5 moves.
- Any planning or forecasting artifact, or a list of the tools you've used → KR1, KR3 and KR4 move.

**Questions**
- **Q1 (DH1, DH2, KH1, KH2):** Do you have the right to work in the Netherlands without sponsorship, and can you work on site in Utrecht and in the Rotterdam office three days a week?
- **Q2 (KR2, KR4):** Have you ever built a forecast, capacity estimate or planning model, even informally; worked with food or retail clients; or used a planning or ERP system?
- **Q3 (DR5):** Did your on-time dashboard include any temperature or cold-chain data, and if so, where did that data come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.