**Worth pursuing: `conditional_go`.** Take the call, and check three things on it: how alone you would be, the pay and contract basis, and how much of the booking flow you would own.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (€52,000–€60,000 base against a pay floor you have not given me)
- `must_have`: direct: R4 (3+ years), R5 (Figma), R6 (own user research), R7 (working with engineers) · adjacent: R8 (own the booking flow end to end)
- `important`: adjacent: R9 (research calls with school owners) · unclear: R10 (working as the only designer)

R8 — the checkout work is real, but it is one step of a booking flow, not the whole flow. R10 — you have never been the only designer, and the role is built around that.

**Opportunity ledger.** The employer checks out from attributable sources (RR5 is a positive signal), and the posting is unusually transparent about pay and hybrid terms. The open items are the solo-designer expectation (RR1) and the contract basis (RR2), both of which the call can answer.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 base, equity 0.5–1%); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the solo-designer scope is concrete in the call (RR1, R10); (2) the post is confirmed permanent, or you are comfortable with its terms (RR2); (3) the pay sits above your floor (R2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 and funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` posting; careers page matches it |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 base plus 0.5–1% equity | `[grounded]` posting and careers page |
| Market calibration | Tillerby 2026 Ireland design survey (n=520), product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posted range sits in the lower-middle of that band | `[generic]` role-family pattern from a salary snippet; not a claim about this employer's offer |
| Scope read | Broad for one person: product ownership, research and delivery at once | `[inferred]` from the posting's three verbs against a six-person company |
| Unknowns | Whether you would be the only designer in practice; contract basis; whether Saoirse Doyle is the CTO (the about page names her as co-founder) | — |
| Contradictions | None between the posting, the careers page and the about page | `[grounded]` three pages checked |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in or able to work from Galway, two office days | hard_gate | direct | medium | none | You stated you moved back to Galway; self-report, not yet probed | `[grounded]` your intake message | none |
| R2 | Base €52,000–€60,000 against your pay floor | hard_gate | unclear | none | hard_gate | No floor given, so the match cannot be checked | `[grounded]` posting | Is the range above or below your floor? |
| R4 | 3+ years of product design | must_have | direct | medium | none | Four years, one employer; exceeds the requirement | `[grounded]` your intake | none |
| R5 | Strong Figma | must_have | direct | medium | none | "Figma daily" is self-report; no file shown | `[grounded]` your intake | Offer a Figma file as an artifact |
| R6 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your intake | none |
| R7 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake | none |
| R8 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign inside a travel-booking product; you did not own the whole flow | `[inferred]` from the checkout work you described; Ronan has already seen the case study | G2 |
| R9 | Research calls with school owners | important | adjacent | low | transferability | Your research was with travel customers, not business owners | `[inferred]` from your research description | G3 |
| R10 | Works as the only designer (implied by "first designer") | important | unclear | low | discovery | You have never been the only designer; nothing else established | `[inferred]` from the posting's framing | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working alone as the designer (R10) | discovery | Nothing on your CV or in your intake shows you operating without design peers | Probably the first question Saoirse and Ronan will test, and it shapes the whole role | Setting up your own review habits without a design lead; running research without a second designer to check it; any project you drove with no one to approve it | Notes from a project you ran alone, or a short account of how you worked with no one to review you | `[grounded]` your intake; `[inferred]` that this is what the role asks |
| G2 | Booking flow end to end (R8) | transferability | Checkout work inside a travel-booking product | Adjacent, and the call will test whether you know the steps before checkout | Search, availability, the decisions that come before payment | The checkout case study Ronan has already seen, with the adjacent steps named | `[inferred]` bridge; `[generic]` that interviewers probe the steps before checkout |
| G3 | School-owner research (R9) | transferability | Monthly sessions with travel customers | The role's research is with business owners, a different interview | Any research with trade or small-business buyers, even informal | A short note of how you would recruit and run calls with owners | `[inferred]` from the adjacent work described |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo design role, with no design peers | unknown | — | "You would be our first designer" | You may carry all design decisions without review | `[generic]` pattern for first design hires at small firms | Who reviews design decisions here, and what design support is planned for year one? | unresolved |
| RR2 | Contract basis unstated | unknown | — | Not stated in the posting | The post may be fixed-term | `[inferred]` from silence on the contract | Is this a permanent post, and if fixed-term, what is the end date? | unresolved |
| RR3 | Pay sits in the lower-middle of the market band | risk_signal | low | "€52,000–€60,000 plus 0.5–1% equity" | The range is reasonable but not above-market for three to five years' experience | `[generic]` from the survey snippet, not a claim about this employer | Is there room to the top of the range for a strong hire? | unresolved |
| RR4 | Broad scope for one person | risk_signal | low | "own the booking flow end to end … run research calls … ship alongside our two engineers" | Three jobs in one role, with no design support | `[generic]` pattern for very small teams | Which of the three gets the most time in the first six months? | unresolved |
| RR5 | Employer checks out, and the founder has the relevant background | positive_signal | — | Careers and about pages; Ronan's public profile | The employer is real, and Ronan has five years' product-lead experience at a Galway travel-software company | `[grounded]` fernquay.example pages and Ronan's public profile | none needed | noted |

On the WhatsApp message: messaging to arrange a video call is routine for a small Irish company, so it is not recorded as a risk. Confirm the calendar invite comes from the Fernquay domain, which you can check against the careers page.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Prepare a walkthrough of the checkout case study that names the steps before and after checkout | see G2 | `[grounded]` your case study; `[generic]` what interviewers ask | pending your approval |
| A2 | Ask RR1, RR2 and RR4 on the call, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Position yourself as having redesigned a checkout and run monthly customer usability sessions, not as having owned booking end to end | Keeps the claim at what you did | `[grounded]` your intake | pending your approval |

**Evidence status**

Verified: none yet. Your intake gives the claims their weight, but nothing has been probed or checked against an artifact.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea-kayak surf schools" and "Fernquay Product Designer job Galway"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Employer established; posting live and consistent with the posting you pasted |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3+ years experience", which returned the Tillerby 2026 Ireland Design Salary Report (snippet only, not fetched). Market calibration in role reality, labeled `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his public profile (linkedin.example/in/ronan-kehoe): co-founder and CEO at Fernquay; five years as product lead at a Galway travel-software company. Application plan positioning |

**Dossier offer:** If you want, I can save this as a `tuesday-dossier.md` for your records, including the questions and the register.

**Upgrade menu**

- A Figma file or a second case study → R5 to `high`, and R8's bridge strengthens.
- A note on how you worked when no one reviewed your design → G1 closes or narrows.
- Your pay floor and whether you need permanent work → R2 resolves, and the decision may move to `go`.
- The hiring manager's own answer on RR1 and RR2 → the conditions for go close.
- A deeper research pass on Fernquay (funding, hiring history, reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Have you ever designed with no other designer to review your work? What did you do instead, and what would you do differently?

R2 — Is €52,000–€60,000 base plus equity above or below the lowest salary you would accept, and does it need to be permanent?

G2 — Did you ever own a booking flow from search to confirmation, or only the checkout step? If only checkout, which earlier steps did you shape?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you want help preparing for the 45-minute call itself, `mock-interview` can build that prep pack.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.