I have the playbook. Next is the research pass: the company existence check and a market sweep for both roles. I'll run the searches in parallel.
**Yes, the Duinvaart role is worth your time, on conditions (`conditional_go`). The Kroonhaven role is not worth it as written (`no_go`).**

Both are first-pass assessments. Web research was refused, so neither employer is verified and neither posting's pay is known. Your own background is self-report, so no claim is above `medium` yet.

## 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Decision snapshot: `conditional_go`**

- **Fit ledger**
  - `hard_gate`: unclear: R1 (Rotterdam office, three days a week)
  - `must_have`: direct: R2, R3, R4, R5a · adjacent: R5b (refrigerated fleet) · unclear: R6 (temperature compliance)
  - `important`: direct: R7
  - `preferred`: adjacent: R8 (Dutch, conversational)

  R5b: parcel work is not cold chain, and that limit stays named. R6: nothing in your background either way, and one question settles it. R1: a gate you have not answered yet.
- **Hard gates:** none failed; unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown.
- **Opportunity ledger:** Clearly scoped and measurable: the posting names its two metrics and a weekly dashboard (RR4). Open points are the missing pay (RR1) and the unverified employer (RR2). No severe red flags, and no request for money or bank details.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: Rotterdam three days a week works for you; (2) RR2: the posting appears on Duinvaart's own careers site; (3) R6: you have temperature or compliance experience, or you can state honestly that you don't.
- **What would change this:** a no on R1 makes it `no_go`, because that gate would fail.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; not verified | `[grounded]` the posting you pasted; not verified by search |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; route-change work with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | Analyst scope with two named metrics; ordinary for the title | `[inferred]` from the posting's responsibilities |
| Market calibration | Not run: the salary search was refused | — |
| Unknowns | Pay; whether route changes are decided by this role or by depot managers | — |
| Contradictions | None within the pasted text | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Rotterdam office, three days a week | hard_gate | unclear | none | hard_gate | No statement from you yet, so the check is unsettled, not failed | `[grounded]` JD | Q1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, no document yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL daily, self-reported | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily; you built the depot dashboard | `[grounded]` your background | a dashboard screenshot would raise it to high |
| R5a | Track on-time delivery | must_have | direct | medium | presentation | Your strongest match, but for parcels | `[grounded]` your background | lead with it in the CV (P1) |
| R5b | Track across a refrigerated fleet | must_have | adjacent | medium | transferability | The metric carries over; cold-chain work does not appear in your background | `[inferred]` from parcel vs. refrigerated | state the limit; claim no cold-chain work |
| R6 | Track temperature compliance | must_have | unclear | none | discovery | Nothing in your background either way | `[grounded]` absence | Q2 |
| R7 | Work with depot managers on route changes | important | direct | medium | presentation | You ran the weekly route-performance review with depot managers and built the dashboard they use; you reviewed routes, not changed them | `[grounded]` your background | keep the word "reviewed" (P1) |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your background | state "conversational" only |

**Gap recovery queue:** R6 (discovery): what you see is nothing either way; closing it needs any compliance or exception-reporting work. R5b (transferability): the bridge is the metric; the limit is refrigerated operations, which you have not done.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | not in the text you pasted | Pay may sit in the full posting, or be withheld | `[grounded]` absence from the pasted text | What is the salary range for this role? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Duinvaart's own careers site, and who would I be interviewing with? | unresolved (search refused, not failed) |
| RR3 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | The role may advise on route changes rather than decide them | `[inferred]` from "work with" against silence on decision rights | Which route changes does this role approve itself, and which go to depot managers? | unresolved |
| RR4 | Measurable outcomes stated | positive_signal | — | "Track on-time delivery and temperature compliance" | Success is measurable, with a weekly dashboard | `[grounded]` JD | How is temperature compliance measured today, and from which data source? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | CV: lead with the on-time dashboard depot managers use; describe the route review as reviewed performance, not route changes | R5a, R7 | `[grounded]` your background | `resume_edits_pending_approval` |
| P2 | Find the live posting on Duinvaart's careers site before applying | RR2 | `[grounded]` register | your call |
| P3 | Confirm the Rotterdam days before investing application effort | R1 | `[grounded]` JD | your call |

## 2. Supply Planner, Kroonhaven Foods (Utrecht)

**Decision snapshot: `no_go`, as written**

- **Fit ledger**
  - `hard_gate`: unclear: R1 (on-site in Utrecht)
  - `must_have`: adjacent: R6 (weekly review meeting), R7 (Dutch, conversational) · unclear: R4 (advanced Excel) · absent: R2 (3+ years FMCG planning), R3 (13-week supply plan), R5 (SAP IBP or similar)

  R6: a recurring review, not an S&OP meeting. R7: conversational, short of the stated fluent bar. R4: no answer yet. R2, R3 and R5: the planning core, and nothing in your background does that work.
- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Opportunity ledger:** The scope is concrete: a 13-week plan and a weekly S&OP meeting (RR3). The pay is not in the pasted text (RR2), and the employer is unverified (RR1). No severe red flags.
- **Severe red flags:** none found.
- **Why `no_go`:** R2, R3 and R5, all must-haves, are absent, and nothing in your background closes them in this role. The Utrecht gate does not drive this decision.
- **What would have to differ:** planning experience of the length R2 asks for, or real use of a planning system (R5).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; not verified | `[grounded]` the posting you pasted; not verified by search |
| Mandate | Own the 13-week supply plan for chilled ready-meals; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planning owner role with a defined cadence | `[inferred]` from the responsibilities |
| Market calibration | Not run: the salary search was refused | — |
| Unknowns | Pay; whether 3+ years is a hard bar | — |
| Contradictions | None within the pasted text | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you yet | `[grounded]` JD | Q1 |
| R2 | 3+ years of FMCG supply or demand planning | must_have | absent | medium | capability | Your statement: you have never worked in planning; the years are a length requirement, so the call rests on that statement | `[grounded]` your background | a planning-analyst route (P4) |
| R3 | Own a 13-week plan balancing capacity against forecast | must_have | absent | medium | capability | No capacity or forecast work in your background | `[grounded]` your background | a capacity-vs-forecast model as a work sample |
| R4 | Advanced Excel | must_have | unclear | none | discovery | Your Excel depth is not stated | `[grounded]` absence | an Excel sample (upgrade menu) |
| R5 | SAP IBP or a similar planning system | must_have | absent | medium | capability | No planning system in your background | `[grounded]` your background | a vendor demo or course; this does not make it experience |
| R6 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review; limit: no production or sales trade-offs | `[grounded]` your background | say "review", not "S&OP" |
| R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, short of the stated bar | `[grounded]` your background | state "conversational" only |

**Gap recovery queue:** R4 (discovery): your Excel depth is unknown; an Excel sample would settle it. R2, R3, R5 (capability): closure is a planning role first, not this posting.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Kroonhaven's own careers site, and who would I be interviewing with? | unresolved (search refused, not failed) |
| RR2 | Pay not stated | unknown | — | not in the text you pasted | Pay may sit in the full posting, or be withheld | `[grounded]` absence | What is the salary range for this role? | unresolved |
| RR3 | Scope and cadence stated | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The role is concrete and measurable | `[grounded]` JD | Which planning decisions does this role make alone? | noted |
| RR4 | Stacked requirements | risk_signal | low | "3+ years … SAP IBP … advanced Excel … fluent Dutch" | The posting may treat tools as must-haves, or may be written for a senior hire; the text alone cannot say which | `[generic]` pattern for planner postings, not a claim about this employer | Is 3+ years in FMCG planning a hard requirement, or would a strong analyst with a different planning background be considered? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P4 | Apply to planner-adjacent roles where route-performance and review work reads as the relevant part | R6, R2 | `[inferred]` from R6 and R2 | your call |

## Research and evidence status

**Verified:** none yet. Everything is your own description, which stands at `medium` at most. **Unverified leads:** none. **Rejected inferences:** none.

Research tier: L1 — searches 5 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Two searches each for Duinvaart and Kroonhaven were refused. Would have checked that each employer exists and that its posting is live (RR1, RR2) |
| 2. Role-family sweep | unavailable | The salary and remit search was refused. Would have set the market band for both titles; the market calibration and the pay check stay open |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- **Search access:** if you allow searches, targets 1 and 2 run for both postings. That settles RR1 and RR2 and sets the salary bands.
- **Full posting links:** the pasted text has no pay, and links would let me read the full postings.
- **Constraints:** where you would commute from, whether weekly Rotterdam or Utrecht days work, and your minimum pay. These settle R1 on both postings and make the pay check possible.
- **Artifacts:** a temperature or compliance report, or alert log, would move R6 from `unclear` to something verifiable. A dashboard screenshot of your on-time work would move R4 and R5a to high. For Kroonhaven, an Excel sample or a capacity-vs-forecast model would address R4 and R3.
- **A CV:** with one, the fit calls rest on a document instead of your description.

If you want, I can write this to a `tuesday-dossier.md` so the next module can read it. For the Duinvaart application itself, resume-tailor is the module that tailors your CV to that posting.

## Questions

1. **(R1, both postings)** Could you work three days a week in Rotterdam, and on-site in Utrecht, and roughly where would you commute from?
2. **(R6, Duinvaart)** Have you worked with temperature, cold-chain or other compliance data, including exception or quality reports that tracked whether a standard was met?
3. **(Pay, both)** What is the lowest monthly pay you would accept for a role like these, so the pay check can run?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.