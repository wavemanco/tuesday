**Yes, worth applying to. `go`.** On what you've shared, the three essential eligibility terms (NMC Adult registration, a full UK licence, a year's post-registration experience) read as met. The open points are interview-probe gaps, not eligibility gaps.

- **Fit ledger.**
  - `hard_gate` — direct: R1, R2
  - `must_have` — direct: R3, R5a, R6a, R7 · adjacent: R4 (home visits to housebound adults), R5b (leg-ulcer care), R6b (continence care) · unclear: R8 (end-of-life visits), R9 (care planning), R10 (written records)
  - `important` — adjacent: R11 (holding your own caseload)
  - `preferred` — absent: R12 (Doppler assessment)

  R4, R5b and R6b are bridges with their limits named. R8, R9 and R10 wait on the two questions below. R12 has a closure path, in the application plan.
- **Opportunity ledger.** Sound on the posting's own terms: the salary and the pool-car arrangement are stated (RR2, RR3). The one open item is whether the post is still live, because the careers page returned nothing (RR1).
- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a register check showing anything other than Adult registration would make R1 a failed gate and the status `no_go`. If the post is no longer open, the status becomes `hold_pending_answers`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract, 410 staff, four locality hubs in Calderdale | `[grounded]` About page, search result |
| Role | Band 5 community staff nurse with a small caseload of your own and a senior community nurse alongside | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Band 5 community staff nurses in England: median £34,300, interquartile range £32,400–£36,600 (n=1,240, 2026). The posting's range sits across that interquartile range. This is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide |
| Scope read | A caseload-holding community post, which is normal for the title | `[inferred]` from the JD |
| Contradictions | None found in what was checked | `[grounded]` About page against JD |
| Unknowns | Whether the post is still open; expected end-of-life and leg-ulcer share of the caseload; Doppler expectations | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated: Adult RN, registration active, revalidation March 2028. Self-reported; not yet checked on the register | `[grounded]` your CV | Check the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated: full UK licence, category B. Not checked; the check is yours | `[grounded]` your CV | Confirm your licence status yourself |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, stated | `[grounded]` your CV | none |
| R4 | Home visits to housebound adults | must_have | adjacent | medium | transferability | Eighteen months visiting patients at home in their first week after discharge. Limit: short post-discharge visits, not a continuing housebound caseload | `[grounded]` your CV; `[inferred]` that week-one visits are an adjacent start | Bridge case in interview |
| R5a | Wound care | must_have | direct | medium | none | Pressure-ulcer and surgical-wound care, stated | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care is stated; leg ulcers are not named. Limit: no leg-ulcer work stated | `[grounded]` your CV; `[inferred]` adjacency | Ask for any leg-ulcer work (chat) |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R6b | Continence care | must_have | adjacent | low | transferability | Catheter care is stated; no continence work named | `[grounded]` your CV; `[inferred]` adjacency | Ask in chat |
| R7 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R8 | End-of-life visits | must_have | unclear | none | discovery | CV is silent | `[grounded]` CV silence | G1 below |
| R9 | Care planning | must_have | unclear | none | discovery | CV is silent on planning owned by you | `[grounded]` CV silence | G1 below |
| R10 | Electronic patient record and clear, timely written records | must_have | unclear | low | discovery | CV is silent on the record system and timeliness | `[grounded]` CV silence | G2 below |
| R11 | Holding your own caseload, with senior support | important | adjacent | medium | transferability | You have never held one; the visit work is the nearest evidence | `[grounded]` your statement | Bridge case in interview |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path below | `[grounded]` CV silence | Ask in chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life and care planning (R8, R9) | discovery | The CV names neither | Both are must-haves, and the caseload is built around them | Discharge-to-assess plans you drew up with families; ward care plans; end-of-life conversations on the ward | A care-plan template or an anonymised plan | `[grounded]` CV silence; `[generic]` that community roles probe planning ownership |
| G2 | Records and timeliness (R10) | discovery | No record system named | Written records are essential | Any electronic record you have used; how you kept notes current on long visit days | A sample entry, anonymised | `[grounded]` CV silence |
| G3 | Doppler and leg ulcers (R5b, R12) | capability | No Doppler and no leg-ulcer work stated | The one preferred row at absent | Any vascular or leg-ulcer exposure, including ward referrals | Training record, if any | `[grounded]` CV; closure path: Rhiannon Mabbott has spoken publicly on Doppler training for new community staff, so ask whether the post includes it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting still live not confirmed | unknown | — | "Community Staff Nurse, Band 5" | The careers page returned no page; the post may have closed or be listed elsewhere | `[inferred]` from the failed careers fetch | Is this post still open on your careers site, and when would the caseload start? | unresolved |
| RR2 | Salary stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Stated pay sits across the Band 5 interquartile range | `[grounded]` JD; `[generic]` survey band | What is the mileage rate, and is the pool-car arrangement written into the offer? | noted |
| RR3 | Pool cars provided | positive_signal | — | "pool cars are provided" | Running costs are covered | `[grounded]` JD | How many pool cars are there, and are they available on visit days? | noted |
| RR4 | Named contact for an informal chat | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The team lead is reachable before applying | `[grounded]` JD | What does a new Band 5's first six months of caseload look like? | noted |

No standing entry applies: the employer is established, so the failed-attribution entry is not raised.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and your licence status yourself | R1, R2 are your own statements | `[grounded]` your CV | for you to do |
| A2 | Confirm the post is live on Calderbrook's own careers site | RR1 | `[inferred]` | for you to do |
| A3 | Lead with discharge-to-assess home visits, then wound, catheter and insulin work. Do not claim a caseload or Doppler experience | R4, R6a, R7, R11, R12 | `[grounded]` your CV | pending your approval |
| A4 | Ask Rhiannon Mabbott about Doppler training for staff new to community work | R12; she spoke publicly on this in 2025 | `[grounded]` speaker page | for you to do |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about): an NHS-contracted CIC with 410 staff across four hubs. Fetched calderbrookhealth.example/careers: no page returned, so the posting's liveness is unverified. Moved RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 Agenda for Change pay scale 2026 nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned her speaker page on the Community Nursing Forum (communitynursingforum.example/speakers/rhiannon-mabbott): leads the Halifax district nursing team, previously eleven years a district nurse, spoke in 2025 on leg-ulcer clinics and Doppler training. Moved A3 and A4 |

## Upgrade menu

- A live posting link, or a careers-page screenshot → RR1 closes.
- Your register check, confirmed to me → R1 moves toward `high`.
- Any leg-ulcer or Doppler exposure, including ward referrals → R5b and R12 move.
- A sanitised care plan or visit note → R9 and R4 move toward `high`.
- A deeper research pass on Calderbrook (leadership, staffing reports, past postings; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want this kept for later, I can produce a `tuesday-dossier.md` for it; just say so.

Two questions:

G1 — Have you planned or led a patient's care from start to finish, including end-of-life planning or the ongoing plan after discharge? What did you decide, and who else was involved?

G2 — Which record system have you written notes in, and how did you keep entries timely on long visit days?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.