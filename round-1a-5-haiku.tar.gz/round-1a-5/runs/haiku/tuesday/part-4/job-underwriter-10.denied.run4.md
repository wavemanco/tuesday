**Yes, it's worth the 45 minutes, on conditions. Status: `conditional_go`.** Nothing in the posting or the WhatsApp message is a red flag. I could not verify that Fernquay exists as described, because every web search was refused in this session. That is unverified, not a finding against them.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate` — direct: R1
  - `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (booking flow end to end)
  - `important` — adjacent: R7 (only designer)
- R6 — your checkout redesign is the nearest work; the limit is that it isn't shown as owning the whole flow. R7 — squad work with four engineers; the limit is that you have never been the only designer.
- **Opportunity ledger.** The posting is specific and open about what it wants, with pay and hybrid terms stated. The scope is wide for one designer (RR1). Pay and equity are stated, but I could not benchmark them (RR2). The employer is unverified (RR3).
- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's existence and Ronan Kehoe's contact are checked on the company's own website before you share more; (2) on the call, you get a concrete answer on what "own the booking flow end to end" means and which decisions sit with you alone (RR1, G1); (3) the pay basis and equity terms are explained (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Role | First designer: own the booking flow, run school-owner research, ship with two engineers | `[grounded]` posting |
| Working with | Co-founder Ronan Kehoe most closely; CTO Saoirse on the call | `[grounded]` posting and WhatsApp message |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Market calibration | Not run: the Irish band for this title could not be checked | — |
| Unknowns | Equity vesting, valuation and strike price; design budget and tooling; who decides on design; funding | — |
| Contradictions | None within what you pasted | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in Galway, two office days a week | hard_gate | direct | medium | none | You say you moved back to Galway last year; stated, not inspected | `[grounded]` your statement | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated | `[grounded]` your statement | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | A Figma file link would raise this to high |
| R4 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; those were consumers, not school owners | `[grounded]` your statement; `[inferred]` the audience difference | none |
| R5 | Works directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your statement | none |
| R6 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | Checkout is the last step of a booking; not shown as owning the whole flow | `[inferred]` adjacency from the checkout work | Your checkout case study, with your decisions marked |
| R7 | Works as the only designer (implied by "first designer") | important | adjacent | medium | transferability | Squad work, never sole design ownership | `[inferred]` from "you would be our first designer" | Closing question Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Only-designer work (R7, important) | transferability | Squad and usability work, with no sole design ownership on record | Likely the main probe for a first-designer role | Calls you made on checkout or research without a design peer to sign off; any area where you set the direction | The checkout case study, marked with who decided what | `[inferred]` from your account; `[generic]` that first-designer interviews probe this |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope wide for one designer | risk_signal | medium | "own the booking flow end to end … run research calls … ship alongside our two engineers" | One designer may carry research, design and delivery with no design review | `[inferred]` from the scope against a team of six; `[generic]` pattern for first-designer roles | What share of the week goes to research against delivery, and who reviews the designs? | unresolved |
| RR2 | Pay and equity unbenchmarked | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may or may not match the market; I could not check | `[grounded]` posting figures; no market claim made | How was this band set, and what do the equity terms vest over, at what valuation? | unresolved |
| RR3 | Employer not verified | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a footprint, the posting may be stale, or the search simply failed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers page, and which address does the interview invite come from? | unresolved |
| RR4 | Specific, transparent posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | Clear about what it wants; pay stated; direct contact with the people who would work with you | `[grounded]` posting | What would a good first 90 days look like? | noted |

The WhatsApp scheduling message and the emailed invite are routine and get no entry. The role is not a hiring process run wholly by chat, since a video call is set.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Fernquay on its own site, and confirm the invite comes from its domain, before sharing more | RR3 | `[grounded]` RR3 | your call |
| A2 | Ask the RR1 and RR2 questions on the call, word for word | They are the register's questions | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout case study, with your decisions and sign-offs marked | R6, G1 | `[grounded]` R6 | pending your approval |
| A4 | On R7, say what you told me: you have never been the only designer; say what you decided alone, if anything | Keeps the gap honest | `[grounded]` your own sentence | pending your approval |

For prep on the call itself, mock-interview can build a pack.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused, so the company's existence and the posting's status are unverified (RR3) |
| 2. Role-family sweep | unavailable | The search for Irish product-designer pay was refused; the band in RR2 stays uncalibrated |
| 3. Hiring manager's public footprint | unavailable | The search for Ronan Kehoe was refused; the co-founder's background is unchecked |

**Upgrade menu**

- Allowing web search again would let me run the company and pay checks, within the one search and two fetches left.
- A link to Fernquay's own website or careers page, which I can read, would close or sharpen RR3.
- Your checkout case study would move R6 to high.
- A Figma file would move R3 to high.
- Your pay floor and equity expectation would let me check the posting against your own constraints.

I can write these findings into a `tuesday-dossier.md` for you to reuse before the call.

1. G1 — Which checkout decisions did you make on your own, and who had the final say on the rest?
2. Do you have a pay floor or an equity expectation I should check the posting against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.