**Worth taking the call, on conditions. Status: `conditional_go`.** Nothing in the posting or the messages is a red flag, and your fit is strong on what you can show. I could not check that Fernquay exists as described: web search was refused in this session, so the company check is still open and the decision stays conditional until you have done it yourself.

The WhatsApp message is not a warning sign. Arranging a call by chat, with the invite coming by email, is routine. The posting also has no requests for money, deposits or bank details.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R8 (Pay €52,000–€60,000 against your floor)
- `must_have` — direct: R2, R3, R5, R6 · adjacent: R4 (Owns the booking flow end to end)
- `important` — unclear: R7 (Sole designer, no design peers)

R4 — a credible bridge from checkout to booking, its limit named: you redesigned checkout, but the CV does not show you owning a flow from research through to shipping.

**Opportunity ledger.** The company's footprint, the salary and the equity are unverified (RR1, RR2), and working alone as the first designer is a question for the call (RR3). One entry runs the other way: the posting states its pay band and its hybrid pattern openly (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R8 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's own careers page confirms the role is live and the company is as described (RR1); (2) the pay and equity terms meet your floor (R8, RR2); (3) on the call, you describe the checkout work as yours only where it was yours (R4).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not checked against any outside source |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Two office days in Galway, the rest flexible | `[grounded]` posting |
| Scope read | Research, design and engineering handoff in one role, with no design team named | `[inferred]` from "first designer" against a silent team |
| Market calibration | Not run: the salary band could not be checked this session | — |
| Unknowns | Funding and stage; who makes product decisions; equity type, vesting and strike | — |
| Contradictions | None visible between the posting and the WhatsApp message | `[grounded]` both texts |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You have moved back to Galway; the stated pattern fits | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years, stated, not yet inspected | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R4 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign at a travel-booking firm; end-to-end ownership not stated | `[grounded]` your background; `[inferred]` adjacency | G1 |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; calls with school owners untested | `[grounded]` your background | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad, stated | `[grounded]` your background | none |
| R7 | Works as the only designer | important | unclear | low | discovery | You have never been the only designer; no design peers stated for this role | `[grounded]` your statement | G2 |
| R8 | Pay €52,000–€60,000 | hard_gate | unclear | high | hard_gate | Your floor was not given; the band is in the posting | `[grounded]` posting | Your floor (question below) |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership (R4, must_have) | transferability | Checkout redesign confirmed; no stated ownership of research, build and launch | A must-have; a clear split between your work and the team's narrows the objection | Checkout work from research to launch, if you ran those stages; any booking or availability work | The checkout case study with a note of who did which stage | `[grounded]` your statement; `[generic]` that interviewers probe ownership first |
| G2 | Working without design peers (R7) | discovery | No design colleagues stated since the start | Shapes whether the role suits you day to day | Design critique in the squad; decisions you made without a review | A description of how decisions were reviewed | `[grounded]` the CV's silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers page, and which schools use the product now? | unresolved |
| RR2 | Pay and equity unverified | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may sit below what this scope usually pays, and equity is worth little without vesting and strike terms | `[generic]` for the band, which was not checked; `[grounded]` posting for the figures | What are the vesting schedule and strike price, and how was the band set? | unresolved |
| RR3 | Solo design role | risk_signal | low | "You would be our first designer" | You may have no design peer for critique or sign-off | `[inferred]` from "first designer" against no design team in the posting | Who reviews design decisions today, and who sets the research budget? | unresolved |
| RR4 | Pay and pattern stated openly | positive_signal | — | "Two days a week at our Galway office" | The posting is transparent about pay and working pattern | `[grounded]` posting | How much of the booking flow is already built, and what does a typical release look like? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before joining the video call, check the invite's sender address and link domain match Fernquay's own website | Routine check on any interview invite | `[generic]` routine check | advice; no approval needed |
| A2 | Ask Ronan for the live posting link | RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Prepare the checkout case study with an explicit split of your work and the team's | G1 and R4 | `[grounded]` G1 | advice |
| A4 | Ask the RR2 and RR3 questions in the call, word for word | The register doubles as call prep | `[grounded]` register | advice |

**Evidence status**

Verified: none yet. Everything so far is your own statement, not an inspected artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were refused, including the two aimed at Fernquay's site and careers page. Would have settled RR1 and whether the role is live |
| 2. Role-family sweep | unavailable | Searches were refused. Would have calibrated R8 and RR2 against a `[generic]` band |
| 3. Hiring manager's public footprint | unavailable | The co-founder search was refused. Would have shown Ronan Kehoe's public professional footprint; it cannot clear RR1 alone |

Dossier offer: I can save this analysis as a `tuesday-dossier.md` to take into the call.

**Upgrade menu**

- Fernquay's own careers-page listing, or a confirmed company address → RR1 closes, and `conditional_go` can become `go`.
- The vesting, strike and band-setting answers → R8 and RR2 close.
- Who owned each stage of the checkout work → R4 can move to `high`.
- Web search, if your session allows it: up to 5 searches and 2 fetches for the company check and the salary band. Say the word and I'll run it.
- For the 45-minute call, `mock-interview` can build a prep pack and run drills.

**Questions**

R8 — What is your floor on pay? Is €52,000 acceptable, or is your minimum higher?

R4 — Did you own the checkout redesign from research through to shipping, or did you join once the flow was already set? Which parts were yours?

RR1 — Can you send the role link from Fernquay's own careers page, so the company check runs on their site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.