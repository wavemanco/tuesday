**Yes, the call is worth taking, but Fernquay is not verified yet.** The verdict is `conditional_go`: the role fits your evidence on paper, and the company itself is still unconfirmed. My web searches were not permitted in this session, so nothing about Fernquay was checked. The WhatsApp message is not a red flag. A video-call invite that arrives by WhatsApp and also by email is routine scheduling, and the posting gives pay, equity, office days and the names of the people you'd work with.

## Decision snapshot

**Status: `conditional_go`.** Apply, or keep the call, once the three conditions below hold.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay band €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer, no design peer)

R7 — checkout redesign is the nearest evidence, its limit named; R8 — customer usability sessions, not owner interviews; R9 — squad work, never working solo; R2 — waiting on your pay floor.

**Opportunity ledger.** RR1 (employer not established, `severity: medium`) caps the decision at `conditional_go`. RR2 (equity terms), RR3 (the WhatsApp invite) and RR4 (decision rights) are open unknowns. RR5 is a positive signal: outcomes and pay are stated.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay band €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Fernquay's own website confirms the company, the live role, and Ronan Kehoe and Saoirse as the people you'd meet (RR1); (2) the pay floor sits inside the band (R2); (3) the equity terms are in writing (RR2).

If (1) cannot be confirmed, stop investing time before the call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting, self-described; not checked |
| Mandate | First designer; owns the booking flow; runs research with school owners | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not established. The role-family sweep did not run, so I can't say whether this band is normal for the title | No label; no search ran |
| Unknowns | Pay floor; equity class and vesting; who makes product decisions; research budget and tools | — |
| Contradictions | None between the posting and your messages | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; your statement, not inspected | `[grounded]` your intake message | none |
| R2 | Pay of €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given, so the band cannot be checked | `[grounded]` posting | Your pay floor (Q1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; no CV attached | `[grounded]` your message | Attach your CV |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no portfolio shared | `[grounded]` your message | Portfolio link |
| R5 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your message | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your message | none |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, which is the nearest booking work; ownership was shared in a squad | `[inferred]` comparison of your checkout work with the booking flow | G1 |
| R8 | Runs research calls with school owners | important | adjacent | medium | transferability | Customer sessions, not owner interviews | `[inferred]` comparison of the two research descriptions | G2 |
| R9 | First designer with no design peer | important | adjacent | medium | transferability | Squad work, but you have never been the only designer | `[inferred]` from the posting's "first designer" and your message | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7) | transferability | Checkout redesign inside a squad; no booking-flow ownership shown | The posting's main scope claim | The checkout case study itself | `[grounded]` your message; `[inferred]` the bridge |
| G2 | School-owner research (R8) | transferability | Customer usability sessions only | The posting names this as a core duty | Any interview guide or notes from customer sessions | `[inferred]` |
| G3 | Working without a design peer (R9) | transferability | Squad experience; no solo design role | The posting's "first designer" framing | A project you drove alone, even a small one | `[inferred]` |
| G4 | Pay band (R2) | hard_gate | Band stated; floor unknown | Decides whether the gate passes | — | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Product Designer — Fernquay" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The share class, vesting and cliff are not given | `[inferred]` from the posting's silence | What share class, vesting schedule and cliff apply to the 0.5–1% equity? | unresolved |
| RR3 | Interview arranged by WhatsApp, with an email invite | unknown | — | "I have emailed you a calendar invite" | The invite and the call are probably genuine, but the sender has not yet been checked against the company's own site | `[grounded]` your message | Could you send the invite from a company address and confirm who will join the video call? | unresolved |
| RR4 | Decision rights and resources for a first designer | unknown | — | "You would be our first designer" | You may own the booking flow without a say in product decisions or research budget | `[inferred]` from the posting's scope against its silence on authority | Who makes the final calls on the booking flow, and what research budget and tools would I have? | unresolved |
| RR5 | Outcomes and pay stated | positive_signal | — | "own the booking flow end to end" | Scope is defined and pay is stated | `[grounded]` posting | What does success look like for the booking flow at six and twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check Fernquay's own website for the company, the live role, and whether Ronan Kehoe and Saoirse appear as team | RR1 | `[generic]` pattern | advice |
| P2 | Check the invite came from a company address | RR3 | `[grounded]` your message | advice |
| P3 | Decide your pay floor before the call | R2 | `[grounded]` posting | advice |
| P4 | Describe the checkout work as a squad redesign ("I redesigned checkout with four engineers"), not as owning the booking flow | R7; the audit's scope and verb axes | `[grounded]` your message | pending your approval |
| P5 | Prepare for the 45-minute call with checkout stories and a direct answer on working with no design peer. For the prep pack itself, mock-interview is the module to use. | R9, RR4 | `[grounded]` | advice |

## Evidence status

**Verified: none yet.**

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software Galway sea kayak surf schools" and "Fernquay careers Product Designer" were refused, because WebSearch is not permitted in this session. Would have moved: whether the company exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 3 years experience 2026" refused. Would have moved: the band calibration for R2 and the mismatch check |
| 3. Hiring manager's public footprint | unavailable | A name was given (Ronan Kehoe); search "Ronan Kehoe Fernquay co-founder" refused. Would have moved: the scope read and which story to lead with |

## Upgrade menu

- Permission for web search → targets 1–3 can run: RR1 clears or stays open, and the pay band gets a market check.
- Your pay floor → R2 closes.
- The checkout case study, or a sanitized version of it → R3 and R5 rise to `high`, and the R7 bridge narrows.
- A Figma portfolio link → R4 rises to `high`.
- Fernquay's own careers page or the live listing → RR1 clears.
- The equity terms in writing → RR2 closes.

Would you like me to write this up as a `tuesday-dossier.md`, so the findings carry into the call prep later?

Questions:

- R2 — What is the lowest base salary you would accept, and does your floor sit inside €52,000–€60,000? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- R7 — On the checkout redesign, which decisions were yours and which were the squad's? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- RR1 — Where did you first see the posting: Fernquay's own careers page or a job board? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.