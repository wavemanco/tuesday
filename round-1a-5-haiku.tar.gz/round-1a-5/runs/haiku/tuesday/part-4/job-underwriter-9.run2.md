**Yes, that request is routine. The offer is worth accepting, once you've checked the employer through its own website.** Status: `conditional_go`.

Research did not run. Every web search was refused, so the employer checks below are still open.

**Fit ledger.**

- `hard_gate`: unclear: R1 (right to work in Ireland without sponsorship), R2 (two office days a week in Limerick)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R7, R8 · absent: R9 (pension changes)

R4 (Irish PAYE, PRSI and USC) is the statutory detail not yet on the record. R9 (pension changes) is hands-on experience you have not had. R1 and R2 are gates nothing so far settles.

**Opportunity ledger.** RR1 (employer not established, `medium`) keeps the decision at `conditional_go` until it is checked. RR2 is a positive signal: two in-person interviews at the office, then a written offer naming the role, pay and reporting line.

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland without sponsorship), R2 (two office days a week in Limerick); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) RR1 verifies: the role appears on the employer's own careers page and the employing entity is on the public register. (2) You confirm R1.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` the ad |
| Role | Permanent Payroll Administrator, €40,000, reporting to Declan Garvagh, Finance Manager; hybrid, two days in Limerick | `[grounded]` the offer |
| Pay | €40,000 sits inside the advertised €38–42k | `[grounded]` ad and offer |
| Market calibration | Not run; the salary search was refused | — |
| Contradictions | None between the ad and the offer | `[grounded]` |
| Unknowns | Employing entity and its registration; whether the role is live on the employer's site; right to work; Irish statutory experience | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland without sponsorship | hard_gate | unclear | none | hard_gate | The inputs do not settle it, and you have not stated it | `[grounded]` the offer's right-to-work check | Question 1 |
| R2 | Two office days a week in Limerick | hard_gate | unclear | low | hard_gate | Not stated as a constraint; you attended two interviews in person, which shows access but is not your statement | `[grounded]` your interviews | Upgrade menu |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years fortnightly payroll for 90 staff; self-reported, not yet inspected | `[grounded]` your account | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Payroll run, but the hotel group's jurisdiction and statutory work are not stated | `[grounded]` silence on jurisdiction | Question 2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use of pivot tables and XLOOKUP | `[grounded]` your account | none |
| R6 | Payroll qualification or working toward one | must_have | direct | medium | none | Payroll Technician certificate, 2024; not yet inspected | `[grounded]` your account | Upgrade menu |
| R7 | Starters and leavers | important | direct | medium | none | Handled in your current role | `[grounded]` your account | none |
| R8 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Done monthly in your current role | `[grounded]` your account | none |
| R9 | Processing pension changes | important | absent | medium | discovery | You have never done these; your manager handled them | `[grounded]` your account | Question 3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R4, must_have) | discovery | Payroll experience is clear; Irish PAYE, PRSI and USC are not named | Must-have tier; the ad lists it under requirements | Year-end returns, RPN or Revenue submissions, USC or PRSI class queries | A payslip sample or a return summary | `[grounded]` silence on jurisdiction |
| G2 | Pension changes (R9, important) | discovery | Never done | Ad lists pension changes as a duty | Enrolments, opt-outs, contribution changes you helped check | Scheme rules, a change form | `[grounded]` your account |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a public footprint, the posting may be stale, or it may not be a live hiring employer. Research could not run, so this is unchecked, not a finding | `[generic]` pattern for employers of this size, not a claim about this one | Which legal entity will employ me, and can you point me to this role on your own careers page? | unresolved |
| RR2 | Two in-person interviews and a written offer naming role, pay and reporting line | positive_signal | — | "delighted to offer you the permanent post … at €40,000" | The process looks like a normal hiring process | `[grounded]` the offer and your account | Who will be my day-to-day contact before I start? | noted |

Routine onboarding steps (bank details, PPS number, passport scan via the portal) take no register entry. The request in your offer is routine, so no hold or warning applies to it.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate Housing on its own website. Check the role is listed and the people team and Declan Garvagh appear there | Clears RR1 without relying on the offer email | `[grounded]` RR1 | proposed |
| A2 | Look up the employing entity on the CRO register and, if it is an approved housing body, on the AHBRA register | Confirms the entity exists | `[generic]` where Irish housing bodies are usually registered | proposed |
| A3 | Enter bank, PPS and passport details only in the portal at the address the employer's own website gives. Bring the original passport on day one | Routine onboarding, kept to the employer's own channel | `[generic]` payroll and right-to-work checks are standard after an offer | proposed |
| A4 | Reply to accept within five working days, once A1 and A2 are done | Keeps the offer and avoids rushing the check | `[grounded]` the offer's deadline | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three calls were refused, so there was no result. Would have checked the role is live and the entity matches the offer (RR1) |
| 2. Role-family sweep | unavailable | Refused. Would have set the €40,000 against the Irish payroll-administrator band |
| 3. Hiring manager's public footprint | unavailable | Not sent, since the search tool was refused. Would have covered Declan Garvagh's public role |

**Upgrade menu**

- Confirming R1 (right to work without sponsorship) closes that gate.
- Confirming R2 (the Limerick office days) closes that gate.
- A short description of your Irish payroll work (G1) moves R4 from `unclear`.
- A copy of the Payroll Technician certificate moves R6 from `medium` to `high`.
- Permission to run web search would let the three checks above run for you.

I can also write this up as a `tuesday-dossier.md` if you want to keep it.

**Questions**

1. R1: Do you have the right to work in Ireland without needing sponsorship?
2. R4: At the hotel group, did you run Irish payroll under PAYE, PRSI and USC yourself, including year-end returns?
3. R9: Did you ever help with pension changes, such as enrolments, opt-outs or contribution changes, even partly, or only watch?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.