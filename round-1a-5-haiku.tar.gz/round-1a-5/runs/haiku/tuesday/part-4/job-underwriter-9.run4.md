**Yes, that's routine.** After a written offer that names the role, pay and location, asking for bank details, a PPS number and a passport scan is standard onboarding. Your caution is right for requests made *before* an offer, or sent somewhere other than the employer's own site. Here, the thing to check is the portal address itself. `conditional_go`

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: direct: R3 · unclear: R1 (right to work without sponsorship), R2 (hybrid, two days a week in Limerick)
  - `must_have`: direct: R4 (2+ years running payroll), R6 (starters and leavers), R7 (payroll-to-ledger reconciliation), R9 (Excel) · adjacent: R8 (pension changes) · unclear: R5 (Irish PAYE, PRSI and USC)
  - `important`: direct: R11 (payroll qualification or working towards one) · unclear: R10 (answering staff queries)
- R8 — a bridge, with its limit named; R5 — Irish statutory detail not yet shown; R10 — no evidence either way.
- **Opportunity ledger.** The offer is credible: written, naming role, pay, location and reporting line, after two in-person interviews you attended (RR2, `positive_signal`). The open item is that I could not check the employer from here (RR1, `severity: medium`).
- **Hard gates:** none failed (R3 `direct`); unconfirmed: R1 (right to work without sponsorship), R2 (hybrid, two days a week in Limerick); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 (Q1, Q2); (2) you check the company and the portal address on its own website (RR1, A1); (3) you answer Q3 on Irish statutory payroll (G1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` posting |
| Role | Permanent Payroll Administrator for 240 staff: monthly payroll, starters and leavers, pension changes, ledger reconciliation, staff queries | `[grounded]` posting and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Pay | €40,000 offered; advertised €38,000–€42,000 | `[grounded]` posting and offer |
| Scope read | One post covering the full payroll cycle, reconciliation and pension changes | `[inferred]` from the duty list |
| Market calibration | Not run: the salary search was refused, so €40,000 is not checked against the market | — |
| Unknowns | Whether the employer exists as advertised; your right to work; the portal address; how pension changes are trained | — |
| Contradictions | None found between the posting and the offer | `[grounded]` both documents |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland without sponsorship | hard_gate | unclear | none | hard_gate | Not stated in anything you gave me. The passport check implies they will test it, which does not settle it | `[inferred]` from the offer's right-to-work step | Q1 |
| R2 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Both documents state it; your location and commute are not in what you gave me | `[grounded]` posting and offer | Q2 |
| R3 | Pay within €38,000–€42,000 | hard_gate | direct | none | none | €40,000 sits inside the advertised range. Your own pay floor was not given, so this is checked against the advert only | `[grounded]` posting and offer | none |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, from your intake; no inspectable proof yet | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your payroll work is clear, but your background does not name these deductions | `[inferred]` from your background against the posting | Q3 (G1) |
| R6 | Starters and leavers | must_have | direct | medium | none | Stated in your background, three years | `[grounded]` your background | none |
| R7 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated in your background | `[grounded]` your background | none |
| R8 | Pension changes | must_have | adjacent | medium | transferability | Starters and leavers touch the same pay records. You have never run a pension change; your manager handled them | `[inferred]` bridge from starters and leavers | G2 |
| R9 | Strong Excel | must_have | direct | medium | none | Daily pivot tables and XLOOKUP, stated | `[grounded]` your background | none |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Neither confirmed nor ruled out by your background | `[inferred]` from the posting | G3 |
| R11 | Payroll qualification, or working towards one | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R5, must_have) | discovery | Payroll work is clear; the Irish statutory detail is not named | A must-have; a clear answer moves R5 to direct | Calculating or checking PAYE, PRSI or USC; year-end returns; Revenue submissions | An anonymised payslip you produced, or a year-end checklist | `[generic]` that Irish payroll interviews usually probe statutory detail |
| G2 | Pension changes (R8, must_have) | transferability | You have run the pay side of starters and leavers, but never a pension change | A must-have; the bridge needs a stated limit and a strengthener | Any pension enrolment, opt-out or contribution-rate change you prepared or checked | A scheme change form, or your manager's checklist (anonymised) | `[inferred]` bridge from starters and leavers |
| G3 | Staff payroll queries (R10, important) | discovery | Not in your background either way | An important row; it affects how the role reads, not the decision | Answering payslip, leave-pay or deduction queries, even informally | None needed; a one-line example | `[inferred]` from the posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not represent a live hiring employer. Research could not run here. Your in-person interviews at their office are your evidence that the employer exists | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me at this role on your own careers page, and confirm the company's registered name? | unresolved |
| RR2 | Offered pay inside the advertised range | positive_signal | — | "€38,000–€42,000" against "€40,000 a year" | The offer matches what was advertised. No market comparison was run | `[grounded]` posting and offer | Is €40,000 where the post is budgeted, or somewhere in the range? | noted |

Routine steps are not register entries: the bank details, PPS number and passport scan requested through the portal follow from a credible written offer, so they carry no entry and no condition.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before you enter anything, find the role on Marrowgate's own website, and type the portal address from there rather than clicking the email link | RR1; the link is only theirs if their own site confirms it | `[grounded]` offer sends the portal link by email | proposed |
| A2 | Reply to accept within five working days, once Q1 and Q2 are answered | Keeps you inside the offer's deadline | `[grounded]` offer | proposed |
| A3 | Ask the People Team how pension changes are trained, and whether the role covers them | R8 | `[generic]` pension duties are often trained on the job | proposed |
| A4 | Enter bank, PPS and passport details only in the portal at the address A1 confirms; bring the original passport on day one | Routine onboarding, done safely | `[grounded]` offer | proposed |

Nothing here goes to Marrowgate until you approve it.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the company and its payroll post were refused. Would have moved RR1 and A1 |
| 2. Role-family sweep | unavailable | The salary and remit search was refused. Would have calibrated €40,000 |
| 3. Hiring manager's public footprint | unavailable | The search for Declan Garvagh was refused. Would have shaped how you present to him |

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` so it carries into a later session.

**Upgrade menu**

- Your answers to Q1 and Q2: R1 and R2 close, and the decision moves to `go` or `no_go`.
- A careers-page link or the registered company name: RR1 closes or narrows.
- An anonymised payslip or year-end checklist: R5 moves toward a clearer fit, and G1 closes.
- Permission to use web search: the three refused targets can run, covering the company check, the pay calibration and the manager's public footprint.
- Your own pay floor: R3 is checked against your number, not the advert.

**Questions**

- **R1:** Do you have the right to work in Ireland without sponsorship?
- **R2:** Can you work from the Limerick office two days a week, given where you live?
- **G1:** Have you calculated or checked PAYE, PRSI or USC yourself, and if so, which parts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.