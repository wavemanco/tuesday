**Yes, apply, but verify the company first.** `conditional_go`. Your background matches most of the posted requirements. The open questions are whether the company is what it says it is, and whether you're comfortable being the only designer. I could not check the company at all, so "legit" is unverified rather than confirmed or ruled out.

- **Fit ledger**
  - `hard_gate`: direct: R1 · unclear: R2 (salary range against your floor)
  - `must_have`: direct: R3, R4, R5 · adjacent: R6 (owning the whole booking flow)
  - `important`: direct: R7 · absent: R8 (sole designer, no design peers)

  R6 is adjacent because the checkout redesign is a slice of the booking flow, not the whole of it. R8 is the posting's central condition, and it is the one you have not done.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the posting is transparent and specific. The employer is unverified (RR1, `severity: medium`), which caps the decision at `conditional_go`. Decision rights and equity terms are unstated (RR2, RR3).
- **Conditions for go:** (1) the company and the role check out on its own website and in the public company register; (2) you'd take a setup with no design peers, which means learning who sets priorities and reviews design; (3) the salary range clears your floor.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting text, unverified externally |
| Team | Two engineers, a CTO (Saoirse), co-founder Ronan Kehoe | `[grounded]` posting and your WhatsApp message |
| Scope | Own the booking flow end to end, run research with school owners, ship with engineers | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting; market band not established |
| Working pattern | Two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Process | WhatsApp note from Ronan, then a video call invite by email | `[grounded]` your message |
| Contradictions | None visible in the material you shared | — |

Market calibration is not established. My searches for the company and for pay benchmarks were refused, so I have no sourced salary band and I won't quote one from memory.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R1 | Work from Galway office two days a week | hard_gate | direct | medium | none | You moved back to Galway; stated, not inspected | none |
| R2 | Salary €52k–€60k against your floor | hard_gate | unclear | — | hard_gate | Your floor was not given | Question 1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years stated, at a travel-booking company | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" stated | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; the posting asks for research with business owners | Probe the difference |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is a slice of booking; end-to-end ownership not claimed | Say which parts you owned |
| R7 | Ship alongside engineers | important | direct | medium | none | Four-engineer squad stated | none |
| R8 | Sole designer, no design peers | important | absent | medium | transferability | Credible adjacency: daily engineer work, owned redesign. Limit: no solo design decisions reviewed by a peer. Strengthener: one case study of a call you made alone | Question 2 |

Confidence grades your own statements, which are CV-equivalent at intake and therefore capped at `medium`.

## Gap recovery queue

- **G1 (R6, transferability):** you have shipped a checkout redesign, not the whole booking flow. The bridge is real, but its limit must be stated. A case study showing which decisions you made would narrow it.
- **G2 (R8, transferability):** you have never been the only designer. The adjacent work is real, but the solo setup is a new condition for you.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway" | Unverified. I could not check the company. Nothing I could find attributes it to a real entity. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Sole designer, decision rights unstated | unknown | — | "You would be our first designer" | You may carry design decisions with no review from a design peer | `[inferred]` from the posting's scope against its silence on who reviews design | Who sets product priorities, and who reviews design work? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The equity may be hard to value at this stage | `[generic]` that early-stage equity is hard to value | What is the vesting schedule, strike price and current valuation? | unresolved |
| RR4 | Salary range against your floor | unknown | — | "€52,000–€60,000" | Your floor may sit above the range | `[grounded]` your floor, not given | Is this range fixed, or open to discussion? | unresolved |
| RR5 | Transparent, specific posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | Scope and process look straightforward | `[grounded]` posting text | — | noted |

The WhatsApp scheduling and the emailed invite are routine interview steps. They are not a red flag, and they get no entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on the company's own website and check the company register before the call | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Check that the invite's sender domain matches the company's own site | Routine, but a cheap check | `[generic]` good practice | pending your approval |
| A3 | Lead with the checkout case study. Describe only the decisions you made | R6, R8 | `[grounded]` R6, R8 | pending your approval |
| A4 | Before the call, prep the sole-designer question with mock-interview | R8, RR2 | `[grounded]` R8 | pending your approval |

Proposed reply to Ronan, pending your approval: "Thanks, Ronan. Yes, a 45-minute call with you and Saoirse works. I'll confirm once the invite arrives by email."

Evidence status: Verified: none yet. Your background is self-reported until you give specifics.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Company searches were refused permission; nothing returned. Would have moved RR1 and R1 |
| 2. Role-family sweep | unavailable | Pay-benchmark search was refused; would have moved R2 and RR4 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe search was refused; would have moved the positioning in A3 |

Searches were refused permission, so I have not retried them. Permission for web search would let me run these.

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep, append to after the call, and update once the company check is done.

Upgrade menu:
- The company's live posting link or careers page → resolves RR1 and the employer question
- Web search permission → L1 company check and salary calibration (R2, RR4)
- Your pay floor → resolves R2
- The checkout case study, or any artifact you can share → raises R6 and R3 from `medium` to `high`

1. What is your pay floor, and is equity part of the decision for you? (R2, RR4)
2. Have you ever made a design call with no design peer reviewing it, even on a side project? (R8)
3. What domain did the invite come from, and does the company's own site list this role? (RR1)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.