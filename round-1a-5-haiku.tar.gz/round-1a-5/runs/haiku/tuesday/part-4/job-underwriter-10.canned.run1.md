**Yes, it looks legitimate, and it's worth the call: `conditional_go`.** Fernquay's own site describes the same company and role as the posting, and the pay sits near the middle of the market band. The open questions are your pay floor, whether you'd hold real product decisions, and whether you can work with no design peer.

- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2 (Base pay €52,000–€60,000)
  - `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
  - `important`: adjacent: R8 (First designer), R9 (Research calls with school owners)
  - R3, R4, R5 and R6 are each `medium`, confirmed at intake and waiting on an artifact; R7 is checkout ownership, not the whole flow; R2 is the one gate the inputs don't settle.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Base pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger.** Positive: RR2, the posted pay sits near the median. Unknown: RR1 (who holds product decisions and design budget) and RR3 (the equity terms).
- **Conditions for go:** (1) your base floor is at or under €60,000 (R2); (2) interviews confirm you'd hold product decisions on the booking flow and have a research budget (RR1); (3) you can say how you'd get design feedback with no peer (R8).
- **What would change this:** if your floor is above €60,000, R2 becomes `hard_gate_fail` and this is `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers; product is Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting; careers page matches |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | For product designers with 3–5 years in Ireland, median base €57,000, interquartile range €51,500–€62,000 (one 2026 report, n=520, snippet read) | `[generic]` role-family sweep; not this employer's offer |
| Scope read | A first design hire at a small, founder-led company is a sole-designer role | `[inferred]` from "first designer" against a six-person team |
| Unknowns | Who sets product priorities; design budget and tools; equity vesting and share count; whether pay is negotiable | — |
| Contradictions | None between posting and careers page. The about page names Saoirse Doyle as co-founder, which fits the "CTO" in the message | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; a location match from your intake, so medium | `[grounded]` your statement | none |
| R2 | Base €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Posted range is grounded; no floor was stated, so the gate is not established | `[grounded]` posting | G1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years stated; the checkout case study Ronan praised has not been inspected | `[grounded]` your statement; Ronan's message | upgrade menu |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file inspected | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | You ran monthly usability sessions; with consumer customers, not school owners | `[grounded]` your statement | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad stated | `[grounded]` your statement | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout is one stage of booking, and you redesigned it within a squad. Whole-flow ownership is not shown | `[inferred]` from checkout ownership | G2 |
| R8 | First designer, no design peer | important | adjacent | medium | transferability | Four years with engineers, but you have never been the only designer anywhere | `[grounded]` posting and your statement | G3 |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Consumer usability work; school owners are a different customer group | `[inferred]` adjacency | upgrade menu |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Base pay (R2, hard_gate) | hard_gate | Posted range only; your floor is unstated | Decides whether the gate is met | Your stated minimum for a role like this | Your own figure | `[grounded]` posting |
| G2 | Booking flow end to end (R7, must_have) | transferability | Checkout redesign | The posting's core ask | Search, availability, payment, confirmation, changes after booking | Case study with your part marked | `[inferred]` from the posting |
| G3 | No design peer (R8, important) | transferability | Squad work with engineers only | The job's main unknown for you | Solo work, feedback loops you built, self-review habits | An example of working without critique | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership without visible design authority | unknown | — | "You would be our first designer: own the booking flow end to end" | Accountable for the flow without decision rights or design budget | `[inferred]` from ownership language against silence on decision rights | Who sets product priorities day to day, and what budget and tools are committed to design research? | unresolved |
| RR2 | Pay posted near market | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range sits near the middle of the band for this experience | `[generic]` market band; `[grounded]` posting | Is the range final, and where would an offer for four years' experience sit? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity's value depends on terms not given | `[inferred]` from silence on vesting and strike price | What are the vesting schedule, strike price and share count behind 0.5–1%? | unresolved |

No request in the posting or the WhatsApp message asks you to pay, deposit or give bank or ID details, so no request entry applies. The WhatsApp invite is routine scheduling.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check that the video link in the emailed invite goes to a fernquay.example address before the call | Confirms the invite is the company's own | `[grounded]` careers page uses fernquay.example | Advice |
| P2 | For the 45-minute call, the mock-interview skill can build a prep pack | Sibling module; named once | — | Advice |
| P3 | Describe checkout as the checkout you redesigned, not as the whole booking flow: "I redesigned our checkout and ran monthly usability sessions" | Keeps R7 at `adjacent`; "end to end" would inflate your scope | `[grounded]` your statement | Pending your approval |
| P4 | Send Ronan the checkout case study with one line on what you owned and what the squad did | Moves R3 and R7 toward `high` | `[grounded]` Ronan's message | Pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Galway careers Product Designer"; fetched fernquay.example/careers/product-designer and fernquay.example/about. The careers page matches the posting; the about page confirms the company. Employer attributable, so no standing failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years Galway", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report); snippet read, not fetched. Feeds the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his public profile (linkedin.example/in/ronan-kehoe): co-founder and CEO at Fernquay; previously five years as product lead at a Galway travel-software company. Snippet, not fetched. Feeds the scope read |

**Dossier offer:** If you want, I can write this up as a `tuesday-dossier.md` to keep and add to after the call.

**Upgrade menu**
- A copy of the checkout case study, with your own account of what was yours → R3 and R7 toward `high` once inspected.
- Your base salary floor → R2 closes, and the decision either holds or moves.
- One usability study you ran with a business owner, however small → R9 toward `direct`.
- Deeper research on Fernquay (funding, leadership, past reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**
- G1: Is €52,000 base the least you would accept, and does the top of the range, €60,000, meet your minimum?
- G2: Beyond the checkout redesign, which parts of a booking flow did you own end to end: search and availability, payment, confirmation, or changes after booking?
- G3: Have you ever designed without another designer to review your work? What did you do to get feedback?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.