**Status: `conditional_go`.** Yes, asking for bank details, a PPS number and a passport check after a written offer that names the role and pay is normal in Ireland. It is not a reason to refuse. The condition is that you confirm the offer really comes from Marrowgate Housing, through their own website, before you send anything. I could not check that from here.

- **Hard gates:** `unconfirmed: R1 (Hybrid, two days a week in Limerick office)`; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the written offer names the role, manager, hours and pay, and the pay sits inside the advertised band [grounded]. The company itself is unverified (RR1).
- **Fit ledger:**
  - `hard_gate`: R1 `unclear`, the Limerick attendance.
  - `must_have`: R2 `direct` (3 years' payroll), R4 `direct` (Excel), R5 `direct` (certificate). R3 `unclear` (Irish PAYE, PRSI and USC, not stated beyond the certificate).
  - `important`: R6 `direct` (starters and leavers), R7 `direct` (payroll-to-ledger reconciliation), R8 `absent` (pension changes, never done), R9 `adjacent` (240 staff against your 90).
- **What would change this:** if you cannot manage the Limerick days, it becomes `no_go`. If the offer does not check out on their own site, it becomes `hold_pending_answers`.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Web search was not permitted in this session, so the company is unverified. |
| 2 | Role-family sweep (pay and scope norms) | skipped | Not run after the first search was refused. |
| 3 | Hiring manager's public footprint | skipped | Not needed for this decision. |

**Role reality.** Payroll Administrator, permanent, €40,000, reporting to the Finance Manager, hybrid with two days a week in Limerick [grounded]. Unknowns: who else is in the payroll team, which payroll system they use, and who administers the pension scheme.

**Evidence map.** The table above lists each requirement's fit. Your background supports the core payroll work. The gaps are pension changes (R8) and proving Irish statutory knowledge (R3).

**Opportunity risk register**

| ID | Class | Severity | Signal | Status | Verification question for the employer |
|---|---|---|---|---|---|
| RR1 | risk_signal | medium | Employer not established from attributable sources. Research could not run. | unresolved | "Could you confirm the People Team's direct phone line and the onboarding portal address, so I can match them to your website?" |

RR1 is a standing entry. The reasons it could stay unconfirmed are side by side, none more likely: a small or new employer, a stale or aggregated posting, or a posting from an employer that is not what it claims [generic]. The entry caps the decision at `conditional_go` until it is cleared.

**Application plan**

1. **Verify before you reply.** Find Marrowgate Housing's website yourself, not through the email link. Check that the role is listed on the careers page and that people@marrowgatehousing.ie matches their domain. Phone the number on their website, not the one in the email, to confirm the offer and ask for the portal address.
2. **Accept by email** within five working days if the checks hold. The reply needs no bank, PPS or passport details.
3. **Enter details only in the portal** at the address their own website gives. Never send bank, PPS or passport details by email or to a personal contact. Enter the details in the portal only once you are sure the link is theirs.
4. **Ask which right-to-work document they need.** A passport is not the only option for Irish or EEA citizens [generic]. Ask whether the scan is stored and for how long, and whether the scan is needed at all, since they also ask you to bring the original on day one.
5. **Ask about pensions before you start.** Who administers the scheme, and how changes are handed over from your manager's role, since you have not done them before.

**Evidence status:** above.

**Dossier offer:** I can save these findings to a `tuesday-dossier.md` for later use if you want them.

**Upgrade menu**
- A web search for Marrowgate Housing, if you give permission for one, would let me check the company's own site and the role-family pay norms. Right now both are unverified.
- The live job posting link, if you have it, would confirm the advert against their careers page.

**Questions**
1. Could you work two days a week at the Limerick office from where you live?
2. Did your Payroll Technician course cover PAYE, PRSI and USC in depth, and have you run them on a live payroll?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.