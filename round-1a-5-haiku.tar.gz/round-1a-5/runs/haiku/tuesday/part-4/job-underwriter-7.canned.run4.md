**Yes, worth applying, on one condition: `conditional_go`.** Apply once the posting is confirmed live on Calderbrook's own careers page. I could not open that page, so the posting itself is unverified.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R11
- `must_have`: direct: R3, R5a, R6a, R7a · adjacent: R5b (leg-ulcer care), R7b (care planning) · unclear: R4 (clear, timely written records), R6b (continence care), R8 (end-of-life visits)
- `important`: adjacent: R9 (holding own caseload)
- `preferred`: absent: R10 (Doppler assessment for leg ulcers)

R9 is the caseload you have never held. R4 and R8 are unconfirmed, and each needs one answer from you. R10 is absent, and it is preferred only.

**Opportunity ledger.** The employer is established: an NHS-contract community service in Calderdale (RR3, RR4 are positive). Open items are whether this post is live (RR1) and whether it is permanent (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R11 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the post is confirmed on the employer's own careers page; (2) RR2: the post's contract basis is confirmed; (3) R9: you have an honest answer ready on caseload (see the application plan).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` about page, calderbrookhealth.example/about |
| Role | Community staff nurse, Band 5; own caseload with senior nurse support; EPR documentation | `[grounded]` posting |
| Pay | Posting £31,050–£37,800 plus mileage. The survey median is £34,300 (interquartile range £32,400–£36,600). The posting's lower end sits below that range | `[grounded]` posting; `[generic]` survey, England, 2026, n=1,240 |
| Unknowns | Whether the post is live (RR1); permanent or fixed-term (RR2) | — |
| Contradictions | None found. The about page says vacancies are on the careers page, which I could not open | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated PIN, registration active; not checked from here | `[grounded]` CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated full licence, category B; not checked from here | `[grounded]` CV | Confirm licence status and expiry |
| R11 | Based in Halifax | hard_gate | direct | medium | none | Stated residence in Halifax; posting names Halifax | `[grounded]` CV, JD header | none |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse; specific, no artifact | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on documentation | `[grounded]` CV silence | G2 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Same wound assessment and dressing work; compression and vascular assessment not stated | `[inferred]` from the wound work listed | G4 |
| R6a | Catheter care | must_have | direct | medium | none | Stated on acute ward | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | CV covers catheter care only | `[grounded]` CV silence | G5 |
| R7a | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R7b | Care planning | must_have | adjacent | medium | transferability | Discharge work plans first-week care at home; a plan across weeks not described | `[inferred]` from the discharge role | G1 |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | G3 |
| R9 | Holding own caseload | important | adjacent | medium | transferability | You state you have never held one; 18 months of home visiting is the nearest | `[grounded]` your statement | G1 |
| R10 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence; closure path is training | `[grounded]` CV; `[inferred]` closure path | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Caseload and care planning (R9, R7b) | transferability | Discharge visits to patients in their first week; no plan of care followed across weeks | An account of a patient you followed beyond the first visit, or the longest you stayed with one | `[grounded]` CV; `[inferred]` bridge |
| G2 | Written records (R4) | discovery | No mention of documentation or record system | A named EPR system and an anonymised example of a note | `[grounded]` CV silence |
| G3 | End-of-life care (R8) | discovery | Not mentioned | Whether you took part in end-of-life care, and your part | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R5b) | transferability | Pressure and surgical wounds only | Whether you have dressed or assessed leg ulcers | `[inferred]` adjacency |
| G5 | Continence care (R6b) | discovery | Catheter care only | Whether you have assessed or managed continence | `[grounded]` CV silence |
| G6 | Doppler assessment (R10) | capability | None | Training, which the employer appears to offer (RR4) | `[grounded]` CV; `[inferred]` from RR4 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status not confirmed | unknown | — | "Current vacancies are listed on our careers page" (about page) | The posting may be closed, or sits on a page I could not reach | `[inferred]` from the failed careers-page fetch | Is this post open now, and where is it listed on your careers site? | unresolved |
| RR2 | Contract basis not stated | unknown | — | Posting silent on contract type | The post may be fixed-term | `[inferred]` from posting silence | Is this post permanent or fixed-term? | unresolved |
| RR3 | Named clinical support | positive_signal | — | "supported by a senior community nurse" | Support is built into the role | `[grounded]` posting | How is the senior nurse's support given to new caseload holders? | noted |
| RR4 | Doppler training appears offered | positive_signal | — | Team lead's 2025 forum talk on Doppler training for staff new to community work | Training may be available to you if you join | `[inferred]` from a public talk | Is Doppler training provided for staff who have not done it before? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the post on the careers page before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Describe caseload honestly: "I visited patients at home in their first week after discharge. I have not held a caseload, and I'd expect to learn that from the senior nurse." | R9, G1 | `[grounded]` your CV and statement | pending your approval |
| P3 | Name Doppler as a learning need and ask about training | R10, RR4 | `[grounded]` R10; `[inferred]` training | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are self-reported and count as leads until you confirm them.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 jobs", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page at that address. Moved the organization row; posting liveness unverified (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary NHS Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the pay calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved RR4 and the scope read. Public talk only |

## Upgrade menu

- The careers-page listing or a direct link to the post → RR1 closes, and the decision may move to `go`.
- Any confirmed information on contract type → RR2 closes.
- An anonymised home-visit note → R4 moves to `medium`.
- Any leg-ulcer dressing or assessment experience, even on a ward → R5b moves up.
- A deeper research pass on Calderbrook (leadership, staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.
- If an interview comes, the mock-interview module can rehearse the caseload question.

Questions:

G1 (R9) — Think of a patient you saw at home in the discharge team. Did you ever follow one patient's plan across several weeks, decide their next steps, and see the outcome? If not, how long did you stay with a patient, and who took over?

G2 (R4) — Which electronic record system have you used, and how soon after a home visit did you write up your notes?

G3 (R8) — Have you taken part in end-of-life care, at home or on the ward? If so, what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.