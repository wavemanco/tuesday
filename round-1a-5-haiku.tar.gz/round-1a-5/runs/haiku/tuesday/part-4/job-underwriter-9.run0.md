**Yes, that request is routine.** For a written offer like this one, employers in Ireland normally collect bank details for salary, a PPS number for Revenue, and a right-to-work check `[generic]`. The rule you were taught applies to timing and channel: don't send these before an offer, and never by email or chat. Enter them only in the employer's own portal, at the address on its own website. Status: `conditional_go`.

- **Fit ledger.**
  - `hard_gate`: unclear: R9 (right to work in Ireland), R10 (Limerick office, two days a week)
  - `must_have`: direct: R1, R2, R3, R6, R7 · unclear: R5 (Irish PAYE, PRSI and USC)
  - `important`: adjacent: R4 (pension changes) · unclear: R8 (staff payroll queries)

  R5 is the must-have the material doesn't show. R4 is carried over from starters and leavers, but you never ran pension changes yourself.
- **Opportunity ledger.** The offer carries no red flag. Pay is €40,000, inside the posted €38,000–€42,000 band (RR3), and the post is permanent. The bank, PPS and passport request comes after a written offer, so it takes no register entry. Two entries remain: RR1, the employer hasn't been checked from public sources, and RR2, contract terms aren't stated.
- **Hard gates:** none failed; unconfirmed: R9 (right to work in Ireland), R10 (Limerick office, two days a week); candidate constraints not given, so checks against your own limits are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 closes: the employer and the portal address match its own website; (2) R9 closes: you confirm your right to work; (3) R10 closes: the Limerick pattern and the pay work for you.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Employer | Marrowgate Housing, a housing association in Limerick | `[grounded]` posting and offer; not checked publicly (see Evidence status) |
| Role | Permanent Payroll Administrator, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope | Monthly payroll for about 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` posting |
| Pay | €40,000 a year, within the posted €38,000–€42,000 band | `[grounded]` offer and posting |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Market calibration | Not run; the pay search was refused (see Evidence status) | — |
| Unknowns | Start date (tied to your notice period), pension scheme, hours, notice and probation | — |
| Contradictions | None between the posting and the offer | `[grounded]` both documents |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated but not shown | `[grounded]` your background | none |
| R2 | Starters and leavers | must_have | direct | medium | none | Stated as part of your payroll work | `[grounded]` your background | none |
| R3 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated; no reconciliation artifact yet | `[grounded]` your background | none |
| R4 | Pension changes | important | adjacent | medium | transferability | Starters and leavers carry over; you never ran pension changes, your manager did | `[grounded]` your statement; `[inferred]` adjacency | G1 |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not named anywhere in your background; the certificate may cover it, but its content isn't stated | `[inferred]` from the material's silence | G2 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use; pivot tables and XLOOKUP stated | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated; certificate not shown | `[grounded]` your background | none |
| R8 | Answering staff payroll queries | important | unclear | low | discovery | Not stated | `[inferred]` from the material's silence | Recall one payroll query you resolved, for interview use |
| R9 | Right to work in Ireland, checked by passport | hard_gate | unclear | none | hard_gate | The offer makes the check a condition; your status isn't in the material | `[grounded]` offer; your status not given | Q1 |
| R10 | Limerick office, two days a week | hard_gate | unclear | none | hard_gate | The pattern is stated; your commuting limit isn't | `[grounded]` posting and offer; your constraint not given | You confirm it fits; no question this turn |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R4, important) | transferability | Starters and leavers carry over; pension changes were not yours | An interviewer is likely to test this limit | Pension admin you saw done or checked, such as opt-ins, contribution changes or leaver refunds, only if you actually saw it | The scheme's joiner or change form, if you have one | `[inferred]` bridge from starters and leavers; `[generic]` that interviewers probe pension admin for this role |
| G2 | Irish PAYE, PRSI and USC (R5, must_have) | discovery | Not named in your background; the 2024 certificate may cover it | A must-have; resolving it moves R5 from unclear | Live PAYE, PRSI or USC deductions you ran, or a Revenue submission you prepared | The certificate's module list | `[inferred]` that the certificate's content is what settles it |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from public sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check couldn't run this session, so this is not a finding that anything looks wrong; you interviewed at its office | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Contract terms not stated | unknown | — | "We are delighted to offer you the permanent post" | The offer gives role, pay and start rule, but not hours, pension scheme, notice or probation | `[inferred]` from the offer's silence | Could you send the written statement of terms, including the pension scheme, probation and notice, before I give notice? | unresolved |
| RR3 | Pay inside the posted band | positive_signal | — | "€40,000 a year" against "€38,000–€42,000" | Mid-band, consistent with the posting | `[grounded]` offer and posting | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before entering anything, check that the portal link's domain matches the address on Marrowgate's own website or careers page | Bank, PPS and passport details go only into the employer's own portal | `[grounded]` the offer names the portal; `[generic]` the check is standard advice | proposed |
| A2 | Ask for the written statement of terms before you give notice | Covers RR2: pension, hours, notice, probation | `[generic]` Irish law requires employers to give a written statement of core terms | proposed |
| A3 | Send the passport scan only through the portal, and bring the original on day one as the offer asks | The right-to-work check is routine | `[grounded]` offer | proposed |
| A4 | Pull the certificate's module list and check for PAYE, PRSI and USC | Settles G2 and R5 | `[inferred]` from G2 | proposed |
| A5 | Prepare one honest pension answer: starters and leavers carried over, pension changes were your manager's, and what you saw | Names the limit in G1 rather than hiding it | `[grounded]` your background; `[generic]` interviewers probe this | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: web search permission was not granted this session. Would have checked the employer, the posting and the offer's domain, moving RR1 and A1 |
| 2. Role-family sweep | unavailable | The search was refused. Would have set €40,000 against the market for this role in Limerick |
| 3. Hiring manager's public footprint | unavailable | The search was refused. Would have informed positioning only; lower priority for this decision |

I did not retry the refused searches.

**Dossier offer:** Want me to write this up as a `tuesday-dossier.md` you can keep and update as you verify things?

**Upgrade menu**
- The careers-page or posting link from Marrowgate's own site → RR1 closes; the decision may move to `go`.
- The written statement of terms → RR2 closes.
- Your right-to-work status, in your own words → R9 confirmed.
- Your pay floor and commute limit → the gate checks run against your own limits.
- The certificate's module list → R5 and R7 move toward `high`.
- A research pass on the employer and the market rate for this role (up to 5 searches and 2 fetches). Web search was refused this session, so it needs your permission to run.

**Questions**
- R9: Do you already have the right to work in Ireland, with no sponsorship needed?
- G2: Did your payroll certificate cover Irish PAYE, PRSI and USC, and have you run them yourself on live payroll?
- G1: Have you seen the pension-change process end to end, such as joiners, opt-outs or contribution changes, even if your manager made the entries?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.