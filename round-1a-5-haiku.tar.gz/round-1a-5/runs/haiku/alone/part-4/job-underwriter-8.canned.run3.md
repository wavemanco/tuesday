**Decision: no-go. Don't send anything, and don't reply with your IBAN, PPS number, passport photo, or any money.**

Whatever the intent behind this posting, the process asks you to do things a legitimate employer doesn't ask for before an offer. Each of these is a problem on its own:

- **Hiring entirely by Telegram, with no call or video interview.** A real employer can be reached by phone or video, and can be checked independently.
- **Your IBAN, PPS number and passport photo before the interview.** Payroll details come after a written offer from an employer you've verified, through a portal you can check. Passport details are not needed at this stage.
- **Paying €349 to a "equipment partner" for a laptop and headset.** A legitimate employer supplies its own equipment. Being asked to pay for it, and promised a refund, is a red flag.
- **The cheque.** You'd be asked to deposit €2,850, keep €350, and send the rest to a third party. Cheques can take time to clear and can be reversed, so you'd be out the money you sent. Moving other people's money this way can also expose you legally, even if you didn't know the cheque was bad.
- **Contact only through a generic postmail address.** Nothing ties it to a company you can verify.

The pay also doesn't match your €30,000 floor. "Up to €26/hour" for 15–30 hours a week is roughly €20k–€40k a year, depending on hours that aren't guaranteed. That's [inferred] from the posting's own figures.

**What to do now**
1. Don't paste your IBAN into Telegram or anywhere else.
2. If you've already sent any details, contact your bank today and ask them to flag the account. Consider changing your passwords too.
3. Report the posting to the jobs site, and to the Gardaí if you've sent anything.
4. If you want to check the company, find it through its own website or public registry and call a number from there, not one from the posting.

Your background is a good fit for real roles: customer service operations, Zendesk and support queues, training, and Excel trackers. Those roles are usually advertised on the employer's own site or a major job board. I can help you find and write applications for them.

I did no web searches for this. The decision rests on the posting and messages you provided, so no research was needed to reach it.

Research tier: L0 — no searches

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.