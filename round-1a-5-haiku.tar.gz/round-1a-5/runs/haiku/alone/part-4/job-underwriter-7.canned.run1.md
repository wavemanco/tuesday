**Yes, apply. Decision: `conditional_go`.** On what you've shared, the essential criteria are met, and you have a clear case on the home-visit and wound-care side. The gaps are caseload, Doppler, and the records and EPR points, which the posting doesn't yet let me verify. Your hard gates are met on what you've stated, but I haven't checked them, so you should confirm them yourself.

- **Hard gates:** failed: none. Unconfirmed: none. (NMC Adult registration and full UK driving licence both `direct`, stated by you, not checked.)
- **Fit ledger:**
  - *Hard gate:* R1 NMC Adult registration (`direct`); R2 full UK driving licence (`direct`).
  - *Must-have:* R3 one year post-registration (`direct`); R4 clear, timely written records (`unclear`); R5a wound care, pressure and surgical (`direct`); R5b leg-ulcer care (`adjacent`); R6 catheter care (`direct`), continence (`unclear`); R7 insulin (`direct`); R8 home visits to housebound adults (`direct`).
  - *Important:* R9 holding your own caseload (`absent`); R10 care planning (`unclear`); R11 end-of-life visits (`unclear`); R12 electronic patient record (`unclear`).
  - *Preferred:* R13 Doppler assessment (`absent`).
- **Opportunity ledger:** Positive: the employer exists as described (RR5), and the pay range sits near the survey centre (RR3). Unknown: whether the posting is live (RR1) and how much caseload support you'd get (RR2). No severe red flags (RR-none). The posting requests nothing from you that would count as a red flag.
- **Severe red flags:** none found.
- **What would change this:** If the posting can't be found live, the decision moves to `hold_pending_answers` until you have a live link or the recruiter confirms it. If the caseload is expected from day one with no supervision, that's a serious mismatch worth raising before you apply.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` company About page |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence, end-of-life, insulin, care planning, with a small personal caseload | `[grounded]` posting |
| Scope read | A supported caseload post, with a senior community nurse alongside | `[inferred]` from "supported by a senior community nurse" |
| Market calibration | Wardround 2026 (England, n=1,240): Band 5 community staff nurse median basic £34,300, IQR £32,400–£36,600; 61% paid mileage | `[generic]` role-family sweep |
| Pay | Posting £31,050–£37,800 plus mileage, inside the survey's range; mileage is common in the market | `[grounded]` posting, `[generic]` survey |
| Unknowns | Caseload size and support; records system; whether continence and end-of-life work is in your remit; posting live status | — |
| Contradictions | None found | — |

**Evidence map** (rows above; confidence bands are on the row they describe, not averaged)

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | NMC Adult registration | hard_gate | direct | high | none | `[grounded]` your CV; check the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | high | none | `[grounded]` your CV; check your own licence |
| R3 | One year post-registration | must_have | direct | high | none | `[grounded]` five years on an acute ward |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | not in CV |
| R5a | Wound care | must_have | direct | high | none | `[grounded]` CV |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | `[inferred]` wound work is adjacent; leg ulcers aren't named |
| R6 | Catheter and continence | must_have | direct | medium | discovery | `[grounded]` catheter in CV; continence not named |
| R7 | Insulin administration | must_have | direct | high | none | `[grounded]` CV |
| R8 | Home visits to housebound adults | must_have | direct | high | none | `[grounded]` seconded to discharge-to-assess, home visits in week one |
| R9 | Holding your own caseload | important | absent | high | capability | `[grounded]` you've never held one |
| R10 | Care planning | important | unclear | low | discovery | not named in CV |
| R11 | End-of-life visits | important | unclear | low | discovery | not named in CV |
| R12 | Electronic patient record | important | unclear | low | discovery | not named in CV |
| R13 | Doppler assessment | preferred | absent | high | capability | `[grounded]` you've never done one |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The posting may be closed, or the careers page sits at another address | `[grounded]` my search found no careers page | Can you send the live posting link? | unresolved |
| RR2 | Caseload support unstated | unknown | — | "You will hold a small caseload of your own" | You may carry it from day one | `[inferred]` from the posting's silence on ramp-up | How much caseload is expected in the first three months, and what supervision goes with it? | unresolved |
| RR3 | Pay in line with market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | No mismatch on pay | `[generic]` survey band | Is mileage paid at the standard rate? | noted |
| RR4 | Hiring manager runs Doppler training | positive_signal | — | Public talk on "Doppler training for staff new to community work" | Doppler training may be available once you join | `[grounded]` a conference speaker bio | Is Doppler training provided to staff new to community work, and when? | noted |
| RR5 | Employer established | positive_signal | — | "Calderbrook Community Health is a community interest company…" | Employer is real, with 410 staff and an NHS contract | `[grounded]` company About page | — | noted |

No standing "employer not established" entry: the employer checks out.

**Application plan** (wording is `resume_edits_pending_approval`; nothing goes out until you approve it)

1. **Lead with home visits.** Proposed CV line: *"Seconded 18 months to the discharge-to-assess team, delivering wound, catheter and insulin care in patients' homes in the first week after discharge."* Every part of this is in your CV. It doesn't claim a caseload, leg-ulcer work or Doppler.
2. **Name the caseload gap in your cover letter, honestly.** For example: *"I haven't held my own caseload yet. I'd want to build up to one with a senior nurse's support."*
3. **On Doppler,** if you apply: *"I haven't done Doppler assessments and would welcome the training."* Don't write that you've done it.
4. **Before you apply,** check your NMC registration and your driving licence yourself, and find the live posting.

Evidence status:

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "…community staff nurse band 5 district nursing jobs", which returned the company About page (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Employer confirmed (RR5); posting not verified (RR1). |
| 2. Role-family sweep | yes | Searched "band 5 community staff nurse salary UK 2026 NHS pay scale", which returned Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Fed the market calibration line and RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Halifax", which returned a conference speaker bio (communitynursingforum.example/speakers/rhiannon-mabbott). Fed RR4. Only professional footprint used. |

**Three questions**

1. Which electronic records system have you used, and how did you keep notes timely? (R4, R12)
2. Have you done any care planning or end-of-life work, even in discharge-to-assess, such as palliative referrals or care plans? (R10, R11)
3. Any leg-ulcer dressing or compression work, even outside your CV's list? (R5b)

Answer any of these, or say "skip" and I'll carry that gap as a minor risk.

**Upgrade menu:** A live posting link or the careers page address would clear RR1. The recruiter's email domain would help confirm the contact. Records or EPR details would move R4 and R12 from low confidence. A line from your discharge-to-assess lead about your home-visit work would support the application plan.

I can save this as `tuesday-dossier.md` so the findings carry into interview prep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.