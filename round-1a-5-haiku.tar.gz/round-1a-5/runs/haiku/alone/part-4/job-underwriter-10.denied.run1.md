**Decision: `conditional_go`.** The role fits your background well. I could not verify that Fernquay exists as described, so the opportunity is unverified, not cleared.

## Decision snapshot

| Priority | Fit | Requirement | Confidence |
|---|---|---|---|
| Must-have | Meets | 3+ years product design (4 years, Dublin travel-booking company) | Medium (CV-only) |
| Must-have | Meets | Strong Figma (daily use, stated) | Medium (no artifact) |
| Must-have | Meets | Has run own user research (monthly usability sessions) | Medium |
| Must-have | Meets | Works directly with engineers (four-engineer squad) | Medium |
| Implied | Partial | Owns the booking flow end to end as first designer | Medium |
| Implied | Partial | Sea-kayak and surf-school domain | Low |

**Hard gates:** none failed. Location meets (you live in Galway, two office days a week). Pay floor is unknown because you haven't told me it.

**Opportunity:** Unverified. Confirming Fernquay exists as described is the open item.

## Research tier

Research tier: L1 — searches 3 of 5, fetches 0 of 2

## Role reality

- **Role:** Product Designer, first design hire at a six-person company. Owns the booking flow, runs research calls with school owners, ships with two engineers. Works most with co-founder Ronan Kehoe. `[grounded]` JD
- **Pay:** €52,000–€60,000 plus 0.5–1% equity, as posted. The market band could not be checked, so no comparison yet. `[grounded]` JD
- **Scope read:** A solo designer role. You have never been the only designer anywhere. `[inferred]` JD and CV
- **Market calibration:** Not established. Search was refused.
- **Contradictions:** None found between the posting and your CV.

## Evidence map

| # | Requirement | Priority | Fit | Gap | Confidence | Source |
|---|---|---|---|---|---|---|
| R1 | 3+ years product design | Must-have | Meets | None | Medium | `[grounded]` CV |
| R2 | Strong Figma | Must-have | Meets | Verifiability | Medium | `[grounded]` CV, no artifact |
| R3 | Own user research | Must-have | Meets | Scale of research unknown | Medium | `[grounded]` CV |
| R4 | Works with engineers | Must-have | Meets | None | Medium | `[grounded]` CV |
| R5 | First designer, owns flow end to end | Implied | Partial | Capability: never sole designer | Medium | `[inferred]` |
| R6 | Sea-kayak / surf-school domain | Implied | Partial | Transferability: travel booking to activity booking | Low | `[inferred]` |
| R7 | Hybrid, two days in Galway | Hard gate | Meets | None | High | `[grounded]` CV and JD |
| R8 | Pay €52k–€60k | Hard gate | Unknown | Your floor not stated | — | `[grounded]` JD |

## Gap recovery queue

| Gap | What it is | What would close it |
|---|---|---|
| R2 | Figma skill is stated, not shown | A link to the checkout case study, or any Figma file you can show |
| R3 | Research is stated, not described | One or two sentences on how the usability sessions were run and what changed |
| R5 | You have not owned a design practice alone | Evidence of working without a design lead, or a plan for how you'd handle it |
| R6 | No sea-kayak or activity-booking experience | Any booking-adjacent or customer-research work that transfers |
| R8 | Pay floor unknown | Your minimum, and whether the posted range is what Ronan has said |

## Opportunity risk register

| # | Class | Severity | Entry |
|---|---|---|---|
| K1 | Failed attribution | Medium | **Standing entry.** I could not confirm Fernquay exists as described. Reasons, none ranked as likely: a company too new or too small to be indexed, a stale posting, or not a real hiring employer. This caps a `go` at `conditional_go` until verified. Resolve with the live posting link, the company's own careers page, or the email domain of the invite. |
| K2 | Compensation | Low | Posted range is `[grounded]`. Market band not checked. |
| K3 | Scope | Medium | Solo design role, first designer. `[inferred]` |
| K4 | Equity | Low | 0.5–1% with no stated terms or stage. `[generic]` |
| K5 | Company stage | Low | Six people, two engineers, a CTO. Stage unverified. `[inferred]` |

**Red flags:** None under the standard test. Nobody has asked you to pay, deposit, or give bank details, and nobody has offered a job wholly over chat. Scheduling a call by WhatsApp is routine.

**Positive signals:** The posting asks for a messy real project over a polished deck, which suits how you work. You would talk directly to the co-founder and the CTO.

**On "is it legit?":** Nothing in the message itself is a red flag. The open question is whether the company is real, and that is what K1 tracks.

## Application plan (proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask for the live posting link and the email domain the invite came from; confirm they match the company's own domain | Closes K1 | `[grounded]` K1 | pending your approval |
| A2 | Look up the registered company name on the Companies Registration Office register yourself | Closes K1 | `[generic]` routine check | pending your approval |
| A3 | Ask for the salary band in writing before the final round | Closes K2 and R8 | `[grounded]` JD range | pending your approval |
| A4 | Prepare for the 45-minute call. Lead with the checkout redesign and monthly usability sessions, and say plainly you have never been the only designer | Keeps claims at what you did | `[inferred]` | pending your approval |

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | Web search permission was not granted this session |
| 2 | Role-family sweep for title, pay and scope | unavailable | Same |
| 3 | Hiring manager's public footprint (Ronan Kehoe) | unavailable | Same |

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so it carries over, and mock-interview can rehearse the 45-minute call from it.

## Upgrade menu

- **Web search permission** would let me check the company site, the salary band and Ronan's public footprint. That moves K1, K2 and the scope read.
- **The live posting link and invite email domain** check K1 without search.
- **Your pay floor** resolves R8.
- **A portfolio or the checkout case study** moves R2 and R3 from medium to high.

## Questions

1. (K1, A1) Can you send the link to the live posting and the email address the calendar invite came from?
2. (R8) What is your lowest acceptable salary, and is €52,000–€60,000 what Ronan has said, or only what is posted?
3. (R2) Can you share a link to the checkout case study, or a Figma file you can show on the call?

You can answer any of these, skip any, or say "skip" and I won't ask again.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.