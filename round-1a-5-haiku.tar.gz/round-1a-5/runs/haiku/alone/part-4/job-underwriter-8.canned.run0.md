**Decision: no-go. Don't send anything, and don't paste your IBAN, PPS number or passport photo to anyone in this process.**

**Why**

The posting itself is fine. Your skills match it well. The problem is what they ask you to do:

- **Sensitive details before any interview.** They want your IBAN, PPS number and passport photo before a chat interview. A real employer asks for these only after a written offer, through a formal onboarding process.
- **Paying for the job.** "Pay €349 by bank transfer to our equipment partner" means you pay them first, with only a promise of a refund.
- **The cheque.** They send you €2,850, tell you to deposit it, keep €350, and forward the rest to "the partner." This is the standard setup for a fake-cheque scam. The cheque will likely bounce after you've already sent real money. Moving money for someone else this way can also make you liable, even if you didn't know.
- **Hired wholly by chat, with a non-corporate contact.** Hiring runs entirely on Telegram, and the only contact is a generic email address. Nothing about the company itself is verified.

Whoever is behind these messages, this is a pattern you should treat as a fraud, not a job offer.

**Fit (separate from the decision)**

- Ticket volume, Zendesk and Excel tracking: stated in your CV, so they count as leads rather than proof.
- Training new starters: stated, supports the "coordinator" side of the role.
- Written English and attention to detail: not evidenced in what you've shared.
- Pay: €26/hour "up to" at 15–30 hours a week is roughly €20k–€40k, with commission unclear. Your €30k floor is reachable but not guaranteed.

On fit alone this is a reasonable role. The opportunity fails on the requests above.

**What to do now**

1. **Stop replying** to @VellowayHiring and don't send any documents, bank details or money.
2. **If you've already sent anything**, contact your bank immediately, ask them to watch the account, and change your online banking passwords. Keep the chat logs.
3. **Report it** to Gardaí (or your local police station) and, if you want, to the Central Bank of Ireland's consumer information service or the consumer complaints route on Telegram.
4. **To look for real remote work**, search for roles listed on the company's own website, check the employer's registration (Companies Registration Office in Ireland), and avoid any role that asks you to pay, deposit a cheque or give bank details before a written offer.

I didn't run any online checks on Velloway, so the decision rests on what's in the posting and messages. Research tier: L0 — no searches.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.