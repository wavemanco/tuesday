**Yes, it's worth applying, with conditions. Status: `conditional_go`.** Your registration and driving licence meet the hard gates, and your acute and home-visit experience matches most of the clinical list. The real gap is that you've never held a caseload, which the role is built around. The posting also needs checking before you invest in an application.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R5, R8 · adjacent: R6 (leg-ulcer care), R7 (catheter and continence care), R9 (care planning), R11 (holding a caseload), R12 (home visiting) · unclear: R10 (end-of-life visits)
- `preferred` — absent: R13 (Doppler assessment)

R4, the one must-have not yet evidenced, is a records question you can answer quickly. R11 is the gap that matters most for this title. R13 closes by training.

**Opportunity ledger.** The employer checks out: the about page describes an established CIC with an NHS contract and 410 staff (RR4). The contact's public profile fits the role (RR5). Three things are unknown: the posting isn't yet confirmed on the careers page (RR1), mileage is unclear alongside pool cars (RR2), and the starting salary sits low in the band (RR3). No severe red flags were found.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the careers page (RR1); (2) mileage and pool-car terms are clear (RR2); (3) the records system and Doppler training are confirmed in conversation with the contact (R4, R13).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` about page |
| Mandate | District nursing for housebound adults; a small personal caseload with senior nurse support | `[grounded]` JD |
| Working pattern | Home visits across Halifax; pool cars provided; mileage stated | `[grounded]` JD |
| Scope read | A normal Band 5 caseload post, not a senior role | `[inferred]` from the JD's listed duties against the Band 5 grade |
| Market calibration | Band 5 community nurses in a 2026 survey (n=1,240): median £34,300, middle half £32,400–£36,600. 61% were paid mileage; 24% had a pool or lease car | `[generic]` Wardround 2026 pay guide, snippet read; `[grounded]` posted range £31,050–£37,800 |
| Unknowns | Records system, caseload size, mileage terms, whether the post is live | — |
| Contradictions | None found between the JD and the about page; the careers page wasn't located | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated as active; revalidation due March 2028 | `[grounded]` CV | Check the NMC register yourself |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Category B full licence, stated | `[grounded]` CV | Confirm your licence record yourself |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | CV is silent on records or EPR; discharge visits imply documentation but don't claim it | `[inferred]` from CV silence | G1 |
| R5 | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | low | transferability | General wound care is claimed; leg ulcers and compression are not. Limit: leg-ulcer assessment not exercised | `[inferred]` | G3 |
| R7 | Catheter and continence care | important | adjacent | medium | transferability | Catheter care is direct; continence is not in the CV | `[grounded]` CV | none |
| R8 | Insulin administration | important | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R9 | Care planning | important | adjacent | medium | transferability | Planning on discharge visits; not longer-term community plans | `[inferred]` | none |
| R10 | End-of-life visits | important | unclear | low | discovery | Nothing in CV; acute-ward work may include it, unclaimed | `[grounded]` CV silence | G3 |
| R11 | Holding a personal caseload | important | adjacent | medium | transferability | Never held one; home visits and discharge work are the nearest evidence. Limit: no ownership of ongoing patients' plans | `[grounded]` CV, `[inferred]` | G2 |
| R12 | Home visiting, in patients' homes | important | adjacent | medium | transferability | 18 months of discharge-to-assess visits, first week only | `[grounded]` CV | none |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path is training; the contact has spoken on Doppler training for staff new to community work | `[grounded]` CV; `[generic]` closure path | Ask the contact (see plan) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and EPR (R4, must_have) | discovery | CV silent on records and EPR | A must-have; resolving it likely moves the status | Any electronic record system used on the ward or in discharge visits; timely notes after home visits | A redacted note example, or the system's name | `[grounded]` CV silence; `[inferred]` that it moves the status |
| G2 | Caseload ownership (R11, important) | transferability | Home visits and discharge work, but no ongoing caseload | This is the title's core, and the likeliest interview probe | Deciding visit order and frequency; owning a patient's plan from start to finish | A description of one discharge-to-assess patient's plan | `[inferred]` bridge; `[generic]` that this is the likeliest probe |
| G3 | Leg-ulcer and end-of-life (R6, R10) | discovery | Wound care is claimed; leg ulcers and end-of-life are not | Both are listed duties; the answer shapes positioning | Any leg-ulcer dressing or compression work; end-of-life care on the ward | Training records or a brief case summary | `[grounded]` CV silence; `[generic]` that these are routinely probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The post may have closed or be filled, or not yet listed | `[inferred]` from the careers search finding no vacancy | Is this post live on your careers page, and when does applications close? | unresolved |
| RR2 | Mileage stated alongside pool cars | unknown | — | "plus mileage"; "pool cars are provided" | Mileage may pay only for own-car journeys | `[inferred]` from the JD's two statements | Is mileage paid when I use a pool car, or only when I use my own? | unresolved |
| RR3 | Starting point sits below the typical band | unknown | — | "£31,050–£37,800 a year" | The posted floor is below the survey's middle half; this is a pattern, not a judgment on this employer | `[generic]` survey band; `[grounded]` posted range | Where in the band would someone with five years' experience usually start? | unresolved |
| RR4 | Employer established | positive_signal | — | "running adult community nursing … under an NHS contract" | An established CIC with 410 staff | `[grounded]` about page | How large is the Halifax district nursing team? | noted |
| RR5 | Named contact has district nursing and Doppler background | positive_signal | — | "led the Halifax district nursing team … spoke on Doppler training" | The contact is likely to be a useful guide to training and caseloads | `[grounded]` speaker profile | What Doppler training do Band 5 community nurses get here? | noted |

The standing entry "employer not established" does not apply: the about page confirms the entity.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the discharge-to-assess home visits, and state the caseload gap plainly rather than implying one | R11, R12 | `[grounded]` CV | pending your approval |
| E2 | Don't claim leg-ulcer or Doppler experience; describe wound care as "acute and home settings" | R6, R13 | `[grounded]` rows | pending your approval |
| Q1 | Ask the contact: records system, Doppler training, caseload size, mileage terms | RR1–RR3, R4, R13 | `[grounded]` register | pending your approval |
| A1 | Check the posting on the careers page before applying | RR1 | `[grounded]` | pending your approval |

Nothing here is sent or changed without your approval; E1 and E2 are proposed wording only.

## Evidence status

Verified: none yet. Your claims come from the CV, so they stand as leads until you confirm them.

Research tier: L1 — searches 5 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", "Calderbrook Community Health careers vacancies", and "Calderbrook Community Health community staff nurse band 5 district nursing job" (no results). Fetched calderbrookhealth.example/about. Moved: employer established; careers page not located, so the posting is unverified (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 pay scale 2026/27 community nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Calderbrook", which returned the speaker profile at communitynursingforum.example/speakers/rhiannon-mabbott. Moved: scope read and the contact questions (RR5) |

Your National Insurance number wasn't needed for any of this, so I left it out.

## Upgrade menu

- Confirmation the posting is live on the careers page, or the recruiter's answer on mileage → RR1 and RR2 close
- The name of your records system, or a redacted note example → R4 moves toward `direct`
- A description of one discharge-to-assess patient's plan, start to finish → R11 gets stronger evidence
- A deeper research pass on Calderbrook (leadership changes, staff reports, Halifax team size; up to 5 more searches and 2 more fetches) — say the word and it runs

I can also write this up as a `tuesday-dossier.md` file if you'd like to keep it.

1. Which electronic patient record have you used, and how did you keep notes timely after home visits? (G1, R4)
2. On discharge-to-assess visits, did you decide visit order or frequency, and did you own any patient's plan from start to finish? (G2, R11)
3. Have you done any leg-ulcer dressing or compression work, or any end-of-life care on the ward? (G3, R6 and R10)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.