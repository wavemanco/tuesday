**Decision: conditional_go.** The role is a reasonable fit on most requirements and a real step up in scope. It is worth taking the call, but the company isn't verified yet, so keep the next steps low-cost until it is.

Research tier: L0, no searches. Web search was not permitted in this session, so I couldn't check the company, the posting, or the market. Everything about Fernquay below comes from your message and is labelled as such.

**Fit (your ledger)**

| Requirement | Read | Basis |
|---|---|---|
| 3+ years product design | Met | [grounded] your 4 years |
| Strong Figma | Met | [grounded] daily use |
| Run your own user research | Partly met | [grounded] monthly usability sessions with customers. [inferred] the posting wants discovery research with school owners, a different audience, and you'd need to show you can run it, not just test flows |
| Works directly with engineers | Met | [grounded] squad of four engineers |
| Owns the booking flow end to end | Transferable, not proven | [inferred] your checkout redesign is close, but you've never owned a product area alone |
| First/only designer | Gap, not a hard gate | [grounded] you've never been the only designer. This is the real risk: no design peer, no review, you set the process |

Hard gates: location and hybrid pattern fit (you're in Galway). Salary is stated at €52–60k. I can't say whether that's market-normal without research, so compare it to your own floor. The 0.5–1% equity has no vesting, strike price or option terms, so its value is unknown.

**Opportunity (the company's ledger)**

- Positive: the posting is specific (named co-founder, CTO in the process, product scope, office pattern, stated pay). That's better than vague listings.
- Unknowns: stage, funding, revenue, runway, and how many customers they have. Six people and a first designer role suggests early-stage, which makes 0.5–1% equity a bet, not a known value.
- Process: a co-founder scheduling a 45-minute call over WhatsApp is common in small companies, and by itself it is not a warning sign. You should still confirm the calendar invite came from a company email domain before joining.
- The dog, the informal tone, and "one messy real project" are preferences, not evidence either way.

**Legitimacy**

Nothing in the posting or the message is a red flag by itself. But I could not confirm that Fernquay exists as described, so this stays unverified. Before you go further, check:

1. Ireland's CRO register (cro.ie) for a company called Fernquay and a director named Ronan Kehoe.
2. That the posting is live on the company's own website or careers page, not only on a job board.
3. That the calendar invite is from an address on the company's domain, and that the video link goes to a normal meeting service.

Do not send bank details, PPS number, ID, or pay anything before a written offer. Ask for the equity terms in writing before accepting anything.

**Recommendation**

Take the 45-minute call. Prepare the checkout case study and be ready to explain how you ran research without a dedicated researcher. Ask the co-founder and CTO how the first designer would get feedback, what the funding and runway look like, and what the equity terms are. Your answers to those questions will do more to verify this company than my analysis can.

**What would change this**

- A missing CRO entry or a posting that exists nowhere except the WhatsApp message: move to `hold`.
- Clear answers on runway, equity terms and design support: move to `go`.
- A request for money or identity documents before a written offer: stop.

**Questions (three)**

1. What's your salary floor, and do you know if the equity is an option grant or shares, with vesting terms?
2. Where did you first see this posting (job board, company site, referral)? That tells us whether the listing is live.
3. In the checkout work, who did the research and synthesis, and who had the final say on design decisions?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.