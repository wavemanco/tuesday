**Worth accepting, on the facts you've given. Status: `go`.** Two things to confirm: Irish PAYE/PRSI/USC experience, and whether the Limerick commute works for you. Neither is a deal-breaker on what you've shared.

**Fit ledger** (evidence and fit only; the opportunity is assessed separately below)

- `must_have`: direct on 2+ years' payroll, starters and leavers, payroll-to-ledger reconciliation, Excel, and the payroll qualification. Unclear on Irish PAYE/PRSI/USC.
- `important`: adjacent on pension changes (you've seen them handled, not done them).
- `hard_gate`: none stated by you, so none checked. Limerick hybrid attendance is unknown.
- **Hard gates:** none failed; unconfirmed: Limerick hybrid attendance (location), and your non-negotiables were not given.
- **Severe red flags:** none.

**Opportunity ledger**

- Positive: a written offer that names the role, the salary and the reporting line, after two in-person interviews at their office. €40,000 sits inside the advertised €38,000–€42,000 band.
- Unknown: whether Marrowgate's own website lists this post and whether Declan Garvagh is a real Finance Manager there. Web search was refused, so I could not check either.
- **Routine, not a red flag:** bank details, PPS and a passport scan through an onboarding portal, after a written offer naming role and pay. This is standard for Irish employers. It gets no risk entry.

**Your question: is it normal?** Yes. Payroll needs your bank details and PPS number, and employers also must check right to work. Two rules still hold: enter details only in the portal at the address shown on Marrowgate's own website, and don't email your passport scan or bank details to anyone. The original passport on day one is also normal.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a Limerick housing association, 240 staff | `[grounded]` job ad |
| Remit | Monthly payroll, starters/leavers, pension changes, payroll-to-GL reconciliation, staff queries | `[grounded]` job ad |
| Contract and pay | Permanent, €40,000 in the advertised band | `[grounded]` offer email |
| Scope read | Ordinary for the title, reporting to a Finance Manager | `[inferred]` from the ad |
| Market calibration | Not run | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | high | none | 3 years fortnightly, 90 staff | `[grounded]` your CV | none |
| R2 | Irish PAYE/PRSI/USC | must_have | unclear | low | discovery | Not stated in your background | — | Confirm (question 1) |
| R3 | Strong Excel | must_have | direct | medium | none | Pivots and XLOOKUP, self-reported | `[grounded]` your statement | Optional: sample workbook |
| R4 | Payroll qualification | must_have | direct | high | none | Payroll Technician certificate, 2024 | `[grounded]` your CV | none |
| R5 | Starters and leavers | must_have | direct | high | none | Done at the hotel group | `[grounded]` your CV | none |
| R6 | Payroll-to-GL reconciliation | must_have | direct | high | none | Done monthly | `[grounded]` your CV | none |
| R7 | Pension changes | important | adjacent | low | capability | Watched, never run | `[grounded]` your statement | Gap queue G2 |

**Gap recovery queue**

- **G1 (R2, discovery):** Irish statutory deductions. Closed by confirming what jurisdiction your hotel group's payroll ran in, and what PAYE/PRSI/USC work you did.
- **G2 (R7, capability):** Pension changes. Closed by learning the employer's scheme rules and workflow before you start, or by asking for their pension provider's manual. Say plainly that you have not done this yet.

**Opportunity risk register**

- *Risk signal, low:* salary not market-checked, since web search was refused. Band-checking the €40,000 is the one thing I'd still like to do.
- *Unknown:* employer identity is established only by your own in-person interviews and the offer, not by an independent source.

**Application plan**

1. Before you reply, confirm the offer came from the same domain Marrowgate uses on its own website. Use that website's contact details if anything looks off.
2. Accept within five working days if that checks out.
3. Ask before starting: which payroll system they run, the pension scheme and its provider, and whether they run PAYE/PRSI/USC in-house.
4. Interview and reframing: lead with the payroll cycles, starters and leavers and reconciliation you've run. Don't claim pension experience. Say you haven't run pension changes, and what you've done to prepare.

**Evidence status**

- Research tier: L1, searches 2 of 5, fetches 0 of 2. Web search was refused by permission, so both attempts count and no page was read.
- L1 target 1, the company's official site and careers page: `unavailable`, search permission refused.
- L1 target 2, role-family sweep for salary and title: `unavailable`, search permission refused.
- L1 target 3, hiring manager's public footprint: `skipped`, not attempted once search was refused.

**Upgrade menu**

- Enable web search: confirms Marrowgate's careers page, the offer domain, and Declan Garvagh's role, and checks €40,000 against the market.
- A CV line on Irish PAYE/PRSI/USC: raises R2 from unclear to direct.
- A sample reconciliation or Excel workbook: raises R3 to high.

**Questions**

1. Did you run Irish PAYE, PRSI and USC yourself at the hotel group, or was it another jurisdiction?
2. Can you commit to two days a week in the Limerick office?
3. May I search the web to check Marrowgate, the offer's domain and the salary band? You can say no.

If you'd like this kept as a file, I can emit it as a `tuesday-dossier.md` with the full report.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.