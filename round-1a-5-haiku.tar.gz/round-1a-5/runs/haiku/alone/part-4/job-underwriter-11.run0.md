**Duinvaart Cold Chain (Operations Analyst): worth your time, with conditions. `conditional_go`**
**Kroonhaven Foods (Supply Planner): not worth your application effort. `no_go`**

## Duinvaart Cold Chain: Operations Analyst

**Fit ledger.**

- `hard_gate`: unclear: D1 (Hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: D2, D3, D4
- `important`: direct: D5, D7; unclear: D6 (Temperature compliance tracking)
- `preferred`: adjacent: D8 (Dutch a plus)

D2–D4 are your daily work. D6 is the new area in this role. D8 is conversational against a "plus".

**Opportunity ledger.** The role is clearly scoped: responsibilities and tools are named (DR3). The salary is not stated (DR2), and I could not check that the employer exists as described (DR1).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting appears on the company's own careers page (DR1); (2) the three-day Rotterdam schedule works with your commute and any constraints you hold (D1); (3) temperature compliance is presented as a new area you are learning, not as experience you have (D6).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Scope read | Analyst role with reporting and recommendation duties; no decision rights stated | `[inferred]` from the tasks named |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Market calibration | Not run; no search was available, so there is no salary or scope norm for this role | — |
| Salary | Not stated | `[grounded]` posting |
| Unknowns | Whether the employer and posting are live; salary; who owns the temperature data; who decides route changes | — |
| Contradictions | None within the posting | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | low | hard_gate | Your commute and location were not in your background; I can't assess it | `[grounded]` posting; your location not given | Confirm you can meet the schedule |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background | Add dates to the CV |
| D3 | Strong SQL | must_have | direct | medium | none | SQL used daily | `[grounded]` your background | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily, including the on-time delivery dashboard | `[grounded]` your background | none |
| D5 | On-time delivery tracking (responsibility) | important | direct | medium | none | Same measure as the dashboard depot managers use | `[grounded]` your background | none |
| D6 | Temperature compliance tracking (refrigerated fleet) | important | unclear | low | discovery | Nothing on temperature or cold-chain data in your background; a parcel carrier may have handled some temperature-sensitive shipments | `[inferred]` from the gap between the posting and your background | Question Q1 |
| D7 | Working with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| D8 | Dutch (a plus) | preferred | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (D6) | discovery | No temperature or cold-chain data in your background | It's the one responsibility you have not shown | Any work with temperature logs, sensor data, or time-sensitive goods, at the carrier or elsewhere | A sanitized example of a temperature or delivery-window report | `[inferred]` from your background |
| G2 | Dutch (D8) | capability | Conversational | Posted as a plus, so it's a tiebreaker | A Dutch course, or work conducted in Dutch | A certificate or a short Dutch-language sample | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer and posting not verified | unknown | — | (posting header) | The posting may be live on the company's site, but I could not confirm it from here | — | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| DR2 | Salary not stated | unknown | — | "Hybrid, three days a week" (no pay given) | The pay may sit below your expectation for this scope | `[inferred]` from the withheld figure | What salary is budgeted for this role? | unresolved |
| DR3 | Responsibilities and tools named | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The role's scope is defined and measurable | `[grounded]` posting | Who owns the temperature data today? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed CV line: "Ran the weekly route-performance review with depot managers; used Power BI and SQL daily, including the on-time delivery dashboard depot managers rely on." | D4, D5, D7. Wording avoids "built", which you did not say | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Confirm the posting on the company's own careers page before applying | DR1 | `[grounded]` DR1 | pending your approval |

### Evidence status

Verified: none yet.

## Kroonhaven Foods: Supply Planner

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K4 (Running a weekly S&OP-style review), K7 (Fluent Dutch); unclear: K5 (Advanced Excel); absent: K2 (3+ years of FMCG planning), K3 (Owning a 13-week supply plan), K6 (SAP IBP or similar)

Three must-haves are absent: planning experience (K2), planning ownership (K3), and a planning system (K6). I'd need years of planning work to close those.

**Opportunity ledger.** The role is clearly scoped (KR1). The salary is not stated (KR2), and I could not check that the employer exists as described (KR3).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** the facts that would have to differ are K2 and K6, both 3+ years of FMCG planning and hands-on planning-system work. Whether a planning-adjacent role at this company would be open to you is a question for the recruiter, not a fact I can check.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance production capacity against the forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Scope read | Planning-owner role, mid-level by the 3+ years asked | `[inferred]` from "own" and the experience asked |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Market calibration | Not run; no search was available | — |
| Salary | Not stated | `[grounded]` posting |
| Unknowns | Which planning system is in use beyond "IBP or similar"; who owns production capacity | — |
| Contradictions | None within the posting | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | Your location and commute were not in your background | `[grounded]` posting | Confirm you can be on-site |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | high | capability | You have never worked in planning | `[grounded]` your statement | none (closure requires time) |
| K3 | Owning a 13-week supply plan and balancing capacity against forecast | must_have | absent | high | capability | No planning ownership or capacity work in your background | `[grounded]` your background | Question Q2 |
| K4 | Running a weekly S&OP-style review | must_have | adjacent | medium | transferability | You ran the weekly route-performance review; the cadence matches, the content (production, forecast) does not | `[grounded]` your background | none |
| K5 | Advanced Excel | must_have | unclear | low | discovery | Excel is not in your background; SQL and Power BI are | `[grounded]` your background | Excel level, upgrade menu |
| K6 | SAP IBP or a similar planning system | must_have | absent | high | capability | No planning-system use in your background | `[grounded]` your background | none (closure requires time) |
| K7 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning ownership (K2, K3) | capability | No forecasting, capacity or planning work in your background | Two must-haves, and the core of the job | Any forecasting, capacity, or volume planning, even small | A sanitized forecast or capacity sheet | `[grounded]` your background |
| G4 | Planning system (K6) | capability | None stated | A must-have, and a platform skill that takes time | Any ERP planning module use | A training certificate | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Scope and responsibilities clear | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The role's ownership is defined | `[grounded]` posting | Which planning decisions does this role own alone? | noted |
| KR2 | Salary not stated | unknown | — | (posting silent on pay) | The pay may be below your expectation | `[inferred]` from the withheld figure | What salary is budgeted for this role? | unresolved |
| KR3 | Employer and posting not verified | unknown | — | (posting header) | The posting may be live on the company's site, but I could not confirm it from here | — | Can you point me to this role on your own careers page? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-A1 | Skip this application | K2, K3, K6 are absent must-haves with no near-term closure | `[grounded]` evidence map | pending your approval |
| K-A2 | Look for demand-analyst or supply-analyst roles, which use your SQL, Power BI and review experience, rather than planner roles | Closer to your evidence | `[generic]` role-family pattern | pending your approval |

### Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Search permission was denied by the host. Neither employer's existence nor either posting's liveness is checked (DR1, KR3) |
| 2. Role-family sweep (both roles) | unavailable | Search permission was denied. No salary band or scope norm for either role (DR2, KR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

If search access is granted, the two rows above would run.

Dossier offer: I can write both assessments to a `tuesday-dossier.md` file, with the evidence map and questions kept for interview prep.

**Upgrade menu**

- A link to each posting → confirms the employer and posting (DR1, KR3) and enables the salary check (DR2, KR2) if search is available.
- Whether you built the on-time delivery dashboard or used it → makes E1 precise and lifts D4 and D5 to `high` confidence.
- A sanitized dashboard screenshot or report → lifts D2–D5 from `medium` to `high`.
- Your Excel level → settles K5 (the decision for Kroonhaven is unaffected).
- Your location and commute → settles D1 and K1.

**Questions**

1. (D6) Have you tracked or handled temperature-sensitive shipments, or temperature or sensor logs, at the carrier or anywhere else?
2. (K3) Have you done any forecasting, capacity or volume planning, even in part, including in an ERP planning module?
3. (D4) Did you build the on-time delivery dashboard, or use it and maintain it?

Answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.