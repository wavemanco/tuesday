## Decision snapshot

**Worth taking the call. Status: `conditional_go`.** Your craft evidence lines up well with the posting. The real gaps are being the only designer and the audience and domain, and the company itself is not yet verified.

**Fit ledger.**

- `hard_gate` — direct: R8 · unclear: R9
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5
- `important` — adjacent: R6 · absent: R7
- `preferred` — none listed

R5 (`adjacent`, `medium`) is a credible bridge with its limit named: checkout is one stage of a booking flow, not the whole flow. R7 (`absent`) is the gap most likely to come up on the call.

**Opportunity ledger.** Concrete on the terms (scope, pay, hybrid pattern, a CTO in the process) but under-evidenced on the company itself. Nothing in the posting or the WhatsApp message is a red flag: no payment or deposit requests, no bank or ID details before an offer, and no hiring wholly by chat. Your candidate stage is interviewing, and the call is the next step.

- **Hard gates:** none failed; met: R8 `direct`; unconfirmed: R9 (your pay floor was not given, so the check against it is unknown).
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Confirm Fernquay exists as described, through its own site or careers page and the domain of the calendar invite (RR1). This is the cap: research could not run, so `go` stays out of reach until this is checked.
  2. Check €52,000–€60,000 plus 0.5–1% equity against your floor and the vesting terms (R9, RR3).
  3. Get a straight answer on who sets priorities and what research budget a first designer gets (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week at the Galway office, otherwise remote | `[grounded]` posting; fits your location |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; vesting and share class not stated | `[grounded]` posting |
| Scope read | A single-designer role at a very small company. The scope is broad for the title, with no design peers | `[inferred]` from "first designer" against "two engineers" and a co-founder as main counterpart |
| Market calibration | Not established. No role-family sweep ran, so no band can be cited for pay, equity or scope | — |
| Contact channel | A co-founder messaging you on WhatsApp to schedule a video call, with a calendar invite sent by email. Scheduling by chat is routine. What matters is whether the invite and the company check out, not the app | `[grounded]` message; no entry in the risk register |
| Unknowns | Whether the company exists as described, its funding or revenue, the actual share class, the research budget, who decides priorities | — |
| Contradictions | None found within what was provided. Nothing could be checked online | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company | `[grounded]` your CV; unverified | none |
| R2 | Strong Figma | must_have | direct | medium | none | Figma daily, stated | `[grounded]` your statement | none |
| R3 | Has run own user research | must_have | direct | medium | transferability | Monthly usability sessions with customers. The posting's audience is school owners, a different buyer | `[grounded]` your statement; audience gap `[inferred]` | G2 |
| R4 | Works directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your statement | none |
| R5 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Checkout is the end of a booking, and end-to-end ownership is not shown | `[grounded]` your statement; the adjacency is `[inferred]` | G1 |
| R6 | Sea-kayak and surf school workflows (implied by the product, not a listed requirement) | important | adjacent | low | transferability | Travel booking shares inventory, availability and payments with activity operators. Operator-side workflows are not shown | `[inferred]` from the product description | G4 |
| R7 | Working as the only designer | important | absent | high | capability | "Never been the only designer anywhere" — your own statement | `[grounded]` your statement | G3 |
| R8 | Location: Galway, two days a week in office | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R9 | Pay floor against €52,000–€60,000 | hard_gate | unclear | none | none | No floor given, so the check is unknown | — | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the flow end to end (R5, must_have) | transferability | Checkout redesign; no account of owning discovery through launch of a whole flow | A must-have, and the one most likely to be probed | Any flow you drove from brief to launch, even inside a squad | A checkout case study that names your decisions and the launch outcome | `[inferred]` from the checkout claim |
| G2 | Research with school owners (R3, must_have) | transferability | Method is strong (monthly sessions); audience is consumers, not operators | The posting names this work explicitly | Any interviews with small-business owners or B2B buyers | Session plan or a sanitized findings summary from the usability sessions | `[inferred]` |
| G3 | Sole designer (R7, important) | capability | No evidence of working without a design peer | Likely to be the central concern for a first hire | A time you set direction with engineers and no design review | A decision you drove alone and what happened | `[grounded]` your statement |
| G4 | Operator domain (R6, important) | transferability | Travel booking is adjacent, not the same | Affects how fast you can run school-owner research | Any work with inventory, scheduling or seasonal capacity | Notes from any operator conversations | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer existence not confirmed; research could not run | risk_signal | medium | "We are six people in Galway" | Reasons side by side, none ranked as likely: the company is too new or small to have a footprint; the posting is stale; it is not a real hiring employer. Standing entry, caps the decision at `conditional_go` | `[inferred]` from the failed check and your report that little appears online | Can you link the live posting on Fernquay's own site or careers page? Does the calendar invite come from the company's own domain? | unresolved |
| RR2 | Decision rights and research budget unstated | unknown | — | "You would be our first designer" | Scope may outrun authority and budget: the role owns the flow, but priorities and research time may sit with the co-founder | `[inferred]` from "first designer" against "two engineers" and no budget line | Who sets priorities for the booking flow, and what research time and budget would a first designer get? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Equity value depends on vesting, share class and dilution, none of which are given | `[grounded]` posting | What are the vesting terms and share class, and is 0.5–1% a range you would negotiate? | unresolved |
| RR4 | Pay and equity package against your floor | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | Whether the package clears your floor depends on a number you have not given | `[grounded]` posting; floor not given | Q2 | unresolved |
| RR5 | Informal, work-over-polish hiring signal | positive_signal | — | "we would rather see one messy real project than a polished deck" | The company says how it judges candidates, and your checkout case study is the kind of evidence it asks for | `[inferred]` | none | noted |
| RR6 | Concrete process: a CTO in the interview loop, a stated scope and salary | positive_signal | — | "Could you do a 45-minute video call with me and Saoirse, our CTO?" | The process has technical and product review, not a single sign-off | `[grounded]` message | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the live posting on Fernquay's own site or careers page. Check that the calendar invite's sender domain matches it | RR1 | `[grounded]` RR1 | your action (a check, not a send) |
| A2 | Take the call. Reply on WhatsApp only to confirm the time; keep anything substantive on email | Keeps a written record | `[generic]` common practice | your action |
| A3 | Lead with checkout, framed exactly: redesigned the checkout flow, ran monthly usability sessions with customers, worked in a squad of four engineers. Do not say "owned the booking flow end to end" | R5, R3; the reframing audit rules out inflating ownership | `[grounded]` your CV | pending your approval |
| A4 | Ask on the call: who sets priorities; the research budget; the first 90 days; vesting and share class; how many paying schools they have | RR2, RR3, RR1 | `[grounded]` register | pending your approval |
| A5 | Name the gaps first: no end-to-end flow owned, no operator research yet, and no experience being the only designer. Give one concrete example for each | R5, R7, R3 | `[grounded]` gap queue | pending your approval |
| A6 | For call rehearsal, mock-interview is the sibling skill; this assessment does not cover it | Scope | — | your choice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two web searches were sent and refused, so the check could not run. It would have confirmed that Fernquay exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the pay and equity package against a role-family band, which is currently not established |
| 3. Hiring manager's public footprint | unavailable | The co-founder's name was given, but the search was refused. It would have checked Ronan Kehoe's public professional footprint against the company's claims |

## Dossier offer

I can write this assessment to a `tuesday-dossier.md` file if you want to keep it for the interview stage.

## Upgrade menu

- A live posting link from Fernquay's own site or careers page → RR1 closes or narrows, and the decision can move toward `go`
- The domain of the calendar invite's sender → RR1 closes on the company side
- Your pay floor → R9 and RR4 close
- A checkout case study link with your decisions named → R5 moves toward `high` confidence
- Enabling web research in a later session → the three unavailable targets run, and the market calibration and the company check become sourced rather than unestablished
- A deeper pass on Fernquay (funding, past customers, leadership changes; up to 5 more searches and 2 more fetches) → offered once, runs on your say-so

## Questions

1. **(RR1)** Do you have a link to Fernquay's live posting, or can you tell me the domain the calendar invite came from?
2. **(RR4, R9)** What is your pay floor, and how much does the equity matter to you?
3. **(G1)** Have you ever taken a flow from brief to launch yourself, or was checkout always one part of a larger team's work?

You can answer in prose, or skip any question; a skip is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.