**Decision:** `conditional_go`. The role fits your evidence well on paper. The company's legitimacy is unverified, and that caps the decision until you check it.

**Fit ledger** (fit is my read of your stated evidence, not a score)
- **Strong:** 3+ years of product design [grounded, your CV]; daily Figma use [grounded]; you've run research with customers through monthly usability sessions [grounded]; you've worked in a squad with four engineers [grounded].
- **Partial:** owning the booking flow end to end. You redesigned checkout, but the posting asks for ownership of the whole flow and you haven't stated that you owned it all [inferred].
- **Gap:** being the only designer. You've never done it [grounded, your statement]. This is a capability gap, and it's the one most likely to matter in the first months.
- **Gap:** research with school owners. Your research has been with travel customers, so this is a transferable skill with a different audience [inferred].

**Hard gates:** None failed. The hybrid pattern (two days in Galway) fits you, since you live there [grounded]. Your pay floor isn't stated, so the salary check is unverified.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

Web search wasn't permitted in this session, so I have no results on Fernquay, Ronan Kehoe, Saoirse, or market pay. Everything below about the company is unverified. I'm not treating that as a finding that it's fake. Nothing I found says it isn't real.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Web search not permitted |
| 2 | Role-family sweep (scope, title, pay for Galway product designers) | unavailable | Web search not permitted |
| 3 | Hiring manager's public professional footprint (Ronan Kehoe) | unavailable | Web search not permitted |

**Role reality**
- Six-person Galway company making booking software for sea-kayak and surf schools [grounded, posting].
- Salary €52,000–€60,000 plus 0.5–1% equity [grounded, posting].
- Pay band against the market: not calibrated; no research ran [generic only].
- The posting's stated tone (informal, portfolio over deck) fits a very early-stage company.

**Opportunity risk register**

| Class | Item | Severity | Notes |
|---|---|---|---|
| Verification | Employer existence unconfirmed | medium | Three reasons fit equally and none is ranked: too new or small; a stale posting; not a real hiring employer. Caps this at `conditional_go` until resolved. |
| Role structure | Solo first designer, no design peers | medium | Self-directed work with no design review. |
| Terms | Equity 0.5–1% with no vesting, strike price or share class stated | medium | Ask before accepting anything. |
| Contact | Scheduling by WhatsApp | low | Routine for scheduling. Not a red flag by itself, but check the calendar invite's sender domain. |

**What would resolve the verification item** (you can do these now, without me):
1. Look up the company's registered name on the Irish CRO register (cro.ie). Check it exists and see who the directors are.
2. Check the company has a working website that describes the product and team.
3. Ask Ronan for the live posting link and the registered company name.
4. Check that the calendar invite came from a company email domain that matches the website.
5. Check LinkedIn for Ronan Kehoe and for Saoirse as CTO.

Don't share bank, tax or ID details, and don't pay for anything, before a written offer.

**Application plan**
- Lead with the checkout redesign, the monthly customer research, and working in a four-engineer squad. Those are your verified strengths.
- Don't claim you owned the booking flow end to end unless you did. Describe what you actually owned.
- For the video call, prepare an answer on how you'd work without design review, and how you'd approach research with school owners. The skill `mock-interview` can help you rehearse that once the call is booked.

**Dossier offer:** If you'd like, I can write this assessment to `tuesday-dossier.md`, so later prep can pick it up.

**Upgrade menu** (what each missing input would unlock)
- The live posting link or the company's careers page: confirms the role is current and resolves the verification item.
- The registered company name: lets you check the CRO register directly.
- Web search permission: would let me check the company, Ronan and Saoirse's public footprint, and Galway product-designer pay.
- Your current salary or pay floor: lets me check the offer against your hard limit.
- Your portfolio or the checkout case study Ronan liked: moves your Figma and ownership claims from CV-only to reviewable.

**Questions**
1. Where did you see the posting, and do you have the live link?
2. What's your pay floor, and would €52–60k plus equity meet it?
3. Have you ever done research with owners of small businesses rather than consumers?

Answer any or all, or reply "skip" to any of them. The skill's response options are the same either way.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.