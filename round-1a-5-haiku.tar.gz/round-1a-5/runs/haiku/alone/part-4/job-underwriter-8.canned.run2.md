## Decision: no_go as presented. Send nothing.

Don't send your IBAN, PPS number, passport, or any payment, and don't deposit or transfer against the cheque. Velloway's hiring process has several red flags that each stand on their own (below). I can't confirm from here that Velloway Logistics exists as described, and I haven't searched for it.

**Hard gates:** pay floor of €30,000/yr is **at risk**. The posting says "up to €26/hour plus commission," and the commission isn't stated.

## Red flags (quoted from the posting and messages)

| # | Flag | Quote | Severity |
|---|---|---|---|
| R1 | Asks you to pay for equipment before any wages | "Please pay €349 by bank transfer to our equipment partner" | high, confirmed |
| R2 | Asks you to deposit a cheque and send most of it on | "Lodge it to your account… transfer the rest to our equipment partner" | high, confirmed |
| R3 | Asks for bank, tax and ID details before an interview or written offer | "send your IBAN, your PPS number and a clear photo of your passport" | high, confirmed |
| R4 | Hiring conducted entirely by chat, with no call, video, or written contract | "Our whole hiring process runs on Telegram" | high, confirmed |

**Why R2 matters:** a cheque can be returned unpaid days or weeks after you've deposited it and transferred money from your own account. You would then owe the amount you sent. The €2,850 cheque and the €349 demand both ask you to move your own money to a third party, which is the usual way this structure costs the person paying.

Per the skill's rules, these flags are facts about the posting and messages, not a finding about who is behind them. To check the employer, use contact details from Velloway's own website, not @VellowayHiring or velloway.hr@postmail.example.

## Role reality

- **Role:** Remote Order Processing Coordinator, Velloway Logistics. 15–30 hrs/week, "up to €26/hour plus commission," "no experience needed," training provided.
- **Pay arithmetic** [inferred]: at €26/hour, 15 hrs/week is about €20,300/yr and 30 hrs/week is about €40,600/yr. Reaching €30,000 takes about 22 hrs/week at the full rate, before any commission. The rate is a ceiling ("up to"), so the real base is unknown.
- **Unstated:** the commission structure, the contract type, and whether payroll is through a registered employer.

## Fit ledger (CV-only, so claims are leads, not proof)

| Priority | Fit | Requirement | Evidence from your background | Confidence |
|---|---|---|---|---|
| must | fits | Attention to detail | ~60 Zendesk tickets/day as a parcel courier agent | medium (CV-only) |
| must | fits | Spreadsheets | Keep your team's weekly tracker in Excel | medium (CV-only) |
| preferred | transferable | Order processing | No direct order-processing evidence; parcel-courier operations are adjacent | low |
| preferred | unknown | Good written English | Not evidenced in what you've shared | unknown |
| must (candidate gate) | at risk | Pay ≥ €30,000/yr | See pay arithmetic above | not verifiable from posting |
| unknown | unknown | Quiet place to work | Your own setup, not a gate | unknown |

## Gap recovery queue

- **Pay floor:** closed only by a written, employer-stated base and commission. Nothing in the posting closes it.
- **Order-processing specifics:** closed by a real job description from a verified employer.
- **Written English:** closed by a writing sample or a reference, if you choose to share one.

## Application plan

1. Don't apply through @VellowayHiring. Don't send any of the requested details.
2. If you want to pursue it, find Velloway's official site or careers page yourself. Contact them through that channel and ask for a written offer and job description.
3. If a genuine role of this kind appears, your strongest evidence is the Zendesk volume, the Excel tracker, and training two new starters. Lead with those, and describe them as you did above.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Velloway official site and careers page | skipped | No search consent at L0 |
| 2 | Role-family sweep (pay and scope) | skipped | No search consent at L0 |
| 3 | Hiring manager public footprint | n/a | No name given |

Velloway's existence is unverified. Until it's confirmed, this entry in the risk register stays open at **medium**.

I can run L1 research if you agree.

Dossier offer: I can write a `tuesday-dossier.md` capturing this assessment so it carries into later interview prep.

**Upgrade menu** (what each input would unlock):
- Link to the original listing on the jobs site: lets me check where the posting came from and whether it's consistent elsewhere.
- Your pay floor broken down (base, hours, and commission assumptions): lets me test the €30k gate against real figures.
- L1 research on Velloway (up to 5 searches, 2 page fetches): checks whether the company exists as described and whether the pay band is typical for this role.

**Questions** (response modes: reply yes, no, or skip to each; skipping is fine):
1. May I run L1 research on Velloway Logistics?
2. Do you have the link to the original listing?
3. Is €30,000 a hard floor for base pay, or would you consider a lower base with commission?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.