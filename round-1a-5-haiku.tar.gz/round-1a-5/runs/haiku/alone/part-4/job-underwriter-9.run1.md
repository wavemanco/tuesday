**Status: `conditional_go`.** Yes, asking for bank details, PPS number and a passport scan after a written offer is normal, and this offer is a credible one. Your rule still applies to the stages before an offer, to anything asked by chat, and to details sent to a personal address. Accept once the two checks below come back clean.

**Fit ledger.**

- `hard_gate`: unclear: R1 (right to work in Ireland), R2 (Limerick office, two days a week), R3 (pay floor). You haven't stated these, so they are unchecked.
- `must_have`: direct: R4 (2+ years running payroll), R6 (strong Excel), R7 (payroll qualification), R8 (starters and leavers), R9 (payroll-to-ledger reconciliation) · adjacent: R10 (pension changes) · unclear: R5 (Irish PAYE, PRSI and USC)

R10 — adjacent, your starter and leaver work is the same process, but you haven't run pension changes; R5 — unclear, no evidence either way yet.

**Opportunity ledger.** The offer matches the advertised terms: €40,000 sits inside the posted €38,000–42,000, hybrid is as advertised, and the reporting line is named (RR2 positive, RR3 positive). Two interviews held at their office is a positive signal. The open items are the scale jump from 90 to 240 staff (RR4) and the unstated pension scheme (RR5). I could not confirm the employer from outside sources (see the evidence status).

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (Limerick office, two days a week), R3 (pay floor); met: none; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your right to work and the Limerick commute confirmed by you (R1, R2); (2) the post confirmed on the employer's own website, and the offer's email domain matches that site (RR1).
- **What would change this:** a right-to-work or commute problem would make R1 or R2 a failed gate and move the status to `no_go`; a pension scheme you can't learn quickly would lower R10.

**Role reality** (all `[generic]` unless noted; no outside research ran)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Housing association, Limerick, about 240 staff | `[grounded]` posting |
| Scope | Full monthly run, starters and leavers, pension changes, reconciliation, staff queries | `[grounded]` posting |
| Pay | €40,000 offered; posted band €38,000–42,000 | `[grounded]` offer and posting |
| Market calibration | €40,000 is a normal figure for a payroll administrator with your experience; the band is a pattern, not their offer | `[generic]` no sweep ran; the band is from the posting |
| Unknowns | Pension schemes, payroll system, support in the first 90 days, your right to work | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland | hard_gate | unclear | medium | hard_gate | You haven't stated this; the offer's passport check makes it a gate | `[grounded]` offer | Q2 below |
| R2 | Limerick office, two days a week | hard_gate | unclear | medium | hard_gate | Commute and location not stated | `[grounded]` posting | Q2 below |
| R3 | Pay floor | hard_gate | unclear | medium | hard_gate | Your floor isn't stated; €40k is inside the band | `[grounded]` offer | Tell me your floor |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years, fortnightly, 90 staff; self-reported | `[grounded]` your background | none |
| R5 | Working knowledge of PAYE, PRSI and USC | must_have | unclear | low | discovery | Not mentioned | `[grounded]` silence | Q1 below |
| R6 | Strong Excel | must_have | direct | medium | none | Pivots and XLOOKUP stated | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R8 | Starters and leavers | must_have | direct | medium | none | Stated | `[grounded]` your background | none |
| R9 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated | `[grounded]` your background | none |
| R10 | Pension changes | must_have | adjacent | low | transferability | Same change process as starters and leavers; no pension changes run yourself | `[inferred]` from R8 | Q3 below |

**Gap recovery queue** (questions are in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R5) | discovery | Nothing on PAYE, PRSI or USC in your background | A must-have; a strong answer moves it to `direct` | Calculations you checked, payslip queries you answered, a payroll system's deduction settings | A payslip sample (anonymised) or a deduction check you ran | `[generic]` that the role probes this line |
| G2 | Pension changes (R10) | transferability | Starters and leavers work; no pension changes | The transferable case has a limit: scheme rules are a separate skill | Pension deduction checks, enrolment forms, scheme queries you saw | Scheme booklet, a rule summary | `[inferred]` from R8 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from outside sources | risk_signal | medium | "Marrowgate Housing" from the offer | The employer may be small or new, or may not be the entity it names; the interviews point the other way | `[generic]` pattern for companies of this size, not a claim about this one | "Which page on your website lists this post, and who would I report to?" | unresolved |
| RR2 | Reporting line stated | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | Clear line of management | `[grounded]` offer | "Will Declan set my first-90-day targets?" | noted |
| RR3 | Hybrid terms and pay match the posting | positive_signal | — | "€40,000 … two days a week in our Limerick office" | Terms as advertised | `[grounded]` offer and posting | "Is the Limerick attendance fixed or by team agreement?" | noted |
| RR4 | Scale: 240 staff against your 90 | unknown | — | "240 staff" | The job may need a larger system or team than you have run | `[inferred]` from the posting's scope | "What payroll system and pay groups will I run, and what support is there?" | unresolved |
| RR5 | Pension schemes unstated | unknown | — | "pension changes" | The scheme rules may be complex and new to you | `[inferred]` from the posting's silence | "Which pension schemes does payroll run, and who answers scheme queries?" | unresolved |

**Routine steps (no entry, no condition):** the portal link, the bank, PPS and passport requests, and the original passport on day one. These are standard after a written offer. Check them, not the request:

- Enter details only in the portal at the address shown on the employer's own website, not a link that differs from it.
- Send nothing by plain email or chat.
- Share only what the portal asks for. If it asks for more, ask why first.

**Application plan** (proposed; nothing is sent without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the posting on the employer's own website, and that the offer email's domain matches it | RR1 | `[generic]` checking the employer's domain | pending your approval |
| P2 | Accept in writing within five working days, after P1 | Offer deadline | `[grounded]` offer | pending your approval |
| P3 | Ask Declan for the pension scheme list and payroll system before the start date | RR4, RR5, R10 | `[generic]` | pending your approval |
| P4 | Refresh PAYE, PRSI and USC against published guidance before day one | R5 | `[generic]` | pending your approval |

**Evidence status**

Verified: none yet. Your stated background is CV-equivalent prose, so it stays at `medium`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches (Marrowgate Housing Limerick; Marrowgate Housing careers payroll administrator; payroll administrator salary Limerick Ireland) were refused by the host's permission setting, so no result. Would have checked RR1 and the posting's status |
| 2. Role-family sweep | unavailable | Same refused call. Would have set the market calibration |
| 3. Hiring manager's public footprint | unavailable | No search sent; the host refused search. Would have checked Declan Garvagh's public role for positioning |

**Upgrade menu**

- Your right to work and Limerick commute → R1 and R2 move from `unclear` to `direct`; the status can move to `go`.
- Your PAYE, PRSI and USC experience, with an example → R5 moves up and G1 closes.
- The pension scheme list → RR5 closes, and R10's fit can improve.
- The employer's website page for this post → RR1 closes. If you allow searches, I can run the three checks that were refused.
- Your pay floor → R3 closes.

If you want, I can write this into a `tuesday-dossier.md` you can keep.

**Questions**

- **R1, R2** — Do you have the right to work in Ireland without sponsorship, and can you do two days a week in Limerick?
- **G1, R5** — How would you describe your working knowledge of PAYE, PRSI and USC: have you run them end to end, or only checked the output of a payroll system?
- **G2, R10** — Did you ever check pension deductions or contribution changes, even as a reviewer, and how did you verify them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.