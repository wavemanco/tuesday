## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct R1, R2, R3 · unclear R4. No gate has failed.
- `must_have`: direct R5, R6, R8, R9 · adjacent R7, R10, R11 · unclear R13 · absent R12
- `important`: unclear R14
- `preferred`: absent R15

R12 (own caseload) is the real gap. R7 is a credible bridge, and R4 is unclear only because you haven't given a pay floor.

**Opportunity ledger.** The employer checks out as a real NHS-contracted community interest company. Pay sits inside the market band. The posting's own support statement (senior community nurse, pool cars) is a positive signal. The posting's live status is unconfirmed.

**Hard-gate line:** R1 direct, R2 direct (stated, not checked), R3 direct, R4 unclear (your pay floor not given).

## Role reality

- **Organization** [grounded, company about page]: Calderbrook Community Health CIC. Adult community nursing and therapy under an NHS contract across Calderdale. Founded 2015, 410 staff, four locality hubs.
- **Role** [grounded, advert]: Band 5 community staff nurse with a small caseload of your own, supported by a senior community nurse. Duties are wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all on an electronic patient record. Pool car provided, plus mileage.
- **Scope read** [inferred]: the duties are close to your current home-visit work. The step up is ownership of the caseload and the planning that goes with it.
- **Market calibration** [generic, one 2026 survey, England, n=1,240]: Band 5 community staff nurse median basic pay £34,300, interquartile range £32,400 to £36,600. 61% of respondents were paid mileage; 24% had a pool or lease car. The advert's £31,050 to £37,800 range sits inside that band.
- **Contact** [grounded, public forum speaker profile]: Rhiannon Mabbott leads the Halifax district nursing team. Her 2025 talk covered nurse-led leg-ulcer clinics and Doppler training for staff new to community work.
- **Doppler training offered here** [inferred from that talk; not confirmed for this post].
- **Contradictions:** none between the advert and the company's about page.

## Evidence map

| # | Priority | Fit | Requirement | Evidence (your CV) | Gap | Confidence |
|---|---|---|---|---|---|---|
| R1 | hard_gate | direct | NMC registration as Adult Nurse | Registered Adult Nurse, registration active, revalidation due March 2028 | none | medium |
| R2 | hard_gate | direct | Full UK driving licence | Full licence, category B (stated, not checked) | none | medium |
| R3 | hard_gate | direct | Based in Halifax | Live in Halifax | none | high |
| R4 | hard_gate | unclear | Pay | Advert gives £31,050 to £37,800 plus mileage; your floor not given | hard-gate | low |
| R5 | must_have | direct | At least one year post-registration | Five years as staff nurse | none | medium |
| R6 | must_have | direct | Wound care | Pressure ulcers and surgical wounds | none | medium |
| R7 | must_have | adjacent | Leg-ulcer care | Wound care transfers; no leg-ulcer work stated | transferability | low |
| R8 | must_have | direct | Catheter and continence care | Catheter care; continence not stated | none | medium |
| R9 | must_have | direct | Insulin administration | Insulin administration | none | medium |
| R10 | must_have | adjacent | Care planning | Discharge-to-assess planning, not owned by you | transferability | medium |
| R11 | must_have | adjacent | End-of-life visits | Home visits; no end-of-life work stated | transferability | low |
| R12 | must_have | absent | Own small caseload | Never held a caseload | capability | low |
| R13 | must_have | unclear | Clear, timely written records | No records sample | capability | low |
| R14 | important | unclear | Electronic patient record | System not named | discovery | low |
| R15 | preferred | absent | Doppler assessment | Never done | capability | high |

## Gap recovery queue

| Gap | Row | What closes it | Type |
|---|---|---|---|
| G1 | R12 | A described example of a patient list you planned and followed up yourself, even within discharge-to-assess | capability |
| G2 | R13 | A redacted note sample, or a description of how you record visits | capability |
| G3 | R7 | Any leg-ulcer assessment or compression work, ward or community | transferability |
| G4 | R15 | Confirmation that Doppler training is given, or your willingness to take it | capability |
| G5 | R4 | Your pay floor | hard-gate |
| G6 | R14 | The electronic record system you have used | discovery |

## Opportunity risk register

| ID | Class | Severity | Entry |
|---|---|---|---|
| RR1 | capability | medium | No caseload history. The advert's support statement is the mitigation, but unverified until the chat. |
| RR2 | hard-gate | low | Pay floor unknown; if your floor is above £37,800 the role fails. |
| RR3 | discovery | low | Posting live status not confirmed; the careers page was not reached. |
| RR4 | capability | low | Doppler is desirable, not essential. Gap is closable by training. |

Failed-attribution check: the employer exists as described, so no standing entry.

## Application plan

- **Lead with** your home visits in the first week after discharge, plus wound, catheter and insulin work. Say "home visits in the first week after discharge", not "community nursing experience" [grounded]. The reframing audit applies here: don't call the discharge work caseload experience.
- **Caseload:** state the gap plainly. Your answer to G1 decides what you say.
- **Doppler:** say you haven't done one and ask whether training is given. Don't claim competence.
- **Informal chat with Rhiannon Mabbott:** the posting's named channel. Two questions to bring: caseload support, and Doppler training.
- **Pay and mileage:** ask how mileage is paid in practice and whether pool cars are always available.
- **Any CV wording** I propose stays `resume_edits_pending_approval` until you approve it.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | yes | About page fetched and matched search results for "Calderbrook Community Health CIC Halifax". Careers page not reached, so the live posting is unconfirmed. |
| 2. Role-family sweep | yes | Wardround 2026 UK Community Nursing Pay Guide, Band 5 community staff nurse, England. |
| 3. Hiring manager's public footprint | yes | Search "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; communitynursingforum.example speaker profile. Public professional footprint only. |

L2 has not run. It is available if you want it.

**Dossier offer:** at the end of this engagement I can write the assessment to `tuesday-dossier.md`, if you want it kept.

## Upgrade menu

- **Live posting link or the careers page:** confirms the posting is live (RR3).
- **Your pay floor:** closes R4, the one unresolved hard gate.
- **L2 research, if you want it:** deeper company diligence (funding, leadership churn, candidate reports) and a recent-news sweep. Up to 5 more searches and 2 more fetches.
- **A redacted records sample or the EPR name:** closes R13 and R14.
- **Your own DVLA and NMC register checks:** you check these records; I don't use the licence or registration numbers.

## Questions

1. **G1 (R12):** On discharge-to-assess, did you ever hold a list of patients that you planned and followed up yourself? Roughly how many?
2. **G3 (R7):** Have you done leg-ulcer assessment or compression bandaging, on the ward or in the community?
3. **G2 (R13):** Which electronic record system have you used, and could you describe how you write up a visit?

Answer any or all, or reply "skip" to pass on one. Each answer comes back as a confirmation card before it changes the map.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.