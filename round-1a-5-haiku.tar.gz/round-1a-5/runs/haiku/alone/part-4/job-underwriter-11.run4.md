## Job 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

Yes, apply, on conditions. Your CV covers the core asks on paper. The open items are the three-day office schedule, whether the role is truly cold-chain, and the employer's posting, which I could not check.

**Decision snapshot — `conditional_go`**

**Fit ledger.**
- `hard_gate` — unclear: R1 (Hybrid, three days a week in the Rotterdam office)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — direct: R8; absent: R7 (Temperature compliance across the refrigerated fleet)
- `preferred` — adjacent: R9 (Dutch)

R1 — unconfirmed until your constraints are known; R7 — absent, no cold-chain or temperature data in your CV; R9 — conversational, which the posting calls a plus.

**Opportunity ledger.** The posting is specific and coherent: scope, outcomes and working pattern are stated (RR4). Salary is withheld (RR2), and it is unclear whether the role decides route changes or advises on them (RR3). The employer is unverified because research was unavailable, not because it failed a check.

- **Hard gates:** unconfirmed: R1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) three office days a week in Rotterdam work for you (R1); (2) the posting is live on Duinvaart's own careers page (RR1); (3) the interview confirms how temperature compliance is measured and whether you would learn that data (R7).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three office days a week in Rotterdam | `[grounded]` posting |
| Scope read | A normal analyst remit: measure, report, advise. Whether it also decides is unknown | `[inferred]` from the verbs |
| Market calibration | Not run. Research was unavailable, so there is no band for this role | — |
| Unknowns | Salary; decision rights on route changes; how temperature data is collected | — |
| Contradictions | None found in the posting; company site not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week in Rotterdam office | hard_gate | unclear | low | hard_gate | Your constraints weren't given, so this can't be checked | `[grounded]` posting | Q1 |
| R2 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier | `[grounded]` CV | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use stated in CV; no sample | `[grounded]` CV | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` CV | none |
| R5 | Track on-time delivery across the fleet | must_have | direct | medium | none | Your on-time dashboard was parcel delivery, not refrigerated; the metric transfers | `[grounded]` CV; `[inferred]` transfer | Q2 |
| R6 | Build weekly dashboards in Power BI | must_have | direct | medium | none | Your depot dashboard is the same kind of work | `[grounded]` CV | none |
| R7 | Temperature compliance across the refrigerated fleet | important | absent | low | capability | Nothing in your CV touches temperature data or cold chain | `[grounded]` posting; absence in CV | G1 |
| R8 | Work with depot managers on route changes | important | direct | medium | none | Route-performance review and depot manager work | `[grounded]` CV | none |
| R9 | Dutch (a plus) | preferred | adjacent | low | capability | Conversational, not fluent | `[grounded]` CV | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R7) | capability | No temperature or cold-chain data in CV | A named responsibility, likely part of the first-year measure | Any work with temperature logs, cold storage, or threshold alerts | A short description of how you tracked a compliance KPI | `[inferred]` |
| G2 | Dutch (R9) | capability | Conversational | Listed as a plus, not required | Dutch-language reporting or meetings | None needed for this decision | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Research could not confirm the employer, so this is unverified, not a finding against it | `[generic]` | Which page on your site carries this posting, and who would I report to? | unresolved |
| RR2 | Salary not stated | unknown | — | Posting silent on pay | The figure may be withheld until later in the process | `[inferred]` from silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | The role may advise while depot managers decide | `[inferred]` from the wording | On route changes, does this role recommend or decide, and who signs off? | unresolved |
| RR4 | Clear scope and measurable outcomes | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The role is defined and measurable | `[grounded]` posting | What does success look like at 90 days? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the on-time delivery dashboard first on your CV, in your own words | Closest match to R5 | `[grounded]` CV | pending your approval |
| E2 | Confirm whether you built or maintained that dashboard before you write it down | Your wording must match what you did | `[grounded]` CV: "the dashboard our depot managers use" | pending your approval |
| A1 | Find the posting on Duinvaart's own careers page before applying | Verifies RR1 | `[generic]` | pending your approval |
| A2 | Ask RR3 and RR2 verbatim in the first interview | Decision rights and pay are the two unknowns that matter most | `[grounded]` register | pending your approval |

---

## Job 2: Supply Planner, Kroonhaven Foods, Utrecht

No, not as a planner. Apply only if you find a planning role that doesn't require three years of FMCG planning experience.

**Decision snapshot — `no_go`**

**Fit ledger.**
- `hard_gate` — unclear: R1 (On-site in Utrecht)
- `must_have` — adjacent: R4 (Balance production capacity against forecast), R5 (Run weekly S&OP meeting), R8 (Fluent Dutch); unclear: R7 (Advanced Excel); absent: R2 (3+ years FMCG planning), R3 (Own a 13-week supply plan), R6 (SAP IBP or similar)

R2, R3, R6 — absent, with no closure you can make in this search; R4, R5 — adjacent, through your route capacity and review work; R8 — conversational Dutch against a fluent requirement; R7 — unknown until you tell me your Excel level.

**Opportunity ledger.** The posting is sound: scope and process are stated (RR3), and salary is withheld (RR2). The problem is the fit, not the job. Employer verification was unavailable, as with Job 1 (RR1).

- **Hard gates:** unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** three years of FMCG planning, or hands-on use of a planning system like SAP IBP. Neither is true now, and neither is closable in this search.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning owner role; the S&OP meeting makes it cross-functional | `[inferred]` from the verbs |
| Market calibration | Not run; research was unavailable | — |
| Unknowns | Salary; team size; the planning system in use | — |
| Contradictions | None found in the posting; company site not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | Your constraints weren't given | `[grounded]` posting | Q1 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | high | capability | You have never worked in planning | `[grounded]` CV and your statement | G1 |
| R3 | Own a 13-week supply plan | must_have | absent | high | capability | No planning ownership | `[grounded]` CV | G1 |
| R4 | Balance production capacity against forecast | must_have | adjacent | low | transferability | Route capacity and volume work, not production | `[inferred]` from route work | none |
| R5 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review | `[grounded]` CV | none |
| R6 | SAP IBP or similar planning system | must_have | absent | high | capability | No planning system use stated | `[grounded]` CV | G2 |
| R7 | Advanced Excel | must_have | unclear | low | discovery | CV names SQL and Power BI; Excel not mentioned | `[grounded]` CV silence | G4 |
| R8 | Fluent Dutch | must_have | adjacent | low | capability | Conversational, not fluent | `[grounded]` CV | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years FMCG planning (R2, R3) | capability | No planning ownership | Years of experience can't be added by a CV edit | Actual volume forecasts, capacity plans, or planning meetings you ran | Any planning-type output you produced | `[generic]` that FMCG planning expects years of practice |
| G2 | SAP IBP or similar (R6) | capability | No planning system use | A named tool requirement | Any planning software you've used | None; training is months, not a CV line | `[generic]` |
| G3 | Fluent Dutch (R8) | capability | Conversational | A must-have level, and the meeting is in Dutch | Dutch-language work | None | `[grounded]` posting |
| G4 | Advanced Excel (R7) | discovery | Not in CV | Could be a quick close | Your real Excel level | A short description | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Kroonhaven Foods, Utrecht" | Research could not confirm the employer; unverified, not a finding | `[generic]` | Which page on your site carries this posting, and who would I report to? | unresolved |
| RR2 | Salary not stated | unknown | — | Posting silent on pay | Pay may be withheld until later | `[inferred]` from silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Clear scope | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role is defined | `[grounded]` posting | How is the S&OP meeting run, and who attends? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Don't apply to this posting as a planner | R2, R3, R6 absent | `[grounded]` fit ledger | pending your approval |
| E2 | Check your Excel level, and say what you did in it only if it's accurate | Closes R7 | `[grounded]` CV silence | pending your approval |
| A1 | Look at demand or supply analyst roles, where forecasting and performance review are the core work | Closer to what you've done | `[generic]` role-family pattern | pending your approval |

---

## Evidence status

Verified: none yet. Every claim above comes from your CV and the two postings.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches on both employers were refused by the host. Would have confirmed each employer exists and the posting is live (RR1, both jobs) |
| 2. Role-family sweep | unavailable | Searches for salary and scope were refused. Would have set market bands for both roles (RR2, both jobs) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md` so it's ready when the answers come in.

## What would move these

- Permission to search: employer checks for both companies and a salary band for each role (RR1, RR2)
- The live Duinvaart posting link from its careers page (RR1)
- Your constraints: where you live, the office days you can do, minimum pay, and contract type (R1 in both jobs)
- What you built on the on-time dashboard, and how many depots and vehicles it covered. This would move R5 and R6 from medium toward high
- Your Excel level (R7, Job 2)

## Questions

1. [R1, both jobs] Where are you based now, and can you do three office days a week in Rotterdam, or full-time on-site in Utrecht?
2. [R5, R6] Did you build the on-time delivery dashboard or maintain it, and how many depots and vehicles did it cover?
3. [RR2] What's your minimum salary, and do you need a permanent contract?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.