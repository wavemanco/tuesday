**Short answer:** Yes, it's worth applying. The company checks out on its own website, and the WhatsApp message is an ordinary interview request. The one real gap is that you've never been the only designer.

**Decision snapshot**

- **Status: `conditional_go`.** Apply. Your craft and collaboration evidence fits well, and the employer is established. Two things would change the answer: whether you can work as the sole designer, and whether the pay works for you.
- **Fit ledger**
  - `must_have`: R2 `direct`, R3 `direct`, R4a `direct`, R7 `direct`, R5 `adjacent`, R6 `absent`
  - `important`: R4b `adjacent`, R8 `direct`, R9 `unclear`
  - R5 and R6 are the rows where the posting asks for ownership you haven't shown alone. R9 is the pay question, which you haven't answered yet.
- **Opportunity ledger:** RR1 (`positive_signal`) says the company's own site matches the posting. RR2 and RR3 are both low-severity unknowns about equity and day-to-day design review. The WhatsApp message (RR4) is routine scheduling and takes no entry.
- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a pay floor below €52,000 would make it `no_go`. A clear "no, we need someone who will run this solo, now" in the interview would move it to `hold_pending_answers`.

**Role reality**

- **Company:** Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools. Six people, based in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, and "funded by its customers" [grounded, company's own about page]. Funding and history are unverified.
- **Ronan:** co-founder and CEO, previously a product lead at a Galway travel-software company for five years [grounded, public profile snippet]. That's close to your own background.
- **Saoirse:** named as co-founder on the about page and as CTO in the WhatsApp message. Not a contradiction, but worth confirming the title in the call.
- **Scope:** first design hire, owning the booking flow, running research with school owners. Read as genuine and substantial [inferred] from the posting.
- **Market calibration:** the Tillerby 2026 Ireland survey (n=520) puts product designers with 3–5 years at a median of €57,000, with an interquartile range of €51,500–€62,000 [generic]. The posted €52,000–€60,000 sits inside that range.
- **Equity** (0.5–1%): no vesting, strike price or cap table is published [unknown].

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| R1 | hard_gate | direct | high | — | Hybrid, two days a week in Galway | You moved back to Galway last year (stated) |
| R2 | must_have | direct | high | — | 3+ years product design | 4 years at a Dublin travel-booking company |
| R3 | must_have | direct | medium | — | Strong Figma | Daily use (stated; no files seen) |
| R4a | must_have | direct | medium | — | Has run own user research | Monthly usability sessions with customers |
| R4b | important | adjacent | medium | transferability | Research calls with school owners | Customer research, but a different audience |
| R5 | must_have | adjacent | medium | transferability | Owns the booking flow end to end | Led the checkout redesign inside a squad |
| R6 | must_have | absent | high | capability | Works as the only designer | Never been the only designer (stated) |
| R7 | must_have | direct | high | — | Works directly with engineers | Squad of four engineers |
| R8 | important | direct | medium | — | Ships real work, not polish | Checkout case study, which Ronan liked |
| R9 | important | unclear | — | unconfirmed | Pay and equity fit your floor | Your floor isn't known to me |

**Gap recovery queue**

- **G1 (R6):** A solo designer is the core gap. It closes with one example where you made the final call without a design peer, or an honest account of how you'd handle that.
- **G2 (R5):** Ownership of the booking flow. Closes if the checkout case study shows decisions you led.
- **G3 (R9):** Pay and equity. Closes once you state your floor.

**Risk register**

- **RR1 (`positive_signal`):** The company's site and careers page match the posting: Galway, six people, booking software, same salary and hybrid terms. Hypothesis: a real, active hiring employer [grounded, one self-published site]. Question for them: "Who are your paying customers now, and how many?"
- **RR2 (`unknown`, `severity: low`):** Equity is stated as a range with no vesting or strike price [inferred from the posting]. Question: "What's the vesting schedule and the strike price, and how many shares are issued in total?"
- **RR3 (`risk_signal`, `severity: low`):** A first design hire at a six-person company may have no design critique or sign-off [generic pattern, not a finding about this company]. Question: "Who reviews design work day to day, and which decisions can I make without sign-off?"
- **Standing entry, employer not established:** not triggered. L1 found the company.

**Application plan**

1. Confirm the time on WhatsApp, then check the emailed invite came from the company's own domain before you join. That's advice, not a condition.
2. Bring the checkout case study. Lead with your research and ownership of the checkout redesign, not with "end to end".
3. For G1, use an honest framing: "I've never been the only designer. Here's how I'd handle decisions with no design peer, and here's where I've made the final call." Don't claim solo ownership you haven't had.
4. No resume or outreach edits are proposed. Any wording you want to send to Ronan needs your approval first.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Fernquay Galway booking software sea kayak surf schools", "Fernquay careers product designer Galway". Pages: fernquay.example/about (fetched); fernquay.example/careers/product-designer (search snippet only, not fetched) |
| 2 | Role-family sweep | yes | Query: "product designer salary Ireland 3 years experience 2026". Source: Tillerby 2026 Ireland Design Salary Report |
| 3 | Hiring manager's public footprint | yes | Query: "Ronan Kehoe Fernquay co-founder". Source: public profile snippet (search snippet only) |

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

The dossier offer: if you want, I can save this assessment as `tuesday-dossier.md` so it carries into interview prep.

**Upgrade menu**

- Your pay floor and your view on the equity range would close G3 and the R9 check.
- The checkout case study link would let me check R5 and R6 against the work itself, which would raise their confidence.
- The emailed invite (sender address and time) would confirm the scheduling step.
- Deeper diligence (L2) would cover funding, leadership history, recent news and candidate reports. It's up to 5 more searches and 2 more fetches. Say if you want it, and I won't offer it again.

**Questions**

1. What's the lowest base salary you'd accept?
2. On the checkout redesign, which decisions did you make alone, and which did you agree with engineers or the business?
3. What's the one real project, even a messy one, you'd walk them through, and what would you change about it?

Answer any of these, or say "skip" to pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.