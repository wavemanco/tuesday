**Decision snapshot**

- **Opportunity: go.** The company checks out on its own public pages. The WhatsApp message is ordinary interview scheduling, not a red flag.
- **Candidate fit: conditional.** You meet most requirements on the stated evidence. The open question is working as the only designer.
- **Hard gates:** none failed. Galway location and two office days fit. Your pay floor and the equity terms are unknown, so those two are unverified rather than failed.

**Fit ledger**

| Priority | Fit | Requirement |
|---|---|---|
| Must | Met | 3+ years product design (4 years, stated) |
| Must | Met | Works directly with engineers (squad of four engineers, stated) |
| Must | Partly met | Own user research (you ran monthly usability sessions with customers; their research calls are with school owners, a different customer group) |
| Must | Partly met | Strong Figma (daily use, stated; no portfolio in hand to verify it) |
| Must | Partly met | Own the booking flow end to end (you redesigned the checkout flow inside a squad; sole ownership is not evidenced) |
| Implied | Gap | Work as the only designer with no design peer (no evidence either way) |

**Role reality**

- **Company, verified** `[grounded]`: Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. The careers page matches the posting: first design hire, hybrid, €52,000–€60,000 plus equity, apply to jobs@fernquay.example.
- **Consistency:** the posting, careers page and about page agree. Saoirse is named as co-founder on the about page and as CTO in the WhatsApp message. Those are compatible.
- **Ronan** `[grounded]`: a LinkedIn profile lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years.
- **Footprint is thin.** Only the company's own pages and one profile turned up. That is an unknown, not a warning sign.
- **Salary** `[generic]`: the 2026 Tillerby Ireland design salary report (n=520) gives a median base of €57,000 for product designers with 3–5 years, interquartile range €51,500–€62,000. The posting's range sits around that median.
- **Equity** is unstated in terms: 0.5–1% with no vesting, strike price or share count. Unknown.
- **Scope signal** `[inferred]`: one designer owning the booking flow, research and shipping, alongside two engineers. That is a wide scope with no stated design support.

**Evidence map** (sources: your background as you described it; the posting)

| Requirement | Evidence | Confidence | Gap type |
|---|---|---|---|
| 3+ years | 4 years at a Dublin travel-booking company | High (stated, employer checkable) | None |
| Engineers | Squad of four engineers | High (stated) | None |
| User research | Monthly usability sessions with customers | Medium (stated, no artifact) | Transferability: customer type differs |
| Figma | Daily use | Medium (stated, no artifact) | Presentation: needs a portfolio |
| Booking flow end to end | Redesigned checkout flow | Medium | Capability: sole ownership unshown |
| Solo working | No evidence | Low | Transferability |
| Galway, hybrid | Moved back to Galway last year | High (stated) | None |

**Gap recovery queue**

- **Solo ownership.** Closes with one concrete example of a flow you drove from brief to ship, with your decisions named, or a clear account of which calls were yours inside the squad.
- **Research with school owners.** Closes with any example of interviewing a small-business or non-enterprise customer, even informally.
- **Portfolio.** Closes with a project link, which would also upgrade Figma and the checkout work.

**Risk register**

- **Equity terms unknown** (unknown class, medium). 0.5–1% means little without vesting, strike and share count.
- **Single-designer role** (risk signal, medium). Responsibility with no design peer or lead in sight. Worth probing on the call.
- **Pay** (unknown, low). The posted range sits around the market median. Your floor is not known to me.
- **Thin public footprint** (unknown, low). Normal for a six-person company.
- **Legitimacy check, advice only.** Confirm the calendar invite comes from the company's own domain, the same one as jobs@ on the careers page. Never send bank, tax, ID details or any payment before a written offer.

**Application plan**

- You have applied, so the next step is the 45-minute call with Ronan and Saoirse.
- Lead with the checkout case study as the piece they already liked. Describe your role there exactly as it was: what you designed, what you decided, what the squad decided. A squad-based redesign stated as your own is the weakest point the interviewers can test.
- Ask for the equity terms and what design support exists after you start.

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Searches "Fernquay Galway booking software…" and "Fernquay careers product designer"; fetched the careers page and the about page. Both match the posting; the company exists as described. |
| 2 | Role-family sweep, compensation | yes | Search "product designer salary Galway Ireland 2026" returned the Tillerby 2026 report. Moved the market calibration line. |
| 3 | Hiring manager's public footprint | yes | Search "Ronan Kehoe Fernquay co-founder" returned his public profile. |

L2 was not run.

**Upgrade menu**

- **Portfolio or case study link:** would raise Figma and the checkout claims from medium to high.
- **Equity terms in writing:** would close the equity unknown.
- **Pay floor:** would confirm or rule out the pay row.
- **Solo-work examples:** would move the end-to-end booking flow row.

I can also run a deeper check on funding and recent news about Fernquay if you want it. That would use up to 5 more searches and 2 more fetches.

Want me to create a full dossier file for this role so you can reuse it? Happy to make one whenever you like.

Questions:

1. Was the checkout case study your own design work, or did you share the decisions with the squad?
2. Does this role's equity terms matter to you, or is your priority the base salary?
3. How comfortable are you making design calls without a design peer to check them?

You can answer in text or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.