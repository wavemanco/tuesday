## Decision snapshot

**Worth applying to, on two conditions. Status: `conditional_go`.** The role matches your strongest evidence (checkout redesign, customer usability sessions, daily Figma, a squad of engineers), and the pay sits inside the market band. On legitimacy: the company exists as described on its own website, and I found nothing suggesting it isn't real. What I could not confirm is that this posting is live on a company-controlled page, and the equity terms are unstated.

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R2
- `important` — adjacent: R6 · unclear: R8
- `preferred` — absent: R9

**Opportunity ledger.** Specific and mostly sound: the pay range is stated, the founders and product are named on the company's own site, and the responsibilities are concrete. Two things are unverified: the posting itself (RS1) and the equity terms (RS3).

- **Hard gates:** none failed; met: R1 `direct`. Your non-negotiables (pay floor, contract type, start date) were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live at a company-controlled address (RS1); (2) the equity terms are stated (RS3). The scheduling by WhatsApp and the email invite are routine and get no entry.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; customer-funded | `[grounded]` fernquay.example/about |
| Organization entity check | Entity confirmed as described, so no failed-attribution entry | `[grounded]` the About page above |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Scope read | A generalist design seat with no design peer; you would set design direction alone or with founder sign-off | `[inferred]` from "first designer" and "own … end to end" |
| Leadership | Ronan Kehoe, co-founder and CEO per a LinkedIn snippet; previously product lead at a Galway travel-software company for five years. Saoirse Doyle is a co-founder on the About page; the CTO title in the WhatsApp message is not confirmed | `[grounded]` LinkedIn snippet, About page |
| Market calibration | Product designers with 3–5 years in Ireland: median €57,000, interquartile range €51,500–€62,000 (n=520). The posting's €52,000–€60,000 sits inside that range | `[generic]` Tillerby 2026 report; `[grounded]` posting figure |
| Unknowns | Equity terms (options or shares, vesting, exercise price); design decision rights; whether the posting is live; the CTO's title | — |
| Contradictions | None found between the posting and the company's own pages. The careers page address I tried returned no page, so the posting is not confirmed live | `[grounded]` fernquay.example/careers fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit | `[grounded]` posting and your statement | none |
| R2 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout stage, which is one part of a booking flow. End-to-end ownership is not evidenced | `[grounded]` CV; `[inferred]` adjacency | Claim the checkout stage only; see G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, stated | `[grounded]` CV | Confirm with dates on the CV |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, stated; no file reviewed | `[grounded]` CV | Work sample would raise this |
| R5 | Own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` CV | Work sample would raise this |
| R6 | Run research calls with school owners | important | adjacent | medium | transferability | Customer research is the same method, but school owners are a different buyer | `[inferred]` from R5 | See G2 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad of four engineers | `[grounded]` CV | none |
| R8 | Working as the only designer | important | unclear | low | discovery | You have never been the only designer. This is not evidence that you can't; it is a question to test | `[grounded]` your statement | See G3 |
| R9 | Sea-kayak, surf or school-software domain | preferred | absent | medium | discovery | No domain evidence found after looking at your background | `[grounded]` CV | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R2) | transferability | Checkout redesign only | The posting says "end to end" and you would be the only designer | Any other booking stage: search, booking confirmation, rebooking, payments | The checkout case study, before and after | `[grounded]` CV; `[inferred]` the gap |
| G2 | School-owner research (R6) | transferability | Monthly usability sessions with consumers | The posting's research is with a different buyer, with B2B workflows | Any interviews with small-business operators or suppliers | A short research plan from one past project | `[inferred]` from R5 |
| G3 | Solo design work (R8) | discovery | No solo or no-peer experience on record | Core to the role | Freelance, side projects, or a period with no design peer | A project you led alone | `[grounded]` your statement |
| G4 | Outdoor or school-software domain (R9) | discovery | None | Preferred, not required; learnable | Any outdoor, leisure or small-operator software exposure, including as a customer | A customer-side project | `[grounded]` CV; `[generic]` that domain can be learned on the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification | Status |
|---|---|---|---|---|---|---|---|---|
| RS1 | The posting is not confirmed on a company-controlled page | unknown | — | "Product Designer — Fernquay" | The posting may sit on a page I did not guess, or may be stale or sent only to you | `[inferred]` from the careers fetch returning no page | Get the live posting URL from the source you used | unresolved |
| RS2 | Thin public footprint | risk_signal | low | "Six people, based in Galway" | A small founder-led company often has a small footprint | `[generic]` pattern; `[grounded]` one About page and one profile snippet | Check for a named customer or product page | unresolved |
| RS3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value of the equity depends on option terms and the cap table, neither of which is given | `[inferred]` from the posting's silence | Ask for the option scheme, vesting, exercise price and dilution | unresolved |
| PS1 | Identifiable operating company | positive_signal | — | "Fernquay makes Kelproster" | A real product with named founders and a stated location | `[grounded]` fernquay.example/about | none | noted |
| PS2 | Pay range stated and inside the band | positive_signal | — | "€52,000–€60,000" | Pay is set in the open, not withheld | `[grounded]` posting; `[generic]` band | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the checkout redesign and say "redesigned the checkout flow", not "owned the booking flow" | R2 and the reframing audit: the checkout claim is verifiable, the end-to-end claim is not | `[grounded]` CV; `[inferred]` | pending your approval |
| A2 | Put the monthly usability sessions first for the research requirement, and name school-owner research as new | R5, R6 | `[grounded]` CV | pending your approval |
| A3 | Send the checkout case study as the work sample, unedited | R4, R5 need an inspectable artifact | `[grounded]` recruiter's comment in your message | pending your approval |
| A4 | At the call, ask who signs off design decisions and what the equity terms are | RS1 and RS3 are the verifiable items | `[inferred]` | pending your approval |
| A5 | If asked about working alone, describe what you would do with no design peer; do not describe a solo track record you don't have | R8 and the reframing audit | `[generic]` how interviews of first-hire roles usually run | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools", which returned fernquay.example/about; fetched "About Fernquay" (fernquay.example/about); fetched fernquay.example/careers, which returned no page. Moved role reality's organization row (entity confirmed) and RS1 (posting not found on the careers page) |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row: median €57,000, interquartile range €51,500–€62,000, `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe", which returned the LinkedIn profile snippet (linkedin.example/in/ronan-kehoe). Moved the leadership row: co-founder and CEO, previously product lead at a Galway travel-software company |

## Upgrade menu

If you want this assessment carried forward, I can emit it as a `tuesday-dossier.md` whenever you like.

- The live posting URL or the company's own careers page → RS1 closes.
- The equity terms (option scheme, vesting, exercise price) → RS3 closes, and the 0.5–1% can be valued.
- The checkout case study itself → R2, R4 and R5 move toward `high` where the work shows.
- Any booking, B2B or outdoor-software work, even a side project → R9 moves.
- Any experience working without a design peer → R8 moves.
- Your non-negotiables (pay floor, contract type, start date) → the hard-gate checks run; they are unknown now.
- A deeper research pass on Fernquay (funding, hiring history, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs; I offer it once.

## Questions

1. (RS1) Where did you see the posting? Can you send its URL, or the company's careers page if you found one?
2. (RS3) Did the posting or Ronan's email mention the equity terms: options or shares, vesting, exercise price? If not, the call is the place to ask.
3. (R9) Have you done any work touching booking, B2B or outdoor and leisure software, even a side project or volunteer work?

Answer in text, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.