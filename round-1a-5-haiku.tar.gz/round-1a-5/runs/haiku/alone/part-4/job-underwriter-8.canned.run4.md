**Decision: `no_go`.** Don't send anything to this sender. The messages ask you to pay for equipment, deposit a cheque, and give bank and ID details before any offer, and the whole process runs in chat. Your fit doesn't change that.

- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year; the posting gives "up to €26/hr" plus commission on 15–30 hours a week). At the full rate, €30,000 needs about 22 hours a week before commission [grounded, arithmetic from the posting].
- **Fit ledger:**
  - hard_gate: R1 (pay of at least €30,000 a year) `unclear`
  - must_have: R2 `direct` (spreadsheets, Excel tracker); R3 `adjacent` (attention to detail, shown only through ticket volume and the tracker); R4 `unclear` (written English, not sampled)
  - important: R5 `adjacent` (order processing; your courier work is customer service, not order processing); R6 `unclear` (quiet workspace, not stated)
- **Opportunity ledger:** RR1–RR4 are confirmed red flags, each `severity: high`. RR5 is a standing risk signal about the employer.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **Confidence:** R2 `medium`, from your CV.
- **Gate status:** the candidate constraint on pay is given, so the R1 check is not blank.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Verification question (asked of the employer) | Status |
|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "pay €349 by bank transfer to our equipment partner" | "Does your company ever ask new hires to pay for their own equipment?" | confirmed |
| RR2 | Cheque deposit and transfer of funds | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner" | "Does your company send cheques for new hires to deposit and forward to a third party?" | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | "What do you need from candidates before an offer, and through which portal?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | "Do you hold any interview or offer stage outside Telegram?" | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" (posting) | "Can you point me at this role on your own careers page, and who would I interview with?" | unresolved |

RR1–RR4 are about the requests in these messages, not about any party. RR5 has three possible reasons, none ranked as likely: the company is too new or small, the posting is stale, or it is not a real hiring employer [generic].

- **Hold:** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.
- **Warning:** I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Verdict on the requests:** This request is very likely a scam. Don't deposit the cheque. This job is very likely a scam, so pay nothing, and send no bank, PPS or passport details, until the employer confirms the role through its own website.

**Evidence status**

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | One search for the company's site returned no results; you gave no link |
| 2 | Role-family sweep (market pay for this role) | skipped | Not run; the requests decide the outcome |
| 3 | Hiring manager's public footprint | n/a | No name given |

**Application plan:** Don't apply or reply through Telegram. If you still want this role, find the company's website yourself, search for its careers page, and apply there. Do not use the contact in the messages. Your strongest case for any similar role is your tracker work and your training of new starters, not the chat.

**Dossier offer:** I can write a `tuesday-dossier.md` for this role so these findings travel with you.

**Upgrade menu**
- The company's own website or careers page, which would settle RR5.
- A written offer from the company's own domain naming the role, pay and hours, which would let R1 be checked.
- Your monthly pay and hours in writing, which would settle R1 — a gate this posting leaves open.

1. Does the company have a website I can check, or a careers page where this role is listed?
2. If the role is real, what hours and base pay would they guarantee in writing?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.