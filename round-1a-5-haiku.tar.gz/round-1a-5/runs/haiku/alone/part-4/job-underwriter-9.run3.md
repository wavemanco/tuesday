**Yes, what they're asking for is routine.** Asking for bank details, your PPS number and a passport scan for right-to-work checks is normal after a written offer that names the role and pay, and this one does. It is not a red flag. The risk is in *how* and *where* you send them, so verify the employer and use only their own portal. `conditional_go`: accept once you've verified the employer through contact details you find yourself, and the decision is yours.

## Decision snapshot

**Yes, the onboarding request is normal, and the role fits you well on paper. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: direct: R11 · unclear: R10
- `must_have`: direct: R1, R3, R4, R5, R6 · unclear: R2
- `important`: adjacent: R9 · unclear: R8 · absent: R7

R1 is the strongest row: three years of fortnightly payroll for 90 staff, with starters, leavers and the monthly ledger reconciliation. R2 (Irish PAYE, PRSI and USC) is the one must-have your CV doesn't state directly, and R7 (pension changes) is the honest gap.

**Hard gates:** none failed. R10 is `unclear` because I don't know your commute to Limerick. R11 is `direct` because €40,000 sits inside the posting's €38,000–€42,000 band.

**Opportunity ledger:** The posting is specific, with a named manager, pay, hybrid days and a stated permanent contract. Your two in-person interviews at their office are first-hand evidence that the organisation exists. Research hasn't run, so the employer's existence is not yet verified from public sources (see the risk register).

## Role reality

- **Title and scope:** Payroll Administrator, permanent. Runs monthly payroll for 240 staff, processes starters, leavers and pension changes, reconciles to the general ledger, and answers staff payroll queries.
- **Organisation:** Marrowgate Housing, a housing association in Limerick `[grounded]` from the posting and offer. Not yet verified from public sources.
- **Reporting line:** Declan Garvagh, Finance Manager `[grounded]` from the offer.
- **Compensation:** €40,000 offered; the posting's band is €38,000–€42,000 `[grounded]`. Market calibration not run.
- **Unknowns:** pension scheme and administration system; probation and leave; notice period and start date; which hybrid days; whether the offer is complete.
- **Contradictions:** none found between the posting and the offer.
- **Scale:** 240 staff against your 90, and monthly against your fortnightly cycle.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence / reasoning |
|---|---|---|---|---|---|---|
| R1 | must_have | 2+ years running payroll | direct | medium | none | 3 years fortnightly payroll, 90 staff (CV, self-reported) |
| R2 | must_have | Working knowledge of Irish PAYE, PRSI, USC | unclear | low | discovery | CV doesn't name the statutory deductions or the jurisdiction; the 2024 certificate likely covers them `[inferred]` |
| R3 | must_have | Strong Excel | direct | medium | none | Daily use; pivot tables; XLOOKUP (self-reported) |
| R4 | must_have | Payroll qualification or working towards one | direct | medium | none | Payroll Technician certificate, 2024 (CV) |
| R5 | must_have | Process starters and leavers | direct | medium | none | 3 years at the hotel group (CV) |
| R6 | must_have | Monthly payroll-to-GL reconciliation | direct | medium | none | Done monthly at the hotel group (CV) |
| R7 | important | Pension changes | absent | none | capability | Never handled personally; your manager did (your account) |
| R8 | important | Answer staff payroll queries | unclear | low | discovery | Not described in the CV |
| R9 | important | Scale and cycle: 240 staff, monthly | adjacent | medium | transferability | 90 staff, fortnightly; the same processes, larger scale and a different cycle `[inferred]` |
| R10 | hard_gate | Hybrid, two days a week in Limerick | unclear | low | hard-gate | Your commute and location not given |
| R11 | hard_gate | Pay within €38,000–€42,000 | direct | medium | none | Offer €40,000 `[grounded]` |

**Reasoning for the decision:** The must-haves are strong on your stated evidence, and the weakest point is the R7 gap. Confidence is capped at medium on a first pass, and nothing is verified beyond your own account.

## Gap recovery queue

- **R2, discovery:** The CV doesn't show the Irish statutory deductions. *Closes with:* a sentence on which deductions you calculated and in what system.
- **R7, capability:** Pension changes were never yours. *Closes with:* an honest statement of what you've seen and what you'd need to learn. Don't claim more than you did.
- **R8, discovery:** Staff queries aren't described. *Closes with:* the query types you handled.
- **R9, transferability:** Scale and cycle differ. *Closes with:* stating the 90-staff, fortnightly scope plainly.

## Opportunity risk register

**Employer not established (standing entry)**

```yaml
signal: "Employer not established from attributable sources"
class: risk_signal
severity: medium
source_quote: "Marrowgate Housing, a housing association in Limerick" / "Marrowgate Housing People Team"
hypothesis: "Research hasn't run, so the employer's registration and the live posting are unconfirmed. Possible reasons, none ranked as likely: the organisation is newer or smaller than its footprint suggests; the posting is stale or aggregated; or the posting doesn't match a live hiring employer. Your in-person interviews at their office count as first-hand evidence, though they don't settle registration or the offer."
provenance: "[generic] pattern for organisations of this size, not a claim about this one"
verification_question: "Can you confirm the role and this offer on your own careers page, and give me the People team's direct contact?"
decision_rule: "Verify through contact details from their own website before you accept or send any details."
status: unresolved
```

**Routine onboarding request:** No register entry. Asking for bank details, PPS and a passport scan after a written offer is routine. The verification steps below are advice, not conditions.

**Pension responsibility (unknown)**

```yaml
signal: "Pension scheme and administration not described"
class: unknown
source_quote: "processes starters, leavers and pension changes"
hypothesis: "The pension workload and system may differ from your experience."
provenance: "[inferred] from the posting's silence on the pension scheme"
verification_question: "Which pension scheme and administration system does this role run, and what training covers pension changes?"
decision_rule: "Proceed if the scheme is standard and the training is real."
status: unresolved
```

## Application plan

The offer is already in hand, so this is the plan for accepting. Your decision.

**Verify before you accept (about 15 minutes):**
1. Type marrowgatehousing.ie into your browser yourself, or use a number from their site. Don't use a link from the email.
2. Check that the role, the People team and Declan Garvagh appear on their website. Check that the address on your interview invitations matches the site.
3. Check that the email domain matches their site exactly. Look for lookalike spellings.

**Accepting:** Reply by email to accept. That needs no personal details. Confirm the €40,000 salary, the start date after notice, the hybrid days and the permanent contract. Ask for any extension you need on the five working days.

**Portal and details:**
- Open the portal only from the address their own website gives. Check that the address matches before you enter anything.
- Bank details: the account should be in your own name. After setup, changes should never be requested by email. If they are, verify by phone on a number from their website.
- PPS number: enter it in the portal only, never by email. Employers need it for Revenue, so the request is normal.
- Passport: upload the scan only through the portal, and only the pages they ask for. Keep the original; the day-one check in person is standard right-to-work practice.

**Positioning:** Lead with the monthly reconciliation and the certificate. For pensions, say honestly that you haven't run pension changes, that your manager did, and what you'd need to learn. Don't claim pension experience.

## Evidence status

**Verified:** None. Every claim is self-reported from your CV and messages, and the claims are stated, not checked. The fit tiers are `direct`, not verified.

**Unverified leads:** None.

**Rejected inferences:** None.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Marrowgate's official site and careers page | skipped | Would confirm the employer exists and the role is live; research consent not given |
| 2. Role-family sweep: Limerick payroll administrator, €38–42k | skipped | Would calibrate the salary band; research consent not given |
| 3. Hiring manager's public footprint (Declan Garvagh) | skipped | Would inform positioning; research consent not given |

## Upgrade menu

- **Research (L1, up to 5 searches and 2 page fetches):** Checks the employer's official site and careers page, sweeps the Limerick payroll salary band, and looks at the hiring manager's public professional profile. This would clear or confirm the standing employer entry and calibrate R11.
- **Your statutory deduction experience (R2):** Moves R2 from `unclear` to `direct`.
- **Commute and non-negotiables (R10, R11):** Clears or confirms the hard gates.
- **Pension scheme details (R7):** Converts the unknown into a concrete plan.

I can write this up as a `tuesday-dossier.md` if you want a record to keep.

**Questions**

1. On the hotel-group payroll, did you calculate PAYE, PRSI and USC yourself, and in what system? *(R2)*
2. What are your limits on commute to Limerick, pay floor and start date? *(R10, R11)*
3. Should I run the research step (L1): check Marrowgate's own site and careers page, and sweep the salary band?

Answer any of these, skip any ("skip" is an answer), or reply "research" to question 3.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.