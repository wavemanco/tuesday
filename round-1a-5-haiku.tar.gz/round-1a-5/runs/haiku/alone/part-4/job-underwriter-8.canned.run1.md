**Decision: no-go on this offer as presented. Don't send your IBAN, PPS number or passport photo, and don't pay the €349.**

**Hard gates**
- **Pay floor (€30,000): at risk.** The posting says "up to €26/hour" for 15–30 hours a week, plus unquantified commission. At the top rate, €30,000 needs about 22 hours a week every week, with no guaranteed base. [inferred from the posting's figures]

**Opportunity ledger (red flags, all from the messages you pasted)**
1. **Personal and banking details before any interview:** IBAN, PPS number and passport photo requested during "screening." [grounded]
2. **Payment to start:** €349 by bank transfer to a third-party "equipment partner," refunded "with your first wages." Nothing in the posting says the employer pays for equipment. [grounded]
3. **Cheque instructions:** you're asked to deposit a €2,850 cheque, keep €350, and send the rest to the same equipment partner. Money paid out from a cheque before it clears can be reversed when the cheque bounces, leaving you to repay the shortfall. [generic banking practice]
4. **Hiring entirely by Telegram,** with no call or video, and the job offered in chat. The contact address (velloway.hr@postmail.example) is a generic mail domain, not a company domain. [grounded]

Check the company through contacts on its own website, not through the Telegram account.

**Fit ledger (your side)**
- **Attention to detail:** strong evidence. Roughly 60 Zendesk tickets a day for three years, plus a weekly Excel tracker. [grounded, from your background]
- **Spreadsheets:** strong evidence, same source.
- **Training others:** you trained two new starters, which the role doesn't require but supports.
- **Written English and a quiet workspace:** not verified. Your CV is in English, but nothing tests it.

Your skills fit this kind of role well. That doesn't change the red flags above.

**What would change the decision:** the role appears on the company's own careers page; there's a written contract with a stated base salary; payroll is set up through a formal process after a written offer; and no equipment purchase is involved.

**Right now**
- Don't send the IBAN, PPS number or passport photo, and don't pay the €349.
- If a cheque arrives, don't deposit it or move any money from it. Take it to your bank.
- You can stop replying and report the account to Telegram.

**Research:** Research tier: L0, no searches. I didn't look up Velloway Logistics, so this verdict rests only on the posting and messages you pasted.

If you'd like, I can save this assessment as `tuesday-dossier.md` for later reference.

**Upgrades available**
- A company check (up to 5 searches and 2 page fetches) to see whether Velloway Logistics exists and hires remotely. This is the main thing that could change the picture on the company side.
- A link to the posting on the jobs site, or the company's own careers page, if you have one.

**Questions**
1. Do you want me to run the company check now, within those limits?
2. Do you have the link to the job on the jobs site, or the company's careers page? You can answer either question or skip it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.