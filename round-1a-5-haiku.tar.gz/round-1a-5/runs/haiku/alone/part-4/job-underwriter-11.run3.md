**Posting 1 (Duinvaart, Operations Analyst) is worth applying to, with conditions. Posting 2 (Kroonhaven, Supply Planner) is not worth your time right now.**

Research didn't run. My two company searches and two salary searches were refused, so nothing below is checked against the employers' sites or against pay data. Every fact comes from the two postings and your background.

---

## Posting 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Yes, apply, once the employer checks out. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`, unclear: R9 (three days a week in Rotterdam; your location and right to work in the Netherlands aren't stated)
- `must_have`, direct: R1, R2, R3, R4, R6, R7
- `must_have`, adjacent: R5 (temperature compliance)
- `preferred`, adjacent: R8 (Dutch)

**Opportunity ledger.** The responsibilities are concrete and measurable, and they match what you already do (RR5). The salary isn't stated, and the posting doesn't say how much authority the role has over route changes (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (hybrid Rotterdam, three days a week; right to work in NL not stated). Your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none in the posting text.
- **Conditions for go:** (1) the role is confirmed live on Duinvaart's own careers page (RR1); (2) R9 is confirmed; (3) temperature compliance is presented as a learning gap, not experience (R5).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | [grounded] posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly dashboards in Power BI; work with depot managers on route changes | [grounded] posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | [grounded] posting |
| Market calibration | Not run; no salary or role-family data was retrieved | — |
| Unknowns | Salary; whether the role decides route changes or advises depot managers; which system holds temperature data | — |
| Contradictions | None within the posting text; not checked against the employer's site | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, in your own statement; no document yet | [grounded] your background | none |
| R2 | Strong SQL | must_have | direct | medium | none | Used daily, per your statement; no artifact yet | [grounded] your background | none |
| R3 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily, including the depot on-time dashboard | [grounded] your background | sanitized screenshot would raise to high |
| R4 | Track on-time delivery | must_have | direct | medium | none | You built and ran the on-time dashboard depot managers use | [grounded] your background | none |
| R5 | Track temperature compliance across a refrigerated fleet | must_have | adjacent | low | transferability | The compliance-tracking method transfers; temperature data and cold-chain rules don't appear in your background | [inferred] from your background against the posting | Q3 |
| R6 | Build weekly dashboards | must_have | direct | medium | none | Weekly reporting cadence in your history: the weekly route-performance review | [grounded] your background | none |
| R7 | Work with depot managers on route changes | must_have | direct | medium | none | Ran the route-performance review with depot managers as its audience | [grounded] your background | none |
| R8 | Dutch | preferred | adjacent | medium | capability | Conversational, not fluent; the posting says "a plus" | [grounded] your statement | none near term |
| R9 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | Your location and right to work in NL aren't given | — | Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What would close it |
|---|---|---|---|
| G1 | Temperature compliance (R5) | transferability | Any exposure to temperature or cold-chain data, even from a previous role, or a clear account of how you'd learn the regulations |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small for an online footprint, the posting may be stale, or it may not be a live hiring employer. Research didn't run, so this is not a finding about the employer. | [generic] pattern for companies of this size | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Where temperature data lives is unknown | unknown | — | "track ... temperature compliance across our refrigerated fleet" | The role may depend on sensor or cold-chain systems you haven't used | [inferred] from the core duties against your background | Which system records temperature compliance, and who owns that data? | unresolved |
| RR3 | Route-change authority unknown | unknown | — | "work with depot managers on route changes" | The role may advise depot managers rather than decide route changes | [inferred] from "work with" against silence on decision rights | Does this role decide route changes itself, or advise the depot managers who do? | unresolved |
| RR4 | Salary not stated | unknown | — | (no pay in the posting) | The posting may leave pay for later | [grounded] posting is silent | What salary is budgeted for this role? | unresolved |
| RR5 | Clear, measurable responsibilities | positive_signal | — | "Track on-time delivery ... build weekly dashboards" | The job's core is work you already do | [grounded] posting | | noted |

**Application plan** (proposed; nothing here is final until you approve it)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the on-time dashboard as an outcome: what it tracked and who used it | Matches R4 and R3 | [grounded] your background | pending your approval |
| E2 | Describe cold-chain work as a learning gap with a plan, not as experience | See R5 | [inferred] | pending your approval |
| A1 | Confirm on Duinvaart's own careers site that the role is live before applying | See RR1 | [generic] | pending your approval |
| A2 | Confirm your right to work and Rotterdam commute before investing in the application | See R9 | [inferred] | pending your approval |

---

## Posting 2: Supply Planner, Kroonhaven Foods, Utrecht

**No, not worth your time now. Status: `no_go`.** R1, R2 and R5 are absent from your background, and planning years and planning-system experience can't be built quickly.

**Fit ledger.**
- `hard_gate`, unclear: R7 (on-site in Utrecht; right to work not stated)
- `must_have`, absent: R1, R2, R5
- `must_have`, adjacent: R3, R6
- `must_have`, unclear: R4

**Opportunity ledger.** The scope is clear and the responsibilities are concrete (positive). The salary isn't stated. The same employer-not-verified entry applies.

- **Hard gates:** none failed; unconfirmed: R7 (on-site Utrecht; right to work not stated). Your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none in the posting text.
- **What would have to differ:** 3+ years of FMCG planning, hands-on planning-system use (SAP IBP or similar), and fluent Dutch. Dutch could close over time; the other two can't close quickly.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | [grounded] posting |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | [grounded] posting |
| Working pattern | On-site in Utrecht | [grounded] posting |
| Market calibration | Not run | — |
| Unknowns | Salary; team size and decision rights; planning system in use | — |
| Contradictions | None within the posting text; not checked against the employer's site | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of FMCG supply or demand planning | must_have | absent | none | capability | No planning role on your CV; you've never worked in planning | [grounded] your statement | none realistic short-term |
| R2 | Own a 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | Your work measures delivery performance; it doesn't set capacity or forecasts | [inferred] from your background | none |
| R3 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review with managers; S&OP covers demand, supply and production planning | [inferred] from your review against [generic] S&OP scope | none |
| R4 | Advanced Excel | must_have | unclear | none | discovery | Not on your CV | [grounded] absence | Q2 |
| R5 | SAP IBP or a similar planning system | must_have | absent | none | capability | Not on your CV | [grounded] absence | none |
| R6 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent | [grounded] your statement | none near term |
| R7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and right to work aren't given | — | Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What would close it |
|---|---|---|---|
| G1 | Planning experience (R1, R2) | capability | Years in a planning role; no short-term route |
| G2 | Planning-system experience (R5) | capability | Hands-on use of SAP IBP or a comparable tool |
| G3 | Fluent Dutch (R6) | capability | Sustained professional Dutch; a longer-term project |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As for Duinvaart: too new or small for a footprint, a stale posting, or not a live hiring employer; research didn't run | [generic] | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Planner expected to run a live cycle from day one | risk_signal | medium | "Own the 13-week supply plan ... run the weekly S&OP meeting" | A hire without planning years may face a long ramp, or the role may be meant for an experienced planner | [generic] pattern for planning roles | What would a new planner be expected to own in the first 90 days, and what ramp is planned? | unresolved |
| RR3 | Salary not stated | unknown | — | (no pay in the posting) | Pay may be left for later | [grounded] posting is silent | What salary is budgeted for this role? | unresolved |
| RR4 | Clear scope | positive_signal | — | "Own the 13-week supply plan" | The role's core is defined | [grounded] posting | | noted |

**Application plan** (proposed; nothing here is final until you approve it)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting now | See R1, R2, R5 | [inferred] from the map | pending your approval |
| A2 | Look for demand or supply analyst roles that use your SQL and Power BI, a step toward planning | See R3, R4 | [inferred] from your background | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed that Duinvaart and Kroonhaven exist and that each posting is live (RR1 in both). Search was refused in this session. |
| 2. Role-family sweep | unavailable | Would have set the market calibration and the salary band for both roles. Search was refused in this session. |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

## Upgrade menu

- A sanitized screenshot of the on-time dashboard (or a description of what it tracked) → R3 to high, and it strengthens E1.
- Your location and right to work in the Netherlands → R9 (Posting 1) and R7 (Posting 2) close.
- Your Excel level → R4 (Posting 2) resolves.
- Any temperature or cold-chain data exposure → R5 (Posting 1) narrows.
- Search access on a follow-up turn → one L1 pass (up to 5 searches and 2 fetches) to check both employers' careers pages and the salary bands for both roles.

If you'd like, I can write this up as `tuesday-dossier.md` to keep and reuse.

---

**Questions:**

1. (R9, Posting 1; R7, Posting 2) What are your constraints on location and right to work in the Netherlands?
2. (R4, Posting 2) How would you rate your advanced Excel: pivot tables, Power Query, formula-driven models?
3. (R5, Posting 1) Have you worked with temperature or cold-chain monitoring data, even in an earlier role?

Answer any of these, say skip, or tell me the answer is no. Each is useful.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.