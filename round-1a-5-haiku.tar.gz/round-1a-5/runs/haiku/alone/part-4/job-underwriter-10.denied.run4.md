**Decision: conditional go.** Apply, but verify the company before you invest time in the process. Research was blocked (see Evidence status), so the company checks below are still open.

## Decision snapshot

- **Candidate fit (medium confidence, CV-based):** Meets the 3+ years, Figma, and working-with-engineers requirements. Partly meets the user-research requirement. Gap on "first designer": you have never been the only designer.
- **Opportunity:** Unverified. No company facts could be checked. Six people, a first design hire, and equity-weighted pay are normal for a seed-stage company but raise the stakes of a bad fit.
- **Hard gates:** None failed. Hybrid with two days in Galway fits your location. Your pay floor is unknown, so the €52,000–€60,000 range is an open check, not a pass.

## Role reality

- **Title and scope:** Product Designer, first design hire, owning the booking flow end to end. Scope is wide: research, design, and shipping, with no design colleague to review your work. `[grounded]` from the posting.
- **Stated pay:** €52,000–€60,000 plus 0.5–1% equity. The equity range is unexplained and needs written terms.
- **Market calibration:** Not checked. I could not verify Irish mid-level product design pay. `[generic]` at most.
- **Contradictions:** The posting asks for "run your own user research" and "ship alongside engineers" but describes no research tools, budget, or existing design artefacts. Worth asking about.

## Evidence map (summary)

| Requirement | Your evidence | Fit | Confidence |
|---|---|---|---|
| 3+ years product design | 4 years at a Dublin travel-booking company | Meets | High (CV) |
| Strong Figma | Daily use | Meets | Medium (CV only) |
| Own user research | Monthly usability sessions with customers | Partly meets | Medium |
| Work directly with engineers | Squad of four engineers | Meets | Medium |
| Own the booking flow | Redesigned checkout flow | Strong overlap | Medium |
| Research calls with school owners | Consumer customers, not small B2B owners | Transferable gap | Low |
| First/only designer | Never the sole designer | Capability gap | High (your own statement) |

## Opportunity risk register

- **Company existence not confirmed** (`severity: medium`, standing entry). Reasons it could be unconfirmed: too new or small, a stale posting, or no real hiring employer. Any of these is possible, and none is assumed. This caps the decision at conditional go until verified.
- **Recruiting contact** (`severity: low`). Ronan contacted you on WhatsApp to schedule. Scheduling by chat is routine, so I'm not treating it as a red flag. The invite should come from a company address, and the video link should match the company's domain.
- **Unstated terms** (`severity: medium`). Equity vesting, dilution, and salary bands are not defined in the posting.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was denied, so nothing was checked |
| 2 | Role-family pay and scope sweep | unavailable | Same reason |
| 3 | Hiring manager's public footprint | unavailable | Same reason; I have not researched Ronan Kehoe or Saoirse |

No outside facts appear in this response. Everything else is from your inputs and the posting.

## Application plan

- **Lead with:** the checkout redesign and the monthly usability sessions. Both show the booking-flow ownership they're asking for.
- **Address directly:** that you have never worked without another designer. Say what you'd do instead: research with the owners, peer review with the engineers, and a clear way to measure your own work.
- **Before the 45-minute call:** Verify the company (see conditions below) and check the salary and equity terms in writing.
- **Practice:** mock-interview can rehearse the call with you.

## Conditions for a go

1. Confirm the company exists independently: its own website, a careers page that lists this role, and an email domain that matches. Don't use the WhatsApp contact as your verification source.
2. Get salary and equity terms in writing before any offer.
3. Ask how the company would support a sole designer: budget for research tools, who reviews your work, and what success looks like in year one.

## Dossier offer

If you want, I can save this analysis as a `tuesday-dossier.md` file that a later session can pick up.

## Upgrade menu

- Web search access would let me check the company, its founders, and pay bands. That would move the failed-attribution entry and the market calibration from unverified to checked.
- A link to the live job post would confirm the posting's current status.
- Your minimum base salary would let me check the pay gate.

## Questions

1. What is your minimum base salary, and would €52,000 with equity be acceptable?
2. What domain did the calendar invite come from, and does the video link go to that same domain?
3. Have you ever done research or design work with no other designer to check it? If so, what did you do?

You can answer in prose, or skip any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.