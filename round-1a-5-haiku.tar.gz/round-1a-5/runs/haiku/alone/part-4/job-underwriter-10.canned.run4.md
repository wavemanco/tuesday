**Decision: conditional_go.** The posting and the recruiting contact are consistent with a small, real company hiring a designer. Your fit is strong on the must-haves. The main unknown is what "first designer, own it end to end" means in practice. This is an assessment from public sources and your background, not proof of the company's status.

**Hard gates:** Hybrid Galway location fits. Your pay floor and equity expectations are not stated, so the €52–60k band and 0.5–1% equity are unchecked against them. Work authorization and schedule are not stated in what you gave me.

**Fit ledger (confidence on CV-sourced claims is `medium` unless you can show work):**
- Must-have, direct: 3+ years of product design; strong Figma; running your own user research; working directly with engineers.
- Must-have, partial: owning the booking flow end to end (you redesigned checkout, not the whole flow).
- Implied, transferability: working as the only designer (you have never done it).
- Implied, transferability: research with school owners (you researched travel-booking customers).

Research tier: L1 — searches 5 of 5, fetches 1 of 2

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer job". Pages: fernquay.example/about (fetched); fernquay.example/careers/product-designer (search snippet). |
| 2 | Role-family sweep | yes | "product designer salary Ireland 3-5 years experience typical range": Tillerby 2026 Ireland Design Salary Report (n=520). |
| 3 | Hiring manager's public footprint | yes | "Fernquay Ronan Kehoe Galway": public LinkedIn snippet only. |

**Role reality**
- Organization `[grounded]`: The company's own about page says it makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, based in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers.
- Posting `[grounded]`: The careers page is live. It matches your posting on title, hybrid pattern, and €52,000–€60,000 plus equity. Applications go to a jobs address on the company's own domain, with one real project.
- Contradiction, minor `[grounded]`: The company site calls Saoirse a co-founder; the WhatsApp message calls her CTO. These are compatible, but confirm her title.
- Ronan `[grounded]`: LinkedIn lists him as co-founder and CEO, previously a product lead for five years at a Galway travel-software company. Worth knowing for positioning; I haven't looked further.
- Market calibration `[generic]`: Tillerby's 2026 Ireland data for 3–5 years' experience gives a median of €57,000 and an interquartile range of €51,500–€62,000. The posted band sits around the median, so the salary is ordinary, not a red flag.
- Scope read `[inferred]`: "First designer", "own the flow", and "research calls with owners" suggests a generalist role with wide scope and little design support.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Source |
|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | — | CV: 4 years |
| R2 | Strong Figma | must_have | direct | medium | — | CV: daily use |
| R3 | Own user research | must_have | direct | medium | — | CV: monthly usability sessions |
| R4 | Work directly with engineers | must_have | direct | medium | — | CV: squad with four engineers |
| R5 | Own booking flow end to end | must_have | partial | medium | presentation | CV: checkout redesign |
| R6 | Work as the only designer | implied | partial | medium | transferability | No prior sole-designer role |
| R7 | Research with school owners | implied | partial | medium | transferability | Travel customers, not B2B operators |

**Gap recovery queue** (questions are in the closing block)
- R5: Show that the checkout work touched the wider booking flow, or describe what you owned beyond it.
- R6: Name something you have shipped with limited design support, or a time you made calls without a design lead.
- R7: Any interview or usability work with businesses or operators, even small.

**Opportunity risk register**
- *Verification, `low`:* A search for the company's registration (Companies Registration Office) returned nothing. This is an unchecked item, not evidence against the company. Check the register yourself at cro.ie.
- *Scope, `medium`:* Sole-designer role plus end-to-end ownership plus research. Ask what design support exists.
- *Equity, `medium`:* 0.5–1% at a six-person company can be worth little or a lot. Ask for the share count, vesting, and strike or exercise terms before you rely on it.
- *Funding, `low`:* The company says it is funded by its customers. That reduces investor-churn risk but ties revenue to a small customer base. Unknown how concentrated it is.
- Not triggered: no failed attribution (the employer is confirmed on its own site); no red flag under the skill's criteria. The WhatsApp scheduling is routine and gets no entry.

**Application plan**
1. The video call is normal. Check that the invite arrived from the company's domain and that the Saoirse named in it is the Saoirse on the website.
2. Before any written offer, don't send bank, tax, or ID details. Payroll details come only after a written offer.
3. Prepare to explain how you would work as the only designer, and how you'd run research with school owners. Lead with the usability sessions and the checkout work.
4. This is positioning advice, not text to send. If you want wording for your application, say so and I'll draft it for your approval.
5. The call prep is mock-interview's job if you want a rehearsal.

**Dossier offer:** I can save this as `tuesday-dossier.md` so the findings carry into later sessions.

**Upgrade menu**
- Sharing the checkout case study (or a link) would firm up R5 and R3.
- Your pay floor and equity expectations would close the hard-gate check.
- Your authorization and schedule would close the remaining hard-gate check.
- Deeper diligence on the company (funding, reviews, news): up to 5 more searches and 2 more fetches. I'll run that only if you say yes.

**Questions**
1. What is your pay floor, and does 0.5–1% equity matter to you?
2. Have you ever owned a flow end to end, beyond the checkout?
3. Have you run research with business owners or operators?

Answer, skip, or say "continue" and I'll proceed on what we have.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.