**Decision: conditional_go.** Worth applying, and the company checks out as real so far. Before any offer, confirm the equity terms and that the sole-designer role has the support you need.

**Is it legit?** Partly verified. Fernquay has a public site (fernquay.example/about) describing it as a six-person Galway company making booking software for sea-kayak, surf and sailing schools, founded 2023 by Ronan Kehoe and Saoirse Doyle. The careers page is live and matches the posting: hybrid, two days a week in Galway, €52,000–€60,000 plus equity, applications to jobs@fernquay.example with one real project. Ronan's public profile lists him as co-founder and CEO, previously a product lead at a Galway travel-software company for five years. A thin online footprint is what a 2023 company of six looks like, so it isn't by itself a warning sign. The WhatsApp message contains nothing that asks for money, a deposit, or bank details. The one thing I can't verify is that the video invite comes from a fernquay address, so check that before the call.

**Fit (per requirement)**
- **Strong:** 4 years as a product designer (requirement is 3+); Figma daily; redesigned a checkout flow; ran monthly customer usability sessions; worked in a squad with four engineers; living in Galway matches the hybrid pattern.
- **Partial, transferable:** "Own the booking flow end to end." Your evidence is the checkout flow, so the question is how much of the end-to-end ownership was yours. Describe your actual role, not the whole project.
- **Partial, domain:** "Run research calls with school owners." Your research was with travel customers. School owners are small-business operators, which is a different audience, but the method carries over.
- **Gap (the main one):** "First designer." You have never been the only designer. This is a capability and support gap, not a hard gate. Your squad experience is the nearest evidence, and you should say plainly how design decisions got made there.
- **Unknown:** your salary floor. The posted range is a fact; whether it clears your floor is not something I can assess.

**Market calibration:** a 2026 Ireland salary survey (Tillerby, n=520) puts product designers with 3–5 years at a median of €57,000 (interquartile range €51,500–€62,000) [generic]. The posted range sits inside that band, slightly below the median midpoint. I found no benchmark for 0.5–1% equity at this stage, so treat that term as uncalibrated.

**Risks**
- **Equity (medium):** the posting doesn't say whether this is options or shares, the vesting schedule, the strike price, or what happens if you leave. Get this in writing before accepting anything.
- **Sole-designer load (medium):** a one-person design function with two engineers and a co-founder CEO. Ask who gives design critique and what research budget exists.
- **Outreach channel (low):** a recruiter-style approach over WhatsApp, with the real details arriving by email. This is common in small companies. Verify the invite's sender domain and that the call names the company.
- **Failed attribution:** none. The company, posting and co-founder all resolved to public sources.

**Application plan**
1. Reply on WhatsApp to confirm the time, then check the invite came from a fernquay address.
2. Prepare the 45-minute call around the checkout case study. Lead with the decisions you made and the research behind them, and state your role exactly. Don't say you "owned" the flow if you contributed to it.
3. Prepare an honest answer on working without another designer: how design critique happened in your squad, and what you'd do without it.
4. Before any offer, ask in writing: options or shares, vesting, strike price, leaver terms, research budget, and who the design decisions report to.

**Research tier: L1 — searches 4 of 5, fetches 1 of 2**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Fernquay Galway booking software sea kayak surf schools", "Fernquay careers product designer". Fetched fernquay.example/careers/product-designer. The about page was read from a search snippet, not fetched. |
| 2 | Role-family sweep | yes | Query: "product designer salary Ireland Galway 3 years experience". Source: Tillerby 2026 Ireland Design Salary Report. |
| 3 | Hiring manager's public footprint | yes | Query: "Ronan Kehoe Fernquay co-founder". Source: public LinkedIn profile, read from a search snippet. |

**Upgrade menu:** a link to the live posting or the invite email's headers would confirm the outreach channel. The checkout case study's details would let me check the positioning claims. A list of what you actually owned in that project would close the end-to-end gap. An L2 pass (funding, hiring patterns, recent news on Fernquay) would add up to 5 searches and 2 fetches; I can run it if you want it.

**Dossier:** I can save this assessment as `tuesday-dossier.md` if you want to carry it into interview prep.

**Questions**
1. Did you apply through the careers email with your case study, or did Ronan reach out first? And did the invite come from a fernquay address?
2. How did design decisions get made in your squad, and how did you handle critique when no other designer was in the room?
3. What's your salary floor, and what do you need on equity terms before you'd consider an offer?

Response mode: answer any of these in a sentence, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.