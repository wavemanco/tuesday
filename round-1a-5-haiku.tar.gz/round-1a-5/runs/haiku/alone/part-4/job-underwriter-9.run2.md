**Decision: conditional_go.** The offer is probably genuine. Asking for bank, PPS and passport details at onboarding is normal in Ireland, and your in-person interviews at their office count for a lot. What's wrong is the order of steps: you're asked to accept first, and the sensitive data follows through a link. Verify the employer and the portal before you send anything.

**Decision snapshot**

- **Fit (confidence per requirement, from your stated background [grounded]):** Strong on 2+ years' payroll (3 years, 90 staff), starters and leavers, the monthly payroll-to-ledger reconciliation, Excel (pivots, XLOOKUP) and the Payroll Technician certificate. Partial on pension changes (you've never run them yourself) and on PAYE/PRSI/USC depth, which you have in practice but haven't been tested on in Irish statutory detail [inferred]. Scale is a step up: 240 staff monthly, against your 90 fortnightly.
- **Hard gates:** Salary €40,000 sits inside the €38–42k band [grounded]. Hybrid, two days a week in Limerick: unknown, because you haven't said where you live or whether you can commute. Notice period: unknown.
- **Opportunity:** No red flag on the role itself. The one item to handle is the data request, covered below.
- **Research tier: L0, no searches run.** The employer-existence check is quicker for you to do directly (see Step 1), so I didn't spend search budget on it.

**Is the data request normal?** Mostly yes:
- **Bank details** for salary, entered once you're employed, are standard.
- **PPS number** is needed by the employer to register you with Revenue, which happens at the start of employment, not before.
- **Passport scan** for a right-to-work check is common, and the original must be checked in person, which is why they ask you to bring it on day one. Ask what they store, for how long, and who can see it.

The concern is that payroll and identity data are what fraudsters go after. A real employer would not object to you verifying it first.

**Before you accept (Step 1: verify, using contacts you find yourself)**

1. Find Marrowgate's website and phone number by searching, not from the email. Check that the domain matches `marrowgatehousing.ie` exactly.
2. Call the switchboard and ask for the People Team to confirm the offer and the onboarding link. You could also ask Declan Garvagh directly, since you've met the team.
3. Check the company's registration on the CRO register. If they call themselves an approved housing body, check the Approved Housing Bodies Regulatory Authority's register too.
4. When the portal link arrives, check that its domain is theirs, or the known domain of their payroll provider. Don't enter your details through any link that doesn't match. Never send your PPS number, bank details or passport scan by email.
5. Don't accept by email until 1–4 are done. Five working days is enough time.

**Gap recovery queue** (what would close each gap, not a question)

- **Pension changes:** Ask in the interview follow-up what scheme they run and who owns the pension changes. Closing it: a plan to shadow or be trained in the first 90 days, or a short course.
- **Hybrid commute and notice period:** Closes the hard-gate unknowns.
- **Irish statutory depth (PAYE/PRSI/USC):** Closes with a worked example or a short test from the employer.

**Opportunity risk register**

- **Data-request sequence** (`severity: medium`, `class: process`): payroll and identity data requested via a portal link after acceptance. Routine, but verify before submitting.
- **Employer existence** (`severity: medium`, standing): not confirmed by search here. Verify via steps 1–3 above.

**Application plan (as far as evidence allows)**

Accept only after verification. Lead with your payroll-to-ledger reconciliation and high-volume starters and leavers. State pensions as a learning area, not a gap you've hidden. Don't claim experience you haven't had.

**Upgrade menu**

- The live job posting link, plus the company's careers page: confirms the posting is current and matches the offer.
- Your commute and notice period: closes the hard gates.
- The pension scheme details: sizes the pension gap.
- Search-based verification (L1): confirms the employer's existence, registration and approved-housing status.

Would you like a dossier file (`tuesday-dossier.md`) saved for later use? It's optional.

**Questions**

1. Can you commute to Limerick two days a week, and what's your notice period?
2. Do you want me to draft the questions to send to the People Team before you accept?

Response modes: answer either or both, or say "skip".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.