**Job 1 (Operations Analyst, Duinvaart Cold Chain): worth applying to, on conditions. `conditional_go`.**
**Job 2 (Supply Planner, Kroonhaven Foods): not worth your time now. `no_go`.**

Web search was refused in this session, so neither employer has been checked and no salary band is established. Both conclusions rest on the posting text and your background.

# Job 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

- **Fit ledger.**
  - `hard_gate`: unclear: R9 (Hybrid, three days a week in Rotterdam office)
  - `must_have`: direct: R1, R2, R3, R4, R7 · adjacent: R5 (Temperature compliance across refrigerated fleet)
  - `important`: direct: R8 · unclear: R6 (Refrigerated and cold-chain operations)
  - `preferred`: adjacent: R10 (Dutch)

  R5 — delivery-performance tracking carries over, temperature data does not; R6 — no cold-chain evidence either way yet; R9 — schedule and commute, unstated by you so far.
- **Opportunity ledger.** The role is specific and well scoped (RR4), but the employer is unverified (RR1) and route authority and temperature ownership are unstated (RR2, RR3).
- **Hard gates:** unconfirmed: R9 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on its own careers page (RR1); (2) three days a week in Rotterdam is workable for you (R9); (3) the temperature role is reporting on compliance, not owning cold-chain operations (R5, R6, RR3).
- **What would change this:** a verified employer and a workable schedule keep it at `conditional_go`. Confirmed cold-chain ownership would raise R5 and R6. A failed R9 would make it `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam | `[grounded]` JD header; existence not established, research unavailable |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A reporting-and-coordination role with three named outputs and no stated team size | `[inferred]` from the three responsibilities |
| Market calibration | Not established. No salary band was searched, so none is given | — |
| Unknowns | Salary (not stated); temperature monitoring tools and who acts on a breach; whether this role approves route changes or recommends them | — |
| Contradictions | None visible from the posting alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Self-reported, not yet verified | `[grounded]` your background | none |
| R2 | Strong SQL | must_have | direct | medium | none | SQL used daily in the role. Self-reported | `[grounded]` your background | none |
| R3 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily. Self-reported | `[grounded]` your background | none |
| R4 | Track on-time delivery | must_have | direct | medium | none | You built and maintain the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| R5 | Track temperature compliance across the refrigerated fleet | must_have | adjacent | low | transferability | Delivery-performance tracking carries over. No temperature or compliance data in your background | `[inferred]` adjacency from R4 | Q2 (below) |
| R6 | Refrigerated and cold-chain operations knowledge | important | unclear | low | discovery | Your background is parcel, not cold chain. The posting does not say how deep the cold-chain knowledge must go | `[inferred]` from the JD's fleet wording | Q2 (below) |
| R7 | Build weekly dashboards in Power BI | must_have | direct | medium | none | Your dashboards are weekly and depot-facing | `[grounded]` your background | none |
| R8 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R9 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated whether this schedule or the Amsterdam–Rotterdam commute works for you | `[grounded]` JD; candidate constraint not given | Q1 (below) |
| R10 | Dutch a plus | preferred | adjacent | low | transferability | Conversational, not fluent | `[grounded]` your background | none; a preferred item |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature and cold-chain work (R5, R6) | transferability | Delivery-performance tracking and dashboards. Nothing on temperature, storage or compliance thresholds | Temperature compliance is the part of the role your background does not cover, and it is named first in the posting | Any monitoring of a threshold-based metric; any sensor, telemetry or breach-report work | A breach report, a KPI definition, or a dashboard that tracks a threshold | `[inferred]` bridge from R4; `[generic]` that this is the likeliest interview objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. This entry records that the check could not run, not that the employer was found wanting | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Route-change authority unstated | unknown | — | "work with depot managers on route changes" | The role may recommend route changes while depot managers decide | `[inferred]` from the JD's wording against its silence on decision rights | Which route changes does this role approve itself, and which go to depot managers? | unresolved |
| RR3 | Temperature-compliance ownership unstated | unknown | — | "track … temperature compliance across our refrigerated fleet" | The role may report on compliance while operations owns the response to a breach | `[inferred]` from the JD's tracking verb against its silence on who acts | When a temperature threshold is breached, who acts, and does this role own any of that response? | unresolved |
| RR4 | Clear, specific deliverables | positive_signal | — | "build weekly dashboards in Power BI" | The role has concrete outputs and a defined cadence | `[grounded]` JD | What does the weekly dashboard go to, and who acts on it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and the live posting on Duinvaart's own careers page before spending application effort | RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead your CV with the on-time delivery dashboard, the route-performance review and the weekly Power BI reporting, stated as they happened | R4, R7, R8 | `[grounded]` your background | pending your approval |
| A3 | If asked about temperature, say what is true: you have tracked performance thresholds, not cold-chain compliance | R5, R6 | `[grounded]` R5 row | proposed |
| A4 | Prepare one anonymised SQL or Power BI example from your carrier work | R2, R3 | `[grounded]` background | pending your approval |

# Job 2: Supply Planner, Kroonhaven Foods, Utrecht

## Decision snapshot

**Not worth your time now. Status: `no_go`.**

- **Fit ledger.**
  - `hard_gate`: unclear: P7 (On-site in Utrecht)
  - `must_have`: adjacent: P1 (3+ years of FMCG supply or demand planning), P3 (Weekly S&OP meeting), P6 (Fluent Dutch) · unclear: P5 (Advanced Excel) · absent: P2 (Own the 13-week supply plan), P4 (SAP IBP or similar)

  P2 and P4 — no planning history and no planning system in your background; P1 and P3 — adjacent only, and the adjacency is reporting rather than planning; P6 — conversational against a fluent requirement; P5 — not yet established.
- **Opportunity ledger.** The employer is unverified (RR1). The scope names no team or sign-off authority (RR2).
- **Hard gates:** none failed; unconfirmed: P7 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a planning history you have not yet mentioned, a planning system you have used, or a role the posting no longer requires to be a planner. Those would have to be true for this to be worth pursuing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` JD; existence not established, research unavailable |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planning-owner role for one product range, with a recurring cross-functional meeting; team size not stated | `[inferred]` from the responsibilities |
| Market calibration | Not established. No salary band was searched | — |
| Unknowns | Team size; planning system in use; salary | — |
| Contradictions | None visible from the posting alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| P1 | 3+ years of supply or demand planning in FMCG | must_have | adjacent | low | transferability | Weekly reporting and dashboards are the nearest adjacency. You have not planned supply or demand | `[inferred]` from your background | none; the limit stands |
| P2 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | No planning work in your background | `[grounded]` your background | none; no realistic closure in the short term |
| P3 | Run the weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly route-performance review with managers | `[inferred]` from your background | none; the limit stands |
| P4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system named in your background | `[grounded]` your background | none |
| P5 | Advanced Excel | must_have | unclear | low | discovery | Excel is not named in your background | `[grounded]` absence in your background | Q3 (below) |
| P6 | Fluent Dutch | must_have | adjacent | low | capability | Conversational, not fluent | `[grounded]` your background | none |
| P7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You have not stated whether this works for you | `[grounded]` JD; candidate constraint not given | Q1 (below) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. This records that the check could not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team and sign-off authority unstated | unknown | — | "Own the 13-week supply plan" | The planner may own the plan without the authority or staff to change capacity | `[inferred]` from the scope against its silence on team | How many planners are on this team, and who signs off the capacity numbers? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Do not apply to this role now | P2 and P4 are absent and carry the role; no realistic closure in the short term | `[grounded]` rows P2, P4 | proposed |
| B2 | Put your effort into operations-analyst postings that ask for SQL and Power BI and do not require a planning system | Those are the postings your evidence matches | `[grounded]` rows R2, R3 against the posting requirements | proposed |

# Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both employers were searched, and every call was refused because web search permission was not granted. It would have moved the existence check for both employers (RR1 in each register) and the live-posting check |
| 2. Role-family sweep | unavailable | Both role-family searches were refused. It would have set the market calibration for both roles. No band is given here |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Verification and salary bands are not established. Both postings withhold salary, and the bands are not given.

# Dossier offer

If you'd like, I can save these two assessments as a `tuesday-dossier.md` file you can come back to.

# Upgrade menu

- Permission to run web search, so I can check both employers on their own sites and set salary bands for both roles. It would be up to 5 searches and 2 fetches for each check.
- A live posting link or each employer's careers page URL. This closes RR1 in both registers.
- Anything showing temperature, cold-storage or compliance data work. This would move R5 and R6.
- Any Excel, forecasting or planning-tool use. This would move P5, and P4 if you have used a planning system.

# Questions

Q1 (R9) — Is three days a week in the Rotterdam office, with the commute from Amsterdam, workable for you?

Q2 (R5, R6, G1) — Have you ever worked with temperature, cold-storage or other compliance data, even in a side task? What did you track, and what happened when a threshold was breached?

Q3 (P5) — How advanced is your Excel? Do you build lookups, pivot tables and scenario models, and have you used any planning or forecasting tool?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.