**Decision: conditional_go.** The role fits you well on the evidence you've given. The one open issue is whether Marrowgate is who the offer says it is, and you can close that before you reply.

**Short answer to your question:** Asking for bank details, your PPS number and a passport check after a written offer is normal for an Irish employer. The PPS number is needed for Revenue reporting, bank details are needed to pay you, and employers must check right to work before you start. The original passport on day one is standard. What's unusual is sending a link in an email and asking for a passport scan through it. That's a common way to collect this data, and it's also the route a fake offer would use, so the link is what to verify. Nothing you've described is a red flag under the skill's threshold: you had in-person interviews, the offer is in writing, the salary matches the ad, and the manager is named. [grounded]

**Research tier: L0, no searches run.** Company checks and market rates were not looked up in this pass. Those are in the upgrade menu.

## Role reality
- **Scope:** Monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-GL reconciliation, staff queries. Reports to Declan Garvagh, Finance Manager. [grounded]
- **Scale step-up:** Your current payroll is 90 staff on fortnightly cycles. Monthly for 240 is a larger job. [inferred]
- **Pay:** €40,000 sits inside the advertised €38–42k band. Your floor is unknown. [grounded]
- **Location and schedule:** Hybrid, two days a week in Limerick. Whether you can commute to that is a hard-gate check I don't know the answer to. [grounded]
- **Market calibration:** I haven't checked this against current Irish salary data, so I can't say whether €40k is typical. [generic]

## Evidence map
| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | 2+ years running payroll | met | high | none | 3 years fortnightly payroll, 90 staff |
| 2 | must-have | Working knowledge of PAYE, PRSI, USC | likely | medium | presentation | Payroll Technician certificate 2024; your CV doesn't say which rules you applied day to day |
| 3 | must-have | Strong Excel | met | high | none | Pivot tables, XLOOKUP, daily use |
| 4 | must-have | Payroll qualification or working towards | met | high | none | Payroll Technician certificate 2024 |
| 5 | duty | Monthly payroll-to-GL reconciliation | met | high | none | Done monthly at the hotel group |
| 6 | duty | Starters and leavers | met | high | none | Done at the hotel group |
| 7 | duty | Pension changes | not met | low | capability | No hands-on experience; your manager handled these |
| 8 | duty | Staff payroll queries | unknown | low | discovery | Not covered in your background |
| 9 | gate | Commute to Limerick, 2 days a week | unknown | — | hard_gate | Not in your background |

[grounded] for the requirements and your evidence; [inferred] for the fit calls.

## Gap recovery queue
- **Row 7 (pension changes):** Your payroll background covers the work around pensions, but not the processing itself. Closing it means knowing how their scheme is administered and whether training is provided. Note that the ad lists pension changes as a duty, not a must-have.
- **Row 2 (Irish rules):** Closing this means naming the PAYE, PRSI and USC work you did, so the certificate is backed by examples.
- **Row 8 (staff queries):** Closing this means checking how much of the job is staff-facing.
- **Row 9 (location):** This is a hard gate. Confirm you can reach Limerick on the two office days before you accept.

## Opportunity risk register
| Class | Severity | Item | Status |
|---|---|---|---|
| Failed attribution | medium | I cannot yet confirm that Marrowgate Housing exists as described. Reasons could be a new or small employer, a stale posting, or a non-employer using the name. None is ranked as likely. Caps the decision at conditional_go until verified. | Unverified (L0) |
| Process | low | Bank, PPS and passport details requested through a portal link after acceptance. Routine, but the link must be verified before you send anything. | Check, not a red flag |

**Verification steps before you reply to the offer:**
1. Find Marrowgate's phone number on their official website, not in the email. Call and ask for the People Team to confirm the offer and that Declan Garvagh is the hiring manager.
2. Check that the portal link's domain matches their website domain exactly, and that it uses HTTPS.
3. Ask for their data-protection notice: what they keep, for how long, and who to contact.
4. Share the passport at the minimum level they need. If they accept it, you can show the original on day one and send only what they require.
5. Five working days is enough to do these. If you need more, ask for a short extension in writing.

## Application plan
- **Lead with:** three years of fortnightly payroll at 90 staff, the reconciliation, and your Excel work. These are verified by your own experience. [grounded]
- **Don't claim:** pension administration. Say you haven't done it, and that you'd learn it from their provider or the scheme. [inferred]

## Evidence status
| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run in this pass; offered in the upgrade menu |
| 2 | Role-family sweep (pay and scope) | skipped | Not run in this pass; offered in the upgrade menu |
| 3 | Hiring manager's public footprint | n/a | No research on Declan Garvagh was requested |

## Dossier offer
If you'd like, I can save this assessment as a `tuesday-dossier.md` file for later use.

## Upgrade menu
- **Company check (L1):** Confirms Marrowgate exists and is hiring for this role, and checks their careers page against the ad. Up to 5 searches and 2 page fetches. Unlocks the failed-attribution item.
- **Market salary check (L1):** Shows whether €40k is typical for this role in Limerick. Unlocks the calibration line.
- **Your CV, with PAYE/PRSI/USC examples:** Raises row 2 from medium to high confidence.

## Questions
1. Can you commute to Limerick on the two office days? This is a hard gate, so I need the answer before the decision can move past conditional_go.
2. Did your hotel payroll use Irish PAYE, PRSI and USC rules, and can you name one example of each? Answer "skip" if you'd rather not.
3. What is your lowest acceptable salary?

Answer in prose, or say "skip" on any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.