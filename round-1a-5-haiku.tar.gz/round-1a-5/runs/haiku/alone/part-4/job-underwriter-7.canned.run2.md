The skill requires reading its reference files before building the evidence map, so I'll load those first.
**Yes, apply, on conditions. Status: `conditional_go`.** You meet all three stated gates and the experience requirement. The weak spots are the caseload you have never held, leg-ulcer care, and Doppler, and those are fixable in how you present your experience and in what you ask the employer.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4 · unclear: R5 (clear, timely written records)
- `important` — direct: R6, R8, R10, R14 · adjacent: R7 (leg-ulcer care), R13 (own caseload) · unclear: R9 (continence care), R11 (end-of-life visits), R12 (care planning)
- `preferred` — absent: R15 (Doppler assessment)

R7 — leg-ulcer work adjacent to your pressure-ulcer and surgical-wound care; R13 — home visiting carries over, but no caseload held; R5 (`low`) — records not yet evidenced; R15 (`medium`) — Doppler not held, a preferred row.

**Opportunity ledger.** The employer is real and the role is clearly scoped, but the support model for the caseload is unstated (RR1) and I could not find the posting on the employer's careers page (RR2). The posted pay range is in line with the market survey, though its floor sits below the interquartile range (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live on the employer's careers page (RR2); (2) caseload size and senior-nurse support are confirmed (RR1, R13); (3) leg-ulcer and Doppler are presented as adjacent or not held, never as held (R7, R15).

**What would change this:** if the post cannot be confirmed live, the status drops to `hold_pending_answers` until it is; if caseload support is thin, the caseload row (R13) becomes a must-have risk.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` employer about page, fetched |
| Role | Band 5 community staff nurse; district nursing for housebound adults; your own caseload, supported by a senior community nurse | `[grounded]` JD |
| Pay and vehicle | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Band 5 community staff nurse, England, 2026 survey (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% paid mileage | `[generic]` Wardround 2026 pay guide; national, not Calderdale-specific |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead, Halifax district nursing; public speaker profile | `[grounded]` community nursing forum speaker page (professional footprint only) |
| Scope read | Caseload-holding with senior support, and documentation on the EPR | `[inferred]` from the JD's wording |
| Unknowns | Caseload size; supervision frequency; continence, end-of-life and care-planning scope; EPR system; whether Doppler training is provided; whether the post is live | — |
| Contradictions | None between the JD and the employer's about page. The careers page could not be located, so the post is unverified. | `[grounded]` about page; `[inferred]` from one search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated on CV; registration not yet checked against the register | `[grounded]` CV, self-report | Check your own register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, full, stated; not checked | `[grounded]` CV, self-report | none |
| R3 | Work based in Halifax | hard_gate | direct | medium | none | You live in Halifax, the role's base | `[grounded]` CV and JD | none |
| R4 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on documentation or EPR use; a discharge-to-assess role plausibly involved notes | `[inferred]` from the discharge-to-assess role | Ask which EPR you used and whether you can show a sanitised note |
| R6 | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Wound-care experience carries over; no leg-ulcer work stated; compression or venous or arterial assessment not mentioned | `[inferred]` from R6 | Ask whether you have assessed or dressed leg ulcers |
| R8 | Catheter care | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | Not stated on CV | `[grounded]` CV silence | Ask about continence work in your discharge-to-assess role |
| R10 | Insulin administration | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R11 | End-of-life visits | important | unclear | low | discovery | Not stated; the acute and discharge work could include it | `[inferred]` | Ask whether end-of-life visits featured in your home visits |
| R12 | Care planning | important | unclear | low | discovery | Not stated; discharge-to-assess work usually involves planning | `[inferred]` | Ask whether you owned care plans for the patients you visited |
| R13 | Holding your own caseload | important | adjacent | medium | transferability | Home visits and discharge follow-up carry over; you have never held an ongoing caseload | `[grounded]` CV, self-statement | Ask about any case you have run end to end |
| R14 | Home visits in patients' homes | important | direct | medium | none | Visited patients at home in their first week after discharge | `[grounded]` CV | none |
| R15 | Doppler assessment | preferred | absent | medium | capability | Stated as never done | `[grounded]` your statement | Closure path: a course, with the employer's training (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7, important) | transferability | Wound-care experience with pressure and surgical wounds; no leg-ulcer work stated | Leg-ulcer care is named first in the JD's list | Any leg-ulcer dressings, compression or venous assessment, even brief | Clinical log, training record | `[inferred]` bridge from R6 |
| G2 | Own caseload (R13, important) | transferability | Home visits and discharge follow-up; no ongoing caseload | The role is built around one; it is the main objection | A patient list you kept from first visit to review, even short-term | A sanitised example of a case you ran | `[inferred]` bridge from R14 |
| G3 | Doppler (R15, preferred) | capability | Not held | Preferred, not essential; a closure path is the answer | A course booked, or training the employer offers | Training record, plan | `[generic]` pattern for preferred skills of this kind |
| G4 | Records and EPR (R5, must_have) | discovery | Documentation not stated on CV | An essential requirement | Notes you wrote; EPR you used | A sanitised note, or a list of systems used | `[inferred]` |
| G5 | Continence, end-of-life, care planning (R9, R11, R12) | discovery | Not stated | Named responsibilities; the interview may probe them | Specific visits where you owned the plan | A sanitised care plan | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload support unstated | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | Caseload size and the senior nurse's review pattern are not given | `[inferred]` from JD silence on caseload size | What is a typical caseload for a new Band 5 here, and how often does the senior nurse review cases? | unresolved |
| RR2 | Posting not located on careers page | risk_signal | low | "Current vacancies are listed on our careers page" (about page) | The post may be stale, or only on an aggregator | `[inferred]` from one search returning only the about page | Which page on your website lists this post, and is it still open? | unresolved |
| RR3 | Posted range against market | unknown | — | "£31,050–£37,800 a year plus mileage" | The floor is below the survey interquartile range; the top is above it | `[generic]` 2026 national survey, n=1,240, not Calderdale-specific | Where in the range does a new caseload-holding Band 5 normally start, and how is mileage paid? | unresolved |
| RR4 | Pool cars provided | positive_signal | — | "pool cars are provided" | Reduces the vehicle cost of the role | `[grounded]` JD | Are pool cars available from your first day? | noted |
| RR5 | Doppler training possibly provided | unknown | — | Public talk: "Doppler training for staff new to community work" | Training for non-holders may be available | `[inferred]` from one conference talk title, not a statement about this post | Is Doppler training provided to staff who do not hold it when they start? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the post is live on the careers page before applying | RR2 | `[grounded]` RR2 | advice |
| A2 | CV wording, proposed: keep "Wound care: pressure ulcers and surgical wounds" and "Visited patients at home in their first week after discharge" exactly as they are; do not add leg-ulcer or caseload claims | R7, R13 | `[grounded]` your CV sentences | pending your approval |
| A3 | Contact Rhiannon Mabbott for the informal chat, using contact details from the employer's own site, and ask RR1 and RR5 | RR1, RR5 | `[grounded]` JD; the contact route is advice | pending your approval |
| A4 | Rehearse the caseload answer before any interview; mock-interview can do this | R13 | `[generic]` caseload questions are standard for this role type | advice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "calderbrookhealth careers vacancies community staff nurse"; fetched calderbrookhealth.example/about. Entity exists as described; careers page not located, so the posting is unverified (RR2). |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary NHS 2026 district nursing", which returned the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` and RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned communitynursingforum.example/speakers/rhiannon-mabbott. Public professional footprint only; informs RR5 and the questions. |

The Wardround survey is national, and its band is `[generic]`; it does not show this employer's offer.

## Upgrade menu

- The caseload size and senior-nurse support model → RR1 closes; R13 moves toward direct.
- The careers-page address for this post → RR2 closes.
- A sanitised care plan or discharge note → R5 and R12 move toward direct.
- A leg-ulcer training or clinical record → R7 moves toward direct.
- A booked Doppler course or the employer's training answer → R15 has a closure path.
- A deeper research pass on Calderbrook (leadership, staff reports, past postings; up to 5 more searches and 2 more fetches) — say the word and it runs.

For a file you can keep, I can write this assessment to `tuesday-dossier.md`.

Three questions, each tagged to its row:

R13 — Have you ever been responsible for a set of patients over several weeks, from first visit to plan review, even on a small scale?

R7 — Have you assessed or dressed leg ulcers yourself, venous or arterial, and did you do any compression therapy?

R9, R11, R12 — In your discharge-to-assess work, did you own the care plan for the patients you visited, and did continence or end-of-life care come up?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.