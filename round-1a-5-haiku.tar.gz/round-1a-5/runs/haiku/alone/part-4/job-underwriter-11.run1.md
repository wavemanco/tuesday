**Duinvaart Cold Chain, Operations Analyst: yes, worth applying to, on conditions (`conditional_go`).**
**Kroonhaven Foods, Supply Planner: no, not now (`no_go`).**

## Decision snapshot: Duinvaart Cold Chain

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (hybrid, three days a week in Rotterdam)
  - `must_have` — direct: R2 (2+ years in logistics), R3 (SQL), R4 (Power BI or Tableau), R5a (on-time delivery tracking) · adjacent: R5b (temperature compliance)
  - `important` — direct: R6 (weekly dashboards), R7 (depot managers on route changes)
  - `preferred` — adjacent: R8 (Dutch a plus)

  R1 — open gate, waiting on your answer; R5b — a bridge only, with no cold-chain data behind it.
- **Opportunity ledger.** Scope and tools are concrete (RR3). The pay is not stated and the employer is not yet verified (RR2, RR1).
- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 is workable, meaning you can do the Rotterdam commute; (2) the role is verified on Duinvaart's own careers page (RR1); (3) the pay range is confirmed (RR2); (4) R5b is presented as a bridge, never as cold-chain experience.
- **What would change this:** if the Rotterdam commute is not workable, R1 fails and the status becomes `no_go`.

## Decision snapshot: Kroonhaven Foods

- **Fit ledger.**
  - `hard_gate` — unclear: K1 (on-site in Utrecht)
  - `must_have` — adjacent: K4 (capacity against forecast), K5 (weekly S&OP), K7 (fluent Dutch) · unclear: K8 (advanced Excel) · absent: K2 (3+ years FMCG planning), K3 (13-week supply plan), K6 (SAP IBP or similar)

  K2, K3 and K6 are the planning years, the plan and the system, and your background touches none of them; K4, K5 and K7 are bridges with their limits named.
- **Opportunity ledger.** Scope is concrete, with a named 13-week plan and weekly S&OP (RR6). The pay is not stated and the employer is not verified (RR5, RR4).
- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Why `no_go`:** three must-haves (K2, K3, K6) are `absent`, and no closure is realistic before applying. That is the capability-gap rule, not a judgement on the employer.
- **What would change this:** a documented FMCG planning history of 3+ years, or hands-on 13-week plan or SAP IBP work. Reframing cannot supply either.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam | Kroonhaven Foods, Utrecht | `[grounded]` your posting text; not verified (see Evidence status) |
| Mandate | Track on-time and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | Own the 13-week supply plan for chilled ready meals; balance capacity against forecast; run weekly S&OP | `[grounded]` posting text |
| Working pattern | Hybrid, three days a week in Rotterdam | On-site in Utrecht | `[grounded]` posting text |
| Pay | Not stated | Not stated | `[grounded]` posting text omits it |
| Market calibration | Not run: the salary search was refused | Not run: the salary search was refused | — |
| Contradictions | None found in the posting text | None found in the posting text | `[grounded]` |

## Evidence map: Duinvaart

Your background is self-report, so confidence is at most `medium` until something inspectable backs it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and commute are not given, so the gate is not established | `[grounded]` posting; no candidate claim | Q1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL used daily; no artifact yet | `[grounded]` your background | a sanitized query would raise to `high` |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily | `[grounded]` your background | none |
| R5a | Track on-time delivery | must_have | direct | medium | none | You ran the on-time dashboard depot managers use. That was parcel delivery, not a refrigerated fleet, so say so | `[grounded]` your background | none |
| R5b | Track temperature compliance across refrigerated fleet | must_have | adjacent | low | transferability | No temperature or cold-chain data in your background. Limit: compliance tracking is the nearest bridge, and no cold-chain data was used | `[inferred]` from the dashboard work | Q2 |
| R6 | Weekly dashboards in Power BI | important | direct | medium | none | Same dashboard work as R3–R5a | `[grounded]` your background | none |
| R7 | Work with depot managers on route changes | important | direct | medium | none | Ran the weekly route-performance review | `[grounded]` your background | none |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, not fluent | `[grounded]` your statement | state the level exactly |

## Evidence map: Kroonhaven

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Location not given | `[grounded]` posting; no candidate claim | Q1 |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | No planning history. This is a years requirement, so it is not a gate | `[grounded]` your background | closure path: a planning-analyst step first |
| K3 | Own the 13-week supply plan | must_have | absent | none | capability | Not in your background | `[grounded]` your background | carry as risk |
| K4 | Balance production capacity against forecast | must_have | adjacent | low | transferability | Route-capacity and delivery-performance analysis is nearest. Limit: no production or forecast work | `[inferred]` from route work | none |
| K5 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | Ran a weekly cross-team review. Limit: it was route performance, not S&OP | `[grounded]` your background | none |
| K6 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning-system use | `[grounded]` your background | carry as risk |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch. Limit: not fluent | `[grounded]` your statement | state the level exactly |
| K8 | Advanced Excel | must_have | unclear | low | discovery | Excel is not in your background; SQL and Power BI are | `[grounded]` absence from background | Excel level in upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Closes it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b) | transferability | Dashboard work, no cold-chain data | Turns a must-have from bridge into evidence | Any reefer log, sensor-alert or temperature work | `[inferred]` bridge |
| G2 | Rotterdam commute (R1) | hard_gate | Location not given | Could fail the gate | Your answer to Q1 | `[grounded]` posting |
| G3 | Planning years, plan, system (K2, K3, K6) | capability | None of the three appear in your background | Three must-haves at `absent` drive the `no_go` | Real planning history; no quick closure | `[grounded]` background |
| G4 | Capacity, S&OP, Dutch (K4, K5, K7) | transferability | Bridges with stated limits | Helps framing, cannot close the rows | Artifacts of the bridge work | `[inferred]` |
| G5 | Excel level (K8) | discovery | Not stated | Could move K8 | Your Excel level | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (Duinvaart) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Not checked: both company searches were refused, so there is no attribution either way. Postings can be stale or from a small firm; this is not a claim about this one | `[generic]` pattern for companies of this size | Can you point me at this role on your own careers page, and who would I interview with? | unresolved |
| RR2 | Pay not stated (Duinvaart) | unknown | — | (no pay in posting) | The pay band is uncalibrated because the salary search was refused | `[grounded]` posting omits pay | What is the salary range budgeted for this post? | unresolved |
| RR3 | Concrete scope (Duinvaart) | positive_signal | — | "Track on-time delivery and temperature compliance…" | Responsibilities and tools are specific | `[grounded]` posting text | Which route decisions would I own directly, and which go to depot managers? | noted |
| RR4 | Employer not verified (Kroonhaven) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as RR1 | `[generic]` pattern for companies of this size | Can you point me at this role on your own careers page, and who would I interview with? | unresolved |
| RR5 | Pay not stated (Kroonhaven) | unknown | — | (no pay in posting) | Same as RR2 | `[grounded]` posting omits pay | What is the salary range budgeted for this post? | unresolved |
| RR6 | Concrete scope (Kroonhaven) | positive_signal | — | "Own the 13-week supply plan…" | Responsibilities are specific | `[grounded]` posting text | Which planning system and forecast data would I use in week one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the Duinvaart CV with the on-time dashboard depot managers use, in your existing words, with no new claims | R5a, R6 | `[grounded]` your background | pending your approval |
| A2 | Describe Dutch as "conversational," never "fluent," unless you say otherwise | R8 | `[grounded]` your statement | pending your approval |
| A3 | Address temperature compliance directly: "I haven't worked with cold-chain temperature data; my compliance dashboards are the nearest" | R5b | `[inferred]` bridge | pending your approval |
| A4 | Verify the Duinvaart role on its careers page and ask for the pay range before interview | RR1, RR2 | `[grounded]` register | pending your approval |
| A5 | Skip Kroonhaven for now. Target demand or logistics analyst roles where SQL and Power BI are the core and planning is not required | K2, K3, K6 | `[inferred]` from the map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Duinvaart Cold Chain Rotterdam; Kroonhaven Foods Utrecht chilled ready meals) were refused permission. Would have moved RR1 and RR4 |
| 2. Role-family sweep | unavailable | One search (supply planner FMCG salary Utrecht) was refused. Would have set the market calibration and RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Because the searches were refused, neither employer is verified and no pay band is calibrated. Those are the gaps the verification questions cover.

Dossier offer: I can write this up as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Permission to search: runs the two company checks and the salary search, which closes or sharpens RR1, RR4, RR2 and RR5.
- Live posting links from each company's own careers page: confirms or closes RR1 and RR4.
- A sanitized dashboard screenshot or query sample: raises R3 and R5a to `high`.
- Your Excel level: resolves K8.

**Questions**

R1 — Where do you live now, and could you commute to Rotterdam three days a week?

R5b — Have you ever worked with temperature or cold-chain data, such as reefer logs or sensor alerts?

Q3 — Are there non-negotiables I should check these roles against, such as a pay floor, contract type or commute limit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.