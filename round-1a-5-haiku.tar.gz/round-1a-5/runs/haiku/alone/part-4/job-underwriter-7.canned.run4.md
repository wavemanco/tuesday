## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** On what you've stated, the three gates are met, so the registration is not the problem. The open items are the written-records requirement and what "small caseload" means here, and the CV shows neither.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4 · unclear: R13 (clear, timely written records)
- `important`: direct: R5, R7, R9 · adjacent: R6 (leg-ulcer care), R10 (care planning), R11 (own caseload) · unclear: R8 (continence care), R12 (end-of-life visits)
- `preferred`: absent: R14 (Doppler assessment)

R13 (`low`) is the one must-have with no evidence yet; R6, R10 and R11 are credible bridges with their limits named; R14 is absent but desirable only.

**Opportunity ledger.** The posting is sound on its own terms: an established CIC with an NHS contract, a stated pay range and a defined remit (RR6, RR4). Still open are whether the posting is live (RR1), the caseload support model and records system (RR2, RR3), and the contract basis (RR5). There are no red flags and no requests for payment or bank details.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live on the employer's careers page (RR1); (2) the records and caseload answers in the questions below come back clean (R13, RR2, RR3); (3) caseload and leg-ulcer work are presented as adjacent, never as held (R10, R11, R6); (4) you check your own NMC register entry and licence before applying, since both are stated here, not checked.
- **What would change this:** if the caseload answer shows R11 is a must-have with no bridge, the status moves to `hold_pending_answers`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` about page |
| Remit | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, EPR documentation | `[grounded]` advert |
| Scope read | A small caseload with senior support: a normal starting remit for the grade | `[inferred]` from the advert's wording, which names no caseload size |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | The advert's range sits around the survey median (£34,300; IQR £32,400–£36,600); 61% of respondents were paid mileage | `[generic]` Wardround 2026 England survey, n=1,240 |
| Unknowns | Caseload size, support model, records system, contract basis, start date, whether the post is permanent, the mileage rate | — |
| Contradictions | None found between the advert and the about page; the careers page was not reached, so the posting is unverified | `[grounded]` about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Registration active, revalidation March 2028; stated, not inspected | `[grounded]` your CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; status is yours to check | `[grounded]` your CV | You check your licence |
| R3 | Based in Halifax | hard_gate | direct | high | none | You live in Halifax; the role is Halifax-based | `[grounded]` your statement, advert | none |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse stated; a length requirement is graded, not gated | `[grounded]` CV | none |
| R5 | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over; leg-ulcer work is not named; the limit is that it is unstated | `[inferred]` from R5 | Q3 |
| R7 | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | CV covers catheters only | `[grounded]` CV silence | Upgrade menu |
| R9 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R10 | Care planning | important | adjacent | medium | transferability | Discharge-to-assess visits imply post-discharge assessment; whether you planned care over time is not stated. The limit is that you did not own ongoing plans | `[inferred]` from the role's visit pattern | Q2 |
| R11 | Own small caseload | important | adjacent | medium | transferability | You have never held one; home visits in the discharge team are the nearest match, with the limit named | `[grounded]` your statement | Q2 |
| R12 | End-of-life visits | important | unclear | low | discovery | Not on the CV; not ruled out | `[grounded]` CV silence | Upgrade menu |
| R13 | Clear, timely written records | must_have | unclear | low | discovery | Essential; the CV is silent on records and names no system | `[grounded]` CV silence | Q1 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not held; no evidence after looking | `[grounded]` your statement | Closure path: training (see RR7) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R13, must_have) | discovery | No records system named on the CV | An essential; decides whether the status moves | Any EPR you have written clinical notes in; notes done on home visits | A sample note, the system's name | `[grounded]` CV silence |
| G2 | Own caseload (R11), care planning (R10) | transferability | Home visits in discharge-to-assess; no caseload held | The most likely interview objection | Visits you followed up, plans you arranged, lists of patients you owned | A visit log, a discharge-to-assess handover sheet | `[inferred]` bridge from the visits described |
| G3 | Leg-ulcer care (R6) | transferability | Wound care is direct; leg ulcers are not named | Leg-ulcer work is the first thing the team lead's public work covers | Dressing and compression decisions on wounds at home | A wound-care record, training certificate | `[inferred]` |
| G4 | Doppler (R14, preferred) | capability | None held | Preferred only; a training pathway may close it | Any ankle-brachial or Doppler exposure, even observed | Training record | `[generic]` closure route |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" (about page) | The advert may be stale or listed differently | `[inferred]` the careers page was not reached | Is this Community Staff Nurse post live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Caseload size and support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" may still be a full caseload for a new nurse | `[generic]` pattern for this grade | What caseload size does a new community staff nurse start with, and how often do you meet the senior nurse? | unresolved |
| RR3 | Records system unnamed | unknown | — | "all recorded on our electronic patient record" | Documentation may take much of a home visit | `[generic]` pattern for community EPRs | Which electronic patient record do you use, and how much of a visit's notes are completed at the patient's home? | unresolved |
| RR4 | Pay sits near the survey median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is within the normal band; mileage is standard | `[generic]` survey against `[grounded]` advert | Is this the budgeted figure, and what is the mileage rate? | noted |
| RR5 | Contract basis unstated | unknown | — | (advert silent) | The post may be fixed-term; your permanence constraint is not given | `[inferred]` from silence | Is this post permanent or fixed-term, and how is it funded? | unresolved |
| RR6 | Employer established | positive_signal | — | "running adult community nursing … under an NHS contract … 410 staff" | The employer exists as described; no failed-attribution entry | `[grounded]` about page | — | noted |
| RR7 | Team lead's public focus | positive_signal | — | Speaker profile: "nurse-led leg-ulcer clinics and … Doppler training for staff new to community work" | Doppler training may exist for new community staff, so R14 could close | `[grounded]` profile for what was said; `[inferred]` that it applies to this role | — | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the discharge-team home visits in terms of what you did on them (wound, catheter, insulin). Do not use "community nurse", "caseload" or "Doppler" | Stays within R5, R7, R9, R11 as stated | `[grounded]` CV | pending your approval |
| A1 | Confirm the post is live on the careers page; check your NMC register entry and licence | RR1, R1, R2 | `[grounded]` | you |
| A2 | Put RR2, RR3 and RR5 to Rhiannon Mabbott at the informal chat | Verification questions | `[grounded]` register | pending your approval |
| A3 | Lead with home-visit wound, catheter and insulin work; name leg ulcers and Doppler as not yet held | The team lead's public focus is leg-ulcer work | `[inferred]` from RR7 | pending your approval |
| A4 | Ask whether Doppler training is offered to new community staff | R14 | `[inferred]` from RR7 | pending your approval |

## Evidence status

Verified: none of your claims yet; they are stated, not inspected. The employer's existence (RR6) and the team lead's public role (RR7) are verified from the sources below.

Your National Insurance number is not needed for this assessment, so I have not used or repeated it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse jobs careers"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Moved the organization row and RR6. The careers page it names was not reached, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 salary Halifax district nursing 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Halifax", which returned the speaker profile on communitynursingforum.example/speakers/rhiannon-mabbott. Moved RR7 and the positioning in A3 |

## Upgrade menu

- A confirmed live careers-page link or the posting's own page → RR1 closes
- The name of your records system and a sample note → R13 moves
- Continence assessment or catheter detail → R8 settles
- Any end-of-life exposure → R12 settles
- Caseload or handover answers → R10 and R11 move
- Any Doppler or ankle-brachial exposure → R14 moves
- The contract basis and your pay floor → RR5 closes, and the constraint check can run; you have not given constraints yet
- Deeper research on Calderbrook (leadership and staffing, staff and candidate reports; up to 5 more searches and 2 more fetches): say the word and it runs

If you'd like, I can save this as `tuesday-dossier.md` for later sessions.

Q1 (R13): Which electronic patient record have you written clinical notes in, and how did you keep notes current across a day of home visits?

Q2 (R10, R11): In the 18 months in discharge-to-assess, did you ever plan a patient's care over several visits, or own a list of patients, even informally? What did you decide, and what did the team do?

Q3 (R6, R14): Have you assessed or dressed leg ulcers at home, or been present for a Doppler or ankle-brachial reading in any role, even observed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.