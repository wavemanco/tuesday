Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor". Asking for a fee, a passport and bank details before any offer, and a cheque to deposit and forward money is a known scam pattern, and this job is very likely a scam. Hold all of it: don't pay, send documents, or deposit the cheque until you have checked the invite with the employer through a phone number or address you find on its own website or careers page, not through the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-12-denied-33a8a198/25192386-5dbb-48f2-ba3b-503194f09865/scratchpad/brennock_remote_administrative_assistant_interview_pack.md. It covers the ad's four areas against your message. Your strongest honest bridge is the appointment book for four physios toward calendars. Travel booking and Excel are where the material is thinnest.

Say the word and I'll play the Skeptic on B2, the question the pack names as the highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Does the office manager make the hiring decision, or are they screening for someone else? The answer reweights the personas.

Could you paste the full ad text? The pack is built on your summary, and the requirement rows would then quote the ad's exact words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_administrative_assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** office manager (name and relationship not given)
**Round:** 30-minute video call, as stated in the invite
**Changes in this version:** first version. Built on your summary of the ad and your background message, with no research run.

## How to use this pack

Personas describe how a question will be asked. Types describe what it is scoring:

- **JD**: can you do the listed job, including its gaps
- **EXP**: does what you did before hold up under questions
- **CASE**: a practical problem, worked live
- **VAL**: values or behaviour (not detected for this round)
- **CO**: company knowledge (no research run)

The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements come from your summary of the ad. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says appointments for four physios, not calendars for executives. Bridge: "For two years I ran the appointment book for four physios." Nothing more is added to it. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom in your own words; if not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" (your summary of the ad) | "good with Word" (your message) | medium | [grounded] | presentation | The quote reaches Word in other terms. Bridge: "I'm good with Word." No practice is added. |
| F4 | "preparing documents in Word and Excel" (your summary of the ad) | "okay with Excel" (your message) | low | [grounded] | discovery | "Okay" does not show how far your Excel use goes. Answer slot: if you have built or edited a spreadsheet for work, say what it held and who used it; if not, say so and say what you would learn first. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices and does not reach it. Bridge: "At the clinic I chased unpaid invoices." Answer slot: if you logged, matched or approved supplier invoices, say which steps and how; if you did not, say so plainly and describe what chasing involved. |

Your message also says "two years as a receptionist at a physiotherapy clinic". That is your background sentence, used in A1.

## Prohibited claims

These are not to be coached. Each is an overstatement of something you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Manages executive calendars | Inflated form of F1 | "I ran the appointment book for four physios." |
| Has processed supplier invoices | Inflated form of "chased unpaid invoices" (F5) | "I chased unpaid invoices." |
| Is fluent in Excel | Inflated form of "okay with Excel" (F4) | "okay with Excel" |

## Personas

Relationship prior: a hiring-side interviewer for a practical admin role. Weights are shown so you can recalibrate.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes gaps: travel booking, Excel level, invoice processing | Highest. The ad lists three areas your message does not cover directly, and a 30-minute screen is where gaps get tested. | Rehearse B1 and B2 until they are boring. Name the gap before it is named for you. |
| Case / practical | Asks how you would handle a live admin task | Medium. A remote admin role is judged on how you work through tasks. | Clarify first, then take the steps in order. Claim no past work in the answer. |
| Conversational | Opens with "walk me through your background" | Low to medium. Likely as the opener, and still scored. | Use the 90-second arc in A1, built only from your quoted sentences. |

## Question banks

### Skeptic (highest weight, depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "okay with Excel" (your message); [grounded] "chased unpaid invoices" (your message) | Name the gaps from your own material: Excel is "okay with Excel", and travel booking does not appear in your background. Say what you would do about each in the first month, as a plan. If you have booked travel for anyone, say how; if not, say so plainly. Keep to 90 seconds. | F2 and F4 are the gaps this question targets. It is the likeliest opening for a screen on an admin role. |
| B2 | "You ran appointments for four physios. What does that tell me about running calendars for a team?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | **Highest-ROI prep in this pack.** Describe the book in your words: four physios, one book, what you did to keep it accurate. Say plainly what it held and what it did not (appointments, not travel or executive diaries). Answer slot: if you changed or resolved bookings for anyone, say how; if not, say so plainly and say how you would handle clashes across a team's calendars. Hold through two follow-ups by returning to the book. | F1 is the bridge the interviewer is most likely to test. The stated gap sits at the edge of the quote, so the honest answer must be ready before the probe. |
| B3 | "Which steps of supplier invoice processing have you done yourself?" | JD | [grounded] "chased unpaid invoices" (your message) | "At the clinic I chased unpaid invoices." Answer slot: if you logged, matched or approved supplier invoices, say which steps and how, in your own words; if you did not, say so plainly and describe what chasing involved. | F5 is transferability. The ad lists processing, so the probe will follow. |
| B4 | "Walk me through how you would build a monthly spend summary in Excel." | JD | [grounded] "okay with Excel" (your message) | Be accurate about your level: "okay with Excel". Walk through the steps in order: confirm the source list and the columns, set up the totals, check them against the source. Answer slot: if you have built a spreadsheet for work, say what it held and who used it; if not, say so and say what you would learn first. | F4 is the thin Excel evidence, and this probe tests competence directly. |

### Case / practical (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A supplier says they never got payment for an invoice you can't find. What do you do?" | CASE | [generic] | Clarify: which invoice, which supplier, what the records show. Check the record, ask the supplier for a copy, confirm with whoever approved it, then reply. Claim no past case. | A live problem from the ad's invoice line. Asked as a decision, so no claim about your past is needed. |
| C2 | "Two people need to travel next Tuesday on a tight budget. Walk me through booking it." | CASE | [generic] | Clarify dates, the budget cap, who approves, and any preferred carriers. Compare options against the cap, confirm with the travellers, and record the booking. Claim no past bookings. | Covers the ad's travel line, which your material does not show. |
| C3 | "How would you check a supplier invoice before it gets paid?" | JD | [generic] | Check the invoice against the approval and the order, check the amount and dates, check the payee details against your records, and flag any mismatch to the approver before paying. | Covers the ad's processing line from the procedure side. |

### Conversational (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices"; "good with Word" (your message) | A 90-second arc in this order: the role and the two years, the appointment book, chasing unpaid invoices, then Word. Use the quoted words. Do not extend any of them. | The opener is scored. The arc is built from your own sentences, so nothing in it needs defending. |
| A2 | "What's drawing you to remote admin work?" | JD | [generic] | One true sentence in your own words. | A casual motivation check. The guidance makes no claim about your history. |

### Requirement coverage

| Ad requirement | Covered by |
|---|---|
| Managing calendars | A1, B2, C2 |
| Booking travel | B1, C2 (no evidence in your material, see F2) |
| Preparing documents in Word and Excel | B4, A1 |
| Processing supplier invoices | B3, C1, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for whoever holds this role?" | Shows you are planning for the job, not just for the interview. |
| R2 | "Which calendar, travel and invoice tools does the team use day to day?" | Shows you would learn them quickly, and gives you the tool names to rehearse. |
| R3 | "What would you want this person to have working well by the end of the first month?" | Turns the interview into a conversation about the job. |
| R4 | "How does the work split between this role and the rest of the team?" | Shows you are thinking about working with others, even remotely. |
| R5 | "What's the next step after this call?" | A practical close that keeps the process moving on the interviewer's terms. |

No interviewer profile exists, so no reverse question ties to a career path.

## Sources

- Provided documents: your message (the invite's wording, your summary of the ad, and your background).
- Research tier: L0. Provided documents only. No search or fetch was run in this turn.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities values` | unavailable | Values cheat sheet: not built. Research was not run at L0. |
| 2. `Brennock Facilities interview process remote administrative` | unavailable | Loop structure: the 30-minute call is taken from the invite alone. |
| 3. `Brennock Facilities strategy` / recent news | unavailable | Grounding brief: not built. |
| 4. `{interviewer name} Brennock Facilities` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Remote Administrative Assistant` JD | unavailable | Your summary of the ad fixes the fit snapshot, so this target would move only the wording of the requirements. |

## Upgrade menu

- The full ad text → the requirement rows quote the exact wording instead of your summary.
- Your CV → the evidence cells can quote sentences beyond your message.
- The office manager's name and role → persona weights and reverse questions can be tailored.
- A `tuesday-dossier.md` → verified evidence and a sharper ranking of the likeliest objections.
- Whatever the 30 minutes will cover → the question coverage can be checked against it.
