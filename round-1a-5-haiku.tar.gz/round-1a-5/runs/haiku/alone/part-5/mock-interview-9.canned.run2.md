Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-9-canned-fac90668/34001ee4-1610-4679-95a2-75c21366ef41/scratchpad/halvering-elementary_fourth-grade-teacher_interview_pack.md. I built it for a panel of the principal and two fourth-grade teammates, since the invite gives no job description and no prep time.

You also included your SSN in the details you sent. I haven't used it, and interview prep doesn't need it. Keep it off resumes and anything you share with the school.

The pack's two biggest gaps are that you haven't taught fourth grade and haven't been a team lead. Questions B1 and B2 are the ones to rehearse hardest. The pack also gives bridges that use only your own sentences, so you won't claim more than you did.

Say the word and I'll play the principal on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

1. Will Principal Vantongeren be your direct supervisor, and did HR mention a lesson demo or other task for the panel?
2. Do you have the full job posting? Its exact wording would sharpen the requirement rows. I can proceed without it.
3. Today is Wednesday, so Thursday may be tomorrow. How much time do you have to prepare? If it's short, I'll cut the pack to a triage.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organisation:** Orrinsford Community School District
**Format:** 45-minute panel
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team
**Built on:** the invite's wording and your résumé details. No job description, prep time or recruiter guidance was provided. Research was not run (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you did.

**Type key**
- **VAL**: behavioral and values alignment
- **EXP**: deep-dive into your experience and what you did
- **JD**: the role's stated requirements
- **CASE**: a live problem to reason through
- **CO**: company knowledge (not covered here; research not run)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Fourth Grade Teacher position" – invite | "Six years teaching third grade at a public elementary school in Joliet" – your CV | medium | [grounded] | transferability | Your material shows third grade, not fourth. Keep the words as they are: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: which parts of third-grade teaching carry into fourth grade, in your own words. If you have not yet worked out what changes in fourth grade, say so and say how you would learn it. |
| F2 | "valid Illinois Professional Educator License with an elementary endorsement" – invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" – your CV | high | [grounded] | none | No gap. Lead with the license and its date in those words. |
| F3 | Teaching reading in the elementary grades – [generic] | "I led our grade level's move to a new reading curriculum in 2024" – your CV; "I've run the after-school reading club for the last two years" – your message | medium | [generic] | none | No gap against a generic requirement. Say both sentences in your own words. |
| F4 | Leading or coordinating a grade-level team – [generic] | "I've never been a team lead" – your message; "I led our grade level's move to a new reading curriculum in 2024" – your CV | low | [generic] | transferability | The gap is stated, so you may say it: "I haven't been a team lead." Then bridge with adjacent work only: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which parts of that move you decided, in your own words. If the team decided, say so and say what you did within it. |
| F5 | Communicating with families – [generic] | "I write a weekly email to families" – your message | high | [generic] | none | No gap. Describe the email in your own words. Do not add response rates or outcomes. |

## Persona table

The panel is weighted by blending the top two personas for each member's relationship (`references/personas.md`). Their roles are the invite's; there are no interviewer profiles, so there is no interviewer read.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | "Third grade, not fourth. Why you?" | High: the invite is for fourth grade, and F1 and F4 are the largest gaps | Rehearse B1 and B2 until they are plain and calm |
| Case / Strategist | Principal | A live problem about planning for a new grade | Medium-high: a principal hires for capability on a real problem | Clarify first, then plan, and say what you would need to know |
| Peer Evaluator | Team members | How you would work with the team; disagreement; credit | High: they will judge what you add to their own work | Reciprocity first: what you bring to them, not only what you need |
| Data-Driven Prober | Team members | How you know something worked | Medium: the résumé has no numbers, so they will likely ask what you saw | Say what you can count and what you cannot. Do not invent figures |

Weights: Skeptic 4 questions (highest, because it covers the biggest gap); Peer Evaluator 3; Case / Strategist 3; Data-Driven Prober 2.

## Prohibited claims

The pack will not coach any of these. Built locally from the fit snapshot.

| Claim | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | F1: the only grade listed is third | "Six years teaching third grade at a public elementary school in Joliet." |
| Having been a team lead, or having led a team | F4: "I've never been a team lead" | "I haven't been a team lead. I led our grade level's move to a new reading curriculum in 2024." |
| Results from the reading curriculum or the reading club (scores, growth, student counts) | No basis given | Describe what you did, and say what you did or did not measure |
| Family response rates or outcomes from the weekly email | No basis given | "I write a weekly email to families." |

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Fourth grade is different from the grade you've taught. What carries over, and what would you have to learn?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | **Highest-ROI prep in this pack.** Name what carries over, in your own words, then the limit, then how you would learn the fourth-grade content. Hold through two follow-ups by returning to what you taught. Never add a fourth-grade claim. Answer slot: if you have worked out what changes in fourth grade, say it; if not, say so and say how you would learn it. | F1 is the largest gap in the fit snapshot, and this objection will come in some form. Deepest rehearsal |
| B2 | "You haven't been a team lead. How would you coordinate a grade-level team?" | JD | [grounded] "I've never been a team lead" – your message | Say "I haven't been a team lead." Then bridge with "I led our grade level's move to a new reading curriculum in 2024", naming only the parts you decided. Do not say "I have led teams." | F4: the second-largest gap, which the principal is likely to test |
| B3 | "How much of the 2024 curriculum move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the parts you decided, in your own words. If the team decided it, say so and say what you did within that decision. Stay calm, and do not defend more than you did | Attribution probe on the strongest leadership-adjacent line in the résumé |
| B4 | "A parent is worried about their child's reading. How would you keep them informed?" | JD | [grounded] "I write a weekly email to families" – your message | Describe the weekly email in your own words: what it covers and how you write it. Do not add response rates or outcomes | F5: a family-communication requirement |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On your first day with a fourth-grade class, what would you want to know first?" | CASE | [generic] | Clarify before planning: current reading levels, which standards and materials the class already uses, and what the team already does. Then say what you would do in week one | A generic case for the grade move; it makes no claim about your past |
| A2 | "If your team were changing its reading approach, what would you do first?" | CASE | [generic] | Clarify, then tie to your own experience in your own words: "I led our grade level's move to a new reading curriculum in 2024." Name steps only if you took them | Builds on F3; a planning question, not a record |
| A3 | "How would you check, after a term, whether a new reading approach is working?" | CASE | [generic] | Name what you would measure and who you would ask. If you have measured something before, say what and how, and if not, say so | Leads into D1, and tests the plan rather than a past figure |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If we disagreed on a lesson plan, how would you handle it?" | VAL | [generic] | Propose principles for handling disagreement, not an invented example. Tell a disagreement story only if you have one | Peer probe on disagreement style; no past claim is made |
| C2 | "What would you bring to our team that we don't already have?" | JD | [grounded] "I've run the after-school reading club for the last two years" – your message | Say what the reading club is, in your own words, and what it gives a reading team. Do not claim student numbers or results | Reciprocity: what you give the peer team, not only what you need |
| C3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" – your CV | Use "we" for the team's work and "I" for your own part. Name your part only as the quote supports it | Peer credit probe, answered with the same attribution rule as B3 |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" – your CV | Answer slot: if you tracked anything, say what and how. If you did not, say so plainly and name what you would track. Do not claim score gains | The résumé has no measure, so this is the likeliest numbers probe |
| D2 | "How many students were in the after-school reading club, and what changed for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years" – your message | Answer slot: if you counted anything, say what. If you did not, say so and say what you observed, in your own words | A prober's natural follow-up on a program with no figures given |

## Reverse questions

Ask any of these. Each includes why it lands.

1. "What does the fourth-grade team already do to support a teacher who is new to the grade?" **Why it lands:** it shows you are planning for the grade move, and the answer tells you what support exists.
2. "What reading approach does the team use now, and how long has it been in place?" **Why it lands:** you learn what a reading curriculum move would involve here.
3. "How do the team members split planning and assessment work?" **Why it lands:** it prepares you for B2 and C1, and it shows you care how the team runs.
4. "What does the principal look for in the first year of a new team member?" **Why it lands:** the principal sits on the panel, and the answer shows what they will judge.
5. (Reciprocity, peer) "What would you need from a new teammate in their first month?" **Why it lands:** it turns the question into a peer conversation and lets you offer what you bring.

## Sources

- **Provided documents:** the school's invite text and the résumé details you gave in this conversation.
- **Searches:** none. **Fetches:** none.
- **Research tier:** L0 (provided documents only). Research was not consented to, so it was not run.
- **Targets:** interviewer public footprint, representative JD, company values and strategy brief were all skipped, with no consent given.

## Upgrade menu

- The full job posting or JD text → the requirement rows become exact quotes, and the B-bank questions can name the posted requirements.
- Consent to research at a deeper tier → public footprint for Principal Dolores Vantongeren and the district's published values, plus a grounding brief.
- Your prep time before Thursday → a prioritized triage section.
- A recruiter or HR email on focus areas or any lesson demo or task → coverage of any pre-declared deliverable.
- A `tuesday-dossier.md` → an underwriter's evidence grading and prohibited-claims review, which would replace the locally built prohibited list.
