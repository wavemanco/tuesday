# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call your mobile.
**Built for:** Sam
**Research tier:** L0 (your message, the advert as you pasted it, and Hannah's LinkedIn message only)

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** your past work checked closely, **JD** the advert's listed duties, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

With about a day, in this order:

1. Know your **notice period** (section A2). The pack does not have it.
2. Settle your **pay line** (A1): "£42,000" in your own words, and what you say if pushed.
3. Be ready on the **hybrid** pattern and your three-day limit (A3).
4. Have a plain answer for **why you're moving** (A4).
5. Be ready for **SAP** and **production planning / QA** (A7, A8). These are the two real gaps.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your work is delivery scheduling, not production scheduling. Make that case and its limits: "I schedule deliveries for our three depots." Do not stretch it to planning or QA. |
| F2 | "Track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | high | [grounded] | none | No gap. Expect a probe on how you chase: see A5. |
| F3 | "Keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | high | [grounded] | none | No gap, but the figure will be probed: see A6. |
| F4 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [inferred] | discovery | The spreadsheet rebuild suggests Excel, but you have not said your level with it. Answer slot in A6. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Meets the requirement. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Words you can use: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as a past. |
| F7 | "Weekly report on on-time dispatch" (advert) | none given | none | [generic] | discovery | Nothing in your material covers dispatch reporting. Answer slot in A9. |
| F8 | "Coordinate ... between planning, the warehouse and QA" (advert), the planning and QA side | none given | none | [generic] | discovery | Nothing in your material covers planning or QA. Answer slot in A8. |
| F9 | Notice period (not in the advert; Hannah will ask) | none given | none | [generic] | hard_gate | Not settled by anything you have shared. Hannah will ask, so the figure is needed before Thursday. |

## Prohibited claims

These are claims this pack will not coach, even if the role seems to invite them.

| # | Do not claim | Basis | Honest form |
|---|---|---|---|
| P1 | Any SAP or ERP experience, or that your in-house system is an ERP | "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We ran our own in-house stock system." |
| P2 | Production planning, production scheduling, or QA coordination | Your material shows delivery scheduling only | "My scheduling was deliveries for three depots." |
| P3 | Dispatch reporting, or any weekly on-time figure | Not in your material | Answer slot (A9) |
| P4 | Sole credit for the drop in discrepancies | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you did and what happened, in those terms. Do not add that the rebuild was the only cause unless you know it. |
| P5 | Your current salary, or any figure for it | Not given | "I'd rather not share my current salary. I'm hoping for £42,000 for this role." |
| P6 | A notice period | Not given | Your actual figure, once you have checked it (A2). |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Recruiter screen | Pay, notice, hybrid, reason for moving, then a quick check of the advert's requirements | Near certain. Hannah has said what she will cover, and it is a screen, not a technical round | Short, plain answers. Give your number, then stop talking. |

This pack covers the recruiter screen only. A hiring-manager round would reweight the banks towards JD and CASE questions.

## Question banks

### Recruiter screen

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | JD | What are your salary expectations? | Your message: "I'm hoping for £42,000" | Say: "I'm hoping for £42,000." Stop there. If she asks about flexibility, repeat the same words. Do not explain how you chose it. | Pay is a term she has said she will cover. £42,000 sits inside the advert's £38,000–£44,000. |
| A2 | JD | What is your notice period? | None given (answer slot) | Answer slot. Give your actual contractual notice, in your own words. If you are unsure, say what you know and that you will confirm it. | Notice is not in the advert or your message, and she has said she will ask. |
| A3 | JD | How would the hybrid pattern work for you? | Your message: "two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth works. I live in north Bristol. I'd want to keep it to two, and three is the most I could do." | Schedule and location are terms she will check. Keep the boundary plain. |
| A4 | EXP | What's prompting the move? | Your message: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | "Our Bristol office is closing next year, and the only offer I have is relocating to Reading, which I don't want." Do not criticise the company, and do not add a growth story. | Reason for leaving is asked in every screen. The true answer is short and does not need embellishing. |
| A5 | JD | Tell me about your operations or logistics experience. | Your message: "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip" | Four years as a logistics coordinator. You schedule deliveries for three depots and chase suppliers when orders slip. Those are the facts; do not widen them. | Covers the 2+ years requirement and the supplier-chasing duty. |
| A6 | EXP | How do you keep stock records accurate? | Your message: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you rebuilt and what happened over the year, in those words. If asked how the figure was counted: answer slot. If you do not know exactly how it was measured, say so. Be ready to say what you would check first. Also answer slot for Excel: say what you used the spreadsheet for, in your own words. | The figure will be probed. Precise attribution is safer than a confident guess. |
| A7 | JD | This role lists SAP or similar ERP as a plus. Do you have that? | Your message: "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We ran our own in-house stock system." Then: "I'd expect to learn it quickly, and I'd want to start with..." (say what you would do, as a plan). | The only real capability gap. Name it plainly and give a closure path. |
| A8 | JD | This role coordinates production schedules across planning, the warehouse and QA. Have you done that? | None given (answer slot) | Answer slot. If any of your work touched planning or QA, say what and how. If none did, say: "My scheduling was deliveries for three depots. I haven't coordinated with planning or QA, and here is how I'd get up to speed..." | Covers the headline duty. Your material does not show it, so do not imply it. |
| A9 | JD | How would you report on on-time dispatch? | None given (answer slot) | Answer slot. If you have produced any weekly report, say what it showed. If not, say what you would measure first. | The advert asks for a weekly report. Your material does not show one. |

## Reverse questions

Each one has a reason it lands. Ask at least one of these; you do not need all five.

1. **"What does a typical week look like across planning, the warehouse and QA?"** Why it lands: it tests whether the production-scheduling part is as the advert describes.
2. **"Which two days are on-site, and is that fixed or flexible week to week?"** Why it lands: the hybrid pattern is a term you need to check, and this confirms it stays within three days.
3. **"Is SAP used day to day, and what is the training if someone is new to it?"** Why it lands: it lets you test F6 without saying you have SAP experience.
4. **"How is on-time dispatch measured and reported, and who reads the weekly report?"** Why it lands: it shows you what the reporting duty involves.
5. **"What are the next steps and timing after this call?"** Why it lands: she said she would cover next steps, so this confirms what comes next.

## Sources

- **Provided documents:** your message about the role and your background; the advert text as you pasted it; Hannah Lowther's LinkedIn message about the call.
- **Research:** none run. Tier L0, so there were no searches or fetches.
- **Target accounting:** Research tier L0. Declared research targets: skipped.
- **Dossier:** none consumed.

## Upgrade menu

- Your notice period → a concrete answer for A2, and F9 closed
- Anything you know about the company's production planning or QA → a more specific answer for A8
- A `tuesday-dossier.md`, if you have one → a record of the gaps this prep found, for later sessions
