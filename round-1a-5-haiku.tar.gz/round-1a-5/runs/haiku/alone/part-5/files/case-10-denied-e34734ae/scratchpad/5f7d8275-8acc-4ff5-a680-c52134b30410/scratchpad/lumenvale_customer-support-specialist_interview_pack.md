# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist, remote
**Company:** Lumenvale Software
**Interview:** Text chat on Telegram with the support team lead (name not given)
**Relationship:** Hiring-side, the team lead who would manage the role. Treated as a hiring-manager round.
**Version:** First version. No earlier pack.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Each question is tagged with one type, and the rationale says why it is in the pack.

| Type | What is being scored |
|---|---|
| VAL | Behaviour against the company's published values. Not included: no values were found or supplied. |
| EXP | Whether what your CV says survives questions, and what you personally did |
| JD | Whether you can do the listed job, including its gaps |
| CO | Knowledge of the company's strategy. Not included: no research ran. |
| CASE | How you reason through a live problem from the job |

The guidance is scaffolding, not a script. Rehearse it in your own words, and only with what you actually did.

## Fit snapshot

The job ad was supplied as your summary, not as its full text, so requirements appear as plain prose, not quotations. Evidence is quoted from your message, which is the only source for your background.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap: three years against two. Expect a probe on whether a customer service advisor role counts as support. Words: "I've been a customer service advisor at an energy supplier for three years." |
| F2 | Zendesk or a similar ticketing tool (job ad, as you summarised it) | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a similar ticketing tool, so the quote reaches the requirement. Expect a Zendesk-specific probe. Words: "I use Freshdesk every day." Medium because nothing has been inspected. |
| F3 | Clear written communication (job ad, as you summarised it) | none given | none | [grounded] | discovery | Your material does not show written customer work. The chat interview tests it live. Answer slot: if you have written customer replies or notes you can point to, say what they were and who read them. If none come to mind, say so plainly and describe how you would write a customer reply. |
| F4 | Confidence handling escalations (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" — your message | low | [inferred] | transferability | Refunds training is adjacent to escalations. It does not show that you escalated. Words: "I trained four new starters on our refunds process last year." Answer slot: if any refund case went beyond your own limit, say what it was and where it went. If none did, say so and describe how you would decide what to pass on. |

## Prohibited claims

Built locally from the fit snapshot. No dossier was present. Each entry is a claim the guidance will not coach, with its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a support team | Inflated form of F1. Your sentence says advisor, not lead. | F1's quote at its own scope. Limit, as the pack's own observation: your material shows an advisor role, not a lead one. |
| Has used Zendesk | Inflated form of F2. Your sentence names Freshdesk. | "I use Freshdesk every day." |
| Wrote the refunds process | Inflated form of F4. Your sentence says you trained starters on it. | "I trained four new starters on our refunds process last year." |
| Has worked for a software company | Negative you stated: "I've never worked for a software company" | The plain acknowledgment, from your sentence: "I haven't worked for a software company." No slot. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of gaps: software background, writing, escalations | Top weight. A hiring-manager round primes Case and Skeptic, and your message names one clear background gap. | Rehearse the software-background objection until it is calm. Acknowledge it plainly, then bridge only with what you stated. |
| Case / Strategist | Live problems from the job: a refund dispute, an escalation | Mid weight. Hiring managers buy capability and test it live, and this is a support job. | Clarify the customer's problem first, then the steps, then the update you will give. |
| Conversational | Friendly opener, casual questions about the tool and your background | Low to mid weight. A chat interview can be terse, but a team lead may open warmly. Casual questions are still scored. | Prepare a 90-second arc on your background. Treat casual tool questions as scored. |
| Pressure | Interruption, challenge to your claim to be a support person | Low weight. Nothing in the material signals it, but a chat can read as blunt. | Pause, restate the question, hold a position through two follow-ups, then concede what is true. |
| Data-Driven Prober | Asks how the 60-a-day figure was counted | Low weight. Only one figure is on your CV-style material, so one defend-the-number question applies. | Say how you know the figure, what it includes, and the assumption you would defend least. |
| Values / Behavioral | Scenario probes tied to company values | Zero weight. No published values were found or supplied, so there is no values round to prepare for. | Not prepared. Ask for the company's values in the upgrade menu if you want them. |
| Peer Evaluator | Seam-splitting with adjacent teams | Excluded. The interviewer is the team lead who would manage the role, not a peer. | Not prepared. |

## Question banks

Weights: Skeptic 5 questions (top), Case 3, Conversational 3, Pressure 2, Data-Driven Prober 2. The most likely objection to you is S1, the software background. It is the highest-return prep in this pack.

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never worked for a software company. Why should we trust you to learn our product quickly?" | JD | [grounded] "I've never worked for a software company" — your message; "answering around 60 calls and emails a day" — your message | Start with the plain acknowledgment: "I haven't worked for a software company." Then return to your daily work: "My work has been answering around 60 calls and emails a day." Answer slot: if you have learned a product or tool quickly before, say what it was and how long it took. If you have not, say so and describe how you would learn this one in your first two weeks. Hold through two follow-ups by returning to the daily volume. Do not claim a product you have not learned. | The most predictable objection, and the negative is your own, so you may say it. Highest-return prep in this pack. |
| S2 | "Three years on the phones at an energy supplier. How much of that work was actually you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | Name what you did in a contact, in your own words. Concede specifically the parts that were the process or someone else's. Hold through two follow-ups on what was yours, and do not reach for more. | An attribution probe on F1. EXP because it tests what you did. |
| S3 | "Tell me about the refunds training you ran. Did you check how the four starters got on afterwards? If so, how?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what the training covered and who took it, in your own words. Answer slot: if you checked how they did, say how. If you did not, say so plainly. | F4 is your only training evidence. The second question asks rather than assumes that a check happened. |
| S4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I trained four new starters on our refunds process last year" — your message, the nearest material | Pick the part of the job you have least direct evidence for, and say how you would close it, as a plan. Escalations and the software side are the likely candidates from your material. Do not present a plan as past experience. | A persona stem from the Skeptic bank. It invites an honest gap answer, which is safer than a bluff. |
| S5 | "The job names Zendesk or a similar ticketing tool. What is your experience with those?" | JD | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk first, in those words, as the tool you use every day. Then say what you do in it. If asked about Zendesk and you have not used it, say so, and say how you would learn it. | F2 is medium. Freshdesk reaches the requirement, and a Zendesk-specific probe is likely. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes that their refund has been pending for twelve days and mentions a chargeback. Draft your first reply, then tell me what you would check next." | CASE | [generic] | Structure the reply: acknowledge the delay without blame, state what you will check and by when, say what happens if the check fails, and give the next update time. Time-box the draft to two minutes. | Tests written communication under pressure. No claim about your past. |
| C2 | "A ticket has been open for five days and the customer is now asking for a manager. What do you do?" | CASE | [generic] | Check what is unresolved and who owns the next step. Decide whether this needs escalation, and to whom. Tell the customer what happens next and by when. Say what you would record for the team lead. | Tests the escalations requirement as a decision, not as a record of past cases. |
| C3 | "Tell me about a written reply you sent to a customer that you are happy with." | JD | [grounded] job ad summary, written communication; no quote of yours carries a written reply | Pick one reply. Say what the customer's problem was, what you wrote, and what happened next, if you know. If you cannot name one, say so and describe a reply you would write today. | Covers the written-communication requirement, which F3 shows no evidence for. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through how you got into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | A 90-second arc: start with the three years at the energy supplier and the daily volume, in your words. Then the Freshdesk day, then the refunds training, then why you are here. Make no claim beyond these sentences. | Biography openers are scored even when casual. |
| D2 | "What does a day in Freshdesk look like for you?" | JD | [grounded] "I use Freshdesk every day" — your message | Say what you do in it, in your own words, and where your knowledge stops. If you do not know a feature, say so. | A casual wording of the tool requirement, which is still scored. |
| D3 | "Why customer support, rather than another part of the business?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | Say what has kept you in this work, in your own words. Answer slot: if you want to move toward software support, say what draws you to it. | Motivation. The quote carries the work; the reason is yours to give. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company" — your message; "I use Freshdesk every day" — your message | Pause and restate the question. Hold: "I haven't worked for a software company. What I bring is daily work in a ticket tool, Freshdesk, every day." Hold through two follow-ups by returning to Freshdesk and the daily volume. Concede specifically if challenged: "You're right that someone who has worked on the software side would start ahead on your product." | Hold-then-concede on the negative you stated. |
| P2 | "That's phone work, not support, isn't it?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | Hold with the quote: calls and emails are customer work, and the tickets you handle are in Freshdesk. Hold through two follow-ups. Concede what is fair: "Fair challenge. Most of my work was calls and emails, with tickets in Freshdesk." | A challenge to the bridge from F1. The quote carries the position you can defend. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "How did you arrive at around 60 a day? What does that count include?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Answer slot: say how you know the figure, what it includes (calls, emails, or both), and the assumption you would defend least. If it is an estimate, say so. | The defend-the-number slot for the one figure you gave. |
| R2 | "Of the 60 a day, did any come from refunds? If so, what share?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | Answer slot: if refunds were part of the 60, give the share as you know it and say how you estimated it. If none were, say so. | A probe linking the volume to the refunds training. The question asks; it does not assume refunds were in the 60. |

## Requirement coverage

| Requirement (job ad, as summarised) | Question IDs |
|---|---|
| 2+ years in customer support | D1, S2, R1, D3 |
| Zendesk or a similar ticketing tool | S5, D2 |
| Clear written communication | C3, C1 |
| Confidence handling escalations | C2, S4 |

## Reverse questions

Each one lands for a reason. None asks the interviewer to verify anything about the invite.

1. "Does the interview stay in this chat, or is there a call or video step after it?" Lands because it tells you what to prepare for and how many rounds to expect. It is a process question, not a check on the invite.
2. "What does a good first week look like for someone in this role?" Lands because it shows what they will measure early, and it shapes which parts of the pack to spend time on.
3. "Which ticketing tool do you run, and how much of it would I use on day one?" Lands because it asks about the Zendesk requirement in their own terms.
4. "When a case needs escalating, who decides, and how fast is a response expected?" Lands because escalations are a stated requirement, and the question shows you understand that.
5. "What did the last person in this role find hardest?" Lands because the answer tells you the probe they are likely to use.
6. "How do you give feedback on written replies to customers?" Lands because written communication is tested throughout a text interview.

No interviewer profile exists, so no reverse question ties to the interviewer's career path.

## Sections not included

- **Interviewer read:** no public information about the team lead. Only a role was given.
- **Prep triage:** prep time was not stated.
- **Graded deliverables:** none declared by the company.
- **Values cheat sheet:** no published values were found or supplied, so no values-style round was detected.
- **Delivery coaching:** no working-style assessment was provided.

## Sources

**Provided documents:**
- The invite, as pasted in your message.
- Your summary of the job ad (four requirements, not full text).
- Your background, as stated in your message.

**Searches sent (both refused by the host, so neither returned a result):**
1. Query: the company's careers listing for this role. Outcome: refused.
2. Query: reports of recruitment scams that use this company's name. Outcome: refused.

**Research tier:** L1, searches 0 of 6 (2 sent, both refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Values cheat sheet, which is not included. No call was sent: the host refused search. |
| 2. interview process for this role family | unavailable | Loop structure and persona weights if a named process existed. No call was sent: the host refused search. |
| 3. company strategy / recent news | unavailable | The CO bank, which is not included. No call was sent: the host refused search. |
| 4. interviewer name and company | n/a | No interviewer name was given. The team lead is unnamed. |
| 5. representative job ad for this title | unavailable | A full job ad would have turned the four summarised requirements into verbatim quotes. No call was sent: the host refused search. |

## Upgrade menu

- The full job ad text → the four summarised requirements become verbatim quotes, and their rows become [grounded] with the ad's own wording.
- The team lead's name → persona weights from their public footprint, and a tailored reverse question.
- Permission to run web searches → values, interview-process and company-existence checks, and a research tier above L0.
- Written examples you can show, such as anonymised customer replies → F3 gets evidence in place of an answer slot.
- Prep time before the chat → a prioritised schedule for the questions above.
- A `tuesday-dossier.md` → verified evidence and binding prohibited claims for every guidance cell.
