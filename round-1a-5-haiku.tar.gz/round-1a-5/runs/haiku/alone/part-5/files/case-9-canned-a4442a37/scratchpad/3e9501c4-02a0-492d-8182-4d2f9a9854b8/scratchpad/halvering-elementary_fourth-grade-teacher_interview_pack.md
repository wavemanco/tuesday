# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Format:** 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren, plus two fourth-grade team members (names not given)
**Built on:** the invite and your résumé. No job description and no online research, so JD-derived items are marked and the research-dependent sections are left out.

## 1. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the beats in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment (not used here: no published values in hand) |
| EXP | Your experience: what you actually did, and whether it holds up |
| JD | The role's stated requirements, gaps included |
| CO | Company and strategy knowledge (not used here: no research run) |
| CASE | A live problem from the job, answered as it happens |

## 2. The fit snapshot

Each requirement is set against your own words. Gap types: `none`, `presentation`, `transferability`, `discovery`, `capability`, `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it as written, and be ready to give the expiry date. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your CV) | none | [grounded] | capability | Your stated absence is the gap, so use your words: "I've never taught fourth grade." Then your third-grade years at their own scope: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: how you would learn the fourth-grade year, given as a plan you would carry out, never as past experience. |
| F3 | "two members of our fourth-grade team" (invite) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your CV) | medium | [grounded] | capability | Team lead is not in the invite; it is your own stated gap. Say: "I've never been a team lead." Then the 2024 move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not widen "led the move" into a lead role. Answer slot: if you have done other team work, say what it was; if not, say so plainly. |
| F4 | Reading instruction for fourth graders (role-family, no source given) [generic] | "I've run the after-school reading club for the last two years" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [inferred] | transferability | The club and the curriculum move are adjacent to classroom reading instruction. Say them at their own scope: "I've run the after-school reading club for the last two years." Any wider step is an answer slot: if you taught reading in class beyond these, say what, in your words. |
| F5 | Family communication (role-family, no source given) [generic] | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. One line of evidence, so expect a follow-up on what the email contains. |

**Highest-ROI prep:** F2. It is the largest gap, and the posting is for fourth grade, so the question will come in some form. Rehearse it until the honest answer is boring.

## 3. Prohibited claims

Claims this pack will not coach, and why. Nothing below should show up in your answers.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | Negative you stated (F2) | "I've never taught fourth grade." No answer slot. |
| Have been a team lead | Negative you stated (F3) | "I've never been a team lead." No answer slot. |
| Chose the reading curriculum | Inflated form of F3's 2024 move | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Pack observation: your material says you led the move, not who chose the curriculum. The slot stays inside the move. |
| Showed reading gains from the club | Inflated form of F4; no outcome appears in your material | The club quote at its own scope. Pack observation: your material gives no results. The slot asks only what, if anything, was tracked. |

## 4. Persona weights

No interviewer read was built: research did not run, and the only name given is the principal's. Weights follow the panel's relationships.

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Probes the fourth-grade and team-lead gaps; asks why fourth grade | High (weight 5). The principal leads the panel, and F2 is the largest gap in your material. | Rehearse the gap until it is boring. Hold the position you can back, concede the specific gap, and offer a plan, never a past. |
| Peer Evaluator | Team members | Asks what you would need from them; probes fit with the team | High (weight 4). Peers price what a hire adds to their own load. | Ask about their process before describing yours. Propose principles, not pretend knowledge of their seams. |
| Data-Driven Prober | Team members | Asks what the reading club tracked; asks how the curriculum move was run | Medium (weight 3). Your CV lines carry no outcomes, which is where probes land. | Say what you did and what you did not count. Never describe a result the material does not show. |
| Case / Strategist | Principal | A live classroom reading problem | Medium (weight 3). Common in panels, though not specific to this invite. | Clarify first, then structure, then name one next step. |
| Conversational | Any member | Opening biography; license confirmation; the family email | Medium (weight 2). Casual questions are still scored. | A 90-second arc, pre-scripted. |
| Pressure | Not weighted | No panel signal points to it | Not weighted. The Skeptic bank's hold-then-concede covers it. | Hold a challenged position through two follow-ups before conceding anything real. |

## 5. Question banks

### A. Skeptic (weight 5): principal

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What would you need to learn about fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your CV) | Say the third-grade years at their own scope. Then name what you would learn, as a plan. Plain statement: "I've never taught fourth grade." Answer slot: if you have fourth-grade experience beyond your material, say what; if not, say so plainly. | F2 is the highest-ROI prep. This is its most likely form. |
| A2 | "You haven't taught fourth grade. Why should we take that risk over a candidate who has?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | Pressure version. Hold through two follow-ups on what you can back: six years of elementary teaching and two years of running the reading club. Then concede specifically: you have not taught fourth grade, and your first-month plan is a plan. Never claim fourth-grade experience. | A pressure form of F2. The hold rests on quotes; the concession is the honest part. |
| A3 | "This team works closely together. Have you ever led one?" | EXP | [grounded] "I've never been a team lead" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say "I haven't been a team lead." Then the 2024 move at its own scope. Answer slot: if you have led other team work, say what and how; if not, say so and say how you would approach leading a piece of work. | F3's gap. The team is the invite's; the lead role is your own stated gap. |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your CV) | Name the fourth-grade year directly: the content and the routines you have not taught. Then the plan. Do not frame it as a strength. | A Skeptic stem for honest self-assessment. The answer is F2, stated plainly. |
| A5 | "Why fourth grade, after six years in third?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | The material gives no reason. Answer slot: give your own reason in your own words; if you have not settled on one, say so plainly. | Motivation probe, the Skeptic's "why here, why now." |

### B. Peer Evaluator (weight 4): team members

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We plan units together as a team. What would you need from us to fit into that?" | CASE | [generic] | Ask about their planning cadence, who owns what, and where materials live. Ask about their process before describing yours. No claim about your past. | A seam question, asked collegially. Peers price what the hire adds to their load. |
| B2 | "When you and a colleague disagree about how to teach something, what happens?" | EXP | [generic] | Selection scaffold: pick a real disagreement about instruction and its outcome; if none comes to mind, say so plainly, then say how you would handle one. | Peer seam probe. No quoted sentence carries a disagreement story, so this is a scaffold. |
| B3 | "Tell us about the reading club you run after school." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe the club in your own words, at the scope of two years of running it. Answer slot: if you tracked any result, say what; if you did not, say so. | The CV line gives no outcome, so the slot asks only what was counted. |

### C. Data-Driven Prober (weight 3): team members

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk us through the 2024 reading curriculum move. Which parts were yours to decide?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe the move in the terms the quote uses, with the year. Answer slot: if you decided any part of it, say which and how, in your own words; if you did not, say so plainly. Never describe a decision the quote does not carry. | The Prober's attribution probe. The CV says led, not chose. |
| C2 | "What did the reading club track, and how did you record it?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything, say what and how; if you did not, say so plainly and say what you would track. | The honest form of the club's outcome, asked for the denominator. Your material shows no results. |
| C3 | "What do you put in your weekly email to families?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe what you actually include, in your own words. Do not claim responses or reach. Answer slot: if you know how families respond, say what you know; if not, say so. | F5's single line, probed for what the email contains. |

### D. Case / Strategist (weight 3): principal

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student in your class is two grade levels behind in reading by October. What do you do first?" | CASE | [generic] | Clarify first: which assessment shows the gap, and what the team already does for this student. Then check one thing before changing anything, and name one next step. | A live classroom reading problem for this role. |
| D2 | "Our fourth-grade team is working through a reading unit. How would you help a student who is stuck on it?" | CASE | [generic] | Clarify what "stuck" looks like and what the unit asks for. Then one method and one check. No past claim. | A live problem set in the role, with no claim about your history. |

### E. Conversational (weight 2): any member

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A pre-scripted 90-second arc: Joliet, six years in third grade, the 2024 move, the reading club, and why you are here. Use the quotes' wording. Answer slot: the reason for fourth grade (see A5). | Opens the panel, and it is scored. |
| E2 | "Can you confirm your Illinois license and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | Say it as written, with the expiry date. | Covers the invite's one hard requirement. |
| E3 | "What would a parent of a fourth grader hear from you in the first month?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe your weekly email in your own words, and how you would use it in this role. Do not claim what families have heard before. | F5 carried into a forward-looking question. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| Illinois license with elementary endorsement | E2 |
| Fourth Grade Teacher position | A1, A2, A4, A5 |
| Two members of the fourth-grade team | A3, B1, B2 |
| Team lead (your stated gap, not in the invite) | A3 |
| Reading instruction (role-family) | B3, C1, C2, D1, D2 |
| Family communication (role-family) | C3, E3 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first semester look like for this role?" | It asks the principal to define success, and shows you are planning, not just applying. |
| R2 | "How does the fourth-grade team plan units across the year?" | It asks the peers about the seam and shows you are thinking about fit. |
| R3 | "How did the school choose its current reading curriculum?" | It connects to your 2024 move without claiming any credit for it. |
| R4 | "What does the team do to support someone new to the grade in their first year?" | It brings out the support your plan for F2 would depend on. |
| R5 | "What is the one thing you would most want the next teacher in this role to change?" | It reveals priorities from the principal directly. |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity with the peers: it tests fit and shows you are offering a contribution, not just asking for one. |

## 7. Sources

- Provided documents: the invite, your résumé as pasted, and your message.
- Searches and fetches: none. Research tier: **L0**. Online research is pending your consent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary values | unavailable | Values cheat sheet, section 10: not built, since no published values are in hand. |
| 2. Orrinsford CSD interview process, fourth grade | unavailable | Loop structure; persona weights follow the named rounds. |
| 3. Orrinsford CSD strategy and recent news | unavailable | Current district reading priorities and recent moves. |
| 4. Dolores Vantongeren, Orrinsford CSD | unavailable | Interviewer read for the principal: public professional footprint. |
| 5. Representative Fourth Grade Teacher JD | unavailable | Would have labelled JD-derived questions and firmed up the requirement rows. |

## 8. Upgrade menu

- The job description text → the requirement rows become `[grounded]`, and the coverage table tightens.
- A light online check of the district and school → a values cheat sheet, the panel's likely process, the district's current reading priorities, and the principal's public professional footprint.
- What HR or the principal said the panel will focus on → persona weights and bank order.
- The two team members' names → an interviewer read and per-member persona assignment.
- Any fourth-grade content you have taught, or any team work you have done beyond the 2024 move → upgrades F2 and F3 from stated gaps to evidence.
- Your prep time before Thursday → a prioritized schedule.
