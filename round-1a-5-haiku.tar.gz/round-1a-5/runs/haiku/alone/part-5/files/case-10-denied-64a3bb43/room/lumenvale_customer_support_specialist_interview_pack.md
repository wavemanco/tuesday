# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote, text-chat interview)

Interviewer: support team lead (name not given). Round: text chat on Telegram. Built for Imani.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, and keep to what you actually did.
- Answer slots (sentences that start "Answer slot:") are instructions for the interview. They are not questions to me.
- Research did not run (see Sources), so there is no company strategy or values section. Company knowledge is generic.

## Fit snapshot

Requirements are quoted from your own summary of the ad, since the full ad text was not pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your words reach the requirement in other terms: customer service, three years, energy. Use them as they stand: "Three years as a customer service advisor at an energy supplier." |
| F2 | "Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a ticketing tool of the kind the ad allows for. Use the sentence as it stands. Zendesk is not in your material, so do not claim it. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | transferability | Email volume is adjacent work. It does not show that your writing is clear, so do not stretch it. Words: "I answer around 60 calls and emails a day." Answer slot: if a written reply of yours was acted on or praised without a follow-up, say what it said, in your own words. If you have no such example, say so plainly. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Nothing you have told me shows an escalation you handled. Answer slot: if you have handled an escalation, say what happened, in your own words. If you have not, say so plainly, and say how you would approach the first one. |
| F5 | Not in the ad. A team lead will probably probe process knowledge (generic) | "I trained four new starters on our refunds process last year" (your message) | medium | [generic] | none | No gap. A story source for process and handover questions. Use the sentence as it stands. |
| F6 | Software product background (generic; the ad does not state it) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |

Limits: the material shows no Zendesk use, no escalation you handled, and no written example. Those are the places an interviewer is most likely to press.

## Persona weights

Relationship prior: a team lead interviewing a candidate for a support role, in a text chat. That points to Case/Strategist and Skeptic. The chat format adds a Conversational opener and a live writing test. Skeptic is weighted highest because the software gap (F6) is the most likely objection.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why should we hire someone who has never worked in software?" | High. F6 is stated and the ad is software-company-shaped | Say the negative first, then the nearest quotes at their own scope. Concede plainly. |
| Case/Strategist | Live support scenarios in the chat | High. Team leads usually test how you handle a real ticket | Clarify, then structure: acknowledge, confirm facts, act, say what happens next |
| Data-Driven Prober | Asks how the 60-a-day figure was counted | Medium. The figure is the one number you gave | Say how you counted it, or say plainly that you do not know |
| Pressure | Short time limits and challenges | Medium, possibly in a timed chat | Pause, restate, hold through two follow-ups, then concede what is true |
| Conversational | A friendly opener and "walk me through" | Medium. Chat interviews often open this way | Have a 90-second arc ready from your quotes |

Depth follows weight: Skeptic 5, Case 4, Prober 3, Pressure 3, Conversational 3. Total 18.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never worked for a software company. Why would you be good at supporting our product?" | JD | [grounded] "I've never worked for a software company" (your message) | Say the negative first: "I haven't worked for a software company." Then bring the nearest quotes at their own scope: "answering around 60 calls and emails a day" and "I use Freshdesk every day". Hold through two follow-ups by returning to those quotes. Concede the gap plainly. Say how you would learn the product, as a plan. | F6 is the most predictable objection and the highest-ROI prep in this pack. Rehearse it until it is calm. |
| A2 | "Our ad asks for Zendesk or a similar tool. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you have used Zendesk, say where and how much. If you have not, say so, and say that Freshdesk is the tool you use every day. | F2 is a presentation row. The question tests the exact tool name. |
| A3 | "What is the hardest contact you have had to escalate, and how did it end?" | JD | [grounded] "confidence handling escalations" (your message) | Open prompt. Pick a contact that needed escalating. It needs a reason for escalating, what you did before escalating, and how it ended. Answer slot: if you have no escalation to describe, say so plainly, then say how you would handle the first one in this role. | F4 is a discovery row, and the ad raises escalations directly. |
| A4 | "You trained new starters. How did you decide they were ready to handle refunds alone?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you set a readiness check, say what it was. If you did not, say so plainly, and say how you would judge readiness now. | F5 is your strongest process story, and the question presupposes a readiness check that your material does not show. |
| A5 | "Tell me about a written message that was misunderstood. What did you change?" | JD | [grounded] "clear written communication" (your message) | Open prompt. Pick a written message that needed a follow-up. Say what was unclear and what you changed. If you cannot think of one, say so, then describe how you check a reply before you send it. | F3 is low confidence, and this chat is itself a written test. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says they were charged twice and is angry. Walk me through your first reply." | CASE | [generic] | Structure it: acknowledge the problem, confirm the facts, say what you will check, give a next step with a time. Do not promise a refund you cannot approve. This guidance makes no claim about your past. | Live problem from the role. Your first reply is the scored part. |
| B2 | "A customer asks for something you are not allowed to approve. What do you do?" | CASE | [grounded] "confidence handling escalations" (your message) | Say what you can do now, what needs escalating, to whom, and what the customer hears and when. Answer slot: if you have done this, say how, in your own words. If you have not, say so and describe the steps. | Raised by the ad's escalation line. This is the decision question behind F4. |
| B3 | "Write me two sentences to a customer who says your last three answers were useless." | CASE | [generic] | Write it live. Name the problem, the action, and the next step. Keep it short and specific, and do not promise more than you can do. | The chat is a writing test. Clear written communication (F3) is scored here. |
| B4 | "Your queue is three times normal and a colleague asks you to skip the notes. What do you do?" | CASE | [generic] | Structure it: what you would do with the queue, what the notes are for, and who you would tell. Make no claim about a past queue. | Live problem on process and pressure. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. Over what period, and how was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say what you counted and over what period, in your own words. Name the assumption behind the figure that you would defend least, or say plainly that you do not know how it was counted. | The one number you gave. Prober questions go straight to it. |
| C2 | "Which Freshdesk features have you used yourself?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you can name features, say which ones and how you used them. If you can only say you used the tool daily, say that. | Tests your tool depth. Your material shows daily use, not features. |
| C3 | "Of the 60 a day, how many did you own from start to finish, and how many were handed to you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: say the split, in your own words. If you do not know the split, say so. | Ownership probe. Your material shows volume, not ownership. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. Why should we take someone with no software background over one who has it?" | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "I use Freshdesk every day" (your message) | Pause and restate the question. Bring the quotes, then concede the software gap plainly. Hold the position for two follow-ups. Concede only what is true. | The same objection as A1, under time pressure. |
| D2 | "You trained four people. Were any of them better than you at refunds?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Hold the fact of the training. Answer what you know, and say plainly if you do not know. | Pressure on a process story. |
| D3 | "That is a lot of contacts. How many did you get wrong?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you know how errors were tracked, say so and give the figure. If you do not know, say that plainly. | The question presupposes a number of errors that your material does not give. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message); [grounded] "I've never worked for a software company" (your message) | A 90-second arc: the energy supplier and the customer work, the daily tool, the training, and why you want a support role in software. Keep it to the quotes. | The opener is scored too. Your four quotes are the arc. |
| E2 | "What takes most of your time in a typical week?" | JD | [generic] | Answer honestly, in your own words. Make no claim beyond what you have told me. | A casual question about the role's daily work. |
| E3 | "What do you know about us already?" | CO | [generic] | Say what the ad and the invite tell you. Do not describe strategy or recent news, since research did not run. Say plainly what you would look up. | Generic company knowledge, because research did not run. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in customer support | F1 covered by A1, C1, E1 |
| Zendesk or a similar ticketing tool | A2, C2 |
| Clear written communication | A5, B3 |
| Confidence handling escalations | A3, B2 |
| Software background (not in the ad, but likely to be probed) | A1, D1 |

## Reverse questions

Ask any five or more. Each has a "why it lands".

1. "What does a typical first week look like for someone starting on your support team?" Why it lands: it shows you are thinking about onboarding, and it is a fair process question.
2. "How is work split between tickets the team closes itself and tickets that go to escalation?" Why it lands: it tests the escalation line directly and signals that you want the real workload.
3. "Which ticketing tool does the team use day to day?" Why it lands: it names the tool in the ad and links to F2.
4. "What does a good first 90 days look like here?" Why it lands: it shows you want a measure of success, not just a start date.
5. "After this chat, what is the next step, and is there a live call or a timed test?" Why it lands: it is a process question you can plan around.
6. "What would make you say the first three months went well?" Why it lands: it invites the team lead's own priorities.

## Prohibited claims

Claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2. Your material names Freshdesk only | "I use Freshdesk every day." The limit is the pack's observation, not a claim: your material names Freshdesk only. |
| Designed or ran the refunds training | Inflated form of F5. Your material says you trained starters | "I trained four new starters on our refunds process last year." Nothing more. |
| Has worked in software support | Negative you stated, F6 | "I haven't worked for a software company." No answer slot on that point. |
| Quantified results from the 60 a day | Inflated form of F3. No outcome was given | "I answer around 60 calls and emails a day." Nothing about outcomes. |

## Sources

Provided documents:
- Your message: the Telegram invite (quoted), your background, and your summary of the ad's requirements.

Searches and fetches sent:
- "Lumenvale Software company careers customer support": refused (permission to use WebSearch was not granted).
- "reports of recruitment scams that use this company's name, run over Telegram": refused.
- No fetches were sent.

Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have moved a values cheat sheet. No values round was detected, so none was written. The company's values could not be checked. |
| 2. Lumenvale Software interview process, support role | unavailable | Would have set persona weights from a real loop. The pack uses round-type priors instead. |
| 3. Lumenvale Software strategy / recent news | unavailable | Would have moved the company-knowledge questions. E3 is generic for this reason. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative Customer Support Specialist JD | unavailable | Would have set the JD wording. The requirements come from your summary. |
| Unnumbered: reports of recruitment scams using the company's name | unavailable | Would have checked the company's name against scam reports. Refused, so nothing was checked. |

## Upgrade menu

- The full job ad text → each requirement row becomes a verbatim quote, and the JD questions use the ad's exact wording
- The team lead's name → persona weights and a tailored reverse question from their public profile
- Web search access → Lumenvale's own values and interview process, which would replace the generic company questions
- Your own examples of an escalation and a written reply → F3 and F4 answer slots become story-mapped answers
- `tuesday-dossier.md` → verified evidence wording and a list of limits for this pack
