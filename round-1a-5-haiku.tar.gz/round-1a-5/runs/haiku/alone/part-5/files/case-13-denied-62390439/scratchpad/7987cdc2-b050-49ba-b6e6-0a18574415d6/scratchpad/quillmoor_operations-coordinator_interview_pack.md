# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep for Sam

Role: Operations Coordinator, Quillmoor Diagnostics (Avonmouth, Bristol; hybrid).
Interviewer: Hannah Lowther, Talent Partner. Round: 30-minute phone call, Thursday 2pm. Recruiter screen.
Built on: the advert, your notes, and Hannah's LinkedIn message. No company or interviewer research (see Sources).

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores: **VAL** values, **EXP** your experience, **JD** the advert's requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say things in your own words, and only what you did.
- Quoted lines are your own sentences. Use them as they are.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (JD) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it in those words: four years as a logistics coordinator at a building-supplies wholesaler. |
| F2 | "track supplier deliveries and chase late orders" (JD) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | No gap; the quote reaches the requirement. Say it as you wrote it. |
| F3 | "keep stock records accurate" (JD) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | Your sentence reaches stock records in other terms. Say it as you did: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. The third is a figure, so expect a probe on how it was counted (B3). |
| F4 | "confident with Excel" (JD) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [inferred] | discovery | Your material shows a spreadsheet you rebuilt. It does not show your Excel level. Answer slot: if the spreadsheet used formulas, lookups or pivot tables, name them; if it did not, say so, and say how you would rate your own Excel. |
| F5 | "Coordinate production schedules between planning, the warehouse and QA" (JD) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | low | [inferred] | transferability | Your scheduling is deliveries to depots, not production schedules. The material says nothing about planning, production or QA. Answer slot: if any of your scheduling involved planners, warehouse staff or QA, say who and how; if none did, say so plainly and say how you would learn production scheduling. |
| F6 | "report weekly on on-time dispatch" (JD) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you tracked delivery timing at your depots, say what you measured and how often; if you did not, say so and say what you would measure first. |
| F7 | "ERP experience (SAP or similar) a plus" (JD) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't used SAP." Then: "We run our own in-house stock system." Learning SAP is a plan, not a past. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." (JD) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | No gap. Your own words cover the pattern and your limit. |
| F9 | "£38,000–£44,000" (JD) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Pay is a logistics slot (A1). |
| F10 | "what's prompting a move" (recruiter's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Reason for leaving is a logistics slot (A4). |
| F11 | "your notice period" (recruiter's message) | none given | none | [grounded] | discovery | Not in your material yet. Give your actual notice period as a figure, in your own words. |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F5 | F5's quote at its own scope. The material shows deliveries to three depots, not production schedules. |
| Reported weekly on on-time dispatch | Inflated form of F6 | F6 as a gap. The material does not show it. |
| Advanced or expert in Excel | Inflated form of F4 | The spreadsheet at its own scope: you rebuilt the stock-count spreadsheet. |
| Used SAP or any ERP system | Negative you stated, F7 | "I haven't used SAP." No answer slot. |
| Credited with the whole fall in discrepancies | Inflated form of F3 | Your sentence at its scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. |
| Your current salary, or any range, floor or flexibility | You gave no figure for either | Decline line only (A1). |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational recruiter | Walks the call's agenda: pay, notice, hybrid, reason for the move, then team and next steps. | High. Hannah set this agenda in the message. | Answer each agenda item once, in your own words, and stop. |
| Light skeptic | Asks whether you have the production or SAP experience the advert names. | Medium. The advert names both, and the material is silent on production and says no to SAP. | Use the plain acknowledgment for SAP (C2). Use the answer slot for production (C1). |
| Knockout check | A direct yes or no on the hybrid days or the pay. | Low. Your answers are already clear. | Give your figure or pattern as you wrote it (A1, A3). |

## Question banks

### A. Logistics (recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: "I'm hoping for £42,000." Then stop. No range, reason or comparison. If asked what you earn now: "I'd rather focus on the range for this role." | F9. Pay fills its slot. Your figure raises no challenge. |
| A2 | "What is your notice period?" | JD | [grounded] your notice period, as Hannah's message names it | Give your actual notice period as a figure, in your own words. Not in your material yet; see the question below the pack. | F11. A logistics slot with no figure given yet. |
| A3 | "How would the two days at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, in your words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If asked about the commute: "I live in north Bristol." Add nothing. | F8. Your limit is three days. |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot in your words, whole. If asked why not Reading: "which I don't want." Do not add to it. | F10. Motivation is consistent with what you wrote. |

### B. Experience

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about your current role." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name the two things in those words: scheduling deliveries for three depots, and chasing suppliers when orders slip. | F2. Your strongest match to the advert. |
| B2 | "You've been a logistics coordinator for four years. What did that cover?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Stay with four years, the role and the wholesaler. | F1. |
| B3 | "Tell me about the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you did and what happened, in those words. Answer slot: if asked how the third was counted, say what you counted and over what period, in your own words; if you are not sure, say so. | F3. The figure earns a defend-the-number probe. |

### C. Skeptic (advert gaps)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role coordinates production schedules across planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if any of your scheduling involved planners, warehouse staff or QA, say who and how, in your own words. If none did, say so plainly, then describe your depot scheduling and how you would learn production scheduling. | F5. The advert's first duty, and the largest gap. Highest-ROI prep in this pack. |
| C2 | "Have you used SAP or another ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, as a plan. No answer slot. | F7. A stated absence, so the words are yours. |
| C3 | "How confident are you with Excel? What do you build in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: name the formulas, lookups or pivot tables you used, if any. If none, say so and rate your Excel plainly. | F4. The advert raises Excel directly. |
| C4 | "How do you report on dispatch performance?" | JD | [grounded] the advert's "report weekly on on-time dispatch" (no candidate sentence) | Answer slot: if you tracked delivery timing at your depots, say what you measured and how often. If you did not, say so and say what you would measure first. | F6. |

### D. Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A production batch is due at QA, but the stock record says the material has not arrived. What do you do?" | CASE | [generic] | Structure: check the stock record, call the supplier, tell planning and QA, and log the discrepancy. Make no claim about your past. | A live problem from the advert's planning, warehouse and QA line. |

## Reverse questions (for Hannah)

1. "Are the Avonmouth days set as fixed days, or do they vary by team?" Why it lands: it tests your fit on F8 and tells you the pattern.
2. "Which stock or planning system does the team use day to day?" Why it lands: it sets up the SAP gap (F7) and shows you what to learn.
3. "How is on-time dispatch reported today, and who reads the weekly report?" Why it lands: it is the reporting gap in F6.
4. "How does production scheduling work between planning, the warehouse and QA?" Why it lands: it is the gap in F5, and the answer shows how much of the job is new to you.
5. "What are the next steps after this call, and how long does the process usually take?" Why it lands: it is the item Hannah said will come after the team, and it gives you a timeline.
6. "What does the team look like, and who would I work with day to day?" Why it lands: Hannah said she will describe the team, so this follows that line.

## Sources

- Provided: the advert (as pasted); your message; Hannah's LinkedIn message.
- Searches sent: 3, all refused (permission not granted in this session):
  - "Quillmoor Diagnostics": refused
  - "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused
  - "Quillmoor Diagnostics Avonmouth Bristol operations coordinator": refused
- Page fetches: 0 of 2 (none sent).

**Research tier: L1. Searches 0 of 6 returned results (3 sent, all refused); fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet. Not built: a recruiter screen is not a values round. |
| 2. Quillmoor interview process | unavailable | Loop structure. Hannah has described this call's agenda and next steps, so persona weights rest on the round type. |
| 3. Company strategy / recent news | skipped | Could not have moved this pack: the screen's questions are logistics and motivation. |
| 4. Hannah Lowther, Quillmoor | unavailable | Interviewer read and a tailored reverse question. The one search was refused. |
| 5. Representative JD | skipped | Your advert fixes the fit snapshot. |

No CO bank was written, because no company research came back.

## Call checklist

- Before the call: confirm your notice period as a figure (A2).
- Pay: "I'm hoping for £42,000." Then stop (A1).
- Hybrid: "two days at Avonmouth is fine, but I wouldn't want more than three" (A3).
- Reason for leaving: your words, whole (A4).
- Production and SAP: answer C1 and C2 in your own words, without adding to them.
- Ask Hannah two or three reverse questions, then the next steps.

## Upgrade menu

- Hannah's public LinkedIn "About" text, pasted by you → an interviewer read and a tailored reverse question.
- The full posting, if it is longer than the advert you pasted → any requirement missing from the fit snapshot gets a row.
- Quillmoor's published values or careers text → a values cheat sheet for a later round.
- Research, once search is permitted → the interviewer, company and interview-process rows, and a company-knowledge bank.
