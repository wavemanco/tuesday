# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Interview:** 30-minute video call with the office manager
**Built from:** your summary of the job ad, your background, and the interview invite as you quoted it. No full job description and no company research were available (research tier L0).

## How to use

- **Personas** describe how the question is asked. **Types** describe what is being scored: Experience, Fit, Skeptic, Pressure, Reverse.
- The guidance is scaffolding, not a script. Answer in your own words, and only with things you actually did.

## Fit snapshot

| Requirement (from the ad, as you relayed it) | Your evidence (quoted) | Confidence | Gap | Bridge language | Provenance |
|---|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | medium | bridge | "I managed scheduling for four people with shifting availability; I haven't managed an executive's calendar, but the planning is the same." | [inferred] |
| Booking travel | none given | none | discovery | No evidence in your background. If you have booked travel for anyone, use it. If not, say so plainly and describe the nearest scheduling work. | [generic] |
| Preparing documents in Word and Excel | "good with Word", "okay with Excel" | medium (Word), low (Excel) | bridge | "I'm strong in Word; with Excel I'm comfortable with basics and I'd want to learn the rest on the job." | [inferred] |
| Processing supplier invoices | "chased unpaid invoices" | low | bridge | Chasing invoices is close to processing them, but it is not the same. Do not say you processed invoices unless you did. | [inferred] |

## Prohibited claims (built locally)

Do not say or imply any of these in an answer:
- That you have booked travel, unless you have.
- That you have processed supplier invoices, as opposed to chasing unpaid ones.
- That you are advanced in Excel. Your stated level is "okay".
- That a physio-clinic appointment book is the same as an executive calendar. Say it's close, not identical.

## Question banks

**Experience**

1. **Tell me about the appointment book you ran for four physios.**
   Guidance: Describe the volume, how you handled clashes and cancellations, and one thing you changed. Provenance: [grounded] "ran the appointment book for four physios".

2. **You chased unpaid invoices. How did you do it, and what did you get back?**
   Guidance: Give the steps you took and the result. Do not stretch it into processing. Provenance: [grounded] "chased unpaid invoices".

**Fit**

3. **Have you booked travel for anyone?**
   Guidance: If yes, give the example. If no, say no, then describe the nearest booking-type task you have done. Do not improvise. Provenance: [generic], answer slot.

4. **How comfortable are you in Excel? Show me or describe something you've built.**
   Guidance: Be honest about "okay". Name the functions you use and offer to learn the rest. Provenance: [grounded] "okay with Excel".

**Skeptic**

5. **Your background is in a physio clinic, not admin. Why should we hire you for this?**
   Guidance: Acknowledge the gap in one sentence. Then point to the scheduling and chasing work as direct evidence. Provenance: [grounded] "two years as a receptionist at a physiotherapy clinic".

**Pressure**

6. **If you had never processed a supplier invoice, how would you learn to do it in week one?**
   Guidance: Name a concrete method: ask for the process, shadow someone, and work from their templates. Do not promise speed you can't show. Provenance: [generic].

## Reverse questions

1. **What does a normal week look like for the calendar and travel side of this role?** Why it lands: shows you're thinking about the actual work, not just the title.
2. **Which systems do you use for calendars, travel and invoices?** Why it lands: tells you what you'd need to learn and signals you're ready to start.
3. **How does someone in a remote role get support when they have a question?** Why it lands: remote roles often fail on this, and the answer is informative.
4. **What would a good first 90 days look like?** Why it lands: gives the office manager a chance to describe success in their own terms.
5. **What are the next steps after this call?** Why it lands: shows you care about the process, and gives you a timeline to plan around.

## Sources

- Provided: your message, including the invite text you quoted.
- Research: none run. Company values, loop structure and current strategy are not included. Anything marked [generic] is general interview practice, not verified about Brennock.

## Upgrade menu

- **Full job description text** → the fit snapshot rows become grounded in the ad's exact wording.
- **Company careers page or official contact details** (found by you, not from the invite) → you can check the role and the company's hiring process directly.
- **Which software the role uses** → the calendar and invoice answers can name the real tools.
- **`tuesday-dossier.md`** → adds verified evidence grading and a deeper rehearsal of your most likely objection.
