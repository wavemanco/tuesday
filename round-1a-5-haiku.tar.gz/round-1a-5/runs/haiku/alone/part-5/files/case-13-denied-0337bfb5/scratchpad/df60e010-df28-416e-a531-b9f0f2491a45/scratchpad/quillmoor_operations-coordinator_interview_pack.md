# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Relationship: recruiter, so the screen checks logistics, motivation and knockouts in a friendly register.
**Built from:** the advert, Hannah's LinkedIn message, and Sam's background as you described it. No research was run (see Sources).

## 2. How to use this pack

- **Personas** describe how a question arrives: conversational, skeptical, probing or pressured.
- **Types** describe what is being scored: **VAL** (values), **EXP** (your past work, checked closely), **JD** (the listed job's requirements and terms), **CO** (company knowledge), **CASE** (a live problem).
- The guidance is scaffolding, not a script. Say it in your own words.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots. It does not say production schedules, planning or QA. Say the deliveries in those words. Answer slot: the advert asks about coordinating across planning, the warehouse and QA, so expect a probe on it. If you have coordinated across those teams, say which and what you did, in your own words; if not, say so plainly and say how you would start. |
| F2 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. Your sentence reaches the requirement in other words: "I chase suppliers when orders slip." |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a number with nothing behind it yet, so expect a probe on it. Say what you rebuilt and what the third measured, in your own words. |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not mention dispatch or delivery-timeliness reporting. Answer slot: if you reported delivery timeliness regularly, say what it measured and who read it; if you did not, say so and say how you would build a weekly on-time figure. |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | No gap. Your sentence states the years and the role. |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The spreadsheet is in your material, but Excel is not named and your confidence with it is not stated. Answer slot: say which program the spreadsheet was built in and what you did in it; if it was not Excel, say what it was. |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | You have not used SAP, and the in-house stock system is adjacent work, not an ERP. Plain acknowledgment: "I've never used SAP." Then the system you have used, in your words. Do not call the in-house system an ERP. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | No gap. Your stated limit is three days. |

**Gap wording summary:** F1, F4 and F6 are where the advert asks for more than your material shows. F7 is the clearest gap: SAP is named, and you have said you have not used it.

## Prohibited claims

Not coached in any answer, hold, bridge or rationale in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have ERP experience" | Inflated form of F7: the in-house stock system read as an ERP | F7's quote at its own scope: "Never used SAP — we run our own in-house stock system." Limit, as this pack's analysis: your material shows an in-house stock system, not an ERP. |
| "I've coordinated production schedules across planning, the warehouse and QA" | Inflated form of F1: deliveries read as production | F1's quote at its own scope: "I schedule deliveries for our three depots". Limit, as this pack's analysis: your material shows deliveries, not production. |
| "The third came from my spreadsheet alone" | Inflated form of F3: a causal claim the quote does not make | F3's quote at its own scope. Who else changed things is a slot in C2, not a claim. |
| "I know Excel well" stated as fact | Inflated form of F6: Excel is not named in your material | F6's answer slot. Say what the spreadsheet was built in. |

## Section 8: Persona table

| Persona | How it shows up in this screen | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Hannah's own agenda: pay, notice, hybrid, reason for moving, then the team and next steps. Friendly, scored. | Highest. She set the agenda in her message. Weight 5. | Short, plain answers in your own words. Treat casual questions about the role as scored. |
| Skeptic (light) | "Why now", "why leave", and the SAP and production gaps against the advert. | High for the reason-for-move question and the SAP question; the advert names both. Weight 5. The Skeptic is light in a recruiter screen, but this screen checks knockouts and motivation closely, so it gets the same depth as the conversational bank. | Hold the stated facts; say the gap in plain words; bridge only with what you have stated. |
| Data-Driven Prober (light) | The "about a third" figure and the weekly dispatch figure. | Medium. A recruiter rarely probes deep, but a number on the CV is the first thing a screen checks. Weight 4. | Say how it was counted, and name the weakest assumption before she asks. |
| Pressure / stress (light) | A sharp follow-up on the SAP gap or the hybrid limit. | Low for a recruiter screen. Weight 2. | Pause, restate the fact you stated, hold through two follow-ups. |

**Session total:** 16 questions. The 18-question floor is for full loops; a 30-minute recruiter screen covers fewer topics, so this pack is shorter on purpose.

## Section 9: Question banks

### Conversational bank (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP, JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | About 90 seconds: the role and the years, then the depots, the supplier chasing and the spreadsheet, in those sentences' own terms. Stop at the spreadsheet; do not extend it. | Opening question; it lays the groundwork for F5, F2 and F3, and it is the one she is most likely to ask first. |
| A2 | "What notice period would you need to give?" | JD | [grounded] "your notice period" — recruiter's message | Logistics slot. Your material does not state a notice period. Give your actual notice period in your own words. If you are unsure of the contract term, say so and say what you would check. | Notice is one of her four named topics. The only safe answer is your own. |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." — your message; the advert's "£38,000–£44,000" — advert | Logistics slot, filled with your own figure: "I'm hoping for £42,000." Then stop and let her respond. If asked what you earn now: "I'd rather focus on the range for this role." Do not add a range, a floor, flexibility or a counter-offer. | Pay is her first named topic. Your figure is already in your words; it raises no further challenge. |
| A4 | "The role is two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | Logistics slot: "I live in north Bristol, so two days at Avonmouth is fine." If she asks about more days, your words were: "I wouldn't want more than three." | The hybrid pattern is her third named topic, and it matches F8. |
| A5 | "What drew you to this role?" | EXP | [grounded] "Coordinate production schedules between planning, the warehouse and QA" — advert | Open prompt. Pick the part of the advert you want to do and say why in your own words. The advert names production scheduling across planning, the warehouse and QA, supplier chasing and weekly dispatch reporting. If nothing in it draws you, say what would. | Her motivation check. The guidance draws only on the advert's own words, and it tells you what the role asks, not why you want it. |

### Skeptic bank (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why are you looking to move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | Say it in those words: the office closes next year, the only offer is a move to Reading, and you do not want that. Stop there. If she asks what you want next, say what you want from this role, in your own words. | Her named topic on reason for moving. Your reason is real and specific; the answer does not need more. |
| B2 | "The role asks for SAP or a similar ERP and production scheduling. What's your experience with those?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." — your message; "ERP experience (SAP or similar) a plus" — advert | **Highest-ROI prep in this pack.** The honest core is the plain acknowledgment: "I've never used SAP." Then "We run our own in-house stock system", in your words. Answer slot: if you learned SAP or any ERP, say how and when; if not, say how you would learn it, as a plan and not a past. For production, say the deliveries you scheduled, and say where production sits relative to them. Hold through two follow-ups by returning to the sentence you stated; concede the learning curve specifically. | F7 and F1 are the gaps this screen is most likely to press, because the advert names SAP and production scheduling. Rehearse the non-defensive answer until it is dull. |
| B3 | "A supplier misses a delivery that a production run depends on. What do you do first?" | CASE | [generic] | Structure it: confirm the impact with planning and the warehouse, check the alternatives, tell QA, and record what changed. The question asks about no past, so the guidance makes no claim about yours. | A live problem from the advert's coordination line. A structured answer shows the coordination the role needs, without a claim about your history. |
| B4 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" — your message | Answer slot: say which program the spreadsheet was built in and what you did in it. If it was not Excel, say what it was. Do not claim a skill level your material does not state. | Excel is a listed requirement and F6 is discovery. Your answer should be exact. |
| B5 | "We report weekly on on-time dispatch. Have you produced that kind of report?" | JD | [grounded] "report weekly on on-time dispatch" — advert | Answer slot: if you reported delivery timeliness regularly, say what it measured and who read it. If you did not, say so plainly and say how you would build a weekly on-time figure. | F4 is discovery. The honest answer is ready before the probe arrives. |

### Prober bank (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your spreadsheet cut discrepancies by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | Defend the number in your own words: what was counted, over what period, against what. Name the assumption you would defend least before she asks. If you do not know how it was counted, say so. | F3's figure is the screen's likeliest number to be checked. |
| C2 | "Which part of that drop was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | Say which part you did: the rebuild. If others changed anything else in the count, say so, in your words. Do not claim the whole third. | Attribution is what a prober checks. Your quote gives you the rebuild and no more. |
| C3 | "How many deliveries a week were you scheduling?" | EXP | [grounded] "I schedule deliveries for our three depots" — your message | Answer slot: if you know the volume, give it. If not, say you would check, and give the scale you can vouch for. | The figure is not in your material, so the guidance supplies no number. |
| C4 | "What would you count as on-time dispatch?" | JD | [grounded] "report weekly on on-time dispatch" — advert | Give the definition you would use, in your own words, and how you would count a late dispatch. This asks about no past of yours. | Her question, if she asks it, is about the measure, not your history. The guidance supplies no figure. |

### Pressure bank (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never used SAP. Why would we think you can learn it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." — your message | Hold: "I've never used SAP." Then say how you would learn it, as a plan. Concede the learning curve specifically. Hold through two follow-ups by returning to the sentence you stated. | Hold-then-concede on the SAP gap. The position you hold is the one you stated. |
| D2 | "Sixty seconds: why should we take you over someone with production experience?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | Short arc: the four years, the depots and the spreadsheet, in those words. Do not claim production experience. If she presses, say the delivery and count work is what you can point to. | A composure test on a time limit. The answer stays in what you stated. |

### Requirement coverage

| Requirement (advert) | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | A5, B2, B3 |
| Track supplier deliveries and chase late orders | A1, F2 (no separate question) |
| Keep stock records accurate | C1, C2 |
| Report weekly on on-time dispatch | B5, C4 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B2, D1 |
| Hybrid: two days a week at Avonmouth | A4 |
| Pay: £38,000–£44,000 | A3 |

## Reverse questions for Hannah

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after this call, and who would I speak to next?" | Shows you are thinking ahead, and gets the team and timing she has said she will cover. |
| R2 | "Where does the coordination role sit between planning, the warehouse and QA?" | Tests the production-coordination requirement and tells you where the role reports into. |
| R3 | "What system does the team use to track supplier deliveries today?" | Learns whether the ERP question is live without presupposing one exists. |
| R4 | "How is the weekly on-time dispatch report produced at the moment?" | Shows you read the advert closely; the answer tells you what the report involves. |
| R5 | "Is the two-day Avonmouth pattern set by team or by the company?" | Settles whether your stated limit of three days has room in it. |

## Section 13: Delivery coaching

Not included: no working-style assessment was provided.

## Section 14: Sources

- **Provided documents:** the advert (Operations Coordinator, Quillmoor Diagnostics); Hannah Lowther's LinkedIn message; Sam's background, as you described it in the message.
- **Searches and fetches:** none sent.
- **Research tier:** L0 — no searches.
- Target accounting (research targets from the L1 list):
  1. Company values: skipped
  2. Interview process: skipped
  3. Company strategy: skipped
  4. Interviewer footprint: skipped
  5. Representative JD: skipped (a JD was supplied)

## Upgrade menu

- Your notice period, in your own words → A2 becomes your own answer, not an instruction.
- A pasted Quillmoor values page or interview guide → a values cheat sheet, if the screen covers values.
- A 6-search research pass on Quillmoor's values, interview process and recent news → confirms the screen's shape and adds company-specific reverse questions.
- The recruiter's prep email → confirms whether the call covers anything beyond what Hannah named.
- `tuesday-dossier.md` from job-underwriter → would add evidence-graded objections and prohibited-claims guardrails.
