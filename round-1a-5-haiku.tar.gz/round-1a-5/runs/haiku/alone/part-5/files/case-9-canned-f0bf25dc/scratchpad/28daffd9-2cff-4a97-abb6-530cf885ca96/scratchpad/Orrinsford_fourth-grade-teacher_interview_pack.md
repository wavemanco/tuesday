# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Format:** 45-minute panel. Principal Dolores Vantongeren plus two members of the fourth-grade team.
**Built on:** the invite and your résumé/message. No job posting, no interviewer profiles, and no web research were available, so this is a first-pass pack.

## How to use this pack

- **Personas** describe how a question is asked (evaluator, skeptic, rapport). **Types** describe what is being scored.
- **Type key:** VAL = behavioral/values. EXP = your own experience, probed closely. JD = the job's own duties. CO = company and strategy knowledge. CASE = a live problem.
- Guidance is scaffolding, not a script. Use your own words. Where the guidance says "answer slot," the honest answer is whatever you actually did or would do.

## Fit snapshot

Requirements come from the invite where quoted. Rows marked [generic] are role-family expectations, not quoted from the invite.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | You have not taught fourth grade, and you said so in your own material. Bridge with what transfers, in your words. Answer slot: what you would teach or check first in the first weeks. |
| F2 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | Requirement met. State it plainly: your license is active through June 30, 2029. |
| F3 | [generic] reading instruction and curriculum | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | none | Strong, but the evidence is about a move, not outcomes. Expect a probe on what changed. |
| F4 | [generic] reading support beyond core instruction | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Real and sustained. Expect a probe on how you knew it helped. Answer slot: any measure you tracked. |
| F5 | [generic] family communication | "I write a weekly email to families" — your CV | medium | [grounded] | none | Strong, concrete habit. |
| F6 | [generic] leading a grade-level team | "I've never been a team lead." — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't been a team lead." Then how you would learn it, said as a plan and never as a past. |

## Prohibited claims

Built locally from the fit snapshot. Each entry is something a candidate under pressure might reach for. No guidance cell in this pack asserts any of them.

| Claim not to make | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" | Your CV: six years in third grade; your message: "I've never taught fourth grade." | "I've taught third grade for six years, and I haven't taught fourth grade." |
| "I have been a team lead" | Your message: "I've never been a team lead." | "I haven't been a team lead. Here is what I did lead, and how I'd approach the role." |
| Reading gains or outcome data from the 2024 curriculum move or the reading club | Nothing in your material gives outcomes. | "I don't have outcome data unless I pull it; here is what I observed and what I'd measure." |
| Knowledge of fourth-grade standards or assessments | Not in your material. | Plan to learn them, said as a plan. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Principal, structured evaluator | Mission, fit, and "tell me about a time" questions, scored on a rubric | High. A principal chairs the panel and usually owns the hiring decision | Short, specific answers built on your quoted sentences |
| Fourth-grade peer, skeptic | Probes the grade-level gap and the team's expectations | High. Two team members will test whether you can carry fourth-grade work | Lead with the concession, then the plan |
| Second peer, rapport | Asks about you, your habits and your classroom | Medium. A warm question often tests judgment too | Answer warmly; use one concrete example |

## Question banks

Weighted: principal 5 questions, skeptic peer 5, rapport peer 3.

### Principal (evaluator), weight 5

**A1** (JD, type EXP). "You've taught third grade for six years. Why fourth?"
- **Provenance:** "Six years teaching third grade at a public elementary school in Joliet"; "Elementary Education (grades 1–6) endorsement".
- **Guidance:** Say what you know and what carries over. Your endorsement covers grades 1–6. Do not claim fourth-grade experience.
- **Rationale:** Opens the panel with the grade-level question every interviewer will have.

**A2** (EXP). "Tell me about the reading curriculum move in 2024."
- **Provenance:** "I led our grade level's move to a new reading curriculum in 2024"
- **Guidance:** Name what you did, in your words, and what was decided by you versus the team. Answer slot: "what did the move change for students, and how do you know?" If you have no measure, say so and say what you would measure.
- **Rationale:** The evaluator's probe into attribution.

**A3** (EXP). "Describe the after-school reading club."
- **Provenance:** "I've run the after-school reading club for the last two years"
- **Guidance:** Cover who attends, what you run, and how often. Answer slot: any measure you used to judge it working.
- **Rationale:** A sustained activity is a strong signal, and a principal will ask how you know it helped.

**A4** (JD). "How do you keep families informed?"
- **Provenance:** "I write a weekly email to families"
- **Guidance:** Describe the weekly email as you wrote it: what it covers and how often.
- **Rationale:** Family communication is a common JD expectation; this is a concrete habit.

**A5** (JD). "What's your experience leading a team?"
- **Provenance:** "I've never been a team lead." (a gap you stated)
- **Guidance:** "I haven't been a team lead." Then the initiative you did lead: "I led our grade level's move to a new reading curriculum in 2024." Then how you'd grow into it.
- **Rationale:** Asked straight, and the honest answer is a gap with a bridge.

### Skeptic peer (fourth-grade team), weight 4 (highest-ROI prep)

**B1** (JD). "You've never taught fourth grade. What will you do in your first month?"
- **Provenance:** "I've never taught fourth grade"
- **Guidance:** "I haven't taught fourth grade." Then a concrete plan: which standards you'd review first, what you'd ask the team, how you'd check your pacing. Answer slot: any specific you already know.
- **Rationale:** This is the most likely objection. Deepest rehearsal: concede in one sentence, then plan. Follow-ups: which standards? What would you ask first? How would you know you're on track?

**B2** (JD, CASE). "A student reads two levels below grade in October. What do you do?"
- **Provenance:** none given. Selection scaffold: "Pick a time you adjusted instruction for a struggling reader."
- **Guidance:** Diagnose before you intervene. Use the reading club and curriculum move only if they fit the case. Honest branch: "I haven't had this exact case in fourth grade; here is how I'd start."
- **Rationale:** Tests reading diagnosis, which your background should cover.

**B3** (EXP). "What did the new reading curriculum actually change?"
- **Provenance:** "I led our grade level's move to a new reading curriculum in 2024"
- **Guidance:** Stay with what you did. Answer slot: "what did you measure?" If nothing, say so; do not invent a number.
- **Rationale:** The sharpest attribution probe on your strongest claim.

**B4** (JD). "Would you plan units with a team that already has a shared calendar?"
- **Provenance:** none given. Selection scaffold: "Pick a time you planned with colleagues."
- **Guidance:** Say you would follow the calendar, and what you'd contribute. Honest branch: "I haven't planned on a shared calendar in fourth grade; here is how I'd fit in."
- **Rationale:** Tests fit with the team, not only skill.

**B5** (VAL). "What do you do when a colleague disagrees with your approach?"
- **Provenance:** none given. Selection scaffold: "Pick a time you disagreed with a colleague about a student."
- **Guidance:** Describe the disagreement and how it resolved.
- **Rationale:** Team-fit question for a panel with a team on it.

### Rapport peer, weight 3

**C1** (VAL). "What do you enjoy most about teaching?"
- **Provenance:** none given. Selection scaffold: "Pick a moment from the reading club or your weekly family email."
- **Guidance:** Choose one specific moment. Keep it short.
- **Rationale:** Warm question; a specific answer lands better than a slogan.

**C2** (EXP). "What would you change about the reading club?"
- **Provenance:** "I've run the after-school reading club for the last two years"
- **Guidance:** Name one change and why. This shows reflection.
- **Rationale:** Shows you think about your own work.

**C3** (JD). "How do you handle a family who doesn't respond?"
- **Provenance:** "I write a weekly email to families"
- **Guidance:** Describe the follow-up you'd use, building on the weekly email.
- **Rationale:** Family communication under strain.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F2 row only; no question needed. Met. |
| Fourth-grade teaching (title) | A1, B1 |
| Reading curriculum (generic) | A2, B2, B3 |
| Reading support (generic) | A3, C2 |
| Family communication (generic) | A4, C3 |
| Team leadership (generic) | A5, B4, B5 |

## Reverse questions

Each one lands for a reason:

1. "What would a new fourth-grade teacher need to know in the first month that isn't written down?" Why it lands: shows you are planning, not just applying.
2. "How does the team plan units together, and where would a new teacher fit?" Why it lands: tests the team dynamic you're walking into.
3. "What does success look like for this position by the end of the first year?" Why it lands: sets a clear bar.
4. "Which reading materials and assessments does fourth grade use now?" Why it lands: shows you're ready to learn their curriculum.
5. "How does the principal support teachers new to a grade level?" Why it lands: shows you think about onboarding.
6. (Reciprocity, peer) "What could a new person do in their first month that would genuinely help your team?" Why it lands: turns the question back to the team and signals contribution.

## Delivery coaching

Not included. No working-style assessment was provided.

## Sources

- Provided documents: your invite (as pasted), your résumé/CV summary, and your message.
- Research tier: **L0** (provided documents only). No searches or fetches were run. Company values, strategy and the district's current curriculum are not covered.
- Interviewer profiles: none provided.

## Upgrade menu

- The job posting or full JD → converts the [generic] rows into [grounded] rows and adds JD questions for each listed duty.
- The names of the two fourth-grade team members → a tailored reverse question and persona weights from their public footprint, if any.
- Any pre-declared task (demo lesson, presentation, written assignment) → a build section for it.
- Deep research (L2, offered once; up to 6 more searches and 2 more page fetches, a few minutes) → company values, current district strategy and recent Orrinsford news for the grounding section.
- A `tuesday-dossier.md` → verified evidence and sharper objection work, if you have one.
