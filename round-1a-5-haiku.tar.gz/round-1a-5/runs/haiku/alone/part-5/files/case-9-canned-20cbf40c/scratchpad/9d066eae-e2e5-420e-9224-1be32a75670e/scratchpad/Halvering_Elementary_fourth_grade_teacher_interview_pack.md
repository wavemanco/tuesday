# Halvering Elementary School, Fourth Grade Teacher: interview prep pack

Role: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District, Illinois)
Format: 45-minute panel interview, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team. The panel's names beyond the principal are not known.
Build: session mode, built from your invite, your CV and your note. No job posting, no research run.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

Type key:
- **VAL**: values alignment (none detected here)
- **EXP**: your own past work, tested for attribution
- **JD**: the role's requirements
- **CO**: company knowledge (not researched this run)
- **CASE**: a live classroom problem

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. State it plainly with the expiry date. |
| F2 | The Fourth Grade Teacher position (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | capability | You stated the absence, so the words are yours: "I've never taught fourth grade." Then the third-grade work at its own scope, and the plan for closing the gap, said as a plan and never as a past. |
| F3 | Working as a member of a grade-level team (role family, not quoted from the invite) | "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | capability | You stated the absence of team lead: "I haven't been a team lead." The 2024 move is at its own scope: you led the move, not the team. Do not stretch it into leading the team. |
| F4 | Reading instruction that supports grade-level learning (role family) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Both lines reach the reading requirement in their own terms. Name the curriculum move and the club as you did them. |
| F5 | Regular communication with families (role family) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | The weekly email answers this on its own. Describe what the email covers in your words. |

Rules the table follows:
- Quotes are your own sentences, with their sources. Everything the pack says about your past rests on these.
- Your material does not show whether you have had any fourth-grade planning, unit or substitute work. The pack does not assume you have. If you have, say so in the interview; if not, say so plainly.
- Your material does not show what your reading club or curriculum move achieved for students. The pack does not supply results.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" or "I have fourth-grade experience" | Inflated form of F2. Your CV says third grade. | "Six years teaching third grade at a public elementary school in Joliet." |
| "I have led a team" or "I've led a grade-level team" | Inflated form of F3. Your message says you have not been a team lead. | "I led our grade level's move to a new reading curriculum in 2024." Plus "I haven't been a team lead." |
| "I chose the new reading curriculum" | Inflated form of F4. Your CV says you led the move, not that you chose the curriculum. | "I led our grade level's move to a new reading curriculum in 2024." |

## Question banks

Panel weights: the Skeptic is the strongest pull, because the two gaps in your note are the first things a panel will see. The Peer Evaluator comes next, because the two fourth-grade members will price what you add to their team. The Case and Prober items are the classroom and evidence checks. The Conversational item is the opener.

### A. The Skeptic (weight 5, highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Start with the third-grade work: "Six years teaching third grade at a public elementary school in Joliet." Then say the gap plainly: "I've never taught fourth grade." Then the plan, as a plan: what you would read first in the fourth-grade materials and from whom you would get the scope. Answer slot: if you have done any fourth-grade work, such as a unit, a planning session or a substitute day, say what it was. If you have not, say so plainly and go to the plan. Hold through two follow-ups by returning to the third-grade work and the plan. | This is the highest-ROI rehearsal in the pack. F2 is the gap the panel will see first, and the question will come in some form. A plain, early acknowledgment beats a defended one. |
| A2 | "How would you learn what fourth graders in this district are expected to know by the end of the year?" | JD | [generic] | A plan, not a past: ask the team for the scope and sequence and the pacing guide, look at the reading materials they use, and check where your current students would land at the start of the year. Do not claim you have done any of this. | This is a plan question. It tests how you would close F2 without claiming you already have. |
| A3 | "You haven't been a team lead. What would you do first if a teammate disagreed with a plan you proposed?" | JD | [grounded] "I've never been a team lead" (your message) | Begin with the plain acknowledgment: "I haven't been a team lead." Then describe how you would handle the disagreement, as an approach. Answer slot: if you have had to get colleagues to agree to something, say what it was and what you did. If not, say so and go to the approach. | F3 is the gap the panel is likely to raise. The question asks for a plan, not a credential. |
| A4 | "Where did the team's reading decisions get made in the 2024 move, and what was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the move at its own scope: you led the move to the new curriculum. Then say who made which decisions, in your words. Answer slot: if you made decisions yourself, say which. If the decision was made by others, say who and what you did. | The panel will test how much of the 2024 move was yours. Describe your part, not the team's, and do not widen it. |
| A5 | "Sixty seconds: why you rather than a fourth-grade teacher already on staff?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | Hold the core: your third-grade work and the reading work carry over, in your words from the CV. Concede specifically: "I don't yet know the fourth-grade content as well as a teacher who has taught it." Then the plan to close that. Hold through two follow-ups. Do not fold on the core claim to restore harmony. | This is the pressure form of F2. The hold-then-concede structure is the rehearsal: a position you can back, and a concession you can name. |

### B. The Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two teams sit side by side. Where's the seam between third and fourth grade, and what happens when you disagree?" | JD | [generic] | Name the principle you would use when grade-level expectations collide: talk to the other team, look at the data together, decide on shared terms. Do not pretend to know the seam. | Peer probes about the seam between grades. A principle beats a guess about a seam you have not seen. |
| B2 | "What would you need from our team in your first month?" | JD | [generic] | Name specific needs: the scope and sequence, the materials, the week's plan, a time to observe the team's reading block. | Reciprocity question. It shows you are thinking about what you would ask of them, not only what you bring. |
| B3 | "You've run the reading club for two years. What do you bring to a grade team's reading block?" | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what you did in the club, in your words. Answer slot: if you planned the club's sessions yourself, say so. If the plan came from somewhere else, say where and what you adapted. | F4's reading link is the club. The question asks about the club, not about results. |
| B4 | "How do you handle credit when work spans teams?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Credit the people who were on the move, then name your part. Answer slot: if others made decisions, name them and what you did. | Credit-sharing is a peer probe. Your own CV line is the example to use, at its own scope. |

### C. The Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student can read but avoids reading and says she hates it. What do you do on Monday?" | CASE | [generic] | Clarify first: what she reads now, what the reading assessment shows, what she chooses to read. Then an approach: a low-pressure choice of text, a short goal, one check-in. Name what you would watch for. | A live classroom problem from the role. No claim about your past. |
| C2 | "Your fourth graders sit at three reading levels, and a parent asks why. How do you respond?" | CASE | [generic] | Start with the parent's concern. Explain the grouping in plain language and the way it changes. Name what you would show the parent. | A live communication problem with a family, which ties to F5. |
| C3 | "A new reading curriculum isn't working for half the grade level. What do you bring to the team?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe how you would check the problem before changing anything: what you would look at and with whom. Answer slot: if you saw something like this with the 2024 curriculum, say what happened and what you did. If not, say so and describe the approach. | Uses your 2024 move as the reference point, at its own scope. |
| C4 | "Write a short note to families about a change in homework. How do you open it?" | CASE | [grounded] "I write a weekly email to families" (your CV) | Open with the change and why it matters to the child. Describe the routine you already use for the weekly email, in your words. | Ties F5 to a live writing task. |

### D. The Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the 2024 reading curriculum move worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the weakest assumption you know of before they do. Answer slot: if you tracked anything to judge the move, name it and say how. If you did not measure it, say so plainly and name what you would look at. | A prober will ask about results your CV does not state. An honest "I didn't measure it" is a strong answer. |
| D2 | "Which part of your six years in third grade would you defend least?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Name the part of the six years you would defend least, such as what a year in third grade does not show about fourth grade. | Tests whether you know the limits of your own record. Not a trap; a credibility move. |
| D3 | "How do you know the reading club helped the students who attended?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything for the club, name it and say how. If you did not, say so and name the observation you would use next time. | The club is a headline line. Do not claim outcomes your material does not show. |

### E. The Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | A 90-second arc: third grade, the reading curriculum move, the reading club, the weekly family email, and why fourth grade. Say the gap in the arc, not at the end. | The opener is scored. Casual questions still count. |
| E2 | "What's the part of your week you look forward to?" | JD | [grounded] "I write a weekly email to families" (your CV) | Keep it short and concrete. The weekly email is a real example. | Casual register, scored for communication economy. |

Requirement coverage:
- PEL with elementary endorsement: F1, gate met, no question needed.
- Fourth Grade Teacher position: A1, A2, A5, E1.
- Team lead (your gap): A3, A4, B4.
- Reading instruction: C1, C3, B3, D1.
- Family communication: C2, C4.

## Persona table

| Persona | Who on the panel | Likelihood | Why | Weight | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal, and possibly a team member | High | Your two gaps (fourth grade, team lead) are the first thing a panel sees. | 5 | Say the gap first. Hold through two follow-ups. Concede specifically. |
| Peer Evaluator | The two fourth-grade team members | High | They will price what you add to their team and what you need from them. | 4 | Reciprocity framing. Name principles for seams you have not seen. |
| Case / Strategist | Principal | Medium | Classroom problems are common in panel rounds for this role. | 4 | Clarify, then approach. Think aloud. No claim about your past. |
| Data-Driven Prober | Principal or a team member | Medium | Your reading curriculum move and your club imply outcome questions. | 3 | Name the weakest assumption. Say "I didn't measure it" when it is true. |
| Conversational | Any panel member, at the start | Medium | Openers are scored. | 2 | A 90-second arc, with the gap included. |

## Reverse questions

1. "What does the fourth-grade team plan together each week, and where would a new teacher fit in that?" Why it lands: it shows you are thinking about the team, not only the job.
2. "What reading materials does fourth grade use now, and what would you want a new teacher to know about them?" Why it lands: it shows you are ready to learn the materials, not just teach them.
3. "How is the team lead role chosen here, and what does it involve?" Why it lands: it shows interest in leadership without claiming it.
4. "How do families usually hear from the school week to week?" Why it lands: it connects to your own weekly email.
5. "What would a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question for the fourth-grade members.
6. "Is this Thursday session the final round, or is there a next step?" Why it lands: it shows you are planning around the process, not just the day.

## Sources

Research tier: L0. No searches or fetches were run for this pack. You have not consented to research, and you have not given a job posting.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary values` | unavailable | Values cheat sheet. Research not run this turn. |
| 2. `Orrinsford Community School District fourth grade teacher interview process` | unavailable | Loop structure and persona weights. Research not run this turn. |
| 3. `Orrinsford Community School District strategy / recent news` | unavailable | Grounding brief for the panel's current priorities. Research not run this turn. |
| 4. `Dolores Vantongeren Orrinsford Community School District` | unavailable | Interviewer read and a tailored reverse question. Research not run this turn. The name is in hand. |
| 5. Representative fourth-grade teacher job posting | unavailable | Requirement text for F2 to F5, which would move from `[generic]` to `[inferred]`. Research not run this turn. |

Provided documents: your invite, your CV (as pasted in your message) and your note.

## Upgrade menu

- The full job posting text → F2 to F5 requirements move from role-family prose to quoted, `[grounded]` requirements, and the coverage table is rechecked.
- The panel's focus areas, or any announced deliverable such as a sample lesson or written task → a build section for it.
- Public research at the default tier on the school, district and principal → a values cheat sheet if they publish values, a grounding brief, and an interviewer read with a tailored reverse question.
- The confirmed date → checked against the calendar. Thursday, 26 November 2026, is Thanksgiving Day; confirm the date with HR.
- `tuesday-dossier.md` → the gaps this prep exposes can be carried into later sessions as verified evidence.
