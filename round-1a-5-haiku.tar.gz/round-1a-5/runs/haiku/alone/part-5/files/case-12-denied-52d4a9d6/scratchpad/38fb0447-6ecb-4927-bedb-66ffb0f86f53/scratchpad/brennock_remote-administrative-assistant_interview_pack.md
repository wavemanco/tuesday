# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager. **Relationship:** assumed to be a hiring manager, the person you'd work with day to day; tell me if that's wrong. **Built from:** your message (the ad's duties as you summarised them, the recruiter's email, your background). No full ad text, CV or company research was available, so most rows are marked `[grounded]` only where they quote you.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **JD**: can you do the listed job, including its gaps.
- **EXP**: do your claims about past work hold up under questions.
- **CASE**: a live problem from the role; no past claim is needed.
- **VAL** and **CO** (values, company strategy): not in this pack, because no company values or research were retrieved.

Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds.

**What to expect:** a short call in which the office manager walks through the four duties (calendars, travel, Word and Excel documents, supplier invoices) and asks how you have done each. Expect the most pressure on invoices and travel, where your material is thinnest.

## Fit snapshot

Requirements come from your message's summary of the ad, quoted as you wrote them. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message, ad summary) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says one appointment book for four physios. Say that, not "managed calendars". Answer slot: if you set rules for clashes or moved bookings between diaries, say which and how; if the clinic set those rules, say so. |
| F2 | "booking travel" (your message, ad summary) | none given | none | [generic] | discovery | Your material is silent on travel. Answer slot: if you have booked travel for someone, say what and how; if you haven't, say so and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" (your message, ad summary) | "good with Word, okay with Excel" (your message) | medium | [grounded] | transferability | Use your own level: good with Word, okay with Excel. Answer slot: name one document you prepared in Word and one Excel task you did. |
| F4 | "processing supplier invoices" (your message, ad summary) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | Chasing unpaid invoices is not processing supplier invoices; do not stretch the bridge. Answer slot: if you entered, matched or approved invoices in any system, say how; if you only followed up payments, say that and say how you would learn the processing steps. |
| F5 | "Remote Administrative Assistant" (recruiter's email) | none given | none | [generic] | discovery | Your material says nothing about working remotely. Answer slot: if you have worked without a team in the room, say how; if not, say so and say how you would structure your day. |

## Prohibited claims

Claims this pack will not coach, built here from your own sentences. Each one is a stretched version of something you actually said.

| # | Claim to avoid | Basis | Honest form |
|---|---|---|---|
| P1 | "managed calendars" | Inflated form of F1's "ran the appointment book for four physios" | "ran the appointment book for four physios". Observation: your material shows one book for four people, not calendars across a team. |
| P2 | "processed supplier invoices" | Inflated form of F4's "chased unpaid invoices" | "chased unpaid invoices". Observation: your material shows chasing payments, not processing invoices. |
| P3 | "strong" or "advanced" Excel | Inflated form of F3's "okay with Excel" | "okay with Excel", plus the specific tasks you can name. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A: Hiring manager (office manager) | Walks through the four duties and asks how you did each | High (depth 5): the office manager is the likely interviewer, and the ad lists four duties | For each duty: what you actually did, then the gap, then how you would learn it |
| B: Skeptic | Probes the gap between clinic reception and this admin role | Medium (depth 3): the invoice duty is the thinnest match in your material | Hold to the quoted sentences; name the limit before you are pushed |
| C: Pressure | Presses on the gaps: why you over someone who has done this | Medium-low (depth 2): common in short calls | Hold one core claim, then concede the gaps specifically |

## Question banks

**A: Hiring manager (depth 5)**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Walk me through how you ran the appointment book for four physios. | EXP, JD | [grounded] "ran the appointment book for four physios" (your message) | Describe the routine in your own words: how bookings came in, how you handled a clash between two diaries, what you did when someone was double-booked. Answer slot: if you set rules for clashes, say them; if the clinic set them, say that. | Closest match to the calendar duty (F1). It is an open walk-through, so it needs a scaffold, not a script. |
| A2 | Two people need booking at the same time. What do you do? | CASE, JD | [generic] | Method: check priority and deadlines, ask the more urgent party, confirm in writing, note what moved. Speak it as a method, not as something you did. | Tests calendar judgement with no past claim needed. |
| A3 | Have you booked travel for anyone? Take me through one booking. | EXP, JD | none given | If you have, describe one booking in your words. If you haven't, say so plainly and say how you would learn the booking tools and approval steps. | Travel is a listed duty with no evidence (F2). The honest branch is the core answer. |
| A4 | Talk me through a Word document and an Excel task you have done. | EXP, JD | [grounded] "good with Word, okay with Excel" (your message) | Name one Word document and one Excel task. Keep "okay" as okay. Answer slot: if you used formulas or lookups, name them; if not, name the Excel tasks you can do and the ones you would learn. | Interviewers test a self-rated level with a concrete task (F3). |
| A5 | What is your experience with supplier invoices? | JD | [grounded] "chased unpaid invoices" (your message) | Say what chasing involved: which invoices, how you followed up, what happened. Answer slot: if you entered, matched or approved invoices in a system, say which; if you only followed up payment, say that. | The invoice duty has no direct match (F4), so this needs a careful answer. |
| A6 | What would you do in your first week to learn our systems? | CASE | [generic] | List: ask for the calendar, travel and accounts tools, shadow an invoice run, write down the approval rules, ask what the office manager expects by the end of week one. | Tests your plan for closing gaps. Nothing is claimed about the past. |
| A7 | Tell me about a time you had to chase something important. | EXP | [grounded] "chased unpaid invoices" (your message) | Open prompt: a real chase, in your words. Beats from your quote: what was owed, who you followed up with, what you did next. Answer slot: if you recorded an outcome, state it; if you did not track one, say so. | Open prompt on the invoice theme the ad raises. Your quote carries only the chase, not an outcome. |
| A8 | How do you keep track of several deadlines at once? | JD | [generic] | Describe your own system. Do not invent a tool or a habit. | Generic duty probe; the answer has to be yours. |

**B: Skeptic (depth 3)**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | You chased unpaid invoices. Did you ever process supplier invoices, or only chase payments owed to the clinic? | EXP, JD | [grounded] "chased unpaid invoices" (your message) | **Highest-ROI prep in this pack.** Hold: "I chased payments on invoices owed to the clinic." Answer slot for the concession: if you did not process supplier invoices, say so plainly and name what you would learn first, such as purchase orders and approval steps. Hold through two follow-ups; do not fold to "yes" to restore harmony. | The invoice duty is the thinnest match in your material, so this probe is likely. Deepest rehearsal: three levels, with the limit named before it is asked for. |
| B2 | Two years on a reception desk: what makes you think you can run a remote diary? | JD, EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Bridge with what you did: you kept a shared diary for four people in one building. Say what changes when the team is remote and how you would adapt. Answer slot: if you have worked remotely or used remote tools, name them; if not, say so. | Remote is in the title (F5); the bridge is your desk role, kept at its own scope. |
| B3 | "Okay" with Excel. How okay? | JD | [grounded] "okay with Excel" (your message) | Name the functions or tasks you use and the ones you would need to learn. Keep "okay" as okay; do not upgrade it under pushback. | Pushback on a self-rating (F3). |
| B4 | What do you already know about what our company does? | JD | [generic] | Say what the ad and the recruiter's email told you, and that you would want to check more. Do not invent facts about the company. | No company research was retrieved, so the honest answer is the scope of what you know. |
| B5 | A supplier invoice doesn't match its purchase order. What do you do? | CASE | [generic] | Method: check the purchase order and delivery record, query the supplier, log the mismatch, escalate to whoever approves. | Live processing question; method only. |
| B6 | Which of the four duties would you find hardest, and why? | JD | none given | Name the one you are least sure of, from your own material, and the first step you would take to close it. | Tests honesty about gaps without asking you to claim a past. |

**C: Pressure (depth 2)**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | The ad asks for travel booking and invoice processing. Why should we hire you over someone who has done both? | JD, EXP | [grounded] "ran the appointment book for four physios" (your message) | Hold: "What I have done is run a shared appointment book for four people and chase payments." Concede specifically: name the two gaps. Close: say how you would close each in the first month. Hold through two follow-ups. | Pressure on the gaps. The held claim is one your quote carries, and nothing more. |
| C2 | Isn't "okay" with Excel a polite way of saying weak? | JD | [grounded] "okay with Excel" (your message) | Do not fold to "weak", and do not puff up to "strong". Say what "okay" means for you, name the tasks, and name your learning step. Hold through two follow-ups. | Pressure on a self-rating (F3). |
| C3 | How do you stay organised without a team in the room? | JD | none given | Answer slot: describe the routines you use, if any. If you have not worked remotely, say so and say how you would structure your day. | Remote is in the title (F5); there is no evidence to lean on. |
| C4 | Give me one reason to believe you will be good at this in six months. | EXP | [grounded] "ran the appointment book for four physios" (your message) | Name the strongest thing you did, at its own scope, and what you would do to show progress in six months. | A pressure closer; the answer rests on your quote and no more. |

**Requirement coverage**

| Requirement | Questions | Notes |
|---|---|---|
| Managing calendars | A1, A2, A6 | |
| Booking travel | A3, B6 | |
| Word and Excel documents | A4, B3, C2 | |
| Supplier invoices | A5, A7, B1, B5, C1 | |
| Remote working (from the title) | B2, C3, B4 | B4 covers the company side |

## Reverse questions

1. **What does the admin workload look like week to week: how much is calendars, travel and invoices?** Why it lands: it shows you are asking about the real split of the job.
2. **Which systems would I use for calendars, travel bookings and supplier invoices?** Why it lands: you learn what to prepare before a start date, and it shows you think about the work itself.
3. **Who would I work with day to day, and how often do you meet remotely?** Why it lands: remote roles depend on this, and the answer tells you about support.
4. **What would make the first 90 days a success for you?** Why it lands: it asks for their scoring sheet directly.
5. **What are the next steps after this call?** Why it lands: it gets the process in writing. It does not check the invite.

## Sources

- **Provided documents:** your message (the ad's duties as you summarised them, the recruiter's email, your background).
- **Web search, query 1:** "Brennock Facilities Ltd Remote Administrative Assistant recruitment". Refused: web search permission was not granted in this session.
- **Web search, query 2:** in place of the query, "reports of recruitment scams that use this company's name". Refused: the same reason.
- **Research tier:** L0. Both searches were refused and no pages were fetched, so no company research is in this pack.

Target accounting:

| Target | Status |
|---|---|
| Official company values | unavailable |
| Documented loop structure | unavailable |
| Recent strategy sweep | unavailable |
| Interviewer public footprint | n/a: no name given |
| Representative JD | n/a: the duties were supplied in your message |

## Upgrade menu

- **The full ad text** → the four duties become quoted `[grounded]` rows, and any other listed requirement gets a row.
- **Your CV** → the fit rows quote your CV's wording, not only your message.
- **The office manager's name** → a tailored reverse question, and persona weights read from their public footprint.
- **Your prep time** → a prioritised order for the 18 questions.
- **A `tuesday-dossier.md`** → verified evidence and allowed strategies for each weak area, replacing the inferred rows.
