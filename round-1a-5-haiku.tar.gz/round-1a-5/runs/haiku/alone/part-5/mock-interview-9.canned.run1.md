Your prep pack is saved here: /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-9-canned-2cb99cfe/a5d420dc-959c-4fa8-aabc-350534e28dac/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md

I left out the ID number and your license number. The pack uses only the license status, which is all the panel needs.

The invite looked ordinary to me. It asks for no fee, bank details or documents, and the district's own hiring page describes the same 45-minute building panel, so I've included no warning.

The main findings:

- **Your biggest gap is fourth grade, not team lead.** The invite doesn't ask for team leadership, so I treat it as a likely probe rather than a stated requirement. The principal is the most likely person to press on the fourth-grade step.
- **The principal's background is in reading.** Public sources say she was a reading specialist for nine years before becoming principal in 2022. Expect precise reading questions, so the highest-value prep is the reading-instruction question in bank A.
- **Your 2024 curriculum move is your strongest evidence.** The district has a new grades 3–5 reading curriculum coming in fall 2027, so that move is directly relevant. The pack keeps it at the scope you described, without claiming you selected the curriculum.
- **The pack limits your claims.** Anything it says about your past comes from your own sentences, and the rest is marked as an answer slot for you to fill in your own words.

I built this at the default research depth. I checked the district's values and hiring pages, the literacy plan news and the principal's public profile. I didn't find a job posting for this district, so the JD-based questions rest on the invite and on a representative listing.

**Question:** Does the panel include a demonstration lesson or a written task? If it does, the pack needs a section for it.

Two offers, neither pushed:
- I can play the Skeptic on question A2, the reading-instruction question the pack names as highest-return prep.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Format: 45-minute panel on Thursday with Principal Dolores Vantongeren and two fourth-grade team members (names not given). Built at research tier L1. No job description was supplied, so JD-tagged content rests on the invite, the district's own hiring page, and one representative listing marked `[inferred]`.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioral and values alignment, against the district's published beliefs
- **EXP**: your own experience, and whether it holds up under questions
- **JD**: the role's stated responsibilities and requirements
- **CO**: the district's current direction, from research
- **CASE**: a live problem, reasoned aloud

Guidance is scaffolding, not a script. Every claim about your past is one of your own sentences, quoted, or a plain acknowledgment, or an answer slot for you to fill in your own words.

## Prep triage

Omitted: no prep time was given.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is the one gate in the invite. Your material shows it met, so no bridge is needed. Have the license details ready, since the panel may check them. |
| F2 | "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page (fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Reading instruction is reached in role terms by the curriculum move and the club. Expect the probe to land on fourth-grade reading, which F5 covers. Say the curriculum move in those words. |
| F3 | "classroom routines" — district hiring page (fetched) | none given | none | [grounded] | discovery | Your material does not show a classroom routine. Answer slot: name a routine you have run in your own classroom, how it works, and whether the school set it or you did. If you have not set one yourself, say so and describe how you would set one. |
| F4 | "how you work with families" — district hiring page (fetched) | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The email reaches families, but not conversations with them, which the district's beliefs name. Bridge: "I write a weekly email to families," at its own scope. Answer slot: if you have talked with families one-to-one, say how often, in your own words. If not, say so and describe the email. |
| F5 | "Fourth Grade Teacher" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | none | [grounded] | transferability | Third grade is adjacent work. The step up to fourth grade is the gap you named. Plain acknowledgment: "I've never taught fourth grade." Then third grade at its own scope. Make no claim about fourth-grade lessons. |
| F6 | "team lead" — `[generic]` role-family requirement; not in the invite | "I've never been a team lead." — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | low | [grounded] | transferability | The invite does not ask for team leadership. This is the gap you raised, and no source names it as a panel topic, so the bank writes it as a likely probe only. Plain acknowledgment: "I've never been a team lead." Adjacent work: the curriculum move, at its own scope. |
| F7 | "a new grades 3–5 reading curriculum from fall 2027" — district news (search result) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | none | Context row: the district is changing its grades 3–5 reading curriculum. Your 2024 move is the nearest sentence you have. Keep it at its own scope. |

## The prohibited list

Built locally from the fit snapshot. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Led the grade-level team | Inflated form of "I've never been a team lead" and of "I led our grade level's move to a new reading curriculum in 2024" | The curriculum quote at its own scope. Analysis, not words for you: the material shows a curriculum move led, not a team led. A3 stays inside the curriculum move. |
| Selected the reading curriculum | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. A5 and D3 ask which part was yours to decide. |
| Designed the reading club | Inflated form of "I've run the after-school reading club for the last two years" | The quote at its own scope. C1 asks what, if anything, was counted. |
| Taught fourth grade | Negative you stated: "I've never taught fourth grade" | Plain acknowledgment: "I've never taught fourth grade." No answer slot. |
| Spoke with every family each term | Inflated form of "I write a weekly email to families," and the district's belief "each teacher speaks with every family each term" | The email quote. B3 asks about one-to-one contact, and your answer stays with what you did. |

## Reading the interviewer

Public footprint only. Principal Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5 (ilprincipalsforum.example).

Implications:

- Reading is her home ground. Expect precise reading questions. A2 is the most likely place for that.
- She may ask about reading conferences. Your material does not mention them, so do not claim them. Answer as A2 instructs.
- Shared vocabulary: "reading curriculum," and grades 3 to 5. Use the words you already have from F2.
- No shared career jump is offered, because your material does not carry one.

## Persona table

The principal is the likely lead on the panel. The two team members are peers. Names of the team members are not known, so persona weights are assigned by role, not by person.

| Persona | Who | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic (weight 5) | Principal | Quiet, persistent probing of the fourth-grade step and team lead | High | Two gaps in your message, and a principal who tests transfers from third grade | Rehearse the fourth-grade and team-lead objections until they are plain. Name the limit first, then the nearest thing you did. |
| Peer Evaluator (weight 4) | Team members | Seams with their own work, "what would you bring" | High | Peers price what the hire adds to their load | Lead with what you would bring their team, not only what you need |
| Case/Strategist (weight 4) | Principal | Live reading and routines problems | Medium | The invite and hiring page name routines and reading | Clarify before you answer. Think aloud. |
| Data-Driven Prober (weight 4) | Team members | Asks what was counted, and what assessment data you used | Medium | Your club and your email are the claims a prober tests | Say what you counted, and say plainly when you counted nothing |
| Conversational (weight 2) | Whoever opens | Casual "tell us about yourself" | High | Openers are scored casually | Keep a 90-second arc ready, built from quoted sentences |

Total: 19 questions across the banks, inside the 18 to 26 range.

## Question banks

### A. Skeptic (principal lead), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never taught fourth grade. What would you do in your first month with a class of fourth graders?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Plain acknowledgment: "I've never taught fourth grade." Then the step up from third grade as a plan, in the order you would look at things first. Answer slot: if you have worked with fourth-grade students in any setting, say where, in your own words. If not, say so and stay with third grade. | F5 is the fourth-grade gap. The principal will test the step up first. The question asks for a plan, so the guidance makes no past claim. |
| A2 | "The panel asks about reading instruction. Where would your reading instruction be weakest in a fourth-grade room?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | Name the weakest part first, in your own words. Then the nearest thing your material carries: the curriculum move and the club, at their own scope. Hold through two follow-ups by returning to what you have taught, not by adding to it. | Highest-return prep in this pack. The principal's background is in reading (see Reading the interviewer), so reading probes will be precise. |
| A3 | "You've never been a team lead. What would you do in your first term on a team that has worked together for years?" | JD | [grounded] "I've never been a team lead." — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment: "I've never been a team lead." Then how you would learn the team's routines before you proposed change, as a plan. Answer slot: if you led any part of the 2024 move, say which part and how you decided, in your own words. If you did not, say so and describe what you contributed. | F6 is the team-lead gap. This is a likely probe rather than a panel topic. The question asks for a plan, and the 2024 move is the nearest sentence you have. |
| A4 | "Why fourth grade, and why this building, after six years in third grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Your material gives no reason for the move, so this guidance gives none. State your reason in your own words. If you have not yet put it into words, say that, and name the part you are sure of. | The question presumes a move your CV carries only as a fact. The reason is yours to give. |
| A5 | "When a new reading curriculum does not fit a student's level, what do you do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you adjusted a student's placement or materials under the 2024 curriculum, say what you did and why. If you did not, say so and describe what you would do. Hold your position on which choices were yours, and concede only what you cannot back. | The question presumes a level-fitting practice that no quote states, so the second branch must allow that it never happened. |

### B. Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us how you'd work with a grade-level team you've just joined." | JD | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page; [generic] for the scaffold | Scaffold: what you would learn about the team's plans first, what you would bring to them, and how you would raise a disagreement with equals. Make no claim about your past. | F6 gap, asked as a peer would ask it. Reciprocity: what you bring their team. |
| B2 | "What would you bring to our team's reading work?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say the 2024 move in your words, at its own scope. Answer slot: if you would influence the team's reading decisions, say which, in your own words. If you have not been part of such decisions, say so. | Peers want to know what the hire adds to their work. |
| B3 | "We're a family-partner school. How do you keep families in the loop?" | VAL | [grounded] "Families Are Partners" — district mission and beliefs page; "I write a weekly email to families." — your CV | Quote the weekly email as you wrote it. Answer slot: if you have talked with families one-to-one, say how often. If not, say so. | F4 limit: the email reaches families, and the district's belief names conversations each term. |
| B4 | "Where's the seam between your third-grade work and our fourth-grade plan, and what happens when you disagree with a colleague?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; [generic] for the disagreement scaffold | Seam: name the third-grade work and where fourth grade starts. Disagreement: no sentence in your material carries one, so use selection criteria. Pick a disagreement with a colleague that had a real stake and left the working relationship intact. If none comes to mind, say so, then describe how you would raise a disagreement with a grade-team peer. | Peer seam probe. The disagreement story is a scaffold, not a claim. |

### C. Data-Driven Prober (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How do you know your reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer slot: if you counted anything about the club, such as attendance or reading levels, say what and how. If you counted nothing, say so plainly. Do not offer a measure you did not track. | No figure is in the material, so no defend-the-number slot applies. The question presumes a measure, so the second branch allows that none was kept. |
| C2 | "Walk me through the weekly email to families. How do you decide what goes in it?" | EXP | [grounded] "I write a weekly email to families." — your CV | Describe the choice in your own words. Answer slot: if you chose the contents, say how. If the school sets a format, say so. | Premised question on a practice the quote does not state. |
| C3 | "Which assessment data did you use to plan reading groups last year?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "assessments inform teaching and never replace it" — district mission and beliefs page | Answer slot: if you used assessment data to plan groups, name which and how. If you did not, say so plainly. | The question presumes groups and data that no quote states. The district belief names assessment, which is why the prober may ask. |
| C4 | "Give me a figure from your reading curriculum rollout." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Conditional: if you have the figure, give it with what it counts. If you do not have it, say you do not have it and that you would check. | No figure is in the material. The prober wants a number; the honest answer is the one you have. |

### D. Case/Strategist (principal), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Half of a fourth-grade class is below grade level in reading in October. What do you do this week?" | CASE | [generic] | Clarify, then state the objective, then segment the class, then approach, metrics and risks. Say first what you would check: which students, which skill. Make no claim about your past. | Live problem in the principal's reading lens. |
| D2 | "What routines would you set in the first two weeks of a fourth-grade year?" | CASE | [generic] — the routines topic is in the district hiring page's panel list | Scaffold: list the routines in the order you would teach them, with the reason for each. Name where a routine came from in your own room only if you can. | Covers F3, the routines gap. |
| D3 | "Our board adopted a grades 3–5 reading curriculum for fall 2027. What would you need to know about it before you teach it?" | CO | [grounded] "a new grades 3–5 reading curriculum from fall 2027" — district news (search result); "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say what you would need from the materials and from the team first. Then the 2024 move, at its own scope. Answer slot: if you advised on the 2024 choice, say which part. If you did not, say so. | Strategy question from research. The 2024 move is the only nearest sentence. |
| D4 | "How would you use a family reading night, which the district holds at every school each term?" | CO | [grounded] "a family reading night at every school each term" — district news (search result); "I've run the after-school reading club for the last two years" — your CV | Scaffold: what a family reading night would need in your room. Then the club, at its own scope. Make no claim that the club held family events. | Family reading night is from research. The club is the nearest reading experience you have. |

### E. Conversational (opener), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV; "I write a weekly email to families." — your CV | A 90-second arc in this order: the classroom, the curriculum move, the club, the weekly email, then the fourth-grade step as a plain acknowledgment. Each beat is one quoted sentence, at its own scope. | Openers are scored casually. |
| E2 | "So, walk us through the journey from your first classroom to here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Use the same arc as E1, in order. Add no events you have not named. | Same arc, a second time, in a different register. |

### Requirement coverage

- Illinois PEL with elementary endorsement: gate, met per your CV. No question, because the status is the check.
- Reading instruction: A2, D3, B2
- Classroom routines: D2, F3 answer slot in A-bank
- How you work with families: B3, C2
- Fourth-grade teaching: A1, A4
- Team lead (`[generic]`, not in the invite): A3, B1

## Reverse questions

1. "How will the fourth-grade team use the grades 3–5 reading curriculum when it arrives in fall 2027?" Why it lands: shows you read the district's literacy plan.
2. "You were a reading specialist before you became principal. Which reading question do you still bring into the building?" Why it lands: ties to her own path, so it becomes a conversation between colleagues.
3. "What could a new person do in the first month that would genuinely help your team?" Why it lands: reciprocity, framed the way a peer frames it.
4. "How does the team plan family reading night each term, and who leads it?" Why it lands: links to the district's family reading night.
5. "How does the building use assessment to inform teaching, in practice?" Why it lands: tests the district's belief in concrete terms.
6. "What would make your first term here feel successful to you?" Why it lands: tells you what they expect, and signals you plan to deliver it.

## Sources

Provided documents: the invite text, and the facts in your message (license, six years in third grade, curriculum move, reading club, weekly email, and that you have never taught fourth grade or been a team lead).

Searches and fetches, with what came back:

- "Orrinsford Community School District values": returned the district's Mission and Beliefs page (fetched).
- "Orrinsford Community School District teacher interview process panel": returned "How we hire teachers" (fetched). It names one 45-minute building panel, the principal and two grade-level teachers, and the topics above.
- "Orrinsford Community School District strategy news": returned the board's 2026–2029 literacy plan (search snippet, not fetched).
- "Fourth Grade Teacher job description elementary Illinois Professional Educator License elementary endorsement": returned one listing at k12jobsboard.example (search snippet). It is not attributable to this district, so it is used only as a typical-role reference, `[inferred]`.
- "Dolores Vantongeren principal Halvering Elementary School": returned a principal profile (search snippet, ilprincipalsforum.example).

Research tier: L1 — searches 5 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Three beliefs ("Every Child a Reader," "Families Are Partners," "Teach for Tomorrow, Not for the Test"). Used as raising sources in B3 and C3. No values cheat sheet, because the loop source does not name a values-style round. |
| 2. Interview process | yes | One 45-minute building panel, principal plus two grade-level teachers. The panel's topics frame the banks. |
| 3. Strategy / news | yes | Board literacy plan: a grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Moved D3 and D4. |
| 4. Interviewer name | yes | Principal since 2022; nine years as a reading specialist before that; 2025 talk on weekly reading conferences in grades 3 to 5. Moved the interviewer read and A2's weighting. |
| 5. Representative JD | yes | One listing, `[inferred]`. Checked the coverage list. Did not change any grounded row. |

## Upgrade menu

- The full job posting text → the representative-listing rows become `[grounded]`, and F3 and D2 sharpen
- The two team members' names → personas assigned per person, and their public footprint can be checked
- Whether the panel includes a demonstration lesson or a written task → a graded-deliverable section
- A deeper research pass on the principal (up to 6 more searches and 2 more fetches, several more minutes) → a tailored reverse question on reading conferences; say the word if you want it
