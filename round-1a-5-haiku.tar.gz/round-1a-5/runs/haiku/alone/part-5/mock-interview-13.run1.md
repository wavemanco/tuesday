Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-13-denied-0b9733a5/ee12c67b-9b5d-460a-97cc-c976ed4cb1e7/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. I built it on a recruiter screen, as your note describes. It has 13 questions rather than the usual 18 to 26, since this is a 30-minute logistics call. Web research was refused in this session, so it uses only the advert, Hannah's message and what you told me.

**Your four logistics answers, in your own words:**
- **Pay:** "I'm hoping for £42,000." Then stop. Don't add a range or a floor.
- **Notice period:** you haven't told me yours, so I can't script it. Give your actual figure.
- **Hybrid:** "Two days at Avonmouth is fine. I wouldn't want more than three."
- **Reason for moving:** "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want."

**The question to rehearse most:** "This role coordinates production planning, the warehouse and QA. Your background is wholesale delivery. Why is this a fit?" Your real overlap is scheduling deliveries across three depots and chasing suppliers when orders slip. Lead with that. Concede only that you haven't used SAP. Don't claim production-planning or QA experience you don't have.

**Other likely questions:** the stock-count drop of about a third (be ready to say how it was measured, or that you didn't measure it), and whether you've reported on on-time dispatch. Your material doesn't show that, so say so plainly if it's true.

**Questions to ask Hannah:**
1. What does a typical week look like across planning, the warehouse and QA?
2. How is on-time dispatch measured and reported today?
3. Which stock system do you run, and how much of the work sits in it?
4. What are the next steps and rough timing after this call?

I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later rounds. Say so if you want it. I can also convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Round: 30-minute phone call with Hannah Lowther (Talent Partner), Thursday 2pm. Relationship: recruiter. Format: phone.

Changes since last version: none (first version).

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **JD**: the question tests a requirement or term from the advert. **EXP**: the question tests what you actually did.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- Your material is quoted in the Provenance and Evidence columns. Anything in quotation marks is your sentence or the advert's.
- **Answer slots** are instructions for the interview. They are not questions to me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Lead with the four years and the wholesaler, in those terms. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows depot delivery scheduling, not production planning, warehouse or QA coordination. The words stay there: "I schedule deliveries for our three depots." Answer slot: if you coordinated across planning, warehouse or QA in any way, say how; if you did not, say so plainly and stay with the depot scheduling. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | none | No gap. The quote reaches the requirement. Use the words: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Your sentence already reaches stock records in other terms, a spreadsheet and not the stock system. Say it as written. Do not add a figure or method you have not given. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported on delivery timing, say what and how often; if you did not, say so plainly and describe how you tracked deliveries. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The quote shows spreadsheet work, not a self-rating. Say it as written, then answer the Excel question in your own words. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't used SAP." Then: "We run our own in-house stock system." Do not describe that system as an ERP unless you know it is one. |

Gate rows: none. The advert's requirements are experience, Excel and a plus-ERP item. None is a knockout gate that your material leaves unmet.

**Pay and location, from your message, are in the logistics rows (A3 to A5), not in the snapshot.**

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production planning or coordinated production schedules | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says depot deliveries, not production planning. |
| Worked with SAP or any ERP | Negative you stated, F7 | "I haven't used SAP." No further claim. |
| Managed supplier relationships or supplier performance | Inflated form of F3 | "I chase suppliers when orders slip." |
| Cut stock discrepancies by a third | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The drop happened over a year. You rebuilt the sheet. |
| Reported on on-time dispatch | Silence, not a negative. Listed only so the pack does not imply it. | Answer slot in B4. Do not state it. |
| Any current salary or pay history, a floor, or a figure below £42,000 | Not given by you | Your figure only: "I'm hoping for £42,000." |
| Flexibility on location beyond your stated limit, or openness to Reading | Not given by you | Your stated limits only: two days is fine, not more than three. |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly, logistics-first, asks your background and the four logistics points in a relaxed tone | High. A recruiter screen's register. Weight: top, 4 questions | Practice the 90-second background, and say each logistics answer in your words without adding. |
| Skeptic | Quiet probing of the production gap, ERP and Excel | Medium-high. The advert's production and ERP lines are where your material is thinnest. Weight: mid, 4 questions | Rehearse B1 until it is boring. Hold with what you stated; concede only the SAP point. |
| Pressure | Short challenge on the production gap or the figure | Low to medium. Weight: low, 2 questions | Pause, restate, hold through two follow-ups. |
| Data-driven prober | Asks how the one-third drop was counted | Low. A recruiter rarely probes, but the figure is on your message. Covered inside A2 and C2 | Know how you measured it, or say plainly you did not. |
| Values / behavioral | Not in a recruiter screen. Not weighted. | Low. No values round detected | None needed for this call. |

## Question banks

### A. Conversational (recruiter's register), weight: top

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet" | 90 seconds, four beats in this order: the four years as a logistics coordinator at the wholesaler; scheduling deliveries for the three depots; chasing suppliers when orders slip; the stock-count spreadsheet rebuild. Say them as written. Stop there. | F1, F2, F3 and F4 are the spine of every later answer. A clean background keeps the Skeptic from finding the gap first. |
| A2 | "Tell me about the stock-count spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the rebuild and the drop, in those words. Answer slot: if you counted the drop, say how, in your own words; say which assumption behind it you would defend least; say which part was yours. If you did not count it, say so plainly. Never give a method you did not use. | F4. A third is a figure you gave, so it raises the defend-the-number slot. This is where a prober would start. |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot. Say your figure, in your words: "I'm hoping for £42,000." Then stop. Do not add a range, a floor or a reason. | Pay is a logistics slot. It is also in the advert's £38,000 to £44,000 band, so your figure sits inside it. |
| A4 | "What's your notice period?" | JD | [grounded] your notice period is not in your message | Logistics slot. Give your actual notice period, in your own words. Do not estimate it. | Notice is a logistics slot, and your figure is not in the material. This row is an instruction until you give it. |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine" and "I wouldn't want more than three" | Logistics slot. Say it in your words: "Two days at Avonmouth is fine. I wouldn't want more than three." Do not describe how you would travel unless asked. | Location is a logistics slot. Your limit is stated; say it once. |
| A6 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot. Say it in your words: "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want." Do not add what you want next unless you choose to. | The reason for leaving is a logistics slot. It is true, and it is a reason the recruiter can accept without follow-up. |

### B. Skeptic, weight: mid

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production planning, the warehouse and QA. Your background is wholesale delivery. Why is this a fit?" | JD | [grounded] "I schedule deliveries for our three depots"; "chase suppliers when orders slip"; "4 years as a logistics coordinator at a building-supplies wholesaler" | **Highest-ROI prep in this pack.** Hold: the overlap is supply-side scheduling and chasing late orders, in your words: "I schedule deliveries for our three depots and I chase suppliers when orders slip." Answer slot: if you have worked with production planning, the warehouse or QA in any way, say how; if you have not, say so plainly and say what you would learn first. Concede only the SAP point, from F7. | F2 is the largest gap. It is the question the advert's first line invites. Hold through two follow-ups by returning to the overlap, not by adding to it. |
| B2 | "The role lists SAP or a similar ERP as a plus. What's your experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I haven't used SAP. We run our own in-house stock system." Answer slot: if you have used any other ERP, say which and what you did in it; if not, say so and say what you would do to learn it. | F7. A plain acknowledgment: you stated the absence. Do not describe the in-house system as an ERP unless you know. |
| B3 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the most complex thing you have built or fixed in Excel, in your words. If you would rate yourself, say the level you believe is true. | F6. The advert's "confident" is a self-rating; the spreadsheet is your evidence. |
| B4 | "The role reports weekly on on-time dispatch. Have you done that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you reported on delivery timing, say what you reported and how often; if you did not, say so plainly and describe how you tracked deliveries. | F5, the discovery gap. Your material does not show reporting. Do not invent it. |

### C. Pressure, weight: low

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has run production planning?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots" | Hold: restate the question, then say what you bring: four years of delivery scheduling and supplier chasing. Hold through two follow-ups. Concede only: "I haven't run production planning." Do not claim parity. | The Pressure version of F2. You are testing composure, not content. |
| C2 | "That one-third drop. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on "I rebuilt." Concede what you cannot separate, in your own words, if that is so. Answer slot: if you can say which part of the drop you can attribute to the rebuild, say it; if you cannot, say so plainly. | F4. The drop happened over a year. You cannot know it all came from the rebuild, and saying so is the honest answer. |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, C1 |
| Track supplier deliveries and chase late orders | A1, B1 |
| Keep stock records accurate | A2, C2 |
| Report weekly on on-time dispatch | B4 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000 to £44,000 | A3 |
| Hybrid, two days at Avonmouth | A5 |

## Reverse questions

Each has a "why it lands". Ask one or two; the call is short.

1. "What does a typical week look like for this role, across planning, the warehouse and QA?" Why it lands: shows you are thinking about the production side, not only the depot side.
2. "How is on-time dispatch measured and reported today?" Why it lands: ties to the weekly reporting line in the advert.
3. "Which stock system do you run, and how much of the work sits in it?" Why it lands: the ERP question, asked as curiosity rather than a gap.
4. "What would a good first three months look like?" Why it lands: a standard question that shows you are planning the job.
5. "What are the next steps and rough timing after this call?" Why it lands: closes the call cleanly and tells you when to expect the next message.

## Sources

Provided documents: the advert text; Hannah Lowther's LinkedIn message; your message to me (background, location, salary, reason for moving).

Research tier: L0 (provided documents only). The two web searches below were refused by the host, so no research ran.

| Query | Result |
|---|---|
| Quillmoor Diagnostics Avonmouth | refused |
| Quillmoor Diagnostics values | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet. Not produced; the search was refused. |
| 2. Interview process / loop | unavailable | Loop structure. Not run; the search was refused. Persona weights follow the recruiter-screen prior. |
| 3. Strategy / recent news | skipped | Not needed for a recruiter screen. The advert and message fix the agenda. |
| 4. Interviewer name and company | n/a | No interviewer profile; the recruiter's name alone is not a research target. |
| 5. Representative JD | skipped | The advert is supplied, and it fixes the fit snapshot. |

## Upgrade menu

- Your notice period → the notice question (A4) gets your own figure in your words, rather than an instruction.
- Search permission, then research at L1 → company values and the loop structure for Quillmoor, which would sharpen the reverse questions.
- The name of the hiring manager, if you learn it → a later-round pack.
