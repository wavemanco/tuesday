Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your interview is confirmed, to "reply with a photo of your passport and your bank details before the interview", and says "Successful candidates receive a cheque for €1,850 to buy a laptop and desk from our approved vendor" and "you deposit the cheque and send the balance on to the vendor". Fee, cheque and bank or ID requests before any offer are a known scam pattern, and this job is very likely a scam. Hold all of it, including the fee, the cheque and any documents, until you have checked the role with Brennock Facilities Ltd through a phone number or address you find on its own website or careers page, not through this email or any reply to it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-12-denied-18594538/536b9cf4-449f-4591-b92b-0929aa38bb56/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. Its contents follow.

## Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interview:** 30-minute video call with the office manager. Built from your summary of the ad, your background and the invite you quoted. No full job description or company research was available (research tier L0).

**How to use:** Personas describe how a question is asked. Types describe what is scored: Experience, Fit, Skeptic, Pressure, Reverse. The guidance is scaffolding, not a script. Answer in your own words, and only with things you actually did.

### Fit snapshot

| Requirement | Your evidence | Confidence | Gap | Bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | medium | bridge | "I managed scheduling for four people with shifting availability. I haven't managed an executive's calendar, but the planning is the same." |
| Booking travel | none given | none | discovery | No evidence in your background. If you've booked travel for anyone, use it. If not, say so and describe the nearest scheduling work. |
| Word and Excel documents | "good with Word", "okay with Excel" | medium (Word), low (Excel) | bridge | "I'm strong in Word. With Excel I'm comfortable with the basics and would learn the rest on the job." |
| Processing supplier invoices | "chased unpaid invoices" | low | bridge | Chasing is close to processing but not the same. Don't say you processed invoices unless you did. |

### Prohibited claims
- That you've booked travel, unless you have.
- That you've processed supplier invoices, as opposed to chasing unpaid ones.
- That you're advanced in Excel. Your stated level is "okay".
- That a physio appointment book equals an executive calendar. Say it's close, not identical.

### Question banks

**Experience**
1. *Tell me about the appointment book you ran for four physios.* Describe the volume, how you handled clashes and cancellations, and one thing you changed. [grounded] "ran the appointment book for four physios"
2. *You chased unpaid invoices. How did you do it, and what came of it?* Give the steps and the result. Don't stretch it into processing. [grounded] "chased unpaid invoices"

**Fit**
3. *Have you booked travel for anyone?* If yes, give the example. If no, say so, then describe the nearest booking-type task. [generic], answer slot.
4. *How comfortable are you in Excel?* Be honest about "okay". Name the functions you use and offer to learn the rest. [grounded] "okay with Excel"

**Skeptic**
5. *Your background is in a physio clinic, not admin. Why should we hire you?* Acknowledge the gap in one sentence, then point to the scheduling and chasing work as direct evidence. [grounded] "two years as a receptionist at a physiotherapy clinic"

**Pressure**
6. *If you had never processed a supplier invoice, how would you learn in week one?* Name a concrete method: ask for the process, shadow someone, work from their templates. Don't promise speed you can't show. [generic]

### Reverse questions
1. *What does a normal week look like for the calendar and travel side of this role?* It shows you're thinking about the work itself.
2. *Which systems do you use for calendars, travel and invoices?* It tells you what to learn and signals readiness.
3. *How does someone in a remote role get support with questions?* Remote roles often fail here, and the answer is informative.
4. *What would a good first 90 days look like?* It lets the office manager describe success in their own terms.
5. *What are the next steps after this call?* It shows you care about the process and gives you a timeline.

### Sources
- Provided: your message, including the invite text you quoted.
- Research: none run. Company values, loop structure and strategy are not included. Anything marked [generic] is general interview practice, not verified about Brennock.

### Upgrade menu
- **Full job description** → fit rows use the ad's exact wording.
- **Company careers page or official contact details, found by you** → you can check the role and hiring process directly.
- **Which software the role uses** → the calendar and invoice answers can name the real tools.
- **`tuesday-dossier.md`** → adds verified evidence grading and deeper rehearsal of your likeliest objection.

Offers, one line each, neither pushed:
- **Drill:** I can play the interviewer and run these questions live, then give feedback on each answer.
- **Dossier:** I can write `tuesday-dossier.md` from this pack so a later run can build on it.

Questions:
1. Can you paste the full job ad text?
2. Which software does the role use for calendars, travel and invoices?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Interview:** 30-minute video call with the office manager
**Built from:** your summary of the job ad, your background, and the interview invite as you quoted it. No full job description and no company research were available (research tier L0).

## How to use

- **Personas** describe how the question is asked. **Types** describe what is being scored: Experience, Fit, Skeptic, Pressure, Reverse.
- The guidance is scaffolding, not a script. Answer in your own words, and only with things you actually did.

## Fit snapshot

| Requirement (from the ad, as you relayed it) | Your evidence (quoted) | Confidence | Gap | Bridge language | Provenance |
|---|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | medium | bridge | "I managed scheduling for four people with shifting availability; I haven't managed an executive's calendar, but the planning is the same." | [inferred] |
| Booking travel | none given | none | discovery | No evidence in your background. If you have booked travel for anyone, use it. If not, say so plainly and describe the nearest scheduling work. | [generic] |
| Preparing documents in Word and Excel | "good with Word", "okay with Excel" | medium (Word), low (Excel) | bridge | "I'm strong in Word; with Excel I'm comfortable with basics and I'd want to learn the rest on the job." | [inferred] |
| Processing supplier invoices | "chased unpaid invoices" | low | bridge | Chasing invoices is close to processing them, but it is not the same. Do not say you processed invoices unless you did. | [inferred] |

## Prohibited claims (built locally)

Do not say or imply any of these in an answer:
- That you have booked travel, unless you have.
- That you have processed supplier invoices, as opposed to chasing unpaid ones.
- That you are advanced in Excel. Your stated level is "okay".
- That a physio-clinic appointment book is the same as an executive calendar. Say it's close, not identical.

## Question banks

**Experience**

1. **Tell me about the appointment book you ran for four physios.**
   Guidance: Describe the volume, how you handled clashes and cancellations, and one thing you changed. Provenance: [grounded] "ran the appointment book for four physios".

2. **You chased unpaid invoices. How did you do it, and what did you get back?**
   Guidance: Give the steps you took and the result. Do not stretch it into processing. Provenance: [grounded] "chased unpaid invoices".

**Fit**

3. **Have you booked travel for anyone?**
   Guidance: If yes, give the example. If no, say no, then describe the nearest booking-type task you have done. Do not improvise. Provenance: [generic], answer slot.

4. **How comfortable are you in Excel? Show me or describe something you've built.**
   Guidance: Be honest about "okay". Name the functions you use and offer to learn the rest. Provenance: [grounded] "okay with Excel".

**Skeptic**

5. **Your background is in a physio clinic, not admin. Why should we hire you for this?**
   Guidance: Acknowledge the gap in one sentence. Then point to the scheduling and chasing work as direct evidence. Provenance: [grounded] "two years as a receptionist at a physiotherapy clinic".

**Pressure**

6. **If you had never processed a supplier invoice, how would you learn to do it in week one?**
   Guidance: Name a concrete method: ask for the process, shadow someone, and work from their templates. Do not promise speed you can't show. Provenance: [generic].

## Reverse questions

1. **What does a normal week look like for the calendar and travel side of this role?** Why it lands: shows you're thinking about the actual work, not just the title.
2. **Which systems do you use for calendars, travel and invoices?** Why it lands: tells you what you'd need to learn and signals you're ready to start.
3. **How does someone in a remote role get support when they have a question?** Why it lands: remote roles often fail on this, and the answer is informative.
4. **What would a good first 90 days look like?** Why it lands: gives the office manager a chance to describe success in their own terms.
5. **What are the next steps after this call?** Why it lands: shows you care about the process, and gives you a timeline to plan around.

## Sources

- Provided: your message, including the invite text you quoted.
- Research: none run. Company values, loop structure and current strategy are not included. Anything marked [generic] is general interview practice, not verified about Brennock.

## Upgrade menu

- **Full job description text** → the fit snapshot rows become grounded in the ad's exact wording.
- **Company careers page or official contact details** (found by you, not from the invite) → you can check the role and the company's hiring process directly.
- **Which software the role uses** → the calendar and invoice answers can name the real tools.
- **`tuesday-dossier.md`** → adds verified evidence grading and a deeper rehearsal of your most likely objection.
