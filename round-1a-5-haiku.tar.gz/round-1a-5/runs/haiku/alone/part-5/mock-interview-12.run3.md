Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says "a cheque for €1,850" arrives for you to "deposit the cheque and send the balance on to the vendor". Requests like these, a fee to hold a slot, a cheque to deposit and money to pass on, and ID or bank details before any offer, are a known scam pattern, and this job is very likely a scam. Hold all of it, including the fee, the cheque, and sending any documents or bank details, until you've checked the invite with the employer through contact details you find on its own website or careers page, not through the invite's email or number. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-5/rooms/case-12-denied-12ec408a/Brennock_Remote-Administrative-Assistant_interview_pack.md. I built it for a 30-minute video call with the office manager. Your note doesn't say whether that person is your direct manager, so the persona weights currently use a hiring-manager prior.

The pack's highest-ROI prep is A4, the invoice question: "Your background is chasing unpaid invoices. Processing supplier invoices is a different job. What would you need to learn?" Say the word and I'll play the Skeptic on it.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to, or someone else on the team? The answer reweights the persona table.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_Remote-Administrative-Assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Relationship: not yet confirmed; persona weights use a hiring-manager prior until it is.
Format: 30-minute video call.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **JD** = can you do the listed duties, gaps included. **EXP** = what you actually did in your past work. **CASE** = a live problem from the role. **VAL** and **CO** do not appear here: no values round was described and no company research was run.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are the duties as you described them from the ad, and the title. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad) | "ran the appointment book for four physios" - your message | medium | [grounded] | transferability | For two years I ran the appointment book for four physios. Answer slot: if you handled any calendar beyond the appointment book, say how; if not, say so and stay with the book. |
| F2 | "booking travel" (the ad) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for someone, say what and how; if you haven't, say so plainly and say how you would learn the booking tools first. |
| F3 | "preparing documents in Word and Excel" (the ad) | "good with Word" - your message; "okay with Excel" - your message | medium | [grounded] | presentation | I'm good with Word, and okay with Excel. Both are self-ratings, so do not let them grow in the room. |
| F4 | "processing supplier invoices" (the ad) | "chased unpaid invoices" - your message | low | [grounded] | transferability | I chased unpaid invoices. Answer slot: if you entered, matched or paid any supplier invoices, say which; if you only chased unpaid ones, say so and describe the steps you took. |
| F5 | "Remote Administrative Assistant" (the title) | none given | none | [grounded] | discovery | Answer slot: if you have worked remotely, say how you kept in touch; if you haven't, say so and say how you would keep the office manager informed. |

Gap-type routing: `presentation` where a quote already reaches the requirement in other terms; `transferability` where a quote is adjacent work that does not reach it; `discovery` where the material is silent.

## Prohibited claims

These are not coached, in any answer, hold or slot.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars and travel for a team | Inflated form of F1 | F1's quote at its own scope. The pack observes that your material shows one appointment book, not a team's calendars. |
| Experienced with Excel | Inflated form of F3 | "okay with Excel", at its own scope. |
| Processed supplier invoices | Inflated form of F4 | "chased unpaid invoices", at its own scope. The pack observes that your material shows chasing, not processing. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the four duties you cannot yet show | Top weight: a hiring-manager prior, plus three quoted gaps (F2, F4, F5) | Rehearse the invoice probe until it is plain. Bridge only from quoted words; name the limit. | 5 |
| Case / Strategist | Live tasks from the calendar, invoice and document work | High: the duties are tasks, so the office manager will test how you order them | Clarify, then order, then say the next step out loud | 4 |
| Data-Driven Prober | Asks how work was counted, and which Excel step you are sure of | High: your Excel is a self-rating, and your practices are quoted only once | Say what you can and cannot say about how you did things | 4 |
| Conversational | Opens with "walk me through" and casual Excel questions | Medium: the opener is scored | Pre-practise a 90-second arc from your quoted words | 3 |
| Pressure | Compares you with someone who already books travel | Lower: a short, timed challenge | Hold on what you can show, concede travel plainly | 2 |

## Question banks

Type key as above. Provenance is the label first, then every quoted sentence the guidance rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name the weakest part in your own words. Then one concrete step you would take before day one. Answer slot: if you have used Excel for a task you can name, say which; if not, say so plainly. | Tests F3 directly. The probe invites a candid answer, which is what it scores. |
| A2 | "Tell me about a time you booked or changed travel for someone else." | EXP | [generic] "ran the appointment book for four physios" | Open prompt. Selection scaffold: pick a time you arranged or changed a trip for someone. If none comes to mind, say so plainly, then give the nearest thing your material carries, running the appointment book (F1), and how you would handle a last-minute rebooking. | F2 has no quote, so the probe comes from the duty list alone. |
| A3 | "I don't see travel or Excel reporting in your background. How would you handle that in this role?" | JD | [grounded] "good with Word"; [grounded] "okay with Excel" | Name what you have, then the bridge: "I'm good with Word, and okay with Excel." Answer slot: if you have booked travel or built an Excel report, say how; if not, say so plainly and name the first thing you would do to learn it. Hold through two follow-ups by returning to those words. | F2 and F3 meet here. The hold is only what the quotes carry. |
| A4 | "Your background is chasing unpaid invoices. Processing supplier invoices is a different job. What would you need to learn?" | JD | [grounded] "chased unpaid invoices" | **Highest-ROI prep in this pack.** Hold: "I chased unpaid invoices." Answer slot: if you entered, matched or paid any supplier invoices, say which; if you only chased unpaid ones, say so and describe the steps you took. Concede the learning gap by name, as a plan, not a past. Hold through two follow-ups; do not fold on the bridge. | F4 is where the duty and your background meet with nothing between them. "Chased" is the nearest word your material carries, so this is the probe most likely to land. |
| A5 | "Why leave a clinic front desk for this role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reason for moving, in your own words; your message does not give one, so this is an answer slot. On remote: if you have worked remotely, say how you kept in touch; if not, say so and say how you would keep the office manager informed. | F5 has no quote. The motivation probe tests consistency with the clinic history. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The office manager has two meetings at the same time and a flight to rebook. What do you do in the next ten minutes?" | CASE | [generic] | Clarify what is fixed: the times, the flight's deadline, who must attend. Then decide what moves and who you tell first. Say the order out loud. | A live scheduling problem from the calendar and travel duties. It makes no claim about your past. |
| B2 | "Month end: the office manager needs a summary of supplier invoices in Excel by Friday. What do you clarify first?" | CASE | [generic] | Clarify where the invoices live, the format, who approves, and the deadline. Then the steps. Say aloud which Excel step you are least sure of. | Covers the invoice and Excel duties together, with no past claim. |
| B3 | "You have been asked to build a monthly report template in Word that others will fill in. How do you start?" | JD | [generic] | Start from the brief and one example, fix the structure before the formatting, then test it with one real set of data. | The Word duty, asked as a task. |
| B4 | "An approver is away and an invoice is due today. What do you do?" | CASE | [generic] | Name who can approve in their absence, what you record, and what you would not do around the approval step. Where you do not know the company's process, say you would ask first. | Tests invoice judgement without inventing a process. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What did running the appointment book for four physios involve week to week?" | EXP | [grounded] "ran the appointment book for four physios" | Walk through a typical week in your own words: what changed most often, and who you checked with. Answer slot: if you can give a count of bookings or changes, say how you counted; if not, say so plainly. | F1 is the only evidence for calendar work, so the probe tests its scale. |
| C2 | "When you chased unpaid invoices, how did you decide which to chase first?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you set an order, say what it was and why; if someone else set it, say so. | F4's evidence. The question presumes a method, so the slot keeps the second branch open. |
| C3 | "How would you check that a figure in a Word report matches its Excel source?" | JD | [generic] | Describe your checks in order: trace the figure to its cell, check the totals, re-run after any edit. Name the step you would add first if unsure. | The Word and Excel duty, with no past claim. |
| C4 | "You are handed a spreadsheet of 500 supplier invoices. What do you do first?" | JD | [grounded] "okay with Excel" | Describe the steps in order: check the headers, filter, total, check against the source. Mark which steps you have used and which you would learn. | F3's self-rating is the only evidence; the answer must not exceed it. |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; [grounded] "ran the appointment book for four physios" | A 90-second arc: the clinic, the appointment book for four physios, the unpaid invoices, and what you want next. Use only these beats. | A casual opener is scored. The arc is built from your two quotes only. |
| D2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "okay with Excel" | Be exact about what you use and what you are learning. "Okay" is your word; do not upgrade it in the room. | Casual register, scored as a JD check on F3. |
| D3 | "What part of the admin work you did at the clinic did you enjoy most?" | EXP | [grounded] "ran the appointment book for four physios" | Choose one true part of that work and say why in a sentence. Do not add a story you have not told before. | An easy-looking question that tests consistency with the clinic history. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who already books travel?" | JD | [grounded] "good with Word" | Hold: name what you can show now from the duties. Then concede plainly that travel is where you have least, and how fast you would close it. Answer slot: if you have booked travel, say how; if not, concede that plainly. Do not defend travel by implication. | A pressure stem. The comparison is the interviewer's, and the hold is only what your quotes carry. |
| E2 | "You say you chased unpaid invoices. How much of what you chased was actually paid?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you know the figure, say it and what part was yours; if you don't, say you don't know and stop there. Hold, then concede: never assert a result you cannot repeat. | The question presumes an outcome your quote does not carry, so the "don't know" branch is built in. |

### Coverage

| Requirement | Question IDs |
|---|---|
| managing calendars | B1, C1, D1 |
| booking travel | A2, A3, E1 |
| preparing documents in Word and Excel | A1, A3, B3, C3, C4, D2 |
| processing supplier invoices | A4, B2, B4, C2, E2 |
| Remote working (title) | A5 |

Total: 18 questions. Highest-ROI prep: **A4**.

## Reverse questions

Each one has a reason it lands.

1. "What does a typical week look like in this role, and where does most of the time go?" Why it lands: shows whether calendar work or documents dominate, so you can say which part you would start on.
2. "Which tools do you use for calendars, travel bookings and invoices?" Why it lands: lets you say which tools you know and which you would learn first.
3. "How are supplier invoices approved once they are processed?" Why it lands: shows you understand the approval chain you would sit inside.
4. "Is the role fully remote, and how would you and the office manager keep in touch day to day?" Why it lands: sets the working pattern, and it tests F5 from the other side.
5. "What would a good first three months look like?" Why it lands: shows what success means to them and gives you the target to plan for.
6. "What happens after this call, and how is an offer usually made?" Why it lands: tells you the normal next steps so you can plan your week around them.

## Sources

- Provided documents: the invite text you pasted; your message (your background, and your Word and Excel notes); the duties as you described them from the ad.
- Research tier: L0 — provided documents only; no search or fetch was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | L0 run, so no search was sent. Would have moved the values cheat sheet, which no values round calls for here. |
| 2. `Brennock Facilities Ltd interview process` | unavailable | L0 run. Would have confirmed the loop; the pack assumes a single 30-minute call as you described it. |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | L0 run. Would have grounded a company brief; the pack does not depend on one. |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your summary of the duties fixes the fit snapshot and the question banks. |

Dossier: none consumed.

## Upgrade menu

- The full ad text → the five fit rows move from your summary to quoted requirements, and the coverage line is checked against the whole list
- Your CV → more evidence quotes for F1 to F4, and a check on the Word and Excel self-ratings
- The office manager's name → persona weights from their public footprint, and a tailored reverse question
- Your reason for leaving the clinic, in your own words → A5 becomes a story-mapped answer instead of an answer slot
- A `tuesday-dossier.md` → verified evidence and prohibited claims bind every guidance cell
