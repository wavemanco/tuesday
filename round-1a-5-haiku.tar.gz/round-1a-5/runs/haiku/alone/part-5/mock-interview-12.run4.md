Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also says successful candidates get "a cheque for €1,850" and that "you deposit the cheque and send the balance on to the vendor." Requests like these, a fee before an interview, a cheque to deposit with money sent back, and ID and bank details before any offer, are a known scam pattern, and this job is very likely a scam. Hold all of them. Send no money, no cheque deposit, and no passport or bank details until you have checked the invite with Brennock Facilities Ltd, using a phone number or address from its own website or careers page rather than anything in the invite or its email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-12-denied-5f19c255/bd50d83f-17f6-4cfc-bf5a-ccc4f8c91b38/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. I built it for a 30-minute call with the office manager. It rests only on your message, with no research run, so the company and the interview format are unchecked.

The pack's highest-ROI prep is A3: "The ad asks for processing supplier invoices. What have you done on that, beyond chasing unpaid ones?" Your material shows chasing unpaid invoices, not processing them, so that gap is where the interview is most likely to press. Rehearse saying what you did, and conceding plainly what you did not.

Say the word and I'll play the Skeptic on A3 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager your future manager, or someone you'd work alongside? The answer changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** office manager (name not given). **Format:** 30-minute video call. **Relationship:** assumed to be a manager-level admin role; see the upgrade menu.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: speak it in your own words, and only about work you actually did.

Type key (types used in this pack):

- **JD**: the job's stated duties and qualifications
- **EXP**: your own experience, and whether it holds up under questions
- **CASE**: a live problem from the role, answered out loud

## Fit snapshot

Requirements are the duties from your message (the ad, as you summarised it). Evidence is your own words, quoted. Nothing here is a claim about your past beyond those quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Bridge: "I ran the appointment book for four physios." Your material shows appointments, not executive calendars, so keep the bridge at appointments. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what, for whom and how; if you have not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word" (your message) | "I'm good with Word" (your message) | low | [grounded] | presentation | Bridge: "I'm good with Word." It is a self-description; your material shows no document you produced. |
| F4 | "preparing documents in ... Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | presentation | Bridge: "I'm okay with Excel." Your material does not show what Excel work you have done, so expect a probe. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Bridge: "I chased unpaid invoices." Answer slot: if you processed an invoice from receipt to payment, say what that involved; if your part was chasing payment, say that. |
| F6 | "Remote Administrative Assistant" (your message, job title) | none given | none | [grounded] | discovery | Answer slot: if you have worked remotely, say how you kept work on track; if you have not, say so plainly and say how you would organise a remote role. |

Observation for you (not words to say): your material says you ran the appointment book and chased invoices. It does not show that you processed invoices, booked travel, or worked remotely.

## Prohibited claims

Claims this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran executives' calendars | Inflated form of F1 | "I ran the appointment book for four physios." |
| Expert in Excel | Inflated form of F4 | "I'm okay with Excel." |
| Processed supplier invoices end to end | Inflated form of F5 | "I chased unpaid invoices." |

## Persona table

Weights reflect the round as you described it: a 30-minute call with an office manager for an admin role, with no interviewer profile to read. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Asks where your background falls short of the duties | Highest: the gaps are in F2, F4, F5 and F6, and a short call will test them first | Rehearse A3 until it is plain; hold what you did, concede what you have not done |
| Case / Strategist (weight 4) | Gives a live admin problem from the role | High: a 30-minute call for an admin role tends to test practical handling | Clarify first, then structure, then act; say what you would check before you act |
| Data-Driven Prober (weight 3) | Asks how you tracked and counted | Medium: follows your appointment-book and invoice work | Say what you did and did not track; never invent a method |
| Conversational (weight 3) | Opens with the journey and easy questions | Medium: common in the opening minutes, and easy to underrate | Use B1 as your 90-second arc; treat casual questions as scored |
| Pressure (weight 2) | Pushes on one claim | Lower in a short call, but a single hard push is possible | Hold your stated position through two follow-ups, then concede any real limit |

Session total: 17 questions. This is under the usual floor of about 18 because a 30-minute call cannot hold more; the banks cover every duty.

## Question banks

### A. Skeptic (weight 5, highest-ROI bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of these tasks would you be weakest at on day one?" | JD | [grounded] "okay with Excel" (your message) | Name Excel as the honest starting point, because F4 is where your material is thinnest. Then say how you would close the gap: practice, a course, or asking a colleague. Answer slot: if you have used Excel for anything specific, name it. | Open prompt on the duties; F4 is the likeliest honest answer |
| A2 | "Your background is appointments and chasing payments. Where would you be starting from scratch in this role?" | JD | [grounded] "I ran the appointment book for four physios" (your message); "chased unpaid invoices" (your message) | Name booking travel and processing invoices as the duties your material does not show (F2, F5). Answer slot: if you have booked travel or processed an invoice, say how, in your own words; if not, say so plainly and say how you would learn it. | Premised on your two quoted sentences; the second branch allows that the work never existed |
| A3 | "The ad asks for processing supplier invoices. What have you done on that, beyond chasing unpaid ones?" | JD | [grounded] "chased unpaid invoices" (your message) | **Highest-ROI rehearsal.** Say what you did: chased unpaid invoices. Answer slot: if you processed an invoice from receipt to payment, say what that involved; if your part was chasing payment, say that and stop there. Hold through two follow-ups by returning to what you chased, not by adding steps. Concede plainly if you never processed one. | F5 is the widest gap between the duty and your evidence, so this probe is the most likely one |
| A4 | "Have you ever worked remotely? How did you keep your own work on track?" | EXP | [grounded] "Remote Administrative Assistant" (your message, job title) | Selection scaffold: pick a time you worked away from the office, or a way you organised your own work; if no such time comes to mind, say so plainly, then say how you would organise a remote role. | F6 is a discovery gap; an open prompt lets you choose what to show |
| A5 | "Why do you want to move from the clinic into an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Give the reason in your own words. Your material shows the clinic work, not the reason for this role, so the reason is yours to say. | Motivation is a common skeptic probe; the answer must be yours |

### B. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through the journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message); "I ran the appointment book for four physios" (your message) | 90-second arc: two years as a receptionist at a physiotherapy clinic; ran the appointment book for four physios; chased unpaid invoices; then why you are here, in your own words. | F1 and F5 are the path; this arc uses only those quotes |
| B2 | "What are you actually playing with in Word and Excel these days?" | JD | [grounded] "I'm good with Word" (your message); "okay with Excel" (your message) | Name one thing you do in Word, in your own words. Say that Excel is the part you are still building. Answer slot: if you built something in Excel that others used, say what; if you did not, say so plainly. | Casual question on a JD duty, still scored (F3, F4) |
| B3 | "Any questions for me?" | JD | [generic] | Never answer "no". Use reverse questions R1 to R4. | Rapport interviewers weight this slot heavily |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about the appointment book: what did you own in it, and what did the physios own?" | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Say what you ran, in your own words. Answer slot: if you set the rules for moving bookings, say what they were; if the physios set their own times, say so. | F1 defines what "ran" covers; a prober checks that scope |
| C2 | "When you chased unpaid invoices, how did you keep track of which were still open?" | EXP | [grounded] "chased unpaid invoices" (your message) | Answer slot: if you kept a list, a log or a system, say what it was; if you chased from memory or someone else's list, say so plainly. Never name a tool or method you did not use. | F5 scope; a prober asks for the method, which the quote does not carry |
| C3 | "Which Excel function would you reach for first to total supplier invoices by month?" | JD | [generic] | If you know the function, name it. If you do not, say so and say how you would find it: the function's help page, or a colleague. Do not bluff a function name. | Tests the F4 gap at the level of a specific tool |

### D. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A director has two meetings booked at the same time, and travel for one is booked for the morning. What do you do first?" | CASE | [generic] | Clarify: which meeting matters more, what can move, and what the travel commits to. Then structure your options, and act on the one the director would choose. Say what you would check before changing anything. | Live calendar and travel problem; a case question makes no claim about your past |
| D2 | "A supplier invoice does not match its purchase order. Walk me through what you would do." | CASE | [generic] | Check the amount against the order and the delivery, then decide who to ask. Name the step where you would stop and escalate. | Live invoice problem; tests F5 without asking about your past |
| D3 | "You are working remotely, and at 4pm your manager asks for a document by 5pm. What do you do?" | CASE | [generic] | Clarify the format and what the document must contain. Say what you can deliver by 5pm, and tell your manager that now, rather than committing to what you cannot reach. | Tests F6 and F3 in a realistic moment |
| D4 | "Show me how you would book a train for a director next Tuesday, in your own words." | CASE | [generic] | Name the steps: check the director's preferences, the time window, the booking tool, confirm, and record the booking. If you have not used a booking tool, say so plainly and say what you would check first. | Tests F2 through a task rather than a claim |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who uses Excel every day?" | JD | [grounded] "okay with Excel" (your message) | Hold the position you stated: you are okay with Excel, and you bring the appointment book and invoice work. Concede plainly that Excel is where you would need to move fastest. Do not claim Excel strength you have not shown. | Hold-then-concede on F4; the comparison is to a rival, not a claim about you |
| E2 | "That's a short list of admin work. How much of the appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Hold: say what you ran and who else had a say. Concede any shared control plainly. Do not expand "ran" into "owned" or "set". | F1 scope under pushback |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| managing calendars | B1, C1, D1 |
| booking travel | A2, D4 |
| preparing documents in Word | B2, D3 |
| preparing documents in Excel | A1, B2, C3, E1 |
| processing supplier invoices | A2, A3, C2, D2 |
| Remote Administrative Assistant | A4, D3 |

## Reverse questions

Each one has a reason it lands.

- **R1.** "What does a typical week look like in this role?" Why it lands: shows you are planning around the real work.
- **R2.** "Which calendar and travel decisions would be mine to make, and which would be yours?" Why it lands: shows you think about ownership before you start.
- **R3.** "What tools do you use day to day for calendars, travel and invoices?" Why it lands: you learn the tools before the probe comes.
- **R4.** "How does the team stay in touch when someone is working remotely?" Why it lands: connects the remote side of the role to how the team works.
- **R5.** "Would there be a further stage after this call?" Why it lands: tells you how to prepare for what comes next.

## Sources

- **Provided documents:** your message (the job ad as you summarised it; your background; the interview format; the invite's own sentences, quoted in the opening paragraph).
- **Research:** none run. No search or fetch was sent, because research was not consented to.

**Research tier:** L0, no search or fetch run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet (not built: no values-style round was detected) |
| 2. `{company} interview process {role family}` | unavailable | Loop structure and persona weights, which here rest on the round as you described it |
| 3. `{company} strategy` / recent news | unavailable | A grounding brief, so you sound current rather than archival |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form |
| 5. representative `{role title}` JD | unavailable | A fuller set of requirement rows; the duties here are from your summary |

## Upgrade menu

- The full job ad text → the four duties become quoted `[grounded]` requirements, and the coverage table tightens
- Your CV → rows marked "your message" move to CV evidence, with higher confidence where it supports them
- The office manager's name → an interviewer read and persona weights for that person
- Permission to research the company's own site and the interview format → loop structure, and a grounding brief
- A `tuesday-dossier.md` → verified evidence for the fit rows and a sharper bank on the invoice gap
