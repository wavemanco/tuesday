Before the prep, one thing in the invite: it says the hiring process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat is a known scam pattern, and a chat on its own doesn't show who you're dealing with or that the message really comes from the company it names. You applied through Lumenvale's careers page, so that's the place to check. Until you've checked, send no money, documents or bank details through this chat. Confirm the invite with Lumenvale using contact details from its own website or careers page, not the Telegram account, number or email the invite gives you. If you'd like the invite itself weighed, job-underwriter can check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-10-denied-63c88868/94ea54db-4d22-4b0b-865a-19646f0fddc5/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. I built it for a text-chat round with the support team lead, using the ad as you summarised it. Research didn't run because web search was refused in this session, so the company-specific content is thin.

The pack's highest-value prep is B3, "Tell me about an escalation you handled that you could not close yourself." The ad asks for escalation confidence and your background doesn't show it, so that's the likeliest probe. Say the word and I'll play the Skeptic on B3 with you.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
1. Can you paste the full job ad text, or the careers page link? The requirement quotes are currently your summary, so the ad would make them firmer, and it may add location or right-to-work terms.
2. Are you based in a country the role is tied to, and does the ad say where the employer is based?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Role: Customer Support Specialist, remote. Company: Lumenvale Software. Interviewer: support team lead (name not given). Round: text-chat interview on Telegram, per the invite. Built on the job ad as you summarised it, not the full ad text. No research ran (see Sources), so the company-specific content is limited.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **CASE**: a live problem from the role. Scores structure.
- **EXP**: a question about your past work. Scores whether your claims hold up.
- **JD**: a requirement from the ad. Scores whether you can do the listed job, gaps included.
- **CO**: company knowledge. None in this pack, because research did not run.
- **VAL**: company values. None in this pack, because no values-style round was detected.

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are quoted from your message, not the ad itself. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your words already reach the requirement in other terms: "For three years I was a customer service advisor at an energy supplier." Expect a probe on whether that counts as customer support. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, and the quote already says it: "I use Freshdesk every day." No Zendesk experience is stated, so none is claimed. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is not clarity, and the bridge should not stretch it. Answer slot: if any of your written replies were checked, praised or sent back to you, say what they were; if none were, say so, and say how you write a reply that has to be clear. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you handled an escalation you could not close yourself, say what it was and what you did; if you have not, say so plainly and say how you would approach one. |
| F5 | Not in the ad as you summarised it; a likely probe (your message) | "I've never worked for a software company" (your message) | high | [grounded] | transferability | Plain acknowledgment: "I've never worked for a software company." Adjacent work is F1 and F2 at their own scope; do not stretch them into software experience. |
| F6 | Not in the ad as you summarised it; a stated strength (your message) | "trained four new starters on our refunds process" (your message) | medium | [grounded] | none | A strength the ad does not ask for. Use it as training, not as escalation experience. |

## Prohibited claims

Built locally from the fit snapshot, since no dossier was present. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a support team | Inflated form of F6 | "I trained four new starters on our refunds process." Your material says trained, not that you led anyone. No slot. |
| Experienced with Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk only. |
| Resolved 60 tickets a day | Inflated form of F3 | "answering around 60 calls and emails a day." Your material says answering, not resolving. |

## Persona weights

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Highest | Live escalation and written-reply problems from the role | High: the team lead is the hiring manager, and text chat suits scenarios | Clarify, then structure, then say what you would do next, in that order |
| Skeptic | High | Probes the software-company gap and the escalations gap | High: F4 and F5 are the gaps the ad and your background leave open | Rehearse the one predictable objection until it is calm; plain acknowledgment where you have one; a ramp plan |
| Data-Driven Prober | Medium | Asks how the volume figure was counted | Medium: one headline number, F3 | Say "around" and "an estimate" where true; name the weakest assumption before they do |
| Conversational | Lower | Opens with the biography, or a casual question about the ad | Medium: text chats often open casually, and casual questions are still scored | Pre-script a 90-second arc |

## Question banks

Question count: 10, below the usual range. The pack is short because the ad was summarised and research did not run. The upgrade menu says what would add more.

### Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry that a refund you promised has not arrived. What do you do first?" | CASE | [generic] | Steps, not a script: check the account and refund status, confirm what was promised, tell the customer what happens next and when, and escalate with the case written up if it is stuck. | A live problem from the refunds work the escalations line points at. It presupposes nothing about your past, so the guidance makes no claim about you. |
| A2 | "A problem needs an engineer, not you. Walk me through the escalation." | JD | [grounded] "confidence handling escalations" | Say what you would gather before handing off, who receives it, and what the customer hears while they wait. Answer slot: if you have escalated a ticket before, say what you included and what happened next; if you have not, say so plainly and describe what you would include. | Scores F4. Asked as a decision, so the guidance does not assume you have done it. |
| A3 | "Write me three lines to a customer who was charged twice." | JD | [generic] | Acknowledge the problem in the first line, say what you are doing about it, and give a time. No jargon. | Tests the written communication requirement (F3) in the medium this interview uses, a text chat. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have worked in customer service for an energy supplier. Why would support for a software product be different?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; [grounded] "I've never worked for a software company" | "For three years I was a customer service advisor at an energy supplier." Then the difference, as a plan: the product, its help documentation and its first tickets are what you would learn first. If asked directly about software: "I've never worked for a software company." | F1 and F5 carry this. The guidance claims nothing about how well you know the product. |
| B2 | "Have you worked with Zendesk?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day." If you have not used Zendesk, say that plainly, then describe how you would learn its ticket workflow. | F2. The question is about a tool, so it presupposes nothing about your past. |
| B3 | "Tell me about an escalation you handled that you could not close yourself." | JD | [grounded] "confidence handling escalations" | **Highest-ROI prep in this pack.** This is the most likely probe on your fit: the ad asks for it and your material does not show it. Answer slot: if you handled one, say what it was, what you did and where it went; if you have not, say so plainly, then say how you would approach one. Hold through a follow-up by returning to what you would do, not by adding to what you did. | F4 is the gap, and the honest answer is ready before the probe arrives. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 60 calls and emails a day counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Use your own words, "around 60 calls and emails a day." Weakest assumption: it is an estimate, not a count, unless you tracked it. Answer slot: if you tracked it, say how; if not, say it is an estimate. | The headline volume figure, F3. |
| C2 | "How did you know the four new starters had got the refunds process right?" | EXP | [grounded] "trained four new starters on our refunds process" | Answer slot: if you checked their work, say how and what you looked at; if you did not, say so plainly and describe how you would check. | F6. This probes what "trained" meant. |

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through how you got into support." | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; [grounded] "I use Freshdesk every day" | A 90-second arc: the role, the daily tool, the training you did, and why support here. | An opener is likely in a chat, and it is scored. |
| D2 | "Pick one thing from the ad you would most want to be good at. Why?" | JD | [generic] | Pick one requirement from the ad, and give a reason that is true for you. No claim about your past. | Casual, but scored against the requirements. |

## Reverse questions

Each one has a reason it lands. None asks for contact details, and none checks the invite.

1. "What does a new support specialist handle in their first month, and what do they hand off?" Why it lands: it shows you are planning your ramp, which answers the Skeptic.
2. "How are escalations routed between support and product or engineering?" Why it lands: it lets you show the escalation thinking from A2.
3. "Which ticketing tool does the team use, and how long has it been in place?" Why it lands: it ties your Freshdesk work to their tool.
4. "Does the process include a call or video interview before any offer?" Why it lands: it tells you what format to prepare for.
5. "What would make someone clearly good at this role after three months?" Why it lands: it ends on what success looks like.

## Sources

Provided documents: your message, which holds the Telegram invite as quoted, your summary of the job ad, and your background.

Searches sent, all refused:

- "Lumenvale Software careers customer support specialist": refused, search permission not granted in this session.
- "Lumenvale Software company values": refused, search permission not granted in this session.
- "reports of recruitment scams that use this company's name": refused, search permission not granted in this session.

Research tier: L1, searches 0 of 6 (3 sent, all refused), fetches 0 of 2.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have set the values cheat sheet, if a values-style round is detected. No values were read. |
| 2. Lumenvale interview process, customer support | unavailable | Would have set the loop structure and persona weights. Weights here are from the round type you described. |
| 3. Lumenvale strategy and recent news | unavailable | Would have added CO questions. None are in this pack. |
| 4. Interviewer name | n/a | No name was given. |
| 5. Representative Customer Support Specialist JD | unavailable | Would have turned the requirement quotes into [grounded] lines from a full ad. |

## Upgrade menu

- The full job ad text, or a link to the careers page you applied through → the requirement quotes come from the ad itself, and any location or right-to-work terms become rows in the fit snapshot.
- The support team lead's name → a tailored reverse question, and persona weights read from their public footprint.
- Search permission for research → values, interview process and any scam reports about the company. The values cheat sheet appears only if a values-style round is detected.
- Your location, and whether the role is tied to one country → a gate row in the fit snapshot, if the ad sets one.
- `tuesday-dossier.md` → verified evidence and prohibited claims from a dossier, sharpening the pack without gating it.
