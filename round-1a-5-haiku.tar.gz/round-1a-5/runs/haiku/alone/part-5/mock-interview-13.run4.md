Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-5-rooms-case-13-denied-97763e02/b7e53f7d-ff05-4c9a-b8dc-5061ed8e4dd6/scratchpad/quillmoor_operations-coordinator_interview_pack.md. I built it for the recruiter screen, since Hannah's message set the round and agenda.

The pack covers the four things she named (pay, notice, hybrid, reason for moving), with your own sentences quoted as the basis for each answer. The biggest gap is production scheduling across planning, the warehouse and QA. Your material only shows delivery scheduling, so that question (B2) is the one to rehearse hardest. The no-SAP answer is short and plain: "I haven't used SAP." For the Reading point, the pack keeps to your own words: the office is closing, the only offer is Reading, and you don't want that.

I didn't run any web research. A screen like this is driven by her message and your notes, so I left out Quillmoor's values and recent news. Say if you want those checked.

Notice period is the one figure I can't supply. Please give me your actual notice period, in weeks or months, so the pack can use your real answer rather than a guess.

Would you like me to play the Skeptic on B2 as a live drill? I can also save a tuesday-dossier.md recording the gaps this prep exposed, or convert the pack to Word if you'd like that.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Round:** 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**Her agenda (her words):** salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move, then the team and next steps.
**Built for:** Sam. First build; no regeneration.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **EXP**: did you do what you say you did? Tested by follow-up.
- **JD**: can you do the listed job, including its gaps?
- **VAL**: values fit. Not used here: no values round.
- **CO**: company knowledge. Not used here: no research was run.
- **CASE**: a live problem. Not used here.

The guidance is scaffolding, not a script. Where it quotes you, those are your own sentences; say them in your own words, close to these.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap on years. Say it as your own sentence. "Production" is not reached by this quote; that sits in F6. |
| F2 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | transferability | Your material shows a spreadsheet rebuild, not which Excel features you used. Words: "I rebuilt our stock-count spreadsheet." Answer slot: if you can name the Excel features you used, name them; if you can't, say so plainly. |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | presentation | Your sentence already reaches stock accuracy. Say it at its own scope: discrepancies fell by about a third over a year. No claim of sole cause (see prohibited list). |
| F4 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | Your sentence reaches both halves: deliveries, and chasing suppliers when orders slip. Say it in those words. |
| F5 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | Words: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as a past. |
| F6 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [grounded] | discovery | Your material shows delivery scheduling; it doesn't show whether that reaches production schedules or planning/QA. Answer slot: if you have scheduled against production, planning or QA, say what and how; if not, say so plainly, and say what you'd need to learn about how those three hand off to each other. |
| F7 | "weekly report on on-time dispatch" — advert | none given | none | [grounded] | discovery | Answer slot: if you have reported on delivery timing, say what you reported and to whom; if not, say so plainly and say what you would track first. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap. Say it in those words. |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised range; that is an observation for you, not a line to say. Give your figure in your own words. |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Answer slot: say your actual notice period as a number of weeks or months. It isn't in your brief, so the pack doesn't supply it. |
| F11 | "what's prompting a move" — Hannah's message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | high | [grounded] | none | No gap. Say it as written. |

Requirements the advert names without a row: none. "Confident with Excel" is covered by F2 and F3 only through the spreadsheet; the advert's other Excel needs have no row.

## Prohibited claims

Built locally from the fit snapshot: the claims a candidate reaches for under pressure. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran production scheduling across planning, the warehouse and QA" | Inflated form of F6 | F4's quote at its own scope. The material says delivery scheduling across three depots, not production scheduling. |
| "The rebuild alone cut discrepancies by a third" | Inflated form of F3 | F3's quote at its own scope: discrepancies fell by about a third over a year. The material doesn't show what else changed in that year. |
| "I have used SAP" or any ERP use | Negative you stated (F5) | "I haven't used SAP." |
| Your current salary, or any estimate of it | No figure given | If asked what you earn now: "I'd rather focus on the range for this role." |

## Persona table

Relationship prior for a recruiter screen: Conversational with a light Skeptic. Weights follow the prior, and the reasoning is shown so you can recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Conversational / Rapport | Friendly openers, logistics asked casually | High. This is the screen's register, and the four logistics points are scored even when they sound casual. | A 60–90 second background arc; answer the logistics plainly and stop. | 5 (A) |
| Skeptic (light) | "No SAP", "no production planning" | High. The advert's gaps sit exactly where a screen checks for knockouts. | Rehearse B2 until it is boring; give the plain acknowledgment for SAP. | 3 (B) |
| Data-Driven Prober | "How was the third counted?" | Medium. The discrepancy figure is the only headline number on your material. | Name the assumption you'd defend least, and say plainly when you don't know. | 3 (C) |
| Pressure | "Why should we consider you?" | Low. A 30-minute screen seldom presses hard. | Pause, restate, hold through two follow-ups, concede the SAP gap plainly. | 2 (D) |

Question weights: Conversational 5, Skeptic 3, Prober 3, Pressure 2. The pack has 13 questions, below the usual 18-question floor. That is deliberate: a 30-minute screen can't carry more, and the logistics slots are the core.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Role, length of time, and day-to-day: the three depots, and chasing suppliers when orders slip. Stop there; add no scope. | F1 and F4 are the two sentences that carry this. Biography is scored casually in a screen. |
| A2 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it in those words. Don't add commute times or details you haven't given. | F8. Logistics slot: your limit is yours to state. |
| A3 | "What's your notice period?" | JD | [grounded] Hannah's message: "your notice period" | Answer slot: say your actual notice period as a number of weeks or months, in your own words. It isn't in your brief and the pack will not guess it. | F10. Logistics slot, a stated term of the role; no figure given, so none is supplied. |
| A4 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say it in your own words, then stop and let her respond. If you'd rather see the band first: "Could you tell me the band for this role?" | F9. Logistics slot: your figure fills it and raises no defend-the-number question. Nothing here asks why the figure, or whether you'd take less. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as written, in one breath. The closure is the fact; the Reading offer is the reason. No grievance about the company. | F11. A motivation question. It must match what you said about the hybrid pattern and the Bristol limit. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists SAP or similar as a plus. Have you used an ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We ran our own in-house stock system." Then say how you would learn it, as a plan, not as something you've done. | F5. The stated absence gets the plain acknowledgment; nothing is added to shrink it. |
| B2 | "The role coordinates production schedules across planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you have scheduled against production, planning or QA, say what and how. If not, say so plainly, then give the nearest thing your material carries (scheduling deliveries across three depots) and what you'd need to learn about how those three hand off. | F6. Highest-ROI prep in this pack: production scheduling is the centre of the advert, and the material is thinnest exactly here. |
| B3 | "The role reports weekly on on-time dispatch. Have you produced a report like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you have reported on delivery timing, say what you reported and to whom. If not, say so plainly and say what you would track first. | F7. Discovery gap. The quote is the nearest sentence, not evidence of a report. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the drop in discrepancies counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say how you counted discrepancies, in your own words. If you can't say, say so: "I don't know exactly how that count was set." Name the assumption behind the figure you'd defend least, before she does. Don't supply a method. | F3. The figure is the candidate's; how it was counted is a defend-the-number slot, not a fact the pack can give. |
| C2 | "What else changed in that year?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if other changes happened, name them. If none did, or you don't know, say so plainly. The rebuild is yours; the year's other changes are not in the material. | F3. Guards the sole-credit trap listed in the prohibited list. |
| C3 | "How do you keep the stock records accurate now?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the rebuilt sheet has specific checks, describe them. If it's mostly layout, say that. | F3. "Keep stock records accurate" is a JD line; the material reaches it only through the rebuild. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our other candidates have SAP. Why should we consider you?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." | Pause, restate the question back to yourself, then anchor in the four years. Concede the SAP gap plainly: "I haven't used SAP." Hold through two follow-ups; don't argue the ERP line. | F1 and F5. Hold-then-concede: the position is the four years, and the concession is the SAP gap. |
| D2 | "You're leaving a closing office. Why should we be the next step?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Restate the reason as you said it. Hold it. Don't add to it. | F11. Pressure on motive. The answer has to match the one you gave in A5. |

## Requirement coverage

| Requirement (advert or recruiter) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C1, C3, through the spreadsheet only. No feature question: none, and why: a screen rarely tests Excel functions. |
| ERP experience (SAP or similar) a plus | B1, D1 |
| Coordinate production schedules across planning, the warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | C3 |
| Weekly report on on-time dispatch | B3 |
| Hybrid: two days a week at Avonmouth | A2 |
| Salary (£38,000–£44,000) | A4 |
| Notice period (her agenda) | A3 |
| What's prompting a move (her agenda) | A5 |

## Reverse questions

Ask two or three of these. Each is a question for Hannah.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after this call, and who would be in the next stage?" | Sets the process and shows you're planning past this call. |
| R2 | "How is the two-day pattern set for the team: fixed days, or agreed week by week?" | Asks how the hybrid pattern works, not whether you'll fit it. |
| R3 | "What does a week look like for the coordinator across planning, the warehouse and QA?" | Tests the B2 gap from her side, and shows you took the production line seriously. |
| R4 | "Could you share the band for this role?" | Lets you hear the band before you name a figure again. |
| R5 | "Who would I report to, and how big is the team?" | Asks for the team information she said she would give. |
| R6 | "What would a good weekly dispatch report look like in the first three months?" | Makes B3 concrete and asks what success means. |

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message (her agenda and the phone-call arrangement); the advert as pasted; your notes on your background, pay, hybrid limit and reason for moving.

**Searches and fetches:** none sent. Research tier: **L0**. The default L1 would have checked Quillmoor's values and recent news. A recruiter screen's questions come from her message and your notes, so the pack doesn't depend on that research; the upgrade menu says what it would add.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | skipped | No values round is detected from a recruiter screen, so the values cheat sheet is dropped. |
| 2. Interview process, operations coordinator | skipped | Her message fixes the screen's agenda, which is what the persona weights use. |
| 3. Quillmoor strategy / recent news | skipped | Nothing in a 30-minute screen's questions depends on it. |
| 4. Hannah Lowther | skipped | Her messages are the only interviewer information. A public-footprint search would not change any answer in this pack. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot. |

**Dropped sections:** grounding brief (no L2 run), reading the interviewer (no interviewer information beyond her role), graded deliverables (none declared), values cheat sheet (no values round), delivery coaching (no assessment provided).

## Upgrade menu

- Your notice period → A3 becomes a stated figure, and the logistics slot is filled.
- Excel features you used in the stock-count rebuild → F2 moves from transferability to presentation, and C1 and C3 get specifics you can say.
- Any production, planning or QA scheduling, even in part → B2's answer slot gets a sentence to build on.
- Any weekly reporting you've done → B3's answer slot gets a sentence to build on.
- Quillmoor's published values and recent news (research at L1) → a values line and a current-news line for R1 and R5.
- Deep research (L2) → strategy brief, role-family loop reports, and recent site news. Offered once: six more searches and two fetches, roughly the same again in time.
