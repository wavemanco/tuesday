Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-7-denied-7db26ad8/e58b378d-0f33-475a-ac2d-7cbe7e5b1b6f/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round with Tobias, with the 60-minute run-of-show and research checklist you asked for added at the end.

Company research didn't run. The web searches were refused by a permission prompt, and I didn't retry them. So the pack has nothing on Saltmarsh's values, interview steps, recent strategy or Tobias's public profile. It says so, and it doesn't assume any of those facts.

The pack's main points:
- **Highest-priority prep:** "You've never led a team." Practise a plain "I've never led a team," then hold on what you did run (the two-year content calendar and the QA checklist) without adding to it.
- **Second:** the in-app purchases gap. Say "I've never worked on a game with in-app purchases," then give a plan for what you'd learn first.
- **Two-title calendar:** this is a case question, so rehearse clarifying first, then sequencing.
- **KPIs:** you presented the retention numbers. You didn't say you owned the KPIs or the post-event review, so don't claim that.

I can run a live drill with any persona, starting with the Skeptic on the team-leadership question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday's session only with Tobias, or is there a panel? If there's a panel, who else is in it and what does each person cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile studio, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations (relationship: hiring manager, from your description)
**Round:** 60 minutes, Friday. Built as a session pack; I have not been told whether it is a panel.
**Built on:** the JD and your background as you wrote them in one message. No company research was available (see Sources), so every statement about Saltmarsh is absent, not assumed.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = the job's own responsibilities and qualifications. **EXP** = what you actually did, tested for attribution. **CASE** = a live problem from the role, scored on structure. **CO** = company and strategy knowledge. **VAL** = behavior against values or principles.
- Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds, in your own words.
- Where a guidance cell says "answer slot", it means the interviewer may probe a practice your material does not show. Answer it from your own experience, or say plainly that it was not yours. Never describe a practice you did not do.

## Fit snapshot

Requirements are the JD's own words. Evidence is your own sentence, quoted exactly. Gap and bridge language is what you may say aloud.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap as worded. Expect a probe on how the calendar was run, since nothing inspectable shows it. Bridge, in your words: "For two years I ran the weekly content-drop calendar for our main title." |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title and weekly content drops. It does not show two titles or live events. Keep the quote at its own scope. Answer slot: if you have planned a calendar across more than one title, or planned events beyond content drops, say which and how you decided; if you have not, say so plainly and say how you would approach the second title. |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | The years are there. Your material does not say the studio's titles were live-service; a weekly content-drop calendar suggests it, but that is not your sentence. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: say, in your own words, whether the title ran on live updates; if it did not, say so. |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this. You have also said "Never led a team"; coordinating teams is not leading them, so do not blur the two. Answer slot: if on a content drop you coordinated design, art, engineering or community work, name the teams and what you asked of each; if you did not, say so and describe how you would run it. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Presenting numbers is not owning a review or choosing the KPIs. Bridge keeps the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the KPIs or wrote a post-event review, say which and how; if someone else set them, say so. |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Close to the requirement. "Wrote" is not "manage", so if asked whether you maintain it, answer from what you did. Bridge: "I wrote the release checklist our QA team still uses." |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Bridge rewords only that quote and adds no practice: "I presented the monthly retention numbers to the studio head." No figure is in your material, so there is no figure to defend in this pack. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote shows a written document another team relies on. It does not by itself show writing quality; a written exercise in the interview would test that. |
| F9 | Not a JD line; likely probe on a mobile live-ops role, from your own stated gap | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this absence, so the plain acknowledgment is yours to give: "I've never worked on a game with in-app purchases." Then how you would learn it, as a plan, never as a past. |

**Gate rows:** none. The JD's "3+ years" is a length-of-experience requirement, not a gate, so it is graded on fit like the rest.

**Confidence bands.** Your statements are specific and confirmed, but nothing inspectable backs them, so the ceiling is medium. A stronger artifact would raise it (see the upgrade menu).

## Persona table

Weights are a shown judgment. There is no interviewer profile and no loop source, so no interviewer read is possible and the loop uses the generic fallback: flat weights, said plainly.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight (questions) |
|---|---|---|---|---|
| Case / Strategist | Live problems on the two-title calendar, a release-day blocker, a retention dip | High. A hiring manager for a live-ops role buys the ability to plan and to decide under time pressure; the JD's first line is a planning requirement | Clarify first, state an objective, sequence, name the risk; think aloud | 5 (A1 to A5) |
| Skeptic | "You've never led a team"; "no in-app purchases" | High. The two gaps in your own message are the two most likely objections; a hiring manager derisks these | Plain acknowledgment first, hold on what your material shows, concede specifically | 4 (B1 to B4) |
| Data-Driven Prober | Asks how the retention numbers were counted and what they were sensitive to | Medium to high. Retention is a named requirement and your one quantitative line is a presentation, so a probe will go to its method | Name the definition you used, or say who set it; name the assumption you would defend least | 4 (C1 to C4) |
| Conversational | Opening biography; a casual "what do you play" | High as an opener, whatever the round. Casual questions are still scored | Pre-rehearsed 90-second arc from your quotes | 3 (E1 to E3) |
| Pressure | "How much of that was actually you?"; a sixty-second comparison | Medium. A hiring manager may test composure on the calendar claim | Pause, restate, hold through two follow-ups, concede only what is true | 2 (D1, D2) |
| Values / Behavioral | Open prompts on unpopular truths and player trade-offs | Low to medium. No published values were available, so no values round is detected; the flat weight keeps one scored behavioral pass in reach | Selection scaffold with its honest branch | 2 (F1, F2) |
| Peer Evaluator | Seams with design and community | Conditional. Applies only if Friday includes a panel member from another team | Propose seam principles; do not claim a resolved disagreement | 2 (G1, G2) |

Total: 22 questions. The top persona gets the most depth because the case block carries the role's core planning requirement.

## Question banks

### Persona A: Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Next quarter one title needs a major update and the other's retention is slipping. Walk me through how you'd plan the calendar for both." | CASE | [generic] | Clarify first: how big the update is, its date, what QA can absorb, and how the retention slip is measured. State the objective, then sequence the two titles so they do not collide on the same team. Name the first risk you would watch. Think aloud for 90 to 120 seconds, and name one premise you would want confirmed. Do not claim a past calendar for two titles. | Covers the two-title half of the calendar requirement (F2) as a live problem. CASE because the interviewer scores structure on a problem from the role. |
| A2 | "A content drop is two days from release and QA has found a blocker. What do you do?" | CASE | [generic] | Decide in order: what the blocker costs if it ships, who must approve a delay, whether a cut or a hotfix is available, and what the community team tells players. Name the release-checklist gate you would not bypass, and who you call first. | Tests managing the release checklist with QA (F6) without asking for a past event. It is a decision question, so no claim about your history is needed. |
| A3 | "Each update needs design, art, engineering and community. Who do you bring in first, and what does each need from you?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" — JD | Sequence by dependency: what art needs settled before it starts, what engineering needs as a fixed scope, what community needs to announce. Name what you would ask each team. Describe this as your approach, not as something you have done, because your material does not show it. | The raising source is the JD line. F4 has no quote, so this asks how you would do it. |
| A4 | "What does a good post-event review look like to you, and what would go in it?" | JD | [inferred] "own the post-event review and the KPIs it reports" — JD | Build the structure: what shipped, planned against actual, the KPIs before and after, what you would change, and an owner for each action. Name the metrics you would pick and why. Answer slot: if you have written or run a post-event review, say what it covered and what you chose to measure; if you have not, say so plainly and give your approach. | F5 is a thin match. The question asks for an approach, and the slot keeps a past review from being invented. |
| A5 | "Retention on one title fell about eight points after a drop. Diagnose it." | CASE | [generic] | Clarify the metric and the window. Check instrumentation and the cohort definition. Segment by new versus returning players and by platform. Separate the drop's content from seasonal or outside causes. Name the first thing you would rule out. | Tests the player-retention requirement. The figure is the interviewer's hypothetical, not a fact about the studio. |

### Persona B: Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. Why would you coordinate four functions for this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I've never led a team." Then hold through two follow-ups on what your material shows: "I ran the weekly content-drop calendar for our main title for the last two years," and "Wrote the release checklist our QA team still uses." Concede the team-leadership gap specifically, in your own words, and say how you would close it. Do not claim you led anyone on any drop. Answer slot: if on a drop you coordinated other teams' work, name the teams and what you asked of them; if you did not, say so and stay with the calendar and the checklist. | The one quoted negative that bears on the JD's coordination language. It is the objection most likely to arrive, and a plain answer here changes the interview. |
| B2 | "Our titles run in-app purchases, and you haven't worked on a game with them. What would you get wrong first?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Give the plain acknowledgment: "I've never worked on a game with in-app purchases." Then name, as a plan, what you would check first: how purchase-driven events are measured compared with retention-only events, and what you would ask the monetization team. Do not claim knowledge of how purchases behave at this studio. | The gap is one you stated, so a plain answer is safe. The question tests whether you can reason about it without pretending. |
| B3 | "You ran the calendar for your main title. What would a second title ask of you that the first didn't?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Answer from the difference, not from history. One calendar means one set of drops; two titles means two calendars drawing on the same design, art and QA capacity. Name the conflict you would plan around first. Answer slot: if you ever ran more than one calendar, say which; if you did not, say so and give your sequencing approach. | F2 is the two-title gap, and this probe is likely. |
| B4 | "You presented the retention numbers. Who set the KPIs they reported?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say who set the KPIs, in your own words. Answer slot: if you chose which KPIs went in, say which and how you decided; if someone else set them, say so and what you added, if anything. Do not claim ownership of the KPIs. | F5 is the JD's "own the KPIs" requirement, and your quote shows presenting only. |

### Persona C: Data-Driven Prober (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers were calculated." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name the retention definition you used, if you know it. If you did not set it, say who did. Name the assumption you would defend least before they ask. No figure is in your material, so do not supply one. Answer slot: if you chose the definition, say which and why; if the studio set it, say so. | Your one quantitative line is a presentation, so the probe goes to its method. |
| C2 | "What did the numbers show in your last monthly presentation, and what did you say caused it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what you showed. If a cause was established, state it at the strength you had for it; if none was, say that no cause was established. Name the evidence behind any cause you offer. Answer slot: if you proposed a cause, name the evidence for it; if none was established, say so plainly. | The next level of C1. Probers ask for the cause after the method. |
| C3 | "After a live event, which three KPIs would you track, and what would make you call it a miss?" | JD | [inferred] "own the post-event review and the KPIs it reports" — JD | Give three KPIs, each with its denominator and time window, and one threshold for a miss. Name the weakest assumption in each. Describe all of it as your approach, not as a past. | The JD's KPI ownership, asked in a way that exercises metric language without inventing a history. |
| C4 | "A drop lifted day-seven retention for a week, then it fell back. How do you tell a real lift from a calendar effect?" | CASE | [generic] | Compare against a holdout or a comparable prior drop. Check for a same-week event or a seasonal pattern. See whether the lift holds in the cohort that joined after the drop. Name what would change your mind. | The retention-metrics requirement, tested through interpretation, with no claim about past drops. |

### Persona D: Pressure (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That calendar you ran. How much of its results were actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Pause. Restate what you ran: a weekly calendar for two years. Hold that through two follow-ups. Concede where a decision was not yours, and name it specifically in your own words. Answer slot: if you set the calendar's priorities, say which; if you ran a calendar someone else set, say so plainly. | The most common follow-up to a calendar claim. The hold is one your quote carries: you ran it. |
| D2 | "Sixty seconds: why you over a candidate who has run live operations on a monetized title?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Do not argue the comparison. Give what your material carries: two years of a weekly calendar, and a release checklist QA still uses. Concede the in-app purchases gap plainly, and name the first thing you would learn in your first week. | The sharpest version of the stated gap. The pack holds only what the quotes carry. |

### Persona E: Conversational / Rapport (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | A 90-second arc with only these beats: the studio and the four years, the calendar for two years, the release checklist QA still uses, and presenting the monthly retention numbers. If you want to add a detail, check first that you did it. | A casual opener is still scored. Staying on your quotes keeps the arc truthful. |
| E2 | "What's a live-ops calendar you've admired, and what did it do well?" | JD | [generic] | Name one you have actually played or studied. Say one specific thing it did: how it paced events, or how it handled a bad drop. Do not say you ran it. | Casual in register, but it scores live-ops fluency, the role's core. |
| E3 | "How did you end up in games?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | One or two sentences: the studio, the role, the four years. Then stop. Answer in your own words; skip any part you would rather not share. | A rapport opener. The answer stays within the quote. |

### Persona F: Values / Behavioral (weight: 2)

No published values were available, so there is no values cheat sheet and no mapped values question. These are open prompts; the honest branch is built in.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to a team that did not want to hear it." | VAL | [generic] "Wrote the release checklist our QA team still uses." — your message | Pick a time a schedule, scope or checklist change was pushed back on. Name the stake, the moment you did not fold, and the outcome, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the checklist you wrote, and what you had to hold firm on, if anything. | A generic behavioral probe. The ending is the honest branch, not a story supplied for you. |
| F2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] "Presented the monthly retention numbers to the studio head." — your message | Pick a case where a player-facing change cost a metric you were tracking, and say what you traded. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented, and what you would do when a player-facing fix moved them down. | No values to map, so this stays a scaffold. The retention line is thin, and the answer should say so. |

### Persona G: Peer Evaluator (weight: 2, conditional on a panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design and community sit beside the live team. Where's the seam, and what happens when we disagree?" | JD | [inferred] "coordinate design, art, engineering and community teams on each update" — JD | Propose seam principles: who decides scope, who owns player-facing text, how a disagreement is escalated to a decision with a date. Do not claim you have resolved one. Answer slot: if you have had a disagreement with another team on a drop, say how it was settled; if not, give the principle you would use. | A peer's seam probe. Only if a panel member is from another team. |
| G2 | "How do you handle credit when a drop depends on another team's work?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Use "we" for the drop and "I" for your part: you wrote the checklist, and QA's use of it is their work. Name your part specifically. Do not claim the drop. | Credit questions are a peer's test of turf. The quote gives one credit-worthy line, and it is yours. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B3 |
| Coordinate design, art, engineering and community teams on each update | A3, G1 |
| Own the post-event review and the KPIs it reports | A4, B4, C3 |
| Manage the release checklist with QA | A2, G2 |
| 3+ years producing live-service games or apps | E1, E3 (plus the F3 gap in the snapshot) |
| Experience running a content calendar | B3, D1 |
| Comfortable with player-retention metrics | C1, C2, C4, A5 |
| Clear written communication | none, and why: no question here tests writing directly. If Friday includes a written exercise, prepare it separately; this pack does not cover one |

## Reverse questions

These are for Tobias. Ask two or three; the rest are backup.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | Shows you take the review and the KPIs seriously, and tells you how decisions actually get made. |
| R2 | "How are the two titles' calendars coordinated today, and where does that break down?" | Shows you have thought about the two-title part. The answer names the real constraint. |
| R3 | "Which of the two titles needs the most attention next quarter, and what is the retention story behind it?" | Invites him to set priorities, and shows whether the retention numbers are trusted. Use his name, not a pronoun. |
| R4 | "How do monetized events and retention work get planned together?" | Names the in-app purchases gap and asks about it instead of claiming knowledge. |
| R5 | "What would make the first ninety days in this role a clear success for you?" | A direct test of what he wants, which you can plan against. |
| R6 | "What could a new producer do in their first month that would genuinely help your team?" | Reciprocity. Use only if a panel member is a peer. |

There is no interviewer profile, so no reverse question is tied to his career path. That is a gap, listed in the upgrade menu.

## Run of show (60 minutes, added at your request)

Given 60 minutes, rehearse these first: **B1, B2, A1, C1, D1, A4**. Everything else is insurance.

| Time | Segment | Questions |
|---|---|---|
| 0 to 5 min | Introductions. Listen for which title and team come up. | none |
| 5 to 10 min | Your 90-second journey, then one follow-up | E1 |
| 10 to 30 min | Case block: clarify before you structure | A1, then A2 or A3 |
| 30 to 40 min | Challenges: hold, then concede on team leadership and in-app purchases | B1, B2 |
| 40 to 50 min | Metrics: method first, then the KPIs you would track | C1, C3, then A5 or C4 if time |
| 50 to 55 min | Pressure if the tone turns; otherwise B4 | D1 or B4 |
| 55 to 60 min | Your reverse questions, then close with next steps | R1 to R5 |

## Research checks you can run yourself (added at your request)

Nothing below is a claim about Saltmarsh. These are things to look up before Friday, so you can use what you find.

- The studio's public values or principles page, if it has one.
- Current job postings for live-operations roles there, which often describe the interview steps.
- Any recent public update, news or interview about the two mobile titles.
- Tobias's public profile, talks or posts, limited to what he has published about his own work.
- Whether the studio lists its interview process. If it does not, ask the recruiter in one email.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis. The honest form is the sentence you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events across two titles" or "I ran the live-events calendar" | Inflated form of F1 and F2 | "I ran the weekly content-drop calendar for our main title for the last two years." The pack's own limit: your material says one title and content drops. |
| "I led a team" or "I managed the people on the calendar" | Your own negative, F4 | "I've never led a team." |
| "I owned the KPIs" or "I ran the post-event review" | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." The pack's own limit: your material says presenting, not owning. |
| "I've worked on a game with in-app purchases" or "I know how in-app purchases affect retention" | Your own negative, F9 | "I've never worked on a game with in-app purchases." |
| "I improved retention" | Inflated form of F7 | "I presented the monthly retention numbers to the studio head." No movement is claimed. |
| "I set the release schedule" or "I decided what shipped" | Inflated form of F6 and F1 | "Wrote the release checklist our QA team still uses." |

## Sources

**Provided documents**
- The JD text, as pasted in your message.
- Your background, as stated in the same message.

**Searches and fetches sent**
- "Saltmarsh Games values": refused (a permission prompt was not granted; not retried).
- "Saltmarsh Games interview process live operations producer": refused.
- "Saltmarsh Games mobile studio news strategy": refused.
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.
- Fetches: none sent.

**Research tier:** L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10: omitted. No values round is detected, so Persona F uses scaffolds. |
| 2. Saltmarsh interview process | unavailable | Loop structure: unknown. Persona weights use the generic fallback, flat and said plainly. |
| 3. Saltmarsh strategy and recent news | unavailable | Grounding brief and CO questions: omitted. Your pack has no CO question; the CASE questions are generic. |
| 4. Tobias Wrenfield with Saltmarsh | unavailable | Interviewer read and an interviewer-tied reverse question: omitted. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public profile, talks or posts, pasted or allowed through search → an interviewer read, persona weights tied to his path, and a reverse question tied to his career.
- Saltmarsh's values page, pasted → a values cheat sheet, and values questions mapped to the published values; F1 and F2 become mapped stories instead of scaffolds.
- The interview steps from the careers page or the recruiter's email → the loop structure, and whether a values round sits in it.
- A recent Saltmarsh update or strategy piece, pasted → CO questions grounded in current strategy; they are generic now.
- The figure from your retention presentation, and how it was counted → C1 and B4 become rehearsed defend-the-number answers, not slots.
- Allowing web search → the four refused targets can run; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so.
- A tuesday-dossier.md, if you have one → verified evidence per requirement in place of the quotes here, and a sourced list of claims this pack should not coach.
