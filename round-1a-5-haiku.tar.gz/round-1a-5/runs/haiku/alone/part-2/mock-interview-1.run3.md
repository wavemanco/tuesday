I couldn't run the research step: all three web searches were refused, so the pack is built from your materials alone and marks what that leaves out. Writing the pack to the scratchpad now.
The saved file has the offers, question and watch-out at its end, which the skill keeps out of the file. Removing that block now.
Your pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-1-denied-e8e039e2/dbd43cbe-1b55-4c1e-8157-35d0970f11c9/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

It has 21 questions across seven personas, weighted toward Dan's data-driven prober and the peer evaluator, with the fit snapshot, prohibited claims, reverse questions for Dan, and a requirement-coverage map. I built it on the assumption that this is a peer round, which you told me.

**Research did not run.** All three web searches were refused, so Northwind's values, the interview loop and Dan's public footprint are missing. The pack uses your research note for the three priorities and the bundling threat, and it says so in the Sources section. The interviewer read rests on your description of Dan's profile.

**Flags to check before the round:**
- **The $400M figure (F9, A1, E2, B2):** the material says it was "credited with" a store-surface change Priya proposed. How it was counted and her share of it are not in what you gave me. Get her own account of both.
- **No sales-ops or quota experience (F8, D1, E1):** this comes from your notes, not from Priya's words. The pack withholds a plain acknowledgment until she confirms it herself. D1 is the highest-ROI prep, since sales-ops and quota work is Dan's own function.
- **Partner-motion design (F4, B4, G2):** the only evidence is the partner revenue model, which the pack keeps at that scope.

One question for you: does the role have an in-office days requirement, a travel requirement, or a work-authorization condition? None of these is in what you sent, and each would be a gate row in the fit snapshot.

I can run a drill with Dan on D1, the highest-ROI question, and give feedback against its guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products (mock-interview pack)

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer: you both report to the same VP.
**Round:** one 60-minute conversation with Dan.
**Version:** first pack. No earlier version to change.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key:
  - **JD**: a stated requirement from the job posting. Can you do the listed job, gaps included?
  - **EXP**: your own past work, probed. Does it hold up when someone checks it?
  - **CO**: company and competitive knowledge. Can you think at Northwind's altitude?
  - **CASE**: a live problem, delivered in the room.
  - **VAL**: behavioral. What did you do when it counted?
- Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.
- **Answer slot** = an instruction for the interview. Answer from your own experience, in either branch the slot offers. It is not a question to answer here.
- The **watch-out** at the foot of this pack applies throughout: do not rehearse anything you did not do.

---

## Fit snapshot

Requirements are the JD highlights as supplied, not the full posting. Evidence is quoted from your notes, and every quote is exact. Source keys: "coach's notes" = the context you gave me about Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" — coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market ownership of a product line. Keep it at that scope: nine years at a large consumer-tech company in product strategy & ops. Answer slot: if you made go-to-market decisions for a product, say which and how you decided; if you did not, say so and describe the product-strategy work you did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — coach's notes | low | [inferred] | discovery | Nothing in the material shows whitespace or any lifecycle motion. The revenue model is the nearest sentence and may touch them, or may not. Answer slot: if the model showed where revenue was not being captured in one of those motions, say what it showed; if it was built for the negotiations alone, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" — coach's notes | medium | [grounded] | presentation | Your material says "skilled in SQL/Tableau". Say that, and do not let skill stand in for independent work. Independence is what the probe will test (A3). |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | The sentence carries partner economics, not partner-motion design. Keep it in its own terms: built a partner-level revenue model used in carrier negotiations. Answer slot: if you designed how a partner was engaged, paid or enabled, say how; if the model was the extent of it, say so. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The sentence reaches the requirement in role terms: cross-org consensus is in the words. Expect a probe on whose consensus, and how it was reached (G1). |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" — coach's notes | medium | [grounded] | presentation | Your material says you use AI tools daily. That is usage, not building. Say usage in those words; do not stretch it to building or leading AI work. |
| F7 | B2B data-infrastructure SaaS (role description) | none given. The material is silent on B2B or enterprise selling; the only company named is consumer-tech. | none | [grounded] | discovery | Answer slot (D2): if you have worked on a B2B or enterprise decision, say which and what you did; if not, say that your material shows consumer-tech work, and say how you would learn the enterprise buyer. |
| F8 | Sales-ops and quota-setting (not in the JD highlights; raised as a gap in the coach's notes) | "No classic sales-ops or quota-setting experience." — coach's notes | medium | [grounded] | capability | Plain acknowledgment only once Priya says it herself: "I haven't done classic sales-ops or quota-setting." Until she confirms it in her own words, this is an answer slot (D1). Keep it apart from F5: setting targets with cross-org consensus is target-setting, not quota-setting. |
| F9 | Headline figure: the ~$400M ARR uplift (not a JD line; a number a data-driven interviewer will test) | "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | medium | [grounded] | discovery | The figure is in your material. How it was counted, and Priya's share of it, are not, and the sentence says "credited with", not "drove". Caveat: expect a probe on method and share. Answer slot (A1): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know the method, say so. |

**Gap-type routing, for the reader:** F1, F4 and F7 gap types follow the evidence cell: transferability where the quote is adjacent work, discovery where the material is silent, capability only where the absence was stated (F8). No row is `hard_gate` because the material names no gate. See the gate question in the message.

---

## Prohibited claims

Built locally from the fit snapshot. There is no dossier. These are the claims a candidate reaches for under pressure. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market strategy for a product line | Inflated form of F1 | "9 at a large consumer-tech company in product strategy & ops", at its own scope. Limit, as the pack's own observation: the material says product strategy and ops, not go-to-market ownership. |
| Designed partner motions or ran partner programs | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations". Limit, as the pack's own observation: the material says the model, not partner-motion design. |
| Led or drove the ~$400M uplift | Inflated form of F9 | "proposed a store-surface change credited with a ~$400M ARR uplift". The uplift is credited to the change; the material does not say who drove it. |
| Set targets alone, or owned the target process | Inflated form of F5 | "set annual volume targets with cross-org consensus", at its scope. Consensus is in the sentence. |
| Expert in SQL/Tableau, or ran independent analyses end to end | Inflated form of F3 | "skilled in SQL/Tableau". Independence is an answer slot (A3), not a claim. |
| Built or led AI work | Inflated form of F6 | "uses AI tools daily". |
| Ran sales-ops or quota-setting work | Sourced entry: negative in the coach's notes (F8) | Plain acknowledgment only once Priya confirms it in her own words. Until then, answer slot D1. |

---

## Reading the interviewer

Public footprint only. The pack rests on your description of Dan's profile. The public-footprint search was refused (see Sources), so no talks or writing were checked.

- **Career pattern:** a pricing and monetization career spine, with one early-stage-startup chapter. Self-described as "relentlessly data-driven."
- **What this means for the room:**
  1. Every number you give will be asked how it was counted. Expect this on the $400M figure (A1, E2) and on the revenue model (A2). Your answers depend on the material, not on a method you can't repeat.
  2. Pricing and packaging are his native language. The case bank (C1 to C3) is tilted toward pricing trade-offs. The partner revenue model (F4) is the best mirror you have: it is monetization vocabulary in your own words.
  3. The startup chapter means he may test pace and scrappiness. Your material shows no startup work, so the pack gives no startup story. Do not invent one; answer with what you did.
  4. Peer dynamics: he will judge what a hire costs his team and what it adds (B1, B4).
- **Mirror opportunities:** the shared vocabulary is pricing and revenue. The honest mirror is F4's quote.
- **Shared jump:** none established. Your material does not show a career move that mirrors his, so the pack offers none.

---

## Persona weights

Relationship prior first: a peer round weights the Peer Evaluator and the Data-Driven Prober most heavily. Interviewer signals adjust it: his self-described data-driven stance raises the Prober, and his pricing background tilts the case questions toward pricing.

No loop source establishes this round. The archetype fallback is generic, so the weights are flat and rest on the relationship prior, not on Northwind's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank depth |
|---|---|---|---|---|
| Data-Driven Prober | Counts, denominators, assumptions; follow-ups two levels deep | Highest. He describes himself as "relentlessly data-driven", and the $400M figure is the most likely probe in the room. | Know what you can say about how each number was counted. Say so plainly when you do not know. Name the weakest assumption before he does. | 5 (A1 to A5) |
| Peer Evaluator | Seams between teams, disagreement, credit, "what would you need from me" | High. Peer prior; both report to the same VP. | Offer seam principles rather than pretending to know the seam. Use disagreement stories that show spine and tact. | 4 (B1 to B4) |
| Case / Strategist | Live problems: pricing, go-to-market, a competitive bundle | Medium-high. Pricing career spine; the research note names the Compass launch and the bundle threat. | Clarify, then objective, segmentation, approach, metrics, risks. Name one premise you would challenge. | 3 (C1 to C3) |
| Skeptic | The day-one weakness, the B2B gap, "why here, why now" | Medium. Gaps in the fit snapshot are where a peer presses. | Rehearse the single most predictable objection until it is boring. Bridge only from adjacent evidence you actually stated. | 3 (D1 to D3) |
| Pressure | Time-boxed challenges, "how much of that was you" | Low-medium. A peer round rarely time-boxes, but one challenge is likely. | Pause, restate, hold through two follow-ups, then concede the specific point. | 2 (E1, E2) |
| Conversational | Opener walk-through; casual questions about JD plus-items | Medium. The opener is near certain, and it is scored. | Pre-scripted 90-second arc from quoted sentences only. Treat casual questions as scored. | 2 (F1, F2) |
| Values / Behavioral | Cross-functional influence story | Low. No values-style round is detected; one behavioral probe is possible. | Open prompts with selection scaffolds; say so plainly when no story comes to mind. | 2 (G1, G2) |

Total: 21 questions, inside the 18 to 26 range.

---

## Question banks

Provenance is the first column of each row. It carries the candidate sentences the guidance rests on, quoted exactly. Rationales refer to Priya's history only by fit-snapshot row ID.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story map: the change you proposed, and the uplift credited to it, in those words. Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you know the method, say it in your own words. If you do not know how it was counted, say so plainly and say who would know. Do not reconstruct a method you cannot repeat under a second question. | F9 is the most likely probe in this room, and it is the figure a prober checks first. EXP because it tests attribution. Highest-ROI on the number after D1. |
| A2 | "Which assumption behind your partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Weakest-assumption move, in your own words, before he asks for it. The material names no assumption, so this is an answer slot: if you can name the assumption you would defend least, say it; if you cannot recall the model's assumptions, say so and say what you would check first. | F4 is the only sentence about the model, and the prober asks for its assumptions, which no sentence states. EXP because it tests what was yours. |
| A3 | "Tell me about an analysis you ran in SQL or Tableau, from raw data to the decision it fed." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt on the JD's independent-analysis line. Answer slot: if you ran one yourself, end to end, say which and what it fed; if the work was largely someone else's query or dashboard, say that. Do not claim a pipeline you did not build. | F3 is the evidence; the JD line "run independent analysis in SQL and Tableau" is the raising source. JD because it scores a stated requirement. |
| A4 | "Where would you look first for whitespace across land, adopt, expand and renew, and what would you check it with?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: which motion first and why; which data would show whitespace; what you would check before trusting it. Make no claim about your past here. If you bring the revenue model in, say only what the sentence says. | The JD names whitespace across the lifecycle; F2 has no evidence that reaches it, so this is a live problem and not a record. JD because it scores the requirement. |
| A5 | "If I gave you last quarter's bookings by segment and asked for a read by Friday, what would you do first?" | CASE | [generic] | Clarify the question and the definitions (bookings, segment). State the first cut you would run. Name the figure you would distrust most. Say what you would hand back. No past claim. | A live problem that tests method, which is what a prober checks after the number. CASE because it is delivered live; the SQL/Tableau requirement is scored in A3. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on pricing and forecasting. Where is the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles: who owns the number, who owns the call, how a disagreement is escalated and settled. Answer slot: pick a time you disagreed with a peer on a number, with a named stake and a working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the consensus behind the targets (F5). | Peer Evaluator seam question. The JD's cross-functional influence line raises it. JD because it scores that requirement. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you proposed, in those words, and whose work sat beside yours, if anyone's did. Answer slot: if you can name whose work sat alongside yours, name them and their part; if the credit was yours alone, say so. Do not extend credit you cannot name. | F9 is a credit question: the uplift is credited to the change, and the peer will ask who else carried it. VAL because it is about how credit is shared. |
| B3 | "Who did your partner-level revenue model feed, and what did they do with it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story map: the model, built; used in carrier negotiations. Those are the beats the sentence states. Answer slot: if you shaped the model for the negotiation team's use, say how; if it was used in ways you did not set, say that. Describe the use only in the sentence's words. | F4's sentence; the question's premise (the model was used) is the sentence's own. EXP because it tests attribution of use. |
| B4 | "How would you design the partner motion for one of the two new product lines: who is the partner, and what do they get?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: the partner's economics, the motion's first step, the risk of channel conflict with the direct team, what you would test first. Make no claim about past partner-motion design. If you draw on the revenue model, say only what the sentence says. | JD partner-motion requirement; the live problem is the scored item. The revenue model is F4's adjacent evidence, so any reference to it stays at the sentence's scope. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "An AI copilot goes into an installed base of enterprise customers. How would you think about its go-to-market: who it is for, how it is priced, what you would test first?" | CASE | [grounded] research note: "an AI copilot launch ('Compass')" | Clarify what the launch is for: expansion, retention or profitability. Segment the base. Price it against the current plan. Metrics: adoption and expansion. Risks: cannibalisation. Use the name Compass only as your note gives it; claim no knowledge of its features. | Compass is one of Northwind's three stated priorities in your note. Pricing is the lens Dan will expect. No claim about Priya's history. |
| C2 | "A much larger platform vendor is bundling its own data tool into its suite. Where do you hold ground in an enterprise deal?" | CO | [grounded] research note: "main competitive threat is bundling by a much larger platform vendor" | Name what you would need to know before choosing a stance: the bundle's price, what the buyer already has, and what the bundle leaves out. Give a stance and its reason. A concession, not a bluff. A pricing-based reason is the strongest. | The competitive threat from your note. CO because it tests altitude. Dan's monetization background makes pricing the native reasoning. |
| C3 | "Enterprise expansion and profitability are both on the table. Where does pricing change sit between them?" | CO | [grounded] research note: "enterprise expansion" and "reaching profitability" | Name the trade-off: what a pricing change buys in expansion and what it costs in margin or bookings. Say which metric you would pick and why. Give one risk. | Both priorities come from your note. The trade-off is where a pricing-minded peer presses. CO because it tests company-level thinking. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." — coach's notes | Answer slot. If you have set a target that planned a sales team's year, say which. If not, say so plainly, then say how you would learn that work in your first 90 days. Plain acknowledgment only once Priya confirms it in her own words: "I haven't done classic sales-ops or quota-setting." Keep target-setting (F5) and quota-setting (F8) apart. Follow-up 1 ("How would you learn it?") gets a plan, not a past. Follow-up 2 ("Who on your team would you ask?") holds the same answer; do not add a credential. | **Highest-ROI prep in this pack.** The sales-ops and quota gap sits inside Dan's own function, so it is the most predictable objection, and the most tempting place to overstate. Deepest rehearsal: two follow-ups, the exact concession, and the plan named before it is asked for. |
| D2 | "I don't see enterprise sales in your background. How would you handle the enterprise motion here?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot. If you have worked on an enterprise or B2B decision, say which and what you did. If not, say that your material shows consumer-tech product strategy and ops, and say how you would learn the enterprise buyer. | F7 is silence, not a stated negative, so the guidance gives no plain acknowledgment. The interviewer's "I don't see" is an observation, not a fact the pack asserts. JD because it scores the B2B context. |
| D3 | "Why here, and why now, for a B2B company when your background is consumer?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Your motivation is not in the material, so the guidance supplies none. Selection scaffold: pick the reason you would give in one sentence, grounded in work you actually did. If no reason comes to mind, say so plainly, then say what the consumer work taught you that you would bring. | Skeptic motivation probe. "Why now" is not in any quote, so the guidance supplies no motive. EXP because the answer rests on the past work. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run enterprise sales for ten years?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Pause. Restate the question. Hold on the sentences in your provenance, at their own scope: the targets set with cross-org consensus, and the revenue model. Hold through two follow-ups before any concession. Concede specifically: you have not run enterprise sales, and say what you would do in the first 90 days. Never fold on the core claim. | Pressure stem. The hold uses only F5 and F4 at their scope. JD because it scores the B2B and target-setting context under stress. |
| E2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate: the figure is credited to a change you proposed. Hold through two follow-ups with the sentence. Concede precisely: if you cannot give your share, say you cannot, and say how you would find out. | The composure test on F9. The hold-then-concede structure is the rehearsal; the share is not in the material, so the guidance does not supply one. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | 90-second arc. The beats are the three sentences, in order: consulting at a top firm, then consumer tech in product strategy & ops, then the revenue model used in carrier negotiations. Add no motive between them. Answer slot: if there is a reason for the move from consulting, say it in your own words; if the move was not a plan, say so. | Rapport opener, scored casually. EXP because it is the work history. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools you use daily and one specific task. Answer slot: if you have a specific workflow, name it; if not, say you use AI tools daily, and do not stretch the answer to building. | "AI experience a plus" is scored when asked casually. JD because it is a stated plus-item; F6 is usage. |

### G. Values / Behavioral (2)

No values-style round is detected, so the guidance is generic. Both are open prompts whose themes come from the JD.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you got a cross-org group to agree on a number." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story map: the targets you set, and the consensus, the beat the sentence states. Answer slot: what you did to reach that consensus, if you did it, in your own words; if the consensus came without your doing, say so. Do not supply the disagreement or the ending. | F5 is the evidence for the JD's cross-functional influence line. VAL because it is behavioral. |
| G2 | "Tell me about a time partner numbers and internal numbers pulled in different directions." | VAL | [grounded] "built a partner-level revenue model used in carrier negotiations" | Selection scaffold: pick a time partner numbers and internal numbers pulled apart, with a named stake. If none comes to mind, say so plainly, then give the nearest thing your material carries: the revenue model and how it was used, in the sentence's words. | The partner-motion requirement raises this; F4 is the nearest evidence. VAL because it asks for behavior under a number conflict. |

---

## Requirement coverage

| JD requirement (or role context) | Question IDs |
|---|---|
| Own GTM strategy for two new product lines | D1, A4, B4 |
| Identify whitespace across land/adopt/expand/renew | A4 |
| Run independent analysis in SQL and Tableau | A3, A5 |
| Partner-motion design experience required | B4, G2, B3 |
| Strong cross-functional influence | B1, G1, B2 |
| AI experience a plus | F2, C1 |
| B2B data-infrastructure SaaS (role context) | D2, C2, D3 |
| Sales-ops and quota-setting (raised as a gap in the coach's notes) | D1, E1 |
| Enterprise expansion, Compass, profitability, competitive bundling (research note) | C1, C2, C3 |
| The ~$400M headline figure | A1, E2, B2 |

Every JD requirement has at least one JD-tagged question. No requirement is uncovered.

---

## Reverse questions for Dan

Peer round, so one reciprocity question is included. One ties to his path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. What did that work teach you that the sales side still can't see?" | Ties to his own career path, which turns an interrogation into a peer conversation. It shows you researched him, not only the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: it frames your value to his team, not only your needs. |
| R3 | "Where does sales strategy's analysis stop today, and the commercial team's decisions start?" | Asks for the seam directly. It gives you the boundary to design around in the first 60 days. |
| R4 | "How will the two new product lines be measured in year one: bookings, adoption or ARR?" | Matches his data-driven self-description. It surfaces the metric question before the interview does. |
| R5 | "When a platform vendor's bundle shows up in a deal, what does your team do in the first call?" | Uses the competitive threat from your research note. It tests whether his team has a playbook, and it is pricing-relevant. |
| R6 | "Of enterprise expansion, the Compass launch and profitability, which is creating the most tension in planning right now?" | Uses the three priorities from your note. It asks him to weigh them, which is the peer conversation you want. |

---

## Sources

**Provided documents:** your message. It holds the JD highlights (not the full posting), the candidate summary, the interviewer description and the research note. No CV, no interviewer profile link and no dossier were provided.

**Searches sent (all refused):**

1. "Northwind Data company values" — refused
2. "Northwind Data interview process Senior GTM Strategy Lead Emerging Products" — refused
3. "Dan Kovac Director of Sales Strategy Northwind Data" — refused

**Research tier:** L1. Searches 0 of 6 (three attempted, all refused). Fetches 0 of 2. Nothing from outside your materials is in this pack.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet not built. No values round is detected, and no values page was read. |
| 2. Northwind interview process, role family | unavailable | Loop structure. The round is on the archetype fallback, so persona weights are flat and rest on the relationship prior. |
| 3. Company strategy / recent news | skipped | Your research note supplies the three priorities and the bundling threat, which is what the case bank needs. No recent-news sweep ran, so currency is unchecked. |
| 4. Dan Kovac with Northwind | unavailable | Public footprint. The interviewer read rests on your description of his profile, and no talks or writing were checked. |
| 5. Representative JD | skipped | JD highlights supplied. |

**Values:** not detected. No values round is in the loop, and no values page was read, so there is no values cheat sheet.

---

## Upgrade menu

- **The full job posting** → requirement rows quoted from the whole text, and any location, travel or work-authorization condition it states becomes a checkable gate row.
- **Priya's CV** → the "coach's notes" evidence becomes her own sentences, quoted from the document she wrote.
- **Priya confirming the sales-ops and quota negative in her own words** → unlocks the plain acknowledgment in D1 and E1 in place of the answer slot.
- **How the ~$400M was measured, and Priya's share of it** → replaces the answer slots in A1, E2 and B2 with her own method and share.
- **Search access** (this session's searches were refused) → Northwind's values, the loop structure, a recent-strategy check and Dan's public footprint. Each would move the unavailable rows in the target accounting above.
- **Dan's public profile link** → recurring themes as likely questions, and a shared professional path for a reverse question, if one exists in Priya's own material.
- **Northwind's recruiter note on the round** → confirms the 60-minute format and whether a case or presentation is pre-declared.
- **`tuesday-dossier.md`** → would carry verified evidence and binding prohibited claims into this pack. Without it, the prohibited list above is built locally.
