Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-7-canned-d9b121ba/823d2ad9-13e7-44c0-b820-eee2c6f5070e/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it on a hiring-manager assumption, since your note didn't say who you're meeting, and I did not run web research, so it uses only what you gave me.

The pack's main finding: your strongest evidence is the content-drop calendar for one title and the release checklist QA still uses. The JD asks for live events across two titles and cross-team coordination, and your material doesn't show either. The highest-ROI prep is the Skeptic bank, A1 to A5. A2 (one title versus two) and A3 (owning the post-event review) are the likeliest probes. Rehearse only what you actually did, and say plainly where you didn't.

Two things would sharpen it:

- **Round type:** is Tobias your future manager, a peer, or part of a panel? The answer reweights every bank.
- **Research:** should I run web research on Saltmarsh and Tobias's public footprint? That would add the company's values, the interview loop, recent strategy, and a reverse question tied to Tobias's own path. I'd use at most 6 searches and 2 page fetches.

I can also drill any persona live. Say the word and I'll play the Skeptic on A2, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (relationship not yet confirmed; built on a hiring-manager prior, see persona table). Built at research tier L0 (your material only). Friday, 60 minutes.

## How to use + type key

- **Personas** describe how a question is asked (the delivery). **Types** describe what is being scored.
- Types: **JD** = a stated requirement from the posting. **EXP** = what you actually did. **CASE** = a live problem from the role, which asks about no past. **VAL** = published values (none supplied, so this type is scaffolded only). **CO** = company and strategy knowledge (none researched, so no CO questions are grounded).
- Guidance is scaffolding, not a script. Speak in your own words. Where guidance quotes your sentences, those are the only things it lets you claim.

## Prep triage

Prep time was not stated, so no schedule is set. If you have limited time, do the Skeptic bank (A1 to A5) first, then the Prober bank (C1 to C2). Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, for two years: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for live events across two titles. If you planned across more than one title, or ran events rather than drops, say which and how. If not, say so and say how you would run two. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | No gap. Your sentence already says it in the JD's terms: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The material shows a checklist used by QA, not coordination across design, art, engineering or community. Answer slot: if you coordinated any of those teams on an update, name which teams, what you needed from each, and how it went. If you did not, say so, and say how you would set it up on the first update. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned the KPIs or a review: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, or ran any post-event review, say what you did. If you did not, say so and say what you would review first. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms: "I presented the monthly retention numbers to the studio head." Say it in those words. Add no figure or event that is not in the sentence. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | high | [grounded] | none | No gap. Your sentence already reaches it: "Wrote the release checklist our QA team still uses." |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Your sentence reaches it in other terms: "I wrote the release checklist our QA team still uses." No written sample was supplied, so do not claim more than this. |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years are stated. Whether the puzzle title was live-service in the sense this role uses is not established by your material. Answer slot: say how the title ran after launch, in its content cadence and after-release handling, in your own words. If it was not live-service, say so and say what carries over. |
| F9 | people leadership (role-family expectation, not quoted from the JD) | "Never led a team" (your message) | none | [generic] | capability | You have stated this gap. Words: "I haven't led a team." Then how you would learn it, said as a plan, never as a past. Coordinating a team's work is not leading it. Do not blur the two. |
| F10 | in-app purchase economics (role-family expectation, not quoted from the JD) | "never worked on a game with in-app purchases" (your message) | none | [generic] | capability | You have stated this gap. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. |

Gap types: F1, F4, F7, F8 are transferability or presentation. F3 is discovery. F9 and F10 are capability because you stated the negative. F2 and F6 have no gap.

## Prohibited claims

These are claims the pack will not coach, because the material does not support them. Basis for each is the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated (F9) | "I haven't led a team." No slot. |
| Ran live events across two titles | Inflated form of F1 and F2 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." A1 and B1 stay inside it. |
| Owned the post-event review or the KPIs it reports | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." C1 asks only how that figure was counted. |
| Coordinated design, art, engineering or community on updates | Inflated form of F3 | F3's slot. E2 asks only what you did, if anything. |
| Experience with in-app purchases or monetised live-service economics | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." No slot. |
| Live-service experience | Inflated form of F8 | F8's slot. The pack does not assert it. |

## Reading the interviewer

Only the name and title are known: Tobias Wrenfield, Head of Live Operations. No public footprint was researched (L0), so no career pattern, talks or writing are read. Practical implications:
- Expect the calendar and KPI requirements to be probed in their own terms, so use the posting's words in your answers.
- A Head of Live Operations will care about the calendar's breaking points, not only its shape. Rehearse how a calendar fails.
- Once you consent to research (see the upgrade menu), this section can be rewritten from their public footprint.

## Persona table

Round type is not yet confirmed. Starting weights come from the hiring-manager prior: a Head-level interviewer for a producer role is most likely the hiring manager. Their job is to buy capability and derisk gaps, so the Skeptic and Case personas carry the most weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two stated gaps (leadership, monetisation) and the mismatch between one title and two. | High. Hiring-manager prior, plus two gaps you stated yourself. Weight: top, 5 questions. | Rehearse the single most predictable objection until it is plain. Name gaps plainly, then a ramp plan. |
| Case / Strategist | Live problem on the calendar, a retention drop, or a KPI choice. | High. The role is live problems on a roadmap. Weight: 3 questions. | Clarify, then structure, then metrics. Think aloud. |
| Data-Driven Prober | Asks how retention figures were counted, and which assumption you would defend least. | Medium to high. The posting names retention metrics. Weight: 3 questions. | Say plainly what you do not know about how a figure was counted. |
| Pressure / Stress | Challenges the monetisation gap, or asks how much of the retention work was yours. | Medium. Used to test composure. Weight: 2 questions. | Hold a position through two follow-ups. Concede the gap, not the strength. |
| Values / Behavioral | Scenario questions tied to the JD's coordination requirement. No published values were supplied, so these are scaffolds. | Medium. Weight: 2 questions. | Selection scaffolds with an honest branch. |
| Conversational | Casual opener and a casual question on live-service games. | Low to medium. Casual questions are still scored. Weight: 2 questions. | A 90-second arc drawn from your own sentences. |
| Peer Evaluator | Seams between design, art, engineering and community, and disagreement. Only plausible in a panel. | Low. Weight: 1 question. | Propose seam principles rather than pretend to know their seams. |

## Question banks

Type key: JD, EXP, CASE, VAL, CO. Provenance comes first in each row. Your quoted sentences are the only claims the guidance draws on.

### A. Skeptic (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team"; "never worked on a game with in-app purchases" | Name the two gaps you have stated, plainly: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Then one ramp plan for each, said as a plan. Do not add a third gap. | F9 and F10 are the two negatives you stated. Naming them first costs less than a probe that finds them. |
| A2 | "Most of your experience is one title's content drops. Why would two live titles be different?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold to your sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned across more than one title or ran events rather than drops, say which and how. If not, say the two-title load is new and how you would sequence it. | F1 transferability. The question presupposes a difference the JD raises; your sentence does not carry two titles. |
| A3 | "Have you owned a post-event review, and the KPIs it reports?" | JD | [grounded] "Presented the monthly retention numbers to the studio head."; raising source: JD "own the post-event review and the KPIs it reports" | Answer slot: if you chose which KPIs were reported or ran a review of an event, say what you did. If you did not, say so and say what you would review first. Do not claim the review. | F4. The question presupposes an ownership the quote does not carry. The second branch is the honest one. |
| A4 | "You have never led a team. Why would you coordinate four disciplines well?" | JD | [grounded] "Never led a team" | Coordinating is not leading, and say so in your own words. Answer slot: if you coordinated any of design, art, engineering or community on an update, name which teams, what you needed from each and how it went. If none, say so and say how you would set it up. | F9 and F3. The question's premise is that coordination is required. Your material does not show coordination. |
| A5 | "An update is ready to ship, but QA says the checklist isn't finished. What do you do?" | CASE | [generic] | Structure it: who decides, what the checklist gates, what you escalate and to whom, and what you do with the update in the meantime. The question is a live problem, so it asks about no past and the guidance makes no claim about you. | Tests the release-checklist requirement without any claim about your past. |

### B. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would plan the next two quarters of live events for two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's retention baseline, team capacity, which titles are in a growth phase and which are in maintenance, and what each KPI measures. Then calendar structure: cadence, dependencies on QA and engineering, a review point per event. Then metrics. | JD requirement 1, the calendar for two titles. This is the F1 gap at its largest. |
| B2 | "Retention on one of your titles fell 15% in the week after an update. Diagnose it." | CASE | [generic] | Clarify what changed: content, events, store listing, a bug, a seasonal dip. Segment by cohort and platform. Check the release log. Set a rollback criterion before you investigate. | Tests the post-event review and retention requirements in a live setting. |
| B3 | "What goes into a post-event review, and who do you need to hear from?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Describe what a review should contain: the goal, the KPIs, the timeline, what went wrong, and the owners of each follow-up. Say which of those you have done, in your own words, and which are plans. | JD requirement 2, post-event review. The quote keeps the review at the presentation you did. |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the retention numbers you presented." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say how the figure was defined, in your own words, only if you know. Name the assumption it was most sensitive to. Answer slot: if you set the definition yourself, say so and how you decided. If another team set it, say that plainly. Either is an honest answer. | F4 and F5. A premised question about your own figure. Defend-the-number, with the honest branch. |
| C2 | "Which assumption behind a retention number would you defend least?" | JD | [generic] | Name one assumption you actually know of, from C1's answer. Do not invent one. If you do not know one, say so. | Prober stem from the persona table. The honest answer is the one you can repeat under a second question. |
| C3 | "What is the first KPI you would track for a title you had just inherited, and why that one?" | CASE | [generic] | State one KPI and the reason it tracks what the title is for. Name what would make you change it. A live problem, so it makes no claim about your past. | Tests KPI ownership, the post-event review requirement, without a premise about your record. |

### D. Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with no monetisation experience over someone who has it?" | EXP | [grounded] "never worked on a game with in-app purchases" | Hold the position. Do not fold to "they have it". Name what carries over, in your quoted sentences: the calendar you ran and the checklist QA still uses. Concede the gap plainly: "I haven't worked on a game with in-app purchases." Then the ramp. Hold through two follow-ups before you concede anything more. | F10 and the stated negative. The test is composure, not the answer. |
| D2 | "That retention presentation. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which parts you did, presenting or analysis, and which were someone else's. If you did not build the numbers, say so. | F4. A premised question about your presentation. The honest branch is the answer. |

### E. Values / Behavioral (2 questions; no published values, so scaffolds only)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and what happened after. If none comes to mind, say so plainly, then give the nearest thing: the retention numbers you presented, and what the studio head did with them, only if you know. | The quote carries a presentation, not an unpopular truth. The scaffold sends you to a real time, not a supplied one. |
| E2 | "Tell me about a time you got an update out across four teams on schedule." | VAL | [grounded] JD "coordinate design, art, engineering and community teams on each update" | Selection scaffold: pick a time a single release needed several teams, and say what you did and what they did. If none comes to mind, say so plainly, then give the nearest thing: the release checklist QA still uses, and how you ran it. | F3 is discovery. The scaffold ends in the honest branch the material needs. |

### F. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own sentences, in this order: four years at a puzzle-game studio; the content-drop calendar; the checklist; the retention presentation. Each beat is a sentence you gave. Stop before the gaps. | Casual openers are scored. The arc covers the years requirement, the calendar, the checklist and the retention work. |
| F2 | "What are you actually playing in live-service games these days?" | JD | [generic] | Name a title you have actually played. If you have not played a live-service game recently, say so and name the nearest one you have. | A casual question on a JD topic, scored as a preparation signal. |

### G. Peer Evaluator (1 question, panel only)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] JD "coordinate design, art, engineering and community teams on each update" | Propose seam principles, such as who owns the calendar and who signs off a release. Answer slot: if you have a disagreement with a team you coordinated, say what it was and how it resolved. If you have not, say so and describe how you would handle it. | F3, a seam the JD names. Propose principles, not a seam you do not know. |

### Coverage

| Requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two titles | A2, B1 | F1 transferability |
| Coordinate design, art, engineering and community teams | A4, E2, G1 | F3 discovery |
| Own the post-event review and the KPIs it reports | A3, B3, C3 | F4 transferability |
| Manage the release checklist with QA | A5, F1 | F6, no gap |
| 3+ years producing live-service games or apps | F1 (the arc), A2 | F8, slot in the upgrade menu |
| Experience running a content calendar | A2, F1 | F2, no gap |
| Comfortable with player-retention metrics | C1, C2, D2 | F5 presentation |
| Clear written communication | none, and why: no written sample was supplied, so no question tests it. The upgrade menu asks for one. | F7 presentation |

## Reverse questions

Each one has a "why it lands." No profile for Tobias was researched, so none ties to their own career path.

1. "What does the calendar look like for the next two quarters, and where does it break?" Why it lands: it shows you think about a calendar as something that fails, not as a list.
2. "Which KPIs does the post-event review report to leadership, and who sets them?" Why it lands: it shows you know ownership is the test of this role.
3. "How is the release checklist owned today, and what would you change in it?" Why it lands: it ties your checklist to their process and invites a specific answer.
4. "What did the last person in this role get wrong in the first 90 days?" Why it lands: it signals you want to avoid the known mistake, not repeat it.
5. "What is the biggest monetisation question the two titles face this year?" Why it lands: it shows you know the gap you stated, and turns it into a question you can learn from.

## Sources

Provided documents: the job description, your background and your stated gaps, all in your message. No research was run (L0). No other document was consumed; no dossier was present.

Research tier: L0 (provided documents only)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, section 10, would have moved. Not built, since research was not run. |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Loop structure; persona weights would follow the named rounds. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | CO questions and the grounding brief would have moved. Not built. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read and a tailored reverse question would have moved. |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Tobias's public profile or talks, from research at L1 → a rewritten interviewer read, persona weights from their footprint, and a reverse question tied to their own path
- Saltmarsh's values and recent launches, from research at L1 → a values cheat sheet (section 10) and CO questions grounded in current strategy
- Whether your puzzle title ran live events or a live-service model → F8's answer slot becomes a grounded line in the arc
- A written sample, such as the release checklist or a post-event write-up → a written-communication bank and a grounded "clear written communication" line
- Whether the interview is a panel or a hiring-manager round → persona weights reset
- A `tuesday-dossier.md` → verified evidence and sharper objection ranking in a later pack
