Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-8-denied-a367e96a/ashgrove_member-experience-lead_interview_pack.md. It covers all three rounds: the recruiter screen, the Head of Member Services, and the branch-manager panel with the escalation case.

I built it at the default research tier without running any searches, because your inputs already fixed the values, round format, strategy and JD. The values and strategy figures are from what you pasted, not checked against Ashgrove's published pages. The pack lists what to verify.

The biggest prep item is B6, the contact-centre question. The job description names the contact centre, and your background says you've never worked in one, so expect it in some form.

Say the word and I'll run a live drill as the Skeptic on B6.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Company and role:** Ashgrove Credit Union, Member Experience Lead (member-owned, about 900 staff)
**Rounds, 4 December 2026:**
1. Recruiter, 30 minutes.
2. Head of Member Services, 45 minutes, mostly behavioural. This is your future manager.
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values.

**Interviewers:** not yet named for rounds 2 and 3, so there is no interviewer read and the personas are weighted by round type.
**Built from:** the job description, the values text, the strategy brief summary and the round details you sent, at the default research tier. Nothing has changed since the first pass.

---

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

- **VAL**: whether past behaviour shows a published value.
- **EXP**: whether your past claims survive scrutiny.
- **JD**: whether you can do the listed responsibilities, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, worked aloud.

Guidance is scaffolding, not a script. Two kinds of cell are instructions for the interview, not questions for you to answer here. An **answer slot** says what to do when a probe reaches a gap. A **logistics slot** covers pay, notice, location and reason for leaving.

---

## Fit snapshot

Requirements are quoted from the job description you sent. Evidence is quoted from your message. Gap wording stays inside your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your words are retail banking and a branch supervisor role. Use them as they stand: "Six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material does not show whether that log was a regulated process, and this pack does not assume it. Answer slot: if you know which rules and timescales governed the log, and who set them, say so in your own words. If none were set where you worked, or you did not know them, say so plainly and describe how you handled the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log, not the process end to end. Keep the log at its own scope. Answer slot: name the steps from a complaint's arrival to its close that you ran yourself. If the log stopped at the branch, say so, and say how you would take on the rest. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own negative, so your words are: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan, never as a past. |
| F5 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | You trained tellers, not supervisors. Say it that way: "I trained new tellers on our escalation script." Answer slot: as a branch supervisor, say how you handled escalations that came to you. If you have coached other supervisors on them, say how. If you have not, say so and say how you would start. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work, and this pack assumes none. Answer slot: if you worked with a digital or app team on a customer journey, say what you did in it. If you did not, say so, and say how you would find where members get stuck in a journey. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sentence reaches monthly complaints reporting but does not show whether volumes or resolution times were counted. Answer slot: say what the spreadsheet counted, and whether it recorded how long cases took. If it did not record times, say so. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | No gap: the sentence reaches the requirement. Limit: a spreadsheet nobody has inspected, so expect a probe on how it works. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your words: "I've never presented to anyone above regional level." Then a plan for how you would build that skill, said as a plan. |

**Confidence** is one of high, medium, low or none. **Provenance** is one of [grounded], [inferred] or [generic]. **Gap type** is one of none, presentation, discovery, transferability, capability or hard_gate. No row is a hard gate: the requirements are experience and skills, not eligibility terms.

---

## Prohibited claims

Built from the fit snapshot before any question was written. These are the claims a candidate reaches for under pressure, and this pack will not coach any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Contact-centre experience | Your own negative, F4 | "I haven't worked in a contact centre." Plus a plan. No answer slot. |
| Presenting to senior leaders | Your own negative, F9 | "I've never presented to anyone above regional level." Plus a plan. No answer slot. |
| Owning the complaints process end to end | Inflated form of F3 | The branch complaints log at its own scope. Your material says the branch log, not the process end to end. |
| Handling regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Whether that log was regulated is not in your material. |
| Designing the metrics or the reporting framework | Inflated form of F7 | "I built the monthly complaints spreadsheet." Nothing about choosing what it measured. |
| Writing the escalation script | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Coaching branch supervisors on escalations | Inflated form of F5 | You trained tellers. The supervisor answer is the slot in F5. |

---

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through your journey" | High in round 1. Recruiter screens are friendly and logistics-led. | A 90-second arc from your own words. Treat casual questions as scored. |
| Light Skeptic | Motive and fit checks in a calm register | Medium in round 1. A recruiter is not the manager, so this stays light. | Say the contact-centre gap in one calm sentence. |
| Values / Behavioral | Scenario probes mapped to the four values | Highest in round 2, which is mostly behavioural, and in the panel's scoring. | Selection scaffolds with honest branches. "I" for your part. |
| Skeptic | Probes the gaps: contact centre, senior presentation, regulated complaints | High in round 2. Your manager will test the gaps in the job description, and those are your gaps. | Hold, then concede specifically. B6 rehearses it. |
| Data-Driven Prober | Asks how the spreadsheet counted volumes and times | High in the panel. Branch managers read the figures they run. | Say what the spreadsheet counted, and say plainly what you cannot say. |
| Peer Evaluator | Seams between branches and the contact centre; credit when work spans teams | High in the panel. Branch managers are colleagues in the same network. | Propose seam principles, not answers you do not know. |
| Case / Strategist | The 20-minute escalation case | Certain in round 3, because the round names it. | Clarify, structure, think aloud. |
| Pressure / stress | Interruptions and time-boxing | Low. No round is described as a stress interview. Hold-then-concede is still in B6. | Pause, restate, hold through two follow-ups. |

**Depth.** Round 1 has six questions: four logistics, one journey opener and one about Ashgrove, which is the recruiter's own check. Round 2 has eight: five values questions, three skeptic questions. Round 3 has eight: four data, three peer, and the case. Twenty-two in total.

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | C5, C6, D1 (F3 and F4 slots) |
| Report monthly on complaint volumes and resolution times | C3, C4 (F7) |
| Coach branch supervisors on escalations | B5 (F5) |
| Work with digital teams on self-service journeys | C7 (F6) |
| 4+ years in financial-services customer operations | A1 (F1) |
| Experience handling regulated complaints | B8 (F2) |
| Confident presenting to senior leaders | B6 is the contact-centre question; B7 (F9) |
| Comfortable with Excel reporting | C1, C2 (F8) |

---

## Grounding brief

Vocabulary from the strategy brief as you summarised it. Check the wording against the published brief before you use any of it in the room.

- Digital: move 40% of member service to digital channels by 2028.
- Network: consolidate eight branches into five hubs over 2027.
- Product: launch a small-business lending product in Q1 2027.
- Competition: the main pressure is app-only banks.

---

## Round 1: Recruiter (30 minutes)

Persona: Conversational (weighted highest), with light Skeptic. Logistics questions come first in the bank, so the recruiter's checklist does not run out of time.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Ninety seconds, in your words: the six years, then the last three as a branch supervisor. Stop there and add nothing. Let the recruiter ask about the complaints work. | A casual opener that is still scored for economy. F1 is the frame. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot. Decide before the call whether you will give the figure you are working to or ask for the band first, then say it in your own words. | Pay is a logistics slot. Your material gives no figure, so the pack gives none. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. If you do not know it yet, say so and say when you will. | Notice is a logistics slot. Your material gives none. |
| A4 | "Where are you based, and what travel can you do?" | JD | [generic] | Logistics slot. Give your base and the travel you can do, in your own words. If the office pattern is unclear, ask what it is. | Location is a logistics slot. A required office pattern, if the recruiter states one, is a fit row. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. One sentence on the reason, in your own words, with no criticism of your employer. If you have not settled what comes next, say you are weighing your options. | Reason for leaving is a logistics slot. Your material gives none. |
| A6 | "What do you know about Ashgrove?" | CO | [grounded] "the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent me" | Name what you have read: the strategy brief you were sent, and the values page. Say what you have read, and no more. | A recruiter's check on whether you prepared. Keep to what you actually read. |

---

## Round 2: Head of Member Services (45 minutes)

Persona: Values / Behavioral (weighted highest), with Skeptic. Your manager will ask about values through behaviour, then test the gaps.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member's need ahead of a process rule." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: pick a time a member's situation did not fit the procedure, what you did next, and whether the member was told why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled, and how you would handle a case where the rule and the member disagreed. | Members First, Always. The raising source is the published line: "we decide from the member's side of the counter". |
| B2 | "Tell me about a time you explained a decision to a member who needed it explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Scaffold: pick a time you explained an outcome, what you said first, and what changed when you explained it again. If none comes to mind, say so, then give the nearest: you trained new tellers on the escalation script, what the script was for, and how you would tell whether the message landed. | Plain Words. The raising source is the published line: "if a member needs it explained twice, we wrote it wrong". |
| B3 | "Tell me about a problem you found that was not yours to fix, and what happened to it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: pick a time you found a problem outside your remit and kept hold of it until it was solved. If none comes to mind, say so, then give the nearest: the monthly spreadsheet, what it showed and what happened next. If it only reported, say so. | Own the Fix. The raising source is the published line: "whoever finds the problem keeps hold of it until it is solved". |
| B4 | "Tell me about a time you thought about a branch's town rather than its numbers." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: pick a time a branch's local situation changed how you handled members or the branch's work. If none comes to mind, say so, then give the nearest: the branch's log, and how you would find out what the branch's town needs before a change. | Neighbours, Not Numbers. The raising source is the published line: "every branch is part of its town". |
| B5 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Scaffold: pick someone you coached, the escalation, and what they did differently afterwards. Name who you coached. If you have coached only tellers on the script, say that and do not stretch it to supervisors. If you have never coached a live escalation, say so and describe the training you did. | JD coaching line, F5. The supervisor answer is the slot in F5, not a claim. |
| B6 | "How would you run complaints across a contact centre you have never worked in?" | JD | [grounded] "Never worked in a contact centre" | Hold: "I haven't worked in a contact centre." Then the plan: the first things you would learn, and who on the contact-centre side you would ask. Hold through two follow-ups by returning to the one thing you know: a complaint needs one owner, whichever channel it came in through. Concede specifically: if asked which contact-centre measures you would watch first, say you do not know them yet, and how you would find out. Never claim contact-centre knowledge. | **Highest-ROI prep in this pack.** The contact centre is the one gap the job description names and you have stated. This is the question most likely to be asked in some form. |
| B7 | "You've never presented above regional level. Why would senior leaders trust you with the monthly numbers?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare the first presentation, and who would check the figures with you first. Do not describe a presentation you have not given. | F9. The stated negative is the only words you need. |
| B8 | "Walk me through how the formal complaints log worked: who set its rules and timescales?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you know the rules and timescales that governed the log, and who set them, say so in your own words. If none were set where you worked, or they were not yours to know, say so plainly. Hold to the log: "I handled the formal complaints log." | F2. The question assumes rules and timescales that your material does not carry, so its second branch must stay open. |

---

## Round 3: Branch-manager panel (60 minutes, including a 20-minute case)

Persona: Data-Driven Prober and Peer Evaluator (the top two for branch-manager colleagues), plus the Case / Strategist for D1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly complaints spreadsheet was counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the columns counted, in your own words. Answer slot: if you chose what went in the columns, say which and why. If the columns were set for you, say so plainly. | F7 and F8. The most likely EXP probe on the spreadsheet. |
| C2 | "Which number on that spreadsheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the column you are least sure of before they do, and say what you would check first. If you cannot say how a column was counted, say that. | Weakest-assumption move. No figure has been given, so no defend-the-number slot opens; the honest branch is "I can't say how it was counted." |
| C3 | "Which of volumes, resolution times, or neither did your spreadsheet record?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer with what it recorded. "Neither" is an honest answer. If you did not track times, say so plainly. | F7. The JD's monthly reporting line, with the honest branch built in. |
| C4 | "How would you report complaint resolution monthly across branches and the contact centre?" | JD | [generic] | Structure: what counts as resolved, two or three measures for a monthly report, whose data feeds each, and how you would check the figures before anyone sees them. Think aloud and name one assumption. | JD reporting requirement, across both channels. F4 is the gap; this question is a plan, not a past. |
| C5 | "Our teams sit side by side. Where's the seam between branches and the contact centre, and what happens when we disagree?" | JD | [generic] and [grounded] "I handled the branch's formal complaints log" | Propose seam principles: one owner per complaint, a shared record, and who decides when the branch and the centre disagree. If you have a disagreement story with a peer, tell it. If none comes to mind, say so, then give the nearest: the branch log, and how you would raise a disagreement with the contact-centre lead. | Peer Evaluator. The seam is the JD's "across branches and the contact centre". |
| C6 | "When a complaint fix needs three teams, how do you decide who keeps hold of it?" | VAL | [generic] | Own the Fix: name one owner and the point at which the fix counts as solved. Say what you would do if the owner stopped acting. Tell a story only if you have one. | Own the Fix is one of the four panel values. |
| C7 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What should happen to a complaint that starts in the app?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Plan, not past: a complaint still needs one owner, whichever channel it came in through. Say what you would need from digital, such as data on where members drop out of a journey. Your work with digital teams is answer slot F6, not this question. | The recruiter's own brief is the raising source. F6 is discovery, so do not describe digital work you have not done. |
| D1 | "A member's complaint about a declined card has sat in a branch for six weeks. They have called the contact centre twice and now say they will take it outside. You have the case. Walk us through your first twenty minutes." | CASE | [generic] | Structure: clarify what the member has been told and what the record shows. Name the objective. Decide the owner and the deadline. Say what the branch and the contact centre each do next. Write the member's message in plain words. Say what you would record and report. Think aloud and challenge one premise. Do not claim you have handled a case like this. | The panel's escalation case, in a generic form. The scenario is invented, not an Ashgrove fact. It tests structure, the end-to-end ownership, and the values together. |

---

## Values cheat sheet

The four values are scored in the panel, and they run through round 2 as well. None of your sentences carries a values story yet, so each row is a selection scaffold ending in an honest branch.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: B1. Nearest sentence, F3: "I handled the branch's formal complaints log". If no such time comes to mind, say so plainly, then give the nearest thing your material carries. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Scaffold: B2. Nearest sentence, F5: "trained new tellers on our escalation script". If none comes to mind, say so, then give that. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: B4. Nearest sentence, F3: "I handled the branch's formal complaints log". If none comes to mind, say so, then give that. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold: B3. Nearest sentence, F7: "I built the monthly complaints spreadsheet our regional manager uses". If you found nothing to fix, say so, then give that. |

---

## Reverse questions

Each one has a reason it lands. None is generic.

1. **"Where does complaint ownership sit today between the branches and the contact centre?"** It tests the job description's "end to end" in one question and shows you read the role as a system.
2. **"As the branch network moves to five hubs over 2027, what happens to complaints from members at the branches that close?"** It ties your questions to the strategy brief you were sent, and it is a question the people who wrote it can answer.
3. **"As digital takes a larger share of member service, which complaint measures does the Head of Member Services watch first?"** It links reporting to strategy and asks what your manager cares about.
4. **"What does a good first ninety days look like for this role, and what would have to be true by day ninety?"** It frames the role as ownership, not a list of tasks.
5. **"When a branch supervisor escalates a case to you, what does a good outcome look like for the member and for the supervisor?"** It covers the coaching line in the job description and shows you think about both sides.
6. **Reciprocity, for the branch managers on the panel: "What would help your branch most from the person in this role in the first month?"** It puts you in the position of a contributor to their work, which is how a peer conversation starts.

---

## Sources

**Provided documents**
- The job description, as you sent it.
- The Ashgrove values, copied from ashgrovecu.org/about/values and pasted in your message.
- The 2026 strategy brief, as you summarised it from the recruiter's copy.
- The round format, from the recruiter's email. This is the only source for it.
- Your background, from your message.
- No dossier was present.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** Every target was either fixed by the inputs or had no name to search for, so no search ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The values text you pasted fixes it. Not checked against the live page. |
| 2. Ashgrove interview process, member services | skipped | Loop structure. The recruiter's email fixes the three rounds, their lengths and the panel. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and CO questions. The strategy brief you pasted fixes current priorities. Not checked against the published brief. |
| 4. Interviewer name with Ashgrove | n/a | No interviewer names were given, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

**Verify before you rely on these**
1. The values wording, against ashgrovecu.org/about/values.
2. The strategy numbers (40%, eight to five, Q1 2027), against the published brief rather than the summary.
3. The round format and the case format, with the recruiter. The escalation case in D1 is a generic example, not Ashgrove's own.

---

## Upgrade menu

- Hours you can spend before 4 December → a prioritised prep schedule, keyed to B6, B7, C1 and D1.
- The spreadsheet itself, or a sample of what it recorded → F7 and F8 move from medium confidence to high, with an inspectable artifact, and C1 to C3 get exact answers.
- The rules and timescales that governed the formal complaints log, and who set them → B8 becomes a story map instead of an answer slot.
- Interviewer names for rounds 2 and 3 → personas weighted per member, an interviewer read, and a reverse question tailored to their path.
- Any written focus or graded deliverable from the recruiter → a build section for it.
- A deeper research pass at L2 (live values page, recent news, leaders' talks), at most 6 more searches and 2 more fetches, a few minutes → a checked grounding brief and sharper CO questions.
- A tuesday-dossier.md from earlier prep → the prohibited list and the highest-ROI objection come from verified evidence, not from this pack's own reading of your message.
