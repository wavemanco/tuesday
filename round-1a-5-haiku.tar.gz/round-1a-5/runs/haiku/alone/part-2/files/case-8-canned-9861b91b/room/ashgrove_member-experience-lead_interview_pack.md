# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Three rounds on 4 December 2026, so this is a loop pack: one shared fit snapshot, then a mini-pack per round. Built 25 November 2026. No interviewer names are assigned yet. No CV was supplied, so your own sentences in your message are the only evidence base; every claim about your past below traces to one of them.

## How to use + type key

**Personas** are how a question is asked. **Types** are what is being scored.

- **VAL**: behavioural and values. Does past behaviour show a value Ashgrove has published?
- **EXP**: experience deep-dive. Do your claims survive a follow-up?
- **JD**: role requirement. Can you do what the listed job asks, gaps included?
- **CO**: company and strategy knowledge. Do you think at the company's level?
- **CASE**: a live problem from the role, worked aloud.

Guidance is scaffolding, not a script. Speak the beats in your own words, and do not memorise a sentence you could not defend under a second question.

Two cell types appear. A **quote** in the Provenance column is a sentence you wrote or the company published. An **answer slot** is an instruction for the interview: answer whichever branch is true for you. A slot is not a question to me, and nothing in it asks you for a reply here.

## Fit snapshot

Shared across all three rounds. The Requirement column quotes the job description. The Evidence column quotes only your sentences, each followed by its source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log, not the end-to-end process. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on stages beyond the log likely. If you set any stage beyond the log, say which and how you decided; if you did not, say so and stay with the log. |
| F2 | The contact-centre part of F1 (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked in a contact centre." Then how you would learn the contact-centre side, as a plan and never as a past. No claim to contact-centre work. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material says tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If you coached a supervisor on an escalation, say what happened in your own words; if you have not, say so and say how you would start. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material shows a monthly spreadsheet, not which measures it held. Answer slot: the JD's reporting line makes a probe on the measures likely. If the spreadsheet counted volumes or resolution times, say which and how it counted them; if it did not, say so and say which you would count first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The sentence does not name the tool, so the pack does not name it either. Answer slot: the JD names Excel. If you built it in Excel, say what it does, in your own words; if you used another tool, say which. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal log, not whether its complaints were regulated. Answer slot: the JD's regulated line makes a probe on the rules the log had to meet likely. If the log had timing or reporting rules, say which and how you met them; if it had none, say so plainly and describe how the formal log ran. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | The length of experience is met in your own words; it is not a gate. Words, with only the quote reworded: "I have six years in retail banking, the last three as a branch supervisor." Stated, not inspected, so expect a probe on the customer-operations side. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan and never as a past. No claim to presentation experience above regional level. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, and the silence is not a stated absence. Answer slot: the JD's digital line makes a probe on self-service work likely. If you worked with a team on a customer-facing channel or a self-service change, say what your part was in your own words; if you did not, say so plainly. |

**Routing note.** The gap type follows the evidence cell. F1 and F3 are transferability because the quote is adjacent work that does not reach the requirement. F2 and F8 are capability because you stated the absence. F4, F5, F6 and F9 are discovery because the material touches the requirement without showing whether it reaches it. F7 is presentation because the quote already reaches the requirement in other terms. None of the four requirements that are a length of experience, a tool or a skill is a gate; no row here is hard_gate.

## Prohibited list

Shared across all rounds. These are the claims this pack will not coach, with their basis. Each entry gives the honest form you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches and the contact centre | Inflated form of F1 and F2 | "I handled the branch's formal complaints log." The material says one branch's log, not the end-to-end process or the contact centre. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." The material says tellers. |
| Has worked in a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No answer slot. |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No answer slot. |
| Handled regulated complaints | Inflated form of F6; the log is formal, regulation is not stated | "I handled the branch's formal complaints log." Whether it was regulated is an answer slot, not a claim. |
| Reported volumes and resolution times each month | Inflated form of F4; the measures are not stated | "I built the monthly complaints spreadsheet our regional manager uses." The measures are an answer slot. |

## Grounding brief

**Built from your summary of Ashgrove's July 2026 strategy brief, not from the brief itself.** I have not checked it online, so use these as the current framing and check the exact wording against the brief.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

The first two matter most for the complaints role: digital shift changes where complaints come from, and the hub consolidation changes who owns an open case when a branch closes. Those are the two CO and CASE rows built on them (B3, B6).

---

## Round 1: recruiter screen, 30 minutes

**Persona weights.** Relationship prior for a recruiter screen is conversational, with a light skeptic. Conversational carries six rows, one over the 4 to 5 guideline, because four of them are the recruiter's logistics questions, which are asked in the same friendly register. Skeptic-light carries one row. The bank is shorter than the loop guideline because a 30-minute screen cannot carry more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (6) | Friendly openers, the background arc, pay, notice, location and the reason for leaving | High. A recruiter screen is run in this register, and those four logistics are the ones a recruiter always asks | Practise a 90-second background arc; give the logistics plainly and once |
| Skeptic, light (1) | One short probe on the contact-centre gap | Medium. The JD's contact-centre line is the first place a recruiter checks fit | Plain acknowledgment, then the nearest true thing, then a plan |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Speak the beats your sentences state, in order: six years in retail banking, the last three as a branch supervisor; the formal complaints log; the tellers' escalation training. Stop at about 90 seconds. Do not add a team, a result or a title the sentences do not carry. | The opener sets what the rest of the loop will test. F7, F1 and F3 are the claims it rests on, and each must be one you can defend in round 2. |
| A2 | "Why Ashgrove, and what do you know about us?" | CO | [grounded] "we decide from the member's side of the counter" (the values page you pasted) | Name one value that matches your own reason, quoting it exactly. Then one strategy point from your reading, presented as a question you would ask rather than a verdict on it. Do not claim you know the branch network beyond what you read. | Recruiters check whether you read the material. Overclaiming knowledge is the most common slip at this stage. |
| A3 | "The role covers the contact centre as well as the branches. What's your experience of the contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest true thing, "I handled the branch's formal complaints log". Then how you would learn the contact-centre side in the first 90 days, as a plan. Stop there. | F2 is a stated absence, so this is a plain acknowledgment with no slot. The interviewer's question comes from the JD's own line, so the premise is raised, not supplied by the pack. |
| A4 | "What are your pay expectations?" | JD | [generic] logistics slot; no pay figure is in your material | Have your own number ready, or ask for the role's band first. Give a figure only if you choose to, in your own words. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a logistics slot. The pack supplies no figure and no range, and nothing here asks why the figure is what it is. |
| A5 | "When could you start, and what is your notice period?" | JD | [generic] logistics slot; no notice period is in your material | Give your actual notice period, in your own words, and the earliest start date you can honestly commit to. | Notice is a logistics slot. It is answered from your own facts only. |
| A6 | "Where would you be based, and what travel would the role need?" | JD | [generic] logistics slot; no location is in your material | Answer with your own constraints only. The 2027 hub changes may come up here; if they do, say what you would need to know before you could answer. | Location is a logistics slot. The hub consolidation makes it more likely to be asked, but the pack does not say where you should be. |
| A7 | "Why are you looking to move on?" | EXP | [generic] logistics slot; no reason for leaving is in your material | Give your reason in one sentence, in your own words, true and specific. Do not criticise the employer you are leaving. | Reason for leaving is a logistics slot. The pack supplies no reason. |

**Reverse questions (round 1)**

1. "What does the 20-minute case look like: a written scenario, or a live complaint?" Why it lands: it shows you read the agenda closely, and it gets the format before the panel.
2. "Who else will I meet after this, and in what order?" Why it lands: it shows you are planning the loop, and it confirms the Head of Member Services round is still on.
3. "How is the panel's scoring against the four values recorded?" Why it lands: it names the values round the recruiter email described, and it tells you how a value is scored.
4. "When is the pay range set, relative to the offer?" Why it lands: a reasonable question on a logistics topic, and it gives you the answer to A4 without your giving a figure.
5. "What does a good first 90 days look like for this role?" Why it lands: it turns the screen into a conversation about the role's real work, and the recruiter's answer shapes round 2.

---

## Round 2: Head of Member Services, 45 minutes

Your manager, and mostly behavioural. This is the hiring-manager round: the prior is case and skeptic, and the brief says behavioural, so the bank leans behavioural and skeptic.

**Persona weights.** Skeptic carries four rows, the top weight, because a hiring manager is buying capability and checking the gaps. Behavioural carries two. Case carries two, one of them the hub problem from the strategy brief. Prober carries two, because the monthly spreadsheet and the regulated-complaints claim are the two places this interview will check your numbers and your scope.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4) | Presses on the contact centre, senior presentation, the tellers-not-supervisors gap and what was yours | High. These are the three JD headline requirements you have stated absences or narrow evidence for | Plain acknowledgment first, then the nearest true thing, then a plan; hold two follow-ups, then concede the exact scope |
| Behavioural (2) | "Tell me about a time…" on holding a complaint and on telling a leader something unwelcome | High. The round is described as mostly behavioural | Selection scaffold, with the honest branch when no story fits |
| Case / Strategist (2) | Digital shift and hub consolidation, applied to the complaints process | Medium to high. The manager owns the roadmap the brief describes | Clarify, then structure, then name a first step you can defend |
| Prober (2) | The spreadsheet's measures and the log's rules | Medium. These are the claims a manager checks against what you say | Name what you know and what you do not; no figures you were not given |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers complaints that come through the contact centre, and you haven't worked in one. Where does your experience stop?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); [grounded] "across branches and the contact centre" (JD) | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest true thing: "I handled the branch's formal complaints log." Then a 90-day plan: learn how a complaint moves from the branch to the contact centre, walk one case end to end, and meet the people who work it. Hold through two follow-ups by returning to the log. Concede the exact scope: "I don't yet know how complaints are routed in the contact centre." | This is the most predictable objection to you and the deepest rehearsal in the pack. The JD's own scope line raises it, and F2 has no story to add, so the honest answer is the acknowledgment plus a plan. Rehearse it until the acknowledgment is short and unembarrassed. |
| B2 | "Tell me about a time you presented to senior leaders." | JD | [grounded] "I've never presented to anyone above regional level." (your message); [grounded] "confident presenting to senior leaders" (JD) | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you have presented to the regional level, say who was in the room and what they decided, in your own words; if not, say so, then how you would prepare for a senior audience, as a plan. Hold for one follow-up, then concede the scope. | F8 is a stated absence. The question is an open prompt from the JD's own line, so it supplies no event; the second branch allows the honest answer. |
| B3 | "The bank plans to move 40% of member service to digital channels by 2028. What does that do to complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the 2026 brief) | Name what stays the same: complaints still arrive, through a different channel. Name the data you would ask for first to see where they come from. Do not describe digital work you have not done (F9). Do not forecast a number. | The brief's first priority. Case/Strategist probe. The digital side of the complaints role has no evidence in your material, so the guidance stays with the questions you would ask, which is honest and still shows thinking. |
| B4 | "Walk me through the monthly complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Speak the three facts the sentence states: you built it; it is monthly; your regional manager uses it. Answer slot: the JD's reporting line makes a probe on the measures likely. If it counted volumes or resolution times, say which and how it counted them; if not, say so plainly and say what you would count first. Do not name the tool unless you used it. | F4 and F5. A Prober asks about the measures first. Stopping at the three facts is the strongest position, because it is the only one the material supports. |
| B5 | "Which rules, if any, governed the timing of the formal complaints in that log?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "experience handling regulated complaints" (JD) | Answer slot: if timing or reporting rules governed the log, say which and how you handled them, in your own words. If none did, say so plainly and describe how the log ran. Do not name a regulator or framework the material does not name. | F6. The question asks which rules; the second branch allows that there were none. This is the regulated-complaints requirement tested directly. |
| B6 | "Eight branches become five hubs during 2027. What happens to open complaints when a branch closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the 2026 brief); [generic] the structure of the answer | Clarify first: which complaints are open, and whether the member keeps the same contact. Then name the risks: complaints in transit, members who rely on a particular person, staff who know the town. Then one first step you can defend: a list of open cases before any closure, one owner per case, and the member told in plain words. Think aloud for about two minutes. | The brief's second priority, and the one most directly about the complaints process. Case/Strategist scores the structure; the first step is where the Values round will look for Own the Fix. |
| B7 | "Tell me about a time you kept hold of a complaint until it was actually solved." | VAL | [generic] open prompt; nearest quote: "I handled the branch's formal complaints log" (your message) | Selection scaffold: a complaint that stayed with you until the member's problem was fixed, and a moment you could have passed it on and did not. If no such case comes to mind, say so plainly, then give the nearest thing your material carries: the formal log you handled, and what you did with any open items. Do not invent the outcome. | Own the Fix. No quoted sentence carries a decision story, so this is a scaffold with an honest branch, not a mapped story. |
| B8 | "You trained new tellers. Why would branch supervisors take coaching from you?" | JD | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "coach branch supervisors on escalations" (JD) | Hold: say the sentence once, then what you would rely on in coaching: the script and the escalation route. Hold through two follow-ups by returning to the sentence. Concede the scope of the sentence: the training was for tellers. Do not add a supervisor example. | F3, transferability. The skeptic's question is the one the JD's coaching line sets. A held position that is true is stronger than a bigger one you cannot back. |
| B9 | "Tell me about a time you told your regional manager something they did not want to hear." | VAL | [generic] open prompt; nearest quote: "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Selection scaffold: a moment you disagreed with a leader who had a stake, what you said, and whether the working relationship held. If none comes to mind, say so plainly, then describe how you would raise a hard point using the spreadsheet's numbers, as a plan. | Values and behavioural; the Members First value is the one a leader's unwelcome truth most often tests. |
| B10 | "The regional manager uses your spreadsheet. How much of its value was really you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Hold: say what you built, and that your regional manager uses it. Concede the scope precisely: what the manager does with it is theirs. Do not claim its use beyond the word "uses". | Attribution. The sentence supports "built" and "uses", and nothing else; the honest answer is the sentence's own scope. |

**Reverse questions (round 2)**

1. "Which complaint measure would tell you in 90 days that I'm working?" Why it lands: it asks for the success test, so you can plan to it, and it makes the manager describe a target.
2. "How does a complaint move from a branch to the contact centre today?" Why it lands: it targets the gap in B1, shows you have thought about the handoff, and gets a true answer you can use.
3. "When the hubs change, who will own an open complaint?" Why it lands: it links to B6, and the answer tells you whether the role owns the transition.
4. "What does a good branch escalation look like from your side?" Why it lands: it asks the manager to define the standard you would coach to, which is useful in round 3.
5. "What did the last person in this role leave unfinished?" Why it lands: it asks for the real backlog, which a manager will answer more honestly than a job description.

---

## Round 3: values panel with a 20-minute case, 60 minutes

Two branch managers. The recruiter's email says the panel is the values round and scores against the four values, so the values cheat sheet below lives here.

### Values cheat sheet

Ashgrove's four values, from the page you pasted on 25 November 2026. For each, the working meaning is my paraphrase. The story column maps a value to a sentence you wrote only where one of your sentences carries a decision; none of your four does, so every row is a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Your mapped story, or selection scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold. Pick a complaint where the easier decision for the branch and the better one for the member differed, and say what you chose. If none comes to mind, say so, then give the nearest thing your material carries: "I handled the branch's formal complaints log" (F1). |
| Plain Words | If a member needs it explained twice, the letter was wrong. | Scaffold. Pick a letter or message you made clearer, and say what you changed. If none comes to mind, say so, then rewrite a letter live. The spreadsheet sentence (F4) carries no plain-language decision, so it is not offered as the story. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold. Pick a case where the branch's local context changed how you handled it. If none comes to mind, say so, then say how you would keep a town's members in view when a branch becomes a hub. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold. Pick a problem you found that was not yours, and say how you kept hold of it. If none comes to mind, say so, then give the nearest thing your material carries: "trained new tellers on our escalation script" (F3) and what you would do about an open item. |

### Persona weights

Relationship prior for a panel is to blend the top two personas of each member's relationship. Both members are branch managers, so the blend is values-behavioural and peer, with case and pressure for the 20-minute case and the composure test. Values/Behavioral carries four rows, the top weight, because the recruiter says the panel scores the four values. Case/Strategist carries three, the 20-minute case and two CO rows built on the brief. Peer Evaluator carries two, because branch managers test the seam between branches and the contact centre. Pressure carries two, because your two stated absences are the likeliest thing a panel holds you to.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (4) | Scenario probes mapped to the four values; stories in STAR shape | High. The recruiter says the panel scores the four values | Map a story where a quote carries one; use the selection scaffold and its honest branch where none does |
| Case / Strategist (3) | The 20-minute escalation case; a diagnosis of slow complaints; the app-only competitor | High. The case is announced; the other two come from the brief | Clarify, then objective, then sequence, then the first move; think aloud |
| Peer Evaluator (2) | Where the seam is between a branch and the contact centre; supervisor escalation | Medium. Two branch managers will test the seam they share with you | Name the seam as a principle, not a fact about their team |
| Pressure (2) | Challenges your two stated absences; asks what was yours | Medium. A panel tests composure against the gaps it can see | Hold, then concede the exact scope; never fold on a true claim |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | The 20-minute case: "A member has complained twice about a branch decision and is now asking to escalate. Walk the panel through how you would handle it." | CASE | [generic] the scenario is a pattern for a complaint escalation; raising source: the recruiter's "a 20-minute case on a complaint escalation" | Clarify first: what the member was told, what the decision was, and whether the branch has a response deadline. The objective is to resolve the member's problem, not defend the branch. Then the sequence: check the file; decide who owns the fix (Own the Fix); speak to the member in plain words; agree a date; record what changed; escalate only if the branch cannot fix it in-branch. Think aloud. Leave five minutes for your questions. | The format the recruiter named. The scenario is generic, so the guidance makes no claim about your past. |
| C2 | "Tell me about a complaint you decided from the member's side of the counter." | VAL | [generic] open prompt; nearest quote: "I handled the branch's formal complaints log" (your message); [grounded] "we decide from the member's side of the counter" (values page) | Selection scaffold: a complaint where the easier branch decision and the better member decision differed, what you chose, and what the member said back. If none comes to mind, say so plainly, then give the nearest thing your material carries, and what you decided on any single entry, in your own words. Do not invent the outcome. | Members First. No quoted sentence carries a decision story, so this is a scaffold. |
| C3 | "A member has had to ask us twice for the same thing. How would you rewrite the letter they got?" | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page) | Show one rewrite: the same content in the shortest plain words, read aloud. Apply the test: if a member would need it explained twice, it is not done. If you have rewritten a letter before, say so and what you changed; if not, do the rewrite live. | Plain Words. The rewrite is the proof, so the guidance asks you to show it rather than describe it. |
| C4 | "When a branch closes, how does it stay part of its town?" | VAL | [grounded] "every branch is part of its town" (values page); [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the 2026 brief) | Scaffold: name what a town loses when a branch closes, what its members still need, and one way the hub keeps them in view. Do not claim you have done this before. | Neighbours, Not Numbers meets the hub consolidation. The question is a live problem, so the guidance makes no claim about your past. |
| C5 | "Tell me about a problem you found that was not yours to fix. What did you do with it?" | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values page); [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold: a problem you found that belonged to another team, and how you kept hold of it until it was solved. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script training (F3), and how you would keep hold of a problem outside your remit. | Own the Fix, the value the panel is most likely to test with an ownerless problem. The honest branch matters more here than any story. |
| C6 | "The main competitive pressure is app-only banks. What does a member-owned credit union offer that an app cannot?" | CO | [grounded] "the main competitive pressure is app-only banks" (your summary of the 2026 brief); [grounded] "every branch is part of its town" (values page) | Name one thing a member-owned branch does that an app does not, as your view, tied to the value. Say what you would measure to know whether it is true. Do not claim anything about Ashgrove's data. | Case/Strategist. The competitive frame from the brief, answered from the values rather than from numbers you do not have. |
| C7 | "Suppose your branch had the slowest complaint times in the region. What would you change first?" | CASE | [generic] hypothetical; no claim about your branch | Clarify first: which stage is slow, intake, investigation or response. Then diagnose before changing anything: check the queue by age and by stage. Then one first move you can defend. Think aloud. | Case/Strategist. The question is hypothetical, so it presupposes nothing about your past. |
| C8 | "A supervisor keeps escalating complaints you think they could settle. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "coach branch supervisors on escalations" (JD) | Answer slot: if you coached a supervisor on an escalation, say what you did and what happened, in your own words; if you have not, say so, and how you would start: first hear the supervisor's reasons, then agree which escalations the script lets them settle. | F3. The panel's version of the coaching requirement. The second branch allows that you have not done it. |
| C9 | "Our teams sit side by side. Where is the seam between a branch and the contact centre, and what happens when you disagree?" | Peer | [generic] persona stem; no claim about any team | Name the seam as a principle: who owns a complaint at the handover, and who decides when the branch and the contact centre disagree. Propose a rule rather than claiming to know their process. | Peer Evaluator. The seam is a live problem, so the answer needs structure, not history. |
| C10 | "You haven't worked in a contact centre, and you haven't presented above regional level. Why should this panel trust your judgement?" | Pressure | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level." (your message) | Hold: answer with the complaints work you did do, the formal log (F1). Hold through two follow-ups. Concede the two negatives in your own words if pushed: "I haven't worked in a contact centre, and I haven't presented above regional level." Do not fold on the log. | Pressure. The panel can see both gaps, so the test is whether you hold the true part without becoming defensive about the rest. |
| C11 | "Which part of the formal complaints log was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Say which part you handled, in your own words. If others worked the log too, name them only as far as you know, and do not assign a share you cannot back. | Attribution. The sentence supports "handled" and nothing more, so the honest answer stays at its scope. |

**Reverse questions (round 3)**

1. "What does a branch do with a complaint it cannot resolve on its own?" Why it lands: it shows you are thinking about the escalation boundary the case tests, and the answer shows the panel's real process.
2. "Which escalation this year took longest to close, and what slowed it?" Why it lands: it asks for the real example the panel will remember, and invites them to describe a problem they are still working on.
3. "What could a new person do in their first month that would genuinely help your branch?" Why it lands: this is the reciprocity question for peers. It shows you are asking what you can bring, not only what you need.
4. "When a branch and the contact centre disagree about a complaint, who decides?" Why it lands: it names the seam in C9 directly and gets the panel's actual rule.
5. "How would you know, from a complaint letter, that Plain Words had been met?" Why it lands: it links the value to a test the panel uses, and it shows you read the values page.

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, B7, C1 |
| Report monthly on complaint volumes and resolution times | B4 |
| Coach branch supervisors on escalations | B8, C8 |
| Work with digital teams on self-service journeys | B3 covers the strategy side only. No question asks about working with a digital team, because fit row F9 has nothing to answer from. Upgrade by adding an example (see the upgrade menu). |
| 4+ years in financial-services customer operations | A1, B1 |
| Experience handling regulated complaints | B5 |
| Confident presenting to senior leaders | B2 |
| Comfortable with Excel reporting | B4 (the spreadsheet); F5 stays low until the tool is named |
| Values round (four published values) | C2, C3, C4, C5 |

Strategy: B3, B6 and C6 are built on your summary of the brief.

---

## Sources

**Provided documents.** Nothing outside them was used.

1. The job description, pasted in your message.
2. Ashgrove's four values, from your paste of ashgrovecu.org/about/values, copied 25 November 2026.
3. The recruiter's email: three rounds on 4 December; the panel is the values round.
4. The 2026 strategy brief, your summary of it only. The brief itself is not in hand.
5. Your background, in your message.

**Searches and fetches.** None were sent.

**Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes it. It feeds the values cheat sheet in round 3 and A2 and C6. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes it. It names the three sessions, who runs each, and that the panel is the values round. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the framing. It feeds the grounding brief and B3, B6, C6. The brief itself is not in hand, which the upgrade menu offers to fix. |
| 4. Interviewer public footprint | n/a | No interviewer name was given, so no query could be formed. The upgrade menu says what a name would unlock. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- Your prep hours before 4 December → a day-by-day prep schedule in place of the default full pack.
- The recruiter's case brief or sample complaint → C1 and the complaint-escalation rows move from generic to grounded in the actual case.
- The full 2026 strategy brief, pasted → B3, B6 and C6 cite the brief itself, not your summary, and the grounding brief can be checked against it.
- The Head of Member Services' name and the two panel members' names → persona weights from their public footprint, and reverse questions tailored to their paths.
- Your CV → any line beyond these notes becomes a fit row, and quotes can come from the document itself.
- A sanitised sample of the monthly spreadsheet, with no member data → F4 and F5 become inspectable. F5 can move from low once the tool is named.
- Any figure from the complaints log, with how it was counted → defend-the-number slots, which you answer in your own words.
- An example of working with a digital team → F9 gains evidence, and the digital requirement gets its own question.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would look for recent loop reports and recent organisation news. Want it?
- A tuesday-dossier.md, if you have one → its verified evidence and prohibited claims replace this pack's local prohibited list.
