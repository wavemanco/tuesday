# Stripe, Product Operations Manager: final-round prep pack

Interviewer: not given. Relationship: not given, so personas use a blended final-round weighting (flat, noticeably weaker than a pack built on the round type). First version, so no changelog.

**What this pack is built on:** the company and role from your message. No CV, no job description, no round details, and both web searches were refused by the host. So there is no Stripe-specific content here: no published values, no loop structure, no current strategy. Every question is a generic product-operations question, and every story has to come from you.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive; whether what you did survives scrutiny
- **JD**: role-driven; can you do the listed job, gaps included
- **CO**: company and strategy knowledge (none in this pack, see the limits above)
- **CASE**: live problem, structured on the spot

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot (worksheet variant)

No requirement is quoted from a JD, because none was supplied. The rows below are the role-family requirements every product-operations role carries, written as plain prose. Each evidence cell reads `none given`, so every row is a worksheet row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run operating cadence and planning across teams [generic] | none given | none | [generic] | discovery | Strong evidence looks like one planning cycle you ran end to end: who was in it, what got decided, what changed. Answer slot: if you have run a planning or operating cycle, say how, in your own words; if you have not, say so plainly and say how you would learn it. |
| F2 | Manage programs that cross several teams [generic] | none given | none | [generic] | discovery | Strong evidence looks like one cross-team program with a named start, a named finish and a named decision you made or influenced. Answer slot: if you have run one, say which and what your part was; if not, say so plainly and say which program you would learn from first. |
| F3 | Define and report on metrics for a process or product area [generic] | none given | none | [generic] | discovery | Strong evidence looks like one metric you chose, how you counted it, and who acted on it. Answer slot: if you have reported a metric, say what it was and how it was counted; if you have not, say so plainly and say what you would measure first. |
| F4 | Design a process and get people to adopt it [generic] | none given | none | [generic] | discovery | Strong evidence looks like one process you changed and what happened after people started using it. Answer slot: if you have changed a process, say what and what people did with it; if you have not, say so plainly and say how you would test adoption. |
| F5 | Communicate clearly with senior stakeholders [generic] | none given | none | [generic] | discovery | Strong evidence looks like one update or decision memo you wrote for someone senior and what they did with it. Answer slot: if you have done this, say to whom and what the outcome was; if you have not, say so plainly and say how you would prepare. |

**Gap rule:** you have not stated any absence yet, so the pack shows no gap as a fact. The pack's own observation is that your material does not show any of these. Adding a CV or a few bullets turns these rows into quoted rows.

## Prohibited list

No quoted sentence about your past exists yet, so the pack cannot build an inflated form of one. This list is therefore short and blunt.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about a past role, metric, tool, program or outcome | The pack's own observation: no sentence about your past has been supplied | Answer slots only. Paste your CV or a few bullets and this list gets specific |

## Persona table

| Persona | How it shows up | Likelihood and reasoning (weight) | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on operations work: plan this, diagnose that | High (5 questions). Final rounds lean on structure, and the role is judged on how you think through ambiguous operations problems | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case |
| Data-Driven Prober | Asks how a number was counted and what it rests on | High (4). Product ops lives on metrics, so any number you give gets opened up | Say plainly what you know about how each number was counted. Name the weakest assumption before they do |
| Skeptic | Quiet, persistent probing of gaps and motive | Medium (3). Without a CV, the likely gap is "why this role from where you are" | Calibrated candor. Name the weakest area, then a concrete ramp plan |
| Peer Evaluator | Seams between teams, credit, disagreement | Medium (3). A final round usually includes someone who works beside the role | Propose seam principles, not invented seams. Reciprocity: what you bring their team, not only what you need |
| Values / Behavioral | Scenario probes for how you have behaved | Lower (2). No published values were retrieved, so these questions are generic | Selection scaffold: pick a real moment. If none comes, say so, then give the nearest one |
| Pressure / Stress | Time-boxed challenge to a position | Lower (2). Common in final rounds with senior people | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational / Rapport | Friendly openers that are still scored | Lower (2). Casual questions are still scored | Keep a 90-second arc ready for the "walk me through it" opener |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Merchant dispute responses have slowed over the last quarter. How would you find out why, and what would you do first?" | CASE | [generic] | Clarify what "slowed" means and for whom. Set one objective. Segment the problem (by team, by dispute type, by time). Propose one approach and the metric that would show it working. Name one risk. Say your first step aloud before the second | Live problem from the operations domain. Tests structure, not an answer |
| A2 | "Three teams disagree on the scope of a launch next month, and you have one week to get to one plan. What do you do?" | CASE | [generic] | Ask who owns the decision and what is non-negotiable. List the options and the criteria for choosing. Pick one and say why. Name the risk you accept by picking it | Tests decision-making under conflict. Hiring-manager style |
| A3 | "Sketch how you would set up an operating review for a product area that has no metrics today." | CASE | [generic] | Start with the decisions the review must support, then the few metrics that inform them, then the cadence and who attends. Say what you would leave out on purpose | Tests whether you start from decisions, not dashboards |
| A4 | "Pick one thing in an operations function like ours that could measurably get faster. Why that one?" | CASE | [generic] | Pick one, name why it matters, and say what you would need to know before committing. A reason beats a list | Tests prioritization judgment |
| A5 | "How do you decide what process to build, and what to leave alone?" | JD | [generic] | Name the test you apply (cost of the problem, how often it recurs, who it hurts). Say when you would deliberately not build one | Generic product-ops requirement. The JD would sharpen this if you paste it |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you own that you trust least. How was it counted?" | EXP | [generic] | Selection scaffold: pick a metric you actually reported or owned. Say how it was counted and the assumption you would defend least, before they ask. If you have no such metric, say so plainly, then describe the nearest number you worked with | Open prompt. Probers open numbers to their assumptions, and a trusted-least metric shows that you know which ones are soft |
| B2 | "Tell me about a time an operations metric moved and you had to explain why. What did you check before you believed it?" | EXP | [generic] | Selection scaffold: pick a real moment. Name what you checked (data quality, a comparison, a second source). If nothing like this comes to mind, say so plainly, then describe how you would check a metric move | Open prompt. Tests whether you verify before you explain |
| B3 | "What is a number you have put in front of leadership, and what could make it wrong?" | EXP | [generic] | Selection scaffold: pick one number you presented. State what it measured, what it did not measure, and one way it could mislead. If you have presented no number, say so plainly and say what you would present first | Open prompt. Same shape as B1, asked as a reporting question |
| B4 | "How would you tell whether a process you built is working after three months?" | JD | [generic] | Name the outcome the process was for, the leading indicator, the lagging indicator, and what would make you change or drop it. If you have not built a process you could evaluate, say how you would set this up | Generic requirement of the role. Tests outcome thinking |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of a product operations role would you be weakest at on day one?" | JD | [generic] | Name the weakest area honestly and specifically. Then give a concrete ramp plan: what you would learn first, from whom, in what order. Do not bluff a competency you lack | Persona stem. The Skeptic scores calibrated candor, not a flawless answer |
| C2 | "Why this role, and why now?" | EXP | [generic] | Give the reason in your own words, in one or two sentences, then one specific thing about the role that drew you. Keep it consistent with everything else you say in the room | Motivation check. The likeliest probe for a candidate changing function |
| C3 | "Operations roles can be a way to stay near the work without owning it. How do you make sure you own outcomes?" | JD | [generic] | Hold the position: name one outcome you would own and how you would know you owned it. If pressed, concede the part you cannot control, specifically, and say what you would do about it | Pressure-leaning Skeptic. Hold-then-concede structure |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where would you expect the seam with us to be, and what happens when we disagree?" | VAL | [generic] | Propose principles for where the seam sits (who decides what, who is consulted) rather than naming a seam you have not seen. For disagreement, use a real moment if you have one; if not, say how you would handle it | Persona stem. Tests partnership fit with a peer |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name how you share credit in practice: say who, in writing or in the room. Keep it to a behavior you do, not a principle you admire | Peer probe on credit-sharing. Shows whether you do it or only say it |
| D3 | "If you joined next month, what would you need from my team in the first month?" | JD | [generic] | Name two or three things you would need, and one thing you would bring their team. Reciprocity first, then needs | Reciprocity framing. Peer interviewers weight what you bring to their team |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over a stronger-looking candidate?" | JD | [generic] | Pause. Restate the question in your own words. Answer with the one or two things you can say truthfully and specifically. Hold the position through two follow-ups before conceding anything | Persona stem. Tests composure under a time box |
| E2 | "Tell me about a result you are proud of. How much of it was actually yours?" | EXP | [generic] | Selection scaffold: pick a real result. Separate what you did from what the team did, in your own words. If you have no result you are proud of, say so plainly and name the one you can describe most precisely | Persona stem. Tests attribution honesty under pressure |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [generic] | Build a 90-second arc: where you started, two or three moves that mattered, where you are now, why this role. Use only what you can say in your own words. If you have not written it, start with the one role you can describe in full | Persona stem. Casual openers are still scored |
| F2 | "What tools do you use day to day for tracking operations work, and what do you wish they did?" | JD | [generic] | Name the tools you have actually used, and one gap you have felt. Do not list tools you have only read about | Tests tool fluency honestly. Rapport questions are scored too |

### Requirement coverage

| Requirement (generic, no JD supplied) | Covered by |
|---|---|
| Operating cadence and planning (F1) | A3, A4 |
| Cross-team programs (F2) | A2 |
| Metrics and reporting (F3) | B1, B2, B3 |
| Process design and adoption (F4) | A5, B4 |
| Senior stakeholder communication (F5) | C2, E1 |
| Assumption and measurement skepticism | B1, B2 |

**Biggest objection to prepare for:** C1 and C3. A product-ops candidate with no quoted experience is most likely to be pushed on whether they can own outcomes. The rehearsal is to name one real outcome, say how you would know you owned it, and concede specifically where you cannot.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for this role?" | Shows you are planning the job, not just applying for it |
| R2 | "How do operations and product decide what work gets done here?" | Tests the operating model and is a question the interviewer can answer well |
| R3 | "How is the main metric for this role counted, and what do people argue about?" | Mirrors B1 and shows you expect the numbers to be contested |
| R4 | "What is the hardest decision the last person in this role had to make?" | Gets a real story and shows you think about the job's hard parts |
| R5 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity. Peer interviewers weight this heavily |
| R6 | "In six months, how will you know you made the right hire?" | Asks for the success criteria directly |

## Sources

Provided documents: the company name and role from your message. Nothing else.

Searches sent:

| Query | Result |
|---|---|
| Stripe company values principles | refused (host declined the search permission) |
| Stripe Product Operations Manager interview process final round | refused (host declined the search permission) |

Research tier: L1 attempted, searches 0 of 6 (2 refused), fetches 0 of 2 (none sent).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) dropped. Values questions are generic, so the Values bank is weaker |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights are blended, not set from named rounds |
| 3. Stripe strategy / recent news | unavailable | Would have set the CO questions. None are in this pack |
| 4. Interviewer name and company | n/a | No interviewer named, so no query could be formed |
| 5. Representative JD for the role | unavailable | Would have fixed the JD-tagged questions and the fit snapshot rows as quotes |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Your CV or a few bullets on what you actually did → fit snapshot rows become quoted, the EXP questions get story maps instead of selection scaffolds, and the prohibited list gets specific
- The job description → the F rows become quoted requirements, and the generic JD questions get tied to the posting's own lines
- The round type and the format (one interview, or several sessions) → persona weights reflect the round, and per-session mini-packs if the final has several parts
- Retrying the research at L1 → the Stripe values cheat sheet, the loop structure and current strategy questions. Retrying is one line from you
- A deep-research pass (L2) → a grounding brief on the company's current priorities and recent moves
- A tuesday-dossier.md → gaps and stories carried across sessions, and verified evidence in place of the generic rows
