# Ashgrove Credit Union: Member Experience Lead interview pack (Dara)

**Role:** Member Experience Lead, Ashgrove Credit Union
**Rounds, all on 4 December 2026:**
- Round 1: recruiter, 30 min
- Round 2: Head of Member Services, 45 min. Your future manager. Mostly behavioural.
- Round 3: panel of two branch managers, 60 min. Includes a 20-minute complaint-escalation case. The panel scores the four values.

No interviewer names yet, so there is no interviewer read. Built in loop mode: one shared fit snapshot, then a mini-pack per round. No CV came with your message, so your background comes from the sentences you wrote.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is scored.
- **VAL**: values alignment. **EXP**: what you actually did. **JD**: the listed job and its gaps. **CO**: company and strategy. **CASE**: a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | high | [grounded] | presentation | Say it in those words: "Six years in retail banking, the last three as a branch supervisor." Your message does not use the words "customer operations"; leave the link to the interviewer. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material shows formal complaints at branch level. It does not say whether any were regulated. Words: "I handled the branch's formal complaints log." Answer slot: if any complaint you logged carried a regulatory deadline or an external referral, say which and what you did; if none did, say so plainly and describe how the log tracked complaints. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message); "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | low | [grounded] | capability | You stated the contact-centre absence. Words: "I haven't worked in a contact centre." Then the plan, said as a plan: how you would learn how a contact centre works a complaint. Never a claim to end-to-end ownership. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | The sentence shows a monthly spreadsheet. It does not show which measures it holds. Answer slot: if it tracked complaint volumes or resolution times, say which and how you counted them, in your own words; if it did not, say so plainly and say what you would track first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Say: "I built the monthly complaints spreadsheet our regional manager uses." Your message says "spreadsheet", not Excel. If you built it in Excel, name that, and only that. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Your material covers tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone above teller level on escalations, say how; if not, say so plainly and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital teams or self-service. Answer slot: if you worked with any team on a customer-facing digital process, say which and what you did; if not, say so plainly and say how you would learn a self-service journey. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "I've never presented to anyone above regional level." Then the plan, as a plan: how you would prepare for a senior audience. Do not add anything to make the gap feel smaller. |

**Requirement coverage line:** F1 in R1-1. F2 in R2-S4. F3 in R2-S1, R2-S3, R3-5. F4 and F5 in R2-S5. F6 in R2-S6. F7 in R2-C2. F8 in R1-6, R2-S2, R2-S1.

## Prohibited claims

These are the claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the member complaints process end to end" | Inflated form of F3 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material describes a branch log, not an end-to-end process. |
| "I handled regulated complaints" | Inflated form of F2 | F2's quote at its own scope. The slot stays inside the log. |
| "I tracked complaint volumes and resolution times every month" | Inflated form of F4 | F4's quote. Your material does not say which measures the spreadsheet held. |
| "I coached branch supervisors" | Inflated form of F6 | "I trained new tellers on our escalation script." |
| "I've worked in a contact centre" | Negative you stated | Plain acknowledgment: "I haven't worked in a contact centre." No slot. |
| "I've presented to senior leaders" | Negative you stated (F8) | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |

## Persona weights and reasoning

| Round | Relationship | Weights (questions) | Reasoning |
|---|---|---|---|
| 1, recruiter | Recruiter screen | Conversational 4, Skeptic 2 | Priors for a screen. Logistics questions are the knockout checks. |
| 2, Head of Member Services | Hiring manager, mostly behavioural | Values/Behavioral 3, Skeptic 4, Pressure 1, Prober 1, Case 3 | Priors for a manager are Case plus Skeptic. Your recruiter said this round is mostly behavioural, so Values carries the most weight, and Skeptic stays high because the manager is buying the missing competencies. |
| 3, panel | Two branch managers, with values scored and a 20-minute case | Values/Behavioral 4, Case 1, Peer 1 | The panel scores the values, and the escalation case is a case. The peer probe covers the seam between branches and the contact centre. |

| Persona | How it shows up | Counter-strategy |
|---|---|---|
| Conversational | Casual openers, pay, notice, location, reason for leaving | Treat every casual question as scored. Keep answers to 90 seconds. |
| Skeptic | Probes the contact-centre and presenting gaps | Rehearse the plain acknowledgment and the plan until they are boring. |
| Pressure | Tests whether your log sentence is inflated | Hold "I handled the branch's formal complaints log" through two follow-ups, then concede specifically. |
| Prober | Asks what the spreadsheet measured and how | Name the assumption you would defend least before they do. |
| Values/Behavioral | Scenario prompts on the four values | Map a story where your material carries one; otherwise use the selection scaffold and say so when there is none. |
| Case | Live problems on complaints and the hub change | Structure aloud: clarify, objective, segment, approach, metrics, risks. |
| Peer | Seams between branches and the contact centre | Lead with what you would bring to their teams, and propose seam principles rather than facts you do not have. |

## Round 1: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background, the last few years especially." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Open prompt. Say the years first, then the three things your message gives you, in that order: the complaints log, the escalation script you trained tellers on, the spreadsheet. Say no more than those sentences. About 90 seconds. | Opens the screen. F1 is your strongest match, so it goes first. Conversational, but scored on how you choose your facts. |
| R1-2 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | The recruiter screen checks logistics. Your material gives no figure, so the answer is yours. |
| R1-3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot, with two options that name no figure: ask for the band first, or give your own number. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a knockout question. No figure is supplied here. |
| R1-4 | "Where would you be based, and what's your availability?" | JD | [generic] | Logistics slot. Give your location and any constraint in your own words. Do not volunteer more than the question asks. | Location is a screen logistic. |
| R1-5 | "What's prompting the move now?" | EXP | [generic] | Logistics slot for the reason for leaving. Give your reason in your own words. Your material gives no reason, so this one is yours to supply. | Reason for leaving is a recruiter check. The pack cannot supply it. |
| R1-6 | "You haven't worked in a contact centre. What would you do early on to close that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then one sentence of plan, said as a plan: how you would learn how a contact centre works a complaint. Do not describe contact-centre work you did not do. | This is the most predictable objection to you, and the recruiter screen is where it first appears. A light Skeptic check, scored lightly. |

**Round 1 reverse questions**
- "What would a successful first six months look like for this role?" Why it lands: it asks the recruiter what the hiring manager will judge, and you can use the answer in round two.
- "What comes after this screen, and who decides?" Why it lands: it shows you understand the process and are not waiting to be told.

## Round 2: Head of Member Services (45 min, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "Tell me about a complaint that went wrong for a member, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, Members First. The sentence carries two beats: you handled the log, and you knew the escalation script. The member's side is not in that sentence. Answer slot: if a complaint on your log was one where the member's account was not being heard, say what you did; if none was, say so plainly and describe how you handled a complaint from the member's side. | Members First is the value this manager is most likely to score. The prompt supplies no event; the theme comes from the published value. |
| R2-B2 | "You trained new tellers on the escalation script. How did you know they had got it?" | VAL | [grounded] "trained new tellers on our escalation script" | Premised on your training sentence. Plain Words: if you checked understanding, say how; if you did not, say so and say what you would check now. | Plain Words is about explaining something twice. The premise is your quote, so it is lawful. |
| R2-B3 | "Describe a problem you found that wasn't yours to fix, and what you did about it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Own the Fix. Pick a problem you found and stayed with until it was solved. It needs a named problem, the point where you kept hold of it, and how it ended. If the spreadsheet came from a problem you found, say what it was. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the spreadsheet itself. | The manager tests Own the Fix with the "not yours" angle. The spreadsheet is the only thing you built that your material carries. |
| R2-S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment, then a plan: "I haven't worked in a contact centre." One sentence of plan. Do not claim contact-centre knowledge. | The JD's end-to-end remit includes the contact centre. The honest answer is the stated limit plus a plan. This is the highest-ROI rehearsal in the pack. |
| R2-S2 | "You've never presented above regional level. How would you present complaint trends to a senior audience?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare, such as a one-page version and a rehearsal with someone who has presented upward. Describe it as a plan. | "Confident presenting to senior leaders" has no sourced evidence. The honest answer is the stated limit and a plan. |
| R2-S3 | "Of the complaints you handled, how much of the outcome was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log." | Pressure. Hold: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to that sentence. Then concede specifically: the parts of an outcome you did not control, in your own words. Never add ownership of outcomes your sentence does not carry. | Pressure tests inflation. Your log sentence is the claim it will press on. |
| R2-S4 | "When a complaint carries a regulatory deadline, how do you know, and what do you do?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if any complaint you logged carried a regulatory deadline or an external referral, say which and what you did; if none did, say so plainly and describe how the log tracked complaints. | "Experience handling regulated complaints" is what your material touches without reaching. The question is generic and presupposes nothing about you. |
| R2-S5 | "Walk me through the monthly complaints spreadsheet: what it measured, and what you built it in." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Prober. Say what the spreadsheet measured, in your own words, and the tool you built it in. If it held volumes or resolution times, say how you counted them and name the assumption you would defend least. If it did not, say so and say what it did hold. | Covers the monthly-reporting requirement and the Excel requirement together. The weakest-assumption move comes first. |
| R2-S6 | "How would you coach a branch supervisor whose escalations keep coming back?" | JD | [grounded] "trained new tellers on our escalation script"; [generic] the question | Structure it: what you would check first (the escalation step or the decision), what you would do with the supervisor, and how you would see it working next month. Then say what you have done: you trained new tellers on the escalation script. If you have coached anyone above teller level, say how; if not, say so and give your plan. | JD coaching requirement. The question is generic, so it makes no claim about you. |
| R2-C1 | "A complaints dashboard shows resolution times rising in two branches. What do you do in the first week?" | CASE | [generic] | Structure aloud: clarify (is it volume, the mix of complaints, or slower handling?), objective (close the open cases and protect the member's clock), segment by branch and complaint type, approach, metrics (resolution time, reopen rate), risks. Challenge one premise. | A live problem from the monthly reporting in the JD. No claim about you. |
| R2-C2 | "The strategy aims to move 40% of member service to digital channels by 2028. How would complaints handling change for a member who starts online?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Structure: where the complaint enters, who owns it, what the member sees at each step, and what the branch and the contact centre still do. Say what you would check first. Use the brief's own words. | The digital shift is likely to come up, and F7 is your gap. Give structure, not experience you do not have. |
| R2-C3 | "Eight branches are moving into five hubs over 2027. A branch supervisor asks what that means for complaints. What do you tell them?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Structure: what changes for complaint ownership, which decisions stay local, what you would promise and not promise, and who you would report to. Say plainly what you cannot know yet. | Likely to come up. It tests Neighbours, Not Numbers under pressure, and your former peers are exactly these supervisors. |

**Round 2 reverse questions**
- "How do you measure complaints handling today, and which measure would you most want to change?" Why it lands: it shows you will look at the numbers before you decide.
- "What do you need from a Member Experience Lead in the first ninety days?" Why it lands: it asks your manager directly what success looks like.
- "When should a supervisor bring a complaint to you rather than resolve it locally?" Why it lands: it shows you already think about escalation judgment.

## Round 3: branch-manager panel (60 min, values scored, 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you decided from the member's side when the rules said otherwise." | VAL | [grounded] "I handled the branch's formal complaints log." | Members First. Your log sentence is the only thing your material carries, and the decision is not in it. Answer slot: if a complaint on your log was decided from the member's side against the rule, say what it was; if none was, say so plainly and describe how you handled a complaint the rules did not cover. | Members First, scored by branch managers who run the rules. |
| R3-V2 | "When did you put something complicated into plain words, and did it land?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. The training is the nearest story: name what you taught and how you put the script into words a teller could use. If you rewrote the script, say how; if you did not, say so and give the training itself. | The nearest story your material carries. |
| R3-V3 | "Which branch in your area do you think of as part of its town, and how has that changed a decision?" | VAL | [generic] | Neighbours, Not Numbers. Pick a branch whose local context changed a choice you made, what the choice was, and what the number alone would have said. If none comes to mind, say so and say what you would check first about a town. | Values prompt with no claim about your past. Your material has no story for this value. |
| R3-V4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Own the Fix. Use the same story as R2-B3 so you have one account, not two. If the spreadsheet came from a problem you found and held, say what it was and how it ended. If not, say so and give the nearest case. | Same value, scored by a different panel. Consistency across rounds matters. |
| R3-CASE | "A member has complained twice about the same thing. The complaint has passed its resolution time, and the member asks about an external referral. The contact centre passed it back to your branch. What do you do in the next hour, the next day and the next month?" | CASE | [generic]; [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | 20-minute case. Structure aloud: clarify (what is the complaint, which clock is running, who owns it now), objective (resolve it and protect the member's right to refer), segment (branch, contact centre, the hand-back), approach, metrics (time to resolve, repeat contacts), risks (a missed clock, inconsistent answers). Name the hand-back as the point to confirm before you act, and say it plainly: "I haven't worked in a contact centre, so I would confirm the hand-back first." | The case is a live problem from the role. Your gap sits exactly at the hand-back, so name it yourself. |
| R3-PE1 | "Our branches and the contact centre share these complaints. Where is the seam, and what happens when you disagree?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Peer Evaluator. Lead with what your branches need from the contact centre and what you would bring to its teams. Propose seam principles, not facts you do not have. On disagreement: if you have disagreed with a peer team, say how it resolved; if not, say so and give your principle. Name the contact-centre limit only if asked. | Branch managers are peers, and the seam is where your gap sits. |

**Round 3 reverse questions**
- "Where does the seam between branch and contact-centre complaints work best today?" Why it lands: it asks the panel to share their own experience of the seam.
- "What would a new person do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question to peers. It shows you are thinking about what you add to their work.
- "Which branch decisions come before the 2027 hub change, and which come after?" Why it lands: it shows you are thinking about timing, not just the headline.

## Values cheat sheet (panel round)

The panel scores the four values. None of your sentences carries a complete story for any value, so each row uses a selection scaffold that ends in its honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2: "I handled the branch's formal complaints log." It carries no decision. Pick a complaint where the member's side changed the outcome. If none, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | F6: "trained new tellers on our escalation script." Pick the training where you put the script into plain words. If you did not, say so and give the training itself. |
| Neighbours, Not Numbers | Every branch is part of its town. | No sentence in your material carries this. Pick a branch whose local context changed a decision you made (R3-V3). If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F5: "I built the monthly complaints spreadsheet our regional manager uses." Pick a problem you found and held (R3-V4). If none, say so. |

## Sources

- **Provided documents:** the JD text; the values page as you copied it on 25 November 2026; the 2026 strategy brief as the recruiter sent it; the recruiter's email on the three rounds; your background message.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. No searches were sent because the inputs already fix every output the research would have moved.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The values page as you pasted it fixes the values cheat sheet. Not checked against the live site. |
| 2. Interview process | skipped | The recruiter's email fixes the loop. Persona weights follow the three rounds. |
| 3. Strategy and recent news | skipped | The strategy brief you pasted fixes the CO and CASE questions in round two. |
| 4. Interviewer footprint | n/a | No interviewer names were given, so there is no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your complaint figures for one recent month, with volumes and resolution times → defend-the-number rows for R2-S5 and R2-C1, and an exact metric answer.
- Your CV, or the spreadsheet's column headings → F4 and F5 move from `[inferred]` and `[grounded]` to exact measures.
- Any coaching of a supervisor, or any work with a digital team → F6 and F7 slots become stories.
- The names of the Head of Member Services and the two branch managers → an interviewer read, and personas per panel member.
- How many days you have before 4 December → a prep triage with a day-by-day schedule.
