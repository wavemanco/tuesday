# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
**Built from:** the underwriting dossier (decision: conditional_go, dossier_version 1.1, generated 2026-08-14). That is about three months old. If the role, team or squad structure has changed since, tell me and the affected rows will be regenerated.
**Research:** none ran. Both searches were refused (see Sources).

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type tags: **VAL** behavioral or values, **EXP** work-experience deep-dive, **JD** role or JD-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview. Answer it from your own experience in either branch. It asks for nothing here.
- Words in quotation marks are your confirmed sentences from the dossier. Use them as written. Anything not in quotation marks is the pack's analysis, not a line for you to say.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (R1, must_have, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | low | [grounded] | transferability | Adjacent work, not the title. The limit comes first: "I haven't held the product manager title." Then the integration work at its own scope. The roadmap-input sessions are input to product, not decisions. The low band is the underwriter's grade for R1. |
| F2 | "Shipped API or platform products" (R2, must_have, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | high | [grounded] | transferability | The dossier does not grade R2, so this grading is the pack's. Your confirmed work is client-side integration of a vendor's APIs. That is adjacent to shipping a platform product, not the same thing. Do not say you shipped a product unless you did. Answer slot: if you shipped an API product yourself, say what it was and your part in it; if not, say that and name the integration work. |
| F3 | "Technical fluency: API docs, schemas" (R3, important, dossier role_profile) | "Wrote the internal integration playbook her team uses" — dossier verified evidence | high | [grounded] | presentation | Strong and inspectable. Name it as the integration playbook, in its own terms. Answer slot: if you wrote or reviewed API docs or schemas, say which; if not, say the playbook is the closest thing and what it covers. |
| F4 | "Stakeholder management across engineering, sales, customers" (R4, important, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence, medium confidence | medium | [grounded] | transferability | Customer-facing work is in the quotes. Engineering and sales stakeholder management is not. The roadmap-input line is medium confidence, with limited inspectable proof, so expect a probe. Answer slot: if you managed engineering or sales stakeholders on an integration, say which and how; if not, say so and name the customer side. |
| F5 | "Agile delivery experience" (R5, preferred, dossier role_profile) | none given | low | [grounded] | discovery | No confirmed entry speaks to agile delivery. Clarify it; do not bridge to it. Ask how the squads define and run their cycle, and say what you would confirm. |
| F6 | "Owning a roadmap and prioritization authority" (R1 sub-claim, dossier uncertain_or_weak_areas, allowed strategy acknowledge_gap) | none given | none | [grounded] | capability | Plain acknowledgment from the dossier's acknowledge_gap area: "I haven't owned a product roadmap." Then a ramp plan, stated as a plan and never as a past. No bridge here. |

**Seven things this table does not show:** decision authority over the two squad leads (the dossier lists it as unknown); the current adoption baseline; whether you have ever held a roadmap in any form; agile delivery; sales-side stakeholder work; any shipped API product of your own; and anything about "seven years," which appears only in the dossier's decision summary and not in its verified evidence. No guidance in this pack uses the seven-year figure.

## 3. Prohibited claims

Built from the dossier's `prohibited_claims` and `acknowledge_gap` area, plus inflated forms the pack built from your confirmed sentences. Nothing in any answer, slot, bridge, reverse question or drill may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims item, quoted whole: "Having held a product manager title or role" | "I haven't held the product manager title." Plain acknowledgment. No slot. |
| Having owned a product roadmap | Dossier prohibited_claims item, quoted whole: "Having owned a product roadmap"; also the acknowledge_gap area in F6 | "I haven't owned a product roadmap." Plain acknowledgment. No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims item, quoted whole: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Plain acknowledgment. The material shows input to product, and the pack's analysis says so. |
| Shipped the partner API platform | Inflated form of F2, built by the pack | The integrations at their own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The material shows integrations, not a shipped platform. That observation is the pack's analysis, not a line for you to say. |
| Owned partner-integration decisions | Inflated form of the roadmap-input quote, built by the pack | "Ran quarterly roadmap-input sessions feeding client evidence to product," at its own scope: input to product. The material says input, not decisions. That observation is the pack's analysis. |

## 4. Persona weights

| Persona | How it shows up in this round | Weight | Reasoning |
|---|---|---|---|
| Skeptic | Presses the PM-title and roadmap gaps as must-haves | 5 | Hiring managers buy capability and derisk gaps. The dossier's named objection and its three weak areas are the Skeptic's material. |
| Case / Strategist | Live problems on partner adoption, discovery and first priorities | 4 | The round is with the hiring manager, who will want to see how you would run their roadmap. |
| Data-Driven Prober | Attribution of the 30+ figure; the adoption baseline | 3 | The 30+ figure and the roadmap-input line are the confirmed claims probers aim at. The adoption baseline is unknown. |
| Pressure | Time-boxed version of the objection | 2 | The objection will be asked under time pressure in some form. Composure is what gets tested. |
| Conversational | The opener and the biography arc | 2 | Casual openers are scored. The biography has to stay inside your confirmed sentences. |
| Peer Evaluator | Seams with the two engineering squads | 2 | The squads are the decision-authority question. The hiring manager may test the seam even without a peer in the room. |

Depths: Skeptic 5, Case 4, Prober 3, Pressure 2, Conversational 2, Peer 2. Total 18 questions. No interviewer profile exists, so there is no interviewer read. No loop source exists, so the weights use the hiring-manager prior.

## 5. Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "You've never held the PM title or owned a roadmap" as the dossier's likely_interviewer_objections item, sourced by the dossier's prohibited_claims items "Having held a product manager title or role" and "Having owned a product roadmap"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Hold:** "I haven't held the title or owned a roadmap." Then the work at its own scope: the integrations, and the roadmap-input sessions as input to product. **Name the limit yourself:** the material does not show you setting priorities for a squad. **Concede specifically:** a PM with three years would move faster on prioritization, and your first months should be shaped around that gap. **Ramp, as a plan:** name the first decision you would want to learn to make and how you would learn it with the squad leads. Hold through two follow-ups by returning to the quotes. Never say you are "effectively" a PM. | The highest-ROI rehearsal in this pack. The dossier's underwriter named this objection from your confirmed evidence. It is asked as written because every negative in it has a dossier source. Weight 5 means the deepest follow-up set. |
| B2 | "Which of your integration work would carry into owning a roadmap, and which would not?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer both halves. Carries over: the scoping and requirements steps, which are the closest thing to discovery in your confirmed work. Does not carry over: deciding priorities across squads. Name the second half first if the interviewer pushes. | F1 and F2 at their limits. This is the transferability case with its limit named, as the underwriter framed it. |
| B3 | "Agile delivery is part of this role. What is your experience of it, and how would you run delivery with two squads?" | JD | [grounded] "Agile delivery experience" (R5, dossier role_profile); "Write specs and drive delivery with two engineering squads" (dossier role_profile) | Clarify, do not bridge. No confirmed entry speaks to agile directly, so none is quoted. Say what you would want to confirm about how the squads define agile. Your closest confirmed work is UAT and go-live with clients, which is delivery but not agile product delivery. **Answer slot:** if you have run a sprint or backlog inside a product team, say which; if not, say so and say what you would ask in the first week. | F5 is `discovery`, and its strategy is `clarify`. A bridge here would be the inflation the dossier forbids. |
| B4 | "Engineering, sales and customers all push on partner APIs. Tell me about managing one of those three groups." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Start with the customer side, using the quotes. **Answer slot:** for engineering or sales, say which group and how you worked with them; if you did not manage either, say so and return to the customer work. Do not describe sales management the material does not show. | F4 is `transferability`. The engineering and sales halves are not in the material, so they stay in the slot. |
| B5 | "What would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap); quoted whole | Two sentences: the plain acknowledgment, "I haven't owned a roadmap or set priorities across squads," then the first decision you would learn to make and how. Stop there. | F6 is `capability` with an acknowledge_gap strategy. The answer names the gap and a plan. Nothing else. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose partner API adoption has flattened. How would you diagnose it?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Clarify the objective: what counts as adoption (first call, production traffic, endpoints in use). Segment partners by size, integration type and when they stalled. Metrics: time to first call, endpoints per partner, integration error rates. Risks: partner capacity, documentation gaps, churn. Ask for the current baseline before choosing a fix. Say aloud that you do not know the baseline. | A live problem from the adoption responsibility. It presupposes nothing about your past. It scores structure and the clarifying questions. |
| C2 | "Sketch how you would run discovery with integration partners in your first 90 days." | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibility); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure: the objective, the partner segments, what you need to learn first, the first three conversations, and what would change the plan. The closest real thing you have is the scoping and requirements steps in client integrations, and say no more than that. Do not describe discovery studies you did not run. | The discovery responsibility is a raising source. The pack's structure is generic; the one claim about your past is the quoted scoping step. |
| C3 | "Walk me through how you would set the first three priorities for this platform." | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Structure: the criteria (partner impact, risk, squad capacity), who you would consult including the two squad leads, and what you would need to know first. Say the priorities are shared with the squad leads until you know where decision authority sits. Do not claim you have set priorities before. | Roadmap ownership is the JD's responsibility. Decision authority is unknown, so the answer should show you would ask first. |
| C4 | "A squad lead disagrees with a priority you've proposed. What do you do?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Clarify what the lead knows that you do not, and what each side would lose. Decide who owns the trade-off. Write the disagreement and the decision down, and escalate with the trade-off stated. Say what you would do before the meeting, not only in it. | This tests the authority question directly in a live form. The answer is a process, not a past. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30-plus integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number. **Answer slot:** say what counted as one integration, which of those you counted, and what would change the figure. Name the assumption you would defend least, in your own words. If the count was kept by someone else, say so and give your share. The pack supplies no counting method. "I don't know how it was counted" is an honest branch if it is true. | The headline figure in your confirmed evidence is the target probers aim at. The four slots are the only ones a figure raises. |
| D2 | "Suppose you had to measure partner API adoption from scratch. What would you measure, and which assumption would you defend least?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Name a leading and a lagging measure, tie each to a partner segment, and state the assumption behind the one you would defend least. Ask for the current baseline before setting a target. Do not attribute any adoption number to your past; the material contains none. | The adoption responsibility is named, and the baseline is unknown. The question checks whether you would ask for one before setting a target. |
| D3 | "Tell me about the quarterly roadmap-input sessions. What did they produce?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit before it is extracted: "I can describe the sessions and what I passed to product." **Answer slot:** if any output was a decision of yours, say which; if the output was input for product's own decision, say so. If you cannot point to what came out of them, say that. Never say the sessions set anything. | F4 is medium confidence, with limited inspectable proof, so this is the probe the dossier flagged. "Ran" is the verb in the quote. Do not promote it to "owned" or "set." |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire you over a PM with three years?" | JD | [grounded] as B1: the dossier's likely_interviewer_objections item, with its prohibited_claims sources; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Pause. Restate the question. Acknowledge: "I haven't held the title or owned a roadmap." Give the two quotes. Give the ramp as a plan. **Hold two follow-ups:** return to the quotes each time. **Concede specifically:** the prioritization gap. Never fold to "I can do the PM job." | The same objection under time pressure. The test is composure: hold a position you can back, and concede only the specific gap. |
| P2 | "That integration count. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold: say which steps in each integration you ran, and which your client or your team ran. **Answer slot:** name the steps that were yours. If the figure covered a team's work, say so and give your share. If your share was smaller than "led" suggests, concede that plainly. | "Led" is the verb the interviewer will press. The answer keeps the attribution inside the quote's steps. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in that order: the integrations, the playbook, the roadmap input to product. Use only those three sentences. Do not add any dates or years you have not confirmed. | Casual but scored. Every fact in the arc is a quoted sentence. |
| V2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Name the playbook and what it covers, in your words. **Answer slot:** if you have used documentation or schema tools, name them; if not, say so and say what you have worked with. | R3 asked casually. The playbook is the one inspectable artifact in your confirmed evidence. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squads sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Propose seam principles, not a map you do not have. Who writes the spec, who makes the trade-off, and how disagreements get written down and decided. Reciprocity: say what you would bring to the squads, not only what you need from them. | The seam is the authority question in a peer form. Principles show judgment without pretending to knowledge. |
| E2 | "How do you handle credit when work spans teams?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name who did what in one integration, using the steps in that quote. **Answer slot:** name the step that was yours. If you do not know whether credit was shared, say so. | Cross-team credit is what an integration with a client involves. The answer stays within the quoted steps. |

## 6. Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1, 3+ years product management | B1, B2, P1, F1 (fit snapshot) |
| R1 sub-claim, owning a roadmap and prioritization authority | B1, B5, C3, F6 |
| R2, shipped API or platform products | B2, V1, F2 |
| R3, technical fluency: API docs, schemas | V2, F3 |
| R4, stakeholder management | B4, E2, F4 |
| R5, agile delivery | B3, F5 |
| Responsibility: own the roadmap for the partner-facing API platform | C3, B5 |
| Responsibility: run discovery with integration partners | C2 |
| Responsibility: define and track adoption metrics | C1, D2 |
| Responsibility: write specs and drive delivery with two squads | C4, E1 |

No requirement is uncovered.

## 7. Reverse questions

The dossier's employer questions and unresolved risks are carried in. No interviewer profile exists, so no question ties to their own career path. This is a hiring-manager round, not a peer round, so no reciprocity question is required.

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority is asserted in the JD and not evidenced. The answer tells you whether the gap in B1 is something you can grow into or something structural. |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption is named as a responsibility with no baseline stated. The answer tells you whether D2 is a plan or a fire. |
| R-3 | "What does a good first 90 days look like with the two squad leads?" | It turns the Skeptic's gap into a ramp plan the hiring manager helps write. |
| R-4 | "What would make this hire look like a mistake six months in?" | It surfaces the failure they would judge you on, and it tests whether the ramp you planned matches theirs. |
| R-5 | "In the last year, what has the partner API team had to say no to, and who made that call?" | It shows how decisions are made in practice. That is the authority question, asked as a fact about the team. |

## 8. Sources

- **Provided document:** the underwriting dossier you pasted (`tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14). Consumed: `handoff_to_mock_interview` (all five rules), `role_profile` (requirement text as raising source; `unknowns` used only as questions, not as analysis), and `decision` (context only). Not in the pasted dossier: `evidence_map`, `evidence_state`, `risk_register`. The opportunity risks came in through `handoff_to_mock_interview`.
- **Searches and fetches sent:**
  - "Quartzline company values": refused.
  - "Quartzline Platform APIs product news 2026": refused.
  - Page fetches: none.

**Research tier:** L1. Searches 0 of 6 (2 refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved the values cheat sheet. Refused, so no values section is in this pack, and the round was not detected as values-style anyway. |
| 2. `Quartzline interview process` | unavailable | Would have set loop structure and persona weights. No call was sent after the first refusal. Weights rest on the hiring-manager prior. |
| 3. `Quartzline strategy` and recent news | unavailable | Would have moved the CO bank and checked whether the dossier's three-month age matters. Refused. The CO bank is absent. |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. |
| 5. Representative JD for the title | skipped | The supplied dossier role_profile fixes the requirements and the JD-tagged questions. |

## 9. Upgrade menu

- **Confirm the "seven years" line in your own words or your CV** → it can be quoted. It currently appears only in the dossier's decision summary, so no answer cell uses it.
- **The full JD text** → the dossier's requirement lines stand in for now. The full text adds the posting's own phrasing and mid-list requirements, and it turns C1 and C2 from generic structure into quoted JD lines.
- **The interviewer's name** → persona weights from their public footprint and a tailored reverse question.
- **Permission for web search** → the values, process and recent-news targets above, which were refused this session. That is the L1 tier. A deeper L2 run (strategy brief, interviewer writing, role-family loop reports, recent org context) is available on your consent, up to 6 more searches and 2 more fetches. It is offered once.
- **Your CV text** → lets the 30+ figure (D1, P2) and the roadmap-input line (D3) be quoted from your own document, not only from the dossier.
- **The squad-authority answer** → the reverse question R-1 settles it. If the answer is that the PM does not set squad priorities, B1 and C3 should be rewritten around that.
