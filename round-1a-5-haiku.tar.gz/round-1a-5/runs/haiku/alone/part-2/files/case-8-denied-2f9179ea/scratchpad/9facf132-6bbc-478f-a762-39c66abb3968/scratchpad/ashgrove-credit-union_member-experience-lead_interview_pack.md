# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

- **Candidate:** Dara
- **Role:** Member Experience Lead
- **Company:** Ashgrove Credit Union (member-owned, about 900 staff)
- **Dates:** 4 December 2026, three rounds
- **Round 1:** 30 minutes with the recruiter
- **Round 2:** 45 minutes with the Head of Member Services, your future manager, mostly behavioural. Name not yet given.
- **Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel also scores the values round. Names not yet given.
- **Built on:** your message, the job description, the recruiter's email, and the Ashgrove values and strategy as you pasted them

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Tag | Type | What it scores |
|---|---|---|
| VAL | Values | Whether your past behaviour shows the four published values |
| EXP | Experience | What you actually did, and whether the CV's claims hold up |
| JD | Role | Whether you can do the listed job, gaps included |
| CO | Company | Strategy and company knowledge |
| CASE | Case | A live problem from the role, solved aloud |

The guidance is scaffolding, not a script. An **answer slot** is an instruction to answer from your own experience. It has two honest branches: say how it was yours, or say plainly that it was not. Use whichever is true.

## Fit snapshot

Each evidence cell holds your own words, quoted exactly. Where a row says "your message", the quote comes from the background you gave me. No requirement in the JD is a gate (none is a term, licence or credential), so there are no hard-gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's complaints log, not the end-to-end process. Words: "I handled the branch's formal complaints log." Answer slot: if you owned any step beyond the log, such as how a complaint was closed or passed on, say which and how you decided; if you did not, say so and stay with the log. |
| F2 | "experience handling regulated complaints" — JD | "Handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | Your material shows formal complaints, but not whether they were regulated or what rules governed them. Answer slot: if the log followed rules set from outside the branch, such as a response deadline or an external referral route, say which and how you worked to them; if not, say what governed it and stay with the log. |
| F3 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The years and the sector are in your sentence, in other words. Words: "I've spent six years in retail banking, the last three as a branch supervisor." Your sentence says retail banking, not customer operations; the bridge keeps your words and adds nothing. |
| F4 | "comfortable with Excel reporting" — JD | "Built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The sentence shows reporting, but does not name Excel. The pack does not say which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." If asked which tool, name it in your own words. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "Built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your material shows a monthly spreadsheet, not which measures it carries. Answer slot: if it carried complaint volumes or resolution times, say which and how you counted them; if it did not, say what it did carry and what you would add first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and the script is "our", a shared one. Words: "I trained new tellers on our escalation script." The limit: you trained tellers, not supervisors. Coaching supervisors is a plan, not a past. |
| F7 | "across branches and the contact centre" — JD | "Never worked in a contact centre." — your message | none | [grounded] | capability | You stated the absence. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show any work with a digital team. Answer slot: if you worked with a digital team on a customer-facing change, say which and what your part was; if you did not, say so, and say what you would learn first about how members use self-service. |
| F9 | "confident presenting to senior leaders" — JD | "Has never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan. Never a claim of presenting above regional level. |

## Prohibited claims

These are the claims this pack will not coach, and why. Each has a basis and an honest form. The banks are written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." Your material says the log, not the end-to-end process. The F1 answer slot stays inside the log. |
| Worked in a contact centre, or ran contact-centre complaints | Negative you stated (F7) | "I've never worked in a contact centre." No slot on contact-centre past. |
| Presented to senior leaders, or above regional level | Negative you stated (F9) | "I haven't presented to anyone above regional level." No slot. |
| Reported monthly on complaint volumes and resolution times; measured resolution times | Inflated form of F5 | The F4 quote at its own scope. The F5 slot asks only what the spreadsheet carried. |
| Wrote the escalation script, or set the escalation process | Inflated form of F6; "our" marks the script as shared | "I trained new tellers on our escalation script." |
| Coached branch supervisors on escalations | Inflated form of F6 | The F6 quote at its own scope. |
| Expert in Excel | Inflated form of F4; the sentence names no tool | The F4 quote at its own scope. Name the tool in your own words if asked. |

## Persona weights

Round 1 follows the recruiter-screen prior: conversational, with a light skeptic. Round 2 is your manager and is mostly behavioural, so Values/Behavioral leads rather than the hiring-manager default. Round 3 scores the values and runs the case, so Values and Case lead. The two branch managers have no names or seniority given, so I treat them as peer-level, which adds Peer Evaluator and Data-Driven Prober.

| Persona | Round and how it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Round 1: the opener and your motivation, in a friendly register | High: a recruiter screen | Pre-scripted 90-second arc; treat casual questions about the JD as scored |
| Values / Behavioral | Round 2 (lead) and Round 3 (scores the four values) | High: Round 2 is mostly behavioural; Round 3 scores the values | STAR-shaped stories; say plainly where no story exists |
| Skeptic | Round 2: your two named gaps, contact centre and senior presenting; light in Round 1 | High in Round 2: the point of the round is to test the gaps | Rehearse the single likeliest objection; concede plainly, do not bluff |
| Pressure | Round 2: your complaints log | Medium: the log is the claim most likely to be probed hard | Hold through two follow-ups, then concede specifically |
| Case / Strategist | Round 3: the 20-minute escalation case; the strategy question | High: the recruiter named the case | Clarify, objective, segmentation, approach, metrics, risks |
| Peer Evaluator | Round 3: seams between branches and the contact centre | Medium: the branch managers are assumed peer-level | Propose seam principles; reciprocity |
| Data-Driven Prober | Round 3: your spreadsheet and the reporting line | Medium: the JD's monthly reporting requirement | Say what you can and cannot say about how it was counted |

Depth: Round 1 has six questions, Round 2 six, Round 3 eight.

## Question banks

### Round 1: recruiter screen (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, last 3 as a branch supervisor" — your message; "Handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | A ninety-second arc in your words: six years in retail banking, the last three as a branch supervisor; one beat from the complaints log; one beat from training tellers on our escalation script; end on why you are applying. | The opening question, scored for clarity. F3 gives the first beat and F1 and F6 give the next two. |
| A2 | "What are you looking for on pay?" | JD | [generic] | Logistics slot. Give the figure you are actually working to, in your own words, or ask first for the role's band. Do not give a figure you have not chosen. | Pay is a recruiter knockout check. The pack gives no figure because you have not given one. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in weeks or months. | A start-date check; a factual answer only. |
| A4 | "Where would you be based, and how often could you get to the office or a hub?" | JD | [generic] | Logistics slot. Say where you would work from and how often you can get there, in your own words. | Location is a recruiter check. The five-hub plan in the strategy brief makes travel a live question. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give your real reason in one or two sentences, in your own words. Do not supply a reason you did not give. | The reason for leaving is a recruiter logistics check and a motivation check. |
| A6 | "What draws you to a role that spans branches and the contact centre?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD; "Never worked in a contact centre." — your message | Say what draws you to the end-to-end scope, in your own words. Then say plainly: "I've never worked in a contact centre." Do not claim contact-centre work to sound ready. | The light skeptic: the recruiter's motivation check. The contact-centre gap (F7) surfaces here first, so decide your plain wording now. |

### Round 2: Head of Member Services (Values/Behavioral lead, Skeptic, Pressure)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you handled a formal complaint through to the end." | EXP | [grounded] "Handled the branch's formal complaints log" — your message | An open prompt: pick a complaint you took through the log. Tell it in the order it happened: what came in, what you did, how it closed. Answer slot: if you took it through steps beyond the log, say which and how you decided; if the log was yours but the decisions were not, say so plainly and tell the case from the log. | The JD asks for end-to-end ownership (F1), and the log is the nearest case. EXP, because it tests what you did. |
| B2 | "Tell me about a time a complaint showed a process was failing a member. What did you do?" | VAL | [generic] | Pick a complaint that showed a process failing a member, a step you saw go wrong, and what you did about it. It needs the member's side and an end you can name. If you have none from the log, say so, then give the nearest thing: how you would bring such a problem to the person who owns the process. | Members First and Own the Fix, asked as a behavioural probe. The guidance makes no claim about your past, so the label stands alone. |
| B3 | "You've never worked in a contact centre, and you haven't presented above regional level. Why should we think you can do both?" | JD | [grounded] "Never worked in a contact centre." — your message; "Has never presented to anyone above regional level." — your message; "Handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message; "Built the monthly complaints spreadsheet our regional manager uses" — your message | Highest-ROI prep. Hold on the branch work you can name: the complaints log, the tellers you trained, the spreadsheet your regional manager uses. Hold through two follow-ups by returning to those. Then concede plainly: "I've never worked in a contact centre," and "I haven't presented to anyone above regional level." Then the plan, as a plan: how you would learn the contact-centre complaint flow early on, and how you would prepare for a senior presentation. Never fold into a past. | The single most likely objection. The JD's contact-centre and presenting lines set it up (F7, F9). The hold is your branch work; the concession is the negative you stated. |
| B4 | "How much of that complaints log was actually you?" | EXP | [grounded] "Handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | Pressure. Hold what you did: you handled the log. Name the part that was shared: the escalation script is "our" script, and you trained tellers on it. Concede where you did not decide: say which decisions were not yours. Do not widen the log to meet the question. | A pressure probe on attribution, aimed at F1, the claim the material shows least. |
| B5 | "How would you coach a branch supervisor who escalates a complaint too late?" | JD | [grounded] "trained new tellers on our escalation script" — your message | The nearest thing your material carries is coaching at teller level, on the escalation script. Answer slot: if you coached anyone past teller level, say who and what you did; if not, say so, then describe how you would start: review two escalations with the supervisor and ask what they saw at each step. | The JD's coaching line (F6). The answer slot lets the premise be false, because your material shows no supervisor coaching. |
| B6 | "Have you worked with a digital team on a self-service journey?" | JD | [grounded] "work with digital teams on self-service journeys" — JD; "Handled the branch's formal complaints log" — your message | Answer slot: if you did, say which journey and your part; if you did not, say so, then say what you would bring from the complaints log about where members get stuck. | The JD's digital line, with no evidence in your material (F8). |

### Round 3: branch-manager panel (Values scoring, Case, Peer Evaluator, Data-Driven Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold: pick a decision where the member's view changed the outcome. It needs a member, a choice, and what the member got. If none comes to mind, say so plainly, then give the nearest thing your log carries, and how you would decide it next time. | Members First, in a round the panel scores against the values. No claim about your past, so the label stands alone. |
| C2 | "Tell us about an explanation that didn't land with a member, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Plain Words. If training tellers on the escalation script is the nearest case, say how you knew whether it had landed. If you did not check, say so and say what you would check. | Plain Words, mapped to the nearest sentence you gave. The honest branch covers the case where no check was made. |
| C3 | "Every branch is part of its town. Eight branches are becoming five hubs. What would you protect for members in the towns that lose a branch?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief (recruiter) | Neighbours, Not Numbers. Name who loses the nearest branch, and what you would keep for them: complaint routes, a named contact, a way to reach the hub. Keep it a plan. Do not claim consolidation experience; your material shows none. | The strategy brief is the raising source. The question presupposes only the brief's consolidation, not anything from your past. |
| C4 | "Tell us about a problem you found that wasn't yours to fix. What did you do?" | VAL | [grounded] "Built the monthly complaints spreadsheet our regional manager uses" — your message | Own the Fix. Pick a problem you found and kept hold of until it was solved. It needs a step you took yourself and an end state you can name. If none of your work ended that way, say so, then give the nearest thing: if the spreadsheet started from a problem you found, say so in your own words; if it did not, say that. | Your material carries no fix story. The spreadsheet is the nearest thing, and the guidance says so rather than promoting it. |
| C5 | "A member has been passed between a branch and the contact centre three times about one complaint, and now asks for their branch manager. You have twenty minutes: what do you do?" | CASE | [generic] | Clarify first: which complaint, which timescale applies, who holds it now. Objective: the member gets one named owner and an answer. Segment the routes: branch, contact centre, escalation. Approach: one owner, one date, one record. Metrics: time to owner, time to resolution, repeat contacts. Risks: a handover that loses the file. Say the framework aloud, and challenge one premise respectfully. | The panel's twenty-minute complaint-escalation case. The framework belongs to the role, so the guidance claims nothing about your past. |
| C6 | "Branches and the contact centre both take complaints. Where is the seam, and what happens when you and we disagree on a decision?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Propose seam principles, not facts about their seam: who holds a complaint at each handover, and how a disagreement gets settled, by the member's outcome. For the disagreement: if you have one from the log, say it plainly; if not, say what you would do. | Peer Evaluator: turf awareness and disagreement style. Reciprocity framing. |
| C7 | "What did your monthly complaints spreadsheet carry, and how did you count it?" | JD | [grounded] "Built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: if it carried complaint volumes or resolution times, say which and how you counted each, and which assumption you would defend least. If it did not carry them, say what it did carry and what you would add first. | Data-Driven Prober on the JD's reporting line (F4, F5). The defend-the-number slot applies only if a figure is given, and none has been. |
| C8 | "Forty per cent of member service is moving to digital by 2028. Where does a complaint go when a member never speaks to anyone?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief (recruiter) | Name the risk: the members most likely to be left with a complaint are those who cannot use the app. Propose an in-app route into the same complaints record, a human fallback, and complaint volume by channel. Keep it a plan. Do not cite digital-team experience; none is in your material (F8). | A strategy-grounded case. The JD's digital line and the panel's scoring meet here. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 (F3) |
| Experience handling regulated complaints | B1, B4 (F2) |
| Confident presenting to senior leaders | B3 (F9) |
| Comfortable with Excel reporting | C7 (F4) |
| Own the member complaints process end to end across branches and the contact centre | B1, B3, C5, C6 (F1, F7) |
| Report monthly on complaint volumes and resolution times | C7 (F5) |
| Coach branch supervisors on escalations | B5, C5 (F6) |
| Work with digital teams on self-service journeys | B6, C8 (F8) |

## Values cheat sheet

Round 3 is a values round: the panel scores against the four published values. Your material carries a story for only one value, so the rest are scaffolds.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "Handled the branch's formal complaints log." No sentence says a decision was made from the member's side. Scaffold (C1): pick a decision where the member's view changed the outcome. If none, say so and give the nearest case. |
| Plain Words | If a member needs it explained twice, it was written wrong | F6: "trained new tellers on our escalation script." Story: the training. Say how you knew it had landed. If you did not check, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence carries a story. Scaffold (C3): name a town or community you served. If none, say so, then give the plan for a branch closure. |
| Own the Fix | Keep hold of a problem until it is solved | F4: "Built the monthly complaints spreadsheet our regional manager uses." No fix story is stated. Scaffold (C4): if the spreadsheet started from a problem you found and you kept hold of it, say so; if not, say that. |

## Grounding brief

Learn the vocabulary from the strategy brief as you pasted it. I have your summary of the brief, not the document itself, so check any figure against the published version before you quote it.

- **40% of member service to digital channels by 2028.** The self-service push. Used in C8 and B6.
- **Eight branches into five hubs over 2027.** The consolidation. Used in C3, and in A4 on travel.
- **Small-business lending product in Q1 2027.** A new product. Your material says nothing about it. If it comes up, say you would want to learn it.
- **Main competitive pressure: app-only banks.** Complaints have to work in the app as well as in the branch. Used in C8.

## Reverse questions

You have no interviewer profile, so none of these ties to a career path yet. The panel is peer-level by assumption, so R5 is the reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 (recruiter) | "Where do members get stuck between branches and the contact centre today?" | It shows you are thinking about the seam the JD names. |
| R2 (Head of Member Services) | "What would you want the complaints measures to show in the first ninety days?" | It puts you on their measures, which is the JD's monthly reporting line. |
| R3 (Head of Member Services) | "How will the move to five hubs change which complaints reach this role?" | It shows strategy fluency, and it ties to the values round's Neighbours value. |
| R4 (panel) | "What does a complaint escalation look like when it goes well here?" | It asks them to describe the standard they score against. |
| R5 (panel, reciprocity) | "What could a new person do in their first month that would genuinely help your branches?" | It turns the conversation peer to peer. |
| R6 (Head of Member Services) | "Which complaint measure does the regional team act on, and which do you find misleading?" | It shows you know how counting changes what a number means. |

## Sources

- **Provided by you:** the job description text; the recruiter's email; the Ashgrove values, which you copied on 25 November 2026 (I have not checked them against the live page); the strategy brief, as you summarised it (July 2026); your background.
- **Searches:** none. **Fetches:** none.

**Research tier:** L0, provided documents only. Searches 0, fetches 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, built from the values you pasted |
| 2. Ashgrove interview process, Member Experience | skipped | Round structure, from the recruiter's email |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief, from the strategy summary you pasted |
| 4. Interviewer name | n/a | No names given |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- **Names of the Head of Member Services and the two branch managers** → persona weights from their public footprint, and a tailored reverse question for each round.
- **Your prep time before 4 December** → a prioritised schedule for the next nine days.
- **A CV, or the complaints log's summary figures if you can share them** → the evidence quotes move from "your message" to "your CV", so you can check the wording against the document.
- **Any detail on how the log was governed**, such as external rules or referral routes → F2's answer slot becomes a grounded bridge.
- **The recruiter's note on what the twenty-minute case covers** → a coverage check on C5.
- **Deep research (L2): role-family loop reports and recent Ashgrove news** → a grounding brief on leadership and a check on the round structure. It would run at most 6 further searches and 2 further fetches. Say yes to run it.
