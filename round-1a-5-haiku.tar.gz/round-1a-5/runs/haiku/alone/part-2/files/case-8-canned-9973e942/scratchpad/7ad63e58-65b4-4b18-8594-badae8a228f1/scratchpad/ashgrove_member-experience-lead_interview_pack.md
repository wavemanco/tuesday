# Interview pack: Member Experience Lead, Ashgrove Credit Union

Rounds on 4 December 2026: (1) 30 min recruiter; (2) 45 min Head of Member Services, mostly behavioural; (3) 60 min panel of two branch managers, including a 20-minute complaint escalation case, scored against the four values.

Built from your message, the JD, the recruiter's process email, the strategy brief as you summarised it, and the four values as you copied them on 25 November 2026. No web research ran (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values; **EXP** your experience, tested; **JD** the job's own requirements; **CO** company and strategy; **CASE** a live problem.
- Guidance is scaffolding, not a script. Where it says "answer slot", you give the honest answer in your own words.
- Question IDs are letter-by-persona (S1, V1, K1 and so on) so you can ask for any of them in a drill.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. The line carries the years and the supervisor role; expect the CV to be checked against it. |
| F2 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end. Words: "I handled the branch's formal complaints log." Limit: the material does not show work beyond the branch. Answer slot: if you ran any part of the process across branches, say which part and how; if your work stayed in one branch, say so and say what carries across. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material does not show whether the log carried regulatory deadlines or ombudsman referrals. Answer slot: if any complaint in the log went to an ombudsman or regulator, say what your part was; if none did, say so plainly. |
| F4 | "report monthly on complaint volumes"; "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | none | The quote reaches both requirements in role-relevant terms. Words: "I built the monthly complaints spreadsheet our regional manager uses." Expect a probe on what it counts (see P2). |
| F5 | "resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether anything tracked how long complaints took to close. Answer slot: if your spreadsheet or log recorded resolution times, say how they were counted; if it did not, say so plainly. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" — your message | medium | [grounded] | presentation | The quote reaches coaching on escalations, but for tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached supervisors on escalations, say how; if you did not, say so and say how you would start. |
| F7 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" — your message | none | [grounded] | capability | Stated absence. Words: "I've never worked in a contact centre." Then how you would learn it, as a plan, never as a past. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you have worked with a digital team, say what you did; if you have not, say so plainly and say how you would learn the member's side of a digital journey. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Stated absence. Words: "I've never presented to anyone above regional level." Then a plan: how you would prepare to present to a senior group, as a plan. |

Gap types follow the routing rule in the output template. F7 and F9 are stated absences, so their words come from your sentences. F3 and F5 are silences, so their words are answer slots.

No JD requirement is a gate (a licence, location, schedule or credential). Nothing is marked hard_gate.

## Grounding brief: the company's current priorities

As you summarised the July 2026 strategy brief (not verbatim; check the wording against the brief before you quote it):

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Vocabulary to use: "member service", "digital channels", "hubs". Flagged stale framings: none in the material.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Round 2 manager; probes the gaps you have already stated: the contact centre, senior presenting, regulated complaints | High. Round 2 is a manager who will be buying capability and derisking gaps. Your three stated gaps (F7, F9, F3) are the first things they will test. | Say the stated absence in your own words, then give a plan. Hold it through two follow-ups. |
| Values / Behavioural (weight 4) | Round 2 behavioural questions; round 3 panel scores each value | Very high. The recruiter confirmed the panel scores against all four values. | Map each value to a true story, or say plainly that you have no story for it. |
| Case / Strategist (weight 3) | The 20-minute escalation case in round 3; strategy questions tied to the brief | Certain for the case (announced). Medium for strategy questions. | Clarify, then structure, then answer. Name the member first. |
| Peer Evaluator (weight 2) | Round 3 panel of branch managers, who will be your peers on the branches' side | Medium. Branch managers may test seams between branch and contact centre. | Give the seam a principle and an owner. Do not pretend to know the seam. |
| Data-Driven Prober (within the peer bank) | Round 3; a branch manager reading your spreadsheet claim | Medium. Your one quantified claim is the spreadsheet (F4), and branch managers read reports. | Name the assumption you would defend least before they do. |
| Conversational / Recruiter (weight 5) | Round 1 recruiter; background and logistics | High. The recruiter screen asks pay, notice, location and reason for leaving. | Give the 90-second background arc. Answer each logistics question in your own words. |
| Pressure | Not signalled by any interviewer yet | Low. Drill one question if time allows. | Pause, restate, hold a position through two follow-ups. |

Weights are shown so you can recalibrate. If you learn the round 2 or round 3 interviewer's names, the weights can change.

## Question banks

Coverage line:

| JD requirement | Covered by |
|---|---|
| Own complaints process end to end across branches and contact centre | S1, S6, P1, K1 |
| Report monthly on complaint volumes | P2, C1 |
| Resolution times | P2 (answer slot), S6 |
| Coach branch supervisors on escalations | S4, K1 |
| Work with digital teams on self-service journeys | S5, K3 |
| 4+ years in financial-services customer operations | C1 |
| Experience handling regulated complaints | S6 |
| Confident presenting to senior leaders | S3 |
| Comfortable with Excel reporting | P2 |
| Company values (panel scoring) | V1, V2, V3, V4 |

### Skeptic bank (weight 5, round 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "I don't see a contact centre in your background. How would you run complaints across one?" **Highest-ROI prep in this pack.** | JD | [grounded] "Never worked in a contact centre" — your message | Hold: "I've never worked in a contact centre." Then the plan, in your words: the first thing you would do is map how a complaint moves from a branch to the centre and back, and who holds it at each step. Hold through two follow-ups by returning to that sentence and the plan. Concede specifically: "I don't yet know how the centre logs a complaint. I'd find out in my first week." | F7 is the stated absence and the likeliest objection to this candidate. The question presupposes the JD's own line, which is a raising source. |
| S2 | "How much of that log was actually you, and not the branch team?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Restate the sentence in your own words. Then say which parts of the log you did yourself. Answer slot: if others also worked the log, say who and what they did. Do not claim a share you cannot name. | F2 is the row that can be inflated most easily. Attribution is the probe. |
| S3 | "You've never presented above regional level. Why would a senior team trust your numbers?" | JD | [grounded] "I've never presented to anyone above regional level" — your message; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say: "I've never presented to anyone above regional level." Then point to the spreadsheet as the thing a regional manager already trusts, in those words. Then the plan: how you would prepare the numbers for a senior group. | F9 is a stated absence. Presenting to senior leaders is a JD requirement. |
| S4 | "You trained tellers. What have you done for supervisors on escalations?" | JD | [grounded] "trained new tellers on our escalation script" — your message | Say what you did with tellers, in those words. Answer slot: if you coached supervisors on escalations, say how; if you did not, say so and say how you would start with the branch supervisors. | F6 is presentation. The job is supervisors, not tellers, so the gap is real. |
| S5 | "The role works with digital teams on self-service journeys. What have you shaped?" | JD | [grounded] JD: "work with digital teams on self-service journeys" | Answer slot: if you have worked with a digital team, say what you did and what you did not do. If you have not, say so plainly, then say how you would learn a member's side of a digital journey. | F8 is silent. The question carries the JD's own line. |
| S6 | "Did any complaint in your log go to an ombudsman or a regulator? What was your part?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: if one did, say what your part was, in your own words. If none did, say so plainly and say how you would handle one. | F3 is discovery. This is the regulated-complaints requirement, and the material does not show it. |

### Values bank (weight 4, round 2 and round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put the member's side of the counter ahead of the process." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a complaint in the log where the process said one thing and the member needed another. Say what you did and what the member heard back. If no complaint turned on that, say so plainly, then give the nearest one the log holds. | Members First. The log is the only candidate sentence, and it places the story without adding one. |
| V2 | "Tell me about a time someone needed a decision explained twice." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Selection scaffold: pick a time a teller or member had to hear a decision again. Say what you changed in the words you used. If the script was the nearest case, say what in it needed rewording. If you found no gap in it, say so. | Plain Words. The script is the only candidate sentence, and it is a training fact, not a plain-words story. |
| V3 | "How have you kept a branch's place in its town when a number pointed the other way?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Selection scaffold: pick a branch-level decision where local impact and a target pulled apart. Say how you weighed them. If none comes to mind, say so plainly, then say how you would weigh them now. | Neighbours, Not Numbers. Your branch supervisor years are the only candidate sentence; the story has to come from them. |
| V4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a complaint you carried to its close. Say what held it open and what you did when it stalled. If you handed one on, say why and what happened. | Own the Fix. The log places the story; the ending must come from your own complaint. |

### Case bank (weight 3, round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A member has complained about a fee twice. The second answer was also no. They say they will go to the ombudsman. You have 20 minutes. Walk us through what you do." | CASE | [generic] | Structure, in this order. (1) Clarify: what the fee was, what each answer said, what the member asked for, and the dates. (2) Member first: what does the member need from this? (3) Decide who owns the fix, and whether the second "no" was right. Own it until it is solved. (4) Write back in plain words, and check the regulatory deadlines for an escalated complaint. (5) Record the decision. (6) Tell the branch supervisor what to change, and work with digital if a self-service step caused the problem. | The 20-minute case from the recruiter's email. It tests the JD's "end to end" line and the Own the Fix value. The guidance makes no claim about your past. |
| K2 | "Eight branches become five hubs in 2027. Complaints from the closing branches rise. What do you do in the first month?" | CO | [grounded] brief: "consolidate eight branches into five hubs over 2027" — as you summarised it | Clarify: which branches, which members, and what the complaints are about. Measure complaints by branch before and after. Talk to the branch supervisors first. Write to members in plain words. Keep the fix with one named owner. | Round 3 will know the brief. The answer should show you can think at the strategy's level, without claiming you have done a hub move. |
| K3 | "The bank plans to move 40% of member service to digital by 2028. What happens to the members who cannot or will not use the app, and how do they still reach a person?" | CO | [grounded] brief: "move 40% of member service to digital channels by 2028" — as you summarised it | Name the risk: a complaint route that ends at the app leaves members stuck. Propose: keep a person in the route, measure which channel complaints come from, and work with digital teams on the journey. No claim about past digital work. | Ties the JD's digital line to the strategy. Answers an app-only-bank competitor question without naming one. |

### Peer and prober bank (weight 2, round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "When a branch and the contact centre disagree about who owns a complaint, what happens?" | JD | [grounded] JD: "across branches and the contact centre" | Principle: one named owner until the complaint is closed, whichever side it started on. Reciprocity: say what you would bring to the branch managers' work, not only what you would need from them. Answer slot: if you have settled such a dispute, say how; if you have not, say so and say what rule you would set. | F2 and F7. A peer probe about the seam. |
| P2 | "Which number in your spreadsheet would you defend least?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Name the assumption you would defend least, in your own words, before they do. Answer slot: if you know how the spreadsheet counts a complaint, say it. If you do not, say so plainly. Answer slot: if it tracked how long complaints took to close, say how; if not, say so. | F4 and F5. A prober's question about the one number you have claimed. |

### Conversational / recruiter bank (weight 5, round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Talk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; [grounded] "I handled the branch's formal complaints log" — your message | Ninety-second arc with only these beats: six years in retail banking; the last three as a branch supervisor; the formal complaints log; training tellers on the escalation script; the monthly spreadsheet. Nothing added. | F1 and F4. The opener sets the rest of the loop. |
| C2 | "What are you looking for on pay?" | JD | none given | Logistics slot. Either give your own figure, or ask first: "Before I give a number, could you tell me the band for this role?" Give no figure you have not chosen. | Pay is a logistics slot. The recruiter's question is not a place to supply a number you did not give. |
| C3 | "What is your notice period?" | JD | none given | Logistics slot. Give your actual notice period. | Notice is a logistics slot. |
| C4 | "Are you able to work from one of the new hubs?" | JD | [grounded] brief: "consolidate eight branches into five hubs over 2027" — as you summarised it | Logistics slot. Give your own answer on where you can work, in one sentence. | Location is a logistics slot. The hub question comes from the brief. |
| C5 | "Why are you leaving your current role?" | EXP | none given | Logistics slot. Give your reason in your own words, in one sentence. | Reason for leaving is a logistics slot. Do not explain past the reason you choose. |

Question count: 19 (S 6, V 4, K 3, P 2, C 5, within the 18 to 26 range). Rounds: round 1 is C1 to C5 plus S1 if time allows; round 2 is S1 to S6 and V1 to V4; round 3 is K1 to K3, V1 to V4, P1 and P2, and S3.

## Values cheat sheet

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Selection scaffold, V1. Your log is the place to find the story. If no complaint turned on it, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Selection scaffold, V2. The script is the nearest sentence. No plain-words story is in your material. |
| Neighbours, Not Numbers | Every branch is part of its town. | Selection scaffold, V3. Your supervisor years are the nearest sentence. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Selection scaffold, V4. Your log is the place to find the story. |

Honest note: none of the four values has a story in the material you gave. Each needs one, and each should come from a specific complaint you handled. If you cannot find one for a value, say so in the interview rather than inventing an ending.

## Reverse questions

Each has a "why it lands" line.

1. "What would a good first six months look like for complaint volumes and resolution times?" Why it lands: it ties your monthly report to their definition of success.
2. "When a complaint starts in a branch and needs the contact centre, who holds it until it is solved?" Why it lands: it tests the Own the Fix seam directly.
3. "How will the 2027 hub moves change which branch a member's complaint goes to?" Why it lands: it shows you have read the brief and are thinking about members, not only numbers.
4. "Which digital journeys generate the most complaints now?" Why it lands: it opens the digital question without a claim about your past.
5. "What would the Head of Member Services want changed after 90 days?" Why it lands: it signals you are planning to work for them.
6. "What is the hardest escalation the branches have handled this year, and how did it end?" Why it lands: it gives the panel a values-based conversation and shows you care how things end.
7. Reciprocity, for the branch managers: "What do you need from the Member Experience Lead that you do not get now?" Why it lands: a peer question that turns the panel into a conversation.

## Prohibited claims

Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| I ran complaints end to end across branches and the contact centre | Inflated form of F2. The material says a branch log. | Quote at its own scope: "I handled the branch's formal complaints log." The material says the branch log, not the process end to end. Slot: S1, P1. |
| I coached branch supervisors on escalations | Inflated form of F6. The material says tellers. | Quote: "I trained new tellers on our escalation script." Slot: S4. |
| I presented complaint numbers to senior leaders | Inflated form of F4, plus the stated absence in F9. | Plain acknowledgment: "I've never presented to anyone above regional level." The spreadsheet is what the regional manager uses, nothing more. |
| I have worked in a contact centre | Negative you stated (F7). | Plain acknowledgment: "I've never worked in a contact centre." Then a plan. |

Silence is not listed. Digital work (F8) and resolution times (F5) are answer slots, not prohibited claims.

## Sources

- **Provided documents:** your message (background, background sentences quoted in the fit snapshot); the JD text as you quoted it; the recruiter's process email; the strategy brief as you summarised it; the four values as you copied them on 25 November 2026. I have not checked the values page or the brief against their originals.
- **Research tier:** L0. Your inputs already fix every output, so no search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the four values are in your pasted copy. |
| 2. Ashgrove interview process | skipped | Round structure and persona weights: the recruiter's email fixes the rounds. |
| 3. Ashgrove strategy / recent news | skipped | Grounding brief and K2, K3: the brief you summarised supplies the priorities. |
| 4. Interviewer name and company | n/a | No names given. The interviewer read is absent. |
| 5. Representative JD | skipped | Fit snapshot: the JD you supplied fixes the requirements. |

## Upgrade menu

- The round 2 manager's name and the round 3 panel's names → persona weights read from their public footprint, and a tailored reverse question.
- Your formal complaints log's counts and any resolution times you recorded → turns F5 from a slot into a grounded answer, and upgrades P2.
- Whether any complaint in the log went to an ombudsman or regulator → upgrades F3 from discovery.
- Any digital or self-service project you have worked on → upgrades F8 from discovery.
- A public check of Ashgrove's own published complaint figures (research at L1) → a concrete number for K1 and K2, without any claim from you.
- A full deep-research pass (L2): the strategy brief checked against the original, and interviewer talks or loop reports → sharper grounding and a more current vocabulary.
