# Stripe, Product Operations Manager: final-round prep pack

Built with no CV, no job description and no company research (both searches were refused), and with the round type unknown. Every requirement is therefore marked [generic], and every persona is weighted equally until you say who you are meeting.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values questions: past behavior, asked for an instance |
| EXP | Questions about your own past work |
| JD | Questions about what the role requires |
| CO | Questions about the company and where it is going |
| CASE | A live problem you work through in the room |

Guidance is scaffolding, not a script. Say it in your own words, and aim for 90 to 120 seconds per answer.

## 2. Fit snapshot (worksheet)

No CV is in the material, so no evidence cell can quote you. Each row lists what strong evidence would look like and gives you an instruction for the part you have to supply. Paste your CV and each row is rebuilt from your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running a recurring operating cadence that several teams attend [generic] | none given | none | [generic] | discovery | Strong evidence: a named forum you ran or sat in, who attended, and one change it caused. Pick a recurring meeting or review you ran or helped run, say who came and what changed because of it. If none comes to mind, say so plainly, then give the nearest one, or how you would set one up |
| F2 | Designing or improving intake, workflows and handoffs between teams [generic] | none given | none | [generic] | discovery | Strong evidence: a process you changed, the before and after, and who used it. Pick one process you touched, say what was slow or broken, and what you changed. If you changed none, say so and say how you would start |
| F3 | Building metrics and dashboards that leaders use to decide [generic] | none given | none | [generic] | discovery | Strong evidence: a metric someone acted on, and how it was counted. Pick a number you owned, name the decision it informed, and say how it was counted. If no one acted on one of yours, say so and give the nearest case |
| F4 | Coordinating launches or rollouts that touch several teams at once [generic] | none given | none | [generic] | discovery | Strong evidence: a launch or rollout, the teams involved, and who decided readiness. Pick one, name the teams, and say who signed off. If you have not run one, say so and say what you would check first |
| F5 | Setting priorities when stakeholder requests compete [generic] | none given | none | [generic] | discovery | Strong evidence: a prioritisation call with criteria and a decision. Pick a time requests competed, name the criteria you used, and say what you dropped. If you have not made such a call, say so and name the criteria you would start with |
| F6 | Working with the tools and systems that operations work runs on [generic] | none given | none | [generic] | discovery | Strong evidence: named tools you have used and what you did with them. List the tools you have used in this kind of work and what you did with each. If none are on your list, say so and name the tools you would learn first |

Only a discovery row is possible here: the material is silent, and no negative has been stated.

## 3. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Gives you a live operating problem from the role | Flat: 3 questions. The round type is unknown, so no persona leads | Clarify, then structure, then metrics, then risks. Think aloud |
| Data-Driven Prober | Pushes on how any number was counted | Flat: 3. Any metric you cite will be probed | Name the weakest assumption before they do. Say plainly when you do not know |
| Pressure / Stress | Interrupts, time-boxes, questions motive | Flat: 3. Shown equally until the round type says otherwise | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Skeptic | Probes gaps: why this role, why now, weakest on day one | Flat: 3. The most likely persona for a final round | Rehearse the day-one question until it is routine. Be candid, not bluffing |
| Values / Behavioral | Asks for a past instance of a principle | Flat: 3. No published values were read, so the themes are generic | Pick an instance. If none fits, say so, then give the nearest one |
| Conversational | Opens casually and asks about your path | Flat: 3. Casual questions are still scored | Have a 90-second arc ready. Treat every casual question as scored |
| Peer Evaluator | Probes seams between teams and disagreement | Flat: 3. Peer reciprocity questions apply only if the interviewer is a peer | Propose principles for the seam. Do not claim knowledge of their team |

Depth is flat at three per persona, so the bank is 21 questions. The pack does not weight personas by relationship because the relationship is unknown.

## 4. Question banks

Coverage note: no job description was supplied, so the banks cover the six generic requirements in the fit snapshot. The Provenance column is [generic] throughout, because no sentence of yours is in the material.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | A launch touches three teams, and none is sure who signs off on readiness. What do you do first? | CASE | [generic] | Clarify who decides and what ready means before you propose any structure. Then name the objective, the owners, the readiness checks and the risks you would escalate. Speak the first three moves in order | F4 and F2 have no evidence, and this is their live shape. CASE because you solve it in the room |
| A2 | Sketch the operating cadence you would set up for a forty-person cross-functional team that has none. | CASE | [generic] | Say the forum, its owner, what goes in, what comes out, and what you would change after the first month. This is a plan, so say it as one | F1 is a cadence requirement with no evidence yet. The answer is a plan, not a record |
| A3 | A key metric dropped fifteen percent week over week. Walk me through your first hour. | CASE | [generic] | Check whether the number itself changed first (its definition, the data pipeline, a launch), before any explanation. Name the one or two splits you would look at, and what would make you escalate | F3. Tests reasoning and vocabulary, and asks nothing about your past |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Tell me about a report or metric you owned that someone acted on. | EXP | [generic] | Selection scaffold: pick one you owned. Say the decision it changed and who acted on it, and say in one sentence how the number was counted. If nobody acted on one of yours, say so and give the nearest case | F3. An open prompt, with its theme taken from the persona stem |
| B2 | Which assumption behind a metric you have used would you defend least? | EXP | [generic] | Pick a metric you actually used. Name its weakest assumption before they ask. If you have not used one closely enough to name an assumption, say so, and name the definition you would check first | F3. The prober checks whether you know your own assumptions |
| B3 | How would you know a process change worked, and not just that the numbers moved? | JD | [generic] | Name a baseline, a comparison period or group, and one counter-metric that would show harm. Say what you have measured, if anything. If nothing, say what you would set up first | F2 and F3 meet here |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Sixty seconds: why you, over someone who has done this exact job before? | EXP | [generic] | Pause, restate the question in your own words, then answer with the one or two things you can point to. Hold through two follow-ups. Concede a specific gap plainly, and never fold on your core claim just to end the moment | A stress stem. With no CV yet, the position you hold is one you must state yourself; the pack supplies no quoted sentence to hold it with |
| C2 | You would prioritise by intake criteria. What happens when the loudest executive ignores them? | JD | [generic] | Name the criteria, how you would put a request through them, and who decides when the criteria lose. Concede where the tension is real. Hold through two follow-ups | F5. The question is a live tension, not a claim about your past |
| C3 | Tell me about a time you were overruled on a priority. | EXP | [generic] | Selection scaffold: pick a time you were overruled. Say what you recommended, what you did next and what it cost. If you were never overruled, say so and give the nearest disagreement | F5. An open prompt; the theme comes from the pressure stem |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Which part of this role would you be weakest at on day one? | JD | [generic] | Name the one area among the six requirements where you would need the most ramp, and say why in one sentence. Then give a plan for the first 30 and 90 days. The follow-ups will be how you would learn it fastest and who you would ask; answer both in your own words. Do not bluff competence you have not shown | The highest-ROI prep in this pack. This objection is likely in some form, and the material is empty exactly where it bites |
| D2 | Which of these needs is the least proven in your background? | JD | [generic] | Pick the requirement you can least evidence and say so plainly. Give the closest thing you have done, and how you would close the gap | An open choice. It presupposes no negative about your background |
| D3 | Why this role now, and what would keep you here for two years? | EXP | [generic] | Three sentences: what draws you to this role, what you are building toward, and what would make you stay. Give the true reason, even if it is a small one | The skeptic's why-now, why-here, why-leave probe. Motivation has to be consistent with the rest of your answers |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | Tell me about a time you delivered an unpopular truth to leadership. | VAL | [generic] | Selection scaffold: pick a time you said something a leader did not want to hear. Name the stake, the moment you did not fold, and the state of the relationship afterwards. If none comes to mind, say so plainly, then give the nearest one | A values stem. No published values were read, so no value is mapped |
| V2 | When did you put a customer ahead of an internal metric? | VAL | [generic] | Same scaffold. Name the metric, the cost to the customer, and the decision you made. If you have no such time, say so and give the nearest tradeoff you faced | A values stem. Its theme is generic |
| V3 | Tell me about a process you changed because the people using it were struggling. | VAL | [generic] | Pick a process change. Say who was struggling, how you found out, and what changed. If you have not made one, say so and give the nearest case | Ties F2 to the behavioral frame. An open prompt |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | So, walk me through the journey. | EXP | [generic] | A ninety-second arc: where you started, the one or two decisions that moved you, what you are best at now, and why this role. Say only what you have actually done | Casual openers are scored. The arc is a scaffold, not a script |
| E2 | What have you been reading about us lately? | CO | [generic] | Name one or two public things you actually read and say how they bear on operations work. If you have read little, say so and ask what matters most to the team now | No research ran, so nothing about the company's strategy is supplied here |
| E3 | What is the most interesting operations problem you have thought about lately? | EXP | [generic] | Pick one you have worked on or read about. Say the problem, your current view, and what you would test first | Tests curiosity and how economically you communicate |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | Our teams sit side by side. Where is the seam, and what happens when we disagree? | JD | [generic] | Propose principles for the seam: who owns intake, and how a disagreement is settled and escalated. Do not claim knowledge of their seam | The peer stem. Weight is flat until the round type is known |
| G2 | How do you handle credit when work spans teams? | EXP | [generic] | Say how you name contributors in writing and in the room. Give one honest example if you have one, otherwise the practice you would use | A collaboration probe |
| G3 | Tell me about a disagreement with a peer that you had to resolve. | EXP | [generic] | Selection scaffold: pick a disagreement. Say what each side wanted, how it was resolved, and what you would do differently. If none comes to mind, say so, then give the nearest one | A peer probe. Its theme is the seam |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cadence | A2, D1 |
| F2 intake and workflows | A1, B3, V3 |
| F3 metrics and dashboards | A3, B1, B2 |
| F4 launches | A1, G1 |
| F5 priorities | C2, C3 |
| F6 tooling | none, and why: the material names no tools. Once a job description names tools, add questions for them |

## 5. Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none is tied to the interviewer's own path. Add a name to get one.

1. What does a strong first 90 days look like here, and what would you expect me to have in place by then? It lands because it turns the day-one objection into a shared plan.
2. Which decision this team made last quarter would you most want an operations partner to have made faster? It lands because it shows you have read what the team is doing.
3. How do product and operations decisions get made when they disagree? It lands because it probes the seam without asking the interviewer to confess to one.
4. What is the hardest part of this role that does not appear in the job description? It lands because it invites the interviewer to name the real job.
5. How will success in this role be measured, and who sets that measure? It lands because it shows you think in outcomes.
6. If the interviewer is a peer: what could a new person do in their first month that would genuinely help your team? It lands as reciprocity, since the peer is also judging what you would add.

## 6. Prohibited claims

Built locally, because no dossier was supplied. The material holds no sentence of yours, so no inflated form of one can be built. These are the two claims most likely to be reached for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Knowing Stripe's internal metrics, roadmap or recent strategy | No source: both searches were refused, and nothing about the company is in the material | Say what you have read publicly, then ask about the rest. No answer slot |
| Experience with a named tool or process the job description names, before you have checked it | No source: no job description is supplied, and no tools are named in your material | Name only the tools you have used. If none on the list, say you would learn them first |

## 7. Sources

Provided documents: your message, which names the company, the role and the final round, and asks for preparation. No CV and no job description were supplied. No dossier was supplied.

Searches sent, both refused, and nothing was returned or attributed to the company:

- "Stripe company values principles": refused
- "Stripe interview process Product Operations Manager final round": refused

No fetches were sent.

Research tier: L1, searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. The values cheat sheet is absent, because no published values were read and no values-style round is established |
| 2. Stripe interview process, Product Operations Manager | unavailable | Refused. The loop is unknown, so persona weights are flat, not loop-tilted |
| 3. Stripe strategy / recent news | unavailable | No call sent. Would have moved the differentiator questions, including E2 |
| 4. Interviewer name | n/a | No interviewer named, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | No call sent. Would have supplied requirements for the fit snapshot in place of the generic rows |

## 8. Upgrade menu

- Job description text → the six [generic] rows become [grounded] requirements, quoted from the posting, and the coverage table is rebuilt
- Your CV, or a few lines on your ops work → each worksheet row becomes a quoted evidence cell, and each scaffold becomes a story-mapped answer
- The round type and the person you're meeting (hiring manager, peer, skip-level, panel) → persona weights and a tailored reverse question
- The recruiter's prep email → the format of the final (one session or several), any named focus areas, and any assignment to present, each of which adds its own section
- Permission to search, if you grant it → the company's published values (a values cheat sheet, with mapped stories for VAL questions), its interview process, and its recent strategy for the CO questions
- An interviewer's name → persona weights from their public footprint, and a reverse question on their path
- Prep time available → a prioritized schedule
- A tuesday-dossier.md from an earlier session → verified evidence and the objections to rehearse, in place of the generic rows
