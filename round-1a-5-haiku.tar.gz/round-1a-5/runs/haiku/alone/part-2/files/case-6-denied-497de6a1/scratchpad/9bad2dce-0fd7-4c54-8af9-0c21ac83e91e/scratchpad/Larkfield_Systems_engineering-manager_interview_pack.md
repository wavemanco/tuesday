# Larkfield Systems — Engineering Manager — Interview prep pack (loop mode, 3 rounds)

**Candidate:** Yusuf. **Company:** Larkfield Systems (industrial IoT, ~600 people). **Role:** Engineering Manager, two squads building device-management services.
**Rounds:** R1 Tuesday, 45 min, Director of Engineering (hiring manager). R2 Thursday after, 60 min, panel of two staff engineers and a product manager. R3 following Monday, 30 min, VP Engineering ("values and leadership philosophy").
**Built on:** your message and the role summary you gave. No full JD was supplied, and web search was refused, so no company research is in this pack.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether what you did holds up under scrutiny.
- **JD**: role-driven. Tests whether you can do the listed job, gaps included.
- **CO**: company knowledge. Not covered here, since no research ran.
- **CASE**: live problem. Tests structure and reasoning, not a remembered answer.
- **VAL**: values and behaviour. Tests whether past behaviour shows the values, not whether you know a slogan.

Guidance is scaffolding, not a script. Say it in your own words, and if a line does not match what you did, cut it.

## Fit snapshot

Requirements come from your role summary (quoted from your message). Evidence is quoted from your message, with its source named. Confidence is one of high, medium, low, none. Provenance is one of [grounded], [inferred], [generic]. Gap type is one of: none, presentation, transferability, discovery, capability, hard_gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" — role summary | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Your material says backend roles. Say that scope first, then the 40 interviews. Answer slot: if you have owned hiring goals for a team beyond backend roles, say how; if not, say so and say how you would build a hiring plan for 11. |
| F2 | "Lead two squads building device-management services" — role summary | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, for three years. It does not show two squads. Answer slot: if you have led more than one team at once, say so; if not, say so and describe how you would run two. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | Your words already reach delivery: you pushed a reliability quarter through. Reword only, adding no figure or event: "You pushed a reliability quarter through against roadmap pressure, and on-call burden fell 60% afterward." |
| F4 | "partner with hardware and product on roadmap" — role summary | "pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Your material does not show a roadmap negotiation with hardware or product. Answer slot: if you have negotiated a roadmap trade-off with hardware or product, say how it went; if not, say so and describe how you would do it. |
| F5 | "partner with hardware and product on roadmap" — role summary, with the hardware-roadmap gap from your message | "I've never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | Managing managers (not a JD line; your named gap) | "I've never managed managers" — your message | none | [grounded] | capability | Words: "I haven't managed managers." Then how you would work with two leads, said as a plan. |
| F7 | "Lead two squads building device-management services" — role summary (IoT domain) | none given. Your message places you at "currently at a payments company" — your message | low | [inferred] | discovery | Your material is silent on device or IoT systems. Answer slot: if you have worked on device or IoT systems, say which; if not, say so plainly and say how you would learn the domain. |

The pack's own observation, not words for you: your material shows team leadership of six and backend hiring. It does not show two squads, eleven people, or hardware roadmaps.

## Prohibited list

These claims are not coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated (F6) | "I've never managed managers." Plain acknowledgment, no slot. |
| Has owned a hardware-adjacent roadmap | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| Led two squads, or led 11 engineers | Inflated form of F2 and F1 | "3 as a team lead of 6." Your scope, unchanged. |
| The 60% drop was caused by your work alone | Inflated form of F3 | Your sentence says "after I pushed a reliability quarter through", which is sequence, not cause. The pack's observation: the material gives sequence, not attribution. The question "how much was you" is the slot. |

## Persona weights (per round)

| Round | Persona | Weight | Why |
|---|---|---|---|
| R1 Director (hiring manager) | Case/Strategist | top, 4 questions | Hiring managers buy capability and test live problems on their roadmap. |
| R1 | Skeptic | 3 questions | Gap-derisking is the hiring manager's job; managing managers and hardware are the gaps they will press. |
| R1 | Data-Driven Prober | 1 question | Your 60% and 40-interview figures will get a probe, but this round is not the number round. |
| R2 panel, staff engineers | Data-Driven Prober | 4 questions | Staff engineers verify depth and figures. |
| R2 | Peer Evaluator | 3 questions | Staff engineers and the PM are your future partners; they price the seam. |
| R2 | Conversational | 1 question | The PM may open casually; casual questions are still scored. |
| R3 VP (values and leadership) | Values/Behavioral | top, 4 questions | Recruiter named the round values-style. |
| R3 | Pressure | 3 questions | A VP round tests composure on the managing-managers gap and the 60% result. |
| R3 | Skeptic | 1 question | "Why leave, why now" is a standard VP probe. |

Reasoning: the persona priors come from relationship types. The company's values are not in hand, so the R3 values questions are scaffolds rather than mapped stories.

## Round 1 — Director of Engineering (hiring manager), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your first 90 days with two squads and 11 engineers. What do you need to know first?" | CASE | [generic] | Clarify first: the squads' current delivery state, the hardware dependencies, the open roles. Then the plan in order: listen, map risk per squad, roadmap with hardware and product, hiring gaps. Say what you would not change yet. Makes no claim about your past. | Live problem from the role; the hiring manager's first ask. |
| A2 | "You've hired for backend roles. What changes when you own hiring for 11 engineers across two squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" and "own delivery, hiring and growth for 11 engineers" (role summary, your message) | Say what stays the same: the loop, the bar, calibration. Then what changes: the hiring plan across two squads, who owns each role. Answer slot: if you have set a hiring plan for a team beyond backend, say how; if not, say so and describe how you would build one. | F1: the scaling probe. The 40 interviews is a figure, so expect "how was that counted" as a follow-up. |
| A3 | "A squad slips a hardware-dependent release by two sprints. Diagnose it." | CASE | [grounded] "partner with hardware and product on roadmap" (role summary, your message) | Structure: confirm the slip's cause, check hardware dependencies, check the roadmap's assumptions, decide what to change first. Challenge one premise respectfully. Makes no claim about your past. | F4 is discovery; this tests the hardware-partnering reasoning without asking you to claim it happened. |
| A4 | "Which part of this roadmap would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" — your message | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it: hardware constraints, release cadence, who to partner with. Do not add a past. | F5: capability gap, stated by you. |
| A5 | "You've never managed managers. How would you lead two leads?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then the plan as a plan: what you would ask leads in week one, how you would set expectations, what you would coach. Hold through two follow-ups by returning to the plan. | F6 and the highest-ROI prep in the pack. This objection will come in some form, and the deepest rehearsal goes here. Hold the plan; concede specifically on what you would learn first. |
| A6 | "What's your experience with device or IoT systems?" | JD | [grounded] "currently at a payments company" — your message | Answer slot: if you have worked on device or IoT systems, say which and what you did; if not, say so plainly and describe how you would learn the domain. Do not name any device work you have not stated. | F7: the domain gap is silence in your material, so the honest answer is either branch. |
| A7 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Say what you counted, the window, and the baseline — in your words. Name the assumption you would defend least before they do. Say which part was yours: you pushed the quarter through. Answer slot: if you do not know the baseline or window precisely, say so. | F3: defend-the-number slot on a headline figure. Do not supply a method you cannot repeat. |
| A8 | "Where would you hold a roadmap line against product, and where would you give?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Story-map from the quote: the pressure, the quarter, what happened as you stated it. Answer slot: if you negotiated a trade-off with hardware or product, say how; if not, say so and describe how you would hold the line. | F4: discovery on roadmap partnering. |

Round 1 requirement coverage:

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | A1, A3 |
| Own delivery, hiring and growth for 11 engineers | A1, A2, A7 |
| Partner with hardware and product on roadmap | A3, A4, A8 |
| Managing managers (your named gap) | A5 |
| Device / IoT domain (your named gap) | A6 |

### Round 1 reverse questions

1. "What do the first 90 days look like for the squad leads, and what would you expect from me in them?" Why it lands: shows you are planning delivery, not just the job title.
2. "Where is the device-management roadmap most contested with hardware right now?" Why it lands: shows you are already thinking about partnering.
3. "What has made past engineering-manager hires succeed or stall here?" Why it lands: a growth signal that a hiring manager can answer specifically.
4. "How is the hiring plan for the two squads set, and who signs off?" Why it lands: shows you understand the hiring ownership the role carries.
5. "What would make you say this hire was a mistake six months in?" Why it lands: invites the Skeptic to say their worry, which you can then address.

## Round 2 — Panel: two staff engineers and a product manager, 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What does the 60% figure leave out?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Name what the figure excludes, in your own words. Name the assumption you would defend least. Say what part was yours: the quarter you pushed through. Answer slot: if you do not know what it excludes, say so. | F3, a second probe on the same figure from a different member. Rehearse it so the answer does not change between rounds. |
| B2 | "Tell me about a technical decision you made in the last year. What was your part?" | EXP | [generic] | Pick a decision you actually made. Say what you decided, what others decided, and the trade-off you accepted. If you have not made a technical decision recently, say so and describe the nearest one. | An open prompt for the staff engineers. You have no quoted technical decision, so the answer is a selection scaffold. |
| B3 | "You've led a team of six. What breaks at eleven?" | JD | [grounded] "3 as a team lead of 6" — your message | Transferability: say what you would expect to change at eleven: span, cadence, how you check in. Answer slot: if you have run more than one team at once, say so; if not, say so and describe how you would run two squads. | F2: the scaling probe from the staff engineers, who will test whether the scope claim is real. |
| B4 | "Where's the seam between your squads and hardware, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — role summary, your message | Propose seam principles, not a seam you have not seen. Answer slot: if you have disagreed with hardware or product on a roadmap decision, say how it went; if not, describe the principles you would use. | F4: the peer seam, where discovery sits. |
| B5 | "How do you split ownership of device services between two squads so neither waits on the other each sprint?" | CASE | [generic] and [grounded] "Lead two squads building device-management services" — role summary, your message | Structure: clarify the dependency map, define interfaces, decide ownership per service, name the trade-off. Makes no claim about your past. | Peer seam question, live problem. |
| B6 | "How do you handle credit when a reliability quarter spans teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Use "we" for the team and "I" for what you did: you pushed the quarter through. Name who else did what in your own words. Do not claim the outcome alone. | Peer credit-sharing probe, with the values lens from the staff team. |
| B7 | "Walk me through your journey." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | A 90-second arc: nine years of engineering, three as team lead of six, now at a payments company, and why this role, in your own words. Do not add a reason you have not stated. | Conversational opener from the PM. Casual questions are still scored. |
| B8 | "What do you need from product to run two squads well?" | JD | [generic] | Reciprocity: what you bring to product's work, then what you need. Propose a concrete cadence for roadmap decisions. | PM question, weighted on partnership fit. |

Round 2 requirement coverage:

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | B5 |
| Own delivery, hiring and growth for 11 engineers | B3, B6 |
| Partner with hardware and product on roadmap | B4, B8 |
| Managing managers (your named gap) | — none here; covered in Round 1 (A5) and Round 3 (C7) |
| Device / IoT domain (your named gap) | — none here; covered in Round 1 (A6) |

### Round 2 reverse questions

1. "What is the most common reason a device-management change slips here?" Why it lands: shows you are thinking about delivery risk before taking the job.
2. "How do staff engineers and squad leads split the technical decisions?" Why it lands: a question about how the decision rights work, which the panel can answer directly.
3. "What would a new peer on the staff team do in their first month that would genuinely help you?" Why it lands: reciprocity framing with peers, which the panel weights.
4. "Where do product and engineering disagree most on the roadmap?" Why it lands: shows you want the seam, not a sanitised version.
5. "How is technical debt in the device services prioritised against feature work?" Why it lands: a question a staff engineer will care about.

## Round 3 — VP Engineering, 30 min ("values and leadership philosophy")

The company's published values are not in hand, so this round's values questions are selection scaffolds, not mapped stories. Section 10 (values cheat sheet) is omitted until the values are provided.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | The nearest story in your material is the reliability quarter. If that is the story, say what you told leadership, in your own words. If you have a different story, use it. If none comes to mind, say so plainly. | Values round. Your quote reaches pressure, not necessarily an unpopular truth, so the slot stays open. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome and an internal metric pulled apart. Say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you have done. | Values round; no candidate sentence carries a customer story. |
| C3 | "Describe a leadership decision you'd defend." | VAL | [generic] | Pick one decision you made as a team lead. Say what you decided, what you knew, what you would still defend. | Leadership philosophy in the form the VP will probe. |
| C4 | "Tell me about a time you were wrong about a delivery commitment." | VAL | [generic] | Pick one commitment you missed or misjudged. Say what you believed, what was wrong, what you changed. If none, say so plainly and describe the nearest. | Values and self-assessment; a VP probes for honesty about misses. |
| C5 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | Lead with what you have done: nine years, three as team lead of six. Name the gap, managing managers, before they ask. Do not claim what you have not done. | Pressure stem. The internal candidate may have the managing-managers experience you lack. |
| C6 | "That 60% result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Hold: "I pushed the quarter through." Concede specifically: the team carried the work. Name the assumption you would defend least. Do not fold on the decision to push. | Pressure probe on your headline figure. The hold is what you actually did. |
| C7 | "You'd be managing managers you haven't managed. Why should I believe you can?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then the plan in order: what you do in week one, what you would learn first. Hold through two follow-ups. Concede specifically on the first 90 days. | The same objection as A5, in the VP's register. Rehearse once, then in the VP's words. |
| C8 | "Why leave payments, and why now?" | JD | [grounded] "currently at a payments company" — your message | Answer slot: if you have a reason for leaving, say it in your own words. If you have not settled a reason, say so and say what you want from this role. Do not invent a reason. | Skeptic probe on motivation. |

Round 3 requirement coverage:

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | — none here; covered in Round 1 (A1, A3) and Round 2 (B5) |
| Own delivery, hiring and growth for 11 engineers | C6 (delivery) |
| Partner with hardware and product on roadmap | — none here; covered in Round 1 (A3, A4, A8) and Round 2 (B4, B8) |
| Managing managers (your named gap) | C5, C7 |
| Device / IoT domain (your named gap) | — none here; covered in Round 1 (A6) |

### Round 3 reverse questions

1. "What does leadership look like here when a squad misses a commitment?" Why it lands: a values question the VP answers directly.
2. "How do you want engineering leaders to make trade-offs with hardware?" Why it lands: connects the VP's answer to your roadmap gap.
3. "What did the last engineering leader in this role do differently from what you'd want?" Why it lands: an honest signal of what the VP is correcting.
4. "Which leadership behaviour here do you want more of in the next year?" Why it lands: shows you are listening for direction rather than selling.
5. "What would make the first six months a clear success from your side?" Why it lands: asks the VP to define the bar in their own words.

## Sources

- Provided documents: your message (the role summary, candidate background, the three rounds, your named gaps). No JD, no recruiter note on values, no interviewer names.
- Searches sent: "Larkfield Systems company values" and "Larkfield Systems engineering manager interview process". Both were refused (permission not granted), so no results came back.
- No fetches.

**Research tier:** L1 — searches 0 of 6 (2 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet (section 10, omitted) and the mapped stories for C1 and C2. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure; the persona weights follow the named rounds, not a confirmed loop. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO bank and differentiator questions; none in this pack. |
| 4. Interviewer name | n/a | No names given. Interviewer read omitted. |
| 5. Representative JD for the title | unavailable | Would have labelled JD-tagged rows `[inferred]` or lifted them to `[grounded]` from a fetched JD. |

## Upgrade menu

- The full JD text → turns the role-summary requirements into `[grounded]` rows with the JD's own wording, and sharpens A2, A3 and B5.
- The company's published values (pasted) → adds the values cheat sheet and maps C1, C2, C3 and C4 to stories.
- The interviewers' names → persona weights per panel member, and a tailored reverse question for each.
- Recruiter's note on the panel's agenda → reweights the panel's personas and trims the bank.
- Search permission → research at L1 (company values, interview process, strategy) in place of the unavailable targets above.
- A `tuesday-dossier.md` from job-underwriter → one line on what it would add: verified evidence and objection constraints for the rows above.
