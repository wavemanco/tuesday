# Larkfield Systems, Engineering Manager: three-round prep pack (loop mode)

First version. Built from your message alone: the role summary and your background. No full JD, CV, interviewer profile, or values page was provided.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values and behaviour; EXP = your own experience, probed; JD = the role's stated requirements; CO = company and strategy; CASE = a live problem from the role.
- Guidance is scaffolding, not a script. Rehearse it in your own words.
- An **answer slot** is an instruction for the interview: it names the question an interviewer may ask and the two honest branches. It is not a question to answer here.
- Quoted sentences come only from your message, and each carries its source.

## Rounds at a glance

| Round | When | Who | Format | Persona weights |
|---|---|---|---|---|
| A | Tuesday | Director of Engineering (hiring manager, would-be boss) | 45 min | Skeptic 4, Case/Strategist 4, Data-Driven Prober 2 |
| B | Thursday after | Two staff engineers and a product manager | 60 min panel | Peer Evaluator 4, Case/Strategist 3, Data-Driven Prober 2, Skeptic 2 |
| C | Following Monday | VP Engineering | 30 min, "values and leadership philosophy" | Values/Behavioral 4, Pressure 3, Case/Strategist 2, Skeptic 2 |

Weighting reasons: a hiring manager is buying capability and derisking gaps, so the Skeptic and the live-problem questions lead. A panel of peers prices what you add to their work, so the Peer Evaluator leads and the PM contributes roadmap cases. A VP round named as values and philosophy is scored behaviour, so the Values/Behavioral bank leads, with pressure after it. No interviewer profiles were given, so no interviewer-signal adjustments apply. The rounds are a loop, so each round's mini-pack is written to its own weights.

## Fit snapshot (shared across all three rounds)

Requirements come from the role summary in your message, which is not a full JD. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your message gives one team of six for three years. The bridge keeps that scope: "For three years I was a team lead of six." Answer slot: if you have ever led more than one group at once, say how it was split; if not, say so, and say how you would split two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, your message) | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | presentation | Your words already reach hiring, for backend roles: "I run our hiring loop for backend roles." Nothing in them reaches eleven engineers, so that scale is an answer slot in A9, not a claim here. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | discovery | The sentence shows delivery under pressure, not owning delivery across two squads, and the bridge should not stretch it. Answer slot: what you shipped and how you decided what went first, in your own words; if the choice was not yours, say so. |
| F4 | "growth for 11 engineers" (role summary, your message) | none given | none | [grounded] | discovery | Your message says nothing about developing engineers. Answer slot: say what you have done to grow people, in your own words; if you have not done it deliberately, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | discovery | The sentence touches roadmap pressure, not partnership with hardware. Your message does not show how you worked with a non-software partner. Answer slot: any partner outside your own team whose constraints shaped a decision, in your own words; if none, say so. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan. Never a claim to hardware roadmap work. |
| F7 | Managing other managers (role-family requirement, [generic]: the role summary does not say whether there are managers beneath this role) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then a plan for how you would learn it, never a past. The role summary does not say whether managers sit beneath this role; that is an upgrade-menu question. |
| F8 | Device-management services domain (role summary, your message) | none given | none | [grounded] | discovery | Your message places you at a payments company and says nothing about device management or industrial systems. Answer slot: any experience with connected or device-side systems, in your own words; if none, say so and say what you would learn first. |

Gap types follow the routing rule: capability only where you stated the absence (F6, F7), discovery where your material is silent (F3, F4, F5, F8), transferability where adjacent work does not reach the requirement (F1), presentation where a quote already reaches the requirement in other terms (F2). No gate requirements appear in the material.

## Prohibited claims

These claims are not coached anywhere in this pack. Each one has a basis, and each has an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the device-management roadmap" or "I owned a hardware-adjacent roadmap" | Inflated form of F5 and F6, and of your "pushed a reliability quarter through" sentence | Your own sentence at its own scope: "I pushed a reliability quarter through against roadmap pressure." Plus the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." |
| "I cut on-call burden by 60%" as a personal result | Inflated form of "My team's on-call burden dropped 60% after I pushed a reliability quarter through" | The sentence as you wrote it: the team's on-call burden dropped 60% after you pushed a reliability quarter through. |
| "I ran hiring for eleven engineers" or "I ran hiring across the organisation" | Widened from "I run our hiring loop for backend roles" | "I run our hiring loop for backend roles, about 40 interviews last year." |
| "I've managed managers" or "I've led leads" | Stated negative: "I've never managed managers" | The plain acknowledgment only: "I've never managed managers." |
| "I led two squads" or "I led eleven engineers" | Widened from "3 as a team lead of 6" | "For three years I was a team lead of six." |

## Round A: hiring manager, Director of Engineering (Tuesday, 45 min)

**Persona weights:** Skeptic 4, Case/Strategist 4, Data-Driven Prober 2. Director-level hiring managers buy capability and test the gaps, so the Skeptic and live roadmap problems lead. No interviewer profile exists, so the weights stay at the relationship prior.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't managed managers. Two squads and eleven engineers: what happens in your first ninety days?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never managed managers." Then the nearest sentence you have: "For three years I was a team lead of six." Answer slot: if you have led people who led others, say how; if not, say so, and then describe the first ninety days as a plan. Hold through two follow-ups by returning to the team of six. | **Highest-ROI prep in the pack.** F1 and F7 both point here: the largest jump in the role. A Director will test whether you know the gap. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name both gaps plainly, in your words: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Then one ramp plan for each, framed as a plan, not a past. Do not add a third weakness to look humble. | F6 and F7 are the two absences you stated. The question asks for them directly. |
| A3 | "I don't see hardware or device work in your background. How would you handle the roadmap with the hardware team?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Acknowledge: "I've never owned a hardware-adjacent roadmap." Then the nearest true sentence: "I pushed a reliability quarter through against roadmap pressure", at its own scope. Answer slot: what you would ask hardware first. A plan, not a claim of past work. | F6 is the stated absence; the hardware partnership is the role's own requirement. |
| A4 | "Why is this manager role your next step, rather than staying a team lead?" | EXP | [generic] | Selection scaffold: pick the reason you would defend in a second follow-up. If the honest reason is one you have not yet said aloud, say it plainly. If it is not in your material, say so, and do not invent a reason. | Skeptics test motivation consistency. Your message gives no reason, so the answer is yours to supply. |
| A5 | "A firmware change lands mid-quarter, and the device team already has its own release planned. How do you decide?" | CASE | [generic] | Clarify what the change does and who asked for it. Then objective, segmentation by affected devices, approach, metrics, risks. Say the hardware constraint aloud before you answer. | A live problem from the role's roadmap partnership. It needs no claim about your past. |
| A6 | "What would you need to know about our hardware roadmap in your first month?" | CASE | [generic] | Name three questions and the order you would ask them: constraints, commitments, and who decides. Think aloud. | Hiring managers use this to see how you ramp. It needs no claim about your past. |
| A7 | "Device onboarding failures rose 20% last month. Diagnose it." | CASE | [generic] | Clarify scope and period. Segment by device type, firmware version, and region. Name the metric you would trust least, and say why. Name two risks to your diagnosis. | A standard live diagnosis, written generically because no sample metric is in your material. |
| A8 | "You would lead two squads. How would you split their ownership?" | JD | [grounded] "Lead two squads building device-management services" (your message) | Split by domain rather than headcount. Say what you would keep central. Say what you would need to learn first about each squad's work. | The role summary gives the two-squad structure. The guidance makes no claim about your past. |
| A9 | "Walk me through how you ran the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Tell it as the sentence states it: you run the loop, for backend roles, about 40 interviews last year. Answer slot: which steps you designed and which you inherited. If you do not know which were yours, say so. Hire outcomes are not in your material; say only what you can count. | F2 is the bridge into hiring for eleven engineers. The scale question is an answer slot here, not a claim. |
| A10 | "Walk me through how the on-call burden fell 60%. How was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Your beats are the 60% and "pushed a reliability quarter through." Weakest-assumption move: name, in your words, the assumption behind the 60% you would defend least, before the interviewer does. Answer slot: how it was counted. If you know, say it; if not, say that. Which part was yours: say it in your words. | F3's evidence is the 60% sentence, so this probe is likely. Defend the number, do not explain it. |

**Requirement coverage, Round A:** lead two squads → A8, A5; own delivery → A10; hiring → A9; growth → none here, see C3; partner with hardware and product on roadmap → A3, A5, A6; eleven engineers → A1, A8.

**Reverse questions, Round A**

- "What did the last person in this role get right, and what would they have done sooner?" Why it lands: you learn the job's real shape from a manager's view.
- "What would make the first six months a clear success for you?" Why it lands: their success criteria become your plan.
- "Where does the hardware team's roadmap get decided, and who has the final say?" Why it lands: it exposes the seam you will have to work across.
- "What is the hardest tradeoff the two squads faced last quarter?" Why it lands: a concrete problem shows the altitude you will work at.
- "Which gap do you most want this hire to close?" Why it lands: it asks them to name the gap, so you can answer it in the room.

## Round B: panel, two staff engineers and a product manager (Thursday, 60 min)

**Persona weights:** Peer Evaluator 4, Case/Strategist 3, Data-Driven Prober 2, Skeptic 2. The staff engineers are peers, so the Peer Evaluator leads. The PM contributes roadmap cases, so the Case/Strategist sits next. The panel members are not named, so personas are not yet assigned per member.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam. Ask what the seam looks like from their side. Name one kind of disagreement you handle well, in your words. | Peer probes come in collegial form. The guidance makes no claim about your past. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit spanned teams. If none comes to mind, say so, then give the nearest thing your material carries: "I pushed a reliability quarter through against roadmap pressure", at its own scope. Who got the credit is yours to say. | A peer probe on partnership fit. |
| B3 | "Tell us about a disagreement with a peer you resolved." | VAL | [generic] | Selection scaffold: pick one where neither side won outright. If none comes to mind, say so, then give the nearest one you can name. Do not invent a resolution. | Disagreement style with equals is what peers score. |
| B4 | "What would you keep from the device team's current design, and what would you change?" | CASE | [generic] | Say what you would need to learn first. Do not critique a design you have not seen; state the questions you would ask. | Peers test whether you respect what exists before you change it. |
| B5 | "Three customer asks and one reliability debt for device management. How do you prioritise?" | CASE | [generic] | Clarify, then objective, segmentation by customer impact, metrics, and risks. State the trade you would make out loud. | The PM's roadmap case, on the squads' own domain. |
| B6 | "What would you need from hardware before committing a quarter to a device-management feature?" | CASE | [generic] | List the dependencies. Say which one you would raise in the first meeting. | The role's hardware partnership, as a live problem. |
| B7 | "Product wants a feature next quarter. What is the first question you ask?" | JD | [generic] | Ask what outcome the customer needs and what they would cut if forced. Then say your own question. | PM-facing; it tests roadmap instinct, not a past. |
| B8 | "Walk us through the reliability quarter: what did you cut, and what got pushed?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Your beat is "pushed a reliability quarter through." Answer slot: which items were cut or pushed, and who decided. If you did not set the list, say so. | F3 and F5 both touch this sentence. Staff engineers will want the specifics. |
| B9 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Weakest-assumption move: name it in your words before they do. If you do not know how the 60% was counted, say so. | A Data-Driven Prober's standard probe on your headline figure. |
| B10 | "You haven't owned a hardware-adjacent roadmap. What would you bring to the hardware conversation?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Acknowledge: "I've never owned a hardware-adjacent roadmap." Then the nearest true sentence, at its own scope, and what you would ask hardware first, as a plan. | F6, the stated gap, asked by the panel. |
| B11 | "Have you led a group the size of two squads and eleven engineers?" | JD | [grounded] "3 as a team lead of 6" (your message) | "For three years I was a team lead of six." Answer slot: whether any group larger than six was yours. If none was, say so, and say how you would scale. Never claim eleven. | F1: the scale gap, asked directly. |

**Requirement coverage, Round B:** lead two squads → B5, B11; own delivery → B8; hiring → see A9; growth → see C3; partner with hardware and product on roadmap → B5, B6, B7, B10; eleven engineers → B11.

**Reverse questions, Round B** (peer round, so reciprocity is included)

- "What could a new manager do in their first month that would genuinely help your squads?" Why it lands: reciprocity. It frames you as an addition to their work.
- "Where does your work meet the device squads' work, and what has broken there?" Why it lands: it names the seam and shows you looked for it.
- "What does the PM most need from the engineering manager on the roadmap?" Why it lands: it shows you are already thinking about the product partnership.
- "What is one thing the panel would like the new manager to fix first?" Why it lands: it turns a generic question into a commitment you can answer.

## Round C: VP Engineering, values and leadership philosophy (Monday, 30 min)

**Persona weights:** Values/Behavioral 4, Pressure 3, Case/Strategist 2, Skeptic 2. The recruiter's words name values and philosophy, so scored behaviour leads, and a VP's pressure follows. No published values are in hand, so this bank is written from generic values questions. The values cheat sheet is absent for that reason.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Selection scaffold: pick a time the truth landed and you did not fold. If none comes to mind, say so, then give the nearest thing your material carries: "I pushed a reliability quarter through against roadmap pressure", at its own scope. | Values rounds score specific decisions, not slogans. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. If your material shows none, say so, and say how you would decide. | A values question with no evidence in your message; the honest branch is the answer. |
| C3 | "How do you grow engineers who might outgrow the team?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary, your message) | Your material does not show growth work. Say what you have done to grow people, in your own words. If you have not done it deliberately, say so, and say how you would start. | F4 is the discovery gap for growth. The guidance makes no claim about your past. |
| C4 | "Give me your leadership philosophy in a minute." | VAL | [generic] | A ninety-second structure: what you believe, then one decision per belief. Use only decisions in your message: "I run our hiring loop for backend roles", "I pushed a reliability quarter through against roadmap pressure". Do not invent beliefs for yourself. | Conversational in tone and scored. The structure is yours to fill. |
| C5 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold: "I pushed the reliability quarter through against roadmap pressure." Hold through two follow-ups. Concede plainly what the team did. Answer slot: which parts were yours, in your words. If you cannot separate them, say so. | A pressure probe on your headline result. Hold the position you can back. |
| C6 | "Sixty seconds: why should we choose you over someone who has managed managers?" | JD | [grounded] "I've never managed managers" (your message) | Pause and restate the question. Acknowledge: "I've never managed managers." Then hold on the record you do have: "For three years I was a team lead of six." | F7 under composure pressure. |
| C7 | "Why should we trust you with leaders of leaders after six people?" | JD | [grounded] "For three years I was a team lead of six." (your message) and "I've never managed managers" (your message) | Hold the team-lead record. Concede the gap plainly. Give the plan as a plan, never as a past. | The second follow-up on F1 and F7. |
| C8 | "Where does device management fit in a hardware business over the next three years?" | CO | [generic] | No strategy brief was available, so say what you would confirm before deciding. Frame by customer outcomes. Do not pretend to know their strategy. | Strategy altitude. Generic because no company material was available. |
| C9 | "Two squads, and a hardware partner that slips a quarter. What is your call at VP level?" | CASE | [generic] | Clarify the commitment and its cost. Decide what you would protect. Name the risk you would communicate upward first. | A live problem at the VP's altitude. |
| C10 | "Why would hardware engineers trust a leader who has never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Acknowledge plainly. Then the plan: what you would do in the first sixty days to earn trust. | F6 at VP level. |
| C11 | "What decision would you make that you would expect pushback on?" | VAL | [generic] | Selection scaffold: pick a decision you would defend. If none comes to mind, say so, and name the decision you would expect the most pushback on. | Values questions test judgement under disagreement. |

**Requirement coverage, Round C:** lead two squads → C8, C9; own delivery → C5; hiring → see A9; growth → C3; partner with hardware and product on roadmap → C10; eleven engineers → C6.

**Reverse questions, Round C**

- "What does the leadership team mean by values when it has to make a hard call?" Why it lands: the recruiter named values; this shows you are listening for them.
- "What is one leadership habit you would want this role to model for the rest of the org?" Why it lands: it links your philosophy to their expectation.

## Sources

- **Provided material:** your message (role summary and background). No CV, full JD, dossier, interviewer profile, or values page.
- **Research tier:** L1 requested. Searches sent 1 of 6, fetches 0 of 2. The one search was refused, so no research moved this pack.
- **Query sent:** "Larkfield Systems industrial IoT engineering values device management" — refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (section 10), now absent. Round C's values questions stay generic. |
| 2. Larkfield interview process, engineering manager | unavailable | Loop structure, to confirm the three rounds and their formats. Persona weights already follow the named rounds. |
| 3. Larkfield strategy and recent news | unavailable | C8 is generic; a strategy brief would make it specific. |
| 4. Interviewer name | n/a | No interviewer names were given, so no query could be formed. |
| 5. Representative EM JD | unavailable | Would have fixed hard requirements beyond the role summary. |

## Upgrade menu

- Full job description text → turns the role-summary requirements into full-JD lines, may surface mid-list requirements, and may add or change rows in the fit snapshot.
- Names or roles of the panel members → per-member persona assignment for Round B.
- Larkfield's published values, pasted → the values cheat sheet, and Round C's values questions mapped to real values.
- Interviewer names → a reading of each interviewer, one personalised reverse question each, and persona weights from public footprint.
- Whether managers sit beneath this role → resolves F7 and rewrites A1 and C6.
- Any pre-declared deliverable from the recruiter, such as a take-home → a graded deliverables section.
- Your CV → upgrades F1 to F3 from message-level to CV-level quotes.
- Search access → research at L1 (values, loop structure, strategy), which moves Sources rows 1 to 3 and C8.
- Prep time before Tuesday → a prep triage schedule.
