# Atlas Freight, Operations Manager: interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known
**Round:** assumed a hiring-manager round, since the round and who you're meeting were not stated. Persona weights rest on that assumption and will change if it's wrong.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = a stated responsibility or qualification. **EXP** = what you actually did, tested on your own record. **CASE** = a live problem from the role, scored on structure. **CO** = company knowledge (none in this pack, see Sources). **VAL** = published values (none detected).
- Guidance is scaffolding, not a script. Say it in your own words. Where a line says "answer slot," the interview answer is yours to give, and either branch of it is an honest answer.

---

## Fit snapshot

Your JD quotes are verbatim from your message. Your evidence quotes are verbatim from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | The material shows one shift team, not four sites. Your bridge is what you run now, in those words: "I'm a senior shift manager over three supervisors." Answer slot: if you have had operational responsibility beyond one site, say where and what; if not, say so plainly and describe how you would take on four. The JD says "terminal" and your material says warehouse and distribution. The pack does not treat them as the same. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the adjacent work; twelve across sites is the requirement. Bridge: "I'm a senior shift manager over three supervisors." Answer slot: if you have set expectations for, coached or appraised a larger group of leaders, say how many and how; if not, say so and describe how you would structure twelve across four sites. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Seven years is total operations time. Your material does not say how many of those years were in a leadership role. Answer slot: state from your own record how many of the seven years were in a leadership role, and when that began. This is a length-of-experience requirement, so it is graded, not treated as a gate. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is about accuracy, not on-time performance or cost per shipment, and the pack does not stretch it to them. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time or cost per shipment at a site, give the figure and how it was counted; if not, say so and say which of your results you would expect to touch them, and why, as a plan. |
| F5 | "build reporting in Excel/Power BI" (JD, Excel part) | "solid Excel" (your message) | low | [grounded] | discovery | "Solid Excel" is a skill level. It does not say you have built reports. Bridge: "I'm solid in Excel." Answer slot: name a report you built in Excel, what it was for and who read it; if you have not built one, say so. |
| F6 | "build reporting in Excel/Power BI" (JD, Power BI part) | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as past work. Do not claim any Power BI work. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap; the quote already reaches the requirement. Confidence is medium because the certificate has not been inspected. Lead with it in the quote's terms: "green belt certified." Have the certificate to hand. |

**Reading the table.** The thinnest rows are the ones the JD weights most: team scale (F2), multi-site scope (F1) and the on-time and cost metrics (F4). Expect the interview to press there.

---

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure. No guidance cell in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned multi-site terminal operations | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material shows one shift team over three supervisors, not four sites. |
| Leads twelve supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors." |
| Designed the peak-season surge plan | Inflated form of your "ran the site's peak-season surge plan two years running" | The quote at its own scope: you ran it two years running. Which parts you set is an answer slot (D3). |
| Improved on-time performance or cost per shipment | Inflated form of F4 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. |
| Has five years of operations leadership | Inflated form of F3 | The pack's observation: your material gives seven years of operations and does not state leadership years. The slot is F3's. |
| Has built Power BI reports | Negative you stated, F6 | "I haven't used Power BI." No answer slot on this point. |

---

## Persona table

Weights use the hiring-manager prior. No loop source was available, so the round structure is not established for this company and the pack says so. Peer and values rounds are not weighted: the round is unknown, and no values were found.

| Persona | How it shows up | Likelihood and reasoning | Depth | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | Scale and tenure probes: three supervisors against twelve, one site against four, years against the bar | High. A hiring manager is buying capability and checking the gaps. The JD's scale is far from your CV's. | 5 (top) | Rehearse the scale objection until it is plain. Return to the quoted fact, then give the plan. |
| B. Case / Strategist | Live terminal problems: on-time drop, cost up, a first 90 days | High. Hiring managers test whether you can structure an operational problem on the role's own terms. | 5 (top) | Clarify before you structure. Name one assumption aloud. Do not pick a root cause early. |
| C. Data-Driven Prober | The 40% figure, what else moved, and the Excel and Power BI reporting | Medium. Your one process figure is the thing a prober tests first. | 3 (mid) | Say how the figure was counted, in your words, and name its weakest assumption before you are asked. |
| D. Pressure | "Why you over someone who has run a terminal?", "How much of that was you?" | Medium. A stress interviewer is likely at a scope comparison you cannot win on scope. | 3 (mid) | Hold the quoted facts through two follow-ups. Concede the scope gap specifically, then give the plan. Never fold on the result. |
| E. Conversational | "Walk me through the journey." "What are you playing with in Lean?" | Low to medium. Casual, but still scored, and the Lean question is a plus-skill asked lightly. | 2 (low) | Practise a 90-second arc from your quoted facts. Answer the Lean question with the belt and any project you can name. |

---

## Question banks

Question types are one token each. Rationale refers to your history only by fit-snapshot row.

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. How would you run twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "lead a team of 12 supervisors" (JD) | Start from the fact, in those words: "I'm a senior shift manager over three supervisors." Then describe how you would structure twelve across four sites, as a plan, in your own words. Answer slot: if you have set expectations for, coached or appraised a larger group of leaders than three, say how many and how; if not, say so plainly and go to the structure. Hold through two follow-ups by returning to the three-supervisor fact and the plan, never by describing twelve as if you have run them. Concede specifically: name the first thing you do not yet know, such as each site's supervisors. | **Highest-ROI prep in this pack.** This is the scale objection in its plainest form. F2 and F1 are where the material is thinnest, so this is where a rehearsed, non-defensive answer does the most. JD because it scores the stated team size. |
| A2 | "The role needs five years of operations leadership. Which of your years were leadership years?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "5+ years operations leadership required" (JD) | Give the total first, in your words: "seven years in warehouse and distribution ops." Then the leadership years, from your own record, with the year they began. Answer slot: if your leadership years total five or more, state them with the start date; if fewer, say the number and that the bar is five. Count leadership only where you held a role that led people, and say which role it was. | F3 is the thinnest JD line. The question's premise is the JD's. The guidance does not adopt it. JD because it scores a stated requirement. |
| A3 | "Terminal work isn't warehouse work. What have you done in a terminal?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "Own daily terminal operations across 4 sites" (JD); "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message) | Say the warehouse and distribution years in those words. Then name what carries across, each at its own scope: the pick-path redesign and the peak-season plan you ran. Answer slot: if you have worked in a transport terminal, such as a cross-dock, yard or linehaul, say where and when; if not, say so plainly and name the terminal processes you would learn first. Do not call warehouse work terminal work. | F1: the pack's observation is that your material says warehouse and distribution, and the JD says terminal. The guidance keeps those apart. JD because it scores the stated scope. |
| A4 | "On-time and cost per shipment are the numbers we run on. Have you moved either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); "drive on-time performance and cost-per-shipment down" (JD) | Hold on what you measured: "I cut mis-pick rate 40% by redesigning the pick path." Say, in your words, that on-time and cost per shipment are different measures from mis-picks. Answer slot: if you have moved on-time or cost per shipment at a site, give the figure and how it was counted; if not, say so plainly and say which of your results you would expect to touch them, and why, presented as a plan. Hold through two follow-ups on the mis-pick figure. Do not stretch it to the named measures. | F4: the material shows accuracy, not on-time or cost per shipment. That limit is the pack's observation, not words for you. JD because it scores the stated metrics. |
| A5 | "The role builds reporting in Excel and Power BI. Have you built reports in Power BI?" | JD | [grounded] "never used Power BI" (your message); "build reporting in Excel/Power BI" (JD); "solid Excel" (your message) | Plain acknowledgment first: "I haven't used Power BI." Then your Excel level in your own words. Then a learning plan, marked as a plan, with how and by when you would learn it. Claim no Power BI work, and do not present your Excel level as reporting you have built unless you can name the report. | F6 is a capability gap you stated. The honest answer is the negative and a plan. The Excel line is the only other thing your material supports (F5). JD because it scores a stated tool. |

### B. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites dropped eight points last month. Walk me through your first week." | CASE | [generic] | Clarify first: what "on time" counts, and whether the drop sits in one lane, one shift or the whole site. Then objective, segments, approach, metrics and risks. Name one assumption aloud. Do not pick a root cause before you have looked. Speakable in 90 to 120 seconds. | A live problem from the JD's on-time line. CASE because it scores structure. No claim about your past, so the label stands alone. |
| B2 | "Cost per shipment is up at all four sites. Where do you start?" | CASE | [generic] | Clarify the definition of cost per shipment and whether volume changed. Split cost into the parts you can see. Name the one data cut you would check first. | A live problem from the JD's cost-per-shipment line. No claim about your past. |
| B3 | "You inherit four sites with four different on-time numbers. What do you do in your first ninety days?" | JD | [generic] | Structure it: one definition of on-time before one target; a site-by-site read; the first change you would make; what you would report weekly. Name what you would need to see before you judge a site. | The JD's four-site scope and on-time line together. CASE in delivery. No claim about your past. |
| B4 | "Two sites measure on-time differently. How do you settle it?" | CASE | [generic] | Name the two definitions, who owns each measure, and the one definition you would set and why. Do not take a side before you have seen both. | A live problem from the four-site scope and the reporting requirement. |
| B5 | "Peak starts in six weeks and your labour plan is fifteen percent short. What do you do this week?" | CASE | [generic] | Clarify the basis of the forecast. Then the options, with their cost and service trade-offs. Name the trade-off you would escalate rather than decide alone. | A live problem on daily terminal operations. No claim about your past. |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how it was counted, in your own words. Answer slot: if you can say how it was counted, say it; if you cannot, say so plainly. If someone else kept the count, say that. Name the weakest assumption before you are asked (C2). | F4's quoted figure is the one number a prober tests first. EXP because it tests what was actually yours. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption in your own words before the interviewer does. If you do not know of one, say you have not tested the figure. The pack does not name an assumption, because your material does not. | The weakest-assumption move the rubric asks for on any figure. Shows self-awareness about the one number you have. |
| C3 | "Did the pick-path change move anything besides mis-picks? What did you check?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you checked and what you did not. Answer slot: if you tracked a second effect, name it and the figure; if you did not check, say so plainly and say what you would check first. If the redesign was a team's, say which part you led. | Probes whether the mis-pick result reached the on-time and cost measures (F4). EXP because it asks what you verified. |

### D. Pressure (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a multi-site terminal?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "Own daily terminal operations across 4 sites" (JD) | Restate the question in one line. Then answer with your three strongest facts, each in the words your material gives: seven years in warehouse and distribution, the pick-path result, the peak-season plan you ran. Answer slot: if the four-site scope is one you have not held, say so in your own words; if you have held it, say where. Hold through two follow-ups. On the second, concede the specific gap and give your plan, not a stronger claim. | F1 and F2 are the scope gap, and a comparison with a multi-site candidate cannot be won on scope. Pressure stem, so the test is composure. |
| D2 | "That's a 40% cut in mis-picks. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the result you stated. Answer slot: say which part of the redesign you did, in your own words; if it was a team's, say which part you led. Hold through two follow-ups. Concede specifically and never fold on the result itself. | A pressure version of C3. The question tests whether you can own your share without inflating it. |
| D3 | "You ran the peak-season plan for two years. Did you set it, or run it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Use the sentence's own verb: you ran the plan two years running. Answer slot: if you set any part of it, say which and how you decided; if you ran a plan someone else set, say so plainly. The two-year fact stands either way. | The "ran" against "set" probe. The inflated form, "designed it," is listed in the prohibited claims. |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: where you started in warehouse and distribution, the pick-path result, the peak plan, where you are now. Each beat is a clause your sentences state, in those words. Do not add an employer, a title or a year you have not given. | F1 and F2 carry the arc, and the arc uses only what they quote. A casual opener is still scored. |
| E2 | "What are you actually playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message); "Lean/Six Sigma a plus" (JD) | Name the Green Belt in your words. Answer slot: if you applied Lean to a project, name it and what you changed; if the belt was training only, say so plainly. | F7: a plus-skill asked casually, which is still scored. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B3, D1 |
| Drive on-time performance and cost-per-shipment down | A4, B1, B2, B4 |
| Lead a team of 12 supervisors | A1 |
| Build reporting in Excel/Power BI | A5 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | E2 |

---

## Reverse questions

Each one has a "why it lands." No interviewer profile was available, so none is tied to a career path.

1. "How is on-time performance defined today, and is it the same across all four sites?" Why it lands: you learn whether the B4 problem exists before anyone asks you to solve it.
2. "What does reporting look like now, which tools, and who reads it each week?" Why it lands: it shows you where Power BI sits and gives A5's honest answer a place to land.
3. "How is the twelve-supervisor team split across the sites?" Why it lands: it shows you have thought about the team's shape, which is the scale in A1.
4. "What would you most want the person in this role to have changed in twelve months?" Why it lands: it names the success measure without asking you to guess.
5. "Which site is furthest from its cost-per-shipment target, and what do the people there say is causing it?" Why it lands: it shows you are ready for the real problem, not the brochure version.
6. "Where does the operation most often get out of step with its plan, and how quickly does the team find out?" Why it lands: it turns a generic question into one about how the role's daily work is run.

---

## Sources

**Provided documents:** your message, containing the job description and your background.

**Searches and fetches sent:**
- "Atlas Freight regional logistics values": refused. Permission to search was not granted in this session.
- "Atlas Freight interview process operations manager": refused. Same reason.
- "Atlas Freight logistics news strategy 2026": refused. Same reason.
- No fetches were attempted.

**Research tier:** L1. Searches 0 of 6 ran, 3 refused; fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have produced the values cheat sheet. Dropped, because no values are in hand and no values-style round was detected. |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have named the rounds and set persona weights. No loop source established the loop, so the persona table rests on the hiring-manager prior, not on this company's documented process. |
| 3. Atlas Freight strategy and recent news | unavailable | Would have fed the CO bank. The CO bank is empty, and the CASE questions are generic. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

**Dossier:** none present.

---

## Upgrade menu

- Atlas's values page, pasted → the values cheat sheet, and VAL questions mapped to your stories.
- Atlas's interview process, or your recruiter's note on the rounds → named rounds and persona weights from the loop, in place of the hiring-manager prior.
- Atlas's strategy or recent news, pasted → the CO bank, which is currently empty, and sharper CASE questions.
- The full posting text → any requirement the summary line in this pack left out, such as the reporting line, the site list, and how "terminal" is used.
- Your CV → F1 to F7 move from your message to your CV, and F3's leadership years can be checked against it.
- The Green Belt certificate → F7's caveat goes and its confidence rises to high.
- The interviewer's name → a tailored reverse question and persona weights from their public background.
- Your recruiter's note on what the round covers → coverage of any pre-declared deliverable.
- Web search permission → the three L1 targets above can run, which would fill the values, process and strategy rows.
- A `tuesday-dossier.md` → verified evidence and locked prohibited claims in place of the local versions.
