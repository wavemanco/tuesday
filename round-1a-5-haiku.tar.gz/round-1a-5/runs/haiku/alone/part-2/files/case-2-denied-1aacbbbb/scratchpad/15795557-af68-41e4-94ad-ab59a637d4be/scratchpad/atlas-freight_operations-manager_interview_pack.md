# Atlas Freight: Operations Manager interview pack

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round: assumed to be a hiring-manager round; confirm and the persona weights will be recomputed.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Types used: **EXP** (work-experience deep-dive), **JD** (role-driven), **CASE** (live problem). **VAL** and **CO** are absent: no values were supplied and research has not run. Guidance is scaffolding, not a script. Say it in your own words.

## Persona weights

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on four terminals, on-time performance and cost per shipment | High | Hiring-manager prior; the JD reads as a list of operating problems | Clarify the metric definitions first, then structure, then act |
| Skeptic | The 3-supervisor vs 12-supervisor gap, the 5+ years line, Power BI | High | Three JD requirements your material meets only in part or not at all | Rehearse the one most predictable objection until it is plain; calibrated candor |
| Data-Driven Prober | The 40% mis-pick figure and the peak-season plan | Medium | Headline numbers get probed for how they were counted | Say how it was counted, and name the weakest assumption before they do |
| Pressure / Stress | Time-boxed challenge to your scale and your tools | Medium | Ops leaders often test composure under a clock | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational / Rapport | Opener and any "anything else?" close | Low, but scored | Casual openers are still scored | A 90-second arc you can speak from memory |

Weights: Case 5 questions, Skeptic 4, Prober 4, Pressure 3, Conversational 2. Total 18.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows shift leadership over three supervisors, not four sites. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have run work across more than one site or shift, say which and what you were accountable for; if not, say so and say what you would do first at each site. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led a group of that size, say so; if not, say the scale is new and name the part you think carries over, in your own words. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | The material shows years in the field, not years leading people. Answer slot: say the year you first led people and the scope since. If the honest count is under five years, say so. Do not round up. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy measure, not on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time performance or cost per shipment, say the measure and your part; if not, say how you would baseline both first. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | transferability | Excel is the tool you named, but no report you built is in your message. Answer slot: name one report you built in Excel, who used it and what it changed; if none exists, say so. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. The certificate has not been inspected here, so expect a probe on what you applied it to. Words: "green belt certified." |

No requirement in this JD is a gate (a licence, location, right to work or similar term), so no gate row appears.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "I'm currently a senior shift manager over 3 supervisors." The limit is this pack's observation: your material shows one shift's leadership. |
| Led twelve supervisors | Inflated form of F2 | "I'm a senior shift manager over 3 supervisors." The limit is this pack's observation. |
| Five years of operations leadership | Inflated form of F3 | "7 years in warehouse and distribution ops." Years leading people are not in your material. |
| Moved on-time performance or cost per shipment | Inflated form of F4 | "I cut mis-pick rate 40% by redesigning the pick path." |
| Built Power BI reporting | Negative you stated, F6 | "I haven't used Power BI." No answer slot. |

## Question banks

### Bank A: Case / Strategist (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're taking over daily operations at four terminals. What do you look at in week one, and what do you need to know before you change anything?" | CASE | [generic] | Clarify first: which site is weakest, what each on-time and cost number measures and how each site counts it, what the shifts and constraints look like. Then structure: segment by site, shift and lane, then first actions. Speakable in 90 seconds, with no claim about your past. | A live problem from the JD's "Own daily terminal operations across 4 sites." It presupposes nothing about you. |
| A2 | "On-time performance is down at one of your four sites and cost per shipment is up. Where do you start?" | CASE | [generic] | Separate the two before solving either. Is on-time a dock, linehaul or cutoff problem, and does cost rise with it? Name the metric definitions before any fix. Offer a diagnosis path, not a conclusion. | Tests the two JD metrics as structure, not recall. |
| A3 | "What would you commit to on on-time performance and cost per shipment in your first six months, and how would you measure it?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Commit to a method and a baseline, not a number you cannot defend: "I'd baseline both first, then set a target per site." Name the definition you would check before setting the target. | Scores the JD's two stated metrics directly. No baseline is given, so the honest commitment is a method. |
| A4 | "How have you used Lean or Six Sigma on a real operations problem?" | JD | [grounded] "green belt certified" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Story-mapped on F7 and F4: the Green Belt, and the pick path you redesigned, where you cut mis-pick rate 40%. Answer slot: if a specific Lean or Six Sigma method was used on the pick path, say which and what you did with it; if none was, say so plainly and describe how the redesign was done. | "Lean/Six Sigma a plus" is the requirement; the pick path is your only real example of it. |
| A5 | "Sketch a 90-day plan to bring cost per shipment down at one site without hurting service. What do you need to know first?" | CASE | [generic] | Clarify cost categories, service commitments and decision rights before proposing changes. Offer two or three levers and the one you would test first. Name what would stop you. | A live version of the cost-per-shipment line. It asks for a plan, not a past. |

### Bank B: Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for five years of operations leadership. Walk me through the leadership years you have." | JD | [grounded] "5+ years operations leadership required" (JD); [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: say the year you first led people and the scope since. The material shows seven years in the field, not years leading. Hold with the years you can state, and concede the exact count if it is under five. Do not round up. Hold through two follow-ups by returning to the count, never by adding to it. | **Highest-ROI prep in this pack.** The JD's line is the scoring sheet, and your evidence is thinnest exactly here (F3). Expect three levels of follow-up. |
| B2 | "You're over three supervisors now. What makes you ready to lead twelve?" | Skeptic | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "lead a team of 12 supervisors" (JD) | Hold the scale as it is: you lead three supervisors now. Bridge only with what that quote carries. Answer slot: if you have led a larger group, say so; if not, say the scale is new and name the part you think carries over, in your own words. | F2's gap. The probe comes on the JD's team size. |
| B3 | "You're a shift manager over three supervisors. Why would four sites work?" | Skeptic | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Answer slot: if you have worked across more than one site or shift, say which and what you were accountable for. If not, say so and say what you would do at each site in the first 30 days. Add nothing to the quote. | F1's transferability. The probe lands on the gap between one shift and four sites. |
| B4 | "You've never used Power BI. How would you build the reporting this role needs?" | Skeptic | [grounded] "never used Power BI" (your message); [grounded] "solid Excel" (your message) | Plain acknowledgment: "I haven't used Power BI." Then the Excel you have, in your words, and a plan for Power BI stated as a plan. Answer slot: name one report you built in Excel, its audience and its effect, if one exists; if none does, say so. | F6 and F5. Power BI is a stated gap, and the honest bridge is Excel plus a plan. |

### Bank C: Data-Driven Prober (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number in your own words. Answer slot: say how it was counted, the period it covers and who measured it. If you counted it yourself, say how; if someone else produced the figure, say so. The pack does not supply a baseline or period. | F4 is the headline metric. Every headline figure gets a defend-the-number question. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before they do, in your own words, from what you know about how it was counted. If you do not know how it was counted, say so plainly. | Converts a gotcha into a credibility gain. |
| C3 | "You ran the peak-season surge plan two years running. What did you set, and what was set for you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story from the quote: you ran it, two years running. Answer slot: name which parts of the plan you set and which came from above. If you set none of it, say so and describe what you ran. | The closest evidence in your material to the JD's throughput and cost goals, so expect a probe on attribution. |
| C4 | "What's the first report you would build for this team, and what decision would it change?" | JD | [grounded] "solid Excel" (your message); [grounded] "build reporting in Excel/Power BI" (JD) | Name the decision before the chart. Start in Excel, the tool you have, and say what Power BI would add later, as a plan. Answer slot: if you have built a report that changed a decision, say which; if not, say so. | The JD's reporting line. It tests whether you think decision-first. |

### Bank D: Pressure / Stress (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you to lead twelve supervisors when you lead three?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause. Restate the question. Anchor in the quote. Hold through two follow-ups. The position you hold is the one the quote carries, and the scale is what you concede, specifically: the twelve-supervisor scope is new to you. Never fold on the pick-path result itself. | Pressure check on B2. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold then concede: say which part you designed, in your own words. Concede any part you cannot separate from others' work, specifically. Answer slot: if others' changes shaped the result, say so. Never fold on the redesign itself. | An attribution honesty probe. |
| D3 | "You've never used Power BI. Why would we hire you to run reporting?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I haven't used Power BI." Do not present the gap as a strength. Concede specifically: the tool is new to you, and name how you would learn it. | Composure check on F6. |

### Bank E: Conversational / Rapport (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | A 90-second arc using only these beats, in this order: seven years in warehouse and distribution, now a senior shift manager over three supervisors, the pick path you redesigned, the peak plan you ran. Add no roles or dates you have not given. | Casual openers are scored. This is the sequence you can say without inventing beats. |
| E2 | "What would you want sorted out in your first month here?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD) | Name a sequence: learn each site's numbers and how they are counted, meet the supervisors, then pick one metric to baseline. A plan, not a past claim. | The JD's opening line, asked as a casual close. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, B3, E2 |
| Drive on-time performance and cost-per-shipment down | A2, A3, A5 |
| Lead a team of 12 supervisors | B2, D1 |
| Build reporting in Excel/Power BI | B4, C4, D3 |
| 5+ years operations leadership required | B1 |
| Lean/Six Sigma a plus | A4 |

## Reverse questions

No interviewer profile exists, so none is tied to a career path. The round is assumed to be a hiring-manager round, so no reciprocity question is included.

| Question | Why it lands |
|---|---|
| How is on-time performance defined today, and is it the same at all four sites? | Shows you would check the metric before setting a target. |
| What is in the cost-per-shipment figure, and who owns each part? | Shows you think in cost drivers, not totals. |
| How are the twelve supervisors split across the sites, and what is the span of control now? | Tests the scale you are being asked to take on. |
| What reporting does the team use now, and is Power BI in use or planned? | Turns your gap into a question about their plan, not a confession. |
| What would make this hire the right call six months from now? | Asks for the scorecard directly. |

## Sources

- Provided documents: the JD text you pasted; your message describing your background.
- Searches and fetches: none run. Research is at L0 (provided documents only) until you answer question 2 below.

Research tier: L0. Research consent pending.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section 10) would map four principles; the section is dropped because no values were supplied |
| 2. Atlas Freight operations manager interview process | unavailable | Loop structure; persona weights would follow the named rounds |
| 3. Atlas Freight strategy / recent news | unavailable | Company and strategy questions (CO); none are in the pack |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer name was given |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Who you are meeting and your relationship to them → persona weights recomputed; the hiring-manager prior is replaced
- Research consent → company values, the interview loop and current strategy questions (CO), so the pack stops being generic on the company
- Your answer to B1's leadership-years slot → that answer becomes quoted material, moving B1 from slot to story
- Your answer to C1 on how the 40% was counted → that answer becomes quoted material, and D2 gets a grounded first branch
- A tuesday-dossier.md from an earlier underwriting run → verified evidence rows in place of the quotes in the fit snapshot
