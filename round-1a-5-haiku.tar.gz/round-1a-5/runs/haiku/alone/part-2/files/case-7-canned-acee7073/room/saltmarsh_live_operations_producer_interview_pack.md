# Saltmarsh Games: Live Operations Producer. Interview prep pack

**Round:** Hiring-manager interview, 60 minutes, with Tobias Wrenfield (Head of Live Operations).
**Assumption:** Saltmarsh's careers page describes the hiring-manager round as the "Outage Hour": a live-incident tabletop, then a values conversation. I built the pack on that format. If Tobias is not your hiring manager, the persona weights below will shift.

---

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse it out loud until it sounds like you.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioral | Whether past behavior shows Saltmarsh's published values |
| EXP | Experience deep-dive | Whether your CV claims hold up, and what you did yourself |
| JD | Role / JD-driven | The listed responsibilities and requirements, gaps included |
| CO | Company knowledge | Whether you know the company's current position |
| CASE | Live problem | Structure and reasoning on a problem from this role |

---

## 1. Fit snapshot

Requirements are quoted from your JD. Evidence is quoted from your message (your background as you wrote it). "Gap type" follows the routing rule in the skill's output template.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows a content-drop calendar for one title, not a live-events calendar for two. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned live events or ran a second title's calendar, say which and how; if you did not, say so and say how you would approach two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given for those four teams. Nearest: "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material shows work with QA, not with design, art, engineering or community. Answer slot: name which of those teams you coordinated with on an update and how decisions were made between them; if you did not coordinate with one of them, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows presenting monthly retention numbers, not owning a post-event review. Words: "Presented the monthly retention numbers to the studio head." Answer slot: if you ran a post-event review, say what it covered and what it reported; if you did not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms: you wrote the checklist, and QA still uses it. Words: "Wrote the release checklist our QA team still uses." Nothing is added. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years reaches the years requirement. Your material does not show that the work was live-service, or that it was at producer level. Answer slot: if you produced at producer level, say which work; if you did not, say what you did as an associate producer on a live title. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Expect a probe, because the claim has limited inspectable proof. Words: as quoted. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Your material does not show how retention was counted, so expect that probe (D1). |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact, used by another team, reaches the requirement. Words: as quoted. Nothing is added. |
| F9 | Not in the JD: your own flagged gap | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated the absence, so the words come from that statement. Words: "I haven't worked on a game with in-app purchases." No answer slot. The JD does not mention in-app purchases, so this is a gap you raised, not one the JD asks for. |

Confidence and gap type are separate calls. F6 and F7 are medium confidence with no gap, because the quote already reaches the requirement. F2 is low because the material is silent on four of the five teams.

**Note on team leadership.** You wrote that you have never led a team. The JD does not ask for it, so there is no row. If it comes up, the plain acknowledgment is: "I haven't led a team."

---

## 2. Prohibited claims

These are the claims this pack will not coach. Each one is a stretched form of a sentence you wrote, or a negative you stated.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the live-events calendar for two titles" | Inflated form of F1 | The quote at its own scope. Your material says a weekly content-drop calendar for one title. |
| "Owned the post-event review and its KPIs" | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." |
| "Managed the release checklist with QA" | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |
| "Led design, art, engineering and community coordination" | Inflated form of F2 | No quote supports it. The answer slot in F2 applies. |
| "Produced live-service content end to end" | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Any claim to in-app purchase experience | Your stated negative, F9 | "I haven't worked on a game with in-app purchases." |
| Any claim to having led a team | Your stated negative | "I haven't led a team." |

---

## 3. Interviewer read

Public footprint only. This comes from one search result, not a fetched page.

- **Career pattern:** A GDC 2026 talk entry describes Tobias as Head of Live Operations at Saltmarsh, previously a QA lead at a console studio.
- **Self-described argument:** His talk title is "Patch Notes Are a Promise". Per the entry, his argument is that a live team is judged by how often its patch notes describe what actually shipped.

**Implications:**
1. Expect questions about the gap between what is announced and what is built. This connects to the Outage Hour and to the value "Ship the Patch Not the Promise".
2. Your release-checklist sentence (F4) is the nearest match to his QA background. Use it as a mirror, but only in your own words.
3. Do not claim you share his path. Your background is QA-adjacent, not QA-led, and no quote shows a move from QA into live operations.

**Shared jump:** None offered. No quoted sentence carries the candidate's side of a career move like his.

---

## 4. Persona table

| Persona | How it shows up | Weight | Why | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Outage Hour tabletop on a live event; plan and diagnose problems | 5 | The Outage Hour is a live-incident tabletop, per the careers page; hiring managers scope the role this way | Clarify, then objective, then the decision path. Think aloud. |
| Values / Behavioral | The values conversation after the tabletop | 3 | The careers page names a values conversation; the three published values are concrete | Map each value to a quoted sentence, or give a selection scaffold ending in an honest branch |
| Skeptic | Probes the gaps: producer-level scope, coordination across four teams, in-app purchases | 3 | The hiring-manager prior is case plus skeptic; your fit snapshot has three medium and one low row | Rehearse the top objection until it is boring. Hold, then concede the gap plainly. |
| Data-Driven Prober | Asks how retention was counted, and what assumption you would defend least | 3 | You presented retention numbers; the JD asks for comfort with retention metrics | Say how it was counted if you know. If you do not, say so. |
| Pressure | Interrupts, time-boxes, questions your ownership | 2 | Mid-weight for a 60-minute round | Pause, restate, hold through two follow-ups |
| Conversational | Opens with "walk me through the journey" | 2 | Hiring managers often open this way | Use a 90-second arc built on quoted sentences |

Weights total 18, within the 18 to 26 range. Depth follows weight.

---

## 5. Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd run the first hour of a simulated outage during a live event." | CASE | [generic] | Clarify: what is broken, which players are affected, which build, and where the live event stands. Then the objective: stop player harm and restore the core loop. Then communications, owners, and the rollback-or-hotfix decision. End on what you would announce and when, since announcements should match what is built. | The Outage Hour format, per the careers page. The question is a live problem, so it makes no claim about your past. |
| A2 | "A live event starts in 48 hours, and a content drop lands the same day with a QA sign-off still open. What do you do?" | CASE | [generic] Raising source: "manage the release checklist with QA" (JD) | Name the decision: hold the drop, or ship behind a QA gate. Say who decides, what the checklist says, and what gets announced. | The JD's checklist line raises it. The scenario is generic, so it claims nothing about your past. |
| A3 | "Retention dropped five points in the week after an event. Diagnose it." | CASE | [generic] | Clarify the event dates and what changed. Segment by cohort, platform and region. Separate the event's effect from normal seasonality. Check instrumentation. Name the first thing you would pull. | The JD asks for comfort with retention metrics, and this tests it as a diagnosis. |
| A4 | "Plan the calendar for two titles over the next quarter. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify shared engineering, QA capacity, event overlap between titles, and community cadence. Answer slot: if you ran more than one title's calendar, say so; if you ran one, say how you would extend that process to two. | F1 is the closest evidence. The question's premise is the JD's, not your history. |
| A5 | "Walk me through how the weekly content-drop calendar worked." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the cadence and the sign-off path in your own words. Answer slot: if you set the sign-off path, say how; if it was set for you, say so. | F1 and F6. This is a premised question, and it presupposes only what your quote states. |

### B. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a dated plan conflicted with what players were showing. It needs a named signal, a decision you made, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented, and how you raised them. | Maps to "Players Before Plans". F3 is the nearest quote. The material does not show the conflict, so this is a scaffold. |
| B2 | "Tell me about a release where what you announced ran ahead of what was built." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if such a release happened, say what was announced, what had shipped, and what you changed afterwards; if none did, say so plainly, then describe how you would keep an announcement to what the checklist has passed. | Maps to "Ship the Patch Not the Promise". F4 is the nearest quote, and it does not show any such release. |
| B3 | "What did you leave in better shape than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote, and that the team still uses it. Do not say it is better than what you found, because your quote does not say so. If you left anything else behind, say what. | Maps to "Leave the Build Greener". The quote carries persistence, not improvement. |

### C. Skeptic (weight 3, four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've been an associate producer for four years. What have you produced end to end?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | **Highest-ROI prep in this pack.** Hold: "I was an associate producer at a puzzle-game studio for four years." Answer slot: name one piece you took end to end; if you did not, say so and say what you ran day to day. Concede the gap plainly: "The producer-level scope is what I haven't yet shown." Then give the plan for closing it, and do not describe a past you did not have. | F5. This objection will arrive in some form, so the non-defensive answer is the one to rehearse most. |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name the weakest part from the JD in your own words: coordinating four teams on each update (F2). Then say how you would start. | Persona stem. It is a generic question, so it asks for no claim about your past. |
| C3 | "I don't see design, art, engineering or community work in your background. How would you handle that here?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: name the team you coordinated with most on an update, and how decisions were made between you; if you coordinated with none of the four, say so plainly and say how you would start. | F2. The premise is the interviewer's reading of your material, which is silent on four of the five teams. |
| C4 | "Have you ever owned a post-event review?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say what you presented. If you ran a post-event review, say what it covered and reported; if you did not, say so plainly. | F3. The honest answer is available whether or not you ran one. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was that monthly retention figure counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how it was counted if you know. If you do not know, say you do not know how it was counted. Do not explain a method you cannot repeat. | F7. Your material does not show the method. |
| D2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption before they do, if you know one. If you do not, say so plainly. | Metric-defence move, from the prober's counter-strategy. No figure is given, so no number needs defending. |
| D3 | "Did any content drop move retention, and how would you tell?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you can see and what you cannot. If no drop can be credited, say so. | F6. The question presupposes nothing: it asks whether an effect exists at all. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire an associate producer for a live-operations producer role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: state the calendar and the years in those words. Do not apologize. Concede the gap plainly: "The scope I haven't shown yet is producer-level ownership. Here is how I'd close it in the first ninety days." | F5 and F1. Hold through two follow-ups before conceding anything. |
| E2 | "That checklist. How much of it was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Answer slot: if others changed it, say what they changed; if you wrote it alone, say so. | F4. Attribution is the probe. Say what you did and no more. |

### F. Conversational (weight 2, three questions for coverage)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the puzzle studio, the weekly calendar, the checklist, the retention presentation. Each beat is one quoted sentence. | Persona stem. Rapport openers are scored too. |
| F2 | "What from the puzzle studio's live model would you carry over?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Name one practice from the calendar and say why it would carry over. If none would, say so. | Tests the fit between your current work and this role. |
| F3 | "If you handed the release checklist to a new QA lead, what would its first page say?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | State the checklist's purpose in your own words, from what it does. Do not add rules it does not contain. | Tests "clear written communication" directly. |

---

## 6. Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A4, A5, F1 |
| Coordinate design, art, engineering and community teams | C2, C3, A2 |
| Own the post-event review and the KPIs it reports | C4, D1, D2 |
| Manage the release checklist with QA | A2, B2, E2 |
| 3+ years producing live-service games or apps | C1, E1 |
| Experience running a content calendar | A5, D3 |
| Comfortable with player-retention metrics | A3, D1, D2 |
| Clear written communication | F3 |

---

## 7. Values cheat sheet

Values are from Saltmarsh's published values page, fetched in full.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, the players win | Selection scaffold, B1, with an honest branch. Your nearest quote is "Presented the monthly retention numbers to the studio head." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2, with an honest branch. Your nearest quote is "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Each release leaves the codebase and checklist better than it found them | Selection scaffold, B3. Your nearest quote is "Wrote the release checklist our QA team still uses." It carries persistence, not improvement. |

---

## 8. Reverse questions

Each question has a line on why it lands.

1. **"You came into live operations from QA on a console studio, as your GDC talk describes. What from that background changes how you run an outage?"** Why it lands: it ties to his own path, and it shows you read his public work. The path comes from a search result, not a fetched page, so check it before you use it.
2. **"Your talk argues that patch notes are a promise. Where in the calendar does that promise get checked?"** Why it lands: it links his talk to the published value "Ship the Patch Not the Promise" and asks how it works in practice.
3. **"How does the live team decide, in practice, when a player signal and the calendar disagree?"** Why it lands: it tests the value "Players Before Plans" in operation, and shows you are thinking about the work, not just the title.
4. **"What does a good post-event review look like here, and who reads it?"** Why it lands: it tells him you are preparing for the JD's post-event responsibility, and it gets his standard.
5. **"What would make the first ninety days a good start for this role?"** Why it lands: it turns the gap into a plan, and it asks him to name the bar.
6. **"How do you judge whether an outage was handled well?"** Why it lands: it asks for his measure of success, which is what the Outage Hour will be scored on.

---

## 9. Prohibited claims

Listed in section 2 above. Nothing in the banks, the reverse questions or the coaching asserts any of them.

---

## 10. Sources

**Provided documents:** your message (the JD, and your background as you wrote it).

**Searches and fetches (L1 research tier):**

| Query or fetch | Result |
|---|---|
| Search: "Saltmarsh Games mobile studio values" | Returned saltmarshgames.com/values |
| Fetch: saltmarshgames.com/values | Three values by name: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener |
| Search: "Saltmarsh Games interview process live operations producer" | Returned saltmarshgames.com/careers/interviewing |
| Fetch: saltmarshgames.com/careers/interviewing | Hiring-manager round is a 60-minute Outage Hour: a live-incident tabletop, then a values conversation. No take-home. |
| Search: "Tobias Wrenfield Head of Live Operations Saltmarsh Games" | Returned a GDC 2026 talk entry, "Patch Notes Are a Promise", at talks.gdconf.example. Search snippet only, not fetched. The domain looks like a placeholder, so verify the talk before you cite it. |

**Research tier:** L1, searches 3 of 6, fetches 2 of 2.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet, section 7: three values by name |
| 2. Saltmarsh interview process | yes | Outage Hour format, which shaped the persona weights and the A bank |
| 3. Saltmarsh strategy and recent news | unavailable | Would have moved the company-knowledge bank. Not run: the two-fetch cap was spent on higher-priority targets. |
| 4. Tobias Wrenfield public footprint | yes | Interviewer read, section 3, and reverse question 1. Search snippet only. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

**Not in this pack:** no fetched strategy material, no news, and no Tobias profile beyond one talk entry.

---

## 11. Upgrade menu

- **Deep research (L2), offered once:** runs up to six more searches and two more fetches on Saltmarsh's strategy, Tobias's talks and writing, and recent org news. Takes a few minutes. It would give the company-knowledge bank, which this pack lacks.
- **Your post-event review or any live incident you ran** → upgrades A1 and B2 from scaffolds to story-mapped answers. Say what happened in your own words.
- **Whether Saltmarsh's titles use in-app purchases** (the JD does not say) → if they do, the Skeptic bank gains a question on your F9 gap.
- **Full text of Tobias's GDC talk** → confirms or drops the reading in section 3 and reverse question 1.
- **Your prep time before Friday** → turns the full pack into a prioritized schedule. The top three to rehearse are C1, A1 and B2.
- **A tuesday-dossier.md from job-underwriter** → would replace the inferred objection in C1 with an evidence-derived one, and add a prohibited-claims list.

---

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
