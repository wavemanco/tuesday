# Interview pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (Thursday). Interviewer: not named.
Built from: your underwriting dossier (tuesday-dossier.md, v1.1, decision conditional_go). No CV and no posting text were supplied, so the requirements come from the dossier's role_profile.
Dating note: the dossier is dated 2026-08-14 and today is 2026-11-25. Check that the posting still reads the same before Thursday.
Research: web search was refused in this session, so the pack has no company values, loop structure or strategy content. Those sections are dropped, not guessed.

## How to use this pack

- **Personas** = how a question is asked (the register and the pressure). **Types** = what is being scored.
- Type key: **JD** = tests a stated requirement or responsibility. **EXP** = tests what you actually did in a past piece of work. **CASE** = a live problem from the role, with no claim about your past. **CO** and **VAL** do not appear, because no company material was available.
- Guidance is scaffolding, not a script. Each guidance cell is meant to be spoken in 90 to 120 seconds, in your own words.
- Quotes in the tables come from the dossier and are exact. V1, V2 and V3 are the three entries of `handoff_to_mock_interview.verified_candidate_evidence`, in order. Requirement quotes (R1 to R5) and responsibilities come from `role_profile`.

## The fit snapshot

Analysis, which is the pack's own observation and not words for you:
- Your material does not show which side of the vendor-and-client line you sat on for the integrations in V1. Settle that for yourself before Thursday. If you can't say it plainly, the adjacent-work story will not hold under a follow-up.
- The dossier's decision prose says "seven years of integration leadership". No verified entry states it, so it is not used anywhere in this pack. Use it only if your CV carries it.
- The R2 row (shipped products) is this pack's own derivation. The dossier does not grade R2.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | Adjacent work only. Say it at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." Name the limit yourself: "I haven't held a product manager title or role." Any wider step is an answer slot inside V1. |
| F2 | "Shipped API or platform products" (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 carries integrations taken through go-live. It does not say a product was shipped. Words: "through go-live", at V1's scope. Answer slot: if you shipped something others used as a product, say what and your part; if the work was client integrations going live, say so. |
| F3 | "Technical fluency: API docs, schemas" (dossier R3, important) | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | A playbook is not shown to be API docs or schemas. Answer slot: name any API docs or schemas you wrote or changed; if you only read them, say so. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | discovery | The quotes reach client and product stakeholders. Engineering and sales are not in the material. Answer slot: if you managed engineering or sales stakeholders, say which and how; if the work was mainly with clients, say so. |
| F5 | "Agile delivery experience" (dossier R5, preferred) | none given | low (dossier grading) | [grounded] | discovery | Nothing in the material shows Agile delivery in a product org. Clarify, do not bridge: define the term in your own words, then say where you have worked this way, if anywhere. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility; R1 sub-claim: roadmap ownership and prioritization authority) | none given; the dossier records the absence in uncertain_or_weak_areas (acknowledge_gap) and in prohibited_claims | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier fields named here: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, stated as a plan. Never a bridge. |

## Persona table

| Persona | How it shows up in this round | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the PM-title gap and asks you to defend the hire | **High.** A hiring manager is buying capability and derisking gaps (relationship prior), and the dossier names the objection | Rehearse A1 until it is plain. Hold the quoted adjacent work and name the limit before it is asked for |
| Case / Strategist | Live problems on the role's own responsibilities | **High.** Same prior; the role_profile lists discovery, specs across two squads and adoption metrics | Clarify, then structure, then state your metric and its weakest assumption. Make no claim about your past in a CASE answer |
| Data-Driven Prober | Asks how the one headline figure, 30+, was counted | **Medium.** One figure on the material, and one medium-confidence line (V3) the dossier expects to be probed | Say what you know about the count. If you don't know how it was counted, say so |
| Pressure | Asks how much was actually yours, and gives a time limit | **Medium-low.** No signal of a stress style, but the top figure invites an attribution probe | Hold the quote through two follow-ups; concede a specific point, never the whole claim |
| Conversational | An opener, and a casual check on the JD's technical line | **Low to medium.** Casual questions are still scored | Use a fixed 90-second arc; treat R3 as scored even when asked casually |
| Peer, Values | Not used | Relationship is hiring manager, so no peer weighting. No published values were available to build a values round from | None |

Weights: Skeptic 5 questions, Case 4, Prober 3, Pressure 2, Conversational 2. That is 16 questions, sized to a 45-minute round.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3) | **The highest-ROI rehearsal in this pack.** Hold: give V1 at its own scope, then V3, then name the limit before it is asked for: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Concede a specific point: the first roadmap quarter would be spent learning how the squad leads set priorities. Hold through two follow-ups by returning to V1 and V3, never by adding to them. V3 is medium confidence: volunteer that it is the thinnest part, and do not stretch it into a roadmap decision. | The underwriter named this objection, so its wording is theirs. Its negatives are sourced to the dossier's prohibited_claims and acknowledge_gap fields, so the question may keep them. JD because it scores R1, a must-have. |
| A2 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1) | Answer with V1 at its scope: integrations taken through go-live. Answer slot: if you shipped something others used as a product, say what and your part in it. If the work was client integrations going live, say so plainly and stop there. Never call an integration a product. | R2 is a must-have, and the dossier does not grade it. This row carries the transferability reading (F2) and is the only place the product question appears. |
| A3 | "The role spans engineering, sales and customers. Tell me about your stakeholder work with each." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1) | Give the client and product work at the quoted scope. Answer slot: if you managed engineering or sales stakeholders, say which and how, in your own words; if the work was mainly with clients, say so. | F4: the JD raises engineering and sales; the material shows only clients and product. The honest split is the answer. |
| A4 | "What does Agile delivery mean to you, and where have you done it?" | JD | [grounded] "Agile delivery experience" (dossier R5, the JD line) | Clarify strategy, because no verified entry speaks to Agile delivery and no quote is available. Give your own definition first, in plain words. Then, where you have worked this way, say how. If you have not worked in an Agile team, say so, and say how you would learn this team's delivery method. | R5 is preferred, the dossier grades it low, and its gap is discovery. A bridge would invent a past the material does not show. |
| A5 | "Where have you worked with API docs or schemas, and what did you do with them?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier R3, the JD line); "Wrote the internal integration playbook her team uses" (V2) | V2 is a playbook you wrote; state it at that scope. Answer slot: if you wrote or changed API docs or schemas, say which; if you only read them, say so. Do not present the playbook as schema work unless you can say how it was. | F3 is discovery. The question presupposes schema work the quotes do not carry, so the second branch must allow that you never did it. |

### Case / Strategist (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner integration stalls at UAT. Where do you start?" | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibility); the approach is [generic] | Clarify: which partner, which phase, what "stalled" means. Then ask what the partner needs. Then separate the blocker from the partner's priority. Say this as your plan. Make no claim about a past stall. | A live problem from the discovery responsibility. It presupposes nothing about your history. |
| B2 | "Partner API adoption has been flat for two quarters. What do you look at first?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Name the weakest assumption in an adoption figure before they do: how adoption is counted, per partner or per call. Ask whether a baseline exists. The dossier says none is stated, so this is also your reverse question, asked here as a clarifier. | Adoption metrics are a named responsibility, and the baseline is unknown. Structure is what is scored. |
| B3 | "Two squads, one partner request, one quarter. How do you sequence it?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Clarify what the request needs and what each squad owns. State the trade-off you would decide first. Then ask who decides when the squads disagree, since the decision-authority question is still open. | The two-squad setup is in the role's own responsibilities. The answer should show how you would decide, not claim who decided before. |
| B4 | "What would your first 90 days on the platform roadmap look like?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Answer as a plan. First, learn the current roadmap and where its inputs come from. Then, learn how the squad leads set priorities. Then propose the first change. Do not describe any roadmap you have owned. | This is the roadmap-ownership area the dossier marks as a capability gap. A question about the future is the one place to answer it without any past claim. |

### Data-Driven Prober (weight: third)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How were the 30+ integrations counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1) | Say what you can say about the count. Answer slot: if you know what counted as one integration, say it in your own terms. If you don't know how it was counted, say so. Name the assumption you would defend least before they do. | The only figure in the material. A defend-the-number question, and the honest answer may be "I don't know how it was counted." |
| C2 | "The roadmap-input sessions: what did product change because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3) | Volunteer the limit first: V3 is the medium-confidence line, and it says what the sessions fed, not what changed. Answer slot: if you can name a change product made, say which and what you did. If the sessions fed evidence and you saw no change, say so. | V3 is medium confidence and the dossier expects this probe. The outcome is not in the quote, so the answer is a slot. |
| C3 | "How would you know an integration had gone well a quarter after go-live?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Name the measure you would use and the assumption each one rests on. Say that you do not know the current baseline and ask for it. | Adoption is named as a responsibility with no baseline. This tests the measure, not a claim you made earlier. |

### Pressure (weight: fourth)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1) | Hold V1 through two follow-ups, returning to "led" and to the phases it names. Concede a specific point: name any phase that was shared or someone else's. Answer slot: if any phase was shared, say which and what you did. If you led all of them, say so and state the phases. | The most likely attribution probe on the top figure. The concession is specific and the claim is not given up. |
| E2 | "Assume the squad leads disagree with your spec. What do you do in the next hour?" | CASE | [generic] pattern for a decision-authority disagreement; no claim about your past | Sixty seconds. Restate the disagreement. Name what would settle it and who has the call. Say what you would do today to get that decision. Concede plainly that you would ask who decides rather than assume. Hold your position on the decision path. | Turns the open decision-authority question into a live problem. It makes no claim about your past. |

### Conversational (weight: lowest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (V1); "Wrote the internal integration playbook her team uses" (V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3) | A 90-second arc in this order: V1, then V2, then V3, each at its own scope. Close on the limit: "I haven't held a product manager title or role." Years and titles are not in this pack. Add only the ones your CV states. | Casual openers are scored. The arc uses only quoted sentences. |
| D2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile requirement) | Answer slot: name any API docs or schema tools you have used, and what you used them for. If you have only read them, say so. | R3 is scored even when asked casually. The second branch lets the answer be "not much". |

**Requirement coverage**

| Requirement | Questions | Notes |
|---|---|---|
| R1: 3+ years product management experience | A1, D1 | Must-have |
| R1 sub-claim: roadmap ownership and prioritization | A1, B4 | Acknowledged, not bridged |
| R2: Shipped API or platform products | A2 | Must-have |
| R3: Technical fluency: API docs, schemas | A5, D2 | |
| R4: Stakeholder management across engineering, sales, customers | A3 | |
| R5: Agile delivery experience | A4 | Preferred |
| Responsibility: adoption metrics | B2, C3 | No baseline stated |
| Responsibility: two engineering squads | B3 | |

Session total: 16 questions, below the usual 18 to 26, because a 45-minute round cannot rehearse more.

## Reverse questions

Each has a "why it lands". There is no interviewer profile, so none is tied to a career path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the two squad leads?"** Why it lands: it tests the dossier's open decision-authority risk. It reads as diligence, and you need the answer before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the posting names adoption metrics and states no baseline. The answer tells you whether the metric is in place.
3. **"Where do integration partners most often get stuck today?"** Why it lands: it tests the discovery responsibility and shows interest in the partners' side of the work.
4. **"What do the two engineering squads each have in flight this quarter?"** Why it lands: it grounds B3 in the actual load, so you know what a first quarter looks like.
5. **"What would make this role's first six months a clear success?"** [generic] Why it lands: it sets the bar for judging the role, and the answer shows you whether the bar is one you can meet.

## Prohibited claims

Built from the dossier's prohibited_claims, with the inflated forms this pack adds. Every guidance cell in this pack is held against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title or role." No slot. |
| Having owned a product roadmap | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan, as a plan. |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Owned the integration roadmap | Inflated form of V3, which says "Ran quarterly roadmap-input sessions feeding client evidence to product" | V3 at its own scope. The limit is the pack's observation: the material shows input sessions, not roadmap decisions. |
| Shipped an API or platform product | Inflated form of V1, which says integrations went live | V1 at its own scope: "through go-live", for client integrations. The material does not show a product. |

## Sources

- **Provided documents:** `tuesday-dossier.md` (v1.1, generated 2026-08-14). Consumed sections: `handoff_to_mock_interview` (all five rules), `role_profile` (requirements and responsibilities), `decision` (context only). Absent from the dossier as pasted: `evidence_map`, `evidence_state` and `risk_register`, so there are no rejected inferences. Risks come from `handoff_to_mock_interview.opportunity_risks_to_validate`.
- **Searches sent (all refused, so nothing returned):**
  - "Quartzline company values": refused
  - "Quartzline Product Manager Platform APIs partner API interview process": refused
  - "Quartzline partner API platform news": refused

**Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, section 10. Omitted, since no values were in hand. |
| 2. `Quartzline interview process Product Manager` | unavailable | Loop structure. Persona weights rest on the hiring-manager prior, not on a named loop. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief. Omitted; the dossier supplies no strategy brief. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Product Manager Platform APIs` JD | skipped | The dossier's role_profile fixes the requirements and responsibilities. |

## Upgrade menu

- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own career path.
- Search access for this session → a re-run at L1 would check Quartzline's values, interview loop and current strategy. That would add a values sheet and a grounding brief.
- A values page, or pasted values → a values cheat sheet, with each value mapped to a story from V1, V2 or V3.
- Your CV → the quoted lines get their dates and titles, and "seven years of integration leadership" can enter a bridge only if the CV states it.
- The current posting → confirms or changes R1 to R5 and the responsibilities, which were underwritten on 2026-08-14.
- Your prep time before Thursday → a prioritized triage section on which questions to rehearse first.
