# Senior Partnerships Manager, Kelverton Rail: second-round prep pack

Second round, 60 minutes, panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a spoken POV on operator partnerships over 18 months, landing on what it means for the operators. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

Built on: your message and the recruiter's email as you quoted it. Not in this session: the internal market report and any job description. Research was refused (see Sources), so nothing here about Kelverton comes from outside your material.

## 1. How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural and values alignment. None detected here (no values round named), so no VAL questions.
- **EXP**: your experience, tested for what was actually yours.
- **JD**: the role itself, including its gaps.
- **CO**: commercial and strategy thinking.
- **CASE**: a live problem, scored on structure.

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## 2. Prep triage (about 4 hours)

1. **0:00 to 1:15, the POV (section 5).** Choose one thesis, write its concession and its operator close, then speak it aloud twice, timed to 12 minutes.
2. **1:15 to 2:15, Ross's bank (A1 to A5, D1 to D2).** Speak each answer aloud. Practise the hold-then-concede on A1 and A4.
3. **2:15 to 3:00, Deepa's bank (C1 to C3, B1 to B4).** C1 is the most important question in this pack. Rehearse three follow-ups on it.
4. **3:00 to 3:30, reverse questions (section 11).** Pick five you can say naturally.
5. **3:30 to 4:00, full dry run.** Time the POV first, then run the Q&A without notes.

Everything else is insurance.

## 3. Persona weights

No interviewer profiles were supplied, so the weights rest on relationship priors and on the recruiter's stated focus.

- **Ross** (Commercial Director): Pressure and Prober. The recruiter wrote "Ross will push on commercials", so commercial pressure is the stated focus.
- **Deepa** (future manager): Skeptic and Case. A future manager tests the gap and watches how you structure the POV.
- The POV is a Case in front of both of them.

## 4. Fit snapshot

No job description was supplied, so the requirements come from the recruiter's email, quoted as you gave it, and from your own description of the panel. Confidence and gap type follow the routing rules in the skill's reference files.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months": recruiter's email | "took it from 6 partners to 40" (your message) | medium | [grounded] | transferability | Your material describes partners selling a payments product, not operators as buyers. Bridge at the quote: "I took it from 6 partners to 40." Answer slot: a probe on operators is likely. If you made a decision about how partners were picked or supported, say which and why. If none was yours, say so and stay with the partner count. |
| F2 | "what it means for the operators themselves": recruiter's email | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material shows planning work for operators, seen from outside their buying decisions. Bridge: "I did bus and light rail network planning, so I know the operator world from the other side." Limit, as the pack's own observation: the material shows planning, not a purchase. Answer slot: if you saw an operator choose a scheduling supplier or tool, say which and what you saw. If you did not, say you saw planning work, not buying. |
| F3 | "Ross will push on commercials.": recruiter's email | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Influenced is not direct, and the material says influenced only. Bridge: "The figure I have is roughly £4M of influenced revenue." Answer slot: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. |
| F4 | Selling into rail operators (inferred: no JD supplied; follows from Ross's commercial focus) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | none | [grounded] | capability | Your own words, as a plain acknowledgment: "I haven't sold into rail. I haven't carried a direct quota." Then how you would learn it, stated as a plan and never as a past. Never describe a rail sale or a quota. |

## 5. Graded deliverable: the 15-minute POV

The recruiter's brief, quoted: "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

Grounded facts to build on: F1 and F2 above. Nothing else about your past goes into the POV.

**Thesis options (pick one, or at most two):**

- **T1 [generic]:** Operators judge a partnership by disruption they do not have to absorb, so the partnership's job is to help planners recover faster, not to add partners.
  - *Mandatory concession:* "I haven't sold into rail, so my view of how operators buy comes from outside. You know their current contracts better than I do."
  - *Differentiation:* the consensus answer is "grow the partner count". Argue the metric instead, and give your reasons.
  - *Anti-pick:* you would not lead with partner count.
- **T2 [generic]:** Start with two operator planning workflows where a partner can show a result within one planning cycle, not with a partner tier.
  - *Mandatory concession:* "This may look slow next to a sales target, and year-one revenue could be smaller."
  - *Differentiation:* tie the first pilot to a named outcome, which is the answer to Ross's commercial push.

**Requested close:** one sentence that starts "For an operator's planner, this means" and names one thing they would do differently on a Monday. Write it yourself; the pack supplies only the form.

**Consensus answer:** your strategy team's report is not in this session, so I cannot say which of its shortlist items to avoid. Paste its headings and this section will be rebuilt to diverge from them.

## 6. Grounding brief

Not produced. The company-strategy research did not run (see Sources).

## 7. Reading the interviewer

Not produced. No public profiles were supplied for Deepa or Ross.

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Pressure (Ross) | Time-boxed, interrupting, pushing on the influenced number and on quota | High. The recruiter named commercial pressure directly | Pause, restate the question, answer from the quote, hold through two follow-ups |
| Prober (Ross) | Asks what a figure counts and which part was yours | Medium to high. "roughly £4M of influenced revenue" and "6 partners to 40" are both figures | Say what the figure counts, name the assumption you would defend least, say plainly what you do not know |
| Skeptic (Deepa) | "Why you, and what do you do on day one that someone from rail would do" | High. The rail gap is the obvious question for a future manager | Plain acknowledgment, then the transfer you can name, then a week-one plan |
| Case (both) | "Where do you start?" on the 18-month plan | High. The POV is itself a case | Clarify first, then state a starting bet and its riskiest assumption |
| Conversational | Friendly opener | Low. The format is a scored panel | Treat any casual question as scored |

## 9. Question banks

Ordered by persona weight. Provenance comes before the guidance.

**Persona A: Ross, Pressure. Weight: highest. Five questions.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never carried a direct quota. What makes you think you can carry one here?" | JD, EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: "I haven't carried a direct quota." Return to what you did carry, in its own quote: "took it from 6 partners to 40." Hold through two follow-ups by returning to that quote. Concede in your own words: name what you would need to learn first. | F4 is the most likely commercial probe. The hold is the quote; the concession is a plan. |
| A2 | "Roughly £4M of influenced revenue. How much of that was yours?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Defend-the-number slot: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. If you did this, say how. If there was no such step, or it was not yours, say so plainly and return to "took it from 6 partners to 40." Never name a counting method for the figure. | A figure raises the defend-the-number slots. "Influenced" is the word Ross will test against "direct." |
| A3 | "Operators have fixed budgets and their own timetables. Why would one pay a partner rather than buy direct?" | CO, CASE | [generic] | Structure it: who signs, which budget pays, what a partner adds that direct does not, and what would make a planner say yes. Name the trade-off you would test first. | Raised by the recruiter's "Ross will push on commercials." Generic because it is a market pattern, not a fact about Kelverton's operators. |
| A4 | "Be straight with me. Are you learning rail on our time?" | EXP, JD | [grounded] "Never sold into rail specifically" (your message); "running the ISV channel" (your message) | Pause, restate, then answer from the quote: "I haven't sold into rail." Then say how you would learn it fastest, as a plan. Hold: partner-led selling is not new to you, rail is. | F4 under direct pressure. The hold is supported by "running the ISV channel"; the concession is a plan, not a past. |
| A5 | "What would you do in the first month to win my trust on commercials?" | CO | [generic] | Name one commercial action you would take in the first month, stated as a plan, and say what you would need from Ross to check it. Claim no past commercial win. | The recruiter's "Ross will push on commercials" raises this. The answer is a plan, not a record. |

**Persona B: Case, Deepa and Ross. Weight: middle. Four questions.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have 18 months. Where do you start, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: which operators are in renewal, what disruption costs them now, which partners already exist. Then give your starting bet. | Case-style probe on the POV. Clarifying first scores structure. |
| B2 | "Pick one operator. What would you offer them that they can't get from us today?" | CASE, CO | [generic] | Pick one operator type, one planning workflow and one offer. Name what you would measure after one planning cycle. Do not name an operator Kelverton serves unless the recruiter did. | The POV's operator close. Generic because the operator is hypothetical. |
| B3 | "What's the riskiest assumption in your 18-month plan?" | CASE | [generic] | Name one assumption about how operators buy, and the evidence that would show it wrong. | Panels push on the plan's weakest premise. Naming it first turns the probe into a strength. |
| B4 | "Give me the POV in one sentence." | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | Practise the thesis in one sentence, then the operator close. | Tests whether the POV has a spine. |

**Persona C: Skeptic, Deepa. Weight: middle. Four questions.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've come from payments partners. What do you do on day one that someone from rail would do better?" | JD | [grounded] "running the ISV channel" (your message); "Never sold into rail specifically" (your message) | **Highest-ROI prep in this pack.** Hold on the channel: you ran the ISV channel, and it transfers in ways you can name in your own words. Concede: "I haven't sold into rail, and the operator buying process is what I'd learn first." Name one week-one action, as a plan. Hold through two follow-ups; concede specifically on the third. Never say you know rail buyers. | The likeliest objection, and the one where the gap is most exact. |
| C2 | "You knew the operator world from the other side. Did you ever see an operator choose a scheduling supplier?" | EXP | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Answer slot: if you saw an operator choose a supplier or tool, say what you saw and what your role was. If you did not, say you saw planning work, not buying. Do not extend from planning to procurement. | Checks whether planning-side knowledge reaches the buying decision. |
| C3 | "What don't you know about operators yet?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I haven't sold into rail." Then the two things you would close first, as a plan. Keep it short and specific. | An invitation to admit the gap. A short, concrete answer scores better than an apology. |
| C4 | "Why would an operator care about a partnership at all, and why now?" | CO | [generic] | Answer with the operator outcome from your POV, then the timing reason you would defend. | The recruiter's "what it means for the operators themselves" raises this. |

**Persona D: Prober, Ross. Weight: lowest. Three questions.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Six partners to forty. How many of the forty did anything?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Say what the count included. If you do not know how many were active, say so. Do not offer a method. | The partner count is your headline figure, so a prober asks what it counts. |
| D2 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the assumption you would defend least, in your own words, before Ross does. If you do not know how it was counted, say that. | The weakest-assumption move for a figure. The same figure as A2, asked as a prober would. |
| D3 | "Which operator metric would you show me first, and why?" | CO | [generic] | Pick one operator-side measure, say what it is sensitive to, and say what you would not count. | A prober's follow-on from the POV's operator close. |

Session total: 16 questions. That is below the rubric's usual 18 to 26 range, because this is one 60-minute panel, and the 15-minute POV carries much of the depth.

**Requirement coverage**

| Stated item (source) | Covered by |
|---|---|
| Operator partnerships over 18 months (recruiter) | B1, B4, D3, section 5 |
| What it means for the operators themselves (recruiter) | B2, C4, F2, section 5 |
| Commercials, Ross (recruiter) | A1 to A5, D1, D2, F3, F4 |
| JD requirements | none: no JD supplied; coverage pending the JD |

## 10. Values / principles cheat sheet

Not produced. No values-style round is named in the material, and no company values were fetched.

## 11. Reverse questions

| Question | Why it lands |
|---|---|
| "Which operator relationship has taught you the most about how they buy?" | Puts the operator at the centre, which is what the POV is asked to do |
| "What would 'good' look like at month 18 for operator partnerships?" | Pins the commercial bar Ross will test, in his terms |
| "How do partner deals and direct sales split operator business today?" | Asks about the seam, and sets up your answer on partner versus direct |
| "What did the last person in this role get right, and what did they miss?" | Lets Deepa describe the role's real gap, which you can then address |
| "What would I need to learn about operators in the first 30 days that isn't in the market report?" | Shows you read the report and want more than its shortlist |
| "Which operator decision would you most like someone in this role to change?" | A forward question that invites a specific operator problem to work on |

No reverse question is tied to an interviewer's career path, because no profiles were supplied.

## 12. Delivery coaching

Not produced. No working-style assessment was provided.

## 13. Prohibited claims

Built locally from the fit snapshot, before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led operator partnerships" or "I ran operator relationships" | Inflated form of F1 and F2. Your material shows partners in payments and planning work for operators | F1's quote at its own scope: "I took it from 6 partners to 40." The limit, as the pack's observation: the material shows partners, not operators as buyers. A2 and C2 stay inside the quotes |
| "I sold into rail" or "I carried a quota" | Your own negatives, F4 | The plain acknowledgment: "I haven't sold into rail. I haven't carried a direct quota." No slot |
| "I generated the £4M" | Inflated form of F3. Your figure is influenced revenue | "roughly £4M of influenced revenue", with D2's slot on what it counts |
| "I know how operators buy" | Inflated form of F2. The material shows planning, not a purchase | "I know the operator world from the other side", as quoted, with C2's slot on whether you saw a purchase |

## 14. Sources

**Provided documents:** your message (background, figures, the panel as you described it); the recruiter's email as you quoted it. The internal market report and any job description were not available in this session.

**Searches sent, all refused:** the search tool returned a permission refusal on all three calls.
- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy scheduling software train operators news": refused

**Target accounting**

Research tier: L1, searches 0 of 6 returned results (3 refused), fetches 0 of 2.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet (section 10). Not required here, since no values round is named |
| 2. Kelverton Rail interview process | unavailable | Loop structure; whether the POV is scored as a graded round |
| 3. Kelverton Rail strategy / recent news | unavailable | CO and CASE questions grounded in current strategy; the grounding brief |
| 4. Deepa, VP Partnerships, Kelverton Rail | unavailable | Interviewer read and a tailored reverse question. The name form (first name, title, company) is enough to search, so this target was formable but not run |
| 5. Representative JD for the role | unavailable | JD-tagged rows; not run because no JD was supplied and the search was refused |

## 15. Upgrade menu

- **Job description text** → turns the recruiter-stated requirement rows into grounded JD lines, and adds JD-tagged questions for each hard requirement.
- **Market report headings** → lets the POV differentiate from the report's shortlist, instead of reciting it.
- **Public profiles for Deepa and Ross** (role and career path) → persona weights for each panel member, the interviewer read, and a reverse question tied to their path.
- **Web search permission** → the three research targets above, run at L1.
- **Whether the POV is scored, and whether Ross scores commercials separately** → sets how much weight the POV carries against the Q&A.
- **Deeper research, once:** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and recent org context. Want it?
