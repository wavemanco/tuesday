# Senior GTM Strategy Lead, Emerging Products: Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer relationship (same VP). Format: one 60-minute conversation.
**Candidate:** Priya.
**Assumption:** Built on your notes as Priya's own account. Her confirmation of each note comes first in the upgrade menu.

---

## 2. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. None detected for this round. |
| EXP | Experience deep-dive | Whether her claims survive scrutiny, and what she actually did |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy | Strategy altitude: priorities, competition, recent moves |
| CASE | Live problem | Structure and reasoning on a problem from the role |

---

## 4. Fit snapshot

Requirements are quoted from your JD highlights and company context, as your message supplied them. Evidence is quoted from your notes. Rows are numbered F1 to F9.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | transferability | Your material says product strategy and ops, not GTM strategy and not a new product line. Keep the claim at that scope. Answer slot: the role asks for GTM strategy for two new product lines, so expect a probe on what she set for a launch. If she set a go-to-market approach for any launch, she says which and how she decided, in her own words. If she did not, or it was not hers, she says so plainly and describes the product strategy work she did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given | none | [grounded] | discovery | Your material does not show lifecycle analysis of any customer base. Answer slot: if she has built a land, adopt, expand or renew view of any customer base, she says what it covered and what it showed. If she has not, she says so and says how she would find whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | Your material reaches this requirement in its own terms, as a skill. Expect a probe for an analysis she ran herself. Answer slot: if she has one, she walks it through end to end in her own words. If she has none she can show, she names the tools she has used and on what data. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "Built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | discovery | The quote touches partner work and does not show whether it reaches partner-motion design. A revenue model used in negotiations is not, on its face, a designed motion. Answer slot: if she designed any part of a partner motion, such as how partners are recruited, supported or paid, she describes it and what she chose. If her work was the economics of a partner deal, she says that and says which parts she did not design. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role terms: consensus across organizations. Lead with the consensus she reached and who had to agree. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Your material says daily use of AI tools, not work on AI products. She says what she uses them for, in those words. Answer slot: if she has worked on an AI product or feature, she says what it was and her part in it. If she has not, she says so and says what she has used AI for. |
| F7 | "enterprise expansion" (company priority, coach's notes) | none given | none | [grounded] | discovery | Your material shows a consumer-tech company and no enterprise selling. Answer slot: if any of her work reached enterprise buyers or customers, she says what it was. If none did, she says so and says how she would learn the enterprise motion. |
| F8 | Sales-ops and quota-setting depth: the interviewer's function, with no JD line behind it (generic) | "No classic sales-ops or quota-setting experience." (coach's notes) | none | [grounded] | discovery | Your notes record this absence, but Priya has not stated it herself, so no plain acknowledgment applies yet. If she confirms it in her own words, it becomes one and the slot below drops away. Until then, answer slot: if she has shaped any target, quota or capacity figure, she says which. If not, she says so and says how she would learn the sales mechanics before the first planning cycle. |
| F9 | Headline figure the notes carry (not a JD line) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | The figure comes from a store-surface change at a consumer-tech company, and your material does not show how it maps to B2B data-infrastructure ARR. Keep the wording at its scope: she proposed the change, and the uplift is credited to it. Answer slot: she says how it was counted and what part was hers. If she does not know how it was counted, she says so plainly. Say the figure as approximate. |

Seven rules are behind these columns. Each confidence, provenance and gap type holds one token. Each evidence cell holds only Priya's words, or your notes quoted exactly, with the source named. Requirements are quoted only from text you supplied. Gap and bridge language carries the qualifiers. F8's gap is one your notes stated, not one Priya did, so it stays `discovery` and its words are an answer slot.

---

## Prohibited list

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them may appear in an answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran GTM strategy for a launch | Inflated form of F1 | The quote at its own scope: product strategy and ops at a consumer-tech company. The limit is the pack's own observation: the material says product strategy, not GTM. F1's slot stays within what she set. |
| Set quotas or sales capacity | Inflated form of F5 and F8 | The quote at its own scope: annual volume targets with cross-org consensus. No quota, no capacity. |
| Designed a partner motion | Inflated form of F4 | The carrier model at its scope: a revenue model used in negotiations. F4's slot asks which parts of a motion she designed. |
| Drove the ~$400M | Inflated form of F9 | "proposed a store-surface change credited with a ~$400M ARR uplift": proposed, and credited to it. |
| Built AI products | Inflated form of F6 | "uses AI tools daily", at that scope. |

---

## 7. Reading the interviewer

The public-footprint search was refused (see Sources), so this read uses only the profile you gave: "relentlessly data-driven" (self-described), a career spine in pricing and monetization, and one early-stage-startup chapter.

- **Prober up.** Every metric Priya gives will be taken apart for its assumptions. The Prober bank (B1 to B5) is weighted for this.
- **Pricing spine.** Case questions tilt toward pricing, packaging and unit economics. That is Dan's native language, so C1 carries it.
- **Startup chapter.** Builder stories land with this profile. Expect scrappiness probes on big-company pace, and D2 covers them.
- **Shared jump.** None offered. The notes show no career step that Priya and Dan both made, so no mirror is claimed.

---

## 8. Persona table

Weights are relationship priors (peer) adjusted by the interviewer signals above. A single conversation with a named peer sets the loop, so no archetype fallback was needed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Peer Evaluator | Seam questions, "what would you need from me," credit | High, weight 5. Peers price what a hire costs their team. | Reciprocity framing. State seam principles, not facts about Dan's team. | A1 to A5 |
| Data-Driven Prober | Denominators, assumptions, "how was it counted" | High, weight 5. "Relentlessly data-driven" raises this. | Name the weakest assumption first. Say plainly what was not counted. | B1 to B5 |
| Case/Strategist | Pricing and unit-economics problems, whitespace | Medium, weight 3. The pricing spine tilts cases toward pricing. | Clarify, then objective, segments, metrics and risks. | C1 to C3 |
| Skeptic | Sales-side gap, enterprise gap, partner gap | Medium, weight 3. A peer in sales strategy will probe the sales side first. | Hold a non-defensive answer, concede the specific gap. Bridge only from quoted evidence. | D1 to D3 |
| Pressure / Stress | "How much of it was actually you?" | Low to medium, weight 2. A composure probe in a one-hour peer conversation. | Pause, hold through two follow-ups, concede specifically. | E1 to E2 |
| Conversational | Casual opener, casual AI question | Low to medium, weight 2. Rapport questions are still scored. | A 90-second arc. Treat the AI question as scored. | F1 to F2 |
| Values / Behavioral | None planned | Not weighted. No values-style round is detected, and your notes name none. | None. If the conversation turns to values, A3 and A4 cover the ground. | none |

**Depth.** Top personas get 5 questions, mid personas get 3, low personas get 2. The pack has 20 questions in total, within the 18 to 26 range.

---

## 9. Question banks

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you draw the line between your GTM work and mine?" | JD | [generic]: no claim about Priya's past | Name the seam as a principle, not a fact about Dan's team: which decisions sit with the product line's GTM, which with sales strategy, and what she would bring to a shared review. Do not claim knowledge of how Dan's team divides the work. | Peer seam probe. JD is the primary type because it tests the role's scope against Dan's. No candidate claim is made, so no quote is needed. |
| A2 | "Our teams sit side by side. What would you need from me in the first quarter?" | JD | [grounded] "Built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name what she needs from Dan in concrete terms. Then offer what she brings to Dan's pricing and monetization work: the revenue-model approach behind the carrier work, in those words. Do not promise a pricing outcome. | Reciprocity framing is the peer counter-strategy. The carrier model is the most relevant thing she can offer a pricing-led peer. F4 is the row it touches. |
| A3 | "When a launch spans both our teams, how do you handle credit?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Describe how the cross-org consensus worked: who had to agree, and what each side got. Answer slot: if there was a case where credit was contested, she says who disagreed and what she did. If there was none, she says so and describes how she would split credit on a shared launch. | Credit-sharing is the peer persona's stated probe. F5 is the row it draws on. |
| A4 | "Tell me about a time you disagreed with a peer's plan. What did you do?" | EXP | [generic]: open prompt, no quote carries a disagreement | Open prompt. Pick a time she disagreed with a peer over a shared decision, and name the disagreement, her position and what changed. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it. | Disagreement with equals is the peer persona's scoring area. No quote supports a story, so the guidance is a selection scaffold with its honest branch. |
| A5 | "What would make you say no to a launch the sales side is pushing?" | CASE | [generic]: hypothetical, no candidate claim | Name the criteria she would use before saying no: the evidence, the cost to the other team, and what she would propose instead. Do not cite a past decision that no quoted sentence carries. | The role's real job includes saying no, and a peer will test it under collegial framing. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that roughly $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend-the-number slot. She says how it was counted, in her own words. Name the assumption she would defend least before Dan does. Say the figure as approximate, and say what she proposed and what was credited to it, without claiming the whole uplift. Answer slot: if she knows the counting method, she says it. If she does not, she says so. | The headline figure is the prober's first target. F9 is its row. EXP because it tests what she actually did. |
| B2 | "Which assumption behind your carrier model would you defend least?" | EXP | [grounded] "Built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the assumption in her own words before Dan does. Answer slot: if she can name it, she says what it was and why it is the weakest. If she cannot recall the inputs, she says so plainly. Do not add inputs or a method she cannot repeat. | Pricing spine: this is Dan's native question. The weakest-assumption move turns a gotcha into a credibility gain. |
| B3 | "Give me the base behind your annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | The question presupposes only the target-setting the quote states. Answer slot: if she can say what the targets were measured against, she says it. If she cannot, she says so, and says whose consensus they went through. | Prober asks for the denominator. F5 is the row it probes. |
| B4 | "Walk me through one analysis you ran yourself. What was the grain of the table?" | JD | [grounded] "skilled in SQL/Tableau" (coach's notes) | Prepare one analysis she ran herself in SQL or Tableau: the question, the source, the grain, and what she checked first. Answer slot: if she has one, she walks it through. If the query or dashboard was someone else's, she says so and says what she did with it. | F3 is scored through this probe. JD because it scores the SQL and Tableau requirement. |
| B5 | "How do you test whether the AI copilot launch and enterprise expansion compete for the same sales capacity?" | CO | [grounded] "enterprise expansion" and "AI copilot launch ('Compass')" (coach's notes, company priorities) | Name what she would measure first: pipeline, rep time or deal mix. Say how she would tell competition from complement. Make no claim about the company's internal numbers. | The two stated company priorities. CO because it tests altitude. The Prober will ask for the test itself. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you price the copilot against a bundle from a much larger platform vendor?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (coach's notes, research note) | Clarify the objective and the buyer first. Then segment by who takes the bundle and who does not, the price-to-value story, and the risks. Name one premise she would challenge. Use packaging and unit-economics language, which is Dan's. No claim about her past. | Pricing-spine tilt plus the stated competitive threat. CO is the primary type, delivered as a CASE. |
| C2 | "Sketch the whitespace for one product line across land, adopt, expand and renew." | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | Clarify first, then structure by lifecycle stage, then name the metric she would check first at each stage. Say what she needs to know before sizing anything. No candidate claim. | The JD requirement, tested as a live problem. CASE because it scores structure, not recall. |
| C3 | "Suppose enterprise expansion revenue fell 20% in one quarter. Diagnose it." | CASE | [generic]: hypothetical, no candidate claim | Clarify the revenue definition first. Structure the diagnosis as volume, price and mix, then name the one assumption she would check before blaming any of them. | Case stem. Hypothetical, so it presupposes nothing about the company's actual numbers. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which sales-facing piece of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" (coach's notes) | **Highest-ROI prep in this pack.** Hold a non-defensive answer. Name the sales-facing piece she would need to learn first: sales-ops or quota mechanics. She may point to the adjacent work in those words: "set annual volume targets with cross-org consensus." Answer slot: if she has run any part of sales ops or quota-setting, she says which part. If not, she says so plainly and says how she would learn it before the first planning cycle. Hold through two follow-ups, and concede the specific gap, not the whole role. | This is the biggest gap, and it sits in front of a Director of Sales Strategy. F8 is the row. The Skeptic stem is the interviewer's own line, so the question does not assert the negative. |
| D2 | "Your big result came from a store-surface change at a consumer-tech company. What carries over to selling data infrastructure to enterprises?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Name the one part of the approach she thinks carries over, and the part she expects not to. Answer slot: if she can name what carries over, she says it. If the consumer-to-enterprise step is real, she says so and says how she would test the transfer early. No claim that a B2B buyer behaves like a store customer. | Transferability on the headline figure (F9), plus the enterprise priority (F7). The scrappiness probe from the startup chapter also lands here. |
| D3 | "Partner motions are part of this role. What have you designed?" | JD | [grounded] "Built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: if she designed any part of a partner motion, she describes it and what she chose. If her work was the economics of a partner deal, she says that and says which parts were not hers to design. Keep the carrier model at its scope. | The JD line raises it. The question asks about design experience and presupposes none. F4 is the row it probes. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Pause, restate the question in one line. Then hold her position on what she brings: product strategy and ops from a consumer-tech company, and the cross-org consensus she reached. Hold through two follow-ups. Concede specifically: an internal candidate knows the company's people and systems, which she does not. Do not invent a reason she is better than an internal person. | Pressure stem. The honest concession is the internal candidate's advantage, which she should name before it is named for her. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold the quoted claim: she proposed the change, and the uplift is credited to it. Hold through two follow-ups. Concede the share specifically: the uplift was not hers alone, and she says what her part was. Do not raise the figure to answer. | Pressure stem on the headline figure. Hold-then-concede structure, with the figure kept the same as in B1. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Prepare a 90-second arc: the consulting years, then the product strategy and ops years, then why this role. The why-this-role part is an answer slot in her own words. Do not add a title or scope the notes do not carry. | Biography opener, scored casually. The two quoted sentences are the arc's only beats. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | She names the tools she uses daily and what she uses them for, in her own words. She does not describe building anything. | AI plus is in the JD, asked casually. Scored as a plus, so it gets a real answer. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A1, D1 |
| identify whitespace across land/adopt/expand/renew | C2 |
| run independent analysis in SQL and Tableau | B4 |
| partner-motion design experience required | D3 |
| strong cross-functional influence | A3 |
| AI experience a plus | F2 |
| Company priority: enterprise expansion | D2, B5 |
| Company priority: AI copilot launch | B5, C1 |
| Company threat: bundling by a much larger platform vendor | C1 |
| Coach's note: no classic sales-ops or quota-setting experience | D1 |
| Headline figure | B1, E2, D2 |

Every requirement has a question.

---

## 11. Reverse questions

Six questions, each with why it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to sales strategy from pricing and monetization. Which sales-side decision did that background change most?" | Ties to Dan's own path. It turns the interview into a peer conversation and shows the candidate looked at Dan, not only the company. |
| R2 | "Where does the GTM work for the two new product lines sit between your team and the product owners today?" | A seam question on the role's own scope. It shows she is thinking about where the role's boundaries are. |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, required for a peer. Rapport-style interviewers weight this slot heavily. |
| R4 | "How are the Compass launch and enterprise expansion being weighed against each other for the same sales capacity?" | Uses the stated company priorities from the research note. It shows preparation without claiming internal knowledge. |
| R5 | "When the larger platform vendor's bundle comes up, what do customers ask your team first?" | Opens the competitive frame. It shows she knows the threat, and it invites Dan to speak to the pricing angle. |
| R6 | "Which number does your team check first when a pricing change is proposed?" | Speaks to a data-driven peer in their own register. It is the question a Prober asks, asked back as a sign of interest. |

---

## Sources

**Provided documents:** your message (JD highlights, candidate notes, interviewer profile, company research note).

**Searches and fetches sent, with what came back:**

| Query | Result |
|---|---|
| "Dan Kovac Northwind Data Director Sales Strategy" | refused (permission to use search not granted) |
| "Northwind Data Compass AI copilot launch enterprise expansion" | refused (permission to use search not granted) |

**Research tier: L1, searches 2 of 6, fetches 0 of 2. Both sent searches were refused.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | Section 6 (values cheat sheet) is dropped: no values-style round is detected. Your notes name a single peer conversation and no values round, so the search could move nothing. |
| 2. Interview process | skipped | Your notes fix the loop: one 60-minute conversation with Dan. |
| 3. Strategy / recent news | unavailable | The Compass query was refused. The C1 and B5 priorities rest on your research note, not on a current check. |
| 4. Dan Kovac, Northwind | unavailable | The name query was refused. The interviewer read uses only your profile. The shared-jump check and the public footprint are both absent. |
| 5. Representative JD | skipped | Your JD highlights are in hand. |

---

## Upgrade menu

- **Priya confirms each coach's note in her own words.** Then F1, F3, F5 and F9 rest on her sentences, and F8 becomes a plain acknowledgment with no answer slot.
- **The full JD text.** The requirement quotes come from the posting itself, not from your highlights. The six JD rows regenerate on the posting's wording.
- **Dan's public footprint, once the search can run.** Recurring themes in any talk or post become likely questions, and a reverse question can be tied to a specific career step.
- **A current strategy check, once the search can run.** It confirms that the Compass and enterprise priorities are still the published ones, before C1 and B5 are rehearsed.
- **Prep time.** With a known time, the pack gets a prioritized triage. Without it, every section is equally weighted.
- **Deeper research.** A further pass of up to 6 searches and 2 fetches, several more minutes. Want it?
- **A `tuesday-dossier.md`.** It would add verified evidence and sharper objections to the pack. Offered below.
