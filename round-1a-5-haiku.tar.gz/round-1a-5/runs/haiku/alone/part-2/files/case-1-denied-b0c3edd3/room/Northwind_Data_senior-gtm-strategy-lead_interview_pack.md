# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer (same VP). **Round:** one 60-minute conversation.
**Version:** first pack, no earlier version.

## 2. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral or values alignment. **EXP** work-experience deep-dive. **JD** role and JD-driven. **CO** company and strategy knowledge. **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only in terms of what you actually did.
- Answer slots are instructions for the interview. They ask for no reply here.

## 4. Fit snapshot

Requirements are the JD highlights you supplied, quoted as written. Evidence is quoted from your coach's notes, which are summaries and not your own CV sentences. Confirm each one with Priya before she uses it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | presentation | "I'm skilled in SQL and Tableau." The quote reaches the requirement in other terms. Say the skill, and do not add an analysis to it. |
| F2 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent work. The material shows a revenue model used in negotiations, not a partner motion designed end to end. Say it at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you designed any part of how partners were paid, enabled or targeted, say which and how you decided. If none of it was yours, say so plainly and describe the model. |
| F3 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Adjacent product work: a change you proposed, credited with an uplift. It is not GTM strategy owned for a product line. Keep "proposed" and "credited" as written. Answer slot: if any go-to-market decision for a launch was yours to make, say which and how. If none was, say which decisions you did shape. |
| F4 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Your material is silent on whitespace work. Answer slot: if you have run an analysis that located under-served accounts or stages, name it and what it showed. If not, say how you would find whitespace first. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: agreement across the organization. Words: "I set annual volume targets with cross-org consensus." The limit is that the consensus was cross-org, and the targets were volume targets. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Adjacent. Daily use of AI tools is not the same as building or shipping an AI product. Words: "I use AI tools daily." The limit is the pack's own observation, not a claim she must make. |
| F7 | quota-setting and sales operations (role-family, not in the JD highlights) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | capability | Your notes record the absence. No first-person words are given until Priya confirms it is her own statement. Once she does, her own sentence is the plain acknowledgment. If she has not said it, this row becomes discovery. |

Gap types follow the routing rule in the output template. Two rows (F2, F3) rest on the same coach's-note sentence at different scopes; that is deliberate.

## 6. Grounding brief

Your research note gives three stated priorities and one competitive threat. Search was refused in this run, so these are your note's claims and not a dated source. Check them against a page before using any number.

- **Priorities:** enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- **Main competitive threat:** bundling by a much larger platform vendor.

## 7. Reading the interviewer

Public footprint was not checked. This read rests on the profile you supplied.

- **Career pattern:** pricing and monetization as the spine, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Implications:**

1. Expect the Prober register. Every number you use will be followed to its denominator and assumption.
2. Case questions will likely come from pricing, packaging and unit economics. That is Dan's native language.
3. The startup chapter makes scrappiness and big-company-pace probes plausible. Keep every story at its own scope.
4. **Shared professional domain:** pricing and monetization against your revenue model. That is fair to name in the conversation. There is **no shared jump** to offer, because Dan's startup chapter has no counterpart in Priya's history. Do not pair them.

## 8. Persona table

Weights come from the peer prior, adjusted by the profile signals above. Depth follows weight.

| Persona | Weight | Why this weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 (A1 to A5) | Peer prior is competence probes. Self-described "relentlessly data-driven" pushes it to the top. | Denominators, assumptions, two-level follow-ups on each number | Name the weakest assumption before Dan does. Say plainly when you do not know how a number was counted. |
| Peer Evaluator | 4 (B1 to B4) | Peer prior. Dan's team load and the seam between teams are what is being priced. | Seam questions, disagreement, credit | Propose seam principles, not a seam you have not seen. Offer reciprocity. |
| Case / Strategist | 3 (C1 to C3) | Pricing spine tilts cases toward packaging and unit economics. Compass and bundling are the live problems. | Live problem on Compass or a partner deal | Clarify, then objective, segments, approach, metrics, risks. Think aloud. |
| Skeptic | 3 (D1 to D3) | The JD's partner-motion requirement and the absent quota work are the gaps a peer will test. | Cross-examination of the gap | Hold what your quotes carry. Use the answer slot for the rest. |
| Pressure / Stress | 2 (E1 to E2) | Low for a peer. Included because the ~$400M credit invites "how much was actually you". | Interruption, "how much was actually you" | Pause, restate, hold through two follow-ups, then concede specifically. |
| Conversational / Rapport | 2 (F1 to F2) | Casual questions about AI are still scored. | Biography opener, "what are you playing with in AI" | A 90-second arc. Treat the casual AI question as scored. |
| Values / Behavioral | 0 | No values-style round is detected. Your words establish a single conversation, so no fallback archetype applies, and no loop source documents a values round. | None in this pack | No values cheat sheet. B2 covers behavioral ground. |

**Highest-ROI prep:** D1. A partner-motion question is required by the JD, and the material shows partner economics, not partner design. Rehearse it to three levels before the other banks.

## 9. Question banks

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend the number. Say what was counted, in your own words. Then name the assumption you would defend least, before Dan does. Answer slot: if you know the counting method, say it. If you do not, "I don't know how it was counted" is an honest answer. Hold to "proposed" and "credited"; do not say "drove". | F3 is the headline figure and the first place a prober goes. EXP because it tests attribution, not the size of the number. |
| A2 | "How would you split that uplift between your change and other effects?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Give your share only in a form you can defend. Say which effects you can separate from yours and which you cannot. Expect a second-level follow-up on how you know. Answer slot: if you split it, say how. If you did not, say that plainly. | F3 again, from the attribution side. The question is written so it does not presuppose that a split was made. |
| A3 | "Your partner-level revenue model was used in carrier negotiations. What did it assume, and which assumption would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name one assumption in your own words. Answer slot: if the model had a volume assumption you set, say what it was and how you set it. If you did not set it, say so. Do not describe a model structure you cannot repeat. | F2 is the partner-motion evidence. A3 tests whether the partner economics were hers. |
| A4 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" (coach's notes) | Open prompt: choose an instance. Name the tool and the decision it touched, and nothing beyond that. Answer slot: if one comes to mind that you ran end to end, name it. If the work supported someone else's question, say so. If none comes to mind, give the nearest thing your material carries and say what you did. | F1 is the JD's independent-analysis line, raised by the JD. Open prompt, because the theme comes from the JD. |
| A5 | "Of the numbers in your background, which would you defend least, and why?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Pick the weakest figure yourself, before the follow-up does. The ~$400M is the likely pick. Name its weakest assumption. If you cannot, say you do not know how it was counted. | The Prober's opener. A candidate who names the weakness first turns a gotcha into credibility. |

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on enterprise expansion. Where would you draw the seam between GTM for new product lines and the core org, and what happens when you disagree?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Propose seam principles: who decides price, who owns the partner, who owns renewal. Do not claim to know Dan's team's seam. For disagreement, name how you would settle it with an equal. No claim about your past here. | The JD's GTM-ownership line raises the seam. Peer probes arrive collegially. |
| B2 | "Tell me about a time you disagreed with a peer on a number. What came of it?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Behavioral, STAR-shaped. "We" for the context, "I" for your contribution. Answer slot: if no disagreement comes to mind, say so, then give the nearest thing your material carries: the volume targets reached cross-org consensus. Say your part in getting there, in your words. | F5 is the cross-functional evidence. Open prompt, because the theme comes from the JD's influence line. |
| B3 | "Where would you look first for whitespace across land, adopt, expand and renew? Who would you need to bring in?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the data you need: the account base, usage, and renewal cohorts. Name who holds each. No past claim, so none is made. | F4 has no evidence, so this is the one place whitespace comes up. It is a live problem, so it presupposes nothing about you. |
| B4 | "Where does monetization work end and sales strategy begin, in your view?" | CASE | [grounded] "pricing and monetization" as the career spine (interviewer profile you supplied) | Give a boundary principle, such as price-setting versus motion design. Give one tradeoff, for example where a discount-approval rule sits. Keep it as your view, not a past result. | Dan's native topic. Tests whether you can speak the pricing language without claiming pricing ownership. |

### Case / Strategist (weight 3, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches as a copilot against a much larger platform's bundle. How would you price its packaging?" | CASE | [grounded] "AI copilot launch ('Compass')" and "bundling by a much larger platform vendor" (your research note) | Clarify, then objective, segments, approach, metrics, risks. Challenge one premise respectfully: the bundle as given. No past claim. | Pricing-spine tilt. The Compass launch and the bundling threat are from your note, which was not checked against a page. |
| C2 | "Enterprise expansion, Compass and profitability: if they conflict in one pricing decision, which goes first?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Pick one, give the reason, and name what you would give up. No past claim. | The three stated priorities, at the company's own altitude. |
| C3 | "A partner offers a rebate-heavy deal that lowers blended price. How do you evaluate it?" | CASE | [grounded] "partner-motion design experience required" (JD highlights) | Use a partner-level view: incremental revenue, cannibalization, what the partner commits to. Present it as your approach, not a result. Answer slot: if you have used a partner-level model for a deal like this, say so, and only at the scope of the model. | JD partner requirement with a pricing tilt. F2 is the nearest real material, and it is only a model. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background shows a partner-level revenue model. What is the closest you have come to designing how partners get paid, enabled or targeted?" | JD | [grounded] "partner-motion design experience required" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **Deepest rehearsal.** Level 1: the model, at its own scope. Level 2: answer slot. If you designed any part of partner pay, enablement or targeting, say which and how you decided. If none of it was yours, say so. Level 3, if Dan says "so you've never designed a partner program": hold the model through two follow-ups; the model is real and was used in negotiations. Concede the gap specifically, in your own words, naming exactly what you did and did not design. Never concede more than that. | F2 is the required JD line, and this is the question the role will ask in some form. The hold is only what the quote carries; the concession is her own honest answer. |
| D2 | "Your strongest result is a store-surface change. What go-to-market work for a launch did you do yourself?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Answer slot: name the go-to-market decisions for the change that were yours. If the launch's go-to-market was not yours, say so, and say what you did shape. Hold "proposed" and "credited" through two follow-ups. | F3 is the JD's own-GTM line. The question's premise is the JD's; the guidance does not adopt it. |
| D3 | "How would you set targets for a sales org you have not run, and how would you know they were fair?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Describe how the consensus was reached, in your words, if it was yours to describe. Answer slot: say whether you have set quotas, in your own words. Do not describe quota-setting you did not do. | F5 and F7. The question presupposes no quota history. The answer slot lets her say what is true. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a partner program?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Pause, then restate the question. Anchor in the model. Hold through two follow-ups. Concede specifically on partner design end to end, in your own words. | Pressure stem. F2 is the only anchor the material gives for partner work. |
| E2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: "I proposed the change, and it was credited with the uplift." Answer slot: if you can say your share and how you know it, say it. If you cannot split it, say so, specifically. | Credit probe. The quote is the whole hold, so it cannot be stretched. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name one tool and one task, in your words. Make no product claims. | AI is a JD plus, asked casually. The casual register is still scored. |
| F2 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc: the two years in consulting, the nine in product strategy and ops, then the move toward this role in your words. End on the partner model as the bridge. | Biography is scored even when casual. This is the rapport opener. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B1, C2, D2 |
| identify whitespace across land/adopt/expand/renew | B3, F4 (answer slot) |
| run independent analysis in SQL and Tableau | A4, F1 |
| partner-motion design experience required | D1, A3, C3, E1 |
| strong cross-functional influence | B2, D3 |
| AI experience a plus | F1 (question), F6 |
| quota-setting (not in JD highlights) | D3, F7 |

Session total: 19 questions, inside the 18 to 26 range.

**Reverse questions**

Ask at least five. Each has a reason it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. It signals that she plans to add to Dan's load, not only to draw on it. |
| R2 | "You moved from an early-stage chapter into pricing and monetization. What did that change about how you would price Compass?" | Tied to Dan's own path. It turns the conversation into a peer one. |
| R3 | "Where does pricing here get decided on data, and where on judgment?" | Tests the data-driven culture and shows she is listening for it. |
| R4 | "How are enterprise-expansion targets split between the two new product lines and the core business?" | Uses a priority from the research note and shows altitude. |
| R5 | "What has the partner side of Compass looked like so far, and what has gone wrong with partners before?" | Goes straight at the partner-motion gap, in a form that invites a candid answer. |
| R6 | "How will you know Compass is working in its first two quarters?" | Outcome measure. It shows she thinks in metrics the way a data-driven peer does. |

## 13. Prohibited claims

Built locally from the fit snapshot. The inflated forms are the claims a candidate reaches for under pressure. No guidance, answer slot, hold or reverse question in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed the partner motion | Inflated form of F2's quote "built a partner-level revenue model" | The quote at its own scope. The limit is the pack's observation: the material shows the model, not a partner motion. |
| Owned GTM for a product line, or led the ~$400M uplift | Inflated form of F3: "proposed" and "credited with" | "proposed a store-surface change credited with a ~$400M ARR uplift," with "proposed" and "credited" kept. |
| Set quotas or ran sales operations | Inflated form of F5's "set annual volume targets," plus the absence recorded in F7 | The quote at its own scope. F7's negative is used only once Priya confirms it is her own statement. |
| Built or shipped AI products | Inflated form of F6's "uses AI tools daily" | "I use AI tools daily." |

## 14. Sources

**Provided documents**

- JD highlights (six requirement lines, not the full JD text).
- Coach's notes on Priya's background (summaries, not her own CV sentences).
- Interviewer profile you supplied: pricing and monetization spine, one early-stage-startup chapter, "relentlessly data-driven."
- Your research note: three priorities and one competitive threat.

No dossier was consumed.

**Searches sent**

Four searches were sent. Each was refused, because web search permission was not granted in this session.

1. "Northwind Data values operating principles": refused.
2. "Northwind Data interview process sales strategy": refused.
3. "Northwind Data Compass AI copilot launch": refused.
4. "Dan Kovac Director of Sales Strategy Northwind Data": refused.

No fetches were sent. No user links were read.

**Research tier: L1, searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable (query 1 refused) | Would have fixed published value names. No values round is detected, so the cheat sheet is dropped either way. |
| 2. Northwind Data interview process, sales strategy | unavailable (query 2 refused) | Would have confirmed the loop. Your words already establish a single conversation, so persona weights hold unless a values round appears. |
| 3. Northwind Data strategy / recent news | unavailable (query 3 refused) | Would have verified the grounding brief and the numbers behind C1 and C2. |
| 4. Dan Kovac, Northwind Data | unavailable (query 4 refused) | Would have shown public talks and writing, and so his recurring themes and a tailored reverse question. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the requirement rows. The full text would upgrade them (see the upgrade menu). |

## 15. Upgrade menu

- **Full JD text** → the six requirement lines become verbatim JD quotes, and the JD-tagged questions take its exact wording.
- **Web search permission, or pasted pages** → targets 1 to 4 above. A values page would add a cheat sheet and could reweight the personas. Dan's public talks would add his recurring themes to the bank.
- **Priya's own confirmation of "No classic sales-ops or quota-setting experience"** → F7 becomes capability with her own sentence. If she has not said it, F7 becomes discovery.
- **How the ~$400M figure was counted, in Priya's words** → A1, A2 and E2 gain real material. Her words would regenerate those rows.
- **A tuesday-dossier.md** → would carry verified evidence and the gap list from this prep into later sessions. Without one, this pack is complete as built.
