# Engineering Manager, Larkfield Systems: loop pack (3 rounds)

Rounds: Tuesday, hiring manager, Director of Engineering, 45 min · Thursday of the following week, panel of two staff engineers and a product manager, 60 min · the following Monday, VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy".
Version 1. First build, so there is no changelog.

## How to use + type key

Personas describe how each question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your own experience; whether it survives scrutiny
- **JD**: the role's stated responsibilities
- **CO**: company and strategy (none in this pack; see Sources)
- **CASE**: a live problem, reasoned out loud

Guidance is scaffolding, not a script. Every guidance cell is meant to be spoken in 90 to 120 seconds.

## Shared fit snapshot

Requirements come from the role summary in your message, which is not a job posting, so it is quoted as such. Evidence is quoted verbatim from your message, the only input about your background. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (role summary) | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | transferability | Your material says you run the backend hiring loop. It does not say you own hiring or growth for a team. Keep it at that scope: "I run our hiring loop for backend roles." Answer slot: if you owned any growth or hiring decision beyond the loop, say which and how you decided; if not, say so plainly. |
| F2 | "Lead two squads building device-management services" (role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six led for three years. It does not show two squads or eleven people. Keep the scale in your words: "3 as a team lead of 6." Answer slot: if you have run work across more than one team, say how those teams and their leads were arranged; if not, say so and say how you would structure two squads. |
| F3 | Managing managers (inferred: the two-squad, eleven-engineer scope implies leads of leads; not in the role summary) | "I've never managed managers" (your message) | none | [grounded] | capability | Words: "I haven't managed managers." Then how you would learn it, said as a plan, never as a past. |
| F4 | "partner with hardware and product on roadmap" (role summary) | "I've never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Your material is silent on partnering with hardware teams; that is an observation, not something to say for you. Answer slot for partnering, not owning (see B2). |
| F5 | Device-management services (role summary) | none given | none | [grounded] | discovery | Your material does not show device, fleet or hardware-facing work. Answer slot: if any system you ran managed devices, fleets or hardware-facing data, say which and what you owned; if none did, say so plainly and say how you would learn the domain. |
| F6 | "own delivery" (role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | high | [grounded] | presentation | Your sentence already reaches delivery in other terms. Keep its wording: "I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60%." The 60% raises defend-the-number slots (C1, B3). |

Gap type is chosen by the evidence cell, not by how a row feels. F3 and F4 are capability gaps because you stated the absence. F5 is discovery because the material is silent. F1 and F2 are transferability because real adjacent work is quoted but does not reach the requirement.

## Prohibited claims

Not coached in any answer, slot, hold or reverse question. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have managed managers" or "I've led leads" | Inflated form of F2, and the negative you stated in F3 | "3 as a team lead of 6," at its own scope. Plain acknowledgment: "I haven't managed managers." |
| "I own hiring and growth" for a team | Inflated form of F1 | "I run our hiring loop for backend roles." |
| "I've worked on device or hardware roadmaps" | Negative you stated (F4); inflated form of F5 | "I haven't owned a hardware-adjacent roadmap." |
| "I designed the reliability quarter" or "I set the trade-offs" | Practice the sentence does not carry; "I pushed a reliability quarter through" is your verb | "I pushed a reliability quarter through against roadmap pressure." Who designed the plan is an answer slot (B3). |

## Prep triage

Prep time is about two weeks, so this is the order to spend it in:

1. **B1**, round one's highest-ROI item. Say "I haven't managed managers" aloud, then the plan, until it comes out without preamble.
2. **B2 and D5**, the hardware gap. It comes up in rounds one and two.
3. **C1 and C2**, the 60% and the 40 interviews. Know how each was counted, or be ready to say you don't know.
4. **E4 and E5** before Monday.

Everything else is insurance.

## Loop mode: round-by-round mini-packs

Each round has its own persona weights and bank. The fit snapshot and prohibited list above apply to all three.

### Round 1: Tuesday, hiring manager (Director of Engineering), 45 min

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the two-squad roadmap and the eleven-engineer plan | High. Hiring-manager prior: they are buying capability and checking the requirements | Clarify, then objective, approach, metrics; think aloud |
| Skeptic | "You've never managed managers" and the hardware gap | High. These are the two gaps the role summary makes most visible | The rehearsed plain acknowledgment, then a plan |
| Data-Driven Prober | The 60% and the 40 interviews | Medium. No public profile for the Director, so no signal either way | Know how each figure was counted; name the weakest assumption; say when you don't know |

Weights: Case/Strategist 4 questions, Skeptic 3, Prober 2. No interviewer profile exists, so the weights are the hiring-manager priors.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What do you need to know in your first two weeks before you change anything, with two squads and eleven engineers?" | CASE | [generic] | Clarify first: the squads' current commitments, where the hardware dependencies sit, what each squad lead would tell you first. Propose no changes yet. | Scoped to the role summary; asks for reasoning, makes no claim about your past. |
| A2 | "Hardware says a firmware release slips six weeks, and product still wants onboarding this quarter. What do you do?" | CASE | [generic] | Separate hard dates from preferences. Name the trade-off and who makes the call. Give one recommendation and the risk you would accept. Say you would bring it to the Director, not decide alone. | Tests the partnership requirement in F4 through reasoning. Nothing about hardware history is needed. |
| A3 | "How would you grow a strong senior engineer into a lead within a year?" | CASE | [generic] | Name the signals you would watch, one stretch assignment, and how you would check it is working. Give it as a plan. | Covers the growth half of F1. Your material shows no growth work, so the answer is a plan, not a record. |
| A4 | "Give me your 90-day plan for the two squads." | CASE | [generic] | Listen first, for about 30 days. Name one delivery risk, one people move, and one roadmap conversation with hardware. Make the plan checkable at day 90. | The hiring manager's own scope. Built live, not recited. |
| B1 | "You've never managed managers. Why should we expect it to work?" | JD | [grounded] "I've never managed managers" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't managed managers." Then a plan, not a past: what you would do with each lead in the first 90 days (meet each one, ask what they would fix first, agree with them which decisions move up). Hold through two follow-ups by returning to the plan. Concede specifically: "I don't know yet how the first conversation with a lead of leads goes." Answer slot: if you have worked with someone managing managers, say what you saw; if not, say so and give the plan. | F3 is the gap the role's scope makes most likely to be probed. The hiring manager is buying derisking, so the plain acknowledgment plus a plan is the answer. |
| B2 | "Hardware and product both want a say in our roadmap. Where have you worked alongside a hardware team?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Answer slot: if you have worked alongside a hardware team, say what they needed from software and how you handled a disagreement; if not, say so plainly and say what you would ask hardware first. | F4. The premise comes from the role summary's partnership line, which is a raising source. Your sentence is about owning, not partnering. |
| B3 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold: "I pushed the quarter through against roadmap pressure." That is your sentence. Hold two follow-ups. Concede specifically what others did. Answer slot: if you set the plan, say so; if others did, name them and what they did. | F6 is the strongest evidence you have, and this question tests whether the 60% survives attribution. Do not claim the drop alone. |
| C1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] same quote as B3 | Name the assumption you would defend least in your own words. If you know how the baseline was measured, say it. If not: "I don't know how the baseline was counted." Give no method. | Defend-the-number slot raised by F6. The honest branch is the answer, not a method. |
| C2 | "Of the roughly 40 interviews you ran last year, how many did you score, and what did the scores decide?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Say what you ran: the backend hiring loop, about 40 interviews. Answer slot: if your scores counted toward decisions, say how; if you ran the loop but did not score each stage, say so plainly. Never claim the offer decisions. | Defend-the-number slot on the 40, and a check on F1's hiring scope. |

**Reverse questions**

- "What does a good first 90 days look like for this role?" Why it lands: it shows you are planning against their definition of success.
- "Which of the two squads is hardest to staff right now, and why?" Why it lands: it gets you the real pressure point, not the brochure version.
- "How far ahead does the hardware calendar get set, and who owns it?" Why it lands: it targets your hardware gap directly.

### Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

The panel has no names, so personas are assigned by role. Staff engineers get Prober first and Peer Evaluator second. The product manager gets Case/Strategist first and Peer Evaluator second.

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (staff engineers) | "What did that quarter actually change in the system?" | High. Staff engineers read the CV line by line | Name what you can; say whose work the rest was |
| Peer Evaluator (both) | Seam questions, disagreement, credit | High. Peers price what the hire costs their work | Propose seam principles; don't pretend to know their seam |
| Case/Strategist (product manager) | Roadmap calls with hardware constraints | Medium-high. The PM owns the roadmap the role partners on | Clarify, criteria, recommendation |

Weights: Prober 3 questions, Peer 3, Case 2.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side on device management. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles: one owner per interface, and disagreements settled by a written trade-off with a deadline. Ask them where the seam is today. | Peer stem. It asks about the future and claims nothing about your past. |
| D2 | "What did the reliability quarter actually change in the system? Which alerts, which services?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Say the quarter's goal and the trade-off it made. Answer slot: if you can name the alerts or services that changed, say which; if the technical changes were others' work, say so and say what you did. | The premise (specific system changes) is not in your sentence, so the answer is a slot. Staff engineers test whether the quarter was technical or process work. |
| D3 | "A device change touches both squads. How do you split the work?" | CASE | [generic] | Name the interface first, then one owner per side, then one integration checkpoint. Say how you would know it is working. | Two-squad scope. A plan, with no past claim. |
| D4 | "Product has three device-onboarding requests and one reliability fix. Walk me through the roadmap call." | CASE | [generic] | Clarify criteria: customer impact, hardware constraints, risk. Name what you would ask hardware before scoring. Give a call, and say what you would tell the losers. | The PM's native question. Tests the partnership requirement without claiming hardware history. |
| D5 | "You haven't owned a hardware-adjacent roadmap. What would you check before agreeing to a hardware date?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Hold: "I haven't owned a hardware-adjacent roadmap." Then the plan: firmware lead time, test-rig availability, what breaks if the date slips. Do not describe a hardware project. | A negative you stated, given back as a plain acknowledgment, with the plan as the answer. |
| D6 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Name the other team's part before your own. Say what you did in the quarter, in your words. Answer slot: if others did most of the quarter's work, say so and say what you contributed. | Peer probe on credit. The quarter is the only work your material describes. |
| D7 | "Which part of a device-management service would be hardest to get right on day one?" | JD | [generic] | Name the hard parts from the role itself, such as fleet state and staged rollouts across devices. Say what you do not know yet and how you would find out. | F5. No claim about your background; tests whether you can name the domain's problems without pretending expertise. |
| D8 | "Cut one device-management feature for a quarter. Which, and why?" | CASE | [generic] | Pick the cut with the smallest customer harm. Say the trade-off out loud. | Roadmap judgement. No claim. |

**Reverse questions**

- "What could a new manager do in their first month that would genuinely help your team?" Why it lands: a peer answer turns a test into a working relationship. Reciprocity question.
- "Where do the staff engineers and product disagree most about device-management priorities?" Why it lands: it shows you want the seam, not the summary.
- "How are hardware dates set today, and who pushes back?" Why it lands: it targets your hardware gap precisely.

### Round 3: following Monday, VP Engineering, 30 min

The recruiter describes this round as "values and leadership philosophy". That is the recruiter's description, not a loop source, so the values-style weighting is a judgment. No published company values are in hand, so no values cheat sheet appears (see the upgrade menu).

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Your leadership philosophy," "an unpopular truth" | High. The recruiter's own words name the topic | Principles tied to your sentences; a scaffold where none carries a story |
| Pressure | A first-time manager of managers; "what did it cost you?" | Medium. An executive round is usually short and composure-testing | Pause; hold through two follow-ups; concede specifically |
| Conversational | "Walk me through the journey" | Low to medium. Casual openers are still scored | A 90-second arc built only from your quoted sentences |

Weights: Values/Behavioral 3 questions, Pressure 2, Conversational 1, plus one case question.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What's your leadership philosophy? Give me the parts you would defend." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Three principles, each tied to a sentence of your own. The reliability quarter carries one story: the decision, the pressure, the result. Name each beat in its own clause. Do not add the reasons you think the quarter worked. | The recruiter's words are the raising source. The quarter is the only story your material supplies. |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you held a position under senior pressure, with a named stake and no fold. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, at its own scope. | Open prompt; no quote carries this story, so it is a selection scaffold with its honest branch. |
| E3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one time, or say there was none. Describe the decision and what it cost, in your words. | Persona stem. Your material has no customer story, so this is a scaffold. |
| E4 | "Sixty seconds: why should we trust a first-time manager of managers?" | Pressure stem | [grounded] "I've never managed managers" (your message) | Hold: "I haven't managed managers." Then, in the sixty seconds, the evidence you do have (the reliability quarter, in your words) and the first 90 days as a plan. Hold through two follow-ups; concede specifically. | Pressure question; the plain acknowledgment is the honest core of the answer. |
| E5 | "Your reliability quarter: did it cost you anything with product?" | Pressure | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if it cost you something with product, say what and what you did about it; if it did not, say so plainly. Do not invent a cost. | The premise (a cost) is not in your sentence, so both branches are offered. |
| E6 | "So, walk me through the journey." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6" · "I run our hiring loop for backend roles — about 40 interviews last year" · "I pushed a reliability quarter through against roadmap pressure" (all your message) | A 90-second arc in the order of your sentences: nine years in engineering, three as a team lead of six, the backend hiring loop, the reliability quarter. Each beat is one of those clauses; add nothing between them. | Low-weight casual opener. Its scoring is in the flow, not the content. |
| E7 | "What would you want to know about our device fleet before you set a delivery goal for the first six months?" | CASE | [generic] | Ask about fleet size, release cadence, incident data and hardware constraints. Propose one goal form and say how you would check it. | Live problem on the role's delivery scope; no claim about your past. |

**Reverse questions**

- "What would make you say in six months that hiring this manager was the right call?" Why it lands: it shows you are measuring the job by their standard.
- "How should a manager handle a roadmap call that hardware disputes?" Why it lands: it is the question you most need answered, asked at the level that decides it.
- "What does reliability mean to the leadership team here?" Why it lands: it lets you hear their definition before you use yours.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A1, A4, D3 |
| Own delivery | B3, C1, D2, E5 |
| Own hiring and growth for 11 engineers | C2, A3 |
| Partner with hardware and product on roadmap | A2, B2, D4, D5 |
| Managing managers (inferred) | B1, E4 |
| Device-management domain (no evidence) | D7, E7 |
| Values and leadership philosophy (recruiter's words) | E1, E2, E3 |

Nothing in the role summary is left uncovered.

## Sources

- **Provided documents:** your message (the role summary and your background). No CV, job posting, recruiter email, interviewer profiles or company values were supplied.
- **Searches attempted:** "Larkfield Systems industrial IoT company values" (refused: web search permission was not granted in this session). "Larkfield Systems device management engineering manager interview" (refused, same reason). Two calls, both refused; no results.

**Research tier:** L1, searches 0 of 6 (2 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, which is absent. The VP round's guidance is generic. |
| 2. Interview process for this role family | unavailable | Loop structure. Round weights come from your stated rounds, not research. |
| 3. Company strategy and recent news | unavailable | Current-strategy questions (CO) are absent. |
| 4. Interviewer names | n/a | No names given, so there was no query to form. |
| 5. Representative job posting | unavailable | JD-tagged questions are derived from your role summary, not from a posting. |

## Upgrade menu

- The full job posting → the six requirement rows become [grounded] against the posting's wording, and any hard requirement (hardware, IoT, managing managers) becomes a gate, not a gap.
- Permission for web search → company research at the L1 tier: values for the VP round, interview-process structure, and current strategy for CO questions.
- Interviewer names, including the Director and the panel → personas and reverse questions tailored to each person, and the interviewer read.
- The recruiter's email → confirms process details and any pre-declared deliverable, which would add a build section.
- The company's values page, pasted → a values cheat sheet for Monday's round, with VAL questions mapped to published values.
- How the 60% was measured, and who else owned the quarter → B3, C1, D2 and D6 move from answer slots to stories, but only in your words, and that regenerates those rows.
- A tuesday-dossier.md → a grounded objection list to sharpen the Skeptic bank.
