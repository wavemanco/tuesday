# Stripe · Product Operations Manager · Final round prep pack

**Interviewer:** not given · **Round type:** not given, so persona weights are flat · **Changelog:** first pack. Built with no CV, no job description and no company research (web search was refused in this session). Every experience cell is a worksheet cell.

## How to use this pack

Personas describe **how a question arrives** (the delivery style). Types describe **what is being scored**:

- **CASE**: a live problem, solved aloud. Tests structure and reasoning.
- **EXP**: a question about your own past work. Tests whether your claims survive scrutiny.
- **JD**: a question about the role's stated or likely requirements. Tests whether you can do the job, gaps included.
- **CO**: a question about the company and its strategy. Not scored in this pack, because no company research ran.
- **VAL**: a behavioral question about how you have acted. Tests the pattern of your choices, not generic virtues.

The guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

No job description and no CV were supplied, so the requirements below are role-family prose from general knowledge of this job type. They are not quotes from Stripe, and no evidence exists yet in your material. Once you share a job description and background, these rows become quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Running an operating process that several teams depend on (role family) | none given | none | [generic] | discovery | Pick a process you ran or changed that other teams relied on. It needs a named process, what you did in it, and what happened to it afterwards. If no such process comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. |
| R2 | Turning a business question into an operating metric someone acts on (role family) | none given | none | [generic] | discovery | Pick a metric you used to decide something. It needs the decision it changed. If you have not used one to decide anything, say so, then describe the nearest one. |
| R3 | Influencing product, engineering, finance and go-to-market without direct authority (role family) | none given | none | [generic] | discovery | Pick a time you got a group to change how it worked without owning its budget or people. It needs the person who resisted and what you did about it. If none comes to mind, say so plainly, then give the nearest one. |
| R4 | Designing a process or tool and getting people to adopt it (role family) | none given | none | [generic] | discovery | Pick a process you designed or improved and how you got people to use it. If you only proposed it, say that. |
| R5 | Writing and presenting to senior leaders (role family) | none given | none | [generic] | discovery | Pick a document or presentation that changed a decision. Say who it went to and what they decided. If none did, say so, then give the nearest one. |
| R6 | Choosing priorities when requests outrun capacity (role family) | none given | none | [generic] | discovery | Pick a time you said no to work or deferred it. It needs the criteria you used and who you told. If you have not had to, say so and describe how you would decide. |

No row is a gate: the material is silent on gates, and no job description was supplied to name any.

## Prohibited claims

No entries yet. An entry on this list is either a stretched wording of a sentence you wrote, or a claim one of your own sentences contradicts. Neither exists yet, because the material holds no sentence about your experience. So this pack coaches no claim of experience at all: every answer is a selection scaffold ending in its honest branch. The list is rebuilt once your background is in.

## Persona weights

Relationship, interviewer and loop are all unknown, so no archetype or loop source applies and no persona outranks another. Weights are flat, and each persona gets three questions. This is the weakest form of the pack: rehearse all six styles.

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist (A) | Live operating problems from the role | Flat: no round type to weight it | Clarify, then structure, then state metrics and risks | 3 |
| Skeptic (B) | Probes the gaps and the motivation | Flat | Name the expected doubt, answer it with what you stated, then a ramp plan | 3 |
| Data-Driven Prober (C) | Asks how numbers were counted | Flat | Name the weakest assumption before they do; say plainly when you do not know | 3 |
| Values / Behavioral (D) | Scenario questions about past choices | Flat. No values round is detected, so these are generic | Selection scaffold, then the honest branch | 3 |
| Pressure / Stress (E) | Interrupts, time-boxes, questions motives | Flat | Pause, restate, hold through two follow-ups, concede specifically | 3 |
| Conversational / Rapport (G) | Friendly openers that are still scored | Flat | 90-second arc; treat casual questions about the role as scored | 3 |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would bring order to a launch that six teams are tracking in six different spreadsheets. What do you need to know first?" | CASE | [generic] | Clarify first: what the launch is for, who decides, what done looks like. Then state one objective, split the work by team or dependency, and propose one shared view and its owner. Name the risks: where the spreadsheets disagree, who is slow to update. Think aloud and say what you are assuming. | Case stem. Draws on R1. CASE because it is a live problem; it asks about no past claim. |
| A2 | "Weekly metrics for one region fell 20% last week. Where would you start?" | CASE | [generic] | Clarify whether the drop is real: a definition change, a data gap or seasonality. Split by time, segment and funnel step, then name the two likeliest causes and the check for each. Name the weakest assumption in the data first. | Case stem. Draws on R2. |
| A3 | "Three teams want the same shared resource next quarter, and you have capacity for one. How do you decide?" | CASE | [generic] | State the criteria before the options: value, cost of delay, who is blocked. Choose one, say what you would tell the other two, and what you would re-check at the next review. | Draws on R6. A prioritization case is common for this job type. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the one area where you have least direct experience, plainly. Say what you would do in the first thirty days to close it. Do not claim experience you have not stated; if you have none in that area, say so. | Skeptic stem. **The highest-ROI prep in this pack:** a skeptic asks some form of this. With no CV yet, the weakest area is unknown, so rehearse the honest form now. |
| B2 | "Why this role, and why now?" | JD | [generic] | Give two reasons from your own path, in your own words, then one thing you want from this role. Keep any company claim to things you have checked yourself. | Motivation probe every panel runs. No company research ran, so no company facts are offered. |
| B3 | "Where would a panel most likely doubt you, and what would you say to them?" | JD | [generic] | Name the doubt in one sentence. Answer it with an experience you have stated, if you have one, then close with a ramp plan. If no experience answers it, say so and give the plan. | Skeptic stem. Its answer depends on R1 to R6, which stay unscored until your background arrives. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you used to decide something. How was it counted?" | EXP | [generic] | Pick one metric you actually used. Say what it measured, how it was counted, and what changed because of it. Name the weakest assumption before the interviewer does. If you have not used a metric to decide, say so and describe the nearest one. | Prober stem. Draws on R2. An open prompt: it asks you to choose the instance. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Answer from the metric in C1: name one assumption, say how it could be wrong, and say what you would check. If you do not know how it was counted, say so. | Prober follow-up. The "I don't know" branch is honest, not a failure. |
| C3 | "Tell me about a process you changed. How did you know it worked?" | EXP | [generic] | Pick one change. Say what was before, what you changed, and the signal you used. If nothing was measured, say so and say what you would measure first. | Draws on R4. Stops a before-and-after from being invented. |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told a senior person something they did not want to hear. It needs the truth you said, to whom, and what changed afterwards. Use "I" for your part and "we" for the team. If none comes to mind, say so plainly, then give the nearest one. | Values stem. No published values were found, so this is generic behavioral practice. Draws on R5. |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need and an internal target pulled apart. Say what you chose, why, and the result, including any cost. If none, say so and give the nearest case. | Values stem, generic. |
| D3 | "Tell me about a time you disagreed with a decision made by someone more senior." | VAL | [generic] | Pick one disagreement. Say what you argued, what you did after the decision, and what you would do differently. Keep the other person's view fair. | Draws on R3. |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over the other strong people in this process?" | JD | [generic] | Pause, then restate the question in your own words. Answer with two strengths you can show, and one honest limit. Hold your answer through the first follow-up. Concede a point only if it is specific. | Pressure stem. Hold-then-concede structure. |
| E2 | "That sounds rehearsed. What did you actually do?" | EXP | [generic] | Do not get defensive. Restate what you did in one sentence. If the outcome belonged to the team, say which part was yours. Hold the position through two follow-ups. Concede a detail you are unsure of, specifically, but never the core claim. | Draws on R5. The concession is the test. |
| E3 | "Tell me about a result you can personally vouch for, and how much of it was you." | EXP | [generic] | Name the result, then split it into what you did and what others did. Say which figure you are sure of and which you are not. If you have no result you can vouch for, say so, then describe the nearest one. | Pressure on attribution. Defend-the-number applies to any figure you give. |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three moves that mattered, in your own words, and why this role now. Keep it to what you can explain under a follow-up. | Casual register, still scored. No background material yet, so this is a scaffold. |
| G2 | "What tools or methods have you been using lately to run operations?" | JD | [generic] | Name the tools you use now and what for. If you have not used one the role expects, say so and how you would learn it in a week. | Draws on R4. Casual questions about tooling are scored. |
| G3 | "What does a typical week look like in a role like this?" | JD | [generic] | Describe a typical week as your understanding, labelled as such. Then ask which part they would most like you to be strong in. | Tests whether your picture of the job matches theirs. |

### Requirement coverage

No requirement is stated in a job description, so the coverage below maps the role-family requirements in the fit snapshot. None is uncovered.

| Requirement | Question IDs |
|---|---|
| R1 operating process across teams | A1, D3 |
| R2 operating metrics | A2, C1, C2 |
| R3 influence without authority | D3 |
| R4 design and adoption | C3, G2 |
| R5 senior communication | D1, E2 |
| R6 prioritization | A3 |

## Reverse questions

Your questions for the interviewer. No interviewer profile exists, so these are role-generic. None is tied to an interviewer's career path, and this is not a peer round, so no reciprocity question is required.

1. **"What does a strong first 90 days look like for this role?"** Why it lands: it surfaces the success criteria and shows you think in outcomes.
2. **"Which process in this area is working least well right now, and who owns it?"** Why it lands: it reveals the real problem and shows you look for the seams.
3. **"How is success measured for this role, and who decides whether it was met?"** Why it lands: you learn the scorecard and the decision-maker.
4. **"What have the people who succeeded in this role done differently from those who struggled?"** Why it lands: a specific answer you can use in the next round.
5. **"Who would I work with most closely, and what do they need from this role that they do not get today?"** Why it lands: it shifts you from applicant toward colleague.
6. **"Where are you in your decision, and what would you need to see from me before then?"** Why it lands: it finds the timeline and the next step.

## Sources

**Provided documents:** your message only ("Stripe final-round interview for a Product Operations Manager role"). No job description, CV, recruiter note or interviewer name.

**Searches sent (all refused, so nothing was read):**
- "Stripe company values operating principles". Refused (target 1).
- "Stripe interview process Product Operations Manager final round". Refused (target 2).
- "Stripe strategy recent news 2026". Refused (target 3).
- "Product Operations Manager job description responsibilities qualifications". Refused (target 5).

No company facts in this pack come from research. Company-specific content is absent.

**Research tier:** L1 requested, unavailable. Searches 0 of 6 (4 attempted, all refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fed the values cheat sheet and the VAL bank. Refused. |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Would have named the rounds and moved the persona weights off flat. Refused. |
| 3. `Stripe strategy` / recent news | unavailable | Would have fed CO questions. None are included; the bank has no CO items. Refused. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative Product Operations Manager JD | unavailable | Would have grounded the requirement rows as [inferred]. Refused. |

## Upgrade menu

- **Job description text** → the six role-family rows become quoted rows, and B1 and B3 can be aimed at the requirement that is most likely to be probed.
- **CV, or a few bullets about your background** → each row's evidence cell fills with your own words, and the selection scaffolds become story maps.
- **Round type and who you are meeting** → persona weights reweight from flat, and the banks reorder to match.
- **The recruiter's note on focus areas, a take-home or a presentation** → a graded-deliverable section for each one named.
- **The interviewer's name** → a public-footprint read, and a reverse question tied to their career path.
- **Web search permission** → the company research pass (values, interview process, strategy) at the default tier. Once that runs, the values cheat sheet appears only if a source documents a values round.
- **Prep time available** → a prioritized schedule of what to rehearse first.
- **A `tuesday-dossier.md`, if one exists** → verified evidence and a sharper choice of which objection to rehearse most deeply.
