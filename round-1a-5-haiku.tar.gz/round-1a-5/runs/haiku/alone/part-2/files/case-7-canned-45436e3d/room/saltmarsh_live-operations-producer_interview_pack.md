# Prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, per Saltmarsh's careers page, to be confirmed by you (see the upgrade menu).
**Format:** one 60-minute interview, a live-incident tabletop followed by a values conversation (careers page).
**Candidate:** Femi (they/them).
**Changelog:** first version.

---

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the company's values |
| EXP | Experience deep-dive | Whether what you did survives scrutiny |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Whether you know the company's current direction |
| CASE | Live problem | Structure and reasoning on a problem from the job, delivered live |

---

## Fit snapshot

Every answer in this pack draws on the quotes below. Quoted sentences are yours (from your message or your background) or from the sources in section 14.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar. Keep the bridge at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles, so expect a probe on how two calendars were coordinated. If you coordinated more than one, say how. If you ran only the one, say so and say how you would set up the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A checklist used by QA touches cross-team work but does not show the coordination itself. Answer slot: name an update where you brought these teams together and what each needed from you. If you did not coordinate them, say so and say how you would set it up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning a post-event review, and presenting is not owning. Bridge: "I presented the monthly retention numbers to the studio head." Your material shows presenting, not owning a review. Answer slot: if any post-event review or its KPI definitions were yours, say which. If not, say so, and say what you would put in one. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge rewords only that quote: "I presented the monthly retention numbers to the studio head." Add no figures. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | Writing the checklist is adjacent to managing it release by release, which your material does not show. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran a release check against it, say how. If not, say so. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | The years meet the number. Live-service is not stated: your material gives a puzzle-game studio and a content-drop cadence. Bridge: "I spent four years as an associate producer at a puzzle-game studio." Whether that counts as live-service is for the interviewer to judge. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Expect a probe on cadence. The bridge is the quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a checklist QA works from. Bridge rewords only that quote: "I wrote the release checklist our QA team still uses." |
| F9 | Leading the people a producer coordinates (role-family expectation, not in the JD) | "Never led a team" (your message) | medium | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn to lead people, said as a plan and never as a past. Never describe the checklist as leading people. |
| F10 | "a season-pass model" (Project Larkspur announcement, saltmarshgames.com) | "Never worked on a game with in-app purchases" (your message) | medium | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then a plan for learning season-pass mechanics, said as a plan. No monetization experience is claimed anywhere in this pack. |

Your material does not establish any incident response, so no row claims one. The tabletop is covered in the Case bank.

### Prohibited claims

What this pack will not coach, and why. Every guidance cell is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events for two titles | Inflated form of F1: your material says one title's content-drop calendar | "For two years I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: the material says one title and content drops, not live events. |
| Owned the post-event review and its KPIs | Inflated form of F3: your material says you presented the numbers | "I presented the monthly retention numbers to the studio head." |
| Owns release sign-off | Inflated form of F5: your material says you wrote the checklist | "I wrote the release checklist our QA team still uses." |
| Led or managed a team | Sourced: your stated negative, "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Worked on in-app purchase or monetized games | Sourced: your stated negative, "Never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

---

## Reading the interviewer

Public professional footprint only.

- **Career pattern:** previously a QA lead at a console studio, now Head of Live Operations at Saltmarsh (GDC 2026 talk listing).
- **Published argument:** "a live team is judged by how often its patch notes describe what actually shipped" (GDC 2026 talk listing).
- **Implications:**
  1. Expect precise questions about what was announced versus what shipped. Answer with exact facts, and say when you do not know.
  2. The release checklist you wrote is shared vocabulary with his QA background. Use it as a mirror point, in your own words.
  3. The careers page says the loop includes a values conversation. Expect the questions in the Values bank.
- **Shared jump:** none found. Your QA-adjacent work and his QA lead background are a shared domain, not a shared career move, so the pack does not frame it as a jump.

---

## Persona table

The loop is one hiring-manager interview (careers page), so the relationship prior is Case/Strategist and Skeptic. The Outage Hour format makes the tabletop the top weight. The values conversation adds Values. His QA background and his published argument sharpen the Prober. The Pressure and Conversational personas are low-weight but included, since every plausible style should be met before the live round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live incident and live-calendar problems | Highest: the careers page names a live-incident tabletop | Clarify, then scope, decide, communicate, then verify; say the assumption you would check first | 5 |
| Skeptic | Gaps: leadership, monetization | High: your two stated gaps are the obvious objections | Plain acknowledgment, then a plan; hold two follow-ups; concede specifically | 4 |
| Values / Behavioral | The values conversation | Certain to occur, format per careers page; values names not verified (section 14) | Selection scaffold with an honest branch where no story exists | 3 |
| Data-Driven Prober | Retention figures and KPI definitions | Medium: a presented figure invites a how-was-it-counted question | Say what you know about counting, and say plainly when you do not | 3 |
| Pressure | Composure under challenge | Medium: a hiring manager may test a gap hard | Pause, restate, hold, then concede exactly what is true | 2 |
| Conversational | Opening journey and an open view question | Medium: the opener is scored too | Ninety-second journey in order, with the gaps named by you | 2 |

---

## Question banks

Requirement coverage (one line per JD requirement):

- Plan and run the calendar for two titles: A2, A3, F1
- Coordinate design, art, engineering and community teams: A5
- Own the post-event review and KPIs: B3, D3
- Manage the release checklist with QA: B4
- 3+ years producing live-service: none, and why: years are in your background and live-service is probed through F1 and F6 in the Journey question (F6 covers fit)
- Experience running a content calendar: A4
- Player-retention metrics: D1, D2, E2
- Clear written communication: none, and why: your writing is judged in every answer, not in a separate question

Total: 19 questions across six personas.

### A. Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 40 minutes into a live event and players report a reward is not being granted. Walk me through the first thirty minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (Saltmarsh careers page) | Clarify first: what is broken, for how many players, since when. Then decide: whether to pause the event, who you tell first, what players see and when. Say the one fact you would verify before acting. Speak in order, in about two minutes. This question makes no claim about your past. | The Outage Hour format from the careers page. CASE because it scores structure in live time. |
| A2 | "You plan live events for two titles. Both release windows land on the same weekend. How do you decide which one moves?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify what each title owes players and what a move costs each. Compare, decide, name the assumption you would check, and name who you would tell. Do not borrow a past decision. | The JD sentence is the raising source. It tests the two-title limit in F1 live, without asserting experience with it. |
| A3 | "Two titles move to one shared events calendar from February. What do you do in the first sixty days?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, Project Larkspur) | Clarify what is shared and what stays per title. Map each team's dependency on the calendar. Decide what the first cycle must protect. Speak to the single live-ops group the announcement describes. No claim about your past. | Larkspur is the company's current direction (announced September 2026). A CO question is the one most candidates cannot touch without research. |
| A4 | "You ran a weekly content-drop calendar for two years. What decision about it would you change now?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Story-map from that sentence: weekly cadence, one title, two years. Name one decision you would change and why, in your words. Answer slot: if you changed what went on the calendar or how it was set, say which and why. If nothing was yours to change, say so and describe the weekly process as you ran it. | F1 and F7. The question is premised on your own sentence, so it presupposes nothing the sentence does not say. |
| A5 | "How would you coordinate design, art, engineering and community on a single update?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Wrote the release checklist our QA team still uses" (your message) | Structure: what each team needs and when, one owner for each decision, and the checklist as the release gate. Use the checklist as your only past reference. Answer slot: if you coordinated one update across these teams, name it. If not, say so and answer the design. | F2 is discovery, so this question asks the design and offers the honest branch rather than a past. |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "This role runs live events on titles that move to season passes, and you have never worked on a game with in-app purchases. What would you do in your first ninety days on that?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message); "a season-pass model" (Project Larkspur announcement) | Plain acknowledgment first, in your words: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: learn season-pass mechanics from the team's own data, meet the monetization owners, and decide what you would check first. Hold through two follow-ups by returning to the plan. Concede specifically what you do not know about how season passes are priced or sold. Never claim monetization experience. | F10 is the stated capability gap, and Larkspur makes the question likely. Deepest rehearsal: three follow-up levels, each answered by returning to the plan. |
| B2 | "You have never led a team. This role coordinates four teams and answers for their updates. Why should we hire you for it?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses" (your message) | Plain acknowledgment: "I haven't led a team." Then the closest thing you have done, in the quote's terms: "I wrote the release checklist our QA team still uses." Then how you would learn to lead people, as a plan. Hold for two follow-ups. Never describe the checklist as leading QA. | F9 and F5. The stated gap is answered truthfully before any strength is offered. |
| B3 | "You presented the monthly retention numbers to the studio head. Which part of the analysis behind them was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold to the presenting: "I presented the monthly retention numbers to the studio head." Answer slot: if you built any part of the analysis, name the part and how you decided it. If you only presented, say so plainly, then say what you would own in a post-event review. | F3 is transferability. This is the JD's post-event ownership, asked as a probe. |
| B4 | "Walk me through how a release gets checked against your checklist." | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-map: you wrote it, and QA uses it. Answer slot: if you ran a release check against it, walk through one. If not, say so, say who did, and say what you would add to the checklist for a live update. | F5, against the JD's line to manage the checklist with QA. |

### C. Values / Behavioral (weight: mid, 3 questions)

The careers page confirms a values conversation, but the value names are not verified (section 14), so these questions use the conversation's form and persona stems, not named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a date you had committed to conflicted with what players needed." | VAL | [grounded] "a values conversation" (Saltmarsh careers page); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Scaffold: pick a time a published date ran against what players needed, what you chose, and who you told. Nearest thing your material carries: the content-drop calendar, but only if a date actually moved. Honest branch: if none comes to mind, say so plainly, then give how you would handle it. | An open prompt whose theme comes from the careers page. Scored in the values conversation. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "a values conversation" (Saltmarsh careers page) | Scaffold: an update or decision where the news was unwelcome, what you said, and how it landed. Honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Persona stem from the Values persona. His published argument (section 7) makes this a likely follow-up on what shipped. |
| C3 | "When did you put a player ahead of an internal metric?" | VAL | [grounded] "a values conversation" (Saltmarsh careers page) | Scaffold: a time a metric and a player need pulled apart, and what you chose. Honest branch: if none, say so plainly, then say how you would decide when the metric and the player disagree. | Persona stem. Links to the retention figure in the Prober bank without assuming one. |

### D. Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you know how it was counted, say the method and window in your own words. If you do not, say so plainly and say who would know. Do not explain a method you cannot repeat under a second question. | F4. No figure was given, so no method is supplied. |
| D2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of, in your words. If you cannot name one, say that. | The weakest-assumption move, asked before the interviewer names it. |
| D3 | "A post-event review says engagement rose and retention stayed flat. What do you check first?" | CASE | [generic] | Clarify the window, the cohort and the comparison. Check whether the event reached the cohort you measured. Decide what would change your reading. This question makes no claim about your past. | The JD's post-event KPI ownership, as a live problem. |

### E. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team" (your message) | Pause, restate, then: "I haven't led a team." Hold for two follow-ups on what you would do in the first month. Concede specifically that you have not led people, and say how you would learn. Never fold on the checklist as evidence of leadership. | F9. The pressure hold is a position your material supports: you have not led people. |
| E2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: "I presented them." Answer slot: if you did any of the analysis, name the part. If you did not, say so. | F3. The answer is the presenting, not the analysis. |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses" (your message); "Presented the monthly retention numbers to the studio head" (your message) | Ninety seconds in order: the studio, the calendar, the checklist, the retention presentation. Then name your two gaps in one line: "I haven't led a team or worked on in-app purchases, and here is how I would close both." | An opener is scored. The arc uses only your quoted sentences. |
| F2 | "What do most teams get wrong about live ops?" | CASE | [generic] | Pick one view and tie it to something you saw in your own calendar work, in your words. Answer slot: if your calendar work shows the point, say how. If not, give the view without the example. | Rapport question. It is scored as a view on the job. |

---

## Sources

**Provided documents:** your message (JD text, background, known gaps).

**Research at tier L1:**

| # | Query or page | Result |
|---|---|---|
| 1 | "Saltmarsh Games company values" | saltmarshgames.com/values, search snippet only; not fetched. Value names are not used as raising sources. |
| 2 | "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched. Outage Hour format and no take-home. |
| 3 | "Tobias Wrenfield Saltmarsh Games" | Talk listing, "Patch Notes Are a Promise" (GDC 2026); search snippet only; not fetched. Career and argument from the snippet. |
| 4 | "Saltmarsh Games mobile game news" | saltmarshgames.com/news/project-larkspur, fetched. Season-pass model and shared events calendar from February 2027. |
| 5 | saltmarshgames.com/values | Fetch sent: not sent in this run. |

Research tier: L1, searches 4 of 6, fetches 2 of 2.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Returned the value names from a snippet only; no values section built, because the page was not fetched. |
| 2. Interview process | yes | Outage Hour format: Case bank, persona weights, no graded deliverable. |
| 3. Strategy and recent news | yes | Project Larkspur: A3, B1, fit row F10. |
| 4. Interviewer public footprint | yes | Career pattern and published argument: interviewer read, C2 rationale. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## Reverse questions

Interviewer is the hiring manager, so one question ties to his path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops from a QA lead role at a console studio. What from those years do you use most in this job, and what did you have to unlearn?" | Ties his public path to a conversation, not an interview. It signals you read his background. |
| R2 | "Two titles move to one shared events calendar and one live-ops group. What does the first quarter look like for this role?" | Shows you read the Larkspur announcement and are thinking about the job's shape, not the title. |
| R3 | "After a live-incident tabletop goes well, what changes for the team?" | Shows you treat the Outage Hour as a practice, not a test. |
| R4 | "How is the post-event review set up today: who writes it, and which KPIs does it report?" | Asks directly about the ownership the JD names, without claiming it. |
| R5 | "On a live update, how does the release checklist get used with QA, and who signs it off?" | Probes the JD's release-checklist line and shows you know how the checklist you wrote would sit in the new group. |
| R6 | "What would make someone in this role clearly succeeding by month six?" | Standard, and useful to hear his answer against your gaps. |

---

## Upgrade menu

- Confirm Tobias is the hiring manager for this role → persona weights stay as they are. If the round is a peer or panel instead, weights and the reverse questions are recomputed.
- Any live incident you handled, however small, described in your words → A1 and C2 move from answer slots to story-mapped guidance.
- Fetch saltmarshgames.com/values → the values cheat sheet, and C1 to C3 can name the values.
- Recruiter's note on what the Outage Hour focuses on → the tabletop emphasis in the Case bank.
- How the retention figure was counted, if you know → D1 and D2 move from answer slots to story-mapped guidance, in your words only.
- Deep research (L2): his talks and writing, and reports on the Outage Hour → sharper reverse questions and a grounding brief on current company direction.
- A tuesday-dossier.md from a prior job review → would add verified evidence and prohibited claims to this pack.
