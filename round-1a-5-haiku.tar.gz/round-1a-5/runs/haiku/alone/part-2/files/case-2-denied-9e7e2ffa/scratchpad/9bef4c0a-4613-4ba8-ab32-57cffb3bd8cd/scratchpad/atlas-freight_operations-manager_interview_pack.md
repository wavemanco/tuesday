# Interview prep: Operations Manager, Atlas Freight

Round: not yet known (built as a hiring-manager round; see Persona table). Interviewer: not named.
First version, session mode. Research: none. Web search was refused, so company values, interview process and strategy are not established here.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: EXP (did you actually do it), JD (can you do the listed job), CASE (live problem from the role), CO (company knowledge: none here, since no research ran).
- Guidance is scaffolding, not a script. Rehearse it aloud, in your own words.
- Answer slots (sentences ending in "if … say so plainly") are instructions for the interview. Fill them from your real experience only.
- Pack size: 16 questions, below the usual 18–26, because research failed and the banks stay limited to what your material and the JD support.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | low | [grounded] | transferability | Your material shows one site and three supervisors, not four sites. Bridge at its own scope: "Right now I manage three supervisors on a shift." Slot in A1 and B1. |
| F2 | "lead a team of 12 supervisors" — JD | "senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Bridge at its own scope: "I manage three supervisors." The gap in numbers is the one a Skeptic will press first. Slot in A1. |
| F3 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Bridge at its own scope: "I cut the mis-pick rate 40% by redesigning the pick path." That is accuracy, not on-time or cost. Your material shows no on-time or cost figure. Slot: if you moved one, say which and how; if not, say so and say what you would measure first. |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | low | [grounded] | hard_gate | Your material does not establish five years of leadership: the seven years is operations work, with no dates for when you led people. Surfaced, not bridged. Asked in Step 1, item (d). |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel, never used Power BI" — your message | medium | [grounded] | capability | You stated the Power BI gap. Words: "I haven't used Power BI." Then how you would learn it, as a plan. Excel is the part you can claim, in your words. |
| F6 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | high | [grounded] | none | Quote reaches the requirement. Words: "I'm Green Belt certified." Expect a probe on applying it (C3). |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. The pack will not coach any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs daily operations across four sites | Inflated form of F1 | Your material says one site and three supervisors: "ran the site's peak-season surge plan two years running," at that scope |
| Leads twelve supervisors | Inflated form of F2 | "senior shift manager over 3 supervisors" |
| Owns on-time performance and cost-per-shipment | Inflated form of F3 | "cut mis-pick rate 40% by redesigning the pick path," at accuracy scope |
| Has five years of operations leadership | Inflated form of F4 | The dated answer from A2. Until you give dates, no claim |
| Has built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." No slot |

## Persona table

Weights are a shown judgment. Relationship is unknown, so these weights assume a hiring-manager round. Question 1 in Step 1 would change them.

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "You lead three, they lead twelve" — the scope gap | High (depth 5) | The JD names 12 supervisors and 4 sites; your material shows 3 and one site (F1, F2). A hiring manager is buying a derisked hire | Hold the scope you have; name the Power BI gap plainly; give a dated plan, not a past |
| Case / Strategist | Live problems on four sites, on-time and cost | High (depth 4) | The JD's first two lines are operating problems | Clarify first, then structure; no claims about your past in case answers |
| Data-Driven Prober | Mis-pick 40% and the Excel-to-Power-BI reporting requirement | Medium (depth 3) | Headline figure on your CV (F3); reporting requirement is a probe magnet | Know how the figure was counted; name the weakest assumption before they do |
| Pressure | Time-boxed challenge on scope and on the 40% | Medium (depth 3) | Senior role; the figure invites "how much was you" | Pause, restate, hold through two follow-ups, concede only what is true |
| Conversational, Peer | Not banked | Low until the round is known | Rebanked if Step 1 answer says peer or panel | Reweight when the relationship is known |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today, and this role leads twelve across four sites. What makes you ready for that jump?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message | Hold the scope you have: "Right now I manage three supervisors on a shift." Say what carries over from those three, without enlarging it. Answer slot: if you have led people across more than one site, or more than three supervisors, say which and how, in your own words; if you have not, say so plainly, then say what you would do in your first 90 days to take on twelve supervisors across four sites, as a plan. Hold through two follow-ups by returning to the three. | F1 and F2 are the largest gaps; the JD gives the numbers, so this objection will come in some form. Deepest rehearsal in the pack. |
| A2 | "The role requires five years of operations leadership. Walk me through the roles where you led people, and when each started." | JD | [grounded] "7 years in warehouse and distribution ops" — your message; [grounded] "senior shift manager over 3 supervisors" — your message | Give dates and titles in your own words. Count only the years you led people. Answer slot: if your leadership time is under five years, say so and say what it covered; if it reaches five, give the dates. | F4, the hard gate. Your material does not show when leadership began, so the pack cannot answer it for you. |
| A3 | "That mis-pick rate fell 40%. Walk me through how it was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Defend the number: say the baseline period, the sample and where the count came from, in your own words. Name the weakest assumption behind the figure before they do. Answer slot: if you pulled the count yourself, say how; if it came from a system or a colleague, say so. | The headline CV figure is the first thing a prober tests. The pack supplies no baseline or method. |
| A4 | "Who else shaped the pick-path redesign, and who made the final call?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Attribution, not counting. Say who else contributed, in your own words. Answer slot: if you made the final call, say how you decided; if others did, say which part was yours. | Separates your part from the team's, which is where a figure gets challenged. |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" — your message | Name it plainly: "I haven't used Power BI." Then the Excel bridge in your own words: "I have solid Excel." Then a plan: how you would learn Power BI in the first month. | F5 is a stated absence, so the plain acknowledgment is the honest answer; the plan carries the rest. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch your first 30 days across four sites. What do you need to know first?" | CASE | [grounded] "Own daily terminal operations across 4 sites" — the JD you supplied | Clarify before structuring: site mix, volumes, how the four sites' on-time figures differ, what is measured today. Then one daily cadence for all four, one definition of on-time and cost-per-shipment, an escalation path. No claim about your past. | A live problem from the JD's first line. It presupposes nothing about you. |
| B2 | "On-time performance at one site has dropped. Diagnose it." | CASE | [generic] | Clarify the metric definition and the time window first. Cut by shift, lane, dock and carrier; ask what changed. Speak in order: definition, cut, hypothesis, next data. | Drives the JD's on-time requirement. [generic]: no interviewer has said this case. |
| B3 | "Cost per shipment is up at one site this quarter. What do you look at first?" | CASE | [generic] | Ask how cost per shipment is calculated and whether volume, mix, labour hours, overtime or rework explains the change. Say which you would check first and why. | Drives the JD's cost requirement. [generic]. |
| B4 | "Two fixes each cut cost but slow on-time performance. How do you decide?" | CASE | [generic] | Name the trade-off, ask which target leads right now, state a decision rule, and say what you would test first. | The JD pairs the two metrics; this trade-off is a common case form. [generic]. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you build the daily on-time report for four sites?" | JD | [grounded] "solid Excel, never used Power BI" — your message | Describe the report's structure: the metric definition, the refresh, the four-site view, who receives it. Say what you would build in Excel first and what would move to Power BI later. Answer slot: if you have built a recurring report in Excel, say what it tracked and who used it; if not, say so and describe the build. | F5's requirement, the reporting the JD asks for. The Excel quote is the only thing your material carries. |
| C2 | "You haven't used Power BI. What have you done to change that, and by when?" | JD | [grounded] "never used Power BI" — your message | Plain acknowledgment: "I haven't used Power BI." Then a dated plan: a course, a practice dataset, a first dashboard. Plan only; no claim of prior use. | Rehearses the stated gap as an honest plan. |
| C3 | "Lean and Six Sigma are a plus here. Which tool have you used on the floor, and what did it change?" | JD | [grounded] "green belt certified" — your message | Name the certification: "I'm Green Belt certified." Then the tool you used and its result, if you applied one. Answer slot: if you applied Green Belt tools on the floor, name the tool and what it changed; if you have not applied the certification yet, say so and say which tool you would start with. | F6: no gap in the requirement, but a probe on applying it is likely. |
| C4 | "You ran the peak-season surge plan two years running. What did you change between the two years?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Describe the plan as you ran it, in your own words. Answer slot: if you changed something between years, say what and why; if you ran the same plan, say so. | Tests whether you owned the plan's design or ran someone else's. Keeps to what you stated. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already leads at four sites?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message; [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Pause and restate the question. Answer with what you did: the three supervisors and the 40% pick-path result, in those words. Concede the scope gap specifically. Hold through two follow-ups; concede only what is true. | Pressure test on F1, F2 and F3. |
| D2 | "That result. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold-then-concede: "I redesigned the pick path; here is my part." Then concede the team's part specifically, and do not fold on your own share. | The hold is on the quote, not on anything larger. |
| D3 | "Why this role now?" | JD | [generic] | Give one sentence of reason, then one piece of evidence from your shift work. If the reason is not yet clear to you, say so. | Your material gives no reason for the move, so the pack supplies none. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1 |
| Drive on-time performance and cost-per-shipment down | B2, B3, B4 |
| Lead a team of 12 supervisors | A1, A2 |
| Build reporting in Excel/Power BI | C1, C2, A5 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | C3 |

## Reverse questions

Each has a "why it lands." No interviewer profile exists, so none is tied to a career path.

1. "What would you need to see in the first 90 days to call this role on track?" — Turns the scope gap into a shared scorecard.
2. "Which of the four sites has the weakest on-time performance, and what is the main driver?" — Shows you are reading the job's real problem.
3. "How is cost per shipment calculated today, and who owns that number?" — The answer you need before B3.
4. "What reporting do the supervisors use day to day, and what is missing from it?" — Lets you show your Excel build honestly.
5. "What Lean or Six Sigma work is running now, and who sponsors it?" — Tests whether your Green Belt has a home here.

## Sources

- **Provided:** the JD text and your background message, both in this conversation.
- **Research tier: L0.** Two web searches were sent and refused (permission not granted). No fetch was sent.
  - "Atlas Freight regional logistics company values" — refused.
  - "Atlas Freight operations manager interview process" — refused.
- **Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have fed a values cheat sheet. None produced |
| 2. Atlas Freight interview process, operations | unavailable | Would have fixed loop structure and persona weights |
| 3. Atlas Freight strategy / recent news | unavailable | Would have grounded CO questions. The bank is CASE only, with [generic] labels |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer named |
| 5. Representative Operations Manager JD | skipped | The JD was supplied |

## Upgrade menu

- Round type and your relationship to the interviewer (Step 1, question a) → reweights the personas and reorders the banks
- Interviewer's name → public-footprint read and a tailored reverse question
- Search permission granted → reruns targets 1–3: values, interview process and strategy. CO questions move from [generic] to grounded
- A deeper research pass (up to 6 more searches and 2 fetches, several minutes) → strategy brief and role-family loop reports, if you want it once search is enabled
- Your leadership dates (Step 1, question d) → resolves the F4 gate and upgrades A2
- Recruiter's prep email → confirms the loop's round count and any deliverable they have announced
