# Ashgrove Credit Union: Member Experience Lead, interview prep pack

First version. Loop mode, three rounds on 4 December 2026.

- **Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
- **Round 1, recruiter:** 30 minutes
- **Round 2, Head of Member Services (your future manager):** 45 minutes, mostly behavioural
- **Round 3, panel of two branch managers:** 60 minutes, including a 20-minute complaint-escalation case. The panel scores the four values.
- **Interviewers by name:** not yet assigned. Persona weights come from round-type priors.
- **Built on:** the JD text, the recruiter's email, the values text you copied on 25 November 2026, the July 2026 strategy brief, and your background. No web research was run (see Sources).

---

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where a guidance cell says "say so plainly", that is an allowed answer and often the strongest one.

| Type | Meaning |
|---|---|
| VAL | Behavioural, tested against Ashgrove's published values |
| EXP | Your own work, tested for precise attribution |
| JD | The job's stated requirements, including its gaps |
| CO | Company and strategy knowledge, from the July 2026 brief |
| CASE | A live problem from the role, reasoned aloud |

---

## 4. Fit snapshot

Requirements are quoted from the JD text or the recruiter's email. Evidence is quoted from your own messages. Nothing in the Evidence column is a paraphrase.

None of the requirements is a gate in the suite's sense (a term or credential bar that you either meet or do not). Each is graded on fit and gap type like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material already reaches this in other terms. Bridge: "For six years I worked in retail banking, the last three as a branch supervisor." Whether that counts as customer operations is the interviewer's call. Say the years in your own words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows the log but does not show whether it was regulated. The word "formal" does not settle it. Answer slot: if the log ran to regulatory timescales or was reported to a regulator, say which and how you tracked them; if it did not, say so and say what governed it. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The adjacent work is one branch's log. Bridge: "For the branch, I handled the formal complaints log." Limit: the material shows one branch's log, not an end-to-end process. Make the transferable case at that scope only. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan and never as a past. Nothing is added to make the gap look smaller. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "built the monthly complaints spreadsheet the regional manager uses" (your message) | medium | [grounded] | presentation | Your material shows a monthly complaints spreadsheet. Bridge: "I built the monthly complaints spreadsheet the regional manager uses." Resolution times are not in that sentence, so that gap is an answer slot in the banks, not part of this bridge. |
| F6 | "comfortable with Excel reporting" (JD) | "built the monthly complaints spreadsheet the regional manager uses" (your message) | medium | [grounded] | none | The sentence reaches reporting in role-relevant terms. It does not name Excel, so do not name Excel unless you used it. Expect a probe on the spreadsheet itself. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never presented to anyone above regional level." Then how you would prepare for that audience, said as a plan. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on the escalation script" (your message) | medium | [grounded] | transferability | The adjacent work is training tellers, not coaching supervisors. Bridge: "I trained new tellers on the escalation script." Limit: coaching supervisors is not in your material. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | No sentence you wrote touches this. Answer slot: if you have worked with a digital or self-service team on a journey, say what you did and how; if you have not, say so and say what you would want to learn from them first. |

**Your material, as the pack reads it:** the strongest evidence is six years in retail banking, three of them as a branch supervisor, with a complaints log and a monthly spreadsheet behind you. The clearest gaps are the contact centre, presenting above regional level, and digital work. Those three are stated or silent in your material, and the pack does not fill them.

---

## 6. Grounding brief (strategy)

The July 2026 strategy brief you were sent is the source here. Its vocabulary:

- "member service"
- "digital channels"
- "hubs"
- "small-business lending"
- "app-only banks"

Its headline commitments:

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use these as vocabulary, not as facts to correct the interviewer on. The brief is dated July 2026. This pack is dated 25 November 2026, and no search has checked whether anything has changed since, so treat the commitments as "as of July" and say so if you mention them.

---

## 8. Persona table

Relationship priors set the starting weights. The recruiter's email sets the loop. Nothing in the inputs adjusts the weights further, because no interviewer is named.

| Round | Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|---|
| R1 recruiter | Conversational | Logistics questions in a friendly register, plus motivation | Top: 5 of 8. A recruiter screen prior is logistics and motivation. | Rehearse your 90-second arc. Treat small talk as scored. |
| R1 recruiter | Skeptic (light) | Knockout checks on the contact centre, regulated complaints and location | Low: 3 of 8. A screen checks knockouts before it checks depth. | State the plain acknowledgment once, then one bridge. Do not over-explain. |
| R2 Head of Member Services | Values/Behavioral | STAR-shaped stories tied to the values | Top: 5 of 8. The recruiter says this round is mostly behavioural. | Build each answer from a sentence you actually wrote, and say the result you saw. |
| R2 Head of Member Services | Skeptic | Cross-examines ownership across channels and presenting above regional | Mid: 2 of 8. A hiring manager prior: they are buying capability and checking gaps. | Deepest rehearsal on B5. Hold the scope you handled, then concede plainly. |
| R2 Head of Member Services | Case/Strategist | One live problem about a complaint pattern | Low: 1 of 8. Mostly behavioural, so the case is short. | Clarify before you structure. |
| R3 panel | Values/Behavioral | Scores each of the four values | Top: 4 of 9. The recruiter says the panel is the values round. | Map each value to a sentence you wrote, or to a scaffold with its honest branch. |
| R3 panel | Case/Strategist | The 20-minute escalation case (C1) | Top for the case block. The recruiter named it. | Clarify, then objective, then structure. Say the risks. |
| R3 panel | Peer Evaluator | Seam questions from branch managers | Mid: 2 of 9. Branch managers are peers, so the peer prior applies. | Reciprocity: what you bring their branches, not only what you need. |
| R3 panel | Data-driven Prober | How the spreadsheet counted things | Low: 1 of 9. Branch managers read reporting closely. | Say which counts were yours and which were set elsewhere. |

---

## 9. Question banks

Each round is a mini-pack with its own bank and reverse questions. Round 1 has 8 questions, round 2 has 8, and round 3 has 9. That is 25 across the loop.

### Round 1: recruiter screen (30 min)

#### Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in a couple of minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on the escalation script"; "built the monthly complaints spreadsheet the regional manager uses" | Ninety seconds, in this order: the six years and the three as supervisor, the complaints log, the teller training, the spreadsheet. Your own words, and no adjectives the sentences do not carry. Stop at the spreadsheet and let them ask. | The warm-up is scored. The arc uses F1, F3, F8 and F5 and nothing else. |
| A2 | "What drew you to Ashgrove, in your own words?" | JD | [generic] no sentence about you is claimed | One reason from the values text and one from your own work, in your words. Keep it short. Do not praise the brand in general. | Motivation is scored quietly in a screen. The pack makes no claim about you here. |
| A4 | "What are your salary expectations?" | JD | [generic] no figure was given | Logistics slot. If you have decided a figure, say it in your own words. If you have not, ask for the role's band before you answer. If asked what you earn now: "I'd rather focus on the range for this role." Nothing more. | The pack supplies no figure, range or floor. The decision is yours. |
| A5 | "When could you start, and what notice do you owe?" | JD | [generic] no figure was given | Logistics slot. Give your actual notice period. | Notice is a term the recruiter checks. Only your own answer fills it. |
| A7 | "Why are you looking to move now?" | EXP | [generic] no reason was given | Logistics slot. Your reason is not in your material, so the answer is yours. Give it in one sentence, forward-looking, with no criticism of your current employer. | Reason for leaving is a logistics topic. The pack does not guess it. |

#### Skeptic (light) (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A3 | "This role runs a contact centre, and you've never worked in one. What's your answer?" | JD | [grounded] "Never worked in a contact centre" | Start with the plain acknowledgment: "I've never worked in a contact centre." Then: if any of your complaint work touched calls or handoffs from a contact centre, say which; if none did, say so and say what you would learn first. Claim no contact-centre experience. | F4 is your largest stated gap, and a recruiter screen treats it as a knockout. The question's premise is your own negative, so it is answerable. |
| A6 | "Where would you work from, and what working pattern can you commit to?" | JD | [generic] no location or pattern was given | Logistics slot. Give the place and the days you can work, in your own words. | Location is a knockout check. The pack holds no location for you. |
| A8 | "What's your experience of regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what the log was and what you did with it, in your words. Answer slot: if the log ran to regulatory timescales or was reported to a regulator, say which and how you tracked them; if it did not, say so and say what governed it. | F2 is the discovery gap. The word "regulated" is the JD's, and the pack does not assume it applies to you. |

#### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "What does the panel score on values, and how is each score recorded?" | Shows you have read the process the recruiter described. |
| "What happens between this call and round two?" | Signals you are planning for the next round, not just this one. |
| "Who would I work with most day to day?" | Shows you are thinking about the manager role. |
| "How is the complaints team's work measured today?" | Points you at the reporting requirement early. |
| "What would help you most in round two?" | A preparation signal to the recruiter, who will remember it. |

### Round 2: Head of Member Services (45 min, mostly behavioural)

#### Values/Behavioral (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a complaint changed what you decided." | VAL | [grounded] "I handled the branch's formal complaints log"; the published value "we decide from the member's side of the counter" (values text, 25 November 2026) | Choose one complaint from the log that you handled. Say what the member asked for, what you decided, and what changed. Say only the outcome you saw. If no complaint changed your decision, say so, then give the nearest case from the log. | Members First, Always. F3 supplies the story source, and the value is a raising source. |
| B2 | "Tell me about a time you had to explain a decision to a member more than once." | VAL | [grounded] "trained new tellers on the escalation script" | Say what the member did not understand the first time and what you changed in the explanation. If you taught a teller to explain it, say what you taught and what they got wrong. Do not claim you wrote the script. If no such case comes to mind, say so and give the nearest one. | Plain Words. F8 is the nearest sentence. |
| B3 | "Tell me about a problem you found that you stayed with until it was fixed." | VAL | [grounded] "built the monthly complaints spreadsheet the regional manager uses" | Answer slot: if the spreadsheet came from a problem you found and kept hold of, say what the problem was and how you knew it was solved. If it was asked for, say so, then say what problem you found and kept, if any. If none, say so. | Own the Fix. F5 is the nearest sentence, and "found" and "kept" are not in it. |
| B4 | "When did a monthly figure hide what members were going through?" | VAL | [grounded] "built the monthly complaints spreadsheet the regional manager uses" | If a figure in your report looked fine while members were unhappy, say what it was and what you did. If you never saw that happen, say so and say what the figure did not show. | Neighbours, Not Numbers. Open prompt, with the value as its raising source. |
| B8 | "Tell me about a time you coached someone on an escalation." | JD | [grounded] "trained new tellers on the escalation script" | Teller training is the nearest sentence. Say what you taught and what the teller did next. Answer slot: if you coached a supervisor or senior colleague on an escalation, say what you did; if you did not, say so. Do not stretch training into supervisor coaching. | Covers F8, the JD's "coach branch supervisors on escalations". |

#### Skeptic (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "Your experience is in branches. This job owns complaints across branches and the contact centre. Why should I believe you can own that?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **Highest-return prep in this pack.** Start with the plain acknowledgment: "I've never worked in a contact centre." Then the branch scope, as far as your log went: "For the branch, I handled the formal complaints log." Then the handoff: if any work of yours reached a contact centre from the branch, say which; if none did, say so. Then what you would do in your first ninety days, as a plan. Hold: do not widen the log into a process. Follow-up one: stay on what you handled. Follow-up two: concede plainly, "I haven't worked on that side, and I'd want to learn it from the team before I claim any of it." Never fold on the branch scope. | F3 and F4 are the largest gaps and the JD's headline line, so this question will come in some form. It gets the most follow-up levels in the pack. |
| B6 | "You've never presented above regional level. Why would senior leaders listen to you?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you have presented the monthly figures to your regional manager, say how; if not, say how the figures reached them. Then how you would prepare for a senior audience, as a plan. Hold: claim no senior-presentation experience. | F7 is a stated absence. The answer is the plain acknowledgment plus a plan. |

#### Case/Strategist (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "Complaints about one branch rose by a third in a month. Walk me through how you'd find out why." | CASE | [generic] no sentence about you is claimed | Clarify whether the rise is one cause or several, and what counts as a complaint. Objective: the members and the branch. Segment by reason, channel and week. Approach: check the log against the spreadsheet first. Name the measures and the risks. Say the approach aloud. Do not claim you have done this before. | The case tests reasoning, not a tool. F5 is the nearest tool, and the pack does not claim it for this case. |

#### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "Across branches and the contact centre, where do escalations stall today?" | Points at the JD's ownership line and invites a diagnosis. |
| "How would you like the monthly complaints report to change in the first six months?" | Shows you have read the reporting requirement closely. |
| "What would a branch supervisor need from this role that they don't get now?" | Signals you are thinking about the coaching part of the job. |
| "How is the shift to digital channels changing which complaints reach a person?" | Ties the question to the strategy brief without quoting it back. |
| "What would make you say at twelve months that this role has done its job?" | Asks for the manager's success criteria. |

### Round 3: panel of two branch managers (60 min, values scored)

#### Values/Behavioral and Case/Strategist (the escalation case, C1, takes 20 of the 60 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Read the case. You have twenty minutes. What do you do next, and why?" | CASE | [generic] no sentence about you is claimed | **The case.** Do not assume facts about the redress route. Use the case text below. | See the case brief below. |

**Case brief (read to the candidate):** A member complained that a monthly account fee was charged after they had asked for it to be stopped. Your branch refunded the fee. The member phoned the contact centre twice and says they were brushed off. They now want the complaint sent to the external redress body. The branch supervisor says the refund settles it. The contact centre says the file is with the branch. The complaint is ten days old, and two other members have complained about the same fee this month.

**Guidance for C1 (say it aloud, in this order):**

1. **Clarify:** what the member is asking for now; whether the fee problem is one account or a pattern; what the redress route and its timescales are for this complaint. Check them. Do not assume them.
2. **Objective:** the member's outcome, a complaint that stops bouncing between teams, and a check for a pattern.
3. **Today:** name one owner for the file, so it stops bouncing (Own the Fix).
4. **The redress route:** do not argue against it. Tell the member plainly how it works and what happens next (Plain Words, Members First).
5. **The other two complaints:** check them today for the same fee cause (Neighbours, Not Numbers: the cause, not only this member).
6. **The supervisor:** coach the supervisor on the decision, rather than only overruling it.
7. **Risks:** the refund alone may not close it. You may be wrong about the fee's cause. Check before you promise anything.
8. **Premise to challenge:** "the refund settles it."

Provenance for C1 is [generic]. The guidance makes no claim about your past or about Ashgrove's fee or redress process. The case is the pack's own practice case, and it is not a fact about this employer.

#### Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C2 | "Tell me about a time your written wording was misread." | VAL | [grounded] "trained new tellers on the escalation script" | If you wrote or taught wording that tellers or members misread, say what was misread and what you changed. If none comes to mind, say so, then say how you taught the escalation script so it could be understood. | Plain Words. Open prompt; F8 is the nearest sentence. |
| C5 | "Tell me about a time you put a member ahead of a target." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Scaffold: pick a decision as a branch supervisor where a member's need and a target pulled apart. If no target-based decision comes to mind, say so, then give the nearest decision you made for a member, in your words. Supply no target and no number. | Members First, Always. F1 holds your only supervisor sentence, so this is a scaffold. |
| C8 | "Tell me about a complaint trend you kept hold of until it was solved." | VAL | [grounded] "built the monthly complaints spreadsheet the regional manager uses" | Scaffold: pick a trend a report surfaced that you kept hold of after it was passed on. If the report was requested and the trend was someone else's, say so and say what you did with it. If none, say so plainly. | Own the Fix. Covers the value B3 does not cover for the panel. |
| C6 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. A town loses its branch. What happens to its complaints?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, July 2026) | Do not argue for or against the plan. Say what you would protect for members in that town: a named route for complaints, someone who knows the town, and what members are told, in plain words. Answer slot: if you have handled a change that affected a branch's members, say what you did; if you have not, say so and say what you would do first. Do not mention your own branch. | Neighbours, Not Numbers, in the strategy's own terms. The hub plan is the brief's, so the question presupposes only what the brief states. |

#### Peer Evaluator and Data-driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "We run the branches your team's complaints come from. What would you need from us on escalations?" | JD | [generic] no sentence about you is claimed | Name one thing you would need: a single contact per escalation, or a clear rule for handovers. Then name what you would bring their branches: the monthly report you know how to build, if you would offer it, in your words. | Peer seam question. Reciprocity: what you bring, not only what you need. |
| C4 | "Walk me through how the monthly complaints spreadsheet counted a complaint." | EXP | [grounded] "built the monthly complaints spreadsheet the regional manager uses" | Answer slot: if you chose what counted as a complaint, or how it was counted or timed, say how, in your words; if it was set elsewhere, or you do not know the rule, say so and say what you would check first. If you know an assumption behind the counts, name it before they ask. If you do not, say so. | The premise is the spreadsheet you built, which F5 quotes. The counting method is not quoted, so it is a slot. This also covers resolution times, if the spreadsheet tracked them. |
| C9 | "What's the hardest part of a complaint that moves from a branch to the contact centre?" | JD | [generic] no sentence about you is claimed | Think from the member's side: the handover, what the member has to repeat, who answers. Name what you do not know: the contact centre's own steps. Claim no contact-centre experience. | Tests reasoning at the seam, which is where F4 bites. |

#### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "Where do branch and contact-centre complaints hand over badly right now?" | A seam question, pitched at the level of the branch managers' own work. |
| "How are branch teams being involved in planning the move to five hubs?" | Shows you care how the change lands in each town, which the values text asks for. |
| "What does a good escalation look like to you?" | Asks the values question in the panel's own words. |
| "When a complaint came up in your branch, who made the final call?" | Invites a practical answer about decision rights, which matters in a branch. |
| "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel. It turns the panel into a conversation. |

### Requirement coverage

Each JD requirement maps to the questions that cover it. Logistics items come from the recruiter screen and are not JD requirements.

| Requirement | Covered by |
|---|---|
| Own the member complaints process across branches and the contact centre | B5, A3, C9 (F3, F4) |
| Report monthly on complaint volumes and resolution times | C4, B7 (F5) |
| Coach branch supervisors on escalations | B8, C1 (F8) |
| Work with digital teams on self-service journeys | C7 (F9). One question only. |
| 4+ years in financial-services customer operations | A1 (F1) |
| Experience handling regulated complaints | A8 (F2) |
| Confident presenting to senior leaders | B6 (F7) |
| Comfortable with Excel reporting | A1, C4 (F6) |
| Four values | B1 to B4, C2, C5, C6, C8, C1 |
| Logistics (pay, notice, location, reason for leaving) | A4, A5, A6, A7 |

---

## 10. Values cheat sheet

The panel scores the four values, as the recruiter's email says. The values text is what you copied on 25 November 2026. Most of your evidence is thin for these values, so most rows are scaffolds. That is a finding, not a gap to fill.

| Value (official name) | Working meaning (paraphrased) | Mapped story: fit row and quote, or scaffold with its honest branch |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3: "I handled the branch's formal complaints log." Pick one decision that the member's side changed. If none comes to mind, say so and give the nearest decision from the log. Banks B1, C5. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8: "trained new tellers on the escalation script." Pick a time wording was misread and what you changed. If none, say so, and say how you taught the script. Banks B2, C2. |
| Neighbours, Not Numbers | Every branch is part of its town | F5: "built the monthly complaints spreadsheet the regional manager uses." Pick a figure that hid what a town was going through. If none, say what the figure did not show. Banks B4, C6. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5 again. Pick a problem you found and kept hold of until it was solved. If the report was requested, say so. If none, say so plainly. Banks B3, C8, C1. |

---

## 13. Prohibited list

These are claims the pack will not coach. Each entry names its basis, because the basis decides the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F3. Your sentence covers one branch's log. | "I handled the branch's formal complaints log." The pack's own observation: the material shows one branch's log, not the process end to end. |
| "Ran complaints across the contact centre" | Stated absence, F4 | "I've never worked in a contact centre." No slot on contact-centre work done. |
| "Presented to senior leaders" | Stated absence, F7 | "I've never presented to anyone above regional level." Nothing else. |
| "The spreadsheet drove branch or regional decisions" | Inflated form of F5. "The regional manager uses" is widened to "decided". | "I built the monthly complaints spreadsheet the regional manager uses." |
| "Wrote or set the escalation script" | Inflated form of F8. Authorship is not in your material. | "I trained new tellers on the escalation script." |
| "Coached branch supervisors on escalations" | Inflated form of F8. Your sentence covers tellers. | "I trained new tellers on the escalation script." The coaching of supervisors is an answer slot only, in B8. |
| "Experience with regulated complaints" | Inflated form of F2. "Formal" is not shown to mean "regulated". | "I handled the branch's formal complaints log." Limit, in analysis: the material does not show whether the log was regulated. |

---

## 14. Sources

**Provided documents, read in full:**

1. The JD text, as you pasted it.
2. The recruiter's email: three rounds on 4 December 2026, with the round structure.
3. The values text you copied from the Ashgrove values page on 25 November 2026.
4. The July 2026 strategy brief, as the recruiter sent it.
5. Your background, in your messages.

**Searches and fetches sent:** none. Each research target below is accounted for against the inputs.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. Nothing has been spent, and nothing was refused or errored.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet (section 10) and the four named values. The inputs decide it, so no search was needed. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds, their lengths and the values round. The loop structure and persona weights come from it. |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief you were sent fixes the current commitments (grounding brief, section 6). Recent news is not established. See the upgrade menu. |
| 4. Interviewer names | n/a | No interviewer is named, so there is no query to form. The interviewer read is absent. See the upgrade menu. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 15. Upgrade menu

- Round 2 and panel names, from the invite or the calendar → personas per interviewer, and a tailored reverse question for each round.
- Your decision on one figure for A4, and the notice period in A5 → quoted into the fit snapshot in your own words. Until then they stay as logistics slots.
- A complaint you handled that went beyond the branch → a grounded beat for B5 and C1, which at present are answer slots.
- Whether the formal complaints log ran to regulatory timescales → F2 moves from discovery to a grounded row.
- Whether the monthly spreadsheet tracked resolution times, and how → F5 gets its resolution-time sentence, and C4 gets a grounded answer.
- Any digital or self-service work you have done → F9 gets a grounded row, and C7's slot gets its honest first branch.
- Deep research, once (L2): recent Ashgrove news, the strategy brief's status since July 2026, and the public footprint of the two branch managers if named. Cost: up to six further searches and two fetches. Run only if you say so.
- A `tuesday-dossier.md` recording the gaps this prep exposed would let a later session start from them.
