# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, mobile game studio of about 350 people
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Relationship:** assumed hiring manager. Not confirmed; see the round-type question in the message.
- **Format:** 60 minutes, Friday
- **Research tier:** L0. Web search was not permitted in this session, so nothing about Saltmarsh's values, loop, strategy or Tobias's public footprint is in this pack. Section 10 (values) and the interviewer read are dropped for that reason.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: a deep-dive into your own experience
- **JD**: the listed job and its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Say things in your own words. The only claims about your past are the quoted lines in the fit snapshot, the plain acknowledgments in the gap rows, and the answer slots, which tell you to say what you did or did not do.

## Prep triage

Prep time was not stated, so this section is dropped.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar, not live events across two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned for a second title, say how. If you have not, say so and say how you would plan across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material shows one team, QA, using a checklist you wrote. It does not show coordination across the four named teams. Answer slot: describe how you got a design, art, engineering or community team to commit to a date. If you have no such example, say so and say what you would do first. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not the same as owning the review or choosing the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: which of those numbers did you define or choose, and which were set by others? If you did not set them, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement in role terms: you wrote it, and QA still uses it. Words: "I wrote the release checklist our QA team still uses." A probe on who ran sign-off for each release is likely; the material does not show it, so answer only from what you did. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | The years and the role are yours. The quote does not say the game was live-service, and your title was associate producer, not producer. Words: "For four years I was an associate producer at a puzzle-game studio." Answer slot: was the puzzle game one that ran ongoing content updates? If yes, say so in those words. If not, say what it was. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | This is your strongest row. Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented the numbers. Words: "I presented the monthly retention numbers to the studio head." Expect a probe on how retention was counted. Answer slot: if you do not know the definition, say so and say where you would check it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Only one written artifact is shown, and it is a checklist. Answer slot: if you have written something for a non-producer audience, such as a post-event summary, say what it was and who read it. If you have not, say so. |

Gaps the JD does not list, sourced from your message:

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| G1 | People management. Not listed in the JD; a likely probe for a role that coordinates four teams. [generic] | "Never led a team" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't led a team." Then how you would coordinate four teams without managing them, as a plan and never as a past. Do not claim leadership you have not done. |
| G2 | In-app purchase or monetization experience. Not listed in the JD; a likely probe for a mobile studio. [generic] | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the spend and conversion metrics, as a plan. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and the pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led teams" or "I managed people" | G1, a negative you stated | "I haven't led a team." |
| "I've worked on monetization" or "I know in-app purchase KPIs" | G2, a negative you stated | "I haven't worked on a game with in-app purchases." |
| "I owned the retention numbers" or "I set the KPIs" | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| "I ran live events across two titles" | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| "I ran the post-event review" or "I ran QA sign-off" | Not in any quote | "I wrote the release checklist our QA team still uses." |
| "I was a live-service producer" | The quote does not say live-service, and F5's title is associate producer | "4 years as an associate producer at a puzzle-game studio." |

## Persona weights

| Persona | Weight | Reasoning |
|---|---|---|
| Case/Strategist | 5 | Relationship prior for a hiring manager. The JD is a list of live-ops responsibilities, so expect live planning problems. |
| Skeptic | 4 | The prior for a hiring manager who is buying capability. Your gaps (G1, G2, F2) are the material for it. |
| Data-Driven Prober | 3 | Your retention claim (F7) and KPI ownership (F3) will be checked. |
| Peer Evaluator | 3 | The role coordinates design, art, engineering, community and QA, so the interviewer will probe the seams. |
| Pressure | 2 | Possible in a 60-minute session, but there is no profile signal to raise it. |
| Conversational | 2 | The opener is scored too. |

Interviewer signals: none. No public footprint was established, so no adjustments were made. Values-style round: not detected, since no loop source was read.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live plan or a diagnosis on a live title | High | Clarify, then structure, then answer. Name the metric you would check first. |
| Skeptic | "You've never led a team" and "never worked on in-app purchases" | High | Say the plain negative once, then bridge with what you did do, and a plan for the gap. |
| Data-Driven Prober | "How was that retention number counted?" | Medium to high | Say what you know about the definition, name the weakest assumption, and say where you would check. |
| Peer Evaluator | Seams between your calendar and design, art, engineering or community | Medium | Propose principles for the seam. Do not claim a process you have not run. |
| Pressure | "How much of that result was actually you?" | Medium | Hold "I presented it," and concede specifically what you did not produce. |
| Conversational | "Walk me through the journey" | High | Have a 90-second arc ready. |

## Question banks

Types: CASE, EXP, JD. Provenance is the label, then the quoted sentences the guidance rests on.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A retention metric on one of your titles drops 15% in the week after a content drop. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what changed: the drop, the cohort, the date. Fix the retention window. Split by cohort, platform and content. Separate the drop's effect from anything external. Decide what to tell the team and when. | Tests the retention diagnosis the JD implies. Labelled generic because it makes no claim about your past. |
| A2 | "Plan the next six weeks of live events for two titles, where one has a QA deadline." | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | Clarify capacity in design, art, engineering and QA, and the dependencies. Name the bottleneck. Anchor dates on the QA window before each drop. Answer slot: you have run one title's calendar (F1). Say how you would handle two, and say that you have not yet done it. | Directly raised by the JD's first line. The second title is the gap in F1. |
| A3 | "What do you need from design, art, engineering and community before you commit a date on a live update?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | List the inputs each team gives you, who signs off, and the lead time you need. Make no claim about a past update. | The JD's coordination line, asked as a process question. Covers F2. |
| A4 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell it in the quote's beats: weekly cadence, your main title, two years. Pick one drop and walk it from start to ship. Answer slot: which decisions on the calendar were yours, and which were the lead's? Say it plainly. | Your strongest evidence (F6). The story must not grow beyond the quote's beats. |
| A5 | "What would you do in your first 30 days to learn two titles you have not worked on?" | JD | [generic] | Read the live dashboards and the last six post-event reviews. Meet the leads on each title. Say which metric you would learn first. | A common day-one question for an external hire. Labelled generic because it makes no claim about your past. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" | Name the gap plainly: "I haven't led a team." Then say what you would do in the first two weeks to learn how the four teams plan. | An open version of the people-management gap. |
| B2 | "You haven't led a team. How would you get four teams to commit to dates when you don't manage any of them?" | JD | [grounded] "Never led a team" and "Wrote the release checklist our QA team still uses." | **Highest-ROI prep in this pack.** Hold: "I haven't led a team." Your evidence is the checklist QA still uses. Describe that without adding to it. Concede specifically: you have not run cross-team date commitments with design, art, engineering or community at this scale. Plan: which decisions you would push to each lead, and how you would set the calendar. Hold through two follow-ups by returning to the checklist and the plan. | This objection comes from the JD's coordination line and the gap in G1, so it will be asked in some form. A held, non-defensive answer changes the interview. |
| B3 | "You've never worked on a game with in-app purchases. Why would you be the right person for the KPIs here?" | JD | [grounded] "I haven't worked on a game with in-app purchases." | Acknowledge it plainly. Then say what you did do with retention, which is F7's quote. Then the plan to learn the spend and conversion metrics. Do not claim IAP knowledge. | G2 is the second likely objection. |
| B4 | "The JD asks for three years producing live-service games. Your title was associate producer. Is that the same thing?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Give the title and the game type in those words. Then say what live content work you did (the calendar). If the puzzle game was not live-service in your sense, say what it was. Answer slot: was the puzzle game one with ongoing content updates? | F5's gap. The honest answer depends on a fact the material does not show. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say the definition only if you know it: window, cohort, base. If you do not know, say so and say where you would check. Name the assumption you would defend least. Answer slot: who defined the metric? | The defend-the-number probe for F7. |
| C2 | "How were the monthly retention numbers chosen for the studio-head review?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say who chose the numbers. If you chose them, say how. If others did, say so without blame. | Tests F3's KPI-ownership gap. The question presupposes a choice, so the answer must allow that none was yours. |
| C3 | "A content drop lifted day-7 retention but cut day-1 in the same week. What would you report?" | CASE | [generic] | Report both numbers. Caveat the cohort mix. Name the weakest assumption. Propose the follow-up cut that would settle it. | A standard retention trade-off. Generic because it makes no claim about your past. |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our design and engineering leads see live updates as a scope risk. Where's the seam between the calendar and their calls?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Propose a principle: you own the date and the ask, the leads own the solution. Do not claim a process you have not run. | Peer seam. The principle is the honest answer. |
| D2 | "The community team runs player feedback, and you run the calendar. Who decides when a drop is delayed for feedback?" | JD | [grounded] "community teams" as part of "coordinate design, art, engineering and community teams on each update" | Propose a decision rule and say what you would need from community before the review. | Tests coordination with community, which F2 does not cover. |
| D3 | "What do you need from QA before a drop you didn't plan for?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Name the checklist and what it covers. Say how you would handle a late change against it. Make no claim beyond the checklist. | Covers the QA requirement (F4) in the peer register. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" | Hold the position: "I haven't led a team." Then the work you can point to, which is the calendar you ran. Hold through two follow-ups. Concede specifically that you cannot claim people management. | Holds G1 under time pressure. |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | "I presented it." Say which part of the analysis you did, if any. If you did none, say so. | The attribution probe for F7. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc: the puzzle studio, the associate producer role, the calendar, the release checklist, the retention readout. Then why Saltmarsh's mobile live-ops. | A casual opener is still scored. |
| F-2 | "What are you playing at the moment, and is there a live update you thought was well done?" | CO | [generic] | Name a real game and one update you have seen. Say what you saw. If you have not seen one, say so. | Casual, but it is the JD's live-ops subject. Generic because the answer must come from your own play. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A2, A5, F1 (answer slot) |
| Coordinate design, art, engineering and community | A3, B2, D1, D2 |
| Own the post-event review and the KPIs | C1, C2, E2 |
| Manage the release checklist with QA | D3, B2 |
| 3+ years producing live-service | B4 |
| Experience running a content calendar | A4 |
| Comfortable with player-retention metrics | C1, C3 |
| Clear written communication | none, and why: no question asks for a writing sample. F8's answer slot covers it if the interviewer raises it. |

## Values / principles cheat sheet

Dropped. Saltmarsh's published values were not established (search was not permitted), and no values-style round was detected.

## Reverse questions

No interviewer profile was established, so none of these is tied to Tobias's career path. They are role-generic.

1. "What does a good first 90 days look like, and which title would I own first?" Why it lands: it shows you have read the two-title scope.
2. "How are post-event reviews run today: who attends, and which KPIs do they report?" Why it lands: the JD gives you ownership of these, so you are asking about the current state.
3. "How does the QA release checklist get updated when a live update goes out?" Why it lands: it shows you know the checklist is a living document, and it tests whether the process you helped write is still in use.
4. "How do design, art, engineering and community get their asks into the calendar today?" Why it lands: it asks about the operating model behind the coordination line.
5. "What would make you say this hire worked out at six months?" Why it lands: it signals that you think about outcomes, and it gives you the success criteria.
6. "What is the biggest retention problem on the two titles right now?" Why it lands: it shows you think in their metrics before you have been told them.

## Delivery coaching

Dropped. No working-style assessment was provided.

## Graded deliverables

Dropped. None was declared.

## Grounding brief

Dropped. The deep tier was not run and no strategy brief was provided.

## Prohibited claims

See the table above, under "Prohibited claims".

## Sources

- **Provided:** the JD text and your message (background).
- **Searches:** L1 targets 1 to 4 were attempted. The web search call was refused because the session has not granted search permission. Nothing was returned for any of them, so nothing from them is used.
- **Dossier:** none present.
- **Target accounting**
  - Research tier: L0
  - 1. Saltmarsh values: unavailable (search refused)
  - 2. Interview loop: unavailable (search refused)
  - 3. Strategy and news sweep: unavailable (search refused)
  - 4. Tobias Wrenfield public footprint: unavailable (search refused)
  - 5. Representative JD: skipped (JD supplied)
  - 6 to 9 (deep research): skipped (not consented)

## Upgrade menu

- Saltmarsh's careers or values page, pasted → the values cheat sheet, with stories mapped to your quoted sentences, and VAL questions
- Tobias's public talks, posts or profile, pasted → persona weights from his footprint, and a reverse question tied to his career path
- The recruiter's note on the round → confirms the round type, and covers any take-home or presentation
- Whether the puzzle game had ongoing content updates → settles the answer slot in F5 and B4
- A piece of writing you are proud of, described → turns F8 from a slot into a story
- A `tuesday-dossier.md` file, if you have one → verified evidence and prohibited-claim guardrails
