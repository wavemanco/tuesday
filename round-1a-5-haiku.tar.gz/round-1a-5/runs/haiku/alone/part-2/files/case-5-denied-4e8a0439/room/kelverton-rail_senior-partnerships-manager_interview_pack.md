# Kelverton Rail: Senior Partnerships Manager, second round (panel)

Panel: **Deepa** (VP Partnerships, future manager) and **Ross** (Commercial Director). 60 minutes: a 15-minute POV (no slides), then Q&A in which Ross will push on commercials. First build, so no changelog.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **EXP**: what you actually did, and whether the figures survive scrutiny
- **JD**: whether you can do the listed job, gaps included
- **CO**: company and strategy knowledge (none in this pack; see Sources)
- **CASE**: a live problem, structured out loud
- **VAL**: behaviour against published values (none in this pack; see Section 10)

The guidance is scaffolding, not a script. Say it in your own words.

## Prep triage (about 4 hours)

1. **75 min: build the POV** (Section 5). Choose one thesis, its concession and the operator outcome it ends on. Talk it through to a 15-minute timer, twice.
2. **60 min: commercials.** P1 to P5 and R2 to R3, out loud, timed. The £4M figure is where Ross will spend the most time.
3. **45 min: the rail gap.** S1, S2 and R1. This is the highest-return rehearsal in the pack: the most predictable objection to you is that you have never sold into rail. Say the plain acknowledgment in one breath, then the plan.
4. **40 min: Deepa's questions.** C1 to C4, S3 and S4.
5. **20 min: reverse questions.** Say all five out loud and keep two.

Everything else is insurance.

## The fit snapshot

No job description was supplied. Requirements come from the recruiter's words as you quoted them (`[grounded]`), or from role-family prose with no source (`[generic]`, no answer slot). The pack has no gate rows: nothing in the material is a term tied to a legal or credential bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter, as quoted by you) | "9 years in partnerships" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partnership growth at a payments company, not operator partnerships. Keep the bridge at the quote's scope: "For four years I ran the channel." Answer slot: if you ever planned something for an operator's benefit, say what and how; if you did not, say the nearest partner-side thing you did. |
| F2 | "what it means for the operators themselves" (recruiter, as quoted by you) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | none | The quote reaches the operator world in role terms. Expect a probe on whether you knew it from the planning side or the selling side; say which, in your words. |
| F3 | "Ross will push on commercials" (recruiter, as quoted by you) | "never carried a direct quota, only influenced revenue" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Influenced revenue is adjacent to commercial accountability, not the same thing. Words: "I never carried a direct quota. I carried influenced revenue." Answer slot: which commercial accountability you did carry, if any. |
| F4 | Selling into train operating companies (role-family prose, no JD supplied) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence, so the words are yours: "I've never sold into rail specifically." Then how you would learn it, as a plan and never as a past. Nothing added to make the gap smaller. |

Confidence grades your evidence. Provenance grades what this pack wrote. The rail row is `capability` because you stated the absence yourself.

## Graded deliverable: the 15-minute POV

Recruiter's own words, as you quoted them: "where you'd take our operator partnerships over the next 18 months", "Please land on what it means for the operators themselves", "no slides needed".

**Grounded facts to build on:** F2 ("5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)") and F1 ("took it from 6 partners to 40, roughly £4M of influenced revenue"). Nothing else about operators is in your material, so do not speak as if it is.

**Thesis options (pick one or two; each has a concession):**

- **T1. Measure operator partnerships by what the operator can see, not by partner count.** Concession: I do not yet know which operator-side measures the company already uses; I would find out before proposing a replacement. Consensus answer: more integrations and co-selling. Differentiation: the partner count is the first number I would drop, and the reason is that the operator cannot feel it.
- **T2. Fewer, deeper operator relationships, planned around the timetable cycle rather than the sales cycle.** Concession: rail procurement and contract cycles may cap how fast this moves, and I have not sold into them.
- **Anti-pick (say it only if you mean it):** I would not open with a pipeline or partner-growth target, because it tells the operator nothing about its own service.

**Close:** end on one operator outcome you would measure in month 18, in the operator's own terms. Do not end on a revenue figure.

## Persona table

| Persona | How it shows up on this panel | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (Ross) | Asks how the £4M was counted, and what you would defend least | High. The recruiter wrote that Ross will push on commercials, and F1 and F3 give him a figure to test | Know what you can and cannot say about each number; name the weakest assumption before he does; say plainly when you do not know |
| Pressure (Ross) | Time-boxed challenge on quota and on how much was yours | Medium. Commercial-director panels often add this; F3 is the exposed row | Pause, restate, hold through two follow-ups, concede specifically |
| Case / Strategist (Deepa) | A live problem on operator partnerships in the next 18 months | High. Deepa is the future manager and the POV is her brief | Clarify, then objective, segmentation, approach, metrics, risks, out loud |
| Skeptic (Deepa) | Rail gap, motivation, and day-one weakness | High. F4 is the largest gap, and a future manager tests it | Plain acknowledgment, then a plan; no claim about rail deals |
| Conversational (Deepa) | Opening "walk us through" and a casual operator question | Medium. Casual questions are still scored | Pre-timed 90-second arc; treat the casual question as scored |

Weights for this panel: Prober 5 questions, Case 4, Skeptic 4, Pressure 3, Conversational 2. This is a shown judgment from the relationship priors (hiring manager plus commercial director), not a measured score.

## Question banks

### Data-Driven Prober (Ross): weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was the £4M counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say, in your own words, how the influenced figure was counted and which part you could attribute to your own work. If you do not know the counting method, say so plainly. | F3 and F1 carry the figure; a figure raises defend-the-number slots and nothing else |
| P2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name the weakest assumption you know of, before he does. If you cannot name one, say that. | The weakest-assumption move converts a gotcha into a credibility point |
| P3 | "What counted as a partner in your 40?" | EXP | [grounded] "took it from 6 partners to 40" | Give the definition you used, in your words. If you are not sure the 40 used one definition throughout, say so. | A count is exposed to its own definition; this probe is likely from a prober |
| P4 | "You had no direct quota. What number did you own?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Answer slot: if you owned a number, say which and how it was measured; if you did not, say so and describe what you did carry. Words: "I never carried a direct quota." | F3 is the exposed row; the premise is his, and the second branch is allowed |
| P5 | "Which of the £4M would have happened without the channel?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: give your honest view of what the channel caused and what it did not, and say how you would tell the difference. | Tests whether "influenced" was spun into "driven"; the honest answer is a limit |

### Case / Strategist (Deepa): weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter, as quoted) | Clarify first: which operators, which outcomes, what is already in place. Then objective, two segments, your approach, the metric, one risk. This is the POV's first question. | Her brief is the POV; this is the same question in its live form |
| C2 | "An operator tells you the platform works but its planning cycles still run late. What do you do?" | CASE | [generic] | Structure it: separate platform fit from process, ask who owns the cycle, propose one test you would run first. Make no claim about a past operator. | A live problem from the role, with no claim about your past |
| C3 | "Which two operator outcomes would you measure, and what would you stop measuring?" | CASE | [grounded] "what it means for the operators themselves" (recruiter, as quoted) | Name two outcomes an operator would recognise and one partner metric you would drop. Give reasons, not a list. | The recruiter asked for this; the answer is judgment, not a fact about the company |
| C4 | "Where would your operator-side view change what you would recommend?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say one planning decision you would change in light of how operators plan. Say that your work was bus and light rail, and that mainline rail is adjacent to it, not the same. Answer slot: if no such decision comes to mind, say so and give the nearest thing your work carried. | F2 is the strongest material you have; the scope limit protects you from a rail-specific probe |

### Skeptic (Deepa): weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | The highest-return rehearsal in the pack. Say: "I've never sold into rail specifically." Then your plan to learn the buying process of train operating companies, as a plan. Hold the plan; do not claim a past. | F4 is the largest gap, and this is its most likely form |
| S2 | "You've never sold into rail. Why would an operator talk to you?" | Skeptic | [grounded] "Never sold into rail specifically" | Hold the gap plainly, then the one thing you do bring, in the quote's scope: operator-side planning work. Hold through two follow-ups; do not add a rail credential. | Calibrated candour over bluffing a competency she owns |
| S3 | "Why leave a payments company where the channel grew from 6 partners to 40?" | Skeptic | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Give your real reason in your own words. Answer slot: if the reason is the sector, say what about rail draws you that payments did not. | A motivation probe; it tests consistency, and F1 is what she will weigh it against |
| S4 | "Your rail background is planning, not selling. Which of those is this job?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede the direction plainly. Then name where planning and selling overlap in your own work, and only as far as you did them. | Makes the gap explicit so she does not have to |

### Pressure (Ross): weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" | Pause. Restate the question. Say: "I've never sold into rail specifically." Hold the operator-side view for two follow-ups; concede the selling gap specifically, not vaguely. | Stress test of composure on the largest gap |
| R2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "running the ISV channel"; "roughly £4M of influenced revenue" | Hold: "I ran the ISV channel." Then concede what was influenced rather than driven, and say which part you can defend. Do not fold on the channel itself. | Hold-then-concede on the most exposed figure |
| R3 | "Walk me through a deal you were accountable for." | JD | [grounded] "never carried a direct quota, only influenced revenue" | Answer slot: if a deal was yours to close, walk through it; if you only influenced deals, say so and walk through the nearest one. Words: "I never carried a direct quota." | Commercial probe; the honest branch is the answer |

### Conversational (Deepa): weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk us through the journey." | JD | [grounded] "9 years in partnerships"; "5 years in transport consulting" | A 90-second arc in your order: nine years of partnerships, then the consulting work, then why this. Do not add to either quote. | Opening question, scored for economy |
| V2 | "What is the one thing about operators you would want us to know?" | VAL-style, unscored | [grounded] "so I know the operator world from the other side" | Answer slot: if your planning work showed one thing about how operators decide, say it; if it did not, say what you learned about how operators plan. | Casual, and a hot topic; treat it as scored |

**Coverage line.** Operator POV: C1, C3, Section 5. Operator outcomes: C3, V2. Commercials: P1 to P5, R2, R3. Rail selling: S1, S2, R1. Any other requirement from a JD: none, because no JD was supplied.

## Reverse questions

1. "What would success for operator partnerships look like at month 18, in the operator's terms?" Why it lands: it lets you close the POV on Deepa's own measure.
2. "How are operator partnerships measured commercially today, and by whom?" Why it lands: it gives Ross a question he can answer, and shows you care about his numbers.
3. "Which operator relationship would you least like to lose, and why?" Why it lands: it shows you are thinking about the operators, not only the pipeline.
4. "What did the last person in this role do that you would want repeated?" Why it lands: it asks Deepa for the job, not the company.
5. "What is the most common reason an operator says no to a scheduling platform?" Why it lands: it shows the rail gap is one you are working on, asked as a question.

No reverse question is tied to an interviewer's own career path: no public footprint was checked.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail deals | Negative you stated: "Never sold into rail specifically" | "I've never sold into rail specifically." No slot about rail deals |
| Carried a quota, or owned a number | Negative you stated: "never carried a direct quota" | "I never carried a direct quota." The quote, at its own scope |
| Ran £4M of revenue | Inflated form of "roughly £4M of influenced revenue" | The quote at its scope: "roughly £4M of influenced revenue" |
| Knows operators' commercial problems from the inside | Inflated form of "so I know the operator world from the other side" | The quote at its scope: bus and light rail planning, seen from the other side |
| Led the partner programme | Inflated form of "running the ISV channel" | "running the ISV channel" |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The internal market report is not in this workspace and was not read; nothing in this pack draws on it.

Searches and fetches sent, all refused, because web search permission was denied in this session:

- "Kelverton Rail values": refused
- "Kelverton Rail interview process Senior Partnerships Manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Kelverton Rail Commercial Director Ross": refused

Research tier: L1, searches 0 of 6 completed (4 sent, all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet (Section 10); dropped |
| 2. `Kelverton Rail interview process {role family}` | unavailable | Loop structure; persona weights fall back to the relationship priors, not the company's documented process |
| 3. `Kelverton Rail strategy` / recent news | unavailable | CO questions; no CO question is in the pack |
| 4. `Ross Kelverton Rail` (name with title and company) | unavailable | Interviewer read (Section 7); dropped |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Would have grounded the requirement rows; the fit snapshot uses recruiter words and `[generic]` prose instead |

## Upgrade menu

- The JD text → the `[generic]` requirement rows become `[grounded]`, and the banks can check the JD's full list.
- The market report's segment headlines, pasted → C1 to C3 and the POV theses gain grounded facts, and a CO question can be added.
- Full names for Deepa and Ross, and web search permission → an interviewer read, persona weights from their public footprint, and a tailored reverse question. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available on the same consent.
- The recruiter's prep email → confirms whether any deliverable beyond the POV is expected.
- A `tuesday-dossier.md` → verified evidence and a sourced prohibited-claims list in place of the local one.
