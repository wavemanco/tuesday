# Larkfield Systems — Engineering Manager: three-round prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
1. Tuesday, 45 min — hiring manager, Director of Engineering (name not given)
2. Thursday of the following week, 60 min — panel: two staff engineers and a product manager (names not given)
3. Following Monday, 30 min — VP Engineering, described by the recruiter as "values and leadership philosophy" (name not given)

**Built on:** your role summary and your background note. No full JD, no interviewer names, no company research (web search was refused in this session, so nothing here is drawn from Larkfield's own material). Loop mode: one shared fit snapshot, then a mini-pack per round.

---

## 1. How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL** — behavioral / values alignment: whether past behavior shows the behavior the company values.
- **EXP** — work-experience deep-dive: whether your claims survive scrutiny, and what you actually did.
- **JD** — role / JD-driven: can you do the listed job, gaps included.
- **CO** — company and strategy knowledge: none researched yet, so CO items are generic.
- **CASE** — live problem: structure and reasoning on a problem from the role.

Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.

---

## 2. Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, led for three years. Two squads are not in it. Words: "For three years I was a team lead of six." Answer slot: if you have set priorities across more than one team, say which and how you decided; if you have not, say so and describe the team you led. |
| F2 | "own delivery" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is reliability work, not delivery ownership. Say the reliability quarter in its own terms: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you set the plan for that quarter, say what you planned and how; if you did not, say so and say what you pushed through. |
| F3 | "hiring and growth for 11 engineers" — JD | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | The quote is an interview loop for backend roles, not hiring decisions for a group of eleven, and it says nothing on growth. Words: "I run our hiring loop for backend roles." Answer slot: if you made hiring decisions, say which and how; if you ran interviews, say so, and say what you have done to develop engineers. |
| F4 | "partner with hardware and product on roadmap" — JD | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you stated, so the pack may give your words back: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F5 | Managing the leads of two squads — [inferred]: the JD says "lead two squads", not "manage managers" | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you stated: "I haven't managed managers." Then how you would learn it, as a plan. The requirement itself is this pack's reading of "lead two squads", so do not present it as the JD's wording. |
| F6 | Device-management and industrial IoT domain — JD | "currently at a payments company" — your message | low | [inferred] | discovery | Your material places you at a payments company and shows no device, telemetry or fleet work. The evidence may exist and the material does not show it. Answer slot: if you have built services that handle devices, telemetry or fleets, say which; if not, say so plainly and say how you would learn the domain. |

Notes on the routing: F4 and F5 are `capability` because you stated the absence. F6 is `discovery` because silence is not a stated absence. No requirement here is a gate the material says nothing about; the question about gates is in the message.

---

## 3. Prohibited list (not coached in any bank)

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" | Your stated negative (F5) | "I haven't managed managers." No slot. |
| "I've owned a hardware roadmap" | Your stated negative (F4) | "I haven't owned a hardware-adjacent roadmap." No slot. |
| "I led two squads" or "I led delivery across teams" | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material shows one team of six. |
| "I owned the reliability roadmap" | Inflated form of F2 | F2's quote at its own scope: you pushed the quarter through. |
| "I hired 40 engineers" | Inflated form of F3 | Your quote says about 40 interviews, not 40 hires. |
| "I drove the 60% drop myself" | Inflated attribution of F2 | Your quote says your team's burden dropped after you pushed the quarter through. The team's result is the team's. |

---

## 4. Persona weights by round

| Round | Persona | Weight | Reasoning |
|---|---|---|---|
| 1 — Director | Case/Strategist | Top (4–5 questions) | Hiring managers buy capability; live problems on their roadmap. Your hardware and two-squad gaps are where that capability is tested. |
| 1 — Director | Skeptic | Top (4–5 questions) | Hiring managers derisk gaps. F4 and F5 are the gaps they will look for. |
| 2 — Staff engineer A | Data-Driven Prober | Top | Staff engineers verify numbers and reliability claims. The 60% figure is their likeliest target. |
| 2 — Staff engineer A | Peer Evaluator | Second | Partnership fit with equals. |
| 2 — Staff engineer B | Peer Evaluator | Top | Seam-splitting between teams; what the hire adds to their load. |
| 2 — Staff engineer B | Pressure | Second | Peer-panel disagreement, delivered as a test of composure. |
| 2 — Product manager | Peer Evaluator | Top | Roadmap seams with product; objections return in collegial form. |
| 2 — Product manager | Case/Strategist | Second | Roadmap and prioritization cases. |
| 3 — VP Engineering | Values/Behavioral | Top | Your round is labeled values by the recruiter. |
| 3 — VP Engineering | Pressure | Second | Executive time-boxing and composure. |
| 3 — VP Engineering | Case/Strategist (strategy-heavy) | Lower (2 questions) | Altitude test; no company research yet, so these are generic. |

The values cheat sheet is not included: it needs Larkfield's published values in hand, and none are. Section 10 is dropped and the upgrade menu asks for them.

---

## 5. Round 1 — Hiring manager (Tuesday, 45 min)

Eight questions. Top personas: Case/Strategist and Skeptic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the team you have led for three years." | EXP | [grounded] "3 as a team lead of 6" — your message | Story-mapped on F1: the team of six and the three years, in your words. Beats: what the team delivered, and how your role changed over the three years. Answer slot: if you set priorities across the team, say which and how you decided; if they came from above, say so and describe what you did with them. | F1 is the scope question. The Director will test the team of six against two squads. |
| A2 | "You run the hiring loop for backend roles. What did the loop look like last year?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Describe the loop's stages and what you scored. Weakest-assumption move: the 40 counts interviews, and the loop's outcome is a separate matter. Answer slot: if you made hiring decisions, say which and how; if you ran interviews only, say so. | F3 is the hiring half of the role, and "about 40 interviews" is the number the Director will ask about. |
| A3 | "You have never managed managers and never owned a hardware-adjacent roadmap. Why should we bet on you for both?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | **The highest-ROI prep in this pack.** Do not argue the gap. Say it plainly: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then the bridge: the reliability quarter, in your words, as evidence that you hold a position under roadmap pressure. Then the plan: how you would learn to manage managers and the hardware constraints, as a plan and never as a past. Hold through two follow-ups by returning to the reliability quarter. Concede the gap is real. | F4 and F5 are the gaps this question names, and the question will come in some form in every round. A rehearsed, non-defensive answer changes the interview. |
| A4 | "Two squads and eleven engineers. How would you split your time between them?" | CASE | [grounded] "Lead two squads building device-management services" — JD | Clarify first: what each squad's roadmap and hiring needs are. Then propose a cadence and name what you would delegate. No claim about your past. | The role's two-squad structure is the case. Generic, because it is a pattern for the problem. |
| A5 | "A hardware team needs a firmware change this quarter, and both your squads have roadmap commitments. What do you do?" | CASE | [grounded] "partner with hardware and product on roadmap" — JD; [grounded] "I haven't owned a hardware-adjacent roadmap." — your message | Structure: clarify the dependency and the cost to each commitment; name who decides; state the tradeoff you would take to product. Plain acknowledgment allowed: "I haven't owned a hardware-adjacent roadmap." Then how you would learn the constraints. | F4 gap, asked as a decision rather than a record. The guidance makes no claim about your past. |
| A6 | "Tell me about a time you held a plan against roadmap pressure." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Story-mapped on the reliability quarter: the stake (on-call burden), what you held, who pushed back, the result. Use "we" for the team and "I" for what you did. Answer slot: how you got the roadmap owners to accept the quarter; if you did not persuade them, say so. | This is the strongest story you have. Open prompt, because you choose the instance. |
| A7 | "How many people does the 60% reflect, and over what period?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend-the-number slot. Say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it, say how in your own words; if someone else counted it, say so. | A figure raises these four slots and no others. |
| A8 | "What would you need from this role in the first ninety days to call it a success?" | JD | [generic] | Give a plan, not a past: delivery across two squads, a hiring plan for eleven engineers, and a cadence with hardware and product. Ask what the Director would measure. | Closes the round on expectations. Generic, because the question needs no claim about you. |

**Round 1 reverse questions** (the interviewer's name and path are not known, so none ties to their career):

1. "What would success look like for someone leading two squads at six months?" Why it lands: it turns the Director's own expectations into the frame for the rest of the conversation.
2. "How does hardware fit into roadmap decisions today, and who decides when a hardware constraint conflicts with product?" Why it lands: it shows you have thought about the seam where the role sits.
3. "Where is the hiring plan for the eleven engineers today, and where is the bar set?" Why it lands: it shows you know hiring is part of the job, and it surfaces what the Director already has in mind.
4. "What has made the last person in this role struggle?" Why it lands: it lets the Director name the real risk, which you can answer.
5. "What would you want an incoming manager to change in the first quarter?" Why it lands: it invites a concrete priority and signals you are ready to act on it.

---

## 6. Round 2 — Panel (Thursday, 60 min)

Ten questions. Personas assigned per member (no names given): staff engineers lead with Prober and Peer; the product manager leads with Peer and Case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Product and hardware disagree about which service ships first. How would you decide?" | CASE | [generic] | Clarify the constraints and who owns each side. Propose a decision rule and say who makes the call. No claim about your past. | Peer seam question from the product manager. Generic because it is a pattern for the problem. |
| B2 | "Take the 60% figure. How was the on-call number counted, and which assumption behind it would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Weakest-assumption move first: name the assumption you would defend least before they find it. Defend-the-number slot: if you counted it, say how, in your own words; if you did not, say so. | The prober's classic follow-up on a headline figure. Strongest for the first staff engineer. |
| B3 | "Who on your team carried the reliability quarter, and what did you personally change?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Use "we" for the team and "I" for what you pushed. Answer slot: if you made technical calls yourself, say which; if you set the scope and held it, say that. | Credit-sharing probe, which the peer evaluator uses. It presupposes a team, which your quote carries. |
| B4 | "Product wants features the hardware cannot support yet. Where is the seam, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — JD; [grounded] "I haven't owned a hardware-adjacent roadmap." — your message | Propose seam principles rather than pretending to know their seam. Reciprocity: what you bring to the peer's team. Plain acknowledgment allowed for the hardware roadmap. | F4's gap, asked by peers. |
| B5 | "What is the closest thing in your work to device telemetry or fleet management?" | JD | [grounded] "currently at a payments company" — your message | Answer slot: if you have built services that handle telemetry or device data, say which; if not, say so plainly and say how you would learn the domain. | F6's gap. The question asks for a stated fact, not a claim. |
| B6 | "How do you decide an engineer is ready to own a service end to end?" | JD | [generic] | Answer slot: if you have used criteria for this, name them in your words; if not, describe how you would define them. | Growth requirement, asked as a judgment call. |
| B7 | "Walk us through the hiring loop you run. What do you score, and what would make you say no?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Describe the loop's stages and what you score. Answer slot: which decisions you made; if you ran only interviews, say so. | F3. The panel will probe the decisions behind the interview volume. |
| B8 | "Your team's on-call dropped 60%. Did anything slip that quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if something slipped, say what and why you accepted it; if nothing slipped, say so, and say how you know. | Trade-off probe. The question presupposes a trade-off only as a possibility, so both branches stay open. |
| B9 | "Sketch a two-quarter roadmap for device management with hardware dependencies. What do you need to know first?" | CASE | [generic] | Clarify inputs and dependencies first. Structure by risk, then by sequence. Name what you would validate with hardware before committing. | Live case from the role's hardware partnership. Generic. |
| B10 | "How would a product manager know a squad is at risk two weeks before a date?" | JD | [generic] | Describe the early signals you would watch. Answer slot: if you have used a particular report or signal, name it; if not, say what you would use first. | Delivery ownership, tested from the product side. |

**Round 2 reverse questions**

1. To staff engineer A: "Where does the service architecture hurt most today?" Why it lands: it invites the engineer to name the real technical debt, which you can plan around.
2. To the product manager: "How does roadmap planning with hardware work now, and what is broken about it?" Why it lands: it signals you want the seam, not a pitch.
3. To the panel, reciprocity (peer): "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the peer's concerns into your contribution.
4. To staff engineer B: "What does on-call look like across the device services today?" Why it lands: it shows you are already thinking about the burden you would inherit.
5. To the product manager: "How do squads and the hardware team share the roadmap decision today?" Why it lands: it asks for the real decision process, which the PM can explain.

---

## 7. Round 3 — VP Engineering (following Monday, 30 min)

Six questions. Top personas: Values/Behavioral and Pressure. The values cheat sheet is not included (see section 4).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In one minute: what is your leadership philosophy, and where has it been tested?" | VAL | [grounded] "I've never managed managers" — your message; [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold: the position you would defend is that reliability is worth a fight against roadmap pressure. Concede: you have not managed managers, and say how you would learn it. Hold through two follow-ups; concede specifically, never on the core claim. | Opening question from a VP who will test composure and philosophy together. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Story-mapped on the reliability quarter. The stake, what you said, the result. "We" for context, "I" for what you did. Answer slot: if the truth did not land with leadership, say so; do not supply the ending. | The values question the recruiter's label points to. Your strongest story, told for the VP. |
| C3 | "How have you developed engineers who have moved up?" | VAL | [generic] | Selection scaffold: pick an engineer you helped grow, and say what you did and what they did. If none comes to mind, say so plainly, then describe how you would develop engineers in this role. | Growth requirement. Generic because your material shows hiring, not development. |
| C4 | "Two squads and eleven engineers: what is your delivery philosophy?" | CASE | [generic] | State two or three principles, and say which you would hold firm and which you would negotiate. No claim about your past. | Altitude question about the role's scope. |
| C5 | "Where does hardware fit into your view of the company's direction?" | CO | [generic] | State a thesis and label its limits: no company research has been done, so say what you would verify first. | Strategy question. Generic, because research did not run. |
| C6 | "What would change your mind about how you lead?" | VAL | [generic] | Name one specific signal you would act on, and say how you would check it. | Composure and self-awareness check. Generic, because it asks for no past claim. |

**Round 3 reverse questions**

1. "What does this company call a good leader, and where has that been tested?" Why it lands: it asks the VP to define the philosophy, which you can then answer.
2. "How has the hardware business changed how engineering leadership works here?" Why it lands: it shows you have thought about the seam at the top of the company.
3. "What have your directors done that you wish more of them did?" Why it lands: it reveals what the VP values in practice.
4. "What would you need to see in the first ninety days to be confident?" Why it lands: it turns the round into a test you can plan for.
5. "How do you tell a team in trouble from a team in a hard quarter?" Why it lands: it invites the VP's own philosophy, which is what this round is about.

---

## 8. Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Lead two squads (JD) | A1, A4, B1, C4 | |
| Own delivery (JD) | A2, B8, B10, C4 | |
| Hiring and growth for 11 engineers (JD) | A2, B6, B7, C3 | |
| Partner with hardware and product on roadmap (JD) | A5, B4, B9, C5 | |
| Managing managers (inferred, F5) | A3, C1 | |
| Device-management and IoT domain (JD) | B5 | Only one question; a generic CO item at C5 covers strategy but not the domain itself. |

---

## 9. Sources

- **Provided documents:** your role summary and your background note. The role summary is treated as JD-tier input only; there is no full JD. No CV was provided.
- **Searches sent:** one. `Larkfield Systems industrial IoT device management`: **refused** (search permission not granted in this session). No fetches.
- **Research tier:** L1 — searches 0 of 6, fetches 0 of 2 (host refused search).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have supplied the values cheat sheet (section 10), which is therefore not included. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed the loop structure and the weights on each round. Weights here are the relationship priors. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved C5 and the CO items. They are generic now. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Engineering Manager` JD | unavailable | Would have sharpened the requirements beyond the role summary. |

---

## 10. Upgrade menu

- The full JD text → turns the `[grounded]` role-summary rows into quotes from the posting, and checks the question list against every requirement.
- Larkfield's published values, pasted → a values cheat sheet for round 3.
- The names of the Director, the two staff engineers, the product manager and the VP → personas per member and reverse questions tied to each person's career path.
- Permission to search → company strategy, values and loop structure, replacing the generic CO items.
- Your CV → quoted lines for each story, so the bridges rest on more than one note.
- Recruiter notes on each round's focus, and any take-home or presentation → weights per round and a build section for any deliverable.
