# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Candidate:** Dara (they/them). **Interviews:** 4 December 2026, three rounds.
- Round A: recruiter, 30 minutes.
- Round B: Head of Member Services, your future manager, 45 minutes, mostly behavioural.
- Round C: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores against the four values.

Built as a loop: one shared fit snapshot, then a mini-pack per round. No interviewer read, because the names are not yet known.

## How to use and type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioural / values alignment
- **EXP**: your experience, tested for what was actually yours
- **JD**: the job's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem, reasoned out loud

Guidance is scaffolding, not a script. Say it in your own words, and rehearse it out loud.

## The fit snapshot

Sources: "your message" is the background you sent me. JD is the job text you pasted. Strategy brief means your summary of it, not the document.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | For the branch, I handled the formal complaints log. That is the scope the words support. Answer slot: if you set any step of the process beyond the log, say which and how you decided; if you did not, say so plainly and stay with the log. |
| F2 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | I trained new tellers on our escalation script. The quote is tellers, not supervisors. Answer slot: if you coached anyone above teller level on escalations, say who and what changed; if you did not, say so and describe how you would start. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The spreadsheet shows monthly reporting. It does not show whether resolution times were tracked. Answer slot: if it tracked how long complaints took to close, say what it showed; if it did not, say so and name the first measure you would add. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | I built the monthly complaints spreadsheet our regional manager uses. Do not add tools or skills the quote does not name. |
| F5 | "4+ years in financial-services customer operations" (JD, gate) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | Six years in retail banking, the last three as a branch supervisor. Met on the material. |
| F6 | "experience handling regulated complaints" (JD, gate) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | hard_gate | Your material does not establish it. "Formal" is the nearest word, and it does not show which rules the log followed or which deadlines applied. The question in this message asks about that. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | I haven't presented above regional level. Then the plan, as a plan and never as a past: how you would prepare for a first senior presentation. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | No evidence in the material. Answer slot: if you have worked on a customer journey in any channel, say which part was yours; if not, say so and say how you would start. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | I haven't worked in a contact centre. Then the plan: spend the first month on the contact-centre floor, listening to complaint calls. |

Rules the table follows: each evidence cell holds your sentences verbatim, with their source. Nothing in the pack says you did something the quotes do not carry.

## Prohibited list

These claims will not be coached, because a candidate reaches for them under pressure and the material does not carry them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F1 | "I handled the branch's formal complaints log." The limit is the pack's own observation: your material shows one branch's log, not the end-to-end process. |
| "Coached branch supervisors on escalations" | Inflated form of F2 | "I trained new tellers on our escalation script." |
| "Tracked resolution times" | Inflated form of F3 | No claim. The pack observes that the material does not show what the spreadsheet tracked. |
| "Worked to a named complaints regulation" | Inflated form of F6 | No claim. The pack observes that the material does not show the rules the log followed. |
| "Worked in a contact centre" | Stated negative, F9 | "I haven't worked in a contact centre." |
| "Presented to senior leaders" | Stated negative, F7 | "I haven't presented above regional level." |

## Persona weights

Relationship priors set the starting point. Your interviewers' names are not known, so the loop's three rounds set the weights.

| Persona | Shows up in | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Round A | High: recruiter screens use this register, and the logistics come up casually | 90-second arc for "tell me about yourself"; treat casual questions as scored |
| Skeptic | A (light), B (lead), C via C6 | High in B: a manager's job is to derisk gaps, and F7 and F9 are the gaps | Rehearse B2 until it is boring; plain acknowledgment first, then the plan |
| Values / behavioural | B (lead), C (guaranteed) | High: round B is mostly behavioural, and the panel scores all four values | Values scaffolds with honest branches; "we" for context, "I" for your part |
| Case / strategist | C (C1, the 20-minute case) | High: the recruiter named the case | Clarify, structure, work the problem, land it; time each part |
| Pressure | C (C6, C7) | Medium: branch managers may test composure | Hold through two follow-ups, then concede one specific point |
| Data-driven prober | B5, C7 | Medium: the spreadsheet is the line most open to checking | Say what it counted and say what you do not know |
| Peer evaluator | C (C5, reverse questions) | Medium: branch managers would work beside the new lead | Reciprocity; propose principles for the seams, not a pretend answer |

## Round A: recruiter (30 minutes)

Weights: conversational leads, with light skeptic. Logistics questions are asked, not answered, in this message; answer them in your own words in the room.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc in this order: the six years, the last three as branch supervisor, the formal complaints log, the teller training, the spreadsheet. Each beat is a clause from a quote above. No adjectives. | Casual opener, scored. F5 shows here; F1 to F4 are the beats it uses. |
| A2 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period. | Recruiter knockout check; the only safe answer is yours. |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot. Give your own figure, or ask what the band for this role is first. Do not offer a range or a history you have not decided on. | Pay is a logistics check; the figure is yours to state. |
| A4 | "Where would you be based, and how do you feel about travel?" | JD | [grounded] "across branches and the contact centre" (JD) | Logistics slot. State where you can work and how much travel you can do across branches. If the answer depends on the hub plan, say so. | The JD puts the role across branches, so travel is a fair check. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give your real reason in your own words, briefly. Then turn to what this role offers in the JD's terms. No reason is supplied here. | Reason for leaving is a standard recruiter check and a skeptic's "why now" in advance. |

## Round B: Head of Member Services (45 minutes, behavioural)

Weights: skeptic leads, with values / behavioural close behind. Your future manager will test the gaps here.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a formal complaint you handled from start to finish." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one complaint from the log and take it in order: what came in, what you did, who you involved, how it closed. Say what was yours and what was decided above you. Answer slot: if the outcome was decided by someone else, say who and what your part was. | F1's quote is the only story the material carries; it tests what was actually yours before the panel does. |
| B2 | "Why this role, with no contact-centre experience?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" (your message) | Plain acknowledgment first: "I haven't worked in a contact centre." Then what carries over: "I handled the branch's formal complaints log." Then the plan: spend the first month on the contact-centre floor, listening to complaint calls. Hold: what the log gave you is working knowledge of how a complaint moves to a decision, and you would want to see how it moves through the phones before you change anything. Concede: the call-handling side is what you would learn first. Rehearse three follow-ups. | F9 is the most predictable objection in the loop, and it returns in round C. This is the highest-return rehearsal in the pack. |
| B3 | "How would you bring the branches and the contact centre into one complaints process?" | JD, CASE | [grounded] "across branches and the contact centre" (JD); "I handled the branch's formal complaints log" (your message) | Start with the path a complaint takes from branch to contact centre to decision. Then one log that everyone writes to. Then the people who take complaints on each side. Name yourself as the owner until it is solved. Speakable in 90 seconds. | F1 is the headline requirement. Asked as a plan, it can be rehearsed without inflating F1. |
| B4 | "How would you coach a branch supervisor who escalates a complaint too late?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold from the teller training: what the script asked for, how you taught timing, what you would do with a supervisor who is slow. Answer slot: if you coached anyone above teller level on escalations, say who and what changed; if you did not, say so and describe how you would start. | F2: the requirement is supervisors, and your quote is tellers. The slot keeps that gap honest. |
| B5 | "What did your monthly complaints spreadsheet track?" | JD, EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it tracked, in your own words, and who used it. If it tracked how long complaints took to close, say what it showed. If it did not, say so plainly and name the first measure you would add. Do not quote a figure you cannot explain. | F3 and F4: the role asks for resolution times and Excel reporting. This is the question most likely to be probed. |
| B6 | "Tell me about a time you had to deliver an unwelcome message to someone above you." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear about a complaint or a process. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the spreadsheet your regional manager uses), or how you would handle one now. | A values stem. No sentence of yours carries this story, so it is a scaffold. |
| B7 | "The role presents complaint trends to senior leaders. How would you prepare for your first presentation above regional level?" | JD | [grounded] "confident presenting to senior leaders" (JD); "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I haven't presented above regional level." Then the plan, as a plan: one page, the three numbers the audience needs, and a run-through with your regional manager beforehand. | F7 is a stated gap. The plan is yours to adopt, and it is never a past. |
| B8 | "What would you change first in a complaint journey inside the app, given the bank is moving 40% of member service to digital by 2028?" | CO, JD | [grounded] "work with digital teams on self-service journeys" (JD); "move 40% of member service to digital channels by 2028" (strategy brief) | Start from the member's side: where complaints start in the app, what members ask for, where a digital complaint would stall. Name the complaints data you would bring to the digital team. Answer slot: if you have worked on a customer journey in any channel, say which part was yours; if not, say so and say how you would start. | F8 has no quote, so the slot is the honest answer. The strategy line is the company anchor. |

## Round C: panel of two branch managers (60 minutes, values scored)

Weights: case leads (C1, 20 minutes), values guaranteed, pressure and peer evaluation close behind.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Case: "A member has complained three times about a fee. They now say they will take it to the ombudsman. The branch says the matter is settled; the contact centre's record says it is not. What do you do, and in what order?" | CASE, JD | [generic] | Run the 20 minutes in four parts. Clarify (about 3 minutes): what the record says, what was promised, the regulator's timeframe for this complaint, whether the member has been told. Structure (about 3 minutes): member first, one owner, one plain letter, the escalation path. Work it (about 10 minutes): correct the record, call the member, explain the fee once and clearly, tell the branch and the contact centre why. Land (about 4 minutes): what you would track and what you would change in the process. Name the timeframe as a question to ask, not a number to state. | The recruiter's 20-minute case, as a generic live problem from the JD's regulated-complaints line. It presupposes nothing about your past. |
| C2 | "Tell us about a complaint you stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: choose one complaint from the log that you kept hold of, from first contact to close, and say when you could have let go and did not. Answer slot: if you handed one on, say to whom and why. If none comes to mind, say so plainly and describe how you would keep hold. | Own the Fix. No sentence of yours carries a specific ending, so the story is a scaffold. |
| C3 | "Tell us about a time you decided a complaint from the member's side when the rule said otherwise." | VAL | [generic] | Scaffold: name the rule, the member's situation, the decision, and who you had to convince. If no such time comes to mind, say so plainly, then describe how you would decide one and what you would record. | Members First. No quote supplies a story, so none is mapped. |
| C4 | "A member has read our letter twice and still doesn't understand it. What do you do?" | VAL, CASE | [generic] | Call them. Ask which sentence is the problem. Rewrite it in their words and check back. Scaffold: if you have explained a process to a member or taught a script in plainer words, say which; if not, say how you would do it. | Plain Words, as a live problem. |
| C5 | "If one of our branches were to close as part of the hub plan, how would you handle the complaints from that town?" | CO, VAL | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Name the members' route to a hub, the complaints still open at closure, how members are told, and the local staff who know the town. No figures. Answer slot: if you have handled a branch closure or merger, say what you did; if not, say how you would start. | Neighbours, Not Numbers under the hub plan. The question is conditional, so it presupposes no closure. |
| C6 | "You have never worked in a contact centre. Why should we trust you to run complaints across one?" | Pressure, JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Hold: "I haven't worked in a contact centre. I have six years in retail banking, the last three as a branch supervisor." Hold through two follow-ups, each returning to the branch work. Concede one specific point: the call-handling side is what you would learn first, and you would want the contact-centre leads' view before you change anything. | F9 under pressure. The second follow-up is where candidates fold, so the concession is specific, not general. |
| C7 | "How much of that spreadsheet was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say exactly what you built. Say whether the regional manager changed any of it, and which parts. Hold the claim as quoted; do not claim the figures or the use as yours. Answer slot: if any part was not yours, say which, and do not defend it. | A pressure stem and a prober stem on F4. It holds the sentence's own scope. |

**Coverage of the JD and values**

| Requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, B3, C1 |
| Report monthly on volumes and resolution times | B5 |
| Coach branch supervisors on escalations | B4 |
| Work with digital teams on self-service journeys | B8 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C1, and the question in this message (F6) |
| Confident presenting to senior leaders | B7 |
| Comfortable with Excel reporting | B5, C7 |
| Contact-centre work, from "across branches and the contact centre" | B2, C6 |
| Members First, Always | C3 |
| Plain Words | C4 |
| Neighbours, Not Numbers | C5 |
| Own the Fix | C2, B3 |

The SME lending launch in Q1 2027 has no question. It is outside this role's JD; mention it only if asked.

## Values cheat sheet

Your material carries no values story. The four values are the weakest area in this pack, and the panel scores them.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: a formal complaint from the log where you chose the member's side against the first answer. If none comes to mind, say so plainly, then describe how you would decide one. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Scaffold: a time you rewrote an explanation or taught a script in plainer words, drawing on the teller training in F2. If the script was not yours to change, say so, then say how you would. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: a time a branch decision reached people as people. If none, say so, and describe how you would treat a town's members in a hub move. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: a complaint from the log you held until it was solved (F1). If you handed one on, say to whom and why. |

## Grounding brief

Words to use, from your summary of the strategy brief. Check every figure against the document itself before the interview.

- "members" and "member service", not "customers", which matches the values
- Move 40% of member service to digital channels by 2028
- Consolidate eight branches into five hubs over 2027
- Launch a small-business lending product in Q1 2027
- The main competitive pressure is app-only banks

No stale framings are flagged, because I have only your summary.

## Reverse questions

| Round | Question | Why it lands |
|---|---|---|
| A | "What would the first year in this role need to show?" | It shows you read the JD's outcomes, and it gives you the recruiter's view of success. |
| A | "Which complaint timeframes does the team work to today?" | It checks the regulated-complaints picture (F6) from the employer's side. |
| B | "When the eight branches become five hubs, which complaints do you expect to change first?" | It shows you read the strategy brief and invites your future manager into the plan. |
| B | "What have the digital teams already tried on complaints, and what did members say about it?" | It shows interest in the self-service journeys (F8) and in members, not only process. |
| C | "What is one escalation from your branch last year that you would want handled differently?" | It shows Own the Fix and gives the panel room to talk about its own work. |
| C | "What could a new person do in their first month that would help your branch most?" | It is the reciprocity question for a peer panel, and it turns the test into a working conversation. |

## Sources

- **Your message:** your background, the round details, the role, and the values you copied from ashgrovecu.org/about/values on 25 November 2026. I have not fetched the values page myself.
- **Recruiter's email:** the three rounds, the panel, the 20-minute case, and the four values scored.
- **Strategy brief (July 2026):** I have only your summary. The document itself has not been read.

**Research tier:** L0, provided documents only. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | Values cheat sheet: the values you pasted fix the section |
| 2. Interview process | skipped | Loop structure: the recruiter's email fixes the three rounds |
| 3. Company strategy / recent news | skipped | Grounding brief: your summary of the brief supplies the current priorities |
| 4. Named interviewer | n/a | No names were given, so there was no query to form |
| 5. Representative JD | skipped | Not needed: the JD you supplied fixes the fit snapshot |

## Upgrade menu

- **Your CV, or the sentences you would use for your background** → the quotes in F1 to F4 and A1 become CV-grounded, not your message.
- **The complaints rules the branch's formal log followed (regulator, timeframes)** → the case's clarify step in C1 and the regulated-complaints row F6 both become specific.
- **The strategy brief itself** → the grounding brief, B8 and C5 can use exact figures and dates.
- **The Head of Member Services' name** → persona weights and reverse questions tied to their career path.
- **The two branch managers' names** → a persona assigned to each panel member.
- **The recruiter's note on what the 20-minute case covers** → C1 becomes a case on the real problem.
- **What the spreadsheet tracks, in your words** → B5 and C7 can answer the question without a slot.
- **A tuesday-dossier.md** → a checked grading of your evidence, and any prohibited claims it records.
