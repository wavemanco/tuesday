# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop: three rounds on 4 December 2026. (1) Recruiter, 30 min. (2) Head of Member Services, 45 min, your future manager, mostly behavioural. (3) Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values. Built 25 November 2026. No interviewers beyond the roles are assigned yet, so there is no interviewer read.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** = whether past behaviour shows Ashgrove's published values. **EXP** = your own record, probed for what was actually yours. **JD** = the job's stated requirements. **CO** = Ashgrove's strategy and competition. **CASE** = a live problem from the role, with no claim about your past.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: answer it from your own experience. If the honest answer is "I haven't", say that plainly.
- The fit snapshot, grounding brief, values sheet, prohibited list and sources are shared across rounds. Each round has its own persona weights and mini-pack.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words already carry the years and the sector. Say them as they are: "6 years in retail banking, the last 3 as a branch supervisor." The sentence does not say what the customer-operations work was. Name that in your own words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Credible adjacent work, at a branch's formal complaints log. Say it at that scope: "I handled the branch's formal complaints log." Answer slot: if the log ran to a regulator's or the firm's own timescales, say which and how you tracked them; if it did not, say so and say what you would check first. |
| F3 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | At its own scope: "trained new tellers on our escalation script." Coaching supervisors is not in that sentence. Answer slot: if you coached other supervisors on escalations, say how; if your coaching was of tellers only, say so and say how you would approach supervisors. |
| F4 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The sentence reaches monthly complaint reporting in other terms: "I built the monthly complaints spreadsheet our regional manager uses." It does not say what the spreadsheet counted. That is the question at B5. |
| F5 | "report monthly on complaint volumes and resolution times" — JD (resolution-times half) | none given | none | [grounded] | discovery | The material is silent on resolution times. Answer slot: if the spreadsheet or the log recorded how long complaints took to close, say how that was measured; if it did not, say so and say what you would add first. |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet and names no tool. Derivation: the spreadsheet may or may not be Excel. Answer slot: if you built it in Excel, name the features you used; if you used another tool, say which. |
| F7 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log is the scope you can stand behind: "I handled the branch's formal complaints log." Answer slot: if your work reached beyond that one branch, say where and how; if it did not, say so plainly and say what "end to end" would take in this role. |
| F8 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Your own statement, so it can be said: "I haven't worked in a contact centre." Then how you would learn a contact centre's complaint flow, said as a plan and never as a past. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Your own statement: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan. |
| F10 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Silent in your material. Answer slot: if you have worked with a digital or product team on a customer journey, say what the journey was and what you did; if you have not, say so and say how you would start with that team. |

No requirement in the JD is a gate (licence, authorisation, location, schedule, pay), so no row is `hard_gate`. Pay, notice and location come up in the recruiter round as logistics slots, not as gates.

## Grounding brief

Vocabulary to learn. These are your words from the strategy summary in your message (July 2026). Your message paraphrases the brief, so check the brief's own wording before quoting it in the room.

| Item | Your words | Provenance |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] — your message |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] — your message |
| Lending | "launch a small-business lending product in Q1 2027" | [grounded] — your message |
| Competition | "the main competitive pressure is app-only banks" | [grounded] — your message |

Stale framings: none flagged, since this is the newest document you have. Nothing beyond the brief was checked.

## Persona table

| Round | Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| 1. Recruiter | Conversational | top | The recruiter's prior is a friendly register, but the four logistics (pay, notice, location, reason for leaving) and motivation are scored | Treat casual questions as scored; give each logistics answer in your own words |
| 1. Recruiter | Skeptic (light) | mid | The contact-centre and senior-presenting gaps are knockout checks at screen level | Name the two gaps before they are raised |
| 2. Head of Member Services | Values / Behavioral | top | The recruiter says "mostly behavioural", which moves this round away from the hiring-manager prior (Case first) | STAR shape; "we" for context, "I" for your contribution |
| 2. Head of Member Services | Skeptic | mid | You would manage the role whose gaps these are; the manager is the one who has to derisk them | Hold the contact-centre position; concede specifically |
| 2. Head of Member Services | Data-Driven Prober | low | One spreadsheet is the only number-bearing evidence | Name the weakest assumption before asked |
| 2. Head of Member Services | Case / Strategist | low | The manager's roadmap questions are mostly in the strategy items | Clarify, then structure |
| 3. Panel | Values / Behavioral | top | The panel scores against the four values | Map each value to a story, or to the honest branch |
| 3. Panel | Peer Evaluator | top | Two branch managers are close to peers of the role, and they are pricing what the hire costs their branches | Reciprocity framing; propose seam principles |
| 3. Panel | Case / Strategist | mid | The 20-minute case is a fixed slot of the 60 minutes | Clarify, objective, segment, approach, metrics, risks, aloud |
| 3. Panel | Data-Driven Prober | mid | Branch managers will test the one artifact you can show | Say what the spreadsheet counted, and what you would defend least |

Values and Peer tie at the top of the panel. Lead with the values questions, since they are what the panel scores. Panel members are not named, so weights are blended from the panel prior.

## Question banks

### Round 1: Recruiter screen (30 min), 8 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | A 90-second arc in this order: the years and the sector, the supervisor role, the complaints log, the spreadsheet. Use these sentences as they are. Add no event. | Opener. F1, F2 and F4 are the whole arc, so every beat is one you already stated. The register is conversational; the content is scored against the JD's first requirement. |
| A2 | "What is your reason for leaving your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in one sentence, in your own words. Your material gives none, so the reason is yours to supply. | Reason for leaving is one of the four recruiter logistics. It is scored as motivation, asked casually. |
| A3 | "What notice do you need to give?" | JD | [generic] | Logistics slot: give your actual notice period. | Notice is one of the four logistics. Only you hold the figure. |
| A4 | "What salary are you looking for in this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band for this role before you give one. Both are yours to choose. | Pay is a logistics slot. The pack supplies no figure and no range. |
| A5 | "Where are you based, and could you work from one of the new hubs?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" — your message | Logistics slot: say where you are based and what you can do, in your own words. Then ask what a hub means for the location of this role. | The hub plan is Ashgrove's, and it makes location a real question. The guidance does not assume the role sits in a hub. |
| A6 | "This role runs across branches and a contact centre. Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I haven't worked in a contact centre." Then one sentence of plan. No slot; the honest answer is the whole answer. | The likeliest knockout check at screen level. F8. |
| A7 | "What do you know about Ashgrove's plans?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message | Name one item from the July brief in your own words and say what it would mean for complaints. Keep to what the brief says; add no figure. | Strategy homework at recruiter level. This is the item most likely to come up. |
| A8 | "Which requirement in the job description do you meet least?" | JD | [grounded] "Never worked in a contact centre" — your message; "I've never presented to anyone above regional level" — your message | Answer with the two gaps you hold, in your own words: no contact-centre work, and no presenting above regional level. Then say how you would start closing the first. | Skeptic-style honesty check. Naming both gaps first keeps the answer calibrated instead of defensive. |

Round 1 covers the JD's first requirement (A1), location and the four logistics (A2 to A5), the contact-centre gap (A6, A8), the strategy (A7) and the senior-presenting gap (A8).

### Round 2: Head of Member Services (45 min), 10 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a time you told someone above you a hard truth. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log," at that scope. | Values / Behavioral persona stem. The round scores whether a hard truth actually landed. |
| B2 | "Tell me about a problem you found that was not yours to fix, and what you did about it." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." — your message | Selection scaffold: a problem you found and kept hold of until it was solved. Say what you found, what you did, and what stayed yours. If you did not keep one, say so, then give the nearest thing your material carries: "I handled the branch's formal complaints log" — your message. | Own the Fix is one of the four values, and this round is where the manager scores behaviour. |
| B3 | "Most of this role runs through a contact centre, and you have never worked in one. Why should we hire you?" | JD | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | Hold: say what you can stand behind, at its scope: "I handled the branch's formal complaints log," and "trained new tellers on our escalation script." Hold through two follow-ups by returning to that log. Concede specifically: "I haven't worked in a contact centre, and I won't pretend to know its queues." Then one plan in the first person: what you would shadow in your first 90 days. | The highest-ROI prep in this pack. It is the most predictable objection, and F8 is where the material is thinnest. It is asked in some form in all three rounds. |
| B4 | "Have you presented to a group above regional level? How would you present complaints data to our executive team?" | JD | [grounded] "I've never presented to anyone above regional level" — your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: how you would prepare, and what you would bring, which is the monthly report you already build. | F9. The second half of the question has a true answer in your sentence about the spreadsheet. |
| B5 | "Walk me through what the monthly complaints spreadsheet counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what it counted, in your own words, and which part you built. If you can name a figure, say how it was counted and the assumption you would defend least. If you cannot say how a column was filled, say so. | F4 and F6. Prober register: expect a request for the denominator. |
| B6 | "You inherit a monthly complaints report with volumes but no resolution times. What do you do before the next board pack?" | CASE | [generic] | Structure it: what the report must answer for its readers. Define when a complaint starts and when it stops, before you add any time. Check where those dates live. Decide what to show, what to leave out, and say why. | A live problem from the JD's monthly report. It asks about no past of yours, so it makes no claim. Tests F5 and F6. |
| B7 | "When did you put a member ahead of a target?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." — your message | Selection scaffold: a decision where the member's side changed what you did. Say what you were measured on, what the member needed, and what you did. If no decision comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log" — your message. | Members First is scored. Tell it from the member's side of the counter, not as a number you hit. |
| B8 | "How did you know the escalation script you trained tellers on had landed?" | VAL | [grounded] "trained new tellers on our escalation script" — your message; "Plain Words — if a member needs it explained twice, we wrote it wrong." — your message | Answer slot: if you checked that the script had landed, say how you checked and what you found. If you did not check, say so, and say how you would check next time. | Plain Words, through the training you did. The premise is your sentence about training, and the second branch allows that it was never checked. |
| B9 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What does that do to a complaints process?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message | Think aloud: which complaints move to digital, which still need a person, and how a digital route hands a complaint to a person. Name one risk and the measure you would watch. Give no figure you were not given. | Strategy at the level this role owns. It also tests the digital-teams requirement (F10) through the complaint route. |
| B10 | "We are consolidating eight branches into five hubs. How do you keep a town's complaints from getting lost?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — your message; "Neighbours, Not Numbers — every branch is part of its town." — your message | Selection scaffold: say what a town loses when its branch changes, how you would hear that complaint, and how you would measure it afterwards. If you have handled a branch change before, say what happened; if you have not, say so. | A values-plus-strategy question. Neighbours, Not Numbers, asked against the strategy's most visible branch move. |

Round 2 covers Own the Fix (B2), Members First (B7), Plain Words (B8), Neighbours (B10), the contact-centre gap (B3), senior presenting (B4), the spreadsheet (B5), the monthly report (B6) and the digital route (B9).

### Round 3: Panel of two branch managers (60 min), 10 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has complained three times about the same charge. The branch supervisor escalates it to you. What happens next?" | CASE | [generic] | The 20-minute case. Clarify first: what the charge is, what the member has been told, and which timescale applies. Confirm the regulated timescale in your firm's procedure, not from memory. Objective: a decision the member can understand. Segment: fee error, system fault, or misunderstanding. Approach: one named owner, one decision, the answer in plain words. Metrics: time to close, repeat complaints. Risks: the supervisor disagrees. Think aloud. | Scored on structure and clarity, not on a right answer. Covers the regulated-complaints requirement without any claim about your past. |
| C2 | "Your branch supervisor thinks your decision is wrong. What do you do?" | CASE | [generic] | Hold the decision against the evidence for two follow-ups: ask what the supervisor saw that you did not. Concede a specific point where it is true. Do not fold on the decision. Say how you would coach the supervisor on the next case. | Tests the coaching requirement inside a case, so the hold-then-concede move is scored without touching your history. |
| C3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message; "Own the Fix — whoever finds the problem keeps hold of it until it is solved." — your message | Selection scaffold: a complaint you kept until it was closed. Say what kept you on it. If the log recorded cases and you did not follow them to the end, say so, and say what you would do differently. | Own the Fix is scored by this panel. Your material says you handled the log, not that you followed cases to the end. The honest branch is the strong answer if it is true. |
| C4 | "How would you tell a town that its branch is being consolidated into a hub?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — your message; "Neighbours, Not Numbers — every branch is part of its town." — your message | Selection scaffold: say, in plain words, what changes for the member, and who you would tell first. If you have explained a branch change to members before, say what you said and what came back. If you have not, say so. | Neighbours, Not Numbers, asked in the panel's own terms, against the strategy's branch move. |
| C5 | "Read me one sentence you would send a member about a fee they were charged. Now make it plainer." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." — your message | Live rewrite: remove jargon, one idea per sentence, and the one action the member can take. No claim about your past. | Plain Words scored live. A sentence in complaint-register language loses this round. |
| C6 | "What tool did you build the monthly complaints spreadsheet in, and what did you use it for?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: name the tool and the features you used. If it was not Excel, say which tool. | Prober. Tests Excel reporting (F6) on the one artifact you can show. |
| C7 | "Our teams sit side by side. Where is the seam between your work and branch operations, and what happens when you disagree?" | VAL | [generic] | Selection scaffold: a real disagreement with a peer over a shared process. Say what each side wanted, what you did, and how it ended. If you have no such time, say so, then say how you would set up the seam on day one. | Peer Evaluator seam question. Nothing in your material shows a peer disagreement, so the scaffold ends in its honest branch. |
| C8 | "What could a new Member Experience Lead do in the first month that would help this team?" | JD | [generic] | Name one thing about branch complaint handling you could do in month one, as a plan. Keep it to the branches' side. | Peer reciprocity: what you bring to their team, not only what you need. |
| C9 | "Which stage of a complaint took the longest, and how do you know?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: if you tracked stages, say which and how you knew. If you did not track stages, say so, and say what you would track first. | Tests the end-to-end and resolution-time requirements (F5, F7). The second branch allows that no stages were tracked. |
| C10 | "What would you need from a branch manager to coach their supervisors on escalations?" | JD | [generic] | Name what you would ask for: the escalations they see, the cases they would want reviewed, and what would change your advice. Say it as a plan. | Covers the coaching requirement from the other side of the table, and gives the panel a peer question to answer. |

Round 3 covers the 20-minute case (C1, C2), the four values (C3, C4, C5, and B2, B7, B8, B10 from round 2), the spreadsheet tool (C6), the seam (C7), the first month (C8), the stage question (C9) and coaching (C10).

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | C1, C9 |
| coach branch supervisors on escalations | C2, C10 |
| report monthly on complaint volumes | B5, C6 |
| report monthly on complaint volumes and resolution times (resolution times) | B6, C9 |
| own the member complaints process end to end across branches and the contact centre | A6, B3, C9 |
| confident presenting to senior leaders | A8, B4 |
| comfortable with Excel reporting | C6 |
| work with digital teams on self-service journeys | B9 covers the digital route only. No question asks about working with a digital team directly. Upgrade menu |

## Values / principles cheat sheet

The panel scores against these four values. Each value gets a story where one of your quoted sentences carries one, or a selection scaffold that ends in its honest branch where none does.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a decision made from the member's side. Selection scaffold, B7 and C9 territory: pick a decision where the member's side changed what you did. If none comes to mind, say so, then give the nearest thing your material carries: "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, the writing was wrong | Your sentence: "trained new tellers on our escalation script." The beat is what you taught and how you knew it landed, given only if you checked. If you did not check, say so. B8 and C5 rehearse this. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a town-level story. Selection scaffold: a time a local place or customer changed a decision you were making. If none, say so plainly. B10 and C4 rehearse the strategy version. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Your sentence: "I handled the branch's formal complaints log." The beat is a complaint kept until closed. If the log recorded cases and you did not follow them to the end, say so. B2 and C3 rehearse this. |

## Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none is tied to a career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first six months look like for this role?" | Shows you plan for the outcome, not the job spec. |
| R2 | "The brief moves 40% of member service to digital by 2028. Which complaints do you expect to move with it?" | Shows you have read the strategy and connected it to complaints. It asks for their view, which gives you their priorities. |
| R3 | "How are complaints split between the branches and the contact centre today, and who owns each part?" | End-to-end ownership is the job. The answer tells you what you would inherit. |
| R4 | "Which regulator's timescales apply to complaints here, and how are they reported to the board?" | Regulated complaints is a JD requirement. The answer tells you what the monthly report must carry. |
| R5 | "What could I do in my first month that would make your branches' complaint handling easier?" | Reciprocity with peers. It is the same question as C8 asked the other way. |
| R6 | "What is the one thing about this team's complaint work you would change first?" | Shows you think about the manager's own priority, and gives you the escalation pattern to rehearse. |
| R7 | "What is the format of the 20-minute case: a written brief in advance, or live?" | Tells you whether the case bank is rehearsed live or from a brief. Asked of the recruiter. |

## The prohibited list

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them appears in any answer slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across the branch network | Inflated form of F7 | The quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: your material says one branch's log. |
| Ran complaint handling across branches and the contact centre | Inflated form of F7 and F8 | The branch quote as above. The contact-centre half has a plain acknowledgment: "I haven't worked in a contact centre." |
| Built the regional complaints report | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." The pack observes that the regional manager uses it; it does not say the report is regional. |
| Trained supervisors on escalations | Inflated form of F3 | "trained new tellers on our escalation script." |
| Has presented to senior leaders | Negative you stated, F9 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |

## Sources

- **Provided documents:** your message, which carried the job description text, the recruiter's process email (three rounds, 4 December), the strategy summary (July 2026), your background, and the four values as you copied them from ashgrovecu.org/about/values on 25 November 2026.
- **Searches and fetches sent:** none. Every output the research would have fed is fixed by the inputs above.
- **Dossier consumed:** none. There is no `tuesday-dossier.md` in this conversation.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | The values sheet and the four VAL themes. The values copy you pasted fixes them. |
| 2. interview process, role family | skipped | Loop structure and persona weights. The recruiter's email fixes the three rounds and their order. |
| 3. strategy / recent news | skipped | The grounding brief and the CO questions. The July brief you summarised fixes them. Anything published after July 2026 is not checked. |
| 4. interviewer name | n/a | No interviewer is named yet, so there is no query. |
| 5. representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Panel members' names → personas for each panel member, and a reverse question tied to their career path.
- The 20-minute case brief, or a note of whether it arrives in advance → C1 and C2 rebuilt on the real brief. They are generic now.
- Whether the spreadsheet or the complaint log recorded resolution times, and how they were measured → F5 moves from discovery to a grounded row, and B6 and C9 get a sourced answer.
- The tool you built the spreadsheet in → F6, B5 and C6 get a sourced answer.
- The strategy brief's own wording, not your summary → the quotes in A5, A7, B9, B10 and C4 become exact.
- Anything Ashgrove has published since July 2026 → the strategy questions and R2 and R4 are checked against current material.
- Deep research (L2): the strategy talks, role-family loop reports and recent organisation news, at most 6 more searches and 2 more fetches. Offered once; it runs only if you say so.
- Prep time before 4 December → a prep triage section ordering the rehearsal by round.
- Any deliverable the recruiter names in advance → a build section for it. None is declared now.
