Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-7-denied-03a05dd2/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Three things matter most:

- **B1 is the highest-return prep.** Expect "you've never worked on a game with in-app purchases. Why would we hire you?" The pack gives a hold on your calendar sentence, then a specific concession on the gap you named.
- **The gate needs a straight answer.** The JD asks for 3+ years of producing live-service games. Your material shows four years on a puzzle game, but not that it was live-service or that you were producing. Only you can settle that.
- **Don't coach team leadership or two-title planning.** Your sentences cover one title's calendar and a checklist QA uses. The pack writes those as they stand and gives you answer slots for anything beyond them.

Company research didn't run: both web searches were refused. Nothing about Saltmarsh Games or Tobias Wrenfield is verified. Please check their values, their live titles, and how they monetize, before Friday.

I can run the B1 drill with Tobias's voice if you want it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word.

Two questions, so the pack fits your situation:
1. Is Tobias your future manager, or will someone else be in the room?
2. Would you call the puzzle title's content drops live-service (ongoing updates after launch), and were you producing or assisting a producer?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not yet confirmed.
**Round:** 60 minutes, one session.
**Research:** did not run. Both web searches were refused by the permission setting. Nothing below about Saltmarsh Games is verified.

## How to use

Personas describe how a question arrives. Types describe what it is scoring.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. None were available, so this tag is absent from the pack. |
| EXP | Experience deep-dive | Whether your claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Not covered: no research ran |
| CASE | Live problem | Structure and reasoning on a problem from the role |

The guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds. Anything in the guidance that is not in one of your own sentences is either a plan you describe as a plan, or an answer slot you fill in your own words.

**Interview timing (60 minutes)**

| Minutes | Block | Questions |
|---|---|---|
| 0 to 5 | Opening. Note what Tobias says the role needs most. | none |
| 5 to 12 | Your 90-second arc, then one follow-up | E1 |
| 12 to 30 | Live problems on the role | A1, A3, A4 |
| 30 to 42 | Pressure and the gaps. Deliberately placed here, before you are tired. | B1, B2, C3 |
| 42 to 52 | Your numbers and your checklist | D1, D2, D3, A5 |
| 52 to 58 | Your questions | R1 to R5 |
| 58 to 60 | Close | none |

## The fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message, verbatim. Where a row has no source, its gap is written as the pack's observation, not as something you said.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, run for two years: "I ran the weekly content-drop calendar for our main title." The two-title scope is not in your material. Answer slot: if you have planned across more than one title, say what carried over and what did not, in your own words. If you have not, say so plainly and say what you would check first. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | Your sentence reaches this requirement directly. Say it in its own terms: you ran the calendar. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Your material names QA and no other team, so coordination with the other four is not shown. Answer slot: if you coordinated design, art, engineering or community on a drop, name the team and the drop, in your own words. If the drops went through QA alone, say so and say how you would bring the other teams in. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is reporting, not owning a review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a post-event review or set its KPIs, say which and how. If you did not, say so plainly and say what you would report after a drop. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. No figure is given, so none is claimed. D2 tests the figure. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | high | [grounded] | presentation | Reword only this quote: "I wrote the release checklist, and our QA team still uses it." Nothing in your material says you owned the release process. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A checklist for one team is one written artifact. Your material does not show writing for readers outside QA. Answer slot: name a written piece someone outside your team acted on, in your own words. If there is none, say so and say how you would write a post-event summary. |
| F8 | "3+ years producing live-service games or apps" (JD, gate) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [inferred] | hard_gate | Your material does not establish this gate. It shows four years, a puzzle game, and the title "associate producer", and does not say the title was live-service or that you were producing. Not bridged. The message asks you about it. |
| F9 | Not in the pasted JD. Mobile live events usually involve spend. (generic) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words, from your own negative: "I haven't worked on a game with in-app purchases." No answer slot, because the pasted posting does not raise it. The probe is rehearsed as a live problem in A3 and B1. |
| F10 | Not in the pasted JD. Team leadership. The JD asks you to coordinate, which is F3. (generic) | "Never led a team" (your message) | none | [grounded] | capability | Words, from your own negative: "I haven't led a team." Give it when asked. It does not bridge into coordination, which is F3's row. |

## Persona weights

Relationship prior: hiring manager, so Case/Strategist and Skeptic are heaviest. There is no interviewer profile, so no interviewer-signal adjustment applies. This is one session, so no loop adjustment applies either.

| Persona | How it shows up | Weight and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live plans for the two titles, a retention drop, a crash three days out | Top. The JD is a live roadmap, and a hiring manager buys the ability to plan it. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | 5 (A1 to A5) |
| Skeptic | The IAP gap, the "associate producer" title, the one-title calendar | Top. Your message names two gaps the JD's requirements touch, and the JD's first requirement is the one your calendar sentence is quoted against. | Hold on the quoted sentence, concede the named gap specifically, and ramp in the plan form. | 4 (B1 to B4) |
| Data-Driven Prober | Walk me through the checklist, how the retention figure was counted, which KPI you would defend least | Mid. Retention metrics and the post-event KPIs are in the JD. | Name the weakest assumption before the interviewer does. Say plainly when you do not know how a figure was counted. | 3 (D1 to D3) |
| Pressure / Stress | A sixty-second "why you", a "how much was actually you", "you've never led a team" | Mid. Your gaps are stated in your own words, so a pressure probe on them is likely. | Pause, restate, hold through two follow-ups, concede only the named gaps. | 3 (C1 to C3) |
| Conversational / Rapport | Your journey, what you play lately | Low. Casual, but scored. | Use the arc. Treat the casual questions as scored. | 2 (E1, E2) |
| Peer Evaluator | Where the seam sits with design and community, and credit when a drop goes well | Low. Tobias is not a peer, but design and community leads will share the drops with you. | Propose seam principles. Do not pretend to know their teams. | 2 (P1, P2) |
| Values / Behavioral | Not included | No published values were available, and no values round was detected. | Not applicable. | 0 |

## Question banks

Provenance comes first in each row. Each quote is one of your own sentences, verbatim, from your message or the JD.

**Highest-ROI prep: B1.** It is the most predictable objection, and it is the one Tobias is most likely to ask in some form.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan next quarter's live-events calendar for two mobile titles. What do you need to know first?" | CASE, JD | [generic] | Clarify first: each title's current update cadence, what each update is for, and who signs off on what. Then objective, the player segments you would target, approach, the metrics you would watch, and two risks. Describe the calendar as a plan. This question asks for no history. | Tests the JD's first responsibility. F1 is why the two-title half is where the pressure lands, so the guidance asks for the plan, not a record. |
| A2 | "Retention on one of your titles dropped four points in the two weeks after a content drop. Diagnose it." | CASE, JD | [generic] | Clarify what retention means here (day seven, cohort) and whether the drop reached everyone. Split by cohort, platform and whether the drop changed the first session. Name the metric you would check first, and challenge one premise in the question. | F5 stands behind the retention requirement. No sentence of yours says you have diagnosed a drop, so this is a plan. |
| A3 | "Imagine a limited-time event on a title where players can spend real money. What do you check before launch, and who do you bring in?" | CASE, JD | [generic] and "never worked on a game with in-app purchases" (your message) | Name the spend risks you would check: offer clarity, fairness, and what the event does to spend against play. Name the teams you would bring in: design, engineering, and whoever owns the monetization data. If Tobias asks whether you have run one: "I haven't worked on a game with in-app purchases." Then return to the plan. | The IAP gap (F9) rehearsed as a live problem. It asks for a plan, so it presupposes nothing about you. |
| A4 | "A release is three days out and QA finds a crash in the new event. What do you do?" | CASE, JD | [generic] | Triage: reproduce it, scope it (which builds, which players), and decide with QA between a hold and a ship with a fix. Say who you tell and when. Name the checklist step that should have caught it. | Connects to the release-checklist requirement. The answer is a decision, not a claim about your past. |
| A5 | "Give me the first three lines of a post-event summary you would send the studio head after a drop that missed its retention target." | JD | [generic] | Lead with the number and the period, then the likeliest cause and what you would check, then the decision you need. Keep it to three lines. Write it as you would send it, not as a speech. | The JD asks for clear written communication, and F7 has no other question. This writing test is the question. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. Why would this studio hire someone who hasn't?" | JD, EXP | [grounded] "never worked on a game with in-app purchases" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold, then concede. Hold: "I haven't worked on a game with in-app purchases, and I won't pretend otherwise. What I did carry over is the weekly content-drop calendar for our main title, for two years." Follow-up one: concede the gap specifically. Spend mechanics, and how events move them, is the part you would learn first. Name the plan for learning it. Follow-up two: hold the calendar point. Do not add a monetization claim to get out of the pressure. | The highest-ROI prep. The question is the objection in its most likely form. The hold rests on your calendar sentence and the concession on the negative you stated, so nothing is added. |
| B2 | "Your title was associate producer. The posting asks for three years of producing live-service games or apps. Which part of that do you meet?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Answer slot: say, in your words, whether the puzzle title's updates ran as an ongoing service after launch, and whether you were producing or assisting. If it did, say what it was. If you were not the producer on it, say so plainly and give the years as they were. | F8 is the hard gate your material does not establish. The question is premised only on the title quoted. |
| B3 | "What did you actually own on the content-drop calendar, and what did you run inside someone else's plan?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: name any decision on that calendar that was yours to make, such as which drop went in which week or what was cut, in your own words. If the calendar was set by someone else and you ran it, say so plainly and describe what running it involved. | F2 at its own scope. The probe is about attribution. |
| B4 | "Your calendar covered one title. The role covers two. What breaks first when you add the second?" | JD, CASE | [grounded] "I ran the weekly content-drop calendar for our main title" (your message) | Answer slot: if you have planned across two titles or more, name what carried over and what broke. If you have not, say so plainly and say what you would check first: cadence, shared QA time, and whose capacity is shared. | F1 is transferability. The two-title scope is the JD's own sentence. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds. Why you, over someone who has run live-service operations for years?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" (your message) | Pause. Restate: "You're asking why me over someone with longer live-service runs." Hold: "They may have longer runs. What I've done is run a weekly content-drop calendar for two years and write the checklist QA still uses." Concede specifically, with only your named gaps: "The gaps are the two I named: in-app purchases, and leading a team." Do not argue the comparison. | Hold-then-concede. The hold rests on two of your sentences, and the concession uses only your stated negatives. |
| C2 | "That retention number you presented. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: say what you did with the monthly retention numbers, and which parts you produced and which you received. If you computed them, say how, in your own words. If you presented figures someone else produced, say so plainly and say what you added. | F4 at its own scope. The probe is attribution, not method. |
| C3 | "You've never led a team. Why would four teams take direction from you on every update?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment first: "I haven't led a team." Hold on the difference: the role asks you to coordinate, and coordinating is not leading. Say how you would set the drop's sign-offs and who decides what. Answer slot: if you coordinated across other teams on a drop, name the team and the moment in your own words. If the drops went through QA alone, say so and say what you would put in place for the other four. | F10 and F3. The premise comes from your own sentence and the JD's own line. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the release checklist you wrote works. What is on it, and what does QA sign off?" | EXP, JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe the checklist's shape in your own words: what it covers, where QA signs off, and how it has changed since you wrote it. If you did not write all of it, or it changed in ways you did not drive, say so plainly. | F6 is the strongest sentence in your material for the checklist requirement, so this is where it gets probed. |
| D2 | "The monthly retention numbers you presented. Walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Defend-the-number slot: say how the figure was counted, in your own words. Name the assumption behind it you would defend least, and which part was yours. If you did not count it, say so plainly and say who did. | F5. No figure is given, so the guidance asks for the method, not a number. |
| D3 | "Which KPI in a post-event review would you defend least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you ran a post-event review, name the KPI you would defend least and why. If you did not, say so plainly and name the KPI you would lead with after a drop, as a plan. | F4. The question is generic, so it does not presuppose that you ran a review. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in the order of those four sentences, in your words. End on the gap you named: "I haven't worked on a game with in-app purchases." Add nothing between the sentences. | The arc uses F1, F4, F6 and F9 as they stand. It ends where your material ends. |
| E2 | "What are you playing right now in mobile live operations, and what is it doing well?" | JD | [generic] | Name one live title you actually play, what its update cadence feels like from the player's side, and one thing it does well. Pick a title you can discuss in detail. No research ran, so check the title's current state before the call. | Casual questions about a JD topic are scored. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Design and community sit next to you on every drop. Where is the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not facts about their teams: who decides the drop's scope, who decides its timing, and how a disagreement escalates. Answer slot: if you have a disagreement from your past, say it in your own words. If not, say so and describe the principle you would apply. | F3 is the gap. The guidance does not claim to know their teams. |
| P2 | "How do you handle credit when a drop goes well across teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Answer slot: say whose work the release checklist was in your telling, and how you would credit design, art, engineering and community on a drop. If the checklist was yours alone, say so. If QA extended it, say that. | F6. Credit probes follow the seam. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B4 |
| Coordinate design, art, engineering and community on each update | C3, P1 |
| Own the post-event review and the KPIs it reports | D3 |
| Manage the release checklist with QA | A4, D1 |
| 3+ years producing live-service games or apps | B2 (gate; the message asks you about it) |
| Experience running a content calendar | B3 |
| Comfortable with player-retention metrics | A2, D2 |
| Clear written communication | A5 |
| Not in the JD: in-app purchases | A3, B1 |
| Not in the JD: team leadership | C3 |

## Reverse questions

No interviewer profile exists, so none of these ties to Tobias's own career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two titles does the calendar cover first, and how different are their update cadences?" | Shows you have thought about scope before the job, and gets Tobias to describe the work. |
| R2 | "Where does a drop most often slip today, and who decides when it is late?" | Names the real release risk and opens the checklist conversation on the team's terms. |
| R3 | "How is the post-event review run now, and which KPIs does it report to leadership?" | Tests the current state of the requirement you would own, and lets you hear what owning it means here. |
| R4 | "How much of the monetization model sits with live operations, and how do you plan events around it?" | Asks where the IAP gap matters without claiming anything. The answer tells you what to ramp first, which B1 needs. |
| R5 | "What would you need to see in the first ninety days for this to be a good hire?" | Points at what success means to Tobias, and lets your B1 ramp plan answer it directly. |

## Prohibited claims

These will not be coached, in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated design, art, engineering and community on each update | Inflated form of F3 | F3's quote at its own scope: the release checklist, and QA. Your material does not show the other four teams. |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: one title's weekly content-drop calendar, for two years. |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope: presented the monthly retention numbers. |
| Owned the release process with QA | Inflated form of F6 | F6's quote: wrote the release checklist QA still uses. |
| Led a team | Sourced negative (F10) | "I haven't led a team." |
| Experience with in-app purchase games | Sourced negative (F9) | "I haven't worked on a game with in-app purchases." |

## Sources

**Provided documents:** your message, including the JD text you pasted and your background.

**Searches and fetches sent:**

- "Saltmarsh Games mobile studio live operations": refused by the permission setting; no results.
- "Tobias Wrenfield Head of Live Operations": refused by the permission setting; no results.

**Research tier:** L1. Searches 0 of 6 (2 attempted, both refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have set the values cheat sheet. No values round was detected, so that section is dropped either way. |
| 2. Saltmarsh Games interview process | unavailable | Would have confirmed the round's structure and weights. Weights are on the relationship prior. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Would have fed the company-knowledge questions. None were written. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have produced an interviewer read and a reverse question tied to his path. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the requirement coverage. |

## Upgrade menu

- **The full JD posting** → the pasted text does not mention monetization or in-app purchases. If the full posting does, F9 gets a raising source, and A3 and B1 are rewritten on it.
- **Your hours before Friday** → a sized prep-triage section, with B1 first.
- **Search access, or Saltmarsh's values page pasted in** → the values section, and company-knowledge questions tied to current strategy.
- **Tobias's public profile, pasted or searchable** → persona weights from his career, and a reverse question tied to his path.
- **The recruiter's note on the round format** → confirms whether this is a hiring-manager round, and moves the persona weights if not.
- **A `tuesday-dossier.md`** → one line on what it would add: it would carry this prep's gaps into later sessions, so they are not rebuilt each time.
