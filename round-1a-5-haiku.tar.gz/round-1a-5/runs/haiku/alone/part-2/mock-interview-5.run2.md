Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-5-denied-b2c61812/b22b4db8-19a2-4062-93d7-b5f9efed01ad/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it on your recruiter email and your background as you described it. I did not have the market report or a job description, and web search was refused, so the pack runs on your material alone. Anything that depends on the report is marked.

The most important items:
- **B1, the rail-and-quota objection** ("You've never sold into rail or carried a direct quota..."). Answer it plainly with what you did, then a 90-day plan. Rehearse this one first.
- **The 15-minute POV.** The pack gives three theses, each with a concession, and rejects the "more resellers" consensus answer. It closes on operator outcomes such as fewer cancelled services and faster rescheduling after a change. Check the theses against the market report before Tuesday.
- **C1, the £4M.** Ross will ask how it was counted. Know the method and the weakest assumption before he raises it.

Offers, not pushed:
- Want me to run a live drill? I can play Deepa's skeptic on B1 and give feedback against that question's guidance.
- Want me to save a `tuesday-dossier.md` recording these gaps for later sessions? Or convert the pack to Word?

Questions that would restructure the pack:
1. Do you have the job description text? Pasting it would turn the recruiter's requirement quotes into grounded rows and show any gate requirement.
2. Can you paste the operator-partnership sections of the market report? That would let me check each POV thesis against it.
3. Can you grant web search permission? That would let me pull Kelverton's public strategy. Otherwise I'll keep the pack at provided-document depth.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, Tuesday. 60 minutes, panel.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** first 15 minutes, a spoken point of view on operator partnerships over 18 months (no slides; must land on what it means for the operators). Remaining 45 minutes, Q&A; Ross will push on commercials.
**Built on:** your email from the recruiter and your background as you described it. I did not have the internal market report or a job description, and web search was not permitted in this session, so this pack runs at research tier L0. Anything that depends on the report is marked.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored. Type tags: EXP (experience), JD (tests a stated requirement), CASE (live problem), GEN (generic pattern), SKEP (challenge to a gap).
- Guidance is scaffolding, not a script. Speak it in your own words; rehearse the shape, not the sentences.
- Quoted sentences come from your own material and nothing else.

## Prep triage (about 4 hours)

1. **75 min:** write the POV in your own words, then say it aloud twice, timed to 12 minutes. Section 5 gives the theses and concessions to build on.
2. **60 min:** rehearse B1 (the rail-and-quota objection) and C1 (the £4M) out loud until they stop sounding rehearsed. These are the highest-return items in the pack.
3. **45 min:** be able to explain how the £4M influenced revenue was counted and which partners it covers. Ross will ask.
4. **30 min:** re-read the reverse questions and check the POV closes on operator outcomes, not on Kelverton's revenue.
5. **Everything else is insurance.**

## The fit snapshot

Requirements come from the recruiter's email (quoted) because no job description was supplied. Rows are graded on your own quoted sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in an ISV channel, not operator partnerships. Say what carries over, at that scope: "I took a channel from 6 partners to 40." Anything wider is an answer slot. |
| F2 | "what it means for the operators themselves" (recruiter email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | presentation | Your quote reaches the operator world in other terms. Lead with it: "I spent five years on the operator side of bus and light rail network planning." |
| F3 | "Ross will push on commercials" (recruiter email) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | high | [grounded] | capability | You stated this absence. Words: "I haven't sold into rail, and I haven't carried a direct quota. My number has been influenced revenue." No slot. |
| F4 | Knowledge of rail scheduling and train operating companies (recruiter email, role context) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | low | [inferred] | transferability | Planning-side knowledge of bus and light rail is adjacent to TOC scheduling, not the same. Answer slot: which operator decisions you saw from inside a planning team, and where you would expect rail to differ. |

**Gate check:** no gate requirement was identified in the material. Confirm if the job description has one.

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure. They are not coached.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I've carried a quota" | Negative you stated (F3) | "I haven't sold into rail, and I haven't carried a direct quota." |
| "I built or ran operator partnerships" | Inflated form of F1 | "I took a channel from 6 partners to 40." |
| "I drove the £4M" | Inflated form of F1 | "Roughly £4M of influenced revenue, which I can walk through." |
| "I understand rail scheduling" | Inflated form of F2/F4 | "I worked on the operator side of bus and light rail planning." |

## Graded deliverable: the 15-minute POV

Your grounded facts for this build: F1 and F2 above. Use only those sentences as the basis for any claim about your past.

**Thesis 1: operators buy reliability and speed of timetable change, so partnerships should be built around the change cycle.**
- Concession: you have not sat inside a TOC planning function. Say so, and say what you would test first.

**Thesis 2: move from vendor-and-reseller to shared delivery, where the partnership is measured on operator outcomes (on-time running, faster reschedules) as well as contracted value.**
- Concession: contracting models like this depend on franchise and procurement rules you may not know in detail. Name that limit.

**Thesis 3: the operator's own suppliers and data feeds are partnership surfaces, not just Kelverton's customers.**
- Concession: you do not know Kelverton's current partner base. Say that plainly.

**Differentiation against the consensus answer:** the consensus answer is "more partners and resellers", borrowed from channel-led software. Say no to it: operators do not resell scheduling software, and a partner count does not show operator value. Say why in one sentence.

**Requested close:** what it means for the operators themselves. Close on an operator outcome you could measure: fewer cancelled services and faster rescheduling after a change.

**Depends on the market report:** every thesis above is my reasoning, not Kelverton's strategy. Check each against the report before the interview. Drop or reframe any that the report contradicts.

## Persona table

| Persona | Who | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Deepa | Live problems on the operator roadmap; POV follow-ups | 35% | Future manager; needs to see how you think about operators | Clarify the goal, then structure, then answer. Think aloud. |
| Skeptic | Deepa and Ross | "Why should we believe you can do this with no rail or quota history?" | 25% | Your two real gaps are in the email and the CV | Hold the honest limit, then give a 90-day plan |
| Data-Driven Prober | Ross | How the £4M was counted; which partners, which period | 20% | Commercial Director; influenced revenue is a number he will check | Know the method and say plainly where you do not know it |
| Pressure | Ross | Time-boxed challenges to your commercial claims | 15% | Commercials are his stated focus | Pause, restate, hold a position through two follow-ups |
| Conversational | Both | Warm opener; a casual question on the operator market | 5% | Low weight, but casual questions are still scored | Treat them as scored |

## Question banks

### Bank A: Deepa (Case / Strategist and Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you start with our operator partnerships in the first six months?" | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Clarify first: which operators, which contract cycle. Then the POV's first thesis. Use the quote only to show how you grew a channel, and do not claim the same work in operators. | Tests structure on the real roadmap |
| A2 | "What would you need to know about our operators before you proposed anything?" | GEN | [generic] | Name three things: how operators choose suppliers, how they handle timetable change, and where they lose time. Ask for the report's view on each. | Shows you think from the operator's side |
| A3 | "What did your transport consulting teach you about operator decisions that software vendors miss?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say one decision you saw from inside a planning team, in your own words. Stop there. | F2's bridge, rehearsed |

### Bank B: Deepa (Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| **B1** | "You've never sold into rail or carried a direct quota. Why should we believe you can lead operator partnerships?" | SKEP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | **Highest-ROI prep in this pack.** Say it first: "I haven't sold into rail, and I haven't carried a direct quota." Then the honest scope of what you did: "I took a channel from 6 partners to 40." Then the 90-day plan for learning rail sales (a plan, not a past). Hold through two follow-ups by returning to what you did. | The most likely objection. Its premise is the stated absence, so it can be answered plainly |
| B2 | "Which part of this would you be weakest at on day one?" | SKEP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Name the rail sales cycle and TOC procurement as the weakest parts. Name your plan for each. | Calibrated candour beats bluffing |

### Bank C: Ross (Data-Driven Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| **C1** | "Walk me through how you got to £4M of influenced revenue. What's in it, and what isn't?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Give the method: which partners, which period, how influence was defined. Say what you do not know about the attribution, and say it plainly. | Ross will check the number. Knowing the method is the defence |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the weakest assumption before he does: the attribution window or how partner-sourced deals were credited. | Probing the assumption is the test |
| C3 | "If you'd carried a quota, what would the number have been?" | SKEP | [grounded] "never carried a direct quota, only influenced revenue" | Say you do not know, and say what you would expect a quota to look like on operator contracts. Do not guess a figure. | A premised question; the honest answer is the limit |

### Bank D: Ross (Pressure)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | SKEP | [grounded] "Never sold into rail specifically" | Pause. Restate the question. Answer with what you bring that a rail seller would not: operator-side planning knowledge and partner-growth experience. Name the trade-off honestly. | Tests composure under time pressure |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Say what your part was, in your own words, and what the team's part was. Do not claim the whole number. | Shrinking an inflated claim gracefully is the skill being tested |

## Reverse questions

Ask two or three of these. Each has a reason it lands.

1. **To Deepa:** "What did the last person in this role wish they had known in their first 90 days?" Why it lands: shows you plan for the role, and gives you a real answer to test your POV against.
2. **To Deepa:** "How do operators' planning teams and your partnership team decide when to change a supplier?" Why it lands: it tests the operator-side claim in your POV with the person who owns it.
3. **To Ross:** "Is the commercial model per seat, per timetable, or outcome-linked?" Why it lands: it shows you think about the revenue mechanism, not only the number.
4. **To Ross:** "How do you count a partnership as successful: contracted value, operator outcome, or both?" Why it lands: links the commercial model to the POV's outcome close.
5. **To Deepa and Ross:** "Which operator problem in the market report do you hear about most in renewal conversations?" Why it lands: it shows you read the report and it invites them to name the problem for you. Depends on the report.

## Sources

- **Provided documents:** your email from the recruiter (quoted in your message). The internal market report was not available to me, so no claim in this pack is checked against it.
- **Searches:** two web searches were attempted (Kelverton Rail's scheduling software and operators; Great British Railways and TOC partnerships). Both were refused: web search permission was not granted in this session. No results came back.
- **Research tier:** L0 (provided documents only).
- **Target accounting:** company strategy: unavailable (search refused). Interviewer public footprint: skipped (no names researched). Role-family loop reports: skipped. Recent org context: unavailable (search refused).

## Upgrade menu

- The market report's operator-partnership sections → the POV theses and concessions are checked against the report, and "depends on the report" items resolve
- The job description text → the recruiter's requirement quotes become `[grounded]` JD rows, and any gate requirement shows up
- Web search permission granted → Kelverton's public strategy, the operator market and recent moves become `[grounded]` in a grounding brief
- Public professional profiles for Deepa and Ross → persona weights per interviewer and tailored reverse questions
