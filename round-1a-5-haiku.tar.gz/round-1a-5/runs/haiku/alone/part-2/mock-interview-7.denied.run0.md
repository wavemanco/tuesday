Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-7-denied-d641cede/44e913b2-6aca-483a-a682-d7d2151a9fde/scratchpad/saltmarsh_live_operations_producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say whether Tobias is your manager, a panel member or a peer. Web search was refused in this session, so the pack rests on the job description and your background message alone. The file lists the searches and what they would have added.

The biggest thing to rehearse is B1. Your two stated gaps, no team leadership and no in-app purchase work, are the likeliest objections. The pack gives you a plain acknowledgment for each, then a bridge from the content-drop calendar and the release checklist, which you have actually done.

Say the word and I'll play the Skeptic on B1 in a live drill.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can carry them into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a panel member or a peer? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed; built on a hiring-manager prior.
**Format:** 60 minutes, Friday.
**Changelog:** first version.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and never say anything your material does not carry.

Type key:

- **VAL**: behavioral and values alignment. Not used here, because no values-style round was detected.
- **EXP**: your experience, tested for what you actually did.
- **JD**: the role's stated responsibilities and qualifications, including the gaps.
- **CO**: company and strategy knowledge. Not used here, because research did not run.
- **CASE**: a live problem from the role, solved aloud.

## The fit snapshot

Each evidence cell holds your own sentences, quoted exactly, with their source. Anything the pack says about your past comes from these quotes, a plain acknowledgment of a negative you stated, or an answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one main title's weekly content-drop calendar, run for two years. It does not show live events, and it does not show a second title. Keep to the scope as stated. Answer slot: the JD's two-titles line makes a probe on a second title likely. If you have planned across more than one title, say which and how; if not, say so, and say how you would plan across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordinating those teams on an update. Your message also says "Never led a team", and this row is where a hiring manager is likely to press on it. Answer slot: if you coordinated design, art, engineering or community on a drop, say who, on which decision, in your own words. If a drop went out without that coordination, or it was not yours to run, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | discovery | Your material shows you presented retention numbers. It does not show you owned a post-event review. Answer slot: if you ran or owned a review after a content drop, say what it covered, which KPIs it reported and who acted on it. If no review was yours, say so plainly, and say what you would measure first. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | None. Lead with the sentence as written: you wrote it, and QA still uses it. Expect a probe on whether you only wrote the checklist or also ran the sign-off with QA. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | presentation | The years are there, and the content-drop work is the nearest sign of live service. Say it in your material's terms: "4 years as an associate producer at a puzzle-game studio." Your material does not say the title was live-service. If asked, name that limit in one clause, and do not call the title live-service. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | None. The quote states the calendar, the scope and the duration in your own words. Expect a probe on what you decided and what came from design. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Your material says you presented the numbers, which reaches the requirement in other terms. Say it that way: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on how the figure was counted. If you know what it measured and over which window, say so. If you cannot say how it was counted, say so. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | presentation | The one written artifact your message names is the checklist. Say it with the quote, not with an adjective. Answer slot: if you have another written artifact, name it in your own words. If the checklist is the only one, say so. |
| F9 | In-app purchase experience on a live title, the role family's usual scope (not in the JD) — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Your message states the absence, so the words are a plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan, never as a past. |

Gap-type routing: F1 is transferability because a quote carries adjacent work that does not reach the two-titles scope. F2 and F3 are discovery because the material is silent or touches the requirement without showing it reaches it. F9 is capability because you stated the absence.

## Prohibited claims

These are not coached anywhere in this pack, and each names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Your negative: "Never led a team" | "I haven't led a team." Plain acknowledgment, no slot. |
| Worked on a game with in-app purchases | Your negative: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then a plan for learning it. |
| Ran a content calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says one main title. The second title is B2's slot. |
| Called the title live-service | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." The limit is this pack's observation: your material does not say the title was live-service. |
| Signed off releases with QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." The material says you wrote it, not that you signed off releases. |

## Persona table

Relationship is not confirmed. The weights below assume a hiring-manager round, which the JD and Tobias's title suggest. If the round is a panel or a peer round, the weights change.

| Persona | How it shows up in this loop | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the two-title calendar, a retention dip, a QA blocker | 5. A hiring manager tests the role's own work, and Tobias owns the calendar this role runs. | Clarify, state the objective, segment, approach, metrics, risks. Think aloud. |
| Skeptic | Probes the two stated negatives and motivation | 4. Your two stated negatives are the likeliest objections. | Plain acknowledgment, bridge only from quoted work, a ramp described as a plan. |
| Data-Driven Prober | Retention figure and post-event review KPIs | 3. Retention is the JD's named metric and your one presented number. | Say how it was counted, or say you do not know. Name the weakest assumption you know of. |
| Pressure | One time-boxed challenge on leadership | 2. A 60-minute interview allows one hard push. | Pause, restate the question, hold through two follow-ups, concede the specific gap. |
| Conversational | Opening biography and a casual writing question | 2. Casual openers are scored. | A 90-second arc made only from quoted sentences. |

## Question banks

Ordered by weight. Each row's Provenance carries every sentence its guidance rests on.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of our mobile titles, one live-events calendar team. How would you plan the next quarter for both?" | CASE | [generic] | Clarify first: which titles, their audiences, what the quarter already holds. Then the objective, how you would split the calendar between the two, what you would hold fixed, and the metric you would check per event. Name one risk: one title's drop crowding out the other's QA time. | The JD's headline scope makes this the likeliest live problem. It asks about the role, not your history, so the guidance makes no claim about you. |
| A2 | "Retention dipped the week after a content drop. Walk me through what you check in the first 48 hours." | CASE | [generic] | Confirm the dip is real: the cohort, the window, the platform. Then check what changed in the drop and what else shipped. Then segment, then decide what design and community need to know. Name the assumption you would test first. | Retention is the JD's named metric and the usual live problem for this persona. The guidance makes no claim about your past. |
| A3 | "Two weeks before an event, QA finds a blocker on one title. What do you do?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: decide with QA whether the blocker stops the release, what the checklist says about that case, who you tell, what moves. Keep the release decision with the team, not alone. If you use the checklist as your example, use the sentence exactly as written and add nothing to it. | The JD's release checklist with QA line (F4). It is a live problem, so it asks nothing about your past. |
| A4 | "Walk me through how you would coordinate design, art, engineering and community on one update." | JD | [grounded] JD line "coordinate design, art, engineering and community teams on each update"; your message has no sentence on it. | Answer slot. The question presumes coordination you may not have done. If you coordinated these teams on an update, say who, on which decision, and how you got them to agree, in your own words. If the update was not coordinated that way, or it was not yours to run, say so plainly and describe how you would run it. | F2 is discovery. The JD raises this line, and your material does not carry it. |
| A5 | "A content drop missed its retention target. What would you put in the review?" | JD | [grounded] JD line "own the post-event review and the KPIs it reports" | Answer slot: say what you would measure, what you would compare it against, and who acts on it, in your own words. If you have run a review after a drop, say what it covered. If none was yours, say so plainly. | F3 is discovery and the JD's post-event review line is the probe. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team and never worked on a game with in-app purchases. Which of those would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Highest-ROI prep in this pack. Hold: "I haven't led a team, and I haven't worked on a game with in-app purchases." Pick the one that matters more for the first 90 days, and say how you would learn it, as a plan. Bridge only from what you stated: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to the calendar and the checklist. Concede the gap specifically: "I haven't led a team. I'd rather say that than guess how I'd do it." Never claim either one. | Both negatives are sourced, so the plain acknowledgment is allowed. The JD's coordination line makes the leadership gap the likelier objection, which is why this is the deepest rehearsal. |
| B2 | "You've run the calendar for your main title. How would you run it across two?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Answer slot. Start with the calendar in the quote's own words. Then the plan for the second title: what you would carry over and what you would not. If you have run more than one title's calendar, say how. If not, say so and give the plan. | F1 is transferability and the JD's two-titles line raises the second-title probe. |
| B3 | "Why is this the next step after four years on a puzzle game?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Answer slot. Your material gives no reason, so the reason is yours to give, in your own words. Say only the reason that is actually yours. | "Why now" is the Skeptic's motivation probe, and no quote states a reason. |
| B4 | "This role owns the KPIs it reports. Which one would you put first, and why?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name one KPI and why it leads, using the retention work you presented as the reason, quoted. Do not claim you set the KPIs for any title. | The JD's KPI line (F3). The pick is a judgment, and the quote is the only experience it draws on. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the retention figure you presented counted? Which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot. If you know what the figure measured, the cohort and the window, say so in your own words. If you do not know how it was counted, say so plainly. Name the assumption you would defend least only if you know one. The pack supplies no method. | F7's presentation row. A presented figure draws the defend-the-number slot. |
| C2 | "Walk me through the last post-event review you owned. What did it measure?" | JD | [grounded] JD line "own the post-event review and the KPIs it reports" | Answer slot. This presumes a review you owned. If you ran a review after a drop, say what it covered, which KPIs it reported and what changed. If none was yours, say so plainly, and say what you would measure first. | F3 is discovery. The JD raises this line, and your material does not carry it. |
| C3 | "Which item on the release checklist do you rely on most, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | Story map from the quote: you wrote it, and QA still uses it. Name one item and why you put it there, in your own words. If QA added items you did not write, say that. | F4 is your strongest CV line. The probe is whether the checklist is a document you wrote or a process you run. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" — your message | Plain acknowledgment: "I haven't led a team." Then the bridge from the calendar and the checklist, quoted. Hold through two follow-ups. Concede the specific gap: "I haven't led a team, and I'd rather tell you that than overstate how I'd do it." | The leadership negative is the most direct form of this challenge. |
| D2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Hold: say what you ran, in the quote's words, and what came from others. Answer slot: if you decided what went into each drop, say which decisions and how. If design set the content and you ran the schedule, say so. Concede only what is true. | An attribution probe on your headline claim. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Wrote the release checklist our QA team still uses." — your message; "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc with four beats, each a quoted sentence: the four years, the calendar, the checklist, the retention numbers. End with what you want from this role, in your own words. | Opening biography is scored. The arc reuses only quoted sentences. |
| E2 | "How do you keep your writing clear for QA and design?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Describe what you did to make the checklist usable, in your own words. If you made no specific choice for clarity, say so, and describe how you would check it with QA. | Clear written communication is in the JD, asked casually and still scored. |
| E3 | "What have you been reading about live ops lately?" | EXP | [generic] | Name one thing you actually read, and say what you took from it. If you have not read anything recently, say so. Do not name a source you did not read. | A casual question on the role's field. Nothing here makes a claim about your past. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B2 |
| Coordinate design, art, engineering and community teams on each update | A4, B1 |
| Own the post-event review and the KPIs it reports | A5, B4, C2 |
| Manage the release checklist with QA | A3, C3 |
| 3+ years producing live-service games or apps | E1, B3 |
| Experience running a content calendar | B2, D2 |
| Comfortable with player-retention metrics | A2, C1 |
| Clear written communication | E2 |

In-app purchases are not a JD requirement. They are covered by B1 because you flagged them as a gap.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for whoever takes this role, specifically on the two titles?" | Tests the two-title scope and shows you are planning for it. |
| R2 | "How is the live-events calendar decided today: who proposes an event, and who can veto it?" | Shows how the coordination actually works, and your next question depends on the answer. |
| R3 | "How is the post-event review run now, and who reads the KPIs it reports?" | Points at the deliverable you would have to own, and shows you know it is one. |
| R4 | "How does the release checklist with QA run today, and what would you want changed?" | Shows you know the checklist you wrote is still in use, and invites Tobias's view. |
| R5 | "Which monetization numbers sit next to retention in your reviews?" | Opens the in-app purchase gap as a question to learn from. It claims nothing. |

No reverse question is tied to Tobias's own career path, because no public profile was available to read.

## Sources

**Provided documents:** the job description pasted in your request, and your background message. No CV file and no dossier were provided.

**Searches sent, all refused:**
- "Saltmarsh Games values": refused. Web search permission was not granted in this session.
- "Saltmarsh Games interview process live operations producer": refused, same cause.
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused, same cause.

**Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not triggered here, since no values-style round was detected. The search was refused. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure and persona weights. The hiring-manager prior is unconfirmed. The search was refused. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Grounding brief and the CO bank. Not sent, under the same permission refusal. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, and a reverse question tied to his path. The search was refused. |
| 5. Representative live operations producer JD | skipped | The job description you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Web search permission, then a rerun → Saltmarsh's values, interview process, recent news and Tobias's public footprint: a values cheat sheet if the round is values-style, loop-based persona weights, and a reverse question tied to his career path.
- Round type, and whether Tobias is your manager, a panel member or a peer → reweights every persona bank.
- The round format, including any pre-declared exercise or take-home → a build section for each one.
- A sentence about a second title, in your own words → F1's gap and B2's slot.
- A sentence about coordinating design, art, engineering or community on a drop → F2 and A4.
- A sentence about a post-event review you ran or owned → F3, A5 and C2.
- A sentence about how the retention figure was counted → F7 and C1.
- A `tuesday-dossier.md` would carry the gaps this prep exposed into later sessions.
