I'll load the skill's reference files before building the pack.
The skill needs research for the values and loop-structure targets before it can write the pack, so I'll run the L1 searches now.
The searches were refused, so the pack will be built on role-family priors and labeled as such. Writing the pack file now.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-3-denied-ae81b8fc/37d92107-4ec5-4b5c-90c8-10653539e0c7/scratchpad/stripe_product-operations-manager_interview_pack.md. It's a first pass. I had no CV, job description, round type or interviewer, and the web searches were refused, so it's built on general product-operations priors. Nothing about Stripe's values, process or strategy is verified yet.

Once you share your materials, I can play the interviewer for a live drill. The pack names C2 ("how much of that was actually you?") as the provisional highest-ROI prep, though that's a default for ops roles until I see your CV.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

To make the next version useful, I need three things:

1. Who are you meeting, and in what relationship (hiring manager, peer, skip-level, or a panel)? Does the recruiter's note name any focus areas or a take-home?
2. Can you paste your CV or background and the job description? If you don't have the JD, say so and I'll use a representative one.
3. How much prep time do you have before the round?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round prep pack

**Changelog:** First pass. No CV, job description, round type or interviewer was provided, so the pack is built on role-family priors. The web searches were refused, so nothing about Stripe is verified here.

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioral and values; **EXP** work-experience deep-dive; **JD** role and JD-driven (none used yet, since no JD was supplied); **CO** company and strategy; **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds. Anything you say about your past must be true and in your own words.
- Sections left out, and why: prep triage (no prep time given); graded deliverables (none declared); grounding brief and values cheat sheet (research did not run, and no values-style round is detected); interviewer read (no interviewer named); delivery coaching (no assessment provided).

## Fit snapshot (worksheet variant)

No CV and no JD were supplied, so every evidence cell is "none given" and every requirement is a role-family prior labeled [generic]. No requirement is a gate in any material supplied, so there are no hard-gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running an operating cadence (planning, reviews, decisions): role-family prior | none given | none | [generic] | discovery | Strong evidence looks like one process you designed or changed, why you changed it, and what happened after. Pick one from your own work. If there is none, say so, then say how you would approach it. |
| F2 | Cross-functional program management with teams that do not report to you: role-family prior | none given | none | [generic] | discovery | Strong evidence looks like one initiative you drove across teams without authority over them. If there is none, say so, then say how you would get alignment. |
| F3 | Defining and tracking metrics that drive decisions: role-family prior | none given | none | [generic] | discovery | Strong evidence looks like a metric you defined, what it was for, and what it changed. Name the metric if you have one. If not, say how you would choose one. |
| F4 | Executive and stakeholder communication, summarizing for a decision: role-family prior | none given | none | [generic] | discovery | Strong evidence looks like one written or spoken summary that changed a decision. If there is none, say how you would structure one. |
| F5 | Scaling process and tools as a company grows; change management: role-family prior | none given | none | [generic] | discovery | Strong evidence looks like a process you changed at larger scale and how people adopted it. If there is none, say what you would watch for first. |
| F6 | Prioritizing across competing requests with incomplete information: role-family prior | none given | none | [generic] | discovery | Strong evidence looks like a call you made with partial data, and what you did next. If there is none, say how you would decide. |

**Requirement coverage:** F1 → A1, A2 · F2 → F1, A5 · F3 → A3, B1, B2 · F4 → C1, R4 · F5 → A2, E1 · F6 → A5

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any project, scope, metric, team size or outcome of yours | No quoted sentence exists yet, so any detail would be invented | Answer slots and selection scaffolds only. The pack's own observation: your material does not show these yet. |
| Knowledge of Stripe's internal practices, products or metrics | No verified source; research was refused | Speak to what you know from public sources, and say where that ends. |

## Persona table

Round type was not given, so the weights below are flat priors for a final round, not a fitted loop. Send the round type to reweight them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 4) | Live operating problems; clarify, structure, metrics | High. The role is built on live operating problems, so this is the default shape for a final round here. | Clarify, state the objective, segment, propose an approach, name metrics and risks. Think aloud. |
| Data-Driven Prober (weight 3) | Asks how a number was counted | Medium. Any figure you cite will be probed, and this is the standard operations-interviewer shape. | Name the weakest assumption before they do. Say plainly when you do not know. |
| Values/Behavioral (weight 3) | Open prompts about past behavior | Medium. Company values were not retrieved, so there is no mapping, but a behavioral segment is still plausible. | Choose a story with a named stake, a point where you did not fold, and an intact relationship. If none comes, say so. |
| Pressure/Stress (weight 3) | Time-boxed challenges; "how much was you?" | Medium. Composure checks are common at final stage. | Pause, restate, hold through two follow-ups, concede a specific point and never the whole claim. |
| Skeptic (weight 2) | "Where would you be weakest?" | Medium-low. Anyone with no record in the material will be asked where the gap is. | Name a real area and a concrete ramp plan. No bluffing. |
| Peer Evaluator (weight 2, only if the round is with a peer) | Seam questions, disagreement, credit | Conditional on round type. | Propose seam principles. Use reciprocity framing. |
| Conversational (weight 2) | Casual opener | Low-medium. Casual openers are scored. | A 90-second arc, the same content as your formal answers. |

## Question banks

**Highest-ROI prep (provisional):** C2, the "how much of that was actually you" probe. Without a CV the pack cannot identify your biggest gap, so this is the default probe for an operations role, not a finding about you.

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our weekly planning process misses its deadlines by about a week every cycle. Walk me through how you'd diagnose that." | CASE | [generic] | Clarify what "missing" means and who is affected. State the objective. Map the steps and owners, then find where delay enters. Propose one change, how you would measure it, and one risk. | Live problem for the cadence requirement (F1). It asks about a method, not your past. |
| A2 | "Sketch the first 90 days of a weekly operating review for a team of 40 across three product areas." | CASE | [generic] | Ask which decisions the review must support before proposing a format. Then sequence it: baseline, first two cycles, the change you expect, and what would make you stop. | F1 and F5: cadence and scaling. A plan question, not a question about your past. |
| A3 | "A launch's key metric dropped 15% in its first week. How do you diagnose it?" | CASE | [generic] | Check the metric first: definition, instrumentation, seasonality, mix. Then segment, rank hypotheses, name the data each needs, set the threshold that triggers action, and say who needs to know. | F3: metric definition under decision pressure. |
| A4 | "What should a product operations team measure first, and why?" | CO | [generic] | Name two or three candidate measures, pick one, defend it, and name what it would miss. Use only public facts about payments businesses, and say where your knowledge ends. | Company research did not run, so this is generic on purpose. A sharper version is possible once current priorities are known. |
| A5 | "You have three urgent requests and one person to do them. What do you drop?" | CASE | [generic] | Name your criteria first: impact, reversibility, deadline. Then say what you drop, what you would renegotiate, and how you would tell the requesters. | F6: prioritization with incomplete information. |

### B. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Pick a number you have reported on. How was it counted?" | EXP | [generic] | Selection scaffold: pick a figure you have reported, if you have one. Say how it was counted, in your own words, then name the assumption you would defend least. If you have no reported figure, say so, then say how you would define one before reporting it. | The prober's signature question. No figure is quoted yet, so this is an answer slot. Serves F3. |
| B2 | "How would you know a process change actually worked, and what would make you doubt it?" | EXP | [generic] | Start with the baseline, then the comparison, then the confounder you would check first, then the threshold you would accept. End with the doubt you would act on. | F3. Tests whether you can attribute a result honestly. A method question, not a claim about your past. |
| B3 | "Which of your own numbers would you not want me to trust?" | EXP | [generic] | Selection scaffold: name a figure you know is soft, and what makes it soft. If you have none, say so, then say which of your methods you would check first. | Self-critique under probing. The honest branch is essential here. |

### C. Pressure/Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have sixty seconds: why should we hire you over someone who has done this exact job?" | EXP | [generic] | Pause. Restate the question in your own words. Name the one or two things you would bring that are specific to you. Concede plainly what you have not done. Do not fold. | A composure check on motive. It tests F4, your senior communication. |
| C2 | "That sounds like the team's result. How much of it was actually you?" | EXP | [generic] | Hold, then concede. Credit the team in one clause, then name the specific part you did, in your own words. If your part was small, say that plainly. Hold through two follow-ups, and concede a precise point, never the whole claim. | Provisional highest-ROI prep. Any credit claim will draw this probe. The answer depends on your own material, which is not in hand yet. |
| C3 | "I'll give you one minute: what is one thing you would cut from a product operations process in its first quarter?" | CASE | [generic] | Time-boxed. Name the one thing to cut and why, the risk of cutting it, and what you would check first. | A time-boxed live problem. No claim about your past. |

### D. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you told a leader something they did not want to hear." | VAL | [generic] | Open prompt. Choose an instance with a named stake, where you did not fold and the relationship survived. If none comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | A persona stem. No company value is confirmed, so there is no mapping. |
| D2 | "When did you put a user's outcome ahead of an internal metric?" | VAL | [generic] | Same selection scaffold. Pick a time you can name the user, the metric and the trade-off. If none comes to mind, say so, then give the nearest, or how you would decide. | A persona stem, not mapped to any published value. |
| D3 | "Describe a project that went sideways. What did you do in the first 48 hours?" | VAL | [generic] | Pick one with a clear first decision. Describe that decision, who you told and why, and what you chose not to do. | Tests judgment under pressure. Selection scaffold. |

### E. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | EXP | [generic] | Name one real area and why. Give a concrete ramp plan with a date. Do not bluff a competency you do not have. | A Skeptic stem. It exposes honest self-assessment. |
| E2 | "Which part of this role do you have the least direct experience in?" | EXP | [generic] | Name it plainly, then the nearest adjacent thing you have done, and how you would close the gap. | It asks rather than asserts, so no negative about your past is presumed. |

### F. Peer Evaluator (weight 2, only if the round is with a peer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, not a map you have not seen. Say what you would bring to their team, not only what you would need. For disagreement, use a time you disagreed with an equal, if you have one. | Peer stem with reciprocity framing. Covers F2. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: name a time credit was shared across teams and how you named each contribution. If none comes to mind, say how you would. | Peer stem. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: what you did, what you learned, why this role now. Each beat needs your own material. | Casual openers are scored. The arc needs your CV to be built properly. |
| G2 | "What process or tool have you been most excited about lately?" | CO | [generic] | Name one, say why it matters, and say what you would want to know about it. | Scored casually. No claim about your past beyond the example you choose. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this role?" | Signals that you think in outcomes. |
| R2 | "Which operating process is most in need of work right now, and what has been tried?" | Shows you are interested in the problem, not just the title. |
| R3 | "How are product and product operations divided on prioritization decisions?" | Surfaces the seam between the two teams. |
| R4 | "What would the person in this seat need to show that a résumé would not?" | Lets the interviewer name the criterion, so you can align your answers to it. |
| R5 | "How is this team's success measured, and who decides when a measure changes?" | A governance question. It shows ownership thinking. |
| R6 | (Peer round only) "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. It turns the slot into a peer conversation. |

No interviewer was named, so there is no reverse question tied to an interviewer's career path.

## Sources

**Provided documents:** none. No CV, job description or invite was supplied.

**Searches sent:**
1. "Stripe company values principles": refused (permission error).
2. "Stripe interview process product operations manager final round": refused (permission error).
3. "Stripe strategy recent news 2026": refused (permission error).

**Fetches sent:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10), left out; no values-style round is detected |
| 2. Stripe interview process, product operations | unavailable | Loop structure; persona weights stayed flat |
| 3. Stripe strategy and recent news | unavailable | Grounded CO questions; A4 and G2 are generic |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative Product Operations Manager JD | unavailable | No call sent, since the search tool was refused for the other targets; requirement rows would have been [inferred] instead of [generic] |

## Upgrade menu

- Your CV or background → the worksheet becomes a fit snapshot quoting your own sentences, selection scaffolds become story maps, and the sharpest objection gets named.
- The job description → F1 to F6 become [grounded] quotes, and the question banks cover each requirement.
- Round type and who you are meeting → reweights the personas and removes the flat weighting.
- Interviewer names → persona weights from public footprint, and a reverse question tied to their career path.
- The recruiter's note on focus areas, or any take-home → build sections for announced deliverables.
- Permission for web search → values cheat sheet, interview process, and CO questions grounded in current strategy.
- Prep time → a prioritized triage schedule.
