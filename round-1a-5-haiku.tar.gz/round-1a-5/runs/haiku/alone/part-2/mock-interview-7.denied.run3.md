Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-7-denied-6f82f64a/bb9b514e-dd9f-4dfc-beaf-6b07c72f9494/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

I could not research Saltmarsh. The web search tool was denied permission on all four attempts, so the pack has no company values, no interview-process details and no news. The values cheat sheet is left out for that reason. The pack covers Tobias only from the name you gave, so there is no read of his background. Once search is allowed, or if you paste their values page or Tobias's profile, I can add those sections.

The pack is built on the assumption that this is a single hiring-manager session. Its highest-return prep is the retention question (B2): name the weakest assumption behind the figure you presented, and hold it through two follow-ups. Your three stated gaps (no team leadership, no in-app purchase experience, and the two-title scope) are each rehearsed with a plain acknowledgment and a plan, never a claim. The pack also covers the 60-minute run-of-show.

I can play the Skeptic on B2 if you want to rehearse it. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for your later sessions. A Word version of the pack is available on request.

Two questions that would reshape the pack:
1. Is Tobias your hiring manager, and is Friday a single session? A take-home, presentation or peer round would change the persona weights.
2. Do you still maintain the release checklist, or did you hand it over? The pack currently treats it as written and used by QA, not run by you.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Round:** 60-minute interview, Friday. Assumed to be a hiring-manager round.
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. No public profile was available to read (see Sources).
**Candidate:** Femi (pronouns not stated; the pack uses "you").
**Changelog:** first version.

**Assumption this pack is built on:** the round is a single session with Tobias as hiring manager, no take-home or presentation declared, and the CV is your message as written. If any of that is wrong, the persona weights in section 8 change.

## 1. How to use this pack and type key

- **Personas** = how a question is asked. **Types** = what is being scored.
- Types: **VAL** behavioral/values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- Quoted sentences in the Provenance column are yours. Only rehearse what sits inside them.

## 2. Prep triage (time not stated, so the default full pack)

Do these, in order:

1. Rehearse the **retention numbers** answer (B2, the highest-ROI prep). The JD asks for retention comfort and you have the one fact that matters: how the numbers were counted.
2. Rehearse the **"you have never led a team"** and **"no in-app purchase experience"** holds (D1, D2). Both will likely come up.
3. Rehearse the **two-titles** answer (A3). The JD asks for two titles; you ran one.
4. Rehearse the walkthrough of the content-drop calendar (A1) to 90 seconds.
5. Prepare the 60-minute run-of-show (section 9).

Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the JD you gave. Evidence is quoted from your message. Confidence and gap type each hold one value.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The quote gives years and role, but not "live-service". Your content-drop work is the live-service evidence. Say: "For four years I was an associate producer at a puzzle-game studio, and for two of them I ran the content-drop calendar for our main title." Answer slot: if the title ran on live-service mechanics such as events or drops, say which, in your own words. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | Direct match. Lead with the quote itself. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the figures were counted. Presenting is not the same as defining the metric. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote shows written output in use. Say it as the artifact it is, not as a general claim about writing. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | Writing and using the checklist is adjacent to managing it with QA. Make the adjacent case and its limit: "I wrote it, and the QA team still uses it. I have not run its sign-off myself unless I say so." Answer slot: say what part of the QA sign-off process you ran. If none, say so. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting numbers is adjacent to owning the KPIs and the review. Do not stretch it. Answer slot: say which figures you chose to report, and whether you set the metrics or only reported them. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this coordination. Answer slot: describe how you got one update through the teams it touched. If you did not do this, say so and say how you would set it up. |
| F8 | "plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title" (your message) | medium | [grounded] | transferability | You ran one title's calendar, not two. Say: "I ran the calendar for one main title." Do not add a second title. |
| F9 | Leading or managing a team (not in JD text; in the coordination scope) | "Never led a team" (your message) | none | [grounded] | capability | This is your stated negative. Words: "I haven't led a team." Then how you would learn to, as a plan. Never a claim to leadership. |
| F10 | Monetization / in-app purchase experience (not in JD text; implied by live-service KPIs) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Your stated negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn monetization metrics, as a plan. |

**Note on confidence and gap types:** F1, F3, F4, F5, F8 rest on your message alone. None of it has been inspected, so expect probes.

## 4. Prohibited claims

Built locally from the fit snapshot. These claims will not be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars for two titles | Inflated form of F2 and F8. Your quote covers one main title. | "I ran the weekly content-drop calendar for our main title for the last two years." Limit: your material says one title. |
| Owned the post-event review and KPIs | Inflated form of F3 and F6. Your quote says you presented the numbers. | "Presented the monthly retention numbers to the studio head." Limit: your material says presented, not owned. |
| Led a team | Your stated negative (F9). | "I haven't led a team." |
| Worked on monetization or in-app purchases | Your stated negative (F10). | "I haven't worked on a game with in-app purchases." |

## 5. Question banks

Persona weights are in section 8. Types are primary first.

### A. Case / Strategist (highest weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell it in 90 seconds: the cadence (weekly), the title (main), the two years, in your words. Answer slot: if you set any part of the calendar's priorities, say which and how you decided. If you received them, say so. | F2 is your strongest direct match, and Tobias will start here. |
| A2 | "Plan the next two months of live events across two titles. What do you do first?" | CASE | [generic] | Clarify first: which titles, what their current KPIs are, which teams are already committed, what the release slots are. Then sequence by dependency and risk. Name one trade-off. This question needs no claim about your past. | A live version of the JD's two-title line. The guidance makes no claim about your history. |
| A3 | "You're asked to run two titles, not one. Where would your first month go?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran: one main title. Answer slot: if you ever supported a second title's calendar in any way, say how. If you did not, say so plainly and describe how you would take on the second title's calendar in the first month. Never claim two titles. | F8 is the gap. This question presupposes two titles, which the JD raises, so the answer must allow the premise to be false for you. |
| A4 | "Walk me through a single update from plan to release, with design, art, engineering and community involved." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Describe the update's steps and where the checklist sat in them. Answer slot: say which teams you coordinated with and how. If you did not coordinate them, say so and describe how you would. | F7 has no quote. The checklist is your one real anchor, so use it only for the step where it applied. |
| A5 | "Your release checklist is the QA team's. What did they change in it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you know: they still use it. Answer slot: if they changed it, say what, and whether you knew. If you do not know, say so plainly. | F4 and F5. A probe on how far the checklist still reflects your version. |

### B. Data-Driven Prober (weight 4, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the retention number you presented was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption you know of behind the figure, before they do. If you do not know how it was counted, say so. Answer slot: say whether you defined the metric or took it from someone else. | F3. Retention is the JD's stated requirement, so expect a deep probe here. |
| B2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | HIGHEST-ROI PREP. Hold through two follow-ups: say the assumption in your own words, and concede the limit it carries. Do not invent the assumption. If you do not know it, say so plainly. | F3 and the JD's retention requirement. Metric questions get the weakest-assumption move. |
| B3 | "What did the studio head do with the monthly retention numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you know: what you presented and to whom. Answer slot: if you know what changed as a result, say it. If you do not, say so. | Tests whether the number changed a decision. Do not claim an outcome you did not see. |
| B4 | "Tell me what your post-event review looked like." | EXP | [inferred] "Presented the monthly retention numbers to the studio head." | Say what you presented, in your own words. Answer slot: if you ran a post-event review, say what it covered and who saw it. If you did not, say so and describe how you would run one. Never claim you owned the KPIs. | F6. The question presupposes a post-event review, which the JD raises and your material does not show. The answer must allow it not to exist for you. |

### C. Skeptic (weight 4, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The JD asks for live-service experience. You have a puzzle game. What is the difference?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Say what your title did with content drops and events, in your words. Concede the gap plainly: you have not worked on a live-service game outside the content-drop calendar. Answer slot: if your puzzle title ran on live-service mechanics, say which. | F1. The gap is the premise; the guidance does not argue it away. |
| C2 | "Have you ever been accountable for a team's output?" | JD | [grounded] "Never led a team" | Hold the plain acknowledgment: "I haven't led a team." Then give the nearest thing you did, in your own words, and what you would do to lead one. Never claim leadership. | F9. A stated negative with a plain acknowledgment. |
| C3 | "You haven't worked on in-app purchases. How would you own monetization KPIs?" | JD | [grounded] "never worked on a game with in-app purchases" | Hold the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say how you would learn the monetization metrics, as a plan. Never claim monetization experience. | F10. A stated negative. The question presupposes monetization KPIs, which the JD does not state directly; answer whichever branch is true. |
| C4 | "Why should we hire a producer whose largest title is a puzzle game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer with the content-drop calendar, two years, one main title, as the strongest thing you can say. Concede the title type once, plainly. Do not argue the category. | F1 and F2 together. The skeptic wants the gap named before you do. |

### D. Pressure (weight 2, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: what makes you ready to lead a team?" | JD | [grounded] "Never led a team" | Pause. Restate the question. Hold: "I haven't led a team." Then the nearest thing you did, and how you would learn. Hold through two follow-ups before conceding anything real. | F9 under time pressure. The pressure is in the timer, not the content. |
| D2 | "Convince me you can do monetization metrics without ever having worked on in-app purchases." | JD | [grounded] "never worked on a game with in-app purchases" | Hold the plain acknowledgment and the plan. Concede the uncertainty specifically. Do not fold to "I can do it." | F10 under challenge. |

### E. Conversational / Rapport (weight 2, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Ninety seconds: four years, the puzzle studio, the calendar, the checklist, the retention presentation. Each is a quote you already have. | The biography opener is scored. |
| E2 | "What do you find most interesting about live operations?" | VAL | [generic] | Say what you actually like about it, in your words, tied to something you did (the content-drop cadence or the retention numbers). Keep it to two sentences. | Casual, but scored. The guidance makes no claim about your past. |

**Coverage check against the JD:** Requirement "3+ years producing live-service" → A1, C1. "Content calendar" → A1, A3. "Retention metrics" → B1, B2, B3. "Clear written communication" → A5 (the checklist). "Coordinate design, art, engineering and community" → A4 (answer slot). "Own post-event review and KPIs" → B4. "Manage release checklist with QA" → A5. "Plan and run calendar for two titles" → A2, A3.

## 6. Values / principles cheat sheet

**Not included.** No values page was retrieved, and no loop source establishes a values-style round. Research was not available (see Sources).

## 7. Reverse questions

Each is `[generic]` because no profile was available for Tobias. Ask them in your own words.

1. "What does the first ninety days look like for whoever takes this role?" Why it lands: it shows you are planning for the role, not for the interview.
2. "Which of the two titles is further behind on its calendar right now, and why?" Why it lands: it asks about real pressure without assuming anything about the titles.
3. "How do you split ownership of the post-event review between live ops and the title teams?" Why it lands: it tests the JD's "own the post-event review" line directly.
4. "What does a good release checklist cycle look like for QA here, and where does it go wrong?" Why it lands: it connects to your checklist work without claiming more than you did.
5. "How do you decide which retention metrics the studio head sees each month?" Why it lands: it asks about the reporting you did, from the other side.

## 8. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live two-title and update-plan problems | Highest. A hiring manager buys capability and tests the two-title gap. | Clarify, then structure. Say one trade-off. |
| Skeptic | Gaps: leadership, monetization, live-service | High. Your three stated negatives are the obvious probes. | Hold the plain acknowledgment. Then the plan. |
| Data-Driven Prober | Retention numbers and the post-event review | High. The JD's retention line is exactly where probers go. | Name the weakest assumption first. Say what you do not know. |
| Pressure | Timed "what makes you ready to lead" | Medium. Depends on Tobias's style, which is unknown. | Pause, restate, hold two follow-ups. |
| Conversational | Biography opener | Medium. Always there. | Pre-script ninety seconds. |
| Peer Evaluator | Seams with other teams | Low. Not a peer round as assumed. | If it is a peer round, tell us and this changes. |

## 9. Sixty-minute run-of-show (assumes a single hiring-manager session)

| Minutes | Block | What to do |
|---|---|---|
| 0 to 5 | Introductions and setup | Let Tobias set the agenda. Ask what they want covered. |
| 5 to 15 | Your journey (E1) and calendar walkthrough (A1) | Ninety seconds each. Use your own words. |
| 15 to 25 | Retention metrics (B1, B2, B3) | Name the weakest assumption. Hold once. |
| 25 to 35 | Two-title case (A2, A3) | Clarify first. Name one trade-off. |
| 35 to 45 | Update coordination and checklist (A4, A5) | Describe the steps. Say which teams you worked with, or that you have not yet. |
| 45 to 52 | Gaps: leadership, monetization (C2, C3, D1, D2) | Plain acknowledgment, then plan. Hold through two follow-ups. |
| 52 to 58 | Your questions (section 7) | Ask two or three. Choose the one tied to the role's first ninety days. |
| 58 to 60 | Close | Say the one thing you want Tobias to remember: the content-drop calendar you ran. |

## 10. Sources

- Provided documents: the JD text you pasted, and your background message.
- Research: **unavailable**. The WebSearch tool returned a permission denial on all four attempted searches, so no search results were obtained.

**Target accounting:**

Research tier: L1 attempted, searches 0 of 6 (permission denied), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 6. Search attempted; permission denied. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure and persona weights. Search attempted; permission denied. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Current priorities for CO questions. Search attempted; permission denied. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. Search attempted; permission denied. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot. |

## 11. Upgrade menu

- Tobias's public profile or talks, if you can share them → an interviewer read and a tailored reverse question
- The company's values page, pasted → a values cheat sheet
- Saltmarsh's careers page or the recruiter's note on the process → confirmed round structure and persona weights
- Retention metric definitions from your old studio, if you can recall them → sharper B1 and B2 answers
- A recent Saltmarsh news item, pasted → current CO questions
