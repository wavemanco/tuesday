Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-7-canned-dcd86de0/saltmarsh_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. No research ran, so the pack uses only your message and the JD.

The biggest gap is the two-title calendar. You ran one title's weekly content-drop calendar, so the pack's highest-value rehearsal is B1: "Which part of that have you owned yourself?" The honest answer is what you ran and nothing more.

Other points to prepare:
- **Retention reporting:** you presented the monthly numbers. The pack does not claim you owned the post-event review or the KPIs behind it, so verify that before Friday.
- **Gaps you stated:** leadership (B3) and in-app purchases (B4) are answered as plain acknowledgments, followed by a plan.
- **Live-service requirement:** the JD's "3+ years producing live-service" is not shown in your material. B2 covers it.

Say the word and I'll play the Skeptic on B1 for a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Three questions so I can tune the pack:

1. Is Tobias your future manager, or is this a different kind of round? The answer reweights every bank.
2. Do you want me to research Tobias's public footprint and Saltmarsh's values and live-ops strategy? It's a few searches; say yes or no.
3. Was the puzzle title live-service, meaning it got ongoing updates after launch?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, not yet confirmed.
**Round:** 60 minutes, Friday.
**Research:** none run (tier L0). The pack uses only your message and the job description you pasted.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your experience in depth, **JD** the role's stated requirements, **CO** company knowledge (none in this pack, since no research ran), **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.
- Not included, and why: prep triage (no prep time given), interviewer read (name only, no public footprint), values sheet (no published values in hand), delivery coaching (no assessment provided), graded deliverables (none declared).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly calendar, for two years, not a live-events calendar across two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe on a second title likely. If you planned or ran a calendar for a second title, say which and what you decided; if you did not, say so plainly and say how you would plan across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material does not show coordination with design, art, engineering or community. The QA line touches a neighbouring area and does not show whether it reaches this requirement. Answer slot: if you coordinated any of those teams on an update, say which, what each needed from you, and what you decided; if you did not, say so plainly and say how you would set it up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting retention numbers is adjacent to owning a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the KPIs a review reported, or ran a review after an event, say what; if you did not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist, and QA still uses it. Words, rewording only that quote: "I wrote the release checklist, and our QA team still uses it." |
| F5 | "3+ years producing live-service games or apps" (JD, gate) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | hard_gate | Your material does not establish this gate. Four years is shown; that the work was live-service is not. The pack asks nothing about it here; the interview question in B2 asks it, and the question to you below resolves it. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in your own words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented monthly retention numbers. Words, rewording only that quote: "I presented the monthly retention numbers to the studio head." |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The checklist touches writing for a working team. It does not show whether it reaches clear written communication for other audiences. Answer slot: if you wrote something a non-team audience acted on, say what it was and what happened; if not, say so and say how you would write a post-event summary. |
| F9 | Not in the JD: people leadership (your own gap note) | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." Then how you would coordinate without line authority, as a plan in the future tense, never as a past. |
| F10 | Not in the JD: in-app purchase work (your own gap note) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation-side metrics, as a plan. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. Observation, in this pack's analysis: your material says one title, not two. |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Observation: the material shows presenting, not owning. |
| Managed the release checklist with QA | Inflated form of F4 | "I wrote the release checklist, and our QA team still uses it." |
| Worked on live-service titles | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." Observation: the live-service part is not in the material. |
| Led a team | Sourced: your stated negative (F9) | "I haven't led a team." |
| Worked on a game with in-app purchases, or knows its monetisation | Sourced: your stated negative (F10) | "I haven't worked on a game with in-app purchases." |

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the live-events calendar and on coordinating an update | 5 questions. A hiring manager is buying capability; live problems from the role are the usual form. | Clarify before structuring. Name one decision you would need from the team. |
| Skeptic | Probes the two-title gap, the live-service gate, the leadership gap | 4 questions. These are the gaps F1, F5 and F9 record. | Rehearse the single most predictable objection until it is plain. Use a stated limit, not a bluff. |
| Data-Driven Prober | Asks how the retention figure and the checklist were counted | 4 questions. F7 and F4 are the headline items on your record. | Say how each figure was counted, or say you did not count it. Name the weakest assumption first. |
| Pressure | Interrupts or challenges the two-title calendar and the checklist | 2 questions. Lower weight for this round type. | Pause, restate, hold through two follow-ups, concede specifically. |
| Conversational | Casual openers on your journey and on live-service play | 3 questions. Casual questions are scored too. | A 90-second arc built only from quotes in the fit snapshot. |

## Question banks

### Case/Strategist (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you plan the live-events calendar for two mobile titles over the next quarter? Where would you start?" | CASE | [generic] | Clarify first: which titles, what is already committed, which KPI the quarter is judged on, and what each team can absorb. Then structure: objective, cadence, the dependency that breaks first, and risks. Ask one question before you commit to a structure. Speakable in 90 seconds. | The JD's first line is the role's core, and a live problem tests structure before recall. F1 is the gap this question makes most visible, so rehearse the structure here rather than a story. |
| A2 | "A release is four days out and design, art and engineering disagree on what ships. Walk me through coordinating that update." | JD | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Name the decision owner, the cut line, what you would put in writing for each team, and the QA gate before release. The guidance makes no claim about a past conflict. | Tests the coordination requirement. F2 has no quote that reaches it, so this stays a plan. |
| A3 | "Retention dropped 15 percent two weeks after a big event. What do you check first?" | CASE | [generic] | Structure: what changed in the event and when, then the cohort split, then whether the drop began before the event. State a hypothesis early and name what you would need from analytics. | Tests the retention requirement in a live form. A pattern for the problem, not a fact about your past. |
| A4 | "Write the first paragraph of a post-event summary for an event that missed its retention target. What goes in it?" | JD | [grounded] JD line "clear written communication"; JD line "own the post-event review and the KPIs it reports" | Say the order: the result against target first, the one cause you believe in and how sure you are, then the decision you need from the reader. Spoken, in about 60 seconds. | Tests F8 and F3 directly. F8 is discovery, so the guidance says nothing about past writing. |
| A5 | "Walk me through how a live update moves from draft to release through your QA sign-off." | JD | [grounded] JD line "manage the release checklist with QA"; "Wrote the release checklist our QA team still uses." (your message) | Start from the quote in its own words: you wrote the checklist, and QA still uses it. After that, the sign-off sequence is an answer slot: if you ran a sign-off step for a live update, say what it checked; if you did not, say so and describe how you would run it. | F4 is the strongest line on your record for this requirement. The sequence after it is the part the material does not carry. |

### Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role plans the calendar for two titles. Which part of that have you owned yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | **Highest-ROI rehearsal in this pack.** Hold: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if any part of a second title's calendar, or any stage of the first, was yours to set, say which and how you decided; if no such step was yours, say so plainly and return to the calendar you ran. Hold through two follow-ups by returning to that calendar. A limit, not a confession. | F1 is where the two-title requirement presses hardest, so expect this in some form. Deepest rehearsal here, with the limit named before it is asked for. |
| B2 | "Your background is a puzzle game. How did that title get updates after launch?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say it in your words: the content-drop calendar you ran. Answer slot: if the title had ongoing updates and you tracked retention across them, say so and for how long; if it was a different model, say what it was and the nearest live-operations work you did. Do not use the words "live-service" unless you can say what they meant for the title. | F5 is the one gate the material does not show met. This question is where it gets checked first. |
| B3 | "I don't see people leadership in your background. How would you lead a team you don't manage?" | JD | [grounded] "Never led a team" (your message) | Start with the plain acknowledgment: "I haven't led a team." Then the plan: how you would coordinate design, art, engineering and community without line authority, in the future tense. | F9 is a gap you stated; the Skeptic is checking whether you state it without bluffing. |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Name one gap in a line: "I haven't worked on a game with in-app purchases." Then your first 30 days: which metrics you would learn first and from whom. Do not claim monetisation knowledge. | In-app purchases are not in the JD, so this comes up only if asked. It is the honest gap on record. |

### Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted. Which figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say how the figure was counted if you know it, and name the weakest assumption before they do. Answer slot: if you computed the figures, say how; if you presented numbers someone else computed, say that and what you checked. Never reconstruct a method you cannot repeat. | Every headline number gets this probe (F7). The figure is the one on your record. |
| C2 | "How do you know the release checklist you wrote catches what it is meant to?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what you wrote and that QA still uses it, in those words. Answer slot: if you tracked what the checklist missed or how often it was used, say what you tracked; if not, say so plainly and say what you would measure. | F4's quote carries use, not outcome. The probe asks for the scope. |
| C3 | "Which post-event KPIs would you own, and which of them did you report yourself?" | JD | [grounded] JD line "own the post-event review and the KPIs it reports"; "Presented the monthly retention numbers to the studio head." (your message) | Say which retention figure you reported, in those words. Answer slot: if you chose the KPIs a review reported, or ran one after an event, say which; if not, say so plainly and name the KPI you would put first. | F3 is transferability. The probe asks where your reporting ends. |
| C4 | "Which KPI would you put first in a post-event review, and what would make you drop it?" | JD | [generic] JD line "own the post-event review and the KPIs it reports" | Name one KPI, its denominator, and the assumption in it you would defend least. Then the condition that would make you retire it. No claim about past reviews. | Tests the KPI requirement as a plan. |

### Pressure (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run a live-events calendar across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold: restate the question, then answer with that sentence. Concede specifically: you have not run a calendar across two titles. Then say the first thing you would do to close that. Do not fold on the one-title calendar being a real calendar. | F1 is the sharpest challenge on the record. Hold, then concede the specific gap. |
| D2 | "The checklist QA uses. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold once: "I wrote it." Then say what QA changed or added, if you know, and whether anyone else worked on it. Answer slot: if others shaped it, say who and how; if you wrote it alone, say so plainly. | Tests whether the quote's scope survives a challenge. |

### Conversational (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc with three beats, each a quoted sentence: the studio and role, the calendar you ran, the checklist and the retention reporting. No new claims. | Casual openers are scored. The arc is the same material as the fit snapshot. |
| E2 | "What live-service titles are you playing right now?" | JD | [generic] | Name one title you actually play and what its updates are like. Answer slot: if you play none now, say so, and name one you have studied and why. | A casual question on a JD topic. |
| E3 | "Tell me about the team you'd work with most closely day to day." | JD | [generic] | Name the team most central to live updates, and what you would need from it in writing. No claim about past work with them. | Tests the coordination requirement (F2) casually. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1, D1 |
| Coordinate design, art, engineering and community on each update | A2, E3 |
| Own the post-event review and the KPIs it reports | A4, C3, C4 |
| Manage the release checklist with QA | A5, C2, D2 |
| 3+ years producing live-service games or apps | B2 |
| Experience running a content calendar | E1 (and F6 in the snapshot) |
| Comfortable with player-retention metrics | A3, C1 |
| Clear written communication | A4 |
| Not in the JD: people leadership | B3 |
| Not in the JD: in-app purchases | B4 |

## Reverse questions

Each is for the end of the interview. Tobias's own career path is not in the material, so none is tied to it.

1. "What does a successful two-title calendar look like at month six, and what would tell you it is slipping?" Why it lands: it shows you think in terms of how the role is scored.
2. "How are post-event reviews run today: who writes them, who reads them, and what happens after?" Why it lands: it tests the review requirement and shows you care about the loop after the event.
3. "Which team is hardest to keep aligned on an update, and what has worked?" Why it lands: it turns the coordination requirement into a question about the team.
4. "How much of the role sits on the monetisation side, and where does it sit?" Why it lands: it tells you how much of your gap matters here, and that changes your prep.
5. "What would you need to see from a new producer in the first 30 days?" Why it lands: it asks for the scoring directly, in a form the interviewer can answer.

## Sources

Provided documents: your message, containing the job description and your background. No dossier was present.

Research tier: L0, no searches or fetches run. Research consent has not been given.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Would have added a values sheet if a values-style round is detected. None is in this pack. |
| 2. Saltmarsh interview process | unavailable | Would have set the loop structure and confirmed the persona weights, which currently assume a hiring-manager round. |
| 3. Saltmarsh strategy and recent news | unavailable | Would have added CO questions. None is in this pack. |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Would have given an interviewer read and reverse questions tied to his path. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's relationship to the role (manager, peer, or other) → persona weights and reverse questions reweighted
- Research consent → public footprint for Tobias (an interviewer read and a tailored reverse question), and Saltmarsh values and live-ops strategy (CO questions)
- Whether the puzzle title was live-service → F5 becomes grounded, and B2's answer slot resolves
- A second title, or any coordination with the design, art, engineering or community teams → F1 and F2 move out of answer slots
- Post-event review evidence → F3 and C3 get grounded answers
- A `tuesday-dossier.md` → verified-evidence grading for each fit row, and a sharper objection rehearsal
