Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-6-denied-97120b48/1a59e9a4-58d9-4d75-a926-1f728c3510ad/scratchpad/larkfield-systems_engineering-manager_interview_pack.md. It covers all three rounds with a shared fit snapshot, a prohibited-claims list, per-round banks and reverse questions, and a sources section. Web search was refused by the host, so the pack has no company values, interview-process or strategy material. Round C is built on the recruiter's "values and leadership philosophy" wording and your own stories.

The highest-return prep is A2: "You haven't owned a hardware-adjacent roadmap. What would you do on day one…" Say the plain acknowledgment, then a concrete learning plan. I can run that as a live drill with a skeptical hiring manager, and I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions.

Three questions would sharpen the pack:
1. Do you have the posted job description text? My requirements come from your summary, so pasting the posting would make the fit rows quote it directly.
2. Will the leads of your two squads report to you? That decides whether the managing-managers answers are about a plan or about a current setup.
3. Do you want me to retry web research if you grant the permission? It would give the values cheat sheet for round C and the loop structure behind the round weights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager interview pack (loop, three rounds)

Candidate: Yusuf. Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people).

Rounds:
- **A**: Tuesday, 45 min, hiring manager (Director of Engineering, would-be boss)
- **B**: Thursday of the following week, 60 min, panel (two staff engineers, one product manager)
- **C**: the following Monday, 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

Built on: your message only. No posted JD text, no CV, no interviewer names. Web research was refused by the host, so the pack has no company-sourced material (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the role's requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script.
- **Answer slots** are instructions for the interview. They ask nothing back here.
- Everything about your past comes from a quoted sentence of yours, and each quote is tagged with its source.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says a team of six, for three years. It does not show two squads or device services. Say the team you led, at its own size. The device-management domain is the part you would learn. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role text, your message), hiring part | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | none | The quote already reaches hiring in role terms. Lead with the loop you run, in those words. "About 40 interviews" counts interviews, not hires. Never restate it as hires. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role text, your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | The sentence already reaches delivery under pressure. Say it in its own words: a reliability quarter, pushed through against roadmap pressure, and the team's burden dropped 60%. No new figures. The 60% raises the defend-the-number slots in A4. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role text, your message), growth part | none given | none | [grounded] | discovery | Answer slot: if you helped an engineer into a bigger role, say who and what you did; if not, say so and describe how you would approach growth for 11 engineers. |
| F5 | "partner with hardware and product on roadmap" (role text, your message) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] derivation: adjacent to roadmap negotiation, not partnership | transferability | Coaching note only. Your material shows roadmap pressure held once, on reliability. It does not show partnering with hardware or product on a roadmap. |
| F6 | "partner with hardware and product on roadmap" (role text, your message), hardware-adjacent part | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Plain acknowledgment, keeping the negative whole: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan, never as a past. |
| F7 | Managing managers (inferred from "Lead two squads"; the role text does not say the squads have leads) | "I've never managed managers" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never managed managers." Then what you would do with leads under you, as a plan. |

Notes on the rows:
- The role text does not mention location, office days or start date. The material is silent on those, so there are no gate rows. Question 2 below asks about them.
- Confidence is `medium` for F1 to F3 because each is your own specific sentence with no inspectable artifact behind it.
- F5 is `low`: it appears only as a coaching note, never as a claim about your history.

## Where your experience is thin, and how to handle it honestly

1. **Managing managers (F7).** Not done. Say so in one plain sentence, then give the plan.
2. **Hardware-adjacent roadmap (F6).** Not owned. The strongest move is a specific learning plan, not a bridge from software roadmaps.
3. **Device-management domain.** Your material is silent. Expect a probe. Answer with how you would learn it, in your own words.
4. **Scale.** Team of six to two squads, and 11 engineers. The gap is real. Name it and say what changes in your approach.
5. **Growth of engineers (F4).** Nothing quoted. Answer slot, honest either way.

The rule for all five: say the gap once, plainly, and do not over-apologize. Then show a specific next step you would take. Do not add a story you have not told me.

## Prohibited claims (not coached in any cell)

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I have led device services" | Inflated form of F1, "3 as a team lead of 6" | "Three years as a team lead of six." The limit is the pack's observation: your material shows a team of six, not two squads. |
| "I've owned a hardware-adjacent roadmap" | Negative you stated in F6 | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot. |
| "I've managed managers" | Negative you stated in F7 | Plain acknowledgment: "I've never managed managers." No slot. |
| "I cut on-call burden by 60%" | Inflated form of F3: the team's figure became your cause | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| "I hired 40 engineers" | Inflated form of F2: interviews became hires | "About 40 interviews last year." |

## Round A: hiring manager (Tuesday, 45 min)

**Persona weights.** No interviewer profile, so these are relationship priors. Hiring manager priors are Case plus Skeptic. Skeptic is top weight: the role's hardest gaps (F6, F7) are where a would-be boss will test you. Case is second, since they buy capability and want to see a plan. Prober is lower, because the numbers come up mainly in other rounds. Depth follows weight: the top persona gets the most questions. In this bank, Skeptic has three, Case has three, Prober has two.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you do in your first 90 days leading two squads on device-management services?" | CASE | [grounded] "Lead two squads building device-management services" (role text, your message) | Clarify first: which squads, what their roadmaps look like, where the hardware dependencies sit. Then sequence: listen before deciding, delivery health, the hardware interfaces, and one change you would make early. Say the plan as a plan. Do not claim past device-service work. | The role's headline. Speak to the scope without claiming past scope (F1 is the bridge). |
| A2 | "You haven't owned a hardware-adjacent roadmap. What would you do on day one when hardware dependencies drive the plan?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | **Highest-ROI prep in the pack.** Start with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, in order: the hardware leads' schedule, lead times, what a firmware release gates, and which commitments you would not make until you had seen them. Hold through two follow-ups by returning to the plan. Concede specifically, e.g. "I don't yet know how your hardware release gates work." Never claim a hardware roadmap you did not own. | F6 is the hardest gap, and this question will come in some form. A rehearsed, non-defensive answer changes the round. |
| A3 | "If one of your squads has a tech lead who outranks you on the technical call, how do you work with them?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then the decision rule you would use, and how you would agree it with the lead in the first week. Name the rule as yours to propose, not as a practice you have run. | F7. The question is a hypothetical about the role, not a claim about your past. |
| A4 | "That 60% on-call drop. How was it counted, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say what you measured and over what period, in your words. Weakest-assumption move: name the assumption you would defend least before they do. Answer slot: if you pushed the quarter through, say what the push consisted of. If others made the call, say so. If you do not know how it was counted, say that. | F3. A figure raises these four defend-the-number questions. Do not explain a method you cannot repeat under a second probe. |
| A5 | "How do you decide a candidate is good enough to hire on your loop?" | EXP | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | Describe the loop in your own words: the stages, what each assesses, and how the decision gets made. Answer slot: if you set the decision rule, say so; if calibration was someone else's, say that. Keep the figure as interviews, not hires. | F2. The loop is your strongest concrete material, and the hiring manager will check it against the role's hiring line. |
| A6 | "Tell me about an engineer you helped grow. What did you do?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role text, your message) | Open prompt. Selection scaffold: pick someone whose growth you were in the room for, and say what you did and what happened. If no such case comes to mind, say so plainly, then describe how you would approach growth for 11 engineers. | F4, the growth requirement with no quote. The honest branch is the answer. |
| A7 | "What makes a hardware team's commitments different from a software team's?" | CASE | [generic] | Structure: lead times, test rigs, release gates, the cost of a field update that cannot be rolled back. Say what you would ask the hardware lead first. | Tests the partnership requirement without asking about your past. |
| A8 | "Your team's reliability quarter ran against roadmap pressure. How would you run that trade-off across two squads?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Clarify, then decide the trade-off. You may use the reliability quarter as one reference point, at its own scope: say what you pushed through, and nothing beyond it. | F3 and F5. Turns your one relevant experience into a reference for the role, without claiming it is the same kind of trade-off. |

## Round B: panel (Thursday, 60 min)

**Persona weights.** Blend by member, since no names are given. Staff engineer 1: Data-Driven Prober plus Case. Staff engineer 2: Pressure plus Skeptic on hardware. Product manager: Peer Evaluator plus Conversational. Weights: Prober 2 (B2, B3), Peer 2 (B1, B6), Case 2 (B5, B8), Pressure 1 (B4), Skeptic 1 (B7).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and product, and what happens when we disagree on priority?" | JD | [grounded] "partner with hardware and product on roadmap" (role text, your message) | Propose seam principles, not a seam you have not seen: who decides scope, how disagreements get escalated, and how you would keep product's plan honest. Do not pretend to know their seam. | Peer probe on the partnership requirement. |
| B2 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Weakest-assumption move: name it in your words before they do. If you do not know a baseline assumption, say so. Do not supply one. | The prober's defend-the-number question. Same figure as A4, asked more deeply. |
| B3 | "Walk me through how you calibrate your interviewers on the hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | Describe what calibration you actually did. If you ran a loop without a calibration step, say so and say what you would add. Keep "about 40 interviews last year" as interviews. | F2 under a second probe. Calibration is the detail they will ask for. |
| B4 | "That 60%. How much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold: "I pushed the reliability quarter through" is your own claim. Hold it through two follow-ups. Concede specifically where you cannot back something, e.g. "The team's burden dropped; I can't say how much of that was the quarter alone." Never fold on the part you did. | The pressure stem. Hold-then-concede. |
| B5 | "A device telemetry feed goes silent for one fleet segment. What do you want to know first?" | CASE | [generic] | Structure: scope (which segment, since when), which signals are trustworthy, what changed on the device side, who owns the hardware fix. If the failure touches hardware you have no record in, say so and name who you would route it to. | Live problem from the device-management domain. No claim about your past. |
| B6 | "How do you handle credit when work spans teams?" | Peer | [generic] | Name the principle first: credit follows who decided and who did the work, and you name partners by name. Keep it to principles unless you have a specific case. | Peer stem. Collegial credit probe. |
| B7 | "Your material doesn't show a hardware roadmap. What would you change first?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then one change, stated as a plan: the first conversation you would have with the hardware lead, and what you would ask them. | F6, asked by a staff engineer who will judge the technical plan. |
| B8 | "Sketch how you'd grow a senior backend engineer toward staff." | CASE | [generic] | Structure: the gap between their current scope and staff scope, the evidence they would need, the two or three stretches you would give them, and how you would check progress. | F4, the growth requirement, asked as a design problem. |

## Round C: VP Engineering (Monday, 30 min)

**Persona weights.** The recruiter named this round "values and leadership philosophy", which makes it a values round. Values/Behavioral is top weight, with four questions. Skeptic has one (on the manager gap). Conversational has one (the opener). The loop's published values are not in hand, so there is no values cheat sheet below. Each value question is answered from the stories you have, or from a selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your leadership philosophy, in your own words?" | VAL | [generic] for the structure; your own words for the content | Two sentences, your own. Then one story that shows it. Keep the philosophy as belief, not as a record of what you have done. | Opening VAL. The recruiter's phrase is the raising source. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Nearest story from your material: the reliability quarter, at its own scope. Beats: what the roadmap asked for, what you pushed through, what happened to the team's burden. Attribution: "my team's" figure, "I pushed" the quarter. If no such time comes to mind, say so plainly, then give the nearest thing you have, as above. | F3 is your nearest values story. Scored for a hard truth told, not a virtue claimed. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | none given | Selection scaffold: pick a time a customer's need, rather than a team target, decided the call. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. Do not invent a customer. | No quote reaches this value. The honest branch is the answer. |
| C4 | "You've never managed managers. Why would this be different for you?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then the way you would learn it in this role, specific and as a plan. Do not argue that it would be different. Name what would show them you can do it. | F7 at VP altitude. Hold-then-concede if pressed. |
| C5 | "Walk me through the journey." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc: nine years of engineering, three as a team lead of six, the payments company now, and why this role. Speak the numbers as you gave them. | Friendly opener, still scored. |
| C6 | "How do you decide what your team says no to?" | VAL | [generic] | Principles first: the criteria you use, who you consult, and how you tell the team. Add one case only if you have one; otherwise say the principle. | Leadership philosophy at VP altitude. |
| C7 | "What would you want your managers to do when a roadmap commitment becomes impossible?" | CASE | [generic] | Say what you would expect: early notice, a stated trade-off, and a decision by a named owner. Do not describe a practice you have run with managers. | A values probe on candour that does not ask for your past. |

## Reverse questions

No interviewer names were given, so none is tied to an interviewer's own path. Every question below is role-generic.

**Round A (hiring manager)**

- "What would success look like at 90 days for whoever takes these two squads?" Why it lands: it tells you how they will judge the first quarter, and invites them to name the priorities in their own words.
- "Which hardware dependency has slipped most in the last two quarters, and why?" Why it lands: it shows you want the real constraint, not the brochure version, and it tests A2 from their side.

**Round B (panel)**

- For the product manager, a reciprocity question: "What could a new engineering manager do in their first month that would genuinely help your team?" Why it lands: a peer conversation, not a status check. It shows you are thinking about what you bring to their work.
- For staff engineer 2: "Where does the device-to-service interface break most often today?" Why it lands: it turns the hardware gap into a concrete technical question.
- For staff engineer 1: "When a reliability fix and a roadmap item compete, how does that call get made here?" Why it lands: it links your one real experience (F3) to how they actually decide.

**Round C (VP Engineering)**

- "What decision in the last year would you most want the next engineering manager to have made differently?" Why it lands: it shows the values in practice, not on the wall.
- "What does the best manager here do in the first six months that a strong manager elsewhere does not?" Why it lands: it puts your philosophy question in their terms.

## Sources

**Provided documents:** your message only (role text, background, the three rounds).

**Research tier: L0 (a deeper tier was attempted and refused).** Three search calls were sent in this turn. The host refused all three before any result came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have built the values cheat sheet (section 10). Round C therefore uses the recruiter's phrase and your stories, not published values. Query refused: "Larkfield Systems company values". |
| 2. Larkfield Systems engineering manager interview process | unavailable | Would have set round weights from the loop's documented structure. Query refused: "Larkfield Systems engineering manager interview process". |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have built the company-knowledge (CO) questions. Query refused: "Larkfield Systems industrial IoT device management strategy". |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Engineering Manager JD | skipped | Your role text fixes the requirement list, so a representative JD would not change the fit snapshot. |

## Upgrade menu

- The posted JD text → F2 to F5 become quoted from the posting rather than from your summary; A1 and A6 are retuned to its exact wording.
- Your interviewers' names for each round → per-member personas, an interviewer read, and tailored reverse questions.
- Permission for web search (or your own pasted company values page) → the values cheat sheet for round C, the company-knowledge questions, and the loop structure behind the round weights.
- The recruiter's note on process details, and whether the loop has any take-home or presentation → graded deliverable sections.
- How the 60% on-call figure was measured (what was counted, over what period) → the defend-the-number answers in A4 and B2 become concrete.
