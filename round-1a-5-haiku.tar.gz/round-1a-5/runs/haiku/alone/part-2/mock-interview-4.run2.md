Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-4-denied-9661c515/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round from your pasted dossier. Web search was refused in this session, so the pack has no Quartzline values, interview-loop details or current strategy. It says so in its Sources section.

The highest-return rehearsal is A1: the "why hire you into a PM role" objection the dossier named. It is the pack's deepest bank entry.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also update `tuesday-dossier.md` with a `pack_feedback` section once you've rehearsed, recording the gaps the prep exposed. And I can convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Interviewer:** not named. **Relationship:** hiring manager. **Round:** 45-minute conversation, Thursday 2026-11-26.
**Built from:** the pasted dossier (`tuesday-dossier.md`, version 1.1, decision `conditional_go`). Web research was refused in this session, so company values, loop structure and current strategy are absent (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Name | What it scores |
|---|---|---|
| JD | Role and JD-driven | Whether you can do the listed job, including its gaps |
| EXP | Experience deep-dive | Whether the claims on your record survive scrutiny |
| CASE | Hypothetical or live problem | Structure and reasoning on a problem from the role |
| CO | Company and strategy | None in this pack: research did not run |
| VAL | Values and behavior | None in this pack: no values page and no values-style round |

## Fit snapshot

Requirements are quoted from the dossier's role profile. Evidence is quoted from the dossier's verified evidence. Confidence and gap type follow the dossier where it grades a row. The dossier does not grade R2 or R3, so F2 and F3 are this pack's own reading, marked `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, dossier role profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, verified_candidate_evidence 1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row, verified_candidate_evidence 3) | low | [grounded] | transferability | Your material carries adjacent work at its own scope: the integrations and the roadmap-input sessions. It does not show a product management title or role, and the dossier records that limit. Say the work at its own scope and name the limit yourself. The title is the requirement you have not met. |
| F2 | "Shipped API or platform products" (JD, dossier role profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, verified_candidate_evidence 1) | low | [inferred] | discovery | Your material touches this requirement without showing whether it reaches it. Integrations of the vendor's APIs are not a platform product you shipped. Answer slot: if you shipped an API or platform product, say which and who used it. If none was yours to ship, say so plainly and name the nearest thing your material carries: the go-lives you ran. |
| F3 | "Technical fluency: API docs, schemas" (JD, dossier role profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, verified_candidate_evidence 1); "Wrote the internal integration playbook her team uses" (dossier row, verified_candidate_evidence 2) | low | [inferred] | discovery | The architecture step touches this requirement, but nothing in your material shows work on schemas or API documentation. Answer slot: if you wrote or reviewed schemas or API docs, name them and what partners needed from them. If not, say so plainly and say how you would build that fluency. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, dossier role profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row, verified_candidate_evidence 3) | medium | [grounded] | presentation | The quote already reaches customers and product in other terms, so reword only the quote. It does not show sales or engineering. Expect a probe on what the sessions changed: the dossier marks this medium, with limited inspectable proof. |
| F5 | "Agile delivery experience" (JD, dossier role profile R5, preferred) | none given | low | [grounded] | discovery | Your material does not establish delivery inside a product organization. Answer slot: if you have run delivery with an engineering team, say how, in your own words. If not, say so plainly and return to the phases your material does carry: scoping, requirements, architecture, UAT, go-live. |
| F6 | Owning a roadmap and prioritization authority (dossier acknowledge_gap area, R1 sub-claim) | none given | none | [grounded] | capability | The dossier records that you have not owned a roadmap or set priorities for a squad. Words: "I haven't owned a product roadmap." Then how you would learn it, as a plan and never as a past. No slot: the dossier's acknowledge_gap area forbids a bridge here. |

Confidence and gap type come from the dossier where it grades a row. F2, F3 and F5 grading is this pack's own and is marked `[inferred]` or sits in a discovery row.

## Prohibited claims

The dossier's `prohibited_claims` bind every cell in this pack. Each entry below is coached only in its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | Plain acknowledgment, sourced to that field: "I haven't held a product manager title." |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap area | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | dossier prohibited_claims | Plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." |
| Set the roadmap from the roadmap-input sessions (inflated form of F4) | built locally: a wider form of "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote at its own scope. The limit is this pack's observation, not a first-person negative: your material says the sessions fed client evidence to product, not who decided. |
| Built the vendor's APIs (inflated form of F1) | built locally: a wider form of "Led 30+ end-to-end client integrations of the vendor's REST APIs" | The quote at its own scope: you led integrations of the vendor's APIs for clients. |

## Persona table

Depth follows weight. Weights are relationship priors for a hiring manager, adjusted by the dossier's named objection and its unknowns. The loop is unknown, so no adjustment from it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title gap and the missing roadmap | High. A hiring manager is buying capability and derisking gaps, and the dossier names the objection | Rehearse the one objection until it is boring. Use a bridge only from adjacent work you stated, and say the limit plainly. Calibrated candor, not bluffing | 5 |
| Case/Strategist | Live problems from the role: decision rights, adoption, a stalled partner | High. A hiring manager tests whether the role's problems can be structured | Clarify, then structure, then name the metric and what you would need first. Name the adoption baseline as unknown | 5 |
| Data-Driven Prober | Asks how the 30+ figure was counted and what the adoption measure is | Medium to high. The dossier flags the roadmap-input sessions for a probe, and adoption metrics are an open unknown | Say how each figure was counted, or say you do not know. Name the weakest assumption before it is raised | 4 |
| Conversational | An opener, a casual walk through your background | Medium. A 45-minute slot opens with this register, and casual questions are still scored | A 90-second arc, with the title gap named before it is asked | 2 |
| Pressure | Time-boxed challenge to the title and to what was your call | Low to medium. Possible if the hiring manager is testing composure | Pause, restate the question, hold through two follow-ups, then concede the specific gap | 2 |

## Question banks

Question IDs are letter-by-persona. A question's type comes from the five-type key above. Answer slots are instructions for the interview: each one ends without a question mark and asks for no reply here.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; the acknowledgment sourced to dossier prohibited_claims | Open with the title, plainly: "I haven't held a product manager title." Then the work at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "Ran quarterly roadmap-input sessions feeding client evidence to product." Then the limit: you have not owned a roadmap or set priorities for an engineering squad. Then the ramp, as a plan and not a past: name the two calls you would need to learn first (which roadmap decisions are yours, and how the squad leads' priorities get ranked), and how you would learn them in the first 30 days. Hold through two follow-ups: if pressed on why the title matters, return to the integration record as the thing you can show. Concede one specific thing: "The roadmap call is the part I haven't done, and it's the part I'd want to see first." Never fold to "I'm ready to be a PM." | The dossier named this objection, so it is the highest-return rehearsal in the pack and gets two follow-up levels. It is the question every version of this interview returns to (F1, F6). JD content; Skeptic delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area, "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it first, in your own words: "I haven't owned a product roadmap, so that is where I'd be weakest on day one." Then the ramp as a plan: sit with each squad lead to find which decisions are theirs and which are the product role's; take the partner discovery conversations early. No slot: the acknowledge_gap area forbids a bridge here, and the answer is the acknowledgment plus the plan | F6 is a capability gap the dossier records, so the honest answer is short and plain. The stem is the Skeptic's standard form |
| A3 | "Describe how you have run delivery with an engineering squad." | JD | [grounded] "Write specs and drive delivery with two engineering squads" (JD, dossier role profile) | Answer slot: if you ran delivery with an engineering team, say how, in your own words. If there was no such step, or it was not yours, say so plainly and return to the phases your material does carry: "scoping, requirements, architecture, UAT, go-live." Do not describe a cadence you did not run | F5 is clarify: the evidence may exist but is not established. The question's premise is the JD's line, and the second branch allows it to be false |
| A4 | "Two squad leads disagree on the sequencing of partner API work. What do you do in the first week?" | CASE | [generic] | Clarify who holds the call and what each lead is optimizing for before choosing a side. List the partner commitments on each side. Propose a decision path with the squad leads rather than around them. Say what you would need to see from partners to decide. Make no claim about your past | A live problem from the role, and the dossier's first unknown: decision authority against the two squad leads. CASE, with JD for the decision-rights content. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A5 | "Which API or platform product have you shipped, and who used it?" | JD | [grounded] "Shipped API or platform products" (JD, dossier role profile R2); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you shipped an API or platform product, say which and who used it. If none was yours to ship, say so plainly, then name the nearest thing your material carries: the go-lives you ran. Do not call the integrations a platform product | R2 is a must-have and F2 is discovery. The premise is the JD's line, and the second branch allows it to be false |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would measure whether partner API adoption is working. What do you need to know first?" | CASE | [generic]; JD "Define and track adoption metrics" (JD, dossier role profile responsibility) | Clarify the objective, then segment partners by type or tier, then give one definition of adoption and two or three supporting metrics. Say you do not yet have the current baseline and ask for it. Give no numbers you were not given | Adoption metrics are a named responsibility, and the dossier lists the current baseline as an unknown. The honest way to rehearse it is to ask for the baseline, not to supply one |
| B2 | "A partner integration stalls after go-live. Diagnose it." | CASE | [generic]; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify which partner and what "stalled" means. Then split the cause: onboarding, documentation or schemas, UAT, and ownership on each side. Say where you would look first. Your integration work went through UAT and go-live, so you can describe where in those phases stalls tend to start. Do not claim you have diagnosed one | Partner discovery and post-go-live adoption are both in the responsibilities. CASE, with JD for the partner content |
| B3 | "Of the four things this role owns, which would you take first, and why?" | JD | [grounded] "Own the roadmap for the partner-facing API platform"; "Run discovery with integration partners"; "Write specs and drive delivery with two engineering squads"; "Define and track adoption metrics" (JD, dossier role profile responsibilities) | Pick one and justify it by what you would need to learn first. Prefer the one whose first step you can start without roadmap authority, such as partner discovery. Name the roadmap as the thing you would earn rather than start with. Never claim you already run any of these | This is the dossier's responsibility list asked directly. It tests whether you can see the role's order of work without claiming its authority |
| B4 | "Adoption on one partner tier drops 20 percent quarter on quarter. Where do you start?" | CASE | [generic] | Check first that the drop is measured the same way across both quarters. Check the denominator. Segment by tier and cohort. Then talk to partners who stopped, before deciding anything. Do not invent a baseline; say that the current one is the first thing you would confirm | A Case stem on the adoption measure, which the dossier lists as unknown. CASE, with JD for the metric responsibility |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your 30 integrations — how was that count made, and which assumption behind it would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what counted as end-to-end and where the list came from, in your own words. Name the assumption you would defend least before it is raised. Say which part was yours and which was the team's. If you cannot say how the count was made, say that plainly | The headline figure draws the probe. The four defend-the-number slots apply: how counted, what it is sensitive to, the weakest assumption, and which part was yours |
| C2 | "Your integration playbook — who uses it, and how do you know?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what the playbook covers and who uses it, in those words. If you have not checked how much it is used, say so, and say how you would check. The playbook is inspectable, so offer it as the artifact | The dossier marks the playbook high-confidence and inspectable. A prober will ask about use, which the material does not establish |
| C3 | "Walk me through an API schema or doc you wrote or reviewed. What did a partner need from it?" | JD | [grounded] "Technical fluency: API docs, schemas" (JD, dossier role profile R3); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you wrote or reviewed a schema or API doc, name it and what partners needed from it. If not, say so plainly, then name the architecture step, which is the part of the integrations you can describe, and how you would build schema fluency | F3 is discovery: the material does not show schema work. The premise is the JD's line, and the second branch allows it to be false |
| C4 | "Which sales or engineering people did you have to win over on a partner deal, and how?" | JD | [grounded] "Stakeholder management across engineering, sales, customers" (JD, dossier role profile R4); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you worked with sales or engineering on a deal, name the group and what you did. If not, say so plainly, then describe the client and product stakeholders you did work with, in the terms of the quote: client evidence carried to product | F4 is presentation: the quote reaches customers and product, not sales or engineering |
| C5 | "What would you need to see in the adoption data to believe a partner integration is really in use?" | CASE | [generic] | Name the event that counts as use, the window it is counted over, and what would make the count misleading, such as test traffic or one large customer. Say you would confirm the current baseline before deciding. Make no claim about any data you have seen | Adoption is named as a responsibility and the baseline is unknown. Probers ask this to test whether a figure can be trusted |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the last few years." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. Then name the title gap before it is asked: "I haven't held a product manager title; that's the gap I'd close first." Keep to what the quotes say | A casual opener is still scored. Naming the gap in the arc means the Skeptic does not have to find it |
| D2 | "What's the one thing you'd want to get your hands on in the first month?" | JD | [generic] | Name one concrete thing and why: the current adoption baseline, or the list of roadmap decisions that are yours. Do not answer "I think you've covered everything" | The rapport register still scores the answer, and the reverse questions in this pack give you the things to name |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; the acknowledgment sourced to dossier prohibited_claims | Pause. Restate the question in your own words. Hold the position: the integration record is what you can show. Concede one specific thing: "They have the title and the roadmap, and I would be starting that part." Hold through two follow-ups before conceding anything more | The objection from A1 under time pressure. Holding a position you can back is the skill here |
| E2 | "The roadmap sessions — how much of what came out of them was actually your call?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you made any call that came out of a session, say which. If none was yours, say so plainly: the sessions fed client evidence to product, and that is what you carried. Hold, then concede the specific limit | F4 is presentation, and the inflated form (setting the roadmap from the sessions) is on the prohibited list. The second branch is the honest answer |

## Coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience (transferability) | A1, A2, D1, E1 |
| R1 sub-claim: owning a roadmap and prioritization authority (capability) | A1, A2, B3 |
| R2: Shipped API or platform products | A5 |
| R3: Technical fluency, API docs and schemas | C3 |
| R4: Stakeholder management across engineering, sales, customers | C4 |
| R5: Agile delivery experience (preferred) | A3 |
| Responsibility: own the roadmap | A2, B3 |
| Responsibility: run discovery with integration partners | B2, B3 |
| Responsibility: write specs and drive delivery with two squads | A3, A4 |
| Responsibility: define and track adoption metrics | B1, B4, C5 |
| Dossier unknown: decision authority against the two squad leads | A4, A2, reverse question 1 |
| Dossier unknown: current adoption baseline | B1, B4, C5, reverse question 2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's first unknown: the JD asserts decision authority and does not show it. The answer tells you the scope you would be in |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second unknown. The answer tells you whether you would start from a number or have to define one |
| 3 | "Who held this seat before, if anyone, and what made the role hard for them?" | Tests whether the seat is new, and what the last holder's problems were, before you accept the scope |
| 4 | "When the two squad leads disagree on sequencing, how is that decided in practice?" | Tests the decision rights that A4 rehearses, in the interviewer's own practice rather than in a case |
| 5 | "Which two or three partner integrations does leadership watch most, and why those?" | Shows you want the real priorities, and tells you which adoption metric the business actually uses |

## Sources

- **Provided documents:** the pasted `tuesday-dossier.md`, version 1.1, dated 2026-08-14. Sections consumed: `handoff_to_mock_interview` (verified evidence, uncertain areas, likely objection, risks, employer questions, prohibited claims), `role_profile` (requirements R1 to R5, responsibilities, unknowns), and `decision` (context only). The dossier has no `evidence_map`, `evidence_state` or `risk_register`, so F2, F3 and F5 grading is this pack's own.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. Three searches were sent and all three were refused by the host.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | The values cheat sheet. Not built because the round is not values-style, so the sheet would not apply here |
| 2. `Quartzline interview process Product Manager Platform APIs` | unavailable | The loop structure. Persona weights are relationship priors, not loop-adjusted |
| 3. `Quartzline strategy` and recent news | unavailable | A company and strategy question. Without it the pack has no CO bank |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative JD | skipped | The dossier's role profile fixes the fit snapshot and the JD-tagged questions |

Queries sent, each refused: "Quartzline company values"; "Quartzline interview process Product Manager Platform APIs"; "Quartzline partner API platform news".

## Upgrade menu

- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own career path
- The full job posting text → a verbatim quote for each requirement and responsibility, where the dossier only carries its summary lines
- The recruiter's notes on the round → confirms the loop; any declared take-home or presentation gets its own build section
- The integration playbook's contents, if you can share them → F3 can quote what it covers, and C2 can cite the artifact directly
- The current adoption baseline, if the recruiter can share it → B1, B4 and C5 can name the real figure rather than asking for it
- Deep research at the L2 tier, once: a company strategy brief, interviewer and team talks, loop reports for this role family, and recent organization news. Up to 6 further searches and 2 fetches, a few minutes of research. It cannot run until the host permits search
