Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-7-canned-a983c933/saltmarsh_live_ops_producer_interview_pack.md`. I built it for a hiring-manager round, using the 60-minute "Outage Hour" that Saltmarsh's careers page describes.

Two things to plan around:

- **The highest-ROI prep is the in-app purchases question (B1).** You've never worked on a game with in-app purchases, and Saltmarsh's own news page says two titles are moving to season passes. Expect that probe. The pack gives you the stated-fact hold and a plan for closing the gap, and it avoids claiming any experience you don't have.
- **Team leadership is the second gap (B2).** The JD doesn't require it, but Saltmarsh is retiring per-title teams for a single live-ops group. Answer with the plan, not a past.

Things I'd want you to know before Friday:

- The Outage Hour includes a live-incident tabletop, so rehearse the A1 case. It's a live problem, not a question about your past.
- Tobias's GDC 2026 talk, "Patch Notes Are a Promise," is about patch notes matching what shipped. He was previously a QA lead. Your release checklist is the strongest bridge to that. The pack gives you the mirror, but don't claim a QA background.
- The Larkspur details come from a search snippet, not the full page. Read the page yourself before you cite the numbers or dates.

Offers, neither pushed:

- **Drill:** I can play Tobias in a live rehearsal. Say which persona and question you want, or I'll start with the Skeptic on B1.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

One question: is this the Outage Hour round, a 60-minute interview with Tobias as hiring manager? If it's a different format, the persona weights and the question banks change.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_ops_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager. Round: built as a hiring-manager round, the 60-minute Outage Hour described on Saltmarsh's careers page. Friday.

## How to use this pack

- **Personas** describe how a question arrives (style). **Types** describe what is being scored.
- Type key: **JD** = the role's stated responsibilities; **EXP** = your past work, probed; **CASE** = a live problem from the role; **VAL** = behaviour against Saltmarsh's published values; **CO** = company and strategy knowledge.
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds.
- Every quote in the Provenance column and the fit snapshot is a sentence you wrote, or a sentence from the JD or a Saltmarsh page, copied exactly.

## Fit snapshot

Requirements are quoted from the JD you pasted, unless the source column says otherwise. Your evidence is quoted from your message, because no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title and a weekly content-drop calendar, not live events across two titles. Keep the words there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned a calendar for more than one title, say which and how; if you did not, say so plainly and say how you would sequence one calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with design, art, engineering or community. Answer slot: if you coordinated any of those teams on an update, say which and what you did, in your own words; if you did not, say so plainly and say how you would set up that coordination for an update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting retention numbers is not the same as owning a post-event review or the KPIs it reports. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs a review reported, say which; if you did not, say so plainly and say what you would put in a post-event review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Direct match. Expect a probe on what the checklist catches, since "still uses" is your claim to defend. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years at a puzzle-game studio reach the years. Your material does not say whether that title was live-service. Bridge: "For four years I was an associate producer at a puzzle-game studio." Answer slot: if asked whether the title was live-service, say what made it ongoing, in your own words; if you cannot say, say so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct match. The two years is your figure; do not expand its scope. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge rewords only the quote: "I presented the monthly retention numbers to the studio head." Expect a probe on how retention was defined. Answer slot: if you know the definition, say it; if it was set by someone else or you do not know it, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | presentation | The quote reaches written communication only in part: a checklist read by QA. Bridge: "I wrote the release checklist our QA team still uses." Do not claim more written work than that. |
| F9 | "retires per-title event teams in favour of a single live-ops group" (Saltmarsh news page, search result, not fetched) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would coordinate a group you do not lead, said as a plan and never as a past. |
| F10 | "moves Tidepool Tactics and Lantern Row to a season-pass model" (Saltmarsh news page, search result, not fetched) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation side, said as a plan and never as a past. |

Gap types in this table follow the routing rule in the skill's output template. Confidence and gap type are separate calls: F4 is medium because it is a stated fact with limited proof, and its gap is none because the quote already reaches the requirement.

The JD does not name team leadership or in-app purchases. Both come from Saltmarsh's own news page, which says the per-title teams are being retired and that Tidepool Tactics and Lantern Row are moving to season passes.

## Prohibited claims

These are claims this pack will not coach, and why. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or a live-ops group | Stated negative: "Never led a team" (F9) | "I haven't led a team." No slot asks about leadership practice. |
| Ran the live-events calendar for two titles | Inflated form of F1 | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says one title. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The material says presented, not owned. |
| Worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" (F10) | "I haven't worked on a game with in-app purchases." |

Not on the list: coordinating design, art, engineering or community teams (F2). Your material is silent on it, so it is an answer slot, not a claim to block.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: an outage in a live event, planning two titles | High. Hiring-manager priors, and the careers page says the round is a live-incident tabletop. Weight 5 | Clarify, then structure, then decide. Think aloud. |
| Skeptic | Quiet probing of the two stated gaps | High. Two stated gaps (F9, F10) and the role's shift to a single live-ops group. Weight 4 | Hold the stated facts, then state how you would close each gap. Never bluff a gap. |
| Data-Driven Prober | Follow-ups on retention numbers and KPI definitions | Medium. Retention is a JD requirement and your only metric evidence (F7). Weight 3 | Say how each number was counted, if you know. If you do not, say so. |
| Values / Behavioural | The Outage Hour's values conversation, mapped to published values | Medium. The careers page names a values conversation. Weight 3 | Map a story to each value only where your material carries one. Otherwise, say so. |
| Conversational / CO | An opener, a casual question on the shared calendar or the season-pass move | Medium. Casual questions on hot topics are still scored. Weight 3 | Hold a 90-second arc. Answer CO questions from the news page, and say what you have not done. |

Weights are relationship priors (hiring manager: Case and Skeptic), adjusted by the careers page's round format. The round's values conversation puts Values on the list.

## Reading the interviewer

Public footprint only.

- **Career pattern.** A GDC 2026 talk titled "Patch Notes Are a Promise", given by Tobias as Head of Live Operations at Saltmarsh. The talk describes Tobias as previously a QA lead at a console studio. Its argument is that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications.** Expect questions about the gap between what was promised and what shipped. Your release checklist (F4) is a QA artifact, so the QA angle will land with Tobias.
- **Mirror opportunity.** Tobias's QA background and your release checklist are both QA-side work. Quote-bound: "Wrote the release checklist our QA team still uses." (F4, your message). This is a mirror of path, not a shared jump, because you have not worked as QA. Do not claim the jump.

## Question banks

Ordered by persona weight. Depth follows weight: Case 5, Skeptic 4, Prober 3, Values 3, Conversational 3.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | A live event is an hour in and a bug is shipping to every player. What do you do? | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (Saltmarsh careers page) | Clarify: which title, what players see, what the calendar says. Decide: pause, roll back or announce. Name who you tell first. Announce what is built, not what is hoped (values page: "we announce what is built, not what is hoped"). Speak it in under two minutes. | This is the Outage Hour's format. CASE because it is a live problem with no claim about your past. |
| A2 | How would you plan the live-events calendar for two titles over their first quarter? | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Clarify the two titles' cadences and shared constraints. Set the dependencies with design, art, engineering and community. Set the review checkpoint. Use your own calendar as the reference point, in your words. Answer slot: if you planned against two titles' cadences, say how; if you have only run one calendar, say so and describe how you would sequence two. | F1 is the closest evidence. The question asks a hypothetical and does not presuppose a past. |
| A3 | Saltmarsh moves to one shared events calendar. How would you run it across two titles? | CO | [grounded] "one shared events calendar from February 2027" (Saltmarsh news page, search result) | Say what you would protect first: the release checklist and the review loop. Name the calendar's owner and what you would need from each team. This is an answer to the company's move, not a claim about your past. | The company's current plan is the CO question. Quoted from the news result, not fetched. |
| A4 | Retention drops ten percent on one title in the week after a content drop. Diagnose it. | CASE | [generic] | Clarify the cohort, the date and what else shipped that week. Split the drop by segment. Name the assumption you would test first. | A stock diagnostic for the role, not a fact about your past. |
| A5 | What would your post-event review of an update include, and what would you report? | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Say what the review covers: the update's goal, what shipped, the KPIs against goal, and what changes next time. Name the one KPI you would report first. | JD requirement. Your own review work is not quoted, so this is a plan, not a record. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | This role is moving two titles to season passes. You've never worked on a game with in-app purchases. What's your read on the monetisation side? | JD | [grounded] "never worked on a game with in-app purchases" (your message); [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model" (Saltmarsh news page, search result) | Hold the stated fact first: "I haven't worked on a game with in-app purchases." Then say what you would learn first, as a plan. Concede specifically: you do not yet know how a season pass changes retention on these titles. Hold through two follow-ups by returning to the stated fact. | This is the highest-ROI prep in the pack. The gap is stated and the company's own move raises it, so this objection is likely. |
| B2 | You would coordinate four teams on each update, and you have never led a team. How do you get them to ship together? | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); [grounded] "Never led a team" (your message) | Hold: "I haven't led a team." Then the plan: one shared checklist, a named owner for each dependency, a checkpoint before each date. Concede that leadership without authority is the part you would need to earn. | F2 and F9 both bear on this. The honest answer is the plan, not a claimed past. |
| B3 | Which part of this JD would you be weakest at on day one? | JD | [grounded] "3+ years producing live-service games or apps" (JD) | Name the two stated gaps: leading a team and in-app purchases. Then the ramp plan for each. Do not name a third gap you have not stated. | Stem for the Skeptic. Your own answer is the stated gaps, so the answer stays inside them. |
| B4 | Tell me about the release checklist QA still uses. What has it caught? | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what the checklist covers, in your own words, and how it is used. Answer slot: if you have a count of what it caught, say the count; if you do not, say so, and do not estimate one. | F4 is the strongest evidence you have. The question presupposes it caught something; the second branch lets it not have. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | How did you define player retention in those monthly numbers? | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you know the definition, say it in your words; if it was set by someone else, or you do not know it, say so. | F7 is the evidence for retention. The question presupposes a definition existed, so the second branch allows it did not. |
| C2 | If you put one KPI from a post-event review in front of a studio head, which assumption behind it would you defend least? | JD | [generic] | Name the assumption before the interviewer does: the sample, the window, or the attribution. Say what you would check first. | JD KPI requirement, asked hypothetically. No claim about your past. |
| C3 | Two weeks of retention after a drop: what would you not trust yet? | EXP | [generic] | Name the window that is too short, the cohort that is too small, and any change that shipped alongside the drop. Say what you would wait for. | A standard prober question. Answer in general terms. |

### D. Values / Behavioural (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Tell me about a time you shipped something that did not match what you had promised. | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (Saltmarsh values page) | Selection scaffold: pick a time an update's promise and its shipped content differed, and say what you did about it. Your material carries no such time. If none comes to mind, say so plainly, then give the nearest thing it does carry: the release checklist (F4). | Ship the Patch Not the Promise is the value Tobias's talk is about. No candidate sentence carries a story for it. |
| D2 | Tell me about a time you put players ahead of the calendar. | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (Saltmarsh values page) | Selection scaffold: pick a time a calendar date and what players needed disagreed, and say what you chose. If none comes to mind, say so plainly, then give the nearest thing your material carries: F1, the content-drop calendar. | No candidate sentence carries a player-first story. The honest branch applies. |
| D3 | What did you leave better than you found it? | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Map the checklist to Leave the Build Greener: "every release leaves the codebase and the checklist better than it found them" (values page). Say what you wrote, and that QA still uses it. Do not claim it improved the build unless you know it did. | F4 is the story. The durability claim is yours to make: "still uses". |

### E. Conversational / CO (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | So, walk me through the journey. | CO | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc: four years at the puzzle-game studio; two years on the content-drop calendar; the release checklist; the monthly retention numbers. Stop there. | An opener is scored: the arc holds the four stated facts and nothing more. |
| E2 | Saltmarsh is moving two titles to season passes. What's your first read? | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model" (Saltmarsh news page, search result); [grounded] "never worked on a game with in-app purchases" (your message) | Give a read on the shared calendar, not on monetisation you have not done. Then the stated gap: "I haven't worked on a game with in-app purchases." | A CO question that is really a B1 probe in casual form. |
| E3 | Write the first paragraph of an announcement for a drop that is one week late. | JD | [grounded] "clear written communication" (JD); [grounded] "we announce what is built, not what is hoped" (Saltmarsh values page) | Say what shipped, what is late, and the new date, in that order. Announce what is built, not what is hoped. Keep it plain. | JD requirement and the announcement principle at once. Tests written communication under the value. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A3, F1 |
| Coordinate design, art, engineering and community teams on each update | B2, F2 |
| Own the post-event review and the KPIs it reports | A5, C2, F3 |
| Manage the release checklist with QA | B4, D3, F4 |
| 3+ years producing live-service games or apps | B3, E1, F5 |
| Experience running a content calendar | A2, E1, F6 |
| Comfortable with player-retention metrics | C1, C3, F7 |
| Clear written communication | E3, F8 |
| Team leadership (from Saltmarsh news page, not the JD) | B2, F9 |
| In-app purchases and season passes (from Saltmarsh news page, not the JD) | B1, E2, F10 |

Every question in the pack is covered by one of the rows above. Coverage is complete: no requirement is left without a question.

## Values cheat sheet

Saltmarsh publishes three values. Your material carries a story for one of them only, so the other two are selection scaffolds with the honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | None carried. D2 is a selection scaffold. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | None carried. D1 is a selection scaffold. Tobias's talk is on this value. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4: "Wrote the release checklist our QA team still uses." D3 maps it. |

## Reverse questions

Ask at least five. Each has a reason it lands.

1. Your GDC 2026 talk argues that patch notes are a promise. When a drop slips on your team, what does the patch note say? *Why it lands:* it ties to Tobias's own talk and to the QA background the talk describes. It is a conversation about his path, not a checklist of questions for them.
2. With per-title event teams moving to a single live-ops group, who owns the shared events calendar day to day? *Why it lands:* it shows you read the news page, and it tests the role's real scope.
3. What does a strong Outage Hour look like, and what do candidates usually get wrong? *Why it lands:* it signals preparation for the round and gives you the interviewer's own standard.
4. Which KPI does the post-event review report first, and who reads it? *Why it lands:* it pins down the JD's KPI ownership, which you need to scope your answers.
5. When the release checklist and a live date conflict, who calls it? *Why it lands:* it tests the release-checklist requirement the JD names, and it shows you know the checklist has an owner.
6. What would the first 90 days need to deliver for the season-pass move? *Why it lands:* it tells you what success looks like for the role, which the JD does not say.

## Sources

Provided documents: the JD and your message, both pasted in this conversation.

Searches and fetches, every one sent:

| Query | Result |
|---|---|
| Saltmarsh Games mobile game studio values | saltmarshgames.com/values, returned |
| Tobias Wrenfield Head of Live Operations Saltmarsh Games | GDC 2026 talk page, "Patch Notes Are a Promise" (search snippet only) |
| Saltmarsh Games live operations producer interview process | saltmarshgames.com/careers/interviewing, returned |
| Saltmarsh Games news 2026 live game | saltmarshgames.com/news/project-larkspur (search snippet only, not fetched) |
| Fetch: saltmarshgames.com/values | Returned the three values and their meanings |
| Fetch: saltmarshgames.com/careers/interviewing | Returned the Outage Hour format and the no-take-home note |

Research tier: L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and D1 to D3 |
| 2. Saltmarsh Games interview process, live operations | yes | Round format (Outage Hour), A1, values conversation |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur (season passes, shared calendar, single live-ops group): A3, B1, E2, F9, F10 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, C2 and reverse question 1 (GDC talk, QA-lead background). Search snippet only |
| 5. Representative live-operations producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Provided documents, not consumed from a dossier: no `tuesday-dossier.md` was present.

## Upgrade menu

- Your CV → the fit snapshot's F1 to F8 move from your message to your CV, and the medium confidence bands can be checked against a document.
- The Project Larkspur page, fetched → the CO questions (A3, E2) quote the full announcement instead of a search snippet.
- Confirmation of the round format → the persona weights are checked against the actual loop.
- Your definition of retention → C1 gets a stated definition to rehearse, if you have one.
- A tuesday-dossier.md from a prior session → the stated gaps carry forward with their evidence.
