I couldn't run web research: search permission was refused, so the pack runs on your notes and the JD highlights only. I'll write the pack to the scratchpad now.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-1-denied-099d50f3/94bc3138-bfcf-4335-8cda-442425bc826c/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`, and I've sent it to you as a rendered file. I built it for a single 60-minute peer round with Dan, as you described.

Web search was refused in this session, so the pack runs on your notes and the JD highlights only. Dan's public footprint and Northwind's current values and strategy are not in it. The interviewer read uses only your description of Dan.

**What's in the pack**
- **23 questions** across seven personas. The Data-Driven Prober and Peer Evaluator carry the most weight, at five questions each.
- **Fit snapshot** that quotes the candidate's background and the JD highlights verbatim. Each row shows the evidence confidence and the gap type.
- **Prohibited claims** the pack won't coach, such as "led the $400M uplift" or "designed the partner motion."
- **Requirement coverage** mapping each JD line to question IDs.
- **Six reverse questions**, including one tied to Dan's startup chapter and one peer reciprocity question.

**Highest-ROI prep: D2.** Partner-motion design is a required JD line, and her material carries only adjacent evidence for it (a partner-level revenue model). Rehearse it through the third follow-up. Hold the position, then concede exactly that the model is not the motion.

**Choices I made that you should check**
- **The "no sales-ops or quota-setting" line is from your notes, not from Priya.** The pack gives it as her plain acknowledgment, but she should confirm the wording in her own words before rehearsing it.
- **No values cheat sheet.** No values-style round was detected and no published values were in hand, so that section is dropped.
- **No coaching of the $400M figure beyond the quote.** Questions A1, A2 and G2 ask how it was counted and what was hers, and the honest branch is "I don't know how it was counted."

Two questions before the next pass:
1. Could you paste the full JD? The highlights leave out its exact wording and any location, travel or work-authorization terms, and those would change the fit snapshot.
2. Did the recruiter say what the 60 minutes will cover, or whether Priya is expected to present anything?

I can also run a drill: I'd play the Skeptic on D2. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data, Senior GTM Strategy Lead (Emerging Products): mock-interview pack

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. Dan is a peer (same VP). **Round:** one 60-minute conversation.

## How to use this pack and type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior that shows influence, judgment, pushback |
| EXP | Work-experience deep-dive | Whether your past claims hold up under probing, and what was actually yours |
| JD | Role / JD-driven | Stated responsibilities and qualifications, including gaps |
| CO | Company and strategy | Whether you think at Northwind's altitude, using the priorities in your research note |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Provenance labels: `[grounded]` traces to a sentence you or the JD gave; `[inferred]` is this pack's derivation from a grounded fact; `[generic]` is a role-family pattern with no claim about you or Northwind.

Source names used below: **JD highlights** (the highlights you sent), **coach's notes** (your background summary), **research note** (your priorities and threat note).

## Interviewer read

Public footprint was not researched (search was refused), so this read uses only your description.

- **"Relentlessly data-driven"** (self-described). Expect the Prober persona to run high. Every number you cite will be taken back to its assumptions.
- **Career spine in pricing and monetization.** Expect case questions to tilt toward pricing, packaging and unit economics. That is Dan's native ground, so a pricing lens in your answers will be noticed.
- **One early-stage-startup chapter.** Builder stories can land well with this background. Expect scrappiness probes about big-company pace.
- **Shared professional path:** none established in the material, so none is offered as a mirror.
- **Peer relationship:** expect seam probes and a question about what this hire adds to Dan's work, not just what it needs.

## Persona table

| Persona | How it shows up in this round | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Takes each number back to its inputs, denominator and assumptions | **High, top weight.** The peer prior, plus Dan's self-described "relentlessly data-driven" pushes it up | Know what you can say about how each number was counted. Say plainly when you do not know. Name the weakest assumption before Dan does | A1 to A5 (5) |
| Peer Evaluator | Seams between partner work and pricing, "what would you need from me", credit and disagreement | **High, top weight.** The peer prior. Dan is pricing what this hire adds to Dan's own work | Reciprocity framing. Propose seam principles, not claims about Dan's team | B1 to B5 (5) |
| Case / Strategist | Live problem on whitespace, the Compass launch, bundling, a profitability trade-off | **Medium-high.** The role is GTM strategy for two new lines, and Dan's pricing career tilts cases toward pricing | Clarify, objective, segmentation, approach, metrics, risks. Challenge one premise | C1 to C4 (4) |
| Skeptic | Probes the required partner-motion design, the absent sales-ops and quota work, and enterprise evidence | **Medium.** The gaps are real and a peer will see them. Lower than the Prober because the round is collegial | Rehearse the most predictable objection until it is boring. Say limits plainly | D1 to D3 (3) |
| Conversational / Rapport | A casual opener, and a casual AI question that is scored | **Low-medium.** Peers open casually. The risk is treating the casual question as unscored | A 90-second arc for the opener. Treat the AI question as scored | E1, E2 (2) |
| Pressure / Stress | Interruption, and attribution challenge on the $400M figure | **Low.** A peer round rarely time-boxes, but attribution probes happen | Pause. Hold through two follow-ups. Concede specifically, never fold on the core claim | G1, G2 (2) |
| Values / Behavioral | Scenario probes on influence and pushback | **Low.** No values-style round was detected and no published values are in hand | Selection scaffolds with honest branches | H1, H2 (2) |

**Highest-ROI prep: D2.** Partner-motion design is a required line in the JD highlights, and your material carries only adjacent evidence for it. That objection will come in some form. Rehearse it to the third follow-up.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | low | [inferred] | discovery | Strategy and product work is in the quote. A go-to-market plan for a new line is not. Answer slot: if you have owned a go-to-market plan for a product line, say which and what you decided. If not, say so, and say how you would start |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent work. The quote says a revenue model, not whitespace across the four stages. Bridge at its own scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you have sized whitespace or an unserved segment, say how and what you counted. If that was not yours, say so and describe how you would approach it |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | presentation | The quote names the tools in other terms. Bridge rewords only that quote: "I'm skilled in SQL and Tableau." No inspectable artifact is on file, so expect a request for an example |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent. A partner-level model used in negotiations is partner-side analysis, not motion design. Bridge at scope, with the limit named as the pack's observation: the material says a model, not a motion. Slot: see D2 |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role terms. No gap, but nothing is inspected behind it, so expect a probe on what the consensus involved |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Adjacent: daily use, not building or running AI work. Bridge at its own scope: "I use AI tools daily." Slot: name one task you do with them |
| F7 | "enterprise expansion" (research note) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | low | [inferred] | discovery | The material is silent on enterprise selling. Slot: see D3 |
| F8 | No JD line: headline figure | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | none | A headline figure with a credit attached. The attribution is yours to defend, and a probe is expected. Words: the quote, at its scope. Slots: A1, A2, G2 |
| F9 | Sales-ops and quota-setting experience (role-family prose, no JD line) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | capability | The absence was stated in your notes. Plain acknowledgment: "I haven't done classic sales-ops or quota-setting." Confirm this wording in Priya's own words before rehearsing it |

Gap-type routing: F9 is `capability` because the absence was stated. F1, F7 are `discovery` because the material touches the requirement without showing it. F2, F4, F6 are `transferability` because adjacent work does not reach the requirement. F3 is `presentation` because its quote already names the requirement's terms. F5 and F8 are `none`.

## Prohibited claims

The pack will not coach any of these. They are built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed or owned the partner motion end to end | Inflated form of F4, against the JD's "partner-motion design experience required" | F4's quote at scope. The limit is the pack's observation, not a claim for Priya: the material says a model, not a motion. D2's slot stays inside the model |
| Owned whitespace across land, adopt, expand and renew | Inflated form of F2 | F2's quote at scope. The revenue model is what the material carries. The slot stays inside the model |
| Led or drove the ~$400M ARR uplift | Inflated form of F8, against "credited with" | F8's quote at its scope. A1, A2 and G2 ask only what was counted and which part was hers |
| Ran sales-ops or set quotas | Negative stated in the coach's notes, F9 | The plain acknowledgment F9 gives: "I haven't done classic sales-ops or quota-setting." No slot |
| Built or shipped AI products | Inflated form of F6, "uses AI tools daily" | F6's quote at scope: "I use AI tools daily." E2's slot asks one task |
| Ran analysis end to end that changed decisions | Inflated form of F3 | F3's quote at scope. A3's slot asks for an instance, and the honest branch is allowed |

## Question banks

Weights: A (Prober) and B (Peer) are top weight at 5 questions each. C (Case) is 4. D (Skeptic) is 3. E, G and H are 2.

### A. Data-Driven Prober (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say what you proposed, in the quote's words, and the figure as "credited with" it. Answer slot: if you know how the figure was counted, say it in your own words. If you do not, say plainly that you do not know how it was counted, and say what you can stand behind. Then name the weakest assumption you know of, before Dan does | F8 is a headline figure, and the Prober will open with the counting method. A figure raises only the defend-the-number slots, so no method is supplied here |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Name the assumption if you can identify one. If you cannot, say you have not isolated one, and say what you would test first. Answer slot: if any input to the figure was yours to set, say which. If none was, say so. Hold through a second follow-up before any concession | The follow-up to A1, drawn from the same quote. It is the stem persona-tuned to this interviewer |
| A3 | "Tell me about an analysis you have run in SQL or Tableau. What was the question, and which input did you trust least?" | EXP | [inferred] "skilled in SQL/Tableau" (coach's notes) | Low confidence, so coach clarification only, never a claim. Name the tool and the question, in your own words. If no analysis comes to mind, say so plainly, then name the nearest thing you have done with these tools | F3 is low and the JD asks for independent analysis. An open prompt, so no instance is supplied |
| A4 | "Which denominator would you check first in a whitespace estimate across land, adopt, expand and renew?" | JD | [generic] | Name the denominator that would move the number most, and how you would test it in SQL before it reaches leadership. Make no claim about past whitespace work | Scores the JD's whitespace requirement. Pure method, so it carries no claim about the candidate |
| A5 | "What was the most sensitive input in the partner-level revenue model you built?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the input if you can. If you could not say offhand, say you would check the model rather than guess. Answer slot: if the model's inputs came from someone else, say which, and what you did with them | F2 and F4 rest on this quote. The Prober tests whether the model is really yours, so the second branch is the honest one |

### B. Peer Evaluator (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two teams sit side by side. Where's the seam between partner work and pricing, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who decides a price and who owns partner terms. Do not claim to know Dan's team's current seam. If you have a disagreement story from your own work, use it. If not, name the principle you would apply | Partner-motion design is a required line, and pricing is Dan's home. The peer seam probe is near-certain. The answer must not assume knowledge of Dan's team |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story map from the sentence: the targets and the cross-org consensus, in the sentence's words. Say who proposed what in that consensus. Answer slot: if you can say which part of the consensus was yours, say it. If the targets were set by someone else, or you did not lead the consensus, say so plainly and describe your role | The JD's "strong cross-functional influence" raises the theme, and F5's quote is the only record of it. A peer will test credit before anything else |
| B3 | "What would you need from me in your first sixty days?" | JD | [generic] | Name two dependencies you would need from Dan's side, and one thing your work could unlock for pricing. Make no claim about past work | Reciprocity framing for a peer. It shows what you bring, not only what you need |
| B4 | "Walk me through the partner-level model you built, and how it was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Tell the story through the quote's beats: what you built, and how it was used. Answer slot: which part of the negotiation was yours, and which side's negotiation it served, in your own words. If you built it and others used it, say so | The premise is exactly the quote's. It is the most likely route into the partner-motion requirement, so the slot about your role is where the honest answer lives |
| B5 | "On an enterprise product, where would a partner-level revenue model touch pricing decisions?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the link as a hypothesis, not as past experience. Say what the model does at its scope, and where a pricing link could sit. Make no claim about pricing decisions you have made | Dan's pricing career makes this the natural counterpart question. It tests the bridge from partner work to pricing without assuming pricing experience |

### C. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you were given two new product lines, how would you size whitespace across land, adopt, expand and renew?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics and risks. Name a pricing and packaging lens, since that is Dan's ground. Challenge one premise respectfully | A live problem from the JD's own list. The hypothetical makes no claim about your past or about Northwind's lines |
| C2 | "Compass is launching. How would you decide which customers see it first, and what would you need to believe for it to change expansion?" | CO | [grounded] "AI copilot launch ('Compass')" (research note) | State the priority from your note. Then the hypothesis chain: adoption, then expansion, and what would falsify it. Do not claim knowledge of Compass pricing or features beyond the note | The research note states the priority. The AI requirement is "a plus", so this also covers it |
| C3 | "A much larger platform vendor bundles a comparable capability into its suite. What do you check first in our pipeline?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (research note) | Pricing and packaging lens. Name where bundling would first show in your data, and the metric you would watch. Make no claim about competitor prices | The bundling threat is the note's, and pricing is where Dan is strongest. A CO question that rewards the pricing lens |
| C4 | "Enterprise expansion and profitability both matter this year. Where do you trade off, and what do you give up?" | CO | [grounded] "enterprise expansion" and "reaching profitability" (research note) | State a position and the risk that comes with it. Name the metric you would watch. Make no claim about Northwind's current plans beyond the note | Two of the three priorities in the note, tested together. A peer GTM lead is expected to take a position on the trade |

### D. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes); [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Name the gap in your own words: "I haven't done classic sales-ops or quota-setting." Then the nearest sentence, at its scope: "set annual volume targets with cross-org consensus." Then a ramp plan, stated as a plan and never as past work | F9 is the stated gap. This question is the calibrated-candor test. Confirm the F9 wording with Priya before rehearsing it |
| D2 | "Partner-motion design is required here, and your partner work is a partner-level revenue model. What is the difference, and where, if anywhere, have you designed part of a partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **Highest-ROI rehearsal.** Hold: say what the model is, at its scope. Hold through two follow-ups. Concede specifically: the model is not the motion. Answer slot: if you designed any part of how partners were engaged, say which and how you decided. If none of it was yours, say plainly that the model is what you built and the motion was not yours | F4 is the required JD line with only adjacent evidence. This objection will come in some form. The second follow-up is where a held position breaks, so the concession must be exact |
| D3 | "I don't see B2B enterprise selling in your background. How would you handle it?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Say what your background shows, at its scope: consumer-tech, product strategy and ops. Answer slot: if you have sold to or worked with enterprise buyers, say how. If not, say so plainly, then describe how you would ramp | F7 is silent, so it is `discovery`, not `capability`. The answer must allow for no enterprise experience, and must never imply it |

### E. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc. Consulting, then consumer-tech product strategy and ops, then the reason for this role, in your own words. The arc is only the quote's beats, plus your reason | Casual register, but scored. The arc is pre-scripted so the opener is not improvised |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools and one task you do with them each day. Do not claim to have built anything with AI unless you did. Answer slot: name the task | "AI experience" is a plus line, asked casually. The honest answer is usage, so the rehearsal is accuracy about its scope |

### G. Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we hire you over someone who has run partner programs?" | JD | [generic] | Pause, then hold. Name the revenue-model work at its scope, the cross-org consensus, and what you would do first on partner motion. Make no claim of running partner programs | Composure on the required partner line. A time-boxed challenge tests whether you hold a position without becoming defensive |
| G2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: say what you proposed, in the quote's words. Concede specifically: name the share you can defend, and what you cannot split. Hold through two follow-ups. Answer slot: if you can say which decisions were yours, name them. If the split is not known to you, say so plainly | Pressure on attribution. The hold is only what the quote carries, so the concession must be specific, not a retreat from "proposed" |

### H. Values / Behavioral (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you pushed back on a number leadership wanted." | VAL | [generic] nearest carry: "set annual volume targets with cross-org consensus" (coach's notes) | Selection scaffold: pick a time you disagreed with a target another organization wanted. It needs a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's "strong cross-functional influence" raises the theme. No published values exist to map, so this is an open prompt |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal target. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A consumer-tech probe, low weight. It is a common scored question and the honest branch is needed |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C1, C4, D1 |
| identify whitespace across land/adopt/expand/renew | C1, A4 |
| run independent analysis in SQL and Tableau | A3, A5 |
| partner-motion design experience required | D2, B4, B5, G1 |
| strong cross-functional influence | B2, H1 |
| AI experience a plus | E2, C2 |

Your research-note priority "enterprise expansion" is covered by C4, D3 and reverse question R4.

## Reverse questions

Each has a one-line "why it lands."

1. **"What did the early-stage startup stretch teach you about pricing that a large-company pricing role doesn't?"** Why it lands: it reads Dan's own path, shows you researched them, and turns the probe into a peer conversation.
2. **"What could a new person do in their first month that would genuinely help your team?"** Why it lands: the peer reciprocity question. It signals you think about what you bring to their team.
3. **"Where do the sales strategy and partner teams already disagree about numbers, and how do you settle it?"** Why it lands: it asks about the seam without claiming to know it, and surfaces the disagreement rule B1 needs.
4. **"Which of the three priorities, enterprise expansion, the Compass launch or profitability, is getting the most pressure from the leadership team right now?"** Why it lands: it uses your research note and shows you think at the company's altitude.
5. **"How is the bundling threat showing up in pricing decisions today?"** Why it lands: it names the competitive threat from your note and asks Dan, in Dan's own domain, what they see.
6. **"What does a good first ninety days look like for this seat?"** Why it lands: a standard closer that gives Dan a chance to describe the job, which is what B3 needs.

## Sources

**Provided documents:** the JD highlights (your message); the coach's notes (your background summary); the research note (priorities and threat); the interviewer description (your message).

**Searches sent (all refused by the host):**

- "Northwind Data company values": refused
- "Northwind Data Compass AI copilot launch": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

**Research tier:** L0. Searches 0 of 6 (3 refused). Fetches 0 of 2. L1 was the default, but search permission was refused, so it did not run.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet, section 10. Dropped: no values-style round was detected and no published values are in hand |
| 2. Northwind Data interview process, GTM peer loop | unavailable | Loop structure and persona weights. No call was sent: search was refused |
| 3. Northwind Data strategy and recent news | unavailable | Current segmentation language and recent moves. The research note carries the priorities, so C2 to C4 rest on your note alone |
| 4. Dan Kovac, Northwind Data | unavailable | Interviewer read beyond your description, and a tailored reverse question |
| 5. Representative GTM strategy lead JD | skipped | The JD highlights you sent fix the fit snapshot and the JD questions |

## Upgrade menu

- **Full JD text** → the requirement quotes become complete, and B1, C1 and D2 can be checked against the whole list
- **Priya's own words on the sales-ops and quota negative** → F9's plain acknowledgment becomes her answer, not your notes' wording
- **Priya's own words on the $400M split** → G2's concession and A2's slot become her answers
- **Her CV** → the coach's-notes quotes become CV lines, and the medium-confidence rows can be inspected
- **Dan's public profile** → persona weights from public footprint, and a reverse question tied to Dan's path beyond your description
- **Search permission** → the four unavailable targets, plus the deep-research offer: about six more searches and two more fetches for the loop report, interviewer talks and recent org context
- **Recruiter's focus areas or any deliverable** → build sections for any pre-declared deliverable
- **A `tuesday-dossier.md`** → evidence-graded quotes, the objections it names, and a prohibited list from earlier work
