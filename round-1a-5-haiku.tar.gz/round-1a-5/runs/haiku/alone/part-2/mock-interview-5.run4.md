Your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-5-denied-cecfc2a8/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

Two limits on it. Web search was refused, so I couldn't check Kelverton's values, strategy or the panel members' backgrounds. And the internal market report isn't in this conversation, so the pack doesn't use it. The POV's differentiation is a hypothesis until you share the report's key points.

The pack's main findings:

- **Highest-return prep is A2**, the "you've never sold into rail" objection. Hold on what you actually said, then concede the buying process specifically. Don't claim rail sales knowledge.
- **Ross's commercials questions (B1 to B4)** hinge on two things you've already said: you've never carried a direct quota, and the £4M is influenced revenue. Say both plainly and don't round either up.
- **The POV**: pick one of three theses, each with a concession. The close must land on what changes for operators day to day, and how you'd know. Time it to 15 minutes, spoken.
- **Prep split** for your four hours: POV first (70 min), then commercials, then the Skeptic drill, then reverse questions. Rail operator knowledge comes once I have the report's key points.

Two questions, so I can tighten the pack:

1. Can you paste the job description, or the requirements from the advert? Without it, the requirement rows are built from the recruiter's email and your background only.
2. Does the role list a direct quota or rail sector experience as a must-have? That changes how hard the commercials and rail rows push.

Offers, both optional:
- A live drill: I play Ross on B2 or Deepa on A2, with follow-ups that react to your answers.
- A `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail (second round, panel)

Changed: first build. No JD supplied, company research not run (search permission refused), internal market report not in context.

## How to use

- **Personas** are how a question will be asked. **Types** are what it scores.
- Type key: **VAL** behavioural/values · **EXP** experience deep-dive · **JD** role-driven · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.

## Prep triage (about 4 hours)

1. **70 min: build the POV.** Choose one thesis and its concession (Graded deliverable below). Say it aloud, timed to 15 minutes, three times. Stop at 15.
2. **60 min: commercials.** Rehearse B1 to B4 aloud. Hold, then concede the specific gap.
3. **45 min: the Skeptic.** Rehearse A2 until it is boring. This is the highest-return item in the pack.
4. **30 min: reverse questions.** Pick five from the list and know why each lands.
5. **Remaining time: rail operator knowledge** from the market report, once you share its key points. Everything else is insurance.

## Panel and persona weights

| Member | Likely persona(s) | Weight | Why |
|---|---|---|---|
| Deepa (VP Partnerships, future manager) | Case/Strategist (top), Skeptic | 4–5 / 3 questions | A hiring-manager relationship prior: buying capability and derisking the gap; the POV is a live problem on operator partnerships. No public profile was checked, so no interviewer-signal adjustment is made. |
| Ross (Commercial Director) | Pressure (top), Data-Driven Prober | 4–5 / 3 questions | Your email says Ross "will push on commercials". A commercial lead's default is to test whether headline numbers survive scrutiny and whether you hold a position under challenge. |
| Both | Conversational (light) | 2 | The opener is scored even when it sounds casual. |

## Fit snapshot

Requirements source: the recruiter's email as quoted in your message. No JD was supplied, so role-family requirements are marked `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says the ISV channel at a payments company, not operator partnerships. Keep the scale claim at its own scope: "I took the channel from six partners to forty." Answer slot: what would be different with operators, in your own words. If you have not worked that out yet, say so and say how you would find out. |
| F2 | "what it means for the operators themselves" (recruiter email) | "so I know the operator world from the other side" (your message); "bus and light rail network planning" (your message) | medium | [grounded] | presentation | Your sentence already reaches the operator view. Say it in those terms: "I know the operator world from the other side, from bus and light rail network planning." Add no planning practice or example beyond what you stated. |
| F3 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence of a direct quota, so the words are yours to give: "I've never carried a direct quota. What I have is influenced revenue." Do not add a target or attainment figure. |
| F4 | [generic] sell into rail or a comparable regulated operator sector (role family; no JD) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't sold into rail." Then how you would learn the buying process, said as a plan, never as a past. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operator partnership strategy | Inflated form of F1 | "took it from 6 partners to 40" at the ISV-channel scope. Your material says the channel, not operator partnerships. |
| Carried or hit a quota | Negative you stated (F3) | Plain acknowledgment: "I've never carried a direct quota." |
| The £4M as revenue you owned | Inflated form of F3 | "roughly £4M of influenced revenue" |
| Sold into rail or knows the operator buying cycle | Negative you stated (F4) | Plain acknowledgment: "I haven't sold into rail." |

## Graded deliverable: the 15-minute spoken POV

Recruiter's words, quoted in your message: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed" and "Please land on what it means for the operators themselves."

Grounded facts to build on: F1 and F2. The consensus answer for this brief is not established here (the market report is not in context). The differentiation below is therefore a hypothesis until you share the report's key points.

**Pick one thesis, with its concession.** Do not present all three.

- **T1: start from the operator's planning cycle, not from partner count.** Concession: I haven't sold into rail, so I'm inferring the buying cycle from the planning side. I'd test it with three operators before committing.
- **T2: partner-led reach that works for ISVs may not suit operators.** Concession: the ISV playbook I ran was not built for operators, and I haven't checked whether operators buy through partners at all.
- **T3: co-own the roadmap with a few operators.** Concession: this is a mechanism I would need to validate, and I can't yet say how many operators it takes.

**Differentiation.** The likely consensus answer is to grow a partner or integrator channel, as an ISV channel does. Anti-pick: say you would not grow partner count before an operator outcome is proven.

**Close, as the recruiter asked:** what changes for the operator day to day, and how you would know. Say it as a hypothesis with a test, not as a figure.

## Question banks

### Deepa (Case/Strategist, then Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A train operator has just declined a renewal. Sketch your first 90 days: what do you need to know first?" | CASE | [generic] | Clarify first: why they declined, what the operator's own targets are. Structure: objective, segmentation of operators, approach, metrics, risks. Name the assumption about operator buying that you cannot yet check. The question presupposes nothing about your past. | A live problem from the role, asked as a decision. [generic] because it is a pattern, not a fact about this employer. |
| A2 | "You've never sold into rail. Which part of operator partnering would you be weakest at on day one?" | JD / Skeptic | [grounded] "Never sold into rail specifically" (your message); [grounded] "so I know the operator world from the other side" (your message) | **The highest-ROI prep in this pack.** Hold: "I haven't sold into rail." Then name the part you would be weakest at, and say what you know from the planning side. Hold through two follow-ups by returning to the planning-side knowledge. Concede specifically: the buying process is the part you have not seen. Never claim rail sales knowledge. | The most predictable objection to a candidate with no rail sales. Your planning-side knowledge is the only honest counter. |
| A3 | "How much of the six-to-forty growth was your call, and how much was the company's?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name which parts you set and why, in your own words. Answer slot: if you chose partner selection or enablement, say how you decided; if those were set elsewhere, say so plainly and describe your part. | A premised question on your quoted figure. The likely prober move on a headline number. |
| A4 | "What would you do with operators that you couldn't do with ISVs?" | JD | [grounded] "so I know the operator world from the other side" (your message); [grounded] "bus and light rail network planning" (your message) | Start from the operator's side because you have seen it: planning change cycles. Then the difference from ISVs. Stay with what the planning work shows. Do not add operator anecdotes. | Tests whether the operator-world claim is judgment or name-dropping. |

### Ross (Pressure, then Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Roughly £4M of influenced revenue. What did you actually own in that?" | EXP / Pressure | [grounded] "roughly £4M of influenced revenue" (your message) | Hold: name which part of the influence was yours to set, in your own words. Concede explicitly where the revenue was the company's. Never say "owned" for influenced revenue. Answer slot: if you know how it was counted, say how; if you do not, say "I don't know how it was counted" and name the assumption you would defend least. | The headline figure is the magnet. Hold-then-concede. |
| B2 | "You've never carried a quota. Why should I believe you can hit one?" | JD / Pressure | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: "I haven't carried a direct quota." Then the closest honest evidence: what you influenced and how. Concede the specific gap: you do not yet know how a quota would change your priorities. Do not state an attainment figure or a claim you could hit one. | This is the commercials objection. Concede specifically; never fold to restore harmony. |
| B3 | "How would you structure a partnership where the operator's return comes from savings, not licence fees?" | CASE | [generic] | Structure: what the operator measures, what drives the savings, who carries the risk, how the vendor is paid. Name the assumptions you cannot yet verify. The question presupposes no fact about your past. | Commercial structure for operators, asked as a problem. |
| B4 | "Walk me through how six-to-forty partners turned into revenue." | EXP / Prober | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Say what the link is and what it is not: partner count and influenced revenue are not the same thing. Answer slot: if you tracked the link, say how; if the revenue attribution was the company's, say so. | A prober move on the partner-to-revenue chain. |

### Conversational (light, either member)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years in partnerships" (your message); [grounded] "5 years in transport consulting" (your message) | A 90-second arc: transport consulting, then the payments ISV channel, then why operators now. The "why" is in your own words; the material does not state it, so say it yourself. | Casual openers are scored. Keep it to the arc. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Operator partnership POV, 18 months (recruiter) | Graded deliverable; A1; A4 |
| What it means for operators (recruiter) | Graded deliverable close; A4; F2 |
| Commercials (recruiter) | B1 to B4 |
| Sell into rail or a regulated operator sector [generic] | A2 |
| Scale partner ecosystems (from your background) | A3; B4 |

## Reverse questions

1. "Which operator partnerships are working best today, and what made them work?" Why it lands: shows you are thinking operator-first.
2. "Where has a partner-led approach not worked with an operator, and why?" Why it lands: invites the Skeptic's test on your own terms.
3. "How are operator contracts structured today, and where do they change?" Why it lands: commercial fluency, and a route into B3.
4. "What would a strong first six months look like in this role?" Why it lands: it turns the role into a measurable plan.
5. "What did the commercial team learn last year about how operators buy?" Why it lands: asks Ross for the commercial view directly.

## Sources

- Provided documents: your message, including the recruiter's email quoted in it. The internal market report is not in this conversation, so no claim here is drawn from it.
- Research tier: L1, searches 0 of 6, fetches 0 of 2 (search permission was refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused: "Kelverton Rail values partnerships". Values cheat sheet was not generated (no published values in hand). |
| 2. `Kelverton Rail interview process` | unavailable | Not sent. Would have set loop structure and persona weights. |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Not sent. Would have grounded the POV's current framing and the CO bank. |
| 4. `Deepa Kelverton Rail` / `Ross Kelverton Rail` | unavailable | Not sent. Would have produced an interviewer read. |
| 5. representative senior partnerships JD | unavailable | Not sent. Would have turned the `[generic]` rows into `[inferred]`. |

Refused: "Kelverton Rail scheduling software train operators" (search, target 1 and 3 context).

## Upgrade menu

- The internal market report's key points, pasted → a consensus check for the POV, and rail-specific operator vocabulary
- The role's JD text → F-rows become `[grounded]`; B-questions tie to the JD's own requirements
- Permission to run web search → company values, strategy and an interviewer read for Deepa and Ross
- Deepa's and Ross's public profiles → persona weights per member and a tailored reverse question
- Recruiter's guidance on the POV (length, audience, what counts as a pass) → tighter build section
