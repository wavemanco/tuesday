Saved to `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-2-denied-31361550/9743acdc-1e0f-4033-b269-ec150a6f098a/scratchpad/atlas-freight-ops-manager-prep.md`. I built it from the JD and your background only. I did not run any research, so Atlas Freight's values and strategy are not in it yet. Round type and interviewers are unknown, so the persona weights are flat.

# Interview prep pack: Operations Manager, Atlas Freight

**Build basis:** JD as pasted; your background as you stated it; no research (L0); round type and interviewers unknown, so personas are flat; no interviewer profile, dossier or assessment; no announced deliverable.

## 1. Fit snapshot

| Row | JD requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|---|
| R1 | "Own daily terminal operations across 4 sites" | "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | medium | scale (four sites) | Your material shows one site. Bridge: "I run daily operations at one site with a shift-level cadence; four sites would mean the same cadence through site leads. Here is how I'd start." |
| R2 | "drive on-time performance and cost-per-shipment down" | "cut mis-pick rate 40% by redesigning the pick path" | medium | metric (accuracy, not on-time or cost) | Mis-pick is an accuracy metric. The pick-path work is your process lever; on-time and cost are not in your material. |
| R3 | "lead a team of 12 supervisors" | "senior shift manager over 3 supervisors" | high for 3; none for 12 | scope | You lead through supervisors today, three of them. Say that number first. |
| R4 | "build reporting in Excel/Power BI" | "solid Excel"; "never used Power BI" | high (Excel); none (Power BI) | tool | Excel is the base you'd build from; Power BI is a plain gap. |
| R5 | "5+ years operations leadership required" | "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors" | leadership years not stated | experience (leadership duration) | Your material shows operations years and a supervisory role. It does not show how many years you have led people. You state that (Q10). |
| R6 | "Lean/Six Sigma a plus" | "Green belt certified" | high | none (plus met) | State the certification and, if you have one, a project you led. |

*Pack observation (analysis, not words for you):* your material shows one site, three supervisors, Excel, and a Green Belt. It shows nothing on cost-per-shipment, on-time performance, Power BI, or leadership years.

## 2. Prohibited claims (built locally)

Each entry inflates a sentence you did say. The honest form is your quote at its own scope.

- **P1.** "5+ years of operations leadership." Widens "7 years in warehouse and distribution ops", which has no leadership qualifier.
- **P2.** "Led or leads 12 supervisors." Widens "over 3 supervisors."
- **P3.** "Ran four sites" or "multi-site ownership." Your material describes one site.
- **P4.** "Led the pick-path redesign." Your sentence says "by redesigning the pick path" and does not say who led it.
- **P5.** "Built the surge plan." Your sentence says "ran the site's peak-season surge plan." "Ran" does not say "designed."
- **Sourced, plain acknowledgment allowed:** "I haven't used Power BI." Source: your "never used Power BI."

## 3. Persona weights (flat, round unknown)

| Persona | Weight | Why |
|---|---|---|
| Data-Driven Prober | 3 | The 40% figure and the Excel base will be probed |
| Skeptic | 3 | Leadership scope and years (R3, R5), and Power BI (R4) |
| Pressure | 3 | The leadership-years gap is the most likely objection |
| Case/Strategist | 3 | Four-site on-time and cost work gets tested live |
| Conversational | 2 | Opening biography and a casual Power BI question |
| Peer | 2 | Ops peers ask about seams and disagreement |

## 4. Question banks

Provenance shows the label and your quoted sentences.

**Conversational and Peer**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Walk me through your background." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | 90-second arc: years in warehouse and distribution, current role, pick-path result and surge plan, then why this role. Only those facts, at their scope. | R1, R5 |
| Q2 | "What are you doing in Excel these days, and what would you build for reporting?" | JD | [grounded] "solid Excel"; raising source: JD "build reporting in Excel/Power BI" | Name one real workbook you built and what it tracked, if you have one. Then: "I haven't used Power BI." | R4 |
| Q3 | "What would you do first with Power BI?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI. My first step would be ___" (your answer). Don't claim a skill or course. | R4 |
| Q4 | "How do you handle a supervisor who disagrees with a plan you've set?" | EXP | [generic] no quote speaks to it. Answer slot. | Pick a time a supervisor pushed back. If none comes to mind, say so, then say how you'd handle it. | R3 |

**Data-Driven Prober**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q5 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number. Answer slot: "If you know the baseline period and how errors were counted, say them. If not, say so." Name the weakest assumption before it's asked. No baseline is supplied here. | R2 |
| Q6 | "Which part of that 40% was yours?" | EXP | [grounded] same sentence | Answer slot: "If you led the redesign, say what you did. If you contributed, say that. If it wasn't your work, say so." | P4 |
| Q7 | "How would you tell whether a change lowered cost-per-shipment?" | JD | [inferred] raising source: JD "drive on-time performance and cost-per-shipment down" | Answer slot: "If you've measured a cost per unit before, say how. If not, say so and describe how you'd build the baseline." Your material is silent here. | R2 |
| Q8 | "On the peak-season surge plan you ran: what did it measure, and what would you change?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Say what "ran" meant in your words. Answer slot: "If you designed it, say so. If you ran a plan someone else set, say that." | P5 |

**Skeptic**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q9 | "You lead three supervisors today. How would you lead twelve across four sites?" | JD | [grounded] "senior shift manager over 3 supervisors"; raising source: JD "lead a team of 12 supervisors", "4 sites" | Hold through two follow-ups. State the three, then how you run them day to day (your answer). Concede specifically: "I haven't led at twelve or across four sites. The first thing I'd check is ___." Don't claim the larger scope. | R3, R1. Most likely objection. |
| Q10 | "I don't see five years of operations leadership in your background. How would you handle that gap?" | EXP | [grounded] "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors"; raising source: JD "5+ years operations leadership required" | **Deepest rehearsal.** Answer slot: "I've been in operations for [your years] and have supervised people since [the year you started]. If I haven't led people for five years, I'd say that and name the number." Hold through two follow-ups. Concede only what your dates show. Never say "five years." | P1, R5 |
| Q11 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; raising source: JD "build reporting in Excel/Power BI" | Name Power BI plainly. Then bridge to "solid Excel." Your ramp plan is your own answer. | R4 |

**Pressure**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q12 | "Sixty seconds: why you over someone who has led at this scale?" | JD | [generic] no quote speaks to other candidates. Answer slot. | Anchor in what you have: one site, the pick-path result, the Green Belt. Don't claim scale. If you don't know who else applied, say so and answer about the role. | R3, R5 |
| Q13 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Hold: state your role in your words. Concede a specific limit if the redesign was shared. Don't fold on your own part. | P4 |

**Case and Strategist**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q14 | "Four sites, on-time performance down, cost-per-shipment up. Where do you start in your first 30 days?" | CASE | [inferred] raising source: JD "Own daily terminal operations across 4 sites; drive on-time performance and cost-per-shipment down" | Clarify the site split and baseline. Objective, then segment by site, shift and lane. Choose two or three metrics. Name the risks, and say your reasoning aloud. No past event is asked about. | R1, R2 |
| Q15 | "If you had to build a weekly site dashboard for leadership, what would it show?" | JD | [grounded] "solid Excel"; "never used Power BI"; raising source: JD "build reporting in Excel/Power BI" | Three to five metrics. Say where Excel holds them and where Power BI would take over ("I haven't used Power BI"). | R4 |

**Other EXP and VAL**

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| Q16 | "Which parts of your 7 years in warehouse and distribution ops shaped how you run a shift?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Name two or three roles or lessons, in your words. If none stands out, say so, then name the closest. | R1, R5 |
| Q17 | "Tell me about a process change that met resistance." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story map: the redesign and its result, in the sentence's terms. Answer slot: "If people pushed back, say how you handled it. If there was no resistance, say so." | P4 |
| Q18 | "Tell me about a time you had to hit a service target under pressure." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story map: the surge plan, its target and your part, at the sentence's scope. If you missed a target, say so and what you changed. | R2 |
| Q19 | "What's your experience with lean or process work, and where did you use the Green Belt?" | JD | [grounded] "Green belt certified" | Name the certification. Name a project only if you led one. Answer slot: "If you applied DMAIC to a real problem, name it and your role. If the certification is what you have, say so." | R6 |

## 5. Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | Q1, Q9, Q14 |
| Drive on-time performance and cost-per-shipment down | Q5, Q7, Q14, Q18 |
| Lead a team of 12 supervisors | Q4, Q9, Q12 |
| Build reporting in Excel/Power BI | Q2, Q3, Q11, Q15 |
| 5+ years operations leadership required | Q1, Q10, Q16 |
| Lean/Six Sigma a plus | Q19 |

Session total: 19 questions.

## 6. Reverse questions

No interviewer profile, so these are role-generic.

1. "What does on-time performance look like at the weakest of the four sites, and what has been tried?" Lands because it shows site-level thinking.
2. "How are the supervisors split across the four sites today?" Lands because it checks span rather than assuming it.
3. "Who owns the cost-per-shipment number, operations, finance, or both, and how is it reported?" Lands because it shows you know cost is a shared number.
4. "What reporting does leadership use now, and where would Power BI fit?" Lands because it turns your gap into a question about their setup.
5. "What would a strong first 90 days look like, and what would make the role fail?" Lands because it shows you think in outcomes.

## 7. Upgrade menu

- **Round type and interviewers:** reweights personas and restructures the banks.
- **Leadership years, budget or cost ownership, multi-site leadership:** turns Q9 and Q10 from answer slots into grounded answers.
- **Research at L1** (up to 6 searches, 2 page fetches): Atlas Freight's values and operations strategy, upgrades the [inferred] rows, adds a strategy question.
- **Research at L2** (up to 6 more searches, 2 more fetches): strategy brief and role-family loop reports. Takes longer.
- **Interviewer names:** an interviewer read, with personas tuned per person.
- **Recruiter's note on focus areas or a take-home:** adds any graded deliverable as its own section.
- **A dossier** from the prep tooling, if you have one: verified evidence and an underwriter's prohibited-claims list, replacing the local list in section 2.

---

**Drill offer:** I can play the interviewer for any question above, with follow-ups, and give feedback against that question's guidance. Say the number, e.g. "drill Q10."

**Dossier offer:** If you have a `tuesday-dossier.md`, share it and I'll fold it in. Otherwise I can write one from your answers.

**Questions for you (two, answer whichever you can):**

1. What's the round (hiring manager, panel, skip-level, HR screen), and who's on it? Did the recruiter name focus areas, a take-home, or a presentation?
2. For the gaps the material doesn't show: (a) how many years have you led people, (b) have you owned a budget or a cost-per-shipment number, (c) have you led across more than one site or a team larger than three? One line each.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight-ops-manager-prep.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Build basis:** JD as pasted; your background as you stated it (quoted below); no research run (L0); round type and interviewers unknown, so persona weights are flat (full-loop); no interviewer profile, no dossier, no assessment; no announced deliverable.

## 1. Fit snapshot

| Row | JD requirement (quoted) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|---|
| R1 | "Own daily terminal operations across 4 sites" | "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | medium | scale (four sites) | Your material shows one site. Bridge: "I run daily operations at one site with a shift-level cadence; four sites would mean the same cadence through site leads. Here is how I'd start." |
| R2 | "drive on-time performance and cost-per-shipment down" | "cut mis-pick rate 40% by redesigning the pick path" | medium | metric (accuracy, not on-time or cost) | Mis-pick is an accuracy metric. Bridge: the pick-path work is the process lever you have; on-time and cost are not in your material. |
| R3 | "lead a team of 12 supervisors" | "senior shift manager over 3 supervisors" | high for 3; none for 12 | scope | Bridge: you lead through supervisors today, three of them. Say that number first. |
| R4 | "build reporting in Excel/Power BI" | "solid Excel"; "never used Power BI" | high (Excel); none (Power BI) | tool | Bridge: Excel reporting is the base you'd build from; Power BI is a plain gap. |
| R5 | "5+ years operations leadership required" | "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors" | years of leadership not stated | experience (leadership duration) | Your material shows operations years and a supervisory role. It does not show how many years you have led people. The answer is yours to state (see Q8). |
| R6 | "Lean/Six Sigma a plus" | "Green belt certified" | high | none (plus met) | Bridge: state the certification and, if you have one, a project you led. |

Pack observation (analysis, not words for you): your material shows one site, three supervisors, Excel, and a Green Belt. It shows nothing on cost-per-shipment, on-time performance, Power BI, or leadership years.

## 2. Prohibited claims (built locally)

Each entry is an inflated form of a sentence you did say. The honest form is your quote at its own scope.

- **P1.** "5+ years of operations leadership." Widens "7 years in warehouse and distribution ops", which has no leadership qualifier. Honest form: "7 years in warehouse and distribution ops", with the leadership years stated by you.
- **P2.** "Led or leads 12 supervisors" or "led teams of this size." Widens "over 3 supervisors."
- **P3.** "Ran four sites" or "multi-site ownership." Widens "the site's peak-season surge plan" (one site).
- **P4.** "Led the pick-path redesign." Your sentence is "by redesigning the pick path" and does not say who led it. Honest form: "cut mis-pick rate 40% by redesigning the pick path", with your role stated by you.
- **P5.** "Built the surge plan." Your sentence is "ran the site's peak-season surge plan." "Ran" does not say "designed."
- **Sourced entry, plain acknowledgment allowed:** "I haven't used Power BI." Source: your sentence "never used Power BI."

## 3. Persona weights (flat, round type unknown)

| Persona | Weight | Why |
|---|---|---|
| Data-Driven Prober | 3 | The 40% figure and the Excel base will be probed |
| Skeptic | 3 | Leadership scope and years (R3, R5), and Power BI (R4) |
| Pressure | 3 | The leadership-years gap is the most likely objection |
| Case/Strategist | 3 | JD asks for four-site on-time and cost work, which a hiring manager tests live |
| Conversational | 2 | Opening biography and a casual Power BI question |
| Peer | 2 | Ops peers ask about seams and disagreement |

Reweight once the round and interviewers are known.

## 4. Question banks

Types: VAL, EXP, JD, CO, CASE. Provenance: one label per row, with your quoted sentences after it.

### Conversational and Peer

| ID | Question | Type | Persona | Provenance | Guidance (90–120 seconds) | Rationale |
|---|---|---|---|---|---|---|
| Q1 | "Walk me through your background." | EXP | Conversational | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Arc: years in warehouse and distribution, the current role, the pick-path result and the surge plan, then why this role. Use only those facts and their scope. | R1, R5. An open biography prompt. |
| Q2 | "What are you doing in Excel these days, and what would you build for reporting?" | JD | Conversational | [grounded] "solid Excel"; raising source: JD "build reporting in Excel/Power BI" | Name one real Excel workbook you built and what it tracked, if you have one. If you have not, say which Excel tasks you do. Then: "I haven't used Power BI." | R4. A casual question on a JD topic is still scored. |
| Q3 | "What would you do first with Power BI?" | JD | Conversational | [grounded] "never used Power BI" | "I haven't used Power BI. My first step would be ___" (your answer). Do not claim a skill or a course. | R4. Plain acknowledgment from your own sentence. |
| Q4 | "How do you handle a supervisor who disagrees with a plan you've set?" | EXP | Peer | [generic] no quoted sentence. Answer slot. | Pick a time a supervisor pushed back. If none comes to mind, say so, then say how you'd handle it. | R3. Your material says nothing about this. |

### Data-Driven Prober

| ID | Question | Type | Persona | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|---|
| Q5 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | Prober | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number. Answer slot: "If you know the baseline period and how errors were counted, say them. If you don't, say so." Name the weakest assumption in your own words before it is asked. No baseline is supplied here. | R2. A headline figure draws probes. |
| Q6 | "Which part of that 40% was yours?" | EXP | Prober | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: "If you led the redesign, say what you did. If you contributed, say that. If the redesign was not your work, say so." | P4. Attribution is the probe. |
| Q7 | "How would you tell whether a change lowered cost-per-shipment?" | JD | Prober | [inferred] raising source: JD "drive on-time performance and cost-per-shipment down" | Answer slot: "If you have measured a cost per unit before, say how. If not, say so and describe how you'd build the baseline first." Your material is silent here. | R2. Silence is an answer slot, not a gap you can fill. |
| Q8 | "On the peak-season surge plan you ran: what did it measure, and what would you change?" | EXP | Prober | [grounded] "ran the site's peak-season surge plan two years running" | Say what "ran" meant in your words. Answer slot: "If you designed the plan, say so. If you ran a plan someone else set, say that." | P5. |

### Skeptic

| ID | Question | Type | Persona | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|---|
| Q9 | "You lead three supervisors today. How would you lead twelve across four sites?" | JD | Skeptic | [grounded] "senior shift manager over 3 supervisors"; raising source: JD "lead a team of 12 supervisors", "4 sites" | Hold through two follow-ups. State the three, then describe how you run them day to day (your answer). Concede specifically: "I haven't led at twelve or across four sites. The first thing I'd check is ___." Do not claim the larger scope. | R3, R1. The most likely objection. |
| Q10 | "I don't see five years of operations leadership in your background. How would you handle that gap?" | EXP | Skeptic | [grounded] "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors"; raising source: JD "5+ years operations leadership required" | **Deepest rehearsal.** Answer slot: "I have been in operations for [your years] and have supervised people since [the year you started]. If I have not led people for five years, I'd say that and name the number." Hold through two follow-ups. Concede only what your dates show. Never say "five years." | P1, R5. The gap sits where the material is thinnest, so this is where a pack is most tempted to thicken the story. |
| Q11 | "Which part of this JD would you be weakest at on day one?" | JD | Skeptic | [grounded] "never used Power BI"; raising source: JD "build reporting in Excel/Power BI" | Name Power BI plainly: "I haven't used Power BI." Then bridge to your Excel base ("solid Excel"). Your ramp plan is your own answer. | R4. |

### Pressure

| ID | Question | Type | Persona | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|---|
| Q12 | "Sixty seconds: why you over someone who has led at this scale?" | JD | Pressure | [generic] no quote speaks to other candidates. Answer slot. | Anchor in what you have: one site, the pick-path result, the Green Belt. Do not claim scale. If you don't know who else applied, say so and answer about the role. | R3, R5. |
| Q13 | "That 40% — how much of it was actually you?" | EXP | Pressure | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Hold: state what you did, in your words. Concede a specific limit if the redesign was shared. Do not fold on your own role. | P4. The position held is the one your quoted sentence carries. |

### Case and Strategist

| ID | Question | Type | Persona | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|---|
| Q14 | "Four sites, on-time performance down, cost-per-shipment up. Where do you start in your first 30 days?" | CASE | Case/Strategist | [inferred] raising source: JD "Own daily terminal operations across 4 sites; drive on-time performance and cost-per-shipment down" | Clarify the site split and the baseline. Objective, then segment by site, shift and lane. Choose two or three metrics. Name the risks. Speak your own reasoning aloud. This question asks about no past event. | R1, R2. Scored on structure, not a right answer. |
| Q15 | "If you had to build a weekly site dashboard for leadership, what would it show?" | JD | Case/Strategist | [grounded] "solid Excel"; "never used Power BI"; raising source: JD "build reporting in Excel/Power BI" | Choose three to five metrics. Say where Excel holds them and where Power BI would take over (plain: "I haven't used Power BI"). | R4. Hypothetical, so it presupposes no dashboard you built. |

### Other EXP and VAL

| ID | Question | Type | Persona | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|---|
| Q16 | "Which parts of your 7 years in warehouse and distribution ops shaped how you run a shift?" | EXP | Conversational | [grounded] "7 years in warehouse and distribution ops" | Name two or three roles or lessons from that span, in your words. Answer slot if none stands out: "say so, then name the closest one." | R1, R5. |
| Q17 | "Tell me about a process change that met resistance." | EXP | Values/Behavioral | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story map: the redesign and the result, in the sentence's terms. Answer slot: "If people pushed back, say how you handled it. If the change met no resistance, say so." | P4. Open prompt, so the theme comes from the sentence. |
| Q18 | "Tell me about a time you had to hit a service target under pressure." | EXP | Pressure | [grounded] "ran the site's peak-season surge plan two years running" | Story map: the surge plan, its target and what you did, in the sentence's scope. Answer slot: "If you missed a target, say so and what you changed." | R2. |
| Q19 | "What do you hold yourself to on lean or process work, and where did you use the Green Belt?" | JD | Skeptic | [grounded] "Green belt certified" | Name the certification. Name a project only if you led one. Answer slot: "If you applied DMAIC to a real problem, name it and your role. If the certification is what you have, say so." | R6. The JD plus, asked directly. |

## 5. Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | Q1, Q9, Q14 |
| Drive on-time performance and cost-per-shipment down | Q5, Q7, Q14, Q18 |
| Lead a team of 12 supervisors | Q4, Q9, Q12 |
| Build reporting in Excel/Power BI | Q2, Q3, Q11, Q15 |
| 5+ years operations leadership required | Q1, Q10, Q16 |
| Lean/Six Sigma a plus | Q19 |

Session total: 19 questions.

## 6. Reverse questions

Interviewer profile not provided, so these are role-generic.

1. "What does on-time performance look like at the weakest of the four sites, and what has been tried?" Why it lands: it shows you are thinking at site level.
2. "How are the supervisors split across the four sites today?" Why it lands: it clarifies span and shows you are checking scope, not assuming it.
3. "Who owns the cost-per-shipment number, operations, finance, or both, and how is it reported?" Why it lands: it shows you know cost is a shared number.
4. "What reporting does leadership use now, and where would Power BI fit?" Why it lands: it turns your gap into a question about their setup.
5. "What would a strong first 90 days look like, and what would make the role fail?" Why it lands: it signals you are thinking about outcomes, not just the job.

## 7. Upgrade menu

- **Round type and interviewers** → reweights personas and restructures the banks. Asked in the message.
- **Leadership years, budget or cost ownership, and multi-site leadership** → turns Q9 and Q10 from answer slots into grounded answers. Asked in the message.
- **Research at L1** (up to 6 searches, 2 page fetches) → Atlas Freight's values and operations strategy, which would upgrade the [inferred] rows and add a strategy question. Not run yet.
- **Research at L2** (deeper, up to 6 more searches and 2 more fetches) → adds the strategy brief and role-family loop reports. Costs more time.
- **Interviewer names** → an interviewer read, and personas tuned per person.
- **Recruiter's note on focus areas or a take-home** → adds any graded deliverable as its own section.
- **A dossier from job-underwriter** → verified evidence and a prohibited-claims list from the underwriter, replacing the local list in section 2.
