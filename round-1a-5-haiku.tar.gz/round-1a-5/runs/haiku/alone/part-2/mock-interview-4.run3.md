Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-4-denied-769dbdbb/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built on the dossier alone. Web search was refused in this session, so it has no company-specific values, process or strategy, and the dossier is 3.5 months old, so check the posting before Thursday.

Say the word and I'll play the Skeptic on A1, the objection the dossier names as most likely and the pack's highest-ROI prep.

I can also update `tuesday-dossier.md` with a `pack_feedback` section recording what this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** hiring-manager round, 45 minutes, Thursday. Relationship: hiring manager (from your note). Interviewer: not named.
- **Built from:** `tuesday-dossier.md`, generated 2026-08-14, about 3.5 months before this pack's date of 2026-11-25. The role's scope or posting may have moved since then. Check the posting before Thursday.
- **Decision carried from the dossier:** conditional_go. Condition: the bridge is positioned as adjacent, never as product management experience.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

Type key: **JD** = the listed job's requirements. **EXP** = what you did in past work. **CASE** = a live problem from the role. **VAL** = how you work with people. **CO** = company knowledge (no research ran, so none here).

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3 | low | [grounded] | transferability | Limit, in this pack's analysis: the material shows client-integration work and roadmap input, not product management time. Bridge, at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." Adjacent work only, never PM experience and never the title. Answer slot, inside the limit: if asked what in that work is closest to product work, name the roadmap-input sessions in the quote's own terms and stop there. |
| F2 | "Shipped API or platform products" (dossier role_profile, R2, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | low | [inferred] | transferability | No dossier grading exists for this row (no evidence_map was present), so this is the pack's own reading: integration go-lives sit on the consuming side of an API, not in shipping the platform. Bridge: say which side you worked on, the client's integration taken through go-live. Add no claim about the platform itself. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" — dossier row V2 | high | [grounded] | presentation | Bridge, in the quote's own terms: "I wrote the internal integration playbook my team uses." Documentation work is what this shows. Schemas do not appear in the material; if asked, answer from the playbook's content and say plainly if schema work was not yours. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3 | medium | [grounded] | transferability | Confirmed, with limited inspectable proof: expect a probe on the roadmap-input sessions, and volunteer the limit first. Bridge: name the customer side and the product side in the quotes' terms. Engineering and sales do not appear in the material. That is this pack's observation, not a claim for you to make. |
| F5 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [grounded] | discovery | Clarify, not bridge: the material does not show whether your work ran on a sprint or release cadence. Answer slot: if it did, say which cadence and how you ran it; if it did not, say so plainly and describe the cadence you did run to get integrations live. |
| F6 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap entry for this area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: how you would learn roadmap ownership in your first months. No bridge and no answer slot on this row. |

## Persona table

Relationship prior for a hiring manager is Case/Strategist plus Skeptic. No interviewer was named, so there is no interviewer signal to adjust it. No loop schedule was given, so this is session mode with the prior unadjusted. Depth follows weight: the top persona gets five questions, the mid persona four, the others two or three. Eighteen questions in total.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Returns to the R1 gap under several questions: "why hire into it instead of a PM" | Very likely. The dossier names this objection as the most likely one, and it sits on the must-have requirement | Rehearse A1 until it is plain: acknowledge, bridge at its own scope, state the limit, then the ramp as a plan |
| Case/Strategist (weight 4) | Live problems on the roadmap, the two squads and adoption; scores structure over answers | Likely. It is the hiring-manager prior, and the JD's squad and adoption responsibilities are the live material | Clarify first, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober (weight 3) | Presses the 30+ figure: how it was counted and what "end-to-end" meant | Likely. A headline figure sits on the material, and figures draw probers | Defend the number in your own words; name the weakest assumption before they do |
| Pressure (weight 2) | Cuts into the bridge: "why should we give this to someone without the title" | Possible in a 45-minute hiring-manager round, with a low prior. Two questions are enough to rehearse it | Pause, restate, hold the core through two follow-ups, then concede one specific thing |
| Conversational (weight 2) | Opens with "walk me through the journey" | Likely as an opener. Casual questions are still scored | A 90-second arc built only from the quoted entries |
| Peer Evaluator (weight 2) | Seams between the two squads and credit when work spans teams | Possible only if a squad lead sits in the loop. Weighted low for that reason | Propose seam principles; do not claim to know the seam |

## Question banks

Each question carries one type. Provenance comes first, and each quote there is one the guidance rests on.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1). The acknowledgments rest on dossier prohibited_claims and on the acknowledge_gap entry in uncertain_or_weak_areas, both named by field | The deepest rehearsal in this pack, with hold-then-concede. 1) Take the premise straight: "I haven't held the product manager title, and I haven't owned a product roadmap." 2) Bridge at its own scope: "What I did do: Led 30+ end-to-end client integrations of the vendor's REST APIs." 3) Name the limit and the ramp: "The roadmap and prioritization are the parts I would ramp on, and I'd rather say that now." Build the case for hiring from the integration work, never against a PM. Follow-up one, "who would set priorities?": hold with a plan, "In the first stretch I'd learn how the two squad leads set priorities before I set any." Follow-up two, "so we'd be training you on the roadmap?": concede the specific thing, "Yes, the roadmap is the part I'd be ramping on." Never claim you could match a PM with three years | R1 is a must-have, the dossier's highest-ROI objection, and the dossier's weakest area at bridge strategy. The negatives in the question have sources, so it is asked as written |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3). The acknowledgment rests on the acknowledge_gap entry in uncertain_or_weak_areas, named by field | Name roadmap and prioritization first, plainly: "On day one, the weakest part is owning a roadmap and setting priorities across two squads. I haven't done that." Then the ramp, said as a plan. Then the second area: "Agile delivery inside a product org is the other part I'd want to confirm, not claim." Keep it under a minute. Give no example of prioritization | A direct JD question. Giving the weak area first and plainly is the cleanest way through the Skeptic |
| A3 | "Tell me about a time you had to decide what to build next. What did you decide?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot. If a call you made shaped what a client integration included, or what went first, name it and what you decided, in your own words. If those scope calls were the client's or the vendor's, say so plainly, then give the nearest thing your material carries: the roadmap-input sessions, and what you carried to product from them. Do not stretch "fed client evidence" into "decided what product builds" | An open prompt on the JD's roadmap requirement. The answer slot keeps the honest branch open, and its second branch is the nearest quoted fact |
| A4 | "Walk me through how you've run delivery on a sprint or release cadence." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Clarify, not bridge. Answer slot: if your integration work ran on a sprint or release cadence, say which and how you ran it, in your own words, through go-live. If it did not, say so plainly and describe the cadence you did run. Do not describe agile practice you did not run | R5 is preferred and sits at discovery. The question asks for a practice the requirement raises, so the second branch has to allow that it never existed |
| A5 | "How is the work you did different from owning the product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | Say the difference in kind, not in size. "I carried a client's implementation of the vendor's APIs through to go-live. My part on the product side was feeding client evidence to product through roadmap-input sessions." If pushed to call it the same work at a bigger scale, hold: the difference is who decides what gets built | Bridges R1 and holds its limit. The general claim that the two kinds of work differ is a [generic] pattern about product work, not a fact about this employer. The two sides rest on the quotes |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat for two quarters. How would you find out why?" | CASE | [inferred] "Define and track adoption metrics" (dossier role_profile responsibility, the underwriter's rendering of the JD) | A live problem with no claim about your past. Clarify first: what counts as adopted (integrated, or live traffic), and for whom. Objective. Segment by partner size, integration type and the stage where partners stall. Name one metric and its weakest assumption before they do. Risks: what a flat line can mean in the data itself. Say you would ask for the current baseline first, since you do not have it | Adoption tracking is a stated responsibility, and the dossier leaves the measure and the baseline unknown. The two-quarter premise is the interviewer's hypothetical, not a fact about Quartzline |
| B2 | "Your two squads want different things next quarter: one wants a versioning overhaul, the other wants a partner onboarding flow. How do you decide, and who decides?" | CASE | [inferred] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility, the underwriter's rendering of the JD) | Clarify who holds the call before you structure anything. Name the criteria you would use, such as partner impact, risk and effort, and the trade you would state aloud. Say how it escalates to the squad leads. Do not claim decision authority you have not held. Say what you would propose, and what you would confirm with the leads first | Decision authority against the squad leads is the dossier's first unknown and the JD's most exposed claim. The question presupposes nothing about your past |
| B3 | "Sketch the first 30 days in this role. What do you need to know first?" | CASE | [generic] | Lead with questions: how the two squad leads decide today; how partner adoption is measured and what its current baseline is; what the roadmap currently contains; how partner discovery is run now. Then say how you would run discovery with partners, as a plan. Make no claim about a past role | The answer previews the questions the reverse bank asks, so the same ones do double duty. The pattern is generic to the situation |
| B4 | "Partner onboarding for a new API takes six weeks. Where would you look first?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot. In client integrations you carried end to end, say where the time went and what you saw, in your own words. If you did not track where the time went, say so, and say what you would measure first. Then structure the answer: where the six weeks sit, which stage the partner stalls at, and what you would ask the partner | CASE with an EXP tie. The integration work is the nearest real ground, and the slot keeps "where did the time go" honest |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You list 30+ end-to-end integrations. How did you count them, and how many would you defend?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Defend the number in your own words, in four parts. How you counted: whether a count was kept. What "end-to-end" had to include for the count to hold. The assumption you would defend least. Which integrations you led, and which were shared with the client or vendor. If no count was kept, say so and give the figure with what it rests on. Do not round it up or tidy it | A headline figure on the material draws the defend-the-number probe. The four parts come from the figure alone, and none names a method the material does not state |
| C2 | "Did any of those integrations get tracked after go-live? If so, what did you track?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot on adoption. If you tracked use after go-live, name what you tracked and the figure, in your own words, and the weakest assumption behind it. If you did not, say so plainly, then say what you would track first to show adoption. Do not describe adoption figures you do not have | This is the adoption-metrics requirement, and the material shows no baseline. The question asks whether tracking happened, so the second branch is open. It also touches R2, delivery through go-live |
| C3 | "What happened to the client evidence you fed to product in those sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | Answer slot, with the limit first: "The sessions are confirmed, but the record of what product did with the evidence is thin." If you can see a change that followed from that evidence, name it and how you know. If you cannot, say so. Do not claim a product change you cannot trace | V3 is medium confidence, with limited inspectable proof, which is the expected-probe seam in the dossier. Volunteering the limit before it is extracted is what the dossier's consumption rules require |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give this to someone without the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1). The title negative rests on dossier prohibited_claims, named by field | Hold, then concede. Pause, then restate the question. Hold the position: the integration work is the client-facing half of this job, and you have done it at 30+ scope. Concede the specific thing: the title and the roadmap are the parts you would ramp on. Do not concede the integration work, and do not add a claim to match the title | The Pressure stem from the persona table. The negative in the question has a source, so it is asked as written |
| D2 | "That integration number, how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Hold through two follow-ups. Return to the quote: "I led them," then name which parts you led end to end. Answer slot: if some of the work was the vendor's or the client's, name that in your words. Do not add to "led" a share of decisions you cannot name. Concede only what is true and specific | The same attribution probe as C1, under time pressure, so the answers must match |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); [grounded] "Wrote the internal integration playbook her team uses" (dossier row V2); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | A pre-scripted 90-second arc in three beats from the quotes: the integrations you led, the playbook you wrote for your team, the roadmap-input sessions that carried client evidence to product. Close on why this role, in your own words, adding nothing the quotes do not carry | A casual opener is still scored for communication economy. The arc uses only the three entries the material holds |
| E2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier row V2) | Answer with the playbook: what it covers, in your own words. Answer slot on schemas: if you have worked with schemas directly, name the work; if you have not, say so and say how you would close the gap | R3 is important. The playbook is the only documentation evidence, and schemas are not in the material |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our two squads sit side by side. Where's the seam, and what happens when we disagree?" | JD | [inferred] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility, the underwriter's rendering of the JD) | Propose seam principles, not a map you claim to know: who owns the spec, how a disagreement is escalated and how fast, what gets written down. Ask the squad leads how they have handled it. Make no claim about a past disagreement. If asked for one, use an answer slot | A squad lead may sit in the loop, and this is decision authority against equals, the dossier's first unknown |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot: name which integrations you led and which were shared work with the client or vendor, in those terms. If you had no credit decision to make, say so and describe how you named the shared work. Do not claim credit you cannot attribute | A collegial probe. The quote carries the scope of "led", and the answer must stay inside it |

### Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1, 3+ years product management experience (must) | A1 (JD), A2 (JD), A5 (JD) | |
| R2, Shipped API or platform products (must) | C2 (JD) | |
| R3, Technical fluency: API docs, schemas (important) | E2 (JD) | Schemas are an open gap in the material |
| R4, Stakeholder management across engineering, sales, customers (important) | F1 (JD), B2 (CASE) | Engineering and sales are not in the material |
| R5, Agile delivery experience (preferred) | A4 (JD), A2 (JD) | |
| Dossier sub-claim: roadmap and prioritization authority | A2, A1, B2, D1 | Plain acknowledgment only, with no slot |
| JD responsibility: define and track adoption metrics | B1 (CASE), C2 (JD) | Baseline unknown |
| Dossier unknown: decision authority against the two squad leads | B2 (CASE), F1 (JD), B3 (CASE) | |

## Reverse questions

Each one carries a "why it lands." The first two are the dossier's questions for the employer. The other three are this pack's.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the JD asserts roadmap ownership alongside two squads, and nothing in the material shows where the line sits. The answer tells you what you would actually be deciding.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the JD names adoption tracking as a responsibility and states no baseline. The answer shows whether you would define the measure or inherit one.
3. **"What would a good first 90 days look like, and who would judge it?"** Why it lands: it gives you the criteria you will be judged on, and it shows you plan to ramp on the roadmap rather than claim it.
4. **"What has changed about this role since it was posted?"** Why it lands: the dossier is from August, and the scope may have moved. Asking checks that in the room and reads as diligence.
5. **"What is the one thing this role needs from its PM that the squads aren't getting now?"** Why it lands: it surfaces the problem the role exists to fix, and it tests whether the integration background is the gap they are hiring for.

No interviewer profile exists, so no reverse question ties to an interviewer's own path.

## Prohibited claims

Each entry names its basis and its honest form. Nothing in the pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment, sourced to prohibited_claims by field: "I haven't held the product manager title." Then the title you did hold, in your own words, as it reads on your CV |
| Having owned a product roadmap | Sourced: dossier prohibited_claims and the acknowledge_gap entry | "I haven't owned a product roadmap." No answer slot on this one |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No answer slot on this one |
| Set what product builds next | Inflated form of dossier row V3 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's analysis: the material says the input reached product, not that you decided what it built. No first-person negative |
| Led engineering squads | Inflated form of dossier row V1 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is this pack's analysis: the material says client integrations, not squads |
| Owned the API documentation standard | Inflated form of dossier row V2 | The quote at its own scope: "Wrote the internal integration playbook her team uses." The limit is this pack's analysis: the material says the playbook, not a standard you set for the platform |

## Sources

- **Provided:** `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14 by job-underwriter). Consumed: `role_profile` (the requirements R1 to R5 stand as the JD's lines), `handoff_to_mock_interview` (verified evidence V1 to V3, taken in the order given; the weak areas; the likely objection; the opportunity risks; the employer questions; the prohibited claims), and `decision` as context. No `evidence_map`, `evidence_state` or `risk_register` was present. The grading in F2 is this pack's own derivation and is labeled as such.
- **Staleness:** the dossier is about 3.5 months old at this pack's date. Nothing here confirms the role is unchanged.
- **Research tier:** L1, searches 3 of 6, fetches 0 of 2. User links read: 0.
- **Searches sent, all refused** (the session did not grant search permission): "Quartzline values"; "Quartzline interview process product manager platform APIs"; "Quartzline partner API platform news 2026".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. Would have moved the values section, which applies only if a values-style round is detected. No values section is in this pack |
| 2. Quartzline interview process, product manager platform APIs | unavailable | Search refused. Would have moved the persona weights. The weights here are the hiring-manager prior, unadjusted |
| 3. Quartzline strategy and recent news | unavailable | Search refused. Would have moved the CO bank and checked the dossier's staleness. No CO question is in this pack |
| 4. Interviewer name and Quartzline | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions |

## Upgrade menu

- **Search permission for this session** → targets 1 to 3 run at the L1 budget. Strategy and news would also confirm whether the role is still live.
- **The interviewer's name** → an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- **The current posting text** → confirms whether the squad split and the adoption responsibility still read as the dossier recorded them. It would upgrade F2 and the B2 and F1 provenance from [inferred] to [grounded].
- **Your CV, and the playbook itself if your employer lets you show it** → the V rows gain your own sentences, and the playbook becomes the inspectable artifact for R3, which would move F3 from medium to high on proof.
- **The Thursday schedule, if it is one of several sessions** → loop mode, with a mini-pack per round.
- **Your prep time** → a prioritized schedule sized to it.
- **The recruiter's focus areas, if they gave any** → reweights the banks.
- **Deep research (L2), offered once:** strategy brief, interviewer talks and writing, loop reports for this role family, and recent organization context. Up to 6 further searches and 2 further fetches. It runs only with your consent and with search permission.
