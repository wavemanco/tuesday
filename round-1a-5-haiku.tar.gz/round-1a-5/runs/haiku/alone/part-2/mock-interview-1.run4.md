Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-1-denied-e56b7856/northwind_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round, since you said Dan is a peer on the same VP.

Two things shaped it. Web search was refused, so the company material comes only from your research note. And the fit quotes are your summary of Priya's background, not her CV sentences, so check each one against her CV before rehearsing.

The highest-ROI prep is D1: how she would set targets for two new lines, with no quota experience. Dan will probably test that, and the pack gives her a concession that doesn't claim quota work.

Say the word and I'll play Dan on D1 in a drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Interview prep pack.** Peer conversation with Dan Kovac, Director of Sales Strategy (same VP as the role). 60 minutes, single round. Candidate: Priya.

First version, so no changelog.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** EXP = work-experience deep-dive (what you actually did); JD = the job's stated requirements; CO = company and strategy knowledge; CASE = live problem, no past claim needed. VAL is not used: no values-style round is detected and no company values were provided.
- **Guidance is scaffolding, not a script.** Each cell is written to be spoken in 90 to 120 seconds. Use your own words.
- **Built on:** a peer round with one interviewer; the JD highlights you sent as the requirement list; your summary of Priya's background as the evidence; your research note as the strategy brief; no web research (see Sources).

## 2. Fit-gap map (fit snapshot)

Everything the pack says about Priya's past draws on the quoted sentences in this table.

**Read this first:** the quotes below are your summary of Priya's background, not her CV sentences. Check each one against her CV before rehearsing it. If her wording differs, the answer changes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD, your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material shows a product change she proposed and its credited uplift, not GTM strategy for a product line. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if any go-to-market decision for that change was hers to make, say which and how she decided; if none was, say so, and say how she would set GTM for a new line. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD, your message) | none given | none | [grounded] | discovery | Your material does not show whitespace work. Answer slot: name a whitespace she has identified and how she looked at it; if she has not, say so and say how she would find one across land, adopt, expand and renew. |
| F3 | "run independent analysis in SQL and Tableau" (JD, your message) | "skilled in SQL/Tableau" (your message) | low | [grounded] | presentation | Words: "I'm skilled in SQL/Tableau." The adjective has no artifact behind it. A work sample would raise the band (upgrade menu). |
| F4 | "partner-motion design experience required" (JD, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The model is adjacent: partner economics for negotiations, not a partner motion. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if she has designed how partners are recruited, enabled or paid, say which and how she decided; if not, say so, and say which partner economics the model covered. |
| F5 | "strong cross-functional influence" (JD, your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Words: "I set annual volume targets with cross-org consensus." Answer slot: which groups had to agree, and what she did to get them there; if the consensus came from a process she did not run, say whose. |
| F6 | "AI experience a plus" (JD, your message) | "uses AI tools daily" (your message) | low | [grounded] | transferability | The material shows use, not building. Words: "I use AI tools daily." Answer slot: name the tasks she uses them for. A plan for AI product work is a plan, not a past. |
| F7 | Sales-ops and quota-setting work: a role-family expectation for a GTM strategy lead, not in the JD highlights ([generic]) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | The stated absence. Plain acknowledgment: "I haven't set quotas or run sales ops." The source is your message, so confirm it is Priya's own account before rehearsing it. Bridge: F5's volume-target work, at its own scope, and how she would learn quota mechanics. |

**Gates:** none in these inputs. The JD highlights name experience, not a term such as location, pay, schedule, work authorization or a credential. If the full posting names one, it becomes a hard-gate row.

## 3. Prohibited claims

These are not coached anywhere in the pack. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for Priya: your material shows a proposed change. |
| Set quotas, ran sales ops or set comp targets | Inflated form of F5, plus the sourced negative in F7 | "I set annual volume targets with cross-org consensus." Plus F7's acknowledgment. |
| The ~$400M ARR was mine, or I drove it | Inflated form of F1's credit | "I proposed a store-surface change," with the credit attributed as the sentence states it. |
| Designed partner motions | Inflated form of F4 | The revenue model at its own scope. |
| Built AI products or led AI work | Inflated form of F6 | "I use AI tools daily." |
| Independent SQL or Tableau analysis that changed decisions | Inflated form of F3 | "I'm skilled in SQL/Tableau." |
| Inside knowledge of Compass or its roadmap | Not in the material; the note gives public priorities only | "I'm working from Northwind's public priorities." |

Sourced negative: F7's acknowledgment, sourced from your message (see F7).

## 4. Grounding brief

Your research note supplies the company's stated priorities and main threat. No further company research was possible (Sources).

- **Stated priorities:** enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- **Main competitive threat:** bundling by a much larger platform vendor.
- **Stale-framing check:** the note is undated, and recent moves (Compass's current status, any launch date) are unverified. Check them before the call.

## 5. Reading the interviewer

**Dan Kovac, Director of Sales Strategy, peer, same VP.** Public footprint from your profile only; no search was possible.

- **Career pattern:** "pricing and monetization roles," with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Practical implications:**

1. Every metric will be probed to its assumptions. Expect denominators and inputs. Section 6's Prober bank is weighted up for this reason.
2. Pricing and monetization is their native language. Case and metric answers should use pricing, packaging and unit-economics terms (C1).
3. The startup chapter means builder stories may land, and you may get "scrappiness" probes about big-company pace.
4. **Mirror opportunity (shared professional domain):** their monetization career pairs with F4's sentence, "built a partner-level revenue model used in carrier negotiations." This is a shared professional domain, not a shared jump, and it is fair to use. Do not build on shared identity or affinity.

## 6. Persona weights and the persona table

**Weights and reasoning.** Peer relationship priors set the starting point: Peer Evaluator and Data-Driven Prober. The interviewer's profile then adjusts them. The Skeptic is added because F7 is the most likely objection.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight (questions) |
|---|---|---|---|---|
| Data-Driven Prober | Denominators, inputs, assumptions behind the $400M and the targets | Highest. Their self-description is "relentlessly data-driven" and F1, F4 and F5 are quotable numbers and claims | Name the weakest assumption before they do. Say plainly when you do not know how a figure was counted | 5 (A1 to A5) |
| Peer Evaluator | Seams between teams, credit-sharing, who owns what | High. The round is a peer round, so seam and disagreement probes are the default | Reciprocity framing. Propose seam principles, not invented facts | 4 (B1 to B4) |
| Case / Strategist | Bundling threat, whitespace, sequencing against priorities | Medium-high. Pricing spine and the bundling threat tilt it toward pricing and packaging | Clarify, then objective, segmentation, approach, metrics, risks | 3 (C1 to C3) |
| Skeptic | The sales-ops and quota gap; partner-motion design; AI use versus build | Medium. Added because F7 is the single most predictable objection | Rehearse the objection until it is plain; calibrated candor over bluffing | 3 (D1 to D3) |
| Pressure / Stress | "How much of it was actually you?" | Low to medium. A peer round rarely stresses, but a sharp probe on the $400M can | Hold, then concede specifically | 2 (E1, E2) |
| Conversational | Opener and casual AI question | Low, but casual questions are still scored | Pre-scripted 90-second arc | 2 (G1, G2) |

**Total: 19 questions** in the banks, inside the 18 to 26 range.

## 7. The most likely objection: highest-ROI prep

**D1** is the highest-ROI rehearsal in this pack. Dan will likely test whether someone with no sales-ops or quota-setting background can set targets for two new lines. Rehearse D1 until the concession is plain, and do not claim quota work.

## 8. Question banks

Provenance comes first in every row. Each quote is verbatim from the fit snapshot.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Story-mapped on F1: the change she proposed, and the credit as the sentence states it. Answer slot: how the figure was counted, what it is sensitive to, the assumption she would defend least, and which part was hers. If she cannot say how it was counted, say so plainly. | A headline metric gets a defend-the-number slot. Prober's top stem, and the row it draws on is F1. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | The weakest-assumption move, in her words, before they name it. The pack names no assumption. Answer slot: name the assumption she knows of, or say she does not know how it was counted. | Converts a gotcha into a credibility gain. Second probe on the same figure. |
| A3 | "Walk me through how the volume targets you set were agreed across orgs." | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Answer slot: name one target, the groups that agreed, and the inputs she used, in her words. If the inputs were set by someone else, say so. If the targets were used for compensation or quota, say so; if not, say what they were used for. | Closest honest bridge to F7. The Prober will go to denominators, so the slot is where the gap is. |
| A4 | "Walk me through an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" (your message) | Open prompt. Pick one analysis she ran end to end, the question it answered and what it changed. If none comes to mind, say so plainly, then give the nearest thing she did in either tool. | JD tag for "run independent analysis in SQL and Tableau" (F3). It is an open prompt because no quote names an analysis. |
| A5 | "What were the partner-level revenue model's inputs, and which one would you have wanted to validate?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Answer slot: name the inputs she can speak to, which of them she owned, and which she did not. | The Prober asks for inputs and denominators. F4 is the row it draws on. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] (no claim about Priya); reciprocity rests on [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name two seam principles rather than pretending to know Dan's seam. Reciprocity: what she brings to their team, at the model's scope, if it overlaps with their work. Answer slot: a disagreement she resolved with an equal team, in her words; if she cannot name one, say so and give the principle she would apply. | Peer stem, and the JD's cross-functional influence line. Reciprocity framing is the pack's answer to "what do you bring us?" |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Credit goes with the sentence's own word: "credited." Say who credited the change and what she did. Answer slot: if credit was shared, name the teams and her part; if some of the work was not hers, say so. | Peer credit probe. Same row as A1, at a different angle. |
| B3 | "On the annual volume targets, who did you need to agree with, and how did you reach yes?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Answer slot: name the groups and what she did to reach agreement. If the agreement was reached in a room she did not run, say whose room. | Cross-functional influence. F5 is the row it draws on. |
| B4 | "If we split the two new lines between our teams, which would you keep and which would you hand me?" | JD | [generic] | A live seam question. State a view and its reason. Make no invented claims about either team. | Tests turf judgment with an equal. The question presupposes nothing about her past. |

### C. Case / Strategist (weight 3, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a comparable capability into its suite at no extra cost. How do you respond for the two new lines?" | CASE | [grounded] "bundling by a much larger platform vendor" (your message) | Clarify first: which buyers, which line, what the bundle includes. Then objective, segmentation, pricing and packaging options, metrics, risks. Challenge one premise respectfully. The problem asks about no past, so it claims nothing about Priya. | Bundling is the note's main threat. Pricing lens is Dan's native language. Profitability ties in through unit economics. |
| C2 | "Northwind is prioritizing enterprise expansion, Compass and profitability. Which one would a new product line most threaten, and how would you sequence go-to-market around it?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your message) | Do not recite the three. Pick one thesis, name the consensus item in one clause, then give one divergence with its reasons. No past claim. | The only company knowledge the pack has is the note. Say so before the call. Differentiate from the note rather than reciting it. |
| C3 | "Enterprise expansion is the priority. Where is the whitespace across land, adopt, expand and renew for a new line, and what would you measure first?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your message); [grounded] "enterprise expansion" (your message) | Segment by account state. Define whitespace, name the metric that tests it first, and say what data it would need and where that data would fail. Do not claim whitespace already found. | JD tag for F2, which is a discovery gap, so the answer is a method, not a finding. Case delivery with a pricing lens. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you would set the volume targets for two new product lines: which inputs, from whom, and what would make you trust them?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "own GTM strategy for two new product lines" (your message) | **Deepest rehearsal.** Hold: the target work is quoted, so answer from it. Answer slot: the inputs she would use and who would own them, in her words. If pressed on quota, concede exactly once: "I haven't set quotas or run sales ops. I set volume targets, agreed across orgs." Hold through two follow-ups by returning to the quoted target work. Never claim quota experience. Name the limit before it is asked: she would need sales ops as a partner for capacity and comp, not as a substitute for her own judgment. The concession uses F7's acknowledgment, sourced from your message. | F1 and F7 together: a data-driven peer who runs sales strategy will test the targets. This is the single most predictable objection. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (your message) | Hold: name the partner-motion gap plainly. Answer slot: whether she has designed any partner motion (how partners are recruited, enabled or paid). If not, the nearest thing is the partner-level revenue model at its own scope, and the first thing she would learn is the partner-motion design. | Skeptic stem. F4 is transferability. Required items are the scoring sheet. |
| D3 | "AI experience is a plus here. What do you use AI tools for, and where would you trust them least?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tasks she uses AI for, in her own words. Answer slot: where she would not trust them, if anywhere. Do not say she builds AI. | The Skeptic tests use versus build. F6 is a low-confidence row, so the honest answer is the one to rehearse. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed the change; the credit is the sentence's." Pause, restate the question, hold through two follow-ups. Concede specifically: answer slot for what she cannot separate from the rest of the work, and how she would separate it if she can. | Hold-then-concede structure. EXP tests attribution under pressure. |
| E2 | "Sixty seconds: why you over an internal candidate for a role that owns two new lines?" | JD | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (your message) | Pause, restate, then 60 seconds: strategy consulting, then product strategy and ops at a consumer-tech company, the partner model, the change she proposed, and why this role. Answer slot on the internal candidate: do not guess their background. | Pressure stem on the JD's headline. The 60-second frame is assembled from quoted sentences only. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (your message) | Pre-scripted 90-second arc: two years of strategy consulting, nine years at a large consumer-tech company in product strategy and ops, the partner model, the change she proposed, and why this role. Add no role title or scope the quotes do not carry. | Casual openers are scored. The arc is assembled from quotes only. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Casual but scored: name the tools and tasks she uses daily, in her words. No build claim. | JD plus-skill asked casually. F6. |

### Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| own GTM strategy for two new product lines | D1, C2 | F1 is transferability |
| identify whitespace across land/adopt/expand/renew | C3 | F2 is a discovery gap, covered by method |
| run independent analysis in SQL and Tableau | A4 | F3 is presentation |
| partner-motion design experience required | D2 | F4 is transferability |
| strong cross-functional influence | B3, B1 | F5 is presentation |
| AI experience a plus | D3, G2 | F6 is transferability |
| Sales-ops and quota-setting (not in JD highlights; a named gap) | D1, A3 | F7 is capability |

## 9. Values / principles cheat sheet

Dropped: no values-style round is detected, and no company values were provided.

## 10. Reverse questions

Each has a one-line "why it lands."

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Shows you are thinking about their load, not only your own. |
| RQ2 | "Your career has run through pricing and monetization, with a startup chapter in the middle. What did the startup change about how you price?" | Ties to Dan's own path and turns an interview into a peer conversation. Shows you read the profile. |
| RQ3 | "Where does your team's expansion work meet the new product lines, and who owns the renewal handoff?" | Seam question. Shows you think in land, adopt, expand and renew, not only in new logos. |
| RQ4 | "Is Compass being sold into existing accounts first, and how is it priced against the expansion motion?" | Uses the priority Dan's team will be living with. Shows the note was read and sharpens C2. |
| RQ5 | "When a larger platform vendor bundles, where has it shown up first for you: renewals or new logos?" | Tests the main threat with a data-driven peer. Expect a data answer, which is what you want. |
| RQ6 | "Which number in the expansion funnel does your team trust least today?" | Signals respect for their method. It lets a data-driven peer tell you where the data is weak. |

## 11. Sources

**Provided documents:** your message, which contained the JD highlights, your summary of Priya's background, Dan's profile and your research note. No CV, no full JD text, no values page, and no dossier were provided. No dossier was consumed.

**Searches and fetches:**

| Query | Result |
|---|---|
| "Northwind Data company values principles" | refused |
| "Northwind Data Compass AI copilot launch" | refused |
| "Dan Kovac Director of Sales Strategy Northwind Data" | refused |

No fetches were sent.

**Research tier:** L1, searches 0 of 6 (three sent, all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet. Dropped anyway: no values-style round is detected. |
| 2. Northwind interview process, role family | unavailable | Loop structure. Persona weights use round-type priors instead. |
| 3. Northwind strategy and recent news | unavailable | Compass's current status and recent moves. The note still fixes the priorities, so C2 runs on the note alone. |
| 4. Dan Kovac and Northwind | unavailable | Public footprint beyond the profile, and any interviewer-specific reverse questions. RQ2 uses the profile only. |
| 5. Representative Director of Sales Strategy JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

## 12. Upgrade menu

- Priya's CV, pasted → her own sentences replace the summary quotes in the fit snapshot. A1 and A2 get checked against how she actually counted the figure.
- Full JD text → the mid-list requirements become verbatim quotes, and any gate (location, pay, schedule, work authorization, a credential) becomes a hard-gate row.
- Approval to run the three refused searches → target rows 1 to 4 turn to yes or unavailable with a reason. Compass's current status gets checked before C2.
- Dan's public talks or writing → the interviewer read gains their recurring themes, and RQ2 is retuned.
- A values page, if the loop has a values-style round → the values cheat sheet (section 9) is added.
- Confirmation that the sales-ops line is Priya's own wording → D1's concession becomes sourced in her words.
- A SQL/Tableau work sample → F3 moves from low confidence to a higher band.
