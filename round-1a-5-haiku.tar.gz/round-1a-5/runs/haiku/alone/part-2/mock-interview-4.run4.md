Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-4-denied-3650cc02/fb7805db-634d-4b34-9c72-1fa446af1184/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it on your dossier, since you didn't say who you're meeting beyond the hiring manager.

Two things to know before Thursday:

- **Company research didn't run.** Web search was refused, so the pack has nothing on Quartzline's values, interview loop or strategy. The question banks are built from the dossier's requirements and your evidence only.
- **The dossier is about three months old** (generated 14 August). Confirm the posting and the team's scope haven't changed.

The pack's core is the objection the dossier named: "You've never held the PM title or owned a roadmap." Rehearse A1 until the concession, the bridge and the ramp plan come out in your own words. The pack never has you claim the PM title, roadmap ownership or squad prioritization, because the dossier lists those as prohibited.

Want me to play the Skeptic on A1 as a drill? I can also add a `pack_feedback` section to your `tuesday-dossier.md` to record what the rehearsal exposes. A Word version of the pack is available too, if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** 45-minute conversation with the hiring manager, Thursday 26 November 2026 (tomorrow, from today's date of 25 November)
- **Interviewer:** name not given. Relationship: hiring manager.
- **Built from:** your message and the job underwriting dossier (`conditional_go`, dossier_version 1.1, generated 2026-08-14). Company research did not run (see Sources), so nothing here is about Quartzline beyond the posting's requirements as the dossier records them.
- **Check before Thursday:** the dossier is about three months old. Confirm the posting and the team's scope have not changed.
- **Changelog:** first version.

## 1. How to use, and the type key

Personas describe how a question is asked. Types describe what it scores.

- **JD**: whether you can do the listed job, gaps included
- **EXP**: whether your claimed work survives scrutiny, and what you actually did
- **CASE**: structure and reasoning on a live problem from the role
- **VAL** and **CO** are not used. No values-style round is detected, and company research did not run.

Guidance is scaffolding, not a script. Say it in your own words, and only the parts that are true for you.

## 2. Prep triage (about one day)

1. **A1, the objection.** Rehearse it until the concession and the bridge come out in your own words. It is the highest-ROI prep in this pack.
2. **Fit rows F1 and F2.** Know the one thing you can say about the integrations, and the one thing you have not done: the PM title and roadmap ownership.
3. **The three evidence stories** (A1, C1, C2), each at the scope its quote carries.
4. **B5 and A5.** Your first 90 days as a plan, and the decision split with the two squad leads.

Everything else is insurance.

## 3. Fit snapshot

Requirements come from the dossier's `role_profile`, which quotes the posting. Evidence quotes come from the dossier's `verified_candidate_evidence`. No `evidence_map` was in the dossier, so the confidence and gap grades below are this pack's, from the dossier's own grading where it gave one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | Your evidence is integration leadership, not product management years. Bridge: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Limit, as this pack's observation: the material shows no product management years and no PM title. Answer slot: if any of those integrations' scope or requirements were yours to decide, say which and how you decided; if not, say so and stay with the integrations you led. |
| F2 | Owning a roadmap and prioritization authority (R1 sub-claim); role_profile responsibility "Own the roadmap for the partner-facing API platform" | none given | none | [grounded] (dossier uncertain_or_weak_areas entry, acknowledge_gap) | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area and prohibited_claims ("Having owned a product roadmap", "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a ramp plan, stated as a plan and never as a past. No bridge. |
| F3 | "Shipped API or platform products" — dossier role_profile R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | Integration work on a vendor's API product, not a shipped API product of your own. Bridge: the same quote at its own scope. Limit: the material does not show you shipping a product. Answer slot: if you shaped what the vendor shipped, say which and how you decided; if not, say so and stay with the integrations. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 (important) | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | high | [grounded] | discovery | The playbook is inspectable, but the material does not show API docs or schema work. Answer slot: if you wrote, reviewed or read API docs or schemas as part of those integrations, say which and what; if not, say so and say how you would get fluent quickly. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | The quote reaches the customer side only: scoping through go-live is client-facing work. Limit, as this pack's observation: the material shows no work with engineering or sales stakeholders. Answer slot: if you worked with the vendor's engineers or sales team on those integrations, say how; if not, say so and say how you would run it across the three groups. |
| F6 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [grounded] (dossier uncertain_or_weak_areas entry, discovery, clarify) | discovery | No verified evidence speaks to it. Clarify: answer slot. If you have run sprint-based delivery, name the team and your part in it; if not, say so, then say what you would want to confirm about how this team defines and runs it. |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | Your quote is partner input routed to product, not discovery you ran. Bridge: the quote at its own scope, with the caveat named: confirmed, limited inspectable proof, expect a probe. Answer slot: if you ran any discovery with clients yourself, say what you asked and how; if the sessions were product's, say so and stay with the input you brought. |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibility; unknown "How adoption is measured today" | none given | none | [grounded] | discovery | The material shows no adoption measure. Answer slot: if you defined or tracked a usage measure for an integration, say what it counted; if not, say so and say what you would measure first. |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | The quote carries scoping and requirements work on client integrations, not specs that engineering squads built against. Bridge: the quote at its own scope. Answer slot: if you wrote specs that engineers built against, say which and what they covered; if not, say so. |

## 4. Prohibited claims

What this pack will not coach, and why. The first three come from the dossier's `prohibited_claims`, so each is sourced; the last three are inflated forms this pack built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims, quoted whole: "Having held a product manager title or role" | Plain acknowledgment: "I haven't held a product manager title." |
| Having owned a product roadmap | Sourced: dossier prohibited_claims, quoted whole: "Having owned a product roadmap" | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims, quoted whole: "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Owned the partner-facing API platform's roadmap | Inflated form of F1, against the JD responsibility "Own the roadmap for the partner-facing API platform" | The F1 quote at its own scope. The limit, as this pack's observation: the material shows integrations led, not a platform owned. |
| Shipped an API product | Inflated form of F3 | The F3 quote at its own scope: integration work on the vendor's product. |
| Ran partner discovery | Inflated form of F7 | The F7 quote at its own scope: "feeding client evidence to product." |

## 5. Interviewer read

Not included. No interviewer name or profile was given, so there is no public footprint to read.

## 6. Persona weights

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 questions | "You've never held the title, why you?" and the day-one weakness | Highest. A hiring manager is buying capability and derisking gaps; the dossier names this objection and two rows (F1, F2) are the gaps | Name the gap first, hold the integration work, concede specifically, then a ramp plan |
| Case / Strategist | 5 questions | Live problems from the role: diagnose adoption, a stalled partner, a decision split | High. Hiring-manager prior is Case plus Skeptic, and the posting names roadmap and adoption work | Clarify first, then structure, then a named weakest assumption |
| Data-Driven Prober | 3 questions | Counting the 30+ integrations; what happened to the roadmap-input evidence; how adoption would be measured | Medium. The medium-confidence row F7 and the 30+ figure invite it | Defend-the-number: how counted, the weakest assumption, which part was yours |
| Pressure / Stress | 3 questions | "Sixty seconds: why you?"; "how much of it was actually you?"; squad leads disagree | Medium. The objection is pressure-prone, and the depth follows the Skeptic | Hold one position through two follow-ups, then concede one specific thing |
| Conversational / Rapport | 2 questions | "Walk me through the journey"; the partner problem you find interesting | Low for a hiring manager, but casual openers are scored | A ninety-second arc with the limit in the middle |

Total: 18 questions.

## 7. Question banks

Depth follows weight. Each guidance cell rests on the quotes in its own Provenance column, and the rationale refers to history only by fit-snapshot row ID.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1). Acknowledgment sourced to dossier prohibited_claims "Having held a product manager title or role" and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Concede first and specifically: "You're right, I haven't held the PM title or owned a product roadmap." Then hold what you can back: "What I've done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Bridge with the limit: "That work is adjacent to this role, not the same job." Hold through two follow-ups by returning to the integrations. If pushed on decision rights, concede the second thing: "I haven't set prioritization for an engineering squad, and I'd want to learn how decisions here are split before I claim authority over them." Close with the ramp plan, as a plan: "In the first month I'd want the decision split agreed with both squad leads and the current adoption baseline." | The objection the underwriter named, and the deepest rehearsal in this pack. It will come in some form. F1 and F2 are its evidence and its limit. Its premise is the dossier's, and each negative in it has a source named in the Provenance column. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility). Acknowledgment sourced to dossier prohibited_claims "Having set prioritization for an engineering squad" | Name the weakness before they do: "Owning the roadmap and making prioritization calls across two squads. I haven't done either, so that's where day one is steepest." Then name the first two things you would do, in your own words. Keep the plan in the future tense. | The Skeptic's stem. Naming the weakest area first turns the probe into candor. F2 is the evidence. |
| A3 | "I don't see product management in your background — how would you handle the roadmap work here?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier 3, medium confidence) | Give the adjacent case with its caveat: "I ran quarterly roadmap-input sessions, and they fed client evidence to product. The roadmap decisions weren't mine to make." Say the caveat before they ask: it is confirmed, with limited inspectable proof. Answer slot: if you can name a product change that traces back to that evidence, say what it was and how you know; if no traceable change came of it, say so. | F7 is the adjacent roadmap experience. Medium confidence means a probe is likely, so the guidance volunteers the limit. The "weren't mine" line rests on the dossier's prohibited claim about roadmap ownership. |
| A4 | "What does agile delivery look like to you inside a product team?" | JD | [generic] | Clarify, since no verified evidence speaks to it. Answer slot: if you have run sprint-based delivery, name the team and your part in it; if you have not, say so, then say what you would want to confirm about how this team defines and runs it. Do not describe a working model you have not used. | R5 is preferred and low confidence, so the dossier's clarify strategy applies. The question asks for a view, not a fact about you. |
| A5 | "What would you need to see from the two squad leads in the first month to know this role is working?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility) | Answer with a test, not a feeling: the decision split written down with both squad leads; one list of partner requests with a named decider for each; one adoption baseline everyone agrees on. Say these as what you would look for, not as what you have done. | The interviewer's live problem on the open decision-rights item. It presupposes nothing about your past. |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A third of your partners stall after their first integration. Where do you start?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1), if you draw on it. Framework is [generic] | Clarify first: what counts as stalled, and whether there is a baseline. Segment by the stage where the stall happens, using the five stages your quote names. Give one hypothesis per segment and one metric per hypothesis. Name your weakest assumption before they do. If you draw on integration work you led, use the quote's stages and nothing more. | Scores structure: clarify, segment, approach, metrics, risks. The stages come from the quote, so the answer draws on what you have. Covers F7's partner-discovery requirement. |
| B2 | "Partner API adoption is flat this quarter. Diagnose it." | CASE | [generic] | Clarify what adoption means and what the baseline is. The material does not establish how it is measured today, so ask. Segment the partner base, state the two or three hypotheses you would test first, and name the metric you would check each against. Do not invent a figure. | The Case stem. F8 is the open item it touches, so the clarifying move is the right first move. |
| B3 | "Which decisions would you want to own yourself on this platform, and which would you hand to the squad leads?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility). Framework is [generic] | Give a principle, not a claimed split: partner-facing scope and sequencing as proposals you would own; engineering trade-offs left to the squad leads; the split confirmed in writing before you start. Do not claim you have held that authority. | R4 and the open decision-rights item. The principle is a pattern for the role, not a claim about your past. |
| B4 | "Walk me through how you'd write the spec for a new partner-facing endpoint that two squads have to build." | CASE | [grounded] "Wrote the internal integration playbook her team uses" (dossier 2). Sequence is [generic] | Walk the spec in order: the partner problem; the requirements; the schema and docs the partner needs; acceptance criteria for each squad; sequencing between the two squads. Answer slot: if you have written or reviewed a spec that engineers built against, name one and say what it contained; if not, say so and walk through the spec you would write. | R3 and the "write specs" responsibility. F4 and F9 are its evidence and its limit. The playbook is the one inspectable artifact in the snapshot, and the guidance draws on nothing beyond it. |
| B5 | "What would your first 90 days look like in this role?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility) | Answer as a plan, in the future tense only. Order: learn the decision split with both squad leads; get the adoption baseline; talk to partners about where integrations stall; then propose the first roadmap change. Name the roadmap gap in one clause, then the plan. Do not describe any past 90 days. | The acknowledge-gap-plus-ramp strategy, tested. It checks whether you can plan without claiming a past. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How did you count them, and what did 'end-to-end' include?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1) | Defend the number in your own words: say how you counted, and that end-to-end covers the five stages your quote names. Name the weakest assumption behind the count before they do. Say which of those integrations you ran end to end and which parts were someone else's. Answer slot: if the count came from a register or the playbook, say which; if you cannot say how it was counted, say so plainly. | F3 and F5 both rest on the 30+ figure. The defend-the-number slots apply: counting method, sensitivity, weakest assumption, and which part was yours. |
| C2 | "What happened to that client evidence once it reached product?" | EXP | [grounded, medium] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier 3) | Give the caveat first: "I ran quarterly roadmap-input sessions, and they fed client evidence to product." Then say what you can trace, if anything. Answer slot: if a product decision traces to that evidence, name it and how you know; if nothing traceable came of it, say so. Do not claim influence over the roadmap. | Medium confidence: confirmed, with limited inspectable proof. The caveat is volunteered before the prober extracts it. This is F7's evidence. |
| C3 | "If you had to measure partner API adoption, what would you count, and what would you defend least?" | JD | [grounded] "Define and track adoption metrics" (role_profile responsibility) | No figure of yours is on record, so there is no defend-the-number slot. Name the one measure you would start with and what counts as active use. Name its weakest assumption in your own words. Say the current baseline is not yet known to you, and ask for it. Do not name a figure or a baseline. | F8. The adoption baseline is the open item. The answer stays with the measure and its assumption, not a number. |

### D. Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone with three years of product management?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1). Acknowledgment sourced to dossier prohibited_claims "Having held a product manager title or role" | Pause, then hold: "Because I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Hold through two follow-ups. Then concede one specific thing: "A PM with three years has done the product job I haven't, and they would move faster on roadmap decisions than I would." Do not concede the integration work. | Stress persona: hold one position through two follow-ups, then concede specifically. The held position is the quote's, not a stronger one. F1 is the gap under pressure. |
| D2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1) | Say which stages of the 30+ you ran end to end, and which were run by others on your team. Answer slot: if some were run by others, say how many and which stages you ran; if all were yours, say so plainly and stop there. Do not round the count up. | The attribution-honesty probe on the 30+ figure. C1 covers how it was counted; this covers the share. |
| D3 | "Suppose both squad leads disagree with your roadmap call. What do you do?" | CASE | [generic] | Hold the partner-facing commitment until the decision owner is named. Concede the point you are wrong about, specifically, in sequencing or timing. Name the escalation path you would want agreed first. Say what you would do; do not describe a precedent you have not had. | Tests decision rights from the other side, which F2 leaves open. [generic]: a pattern for the problem, not a claim about your past. |

### E. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier 1); "Wrote the internal integration playbook her team uses" (dossier 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier 3) | Ninety seconds: the integrations first, in the quote's stages; then the playbook; then the roadmap-input sessions, with the medium caveat in your own words; then why this role, naming the step honestly: from integration work toward owning a platform's roadmap. Do not say "product experience" as a claim about your past. | Casual openers are scored. The arc carries the limit in the middle, so it is not an opener that opens a gap. |
| E2 | "What's the partner integration problem you find most interesting these days?" | CASE | [generic] | Answer with one specific integration problem you have seen, in the quote's terms (scoping, requirements, architecture, UAT, go-live). If none comes to mind, say so and give the nearest one. Then ask one question back about how partners raise problems. | F7's partner-discovery requirement, asked casually. An open prompt with an honest branch. |

### Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1: 3+ years product management experience | A1, A2, A3, D1 | Limit stated in F1 |
| R2: Shipped API or platform products | C1, D2 | Limit stated in F3 |
| R3: Technical fluency, API docs and schemas | B4 | Limit stated in F4 |
| R4: Stakeholder management across engineering, sales, customers | B3, D3 | Limit stated in F5 |
| R5: Agile delivery experience | A4 | Clarify strategy, F6 |
| Run discovery with integration partners | B1, E2 | F7 |
| Own the roadmap for the partner-facing API platform | A1, A2, A5, B5 | F2 |
| Define and track adoption metrics | B2, C3 | F8 |
| Write specs and drive delivery with two engineering squads | B4, B5 | F9 |

## 8. Reverse questions

No interviewer profile exists, so none ties to the interviewer's own path. Each one below addresses an open item from the dossier.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it is the decision-rights item, asked before you accept. It reads as diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: you do not know the baseline. The answer tells you whether the metric exists at all.
3. **"What would make the two squad leads confident in whoever owns this roadmap?"** Why it lands: it tests the working relationship from their side.
4. **"How do partner-facing changes get sequenced when both squads have to ship?"** Why it lands: it makes the spec-and-delivery responsibility concrete.
5. **"What has the team learned in the last quarter about where partner integrations stall?"** Why it lands: it asks for the current picture and shows you are listening for what has changed.

## 9. Sources

- **Provided documents:** `tuesday-dossier.md`, in your message. Sections consumed: `role_profile` (the JD tier: requirements, responsibilities, unknowns); `handoff_to_mock_interview` (verified evidence, weak areas, the objection, risks, employer questions, prohibited claims); `decision` (context only). Not present in the dossier: `evidence_map`, `evidence_state`, `risk_register`, so this pack's grades are its own where the dossier gives none.
- **Dossier version:** 1.1, the major version this skill reads.
- **Queries sent:**
  - "Quartzline interview process Product Manager Platform APIs": refused (search permission not granted).
  - "Quartzline partner API platform strategy": refused (search permission not granted).
  - Fetches: none sent.
- **Research tier:** L1, with searches 0 of 6 (both refused) and fetches 0 of 2.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet. Only applies if a values-style round is detected; none is, so it would have moved nothing here. |
| 2. `Quartzline interview process Product Manager` | unavailable | Loop structure and persona weights. The query was refused, so the weights rest on the hiring-manager prior alone. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and CO questions. The query was refused, so no CO questions were written. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD questions. |

## 10. Upgrade menu

- **Search access, or a pasted company page** → a grounding brief and loop-structure check, which would firm up persona weights and add CO questions.
- **The interviewer's name** → a public-footprint read, persona weights based on it, and a tailored reverse question.
- **A record of the roadmap-input sessions** (agenda, product readout, a message) → F7 and C2 move from medium toward high, and C2 gets an answer you can point to.
- **A sample spec you wrote for an integration, if you have one** → B4 and F9 draw on a real artifact instead of an answer slot.
- **The posting's current text** → confirms whether the dossier's `role_profile` still matches the role as it stands now.
- **Deep research (L2)**: a strategy brief, interviewer talks, role-family loop reports, and recent org context. It needs search access and would add up to six searches and two fetches.
