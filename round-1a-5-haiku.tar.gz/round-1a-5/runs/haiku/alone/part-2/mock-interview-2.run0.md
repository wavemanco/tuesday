Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/haiku/alone/part-2/rooms/case-2-denied-b32b741c/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. I did not search for Atlas Freight, so it uses only your job description and your background.

The three things the pack says to prepare first:

- **Span of control (B1, highest-ROI):** the JD asks you to lead 12 supervisors across four sites. Your evidence is 3 supervisors at one site. Rehearse saying the number you've led, then your plan for the gap, without bluffing.
- **The 5+ years leadership requirement (B2):** the material doesn't show how many of your 7 years were in a leadership role. Have the dates ready.
- **Power BI (B3):** you've never used it. The honest answer is "I've never used Power BI," then a concrete plan to learn it.

I'd also drill your mis-pick result. Expect "how was that counted?" and "how much of it was actually you?" (C1, D2).

Would you like me to play the Skeptic on B1 so you can rehearse it live? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would reshape it:

1. Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.
2. Do you have five or more years of leading people in operations? Your note gives 7 years of operations work and 3 supervisors, and the JD requires five years of leadership.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (regional logistics, about 800 employees, four sites)
**Company:** Atlas Freight
**Interviewer:** not named. **Round:** not stated. Built as a hiring-manager round, with flat weights adjusted to the JD.
**Research:** none run. This pack uses only your job description and your background. Company values, loop structure and recent news are absent (see Sources).

---

## How to use this pack

- **Personas** describe how a question arrives (the tone and the pressure). **Types** describe what is being scored.
- **Type key:**
  - **VAL**: behavioral / values alignment. Whether past behavior shows the company's published values.
  - **EXP**: work-experience deep-dive. Whether your claims survive scrutiny, and what you personally did.
  - **JD**: role-driven. Whether you can do what the listed job asks, including its gaps.
  - **CO**: company and strategy knowledge. Not covered here, because no company research was run.
  - **CASE**: hypothetical or live problem, delivered in the interview.
- **Guidance is scaffolding, not a script.** Use your own words. Where a guidance cell says "answer slot", the answer depends on your real experience. Give the honest branch if the real answer is no.

---

## Fit snapshot

Each row sets a JD requirement against your own words. Quotes are your exact sentences, or the JD's exact lines. Gap and bridge language is what you can say aloud.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material shows shift management over 3 supervisors at a site you described as "the site's" surge plan. It does not show daily ownership across four sites, and the bridge stays at that scope. Answer slot: if you ever had a daily view of more than one site, say what it was; if you did not, say so plainly and describe how you ran your own site's day. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message) | low | [grounded] | transferability | Your material shows accuracy (mis-pick rate), not on-time performance or cost per shipment. Keep the bridge at its own scope: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment in any role, say which and how; if you did not, say so plainly and name the measure you would watch first. |
| F3 | "lead a team of 12 supervisors" (JD) | "senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows leading 3 supervisors. The step to 12 is not shown, so the bridge stays at 3. Answer slot: if you have led a larger group of leaders, say how many and what they reported; if not, say so plainly, and say how you would structure a team of 12. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish this gate. It gives 7 years of operations work, and it does not say how many of those years were in a leadership role. Not bridged. The one question this pack asks about it is in the message that presents it. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | presentation | Your quote reaches the Excel half in your own terms. Use the quote as it stands: "solid Excel." Nothing is added about what you have built. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | The Power BI half is a gap you stated. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | Your credential reaches the requirement in role-relevant terms. A credential with nothing inspected behind it draws a probe. Answer slot: name the process you applied the method to and what it measured; if you did not apply it to a project, say so plainly. |

Seven rules this table follows: confidence, provenance and gap type each hold one value; evidence holds only your sentences; the JD lines are quoted exactly; qualifiers sit in the last column; gap rows get words, and those words have a source; gap type follows the evidence cell; bridges are checked for claims that outrun the quote.

---

## Persona table

**Weights and reasoning.** No round type, interviewer or loop was given, so these weights are a hiring-manager prior. A hiring manager for an operations leader is buying capability and derisking gaps, so Case and Skeptic lead. Tell me the round and the weights change (see Upgrade menu).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (5 questions) | Live problems on terminal operations: an on-time miss, cost per shipment across sites, a reporting design. | High. The JD's headline asks (on-time, cost, four sites) are operational problems, so expect live cases. | Clarify, then structure, then name the first measure. Describe the approach, not a result you have not had. |
| Skeptic (4 questions) | Pressure on the gaps: span of control, multi-site scope, the 5+ years gate, Power BI. | High. F1, F3, F4 and F6 are the largest gaps in the material. | Rehearse the span question until it is routine. Hold on the number you have, concede the gap in one sentence, then give your plan. |
| Data-Driven Prober (3 questions) | Asks how the 40% was counted, what the peak-season plan measured, what the Green Belt project was. | Medium-high. Your headline figure and your certification both draw probes. | Say the weakest assumption before they do. Say "I don't know" where you don't. |
| Pressure / Stress (3 questions) | Time-boxed challenge: "how much of that was actually you?", "why you over someone who has run four sites?" | Medium. Common for operations roles where composure under fire matters. | Pause. Restate. Hold the number and your share. Concede the span difference without folding. |
| Peer Evaluator (2 questions) | Seams between sites and teams; credit when results span teams. | Low-medium. A hiring manager may bring in a peer; the peer seam is real across four sites. | Propose seam principles, not facts about their network. Name the people in any shared result. |
| Conversational / Rapport (2 questions) | "Walk me through the journey"; a casual question about Excel. | Low-medium. Casual questions are still scored. | A 90-second arc from your own sentences. Answer the Excel question concretely. |

Total: 19 questions across six personas.

---

## Question banks

Provenance carries every sentence your guidance rests on, quoted exactly as in the fit snapshot. Rows that make no claim about you carry their label alone.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "One of your terminals misses on-time performance on two of its three shifts. What do you need to know before you change anything?" | CASE | [generic] | Clarify first: which shifts, how on-time is measured, what changed on those shifts recently. Then structure: measure by shift, find where the misses start, pick one lever to test first. Say the first measure out loud. | A live problem from the JD's on-time line, asked as a decision. It makes no claim about your history, so it carries no quote. |
| A2 | "Cost per shipment differs across your four sites. Where do you start in the first month?" | CASE | [generic] | Ask what the cost-per-shipment figure includes and who owns it. Compare sites on their cost drivers, not the total. Pick the site where a driver is both measurable and changeable. Say what you would not change yet. | The JD's cost line as a structured choice. No claim about your past. |
| A3 | "Design the weekly terminal report that four site leads and the regional director will both read. What goes on it?" | JD, CASE | [grounded] "build reporting in Excel/Power BI" (JD); [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Lead with five or fewer measures, each with one written definition and one owner, then the trend and the exceptions. Tool second. If asked which tool, say "solid Excel" for what you have. For Power BI, say "I've never used Power BI," then the plan: how you would learn it on this report. | The JD names the reporting tools, so this is the requirement's likeliest practical test. F5 and F6 are the evidence behind the tool answer. |
| A4 | "You inherit four sites whose leads know them better than you do. What do you do in the first 30 days?" | JD | [generic] | Listen before you change. Walk each site's floor, meet each lead, and agree one on-time and one cost baseline with them before you touch a process. Name the site you would look at first and why. | A hypothetical about four-site ownership. Judged on sequencing, not on experience. |
| A5 | "Walk me through how you would lead twelve supervisors in your first quarter." | JD | [grounded] "senior shift manager over 3 supervisors" (your message) | Structure: a standing one-to-one with each supervisor, one shared metric, one shift-start standard, and a clear escalation path. Answer slot: if you have led a larger group, say so and how; if not, say what you have led, "senior shift manager over 3 supervisors," and give the plan at twelve. | The JD's headline people requirement, asked as a plan. The slot stops a claim of experience with twelve. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've led three supervisors. How would you lead twelve across four sites?" | JD, EXP | [grounded] "senior shift manager over 3 supervisors" (your message); [grounded] "lead a team of 12 supervisors" (JD) | **Highest-ROI prep in this pack.** Open with the number you have led, in your words. State the JD's number without comment. Then the plan for the gap: how you would stage it. Hold through two follow-ups by returning to three, not by adding to it. Answer slot: if you have had any view across more than one site, or led more than three supervisors, say so; if not, say so plainly. | The span gap is the largest in the material, and "12 across 4 sites" is where a Skeptic lands. Deepest rehearsal here, because the honest answer is a concession, and folding or bluffing fails the probe. |
| B2 | "The JD asks for five years of operations leadership. How many years have you led people, and in what roles?" | EXP, JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "senior shift manager over 3 supervisors" (your message) | Give dates. Separate the years of operations work from the years you led people. Answer slot: if you have five or more years of leading people, give the roles and dates; if you have fewer, give the number as it is, alongside the 7 years of operations work. | F4 is the gate the material does not establish. The question is the interviewer's line; the answer is dates in your own words. |
| B3 | "You've never used Power BI, and this role builds reporting in it. Why should we wait for you?" | JD | [grounded] "never used Power BI" (your message) | Say: "I've never used Power BI." Then a first-month plan, said as a plan: what you would learn and how you would prove it on real reporting. If you know how long it would take, say it; if not, say so. Hold: do not argue that Excel makes Power BI unnecessary. | F6 is the clearest gap. The premise is your own sentence, so the question may presuppose it. Hold, then concede the timeline honestly. |
| B4 | "Your strongest result is a mis-pick rate. On-time performance and cost per shipment are what this role is paid for. Why should we believe you move those?" | JD, EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Hold the figure at its own scope: "cut mis-pick rate 40% by redesigning the pick path." That is accuracy, not the two measures. Answer slot: if you tracked on-time performance or cost per shipment in any role, say which and how; if not, say so plainly, then name the measure you would watch first. | "Strongest result" is the interviewer's characterization, not the pack's. The JD raises the two measures. The honest answer is the figure at its scope, plus the slot. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number in your own words: the period, the starting point, what counted as a mis-pick, and who counted. Name the weakest assumption before they do. Answer slot: if you know how it was counted, say it; if not, say "I don't know how the baseline was counted," and say which part of the redesign was yours, or, if the redesign was not yours, say so. | Every headline metric gets a defend-the-number question. The guidance supplies no method or baseline, because your material supplies none. |
| C2 | "What was in the peak-season surge plan, and what would you measure to say it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Name what the plan contained, in your words, and that you ran it two years running. Answer slot: if you measured whether it worked, say what and how; if you did not, say so plainly. | Your second headline claim. A prober asks how success was known. The question presupposes only that the plan existed and was run. |
| C3 | "Your Green Belt: what process did you apply it to, and what did the project measure?" | EXP, JD | [grounded] "green belt certified" (your message); [grounded] "Lean/Six Sigma a plus" (JD) | Name the credential as stated: "green belt certified." Answer slot: if you applied the method to a process, name the process and the measure; if you did not apply it to a project, say so plainly and say how you would apply it here. | A credential draws a probe about its use. The second branch allows that no project happened. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run four sites?" | JD, EXP | [grounded] "senior shift manager over 3 supervisors" (your message); [grounded] "7 years in warehouse and distribution ops" (your message) | Pause. Restate the question. Anchor in what you stated. Hold: do not claim four sites or any multi-site role. Hold two follow-ups by returning to the mis-pick result and the surge plan, each at its own scope. Concede precisely: someone who has run four sites has more span than you do now. | Composure test. The honest answer uses only what you stated and concedes the span difference without folding. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the figure and the redesign as your message states them. Say your share in your own words. Answer slot: if the redesign was yours, say which parts; if it was a team's, say so and say what you did in it. | Attribution under pressure. Hold on the figure; concede the share if it is smaller. |
| D3 | "This is a step up from senior shift manager. Why now?" | JD | [grounded] "senior shift manager over 3 supervisors" (your message) | Agree that the scope is bigger. Give your own reason for applying, in your words. Answer slot: if you have a reason for moving now, say it; if you have not settled it, say so plainly. | A motivation probe. The reason is yours to give, and the pack supplies none. |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our distribution teams and your four terminals share handovers. Where's the seam, and what happens when we disagree?" | JD, CASE | [generic] | Propose seam principles, not facts about their network: one owner per handover, one shared on-time definition, a named escalation. Say what you would want from them. Answer slot: if you have disagreed with another team over a handover, say what was decided and how; if not, say how you would raise it. | A peer seam probe prices how the hire affects the peer's load. No claim about your past. |
| E2 | "How do you handle credit when a result spans two teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name who was involved in the redesign and what each did, in your words. Answer slot: if other teams were involved, name them and what they did; if the redesign was yours alone, say so. | A credit probe on your headline result. The slot prevents a credit claim your material does not carry. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); [grounded] "green belt certified" (your message) | A 90-second arc: the seven years, the shift role, the pick-path result, the surge plan, the Green Belt. Each beat is a clause your sentences state. Add no event between them. | Casual openers are scored. The arc uses only your stated clauses. |
| F2 | "What's the Excel side of your day-to-day look like?" | JD | [grounded] "solid Excel" (your message) | Keep it concrete and in your words, about what you do. Answer slot: name one piece of Excel work you have done and what it fed; if none comes to mind, say so. | A JD tool asked casually. Still scored. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A4, B1 |
| Drive on-time performance and cost-per-shipment down | A1, A2, B4, C2 |
| Lead a team of 12 supervisors | A5, B1 |
| Build reporting in Excel/Power BI | A3, B3, F2 |
| 5+ years operations leadership required | B2 (the gate, also asked in the message) |
| Lean/Six Sigma a plus | C3 |

---

## Reverse questions

Five questions to ask the interviewer. No interviewer profile exists, so none is tied to their career path.

1. **"What does the first 90 days look like for someone taking over the four terminals?"** Why it lands: it shows you are planning for the scope, not just the title.
2. **"How are on-time performance and cost per shipment reported to you now, and how often?"** Why it lands: it anchors the JD's two measures in how they are actually tracked.
3. **"How many of the twelve supervisors are new in role this year?"** Why it lands: it shows you are thinking about the team as it is, not as the org chart says.
4. **"What does the business count as cost per shipment, and who owns that number?"** Why it lands: it surfaces the definition question before you are asked it in a test.
5. **"Is the reporting meant to be built in Power BI from the start, or moved from Excel over time?"** Why it lands: it turns your Power BI gap into a question about the business's plan.

---

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot. Each entry names its basis, and its honest form is what you can say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1. Your material says a site's shift and surge plan, not four sites. | "senior shift manager over 3 supervisors," at its own scope. The pack observes that the material does not show four sites. |
| Led a team of twelve supervisors | Inflated form of F3. Your material says three. | "senior shift manager over 3 supervisors." The twelve stays a plan. |
| Has five or more years of operations leadership | Inflated form of F4. Your material does not establish it. | The dates you give in answer to B2, if any. The pack observes that the gate is not established by the material. |
| Improved on-time performance or cost per shipment | Inflated form of F2. Your material says mis-pick rate. | "cut mis-pick rate 40% by redesigning the pick path." |
| Has Power BI experience | Negative you stated (F6). | "I've never used Power BI." No slot beyond the plan. |

---

## Sources

- **Provided documents:** the Atlas Freight job description as pasted in your message; your background in the same message.
- **Dossier:** none present.
- **Research tier:** L0. No search or fetch was run. The company, its values, its interview process and its recent news are not established.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet (not built; no values round is detected, so the section is dropped). |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure. Persona weights are a hiring-manager prior, not a loop read. |
| 3. `Atlas Freight strategy / recent news` | unavailable | Company and strategy questions (CO). None are written. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- The round type and who you will meet → persona weights and bank depth reordered to match the round (the message asks)
- Five-plus years of leading people, confirmed → F4 becomes a grounded row, and B2 can be answered with dates
- Light research on Atlas Freight's values, interview process and recent news (six searches, two page fetches at most) → the values section, a loop-shaped persona weighting and company-strategy questions (CO) that stop being generic
- A recruiter's note on process details, such as whether there is a case or presentation → the round's structure and any graded deliverable
- Prep time before the interview → a prioritized schedule tied to question IDs; the highest-ROI rehearsal is B1
- A `tuesday-dossier.md` from an earlier session → verified evidence replaces the inferred rows, and any recorded objections replace the local prohibited list
