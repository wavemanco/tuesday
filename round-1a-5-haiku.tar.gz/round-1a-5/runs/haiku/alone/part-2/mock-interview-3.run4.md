Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-3-denied-1a334840/0b23b50e-61ea-4928-ac5e-15fa9f239dcf/scratchpad/stripe_product-operations-manager_interview_pack.md. It's a generic pack. I had no CV, job description, or interviewer details, and web search was refused in this session, so it has nothing about Stripe's values, interview loop, or current strategy. Treat the 18 questions as practice, not a forecast of what you'll be asked. It covers case, data, pressure, skeptic, behavioral, conversational, and peer styles, plus a reverse-question list.

Once you share the job description and your CV, I can name your most likely objection and write answers built on what you actually did. Those answers would be much stronger than the generic guidance here.

- Say the word and I'll run a live round where I play the Case/Strategist on question A1, with feedback against that question's guidance.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and in what format: your future manager, a peer, a panel, or a values round? Did the recruiter announce a take-home or presentation?
2. Can you paste the job description and your CV, or a short summary of your background?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

**Interviewer:** not known. **Round format:** not known. **Pack type:** generic worksheet variant. No CV, job description or background was provided, so the candidate-evidence columns are empty and the questions are built from role-family knowledge.

**What changed:** first session; nothing regenerated.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only about things you actually did.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values alignment | Whether past behavior shows the company's published values. Not used here: no published values were read. |
| EXP | Experience deep-dive | Whether your past work holds up under scrutiny, and what you personally did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps. Not used here: no JD was read. |
| CO | Company knowledge | Homework on strategy and recent moves. Not used here: research was unavailable. |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |

## 2. Persona weights

The relationship to your interviewer is unknown, so every persona gets flat weight. This is a weaker pack than one built on a known round, and each bank below says so only where it matters.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 3 | Live operational problems | Medium. Final rounds for ops roles often include one. | Clarify the goal, then structure, then answer. Think aloud. |
| Data-Driven Prober | 3 | Follows any number you give to its assumptions | Medium. Any figure you give will be checked. | Know how each figure was counted. Name your weakest assumption first. |
| Pressure / Stress | 3 | Interrupts, time-boxes, challenges your fit | Medium. A common final-round test of composure. | Pause, restate, hold a position through two follow-ups, then concede specifically. |
| Skeptic | 3 | Probes gaps and motivation | Medium-high. Every final round tests why you and why now. | Rehearse the one objection until it is plain. Concede without bluffing. |
| Behavioral | 2 | Asks for past examples | Medium. Expected in most final rounds. | Use STAR. Say "we" for context and "I" for your part. |
| Conversational | 2 | Friendly openers that are scored | Low to medium | Give a short, complete arc. Treat casual questions as scored. |
| Peer Evaluator | 2 | Seams between teams, credit, disagreement | Low to medium. Higher if the round is with a peer. | Describe seam principles, not claims about their team. |

## 3. Question banks

Every row is `[generic]`: no sentence of the candidate's own is quoted, so no guidance asserts anything about their past. Where a question asks for a past example, the guidance is a selection scaffold ending in an honest branch.

### Case / Strategist

| ID | Question | Type | Provenance | Guidance (about 90 to 120 seconds) | Why it's here |
|---|---|---|---|---|---|
| A1 | A launch due Friday still lacks sign-off from legal and support. What do you do in the next hour? | CASE | [generic] | Clarify what sign-off gates: shipping, or only launch communications. Name the decision owner, the cost of shipping against the cost of slipping, and the one message you would send. | Launch coordination is core to the role family. The question tests triage, not a right answer. |
| A2 | The weekly product review runs long and decisions do not stick. Diagnose it and tell me what you would change in a month. | CASE | [generic] | Clarify the meeting's purpose and who attends. Separate a decision problem from an agenda problem. Propose one change to test and one measure to read it by. | Process diagnosis is a common ops case. |
| A3 | Name a metric you would put on a dashboard for a team shipping a new feature, and tell me how it could mislead you. | CASE | [generic] | Pick a metric tied to the team's goal. Name its likeliest failure, such as gaming or a bad proxy. Say how you would check it. | Tests metric judgment without asking about past numbers. |

### Data-Driven Prober

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| B1 | Tell me about a time you used data to change a decision. What was the number, and how did you know it was right? | EXP | [generic] | Open prompt. Pick one instance where data changed a call. State the metric, its source, the assumption you would defend least, and which part was yours. If no such time comes to mind, say so plainly, then give the nearest case you have, or how you would approach it. | Any figure you give will be checked. This is the most likely probe. |
| B2 | Tell me about a metric you reported that later turned out to be wrong or misleading. What happened? | EXP | [generic] | Open prompt. If you have one, say what the metric measured, what it missed, and what you changed. If you have none, say so plainly and say what you would check first next time. | Probers ask this to see whether you can admit a flawed number. |
| B3 | How would you know, six months on, that a process you set up was working? | EXP | [generic] | Name two or three signals you would watch. Say how you would separate adoption from impact. Say what you would stop doing if the process failed. | Tests how you measure operational work, which is often where ops candidates are weakest. |

### Pressure / Stress

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| C1 | Sixty seconds: why should we hire you over someone who has run this kind of process for longer? | EXP | [generic] | Hold the position. Name the specific thing you would bring and what you would do in your first 90 days. Do not argue against the other candidate. If challenged, concede one specific gap in experience and keep the rest of the position. | Classic pressure stem. The test is composure, not the content. |
| C2 | That sounds like coordination. Isn't this just project management with a better title? | EXP | [generic] | Hold: separate running a project from designing the system that makes projects run. Hold through two follow-ups, then concede any point that is actually true. | Tests composure under a dismissive challenge. |
| C3 | Tell me about a process change someone rejected. What did you do next? | EXP | [generic] | Open prompt. If you have one, say what was rejected, what you did, and what you would do differently. If you have none, say so plainly, then say how you would make the case for a change. | Pushback on process changes is common in this role. |

### Skeptic

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| D1 | Which part of this role would you be weakest at on day one? | JD | [generic] | Name the one area you would ramp on, say how you would learn it in the first month, and whom you would ask. Do not bluff a competency you lack. | Standard skeptic stem. The real answer depends on the JD, which has not been read. |
| D2 | Why leave where you are, and why now? | EXP | [generic] | Say what you want next, in terms of the work, not what is wrong with your current job. Keep it short. | Motivation-consistency probe that every final round tests. |
| D3 | What would have to be true for you to be unhappy in this role a year from now? | EXP | [generic] | Name two honest conditions, such as no real decision rights or no clear success measure. Say how you would check for them early. | Tests self-knowledge and whether you have thought about the risk. |

### Behavioral

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| E1 | Tell me about a time you got people who did not report to you to do something. What did you do? | EXP | [generic] | Open prompt. Use STAR. Say "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest example you have. | Influence without authority is central to this role family. |
| E2 | Tell me about a time you disagreed with a decision that went ahead anyway. | EXP | [generic] | Open prompt. Say what you said, what you did next, and what you would do differently. Name a moment you did not fold, if one exists. | Tests how you disagree and how you commit afterward. |

### Conversational

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| F1 | So, walk me through your path to here. | EXP | [generic] | A 90-second arc, one line per stage: what you did, what you learned, why it led to the next step. Do not add stages you did not work in. | Biography question. Scored for economy and clarity. |
| F2 | What are you reading or working with right now that's relevant to this space? | CO | [generic] | Name one real thing you have used or read, and say what you took from it. Do not invent a source. | Casual questions about the role's topics are still scored. |

### Peer Evaluator

| ID | Question | Type | Provenance | Guidance | Why it's here |
|---|---|---|---|---|---|
| G1 | Our teams sit side by side. Where is the seam between product and operations, and what happens when we disagree? | EXP | [generic] | Propose seam principles, such as who decides what, rather than claims about their team. Name one disagreement you handled and how you committed afterward. | Seam-splitting between adjacent teams is standard for peers. |
| G2 | How do you handle credit when work spans teams? | EXP | [generic] | Say how you credit people in writing and in meetings. Give one example if you have one, and otherwise how you would set it up. | Probes partnership fit. |

**Session total:** 18 questions, within the 18 to 26 range. Requirement coverage: no JD was read, so none of the banks can be checked against a list of requirements. Until one is supplied, treat the coverage as unverified.

## 4. Fit snapshot (worksheet variant)

No candidate evidence was provided, so every evidence cell is `none given`. The requirements below are role-family prose, not quotes from any posting, and each is `[generic]`. Each bridge says what strong evidence would look like. Answer slots and selection scaffolds appear where a question would need the candidate's past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional process or launch end to end (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: one process you designed or ran across two or more functions, with a result you can state. Selection scaffold: pick a time you coordinated people who did not report to you. If no such time comes to mind, say so plainly, then say how you would handle it. |
| F2 | Use data to make operational decisions (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: one decision changed by a measure you tracked, with the measure's limits stated. Selection scaffold: pick a time a number changed a call. If none did, say so, then say what you would measure first. |
| F3 | Write clear decision memos and briefings for senior readers (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: a document that changed a decision. Selection scaffold: pick one document you wrote for a decision-maker and say what it asked them to decide. If none comes to mind, say so, then say how you would structure one. |
| F4 | Build processes that outlast the person who started them (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: a process still running after you moved on, or one you documented so others could run it. Selection scaffold: pick a process you set up and say who runs it now. If none, say so, then say what you would write down first. |
| F5 | Work with unclear ownership in a fast-changing organisation (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: a time you clarified ownership without a mandate. Selection scaffold: pick a time two teams disagreed about who owned a task. If none, say so, then say how you would find the owner. |
| F6 | Set and track success measures for operational work (role-family prose, no source) | none given | none | [generic] | discovery | Strong evidence: a measure you defined and reported on. Selection scaffold: pick an ops measure you were responsible for and say how it was counted. If none, say so, then say what you would track first. |

## 5. Prohibited claims

Empty for now. The rule is that no claim about your past is coached unless it is in your own words. Nothing you have said so far is available to stretch, so nothing is listed. Once you share a CV or your own description of past work, this list is built from it. Until then, no answer in this pack should be read as a claim about your experience.

## 6. Reverse questions

Each one carries a reason it lands. None is tied to an interviewer's own path, since no interviewer profile exists.

| ID | Question | Why it lands |
|---|---|---|
| R1 | What does this team need to be true in six months that is not true now? | Surfaces the real problem behind the role. |
| R2 | What does a strong first 90 days look like, and who would judge it? | Makes success concrete and reveals who the stakeholders are. |
| R3 | Where has this function's process broken down most often recently? | Shows you think about failure modes rather than only successes. |
| R4 | When product, operations and legal disagree, how is the decision made? | Tests the operating model and the decision rights you would actually have. |
| R5 | What did the last person in this role spend most of their time on, and what would you change? | Candid information about the role's real workload. |

## 7. Sources

- **Provided documents:** none. No JD, CV, interviewer profile, recruiter guidance or dossier was supplied in this conversation.
- **Research tier:** L0. Web search was refused in this session, so nothing about the company was looked up.
- **Searches sent (all refused):**
  - "Stripe company values operating principles"
  - "Stripe interview process product operations manager final round"
  - "Stripe strategy news 2026"
  - "Stripe Product Operations Manager job description"
- **Target accounting:**
  - Target 1, company values: unavailable
  - Target 2, interview process: unavailable
  - Target 3, strategy sweep: unavailable
  - Target 4, interviewer footprint: n/a (no interviewer named)
  - Target 5, representative JD: unavailable
- **What this means for the pack:** no company values, loop structure or strategy is in it. No values cheat sheet, no CO or CASE questions grounded in the company, and no values-style round is assumed.

## 8. Upgrade menu

- **CV or a background summary** → the fit snapshot's six `[generic]` rows become grounded, and the banks get story-mapped answers and a real prohibited list.
- **The job description, pasted** → each requirement is quoted, the coverage table can be checked, and the `[generic]` questions become `[grounded]` where the JD supports them.
- **Who you are meeting, and the round's format** → persona weights stop being flat, and the reverse questions can be tied to the interviewer's path.
- **Recruiter's notes on focus areas or any take-home or presentation** → coverage of the announced deliverable, with a build section for it.
- **Web search allowed** → a standard research pass (company values, interview process, recent strategy) gives a values cheat sheet and company-grounded CO and CASE questions.
- **A `tuesday-dossier.md`** → carries forward the gaps this prep exposes, so later sessions start from them.
