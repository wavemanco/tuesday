Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-5-denied-91023f93/bb66c022-4137-4a08-a7c3-9e940b458b8c/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built on a second-round panel with Deepa (your future manager) and Ross (Commercial Director), a 15-minute POV you deliver aloud, and then Q&A. Web search was refused in this session, so there's no company research in it. The internal market report isn't in what I received, so the pack doesn't use it.

## Prep triage (about four hours)

1. About 90 minutes: build the POV (section 5) and say it aloud twice against a 15-minute timer.
2. About 60 minutes: Ross's bank (A and D), defend-the-number and hold-then-concede.
3. About 45 minutes: C1, the deepest rehearsal in the pack, with two follow-ups each time.
4. About 20 minutes: the reverse questions (section 11).

Everything else is insurance.

## 1. Fit snapshot

No job description was supplied, so the requirements come from the recruiter's own words, quoted, or are role-family prose marked `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in a payments ISV channel, not operator partnerships. The bridge is that quote at its own scope: "took it from 6 partners to 40." Answer slot: if you have a view on how operators buy scheduling software, say what it rests on, and say plainly if it rests on your planning years rather than on selling to operators. |
| F2 | "Please land on what it means for the operators themselves." (recruiter's email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | none | No gap at the level of the quote, which reaches the operator view in role terms. Expect a probe on whether planning-side knowledge is the same as an operator's view. Say which part you know from planning work and which part you would test. |
| F3 | "Ross will push on commercials." (recruiter's email) | "I've never carried a direct quota, only influenced revenue." (your message) | low | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota, only influenced revenue." Then how you would take on a quota, said as a plan, never as a past. |
| F4 | Experience selling into rail operators (role-family, `[generic]`) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "Never sold into rail specifically." Then how you would learn rail buying, said as a plan. |

The material doesn't show operator-side sales, quota ownership, or how any figure was counted. Those are the pack's own observations; the words you say in the room come from the answer slots.

## 2. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Took it from 6 partners to 40 myself, one by one" | Inflated form of F1 | "took it from 6 partners to 40" at its own scope. The material says the channel grew, not who signed each partner. |
| "Carried a direct quota" or "owned the commercial numbers" | Inflated form of F3 | "influenced revenue," quoted. The material says influenced, not quota. |
| "Sold into rail operators" | Negative you stated, F4 | "Never sold into rail specifically." |

## 3. Interviewer read

Public footprint wasn't researched. From the roles alone: Deepa is the hiring-manager pattern (capability and gap-derisking, live problems on the roadmap). Ross is the commercial focus the recruiter flagged, so expect numbers.

## 4. Persona weights (panel)

| Persona | Who | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|---|
| Pressure | Ross | Interrupts on commercials, time-boxes | High: the recruiter named commercials | Hold, then concede specifically. A2, A3 |
| Case / Strategist | Deepa and Ross | Follow-ups on the POV, live plans | High: the POV is a pre-declared deliverable | Clarify, then structure. B1 to B3, A4 |
| Skeptic | Deepa | Quiet probing of rail and quota | High: F3 and F4 are the shown gaps | Acknowledge plainly, then plan. C1 to C3 |
| Data-Driven Prober | Ross | Asks how a figure was counted | Medium-high: the influenced-revenue figure is a headline | Name the weakest assumption first. D1, D2 |
| Values, Conversational | none | none | No values round detected; reverse-question slot still scored | Values sheet dropped; reverse questions, section 11 |

## 5. The 15-minute POV

The recruiter's words set the brief: "where you'd take our operator partnerships over the next 18 months," landing on "what it means for the operators themselves." Only F1 and F2 are facts you can build on.

- **Thesis 1 (lead): operators buy around their planning cycle, not the vendor's sales cycle.** Build on F2. Concession: "I haven't sold into rail, so this is a hypothesis I would test with operators before committing spend."
- **Thesis 2: grow operator partners through enablement, not volume.** Build on F1. Concession: rail implementations are longer and more regulated, so a channel that scaled in payments may not scale the same way.
- **Thesis 3: operators, not partners, should define success measures.** Concession: operators may not want to share outcome data, and this fails if they don't.
- **Differentiation.** The likely consensus is "expand the systems-integrator network and co-sell." Start from the operator's timetable-change cycle instead. Anti-pick: say no to any partner that can't show an operator outcome.
- **Close:** one concrete benefit for a planner, stated as your view, not a platform claim.

## 6. Question banks

**Bank A: Pressure (Ross), top weight**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you commit to on operator revenue in year one?" | JD | [grounded] "Ross will push on commercials." (recruiter's email) | Answer only with a figure whose basis you can show. If you can't build one from operator data yet, say how you'd build it in the first quarter, and why you aren't borrowing the payments numbers. | Commercials is the stated push. Asks for no past figure. |
| A2 | "Sixty seconds: why should we trust your commercial judgement when you've never carried a quota?" | JD | [grounded] "I've never carried a direct quota, only influenced revenue." (your message) | Hold: name what you did own, in your words: influenced revenue, roughly £4M. Hold through two follow-ups by returning to that scope. Concede specifically: no quota carried, and you'd want time to learn how quota decisions are made. Don't fold on the influenced figure. | Pressure version of C3. |
| A3 | "That roughly £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); "took it from 6 partners to 40" (your message) | Answer slot: if you can say what share was yours, say it. If the growth came from many people's work, say so plainly. Don't give a share you can't trace. | Pressure stem on the headline figure. |
| A4 | "Sketch how you would make money from operators in year one." | CASE | [generic] | Clarify first: who pays, direct or via partner, and the buying cycle. Then one model, one metric, one risk. | Commercial push in case form. |

**Bank B: Case / Strategist (Deepa and Ross)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your POV is about partners. Where does the operator's planning team sit in it?" | CASE | [grounded] "(bus and light rail network planning, so I know the operator world from the other side)" (your message) | Say what the planning years show (how an operator plans, where scheduling decisions get made) and what they don't (how operators buy software). Name the boundary. | F2 is the evidence. |
| B2 | "What would you stop doing with operators in the first six months?" | CASE | [generic] | Name one thing you'd say no to, such as chasing the largest operators before smaller ones sign. Give the reason. | Anti-pick with a real trade-off. |
| B3 | "What evidence would change your view of this POV?" | CASE | [generic] | Name one data point and one conversation that would make you drop a thesis. Say it before they ask. | Rehearses the concession in section 5. |

**Bank C: Skeptic (Deepa)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. What would you do on day one that someone who had would not?" | JD | [grounded] "Never sold into rail specifically" (your message); "so I know the operator world from the other side" (your message) | **Highest-ROI prep in this pack.** Lead with the planning knowledge and name its limit: it shows how operators plan, not how they buy. Answer slot: if you've sold into any regulated buyer, name it and what it taught you. If not, say so plainly and set out your first month as a plan, such as operator conversations before any proposal. Hold through two follow-ups. Concede without apology: "I haven't sold into rail." | Will come in some form. The gap is your own stated negative, so the acknowledgment has its source. |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest part honestly (rail buying, or carrying a quota), then the ramp plan, given as a plan. | Skeptic stem; draws on F3 and F4. |
| C3 | "I don't see a direct quota in your background. How would you handle that?" | EXP | [grounded] "I've never carried a direct quota, only influenced revenue." (your message) | Plain acknowledgment: "I've never carried a direct quota." Then the scope: influenced revenue. Then how you'd learn quota decisions, as a plan. | F3's gap. |

**Bank D: Data-Driven Prober (Ross)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: how it was counted, the assumption you'd defend least, and which part was yours. If you don't know how it was counted, say so plainly. | Defend-the-number slot. |
| D2 | "Six partners to forty: how many of those came through your own work?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you signed some, say how many and how. If the growth came from other people's work, say so and name your part. | Second branch allows the premise to be false. |

## 7. Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months | Section 5; B1 to B3 |
| Land on what it means for operators | Section 5 close; B1 |
| Commercials will be pushed | A1 to A4; D1, D2 |
| JD requirements | none supplied; coverage waits on the JD |

## 8. Reverse questions

| # | To | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "What would a strong first 90 days look like, and which operator would you want moved first?" | Shows you're planning around operators, not generic onboarding. |
| R2 | Deepa | "Which operator relationships are working well today, and which aren't?" | Asks for the real map and invites candour. |
| R3 | Ross | "When you look at operator revenue, which number would you want the next hire to move first?" | Puts you in the commercial conversation Ross expects. |
| R4 | Ross | "How do operators measure scheduling outcomes today, and does a partner-sold product change that measure?" | Ties commercials to operator outcomes, your POV's close. |
| R5 | Deepa | "What has to be true in six months for you to say this hire worked?" | Gives you a measure to build the close on. |

## 9. Sources

Research tier: L1. Searches 0 of 6 returned results (3 sent, all refused by the host). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values sheet; dropped anyway, no values round detected |
| 2. Interview process, partnerships | unavailable | Loop structure and round weights; panel fallback used |
| 3. Strategy and recent news | unavailable | Grounding brief and CO questions |
| 4. Deepa and Ross with Kelverton Rail | unavailable | Interviewer read beyond roles; tailored reverse questions |
| 5. Representative JD | unavailable | Fit snapshot requirements; no JD supplied |

Queries sent, all refused: "Kelverton Rail company values"; "Kelverton Rail interview process partnerships"; "Kelverton Rail strategy news."

Provided documents: your message, including the recruiter's email as quoted in it.

## Upgrade menu

- **JD text** → the `[generic]` rows become `[grounded]`, JD-tagged questions are added per requirement, and any gate (right-to-work, office days) is surfaced.
- **Key points from the market report** (segments, numbers, the shortlist) → section 5 can depart from the consensus answer on purpose.
- **Public profiles for Deepa and Ross** → persona weights per member and a tailored reverse question.
- **Your CV** → turns your background sentences into CV quotes and can raise F1 and F3 confidence.

---

Two offers, neither pushed:
- Say the word and I'll run a drill on C1, the question this pack flags as the highest-return prep: I'll play the Skeptic and follow up on what you actually say.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed (rail, quota, the influenced-revenue figure) so they carry into later sessions.

Two questions, which would change the pack:
1. Could you paste the job description, or the posting's requirement list? That turns the `[generic]` rows into quoted requirements and surfaces any gate, such as office days or right-to-work.
2. Could you paste the key points from Kelverton's market report, such as the segments, the headline numbers and the shortlist? I'd use them to find where to depart from the consensus answer. I won't recite them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round prep pack

Panel on Tuesday: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV, no slides, then Q&A. Ross will push on commercials.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioural and values alignment
- **EXP**: your own past work, probed for accuracy
- **JD**: the role's stated responsibilities
- **CO**: company and strategy knowledge
- **CASE**: a live problem

The guidance is scaffolding, not a script. Rehearse the structure and your own words.

## Prep triage (about four hours)

1. About 90 minutes: build the POV (section E) and say it aloud twice against a timer at 15 minutes.
2. About 60 minutes: Ross's bank (A and D), with defend-the-number and hold-then-concede.
3. About 45 minutes: C1, the deepest rehearsal in this pack, with two follow-ups each time.
4. About 20 minutes: the reverse questions (section 11).

Everything else is insurance.

## 1. Fit snapshot

No job description was supplied. The requirements below come from the recruiter's own words, quoted, or are role-family prose marked `[generic]`, which raises no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in a payments ISV channel, not operator partnerships. The bridge is that quote at its own scope: "took it from 6 partners to 40." Answer slot: if you have a view on how operators buy scheduling software, say what it rests on, and say plainly if it rests on your planning years rather than on selling to operators. |
| F2 | "Please land on what it means for the operators themselves." (recruiter's email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | none | No gap at the level of the quote, which reaches the operator view in role terms. Expect a probe on whether planning-side knowledge is the same as an operator's view. Say which part you know from planning work and which part you would test. |
| F3 | "Ross will push on commercials." (recruiter's email) | "I've never carried a direct quota, only influenced revenue." (your message) | low | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota, only influenced revenue." Then how you would take on a quota, said as a plan, never as a past. |
| F4 | Experience selling into rail operators (role-family, `[generic]`) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "Never sold into rail specifically." Then how you would learn rail buying, said as a plan. |

Your material does not show operator-side sales, quota ownership, or the method behind any figure. The pack says so as its own observation. The words you say in the room are the answer slots, and nothing here adds to them.

## 2. Prohibited claims

Built locally from the fit snapshot. Do not say any of these in the interview.

| Not coached | Basis | Honest form |
|---|---|---|
| "Took it from 6 partners to 40 myself, one by one" | Inflated form of F1 | "took it from 6 partners to 40" at its own scope. The limit is the pack's observation: the material says the channel grew, not who signed each partner. |
| "Carried a direct quota" or "owned the commercial numbers" | Inflated form of F3 | "influenced revenue," quoted. The limit: the material says influenced, not quota. |
| "Sold into rail operators" | Negative you stated, F4 | Plain acknowledgment: "Never sold into rail specifically." |

## 3. Interviewer read

Public footprint was not researched (see Sources). With only the roles you have given, the read is limited:

- Deepa is your future manager (VP Partnerships), so the hiring-manager pattern applies: capability and gap-derisking, with live problems on the real roadmap.
- Ross is the Commercial Director, and the recruiter has said Ross will push on commercials. Expect a commercial and numbers focus.

## 4. Persona weights (panel)

A panel blends the top two personas of each member's relationship.

| Persona | Who | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Interrupts on commercials, time-boxes answers | High: the recruiter named commercials | Hold the position, then concede specifically. A2, A3 |
| Case / Strategist | Deepa and Ross | Follow-ups on the POV, live plans | High: the 15-minute POV is a pre-declared deliverable | Clarify, then structure. B1 to B3, A4 |
| Skeptic | Deepa | Quiet probing of the gaps: rail, quota | High: F3 and F4 are the gaps the material shows | Acknowledge plainly, then plan. C1 to C3 |
| Data-Driven Prober | Ross | Asks how a figure was counted | Medium-high: the influenced-revenue figure is a headline on your background | Name the weakest assumption before they do. D1, D2 |
| Values / Behavioural | none | none | No values-style round detected | Values cheat sheet dropped |
| Conversational | none | none | Low; the reverse-question slot is still scored | Reverse questions, section 11 |

## 5. Graded deliverable: the 15-minute POV

The recruiter's own words set this: a short POV "on where you'd take our operator partnerships over the next 18 months," landing on "what it means for the operators themselves." Facts you can build on are F1 and F2 only.

- **Thesis 1 (lead): operators buy around their planning cycle, not the vendor's sales cycle.** Build on F2: "so I know the operator world from the other side." Mandatory concession: "I haven't sold into rail, so this is a hypothesis I would test with operators before committing spend."
- **Thesis 2: grow operator partners through enablement, not volume.** Build on F1: "took it from 6 partners to 40." Concession: rail implementations are longer and more regulated, so a channel that scaled in payments may not scale the same way here.
- **Thesis 3: operators, not partners, should define the success measures.** Concession: operators may not want to share outcome data, and this would fail if they don't.
- **Differentiation from the consensus answer.** The likely consensus is "expand the systems-integrator network and co-sell." Depart from it by starting from the operator's timetable-change cycle. Anti-pick: say no to any partner that cannot show an operator outcome.
- **Requested close: what it means for operators.** One concrete benefit for a planner, stated as your view, not a platform claim.

## 6. Grounding brief

Not built. Company research was not available in this session (see Sources), and the internal market report was not in the material I received. Once you paste its key points, this section can say which consensus answers to depart from.

## 7. Question banks

### Bank A: Pressure (Ross). Top weight, four questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you commit to on operator revenue in year one?" | JD | [grounded] "Ross will push on commercials." (recruiter's email) | Answer only with a figure whose basis you can show. If you cannot build one from operator data yet, say how you would build it in the first quarter, and say why you are not borrowing the payments channel's numbers. Hold the frame, not a number. | Commercials is the stated push, and this is its likeliest form. The question takes the recruiter's line as its premise and asks for no past figure. |
| A2 | "Sixty seconds: why should we trust your commercial judgement when you've never carried a quota?" | JD | [grounded] "I've never carried a direct quota, only influenced revenue." (your message) | Hold: name what you did own, in your words: influenced revenue, roughly £4M. Hold through two follow-ups by returning to that figure's scope. Concede specifically: you have not carried a quota and would want time to see how quota decisions are made. Do not fold on the influenced figure. | Pressure version of C3. The held position is the one you stated. |
| A3 | "That roughly £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); "took it from 6 partners to 40" (your message) | Answer slot: if you can say what share was yours, say it in your own words. If the channel's growth came from many people's work, say so plainly. Do not give a share you cannot trace. | Pressure stem on the headline figure. The share is an answer slot, not a number to supply. |
| A4 | "Sketch how you would make money from operators in year one." | CASE | [generic] | Clarify first: who pays, whether the operator buys direct or through a partner, and the buying cycle. Then one model, one metric, and the risk you would watch first. No claim about your past. | Ross's commercial push in case form. `[generic]` because no quote speaks to operator monetisation. |

### Bank B: Case / Strategist (Deepa and Ross). Three questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your POV is about partners. Where does the operator's planning team sit in it?" | CASE | [grounded] "(bus and light rail network planning, so I know the operator world from the other side)" (your message) | Say what the planning years show: how an operator plans, and where a scheduling decision gets made. Say what they do not show: how operators buy software. Name the boundary between the two. | F2 is the evidence. The question presumes the operator side, which the quote carries. |
| B2 | "What would you stop doing with operators in the first six months?" | CASE | [generic] | Name one thing you would say no to, such as chasing the largest operators before smaller ones have signed. Give the reason and what it protects. | Anti-pick: a strategy question with a real trade-off. `[generic]` because the example is the skill's, not the company's. |
| B3 | "What evidence would change your view of this POV?" | CASE | [generic] | Name one data point and one conversation that would make you drop a thesis. Say it before they ask. | Rehearses the mandatory concession in section 5. |

### Bank C: Skeptic (Deepa). Three questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. What would you do on day one that someone who had would not?" | JD | [grounded] "Never sold into rail specifically" (your message); "so I know the operator world from the other side" (your message) | **Highest-ROI prep in this pack.** Lead with the planning knowledge, quoted, and name its limit: it shows how operators plan, not how they buy. Answer slot: if you have sold into any regulated buyer, name it and what it taught you. If not, say so plainly and set out your first month as a plan, for example operator conversations before any proposal. Hold through two follow-ups by returning to the planning knowledge. Concede without apology: "I haven't sold into rail." | This question will come in some form. The gap is a negative you stated, so the acknowledgment has its source. The day-one plan is a plan, never a past. |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest part honestly: rail buying, or carrying a quota. Then the ramp plan, given as a plan. | Skeptic stem. The answer draws on F3 and F4, the rows the material shows as gaps. |
| C3 | "I don't see a direct quota in your background. How would you handle that?" | EXP | [grounded] "I've never carried a direct quota, only influenced revenue." (your message) | Plain acknowledgment: "I've never carried a direct quota." Then the honest scope: influenced revenue. Then how you would learn quota decisions, as a plan. | F3's gap. The acknowledgment's source is the negative you stated. |

### Bank D: Data-Driven Prober (Ross). Two questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say how it was counted, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. No method is supplied here. | The defend-the-number slot a figure raises. Only your own words go in. |
| D2 | "Six partners to forty: how many of those came through your own work?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you signed some of them, say how many and how. If the growth came from other people's work, say so plainly and name your part in it. | Premised on "took it." The second branch allows the premise to be false. |

## 8. Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | Section 5; B1 to B3 |
| Land on what it means for operators (recruiter) | Section 5 close; B1 |
| Commercials will be pushed (recruiter) | A1 to A4; D1, D2 |
| Job description requirements | none supplied; coverage waits on the JD |

## 9. Values cheat sheet

Not built. No values-style round was detected, and no published values were in hand.

## 10. Reading the interviewer

See section 3. Public footprint was not researched.

## 11. Reverse questions

| # | To | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "What would a strong first 90 days look like in this role, and which operator would you want moved first?" | Signals you are planning around the operator, not generic onboarding. |
| R2 | Deepa | "Which operator relationships are working well today, and which are not?" | Asks for the real map, and invites a candid answer. |
| R3 | Ross | "When you look at operator revenue, which number would you want the next hire to move first?" | Puts you in the commercial conversation Ross expects. |
| R4 | Ross | "How do operators measure scheduling outcomes today, and does a partner-sold product change that measure?" | Ties commercials to operator outcomes, the close of your POV. |
| R5 | Deepa | "What has to be true in six months for you to say this hire worked?" | Gives you a measure to build the POV's close on. |

## 12. Sources

Research tier: L1, searches 0 of 6 returned results (3 sent, all refused by the host); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet; dropped anyway, since no values-style round was detected |
| 2. Kelverton Rail interview process, partnerships | unavailable | Loop structure and round-specific persona weights; panel fallback used instead |
| 3. Kelverton Rail strategy and recent news | unavailable | Grounding brief and CO questions; the internal market report would supply this if pasted |
| 4. Deepa and Ross with Kelverton Rail | unavailable | Interviewer read beyond roles; tailored reverse questions |
| 5. Representative Senior Partnerships Manager JD | unavailable | Fit snapshot requirements; no JD was supplied |

Queries sent, all refused:
- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy news": refused

Provided documents: your message, including the recruiter's email as quoted in it. The internal market report was not in this session, so this pack does not use it.

## Upgrade menu

- **JD text** → the three `[generic]` rows become `[grounded]`, JD-tagged questions are added per requirement, and any gate such as right-to-work or office attendance is surfaced.
- **Key points from Kelverton's market report** (segments, numbers, the shortlist) → section 5 can depart from the consensus answer on purpose, instead of guessing it.
- **Public profiles for Deepa and Ross** (roles, talks, writing) → persona weights per member and a tailored reverse question.
- **Your CV** → turns your background sentences into CV quotes, and can raise F1 and F3 confidence.
