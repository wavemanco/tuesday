Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-8-canned-3b58b0c3/589aef75-1b3c-4a13-b871-8f40bfff2464/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. It's built for all three rounds, each with its own question bank. I didn't ask you anything, since your inputs covered the setup. I didn't run web research either, so the strategy and values content comes from what you pasted.

# Ashgrove Credit Union: Member Experience Lead

**Prep pack, loop mode.** Three rounds on 4 December 2026. Built 25 November 2026.

- **Round 1:** recruiter screen, 30 min
- **Round 2:** behavioural, 45 min, with the Head of Member Services (your future manager)
- **Round 3:** panel, 60 min, two branch managers (names not yet assigned), including a 20-min complaint-escalation case, scored against the four values

## How to use

Personas are how a question arrives. Types are what it scores.

| Tag | Meaning |
|---|---|
| VAL | Values and behavioural: what your past shows about the published values |
| EXP | Your own experience: what you actually did |
| JD | The listed job: its requirements, including gaps |
| CO | Company and strategy |
| CASE | A live problem from the role, worked aloud |

Guidance is scaffolding, not a script. An answer slot ends in an instruction, not a question. It is for the interview and asks you nothing here.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, since no CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Say it in your own words: "I have six years in retail banking, the last three as a branch supervisor." Expect a probe on whether a branch counts as customer operations. Answer with what you did in that work, not with a new label. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | none | No bridge needed. Expect a probe on "regulated". Answer slot: if any complaint you handled was governed by a regulatory requirement, say which and what it required of you. If none was, say so plainly. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | medium | [grounded] | capability | "I've never presented to anyone above regional level." Then a plan, not a past: how you would prepare a first presentation to senior leaders. Your material does not show that you presented the spreadsheet, so don't add it. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | No bridge needed; the spreadsheet is the evidence. Expect a probe on how you built it. Answer slot: name the functions or features you used, in your words. If you built it without formulas, say so. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material carries one branch's log, not a process across branches or the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: which stages of a complaint were yours to decide, from intake to closure. If others set a stage, say so. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly reporting is shown. Resolution times are not in the material. Answer slot: whether the spreadsheet tracked resolution times. If it did, say how they were measured. If not, say so and what you would add first. |
| F7 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as branch supervisor" (your message) | low | [inferred] | transferability | You trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Coaching a supervisor is a plan, not a past. Answer slot: if you coached anyone on an escalation, say what you did. If the closest was training tellers on the script, say that. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, and you haven't said you lack this experience. Answer slot: if you have worked with a digital team on a self-service journey, say which and your part. If not, say so and say what you would need to learn from a digital team before changing a complaints journey. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | medium | [grounded] | capability | "I've never worked in a contact centre." Then a plan: how you would learn a contact-centre queue in your first month. |

**Four things the table enforces:**
- Your material shows one branch's complaints log, not a process across branches or the contact centre (F5, F9).
- Monthly reporting is shown; resolution times are not (F6).
- Presenting above regional level is a gap you named yourself (F3).
- The pack's observations, such as "your material does not show X", are analysis. The words you say come from your quotes or from an answer slot.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B1, C5 |
| Confident presenting to senior leaders | B5 |
| Comfortable with Excel reporting | B4 |
| Own the complaints process end to end across branches and the contact centre | B2, B3, C5 |
| Report monthly on complaint volumes and resolution times | B4 |
| Coach branch supervisors on escalations | B6, B7 |
| Work with digital teams on self-service journeys | B8, C7 |
| Pay, notice and location (posting logistics) | A3, A4, A5 |

## Grounding brief (strategy)

From your summary of the July 2026 brief. Check the exact wording in the document before quoting it in the room.

- Move 40% of member service to digital channels by 2028 (C7).
- Consolidate eight branches into five hubs over 2027 (C6).
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks (C8).

## Persona weights

| Round | Persona (weight) | How it shows | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational / Rapport (top); Skeptic (light) | Friendly openers, logistics, a motivation check, one knockout gap | Recruiter screens are logistics plus motivation consistency. The risk is treating them as unscored. | Script a 90-second background. Treat the logistics as scored. Answer the gap in one sentence. |
| 2, Head of Member Services | Case / Strategist (top); Skeptic (second); Data-Driven Prober (for reporting) | A live escalation problem, a scope challenge, a probe on your spreadsheet | Hiring-manager priors: they're buying capability and checking the gaps. As your future manager, expect operational questions. | Structure before answering. Name the weakest assumption in your own figures. Hold the scope gap, then concede it. |
| 3, panel of two branch managers | Values / Behavioral (top); Case / Strategist (second, for the 20-min case); Pressure (third) | Values-mapped stories, a timed complaint case, follow-ups | The panel scores against the four values, so the values round is the scored round. With no names yet, weights are blended. | Map a story to each value where your material carries one. Where it doesn't, say so. Think aloud in the case. |

## Values cheat sheet

Round 3 is the values round. The panel scores against these four values, as you copied them on 25 November 2026.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | C1. Nearest story: "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message). If no decision against process was yours, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | C2. Nearest story: "trained new tellers on our escalation script" (your message). Say what you changed in it, or that you taught it as written. |
| Neighbours, Not Numbers | Every branch is part of its town | C3. Nearest story: "I built the monthly complaints spreadsheet our regional manager uses" (your message). Your material doesn't show anything about the town. Say so if asked. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | C4. Your material shows a complaints log, not a problem you found and followed to solved. If you didn't see one through, say so. |

## Prohibited claims

These are claims the pack won't coach, with the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 | F5's quote at its own scope. Your material says one branch's log, not the process across branches or the contact centre. B2 stays inside the log. |
| Presented to senior leaders | Your own negative (F3) | "I've never presented to anyone above regional level." No slot. |
| Reported resolution times to your regional manager | Inflated form of F6 | The spreadsheet at its own scope. Whether resolution times were in it isn't shown. B4 asks only that. |
| Worked in a contact centre | Your own negative (F9) | "I've never worked in a contact centre." No slot. |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." Coaching a supervisor is a plan, not a past. |

## Question banks

### Round 1: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background in about two minutes." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Beats: six years in retail banking; the last three as a branch supervisor; then the complaints log and training tellers, in those words. Aim for 60–90 seconds. Add no role and no result. | Opener, scored for economy. F1 and F2 are the only facts about your past in this pack. Covers the 4+ years requirement. |
| A2 | "What is drawing you to Ashgrove?" | CO | [grounded] "Members First, Always — we decide from the member's side of the counter" (published value, pasted) | Name one published value you understand, in your own words, and what it would mean at a branch counter you know. Keep it to about 60 seconds. | Recruiters test whether you read the values. One specific value beats general enthusiasm. |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot. Give your own figure or range in your own words, or say you'd like the role's band first. This pack supplies no figure. | Pay is a knockout logistic. Your answer is yours alone. |
| A4 | "When could you start, and what notice do you owe your current employer?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | Knockout check. The answer is yours alone. |
| A5 | "Where could you work from, and how many office days suit you?" | JD | [generic] | Logistics slot. Say the locations and office days you can actually do. | Location and office pattern are knockouts. The 2027 hub plan may change where roles sit (see reverse questions). |
| A6 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics and motivation slot. Give your own reason in one or two sentences, about the move rather than people. Your material gives no reason, so this pack offers none. | The recruiter checks motivation consistency. The reason is yours alone. Nothing here asks what you want next. |
| A7 | "Your background is retail. This role runs complaints across branches and a contact centre. Where's the gap?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then one plan: how you would learn a contact-centre queue in your first month. | Light Skeptic. F9 is the gap the JD raises. Your own negative needs no slot. |

### Round 2: Head of Member Services (45 min, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you handled the branch's formal complaints log." | EXP, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Beats: what the log held, and what you did with entries, in your own words. Answer slot: say which stages of a complaint were yours to decide (intake, investigation, decision, closure). If someone else set a stage, say who. | F2 is the evidence for the regulated-complaints requirement. The stage question covers the probe the JD's end-to-end line invites. |
| B2 | "The role owns the complaints process end to end across branches and the contact centre. Which parts have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **Highest-ROI prep in this pack.** This scope gap is where the JD presses hardest, so expect it in some form. Hold: "I handled the branch's formal complaints log." Answer slot: if you owned a stage across more than your branch, say which and how you decided. If not, say you handled the branch's log and say how you would learn the wider process. Hold through two follow-ups by returning to the log. If pressed, concede the contact-centre gap plainly. | F5 is the gap. The question presumes ownership the quote doesn't carry, so its second branch allows that the ownership never existed. This is where the deepest rehearsal goes. |
| B3 | "You've never worked in a contact centre. What makes this hire a safe bet?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Plain acknowledgment: "I've never worked in a contact centre." Hold on the part your material shows: "I handled the branch's formal complaints log." Concede the contact-centre gap rather than arguing it. Then one plan: how you would learn a contact-centre queue in your first month. Hold through two follow-ups. | Pressure-style. The test is composure with a known gap. F9 is the gap. |
| B4 | "Walk me through the monthly complaints spreadsheet your regional manager uses. What does it count?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats: what you built, that it runs monthly, who uses it. Weakest-assumption move: name, in your own words, the assumption behind its numbers you'd defend least, before they do. Answer slot: whether it tracked resolution times. If so, say how they were measured. If not, say so and what you'd add first. | F4 and F6 are the evidence for Excel reporting and monthly reporting. The resolution-times slot asks only what the quote doesn't carry. Prober: expect a probe on the denominator. |
| B5 | "The role presents to senior leaders. Have you presented to anyone above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare a first presentation to senior leaders, and how you'd test it with your regional manager first. | Skeptic. F3 is a gap you named. Your own negative needs no slot. |
| B6 | "A branch supervisor says their escalations are backing up, and the regional manager wants a fix next month. What do you do first?" | CASE | [generic] | Structure aloud: clarify what is backing up and since when; set the objective (time to first response, escalations closed); segment by complaint type and branch; approach; metrics; risks. Speak to the approach, not to a time you did it. | This is the JD's coaching-supervisors line in live form. The pack asserts no past here. |
| B7 | "How would you coach a branch supervisor on escalations, having been one yourself?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Plan first: what you would check, what you would say, how you would follow up. Answer slot: if you coached anyone on an escalation, say what you did. If the closest was training tellers on the script, say that. | F7 is transferability: you trained tellers, not supervisors. The plan is not a past. |
| B8 | "Tell me about a time you worked with a digital team on a self-service journey." | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Open prompt. Answer slot: if you have worked with a digital team on a self-service journey, say which and your part. If not, say so plainly, then say what you'd need to learn from a digital team before changing a complaints journey. | F8 has no evidence. The honest form is the slot. |

### Round 3: panel (60 min, values and case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter, when the process said otherwise." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (published value); "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold: a time you went against process for a member's benefit. It needs a stake, a decision you made, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log. Answer slot: if a decision against process was yours, say what you decided and what happened. If it wasn't yours, say so. | The panel scores the value. Your nearest story is the log, not a reversal. |
| C2 | "Tell me about an explanation you had to rewrite because a member didn't follow it." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" (published value); "trained new tellers on our escalation script" (within "I handled the branch's formal complaints log and trained new tellers on our escalation script") | Selection scaffold: a time you changed how something was explained: a letter, a script, a step. If none comes to mind, say so, then give the nearest thing: the escalation script you trained tellers on. Answer slot: if you changed the wording of that script, say what you changed. If you taught it as written, say that. | The nearest story carries a script, not a rewrite. Say which it was. |
| C3 | "When did a target you were given fail to show something about a branch's community?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" (published value); "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: a time a number missed something about the people it counted. If none, say so. Nearest: the monthly spreadsheet. Say what it counted. If it counted nothing about the branch's town, say so. | The question assumes a target. Your material doesn't show a target being missed. |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (published value) | Selection scaffold: a problem you found, what you kept hold of, how it ended. Your material has no ending to supply, so don't supply one. Answer slot: if you saw a problem through to solved, name it. If it ended unsolved, or wasn't yours, say so plainly. | Own the Fix is scored on the ending. An unsolved problem, honestly told, scores better than an invented close. |
| C5 | "A member has complained three times, first at a branch, then to the contact centre. Now they say they'll go to the regulator. Talk us through the next 48 hours." | CASE | [generic]. Raising sources: JD "experience handling regulated complaints"; JD "end to end across branches and the contact centre" | Twenty-minute case. Clarify before structuring: what was promised, when, what each complaint says, which regulator and which timescale apply. Ask, don't assume a name. Objective; one owner for the case (Own the Fix); a plain-words reply to the member (Plain Words); who in the branch and the contact centre does what; a record; risks (a missed timescale, two channels giving different answers). Metrics: first response time, reopen rate. Think aloud. Make no claim about your past. | A live problem from the role. The panel scores structure, not the answer. |
| C6 | "Eight branches become five hubs during 2027. A closing branch has complaints open. What's your plan?" | CO, CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief) | Structure: clarify which branches and when. Objective: no member loses an open complaint in the move. Segment: open complaints at closing branches. Approach: a named owner per complaint, one handover note, regulator timescales kept. Metrics: open complaints at handover, time to first response after. Risks. Don't claim knowledge of Ashgrove's plan beyond the brief. | Strategy-grounded CO. A differentiator: most candidates can't engage with the consolidation. |
| C7 | "They aim to move 40% of member service to digital channels by 2028. What happens to complaints when that shifts?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief) | Complaints move into channels that don't show in the current log. Name the one thing to watch: complaint volume and resolution time by channel. Say what you'd want to know before the shift. Use no figure beyond the brief's. | Strategy question. It tests whether you can reason at the company's altitude. |
| C8 | "The main pressure is app-only banks. How does a complaint affect whether a member stays?" | CO | [grounded] "the main competitive pressure is app-only banks" (your summary of the July 2026 brief) | Answer from the member's side: what a member remembers of a complaint is how it was handled, in plain words and in time. Name one thing a branch can do that an app can't, as your view, not a fact about Ashgrove. Don't pitch app features. | Tests altitude under competitive pressure. |

## Reverse questions

**Round 1 (recruiter):**
- "What does a strong first six months look like in this role?" Why it lands: the recruiter can tell you what the panel will score.
- "What comes after the panel?" Why it lands: shows you're tracking the timetable.

**Round 2 (Head of Member Services):**
- "How does a complaint move today between a branch and the contact centre, and where does it stall?" Why it lands: it's the scope the JD names, and it shows you read the JD.
- "What would you want the Member Experience Lead to have changed by the first 90 days?" Why it lands: their answer is the scoring sheet for your first months.
- "How will the hub consolidation change who handles a complaint?" Why it lands: connects the July 2026 brief to the role.

**Round 3 (panel):**
- "When a complaint crosses from a branch to the contact centre, who owns it at each step?" Why it lands: tests Own the Fix in their own practice.
- "What do branch managers do with complaint resolution times now?" Why it lands: ties the reporting requirement to their branch work.
- "What did the best recent complaint handling look like here, in member terms?" Why it lands: their answer shows the values in practice, and you can reflect it back.

## Sources

- **Provided documents:** the JD text (your message); the recruiter's round outline (your message); the values copy (pasted 25 November 2026); the July 2026 strategy brief (your summary, not the document).
- **Searches sent:** none. **Fetches sent:** none.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | yes | Values cheat sheet: the four values as you pasted them |
| 2. Ashgrove interview process, member services | skipped | The recruiter's outline already fixes the rounds, so persona weights follow them |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief supplies the current priorities |
| 4. Interviewer name and profile | n/a | No names given for round 2's manager or round 3's panel |
| 5. Representative JD for the title | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The panel members' names → per-member persona weights and a tailored reverse question for each.
- The Head of Member Services' name → a read of their public footprint, if they publish.
- The July 2026 brief itself → the grounding brief checked against its exact wording, and C6 and C7 quoted exactly.
- Whether the spreadsheet tracked resolution times, in a sentence → F6 becomes a quoted row, and B4's slot narrows.
- Whether any complaint in the log was regulated, and how → F2's probe slot gets a concrete answer.
- Hours you can prep each day before 4 December → a prep triage section sized to them.
- Any figure you reported from the spreadsheet → the defend-the-number slots in B4 become specific.
- Deep research (L2): the strategy brief, interviewer talks, loop reports and recent organisation news. Offered once. It adds up to 6 searches and 2 fetches and takes a few minutes. Say yes and it runs.
- A tuesday-dossier.md recording verified evidence and claims to avoid would sharpen the fit rows and the prohibited list. Not required.

---

Say the word and I'll play the Skeptic on B2, the highest-ROI prep in the pack.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead

**Prep pack, loop mode.** Three rounds on 4 December 2026. Built 25 November 2026.

- **Round 1:** recruiter screen, 30 min (recruiter's name not given)
- **Round 2:** behavioural, 45 min, with the Head of Member Services (your future manager)
- **Round 3:** panel, 60 min, two branch managers (names not yet assigned), including a 20-min complaint-escalation case, scored against the four values

Built on: the JD you pasted, your background as you described it, the recruiter's round outline, the values you copied from ashgrovecu.org/about/values, and your summary of the July 2026 strategy brief. No web research was run.

## How to use

Personas are how a question arrives. Types are what it scores.

| Tag | Meaning |
|---|---|
| VAL | Values and behavioural: what your past shows about the published values |
| EXP | Your own experience: what you actually did |
| JD | The listed job: its requirements, including gaps |
| CO | Company and strategy |
| CASE | A live problem from the role, worked aloud |

Guidance is scaffolding, not a script. An answer slot ends in an instruction, not a question. It is for the interview and asks you nothing here.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, since no CV was provided. Everything you gave is self-reported, so nothing here is above `medium` unless you have an artifact to show.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Say it in your own words: "I have six years in retail banking, the last three as a branch supervisor." Expect a probe on whether a branch counts as customer operations. Answer it with what you did in that work, not with a new label. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | none | No bridge needed. Expect a probe on "regulated". Answer slot: if any complaint you handled was governed by a regulatory requirement, say which and what it required of you. If none was, say so plainly. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | medium | [grounded] | capability | "I've never presented to anyone above regional level." Then a plan, not a past: how you would prepare a first presentation to senior leaders. Your material does not show that you presented the spreadsheet, so do not add it. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | No bridge needed; the spreadsheet is the evidence. Expect a probe on how you built it. Answer slot: name the functions or features you used, in your words. If you built it without formulas, say so. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material carries one branch's log, not a process across branches or the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: which stages of a complaint were yours to decide, from intake to closure. If others set a stage, say so. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly reporting is shown. Resolution times are not in the material. Answer slot: whether the spreadsheet tracked resolution times. If it did, say how they were measured. If not, say so and say what you would add first. |
| F7 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as branch supervisor" (your message) | low | [inferred] | transferability | You trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Coaching a supervisor is a plan, not a past. Answer slot: if you coached anyone on an escalation, say what you did. If the closest was training tellers on the script, say that. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, and you have not said you lack this experience. Answer slot: if you have worked with a digital team on a self-service journey, say which and your part. If not, say so and say what you would need to learn from a digital team before changing a complaints journey. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | medium | [grounded] | capability | "I've never worked in a contact centre." Then a plan: how you would learn a contact-centre queue in your first month. |

**Four things the table enforces:**
- Your material shows one branch's complaints log, not a process across branches or the contact centre (F5, F9).
- Monthly reporting is shown, resolution times are not (F6).
- Presenting above regional level is a gap you named yourself (F3).
- The pack's own observations, such as "your material does not show X", are analysis. The words you say come from your quotes or from an answer slot.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B1, C5 |
| Confident presenting to senior leaders | B5 |
| Comfortable with Excel reporting | B4 |
| Own the complaints process end to end across branches and the contact centre | B2, B3, C5 |
| Report monthly on complaint volumes and resolution times | B4 |
| Coach branch supervisors on escalations | B6, B7 |
| Work with digital teams on self-service journeys | B8, C7 |
| Pay, notice and location (posting logistics) | A3, A4, A5 |

## Grounding brief (strategy)

From your summary of the July 2026 brief. Check the exact wording in the document itself before quoting it in the room.

- Move 40% of member service to digital channels by 2028 (C7).
- Consolidate eight branches into five hubs over 2027 (C6).
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks (C8).

## Persona weights

| Round | Persona (weight) | How it shows | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational / Rapport (top); Skeptic (light) | Friendly openers, logistics, a motivation check, one knockout gap | Recruiter screens are logistics plus motivation consistency. The risk is treating them as unscored. | Script a 90-second background. Treat the logistics as scored. Answer the gap in one sentence. |
| 2, Head of Member Services | Case / Strategist (top); Skeptic (second); Data-Driven Prober (for reporting) | A live escalation problem, a scope challenge, a probe on your spreadsheet | Hiring-manager priors: they are buying capability and checking the gaps. They are your future manager, so expect the operational questions. | Structure before answering. Name the weakest assumption in your own figures. Hold the scope gap, then concede it. |
| 3, panel of two branch managers | Values / Behavioral (top); Case / Strategist (second, for the 20-min case); Pressure (third) | Values-mapped stories, a timed complaint case, follow-ups | The panel scores against the four values, so the values round is the scored round. With no names yet, weights are blended. | Map a story to each value where your material carries one. Where it does not, say so. Think aloud in the case. |

## Values cheat sheet

Round 3 is the values round. The panel scores against these four values, quoted as you copied them on 25 November 2026.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | C1. Nearest story: "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message). If no decision against process was yours, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | C2. Nearest story: "trained new tellers on our escalation script" (your message). Say what you changed in it, or that you taught it as written. |
| Neighbours, Not Numbers | Every branch is part of its town | C3. Nearest story: "I built the monthly complaints spreadsheet our regional manager uses" (your message). Your material does not show anything about the town. Say so if asked. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | C4. Your material shows a complaints log, not a problem you found and followed to solved. If you did not see one through, say so. |

## Prohibited claims

These are claims the pack will not coach, with the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 | F5's quote at its own scope. Your material says one branch's log, not the process across branches or the contact centre. B2 stays inside the log. |
| Presented to senior leaders | Your own negative (F3) | "I've never presented to anyone above regional level." No slot. |
| Reported resolution times to your regional manager | Inflated form of F6 | The spreadsheet at its own scope. Whether resolution times were in it is not shown. B4 asks only that. |
| Worked in a contact centre | Your own negative (F9) | "I've never worked in a contact centre." No slot. |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." Coaching a supervisor is a plan, not a past. |

## Question banks

Each row's Provenance carries every sentence the guidance rests on.

### Round 1: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background in about two minutes." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Beats: six years in retail banking; the last three as a branch supervisor; then the complaints log and training tellers, in those words. Aim for 60–90 seconds. Add no role and no result. | Opener, scored for economy. F1 and F2 are the only facts about your past in this pack. Covers the 4+ years requirement. |
| A2 | "What is drawing you to Ashgrove?" | CO | [grounded] "Members First, Always — we decide from the member's side of the counter" (published value, pasted) | Name one published value you understand, in your own words, and what it would mean at a branch counter you know. Keep it to about 60 seconds. | Recruiters test whether you read the values. One specific value beats general enthusiasm. |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot. Give your own figure or range in your own words, or say you would like the role's band first. This pack supplies no figure. | Pay is a knockout logistic. Your answer is yours alone. |
| A4 | "When could you start, and what notice do you owe your current employer?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | Knockout check. The answer is yours alone. |
| A5 | "Where could you work from, and how many office days suit you?" | JD | [generic] | Logistics slot. Say the locations and office days you can actually do. | Location and office pattern are knockouts. The 2027 hub plan may change where roles sit (see reverse questions). |
| A6 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics and motivation slot. Give your own reason in one or two sentences, about the move rather than people. Your material gives no reason, so this pack offers none. | The recruiter checks motivation consistency. The reason is yours alone. Nothing here asks what you want next. |
| A7 | "Your background is retail. This role runs complaints across branches and a contact centre. Where's the gap?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then one plan: how you would learn a contact-centre queue in your first month. | Light Skeptic. F9 is the gap the JD raises. Your own negative needs no slot. |

### Round 2: Head of Member Services (45 min, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you handled the branch's formal complaints log." | EXP, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Beats: what the log held, and what you did with entries, in your own words. Answer slot: say which stages of a complaint were yours to decide (intake, investigation, decision, closure). If someone else set a stage, say who. | F2 is the evidence for the regulated-complaints requirement. The stage question covers the probe the JD's end-to-end line invites. |
| B2 | "The role owns the complaints process end to end across branches and the contact centre. Which parts have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **Highest-ROI prep in this pack.** This scope gap is where the JD presses hardest, so expect it in some form. Hold: "I handled the branch's formal complaints log." Answer slot: if you owned a stage across more than your branch, say which and how you decided. If not, say you handled the branch's log and say how you would learn the wider process. Hold through two follow-ups by returning to the log. If pressed, concede the contact-centre gap plainly. | F5 is the gap. The question presumes ownership the quote does not carry, so its second branch allows that the ownership never existed. Deepest rehearsal goes here. |
| B3 | "You've never worked in a contact centre. What makes this hire a safe bet?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Plain acknowledgment: "I've never worked in a contact centre." Hold on the part your material shows: "I handled the branch's formal complaints log." Concede the contact-centre gap rather than arguing it. Then one plan: how you would learn a contact-centre queue in your first month. Hold through two follow-ups. | Pressure-style. The test is composure with a known gap. F9 is the gap. |
| B4 | "Walk me through the monthly complaints spreadsheet your regional manager uses. What does it count?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats: what you built, that it runs monthly, who uses it. Weakest-assumption move: name, in your own words, the assumption behind its numbers you would defend least, before they do. Answer slot: whether it tracked resolution times. If so, say how they were measured. If not, say so and what you would add first. | F4 and F6 are the evidence for Excel reporting and monthly reporting. The resolution-times slot asks only what the quote does not carry. Prober: expect a probe on the denominator. |
| B5 | "The role presents to senior leaders. Have you presented to anyone above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare a first presentation to senior leaders, and how you would test it with your regional manager first. | Skeptic. F3 is a gap you named. Your own negative needs no slot. |
| B6 | "A branch supervisor says their escalations are backing up, and the regional manager wants a fix next month. What do you do first?" | CASE | [generic] | Structure aloud: clarify what is backing up and since when; set the objective (time to first response, escalations closed); segment by complaint type and branch; approach; metrics; risks. Speak to the approach, not to a time you did it. | This is the JD's coaching-supervisors line in live form. The pack asserts no past here. |
| B7 | "How would you coach a branch supervisor on escalations, having been one yourself?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Plan first: what you would check, what you would say, how you would follow up. Answer slot: if you coached anyone on an escalation, say what you did. If the closest was training tellers on the script, say that. | F7 is transferability: you trained tellers, not supervisors. The plan is not a past. |
| B8 | "Tell me about a time you worked with a digital team on a self-service journey." | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Open prompt. Answer slot: if you have worked with a digital team on a self-service journey, say which and your part. If not, say so plainly, then say what you would need to learn from a digital team before changing a complaints journey. | F8 has no evidence. The honest form is the slot. |

### Round 3: panel (60 min, values and case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter, when the process said otherwise." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (published value); "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold: a time you went against process for a member's benefit. It needs a stake, a decision you made, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log. Answer slot: if a decision against process was yours, say what you decided and what happened. If it was not yours, say so. | The panel scores the value. Your nearest story is the log, not a reversal. |
| C2 | "Tell me about an explanation you had to rewrite because a member didn't follow it." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" (published value); "trained new tellers on our escalation script" (within "I handled the branch's formal complaints log and trained new tellers on our escalation script") | Selection scaffold: a time you changed how something was explained: a letter, a script, a step. If none comes to mind, say so, then the nearest thing: the escalation script you trained tellers on. Answer slot: if you changed the wording of that script, say what you changed. If you taught it as written, say that. | The nearest story carries a script, not a rewrite. Say which it was. |
| C3 | "When did a target you were given fail to show something about a branch's community?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" (published value); "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: a time a number missed something about the people it counted. If none, say so. Nearest: the monthly spreadsheet. Say what it counted. If it counted nothing about the branch's town, say so. | The question assumes a target. Your material does not show a target being missed. |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (published value) | Selection scaffold: a problem you found, what you kept hold of, how it ended. Your material has no ending to supply, so do not supply one. Answer slot: if you saw a problem through to solved, name it. If it ended unsolved, or was not yours, say so plainly. | Own the Fix is scored on the ending. An unsolved problem, honestly told, scores better than an invented close. |
| C5 | "A member has complained three times, first at a branch, then to the contact centre. Now they say they'll go to the regulator. Talk us through the next 48 hours." | CASE | [generic]. Raising sources: JD "experience handling regulated complaints"; JD "end to end across branches and the contact centre" | Twenty-minute case. Clarify before structuring: what was promised, when, what each complaint says, which regulator and which timescale apply. Ask, do not assume a name. Objective; one owner for the case (Own the Fix); a plain-words reply to the member (Plain Words); who in the branch and the contact centre does what; a record; risks (a missed timescale, two channels giving different answers). Metrics: first response time, reopen rate. Think aloud. Make no claim about your past. | A live problem from the role. The panel scores structure, not the answer. |
| C6 | "Eight branches become five hubs during 2027. A closing branch has complaints open. What's your plan?" | CO, CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief) | Structure: clarify which branches and when. Objective: no member loses an open complaint in the move. Segment: open complaints at closing branches. Approach: a named owner per complaint, one handover note, regulator timescales kept. Metrics: open complaints at handover, time to first response after. Risks. Do not claim knowledge of Ashgrove's plan beyond the brief. | Strategy-grounded CO. Differentiator: most candidates cannot touch the consolidation. |
| C7 | "They aim to move 40% of member service to digital channels by 2028. What happens to complaints when that shifts?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief) | Complaints move into channels that do not show in the current log. Name the one thing to watch: complaint volume and resolution time by channel. Say what you would want to know before the shift. Use no figure beyond the brief's. | Strategy question. It tests whether you can reason at the company's altitude. |
| C8 | "The main pressure is app-only banks. How does a complaint affect whether a member stays?" | CO | [grounded] "the main competitive pressure is app-only banks" (your summary of the July 2026 brief) | Answer from the member's side: what a member remembers of a complaint is how it was handled, in plain words and in time. Name one thing a branch can do that an app cannot, as your view, not a fact about Ashgrove. Do not pitch app features. | Tests altitude under competitive pressure. |

## Reverse questions

Each question has a line on why it lands. Round 2 is your future manager, so its questions carry most weight.

**Round 1 (recruiter):**
- "What does a strong first six months look like in this role?" Why it lands: the recruiter can tell you what the panel will score.
- "What comes after the panel?" Why it lands: shows you are tracking the timetable.

**Round 2 (Head of Member Services):**
- "How does a complaint move today between a branch and the contact centre, and where does it stall?" Why it lands: it is the scope the JD names, and it shows you read the JD.
- "What would you want the Member Experience Lead to have changed by the first 90 days?" Why it lands: their answer is the scoring sheet for your first months.
- "How will the hub consolidation change who handles a complaint?" Why it lands: connects the July 2026 brief to the role.

**Round 3 (panel):**
- "When a complaint crosses from a branch to the contact centre, who owns it at each step?" Why it lands: tests Own the Fix in their own practice.
- "What do branch managers do with complaint resolution times now?" Why it lands: ties the reporting requirement to their branch work.
- "What did the best recent complaint handling look like here, in member terms?" Why it lands: their answer shows the values in practice, and you can reflect it back.

## Sources

- **Provided documents:** the JD text (your message); the recruiter's round outline (your message); the values copy (pasted 25 November 2026); the July 2026 strategy brief (your summary, not the document).
- **Searches sent:** none. **Fetches sent:** none.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | yes | Values cheat sheet: the four values as you pasted them |
| 2. Ashgrove interview process, member services | skipped | The recruiter's outline already fixes the rounds, so persona weights follow them |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief supplies the current priorities |
| 4. Interviewer name and profile | n/a | No names given for round 2's manager or round 3's panel |
| 5. Representative JD for the title | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The panel members' names → per-member persona weights and a tailored reverse question for each.
- The Head of Member Services' name → a read of their public footprint, if they publish.
- The July 2026 brief itself → the grounding brief checked against its exact wording, and C6 and C7 quoted exactly.
- Whether the spreadsheet tracked resolution times, in a sentence → F6 becomes a quoted row, and B4's slot narrows.
- Whether any complaint in the log was regulated, and how → F2's probe slot gets a concrete answer.
- Hours you can prep each day before 4 December → a prep triage section sized to them.
- Any figure you reported from the spreadsheet → the defend-the-number slots in B4 become specific.
- Deep research (L2): the strategy brief, interviewer talks, loop reports and recent organisation news. Offered once. It adds up to 6 searches and 2 fetches, and takes a few minutes. Say yes and it runs.
- A tuesday-dossier.md recording verified evidence and a list of claims to avoid would sharpen F-rows and the prohibited list. Not required.
