Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a5-runs-haiku-alone-part-2-rooms-case-8-denied-8294c121/1e880b80-117c-4757-8630-3165825c85c5/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. It's built on the JD, Ashgrove's values, the recruiter's round description and the July strategy brief you sent, plus your background. I didn't run any web searches, because those inputs already cover what a search would have found.

# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union.
**Rounds, 4 December 2026:** Round 1, recruiter (30 min). Round 2, Head of Member Services, your future manager (45 min, mostly behavioural). Round 3, panel of two branch managers (60 min, values-scored, with a 20-minute complaint-escalation case).
**Interviewers not yet named:** Round 2 and Round 3 names are not assigned. Personas below come from round-type priors only.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: rehearse it aloud, in your own words.

- **VAL**: values and behavioural. Does a past action show one of Ashgrove's published values?
- **EXP**: experience deep-dive. Does your own record hold up under a second question?
- **JD**: role requirement. Can you do the listed part of the job, gaps included?
- **CO**: company and strategy. Can you talk about the July 2026 brief at its altitude?
- **CASE**: live problem. Structure and reasoning count, not a right answer.

## Fit snapshot

Your material is your message to me only. No CV was supplied, so every quote below is from what you wrote, and medium is the highest confidence any claim here can carry until something is inspected. The JD names no hard gates (no licence, location or schedule term), so there are no hard_gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote covers it. Say it in its own words: six years in retail banking, the last three as a branch supervisor. Expect a check on dates. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your quote is one branch's log, and the bridge stays there: "I handled the branch's formal complaints log." Answer slot: the JD asks for end-to-end ownership across branches and the contact centre, so expect a probe on what you set beyond the log. If you set any step, say which and how you decided, in your own words. If you did not, say plainly that you handled the log, and describe how it ran. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The quote reaches monthly reporting. It does not show resolution times. Answer slot: say what the spreadsheet counted, in your own words. If it counted resolution times, say how they were measured. If it did not, say so, and say what you would add first. |
| F4 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your quote says formal. It does not say regulated. Answer slot: if the log ran to a set timeline or to external rules, name them. If it did not, say what made it formal, in your own words. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The quote is about tellers, not supervisors, and the bridge stays at that scope: you trained new tellers on the escalation script. Answer slot: expect a probe on whether you have coached a supervisor on escalations. If you have, say what you did. If you have not, say so, and say how you would start. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: if you have worked with one on a member journey, say what you did. If you have not, say so plainly, and say how you would start. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote says spreadsheet, not Excel. Use its words, and do not claim Excel skills it does not carry: "I built the monthly complaints spreadsheet our regional manager uses." |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Stated absence, in your words: "I've never presented to anyone above regional level." Then how you would build the skill, said as a plan, never as a past. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Stated absence, in your words: "Never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan, never as a past. |

## Prohibited claims

These are the claims this pack will not coach, because the material does not carry them. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across branches and the contact centre | Inflated form of F2 | "I handled the branch's formal complaints log." The material says one branch's log, not the process end to end. The scope question stays inside the log (S2). |
| Handled regulated complaints to regulatory timelines | Inflated form of F4 | "I handled the branch's formal complaints log." The material does not show regulation or a timeline. |
| Tracked resolution times in the spreadsheet | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times are not in the quote; the slot asks only what it counted. |
| Coached branch supervisors on escalations | Inflated form of F5 | "trained new tellers on our escalation script." The material is about tellers. |
| Presented to senior leaders | Negative you stated (F8) | Plain acknowledgment: "I've never presented to anyone above regional level." |
| Contact-centre experience | Negative you stated (F9) | Plain acknowledgment: "Never worked in a contact centre." |
| Advanced Excel, or any named Excel function | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Persona weights

Relationship priors set the start: a recruiter screen leans conversational with a light skeptic; a hiring manager leans case and skeptic; a panel blends the top two personas of each member. Round 2 is described as "mostly behavioural", so values and behavioural questions lead it. The panel scores against the four values, so the values persona leads round 3. There is no interviewer profile, so no interviewer adjustment applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four values; stories in STAR shape | High. The panel scores on the four values, and round 2 is mostly behavioural. | Map a story to each value where one of your quoted sentences carries one. Where none does, use a selection scaffold and its honest branch. |
| Skeptic | Probes the scope and the gaps: one branch, no contact centre, no senior presenting | High. F2, F8 and F9 are the gaps the JD's own lines press on. | Rehearse the scope objection until it is plain. Concede the limit first, then give a plan, said as a plan. |
| Conversational | An open journey question, then logistics in a friendly register | High in round 1. Recruiter screens check logistics in a casual register. | Use a 90-second arc. Treat the logistics as scored. |
| Case/Strategist | Live problems: the escalation case, hub and digital questions | Medium-high. The recruiter names a 20-minute escalation case, and the brief names hubs and digital targets. | Clarify, then structure, then answer. Use the strategy's vocabulary; make no claims about your own experience there. |
| Pressure | Interrupts and holds you to scope | Medium. A panel may press once, and the scope question is the likely line. | Hold through two follow-ups. Concede the scope explicitly. Do not fold on the core. |
| Data-Driven Prober | Asks what a number counted | Low-medium. Your only metric-bearing item is a spreadsheet, and no figure was given. | Say what it counted, in your words. Say plainly when you do not know. |

## Question banks

Sub-tables follow the persona weights, highest first. IDs: V for Values/Behavioral, S for Skeptic, A for Conversational, K for Case/Strategist, P for Pressure, D for Prober. Round numbers are in the rationale.

### Values/Behavioral (7 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a complaint where what the member needed and what the process allowed didn't match. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold, open prompt: pick one complaint from the log where the process and the member pulled apart. Say what the member needed, what you did, and where your decision stopped. If you did not decide the outcome, say so. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries: how you handled the log. | Round 3, Members First. F2 is the only sentence of yours it can rest on, so the story stays at the log's scope. The value needs a decision the quote does not state. |
| V2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: the script is the nearest carrier. If you rewrote any of its wording so a teller could say it plainly, say what you changed and why. If you taught it as written, say so plainly. If no such time comes to mind, say so, then describe how you would check whether a script is plain enough. | Round 3, Plain Words. F5 carries the training, not any wording change, so the honest branch is the rewrite or the plain teaching. |
| V3 | "Tell me about a time a local detail changed a decision the numbers pointed the other way." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Scaffold: name the local fact, the number it cut against, and what you did. Your three years as a branch supervisor are the setting. If no such time comes to mind, say so plainly, then say how a branch's town shows up in a complaint. | Round 3, Neighbours, Not Numbers. F1 gives the setting only. The decision is not in your material, so the honest branch is required. |
| V4 | "Tell me about a process problem you found that wasn't yours to fix, and what you did about it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Story map from the quote: you built the spreadsheet, and your regional manager uses it. Answer slot: if the spreadsheet surfaced a problem you then followed to a fix, say what it was and where it ended. If you did not follow a finding through, say so. Own the Fix: whoever finds the problem keeps hold of it until it is solved. | Round 3, Own the Fix. F3 and F7 carry the spreadsheet. The follow-through is the part the quote does not state. |
| V5 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a time you took a finding to someone senior that they did not want. Say what it was, what you said, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the spreadsheet your regional manager uses, and whether it ever showed them something they did not want to see. If it did not, say so. | Round 2, persona stem. The spreadsheet is the only leadership-facing item in your material, so the rest is scaffold. |
| V6 | "How would you coach a branch supervisor who escalates every complaint, or none?" | JD | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" (your message) | Say the nearest thing you did: you trained new tellers on the escalation script, in those words. Then describe how you would coach a supervisor, as a method. Answer slot: if you have coached a supervisor on escalations, say what you did. If you have not, say so. | Round 2. Coaching supervisors is the JD's line. Your material covers tellers, so the answer is a method plus the honest branch (F5). |
| V7 | "How would you work with a digital team on a self-service complaint journey?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Your material does not show this work. Answer slot: if you have worked with a digital or app team on a member journey, say what you did. If you have not, say so plainly, and say how you would start. | Round 2. The digital requirement has no evidence in your material (F6), so the slot is the whole answer. |

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role owns complaints across the contact centre. You haven't worked in one. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment, in your words: "Never worked in a contact centre." Then how you would learn it, as a plan: what you would learn first, and from whom. Do not describe contact-centre work as if you had done it. | Round 1, recruiter screen. F9 is the stated gap. The premise is your own negative, quoted. |
| S2 | "The role owns complaints end to end across branches and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | **Highest-ROI prep in this pack.** Expect this objection in some form, most likely early in round 2. Hold: "I handled the branch's formal complaints log." Concede the scope first: "It was one branch's log." Answer slot: if you set any step beyond the log, say which and how you decided, in your own words. If you did not, say plainly that you handled the log, and describe how it ran. Hold through two follow-ups by returning to the log. Never add to it. A plain "I didn't set any step" is a complete answer. | Round 2. F2 is the requirement this Skeptic will press. It is the objection most likely to be asked and the one where the material is thinnest, so it gets the deepest rehearsal. |
| S3 | "Presenting to senior leaders is part of this role. How would you prepare to present to a senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment first, in your words: "I've never presented to anyone above regional level." Then how you would prepare, as a plan: what you would test first, and who you would rehearse with. Do not describe a presentation you have not given. | Round 2. F8 is a stated absence. The acknowledgment comes first so the answer does not drift into a past you do not have. |
| S4 | "What makes a complaint regulated, and what changes about how you handle it?" | JD | [grounded] "experience handling regulated complaints" (JD); "I handled the branch's formal complaints log" (your message) | Answer from the log. "Formal" is the word your material carries. If the log ran to a set timeline or external rules, name them. If it did not, say what made it formal, in your own words. Do not describe regulatory duties you did not handle. | Round 2. F4 is transferability: the quote carries formal, not regulated, so the honest answer stays at the log's scope. |

### Case/Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A member says the app showed their complaint as resolved, but a branch letter says it is still open. Walk us through how you'd handle it." | CASE | [generic] | Structure it, don't improvise a past: clarify what each channel shows and which record is right; decide who owns the fix; tell the member what is happening, in plain words; set the escalation route and who decides; say what you would record and report. Say what you would check first. Claim nothing about your experience. | Round 3, the 20-minute escalation case the recruiter named. The scenario is an illustration, not the panel's real case, so it is generic. |
| K2 | "Eight branches become five hubs during 2027. Which complaints would be hardest to keep consistent through that change?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Structure: complaints in flight at a branch when it consolidates; handoffs between hubs; the member's sense of their town. Name one thing the log must survive the move with. No claim about your experience. | Round 3. It tests whether you think at the company's altitude, not whether you have run a consolidation. |
| K3 | "Forty percent of member service is moving to digital channels by 2028. What happens to a complaint that starts in the app?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Say where a digitally raised complaint would be logged, who would own it, and what you would check first. Keep to what you would want to know. No claim about your experience. | Round 2. Digital is the brief's largest target, and it reaches complaints directly. |
| K4 | "Our small-business lending product launches in Q1 2027. How would its complaints differ from retail complaints?" | CO | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief) | State what you would expect to differ, as your view, and what you would check first. Hold to what you would expect, not what you know. No claim about your experience. | Round 2. Few candidates can speak to it, and the honest answer is a view. |

### Pressure (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You've run one branch's complaints log. Why should we trust you across eight branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "consolidate eight branches into five hubs over 2027" (strategy brief) | Hold: "I handled the branch's formal complaints log." Concede the scope first: "It was one branch's log." Hold through two follow-ups by returning to what you did in that log. Do not claim beyond it. Then, as a plan, say what you would do to take on the wider scope. | Round 3. The same objection as S2, pressed by a panel. Rehearse S2 first; this is that line under pressure. |

### Conversational (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc. Start with six years in retail banking, the last three as a branch supervisor. Then the formal complaints log, the teller script and the spreadsheet, in those words. Close with one sentence of your own on why this role. Add nothing between the beats. | Round 1. The four quotes are the arc's beats, each at its own scope. F1 is the spine. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give the figure you want, in your own words, or say you would like to see the band first. If asked what you earn now, you can say: "I'd rather focus on the range for this role." | Round 1, logistics: pay. A knockout check in a friendly register. Treat it as scored. |
| A3 | "What notice do you owe your current employer?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | Round 1, logistics: notice. |
| A4 | "Which office would you work from, and how often would you need to be on site?" | JD | [generic] | Logistics slot: name the office and the on-site days you can actually work, in your own words. If you do not yet know which hub you would sit in, say so. | Round 1, logistics: location. Consolidation may change the office, and the screen will check whether you know. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: one or two sentences, your reason, in your own words. Keep it to the work, not to people at the branch. | Round 1, logistics: reason for leaving. Keep it consistent with A1. |

### Prober (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what the monthly complaints spreadsheet counts, and how you counted it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name what it counts, in your own words. Answer slot: if it counted resolution times, say how they were measured. If it did not, say so, and say what you would add first. Never describe a measure you did not track. | Round 2. The spreadsheet is your only metric-bearing item. A prober asks what it counts, which is the F3 slot. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the complaints process end to end across branches and the contact centre | S2, P1, S1 |
| Report monthly on complaint volumes and resolution times | D1 |
| Coach branch supervisors on escalations | V6 |
| Work with digital teams on self-service journeys | V7, K3 |
| Experience handling regulated complaints | S4 |
| Confident presenting to senior leaders | S3 |
| Comfortable with Excel reporting | D1 |
| Escalation case (Round 3) | K1 |

Every requirement has at least one question. None is uncovered.

## Values cheat sheet

The panel scores against these four values. Each row maps to a quoted sentence from the fit snapshot, or to a selection scaffold with its honest branch where no quote carries a story.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2: "I handled the branch's formal complaints log" (your message). No decision is in the quote, so use the scaffold and its honest branch (V1). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F5: "trained new tellers on our escalation script" (your message). Scaffold: did you change any wording? If you did, say what. If not, say so (V2). |
| Neighbours, Not Numbers | Every branch is part of its town. | F1: "6 years in retail banking, the last 3 as a branch supervisor" (your message). This gives the setting only; use the scaffold (V3). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3 and F7: "I built the monthly complaints spreadsheet our regional manager uses" (your message). A story from the quote, with an answer slot on follow-through (V4). |

## Grounding brief

Your inputs included the July 2026 strategy brief as sent by the recruiter. These are the current priorities, in the brief's own words.

| Fact | Provenance |
|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, July 2026) |
| Consolidate eight branches into five hubs over 2027 | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) |
| Launch a small-business lending product in Q1 2027 | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief) |
| The main competitive pressure is app-only banks | [grounded] "the main competitive pressure is app-only banks" (strategy brief) |

Use the brief's vocabulary: digital channels, hubs, small-business lending, app-only banks. The brief is from July 2026. Ask the recruiter whether anything has changed since.

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path. Each question is for you to ask in the interview.

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the regional manager do with the monthly complaints report, and what would make it more useful?" | It shows you read reporting as a decision tool, and you know your own spreadsheet is in use. |
| 2 | "As eight branches become five hubs during 2027, which complaints does the team expect to be hardest to keep consistent?" | It shows you have read the July brief, and it invites them to name the risk. |
| 3 | "How will complaints from the small-business lending product sit alongside retail complaints?" | It ties to the Q1 2027 launch and shows you are thinking about the product, not only the process. |
| 4 | "How do branch supervisors and the digital team share complaint data today?" | It tests the 40% digital target's plumbing, and it invites their view of the self-service work. |
| 5 | "What would the first six months in this role need to look like for you to say it had gone well?" | It asks for the success measure directly, which is what a manager's round is for. |
| 6 | "What does the complaints process not show yet that you wish it did?" | It invites their own view of where the fix is, which matches the Own the Fix value. |

## Prep sequence

The highest-value preparation, in order:
1. **S2** (scope of ownership) and **P1** (the same line under pressure). The gap is widest here, and the interview will probably press it.
2. **S1** and **S3**: the two plain acknowledgments. Say them in your own words, then the plan, without hedging.
3. **V1 to V4** and **K1**: the values stories, and the escalation case.

Everything else is insurance.

## Sources

**Provided documents:**
- The JD, pasted in your message.
- Ashgrove's values page, copied 25 November 2026, pasted in your message.
- The recruiter's email describing the three rounds, pasted in your message.
- The 2026 strategy brief (July 2026), as sent by the recruiter, pasted in your message.
- Your background, from your message. No CV was supplied.

**Searches and fetches sent:** none.

Research tier: L0. Searches 0 of 0, fetches 0 of 0. Every research target below is already fixed by a provided document, so no call was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The values page is in hand, so a search would only restate it. |
| 2. Ashgrove interview process | skipped | Loop structure and persona weights. The recruiter's email fixes the three rounds and their format. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief. The July 2026 brief supplies the current priorities. Recent news was not searched; see the upgrade menu. |
| 4. Interviewer name | n/a | No names are assigned, so there was no query to form. |
| 5. Representative JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Round 2 and Round 3 interviewers' names → persona weights from their public professional footprint, and a tailored reverse question.
- The recruiter's brief for the 20-minute escalation case → K1 becomes grounded in the panel's actual scenario.
- Your CV, or the complaints spreadsheet's headings with one anonymised month → F1 to F5 and F7 gain inspectable evidence, and D1's answer slot can become a story map.
- Deep research at L2 (an update on the strategy since July, the interviewers' public talks, recent reports on this role's loop) → at most six further searches and two fetches, a few minutes. Offered once.

---

Two offers, neither pushed:
- Say the word and I'll play the Skeptic on S2, the question this pack names as highest-ROI.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union.
**Rounds, 4 December 2026:** Round 1, recruiter (30 min). Round 2, Head of Member Services, your future manager (45 min, mostly behavioural). Round 3, panel of two branch managers (60 min, values-scored, with a 20-minute complaint-escalation case).
**Interviewers not yet named:** Round 2 and Round 3 names are not assigned. Personas below come from round-type priors only.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: rehearse it aloud, in your own words.

- **VAL**: values and behavioural. Does a past action show one of Ashgrove's published values?
- **EXP**: experience deep-dive. Does your own record hold up under a second question?
- **JD**: role requirement. Can you do the listed part of the job, gaps included?
- **CO**: company and strategy. Can you talk about the July 2026 brief at its altitude?
- **CASE**: live problem. Structure and reasoning count, not a right answer.

## Fit snapshot

Your material is your message to me only. No CV was supplied, so every quote below is from what you wrote, and medium is the highest confidence any claim here can carry until something is inspected. The JD names no hard gates (no licence, location or schedule term), so there are no hard_gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote covers it. Say it in its own words: six years in retail banking, the last three as a branch supervisor. Expect a check on dates. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your quote is one branch's log, and the bridge stays there: "I handled the branch's formal complaints log." Answer slot: the JD asks for end-to-end ownership across branches and the contact centre, so expect a probe on what you set beyond the log. If you set any step, say which and how you decided, in your own words. If you did not, say plainly that you handled the log, and describe how it ran. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The quote reaches monthly reporting. It does not show resolution times. Answer slot: say what the spreadsheet counted, in your own words. If it counted resolution times, say how they were measured. If it did not, say so, and say what you would add first. |
| F4 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your quote says formal. It does not say regulated. Answer slot: if the log ran to a set timeline or to external rules, name them. If it did not, say what made it formal, in your own words. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The quote is about tellers, not supervisors, and the bridge stays at that scope: you trained new tellers on the escalation script. Answer slot: expect a probe on whether you have coached a supervisor on escalations. If you have, say what you did. If you have not, say so, and say how you would start. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: if you have worked with one on a member journey, say what you did. If you have not, say so plainly, and say how you would start. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote says spreadsheet, not Excel. Use its words, and do not claim Excel skills it does not carry: "I built the monthly complaints spreadsheet our regional manager uses." |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Stated absence, in your words: "I've never presented to anyone above regional level." Then how you would build the skill, said as a plan, never as a past. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Stated absence, in your words: "Never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan, never as a past. |

## Prohibited claims

These are the claims this pack will not coach, because the material does not carry them. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across branches and the contact centre | Inflated form of F2 | "I handled the branch's formal complaints log." The material says one branch's log, not the process end to end. The scope question stays inside the log (S2). |
| Handled regulated complaints to regulatory timelines | Inflated form of F4 | "I handled the branch's formal complaints log." The material does not show regulation or a timeline. |
| Tracked resolution times in the spreadsheet | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times are not in the quote; the slot asks only what it counted. |
| Coached branch supervisors on escalations | Inflated form of F5 | "trained new tellers on our escalation script." The material is about tellers. |
| Presented to senior leaders | Negative you stated (F8) | Plain acknowledgment: "I've never presented to anyone above regional level." |
| Contact-centre experience | Negative you stated (F9) | Plain acknowledgment: "Never worked in a contact centre." |
| Advanced Excel, or any named Excel function | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Persona weights

Relationship priors set the start: a recruiter screen leans conversational with a light skeptic; a hiring manager leans case and skeptic; a panel blends the top two personas of each member. Round 2 is described as "mostly behavioural", so values and behavioural questions lead it. The panel scores against the four values, so the values persona leads round 3. There is no interviewer profile, so no interviewer adjustment applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four values; stories in STAR shape | High. The panel scores on the four values, and round 2 is mostly behavioural. | Map a story to each value where one of your quoted sentences carries one. Where none does, use a selection scaffold and its honest branch. |
| Skeptic | Probes the scope and the gaps: one branch, no contact centre, no senior presenting | High. F2, F8 and F9 are the gaps the JD's own lines press on. | Rehearse the scope objection until it is plain. Concede the limit first, then give a plan, said as a plan. |
| Conversational | An open journey question, then logistics in a friendly register | High in round 1. Recruiter screens check logistics in a casual register. | Use a 90-second arc. Treat the logistics as scored. |
| Case/Strategist | Live problems: the escalation case, hub and digital questions | Medium-high. The recruiter names a 20-minute escalation case, and the brief names hubs and digital targets. | Clarify, then structure, then answer. Use the strategy's vocabulary; make no claims about your own experience there. |
| Pressure | Interrupts and holds you to scope | Medium. A panel may press once, and the scope question is the likely line. | Hold through two follow-ups. Concede the scope explicitly. Do not fold on the core. |
| Data-Driven Prober | Asks what a number counted | Low-medium. Your only metric-bearing item is a spreadsheet, and no figure was given. | Say what it counted, in your words. Say plainly when you do not know. |

## Question banks

Sub-tables follow the persona weights, highest first. IDs: V for Values/Behavioral, S for Skeptic, A for Conversational, K for Case/Strategist, P for Pressure, D for Prober. Round numbers are in the rationale.

### Values/Behavioral (7 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a complaint where what the member needed and what the process allowed didn't match. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold, open prompt: pick one complaint from the log where the process and the member pulled apart. Say what the member needed, what you did, and where your decision stopped. If you did not decide the outcome, say so. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries: how you handled the log. | Round 3, Members First. F2 is the only sentence of yours it can rest on, so the story stays at the log's scope. The value needs a decision the quote does not state. |
| V2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: the script is the nearest carrier. If you rewrote any of its wording so a teller could say it plainly, say what you changed and why. If you taught it as written, say so plainly. If no such time comes to mind, say so, then describe how you would check whether a script is plain enough. | Round 3, Plain Words. F5 carries the training, not any wording change, so the honest branch is the rewrite or the plain teaching. |
| V3 | "Tell me about a time a local detail changed a decision the numbers pointed the other way." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Scaffold: name the local fact, the number it cut against, and what you did. Your three years as a branch supervisor are the setting. If no such time comes to mind, say so plainly, then say how a branch's town shows up in a complaint. | Round 3, Neighbours, Not Numbers. F1 gives the setting only. The decision is not in your material, so the honest branch is required. |
| V4 | "Tell me about a process problem you found that wasn't yours to fix, and what you did about it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Story map from the quote: you built the spreadsheet, and your regional manager uses it. Answer slot: if the spreadsheet surfaced a problem you then followed to a fix, say what it was and where it ended. If you did not follow a finding through, say so. Own the Fix: whoever finds the problem keeps hold of it until it is solved. | Round 3, Own the Fix. F3 and F7 carry the spreadsheet. The follow-through is the part the quote does not state. |
| V5 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a time you took a finding to someone senior that they did not want. Say what it was, what you said, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the spreadsheet your regional manager uses, and whether it ever showed them something they did not want to see. If it did not, say so. | Round 2, persona stem. The spreadsheet is the only leadership-facing item in your material, so the rest is scaffold. |
| V6 | "How would you coach a branch supervisor who escalates every complaint, or none?" | JD | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" (your message) | Say the nearest thing you did: you trained new tellers on the escalation script, in those words. Then describe how you would coach a supervisor, as a method. Answer slot: if you have coached a supervisor on escalations, say what you did. If you have not, say so. | Round 2. Coaching supervisors is the JD's line. Your material covers tellers, so the answer is a method plus the honest branch (F5). |
| V7 | "How would you work with a digital team on a self-service complaint journey?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Your material does not show this work. Answer slot: if you have worked with a digital or app team on a member journey, say what you did. If you have not, say so plainly, and say how you would start. | Round 2. The digital requirement has no evidence in your material (F6), so the slot is the whole answer. |

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role owns complaints across the contact centre. You haven't worked in one. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment, in your words: "Never worked in a contact centre." Then how you would learn it, as a plan: what you would learn first, and from whom. Do not describe contact-centre work as if you had done it. | Round 1, recruiter screen. F9 is the stated gap. The premise is your own negative, quoted. |
| S2 | "The role owns complaints end to end across branches and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | **Highest-ROI prep in this pack.** Expect this objection in some form, most likely early in round 2. Hold: "I handled the branch's formal complaints log." Concede the scope first: "It was one branch's log." Answer slot: if you set any step beyond the log, say which and how you decided, in your own words. If you did not, say plainly that you handled the log, and describe how it ran. Hold through two follow-ups by returning to the log. Never add to it. A plain "I didn't set any step" is a complete answer. | Round 2. F2 is the requirement this Skeptic will press. It is the objection most likely to be asked and the one where the material is thinnest, so it gets the deepest rehearsal. |
| S3 | "Presenting to senior leaders is part of this role. How would you prepare to present to a senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment first, in your words: "I've never presented to anyone above regional level." Then how you would prepare, as a plan: what you would test first, and who you would rehearse with. Do not describe a presentation you have not given. | Round 2. F8 is a stated absence. The acknowledgment comes first so the answer does not drift into a past you do not have. |
| S4 | "What makes a complaint regulated, and what changes about how you handle it?" | JD | [grounded] "experience handling regulated complaints" (JD); "I handled the branch's formal complaints log" (your message) | Answer from the log. "Formal" is the word your material carries. If the log ran to a set timeline or external rules, name them. If it did not, say what made it formal, in your own words. Do not describe regulatory duties you did not handle. | Round 2. F4 is transferability: the quote carries formal, not regulated, so the honest answer stays at the log's scope. |

### Case/Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A member says the app showed their complaint as resolved, but a branch letter says it is still open. Walk us through how you'd handle it." | CASE | [generic] | Structure it, don't improvise a past: clarify what each channel shows and which record is right; decide who owns the fix; tell the member what is happening, in plain words; set the escalation route and who decides; say what you would record and report. Say what you would check first. Claim nothing about your experience. | Round 3, the 20-minute escalation case the recruiter named. The scenario is an illustration, not the panel's real case, so it is generic. |
| K2 | "Eight branches become five hubs during 2027. Which complaints would be hardest to keep consistent through that change?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Structure: complaints in flight at a branch when it consolidates; handoffs between hubs; the member's sense of their town. Name one thing the log must survive the move with. No claim about your experience. | Round 3. It tests whether you think at the company's altitude, not whether you have run a consolidation. |
| K3 | "Forty percent of member service is moving to digital channels by 2028. What happens to a complaint that starts in the app?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Say where a digitally raised complaint would be logged, who would own it, and what you would check first. Keep to what you would want to know. No claim about your experience. | Round 2. Digital is the brief's largest target, and it reaches complaints directly. |
| K4 | "Our small-business lending product launches in Q1 2027. How would its complaints differ from retail complaints?" | CO | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief) | State what you would expect to differ, as your view, and what you would check first. Hold to what you would expect, not what you know. No claim about your experience. | Round 2. Few candidates can speak to it, and the honest answer is a view. |

### Pressure (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You've run one branch's complaints log. Why should we trust you across eight branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "consolidate eight branches into five hubs over 2027" (strategy brief) | Hold: "I handled the branch's formal complaints log." Concede the scope first: "It was one branch's log." Hold through two follow-ups by returning to what you did in that log. Do not claim beyond it. Then, as a plan, say what you would do to take on the wider scope. | Round 3. The same objection as S2, pressed by a panel. Rehearse S2 first; this is that line under pressure. |

### Conversational (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc. Start with six years in retail banking, the last three as a branch supervisor. Then the formal complaints log, the teller script and the spreadsheet, in those words. Close with one sentence of your own on why this role. Add nothing between the beats. | Round 1. The four quotes are the arc's beats, each at its own scope. F1 is the spine. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give the figure you want, in your own words, or say you would like to see the band first. If asked what you earn now, you can say: "I'd rather focus on the range for this role." | Round 1, logistics: pay. A knockout check in a friendly register. Treat it as scored. |
| A3 | "What notice do you owe your current employer?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | Round 1, logistics: notice. |
| A4 | "Which office would you work from, and how often would you need to be on site?" | JD | [generic] | Logistics slot: name the office and the on-site days you can actually work, in your own words. If you do not yet know which hub you would sit in, say so. | Round 1, logistics: location. Consolidation may change the office, and the screen will check whether you know. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: one or two sentences, your reason, in your own words. Keep it to the work, not to people at the branch. | Round 1, logistics: reason for leaving. Keep it consistent with A1. |

### Prober (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what the monthly complaints spreadsheet counts, and how you counted it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name what it counts, in your own words. Answer slot: if it counted resolution times, say how they were measured. If it did not, say so, and say what you would add first. Never describe a measure you did not track. | Round 2. The spreadsheet is your only metric-bearing item. A prober asks what it counts, which is the F3 slot. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the complaints process end to end across branches and the contact centre | S2, P1, S1 |
| Report monthly on complaint volumes and resolution times | D1 |
| Coach branch supervisors on escalations | V6 |
| Work with digital teams on self-service journeys | V7, K3 |
| Experience handling regulated complaints | S4 |
| Confident presenting to senior leaders | S3 |
| Comfortable with Excel reporting | D1 |
| Escalation case (Round 3) | K1 |

Every requirement has at least one question. None is uncovered.

## Values cheat sheet

The panel scores against these four values. Each row maps to a quoted sentence from the fit snapshot, or to a selection scaffold with its honest branch where no quote carries a story.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2: "I handled the branch's formal complaints log" (your message). No decision is in the quote, so use the scaffold and its honest branch (V1). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F5: "trained new tellers on our escalation script" (your message). Scaffold: did you change any wording? If you did, say what. If not, say so (V2). |
| Neighbours, Not Numbers | Every branch is part of its town. | F1: "6 years in retail banking, the last 3 as a branch supervisor" (your message). This gives the setting only; use the scaffold (V3). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3 and F7: "I built the monthly complaints spreadsheet our regional manager uses" (your message). A story from the quote, with an answer slot on follow-through (V4). |

## Grounding brief

Your inputs included the July 2026 strategy brief as sent by the recruiter. These are the current priorities, in the brief's own words.

| Fact | Provenance |
|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, July 2026) |
| Consolidate eight branches into five hubs over 2027 | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) |
| Launch a small-business lending product in Q1 2027 | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief) |
| The main competitive pressure is app-only banks | [grounded] "the main competitive pressure is app-only banks" (strategy brief) |

Use the brief's vocabulary: digital channels, hubs, small-business lending, app-only banks. The brief is from July 2026. Ask the recruiter whether anything has changed since.

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path. Each question is for you to ask in the interview.

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the regional manager do with the monthly complaints report, and what would make it more useful?" | It shows you read reporting as a decision tool, and you know your own spreadsheet is in use. |
| 2 | "As eight branches become five hubs during 2027, which complaints does the team expect to be hardest to keep consistent?" | It shows you have read the July brief, and it invites them to name the risk. |
| 3 | "How will complaints from the small-business lending product sit alongside retail complaints?" | It ties to the Q1 2027 launch and shows you are thinking about the product, not only the process. |
| 4 | "How do branch supervisors and the digital team share complaint data today?" | It tests the 40% digital target's plumbing, and it invites their view of the self-service work. |
| 5 | "What would the first six months in this role need to look like for you to say it had gone well?" | It asks for the success measure directly, which is what a manager's round is for. |
| 6 | "What does the complaints process not show yet that you wish it did?" | It invites their own view of where the fix is, which matches the Own the Fix value. |

## Prep sequence

The highest-value preparation, in order:
1. **S2** (scope of ownership) and **P1** (the same line under pressure). The gap is widest here, and the interview will probably press it.
2. **S1** and **S3**: the two plain acknowledgments. Say them in your own words, then the plan, without hedging.
3. **V1 to V4** and **K1**: the values stories, and the escalation case.

Everything else is insurance.

## Sources

**Provided documents:**
- The JD, pasted in your message.
- Ashgrove's values page, copied 25 November 2026, pasted in your message.
- The recruiter's email describing the three rounds, pasted in your message.
- The 2026 strategy brief (July 2026), as sent by the recruiter, pasted in your message.
- Your background, from your message. No CV was supplied.

**Searches and fetches sent:** none.

Research tier: L0. Searches 0 of 0, fetches 0 of 0. Every research target below is already fixed by a provided document, so no call was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The values page is in hand, so a search would only restate it. |
| 2. Ashgrove interview process | skipped | Loop structure and persona weights. The recruiter's email fixes the three rounds and their format. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief. The July 2026 brief supplies the current priorities. Recent news was not searched; see the upgrade menu. |
| 4. Interviewer name | n/a | No names are assigned, so there was no query to form. |
| 5. Representative JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Round 2 and Round 3 interviewers' names → persona weights from their public professional footprint, and a tailored reverse question.
- The recruiter's brief for the 20-minute escalation case → K1 becomes grounded in the panel's actual scenario.
- Your CV, or the complaints spreadsheet's headings with one anonymised month → F1 to F5 and F7 gain inspectable evidence, and D1's answer slot can become a story map.
- Deep research at L2 (an update on the strategy since July, the interviewers' public talks, recent reports on this role's loop) → at most six further searches and two fetches, a few minutes. Offered once.
