## Decision snapshot

Yes, it's worth applying, on three conditions. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery warehouse), R9 (data contracts analysts depend on); unclear: R8 (ingestion from our app and CRM)

R2–R6 are all `direct` on what you've told me, but at `medium` confidence because nothing is inspectable yet. R7 is the one real gap, and it's a transferability gap, not a missing skill.

**Opportunity ledger.** The posting is sound and discloses its pay, which sits inside the Series B–D senior band (RR3). Scope is broad for one seat (RR1), and the employer is not independently verified (RR5), because the web search was refused.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:**
  1. Your location and eligibility for remote US or Denver (R1). If it fails, the status becomes `no_go`.
  2. The employer and live posting confirmed on Pellucid's own careers page (RR5).
  3. In the screen, ingestion ownership and the contract definition confirmed (R8, R9, RR1). BigQuery is presented as adjacent, never as experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` your pasted About page |
| Mandate | Build and run the reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ingestion, warehouse and contracts in one seat suggests end-to-end ownership of the reporting data path | `[inferred]` from the responsibility list against its silence on team size |
| Market calibration | Pay report you supplied: Senior Data Engineer at Series B–D companies, base median $151,000, IQR $139,000–$163,500, typical seniority 5–8 years, typical scope one domain with no direct reports. The posted $148,000–$166,000 sits around the median and mostly inside the IQR; the top end is above the upper quartile. Equity is unquantified | `[generic]` band from the recruiter's report, not checked by me; `[grounded]` posted range |
| Unknowns | Location eligibility; equity size and vesting; team and reporting line; who owns ingestion versus the warehouse models; what a "data contract" means here | — |
| Contradictions | None between the JD and the About page you pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and eligibility aren't in the inputs, so the gate can't be checked | `[grounded]` JD term | Question 1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated by you; no artifact to inspect. Meets the 5–8 year senior norm | `[grounded]` your background; `[generic]` norm | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, as you stated; limited inspectable proof | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse. The requirement says "a cloud warehouse", not BigQuery | `[grounded]` your background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background | none |
| R7 | BigQuery warehouse (named in the role's responsibilities) | important | adjacent | medium | transferability | Your Snowflake dbt modelling, testing and SQL carry over. You have never used BigQuery, so its specifics (partitioning, clustering, cost model, IAM) are unexercised | `[grounded]` JD; `[inferred]` transfer from Snowflake work | G1 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Not in what you've described. Ingestion is plausible in a payroll data role, but unconfirmed | `[grounded]` JD; `[inferred]` | Question 2 |
| R9 | Data contracts analysts depend on | important | adjacent | low | transferability | Your quality testing supports consumer guarantees, but you haven't said you owned formal contracts with analysts. Limit: contracts not yet exercised | `[inferred]` from the Great Expectations work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery specifics (R7) | transferability | dbt, SQL and testing on Snowflake; no BigQuery | Named in the responsibilities, so a likely interview probe | Any warehouse migration, cost tuning or partitioning work on Snowflake; dbt model design that transfers | A small dbt project on BigQuery, or a migration note comparing Snowflake and BigQuery | `[inferred]` transfer; `[generic]` that interviewers probe warehouse-specific choices |
| G2 | Ingestion from app and CRM (R8) | discovery | Nothing in what you've described covers source ingestion | Core to the role's first months | Pipelines pulling application-database or CRM data; schema ownership; incremental loads | Pipeline diagram or a description of one source you owned end to end | `[grounded]` JD; `[inferred]` |
| G3 | Data contracts (R9) | transferability | Quality tests in place; no formal consumer contracts mentioned | The role's stated deliverable to analysts | Schema agreements, breaking-change handling, owner notices | A sample contract or a description of a changed-schema incident you handled | `[inferred]` |

The queue holds no questions. The question for G2 is in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ingestion, warehouse and contracts in one seat | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | One engineer may own the full reporting path with little platform support | `[inferred]` from the scope list against silence on team size | Who else works on the data platform, and who owns ingestion versus the warehouse models? | unresolved |
| RR2 | Hiring manager not named | unknown | — | (the posting names no hiring manager) | Common for postings of this kind; not a warning on its own | `[generic]` | Who would I report to, and who owns this seat? | unresolved |
| RR3 | Pay disclosed, inside the band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Stated pay sits near the band median; the top end is above the upper quartile | `[grounded]` JD range; `[generic]` band from the pay report | How is the $148,000–$166,000 range set for this level? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity value, vesting and strike price are unstated | `[grounded]` JD | What is the equity grant, vesting schedule and strike price? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Web search was refused, so only your two pasted pages establish it | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

RR5 caps the decision at `conditional_go` until the employer and posting are verified. Nothing here is a red flag. This is not a finding that the employer is fake; it means I could not check it.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Pellucid's own careers page and note its URL | RR5 | `[grounded]` standing entry | proposed |
| A2 | Confirm your location and eligibility before tailoring anything | R1 | `[grounded]` JD term | proposed |
| A3 | Resume framing: lead with the Snowflake dbt build (about 180 models), Airflow and Great Expectations; name Snowflake explicitly; describe BigQuery as not yet used, never as experience | R4, R5, R6, R7 | `[grounded]` your background; `[inferred]` framing choice | resume_edits_pending_approval |
| A4 | Optional: a small dbt project on BigQuery (free sandbox) as an inspectable work sample, linked only if you finish it | R7 | `[inferred]` from G1 | proposed |
| A5 | Screen questions: ingestion ownership, the contract definition, the team around the seat | RR1, R8, R9 | `[generic]` interview practice | proposed |
| A6 | Ask how the pay range is set and what the equity terms are, before the offer stage | RR3, RR4 | `[generic]` | proposed |

Nothing is finalized until you approve it. A3 is the only item that changes text you would send.

## Evidence status

Verified: none yet. Everything above rests on your own statements and the two pasted pages.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent for Pellucid Learning and its senior data engineer posting. Both were refused by permission, so nothing returned. Would have moved RR5 (employer and posting verified) and the posting's consistency with the About page |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you supplied already fixes the band, median, IQR and scope norm for this seniority, so no search was sent. The band is `[generic]` and unchecked by me |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` to carry into later sessions.

## Upgrade menu

- Permission to run web search (refused this run): would verify the employer, the live posting and the scope of the seat. Up to 3 more searches and 2 fetches; say the word and I'll try.
- Your location and eligibility: resolves R1, which decides whether this stays `conditional_go` or becomes `no_go`.
- The careers-page URL or live posting link: closes RR5.
- A BigQuery sandbox project or migration note: gives G1 an inspectable artifact, which would raise R7's confidence.
- The equity terms and your pay floor: close RR4 and let me run the pay check against your floor. You haven't given a floor, so that check is open.
- The hiring manager's name, if the posting or a recruiter gives it: RR2 closes and I can check the public footprint.

## Questions

R1 — Where are you based, and does remote US or the Denver office work for you?

G2 (R8) — Have you built ingestion from an application database and a CRM? Which sources, which tools, and who owned the schemas?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.