**Decision snapshot: conditional go. Apply, after checking that the posting is live and confirming pay and location.**

- **Fit ledger (candidate, not the role):**
  - *Must-have, strong:* 5+ years product analytics (6 years); experiment design at scale (30+ tests/yr, pricing test with 11% retention lift); Looker (built the instance, 40+ governed dashboards); written communication to non-technical stakeholders (monthly exec memo, monthly VP Product presentation).
  - *Must-have, partial:* expert SQL (daily Snowflake use; "expert" is unverified until a work sample is seen); metrics layer (governed dashboards and the consent model suggest it, `[inferred]`).
  - *Gap:* mentoring two junior analysts (nothing in the background on this); clinician partnership (no clinical or care-navigation exposure).
  - *Preferred, gap:* healthcare data and HIPAA (none; consumer GDPR/CCPA PII and consent-state work is transferable, not equivalent).
- **Hard-gates line:** None stated in the JD. Location, work authorization, and your pay floor are unknown to me, so they are unchecked, not passed.
- **Opportunity ledger:** No red flags in the JD. Unknowns: compensation is not stated, which the posting itself withholds; team structure and reporting line; how much HIPAA work the role carries day to day. The employer is unverified (see evidence status).

**Role reality**
- Scope: an analytics owner for one app with a metrics layer, self-serve Looker, experimentation, and two reports to mentor. That is a player-coach senior IC role, closer to what you already do than the title suggests.
- Market calibration: `[generic]`. Senior product analytics roles at this scope usually sit near the top of the IC band. I have not checked the actual band for this employer.

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | must | strong | 5+ yrs product analytics | 6 yrs, consumer subscription | high (CV-stated) | none |
| 2 | must | strong | Experiment design at scale | 30+ A/B tests/yr; 11% retention lift | medium-high (CV-stated; check the 11% figure's method) | none |
| 3 | must | strong | Looker or similar BI | Built instance from scratch; 40+ governed dashboards | high | none |
| 4 | must | partial | Expert SQL | Daily Snowflake use | medium | capability (unverified depth) |
| 5 | must | partial | Metrics layer ownership | Governed dashboards, consent model | low (`[inferred]`) | presentation |
| 6 | must | strong | Non-technical written comms | Monthly exec memo; VP presentations | high | none |
| 7 | must | gap | Mentor two junior analysts | Not in the background | none | discovery |
| 8 | must | gap | Clinician/roadmap partnership | No clinical domain | none | transferability |
| 9 | preferred | gap | Healthcare data / HIPAA | None; consumer PII and consent model transferable | none for HIPAA | transferability |

**Gap recovery queue** (no questions here; the closing block asks them)
- Row 4: a work sample, such as an anonymized query or analysis, would raise SQL to high.
- Row 5: a description of what the metrics layer covers (definitions, ownership, tooling) would confirm or drop it.
- Row 7: any formal or informal mentoring, even of interns or peers, would move it from gap to partial.
- Row 9: the consent-state model is the strongest transferable artifact. Describe its controls so it can be framed accurately.

**Risk register**
- *Employer unverified:* research was not run, so this is a standing check, not a failed attribution. It caps the decision at conditional go until the posting and company are confirmed.
- *Pay withheld:* the posting omits compensation. Ask for the band before investing time.
- *Healthcare framing:* do not say or imply HIPAA experience. Say "consumer PII and consent-state work under GDPR/CCPA" instead.

**Application plan** (`resume_edits_pending_approval`; nothing is finalized without your approval)
- Lead with experimentation (30+ tests, the pricing test), Looker build-out, and the exec memo.
- Frame the consent-state model as regulated-data work, and name the gap in healthcare directly rather than hiding it.
- Proposed phrasing to check for inflation: "led" the experimentation program is fine if you owned design and decisions; "expert SQL" should be backed by a work sample, not asserted.

**Evidence status**

Research tier: L0 — no searches; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run in this pass; L1 is available |
| 2 | Role-family sweep (scope, title, pay) | skipped | Not run in this pass |
| 3 | Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** If you want, I can write `tuesday-dossier.md` with this assessment so the next pass starts from the same evidence.

**Upgrade menu**
- Live posting link or recruiter email domain: verifies the employer and unlocks L1 research (up to 5 searches, 2 fetches).
- A SQL or analysis work sample, anonymized: raises row 4 to high.
- Compensation band and your floor, plus location and remote terms: lets me check the hard gates.
- Hiring manager's name: lets me tailor the positioning to that reader.

**Questions**
1. Do you have the live posting link or the recruiter's email domain? That lets me verify the employer.
2. What is your pay floor, and what location or remote terms can you accept?
3. Have you mentored or managed analysts formally or informally?

Reply in prose or skip any question; silence counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.