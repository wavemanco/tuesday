**Decision: conditional go.** You aren't wasting your time on the pivot, but this specific role is a stretch on its one must-have. Apply only if you can truthfully point to product decisions you made or shaped. Otherwise, aim at PM roles whose titles or scope match your integration background more directly.

**Hard gates:** None are stated in the posting. Location, pay and schedule are missing from the JD, so they're unknown, not cleared. The "3+ years PM" line is a must-have requirement, not a hard gate, so it can be argued with but won't be filtered out by law or license.

Research tier: L0, no searches. Everything below rests on the JD and your resume alone. Company facts are unverified.

**Fit, requirement by requirement**

| Requirement | Fit | Why |
|---|---|---|
| 3+ yrs PM (must-have) | Gap | No PM title. PM-adjacent work exists (roadmap-input sessions, requirements docs), but it's not a PM role. |
| Shipped API or platform products | Partial | You delivered 30+ integrations of an API product. You didn't own its roadmap or release decisions. |
| Technical fluency (API docs, schemas) | Strong | Postman, SQL, OpenAPI, integration architecture. |
| Stakeholder management (eng, sales, customers) | Strong | You coordinated vendor engineers, client engineers and PMs on custom builds. |
| Discovery with integration partners | Strong, inferred | Scoping workshops and quarterly client-feedback sessions are discovery in practice. |
| Write specs, drive delivery with eng squads | Partial | You wrote requirements documents. Sprint ownership and squad-level delivery aren't evidenced. |
| Define and track adoption metrics | Gap | Nothing on your resume. Unknown whether you ever measured adoption. |
| Coordinate launches with sales and support | Strong | Go-live, UAT and the integration playbook cover this closely. |
| Agile delivery experience | Unknown | Not stated. |

**Gap types:** mostly transferability (your work is real but framed as implementation, not product) and discovery (metrics and agile not yet evidenced). The PM-title gap is presentation plus the years requirement, and only real product ownership would close it.

**Opportunity read (on the JD alone)**
- The scope is reasonable: one API platform, two squads, a Series B company of about 150 people. Nothing in the posting is a red flag.
- Unknowns: company health, pay, location, and whether "3+ years" is strict or flexible.
- The posting asks for the PM title and the platform-product record together. That's a tight screen, and recruiters will likely filter on the title first.

**Application plan**
1. Apply only where you can truthfully name a product decision you influenced, with its outcome. If you can, tailor the resume around those decisions, not the implementation volume.
2. Write the adoption story. If you ever tracked integration go-live rates, time-to-first-call, or how many clients used a feature, that's your metric evidence. Don't invent it.
3. Verify the posting is live and the company is real before spending serious time (the careers page or recruiter's email domain would do it).
4. If the triage tool is real and support teams adopted it, that is strong evidence of product work. It's unconfirmed, so I'm not counting it.

**Risks**
- Title screen: likely rejected on the 3+ years PM line regardless of fit.
- Unverified company: I haven't confirmed the employer exists as described.

**Evidence status**
- Research tier: L0, no searches; user links read 0.
- No dossier, no other sources.

**Want to go further?** A dossier (`tuesday-dossier.md`) would hold this assessment so a later interview-prep session can use it. Research at L1 (up to 5 searches and 2 page fetches) would verify the company and the role-family pay band. Both are optional.

**Questions**
1. Have you ever owned a backlog, decided between competing requests, or made a roadmap call that shipped? If so, what was it and what happened? *(Gap rows: PM years, shipped product.)*
2. Did you build the request-triage tool? If so, what did support adoption look like, and was it measured? *(Unconfirmed memory lead.)*
3. What are your pay floor and location limits? *(Structural, unknown.)* Also: should I run L1 research to verify the company and the role's pay band?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.