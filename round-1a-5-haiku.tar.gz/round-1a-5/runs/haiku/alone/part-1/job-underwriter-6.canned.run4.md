**Decision: conditional_go.** Worth applying, but expect the forecast and billing-data requirements to be the screen, and verify the posting before you invest time.

## Decision snapshot

**Candidate fit** (per requirement, not a single score)

| Priority | Fit | Requirement |
|---|---|---|
| Must-have | Meets | 4+ years in RevOps, sales ops or analytics at a B2B software company (your 5 years at a B2B payments company; "software" is a transferability gap) |
| Must-have | Meets | HubSpot or Salesforce administration (Salesforce admin certified) |
| Must-have | Partial | Strong SQL and spreadsheet modelling (SQL weekly, Excel daily; modelling not yet evidenced) |
| Must-have | Gap | Experience owning a forecast (you ran the pipeline review; finance owned the forecast) |
| Must-have | Gap | Experience working with finance on billing or revenue data (no billing data work) |

**Hard gates:** none failed on known facts. Two are unknown: Bristol hybrid, two office days a week, and your pay floor against £61,500–£67,000 plus share options.

**Opportunity ledger:** the posting matches the employer's public profile (invoicing software, Bristol). The hiring manager, Tamsin Achebe, is listed as Head of Revenue Operations with a payments sales-ops background, close to your own path. The employer's careers page did not resolve, so the posting is not confirmed on the employer's own site. That caps the decision at conditional_go.

## Role reality

- **Role:** Revenue Operations Lead, Quillfield. Owns CRM and billing data, builds pipeline and renewal reporting, runs the quarterly revenue forecast with the CFO. `[grounded]` from the posting.
- **Organization:** invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A in April 2025. `[grounded]` from the company's About page.
- **Scope read:** the forecast and billing ownership make this broader than a reporting role. `[inferred]` from the posting's responsibilities.
- **Pay:** the posted £61,500–£67,000 sits in the lower half of the 2026 UK benchmark for revenue operations leads at B2B software companies (median £64,200, interquartile range £57,800–£70,400). `[generic]`, one survey source (Ledgerline, n=438).
- **Contradictions:** none found between the posting and the employer's About page. The careers page address returned nothing.

## Evidence map

| # | Priority | Requirement | Fit | Gap | Confidence |
|---|---|---|---|---|---|
| 1 | Must-have | 4+ years RevOps / sales ops / analytics | Meets | "B2B software" vs payments: transferability | Medium-high (CV, self-reported) |
| 2 | Must-have | HubSpot or Salesforce admin | Meets | None | High (certification) |
| 3 | Must-have | Strong SQL and spreadsheet modelling | Partial | Evidence of modelling, not just use | Medium |
| 4 | Must-have | Owned a forecast | Gap | Ownership never held; finance owned it | `[inferred]` gap |
| 5 | Must-have | Worked with finance on billing or revenue data | Gap | No billing data work | Stated by you |

## Gap recovery queue

- **Row 4, forecast ownership.** Closing it would need evidence that you produced or owned forecast numbers, even partially, for example contributing the pipeline-to-revenue bridge in your monthly review. Without that, present yourself as a forecast input owner, not an owner.
- **Row 5, billing data.** Closing it needs any real contact with invoice, billing or revenue-recognition data. If there is none, say so and lead with the adjacent work: pipeline and renewal data, which billing usually reconciles to.
- **Row 3, modelling.** Closing it needs one concrete example of a model you built (a forecast, a cohort, a renewal-rate calculation).

## Opportunity risk register

- **Failed attribution, medium (standing).** The company exists as described, but the posting is not confirmed on its own site. Reasons side by side, none ranked as likely: a stale or re-posted listing, a recruiter-run posting on a third-party board, or a role not yet on the company's site. Resolves with the employer's careers page or the recruiter's email domain.
- **Pay position, low.** Lower half of the benchmark. Check against your floor before applying.
- **Location, unknown.** Two office days a week in Bristol is a hard gate if you cannot commute.

## Application plan (within evidence)

1. Confirm the posting on the employer's own site, or get the recruiter's email domain, before a long application.
2. Lead with the match on rows 1 and 2: five years of sales ops at a B2B payments company, Salesforce certified.
3. Name the forecast and billing gaps yourself, with the adjacent work beside each. Do not describe pipeline review as forecast ownership, or any billing work as billing-data experience.
4. Positioning angle: the hiring manager's path closely mirrors yours, so a payments-sales-ops story is credible to this reader. Keep it to what you have done.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | About page found via search (quillfield.co.uk/about). Careers page at quillfield.co.uk/careers returned no page. |
| 2. Role-family sweep (pay and scope) | yes | Ledgerline 2026 UK Revenue Operations Pay Guide. |
| 3. Hiring manager's public footprint | yes | Public professional profile for Tamsin Achebe (search snippet only). |

The posting itself was read from the link you gave; it is not charged to the budget.

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` so a later session can pick it up.

## Upgrade menu

- **Your CV or a short resume**: firms up rows 1–3 from claims to evidence.
- **One modelling example**: moves row 3 to high confidence.
- **Your pay floor and commute**: settles the hard-gate check.
- **Employer careers page or recruiter email domain**: lifts the failed-attribution cap.

## Questions

1. Can you commute to Bristol two days a week, or do you need remote-only? *(hard gate; closes the location check)*
2. What is your lowest acceptable base salary? *(pay position, row in the risk register)*
3. Have you ever produced, contributed to, or checked forecast numbers, or touched invoice or billing data, even in a support role? *(rows 4 and 5)*

Answer any, all or none; say "skip" for any you'd rather leave.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.