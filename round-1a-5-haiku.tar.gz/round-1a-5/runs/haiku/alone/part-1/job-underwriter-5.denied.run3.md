**Yes, worth applying, but I'd hold until two facts are checked.** The CV matches the stack closely, and the posted pay looks market-normal. Status: **`hold_pending_answers`**, waiting on where you're based and whether the base clears your floor.

**Fit ledger**
- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery); unclear: R10 (ingestion from our app and CRM), R11 (data contracts our analysts depend on)

R9 is a credible bridge from Snowflake, with its limit named. R10 and R11 are not in your background yet.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Opportunity ledger:** The posting is transparent. The posted base sits near the sweep median (RR4), and the scope reads as normal for the title. Open: the reporting line (RR1), whether BigQuery is already built or part of the job (RR2), and equity terms (RR3). Employer attribution is unverified because research did not run (RR5), which caps the decision at `conditional_go`.
- **What would change this:** The hold waits on R1 (your location) and R2 (whether $148,000 clears your floor). If both clear, it moves to `conditional_go`, pending RR5 and a concrete answer on RR1. If you're outside the US and can't work from Denver, R1 fails and the status is `no_go`. A base below your floor that the employer won't move is also `no_go`.

## Research

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused at the permission prompt, so nothing was attributed. The about and careers text you pasted is in hand but not checked live. Would have moved the organization row and RR5. |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied fixes the band and the senior-scope norm. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted about page; not checked live |
| Mandate | Build and run the pipelines for reporting: app and CRM ingestion, a dbt-modelled warehouse in BigQuery, and data contracts | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` JD |
| Market calibration | Base IQR $139,000–$163,500, median $151,000. The posted band sits near the median (midpoint $157,000). Senior typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. | `[generic]` role-family pattern from the supplied report (n=2,310, Series B–D); figures `[grounded]` in that report |
| Scope read | Ownership of a domain's pipelines is the normal reading for this title. Whether this role has reports is not stated. | `[inferred]` from "build and run" against the title |
| Unknowns | Hiring manager, team size, reporting line, equity terms, whether BigQuery is built or migrating, your location against R1 | — |
| Contradictions | None found between the JD and the pasted about page | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not established. | `[grounded]` JD; candidate constraint not given | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No stated floor, so the check is not run. | `[grounded]` JD; candidate constraint not given | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. CV only, so a probe is expected. | `[grounded]` CV | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily. CV only. | `[grounded]` CV | none |
| R5 | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models. CV only. | `[grounded]` CV | none |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake, which is a cloud warehouse. | `[grounded]` CV | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow for orchestration. | `[grounded]` CV | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite. | `[grounded]` CV | none |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake plus dbt carries over. BigQuery specifics (its SQL dialect, cost model, partitioning) are not exercised. | `[inferred]` from Snowflake work; you have never used BigQuery | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Not in the CV. | `[grounded]` CV silence | G2; Q3 below |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Not in the CV. | `[grounded]` CV silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt experience; no BigQuery | The posting names BigQuery as the warehouse. The gap is in the platform, not the skill. | Any warehouse you tuned for cost or partitioning, even on Snowflake | A query or model you wrote that was cost-sensitive | `[inferred]` bridge from Snowflake work |
| G2 | Ingestion from app and CRM (R10, important) | discovery | No ingestion work in the CV | The first responsibility named in the JD | Pipelines from a product database into a warehouse; CRM data pulled via API or a sync tool | A pipeline diagram or DAG screenshot | `[grounded]` CV silence |
| G3 | Data contracts (R11, important) | discovery | No contract work in the CV | Analysts depend on these, so they are a reporting-facing obligation | Schema agreements, dbt model contracts, versioned tables consumers relied on | A contract document or an example schema change you managed | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team not stated | unknown | — | "Build and run the pipelines" | The role may carry no direct reports, or the team may be small | `[inferred]` from the posting's silence on reporting | Who would I report to, and how many engineers sit on the data team? | unresolved |
| RR2 | BigQuery state unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be built already, or migrating into it may be the job | `[inferred]` from the posting's wording | Is the BigQuery warehouse already built, or is moving into it part of this role? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The equity may be small or unvested | `[grounded]` posting names equity with no terms | What is the equity grant size and vesting schedule? | unresolved |
| RR4 | Posted base in market range | positive_signal | — | "$148,000–$166,000" | Transparent and near median | `[grounded]` posting; `[generic]` against the sweep median | Does the base include bonus or is it base only? | noted |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm your location fits R1 and that $148,000 clears your floor, before applying | The two gates | `[grounded]` JD | your answer needed |
| P2 | Verify the posting on the company's own careers page before investing effort | RR5 | `[generic]` standing entry | pending your approval |
| P3 | CV line: "Built a dbt project of about 180 models on Snowflake." Your words, nothing added. | R5, R6 | `[grounded]` CV | resume_edits_pending_approval |
| P4 | State BigQuery plainly: "No production BigQuery; Snowflake and dbt experience." Do not imply BigQuery use. | R9 | `[grounded]` CV; `[inferred]` gap | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is your self-report in the CV and this conversation.

## Upgrade menu

- A live check of the posting and the about page (the searches were refused): would verify the organization row and settle RR5.
- Your location and your pay floor (R1, R2): these are the gates.
- Ingestion or data-contract work from your history (R10, R11): each row moves from unclear once you give an example.
- A sanitized dbt model or Great Expectations suite: would raise R5 and R8 from `medium` toward `high`.
- The hiring manager's name: would inform RR1 and the positioning.
- A deeper research pass on Pellucid Learning (funding, leadership changes, reports; up to 5 more searches and 2 more fetches). Say the word and it runs, though the permission prompt may need approving first.

Once per engagement, if you want this written up as a `tuesday-dossier.md` for the rest of the search, say so.

**Q1 (R1):** Are you based in the US, and could you work remotely there or from the Denver office?

**Q2 (R2):** Is a $148,000 base, with equity on top, at or above your floor?

**Q3 (R10):** Have you built ingestion from a product database or a CRM such as Salesforce or HubSpot? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.