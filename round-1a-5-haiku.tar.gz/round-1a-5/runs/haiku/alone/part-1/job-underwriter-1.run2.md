**Decision: conditional go.** Apply. Your core requirements are well evidenced; the gaps are healthcare domain and mentoring, and neither blocks the application. The posting itself is unverified, so check it before you invest a long application.

**Research tier: L0, no searches.** This assessment rests only on the JD and your background. An L1 check of the live posting and the role-family pay band is on the upgrade menu below.

## Decision snapshot

- **Fit:** strong on 4 of 6 requirements, partial on 2 (mentoring and healthcare). No fit score, per the skill's rule; confidence is per requirement below.
- **Hard gates:** none stated in the JD. Your non-negotiables (pay, location, schedule) were not given, so they are **unknown**, not cleared.
- **Opportunity:** no red flags in the JD text. Pay is not posted, and the company is unverified.

## Role reality

- **Scope [grounded]:** owns the metrics layer, experiment design and analysis, self-serve Looker, PM and clinician partnership, and mentoring two juniors. This is a lead-analyst role, not an individual-contributor one.
- **Market calibration [generic]:** a senior product analytics role with people-lead duties and clinical stakeholders is a common pattern in digital health. Not a claim about this employer.
- **Compensation:** not stated. The posting withholds it, which is worth asking about.
- **Contradictions:** none within the JD.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | 5+ yrs product analytics | Met | High | none | 6 yrs at a consumer-subscription company [stated] |
| 2 | Must | Expert SQL | Likely met | Medium | discovery | Daily SQL on Snowflake, and built a consent-state model in the warehouse. "Expert" is your self-assessment; no one has verified it |
| 3 | Must | Experiment design at scale | Strong | High | none | Ran a 30+ tests/yr program; pricing test behind an 11% retention lift. Confirm the lift's basis (relative or absolute) and your ownership level before using it |
| 4 | Must | Looker or similar BI | Strong | High | none | Built the instance from scratch; 40+ governed dashboards |
| 5 | Must | Written communication to non-technical stakeholders | Strong | High | none | Writes the monthly exec memo; presents to the VP Product monthly |
| 6 | Must | Metrics layer ownership | Partial | Medium | transferability | "Governed" dashboards and a consent model are adjacent. A formal metrics layer you maintained would be stronger |
| 7 | Preferred | Mentoring two junior analysts | Unknown | Low | discovery | No evidence in your background. You may have done it informally |
| 8 | Preferred | Clinician partnership | Gap | — | transferability | Consumer-PM partnership only; no clinical stakeholders |
| 9 | Plus | Healthcare data / HIPAA | Gap | — | capability | None. GDPR/CCPA consumer PII work is the nearest real match. It is not HIPAA experience |

## Opportunity risk register

- **Domain switch (medium):** consumer subscription to regulated digital health. Expect questions on PHI handling and clinical context.
- **Unverified posting (medium):** no live posting or company page checked. Verify before applying.
- **Compensation withheld (low):** not a red flag alone, but unknown against your floor.

## Application plan

- **Lead with:** the experimentation program (30+ tests/yr, pricing test), the Looker build with 40+ governed dashboards, and the exec memo. These map directly to the core of the role.
- **Healthcare:** state the consent-state and PII work as what it is: GDPR/CCPA consumer data governance. Do not describe it as HIPAA-ready, healthcare-grade or equivalent. Anything that implies HIPAA experience you lack would be a false claim.
- **Mentoring:** if you have any informal onboarding, review or coaching of junior analysts, include it. If not, say nothing rather than stretch.
- **Proposed CV language:** `resume_edits_pending_approval`. Nothing is finalized until you approve it.

## Questions

1. Have you mentored or reviewed the work of junior analysts, even informally? This decides whether the mentoring row moves up.
2. What are your non-negotiables on pay, location and schedule? I cannot clear the hard gates without them.
3. Was the 11% retention lift relative or absolute, and did you design the test alone or with others? The application needs both answers.

*Response mode: answer any of these, or say "skip". Silence is an answer.*

**Upgrade menu:**
- **L1 research (up to 5 searches, 2 fetches):** confirms the posting is live and the company exists as described, and gives the role-family pay band. This resolves the unverified-posting risk.
- **Mentoring evidence:** any junior-analyst work, even informal, moves row 7.
- **Healthcare exposure:** any adjacent work (regulated data, patient-facing product, health-plan or benefits data) would move row 9.
- **Tuesday dossier:** I can produce a `tuesday-dossier.md` that carries this assessment forward for later turns.

For interview prep after you decide, mock-interview is the sibling skill.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.