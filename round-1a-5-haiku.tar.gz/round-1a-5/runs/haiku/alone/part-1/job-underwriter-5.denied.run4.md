**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office)
- `must_have`: direct: R2, R3, R4a, R5, R6, R7 · adjacent: R4b (BigQuery warehouse)
- `important`: unclear: R8 (ingestion from app and CRM), R9 (data contracts)

R4b is a credible bridge from Snowflake, with BigQuery itself unexamined. R1 and R8–R9 are unclear from what you gave me, not evidenced against you.

**Opportunity ledger.** The posted pay sits at the role-family median, and the scope is named (RR2 positive). Unresolved: whether the employer and posting verify (RR1), equity value (RR3), and who the hiring manager is (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the company's own careers page, with the employer confirmed (RR1); (2) your location and US work eligibility are confirmed (R1); (3) any BigQuery ramp is framed as adjacent, never as BigQuery experience (R4b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` the about page as you provided it; not checked against the live site |
| Mandate | Build and run pipelines for tutoring reporting: app and CRM ingestion, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Scope read | Wider than the usual one-domain senior scope: ingestion, warehouse and contracts in one post | `[inferred]` from the JD's three areas against the pay report's norm |
| Market calibration | Posted base $148,000–$166,000 sits around the median ($151,000) and reaches above the IQR top ($163,500). The company's Series C stage falls within the Series B–D cohort the report covers | `[generic]` Datawright 2026 report, n=2,310, as your recruiter sent it; `[grounded]` the JD's figure |
| Unknowns | Equity value; hiring manager; whether CRM ingestion is in scope; what BigQuery fluency is expected on day one; your location and authorization | — |
| Contradictions | None found between the JD and the about page as provided | `[grounded]` provided text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | discovery | JD gate is clear; your location and authorization were not in what you gave me | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in the CV only | `[grounded]` CV | none |
| R3 | dbt | must_have | direct | medium | none | About 180 models on Snowflake, stated in the CV only | `[grounded]` CV | none |
| R4a | A cloud warehouse (the requirement's general wording) | must_have | direct | medium | none | Snowflake is a cloud warehouse; the requirement does not name one | `[grounded]` CV against JD wording | none |
| R4b | BigQuery warehouse (the responsibilities) | must_have | adjacent | medium | transferability | Snowflake and BigQuery share the dbt-on-cloud-warehouse pattern, but the JD names BigQuery and you have not used it. Limit: no BigQuery use stated | `[inferred]` transfer from the Snowflake work | Q2; G1 |
| R5 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration on payroll pipelines, per CV | `[grounded]` CV | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations test suite, per CV | `[grounded]` CV | none |
| R7 | Strong SQL and Python | must_have | direct | medium | none | Used daily, per CV | `[grounded]` CV | none |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | CV describes pipelines but not these sources | `[grounded]` CV silence | Q3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | CV mentions dbt models and tests, not contracts | `[grounded]` CV silence | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery specifically (R4b, must_have) | transferability | Snowflake dbt work; no BigQuery in the CV | The JD names BigQuery as the warehouse, so this is the most visible objection | Any BigQuery sandbox, course, migration, or cost or partitioning discussion | A small dbt project on BigQuery you can show | `[inferred]` transfer; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | This is a gap in my check, not a finding. The one search that would have confirmed the employer and posting was refused, so nothing here is verified. The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Posted pay at the role-family median | positive_signal | — | "$148,000–$166,000 plus equity" | The stated band is realistic for the level and stage | `[generic]` pay report band; `[grounded]` JD figure | Is $148,000–$166,000 the approved band for this level? | noted |
| RR3 | Equity value unstated | unknown | — | "plus equity" | Total compensation may be materially lower or higher than the base suggests | `[inferred]` from the posting's silence on grant size | What is the grant size, vesting schedule, and valuation basis? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting names no hiring manager) | Reporting line and roadmap ownership are unknown | `[inferred]` from the posting's silence | Who would I report to, and who owns this pipeline's roadmap? | unresolved |
| RR5 | Scope wider than the usual one-domain senior role | risk_signal | low | "Build and run the pipelines behind our… reporting: ingestion…, a dbt-modelled warehouse…, and the data contracts" | This could be a broader remit than the title usually carries, with no direct reports stated | `[generic]` scope norm from the pay report; `[inferred]` from the JD's three areas | Does this role own all three areas, or one domain, and does it have a team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the Snowflake bullet with dbt modelling and test conventions, without implying BigQuery | see R4b | `[grounded]` CV | pending your approval |
| W1 | Build a small dbt project on BigQuery to show | see R4b, G1 | `[generic]` a ramp artifact is a common way to close a stack gap | pending your approval |
| A1 | Ask the recruiter for the live posting link and the hiring manager before investing in the application | see RR1, RR4 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR3 and RR5 in the first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Once you apply, mock-interview can rehearse the BigQuery question with you.

## Evidence status

Verified: none yet. The claims rest on your CV, the JD and the about page as you provided them. None has been checked against an outside source.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search to confirm the employer and the posting was sent and refused. It would have moved RR1 and the posting-live check |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report and its scope norm were pasted in hand, which fixes the market calibration band and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting or the company's careers page → RR1 closes, and the employer is verified.
- BigQuery evidence (a sandbox project, a course, a migration) → R4b can move toward direct.
- CRM ingestion or data-contract work in your history → R8 and R9 resolve.
- Your location and work authorization → R1 resolves.
- A deeper research pass on the company (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.
- The hiring manager's name → the scope read and the positioning for that reader.

I can also write this up as `tuesday-dossier.md` so the analysis carries into your interview prep.

1. Where are you based, and are you authorized to work in the US without sponsorship? (R1)
2. Have you touched BigQuery at all, such as a sandbox, a course, a migration or a query-cost discussion? If not, how fast could you ramp? (R4b, G1)
3. Did app or CRM ingestion, or data contracts with analysts, sit in your work at the payroll company? (R8, R9)

Answer in text, paste a link, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.