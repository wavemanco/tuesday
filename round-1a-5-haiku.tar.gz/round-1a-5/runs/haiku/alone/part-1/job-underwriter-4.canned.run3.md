**Decision: conditional_go.** Apply, once the three conditions below are checked. The role is a close fit on the stated requirements. The main open items are the pet-insurance domain gap and several facts the posting does not state.

**Research tier: L0.** I have not searched the company, the posting, or the market. Every company and market statement below is either from your input or labeled. Research is available as an upgrade, described below.

## Decision snapshot

**Candidate fit ledger** (per requirement, from the evidence map)
- Must-have: meets, 4+ years pricing analytics (5 stated) · meets, GLM experience (young-driver rating model, built and maintained) · meets, strong SQL and Python (stated daily) · meets, presenting to an underwriting lead (quarterly review to head of underwriting)
- Preferred: meets, insurance experience (UK motor)
- Implied: partial, pet-insurance pricing (no pet experience) · partial, ownership of a live product's monitoring (motor only, not stated as a live-product owner)

**Hard gates:** location and right to work, unknown (JD says "fully remote (UK)"; your location is not stated) · pay, unknown (not in the posting; no floor given) · line management, not a stated gate, but the title "Senior" leaves it open

**Confidence:** medium. All fit claims rest on your CV statements. No artifacts or references have been checked.

**Opportunity ledger** (separate from fit): no red flags in the text provided. Unknowns: company stage, whether the posting is live, pay, and whether this is a new product or an existing book.

## Role reality

- **Role:** Senior Pricing Analyst, Brindlemoor (insurtech). Owns pricing analytics for a pet-insurance product: builds and monitors rating models, designs and reads price tests, and turns results into recommendations for underwriting and product.
- **Stated requirements:** 4+ years pricing or actuarial analytics; strong SQL and Python; GLM experience; presenting to underwriting or actuarial leads. Insurance experience is a plus.
- **Implied:** the role has a live product to monitor, so the work is ongoing, not a one-off build. Pet-insurance risk drivers differ from motor's. Management is not mentioned.
- **Unknowns:** team size, reporting line, pay, stage of the product, whether the role has line management.
- **Market calibration:** a senior analyst in pet pricing usually carries the same modelling toolkit as motor, with a different risk-driver set `[generic]`. This is a pattern, not a claim about Brindlemoor.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ yrs pricing/actuarial analytics | meets | medium | none | 5 yrs stated, last 2 as senior analyst |
| 2 | Must | Strong SQL | meets | medium | none | Daily use, stated |
| 3 | Must | Strong Python | meets | medium | none | Daily use, stated |
| 4 | Must | GLM experience | meets | medium | none | Built and maintained GLM for young-driver book |
| 5 | Must | Presenting to underwriting/actuarial leads | meets | medium | none | Quarterly pricing review to head of underwriting |
| 6 | Preferred | Insurance experience | meets | medium | none | UK motor insurer, 5 yrs |
| 7 | Implied | Pet-insurance pricing | partial | low | transferability | No pet work; motor transfers in method, not in risk drivers |
| 8 | Implied | Monitoring a live product | partial | medium | discovery | Monitoring motor rating models stated; live-product ownership not stated |
| 9 | Hard gate | UK location / right to work | unknown | unknown | hard-gate | Not stated |
| 10 | Hard gate | Pay | unknown | unknown | hard-gate | Not in posting; no floor given |
| 11 | Implied | Line management | unknown | unknown | discovery | Title "Senior"; neither confirmed nor excluded |

## Gap recovery queue

- **G7, pet-insurance pricing (transferability).** Motor GLM and price-test methods carry over. Pet risk drivers (breed, age, vet-cost inflation, lifetime vs annual cover) are new `[generic]`. Closes with: any pet, companion-animal, or non-motor pricing work, even small.
- **G8, live-product monitoring (discovery).** Closes with: a description of monitoring you ran on a live book (loss ratio tracking, rate-change triggers, model drift checks).
- **G11, line management (discovery).** Closes with: the hiring manager's answer on the role's reporting scope.

## Opportunity risk register

- **Unverified posting and employer (medium, standing):** L0 means I have not confirmed the company exists as described or that the posting is live. Cap: conditional_go until checked. Resolve with: the live posting link, the company's careers page, or the recruiter's email domain.
- **Pay not stated (low):** the posting withholds pay. Worth asking directly.
- **Insurtech stage unknown (low):** funding and product maturity are unchecked.

## Application plan (as far as evidence allows)

- Lead with GLM and price-test work, which map directly to the role's core. Use the quarterly underwriting presentation as evidence for the presenting requirement.
- Address pet-insurance directly rather than hiding it: state the motor-to-pet transfer and what you would learn first. Do not claim pet experience.
- **Proposed CV language, pending your approval, not yet used:** "Built and maintained a GLM rating model for a young-driver motor book; ran 14 price tests with the underwriting team; present quarterly pricing reviews to the head of underwriting." Nothing here is finalized until you approve it.

## Conditions for applying

1. Confirm the posting is live via the company's own careers page.
2. Confirm location and right to work for UK remote.
3. Confirm the pay band before interview, and whether the role has line management.

## Evidence status

Research tier: L0 — no searches; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | L0 in effect; research not yet consented |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0 in effect; research not yet consented |
| 3 | Hiring manager public footprint (Odile Varga) | skipped | L0 in effect; research not yet consented |

## Dossier offer

If useful, I can write this assessment to `tuesday-dossier.md` so a later session can pick it up without re-reading the posting.

## Upgrade menu

- **L1 research (up to 5 searches, 2 fetches):** verifies the company and posting, sweeps market pay for this seniority, and checks the hiring manager's public professional footprint. This clears the unverified-employer item and the pay gap.
- **Pet or non-motor pricing work:** a short description or a sample would move G7 from partial to meets.
- **A monitoring write-up or dashboard example:** would move G8.

## Questions

1. **[G11]** Does "Senior" here come with line management or mentoring? The posting says neither, and it changes how much the never-managed point matters.
2. **[G7]** Have you done any pet, companion-animal, or non-motor pricing work, even at small scale?
3. **[G10]** What pay floor do you need, and is UK remote location and right to work confirmed for you? I will treat both as hard-gate checks.

Reply with answers, "skip" to skip any, or "research" to run the L1 check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.