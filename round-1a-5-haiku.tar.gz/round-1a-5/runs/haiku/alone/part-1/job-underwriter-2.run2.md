**Snapshot:** Not a waste of time, but this posting is a stretch on its literal must-have. Status: `conditional_go`.

**Fit ledger.**

- `must_have`: direct: R3, R4; adjacent: R1b (product-decision work without the title), R2 (shipped API or platform products); absent: R1a (3+ years product management, titled)
- `important`: adjacent: R5 (run discovery with integration partners), R6 (write specs and drive delivery with engineering squads), R8 (coordinate launches with sales and support); unclear: R7 (define and track adoption metrics), R9 (agile delivery experience)

R3 (`medium`) and R4 (`medium`) are strong on technical fluency and stakeholder work, but both rest on your CV alone. R1a is the titled-years bar, unmet on paper. R7 and R9 stay unclear until you answer.

**Opportunity ledger.** The posting is specific about scope: a partner-facing platform, two squads, named launch duties. It asserts roadmap ownership without showing decision rights (RR1), and it gives no pay or location (RR3). No severe red flags.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you can give one concrete example of a product decision you owned, verifiable in interviews (R1a, R1b); (2) you can show how you measured adoption of something you built (R7); (3) you confirm the 3+ years bar is not an automatic screen (RR2). If it is a literal screen with no route around it, this posting is a poor use of your time, though the role family may not be.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD |
| Mandate | Own the roadmap for the partner-facing API platform; lead discovery, specs and delivery across two squads | `[grounded]` JD |
| Scope read | Broad for one PM: platform ownership, partner discovery, two squads, and launch coordination with sales and support | `[inferred]` from the count of duties against the two squads |
| Market calibration | Not run; search was unavailable | — |
| Compensation | Not stated | `[grounded]` JD is silent |
| Unknowns | Decision rights, location, pay, contract basis, whether 3+ years is literal | — |
| Contradictions | None visible in the JD text you gave | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management, titled | must_have | absent | none | discovery | No PM title on the CV, and you say so yourself. Length of experience is not a gate, so it keeps its must-have tier | `[grounded]` CV and your statement | Question Q1 |
| R1b | Product-decision work without the title | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions for product and requirements documents. Limit: no evidence you owned prioritization or the roadmap decision | `[grounded]` CV, self-reported; `[inferred]` adjacency | Q1 answer decides this |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client integrations of your vendor's REST APIs. Limit: you shipped integrations on a platform, not the platform as a product | `[grounded]` CV | Work sample: a sanitized requirements doc or playbook excerpt |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture. CV self-report, no artifact, so capped at medium | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds. Sales work is not on the CV, so that part is unshown | `[grounded]` CV | none |
| R5 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions are the closest match. Not framed as product research | `[grounded]` CV | none |
| R6 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination. No squad delivery cadence shown | `[grounded]` CV | Work sample, as R2 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | CV is silent on metrics. The triage-tool lead is unconfirmed and cannot count | `[grounded]` CV silence; memory lead unconfirmed | Question Q2 |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT across 30+ integrations. Sales and support coordination not stated | `[grounded]` CV | none |
| R9 | Agile delivery experience | important | unclear | low | discovery | CV is silent | `[grounded]` CV silence | Ask in interview |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Owned product decisions (R1a, R1b) | discovery | You have adjacent product work but no stated decision you made and answered for | This is the must-have most likely to decide the screen. Closing it moves R1b toward direct | A roadmap you set, a prioritization call with its reasoning, a launch decision you owned | `[inferred]` that this closes the must-have |
| G2 | Adoption measurement (R7) | discovery | No metric on the CV | An explicit responsibility with no evidence on the CV | Adoption numbers, a before-and-after, a dashboard you used | `[grounded]` JD duty against CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership asserted, decision rights not shown | unknown | — | "Own the roadmap for our partner-facing API platform" | Priorities may pass through a product lead or leadership | `[inferred]` from ownership language against silence on decision rights | Which roadmap decisions does this role make alone, and which need sign-off? | unresolved |
| RR2 | Literal 3+ years PM bar may act as a title-years filter | risk_signal | medium | "3+ years product management experience (must-have)" | Non-PM titles may be filtered before your bridge is read | `[generic]` pattern for PM screens, not a claim about this employer | Is the 3+ years requirement a hard screen, or would owned product work at this level count? | unresolved |
| RR3 | Pay and location not stated | unknown | — | JD silent on both | Could be standard practice; no band to compare against | `[inferred]` from the JD as given | What is the base range, and what is the location policy? | unresolved |
| RR4 | Employer and live posting not verified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to show a footprint, the posting may be stale, or it may not represent a live hiring employer. This is because research could not run, not because a search failed | `[generic]` pattern for companies of this size | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved; caps the decision at `conditional_go` |
| RR5 | Scope and responsibilities stated concretely | positive_signal | — | "two engineering squads" | Scope is defined and measurable | `[grounded]` JD | How many partners does the platform serve today, and which launches are scheduled this year? | noted |

No `severity: high` entries.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your integration bullets with the client-feedback loop you ran for product (roadmap-input sessions) | Presents R1b truthfully | `[grounded]` CV | pending your approval |
| E2 | Headline states your real title and the adjacent scope. Do not use "product manager", "owned the roadmap" or "shipped the platform" | Avoids claims the evidence does not hold | `[grounded]` CV; reframing audit | pending your approval |
| A1 | Ask the recruiter whether the 3+ years bar is literal, and whether owned product work at this level counts | RR2 | `[grounded]` JD must-have label | pending your approval |
| A2 | Prepare one owned-decision story with its outcome and how you knew | G1, R1a | `[grounded]` gap G1 | pending your approval |
| A3 | Also target internal-transfer or integrations PM roles, where the bar is often lower | Lower-bar bridge titles | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on what you wrote at intake, which is CV-equivalent and not yet probed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was not granted, so the employer and live posting are unchecked. Would have moved RR4 and the contradictions row |
| 2. Role-family sweep | unavailable | Same cause. Would have set the market calibration for title, scope and pay |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- A confirmed owned product decision, or the playbook excerpt → R1a and R1b move toward `direct`, and R6 toward `high`.
- Your answer on adoption metrics → R7 moves from `unclear` to adjacent or direct.
- The Quartzline careers-page link and the live posting → RR4 closes, and research can run.
- Search permission granted → L1 reruns on Quartzline's existence and the PM-bar norm for this title. Up to 5 searches and 2 fetches.
- A deeper diligence pass (funding, leadership churn, public reports) is available once, up to 5 more searches and 2 more fetches, if you want it.

I can save this assessment as a `tuesday-dossier.md`, so the row IDs and your answers carry into a later session.

**Questions:**

**R1a** — Have you ever owned a product decision end to end: deciding what got built or in what order, and answering for how it turned out? If so, what did you decide, and what did engineering and clients own?

**R7** — I have an unconfirmed lead that you built an internal request-triage tool that support agents adopted. Is that right? If so, what did it do, and how did you know they adopted it?

**Constraints (not tied to a row)** — Are there non-negotiables I should check against this role, such as a pay floor, location or remote, contract type, or start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.