**Yes, it looks worth applying to, with conditions: `conditional_go`.** Your fit is strong on the requirements the posting lists. The open questions are your location and pay floor, which you haven't stated, and the ingestion and data-contract work, which your background doesn't mention.

**Fit ledger.**

- `hard_gate`: unclear: R1, R2
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 · unclear: R9, R10

R3–R7 are direct but self-reported, so they stay at `medium` until inspected. R8 (BigQuery) is the one real stack gap, and it's transferable from Snowflake. R9 and R10 are responsibilities the posting names and your background doesn't.

**Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (salary against your floor); candidate constraints not given — checks against them unknown

**Severe red flags:** none found.

**Opportunity ledger.** The terms are market-normal: the posted band sits inside the senior interquartile range (RR1), and the company checks out with a live, consistent posting (RR2). Open items are the unnamed hiring manager (RR3), the unquantified equity (RR6), and the ingestion and contracts scope (RR4).

**What would change this:** For `conditional_go`, the conditions are (1) your location and pay floor are compatible with the posting (R1, R2); (2) the ingestion and data-contract scope matches what you've owned (R9, R10). If your floor is above $166,000, or you need to be outside Denver or remote, the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` company About page (search snippet) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt warehouse on BigQuery, analyst data contracts | `[grounded]` JD, confirmed on the live careers page |
| Scope read | One domain (reporting) with ownership of ingestion and contracts; no direct reports stated | `[inferred]` from the responsibilities list |
| Market calibration | Senior at Series B–D: median $151,000, IQR $139,000–$163,500; "Senior" usually means 5–8 years | `[generic]` Datawright 2026 pay report (search snippet). The posted $148,000–$166,000 has a midpoint of $157,000, above the median and inside the IQR. Pellucid's Series C matches the report's peer group. |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetch |
| Unknowns | Hiring manager; team size; whether BigQuery is new or a migration; equity terms | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: remote US or Denver | hard_gate | unclear | none | hard_gate | Your location isn't stated | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, ~180 models | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R8 | BigQuery (the warehouse the JD names) | important | adjacent | medium | transferability | Snowflake and dbt transfer; no BigQuery use | `[inferred]` transferability | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[grounded]` JD; silence in your background | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[grounded]` JD; silence in your background | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience; no BigQuery | The JD names BigQuery; a ramp is likely | Any warehouse migration, cost tuning, or dbt adapter work | A small BigQuery or dbt-on-BigQuery project, or a note on how your Snowflake patterns map | `[inferred]` |
| G2 | Ingestion and contracts (R9, R10) | discovery | Not in your background | Two responsibilities the role is built around | Any source-system ingestion, schema ownership, or consumer agreements, even if not labelled "contracts" | Q3's answer, or a project description | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary sits inside the role-family band | positive_signal | — | "$148,000–$166,000" | Market-normal pay for the title and stage | `[grounded]` JD vs `[generic]` pay report | — | noted |
| RR2 | Company verified; posting live and consistent | positive_signal | — | "Accepting applications" | Employer is real and hiring | `[grounded]` careers page and About page | — | noted |
| RR3 | Hiring manager not named | unknown | — | (no name in JD) | Normal for this stage, but it limits how you can target the application | `[grounded]` JD silence | Who is the hiring manager, and who is the team? | unresolved |
| RR4 | Ingestion and contracts not in your background | risk_signal | medium | "ingestion from our app and CRM" | The role may own more source-side work than your reporting background shows | `[inferred]` from JD vs background | Q3 | unresolved |
| RR5 | BigQuery is new | risk_signal | low | "dbt-modelled warehouse in BigQuery" | A short ramp, not a blocker | `[inferred]` | Is BigQuery already live, or a migration in progress? | unresolved |
| RR6 | Equity unquantified | unknown | — | "plus equity" | Value unknown until terms are shared | `[grounded]` JD | — | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the Snowflake/dbt model count and Airflow ownership; don't claim BigQuery | Strongest direct evidence | `[grounded]` your background | resume_edits_pending_approval |
| A2 | In the application, say BigQuery is new and state the ramp plan | Avoids an interview surprise (RR5, R8) | `[inferred]` | pending your approval |
| A3 | Prepare an answer on ingestion and data contracts before interviewing | G2, RR4 | `[grounded]` | pending your approval |
| A4 | Settle your location and pay floor before investing in the process | R1, R2 | `[grounded]` | pending your approval |

## Evidence status

Verified: none yet. Everything above is self-reported in this message, so it is `medium` at most.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring company Denver" (returned pellucidlearning.com/about, as a snippet only); fetched pellucidlearning.com/careers/senior-data-engineer, live and matching the JD. Confirms RR2 and the contradictions row |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer salary" (returned datawright.example/2026-data-engineering-pay-report, as a snippet). Sets the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A short BigQuery project, or a sanitized dbt-on-Snowflake model excerpt → R8 toward `high` and G1 closes.
- A sanitized Great Expectations suite excerpt → R7 to `high`.
- The hiring manager's name → RR3, and the scope read.
- Equity terms → RR6.
- Deeper research on Pellucid (funding and leadership changes, hiring patterns, candidate and employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can save this as `tuesday-dossier.md`, which other Tuesday skills can read.

**Questions:**

- **[R1]** Are you based in the US, and would you take the remote or Denver options only?
- **[R2]** What is the lowest base salary you'd accept?
- **[R9, R10]** Have you owned ingestion from an app or CRM, or written data contracts that analysts depend on?

Answer in prose, or say "skip" on any of them; silence counts as a skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.