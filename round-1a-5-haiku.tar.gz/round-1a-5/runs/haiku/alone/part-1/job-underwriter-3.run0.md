**Not worth pursuing on these terms. Status: `no_go`.** Two of your hard constraints fail outright, and the strength of the rest of your profile doesn't offset them. R1 and R2 both fail.

- **Hard gates:** failed: R1 (base pay of at least $150k), R2 (remote-only work). Your constraints were given, so these checks ran.
- **Fit ledger (one line per Priority tier):**
  - `hard_gate` — hard_gate_fail: R1 (base pay of at least $150k), R2 (remote-only work)
  - `must_have` — direct: R3, R4 · absent: R5 (SEO/content, brand, PR, partnerships, sales ops)
  - `important` — direct: R6 · adjacent: R7 (operating as a team of one)
- **Opportunity ledger:** The role is built with several risk signals: scope with no stated authority or resources (RR1), an always-on expectation (RR2), no defined success metrics (RR3), and a base range that may not match the mandate (RR4, unverified). No severe red flags. No positive signals verified.
- **Severe red flags:** none found.
- **What would change this:** the employer would have to offer a remote role with a base of at least $150k. Both facts are currently contradicted by the posting, so this is unlikely.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, profitable since day one | `[grounded]` posting; the claims are unchecked |
| Mandate | Own all revenue growth end to end across seven functions: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Location | On-site in Austin, five days a week, "no exceptions" | `[grounded]` posting |
| Market calibration | Not run. A Head of Growth at this scope would normally be paid well above this range, but I haven't checked a band | unverified |
| Unknowns | Whether the role exists as described, how the equity is valued, what the success metrics are | — |
| Contradictions | None within the posting. A full-scope Head of Growth title alongside a team of one and a base under $85k is a mismatch worth questioning | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Posted range tops out at $85k, $65k under your floor | `[grounded]` posting and your stated constraint | none |
| R2 | Remote-only work (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | "On-site in our Austin office 5 days a week — no exceptions" | `[grounded]` posting | none |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | Nine years, with growth lead and Head of Growth roles | `[grounded]` your profile, unverified | none |
| R4 | Paid acquisition and lifecycle/CRM ownership | must_have | direct | medium | none | Owned both at two B2C subscription companies | `[grounded]` your profile, unverified | none |
| R5 | SEO/content, brand, PR, partnerships, sales ops | must_have | absent | medium | capability | Not in your profile | `[grounded]` absence in your profile | see G1 |
| R6 | Revenue growth at scale | important | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled | `[grounded]` your profile, unverified | none |
| R7 | Operating as a team of one with ambiguity | important | adjacent | low | transferability | You have built and managed teams of 3–7 and owned a budget, but not operated solo | `[inferred]` from your profile | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Five must-have functions with no evidence (R5), and solo operation (R7) | capability / transferability | No SEO, brand, PR, partnership or sales-ops work in your profile | Those are five of the seven functions the role owns | Any SEO or partnership work you did as part of growth, even if you didn't own it | Project summaries, if you have them | `[grounded]` profile |

Closing the gap would not change the decision, because R1 and R2 still fail.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without stated authority or resources | risk_signal | medium | "You will be a team of one to start" | You could be accountable for all seven functions with no budget or headcount committed | `[inferred]` from the scope against the team size | What budget and headcount are committed to this role in year one? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine, not occasional | `[grounded]` quote | How often does "when it matters" happen, and how did the last quarter go? | unresolved |
| RR3 | Success metrics undefined for a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be measured on criteria that change without notice | `[grounded]` quote | What three metrics define success at six and twelve months, and who sets them? | unresolved |
| RR4 | Pay below the level the mandate implies | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The title and scope may not match the pay | `[grounded]` posting; the market band is unchecked | What is budgeted for this role's base? | unresolved |

**Standing entry, employer not established:** not checked. This pass ran no research, so I can't say whether Novaline exists as described. This is a limit of this pass, not a finding about the company.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to the posting as written | R1 and R2 fail | `[grounded]` map rows | recommended |
| P2 | If you want to test it, ask the employer through contact details on its own careers page whether the role can be remote and what base is budgeted | Would test the only two things that could change the status | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Your background and the posting's terms rest only on what you've shared here.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Not run on this pass. It would test whether Novaline exists as described and whether the posting is live. Available on your go-ahead |
| 2. Role-family sweep | skipped | Not run. It would set the pay band for this title and scope against the $70–85k offered. Available on your go-ahead |
| 3. Hiring manager's public footprint | n/a | No hiring manager is named in the posting |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` to keep with your application notes.

## Upgrade menu

- L1 research on Novaline: the employer check either clears or caps the status, and the pay band tests RR4 against the market.
- A written statement from Novaline that the role is remote and the base is at least $150k: R1 and R2 would become checkable, and the status could reopen to `hold_pending_answers`.
- A deeper research pass on Novaline (up to 5 more searches and 2 more fetches), on your go-ahead.

**Questions**

1. (RR4, employer check) Do you want me to run the L1 research pass on Novaline: whether it exists as described, and the market pay band for this title?
2. (R1, R2) Would you like to send the employer the one question in P2? It's the only thing that could move this off `no_go`.

Reply with which of these you want. Silence leaves the status at `no_go`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.