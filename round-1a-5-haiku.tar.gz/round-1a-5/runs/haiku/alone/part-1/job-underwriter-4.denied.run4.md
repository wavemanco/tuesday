**Yes, I'd apply, on conditions: `conditional_go`.** On the core of the role your evidence is strong. The posting is thin, and I couldn't verify the employer, so check those points before you invest in the loop.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based role)
- `must_have`: direct: R2, R3, R4, R5, R7 · adjacent: R6 (Rating models for a pet-insurance product)
- `preferred`: direct: R8 (Insurance experience, from motor)

R2–R5 and R7 are your stated experience. R6 is a credible bridge: the GLM method carries over, and the pet-specific limits are named in the gap queue.

**Opportunity ledger.** No red flags, and nothing in the posting asks you for money, bank details or a deposit. The posting is silent on salary, decision rights and people management (RR1–RR3), and I couldn't verify the employer or that the posting is live (RR4). One entry runs the other way: the remit is specific, with a named hiring manager and an explicit price-test brief (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based role); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Conditions for go:** (1) you confirm the remote-UK gate (R1); (2) the posting is live on Brindlemoor's own careers page (RR4); (3) decision rights and any people management are clear before the loop (RR1, RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; one pet-insurance product | `[grounded]` JD only; not verified |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Scope read | One product, one analytics owner; a senior IC-style remit as written | `[inferred]` from "own … for our pet-insurance product" |
| Market calibration | Not run: the salary and role-family search was refused | — |
| Unknowns | Salary; decision rights; people management; team size; company stage; contract basis | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your location and right to work aren't stated here; the UK motor history suggests it, which is not confirmation | `[inferred]` from CV history | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; user-stated, no artifact | `[grounded]` user-stated | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, user-stated | `[grounded]` user-stated | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model | `[grounded]` user-stated | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` user-stated | none |
| R6 | Build and monitor rating models for a pet product | must_have | adjacent | medium | transferability | Motor rating method carries over; pet risk drivers and lifetime-cover dynamics are unexercised | `[inferred]` bridge from R4 | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` user-stated | none |
| R8 | Insurance experience | preferred | direct | medium | none | Motor insurer; pet product absent (see R6) | `[grounded]` user-stated | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-product rating (R6, must_have) | transferability | Motor GLM and price-test work; no pet product | R6 is the most likely objection; a stated limit makes the bridge credible | Any pricing of accident, health or annual-renewal cover; any lifetime or ongoing-benefit product you modelled | A pet-pricing reading note, or an anonymised model-structure summary | `[generic]` pet pricing differs from motor on breed, age and vet-cost trends; `[inferred]` bridge from R4 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights not stated | unknown | — | "Own pricing analytics" | You may recommend while the Director or a committee decides | `[inferred]` from the JD's silence on decision rights | Which pricing decisions does this role make itself, and which go to the Director or a committee? | unresolved |
| RR2 | Salary withheld | unknown | — | (not stated) | Pay may sit below your expectation, or the employer may not publish salaries | `[generic]` a withheld figure is common; no band available | What is the budgeted salary and band for this role? | unresolved |
| RR3 | People management unstated | unknown | — | "Senior Pricing Analyst" | The title may come with reports; the JD doesn't say | `[inferred]` from the title against the JD's silence | Does this role line-manage anyone now or within a year? | unresolved |
| RR4 | Employer and posting unverified | risk_signal | medium | "Brindlemoor (insurtech)" | The posting can't be checked from here; it may be stale, or the company may be too new to have a public footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| RR5 | Remit is specific | positive_signal | — | "design and read price tests" | Scope and deliverables are defined | `[grounded]` JD | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Check the posting on Brindlemoor's own careers page before applying | RR4 | `[grounded]` register | pending your approval |
| E2 | Ask RR1–RR3 in the first call, before the loop | decision rights, pay, management | `[grounded]` register | pending your approval |
| E3 | Use "ran 14 price tests" and "built and maintained the GLM" exactly as you did them; claim design only where you designed | keeps every claim at its real strength | `[grounded]` your account | pending your approval |
| E4 | Frame pet as a transfer, not experience: name what carries over (GLM method, test design, underwriter communication) and what doesn't | R6 | `[generic]` for the domain points | pending your approval |

**Evidence status**

Verified: none by document. R2–R8 are your own statements in this conversation, at `medium` (specific, but no artifact inspected). Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor insurtech pet insurance"; the call was refused. Would have moved: whether the posting is live and the employer exists as described (RR4) |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst pet insurance UK salary"; refused. Would have moved: the market band for RR2 and the scope norm |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have moved: the scope read and which story to lead with for this reader |

Web search permission was not granted, so I did not retry. I have not given a salary band from memory.

**Upgrade menu**

- A link to the live posting or Brindlemoor's careers page → RR4 closes or stays open.
- A salary band or a budget answer → RR2 closes.
- Your location and right-to-work position → R1 closes.
- An inspectable pet-pricing artifact, such as a reading note or anonymised model summary → R6 moves toward `direct`.
- Permission to run web search → the three research checks above can run.

Questions (answer any, or say skip):

R1 — Are you based in the UK with the right to work here, and is a fully remote role workable for you?

R6 — Have you done any pricing work on pet, health or lifetime-benefit cover, even a side project or reading? If so, what?

RR3 — Would you take on line management of a pricing team if this role carries it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.