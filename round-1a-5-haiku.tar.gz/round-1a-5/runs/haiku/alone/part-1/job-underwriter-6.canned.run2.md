**Worth going for, but hold until two things are checked: `hold_pending_answers`.** Your day-to-day experience matches most of what the role asks for: pipeline and renewal reporting, SQL, Salesforce, and a monthly pipeline review. The two places you'd be stretching are the forecast and billing data, and the posting doesn't yet tell us whether your location and pay floor work, which could decide it.

**Fit ledger.**

- `hard_gate` — unclear: R1, R2
- `must_have` — direct: R3, R5, R6; adjacent: R4, R7; unclear: R8
- `important` — direct: R9

R3, R5, R6 — direct on experience, Salesforce and SQL; R4 — B2B payments, not software (limit named); R7 — pipeline review feeds a forecast, but you've never owned one (limit named); R8 — billing data never worked, finance contact unknown; R1, R2 — no location or pay floor stated to check against.

**Hard gates:** none failed; unconfirmed: R1 (two office days a week in Bristol), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown

**Severe red flags:** none found.

**What would change this:** the awaited answers are your location and pay floor (R1, R2), and whether you have ever worked with finance on revenue or renewal numbers (R8). If the first two clear and R8 has any finance contact, this moves to `conditional_go`, with the conditions below.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; founded 2018; 96 employees; £11M Series A, April 2025 | `[grounded]` quillfield.co.uk/about |
| Role | Revenue Operations Lead; owns CRM and billing data; builds pipeline and renewal reporting; runs the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two office days a week in Bristol | `[grounded]` JD |
| Scope read | Wider than a single function: CRM, billing data, reporting and forecast together. Team size and decision rights are not stated | `[inferred]` from the JD's responsibility list against its silence on team |
| Market calibration | £61.5k–£67k sits around the median for UK RevOps leads in B2B software (£64.2k; interquartile range £57.8k–£70.4k). This is the band, not this employer's offer | `[generic]` Ledgerline 2026 UK RevOps pay guide (n=438) |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield. The posting doesn't say whether this role reports to them | `[grounded]` public profile; reporting line `[inferred]` |
| Unknowns | Reporting line; team size; who owns the forecast versus finance; contract type; whether the posting is on Quillfield's own careers site | — |
| Contradictions | None between the JD and the company's own pages | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | No candidate location given, so nothing to check | `[grounded]` JD; no claim | Q1 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD; no claim | Q1 |
| R3 | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | Five years in sales ops, two running RevOps; stated, not yet inspected | `[grounded]` your message | none |
| R4 | At a B2B software company | must_have | adjacent | medium | transferability | Your employer was a B2B payments company, so it's B2B but not software. Limit: no software-company context | `[inferred]` from your employer type | G3 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet seen | `[grounded]` your message | upgrade menu |
| R6 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; stated | `[grounded]` your message | none |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review, which feeds forecasts. Limit: finance owned the company forecast | `[inferred]` from the pipeline review's place in forecasting | G1 |
| R8 | Working with finance on billing or revenue data | must_have | unclear | none | discovery | Billing data never worked on. Revenue or renewal work with finance is not stated | `[grounded]` your message; finance contact unknown | Q2 |
| R9 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt both dashboards; stated, not yet inspected | `[grounded]` your message | upgrade menu |

Confidence on R1 and R2 is `none` because no candidate claim exists yet.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7) | transferability | Pipeline review and renewal reporting; no company forecast owned | A must-have, and the one the CFO-facing part of the role leans on | Any pipeline-to-close comparison you produced that a finance team used | A sanitized forecast-versus-actuals note | `[inferred]` bridge from the pipeline review; `[generic]` that forecast ownership is what interviews probe |
| G2 | Finance on billing or revenue data (R8) | discovery | Billing data never worked on; renewal dashboards may have touched revenue figures | A must-have that the role centres on; the answer decides whether this is a stretch or a gap | Reconciling pipeline or renewals against what finance booked; invoice-level or renewal-value checks | A sanitized reconciliation or renewal-value example | `[grounded]` your message; `[inferred]` that this moves the decision |
| G3 | Software-company context (R4) | transferability | B2B payments; no software-company work | A named requirement, but a payments background is close to what this employer does | Invoicing and payments work at a payments company; subscription or renewal logic | Company product overview from your own work | `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's careers site in search | unknown | — | Posting on jobs.tallyboard.example | The posting may be live but unindexed, filled, or only on the aggregator | `[inferred]` from one failed search | Where is this role listed on Quillfield's own careers site? | unresolved |
| RR2 | Reporting line and team unstated, against a hiring manager who runs RevOps | unknown | — | "You will own our CRM and billing data" | The role may sit under Tamsin Achebe, or beside them with its own remit | `[inferred]` from the public title against the JD's silence | Does this role report to the Head of Revenue Operations, and what team and budget sit under it? | unresolved |
| RR3 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model and sign-off, or prepare inputs for the CFO | `[inferred]` from the verb "run" against the JD's silence on finance's role | Does this role own the forecast model and sign-off, or prepare it for the CFO? | unresolved |
| RR4 | Salary stated and mid-band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is likely within expectation for the level | `[grounded]` JD; band `[generic]` | Is the range the budgeted band for this level? | noted |
| RR5 | Named deliverables | positive_signal | — | "build the pipeline and renewal reporting our sales and finance teams run on" | The scope is concrete and measurable | `[grounded]` JD | Which of these deliverables exist already, and which are new? | noted |

No severe red flags. The posting asks nothing of you beyond the role itself. The standing "employer not established" entry doesn't fire: Quillfield's own site confirms the company exists.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Describe the forecast experience as pipeline review that feeds a forecast, not as forecast ownership | Keeps R7 truthful and stops an interviewer finding an overclaim | `[grounded]` R7 | pending your approval |
| A2 | Ask the recruiter for the reporting line, forecast ownership, and the careers-page link | Clears RR1–RR3 before you invest in the loop | `[grounded]` RR1–RR3 | pending your approval |
| A3 | Lead with the pipeline and renewal dashboards and the Salesforce certification | These are your strongest direct matches (R5, R9) | `[grounded]` R5, R9 | pending your approval |
| A4 | Prepare one sanitized reconciliation example, if one exists | Only route to a stronger R8 | `[grounded]` G2 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your message, which counts as a CV-equivalent prose background: leads for verification, not proof.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searches "Quillfield invoicing software company Bristol" (returned quillfield.co.uk/about: Bristol, founded 2018, 96 employees, Series A April 2025) and "Quillfield careers Revenue Operations Lead" (no results). Moved: employer confirmed; posting not found on the careers site (RR1) |
| 2. Role-family sweep | yes | Search "revenue operations lead UK salary Bristol B2B software forecast" returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration |
| 3. Hiring manager's public footprint | yes | Search "Tamsin Achebe Quillfield" returned one profile, "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: reporting-line question (RR2) and positioning. One result; attribution rests on the name and employer match |

The posting was read as a link you gave me (`user links read 1`).

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so the recruiter's answers can update it in place.

## Upgrade menu

- A Salesforce administrator certificate → R5 to `high`
- A sanitized forecast-versus-actuals note, or a pipeline input finance used → R7 moves toward `direct`
- A sanitized reconciliation or renewal-value example → R8 becomes assessable
- A sanitized pipeline or renewal dashboard screenshot → R9 to `high`
- The posting's link on Quillfield's careers site → RR1 cleared
- Your location and pay floor → R1 and R2 resolved
- A deeper research pass on Quillfield (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs

## Questions

Q1 (R1, R2) — Can you work two office days a week in Bristol, and is £61,500 above your pay floor?

Q2 (R8) — Did you ever work with finance on revenue, renewal or billing numbers at the payments company, even at reconciliation level?

Q3 (R7) — Did any pipeline number you produced go into a company forecast that finance or the CFO used, even in part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.