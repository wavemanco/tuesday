**Yes, apply, but confirm the employer and the location first.** Your core experience matches the must-haves closely. The open items are whether Brindlemoor is a real hiring employer as described, your location, pay, and whether the role manages people. Status: `conditional_go`.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0.** Both searches were refused because search permission was not granted, so nothing about Brindlemoor has been checked outside your pasted text.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls were refused. This would have confirmed Brindlemoor exists as described and the posting is live (RR1). |
| 2. Role-family sweep | unavailable | Same refusal. This would have set a market pay band and scope norm for the title. |
| 3. Hiring manager's public footprint | unavailable | Odile Varga's name was given, but no search was sent after targets 1 and 2 were refused. It would have informed positioning. |

## Decision snapshot

**Apply, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (pet-insurance product)
- `preferred` — direct: R9

R8 — motor pricing carries over, pet risk drivers don't; R1 — location not yet stated.

**Opportunity ledger.** The scope is specific and the reporting line is named (RR4). Pay, direct reports and decision rights are unstated (RR2, RR3), and the employer is unverified (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Brindlemoor's role is confirmed on its own careers site (RR1); (2) you are UK-based (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header. Existence not checked (search refused) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A step from senior analyst to owner of pricing analytics for one product | `[inferred]` from the responsibility list against the title |
| Market calibration | Not run. There is no pay band to set against | — |
| Unknowns | Pay, contract type, direct reports, which pricing decisions the role makes alone | — |
| Contradictions | None visible from the JD alone; not cross-checked online | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | The gate is location. Nothing you've said settles where you're based. | `[grounded]` JD | Confirm (Q1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst. This is a length requirement, so it is not a gate. Self-reported; no artifact. | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, as you state it. No artifact yet. | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Motor, not pet. | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | presentation | Building and maintaining are stated. Monitoring cadence is not. | `[grounded]` your background; `[inferred]` that monitoring is not yet evidenced | Gap G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting. | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. | `[grounded]` your background | none |
| R8 | Pet-insurance pricing context | important | adjacent | medium | transferability | Motor pricing method carries over: GLM frequency and severity, test design, rating-factor work. Not exercised: pet risk drivers, vet-cost trends, lifetime or annual pet product structure. | `[inferred]` from the JD's pet product against your motor work | Gap G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer. | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance context (R8, important) | transferability | Motor pricing work only; no pet data or product | The most likely objection in an interview. A stated limit answers it better than a claim of pet expertise would. | Any pet-pricing reading, competitor comparison or sample rating analysis, even informal | A short pet pricing note, or a sample GLM on public pet data | `[inferred]` that this is the likeliest objection; `[generic]` for pet-market differences |
| G2 | Monitoring of rating models (R5, must_have) | presentation | Build and maintain are stated; monitoring routine is not | Monitoring is in the JD and is the part most likely to be probed | Drift checks, loss-ratio tracking, A/E reviews, alerts you set on a live model | A monitoring pack, dashboard screenshot, or a written routine | `[grounded]` your background; `[inferred]` that it is probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role posted on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay in the posting) | Pay may sit below the senior band for this title. No band was searched, so this cannot be calibrated. | `[inferred]` from the withheld figure | What is the base salary range for this role? | unresolved |
| RR3 | Direct reports and decision rights not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean accountable for pricing outcomes without people management or sole sign-off on rate changes. You have never managed anyone, so this matters. | `[inferred]` from "own" against silence on people and authority | Does this role manage anyone, and which rate changes can it approve alone? | unresolved |
| RR4 | Clear scope and named reporting line | positive_signal | — | "build and monitor rating models, design and read price tests" | The role's outputs are defined and measurable, and the reporting line is named. | `[grounded]` JD | What does success look like in the first year? | noted |
| RR5 | Contract type not stated | unknown | — | (no contract type in the posting) | The role may be fixed-term or permanent. Nothing in your inputs makes this a gate. | `[inferred]` from the silence | Is this a permanent role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Brindlemoor's own careers site before applying | RR1 | `[generic]` pattern for employers of this size | proposed |
| A2 | Lead with motor evidence on R4, R6 and R7, and name the pet gap yourself: "motor pricing; no pet data yet" | R4, R6, R7, R8. Claiming pet expertise would be inflation | `[grounded]` rows above | pending your approval |
| A3 | Ask the recruiter for the salary band and whether the role has direct reports | RR2, RR3 | `[grounded]` RR2, RR3 | proposed |
| A4 | Prepare a monitoring routine answer, stated only as far as it is true | R5, G2 | `[grounded]` G2 | proposed |

## Evidence status

Verified: none yet. Everything above is your self-report from this conversation and has not been confirmed through a specific probe.
Unverified leads: none.
Rejected inferences: none.

## Upgrade menu

- Search permission granted → targets 1 and 2 run, checking RR1 and setting a pay band for RR2.
- UK location confirmed → R1 closes.
- The posting link from Brindlemoor's careers site → RR1 closes.
- A salary range → RR2 closes, and it gets set against the band.
- A pet-pricing note or sample analysis → R8 moves from the self-report to an artifact.
- A monitoring pack, dashboard screenshot or written routine → R5 moves toward `high`.

If it's useful, I can save this as a `tuesday-dossier.md` file so it carries into later sessions.

## Questions

1. **R1:** Are you based in the UK? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **RR1:** Where did you find this posting? If it's on Brindlemoor's own careers site, a link would settle that question.
3. **RR3:** Did the posting or the recruiter say whether this role has direct reports?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.