## Decision snapshot

**Yes, apply, but as a `conditional_go`, not a clean `go`.** Your must-haves read as direct. The open items are one hard gate, pet insurance, and whether the role has people or product scope.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (recommendations for underwriting and product), R10 (pet-insurance product)
- `preferred` — direct: R9 (insurance experience)

R6 and R7 are direct on running tests and building models; design and monitoring are not yet separated. R10 is the one real gap: motor pricing carries over, pet pricing is unexercised.

**Opportunity ledger.** The posting and employer are unverified because the search step was refused (RR1). Pay (RR3) and line management (RR2) are unknown. RR4 is a positive: the remit is concrete.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you are UK-based and can work fully remote from there; (2) R6 and R7 confirmed as design and monitoring in interview; (3) the posting verified on Brindlemoor's own careers site (RR1); (4) the pet gap stated with its limit, not framed as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your JD header; existence not verified (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics role; no people responsibilities stated | `[inferred]` from the listed duties against the title |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Market calibration | Not run: the role-family search was refused, so no pay or scope band is claimed | — |
| Unknowns | Pay; line management; product ownership; rating-model ownership at launch; maturity of the pet product | — |
| Contradictions | None in what you supplied; the company's own site could not be checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (JD: "Fully remote (UK)") | hard_gate | unclear | none | hard_gate | No statement of your location or working constraints was given; the gate is not established | `[grounded]` JD; constraint not given | Question 1 |
| R2 | 4+ years in pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst. The years figure is graded on fit, not as a gate | `[grounded]` your background, self-reported | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | SQL and Python used daily; "strong" is self-assessed | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | Ran 14 price tests with underwriting; design and read-out not separated | `[grounded]` your background; design not stated | Question 2 |
| R7 | Build and monitor rating models | must_have | direct | medium | discovery | Built and maintained a model (R4); post-launch monitoring not stated | `[grounded]` your background; monitoring not stated | Question 3 |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are stated; product-side recommendations are not. Limit: no product decisions evidenced | `[grounded]` your background; `[inferred]` that product is the gap | Bridge case in the gap queue |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing transfers (GLM, rating, price tests). Pet-specific pricing is not exercised; you stated you have never worked on pet insurance | `[grounded]` your statement; `[inferred]` requirement from the mandate; `[generic]` that pet cover has its own rating drivers | Name the limit and closure path (G1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R10, important) | transferability | Motor pricing carries over; pet pricing not exercised | The main objection a pet-product hiring manager is likely to raise | Any non-motor personal-lines pricing; work on a product with different cost drivers from motor | A pricing note or model documentation you can show | `[inferred]` transfer is the objection; `[generic]` pet cover has distinct rating drivers |
| G2 | Price test design (R6, must_have) | discovery | Ran 14 tests; design and read-out not separated | Design ownership is the difference between running and leading tests | Test briefs, test-cell design, read-out decks | A test brief or read-out, anonymised | `[grounded]` your background |
| G3 | Post-launch monitoring (R7, must_have) | discovery | Built and maintained a model; monitoring not stated | Monitoring is named in the mandate | Actual-vs-expected reviews, drift checks, recalibrations | A monitoring pack or dashboard screenshot | `[grounded]` your background |
| G4 | Product-side recommendations (R8, important) | transferability | Underwriting recommendations stated; product not | Product is in the mandate | Pricing or cover changes you proposed that product adopted | A product recommendation you wrote | `[grounded]` your background |
| G5 | Fully remote UK gate (R1, hard_gate) | hard_gate | Not established | Fails or passes the whole application | — | — | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Brindlemoor (insurtech)" | The search step was refused, not returned empty, so existence and liveness are unverified | `[grounded]` search refused this session | Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Line management not stated | unknown | — | "Senior Pricing Analyst"; "Own pricing analytics" | People responsibilities may apply to a senior title; you have not managed anyone | `[inferred]` from JD silence against the title | Does this role line-manage anyone, now or in its first year? | unresolved |
| RR3 | Pay not stated | unknown | — | JD text carries no salary | Pay is a term; it could conflict with your floor, which you have not given | `[grounded]` JD as supplied | What is the base salary for this role? | unresolved |
| RR4 | Concrete remit | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined, which helps the fit read | `[grounded]` JD | Which rating models does the role own at launch, and which already exist? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Brindlemoor's own careers site before applying | Closes RR1 | `[grounded]` RR1 | proposed, pending your approval |
| A2 | Lead with what carries over: GLM build and maintenance, the 14 price tests, the quarterly review to underwriting. Use only wording that matches what you told me | R3, R4, R5, R6 | `[grounded]` rows | proposed, pending your approval |
| A3 | State the pet gap first, with its limit: motor pricing transfers; pet pricing is unexercised; name a closure path | R10, G1 | `[grounded]` R10; `[generic]` pet cover drivers | proposed, pending your approval |
| A4 | Ask RR1, RR2 and RR3 in the first call with the employer | The register doubles as interview preparation | `[grounded]` register | proposed, pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at intake; no claim has been confirmed in a probe.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were refused: the environment has not granted search permission. Would have checked that the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The pay and scope search was refused, so no market calibration is given (RR3 stays unknown) |
| 3. Hiring manager's public footprint | unavailable | The name was given, so a query could be formed; the search was refused. Would have fed positioning for Odile Varga's reading of your story |

Nothing from research is used in this assessment.

Dossier offer: I can write this out as `tuesday-dossier.md` so the map, register and plan carry forward into later sessions.

## Upgrade menu

- Search permission for this environment → runs the three L1 targets above (up to 5 searches and 2 fetches): it checks the employer (RR1), sets a pay band (RR3), and reads the hiring manager's public footprint.
- The live posting link, or the careers-site page → RR1 closes or fails.
- Your CV, pasted → your R2–R9 claims move from self-report toward inspectable.
- An anonymised price-test brief or read-out → R6 to `high`.
- A monitoring pack or model documentation → R7 to `high`.
- Any non-motor personal-lines pricing work → R10 transfers more strongly.

1. **R1:** Are you based in the UK, and is working fully remote from there workable for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **R6:** Of the 14 price tests you ran last year, which did you design yourself, and which did you run and read out?
3. **R7:** After a rating model goes live, did you monitor it, for example against actual-vs-expected results, and what did you act on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.