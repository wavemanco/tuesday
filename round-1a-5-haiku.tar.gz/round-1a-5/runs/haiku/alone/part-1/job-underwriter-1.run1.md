## Decision snapshot

**Yes, apply, on conditions. You are a strong fit on the core of this role. Status: `conditional_go`.** The five must-haves (R1, R2, R3, R4, R5) all read `direct`, and the open items are mentoring (R8), clinician-facing work (R7b) and healthcare data (R9, a stated plus). The condition that could stop this is that I could not verify the employer.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R6 (define and maintain the metrics layer) · unclear: R8 (mentor two junior analysts) · absent: R7b (partner with clinicians)
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

R3 (`medium`) is confirmed experiment design at scale, waiting on an artifact. R6 is adjacent: the governed dashboards show governance, but nothing you've told me shows you owned metric definitions. R8 is unclear, not absent, because nothing in your inputs settles it either way.

**Opportunity ledger.** Under-specified, and not verified: I could not confirm the employer exists as described (RR1), and the posting gives no compensation (RR2) or decision rights (RR3). RR4 is a positive: the deliverables are concrete.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is confirmed live on the company's own careers page; (2) R8 is answered with real mentoring evidence; (3) RR2 gets a concrete base range before you invest heavily in interviews.
- **What would change this:** a live posting that can't be found on the company's own site moves the decision to `hold_pending_answers`. A clinician-facing mandate that makes you the sole owner of clinical analysis would raise R7b to a must-have gap.

## Role reality

Stage: evaluating (assumed, since you didn't say otherwise).

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` the JD header; not externally checked |
| Mandate | Own product analytics for a care-navigation app | `[grounded]` JD |
| Scope read | Senior individual contributor with two mentees and a cross-functional remit | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run. The role-family search was refused, so there is no pay band | — |
| Unknowns | Compensation, decision rights, regulated-data scope, reporting line | — |
| Contradictions | None found in the material given. The careers-page check did not run | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated in your background. Self-reported, with no artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, self-reported | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test behind the 11% retention lift. Self-reported, no write-up yet | `[grounded]` your background | Offer: a pricing-test write-up would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards. Self-reported | `[grounded]` your background | Offer: a sanitized dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents to the VP Product monthly | `[grounded]` your background | Offer: a sanitized memo excerpt would raise to high |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the memo show governance. Limit: nothing says you owned metric definitions. Strengthener: a metric-definitions document | `[inferred]` from the dashboards you built | Q-R6 below |
| R7a | Partner with PMs on roadmap decisions | important | direct | medium | none | Monthly work with the VP Product and the consumer-side teams | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | absent | none | discovery | Nothing in your inputs covers clinician-facing work | `[grounded]` silence in your background | Q-R7b below |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your inputs don't mention mentoring | `[grounded]` silence in your background | Q-R8 below |
| R9 | Healthcare data experience (HIPAA), a stated plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer-PII work and a consent-state model for the warehouse. Limit: no PHI, no HIPAA-covered entity, no business associate agreements | `[inferred]` from the consent-model work | Q-R7b below covers this |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8) | discovery | Nothing in your inputs | An important requirement; a clear yes moves R8 to `direct` | Onboarding or training a junior analyst; reviewing their SQL or analyses; owning a team's career development | A team-onboarding plan, a review note | `[grounded]` silence in your background |
| G2 | Clinician work and regulated data (R7b, R9) | discovery | Consumer-side work, plus the consent model | Clinician partnership is the main domain gap; HIPAA is a stated plus | Advisory work with clinicians; any PHI or BAA exposure, even partial | A data-access policy you worked under | `[grounded]` your background; `[generic]` that this role family probes the clinical line |
| G3 | Metrics-layer ownership (R6) | transferability | Governed dashboards and a memo | The role names this as a core responsibility | Writing metric definitions; owning the semantic layer; deciding which metrics the exec memo reports | A metric-definitions doc, a semantic-layer diagram | `[inferred]` from the dashboards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established. Research was refused, so this is unchecked, not disproved | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Compensation not stated | unknown | — | (no pay line in the JD) | The base may sit below what the title and scope usually command, or the posting may simply omit it | `[inferred]` from the JD's silence on pay | "What is the budgeted base range for this role?" | unresolved |
| RR3 | Decision rights over the metrics layer and roadmap not stated | unknown | — | "define and maintain the metrics layer" | The role may define metrics without owning the roadmap calls, which sit with PMs and clinicians | `[inferred]` from the responsibility list against its silence on authority | "Which roadmap decisions does this role make alone, and which are shared?" | unresolved |
| RR4 | Concrete deliverables | positive_signal | — | "build self-serve dashboards in Looker" | Scope is defined and measurable | `[grounded]` JD | "Who owns the metric definitions today?" | noted |
| RR5 | Healthcare data handling unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | The analytics stack may hold PHI, which would bring HIPAA controls into daily analysis | `[inferred]` from the JD's HIPAA mention | "What regulated data does this analytics stack hold, and what HIPAA access controls apply to analysts?" | unresolved |

No entry is `severity: high`. There are no requests made of you in the material.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on the company's own careers page before you invest application effort | see RR1 | `[generic]` standard practice | advice, no approval needed |
| E1 | Lead your CV's experience section with the experimentation program, using your own figures: "designed and ran the experimentation program: 30+ A/B tests a year, including a pricing test behind an 11% retention lift" | see R3 | `[grounded]` your background; counts stay attached to the tests | pending your approval |
| E2 | Add: "built the company's Looker instance from scratch; 40+ governed dashboards" | see R4 | `[grounded]` your background | pending your approval |
| P1 | Positioning: lead with experimentation and the exec memo; name the consent-state model as your regulated-data work, and do not call it healthcare experience | see R5, R9 | `[grounded]` rows R5 and R9 | pending your approval |
| Q1 | Ask the RR2, RR3 and RR5 questions verbatim in the first recruiter call | the register doubles as interview prep | `[grounded]` register | advice |

## Evidence status

Verified: none yet. Your background is self-reported in this conversation and no artifact has been inspected.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was refused in this session, so the employer, the live posting and the team are unchecked. Would have moved RR1 and the role-reality contradictions row |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market band for RR2 and the calibration line |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, so there was no query to form |

## Upgrade menu

- Permit web search in this session, or paste the live posting link or the company's careers-page text: runs the employer and pay checks, moves RR1 and RR2, and sets a market band.
- A pricing-test write-up (design, sample size, result), or a sanitized excerpt of the exec memo: raises R3 and R5 from `medium` to `high`.
- A sanitized Looker dashboard screenshot with no customer data: raises R4 to `high`.
- A metric-definitions doc, or a note on whether you owned definitions: resolves R6.
- Confirmed mentoring evidence: resolves R8.

Want me to save this assessment as `tuesday-dossier.md`? I can do that whenever you say so.

Q-R8 — Have you managed or mentored junior analysts? How many, for how long, and what did you own: onboarding, reviews, their analysis, or their career development?

Q-R7b — Have you done clinician-facing work, or worked with regulated health data (PHI, HIPAA, business associate agreements), even partly or in an advisory way?

Q-R6 — For the metrics you reported, did you define the metric definitions and their governance, or did you consume definitions someone else owned?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.