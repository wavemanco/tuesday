## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (location, see RR1)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R8 (pet-insurance product)
- `preferred`: direct: R7 (insurance, motor only)

R8 is a credible bridge with its limit named. R1 to R6 are stated but not yet evidenced beyond your CV, so they sit at `medium`.

**Opportunity ledger.** The role is clearly scoped and reports to a named director. Two things are unresolved: the posting contradicts itself on location (RR1), and no salary is published (RR2). A thin employer footprint is recorded as a standing entry (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (location: the JD says "Fully remote (UK)", the careers page says "Leeds office four days a week"). Your constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location settled: remote, or you accept Leeds four days a week (RR1); (2) a base salary confirmed, ideally in or near the band (RR2); (3) the pet-insurance gap stated as adjacent, never claimed as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; name from your brief |
| Working pattern | JD: fully remote, UK. Careers page: Leeds office four days a week | `[grounded]` both, contradictory |
| Scope read | A normal senior individual-contributor scope for this title; no line management stated | `[inferred]` from the JD's responsibilities and silence on reports |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 | `[generic]` Pricewell 2026 pay survey, from search snippet |
| Compensation | Not stated in either source; the band is what to expect, not this employer's offer | `[grounded]` absence in both sources |
| Unknowns | Base salary; which location is real; team size; whether the rating-model changes are the post-holder's to make alone or go through the Director | — |
| Contradictions | Location (JD vs careers page) | `[grounded]` both |

Line management is not in the JD, so it gets no row.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, two as senior analyst, stated; CV only | `[grounded]` your CV | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your CV | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your CV | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting; exact match to the JD's audience | `[grounded]` your CV | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Build and maintain stated; "monitor" is implied by maintenance but not described | `[inferred]` from "maintained" | a monitoring example would raise it |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 tests with the underwriting team | `[grounded]` your CV | none |
| R7 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer; not pet | `[grounded]` your CV | none |
| R8 | Pet-insurance product knowledge | important | adjacent | low | transferability | No pet work. Rating logic and price-test method transfer; product-specific factors do not | `[inferred]` | see gap G1 |
| R9 | Location: remote UK, or Leeds four days a week | hard_gate | unclear | low | discovery | Your location and constraints were not given; the posting contradicts itself | `[grounded]` JD vs careers page | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8) | transferability | No pet work; motor only | The JD names the pet product as the whole remit; it is the likeliest objection | Applying the same GLM and test logic to a different book; any work on claims frequency or severity drivers | A sanitised note on how you would adapt young-driver rating factors to pet | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts itself | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two is out of date, or the role is hybrid and the JD is wrong | `[grounded]` both sources | Is this role remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in either source | The figure may sit below the band, or Brindlemoor does not publish salaries | `[inferred]` from the absence against the `[generic]` band | What is the base salary range? | unresolved |
| RR3 | Employer footprint thin (standing entry: employer not established) | risk_signal | medium | Search "Brindlemoor insurtech pet insurance" returned no results; the careers page does exist | The firm may be too new or small to show online; the posting may be stale (it says "accepting applications", so less likely); or the firm may not be a real hiring employer (its careers page makes this less likely, but does not settle it) | `[grounded]` search and careers page | What is the company's stage, funding and headcount? | unresolved |
| RR4 | Clear outcomes and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing." | The scope is defined and the reporting line is named | `[grounded]` careers page | — | noted |

No requests for money, deposits or bank details appear in the material, so no hold applies.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the 14 price tests and the GLM work, framed for an underwriting audience | Matches the JD's presentation and testing requirements | `[grounded]` JD, R4, R6 | pending your approval |
| P1 | Reference Odile Varga's public talk, "Small Books, Loud Errors" (2025 Insurance Pricing Forum), on monitoring rating models in small books; lead with how you monitored the young-driver model | Her public focus matches R5; the link is your own experience, so only use it if it is true | `[grounded]` talk listing (search snippet); the link is `[inferred]` | pending your approval |
| A1 | Ask the recruiter to confirm location and salary before investing in the loop | Closes RR1 and RR2 | `[grounded]` RR1, RR2 | pending your approval |
| G1 | Prepare a one-page note on adapting rating logic to pet insurance | Closes G1 | `[inferred]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the contradictions row (location) and RR1, and the standing entry RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example, from snippet; not fetched). Set the market calibration line `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a professional profile and a 2025 conference talk listing (from snippets; not fetched). Moved the application plan's positioning (P1) only |

## Upgrade menu

- An answer on location → RR1 closes; R9 becomes `direct` or `no_go`.
- The base salary → RR2 closes, set against the band.
- A sanitised price-test readout, or a GLM or monitoring document → raises R1 to R6 to `high`.
- A deeper research pass on Brindlemoor (funding, headcount, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` file to keep and to hand to mock-interview later.

## Questions

1. **(RR1, R9)** Can you work in Leeds four days a week, or do you need fully remote UK?
2. **(RR2)** What base salary would you need to take this? The survey median is about £58,400.
3. **(G1, R8)** Do you have any pet-insurance exposure at all, even informal, such as a side project or a conversation with a pet insurer? If not, I'll keep the gap as stated.

Answer in prose, or say "skip" on any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.