**Short answer: don't pursue it as posted.** Two of its stated terms fail your hard constraints, and no amount of fit changes that.

**Hard gates (from the posting's own text, not inferred)**
- **Location:** "On-site in our Austin office 5 days a week — no exceptions." You need remote-only from Portland. Fails.
- **Pay:** "$70–85k base." Your floor is $150k, so the top of their range is $65k short. Fails. The equity language doesn't close that gap, and Series A equity is hard to value.

Both are stated terms, so they can't be negotiated away on paper. The posting says "no exceptions" on location.

**Fit is not the problem.** Your 9 years, the $8M→$40M ARR scale-up, paid/lifecycle/experimentation ownership, team management, and SQL/GA4/Braze all line up with the role. The 8+ years requirement is met.

**What feels off, and why**
- **Title versus terms.** A Head-of role with 8+ years required is offered at a base that looks low for that title. I haven't checked this against market data, so treat it as a pattern, not a fact.
- **Scope versus staffing.** "All revenue growth end to end," covering paid, SEO, lifecycle, brand, PR, partnerships, and sales ops, handed to "a team of one." The posting presents that as a feature ("players who don't need a bench").
- **Hours and accountability.** "Evenings and weekends... is just who we are," plus "success metrics will evolve." Neither is illegal or unusual on its own, but together they describe a role where the bar moves and the hours are open-ended.

**What I didn't do.** I ran no research, so I couldn't confirm that Novaline exists as described or check its pay against current market data. I also didn't run the full underwriting write-up this skill normally produces. If you want that, I can run a short company check (about 5 searches and 2 page fetches) to verify the company and the role-family pay range. It wouldn't change the decision, since both failed gates are the posting's own terms.

**Recommendation:** Skip it. Your time is better spent on roles that are remote and in the $150k+ range. If you want to test whether they'd bend, the only question worth asking is whether they'd consider remote and a higher base. Given "no exceptions," I'd expect a no.