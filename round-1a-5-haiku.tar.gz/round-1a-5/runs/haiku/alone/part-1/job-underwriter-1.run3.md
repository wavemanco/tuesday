**Yes, apply, though I'd check the posting first.** On the core of the role you're a strong fit: the SQL, experimentation, Looker and exec-communication requirements all map to evidence you already have. The gaps are healthcare, clinician work and mentoring. Status: `conditional_go`.

- **Fit ledger.**
  - `must_have`: direct R1, R2, R3, R4, R5 · adjacent R6
  - `important`: direct R9 · absent R7 · unclear R8
  - `preferred`: adjacent R10
- **Opportunity ledger.** The posting is unverified: my web searches were refused, so I could not confirm Harborlight exists or that this role is live (RR1). The JD itself is clear on scope and gives no salary (RR2, RR3).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role appears on Harborlight's own careers site, found by you rather than through a link someone sent you (RR1); (2) you can show mentoring or people-management evidence for R8, or else frame it honestly as adjacent; (3) you frame clinician and HIPAA experience as transferable with its limits, not as domain experience (R7, R10).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, as you pasted it; existence not checked |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership | `[grounded]` JD |
| Scope read | A senior owner role with two analysts to mentor | `[inferred]` from the title and the mentoring line |
| Market calibration | Not run: the role-family search was refused, so no band | — |
| Unknowns | Whether the posting is live; how much work is with clinicians; team reporting line; salary; location and work pattern | — |
| Contradictions | None visible in the pasted text | `[grounded]` pasted JD |

**Evidence map** (all candidate claims are CV-level and unprobed, so none reaches `high`)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years in one role; a years requirement is graded on fit, not as a gate | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; expertise level not shown | `[grounded]` your intake | Offer an anonymised query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift; design rigour not yet described | `[grounded]` your intake | Offer one experiment readout |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the instance and 40+ governed dashboards | `[grounded]` your intake | Offer a dashboard screenshot |
| R5 | Define and maintain the metrics layer | must_have | direct | medium | presentation | "Governed" dashboards imply owned metric definitions, but the wording doesn't say so | `[grounded]` your intake | Repositioning proposal E1, pending your approval |
| R6 | Partner with PMs to turn analysis into roadmap decisions | must_have | adjacent | medium | transferability | Exec memo and monthly VP Product presentations are the bridge; PM partnership is not stated | `[grounded]` your intake; `[inferred]` adjacency | Gap queue G1 |
| R7 | Partner with clinicians | important | absent | none | discovery | No clinician work described | `[grounded]` silence in intake | Recall question Q1 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Not mentioned | `[grounded]` silence in intake | Recall question Q2 |
| R9 | Strong written communication with non-technical stakeholders | important | direct | medium | none | Monthly metrics memo read by the exec team | `[grounded]` your intake | Offer the memo, anonymised |
| R10 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI or HIPAA work | `[grounded]` your intake; `[inferred]` adjacency | Gap queue G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM partnership (R6, must_have) | transferability | Exec and VP Product communication; no PM partnership stated | A must-have; a clear PM example would move it to direct | Feature launches where your analysis changed a PM's scope or priority; a metric you defined that a PM adopted | A PM-facing brief or roadmap note | `[grounded]` intake; `[inferred]` that this is the likeliest question |
| G2 | HIPAA and healthcare data (R10, preferred) | transferability | Consumer PII under GDPR/CCPA; consent-state model in the warehouse | Preferred, not a gate; the limit is no PHI or HIPAA controls | Consent and data-access rules you designed; any regulated data you touched | A consent-model data dictionary, sanitised | `[grounded]` intake; `[generic]` that healthcare teams weigh HIPAA experience |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Harborlight Health (digital-health scale-up…)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research was refused, so this is unverified, not disproven | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in the JD) | The band may sit below your expectation, or salaries are simply unpublished | `[inferred]` from the JD's silence | What is budgeted for this role? | unresolved |
| RR3 | Clinician-facing scope unclear | unknown | — | "partner with … clinicians" | Clinicians may direct analysis priorities, or may only be consulted | `[inferred]` from the JD's wording | How much of the work is with clinicians, and what clinical decisions do the analyses feed? | unresolved |
| RR4 | Mandate is clearly scoped | positive_signal | — | "Own product analytics for our care-navigation app" | Ownership of a named product and a defined set of responsibilities | `[grounded]` JD | Who sets the metrics-layer priorities today? | noted |

**Application plan** (every row proposed; nothing applied)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Name metric-definition ownership explicitly in your CV, if it is true | see R5 | `[grounded]` intake | pending your approval |
| A1 | Check the posting on Harborlight's careers site before you spend effort | see RR1 | `[generic]` standing check | pending your approval |
| A2 | Choose one anonymised work sample (experiment readout or memo) to show | see R3, R9 | `[grounded]` rows R3, R9 | pending your approval |
| A3 | Prepare candid answers on mentoring and clinician work, with their limits | see R7, R8 | `[grounded]` rows R7, R8 | pending your approval |

**Evidence status**

Verified: none yet. Every claim above rests on your intake text, unprobed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused, so the employer and posting are unchecked (RR1) |
| 2. Role-family sweep | unavailable | Refused; no market band for scope or pay (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**

- An anonymised experiment readout or the monthly memo → R3 and R9 to `high` in the first-pass sense, once inspected.
- A query sample → R2 from `medium` to `high`.
- The careers-page link to the role → RR1 closes.
- Mentoring or people-management evidence → R8 moves off `unclear`.
- Once search permission is granted, I can rerun the employer check and the salary sweep (up to 5 searches and 2 fetches).
- If you'd like, I can save this as `tuesday-dossier.md` to keep and reuse.

**Questions**

R8 — Have you managed or formally mentored junior analysts? If so, how many, for how long, and what did you own: hiring, reviews, their work plans?

R7 — Have you worked with clinicians, dietitians or other domain experts on analyses? What decisions did those analyses feed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.