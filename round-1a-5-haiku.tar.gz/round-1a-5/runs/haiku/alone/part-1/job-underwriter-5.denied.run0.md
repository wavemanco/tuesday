**Decision: worth applying, on conditions. Status: `conditional_go`.**

Ines, your evidence matches the must-haves well. The one real gap is BigQuery, which is a transferability gap, not a capability gap. Two requirements about ingestion and data contracts are unknown from your CV. The employer is not yet verified, which caps the decision at `conditional_go`.

**Fit ledger.**

- `hard_gate` — unclear: R1, R2
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 · unclear: R10, R11

R9 — BigQuery against your Snowflake work, its limit named; R10, R11 — ingestion and data contracts, not in your CV.

**Opportunity ledger.** Pay is stated and sits near market (RR2, positive); the scope is realistic for the title (RR4, positive). Unresolved: the employer is not established from attributable sources (RR1, which caps `go`), and equity is unstated (RR3). No requests of you appear in the posting.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (pay, against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live and the employer checks out (RR1); (2) your location and pay floor are confirmed against R1 and R2; (3) BigQuery is framed as adjacent with its limit stated (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` About page text you pasted; not fetched |
| Mandate | Build and run the pipelines behind tutoring reporting: app and CRM ingestion, dbt models in BigQuery, data contracts for analysts | `[grounded]` JD |
| Scope read | Ownership of one reporting domain's pipelines; no direct reports stated | `[inferred]` from the JD's scope; matches the typical pattern in the report |
| Working pattern | Remote US or Denver office | `[grounded]` JD |
| Market calibration | Base median $151k, IQR $139k–$163.5k for Senior DE at Series B–D. The posted $148k–$166k (midpoint $157k) sits in the IQR, slightly above the median | `[generic]` band from the Datawright report your recruiter sent (n=2,310, not verified); `[grounded]` posted range |
| Unknowns | Hiring manager, team, level, equity terms, who owns ingestion | — |
| Contradictions | None between the JD and the About page as provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location and constraints were not given | `[grounded]` JD; constraints not provided | Q3 |
| R2 | Pay: $148k–$166k plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given; the posted range is near market | `[grounded]` JD | Q3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated on the CV; no inspectable artifact | `[grounded]` CV | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, per CV | `[grounded]` CV | none |
| R5 | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models | `[grounded]` CV | none |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; BigQuery is handled under R9 | `[grounded]` CV | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` CV | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` CV | none |
| R9 | BigQuery, named in the role's scope | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery use, so the limit is BigQuery-specific operation (cost and partitioning, GCP IAM) | `[inferred]` from the JD's scope; `[grounded]` CV | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | CV silent on ingestion sources | `[grounded]` CV silence | Q1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | CV silent on contracts or consumer agreements | `[grounded]` CV silence | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Six years on Snowflake, dbt and Airflow; no BigQuery | Named in the role's scope; a stated limit narrows the objection | Any cloud-warehouse cost or partition tuning; dbt projects moved between warehouses | A small dbt project on BigQuery; a note on Snowflake-to-BigQuery differences | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likely objection |

The question for G1 is not asked here; it is part of the closing block below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | The posting may be stale, the entity may be too small to have a footprint, or the posting may not be from a live hiring employer. Research could not run, so this is unverified | `[generic]` pattern for companies of this size, not a claim about this one | Is this role live on your careers page today, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated and near market | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is transparent and sits in the typical band | `[grounded]` JD; `[generic]` band from the provided report | none needed | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Equity could be material to total pay; grant size and terms are not given | `[inferred]` from the posting's silence | What is the equity grant size, vesting schedule and strike price? | unresolved |
| RR4 | Scope realistic; hiring manager not named | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Pipeline ownership for one domain is the typical scope; the manager is unknown | `[inferred]` from the JD; `[generic]` scope norm from the report | Who would own this pipeline domain day to day, and who is the hiring manager? | unresolved |

No request in the posting asks you to pay, deposit, or give financial or ID details.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the posting is live on Pellucid's own careers page and that the company matches its About page | RR1 gates the decision | `[grounded]` RR1 | proposed |
| A2 | Confirm your location and pay floor against R1 and R2 before applying | Hard gates unknown | `[grounded]` R1, R2 | proposed |
| A3 | Lead with dbt on Snowflake (about 180 models), Airflow and Great Expectations; state BigQuery as adjacent with its limit: "I haven't run BigQuery in production; I've moved the same dbt and SQL practice across Snowflake" | R5, R7, R8, R9 | `[grounded]` CV; `[inferred]` bridge | resume_edits_pending_approval |
| A4 | Prepare an honest answer on ingestion and data contracts, from your own experience | R10, R11 | `[grounded]` gap rows | proposed |
| A5 | Optionally, build a small dbt project on BigQuery to narrow the R9 limit | Strengthens G1 | `[generic]` that a concrete artifact narrows this objection | proposed |

## Evidence status

Verified: none yet. The CV claims are self-reported.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because web search permission was not granted; the JD and About page were provided as text, not fetched. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Refused in the same way; the pay band here is the provided Datawright report, not a search. Would have checked the market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A BigQuery dbt project, even small → R9 to `high`; the BigQuery objection narrows.
- Examples of ingestion from an app or CRM → R10 from `low` to direct.
- An example of data contracts or consumer agreements → R11 from `low` to direct.
- Your location and pay floor → R1 and R2 resolve; the decision may move to `go` or `no_go`.
- Live posting and employer check → RR1 closes.
- Search permission granted → L1 checks run on the employer and the pay band.

I can also write `tuesday-dossier.md` with this assessment if you want it for interview prep.

Questions:

1. **R10** — Tell me about a time you built ingestion from an application database or a CRM. Which sources, how was it loaded, and who consumed it?
2. **R11** — Did you define data contracts with your consumers, such as schema ownership, breaking-change rules or SLAs? If not, what was the closest equivalent?
3. **R1, R2** — Are you based in the US, and would remote or the Denver office work? What is your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.