**Decision: no_go on the terms as posted.** I'd hold any further work on it unless the terms change.

**Decision snapshot**

- **Hard gates: 2 failed.**
  - **Pay:** $70–85k base against your $150k floor. That is $65–80k short, 43–53% under your floor. Equity can't close a base-salary gap that size. `[grounded]`
  - **Location:** on-site in Austin five days a week, "no exceptions," against your remote-only constraint. The posting says this in its own words, so no reframing changes it. `[grounded]`
- **Fit ledger (candidate side):** Strong on paid, lifecycle, experimentation, the SQL/GA4/Braze stack, team leadership, and the $8M→$40M ARR scale-up. Unknown on SEO/content, brand, PR, partnerships, and sales ops, which the posting makes core. Fit is strong on the parts you've done, and the two hard gates sit outside fit altogether.
- **Opportunity side:** Scope is very wide for a "team of one to start," and the posting says evenings and weekends are expected. It also says success metrics will change. Those are risk signals, not disqualifiers on their own.

**Role reality**

- Head of Growth, reporting to the CEO with a dotted line to the board. Owns all revenue growth, including six functions that usually need separate people.
- The posting asks for a solo operator ("we believe in players who don't need a bench"). You have built and managed teams of 3–7. That is a preference mismatch, not a capability gap.
- Compensation is stated, so it is calibrated against the posting's own figure. I could not check it against a market band (see the evidence status below). `[grounded]` for the figure; the market comparison is not established.

**Evidence map (condensed)**

| # | Requirement | Priority | Fit | Gap | Confidence |
|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | must | meets | none | medium (self-stated) |
| 2 | Paid acquisition | must | meets | none | medium |
| 3 | Lifecycle / CRM | must | meets | none | medium |
| 4 | Experimentation, SQL, GA4, Braze | preferred | meets | none | medium |
| 5 | SEO / content | must | unknown | discovery | — |
| 6 | Brand, PR | must | unknown | discovery | — |
| 7 | Partnerships | must | unknown | discovery | — |
| 8 | Sales ops | must | unknown | discovery | — |
| 9 | Solo build, no team | must | partial | transferability | medium |
| 10 | Thrive on ambiguity | must | partial | transferability | low |
| 11 | Base ≥ $150k | hard gate | fails | hard-gate | — |
| 12 | Remote-only | hard gate | fails | hard-gate | — |

**Gap recovery queue**

- Rows 5–8: closable only if you owned any of those functions. Your CV doesn't say, so these stay unknown.
- Rows 11–12: not closable by wording. No positioning or framing changes them.

**Opportunity risk register**

- **Pay vs floor** (`hard_gate`, high): the gap in the snapshot above.
- **On-site vs remote** (`hard_gate`, high): fixed by the posting.
- **Scope vs headcount** (medium): all of growth for one person, with no team.
- **Hours** (medium): "evenings and weekends" is stated as the norm.
- **Shifting success metrics** (medium): no stable target to be measured against.
- **Unverified employer** (medium, standing entry): I could not confirm that Novaline exists as described. Reasons to keep in view, none ranked as likely: too new or small, a stale posting, or a listing that isn't from a hiring employer. This caps any `go` at `conditional_go` until it's checked. It is not a finding against the employer.
- **Pattern** (generic): a Head-level role that combines all-of-growth scope for one person, pay around half your floor, equity as the offset, and on-site "no exceptions" is a combination often seen in roles that are underpriced or mis-scoped. `[generic]`, a pattern and not a claim about this employer.

**Application plan**

None proposed. The two hard gates would need to change before any CV work makes sense. If they do, tell me the new terms and I'll rerun this.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2. Both searches were refused by a permission prompt, so they count toward the budget and returned nothing.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search permission denied; Novaline's existence is unverified |
| 2 | Role-family sweep (scope, title, comp) | unavailable | Search permission denied; no market band |
| 3 | Hiring manager footprint | n/a | No name given |

**Offer:** If you want, I can write up a dossier (`tuesday-dossier.md`) from this assessment, so it carries into later rounds.

**Upgrade menu**

- **Link to the live posting or Novaline's careers page**, or the recruiter's email domain. This would resolve the unverified-employer entry.
- **Your CV or a list of functions you've owned**, for rows 5–8.
- **Search permission**, so I can check the market band for Head of Growth at this stage and confirm the company exists.

**Questions**

1. Did you own SEO/content, brand, PR, partnerships, or sales ops in either role? (This moves rows 5–8 but doesn't change the hard gates.)
2. How did this reach you: a recruiter, a referral, or the careers page? (This is the attribution check.)

Reply to either, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.