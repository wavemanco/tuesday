**Decision: conditional_go.** Apply. Your core experience matches this role closely. Two things to settle before you invest heavily: the pay range, and whether the job includes managing people.

**Fit ledger** (stated background, not yet checked against documents)

| Requirement | Priority | Fit | Evidence |
|---|---|---|---|
| 4+ years pricing or actuarial analytics | Must-have | Strong | 5 years, last 2 as senior analyst |
| Strong SQL and Python | Must-have | Strong | Daily use |
| GLM experience | Must-have | Strong | Built and maintained the young-driver rating model |
| Presenting to underwriting or actuarial leads | Must-have | Strong | Quarterly pricing review to the head of underwriting |
| Design and read price tests | Implied by "own pricing analytics" | Strong | 14 tests last year with underwriting |
| Build and monitor rating models | Implied by the JD | Strong | Maintained a live model |
| Insurance experience | Plus | Strong | UK motor insurer |
| Pet-insurance product knowledge | Implied by "our pet-insurance product" | Partial, transferable | No pet experience. Pet pricing has different drivers, such as species, breed, and vet-cost inflation, and different cover structures. [generic] |
| People management | Not stated in the JD | Unknown | You've never managed anyone. Whether this role includes it is open. |

**Hard gates:** none failed on what you've told me. Two are unconfirmed: your eligibility to work remotely in the UK, and whether the pay meets your floor. The JD gives no pay.

**Role reality**
- The JD is specific and internally consistent: scope, requirements, and the reporting line to Odile Varga, Director of Pricing, are all named.
- The scope is ownership of a rating function, not an analyst seat. That fits your senior-analyst history.
- Unknowns: company stage, funding, and whether the posting is live. I haven't checked any of these (see the evidence status below).
- Market calibration: not run. No pay band has been checked.

**Gap recovery queue**
- **Pet-insurance domain.** Type: transferability. Closes with: one example of you applying motor pricing logic to a different risk pool, or a pet-specific reading you've done. Your motor experience carries most of the weight.
- **People management.** Type: unknown. Closes with: the JD's own answer, or a recruiter's answer. It's not a gap until the role says it is.

**Opportunity risk register**
- **Pay not stated.** Class: mismatch risk, `severity: medium`. The JD withholds pay, so you can't yet tell whether it meets your floor.
- **Company not verified.** Class: failed attribution, `severity: medium`. I haven't confirmed the company exists as described: stage, size, and whether it is hiring. This caps a `go` at `conditional_go` until checked.
- **No red flags in the JD text.** It asks for no payment, no bank details, and no hiring by chat.

**Application plan (as far as the evidence allows)**
- Lead with the GLM build and maintenance, the 14 price tests, and the quarterly review to underwriting. These are your verified-by-you strengths and map directly to the must-haves.
- Address pet insurance head-on as a transfer, not a claim of experience. Don't write "pet insurance experience" anywhere.
- Don't claim management experience. If the role includes it, say it's a development area and show the leadership you do have, such as mentoring or leading the quarterly review.
- Nothing here is ready for external use. Any CV or outreach wording needs your approval first.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | No search run; research was not requested. |
| 2 | Role-family sweep (pay, scope) | skipped | No search run. |
| 3 | Hiring manager's public footprint | skipped | No search run; no research consent given. |

The company and pay checks above are the first research I'd run if you want them. I've kept this to L0 because the JD and your background were enough for a fit read.

**Dossier:** I can write a `tuesday-dossier.md` with this assessment if you want it saved for later use.

**Upgrade menu**
- **L1 research** (up to 5 searches and 2 page fetches): checks the company's existence and posting, and the pay band for this seniority.
- **Live posting link**: confirms whether the role is still open and whether pay is listed there.
- **Your pay floor**: lets me check the gate.

**Questions**
1. Does the role involve managing people, even informally?
2. What's your pay floor, and do you know the range? The JD doesn't state pay.
3. Do you have a link to the live posting, or the recruiter's email domain? This lets me confirm the company exists as described.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.