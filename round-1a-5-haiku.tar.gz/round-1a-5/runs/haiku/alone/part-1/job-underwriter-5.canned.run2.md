**Short answer: probably yes, but hold until one thing is confirmed.** Your stack lines up with almost every requirement. The open item is the location gate: the role is US-remote or Denver, and I don't have your location or work status.

**Decision snapshot**

**Status: `hold_pending_answers`.** The fit is strong, the posting is sound, and one hard gate is unchecked. If the gate clears, this moves to `conditional_go`.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver office)
- `must_have` — direct: R2, R3, R4a, R4b, R5, R6
- `important` — adjacent: R7 (BigQuery, the named warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts rely on)

R7 is the bridge: Snowflake dbt carries over, BigQuery itself is new. R8 and R9 are pipeline responsibilities your background doesn't yet show.

**Opportunity ledger.** Sound and fairly transparent. The salary and stack are stated, and the pay sits inside the market band (RR1). The equity is unpriced (RR2), the team is unnamed (RR4), and the employer is corroborated only by its own pages (RR5). No red flags.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** awaiting your US location and work status (R1). If R1 clears, `conditional_go`, with R8 and R9 tested in the first screen and RR3 answered. If R1 fails, `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company about page, fetched |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and analyst-facing data contracts | `[grounded]` posting, fetched |
| First-year outcomes | None stated | — |
| Working pattern | Remote US or Denver office | `[grounded]` posting |
| Scope read | Ownership across ingestion through contracts; could be one domain or wider, the posting doesn't say | `[inferred]` from "build and run" across three areas |
| Market calibration | Senior data engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years; scope usually one domain's pipelines, no direct reports. The posting's $148,000–$166,000 sits within the IQR | `[generic]` Datawright 2026 report, n=2,310, supplied by your recruiter (not re-searched); `[grounded]` posted range |
| Unknowns | Location and work status fit, equity terms, team size, hiring manager, first-year outcomes | — |
| Contradictions | None; the careers page matches the pasted posting | `[grounded]` fetched page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | low | hard_gate | Your location and US work status aren't given, so the gate can't be checked | `[grounded]` posting | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated, not inspected | `[grounded]` stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; no code sample to inspect | `[grounded]` stated background | a code sample would raise to high |
| R4a | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models | `[grounded]` stated background | E1 |
| R4b | A cloud warehouse | must_have | direct | medium | none | Snowflake | `[grounded]` stated background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` stated background | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | `[grounded]` stated background | none |
| R7 | BigQuery (the named warehouse) | important | adjacent | medium | transferability | Snowflake dbt modelling carries over; you have not used BigQuery | `[generic]` dbt and SQL portability across warehouses | G3 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Your background doesn't mention source-system ingestion | `[grounded]` posting; silence in your background | G1 |
| R9 | Data contracts analysts rely on | important | unclear | low | discovery | No mention of contracts or consumer agreements | `[grounded]` posting; silence in your background | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Background covers data engineering but not source ingestion | Named in the first responsibility | Pulling from a CRM's API or an app database; retries, backfills, incremental loads | A pipeline sketch or repo excerpt | `[grounded]` posting; `[inferred]` that it moves the status |
| G2 | Data contracts (R9, important) | discovery | No mention of schema agreements with consumers | Named as what analysts depend on | Agreed schemas, versioned models, breaking-change process, dbt model contracts or schema tests | A contract doc or schema test | `[grounded]` posting |
| G3 | BigQuery (R7, important) | transferability | Snowflake dbt work; no BigQuery | The posting names the warehouse | Snowflake-to-BigQuery differences you've reasoned through; a sandbox dbt model. **Limit:** no BigQuery production use, partitioning or cost work. **Strengthener:** a small BigQuery sandbox dbt project | A sandbox project or short write-up | `[generic]` that dbt modelling ports across warehouses |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated, within market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and near market; the open question is where in the range this lands | `[grounded]` posting; `[generic]` band | "Where in the $148,000–$166,000 range is this hire expected to land, and how is that set?" | noted |
| RR2 | Equity unpriced | unknown | — | "plus equity" | The equity could be a large or small part of total pay; grant size, vesting and strike set its value | `[inferred]` from the posting's silence on terms | "What equity grant does this role carry, what is its vesting schedule, and what is the latest strike price?" | unresolved |
| RR3 | BigQuery required; your warehouse is Snowflake | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | BigQuery specifics (partitioning, cost, access controls) may take a quarter to ramp; dbt and warehouse requirements are met on Snowflake | `[generic]` cross-warehouse pattern | "Which BigQuery practices does this role need in the first 90 days, and what ramp do you expect from Snowflake?" | unresolved |
| RR4 | No hiring manager, team size or reporting line | unknown | — | (posting silent) | Ownership may be wider or narrower than the one-domain pattern | `[inferred]` from silence; `[generic]` pattern | "Who would this role report to, and how many engineers own the pipelines alongside it?" | unresolved |
| RR5 | Employer corroborated only by its own pages | unknown | — | "Series C ($52M, February 2026)" | Funding and stage rest on the company's own page; a third-party source would confirm them. Not a standing entry: the posting is live on the company's careers page and matches your paste | `[generic]` private-company pattern; `[grounded]` one search, no results | "Which investors led the February 2026 Series C, and where was the round announced?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your US location and work status before investing in the loop | The gate decides the hold (R1) | `[grounded]` posting | pending your approval |
| E1 | Summary line: lead with the dbt build (about 180 models on Snowflake), Airflow orchestration and the Great Expectations suite | Maps to R4a, R5, R6 | `[grounded]` CV | `resume_edits_pending_approval`. Reframing audit: moves existing claims up; adds none |
| W1 | BigQuery bridge: "I've built dbt on Snowflake and haven't run BigQuery in production. The modelling ports; I'd ramp on BigQuery's partitioning and cost controls." | Names the limit (R7, RR3) | `[generic]` portability; `[grounded]` the no-BigQuery fact | `resume_edits_pending_approval`. Use only the ramp clause if you'd stand behind it |
| Q1 | Put RR2, RR4 and RR5 to the recruiter screen verbatim | The register doubles as screen prep | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results); fetched pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about. Both match your paste: posting live, company facts as stated. No third-party page found, so funding stays on the company's own page (RR5) |
| 2. Role-family sweep | skipped | Your recruiter's Datawright 2026 report already fixes the band used in the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name given |

**Upgrade menu**

- A BigQuery sandbox dbt model, or a short Snowflake-to-BigQuery write-up → R7 moves from `adjacent` toward `direct`; RR3 narrows.
- A CRM or app-database ingestion sketch or repo excerpt → R8 moves from `unclear` toward `adjacent` or `direct`.
- A data-contract document or schema test → R9 moves likewise.
- The recruiter's answer on location and team → R1 closes, and the decision moves to `conditional_go` or `no_go`.
- Equity figures → RR2 closes.
- Deeper research on Pellucid: funding confirmation, leadership changes, public employee reports; up to 5 more searches and 2 more fetches. This is offered once, and I'll run it on your word.

If you want, I can write this up as a `tuesday-dossier.md` to take into the loop.

1. **Gate (R1):** Are you based in the US, and are you authorized to work there without sponsorship?
2. **G1:** Have you built ingestion from an application database or a CRM's API, and how did you handle retries and backfills?
3. **G3:** Have you run anything in BigQuery, even a sandbox project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.