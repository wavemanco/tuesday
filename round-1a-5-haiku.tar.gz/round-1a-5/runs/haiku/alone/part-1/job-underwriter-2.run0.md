**Decision: conditional_go.** You're not wasting your time, but the "3+ years PM" must-have will screen you out unless you frame your real experience accurately and show evidence of the product work.

**Research tier: L1, but the first search was refused, so no outside facts were checked.** The count is searches 1 of 5, fetches 0 of 2. Everything about Quartzline below is from the JD alone, so the company is not verified.

### Fit ledger (CV only, so these are leads until you confirm them)

| Requirement | Priority | Fit | Confidence | Gap type |
|---|---|---|---|---|
| 3+ years PM experience | must-have | gap | low | transferability |
| Shipped API or platform products | must-have | partial | medium | capability |
| Technical fluency (API docs, schemas) | must-have | strong | high | none |
| Stakeholder management across eng, sales, customers | must-have | strong | high | none |
| Agile delivery | must-have | unknown | low | discovery |
| Run discovery with integration partners | core | strong | medium | presentation |
| Write specs, drive delivery with engineering squads | core | strong | medium | presentation |
| Define and track adoption metrics | core | gap | low | capability |
| Coordinate launches with sales and support | core | partial | medium | presentation |

**Hard gates:** None stated in the JD. Your non-negotiables (pay, location, authorization, schedule) weren't provided, so they are unknown and unchecked.

### Reading the requirements honestly

- **The 3-year bar is not a hard gate.** A hard gate is a condition like authorization, location, or pay, not years of experience. It's a must-have that a recruiter can filter on. Your roadmap-input sessions and requirements documents are real product-adjacent work. Claim them as what they were: you gathered client feedback for product and wrote the specs for custom builds. Don't claim you owned a roadmap unless you did.
- **Your strongest evidence is on the consumer side of the API.** You have led 30+ integrations of the company's REST APIs. The JD asks for someone who owns the platform's direction. Your biggest gap is ownership: prioritization decisions, versioning, adoption measurement.
- **[generic] Market calibration:** Series B platform PM roles usually expect 3+ years of PM work. Candidates who come from implementation or solutions engineering are more often hired into technical PM, partner PM, or integrations PM roles.

### Your memory lead (not evidence)

An earlier note says you built an internal request-triage tool that support agents adopted. **This is unconfirmed and I have not counted it.** If it's real, it is your best evidence for shipped product work and for adoption. Confirm it before using it anywhere.

### Opportunity ledger

- No red flags in the JD. No pay range, location, or remote policy is stated, so those are unknowns.
- Company existence, stage, and whether the posting is live are unverified because research was refused. Until they are checked, this stays a conditional go.

### Application plan (proposed, pending your approval)

- **Resume edits, proposed as `resume_edits_pending_approval`:** Change "led integrations" to "led 30+ client integrations; gathered quarterly client feedback that fed the product roadmap; wrote the team's integration playbook." Don't write "product manager" or "owned roadmap."
- **Positioning:** Lead with the partner-discovery and spec work, and name the platform you know best. Have one written example of a spec you wrote and what changed because of it.
- **Target:** Apply to this role if the posting checks out, and also to technical PM, partner PM, and integrations PM roles, which screen less hard on the 3-year bar.
- **Gap to close:** Adoption metrics are your weakest core requirement. Before interviews, be ready with one metric you influenced and how you measured it.

### Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search permission was refused. |
| 2 | Role-family sweep (scope, title, pay) | skipped | Blocked by the same refusal. |
| 3 | Hiring manager's public footprint | n/a | No name given. |

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` so the next session can pick it up.

**Upgrade menu** (what each missing input would unlock):
- **Live posting link or Quartzline's careers page:** verifies the company and the role, and checks the pay and location.
- **Triage tool details (what it was, who used it, any adoption numbers):** could move shipped-product evidence from unknown to medium or high, if confirmed.
- **Any metric you've tracked:** closes the adoption-metrics gap.
- **Your hard constraints (pay floor, location, work authorization):** lets the hard-gate check run.
- **Search permission for research:** lets me check the company and the market pay range.

**Questions** (answer any or none; reply "skip" to any of them):
1. **Triage tool (memory lead):** Did you build this, and did support agents actually adopt it? How did you know, and what did you measure?
2. **Metrics:** Have you ever tracked adoption, usage, or time-to-integrate for an integration or a product? If so, what were the numbers?
3. **Constraints:** What are your minimums for pay, location or remote, and work authorization?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.