## Decision snapshot

**Worth applying to. Status: `go`.**

**Fit ledger.**

- `hard_gate`: unconfirmed: R1 (Location: remote US or Denver)
- `must_have`: direct: R2, R3, R4, R5, R6 · adjacent: R7 (BigQuery) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts)
- `important`: none stated separately

The core requirements match your background. The one clear gap is BigQuery, which is a platform you can learn on top of dbt and SQL skills you already have. Ingestion and data contracts are in the JD but not in your background, so they're unknowns, not gaps yet.

**Opportunity ledger.** Sound. The salary sits inside the role-family band, the company checks out, and the posting is live and consistent with the JD. The open items are equity value and team shape.

- **Hard gates:** none failed; unconfirmed: R1 (location). Checks against your salary floor are unknown because no floor was given.
- **Severe red flags:** none found.
- **What would change this:** a location outside remote-US and Denver, a salary floor above $166,000, or ingestion and contract ownership that turns out to be absent from your work. Any of these moves it to `hold_pending_answers` or `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page, fetched |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, careers page fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 base plus equity (equity amount not stated) | `[grounded]` JD |
| Scope read | One domain (reporting) with ownership of pipelines and contracts. Normal for the title, though the contract ownership reaches into analysts' work | `[inferred]` from the JD's named responsibilities against the typical single-domain scope |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted range midpoint (about $157,000) sits inside the IQR | `[generic]` Datawright 2026 pay report, plus `[grounded]` JD |
| Unknowns | Equity value and vesting; team size; who sets contract standards; hiring manager | — |
| Contradictions | None. The JD and careers page match, and the company page matches both | `[grounded]` three sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver | hard_gate | unclear | low | hard_gate | Your location wasn't given, so the check can't run | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated but not documented | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your statement | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your statement | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your statement | none |
| R7 | BigQuery as the warehouse | must_have | adjacent | high | transferability | Never used BigQuery. Snowflake and dbt transfer, but BigQuery-specific features and cost model don't | `[grounded]` your statement; `[inferred]` transferability | G1 |
| R8 | Ingestion from app and CRM | must_have | unclear | low | discovery | Not in your background. May be covered by your payroll work, but not stated | `[grounded]` JD; CV silent | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` JD; CV silent | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt in production; no BigQuery | The JD names BigQuery, so it's a likely interview probe | Any BigQuery exposure: a sandbox, a course, a dbt-bigquery adapter, a migration you scoped | A short write-up or repo | `[inferred]` transferability |
| G2 | Ingestion from app and CRM (R8) | discovery | Not in your background | A named responsibility of the role | Source-system ingestion, CDC, or CRM syncs at your payroll company | A pipeline description | `[grounded]` JD |
| G3 | Data contracts (R9) | discovery | Not in your background | Named responsibility; analysts rely on it | Schema agreements or data quality SLAs with downstream consumers | A contract or SLA example | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary inside the role-family band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Compensation is market-normal for the title | `[grounded]` JD against `[generic]` band | — | noted |
| RR2 | Equity value and vesting unstated | unknown | — | "plus equity" | Equity may be a meaningful part of pay, or nominal | `[inferred]` from the posting's silence | What is the equity grant, vesting schedule, and current valuation? | unresolved |
| RR3 | Contract ownership reaches into analysts' work | unknown | — | "the data contracts our analysts depend on" | Ownership may be solo, or shared with analytics | `[inferred]` from the JD's scope | Who sets the data contract standards, and is this role the sole owner? | unresolved |
| RR4 | No hiring manager named | unknown | — | (absent) | Common at growing companies; not a red flag on its own | `[generic]` pattern | Who is the hiring manager? | unresolved |
| RR5 | Company checks out | positive_signal | — | "Series C ($52M, February 2026)" | Stable, funded, sized as described | `[grounded]` about page; posting live on careers page | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the ~180-model dbt project on Snowflake, stated as built and run in production | Maps directly to R4 | `[grounded]` your statement | pending your approval |
| A2 | State BigQuery plainly as a platform you'd ramp on, with the Snowflake and dbt work as the transferable base. Do not claim BigQuery experience | R7; avoids an inflated claim | `[grounded]` R7 | pending your approval |
| A3 | Ask in the first screen: who owns ingestion, and who sets the contract standards | RR3; G2, G3 | `[grounded]` RR3 | pending your approval |
| A4 | Ask about equity grant size and vesting before accepting any offer | RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your statement, not a document.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" tutoring company" (returned the about page). Fetched pellucidlearning.com/careers/senior-data-engineer (live, matches the JD) and pellucidlearning.com/about (matches the company description). Moved: company exists as described, posting is live, no failed attribution |
| 2. Role-family sweep | yes | Searched "senior data engineer base salary median 2026 Series B D company", which returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report). Moved: market calibration for RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your location and salary floor → R1 closes; the decision becomes final against your constraints.
- A BigQuery sandbox or course → R7 moves from `adjacent` toward `direct`.
- A description of your ingestion or contract work → R8 and R9 move from `unclear`.
- The equity grant and vesting schedule → RR2 closes.
- The hiring manager's name → the application plan can lead with the story that fits that reader.
- A deeper company pass (funding history, leadership changes, employee reports; up to 5 more searches and 2 more fetches): say the word and it runs.

I can also write this up as a `tuesday-dossier.md` file if you want to keep it.

**Questions:**

1. **Q1 (R1, constraints):** Where are you based, and is $148,000 your floor? Answer in prose, or say skip to leave either open.
2. **Q2 (R8, R9):** Have you owned source-system ingestion or data contracts with downstream consumers, even in part?
3. **Q3 (R7):** Have you touched BigQuery at all, even in a sandbox or course?

Reply in prose to any question, or say "skip" to leave it open.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.