## Decision snapshot

**Worth applying to, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (US-remote or Denver location), R10 (pay floor against $148,000–$166,000)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery), R9 (data contracts) · unclear: R8 (CRM and app ingestion)
- `preferred`: none listed

**Opportunity ledger.** Sound. The stated stack and responsibilities are explicit, the posting is live and matches the careers page, and the salary sits near the market median. Open items are the hiring manager, the equity amount, and who owns pipeline on-call. No red flags.

- **Hard gates:** none failed; unconfirmed: R1 (unclear), R10 (unclear). Your location, authorization and pay floor weren't in what you sent, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm R1 and R10 against your own constraints; (2) frame the BigQuery gap as Snowflake production experience plus no BigQuery use yet (R5); (3) confirm CRM ingestion and data-contract work (R8, R9) in the first conversation.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016; Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` pellucidlearning.com/about (search result text, page not fetched) |
| Mandate | Build and run pipelines for tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD and careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three pipeline domains in one post. Ordinary for the title if one team owns them all; unconfirmed | `[inferred]` from the three named domains against the silence on team size |
| Market calibration | Base median $151,000, IQR $139,000–$163,500 for Senior at Series B–D companies. The posted range sits around that median and mostly inside the IQR. Senior typically means 5–8 years, with ownership of one domain's pipelines and no direct reports | `[generic]` Datawright 2026 report (datawright.example/2026-data-engineering-pay-report, search result text); `[grounded]` JD for the posted range |
| Unknowns | Hiring manager; team size; equity amount; on-call for "run"; whether the CRM sits in the same ingestion stack | — |
| Contradictions | None. The careers page matches the JD | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US-remote or Denver location and work authorization | hard_gate | unclear | none | hard_gate | The JD offers remote US or Denver. Your location and authorization weren't given, so nothing to check | — | Q1 |
| R2 | 5+ years data engineering | must_have | direct | high | none | Six years at a B2B payroll company | `[grounded]` your CV, not yet inspected: a lead | none |
| R3 | Strong SQL and Python | must_have | direct | high | none | Both used daily | `[grounded]` your CV | none |
| R4 | dbt and a cloud warehouse | must_have | direct | high | none | dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse | `[grounded]` your CV | none |
| R5 | BigQuery warehouse (named in the JD's responsibilities) | important | adjacent | low | transferability | Same dbt and warehouse discipline carries over. No BigQuery use claimed | `[inferred]` from R4 | Q2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | high | none | Airflow set up for orchestration | `[grounded]` your CV | none |
| R7 | Data quality testing | must_have | direct | high | none | Set up the Great Expectations suite | `[grounded]` your CV | none |
| R8 | Ingestion from the app and CRM (implied by the responsibilities) | important | unclear | low | discovery | CRM ingestion isn't in your CV | — | Q3 |
| R9 | Data contracts analysts depend on (implied) | important | adjacent | low | discovery | Quality testing is close, but contracts aren't claimed | `[inferred]` from R7 | Q3 |
| R10 | Pay against $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor was given | `[grounded]` JD | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5) | transferability | Snowflake and dbt, no BigQuery | Named in the JD's responsibilities; the most likely technical question | Any BigQuery or GCP work, including a sandbox or side project | A small dbt project on BigQuery | `[inferred]` from R4; `[generic]` that this is a likely probe |
| G2 | CRM ingestion (R8) | discovery | Ingestion work in the CV, no CRM named | Explicit responsibility | Any CRM or SaaS-API ingestion | A pipeline description | `[inferred]` |
| G3 | Data contracts (R9) | discovery | Quality testing, no contracts named | Analysts depend on them | Schema agreements or ownership with analysts, even unnamed | A contract or SLA example | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary posted | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is competitive for the title | `[grounded]` JD; `[generic]` band | — | noted |
| RR2 | Stack and responsibilities explicit; live posting matches careers page | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Scope is defined and the posting is current | `[grounded]` careers page | — | noted |
| RR3 | Hiring manager not named | unknown | — | (absent) | Unknown reporting line | `[grounded]` JD silence | Who is the hiring manager, and who owns this team? | unresolved |
| RR4 | Equity amount unstated | unknown | — | "plus equity" | Equity is a grant, not a stated figure | `[grounded]` JD | What is the equity grant, and what is its vesting? | unresolved |
| RR5 | Ownership of three domains; team size unstated | unknown | — | "ingestion ... warehouse ... data contracts" | One team may carry all three, or the post may be one domain of a larger team | `[inferred]` from the three named domains | Does one team own ingestion, warehouse and contracts? Who is on-call for the pipelines? | unresolved |

No standing "employer not established" entry: the official site and careers page both resolve, so the entry isn't raised.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter who the hiring manager is, and whether one team owns ingestion, warehouse and contracts | see RR3, RR5 | `[grounded]` register | pending your approval |
| A2 | Learn enough BigQuery basics to answer the G1 question honestly before the first technical round | see G1 | `[inferred]` | advice |
| E1 | Resume: state the Snowflake dbt project and Great Expectations work with what you actually did. Don't describe BigQuery experience | see R4, R5, R7; no inflated wording | `[grounded]` CV | pending your approval |
| Q1 | Ask the verification questions of RR3, RR4 and RR5 in the first interview | The register doubles as interview preparation | `[grounded]` register | advice |

## Evidence status

Verified: none yet. The CV claims are leads until you show an inspectable artifact.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning senior data engineer careers"; fetched pellucidlearning.com/careers/senior-data-engineer (page live, matches the JD). The About page (pellucidlearning.com/about) came up in search text, not a fetch. Moved: the entity resolves to its own domain; no contradictions |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B-D US 2026 pay report"; the result was the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report), read from search text. Moved: market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

L2 has not run. It is available on request: deeper company diligence (funding, leadership churn, hiring patterns) and a recent-news sweep.

**Dossier offer:** If you want to keep this analysis, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R10 close, and the hard-gate line clears.
- A BigQuery sandbox or project artifact → R5 rises from `low` toward `medium`.
- A CRM ingestion or data-contract example → R8 and R9 rise from `low`.
- The hiring manager's name → RR3 closes, and the application can be positioned for that reader.
- L2 deeper diligence on Pellucid (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → available on your word.

**Questions** (answer in text, or say skip; a skip is an answer):

1. **R1 and R10:** Are you able to work remotely from the US, or from Denver, and what is your base-pay floor?
2. **G1 (R5):** Have you used BigQuery or any GCP tooling at all, even in a sandbox or side project?
3. **G2 and G3 (R8, R9):** Have you built ingestion from a CRM, or defined data contracts with analysts, even if you didn't call them that?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.