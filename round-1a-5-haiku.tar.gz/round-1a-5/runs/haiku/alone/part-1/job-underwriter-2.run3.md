**Decision snapshot**

**Decision: `conditional_go`.** Apply, with honest framing and one direct question to the recruiter about the years requirement. You are not wasting your time, but the 3+ years PM requirement is a real gap and will likely be the first screen.

- **Fit ledger, by priority**
  - *Must-have:* 3+ years PM is a **gap**. Shipped API or platform products is **partial**.
  - *Required:* Technical fluency is **strong**. Stakeholder management is **strong**. Discovery with partners is **partial**. Agile delivery is **unknown**.
  - *Implied:* Roadmap ownership is a **gap**. Spec writing and delivery drive is **partial**. Launch coordination with sales and support is **partial**. Adoption metrics are **unknown**.
- **Hard gates:** None are stated in the JD. Your own constraints (pay, location, authorization, schedule) were not provided, so they are **unknown and not checked**.
- **Is the 3+ years a hard gate?** Not in this assessment's sense. Hard gates are terms like authorization, location, pay, and schedule, not years of experience. So it is a must-have gap you can address, not a bar that wording cannot solve. You cannot claim around it, though: you have no PM title, and you should not present integration work as PM years.

**Role reality** `[grounded]` (from the JD only)
- Product Manager, Platform APIs, Quartzline. B2B logistics tech, about 150 people, Series B.
- Owns the partner-facing API roadmap, runs discovery with integration partners, writes specs, drives two engineering squads, defines adoption metrics, and coordinates launches.
- Scope read: a legitimate platform PM role. The work is close to what you have done from the implementation side, but with ownership you have not held.
- Compensation is not stated, so there is nothing to calibrate. Market band: not checked `[generic]` (no research run).

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ years PM | gap | high | transferability | No PM title or years. Adjacent: roadmap-input sessions, requirements documents. |
| 2 | Must-have | Shipped API or platform products | partial | medium | presentation | 30+ REST API integrations taken to go-live. You did not own the product. |
| 3 | Required | Technical fluency (API docs, schemas) | strong | medium | — | Postman, SQL, OpenAPI. CV-only, so a lead until shown. |
| 4 | Required | Stakeholder management (eng, sales, customers) | strong | medium | — | Coordinated vendor engineers, client engineers, and PMs. Sales not stated. |
| 5 | Required | Agile delivery | unknown | low | discovery | Not stated on the CV. |
| 6 | Required | Discovery with integration partners | partial | medium | transferability | Scoping workshops and client feedback sessions, but for implementations, not a product roadmap. |
| 7 | Implied | Roadmap ownership | gap | high | capability | Gave input to product. Did not own the roadmap. |
| 8 | Implied | Specs and delivery drive with two squads | partial | medium | transferability | Requirements documents, UAT, go-live. No sprint or squad ownership stated. |
| 9 | Implied | Adoption metrics defined and tracked | unknown | low | discovery | SQL suggests the capability. No tracked metrics stated. |
| 10 | Implied | Launch coordination with sales and support | partial | medium | — | Go-live and UAT coordination. Wrote the playbook. Support and sales coordination not stated. |
| 11 | Hard gate | Constraints (pay, location, authorization, schedule) | hard_gate | unknown | — | Not provided, not checked. |

The triage tool from the earlier conversation is **not counted**. It is unconfirmed, so it is a question (below), not evidence.

**Gap recovery queue** (no questions here; the questions are in the closing block)
- Row 1, years: closes only with evidence of product-owning work, such as a PM rotation or a product-like project you can describe concretely. Otherwise this stays a screen risk.
- Row 2, shipped products: closes with a precise description of what you shipped and what you decided on each integration.
- Row 5, agile: closes with a yes or no and the tooling used.
- Row 9, metrics: closes with any usage, go-live timing, or support data you tracked.

**Opportunity risk register**
- **Employer existence not verified (`medium`, standing).** Quartzline was not searched. A link to the live posting or the company's careers page would resolve it.
- **Years mismatch (`medium`).** The recruiter screen is likely to filter on years. This is the main risk to the application.
- **Compensation not stated (`medium`).** Ask before investing time.
- **Red flags:** none observed in the JD text provided.

**Application plan**
- Do not claim PM years, a PM title, or roadmap ownership.
- Lead with the 30+ integrations taken to go-live, the discovery and requirements work, and the client feedback you fed into product.
- Proposed resume lines, **pending your approval** (drawn from your CV, nothing added):
  - "Led end-to-end delivery of 30+ client integrations of REST APIs, from scoping workshops and requirements through UAT and go-live."
  - "Ran quarterly client feedback sessions that fed product roadmap inputs."
  - "Wrote the integration playbook used across the team."
  - Avoid: "product manager," "owned the roadmap," "shipped the platform."
- Ask the recruiter directly whether strong integrations and discovery experience can substitute for the 3+ years PM requirement. A clear answer now saves time either way.
- Parallel targets: Technical PM, Integrations PM, or Solutions-to-PM roles with lower bars, and an internal PM rotation at your current vendor if one exists.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 run; the decision rests on the JD and CV. Employer existence remains open. |
| 2. Role-family sweep (scope, title, pay) | skipped | L0 run. Market band is not checked. |
| 3. Hiring manager footprint | n/a | No name given. |

User links read: none.

If you want, I can save this as `tuesday-dossier.md` so the next conversation starts from it.

**Upgrade menu** (what each input would change)
- A live posting link or the careers page: resolves the employer-existence risk.
- A research pass at L1: checks the company, the pay band, and the hiring manager's public background.
- Your constraints (pay floor, location, authorization, schedule): runs the hard-gate checks.
- A work sample, such as an anonymized integration spec or the playbook (only with your approval before use): raises rows 2 and 3 from medium to high.
- A reference from a client-side PM or engineer: raises the shipped-products and stakeholder rows.

**Questions**

1. Did you build the request-triage tool that support agents adopted? If yes, how did you measure adoption, and what did you decide without asking anyone? (Closes row 7 if confirmed.)
2. Did you track any numbers on the integrations, such as time to go-live, support tickets, drop-off, or API usage? (Closes row 9.)
3. Did you work in sprints or own a backlog with the vendor's engineers? If so, which tools? (Closes row 5.)

You can answer any of these, or skip them; silence is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.