## Decision snapshot

**Decision: conditional_go.** Apply, but treat two of the posting's seven stated requirements as real gaps you will need to address directly.

**Candidate fit ledger** (scored on fit only)
- **Met, stated:** Salesforce admin certification; strong SQL and spreadsheet modelling (SQL weekly, Excel daily); 4+ years in sales or revenue operations, if B2B payments counts as B2B software (see the transferability note below).
- **Adjacent, partly met:** pipeline and renewal reporting; running the monthly pipeline review with a sales director.
- **Not met:** owning a forecast; working with finance on billing or revenue data.

**Hard gates:** Bristol, hybrid two days a week, is a location gate. Your location against it is unknown to me. Nothing else in the posting is a hard gate as written.

**Opportunity ledger** (scored on the role's merits): no red flags in the posting. Uncertainties are listed under Role reality.

**Why conditional rather than go:** the role's core scope is to own billing data and to run the quarterly revenue forecast with the CFO. Those are the two things you have not done. Your operational and tooling evidence is strong, so the case is credible, but it depends on how you frame the gap.

## Role reality

- **Title and scope** [grounded]: Revenue Operations Lead at Quillfield, an invoicing software company. Owns CRM and billing data; builds pipeline and renewal reporting used by sales and finance; runs the quarterly revenue forecast with the CFO.
- **Pay and place** [grounded]: £61,500–£67,000 plus share options; Bristol, hybrid, two days a week in the office.
- **Requirements** [grounded]: 4+ years in revenue, sales operations or a similar analytics role at a B2B software company; HubSpot or Salesforce administration; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data.
- **Scope read** [inferred]: the forecast and billing-data items suggest a role that sits between sales and finance, with more finance-facing accountability than a typical sales ops role. The posting does not say whether this is a new seat or a replacement.
- **Unknowns** [grounded in absence]: team size, reporting line, whether the forecast ownership is new to the business, and the hiring manager's background (the recruiter named Tamsin Achebe; I have not checked her public profile).
- **Market calibration:** not run. I have no market pay or scope benchmark for this title, so I cannot say whether £61.5k–£67k is in band.
- **Source check:** I read the posting on a third-party aggregator (Tallyboard). I have not confirmed it on Quillfield's own careers page.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | 4+ years RevOps/sales ops/analytics at B2B software company | Met, transferable | medium | transferability | 5 years sales ops at a B2B payments company; last 2 running UK RevOps. Payments is not software; expect the question. |
| 2 | must-have | HubSpot or Salesforce admin | Met | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards. Certification is stated, not verified. |
| 3 | must-have | Strong SQL and spreadsheet modelling | Met | medium | none | SQL weekly; Excel daily. Self-described; no sample to show. |
| 4 | must-have | Experience owning a forecast | Not met | low | capability | Finance owned the company forecast. Adjacent: monthly pipeline review with the sales director. |
| 5 | must-have | Experience working with finance on billing or revenue data | Not met | low | capability | No billing data experience. Adjacent: renewal reporting, if it touched revenue figures finance used. |
| 6 | core scope | Own CRM and billing data | Partly met | low | capability | CRM ownership is close to what you do. Billing data is not. |
| 7 | core scope | Build pipeline and renewal reporting for sales and finance | Met | medium | none | You rebuilt pipeline and renewal dashboards. Finance as a consumer is not evidenced. |

## Gap recovery queue

- **Gap 4 (forecast ownership):** what closes it: any record of you producing, reconciling or presenting forecast numbers, even as a contributor to finance. Pipeline-review work alone does not close it.
- **Gap 5 (billing data):** what closes it: any project where you reconciled bookings, invoices or renewals against recognised revenue, or worked from billing-system exports.
- **Gap 1 (payments vs software):** what closes it: a line on the SaaS-style metrics you tracked (ARR, churn, renewal rate), which map onto a software business.

## Opportunity risk register

- **Location (hard gate, severity high until answered):** Bristol two days a week. Unknown whether this works for you.
- **Pay (medium):** the posted range is stated. No floor was given, so no comparison has been made.
- **Source (medium):** the posting is on an aggregator. Confirm it on Quillfield's careers page before you invest time.
- **Scope (low):** the forecast and billing ownership is a larger remit than the title suggests. Ask about it in the interview.

## Application plan

1. Confirm the Bristol commute and your pay floor before applying.
2. Find the role on Quillfield's own careers page.
3. Lead with the Salesforce and reporting evidence (rows 2, 3, 7).
4. Describe the forecast and billing gaps as adjacent, with no claim of ownership. Example: "I run the pipeline review and my renewal reporting feeds revenue conversations; I have not owned a company forecast, and I would build that capability with finance."
5. Do not describe pipeline review as forecast ownership. That would overstate your record.

Proposed CV language is pending your approval; I have not drafted any text for an external audience.

## Research tier

Research tier: L0 — no searches; user links read 1

No research targets were declared at this tier, so there is no evidence-status table. An L1 pass would check whether Quillfield and the role exist as described, and would provide a market pay band for the title.

**Upgrade menu.** What each addition would unlock:
- **Live-posting and employer check (L1):** confirms the company exists and the role is live on its own site. Also resolves the aggregator-source concern.
- **Role-family market band (L1):** tells you whether £61.5k–£67k is in range for this seniority.
- **Hiring manager public footprint (L1):** shows which story will land best with Tamsin Achebe.
- **Your CV or a work sample** (for example, any forecast or billing-reconciliation artifact): would raise row 4 or 5 above low confidence.

**Tuesday dossier:** I can save this assessment as a `tuesday-dossier.md` file for later use, whenever you want it.

Questions (answer in prose, or say skip on any):
1. Can you work in Bristol two days a week, or is that a blocker?
2. What is your salary floor?
3. Have you contributed numbers to a forecast or reconciled revenue or billing data, even as an input to someone else's model?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.