**Decision snapshot: `conditional_go`**

The candidate fit is strong. The opportunity is unverified, and that caps the decision at conditional until it is checked.

| Priority | Fit | Requirements |
|---|---|---|
| Must-have | Met | 4+ years pricing analytics (5 years, last 2 senior) · GLM experience (built and maintained one) · strong SQL and Python (daily) · presenting to an underwriting lead (quarterly review to head of underwriting) · price tests (14 last year, with underwriting) |
| Preferred | Met | Insurance experience (UK motor) |
| Not in the JD | Unknown | Pet-insurance domain · people management (the JD says "own" but doesn't state line management) |

- **Hard gates:** Fully remote (UK). Your location and right to work in the UK were not given, so this is unknown, not passed.
- **Confidence:** Medium on every fit row. All evidence is your CV description, with no artifacts yet.

**Role reality**
- `[grounded]` Senior Pricing Analyst, Brindlemoor (insurtech), pet-insurance product. Owns rating-model build and monitoring, price-test design and reading, and recommendations to underwriting and product. Hiring manager: Odile Varga, Director of Pricing.
- `[grounded]` The posting gives no compensation.
- `[inferred]` This is an individual-contributor analytics role with a strong influence-on-decisions component. The "own" language reads as scope over the pricing analytics function, which could mean team leadership. The posting doesn't say.
- `[generic]` Motor and pet pricing share the core toolkit (GLMs, frequency-severity thinking, test design). Pet has different claims patterns, shorter policy terms and different customer dynamics. That is a learnable domain gap, not a skills gap.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | Met | Medium | None | 4+ years pricing/actuarial analytics | 5 years, UK motor insurer; senior analyst for last 2 |
| 2 | Must | Met | Medium | None | Strong SQL and Python | Daily use (your statement) |
| 3 | Must | Met | Medium | Transferability (small) | GLM experience | Built and maintained the young-driver GLM. Motor, not pet. |
| 4 | Must | Met | Medium | None | Presenting to underwriting or actuarial leads | Quarterly pricing review to head of underwriting |
| 5 | Must | Met | Medium | None | Designing and reading price tests | 14 tests last year with underwriting |
| 6 | Preferred | Met | Medium | None | Insurance experience | UK motor |
| 7 | Not stated | Gap | — | Capability/transferability | Pet-insurance domain | No pet experience (your statement) |
| 8 | Not stated | Unknown | — | — | People management | Never managed anyone. JD doesn't say whether this is a leadership role. |

**Gap recovery queue** (no questions here; they are in the closing block)
- **G1, pet domain (transferability):** Closes with any pet-adjacent exposure, such as pet-food or vet-related data, or a clear account of which motor pricing methods carry over. Ramp-up is the realistic path.
- **G2, people management (unknown):** Closes once the scope is confirmed. If the role has no reports, this is not a gap.

**Opportunity risk register**
- **Failed attribution, `medium`, standing (not verified):** I did not run research in this pass, so I can't confirm Brindlemoor exists as described (stage, size, product, live posting). The reasons are side by side and none is ranked as likely: too new or small, a stale posting, or not a real hiring employer. This caps the decision at `conditional_go` until verified. It would be resolved by the live posting link, the company's careers page, or the recruiter's email domain.
- **Compensation withheld, `low`:** Unstated, so I can't compare it to your floor. Worth asking.
- **Scope ambiguity, `low`:** "Own" versus line management, see G2.

**Application plan (as far as evidence allows)**
- Lead with the GLM you built and maintained, the 14 price tests, and the quarterly review to the head of underwriting. Those are the three things the JD asks for most directly.
- Present pet as a transferable domain you'd ramp into, not as experience. Don't write "pet-insurance experience" anywhere.
- No resume edits are proposed yet. Any wording for the CV or outreach would come to you for approval before use.

**Evidence status**
- Research tier: L0 — no searches
- Brindlemoor company check and the posting check: skipped, L0 run; available at L1.
- Hiring-manager footprint (Odile Varga): skipped, L0 run; available at L1 since you gave her name.
- Role-family sweep for pay and scope: skipped, L0 run; available at L1.

Your CV and the JD were the only sources. Everything beyond them is `[generic]` or `[inferred]`.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so it carries into later sessions.

**Upgrade menu**
- **L1 research (up to 5 searches, 2 fetches):** Confirms Brindlemoor exists, that the posting is live, and what pay is typical for this seniority. It also looks at Odile Varga's public professional background to shape positioning. This would clear or confirm the failed-attribution risk.
- **Pet-adjacent detail from you:** Any exposure to pet, vet, or companion-animal data would move G1 from transferability toward partial evidence.
- **The posting link:** Confirms the live status and lets me read the full text.

**Questions**
1. Are you based in the UK and eligible to work there?
2. Does this role manage people, or is it individual-contributor? The posting says "own" but doesn't say.
3. Where did you find the posting? A live link or the company's careers page would clear the main open risk.

Reply with answers, say "skip" to skip any question, or ask for the L1 research pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.