**Yes, worth applying, on conditions. Status: `conditional_go`.** Your must-haves match the posting well. Two things stand between you and a clean go: your location against the Remote (US) or Denver gate, and whether the employer is verifiable from independent sources.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (salary $148–166k against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R6 — Snowflake to BigQuery is a bridge, with its limit named; R9 and R10 — the posting's core responsibilities, and your background doesn't name them.

**Opportunity ledger.** The role is clearly scoped and the stated pay sits at market: RR2 is a positive signal. Against that, the employer has no independent footprint I could find (RR1, medium), and the hiring manager and equity terms are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (salary $148–166k against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're US-based or can work from Denver (R1); (2) the employer checks out through a hiring-manager name and a recruiter email domain that match its site (RR1); (3) your pay floor sits at or below $148k (R2).
- **What would change this:** if R1 is no, the status is `no_go` on the gate. If the employer can't be tied to a real hiring team, hold the application.

**Research tier: L1 — searches 1 of 5, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning K-12 live online tutoring Denver", no results. Fetched pellucidlearning.com/careers/senior-data-engineer (posting is live and matches the pasted JD) and pellucidlearning.com/about (matches the pasted company text). Moved the contradictions row (none) and the failed-attribution entry RR1 |
| 2. Role-family sweep | skipped | The Datawright figures are in hand as pasted (median $151k, IQR $139k–$163.5k), which fixes the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name given |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring in 31 states, founded 2016, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page, fetched |
| Mandate | Build and run the pipelines behind reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, live posting |
| Scope read | One domain's pipelines with defined consumers; no direct reports stated, which matches the usual remit for this title | `[generic]` role-family pattern; `[grounded]` JD silence on reports |
| Market calibration | Stated $148k–$166k sits at the median ($151k) and below the IQR top ($163.5k); midpoint $157k | `[generic]` Datawright 2026 report, 2,310 respondents, supplied by your recruiter, not independently checked |
| Unknowns | Hiring manager; equity value; location gate against yours; BigQuery depth expected | — |
| Contradictions | None between the JD and the live posting | `[grounded]` careers page fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No statement of your location in the material | `[grounded]` JD; your location not given | Q1 below |
| R2 | Salary $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | Your floor is not given | `[grounded]` JD | Q3 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact yet | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models, self-reported | `[grounded]` your intake | none |
| R6 | BigQuery warehouse (named in the JD's role description) | important | adjacent | medium | transferability | dbt and warehouse modelling carry over; BigQuery itself is untested for you | `[inferred]` from the JD and your Snowflake work | G2 below |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, self-reported | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your background doesn't say which sources you ingested | `[grounded]` absence in your intake | G1 below |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence in your intake | G1 below |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R9, R10) | discovery | Your intake covers warehouse, orchestration and testing, not sources or consumer agreements | Both sit in the posting's first sentence, so they carry the role | Pipelines pulling from a product database or a CRM; schema or SLA agreements with an analytics team; a breaking change you handled with consumers | A pipeline diagram, a contract doc, a README | `[grounded]` absence in intake; `[generic]` that this kind of role centres on these |
| G2 | BigQuery (R6) | transferability | Snowflake dbt work; no BigQuery | The posting names BigQuery specifically | Snowflake-to-other-warehouse moves; any GCP work | A short note on what differs in your Snowflake setup (cost model, partitioning) | `[inferred]` from the JD and your intake |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from independent sources | risk_signal | medium | "Pellucid Learning" | The posting is live on the company's own domain, but the search found no independent coverage. That may reflect a small or young company, or a stale posting | `[generic]` pattern for companies of this size, not a claim about this one | Who is the hiring manager, and which email domain does the recruiter write from? | unresolved |
| RR2 | Stated pay sits at or above the market median | positive_signal | — | "Salary $148,000–$166,000" | The range is competitive for the title | `[generic]` Datawright band | — | noted |
| RR3 | Hiring manager not named | unknown | — | (posting silent) | The reporting line is unclear | `[inferred]` from the posting | Who will I report to, and what does the team own today? | unresolved |
| RR4 | Equity value unstated | unknown | — | "plus equity" | Equity could be material or nominal | `[inferred]` from the posting | What is the grant size and vesting schedule? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location against the Remote (US) or Denver gate before investing in the application | R1 | `[grounded]` JD | awaiting your answer |
| A2 | Ask the recruiter for the hiring manager's name and the email domain, then check both against the company's own site | RR1, RR3 | `[generic]` pattern | pending your approval |
| A3 | Prepare the BigQuery bridge honestly: dbt on Snowflake, BigQuery not yet used | R6 | `[inferred]` | pending your approval |

**Questions**

Q1 (R1): Are you based in the US, and can you work from Denver if remote is not an option?

Q2 (G1, R9, R10): Have you owned data ingestion from an app or CRM, or defined data contracts with an analytics team? Describe what you built, who relied on it, and what broke. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (R2): What base pay would you need? Answer in text, or say skip.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Next steps.** I can turn this into a `tuesday-dossier.md` at the natural end of the engagement, if you want it.

**Upgrade menu.**

- A dbt project or test-suite artifact from Snowflake (sanitized) → R3, R5 and R8 move from `medium` to `high`.
- Any BigQuery or GCP work, even a side project → R6 closes or narrows.
- Your location confirmed → R1 closes, and the status either holds or moves to `no_go`.
- Your pay floor → R2 closes.
- The hiring manager's name and recruiter's email domain → RR1 and RR3 close.
- A deeper research pass on Pellucid (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and I'll run it, once.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.