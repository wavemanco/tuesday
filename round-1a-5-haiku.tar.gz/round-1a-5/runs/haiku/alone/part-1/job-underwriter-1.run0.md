**Yes, you fit the core of this role on paper. Apply, on conditions. Status: `conditional_go`.** Six of the nine requirements match your record directly. The healthcare gap is real, but the posting calls it a plus, not a gate.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5, R6
- `important` — adjacent: R7 (partner with clinicians); unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R7 — clinician work is the untested half (PM partnership is in your memo work); R9 — consent-state and PII work is a bridge, not healthcare experience.

**Opportunity ledger.** The JD is specific about the work but silent on team, decision rights, and whether patient data is in scope (RR1–RR3). One entry runs the other way: the scope is named concretely (RR4). Employer existence is unverified in this session (standing entry below).

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** conditions for go are (1) the posting is confirmed on Harborlight's own careers page or the recruiter's domain; (2) RR1 team and decision scope is concrete; (3) RR2 patient-data scope is one you can work in.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header (user-provided; not independently verified, see evidence status) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Broad for one analyst: strategy, experimentation, BI, and people management in one role | `[inferred]` from the responsibility count |
| Market calibration | Not calibrated. The salary search was refused; no band was checked, and model memory is not a source | — |
| Unknowns | Team size, decision rights, patient-data scope, clinician involvement, salary, location, contract type | — |
| Contradictions | None found in the JD as provided | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, consumer-subscription product analytics | `[grounded]` your CV, not yet verified | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a judgment resting on that | `[grounded]` your CV | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, one pricing test with an 11% retention lift. Attribution to that test needs checking | `[grounded]` your CV | an excerpt of the test readout would raise this |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards | `[grounded]` your CV | none |
| R5 | Strong written communication, non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo; presents to the VP Product | `[grounded]` your CV | a sanitized memo excerpt would raise this |
| R6 | Define and maintain the metrics layer | must_have | direct | medium | none | Governed dashboards imply metric definitions; ownership of the layer itself is not stated | `[inferred]` from dashboard governance | confirm you owned definitions, not only dashboards |
| R7 | Partner with PMs and clinicians | important | adjacent | medium | transferability | PM partnership in the memo work. No clinician work | `[inferred]` from the memo audience | gap G1 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not in your CV; no evidence either way | — | gap G2 |
| R9 | Healthcare data, HIPAA | preferred | adjacent | low | capability | No healthcare work. Consumer PII under GDPR/CCPA and the consent-state model are a bridge | `[inferred]` from your CV | gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7, important) | transferability | Stakeholder work with PMs and executives; none with clinicians | Clinicians are a named stakeholder group in the JD | Work with ops, customer care, or any domain experts | A sanitized example of translating analysis for a non-analyst domain expert | `[inferred]` |
| G2 | Mentoring (R8, important) | discovery | Silent in the CV | The JD names it as a responsibility | Any analysts you trained or reviewed | A line on mentoring or review practice | `[grounded]` CV silence |
| G3 | Healthcare and HIPAA (R9, preferred) | capability | No healthcare work | A plus, not a gate | Consent-state model, PII handling, access controls | A sanitized description of the consent model | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team size and decision rights unstated | unknown | — | "Own product analytics for our care-navigation app" | The role may be solo, or sit under a data team with shared metric ownership | `[inferred]` from scope language against silence on team | Who else owns the metrics layer and data engineering, and how many analysts report to this role? | unresolved |
| RR2 | Patient-data scope unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may query protected health information under controls that differ from consumer PII work | `[inferred]` from the HIPAA mention and the product | What patient data would this role query, and what access controls apply? | unresolved |
| RR3 | Clinician involvement unclear | unknown | — | "partner with product managers and clinicians" | Clinicians may be a stakeholder group needing clinical-domain fluency | `[generic]` pattern for clinical stakeholders | How often does this role work directly with clinicians, and what clinical knowledge is expected? | unresolved |
| RR4 | Scope named concretely | positive_signal | — | "define and maintain the metrics layer" | Success is measurable against a defined layer | `[grounded]` JD | — | noted |
| SE | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Unverified in this session. The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. These are possibilities, none ranked | `[generic]` pattern for companies of this size | Can you point me at the role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation program and the 11% retention lift, with the test context stated | Strongest match to R3 | `[grounded]` your CV | pending your approval |
| A2 | Present the consent-state and PII work as an adjacent bridge to R9, not as healthcare experience | Keeps the claim within what you did | `[inferred]` from R9 | pending your approval |
| A3 | Confirm the posting on Harborlight's own careers page before investing in the application | Closes SE | `[generic]` | pending your approval |
| A4 | Ask RR1–RR3 in the first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is from your message, so each is a lead until checked.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused because web search permission was not granted this session; I did not retry. Would have confirmed the employer and posting (SE, the contradictions row) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market calibration for title and salary |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Web search permission granted → targets 1 and 2 run. Closes SE and sets the market calibration.
- A link to the live posting or Harborlight's careers page → closes SE.
- A sanitized memo excerpt or a test readout → R5 and R3 to `high`.
- A sanitized consent-model description → R9 gets stronger evidence.
- A deeper research pass (L2) on Harborlight's funding, leadership, and reviews: up to 5 more searches and 2 more fetches. I'll run it only if you say so.

A `tuesday-dossier.md` file of this assessment can be emitted for later sessions if you want one.

**Questions:**

1. (RR1) Does this role own the metrics definitions alone, or share them with a data engineering team, and how many analysts report to it?
2. (RR2) What patient data would this role query, and what access controls apply?
3. (RR3, R7) How often does this role work directly with clinicians, and what clinical knowledge does the posting expect?

Answer in text, paste a sanitized excerpt, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.