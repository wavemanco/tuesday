**Decision: conditional go.** Apply, but confirm the location and check that the employer is real before you spend time on interview prep.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched brindlemoor.co.uk/careers/senior-pricing-analyst. The careers page is the only web presence found. |
| 2 | Role-family sweep | yes | "Senior Pricing Analyst pet insurance UK salary GLM" returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey. |
| 3 | Hiring manager's public footprint | yes | "Odile Varga Director of Pricing Brindlemoor" returned one snippet. Not fetched, so not independently checked. |

## Decision snapshot

- **Fit, core requirements:** strong. Five of six requirements match her motor-insurance record directly. Confidence is medium across the board because all of it is self-reported and nothing is inspectable yet.
- **Main gap:** no pet-insurance experience. This is a transferability gap, not a hard gate.
- **Hard gates:**
  - **Location: unresolved.** The JD says "fully remote (UK)". The careers page says "Leeds office four days a week." Her location isn't stated, so I can't check it against either.
  - **Pay: unknown.** Neither source gives a salary, and her floor isn't stated.
- **Opportunity:** the posting is live on the company's own domain, but I found no third-party corroboration of the company. That caps the decision at conditional go.

## Role reality

- **Scope:** owns pricing analytics for a pet-insurance product, builds and monitors rating models, designs and reads price tests, and makes recommendations to underwriting and product. Reports to the Director of Pricing. [grounded, JD and careers page]
- **Contradiction:** remote versus four days a week in Leeds. Surfaced, not resolved. [grounded]
- **Market calibration:** the Pricewell 2026 survey puts senior pricing analysts at UK insurers and insurtechs at a median base of £58,400, with an interquartile range of £52,100 to £64,900 (n=612). [generic]
- **Posting withholds pay.** Worth a question.
- **Hiring manager:** the search snippet says Odile Varga is Director of Pricing at Brindlemoor, previously head of pricing analytics at Calloway Re, and spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. [grounded, one unverified snippet]

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 4+ years pricing or actuarial analytics | must | meets | medium | none | 5 years, last 2 as senior analyst (stated) |
| 2 | Strong SQL and Python | must | meets | medium | none | Daily use (stated) |
| 3 | GLM experience | must | meets, strong | medium | none | Built and maintained the young-driver rating GLM (stated) |
| 4 | Presenting to underwriting or actuarial leads | must | meets | medium | none | Quarterly pricing review to head of underwriting (stated) |
| 5 | Design and read price tests | must (implied by JD) | meets | medium | none | 14 price tests last year, with underwriting (stated) |
| 6 | Build and monitor rating models for a pet product | must | partial | medium | transferability | Motor, not pet (stated). Her GLM and monitoring work transfers; pet-specific drivers do not. |
| 7 | Turn results into recommendations for product | must | partial | low | discovery | Underwriting presentations stated; product-level recommendations not stated |
| 8 | Insurance a plus | preferred | meets | medium | none | UK motor insurer (stated) |
| 9 | Hard gate: location | hard_gate | unknown | low | hard gate | Sources contradict; her location not stated |
| 10 | Hard gate: pay | hard_gate | unknown | low | hard gate | Posting gives no pay; her floor not stated |

People management is not in the JD, so it isn't a gap here. It only becomes one if the role turns out to include direct reports.

## Gap recovery queue

- **G1, location (hard gate):** resolve by confirming her location and whether Leeds four days a week is workable. Closed by her answer.
- **G2, pay (hard gate):** resolve by confirming her floor against the [generic] band above. Closed by her answer.
- **G3, product recommendations (discovery):** she may have this evidence and not have mentioned it. Closed by a concrete example, if one exists.
- **G4, pet-insurance domain (transferability):** not closable by a document. Address it honestly in the application and show how fast she can learn the pet drivers. Do not claim knowledge she doesn't have.

## Opportunity risk register

- **Failed attribution (medium, standing):** the only web presence is the careers page. No press, funding or other independent mention turned up. Possible explanations include a company that is new or small, a stale posting, or a recruiter-led listing. Any of these is possible; none is established. Resolve by checking the company's own homepage, or by asking the recruiter directly through the careers page for the company's registration details.
- **Location mismatch (high, until resolved):** remote in the JD, four days in Leeds on the careers page.
- **Pay withheld (medium):** the posting gives no pay, so the band in Role reality is the only reference point.

## Application plan

1. **Before applying:** confirm your location and whether Leeds four days a week works. Check the company through its own channels.
2. **Lead with:** the GLM you built and maintained, the 14 price tests, and the quarterly review to the head of underwriting. These map to the monitoring and test-reading parts of the role.
3. **Speak to the hiring manager's published interest:** monitoring rating models is a theme of her 2025 talk. Lead with what you did in monitoring, not with her talk's content, which you haven't read.
4. **Address the pet gap directly:** say you haven't worked on pet insurance and name the transferable parts (GLM rating, monitoring, test design). Do not write anything like "experienced in pet insurance".
5. **Proposed CV language (pending your approval, not for use yet):** "Built and maintained the GLM rating model for a young-driver motor book; designed and read 14 price tests with the underwriting team; presented the quarterly pricing review to the head of underwriting."

## Evidence status

Your claims are self-reported in this conversation. Nothing has been checked against a document. Upgrading the confidence bands needs something inspectable: a sanitised model documentation page, a test readout, or the review deck.

## Dossier offer

If you want, I can save this assessment as a `tuesday-dossier.md` file so you can pick it up later.

## Upgrade menu

- **Location and pay answers:** unlock the two hard-gate rows. Without them, the decision stays capped.
- **A sanitised model documentation page or test readout:** raises your GLM and price-test rows from medium to high confidence.
- **A product-level recommendation example:** closes G3.
- **Deeper research (L2):** company funding, leadership changes, hiring patterns, and a recent-news sweep. Up to 5 more searches and 2 more fetches. Offered once; I won't run it without your go-ahead.

## Questions

1. **G1 (location):** Where are you based, and can you work from Leeds four days a week?
2. **G2 (pay):** What is your base floor? The posting gives no pay, and the survey median is £58,400. [generic]
3. **G3 (product recommendations):** Have you made a pricing recommendation that changed a product or underwriting rule? What happened?

You can answer any, all or none. Skipping is fine, and I won't ask again.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.