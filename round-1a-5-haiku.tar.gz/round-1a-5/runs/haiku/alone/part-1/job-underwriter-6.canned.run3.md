**Decision: conditional go.** You meet the tooling and years requirements, and the role is close to what you already do. Two must-have requirements are real gaps, and two hard gates are unanswered: your location and your pay floor.

**Decision snapshot**

- **Fit:** Meets on years (5), Salesforce admin, SQL, and pipeline and renewal reporting. Partial on "B2B software" (you're at a payments company). Gap on owning a forecast and on working with finance on billing or revenue data.
- **Hard gates:** Location (Bristol, two office days a week) is unknown. Pay (£61,500–£67,000 plus shares) is unknown against your floor. You haven't given either.
- **Opportunity:** No red flags. The posting is coherent, the salary is stated, nothing asks you to pay or give bank details. Company verified.
- **Conditions:** Bristol hybrid is workable for you, your pay floor sits inside the range, and you can evidence forecast-adjacent work without overclaiming.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1**

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | yes | Query "Quillfield invoicing software Bristol company". Rests on quillfield.co.uk/about. Careers page did not surface, so the posting is checked against the JD only. |
| 2 | Role-family sweep | yes | Query "Revenue Operations Lead salary UK B2B software 2026". Rests on the Ledgerline 2026 UK Revenue Operations Pay Guide. |
| 3 | Hiring manager public footprint | yes | Query "Tamsin Achebe Quillfield revenue". One result: a LinkedIn profile. |

**Role reality**

- **Role:** Revenue Operations Lead, Quillfield, Bristol, hybrid (two office days a week). Owns CRM and billing data, builds pipeline and renewal reporting for sales and finance, and runs the quarterly revenue forecast with the CFO. (Posting, [grounded])
- **Company:** Invoicing and payments software for UK builders' merchants. Founded 2018, 96 employees, Series A (£11M) in April 2025. ([grounded], quillfield.co.uk/about)
- **Hiring manager:** Tamsin Achebe, Head of Revenue Operations. Previously sales operations manager at Corvane Payments for four years. ([grounded], one profile result, not verified by you.) The posting doesn't state this role's reporting line; ask the recruiter.
- **Market calibration:** The stated salary sits inside the role-family band. The 2026 UK median is £64,200 and the interquartile range is £57,800–£70,400 (n=438). ([generic], one source.) The share options are unvalued.
- **Scope read:** Ownership of CRM data, billing data, reporting for two functions, and the forecast is broad for one hire. ([inferred] from the posting.) The company is at Series A, so this may be building a function that didn't exist before. ([inferred])

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | Must-have | Partial | High on years, medium on sector | Transferability | 5 years sales ops, last 2 running UK RevOps, at a B2B payments company |
| R2 | HubSpot or Salesforce administration | Must-have | Meets | High | None | Salesforce admin certified; rebuilt pipeline and renewal dashboards. Certificate is stated, not checked. |
| R3 | Strong SQL and spreadsheet modelling | Must-have | Meets on SQL, likely on modelling | Medium | Confirm | SQL weekly, Excel daily. "Modelling" not described. |
| R4 | Experience owning a forecast | Must-have | Gap | Low | Capability / transferability | Finance owned the company forecast. You run the monthly pipeline review with the sales director, which is adjacent. |
| R5 | Working with finance on billing or revenue data | Must-have | Gap | Medium | Discovery | Never worked on billing data. Whether you worked with finance on revenue data is unknown. |
| H1 | Location: Bristol, two office days a week | Hard gate | Unknown | — | Discovery | Your location wasn't provided. |
| H2 | Pay: £61,500–£67,000 plus shares | Hard gate | Unknown | — | Discovery | Your pay floor wasn't provided. |
| P1 | Pipeline and renewal reporting | Core scope | Meets | High | None | Rebuilt both dashboards. |

**Opportunity risk register**

- **Scope overload** (medium, [inferred]): CRM, billing, two-function reporting and the forecast in one role.
- **Forecast accountability** (medium): The role answers to the CFO for the number. R4 is the least-closable gap.
- **Pay** (low, [generic] and [grounded]): Inside the band. Shares are unvalued.
- **Stage** (low, [inferred]): Series A growth, possibly a new function.
- **Company existence** (not triggered): Verified.

**Application plan (as far as evidence allows)**

- Lead with the Salesforce certification, the pipeline and renewal dashboards, and SQL. These are your strongest, verifiable matches.
- For R4, only say true things, such as that you run the monthly pipeline review with the sales director. Don't describe that as owning a forecast unless it's true.
- Don't claim billing or finance-facing revenue work until you've confirmed it (R5).
- Hiring manager: Tamsin Achebe's background is close to yours (sales operations, then RevOps leadership at a payments company). Only reference that if it's useful and accurate for you.

**Gap recovery queue**

- **R4:** Forecast ownership is missing. Would close with evidence of commit or best-case calls feeding a forecast.
- **R5:** Billing and revenue-data experience is missing. Would close with any finance-facing revenue or settlement work.
- **H1 and H2:** Hard gates unanswered. Would close with your location and pay floor.

**Upgrade menu**

- Your location and pay floor: they resolve both hard gates.
- A redacted sample of your dashboards: raises R2 and R3 from stated to checked.
- The recruiter's answer on the reporting line for this role.
- The Quillfield careers page: confirms the posting is current and consistent.

I can build a dossier of this assessment (`tuesday-dossier.md`) if you want to carry it into other applications or interviews.

**Questions**

1. **[R4]** When you run the monthly pipeline review, do you set or sign off the commit and best-case numbers that feed the sales forecast, and who owns the final figure?
2. **[H1]** Where are you based relative to Bristol, and could you do two office days a week there?
3. **[R5]** Have you worked with finance on revenue, invoicing or settlement data? Payments transaction data may be closer to billing than it looks.

Reply with answers, say "skip" for any question, or tell me to proceed without them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.