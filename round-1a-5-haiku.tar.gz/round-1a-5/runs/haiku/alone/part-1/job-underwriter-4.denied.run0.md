**Decision snapshot**

**Worth applying to, conditional on two checks. Status: `conditional_go`.**

**Fit ledger.** On your background the fit is strong. Every stated requirement maps to something on your CV, with one real gap (pet insurance) and one unknown (product-facing recommendations).

- `hard_gate`: unclear: R11 (UK right to work without sponsorship; not stated)
- `must_have`: direct: R1, R2, R3, R4, R5, R6 · unclear: R7 (recommendations for product)
- `important`: absent: R9 (pet-insurance domain, implied by "our pet-insurance product")
- `preferred`: direct: R8 (insurance experience, motor)

R9 is a credible transferability gap, not a capability gap: your rating and test work transfers, but the pet-specific drivers don't. R7 is only unclear because your CV describes presenting to underwriting, not product.

**Opportunity ledger.** The role is clearly defined, but the employer is unchecked and the pay and management scope are withheld. Nothing in the posting is a red flag on its own.

- **Hard gates:** none failed; unconfirmed: R11 (UK right to work); candidate constraints not given, so checks against notice period and salary floor are unknown.
- **Severe red flags:** none found in the pasted posting.
- **Conditions for go:** (1) Brindlemoor is verified as a live, hiring employer (see RR1); (2) the posting's scope on line management and product decisions is confirmed (RR4, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics role covering the full pricing cycle; the list of duties is broad but within a senior analyst's remit | `[inferred]` from the duty list |
| Market calibration | Not established: no research run, so no salary or scope band | — |
| Unknowns | Salary, contract basis, line-management, product decision rights, employer's live status, what pet data exists | — |
| Contradictions | None within the pasted JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, UK motor insurer; stated, not inspected | `[grounded]` your background | Surface in CV |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use; stated | `[grounded]` your background | Work sample would raise it |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a young-driver rating GLM; stated | `[grounded]` your background | Outcome metrics would raise it |
| R4 | Designing and reading price tests | must_have | direct | medium | none | 14 tests last year with underwriting; stated | `[grounded]` your background | Test results with outcomes |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to head of underwriting; stated | `[grounded]` your background | None |
| R6 | Monitoring rating models | must_have | direct | medium | none | Maintaining the GLM covers much of monitoring; the word itself is not on the CV | `[inferred]` | Confirm monitoring cadence in interview prep |
| R7 | Recommendations for product, not only underwriting | must_have | unclear | low | transferability | No product-facing recommendations on the CV | `[grounded]` absence on CV | See gap queue G2 |
| R8 | Insurance experience | preferred | direct | medium | none | Motor insurance | `[grounded]` your background | None |
| R9 | Pet-insurance domain | important | absent | none | transferability | Nothing on pet; implied by the product, not a stated requirement | `[grounded]` absence on CV | See gap queue G1 |
| R10 | Line management | — | — | — | — | Not in the JD; you have never managed | `[grounded]` JD silence | Carried in RR4 |
| R11 | Right to work in UK without sponsorship | hard_gate | unclear | low | hard_gate | Not stated by you | — | Confirm (Q2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R9, important) | transferability | Motor pricing only; no pet, companion-animal or vet-cost work | Pet drivers (species, breed, vet-cost inflation, claim frequency) differ from motor, and a reader will probe this first | Any work with low-frequency, high-severity claims or non-motor product data | A short write-up of how you'd adapt a GLM to a new product | `[generic]` that these are the usual pet-pricing drivers |
| G2 | Product recommendations (R7, must_have) | transferability | Recommendations go to underwriting; product not mentioned | The JD names product as a recipient | Any price-test result that changed a product feature or tariff | One product-side recommendation you made and what happened | `[inferred]` from the JD's named audiences |

The queue holds no questions. Each question is asked in the closing block, tagged with its row id.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked; no research run | unknown | medium | "Brindlemoor (insurtech)" | Employer may be newer or smaller than the posting suggests, or the posting may be stale; none is ranked as likely | `[inferred]` | Q1 | unresolved |
| RR2 | Salary not stated in the JD | unknown | — | (none) | Pay may be below your floor or simply unpublished | `[grounded]` JD silence | Q2 | unresolved |
| RR3 | Pet domain ramp | risk_signal | medium | "our pet-insurance product" | Ramp time on pet-specific drivers may be the main early objection | `[inferred]` from R9 | Does the role expect pet pricing in the first quarter? | unresolved |
| RR4 | Line management unstated against "Senior" | unknown | — | "Senior Pricing Analyst" | Role may carry management, which you have never done | `[inferred]` | Q3 | unresolved |
| RR5 | Product decision rights unstated | unknown | — | "recommendations for underwriting and product" | Recommendations may go to product without authority over decisions | `[inferred]` | Q3 | unresolved |
| RR6 | Strong requirement match | positive_signal | — | "4+ years pricing or actuarial analytics; GLM experience" | Five years and a maintained GLM meet the core list | `[grounded]` | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Surface the 14 price tests and the GLM work as outcome bullets, with real results only | see R3, R4 | `[grounded]` your background | pending your approval |
| W1 | Write a one-page note on adapting a motor GLM to a pet book, framed as a plan, not as pet experience | see G1, R9 | `[generic]` | pending your approval |
| A1 | Check Brindlemoor's live posting and company status before investing time | see RR1 | `[inferred]` | pending your approval |
| A2 | Ask the recruiter about salary band, contract basis and line management before the first interview | see RR2, RR4 | `[grounded]` register | pending your approval |

Nothing in this plan says you have pet-insurance experience. Your CV claims cover motor pricing only.

## Evidence status

Verified: none yet.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was denied permission, so no search ran. Employer check (RR1) stays open. The tool was not retried. |
| 2. Role-family sweep | unavailable | Same cause. Market calibration is absent. |
| 3. Hiring manager's public footprint | skipped | Not run. Odile Varga is named; offered on consent. |

## Upgrade menu

- **Employer check:** the live posting link, or your permission to run up to 5 searches and 2 page fetches, would verify Brindlemoor and close RR1.
- **Salary band:** the figure from the recruiter, or a role-family search, would resolve RR2.
- **Pet material:** any pet-pricing notes or public product material would move R9 from absent toward partial.
- **CV outcomes:** metrics for the price tests and GLM changes would raise R3 and R4 from medium to high once checked.
- **Constraints:** notice period, salary floor and right-to-work status would close the hard-gate check.

I can also write this assessment to `tuesday-dossier.md` for later interview preparation.

**Questions**

1. **(RR1)** Do you have the live posting link? And may I run up to 5 searches and 2 page fetches on Brindlemoor and Odile Varga's public profile to check the employer and the market?
2. **(R11, RR2)** Do you have UK right to work without sponsorship? Also, what's your salary floor and earliest start date?
3. **(RR4, RR5)** Does the posting, or any recruiter contact, say whether this role manages people or owns product decisions?

You can answer in prose, and "skip" is a valid answer to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.