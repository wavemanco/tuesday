**Decision: conditional_go.** The role fits your experience well. The open items are whether Brindlemoor is verified and whether pet insurance is a gap you can close.

**Decision snapshot**

| Ledger | Read |
|---|---|
| Candidate fit | Strong on the core requirements; partial on the pet-insurance context. |
| Opportunity | Unverified. Company, posting, and pay are unchecked. No red flags in the JD itself. |
| Hard gates | Fully remote UK is stated. Your location and right to work aren't in what you gave me, so this is unknown until confirmed. No gate is triggered by the lack of people management. |

**Role reality**
- Senior individual-contributor pricing analytics for a pet-insurance product: build and monitor rating models, design and read price tests, and recommend to underwriting and product.
- The JD does not require managing people. `[grounded]`
- Stated pay: none. The posting withholds it. `[grounded]`
- Market calibration: not run. Pay bands and scope norms for this title are unverified. `[generic]` only.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Evidence / gap |
|---|---|---|---|---|---|
| 1 | Must-have | 4+ years pricing or actuarial analytics | Meets | High | 5 years, motor pricing, last 2 senior. `[grounded]` |
| 2 | Must-have | GLM experience | Meets | High | Built and maintained the young-driver rating GLM. `[grounded]` |
| 3 | Must-have | Strong SQL and Python | Meets | Medium | Daily use, self-reported. Needs a code sample to raise confidence. |
| 4 | Must-have | Presenting to underwriting or actuarial leads | Meets | High | Quarterly pricing review to the head of underwriting. `[grounded]` |
| 5 | Core duty | Design and read price tests | Meets | High | 14 tests run last year with underwriting. `[grounded]` |
| 6 | Plus | Insurance experience | Meets | High | UK motor insurance. |
| 7 | Implied | Pet-insurance pricing context | Gap | Low | No pet experience. Pet pricing differs: lifetime vs annual cover, breed and condition drivers, vet-cost inflation. `[inferred]` |
| 8 | Implied | Building a rating model for a newer product with thin claims history | Partial | Low | Your GLM work was on an established book. `[inferred]` |

**Gap recovery queue** (no questions here; the closing block asks them)
- **G1, transferability (pet context):** closes with a project involving non-motor pricing or a written pet-pricing plan.
- **G2, capability (new-product build):** closes with an example of a model built from limited data.
- **G3, hard gate (location and right to work):** closes with your confirmation.

**Opportunity risk register**
- **Brindlemoor existence and posting status — medium, unverified.** Not researched. This caps the decision at conditional_go until confirmed.
- **Pay withheld — medium.** Compare against your floor once a figure appears.

**Application plan**
- Lead with the GLM build-and-maintain work, the 14 price tests and their decisions, and the underwriting presentations. These are your strongest, verifiable claims.
- Address pet insurance directly as transferable motor pricing, not as existing experience. Don't imply pet work you haven't done.
- Don't claim management. The role doesn't require it.

**Evidence status**

Research tier: L0 — no searches. Research was not run in this pass; L1 is the default and I can run it on your yes.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not consented yet. |
| 2 | Role-family sweep (scope and pay) | skipped | Not consented yet. |
| 3 | Hiring manager's public footprint | skipped | Not consented yet. |

**Upgrade menu**
- A code sample or anonymised model write-up: raises SQL/Python and GLM confidence from medium to high.
- The live posting link or the Brindlemoor careers page: resolves the employer check.
- L1 research (up to 5 searches, 2 page fetches): verifies the company, the posting, and the pay band.
- Any non-motor or build-from-scratch pricing work: moves G1 and G2 from low to medium.

If you want a tracked record of this assessment, I can save it as `tuesday-dossier.md`. It's optional.

**Questions**
1. Are you based in the UK, and do you have the right to work there?
2. Do you have the live posting link or Brindlemoor's careers page? If not, shall I run the L1 check?

Reply with answers, "skip" for any question, or "research" to run the check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.