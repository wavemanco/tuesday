**Decision: no_go on the posting's stated terms.** Your instinct is right. The posting fails both of your hard constraints, and its own terms don't agree with each other.

## Decision snapshot

- **Opportunity:** `no_go`. Two hard gates fail on the posting's own text. Company research could not change that, so I did not run it (see Research tier).
- **Candidate fit:** strong on the core growth-leadership requirements. Five of the seven listed functions have no evidence in your background.
- **Hard gates:**
  - **Pay: FAILED.** Posted base is $70–85k [grounded]. Your floor is $150k.
  - **Location: FAILED.** On-site in Austin 5 days a week, "no exceptions" [grounded]. You are remote-only from Portland.
- **Fit ledger**

| Priority | Fit | Requirement |
|---|---|---|
| Must-have | Strong | Paid acquisition, lifecycle/CRM, experimentation, growth team leadership, SQL/GA4 analytics |
| Must-have | Meets | 8+ years growth leadership (you have 9) |
| Stated scope | Gap, unevidenced | SEO/content, brand, PR, partnerships, sales ops |
| Stated scope | Partial | E-commerce enablement (your background is B2C subscription) |

## Research tier

Research tier: L0 — no searches

I chose not to research. Both hard gates fail on the posting's own words, so no company fact would flip the verdict. This is a departure from the L1 default, and L1 is offered in the upgrade menu.

## Role reality

- **Scope:** seven functions, "a team of one to start," and "no bench." That is a senior remit with no team.
- **Seniority vs. pay:** "Head of Growth" with "8+ years required" is paired with $70–85k base [inferred from the posting's own terms]. That pairing is the main reason the posting feels off.
- **Hours:** "evenings and weekends when it matters is just who we are" is a stated expectation, not a formal gate.
- **Success:** "success metrics will evolve as we learn." No defined targets.
- **Market calibration:** not established at L0. I won't give a market figure from memory. Any comparison to market pay is `[generic]` and needs L1 to ground it.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement and evidence |
|---|---|---|---|---|---|
| 1 | Must-have | Strong | Medium | None | Paid acquisition: owned in both roles (CV-only) |
| 2 | Must-have | Strong | Medium | None | Lifecycle/CRM: owned, Braze (CV-only) |
| 3 | Must-have | Strong | Medium | None | Experimentation: owned (CV-only) |
| 4 | Must-have | Strong | Medium | None | Teams of 3–7 built and managed (CV-only) |
| 5 | Must-have | Strong | Medium | None | SQL, GA4 (CV-only) |
| 6 | Must-have | Meets | Medium | None | 8+ years: 9 years stated (CV-only) |
| 7 | Stated scope | Partial | Medium | Transferability | E-commerce vs. B2C subscription |
| 8 | Stated scope | Gap | Not evidenced | Discovery | SEO/content |
| 9 | Stated scope | Gap | Not evidenced | Discovery | Brand |
| 10 | Stated scope | Gap | Not evidenced | Discovery | PR |
| 11 | Stated scope | Gap | Not evidenced | Discovery | Partnerships |
| 12 | Stated scope | Gap | Not evidenced | Discovery | Sales ops |
| 13 | Hard gate | Fails | Confirmed | None | Pay: $70–85k vs. $150k floor [grounded] |
| 14 | Hard gate | Fails | Confirmed | None | Location: on-site Austin 5 days vs. remote-only [grounded] |

Rows 8–12 may be gaps in the CV rather than in your experience. Row 7 is a judgment about transferability, not a gap in capability.

## Opportunity risk register

| Class | Severity | Confidence | Entry |
|---|---|---|---|
| Hard-gate mismatch: pay | High | Confirmed | $70–85k posted vs. $150k floor [grounded] |
| Hard-gate mismatch: location | High | Confirmed | On-site 5 days, "no exceptions," vs. remote-only [grounded] |
| Scope and seniority mismatch | Medium | Inferred | Head-level title and remit, team of one, junior-band pay |
| Hours expectation | Medium | Stated | Evenings and weekends as a norm |
| Undefined success criteria | Medium | Stated | "Metrics will evolve" |
| Failed attribution (standing) | Medium | Not established | Company existence and live posting not verified. Reasons open: too new or small, stale posting, or not a real hiring employer. Caps any `go` at `conditional_go`. |

## Application plan

None recommended. If the company changes the terms to at least $150k base and remote work in a Portland-compatible arrangement, re-underwrite the role. I have not drafted any outreach or CV language.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | L0 chosen; the verdict rests on the posting's own gates |
| 2 | Role-family sweep (market pay and scope) | skipped | Same reason; the market band stays `[generic]` |
| 3 | Hiring manager's public footprint | n/a | No name given |

## Gap recovery queue

- **Row 8–12 (SEO, brand, PR, partnerships, sales ops):** not in the CV. Closing this gap needs evidence of any of these in your past roles.
- **Row 7 (e-commerce):** transferability. Closing it needs a view of how your subscription work maps to e-commerce enablement.
- **Row 13–14 (hard gates):** cannot be closed by wording. Only the employer changing the terms closes them.

## Dossier offer

If you want, I can write these findings to a `tuesday-dossier.md` file you can keep.

## Upgrade menu

- **L1 research (up to 5 searches, 2 fetches):** confirms the company exists as described, checks the live posting, and grounds a market pay band for this seniority. Consent needed.
- **A link to the live posting or the recruiter's email domain:** lets the company be checked directly.
- **CV evidence for SEO, brand, PR, partnerships, or sales ops:** would raise rows 8–12.

## Questions

1. **(Row 13, pay):** Did the recruiter or company mention compensation beyond the posted $70–85k, such as a different band or a note on how the figure is set?
2. **(Rows 10–12, PR, partnerships, sales ops):** Have you owned any of these, even if they aren't in your CV?
3. **(Failed attribution):** Can you send a link to the live posting or the recruiter's email domain?

Reply with answers, or "skip" for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.