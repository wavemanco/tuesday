**Yes, apply, on three conditions: `conditional_go`.** The core of the role matches your record. The two gaps are forecast ownership and billing data, and three hard gates are still unchecked.

**Fit ledger.**

- `hard_gate`: unclear: R7, R8, R9
- `must_have`: direct: R1, R2, R3; adjacent: R4; absent: R5
- `important`: direct: R6

R4 is adjacent (owning a forecast); R5 is absent (finance work on billing data); R6 is the strongest direct match on the posting's own words.

**Opportunity ledger.** Clear scope and an in-band salary (RR3). Who owns the forecast and billing numbers, and the reporting line, are unknown (RR1, RR4). The posting isn't yet confirmed on Quillfield's own site (RR2). Severe red flags: none found.

- **Hard gates:** none failed; unconfirmed: R7 (Right to work in the UK), R8 (Bristol hybrid, two days in office), R9 (Base pay £61,500–£67,000); candidate constraints not given — checks against them unknown

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol, 96 staff, £11M Series A in April 2025 | `[grounded]` search snippet of quillfield.co.uk/about (not fetched in full) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| First-year outcomes | Not stated | Posting is silent |
| Working pattern | Bristol hybrid, two office days a week | `[grounded]` posting |
| Scope read | Wide for one role: CRM, billing data, pipeline reporting and the forecast with finance in a single post | `[inferred]` from the four responsibilities |
| Market calibration | Median base £64,200, interquartile range £57,800–£70,400 for UK B2B software revenue ops leads (n=438). The posting's £61,500–£67,000 sits inside that range | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting for the stated salary. Not this employer's offer as a benchmark |
| Unknowns | Reporting line; forecast ownership versus finance; billing data access; first-year outcomes; team size | — |
| Contradictions | None between the posting and the search results. Quillfield's careers page was not found, so the posting is unverified on the employer's own site | `[grounded]` fetch of quillfield.co.uk/careers returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or similar at a B2B software company | must_have | direct | high | none | Five years in sales ops and two running UK revenue ops match the years and role. The employer was a B2B payments company, not software; name that in applications | `[grounded]` your statement | none |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certification | `[grounded]` your statement | Attach the certificate reference |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily, but no artifact to inspect | `[grounded]` your statement | W1: a sample would raise this to high |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | You never owned the company forecast; finance did. Your monthly pipeline review with the sales director is the nearest input to it | `[grounded]` your statement; adjacency `[inferred]` | G1; Q2 |
| R5 | Experience working with finance on billing or revenue data | must_have | absent | high | capability | You have never worked on billing data, and no finance revenue work is stated | `[grounded]` your statement | G2; Q1 |
| R6 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your statement | Surface it in the CV summary (E1) |
| R7 | Right to work in the UK | hard_gate | unclear | low | hard_gate | Neither you nor the posting has said | — | You confirm |
| R8 | Bristol hybrid, two office days a week | hard_gate | unclear | low | hard_gate | Your location and willingness not stated | — | You confirm |
| R9 | Base pay £61,500–£67,000 | hard_gate | unclear | low | hard_gate | Your pay floor not given; the figure sits in the market band | `[grounded]` posting | You confirm |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R4, must_have) | transferability | Monthly pipeline review with the sales director; no company forecast owned | The posting puts the quarterly forecast with the CFO in this role | Any pipeline-to-forecast work, even if finance owned the number | An anonymised pipeline-to-forecast reconciliation | `[grounded]` your statement; `[inferred]` adjacency |
| G2 | Billing or revenue data with finance (R5, must_have) | capability | No billing data work; no finance revenue work stated | The posting puts billing data in this role's ownership | Read-only revenue or transaction data work, including from the payments company | A sanitised revenue report you built | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership of billing numbers and the forecast is not split from finance | unknown | — | "own our CRM and billing data"; "run the quarterly revenue forecast with the CFO" | The role may own reporting on these numbers while finance owns the figures it signs off | `[inferred]` from the posting's scope against its silence on decision rights | Which billing and forecast numbers does this role own outright, and which does finance own and sign off? | unresolved |
| RR2 | Posting not found on Quillfield's own careers site | risk_signal | medium | Posting on Tallyboard only | The posting may be stale or aggregated; the employer itself is established by its about page | `[generic]` pattern for job listings on aggregators, not a claim about this employer | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Salary stated and inside the market band | positive_signal | — | "£61,500–£67,000" | Pay is transparent and in range for the title | `[generic]` band against `[grounded]` posting | — | noted |
| RR4 | Reporting line not stated | unknown | — | Posting names no manager | The hiring manager may be Tamsin Achebe, Head of Revenue Operations at Quillfield; the role may sit under her | `[inferred]` from the public profile and the recruiter's statement | Does this role report to you, and how will the first six months be measured? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV's RevOps summary with the pipeline and renewal dashboards and the Salesforce certification | R2, R6 are your strongest direct matches | `[grounded]` CV and posting | pending your approval |
| E2 | Describe the pipeline review as an input to the forecast only if it fed a number finance used. Otherwise leave forecasting out | Avoids claiming forecast ownership (R4) | `[grounded]` R4 row; reframing audit | pending your approval |
| W1 | Build a short SQL or Excel sample from anonymised pipeline data | Raises R3 from medium to high | `[grounded]` R3 row | pending your approval |
| A1 | Ask the recruiter for the reporting line and whether billing data access is part of the role | RR1 and RR4 | `[grounded]` register | pending your approval |
| A2 | Check the posting on Quillfield's own site before applying | RR2 | `[grounded]` register | pending your approval |

**Positioning for Tamsin Achebe.** Her public profile shows she is Head of Revenue Operations at Quillfield, and before that a sales operations manager at Corvane Payments for four years (`[grounded]` profile snippet). Lead with sales-operations and pipeline work, the lens she has worked from. Don't assume shared history beyond what the profile says.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (returned quillfield.co.uk/about) and "Quillfield careers Revenue Operations Lead" (no results); fetched quillfield.co.uk/careers (no page). Moved RR2; the employer exists per its about page |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield CFO finance", which returned her LinkedIn profile (linkedin.example/in/tamsin-achebe). Moved RR4 and the positioning |

## Upgrade menu

- Your answers on right to work, Bristol attendance and pay (R7–R9) → those rows resolve; the status could move to `go` or `no_go`.
- A workbook sample or anonymised query (W1) → R3 to `high`.
- Any finance or revenue-data work, even read-only → R5 may move from `absent`.
- A confirmed reporting line → RR4 closes.
- Confirmation of the posting on Quillfield's own site → RR2 closes, and the cap on `go` lifts.
- A deeper research pass on Quillfield (funding, leadership changes, staff reports, up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` file to keep.

**Questions:**

1. (R5) Have you ever worked with finance on revenue or billing data, even read-only or as a reconciliation check?
2. (R4) When your pipeline review fed the sales forecast, who owned the number that went to finance, and what was your part in it?
3. (R7–R9) Do the Bristol two-days-a-week pattern, the right to work in the UK and the £61,500 base all work for you?

Answer any of these in your own words, say skip, or leave them. I won't re-ask.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.