**Decision: conditional go.** Pursuing this is not a waste of time, but only if you can truthfully show product ownership. Your technical and stakeholder evidence is strong. The gap is the one must-have line: 3+ years of product management, which your resume doesn't show.

Research tier: L0, no searches. This assessment uses only the JD and your resume. I haven't checked Quartzline, the posting, or pay.

**Ledgers, kept separate**

- **Candidate fit:** strong on the integration and customer side, weak on the PM-ownership side. Confidence is medium-high, because these are CV-only claims.
- **Opportunity quality:** plausible role at a reasonable-looking company. Nothing in the JD text is a red flag. It's unverified, and compensation is unstated.

**Evidence map (CV-only claims, so confidence is capped)**

| Requirement | Fit | Evidence | Gap type |
|---|---|---|---|
| 3+ yrs product management (must-have) | Gap | No PM title. Roadmap-input sessions and requirements docs are adjacent, not PM ownership. | Capability / transferability |
| Shipped API or platform products | Partial | 30+ REST integrations end to end, as the implementer. You didn't own a product release. | Transferability |
| Technical fluency with API docs and schemas | Strong | Postman, SQL, OpenAPI, integration architecture | None |
| Stakeholder management: eng, sales, customers | Strong | Coordinated vendor engineers, client engineers, and PMs on custom builds | None |
| Partner discovery | Strong | Scoping workshops; quarterly client roadmap-input sessions | Presentation |
| Specs and delivery with two eng squads | Partial | Requirements documents; no evidence of owning a backlog or sprints | Transferability |
| Define and track adoption metrics | Gap | SQL is a tool, not evidence you've defined success metrics | Capability |
| Launch coordination with sales and support | Strong | Go-live and UAT ownership; the integration playbook | None |
| Agile delivery | Unknown | Not on the CV at all | Discovery |

**Gap recovery: what would close it**

- **The years gap** is the hard one. Show real PM-type decisions: what got built next, scope you cut, a success metric you owned. If the honest answer is "I influenced but didn't decide," say that, and target roles that accept technical PM or solutions-to-product paths.
- **Shipped products:** any feature you specified and saw released, even as a contributor, counts. Describe it as what it was.
- **Metrics:** any adoption or time-to-integrate numbers you tracked for clients.
- **Agile:** whether you ran or joined sprints, and with which teams.

**Risk register**

- The must-have 3+ years line is likely to be screened on title before anyone reads your strengths. Expect that.
- Compensation is unstated. The posting withholds it, which is worth a question to the recruiter.
- Company existence and posting status are unverified. Confirm the posting is live on Quartzline's own careers page.

**Application plan**

1. Apply only if you can truthfully answer the years question with a PM-ownership example. Otherwise use a warm referral or a direct note to the hiring manager, which gets past the title screen.
2. Lead with the integration-to-roadmap story: you know what partners need and how they fail, and you've turned that into requirements.
3. Don't write "product manager" anywhere for coordination work. Any CV language needs your approval before it goes out.

**Upgrade menu:** a link to the live posting; the hiring manager's name if you have one (for a brief footprint check, L1); your non-negotiables on pay, location and schedule; any artifact that shows PM work, such as a spec, roadmap doc, or launch plan.

**Questions** (at most three)

1. In the 30+ integrations and roadmap sessions, did you ever decide what got built next, cut scope, or own a success metric? Give one example.
2. Did any feature you specified ship with your requirements behind it? Name the product and what you owned.
3. Earlier notes mention an internal request-triage tool that support adopted. Is that true? If so, what did it do, and how many people used it? I've treated it as unverified.

Response modes: answer any of these in prose and I'll update the map. Skip any you can't answer.

Dossier: I can save this as `tuesday-dossier.md` for reuse, if you want it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.