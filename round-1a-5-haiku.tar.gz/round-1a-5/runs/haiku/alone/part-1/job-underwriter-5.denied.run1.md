**Worth applying to, on conditions. Status: `conditional_go`.** The stack fits well. Two things block a clear go: the employer is not yet independently verified, and two implied requirements (ingestion, data contracts) plus the BigQuery warehouse are unconfirmed for this role.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver; your location and work authorization not given)
- `must_have`: direct: R2, R3, R4, R5, R6 · unclear: R7, R8
- `important`: adjacent: R9 (BigQuery)
- `preferred`: none listed in the posting

**Opportunity ledger.** Sound on the terms it states: salary is published at $148,000–$166,000, near the role-family median, and no red flags were found. The employer's self-description is unverified (RR1), and the posting carries no hiring manager, team size, or on-call terms (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver, work eligibility). Candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verified (RR1); (2) R1 confirmed; (3) BigQuery, ingestion and contracts scope confirmed before any of them is claimed (R7–R9).

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company about page as provided; self-published, not independently checked (RR1) |
| Mandate | Build and run pipelines for tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts analysts depend on | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity unquantified | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posting's range sits around the median, with its top near the upper quartile | `[generic]` Datawright 2026 report as forwarded by the recruiter; figures not independently checked |
| Scope read | "Build and run" plus contracts points to ownership of the reporting domain's pipelines; consistent with the report's typical scope (one domain, no direct reports) | `[inferred]` from JD wording against the report's norm |
| Seniority read | "5+ years" sits inside the report's 5–8-year norm for Senior; your 6 years is in range | `[generic]` report; `[grounded]` your background |
| Unknowns | Team size, reports, on-call, BigQuery migration status, equity value, hiring manager (none named), salary budget | — |
| Contradictions | None between the JD and the about page as provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver; work eligibility | hard_gate | unclear | none | hard_gate | Your location and authorization were not given, so the check cannot run | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-stated; no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; self-stated, no artifact | `[grounded]` your intake | sample on request (upgrade menu) |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the dbt project (~180 models) on Snowflake. The JD asks for "a cloud warehouse", which Snowflake meets as written | `[grounded]` your intake | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration; self-stated | `[grounded]` your intake | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite; self-stated | `[grounded]` your intake | artifact would raise to high (upgrade menu) |
| R7 | Ingestion from the app and CRM | must_have | unclear | low | discovery | Named in the JD's description; your background does not say whether you built ingestion from a product app or a CRM | `[grounded]` JD; CV silence | Q3 (G2) |
| R8 | Data contracts analysts depend on | must_have | unclear | low | discovery | Named in the JD's description; no mention of contracts in your background | `[grounded]` JD; CV silence | Q3 (G3) |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Your warehouse is Snowflake; dbt and SQL carry over; BigQuery-specific operation was never exercised. Named in the JD's description, not its requirements | `[grounded]` JD; `[inferred]` that the carry-over is real | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale; no BigQuery | The JD's reporting warehouse is BigQuery; the limit is the platform, not the modelling | Any BigQuery work, including sandbox or a migration of a dbt project between warehouses | A sanitized note on porting dbt conventions between warehouses, or a small BigQuery project | `[inferred]` carry-over; `[generic]` that BigQuery-specific operations are a common interview probe |
| G2 | Ingestion from app and CRM (R7, must_have) | discovery | Pipelines and dbt, but no stated source-system ingestion | A must-have, and the JD names it first | Pipelines pulling from a product database, event stream, or CRM API; handling schema drift or late-arriving data | An ingestion DAG outline or sanitized design note | `[grounded]` JD; `[inferred]` that this is a probe area |
| G3 | Data contracts (R8, must_have) | discovery | No mention of contracts or analyst-facing agreements | The JD ties the role to analysts depending on contracts | dbt contracts or tests that analysts relied on; schema agreements with a downstream team | A sanitized contract definition or test config | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently confirmed | unknown | medium | "Pellucid Learning runs live online tutoring … Series C ($52M, February 2026)" | Three reasons, none ranked as likely: the company is too new or small for the claims; the posting is stale; it is not a live hiring employer | `[grounded]` company page as provided; live check refused (L1 targets 1 and 2 unavailable) | Does the posting appear on the company's own careers page, and what is the recruiter's email domain? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity may be worth little or a lot; the posting gives no basis | `[grounded]` JD | What is the equity grant, vesting, and last valuation? | unresolved |
| RR3 | No hiring manager named | unknown | — | (absent from JD) | Common in recruiter-led postings; neutral on its own | `[grounded]` JD | Who would this role report to? | unresolved |
| RR4 | Scope unknown: on-call, team, reports | unknown | — | "build and run" | "Run" may imply on-call for reporting pipelines | `[inferred]` from "build and run" | Is there on-call, and how large is the data team? | unresolved |
| RR5 | Salary is published | positive_signal | — | "$148,000–$166,000" | Pay transparency; the figure is near the role-family median | `[grounded]` JD; `[generic]` median | none needed | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting is live and find the recruiter's email domain before investing time | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter: BigQuery's current role, contract ownership, on-call, team size, hiring manager, equity | see RR2–RR4, R9 | `[grounded]` register | pending your approval |
| A3 | Resume: describe the Snowflake dbt work as cloud-warehouse experience; do not list BigQuery as experience | Keeps R9 truthful; avoids a claim the interview will probe | `[grounded]` R4, R9 | pending your approval |
| A4 | Prepare one sanitized example each for ingestion (R7) and contracts (R8), only if you have one | see G2, G3 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Your background claims are self-stated at intake; no artifact has been checked.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning senior data engineer careers"; the call was refused because search permission was not granted. Would have checked that the employer and posting exist as described (RR1) |
| 2. Role-family sweep | unavailable | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer base salary median"; refused for the same reason. Would have checked the forwarded report's figures and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query can be formed |

## Upgrade menu

- Granting search permission → reruns targets 1 and 2 (up to 3 more searches and 2 fetches) → RR1 resolves or fails; the salary band gets checked against the report.
- The live posting link or the recruiter's email domain → RR1 closes or sharpens.
- Your location and work authorization → R1 closes; the hard-gate check runs.
- A sanitized dbt model, data contract, or Great Expectations config → R6 to high; R4 and R8 gain evidence.
- A hiring manager's name → the scope read and which story to lead with for that reader.

I can also write this analysis to `tuesday-dossier.md` so a later session can pick it up.

1. G2 (R7): Have you built ingestion from a product app or a CRM? Describe one example: source, load pattern, and what broke.
2. G3 (R8): Have you owned data contracts or schema agreements that analysts depended on? Describe one example.
3. R1 and constraints: What is your location, are you authorized to work in the US, and what is your base salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.