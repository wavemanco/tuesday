## Decision snapshot

**Decision: no_go on the posting as written.** Two stated terms fail your hard constraints, and neither can be negotiated away by wording.

**Fit ledger (candidate side, CV-only, unverified):**
- **Strong:** 8+ years growth leadership, paid acquisition, lifecycle/CRM (Braze), experimentation and analytics (SQL, GA4), and scaling ARR ($8M to $40M).
- **Partial:** Team of one with no bench, against your experience building and managing teams of 3 to 7. Also a B2C-subscription-to-B2B-enablement transfer.
- **Unknown or no evidence:** SEO/content, brand, PR, partnerships, sales ops.

**Hard gates (failed rows first):**
- **Fail, pay:** posted base $70–85k against your $150k floor, a gap of $65–80k. [grounded]
- **Fail, location:** on-site Austin 5 days a week, "no exceptions", against remote-only from Portland. [grounded]

**Risk register:** the company is unverified (standing entry, see below), and the posting carries several scope and schedule signals.

**Research tier: L1 — searches 1 of 5, fetches 0 of 2.** The one search I sent was refused because WebSearch permission was not granted, so this assessment rests on the posting and your stated background alone.

## Role reality

- **Scope:** seven functions for one person, starting alone. [grounded]
- **Team framing:** "we believe in players who don't need a bench." [grounded]
- **Schedule:** "evenings and weekends when it matters is just who we are." [grounded]
- **Ambiguity:** "success metrics will evolve as we learn." [grounded]
- **Market calibration:** not run. It needs the research tier, and I won't supply a pay band from memory.
- **Compensation:** the posted $70–85k is [grounded]. Your $150k floor is stated. The gap is arithmetic on those two figures.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | hard_gate | Base pay vs. $150k floor (posted $70–85k) | fail | high | hard_gate | JD comp line; your floor |
| 2 | hard_gate | Remote-only vs. on-site Austin 5 days | fail | high | hard_gate | JD location line |
| 3 | must | 8+ years growth leadership | strong | medium | none | 9 years; Head of Growth at two companies |
| 4 | must | Paid acquisition | strong | medium | none | CV |
| 5 | must | Lifecycle/CRM | strong | medium | none | Braze, CV |
| 6 | must | Experimentation and analytics | strong | medium | none | SQL, GA4, CV |
| 7 | must | Revenue growth at scale | strong | medium | none | $8M to $40M ARR over three years |
| 8 | must | SEO/content | unknown | low | capability | not in your evidence |
| 9 | must | Brand and PR | unknown | low | capability | not in your evidence |
| 10 | must | Partnerships | unknown | low | capability | not in your evidence |
| 11 | must | Sales ops | unknown | low | transferability | B2C background; posting is e-commerce enablement |
| 12 | implied | Solo operator, no team | partial | medium | transferability | managed teams of 3 to 7 |
| 13 | implied | Thrives in ambiguity | unknown | low | none | not evidenced either way |

"Medium" on your strong rows reflects that the claims are stated in your CV and not yet checked against records.

## Opportunity risk register

| Class | Severity | Signal | Provenance |
|---|---|---|---|
| Pay mismatch | high | Posted $70–85k against $150k floor; a Head-titled role at that figure is unusual for the title and scope | [grounded] posting; the market comparison is not run |
| Location mismatch | high | On-site five days, "no exceptions", against remote-only | [grounded] |
| Schedule | medium | Evenings and weekends framed as culture | [grounded] wording, [inferred] as a risk |
| Scope and team pattern | medium | Seven functions, one person, "no bench", evolving metrics, a Head title at the stated pay | [inferred] from the combination |
| Company unverified (standing entry) | medium | Cannot confirm Novaline exists as described, or that the posting is live. Reasons, none ranked as likely: too new or small; stale posting; not a real hiring employer. "Profitable since day one" is unverified. | [grounded] that it is unchecked |

This standing entry caps any `go` at `conditional_go` until the company is verified. The decision is `no_go` regardless, because the two hard gates already fail.

**What would change this:** a base of at least $150k and written confirmation the role is remote-eligible. Even then the company check would have to pass before it reached `conditional_go`.

## Application plan

- **Don't apply on these terms.** Nothing on your side closes the pay or location gap.
- **If you want to keep the door open:** ask the recruiter in writing whether the role is remote and what the base range is. A no to either closes it.
- **If you engage later:** lead with the ARR scale-up and budget ownership, which is your strongest verified-as-stated evidence. Name the SEO, brand, PR, partnerships and sales-ops gaps plainly. Don't claim them.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | WebSearch permission not granted; no page fetched |
| 2 | Role-family sweep (scope, title, pay) | unavailable | Same; no market calibration possible |
| 3 | Hiring manager's public footprint | n/a | No name given |

I can write a `tuesday-dossier.md` that captures this analysis for later use.

**Upgrade menu:**
- Grant WebSearch permission, and I can check whether Novaline exists as described, whether the posting is live, and where the pay sits against the market for this title.
- A live posting link or Novaline's careers page makes that check faster and more reliable.
- Work samples or records for SEO, PR or sales ops would raise those rows from unknown to something checkable.

**Questions:**
1. Did the posting or recruiter say anything about remote work or the pay range beyond the JD text? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. Do you have the live posting link or Novaline's careers page? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.