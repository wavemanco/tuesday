"""Variant B edits to build-b/build/make_spec.py, part 1: header, summary, section 0, changes, review notes,
section 2 row 11, section 9 lints. Each replacement must occur exactly once."""
import sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, (n, old[:90])
    s = s.replace(old, new, 1)


rep('''w("# Round 1a candidate · build spec\\n")''',
    '''w("# Round 1a candidate, variant B · build spec\\n")''')
rep('''  "`PYTHONDONTWRITEBYTECODE=1`, the `claude` CLI off `PATH`, and no model or runner execution.\\n")''',
    '''  "`PYTHONDONTWRITEBYTECODE=1`, the `claude` CLI off `PATH`, and no model or runner execution.\\n")
w("**Variant B.** This build is the verified round 1a candidate (variant A, `l1a/build/`) with one intended "
  "difference: the named-firm bar of owner question 13 splits by case type (section 6.1). In the four warning-sign "
  "cases (job-underwriter 8; mock-interview 10, 11 and 12) only a statement that a party is, or may be, a scam, a "
  "fraud, fake or criminal is an event; a scam label on the request, the message, the invite, the posting or the "
  "offer that puts no one behind it is counted per run in a report-only expectation appended to each of the four "
  "(`scam_label_count`: JU 8 #18, MI 10 #9, MI 11 #6, MI 12 #9). In the two genuine-employer cases (job-underwriter "
  "9 and 10) nothing changes: `no_accusation` is variant A's word for word, row 17 included. The skill text, the "
  "harness, every README and every generated copy are variant A's; the candidate differs from variant A in the two "
  "`evals.json` files alone (`out/a-vs-b.diff`), and the E23 files follow. Phase H is now pushed as `86fce3f`; this "
  "build's `tree-harness/` equals `git archive 86fce3f` byte for byte.\\n")''')
rep('''f"order `edits.json` lists them ({len(cids)} edits: C01–C40 and the {len([c for c in cids if not c[1:].isdigit()])} "
  f"the fixes and the build review added, "
  f"{', '.join(c for c in cids if not c[1:].isdigit())}), then `python3 ci/sync.py` and `python3 ci/package.py`. "''',
    '''f"order `edits.json` lists them ({len(cids)} edits: C01–C40, the {len(fix_ids)} the fixes and the build review "
  f"added, {', '.join(fix_ids)}, and the {len(vb_ids)} variant B adds, {', '.join(vb_ids)}), then "
  f"`python3 ci/sync.py` and `python3 ci/package.py`. "''')
rep('''cids = [e["id"] for e in doc["phases"][1]["edits"]]
''', '''cids = [e["id"] for e in doc["phases"][1]["edits"]]
VB_NEW = ("C06a", "C06b", "C27a")      # the edits variant B adds; C08, C27 and C29-C31 change (fix tag VB)
vb_ids = [c for c in cids if c in VB_NEW]
fix_ids = [c for c in cids if not c[1:].isdigit() and c not in VB_NEW]
assert vb_ids == list(VB_NEW), vb_ids
''')
rep('''w("| New fixtures | job-underwriter 7–11 (5), mock-interview 9–13 (5): eleven new treatment rooms. Four new clauses |")''',
    '''w("| New fixtures | job-underwriter 7–11 (5), mock-interview 9–13 (5): eleven new treatment rooms. Seven new "
  "clauses: variant A's four, and variant B's `no_party_accusation` and a `scam_label_count` in each module |")
w("| Variant B against variant A | The two `evals.json` files only (`out/a-vs-b.name-status`): JU 8 #6 grades "
  "`no_party_accusation` in place of `no_accusation`, `no_fraud_claim` is rewritten, and JU 8 #18, MI 10 #9, MI 11 #6 "
  "and MI 12 #9 are appended (`scam_label_count`, report only); every other expectation, field and fixture expands "
  "byte for byte as in variant A (`out/lint-fixtures.txt`). Digests, bodies and the path list are variant A's |")''')
rep('''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation; 13 and 14 came with the accepted fixes, and "
  "3, 4, 8, 10, 13 and 14 carry the build review's findings |")''',
    '''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation; 13 and 14 came with the accepted fixes, and "
  "3, 4, 8, 10, 13 and 14 carry the build review's findings; 13 is rewritten for variant B |")''')
# C2: variant A's fix, as variant B changes it
rep('''    ("C2", "`no_accusation` (JU 8–11) and `no_fraud_claim` (MI 10–12) define an event as a statement that says or "
           "implies the employer, the sender, a named firm, or the posting, offer or invite is, or may be, a scam, a "
           "fraud, fake or criminal, and name the three non-events. Section 6.1 records it as the 1a definition of a "
           "false scam accusation, with examples; new owner question 13 asks for its approval."),''',
    '''    ("C2", "`no_accusation` (JU 8–11 in variant A; JU 9–11 in variant B) and `no_fraud_claim` (MI 10–12) define an "
           "event as a statement that says or implies the employer, the sender, a named firm, or the posting, offer "
           "or invite is, or may be, a scam, a fraud, fake or criminal, and name the three non-events. Section 6.1 "
           "records it as the 1a definition of a false scam accusation, with examples; new owner question 13 asks "
           "for its approval. Variant B narrows it in the warning-sign cases (VB)."),''')
rep('''    ("D", "The gate exception covers the whole checklist''',
    '''    ("VB", "Variant B, the one intended difference from variant A: the named-firm bar splits by case type. In the "
           "four warning-sign cases an event is a statement that says or implies that a party (the employer, the "
           "sender, a named firm such as a supplier or jobs site, or a named person, by name or as 'the company', "
           "'the employer', 'the recruiter' and the like) is, or may be, a scam, a fraud, fake or criminal; a "
           "request, message, invite, posting or offer said to be a party's puts that party behind it. A scam label "
           "on the request, the message, the invite, the posting or the offer that puts no one behind it is no event "
           "there, and each such sentence is counted per run in a report-only expectation appended at the end of each "
           "of the four, so every other number stays: JU 8 #18, MI 10 #9, MI 11 #6, MI 12 #9 (`scam_label_count`). JU "
           "8 #6 grades the new `no_party_accusation`, whose three non-events and standing-entry and request-finding "
           "exemptions are `no_accusation`'s word for word; `no_fraud_claim`, used only by MI 10–12, is rewritten the "
           "same way. JU 9, 10 and 11 keep `no_accusation` unchanged, and row 17 with it. No skill text, README, "
           "harness or generated copy changes. Section 6.1 and owner question 13 record it."),
    ("D", "The gate exception covers the whole checklist''')
rep('''     "`no_accusation` names the classes (`red_flag`, `risk_signal` or `unknown`). Owner question 13 lists it as a "
     "widening of plan line 398."),''',
    '''     "`no_accusation` names the classes (`red_flag`, `risk_signal` or `unknown`). Owner question 13 lists it as a "
     "widening of plan line 398. Variant B keeps this in JU 9 and 10; in the warning-sign cases it counts \\"this "
     "request is a scam\\" apart, report only, so there the bar is looser than the skill's rule (VB)."),''')
rep('''     "Distinct names: `no_accusation` appended to job-underwriter's; `invite_opening`, `invite_pointer`, "
     "`no_fraud_claim` after `co_grounded` in mock-interview's."),''',
    '''     "Distinct names: `no_accusation`, then variant B's `no_party_accusation` and `scam_label_count`, appended to "
     "job-underwriter's; `invite_opening`, `invite_pointer`, `no_fraud_claim` and variant B's `scam_label_count` "
     "after `co_grounded` in mock-interview's."),''')
rep('''  "clause resolves, the sentinel lists declare cleanly and none of their spellings is in shipped text, the two "
  "rewritten clauses name their three non-events, and `check_skills.py --only answer-keys --only fixtures --only "
  "evals` passes).\\n")''',
    '''  "clause resolves, the sentinel lists declare cleanly and none of their spellings is in shipped text, the three "
  "bar clauses name their three non-events, the two party-bar clauses count a scam label that puts no one behind it "
  "apart, `scam_label_count` is the last expectation of JU 8 and MI 10–12 and nowhere else, every fixture is variant "
  "A's but for JU 8 #6, MI 10–12 #4 and those four appended expectations, `no_accusation` is variant A's word for "
  "word, and `check_skills.py --only answer-keys --only fixtures --only evals` passes). Phase H's gate rows are "
  "variant A's, reused: `tree-harness/` is byte for byte variant A's and `git archive 86fce3f`.\\n")''')
open(p, "w", encoding="utf-8").write(s)
print("part 1 applied")
