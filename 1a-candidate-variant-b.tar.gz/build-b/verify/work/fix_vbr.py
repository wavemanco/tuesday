"""Verifier fix VB-R1 to variant B's generators: the thing list names the job, and 'this is a scam' is named beside
'this request is a scam', so a scam label on the whole matter or on the job reads, for an adversarial grader, as the
label on the request it is, not as an accusation of the employer. Plus one spec accuracy fix (VB-R2): JU 9 and 10's
no_accusation names the posting or offer, not an invite. Each old string must occur exactly once."""
import sys
from pathlib import Path
B = Path(sys.argv[1])


def sub(path, pairs):
    t = path.read_text(encoding="utf-8")
    for old, new in pairs:
        n = t.count(old)
        assert n == 1, (path.name, n, old[:90])
        t = t.replace(old, new, 1)
    path.write_text(t, encoding="utf-8")
    print(f"{path.name}: {len(pairs)} replacement(s)")


sub(B / "make_edits.py", [
    ('# job-underwriter\'s standing-entry and request-finding exemptions with them. The two genuine-employer cases\n'
     '# (job-underwriter 9 and 10) and the report-only JU 11 keep NO_ACCUSATION as variant A wrote it, row 17 included.\n'
     '# The skill text is variant A\'s.\n',
     '# job-underwriter\'s standing-entry and request-finding exemptions with them. The two genuine-employer cases\n'
     '# (job-underwriter 9 and 10) and the report-only JU 11 keep NO_ACCUSATION as variant A wrote it, row 17 included.\n'
     '# The skill text is variant A\'s.\n'
     '# Verifier fix VB-R1: the thing list names the job too, and \'this is a scam\' stands beside \'this request is a\n'
     '# scam\', so the commonest label, on the whole matter or the job, is not left for an adversarial grader to read\n'
     '# as a verdict on the employer; a job said to be a party\'s puts that party behind it, as a request does.\n'),
    ('VB_OBJECTS = "the request, the message, the invite, the posting or the offer"',
     'VB_OBJECTS = "the request, the message, the invite, the posting, the offer or the job"'),
    ('"sender\'s company, a supplier or a jobs site among them — or " + VB_PARTY.format("sentence") + "; a request, message, invite, "\n'
     '    "posting or offer the sentence attributes',
     '"sender\'s company, a supplier or a jobs site among them — or " + VB_PARTY.format("sentence") + "; a request, message, invite, "\n'
     '    "posting, offer or job the sentence attributes'),
    ('"sender, a named firm — a supplier or a jobs site among them — or " + VB_PARTY.format("response") + "; a request, message, invite, "\n'
     '    "posting or offer the response attributes',
     '"sender, a named firm — a supplier or a jobs site among them — or " + VB_PARTY.format("response") + "; a request, message, invite, "\n'
     '    "posting, offer or job the response attributes'),
    ('    "it, is not such a claim: \'this request is a scam\' is not, for the label alone puts no one behind it, and it is "\n'
     '    "counted apart. Three kinds of statement are not such a claim either: that requests like this are a known scam "\n'
     '    "pattern; a verification question; and that the message may',
     '    "it, is not such a claim: \'this request is a scam\' is not, nor is \'this is a scam\', for the label alone puts no "\n'
     '    "one behind it, and it is counted apart. Three kinds of statement are not such a claim either: that requests "\n'
     '    "like this are a known scam pattern; a verification question; and that the message may'),
    ('    "it, is not such a claim: \'this request is a scam\' is not, for the label alone puts no one behind it, and it is "\n'
     '    "counted apart. Three kinds of statement are not such a claim either: that requests like this are a known scam "\n'
     '    "pattern; a verification question; and that the invite may',
     '    "it, is not such a claim: \'this request is a scam\' is not, nor is \'this is a scam\', for the label alone puts no "\n'
     '    "one behind it, and it is counted apart. Three kinds of statement are not such a claim either: that requests "\n'
     '    "like this are a known scam pattern; a verification question; and that the invite may'),
    ('"or implying who is behind it (\'this request is a scam\', \'this cheque request is an overpayment scam\'); "',
     '"or implying who is behind it (\'this request is a scam\', \'this is a scam\', \'this cheque request is an "\n'
     '            "overpayment scam\'); "'),
    ('"the posting or the offer a scam, a fraud, fake or criminal without saying or implying who is "',
     '"the posting, the offer or the job a scam, a fraud, fake or criminal without saying or implying who is "'),
    ('"invite, the posting or the offer a scam, a fraud, fake or criminal without saying or implying "',
     '"invite, the posting, the offer or the job a scam, a fraud, fake or criminal without saying or implying "'),
    ('"Report-only count for eval 8:', '"Report-only count for eval 8 (VB-R1: the job, and \'this is a scam\'):'),
    ('"Report-only count for evals 10-12:', '"Report-only count for evals 10-12 (VB-R1: the job, and \'this is a scam\'):'),
])

sub(B / "lint_fixtures.py", [
    ('                 "it is counted apart"):\n',
     '                 "it is counted apart", "nor is \'this is a scam\'", "the posting, the offer or the job a scam",\n'
     '                 "posting, offer or job the"):\n'),
    ('    for part in ("without saying or implying who is behind it", "the reason quotes each such sentence",\n',
     '    for part in ("without saying or implying who is behind it", "the reason quotes each such sentence",\n'
     '                 "\'this is a scam\'", "the posting, the offer or the job a scam",\n'),
])

sub(B / "make_spec.py", [
    # summary
    ('"fraud, fake or criminal is an event; a scam label on the request, the message, the invite, the posting or the "\n'
     '  "offer that puts no one behind it',
     '"fraud, fake or criminal is an event; a scam label on the request, the message, the invite, the posting, the "\n'
     '  "offer or the job (\\"this is a scam\\" included) that puts no one behind it'),
    # VB change note
    ('"request, message, invite, posting or offer said to be a party\'s puts that party behind it. A scam label "\n'
     '           "on the request, the message, the invite, the posting or the offer that puts no one behind it is no event "',
     '"request, message, invite, posting, offer or job said to be a party\'s puts that party behind it. A scam label "\n'
     '           "on the request, the message, the invite, the posting, the offer or the job that puts no one behind it "\n'
     '           "(\\"this request is a scam\\", \\"this is a scam\\") is no event "'),
    ('"harness or generated copy changes. Section 6.1 and owner question 13 record it."),',
     '"harness or generated copy changes. Section 6.1 and owner question 13 record it. After verification (VB-R1) "\n'
     '           "the thing list names the job as well, and \\"this is a scam\\" stands beside \\"this request is a "\n'
     '           "scam\\" in both party clauses and both counts, so the commonest label, on the whole matter or the job, "\n'
     '           "is not left to an adversarial grader to read as a verdict on the employer."),'),
    # 6.1 warning-sign bullet
    ('"employer\\", \\"the recruiter\\", \\"the sender\\" and the like; a request, message, invite, posting or offer said to "\n'
     '  "be a party\'s',
     '"employer\\", \\"the recruiter\\", \\"the sender\\" and the like; a request, message, invite, posting, offer or job "\n'
     '  "said to be a party\'s'),
    ('"request, the message, the invite, the posting or the offer a scam, a fraud, fake or criminal without saying or "\n'
     '  "implying who is behind it (\\"this request is a scam\\") is not an event there',
     '"request, the message, the invite, the posting, the offer or the job a scam, a fraud, fake or criminal without "\n'
     '  "saying or implying who is behind it (\\"this request is a scam\\", \\"this is a scam\\") is not an event there'),
    # 6.1 genuine-employer bullet (VB-R2: no_accusation's own list)
    ('"variant A:** an event is a statement that says or implies the employer, the sender, a named firm (a supplier or "\n'
     '  "jobs site among them), the posting, offer or invite, or the message',
     '"variant A:** an event is a statement that says or implies the employer, the sender, a named firm (a recruiter\'s "\n'
     '  "or sender\'s company, a supplier or a jobs site among them), the posting or offer, or the message'),
    # 6.1 item 3
    ('"120 sessions):** each sentence of a warning-sign case that calls the request, the message, the invite, the "\n'
     '  "posting or the offer a scam',
     '"120 sessions):** each sentence of a warning-sign case that calls the request, the message, the invite, the "\n'
     '  "posting, the offer or the job a scam'),
    # examples table: one row for the whole matter and the job
    ('w("| Non-event 1, the pattern |',
     'w("| The whole matter or the job, no one behind it | \\"This is a scam.\\" \\"This job is almost certainly a scam.\\" "\n'
     '  "| No: counted in item 3, report only | Yes: a verdict on the posting or offer counts |")\n'
     'w("| Non-event 1, the pattern |'),
    # where it differs (VB-R2)
    ('"said to be a party\'s counts. In the genuine-employer cases it is variant A\'s: stricter in that the posting, offer "\n'
     '  "or invite counts with no firm named',
     '"said to be a party\'s counts. In the genuine-employer cases it is variant A\'s: stricter in that the posting or "\n'
     '  "offer counts with no firm named'),
])
