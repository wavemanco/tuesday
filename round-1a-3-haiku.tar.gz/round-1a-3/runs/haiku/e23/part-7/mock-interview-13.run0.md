Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-7-rooms-case-13-denied-eeb95784/880fe7ca-b814-45ad-9707-be1dc4cc7638/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It's built only from your message and the advert. I didn't run any web research, so there are no salary benchmarks or details from Quillmoor's site.

# Quillmoor Diagnostics: Operations Coordinator recruiter screen prep

**Round:** 30-minute phone call, Thursday 26 November, 2pm, with Hannah Lowther (Talent Partner).

**Type key:** EXP is your experience, JD is fit against a requirement, MOT is why you're moving, TERMS is salary, notice and hybrid. Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

## Prep triage
1. Decide your salary number and floor before the call (C1).
2. Find your notice period in your contract (C2).
3. Rehearse B1 out loud. It's the question most likely to expose a gap.
4. Rehearse A4 until the move sounds plain.

Everything else is insurance.

## Fit snapshot

| Requirement | Your evidence (verbatim) | Fit | Gap |
|---|---|---|---|
| Coordinate production schedules across planning, warehouse, QA | "I schedule deliveries for our three depots and chase suppliers when orders slip" | Adjacent | Transferability. Say the limit: deliveries, not production. |
| Track supplier deliveries, chase late orders | Same quote | Direct | None |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Direct | None. Your strongest material. |
| Weekly on-time dispatch report | None given | Unknown | Discovery. Answer slot in B3. |
| 2+ years operations or logistics | "4 years as a logistics coordinator at a building-supplies wholesaler" | Exceeds | None |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Partial | Presentation. Describe what it does; don't rate yourself "expert." |
| SAP or ERP (a plus) | "Never used SAP — we run our own in-house stock system" | Adjacent | Transferability. "I haven't used SAP." |
| Two days a week at Avonmouth | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Met | None |
| £38,000–£44,000 | "I'm hoping for £42,000" | Within range | None |
| Notice period | Not in the advert or your message | Open | Hard gate. The one open item. |

## Words to avoid under pressure
- **"Production scheduling" or "production schedules."** Your material shows delivery schedules across three depots.
- **"SAP experience."** You've said you haven't used it.
- **"Expert" or "advanced" Excel.** You rebuilt one spreadsheet.
- **"Ran the warehouse" or "managed the depots."** You schedule deliveries for three depots.

## Likely questions

**Conversational** (her warm opening questions)
- **A1, "Tell me about your current role."** Give a 60-second version: four years, a building-supplies wholesaler, three depots.
- **A2, "What does a typical week look like?"** Lead with scheduling and chasing suppliers, in those words. Don't add production.
- **A3, "What did you do with the stock-count spreadsheet?"** Say what you rebuilt and what the one-third figure measured. If you can't explain how the discrepancy count was made, say you can check it.
- **A4, "What's prompting the move?"** Say the office is closing next year, the only offer is relocating to Reading, and you want to stay in Bristol. Don't criticise the employer. Then say what you want next.

**Skeptic** (checking the advert's requirements)
- **B1, "The role coordinates production schedules across planning, the warehouse and QA. What's your experience of that?"** This is the highest-value prep. Name delivery scheduling in your own words, then state the limit. If you've had any contact with production planning or QA, say exactly what. If not, say what carries over from delivery scheduling, such as planning around dependencies and chasing late inputs.
- **B2, "Have you used SAP or another ERP?"** "I haven't used SAP. We run an in-house stock system." Then say what you did in that system. Keep it brief, since it's only a plus.
- **B3, "Have you produced an on-time dispatch figure?"** If you tracked delivery timings, say what you counted and how often. If not, say so and say how you'd build the weekly figure from your schedules.

**Terms**
- **C1, "What salary are you looking for?"** Say £42,000, then stop. If she asks for a range, give the floor you've decided. That number is yours to set.
- **C2, "What's your notice period?"** Give the period from your contract. If it's unclear, say you'll confirm it in writing rather than guess.
- **C3, "How does two days a week at Avonmouth work for you?"** Two days is fine. Three is your ceiling if she asks.

## Questions to ask her (pick four)
1. "What does success look like at six months?"
2. "How is the weekly on-time dispatch report used, and who reads it?"
3. "How do planning, the warehouse and QA work together day to day?"
4. "Which days are the office days at Avonmouth for the team?"
5. "What are the next steps after this call?" She's said she'll cover this, so use it only to confirm the date.

## Upgrade menu
- **Notice period from your contract** closes the one open gate (C2).
- **A salary floor you've decided** turns C1 into a scripted range.
- **What the spreadsheet does** (formulas, reports, lookups) would strengthen the Excel answer.
- **A research sweep** on Quillmoor's published details and Bristol ops salaries would add company context.

---

**Drill:** Say the word and I'll play Hannah on B1, the production-scheduling question, and give you feedback on your answer.

**Dossier:** I can save a `tuesday-dossier.md` recording these gaps so later rounds start from them.

**Word:** I can convert the pack to .docx if you'd like it.

**Question:** What is your notice period, and is it set by your contract? It's the one thing I can't settle from what you've given me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (Avonmouth, Bristol, hybrid two days a week)
**Round:** 30-minute phone call, Thursday 26 November, 2pm, with Hannah Lowther (Talent Partner). Relationship: recruiter.
**Research tier:** L0. Built from your message and the advert only. No web search or fetch was run.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored: **EXP** (your experience), **JD** (fit against a requirement), **MOT** (why you are moving), **TERMS** (salary, notice, hybrid). Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

## Prep triage

The call time is fixed, so in order:

1. Decide your salary number and any floor before the call (C1).
2. Find your notice period in your contract (C2).
3. Rehearse B1 out loud. It is the question most likely to expose a gap.
4. Rehearse A4 until the move reads plainly.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | transferability | Delivery scheduling is adjacent to production scheduling, not the same thing. Your material shows delivery schedules across three depots, not production planning. Say that limit yourself before anyone probes it. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | high | [grounded] | none | Direct match. Lead with "I chase suppliers when orders slip." |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | high | [grounded] | none | Direct match. The named result is the strongest thing in your material. |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Nothing in your material covers dispatch timing. Answer slot in B3. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Exceeds the requirement. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The evidence is the rebuild. Say what the spreadsheet does in your own terms. Do not rate yourself "expert." |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | low | [grounded] | transferability | Your in-house stock system is adjacent experience. Limit, plainly: "I haven't used SAP." |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Term met. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your target sits inside the advertised range. |
| F10 | Notice period (not in the advert or your message) | none given | none | [grounded] | hard_gate | Not yet established. This is the one open gate. Answer slot in C2, and the one question below. |

## Prohibited claims

Built locally from the fit snapshot. These are the wordings to avoid under pressure.

| # | Listed wording | Basis | Honest form |
|---|---|---|---|
| P1 | "production scheduling," "production schedules" | Widens F1's quote, which is about delivery schedules (inflated form) | "I schedule deliveries for our three depots." Your material shows delivery schedules, not production. |
| P2 | "SAP experience," "I know SAP" | Your own negative: "Never used SAP" (sourced) | "I haven't used SAP. We run our own in-house stock system." |
| P3 | "expert in Excel," "advanced Excel" | Widens F6's quote, which is a spreadsheet rebuild (inflated form) | "I rebuilt our stock-count spreadsheet." |
| P4 | "ran the warehouse," "managed the depots" | Widens "I schedule deliveries for our three depots" (inflated form) | "I schedule deliveries for our three depots." |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational | Warm, asks about you and the move | High. Recruiter-screen prior | Tell the story in order: role, the spreadsheet, the move. |
| Skeptic (knockout) | Checks each advert requirement against your CV | Medium. Recruiter screens are light on this, but the advert has three specific asks | Name the limits before she probes them. |
| Terms | Salary, notice and hybrid as a checklist | Certain. She listed all four in her message | Give the number or fact, then stop talking. |

Weighting: the recruiter-screen prior is conversational plus light skeptic. Her message names the terms, so they are certain. Persona depth follows weight: conversational gets four questions, skeptic three, terms three.

## Question banks

### A. Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | A 60-second version: four years, a building-supplies wholesaler, three depots. Use your own words. | F5 is the evidence. Short beats long here. |
| A2 | "What does a typical week look like?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Lead with scheduling and chasing, in those words. Do not add production. | F2. Direct match, so no hedging needed. |
| A3 | "What did you do with the stock-count spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you rebuilt and what the figure measured. Answer slot: how the discrepancy count was made. If you cannot say, say you can check it. | F3 and F6. Strongest evidence in the pack. |
| A4 | "What's prompting the move?" | MOT | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | State the closure, the Reading offer, and that you want to stay in Bristol. Do not criticise the employer. Answer slot: what you want next. | The reason is true, so say it plainly. |

### B. Skeptic / knockout (weight: light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules across planning, the warehouse and QA. What's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | **Highest-ROI prep.** Name delivery scheduling in those words, then state the limit: deliveries, not production. Answer slot: if you have worked with production planning or QA in any way, say exactly what. If not, say what from delivery scheduling carries over, such as planning around dependencies and chasing late inputs. | F1 and P1. Hold the limit; do not stretch the scope. |
| B2 | "Have you used SAP or another ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I haven't used SAP. We run an in-house stock system." Answer slot: what you did in that system. Do not claim SAP. | F7 and P2. A plus, not a requirement, so keep it brief. |
| B3 | "The role reports weekly on on-time dispatch. Have you produced a figure like that?" | JD | none given. Answer slot | Answer slot: if you tracked delivery timings, say what you counted and how often. If not, say so and say how you would build the weekly figure from your schedules. | F4. No quote speaks to this, so the answer is yours to give truthfully. |

### C. Terms (weight: certain)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What salary are you looking for?" | TERMS | [grounded] "I'm hoping for £42,000" | Say £42,000, then stop. If she asks for a range or flexibility, answer with the floor you set before the call. That number is yours to decide. | F9. Inside the advert's range, so no need to apologise for it. |
| C2 | "What's your notice period?" | TERMS | none given. Answer slot | Answer slot: give the period from your contract. If it is unclear, say you will confirm it in writing rather than guess. | F10. The only open gate. |
| C3 | "The role is two days a week at Avonmouth. How does that work for you?" | TERMS | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Two days is fine. If asked, three is your ceiling. | F8. Term met. |

## Reverse questions

Ask any four. R5 she has already said she will cover.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like at six months?" | Shows what the role is measured on, so you can compare it to the weekly dispatch report. |
| R2 | "How is the weekly on-time dispatch report used, and who reads it?" | Tells you whether the report drives decisions or is a formality. It also lets you say what you would measure. |
| R3 | "How do planning, the warehouse and QA work together day to day?" | Shows how much of the scheduling is coordination and how much is sign-off. |
| R4 | "Which days are the office days at Avonmouth for the team?" | Pins down the hybrid pattern you would be committing to. |
| R5 | "What are the next steps and timeline after this call?" | She said she would cover this. Asking confirms the date. |

## Sources

- Provided: your message (background, the four terms, the Thursday call) and the advert text.
- Research: none run. Tier L0. The questions were answerable without it.

## Upgrade menu

- Your notice period, confirmed from your contract → closes the open gate in F10 and C2.
- A salary floor you decide before the call → turns C1's answer slot into a scripted range.
- What the spreadsheet does (formulas, reports, lookups) → upgrades F6 from medium to high.
- An L1 research sweep (about six searches, two page fetches) → Quillmoor's published details and a Bristol salary check for ops roles.
