Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/haiku/e23/part-7/rooms/case-13-denied-f93e2c65/quillmoor_operations-coordinator_interview_pack.md`. The full pack is below.

# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30 minutes by phone to the mobile number on your application. Built from your message and the advert only. No research was run.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Two types appear here:

- **EXP**: what you actually did, and whether it holds up when someone asks how.
- **JD**: whether you can do the listed job, gaps included.

The guidance is scaffolding, not a script. Say it in your own words, and stop where the scaffold stops.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | "Four years as a logistics coordinator at a building-supplies wholesaler." |
| F2 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | "I chase suppliers when orders slip." Same words, no added practice. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | "I schedule deliveries for our three depots." Your material shows delivery scheduling, not production scheduling, and no planning or QA work. Answer slot: if you have worked alongside production planning or QA in any way, say how; if you have not, say so. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The sentence as it stands. A headline figure, so expect a probe on how it was counted (C1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Nothing in your material shows a dispatch report. Answer slot: if you have produced any weekly delivery or dispatch measure, say what it measured; if not, say so and how you would build one. |
| F6 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The rebuild suggests Excel use but does not show a level of proficiency. Answer slot: name what you built in it, in your own words, and rate yourself no higher than that. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | high | [grounded] | capability | "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as past experience. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | "I'm hoping for £42,000." Inside the advert's range; the gate is met. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | "Two days at Avonmouth is fine." Inside the pattern; the gate is met. |

Notice period is not in the advert, and your material does not include it. It is handled in A4, not in the snapshot.

## Prohibited claims

These are not to be coached, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the stock system" or "I ran stock control" | Inflated form of F4 | "I rebuilt our stock-count spreadsheet." Your material says the spreadsheet, not the system. |
| "I managed supplier performance" | Inflated form of F2 | "I chase suppliers when orders slip." |
| "I have worked with production planning and QA" | Inflated form of F3 | "I schedule deliveries for our three depots." |
| "I have SAP experience" | Negative you stated (F7) | "I haven't used SAP." |
| "The drop in discrepancies was my work alone" | Inflated form of F4's figure | "Discrepancies fell by about a third over a year." Your material does not show what else changed that year. |

## Persona weights

Relationship prior for a recruiter screen is conversational, with a light skeptic. No interviewer profile exists, so no adjustments apply.

| Persona | How it shows up on this call | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | A friendly walk-through, then motivation and logistics checks | High. Recruiter screens run in this register, and the four topics she named are scored even when casual | A 90-second background arc; treat the notice and hybrid questions as scored |
| Skeptic | "Why leave, why now" and the SAP and production gaps | High. Both gaps are visible in the advert and your message | Rehearse the SAP answer until it is plain; say the production and QA gap as it is |
| Data-driven prober | The "about a third" figure | Medium. One headline number is the only place the pack expects a probe | Know how it was counted, or say you don't |

The other personas (peer, case, pressure, values) are low-weight for a recruiter screen and are not drilled here. Depth follows weight: five questions for the top persona, three for each of the others. The pack runs to eleven questions, under the usual 18 to 26, because a 30-minute screen cannot use more.

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | About 90 seconds: the four years, the three depots and delivery scheduling, the supplier chasing when orders slip, then the stock-count spreadsheet last. Use those sentences as they stand and add nothing to them. | The opening biography, and the first check on F1 to F4. A fixed arc keeps the call short. |
| A2 | "What are you looking for in your next role?" | JD | [grounded] "I schedule deliveries for our three depots" | Name what the advert describes, and say how your delivery scheduling is the nearest match, in your own words. Do not claim the advert's duties beyond that. | A motivation opener tied to F3, so the match is stated before anyone tests it. |
| A3 | "Why are you looking to move now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those terms: the Bristol office closes next year, the only offer is relocating to Reading, and you would rather stay in Bristol. That is the whole answer. Add no view on Reading or on your current employer. | The motivation check every screen asks. A short, true answer does better than a long one. |
| A4 | "What's your notice period?" | JD | [generic] | State your notice period as a fact, and say what it means for a start date. Your material does not include it, so the figure has to come from you before Thursday. There is no rehearsed number here. | A knockout logistics check the recruiter named. The guidance makes no claim about you, so it needs no quote. |
| A5 | "How do you feel about two days a week at Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say two days is fine and that you live in north Bristol. Give the three-day ceiling only if asked, in those words. Do not agree to a day pattern you have not been given. | Hybrid is one of the four topics she named. The quote already states the constraint. |

### B. Skeptic (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | **Highest-ROI prep.** Rehearse this until it is flat: "I haven't used SAP. We ran our own in-house stock system." Then the plan, said as a plan: what you would ask for first and how you would learn it. Answer slot: if you have used any ERP, name it in your own words; if you have not, say so. Hold any follow-up by returning to the in-house system. | The advert lists ERP as a plus, and your material has a clear negative (F7). The words are the stated negative only. |
| B2 | "This role coordinates production between planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots" | Say what you did: you scheduled deliveries for three depots. Then say plainly that your material does not show production planning or QA work. Answer slot: if you have worked alongside production planning or QA in any way, say how; if you have not, say so, and say how you would learn the QA side first. | The advert's first duty and a transferability gap (F3). The question presumes production work the quote does not carry, so the second branch must allow that it never happened. |
| B3 | "What salary are you expecting?" | JD | [grounded] "I'm hoping for £42,000" | Say "£42,000" and then stop. It sits inside the advert's £38,000 to £44,000, so you can say that if it helps. Do not offer a lower figure or a range you have not set. | Pay is a term she named. The figure is inside the band, so no bridge is needed (F8). |

### C. Data-driven prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. How much of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | Defend the number in your own words, in four parts. How the discrepancies were counted: answer slot, if you know, say so; if you don't, say you don't. What it is sensitive to: answer slot, the same way. The assumption you would defend least: your own words. Which part was yours: you rebuilt the spreadsheet. Your material does not show what else changed that year, so do not claim the whole drop. | A headline figure on your background (F4). These four parts are the only slots a figure raises. |
| C2 | "How do you report on-time dispatch?" | JD | [grounded] the advert's own line, "report weekly on on-time dispatch" | Answer slot: if you have produced any weekly delivery or dispatch measure, say what it measured; if you have not, say so and how you would build a weekly report from the records you would have. Make no claim about past reporting. | F5 is a requirement with no evidence in your material. The coverage rule still needs a question for it. |
| C3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet". Derivation: the rebuild suggests Excel use but does not show a level. | Name what you built in it, in your own words, and rate yourself by that, no higher. Answer slot: if you have used formulas, pivots or lookups, name them; if not, say what you did use. | Excel is a stated requirement. The quote touches it without showing proficiency (F6), so the rating is yours to give, and no higher. |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | C1 |
| Report weekly on on-time dispatch | C2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1 |
| £38,000–£44,000 | B3 |
| Hybrid: two days a week at our Avonmouth site | A5 |

## Reverse questions

Ask these in the slot where she invites your questions, which is the team and next steps part of her call.

1. "What does a typical week look like across planning, the warehouse and QA?" Why it lands: it asks about the real job, and the answer shows where the production and QA side bites.
2. "How is on-time dispatch measured and reported today?" Why it lands: it turns the weekly report requirement into a question about current practice.
3. "Is SAP the system of record for stock and production, or is it something else?" Why it lands: it shows you know the gap and asks where the team actually works.
4. "How does the Avonmouth pattern work in practice: which days, and who sets them?" Why it lands: it treats the hybrid question as logistics, which is how she framed it.
5. "What are the next steps, and how long between them?" Why it lands: she named next steps for the end of the call, so the question is expected.
6. "Why is the role open: a new post or a replacement?" Why it lands: it asks about the job, not only the process.

## Sources

Provided only: your message and the advert. No search or fetch was run.

Research tier: L0. No search or fetch was run, so company values, the interview process and recent company news are not established.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values section. The pack was built at L0, so no values were established. |
| 2. Quillmoor interview process | unavailable | Persona weights and round structure. The pack takes the call's four topics from the recruiter's message. |
| 3. Quillmoor strategy and recent news | unavailable | Grounding brief: current site and dispatch context. |
| 4. Interviewer footprint (Hannah Lowther, Talent Partner) | unavailable | Interviewer read and a recruiter-specific reverse question. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period → the figure A4 needs before Thursday. Only you can supply it.
- Any ERP or stock system you have used besides SAP, in your own words → upgrades the answer slot in B1.
- Research at L1 on Quillmoor (values, recent news about the Avonmouth site) → a values section and a grounding brief, so the questions carry company-specific words.
- How the "about a third" was counted, from your own notes → the answer slots in C1 become specific, in your words.
- A one-line reply from Hannah on whether there is a later technical or practical stage → a process section, so the next round can be prepared.

---

Want a short drill? I'll play the recruiter's skeptic on B1 (the SAP question) and push on your follow-ups.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions.

Your notice period is the one thing I need from you before Thursday. What is it, and does it affect when you could start?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30 minutes by phone to the mobile number on your application. Built from your message and the advert only. No research was run.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Two types appear here:

- **EXP**: what you actually did, and whether it holds up when someone asks how.
- **JD**: whether you can do the listed job, gaps included.

The guidance is scaffolding, not a script. Say it in your own words, and stop where the scaffold stops.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | "Four years as a logistics coordinator at a building-supplies wholesaler." |
| F2 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | "I chase suppliers when orders slip." Same words, no added practice. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | "I schedule deliveries for our three depots." Your material shows delivery scheduling, not production scheduling, and no planning or QA work. Answer slot: if you have worked alongside production planning or QA in any way, say how; if you have not, say so. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The sentence as it stands. A headline figure, so expect a probe on how it was counted (C1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Nothing in your material shows a dispatch report. Answer slot: if you have produced any weekly delivery or dispatch measure, say what it measured; if not, say so and how you would build one. |
| F6 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The rebuild suggests Excel use but does not show a level of proficiency. Answer slot: name what you built in it, in your own words, and rate yourself no higher than that. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | high | [grounded] | capability | "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as past experience. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | "I'm hoping for £42,000." Inside the advert's range; the gate is met. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | "Two days at Avonmouth is fine." Inside the pattern; the gate is met. |

Notice period is not in the advert, and your material does not include it. It is handled in A4, not in the snapshot.

## Prohibited claims

These are not to be coached, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the stock system" or "I ran stock control" | Inflated form of F4 | "I rebuilt our stock-count spreadsheet." Your material says the spreadsheet, not the system. |
| "I managed supplier performance" | Inflated form of F2 | "I chase suppliers when orders slip." |
| "I have worked with production planning and QA" | Inflated form of F3 | "I schedule deliveries for our three depots." |
| "I have SAP experience" | Negative you stated (F7) | "I haven't used SAP." |
| "The drop in discrepancies was my work alone" | Inflated form of F4's figure | "Discrepancies fell by about a third over a year." Your material does not show what else changed that year. |

## Persona weights

Relationship prior for a recruiter screen is conversational, with a light skeptic. No interviewer profile exists, so no adjustments apply.

| Persona | How it shows up on this call | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | A friendly walk-through, then motivation and logistics checks | High. Recruiter screens run in this register, and the four topics she named are scored even when casual | A 90-second background arc; treat the notice and hybrid questions as scored |
| Skeptic | "Why leave, why now" and the SAP and production gaps | High. Both gaps are visible in the advert and your message | Rehearse the SAP answer until it is plain; say the production and QA gap as it is |
| Data-driven prober | The "about a third" figure | Medium. One headline number is the only place the pack expects a probe | Know how it was counted, or say you don't |

The other personas (peer, case, pressure, values) are low-weight for a recruiter screen and are not drilled here. Depth follows weight: five questions for the top persona, three for each of the others. The pack runs to eleven questions, under the usual 18 to 26, because a 30-minute screen cannot use more.

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | About 90 seconds: the four years, the three depots and delivery scheduling, the supplier chasing when orders slip, then the stock-count spreadsheet last. Use those sentences as they stand and add nothing to them. | The opening biography, and the first check on F1 to F4. A fixed arc keeps the call short. |
| A2 | "What are you looking for in your next role?" | JD | [grounded] "I schedule deliveries for our three depots" | Name what the advert describes, and say how your delivery scheduling is the nearest match, in your own words. Do not claim the advert's duties beyond that. | A motivation opener tied to F3, so the match is stated before anyone tests it. |
| A3 | "Why are you looking to move now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those terms: the Bristol office closes next year, the only offer is relocating to Reading, and you would rather stay in Bristol. That is the whole answer. Add no view on Reading or on your current employer. | The motivation check every screen asks. A short, true answer does better than a long one. |
| A4 | "What's your notice period?" | JD | [generic] | State your notice period as a fact, and say what it means for a start date. Your material does not include it, so the figure has to come from you before Thursday. There is no rehearsed number here. | A knockout logistics check the recruiter named. The guidance makes no claim about you, so it needs no quote. |
| A5 | "How do you feel about two days a week at Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say two days is fine and that you live in north Bristol. Give the three-day ceiling only if asked, in those words. Do not agree to a day pattern you have not been given. | Hybrid is one of the four topics she named. The quote already states the constraint. |

### B. Skeptic (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | **Highest-ROI prep.** Rehearse this until it is flat: "I haven't used SAP. We ran our own in-house stock system." Then the plan, said as a plan: what you would ask for first and how you would learn it. Answer slot: if you have used any ERP, name it in your own words; if you have not, say so. Hold any follow-up by returning to the in-house system. | The advert lists ERP as a plus, and your material has a clear negative (F7). The words are the stated negative only. |
| B2 | "This role coordinates production between planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots" | Say what you did: you scheduled deliveries for three depots. Then say plainly that your material does not show production planning or QA work. Answer slot: if you have worked alongside production planning or QA in any way, say how; if you have not, say so, and say how you would learn the QA side first. | The advert's first duty and a transferability gap (F3). The question presumes production work the quote does not carry, so the second branch must allow that it never happened. |
| B3 | "What salary are you expecting?" | JD | [grounded] "I'm hoping for £42,000" | Say "£42,000" and then stop. It sits inside the advert's £38,000 to £44,000, so you can say that if it helps. Do not offer a lower figure or a range you have not set. | Pay is a term she named. The figure is inside the band, so no bridge is needed (F8). |

### C. Data-driven prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. How much of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | Defend the number in your own words, in four parts. How the discrepancies were counted: answer slot, if you know, say so; if you don't, say you don't. What it is sensitive to: answer slot, the same way. The assumption you would defend least: your own words. Which part was yours: you rebuilt the spreadsheet. Your material does not show what else changed that year, so do not claim the whole drop. | A headline figure on your background (F4). These four parts are the only slots a figure raises. |
| C2 | "How do you report on-time dispatch?" | JD | [grounded] the advert's own line, "report weekly on on-time dispatch" | Answer slot: if you have produced any weekly delivery or dispatch measure, say what it measured; if you have not, say so and how you would build a weekly report from the records you would have. Make no claim about past reporting. | F5 is a requirement with no evidence in your material. The coverage rule still needs a question for it. |
| C3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet". Derivation: the rebuild suggests Excel use but does not show a level. | Name what you built in it, in your own words, and rate yourself by that, no higher. Answer slot: if you have used formulas, pivots or lookups, name them; if not, say what you did use. | Excel is a stated requirement. The quote touches it without showing proficiency (F6), so the rating is yours to give, and no higher. |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | C1 |
| Report weekly on on-time dispatch | C2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1 |
| £38,000–£44,000 | B3 |
| Hybrid: two days a week at our Avonmouth site | A5 |

## Reverse questions

Ask these in the slot where she invites your questions, which is the team and next steps part of her call.

1. "What does a typical week look like across planning, the warehouse and QA?" Why it lands: it asks about the real job, and the answer shows where the production and QA side bites.
2. "How is on-time dispatch measured and reported today?" Why it lands: it turns the weekly report requirement into a question about current practice.
3. "Is SAP the system of record for stock and production, or is it something else?" Why it lands: it shows you know the gap and asks where the team actually works.
4. "How does the Avonmouth pattern work in practice: which days, and who sets them?" Why it lands: it treats the hybrid question as logistics, which is how she framed it.
5. "What are the next steps, and how long between them?" Why it lands: she named next steps for the end of the call, so the question is expected.
6. "Why is the role open: a new post or a replacement?" Why it lands: it asks about the job, not only the process.

## Sources

Provided only: your message and the advert. No search or fetch was run.

Research tier: L0. No search or fetch was run, so company values, the interview process and recent company news are not established.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values section. The pack was built at L0, so no values were established. |
| 2. Quillmoor interview process | unavailable | Persona weights and round structure. The pack takes the call's four topics from the recruiter's message. |
| 3. Quillmoor strategy and recent news | unavailable | Grounding brief: current site and dispatch context. |
| 4. Interviewer footprint (Hannah Lowther, Talent Partner) | unavailable | Interviewer read and a recruiter-specific reverse question. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period → the figure A4 needs before Thursday. Only you can supply it.
- Any ERP or stock system you have used besides SAP, in your own words → upgrades the answer slot in B1.
- Research at L1 on Quillmoor (values, recent news about the Avonmouth site) → a values section and a grounding brief, so the questions carry company-specific words.
- How the "about a third" was counted, from your own notes → the answer slots in C1 become specific, in your words.
- A one-line reply from Hannah on whether there is a later technical or practical stage → a process section, so the next round can be prepared.
