# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday, 2pm, 30 minutes by phone with Hannah Lowther (Talent Partner), on your mobile number from the application. Built from your notes and the advert only. I didn't research Quillmoor beyond that, so this covers the role, not their culture or strategy.

## 1. Your 60-second pitch

> "I've spent four years as a logistics coordinator at a building-supplies wholesaler. I schedule deliveries across our three depots and chase suppliers when orders slip, so I'm used to keeping several parties moving to one timetable. I also rebuilt our stock-count spreadsheet, and over the year discrepancies fell by about a third. I'm looking at Quillmoor because this role joins scheduling, supplier chasing and stock accuracy, which is most of what I do now, in a production setting. I'm newer to manufacturing and ERP systems, and that's the part I'd want to learn quickly."

Say it in your own words. Every claim in it is one you've told me, so keep it to those.

## 2. The four topics Hannah named

**Salary**
- Your number: "I'm looking for around £42,000, depending on the full package."
- Advert range is £38,000–£44,000. £42k sits in the upper half, so you have some room. Don't name a floor.
- If she asks for a range first, ask what budget they've set for the role before you give one.
- Avoid "I'm flexible" without a number. It gives her nothing to work with.

**Notice period**
- Not in your notes. Know the exact figure before Thursday, and whether you can start sooner if it's negotiable.

**Hybrid pattern**
- "Two days at Avonmouth works well for me. I live in north Bristol and I'd prefer not to go beyond three."
- Then ask which days are expected. Production planning may want people on site on particular days.
- Only say "no more than three" if that's a real limit. Otherwise phrase it as a preference.

**Why you're moving (the honest answer)**
- "Our Bristol office is closing next year. The only offer I've had is relocating to Reading, and I'd rather stay in Bristol. That's why I'm looking now."
- Keep it short and factual. Don't criticise your employer or sound desperate.
- Stop there. Don't add extra reasons unless they're true and you want to share them.

## 3. Likely questions, with honest answers

| Question | Answer slot (your words) | What to avoid |
|---|---|---|
| "Any SAP or ERP experience?" | "No SAP. We use an in-house stock system, and I've been the one maintaining it. I'm confident learning a new ERP." | Claiming SAP or ERP use you don't have |
| "How comfortable are you with Excel?" | Describe what you actually built and used, e.g. the stock-count rebuild | "Advanced" without specifics. Be ready to say what you did with it |
| "Any manufacturing or QA background?" | "Not in manufacturing. I've worked to tight delivery schedules with suppliers, so I know what late inputs do to a timetable." | Implying you've worked with QA processes |
| "How do you handle late orders?" | Walk through your real steps: who you chase, how fast, what you escalate | Inventing a process |
| "Why this role?" | Link the advert's three tasks (schedules, supplier chasing, stock accuracy) to your experience | Generic enthusiasm with no link to the job |

## 4. Questions to ask Hannah

1. What does a typical week look like across planning, the warehouse and QA?
2. How is on-time dispatch measured at the moment?
3. Is the role new or a replacement? Who would I report to?
4. Which days are expected on site, and is that fixed?
5. What ERP do they use, and how is training done?
6. What's the budget for the role, and is there flexibility within it?
7. What are the next stages, and when would you expect to hear?

## 5. Before Thursday

- Check the mobile number on your application is current and you can answer from an unknown number.
- Pick a quiet place with a signal, and have your CV, the advert and this sheet in front of you.
- Note any changes to the booking and tell Hannah on LinkedIn, as she asked.

## Gaps and questions

- **Notice period:** what is it, and can it be shortened?
- **Excel:** what can you actually do? (e.g. lookups, pivot tables, formulas you built). I'd like specifics so the answer holds up under follow-up.
- **On-time or KPI reporting:** have you produced a regular report like the weekly on-time dispatch one? If so, what did it measure?

**Offers, one line each:**
- **Drill:** I can play Hannah and run the salary and "why are you moving" questions with follow-ups, then give feedback.
- **Dossier:** I can save this prep as a `tuesday-dossier.md` file if you'd like it kept with the application notes.

**Upgrade menu:** adding the notice period, your Excel detail, and any KPI reporting experience would let me sharpen the pitch and the Excel answer. Adding Quillmoor's own job description, if they've sent one, would show whether the advert is the full picture.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.