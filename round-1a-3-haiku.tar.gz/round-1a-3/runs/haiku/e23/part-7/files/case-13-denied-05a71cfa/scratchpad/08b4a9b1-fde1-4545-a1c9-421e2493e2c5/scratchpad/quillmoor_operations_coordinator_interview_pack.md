# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner. She will call the mobile number on your application.
**Candidate:** Sam

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the advert's requirements), CO (company knowledge), CASE (live problem). Logistics questions in a screen carry no type, because they score nothing beyond the answer itself.
- The guidance is scaffolding, not a script. Say it in your own words.
- Answer slots are instructions for the call. Answer whichever branch is true for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Met. Say the four years and the wholesaler, nothing added. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production schedules or QA. Words: "I schedule deliveries for our three depots." Answer slot: the advert puts planning, warehouse and QA together, so expect a probe there. If you have agreed a timetable across teams with different priorities, say which teams and how. If you haven't, say so plainly and say how you would learn the production side. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | none | Met. Say it in your own words. Do not add supplier numbers or outcomes. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Your material says the rebuild and the fall, and nothing about what else changed over the year. Do not say the rebuild alone caused the fall. If asked how the discrepancies were counted, see R7. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show reporting on dispatch performance. Answer slot: if you have reported on delivery or dispatch performance, say what you reported and how often. If you haven't, say so plainly and say how you would report it. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | discovery | The rebuild shows spreadsheet work. It does not show your Excel level. Answer slot: say which Excel features you used, in your own words. If you are not sure how to rate yourself, say so. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't used SAP." Then say what you did in the in-house stock system, in your own words. Do not call it ERP experience. |

**The pack's own observations, for you and not for the call:** your material shows no manufacturing site and no QA function. That is the biggest distance between your background and this role. It is also what the advert's "production schedules … and QA" line will press on.

## Prohibited claims

These are claims this pack will not coach, even though they sound like the natural next step.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have ERP or SAP experience" | Negative you stated (F7) | "I haven't used SAP." |
| "I owned production scheduling" | Inflated form of F2. The sentence you wrote says deliveries across three depots. | Your F2 quote at its own scope. Pack observation: your material says delivery scheduling, not production. |
| "The rebuild caused the drop in discrepancies" | Inflated form of F4. The sentence says the fall happened over a year, not what caused it. | Your F4 quote at its own scope. Pack observation: your material shows the fall, not its cause. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Recruiter (screen) | Salary, notice period, hybrid, reason for moving, then team and next steps. Short questions, notes taken. | High. Hannah listed this agenda in her message. | Give your number early and clearly. Keep each answer under about 60 seconds. End each answer on a fact, not an adjective. |
| Prober (CV figures) | Asks how a number was counted, or asks for specifics behind a CV line. | Low to medium. Most likely only if she passes your CV to the hiring manager, or if the screen runs long. | Say what you did, in your own words. If you don't know how a figure was counted, say so. |

## Question banks

Types are the five defined above. Logistics questions carry no type.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "What are your salary expectations?" | logistics | [grounded] "I'm hoping for £42,000." (your message) | Say the number first: "I'm looking for around £42,000." Before you give it, you can ask: "What's the budget for this role?" Do not go below your number to fit her range. The advert's range is £38,000–£44,000. | Her first topic. The number is yours, not a claim about your past. |
| R2 | "What's your notice period?" | logistics | none given | Your notice period is not in the material I have. Check your contract before Thursday and give the exact figure, plus your earliest start date if you know it. | A fact only you hold. Answer slot: the figure is yours to supply. |
| R3 | "The role is two days a week at Avonmouth. How would that work for you?" | logistics | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say the two days are fine and that you live in north Bristol. If she asks whether more days are possible, say you would prefer no more than three. Do not volunteer more than that. | The hybrid pattern is on her list. Your sentence sets the boundary. |
| R4 | "What's prompting you to look for a move?" | logistics | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say it factually, in those terms. Do not criticise the company. Then say what you want from the next role, in one sentence. | It is on her list. The sentence is already true and already yours. |
| R5 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Four years as a logistics coordinator at a wholesaler. Scheduling deliveries for three depots. Chasing suppliers when orders slip. Keep it to about 60 to 90 seconds, using only those beats. | Her open opener. What you say here decides which requirements she probes. |
| R6 | "This role coordinates production schedules across planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Say what you do: delivery scheduling across three depots. Answer slot: if you have agreed a timetable across teams with different priorities, say which teams and how. If you haven't, say so plainly and say how you would learn the production side. | F2 is the biggest gap. The advert raises it. |
| R7 | "Your stock-count rebuild cut discrepancies by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Answer slot: say how the discrepancies were counted, what the count is sensitive to, which assumption you would defend least, and which part was yours. If you don't know how it was counted, say so. | F4. A figure from your CV is the likeliest probe. Do not explain a method you cannot repeat. |
| R8 | "The role mentions SAP or a similar ERP. Have you used one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Hold: "I haven't used SAP." Then say what you did in the in-house stock system, in your own words. Do not call it ERP experience. | F7. Plain acknowledgment, then the nearest real thing. |
| R9 | "The role reports weekly on on-time dispatch. Have you reported on delivery performance?" | JD | none given | Answer slot: if you have reported on dispatch or delivery performance, say what you reported and how often. If you haven't, say so plainly. | F5. Your material is silent here, so the honest answer is yours to give. |
| R10 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Answer slot: say which Excel features you used on that spreadsheet, in your own words. If you are not sure how to rate yourself, say so. | F6. The advert asks for confidence, so give the level you actually have. |
| R11 | "What do you know about Quillmoor Diagnostics?" | CO | none given | This pack did not research the company. Before Thursday, read their website and the advert. Say two things you found, in your own words. | Common in screens. This is the gap the research tier would have filled. |

**Requirement coverage**

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | F1, R5 |
| Coordinate production schedules between planning, the warehouse and QA | F2, R6 |
| Track supplier deliveries and chase late orders | F3, R5 |
| Keep stock records accurate | F4, R7 |
| Report weekly on on-time dispatch | F5, R9 |
| Confident with Excel | F6, R10 |
| ERP experience (SAP or similar) a plus | F7, R8 |

## Reverse questions

Ask two or three of these. Each one shows you have thought about the role.

1. **"What's the budget band for this role, and how was it set?"** Why it lands: she has to name a figure before you commit to yours.
2. **"Are the two Avonmouth days fixed, or do they flex by week?"** Why it lands: it shows you have thought about the hybrid pattern in practice.
3. **"What does a coordinator here handle between planning, the warehouse and QA in a normal week?"** Why it lands: it gets you the real job, and it tests the gap in F2.
4. **"What would success look like after three months in this role?"** Why it lands: it gives you the measure the team will use.
5. **"What happens after this call, and roughly how long does each step take?"** Why it lands: it tells you the timeline and shows you are planning around it.

## Sources

- Provided documents: Hannah Lowther's LinkedIn message, the advert text, and your notes.
- No search or fetch was run for this pack.

**Research tier: L0, no searches or fetches run**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet. Not run: research was not consented to in this session. |
| 2. Quillmoor interview process | unavailable | Confirmation of whether the screen is followed by a hiring-manager round. Not run. |
| 3. Quillmoor strategy / recent news | unavailable | Current company context for R11 and the reverse questions. Not run. |
| 4. Interviewer footprint (Hannah Lowther) | unavailable | Interviewer read. Not run. A recruiter's public footprint is low-yield for a screen. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Company research at L1 (values, interview process) → a values section and confirmation of the loop structure.
- Your notice period → R2 becomes a stated figure instead of an answer slot.
- Your dispatch reporting and Excel level → F5 and F6 move from discovery to a stated answer.
- Hannah's own words on focus areas or next steps → the reverse questions can be tuned to what she has said.
- A `tuesday-dossier.md` from an earlier job-underwriter run, if you have one → sharper objections and a checked prohibited list.
