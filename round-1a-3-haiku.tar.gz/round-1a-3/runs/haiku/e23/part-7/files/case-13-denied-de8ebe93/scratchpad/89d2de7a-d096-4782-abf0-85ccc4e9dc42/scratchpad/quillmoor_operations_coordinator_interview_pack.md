# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, 30 minutes by phone, with Hannah Lowther (Talent Partner). Candidate: Sam.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your own experience), JD (the advert's requirements), CASE (a live problem). Logistics questions are knockouts, not scored by type.
- Guidance is scaffolding, not a script. Say it in your own words.
- Your agenda, in Hannah's order: salary, notice period, hybrid pattern, reason for moving, then the team and next steps.

## Prep triage

1. Settle your notice period before Thursday. Your material doesn't state it, and she will ask first.
2. Rehearse A9 (SAP and production). It is the most likely objection and the highest-return prep.
3. Know the one-third figure (A8) cold: what it counts and what it does not.
4. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | Meets the requirement directly. Lead with it. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across depots, not production planning or QA. Stay at that scope: "I schedule deliveries for three depots." Answer slot: if any of your scheduling touched planning or warehouse handoffs, say how; if not, say so plainly and describe what you did schedule. |
| F3 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | high | [grounded] | none | Direct match. Use your own words for how you chase. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | presentation | The quote reaches the requirement. The figure is a probe target, so know how it was counted (A8). |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The material shows a spreadsheet rebuild but does not show your Excel level. Answer slot: describe what the spreadsheet tracks and what you built, in your own words. Do not claim specific functions you did not use. |
| F6 | "weekly report on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on dispatch reporting. Answer slot: if you reported on delivery timing, say what and how often; if you did not, say so and say what you would report first. |
| F7 | "ERP (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A plus, not a requirement. Say the plain acknowledgment: "I haven't used SAP." Then your in-house system. |
| F8 | Notice period, hybrid pattern (your plan) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Logistics, not a requirement. Notice period is not yet stated. |

**Limits the material shows (pack observation, not words for you):** your material says deliveries, not production scheduling; it says the stock spreadsheet, not Excel skills; it says nothing about dispatch reporting.

## Prohibited list

Claims this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Production planning or QA coordination experience | Inflated form of F2 | "I schedule deliveries for our three depots." The limit: your material says deliveries, not production. |
| SAP experience of any kind | Negative you stated (F7) | "I haven't used SAP." Then your in-house system, at its own scope. |
| An exact percentage such as "33%" | Inflated form of F4 | "About a third over a year." Use the figure as you know it. |
| The spreadsheet alone caused the drop | Inflated form of F4 | "I rebuilt the stock-count spreadsheet, and discrepancies fell over that year." Don't claim it was the only cause unless you know that. |

## Persona table

| Persona | How it shows up in this call | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport | Friendly opener, "walk me through your background", casual questions about the role | High | Recruiter screen prior: conversational, with logistics checks | Pre-script a 90-second background (A1). Treat casual questions as scored. |
| Skeptic | "Why should we move you forward without SAP?", "why this role?", "why now?" | High (highest-return) | Recruiter screen prior: light Skeptic. The advert's production and SAP lines are where your material is thin | Rehearse A9 until it's boring. Bridge from what you did, then say the limit plainly. |
| Data-Driven Prober (light) | "How was the one-third counted?" | Medium | Your figure is a headline number; recruiters check it | Know what counted as a discrepancy and over what period (A8). |

## Question bank

Ordered by weight. Provenance comes first and carries every quote the guidance rests on.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" — your message; "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | 90 seconds: four years in logistics coordination at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip. Stop there and let her ask. | The opener. F1 and F3 meet the advert's first two lines. |
| A2 | "What are your salary expectations?" | Logistics | [grounded] "I'm hoping for £42,000." — your message | Say: "I'm hoping for £42,000." Then stop. If she asks about flexibility, say the advert's range is £38,000–£44,000 and you'd look at the whole package. | Her first agenda item. Do not give a range below the one you chose. |
| A3 | "What's your notice period?" | Logistics | none given. Answer slot: state the period in your contract | Give the exact period from your contract. If it's longer than she expects, say so and say what you've agreed with your current employer, if anything. | Knockout item. Not in your material yet (see the upgrade menu). |
| A4 | "How would the two days at Avonmouth work for you?" | Logistics | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | "Two days at Avonmouth works; I'm in north Bristol." If she asks about more days, say three is the most you'd want. Don't offer three unprompted. | Hybrid is her third agenda item. The ceiling is for the offer stage, not the first answer. |
| A5 | "What's prompting the move?" | Skeptic | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | "Our Bristol office is closing next year, and the only offer is relocating to Reading. I'd like to stay in Bristol." No criticism of your employer. | The honest answer is also a strong one. Keep it short. |
| A6 | "Why this role, and why Quillmoor?" | JD | none given. Answer slot: say what draws you to this role, in your own words | Answer slot: your material does not yet show a reason for Quillmoor. Say what in the advert interests you, in your own words, and what you'd want to learn about diagnostics. | Likely follow-up to A5. "Closing office" alone reads as a bridge, not a motive. |
| A7 | "Our role coordinates production planning, the warehouse and QA. How does your background fit that?" | JD | [grounded] "I schedule deliveries for our three depots" — your message | Bridge from deliveries: "I schedule deliveries for three depots and chase suppliers when orders slip. That's the coordination side; I haven't done production planning or QA." Answer slot: if any of your scheduling touched warehouse or planning handoffs, say how. | F2. Name the limit yourself: it reads as honest, and she would find it anyway. |
| A8 | "You say discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | Weakest-assumption move: name, in your words, the assumption you'd defend least (for example, what counted as a discrepancy, or whether other changes happened that year). Answer slot: if you counted discrepancies a specific way, say how; if you didn't track it formally, say so and give the nearest figure you did track. | F4 is the headline number most likely to be probed. Know the method before she asks. |
| A9 | "You haven't used SAP. Is that a problem for this role?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." — your message | HIGHEST-ROI PREP. Hold: "I haven't used SAP. We run an in-house stock system, and I've used it to ..." — then say what you did in it, in your own words. If she presses, concede plainly: "I'd need to learn SAP; ERP is a plus here, not a requirement, and I'd be ready to learn it." Do not promise SAP skills. | F7 is a plus, so the honest case is adjacent work plus a learning plan. Hold through two follow-ups, then concede the gap without folding on your experience. |
| A10 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" — your message | Answer slot: describe what the spreadsheet tracks and what you built, in your own words. Don't claim advanced functions you didn't use. | F5. Specifics are yours to supply; the pack supplies none. |
| A11 | "Have you reported on on-time dispatch?" | JD | none given. Answer slot: if you reported on delivery timing, say what and how often; if not, say so and say what you'd report first | Answer slot as written in F6. | F6 is a stated requirement with no quote behind it. |

**Requirement coverage:** Hard requirement "2+ years" → A1. "production schedules" → A7. "track supplier deliveries and chase late orders" → A1. "keep stock records accurate" → A8. "confident with Excel" → A10. "weekly on-time dispatch reporting" → A11. "ERP (SAP or similar)" → A9.

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does this role spend most of its week on, and how do the planning, warehouse and QA handoffs run today?" | Shows you've read the advert closely; tells you where the gaps are negotiable. |
| "Which two days would be in the office, and is Avonmouth fixed?" | Confirms the hybrid pattern before the offer stage. |
| "What does the process look like from here, and who is the next person I'd speak to?" | Covers next steps, which she said she'd cover. |
| "Is the £38,000–£44,000 range fixed for this role?" | Tests salary room without anchoring lower. |
| "What would success look like in the first 90 days?" | Peer-style question that signals you're thinking about the job, not just the offer. |

## Sources

Research tier: L0 — no searches or fetches run. Provided documents only: the advert and your message.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Quillmoor values | unavailable (L0) | No values section in this pack. |
| 2. Quillmoor interview process | unavailable (L0) | Loop structure. Not in this pack. |
| 3. Quillmoor strategy / news | unavailable (L0) | Grounding brief. Not in this pack. |
| 4. Hannah Lowther, public footprint | unavailable (L0) | Interviewer read and a tailored reverse question. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot. |

## Checklist for the call

- Phone on, charged, in a quiet room. Your application and this pack open.
- Notice period confirmed from your contract (A3).
- Salary line ready: "I'm hoping for £42,000." (A2)
- Hybrid line ready: two days works; three is the ceiling. (A4)
- Closing-office line ready, short. (A5)
- One clear answer on SAP (A9) and one on the one-third figure (A8).
- Five reverse questions picked; at least two asked.
- Ask Hannah for the next step and a timeline before you hang up.

## Upgrade menu

- Your contractual notice period → a firm answer to A3 (the pack cannot supply it).
- How the one-third figure was counted (baseline, what counted as a discrepancy, the period) → A8 becomes a rehearsed answer, not a slot.
- Your Excel use and what the stock spreadsheet tracks → A10 and F5 become `[grounded]`.
- Any dispatch reporting you did → A11 and F6 gain a quote.
- The team or hiring manager's public profile → a tailored reverse question and the interviewer read.
