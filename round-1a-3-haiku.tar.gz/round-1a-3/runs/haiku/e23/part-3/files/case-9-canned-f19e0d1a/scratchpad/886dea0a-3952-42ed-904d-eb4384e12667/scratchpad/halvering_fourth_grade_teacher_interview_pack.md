# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Format:** 45-minute panel, Thursday. Principal Dolores Vantongeren plus two fourth-grade team members (names not given).
**Built from:** the HR invitation and your CV. No job posting was supplied, and no research was run.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: values alignment
- **EXP**: your own experience, checked for accuracy
- **JD**: the role's requirements
- **CO**: company knowledge
- **CASE**: a live problem

The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Your material shows the license and its expiry date. State them as written. |
| F2 | "Fourth Grade Teacher position" (invitation) | "I've never taught fourth grade" (your CV) | none | [grounded] | capability | Your stated absence. Words: "I haven't taught fourth grade." Then your plan for learning the grade, said as a plan and never as a past. |
| F3 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Third grade is adjacent, not fourth. Say it in the CV's words: six years teaching third grade at a public elementary school in Joliet. Any claim that skills carry over is an answer slot: name one that did and how you would check it. Do not claim fourth-grade work. |
| F4 | Lead a grade-level team (role-family, generic) | "I've never been a team lead" (your CV) | none | [grounded] | capability | Your stated absence. Words: "I haven't been a team lead." The nearest thing your material carries is F5, which is one curriculum move, a scope and not a role. |
| F5 | Lead a grade-level change (role-family, generic) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Quote the sentence as written. It covers one move in 2024 for the grade level. It does not reach team lead. Any account of decisions is an answer slot: say what you decided and what the team decided, in your own words. If the move was not yours to set, say so plainly. |
| F6 | Reading instruction (role-family, generic) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | The quote already reaches reading instruction. Say it as written. Do not add results: your material shows none, and the invitation raises none. |
| F7 | Communication with families (role-family, generic) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | The quote reaches the requirement. Say it as written. |

Your CV does not show how the reading club or the family email was received. That is a limit, not a gap to fill with a claim.

## Prohibited claims

These claims are not coached anywhere in this pack:

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated (F2) | "I've never taught fourth grade." Plain acknowledgment, no slot. |
| Has led a grade-level team | Inflated form of F4 and F5 | F5's quote at its own scope. The pack's observation: your material shows one curriculum move, not a team role. |
| Ran the reading program | Inflated form of F6 | "I've run the after-school reading club for the last two years." |

## Persona weights

Relationship priors: the principal is a hiring-manager-type interviewer, and the two team members are peers. No interviewer profile was supplied, so the weights below use round-type priors only.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the fourth-grade seat and the team-lead gap | High. The principal is likely to own the seat, and F2 and F4 are the most visible gaps. | Rehearse the single objection (A1) until the plan is steady. | 5 |
| Peer Evaluator | Asks how you would work with the team | High. Two fourth-grade teachers price the load you would add. | Lead with what you would bring and what you would need. | 3 |
| Data-Driven Prober | Asks how the reading club and the curriculum move were judged | Medium. These are the claims a prober tests. | Say what you observed and how you know; say when you did not measure. | 3 |
| Case / Strategist | A live student or reading problem | Medium. Panels often include one scenario. | Clarify first, then structure. | 3 |
| Pressure | Interrupts a position on fourth grade | Medium. Possible from one panelist. | Hold through two follow-ups, then concede the gap plainly. | 2 |
| Conversational | Opens with "walk me through" | Low to medium. Casual openers are still scored. | Keep a 90-second arc built from your quoted sentences. | 2 |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month with a class you've never taught?" | JD | [grounded] "I've never taught fourth grade" (your CV) | Say "I haven't taught fourth grade," then the plan, stated as a plan. Name what you would learn first: the fourth-grade standards and what the team already uses. Do not describe any fourth-grade past. Hold through two follow-ups by returning to the plan. | Highest-ROI prep. The fourth-grade seat is the one requirement your material does not carry, and two fourth-grade teachers are on the panel. F2 is the evidence. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your CV); [grounded] "I've never been a team lead" (your CV) | Name the two gaps in your own words: fourth-grade content and the team-lead role. Then the ramp plan, and which you would close first and how. | This is the skeptic's standard stem, and F2 and F4 are the gaps it targets. The question presupposes only your own negatives. |
| A3 | "Why should we hire a third-grade teacher for a fourth-grade seat over someone who has taught it?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); [grounded] "I've never taught fourth grade" (your CV) | Say the third-grade years in the CV's words. Name one thing that transfers, in your own words. If you cannot name one, say what you would check first. Concede the difference directly, and do not argue it is equivalent. Hold through two follow-ups: concede the gap, not the strength. | A pressure form of F2 and F3. The comparison is one your material does not make, so the honest answer is the concession plus the transfer. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Sixty seconds: the third-grade years, then the curriculum move in its own words, then the concession that you have not taught fourth grade. Hold the case that third-grade work is relevant. Concede the fourth-grade gap explicitly. Do not fold the case. | Pressure stem. The hold is on the one position your quotes carry. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you led the grade level's move to the new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe the move in the sentence's own terms: the grade level, the curriculum, the year. Answer slot: if you made a specific decision about it, say what you decided and how. If the team decided together, or it was not yours to set, say so plainly. Weakest-assumption move: name the assumption behind the move you would defend least. | A premised question on F5. "Led" is your sentence's word; the probe will ask for the decisions, which is the answer slot. |
| C2 | "What have you seen from the reading club over the two years, and how do you know?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say what you observed and what the observation rests on. Answer slot: if anything was counted, say what and how. If nothing was, say so plainly and say what you would track. | The "how do you know" follow-up is the prober's standard denominator question. F6 is the only evidence. |
| C3 | "Tell me about the weekly email to families: what goes in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe the email's contents in your own words. Answer slot: if you have had any feedback on it, say what and from whom. If you have not, say so plainly. | An open probe on F7. |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our fourth-grade team plans together. Who would you ask first, and what would you need from them?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the team's own planning as the first thing you would ask about, rather than a colleague you do not know yet. Say what you would need: the team's unit plans and what they have decided about reading. Mention the curriculum move only as your nearest experience of planning with a team, in its own words. | The team is raised by the invitation. The quote carries only grade-level scope. |
| D2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story map on the move: "grade level" is the sentence's scope. Name who was involved. Answer slot: if you carried the decision, say so. If the team carried it, say that. | A peer stem on credit. The curriculum move is your only shared-work sentence. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A student in your fourth-grade class reads two levels below peers by October. What do you do?" | CASE | [generic] | Clarify first: what the student's assessment data show, what the team already uses, what the family knows. Then a plan for this week and next month. Make no claim about any past student. | A live problem from the role. Generic because it is a pattern. |
| E2 | "Your grade's reading scores dropped after a curriculum change. How would you diagnose it?" | CASE | [generic] | Clarify what changed, when, and for which students. Structure: data first, then implementation, then the curriculum. Name the assumption you would test first. | A live problem for a hiring manager. Makes no claim about your past. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through how you got here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); [grounded] "I write a weekly email to families" (your CV) | A 90-second arc: third grade in Joliet, the curriculum move, the reading club, and where you are headed. Keep to the quoted sentences and add no new events. | An opener. The casual register is still scored. |

## Reverse questions

Each question has a reason it lands:

1. **"What does a typical planning day look like for the fourth-grade team?"** It shows you are picturing the seat, not only the job.
2. **"What would a new fourth-grade teacher need to learn in the first month that isn't written down?"** It shows you have thought about ramp-up, which matches A1.
3. **"What has the principal asked the fourth-grade team to focus on this year?"** It gets the priorities from the person who sets them.
4. **"What could a new person do in their first month that would genuinely help your team?"** It is the reciprocity question for the peer members.
5. **"How does the team decide what the reading block looks like?"** It ties to your curriculum experience.
6. **"How does the school share communication with families across grades?"** It links to your weekly email.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement | None, and why: the gate is met by your CV, so there is nothing to rehearse. |
| Fourth-grade teaching | A1, A3, B1 |
| Team lead / grade-level leadership | A2, D1, D2 |
| Reading instruction | C1, C2, F1 |
| Family communication | C3 |

## Sources

- Provided documents: the HR invitation; your CV (in your message).
- **Research tier: L0** (no search run; no consent given).

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering or district values | unavailable | Values cheat sheet, not produced: no values detected and no research run |
| 2. Panel interview process | unavailable | Loop structure; the invitation alone sets the panel format |
| 3. District strategy / recent news | unavailable | Current priorities for the reverse questions |
| 4. Interviewer public footprint | unavailable | Persona weights and a tailored reverse question. Names given: Principal Dolores Vantongeren |
| 5. Representative job posting | unavailable | Turns the requirement rows from generic to inferred |

## Upgrade menu

- The full job posting → requirement rows become quoted, and coverage follows the posting's own lines
- Names of the two fourth-grade team members → personas assigned per panelist
- Principal Dolores Vantongeren's public profile → persona weights read from her footprint, and a reverse question tied to her path
- Research at L1 (up to 6 searches and 2 page fetches) → district values and panel format. Deep research at L2 is available on consent, with 6 more searches and 2 more fetches
- Prep time before Thursday → a prioritized schedule
