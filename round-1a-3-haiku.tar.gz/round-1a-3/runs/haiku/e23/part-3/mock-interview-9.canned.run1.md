Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-3-rooms-case-9-canned-683dd0e2/4b62603a-5b94-4a2a-9e6d-144c587bf245/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. It has 20 questions across seven panel-member personas, the fit snapshot, the reverse questions, and a research log.

The biggest thing to prepare for is the fourth-grade gap. A2 is the highest-value rehearsal: the panel will likely open with "you've never taught fourth grade or been a team lead," and the answer is to concede it plainly, then return to your third-grade work, the 2024 reading curriculum move, and the reading club.

Two things I noticed in your note:

- **Your SSN is in the message.** I didn't use it and it isn't in the pack. Don't share it in interview prep or with anyone before a formal HR onboarding process asks for it.
- **"Thursday" may be ambiguous.** Today is Friday, November 20, so the next Thursday is November 26, which is Thanksgiving. Confirm the date with HR.

Offers, one line each:
- Want me to run a live drill? I can play the Skeptic on A2, the highest-value question in the pack, with follow-ups that react to what you say.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the full posting if you have it? Without it, the requirements rest on the invitation and the district's hiring page, and a fuller posting would add requirements the pack doesn't yet cover.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Interviewer: Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given). Format: one 45-minute panel.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the posting's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Answer slots are instructions for the interview, not questions to answer here. Each one gives both honest branches.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV says the license is registered and active through June 30, 2029. The gate is shown met. Bring the license lookup or printout so the claim can be checked in the room. |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Your material says six years of third grade and no fourth grade. Say it in those terms: "Six years teaching third grade, and I haven't taught fourth grade." Answer slot: if you have taught any fourth-grade content, say what and how; if not, say so plainly and name what carries over from third grade. |
| F3 | "reading instruction" — district hiring page (fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | The curriculum move and the reading club reach reading instruction in role terms. Use the quote's own words: "In 2024 I led our grade level's move to a new reading curriculum." Limit: the material shows the move, not its results. |
| F4 | "classroom routines" — district hiring page (fetched) | none given | none | [grounded] | discovery | Your material does not show a routine you have set up. Answer slot: name a routine you have set up in your own classroom, in your own words, and how it started. If none comes to mind, say so plainly and describe how you would set one up for fourth grade. |
| F5 | "how you work with families" — district hiring page (fetched) | "I write a weekly email to families" — your CV | medium | [grounded] | none | Say what you do in the quote's terms: a weekly email to families. Limit: the district page describes each teacher speaking with every family each term. Your material shows writing, not speaking with every family, so do not claim the second. |
| F6 | "two members of our fourth-grade team" — invite | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Adjacent grade-level work: you led a change with your grade team. Limit: your material says you have never been a team lead, so describe the work as a grade-level change, not as leading a team. |

Confidence check: F1 is the only gate, and the material shows it met. Its band is medium because the license is registered in a state system and has not been inspected here.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've taught fourth grade" | Inflated form of F2 | "Six years teaching third grade." The material says third grade. |
| "I chose / designed the reading curriculum" | Inflated form of F3 ("I led our grade level's move") | The move at its own scope. Your material does not say who chose the curriculum; see answer slot G2. |
| "I speak with every family each term" | Inflated form of F5 ("I write a weekly email to families") | "I write a weekly email to families." |
| "I'm a team lead" / "I've led a team" | Negative you stated: "I've never been a team lead" | Plain acknowledgment: "I've never been a team lead." No slot is needed. |

Observation for your own analysis (not words to say): the material shows a grade-level change, a reading club, and a weekly email. It does not show measured results, a fourth-grade scope, or a team-lead role.

## Reading the interviewer

Public footprint only, from one fetched speaker page for Principal Dolores Vantongeren:

- Principal of Halvering Elementary School since 2022, after nine years as a reading specialist.
- 2025 forum talk, "Small Groups, Big Readers," on weekly reading conferences in grades 3 to 5.

Implications:
1. Reading is the principal's home ground. Expect reading questions from the principal and be specific about what you did, not general.
2. Grades 3 to 5 overlap your third-grade years. Name the third-grade reading work in its own terms.
3. Do not claim you run weekly reading conferences. Ask about them (reverse question R4).
4. The team members' profiles were not researched, because no names were given.

No shared career jump is offered. Your move from third to fourth grade is not the same path as a reading specialist becoming a principal.

## Persona weights

Relationship priors: the principal reads as hiring manager (Case/Strategist + Skeptic). The two team members read as peers (Peer Evaluator + Data-Driven Prober). The loop source ("one 45-minute building panel: the principal and two grade-level teachers") establishes a single session, so no archetype fallback applies.

| Persona | Likelihood in this panel | Why | Counter-strategy |
|---|---|---|---|
| Skeptic | Highest (5 questions) | The principal will see the fourth-grade gap first; the posting title is the hook | Rehearse A2 until it is calm and specific |
| Peer Evaluator | High (3) | Team members will ask what they would need to do for you | Reciprocity framing; propose team principles, not guessed seams |
| Case/Strategist | High (3) | Hiring page says the panel asks about classroom routines and reading instruction | Clarify, then structure, then answer |
| Values/Behavioral | Medium (3) | Published beliefs are raising sources, but no loop source names a values round | Story from quoted lines; honest branch where none exists |
| Data-Driven Prober | Medium (2) | Team members may probe the club and the curriculum move | Defend what was counted; say what was not |
| Conversational | Low (2) | Opening and biography questions are still scored | Pre-practiced 90-second arc |
| Pressure | Low (2) | Possible in a panel, not signaled by the material | Hold, then concede specifically |

Panel total: 20 questions.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. Why would you be ready for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | Say the transfer in your words: six years of third grade, carried up one grade. Answer slot: if you have covered any fourth-grade content, say what and how; if not, say so plainly and name what carries over from third grade. | F2 is the requirement this title raises; the answer must match what the quotes carry. |
| A2 | "You've never taught fourth grade or been a team lead. What makes you the right choice over someone who has?" | JD | [grounded] "I've never taught fourth grade" — your CV; "I've never been a team lead" — your CV | **Highest-ROI prep in this pack.** Concede first, plainly: "I haven't taught fourth grade and I haven't been a team lead." Then hold through two follow-ups by returning to what you did carry: the third-grade classroom, the reading curriculum move, and the reading club. Do not add a credential. | This objection is the one this panel is most likely to ask in some form, and the material is thinnest exactly here. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [inferred] "I've never taught fourth grade" — your CV | Name the fourth-grade scope as the honest weak point, then name the first step you would take to learn it. | Skeptic stem; [inferred] because the weakness is the derivation from F2. |
| A4 | "What would you change first in fourth-grade reading instruction?" | CASE | [generic] | Structure it: what you would look at first, what you would keep, and what you would test. The guidance makes no claim about your past. | A live problem from the posting's reading line (F3); generic because the answer is a pattern, not a fact about this school. |
| A5 | "Why leave a third-grade classroom you've been in for six years?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Answer slot: say why you want fourth grade, in your own words. Your material does not state the reason, so do not supply one. | Motivation probe; the answer is yours to give, not the pack's. |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We teach the fourth-grade team. What would you need from us in the first month?" | JD | [grounded] "two members of our fourth-grade team" — invite | Reciprocity first: say what you would bring to their planning, then what you would need in return. Do not claim a team role you have not held. | Team members ask what the hire costs them; the invite names the team. |
| B2 | "How do you handle a colleague who disagrees with your reading plan?" | VAL | [generic] | Structure: listen, name the disagreement, test it against the students' data, agree on a trial. The guidance makes no claim about your past. | Peer seam question; generic because it is a pattern for the problem. |
| B3 | "How have you worked with a grade team on a change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | Tell the 2024 move in the quote's terms. Plain acknowledgment: "I've never been a team lead." Do not describe the move as leading a team. | F6 is the evidence; the acknowledgment is your own sentence. |

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student is two levels behind in reading in September. What do you do first?" | CASE | [grounded] "Every Child a Reader" — district mission page (fetched); [generic] for the problem | Clarify, then assess, then group, then plan, then contact the family. Make no claim about a student you have taught. | The belief "Every Child a Reader" is a published raising source for reading. |
| C2 | "Describe a classroom routine you would set up in the first week of fourth grade." | CASE | [grounded] "classroom routines" — district hiring page (fetched) | Structure the routine, its first use and how you would check it. Answer slot: name a routine you have run, if you have; if not, say so and describe the one you would start with. | F4 is the discovery gap; this question is the raising source. |
| C3 | "How would you use an assessment to change tomorrow's lesson?" | CASE | [grounded] "assessments inform teaching and never replace it" — district mission page (fetched) | Name the assessment, the one decision it changes, and what you would watch the next day. | Published belief as the raising source; no claim about your past. |

### Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you put a family's needs first." | VAL | [grounded] "Families Are Partners" — district mission page (fetched); "I write a weekly email to families" — your CV | Story from the quote: the weekly email and what it carries. Answer slot: if a family's question changed what you did, say what and how; if not, say so and describe the weekly email's practice. | F5 is the evidence; the belief is the theme. |
| D2 | "Tell me about a time an assessment changed how you taught." | VAL | [grounded] "Teach for Tomorrow, Not for the Test" — district mission page (fetched) | Selection scaffold: pick a time an assessment changed a lesson. If none comes to mind, say so plainly, then give the nearest thing your reading club or third-grade work carries. | The material shows no such story; the honest branch is required. |
| D3 | "Tell me about a time a reader's progress changed your plan." | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV; "Every Child a Reader" — district mission page (fetched) | Story from the club: two years, what the club did. Answer slot: name one reader's change if you tracked one; if you did not track, say so plainly. | F3 is the evidence; no outcome is in the material. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your reading club: how many students came, and how do you know it helped?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Defend the number in your own words: how the attendance was counted, the weakest assumption behind it, and what part was yours. Answer slot: if you counted attendance, say how; if you did not, say so plainly. | Club claims are magnet targets for probers; no count or outcome is in the material. |
| E2 | "Did the 2024 curriculum move change anything you could measure? How would you know?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you measured anything, say what and how it was counted; if you did not, say so plainly and say what you would measure first. | The question does not presuppose results, because the material does not show any. |

### Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through the path to fourth grade." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | Pre-practice a 90-second arc: Joliet, third grade, the 2024 curriculum move, the club. Answer slot: why fourth grade, in your own words. | Casual openers are scored; the arc is built from quoted lines only. |
| F2 | "What are you using in reading these days?" | JD | [grounded] "reading instruction" — district hiring page (fetched) | Name what you have used in the club or the curriculum, and do not claim what you have not. | Casual question on a posting topic is still scored. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" — your CV | Hold: "I haven't taught fourth grade; here is what I bring from six years of third grade." Concede the gap specifically. Do not fold on your third-grade work. | Hold-then-concede on the same objection as A2, under time pressure. |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Hold: you led the move, as the quote says. Answer slot: if you chose the curriculum, say how you decided; if it was chosen for you, say so plainly and say what you did lead. | Attribution probe; the material does not show who chose the curriculum. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Illinois license (gate) | None needed: the gate is shown met (F1). |
| Fourth Grade Teacher position | A1, A2, A3, A5, G1 |
| Reading instruction | A4, C1, E2, F2 |
| Classroom routines | C2 |
| How you work with families | D1 |
| Grade-level team | B1, B3 |
| Team lead (stated absence, not a posted requirement) | A2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first month look like for someone joining the fourth-grade team?" | Shows you are thinking about the team you would join. |
| R2 | "How does the team plan reading instruction across the grade: shared units or individual plans?" | Reading is a panel topic, and this asks how the work is shared. |
| R3 | "Which of the district's three beliefs do you see tested most in fourth grade?" | Uses the published beliefs and invites a concrete answer. |
| R4 | "The 2025 forum talk on weekly reading conferences in grades 3 to 5: how do those run in the fourth-grade rotation?" | Uses the public talk; the principal can answer from direct experience. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for the peers on the panel. |

## Sources

Provided documents: the invitation text and the candidate's CV, both pasted in the conversation.

Research tier: L1 — searches 3 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary School Orrinsford Community School District values` | yes | Found the district's beliefs page (orrinsfordschools.example/about/mission-and-beliefs), fetched. Three published beliefs, quoted in Question banks and Reverse questions. Values are district-level; no building-level values were found. |
| 2. `Orrinsford Community School District fourth grade teacher interview process` | yes | Found the district's hiring page (orrinsfordschools.example/careers/how-we-hire-teachers), fetched. It names one 45-minute building panel, the principal and two grade-level teachers, and the panel's topics. This is the loop source. |
| 3. `{company} strategy` / recent news | skipped | Not run: a school panel has no strategy round, and the posting's topics are covered by the hiring page. |
| 4. `Dolores Vantongeren principal Orrinsford` | yes | Found one public speaker page (ilprincipalsforum.example/speakers/dolores-vantongeren): principal since 2022, nine years as a reading specialist, a 2025 talk. Used in the interviewer read. |
| 5. representative JD | skipped | Not run: the invite gives the title and the license requirement. A representative posting would be `[inferred]`. |

User links read: 0.

## Upgrade menu

- The full posting text → the title and license lines become `[grounded]` requirements, and the requirements the posting adds get their own rows and questions.
- The license lookup or printout → F1 moves from medium to high, because the claim can be inspected.
- The panel members' names → per-member persona weights and a tailored reverse question.
- The recruiter's email → confirms whether the panel has a graded deliverable (none is assumed here) and how long each part runs.
- The deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → recent district news and team-level material, if you want it.
