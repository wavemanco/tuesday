Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-3-rooms-case-9-canned-9d0b7ca8/e10d2ea6-e68a-4291-99d6-2ec506a2c00d/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it as a panel round: the principal plus two grade-level teachers. I used the district's own "How we hire teachers" and mission pages, and one representative fourth-grade posting.

I left your SSN out of the pack. A panel doesn't need it, and it shouldn't sit in prep files.

The highest-ROI prep is question A1, "You've never taught fourth grade. Why would this team take that risk?" The invite makes it the most likely question. The pack gives you the plain sentence to say, then your six years of third grade in Joliet to stand on. Please rehearse only what you did.

Two offers, neither pushed:
- I can play the principal on A1 in a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Do you have the full posting text for this job? If you send it, the pack can quote the real requirements instead of the search snippet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Panel interview, 45 minutes, Thursday (the invite gives no date). Panel: Principal Dolores Vantongeren plus two fourth-grade team members (names not given).

Built as a panel round. Assumption: no full posting was supplied, so requirements come from the invite, the district's own pages, and one representative posting (search result only, not fetched).

## How to use

Personas describe how a question is asked. Types describe what is scored: **VAL** values, **EXP** your experience, **JD** the role, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding for a spoken answer, not a script. Say only what you did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (your message) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate met on your own statement, and the quote reaches it in full. Limit: no inspectable copy yet. Bring the license printout or check the state lookup before Thursday. |
| F2 | Teach the fourth-grade year: the role is "Fourth Grade Teacher" (your message) | "I've never taught fourth grade and I've never been a team lead." (your CV) | high | [grounded] | capability | A gap you stated, so the pack may give the words back: "I haven't taught fourth grade." Then the nearest record your CV carries: "Six years teaching third grade at a public elementary school in Joliet." The closure is a plan, said as a plan and never as a past. |
| F3 | Work with the grade-level team (representative posting, [inferred], unquoted) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Adjacent work: the quote is a grade-level move, not a team-lead role. Say it at that scope. Limit, from you: "I've never been a team lead." Answer slot: if you made a decision on that move, say which; if not, say what your part was. |
| F4 | Plan and teach reading (representative posting, [inferred], unquoted) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "Six years teaching third grade at a public elementary school in Joliet." (your CV) | medium | [grounded] | none | The quotes reach reading instruction in role terms. Limit: the teaching was third grade, not fourth. |
| F5 | Differentiate instruction using assessment data (representative posting, [inferred], unquoted; the panel page names reading instruction) | none given | none | [inferred] | discovery | Your material does not show assessment use. Answer slot: if you used an assessment result to group or plan reading, say which and what changed; if you did not, say so and say how you would use one. |
| F6 | Classroom routines ("classroom routines", district panel page, fetched) | none given | none | [grounded] | discovery | Your material does not show routines. Answer slot: if a routine you ran in third grade carries over, say which; if you have none to point to, describe the one you would set. |
| F7 | Work with families ("how you work with families", district panel page, fetched) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | The quote reaches family communication. Say only that you write it. Do not claim how families responded. |

## Reading the interviewer

**Dolores Vantongeren, Principal.** Public listing: principal of Halvering Elementary since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.

- Reading is her home ground. Expect reading questions with a specialist's precision.
- Her talk is about grades 3 to 5, next to your third-grade record. The mirror is shared vocabulary around reading. Use her talk only if you have read it, and never claim her method as yours.
- No shared career jump: a reading specialist who became principal is not your path. No career-jump reverse question applies.

**Two grade-level team members.** No public footprint, so no read. Their personas follow the panel rule below.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic (principal) | The fourth-grade gap, the team-lead gap, "how much was you" | High. The invite is for a fourth-grade role, and your CV says you have not taught fourth grade. This is the most predictable question in the room. | Hold the plain sentence, then the third-grade record. Concede the exact gap in one line. | 5 (A) |
| Case/Strategist (principal) | A live reading or routines problem | High. The district's panel page names reading instruction and classroom routines. | Clarify, structure, first move. | 3 (B) |
| Peer Evaluator (grade team) | "What would you need from us," working through disagreement | High. Two grade-level members sit on the panel, and the team-lead gap makes collaboration the probe. | Ask for specifics. Say what you did, not what you decided for the team. | 3 (C) |
| Values/Behavioral (both) | The district's three beliefs | Medium. A values-style round is not detected: the loop source names reading, routines and families, not values. The published beliefs still raise these questions. | Map each belief to a quoted sentence, or give a selection scaffold. | 3 (D) |
| Data-Driven Prober (grade team) | "How did you know it worked" | Medium. Team members often test an answer's measurement. | Say what you measured and how, or say plainly that you did not. | 2 (E) |
| Conversational | The opener and the "tell us about yourself" slot | Medium. Panels usually open this way, and casual questions are still scored. | A 90-second arc. | 2 (G) |

Panel weighting: the principal carries Skeptic and Case; the grade team carries Peer and Prober. Total: 18 questions.

Requirement coverage:

| Requirement | Covered by |
|---|---|
| Valid Illinois license, elementary endorsement | None, and why: met on your statement. Confirm with the state lookup, not in the room. |
| Teach the fourth-grade year | A1, A2 |
| Plan and teach reading | B1, E1, D1 |
| Writing, math, science, social studies (representative posting) | None, and why: the invite and the district's panel page do not raise them, so they earn no question. Check against the full posting. |
| Differentiate using assessment data | D3, E2 |
| Classroom routines | B3 |
| Work with families | D2 |
| Work with the grade-level team | C1, C2 |
| Team lead (your gap; not in the invite) | A3, C2 |

## Question banks

Highest-ROI prep: **A1.** It is the most likely question in this round, and it is the one where a non-defensive answer changes the interview.

### A. Skeptic (principal), depth 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. Why would this team take that risk?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your CV) | Hold the fact first: "I haven't taught fourth grade." Then the nearest record: "Six years teaching third grade at a public elementary school in Joliet." Name one thing you would do in the first month to close the gap, as a plan. Hold through two follow-ups by returning to the third-grade record. Never say you have taught any part of a fourth-grade year. Concede the exact gap in one sentence. | F2 is the capability gap, and this is its most likely form. Highest-ROI prep. |
| A2 | "What would you need in your first month to teach fourth grade well?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your CV) | An open plan answer with no past claim. Name two or three specific things you would ask the team for, in your words. | Follows F2 and asks for a plan, so the answer makes no claim about your past. |
| A3 | "Who made the calls on the reading move?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead." (your CV) | Plain acknowledgment: "I've never been a team lead." Then the quote at its own scope. Answer slot: if you made a call on the move, say which and why. If there was no such call, or it was not yours, say so plainly and describe what you did do on the move. | F3 is transferability, and this probe tests the widening from "led the move" to "led the team". |
| A4 | "How much of the 2024 reading change was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Stay with the sentence. Name what "led" covered, in your words: the part you ran and the part the team ran. Concede the shared part out loud. Hold through two follow-ups. Answer slot: if you chose or evaluated the curriculum, say how; if you did not, say so and describe the move's actual scope. | Attribution honesty under pressure. "How much was you" is the likely wording. |
| A5 | "Why leave third grade for fourth now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Your material gives no reason, so the answer has to come from you. Say it in one or two plain sentences. Answer slot: if your reason concerns the grade, the team, or the district, say which. If you cannot state it plainly yet, that is the prep to do before Thursday. Do not borrow the district's values as your reason. | The motivation probe. The material is silent, so the pack does not supply a reason. |

### B. Case/Strategist (principal), depth 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's week three. A student reads well below the rest of the fourth-grade group and has stopped working during reading. What do you do?" | CASE | [generic] | Clarify first: what the student's work and assessments show, and what the student says. Then structure: the student, the group, the family, the grade team. Give your first move, one thing you would not do, and what you would check a week later. Do not name a program or result you have not used. | A live problem from the panel's reading-instruction topic. It asks about no past, so it claims nothing about you. |
| B2 | "The grade team has a new reading curriculum, and two teachers are unhappy with it. What do you do?" | CASE | [generic] | Clarify what "unhappy" means: fidelity, pacing, or results. Look at the evidence the team holds, decide what to keep, and agree a shared test for the next decision. Say what you would want from the principal. | A live problem close to the grade-team collaboration the panel will weigh. No claim about your history. |
| B3 | "Walk us through your first week of routines in a fourth-grade classroom." | JD | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families." (district panel page) | Describe the routines you would set on day one, in order: arrival, transitions in the reading block, how work is turned in. Answer slot: if a routine you ran in third grade carries over, say which; if you have none to point to, describe the one you would set. | "Classroom routines" is a named panel topic on the district's own page. This covers F6. |

### C. Peer Evaluator (grade team), depth 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We work as a team. What would you need from us in your first month?" | JD | [grounded] "I've never been a team lead." (your CV) | Ask for specifics: unit plans, the assessment calendar, the shared reading schedule. For reciprocity, name what you would bring from the 2024 move, at the scope of your part. | Team-fit probe from the grade members. The question asks for what they need, so it claims nothing. |
| C2 | "When the team disagrees on a plan, how do you handle it?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use the move as the story only if there was disagreement in it. If there was, say how it was settled and what you did. If there was none, say so and describe how you would raise a disagreement with equals. Do not describe yourself as deciding for the team. | Collaboration probe. Grounded only on the quote; the team-lead limit applies. |
| C3 | "Where does your team's work meet the grades around it, and what happens when you disagree?" | JD | [generic] | Name seam principles, not facts about these teams: who owns what students carry from one grade to the next, and how you would settle a disagreement with the neighbouring team. | A peer seam question. Answered as principles, so no claim is made. |

### D. Values/Behavioral (both), depth 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Orrinsford's first belief is Every Child a Reader. What does 'no student leaves third grade without a reading plan' mean in your classroom?" | VAL | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." (district values page); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say the belief in your own terms. Then the 2024 move at its scope, in the quote's words. Answer slot: if you wrote reading plans for students, say what they held; if you did not, say so and say what you did for students who were behind. Never claim the plan was yours alone. | The district's page raises this belief directly. The question asks about your classroom, so the answer must come from you. |
| D2 | "Families are partners here, and each teacher speaks with every family each term. Tell me about a family conversation that went hard, and how you handled it." | VAL | [grounded] "I write a weekly email to families." (your CV); "Families Are Partners: each teacher speaks with every family each term." (district values page) | An open prompt: pick a real family conversation. Say what the weekly email does in your practice, then the conversation you choose. If no hard conversation comes to mind, say so plainly, then give the nearest thing and how you would handle one. Never claim the email drew a response. | The family-contact sentence in your material is the email. |
| D3 | "Teach for Tomorrow, Not for the Test says assessments inform teaching and never replace it. How do you use assessments without letting them run the class?" | VAL | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district values page) | Name one assessment you used to plan a lesson or group students, and the change you made. Answer slot: if you used an assessment result to change your teaching, say which and what changed; if you did not, say so and say how you would use one. Do not name a test your material does not give you. | The values version of F5. Your material carries no assessment use, so the slot stays open. |

### E. Data-Driven Prober (grade team), depth 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did you know the reading move worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured the move, say what, how it was counted, and what it is sensitive to. If you did not measure it, say so plainly, and say what you watched. Name the weakest assumption you know of behind any result. | The probe asks for a measure, and your material carries none, so the pack supplies no result. |
| E2 | "What do you use to decide which students need reading support?" | JD | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district values page) | An open prompt. Name the one you actually used and what it showed. If you had no formal process, say so and say what you looked at. | The procedural version of D3, asked by the grade team. |

### G. Conversational, depth 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | A 90-second arc: six years of third grade in Joliet, the 2024 reading move, the after-school reading club, the weekly family email. Answer slot: say why you are here in your own words. Leave out anything not in your material. | The opener. Casual in register, but scored. |
| G2 | "What's something from your reading club you're proud of?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Describe one moment from the club in your own words. If nothing specific comes to mind, say what the club does each week. Give no outcomes (scores, attendance) unless you hold them and can say how they were counted. | A casual question about a grounded activity. It tests communication, not a claim. |

## Reverse questions

1. **To the principal:** "You moved from reading specialist to principal. What from the specialist work still shows up in how this building teaches reading?" *Why it lands:* it ties to her own path and her 2025 talk, and turns the interview into a peer conversation.
2. **To the principal:** "What does a strong first month on the fourth-grade team look like?" *Why it lands:* it turns the A1 gap into a planning conversation.
3. **To the grade team (reciprocity):** "What could a new teacher on this team do in the first month that would genuinely help you?" *Why it lands:* it answers the peer probe in their terms.
4. **To the grade team:** "How does the team plan reading units together, shared plans or individual ones?" *Why it lands:* the panel page names reading instruction, and this shows you care about the team's process.
5. **To the panel:** "When references are taken after the panel, what do you want them to speak to?" *Why it lands:* the district's hiring page says references come after the panel, and the question shows you know the process.

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing in any answer, slot, hold or reverse question may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade, or any part of a fourth-grade year | Negative you stated (F2) | "I've never taught fourth grade." A plain acknowledgment, with no answer slot. |
| Being a team lead, or deciding for the grade team | Negative you stated (F3); inflated form of "I led our grade level's move" | "I've never been a team lead." The quote stays at its own scope. |
| Choosing the reading curriculum | Inflated form of "I led our grade level's move to a new reading curriculum in 2024." The material says the move, not who selected the curriculum. | The quote at its own scope. A3 and A4 slots sit inside the move. |
| Results from the reading club or the weekly email: scores, attendance, family replies | Incident or practice. Your material says the club ran and the email was written. It gives no outcomes. | The quotes at their own scope. Any result only if you hold it and can say how it was counted. |

## Sources

- **Provided:** the invite (your message), your CV, and your notes in this conversation.
- **Searches sent (4):**
  1. "Orrinsford Community School District Halvering Elementary values": returned the district's mission and beliefs page.
  2. "Orrinsford Community School District teacher interview process panel": returned the district's "How we hire teachers" page.
  3. "Dolores Vantongeren principal Halvering Elementary": returned a principals' forum speaker page.
  4. "fourth grade teacher job description Illinois Professional Educator License elementary endorsement": returned a K12 jobs board listing. Snippet only, not fetched, so its requirements are unquoted and labeled [inferred].
- **Fetches (2):** both district pages above, read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Three beliefs by name; they raise D1 to D3 and E2. No values cheat sheet: the loop source names no values round. |
| 2. Orrinsford interview process | yes | Loop established: one 45-minute building panel (principal and two grade-level teachers), topics named. No values-style round in it. |
| 3. Strategy / recent news | skipped | The panel page already fixes what this round asks (reading instruction, routines, families). A district strategy sweep would not change those questions, so no CO questions were built. |
| 4. Interviewer name | yes | One listing: principal since 2022, prior reading specialist, 2025 talk. Used for the interviewer read and reverse questions 1 and 2. |
| 5. Representative fourth-grade JD | yes | One listing, snippet only. Gave the representative requirements labeled [inferred]. Not quoted, because it was not fetched. |

## Upgrade menu

- **The full posting text** → the [inferred] rows become quoted [grounded] rows, and the writing, math, science and social studies gap is checked against the real requirements.
- **A copy of your license, or the state lookup printout** → F1 can be graded on an inspectable artifact rather than your statement.
- **The interview date and your prep days** → a prep schedule sized to the time you have.
- **The names of the two grade-level members** → persona weights per member instead of the panel blend.
- **Any figure you actually tracked on the reading move or the club** → E1 and G2 can carry a real number with its method, instead of an answer slot.
- **Your own reason for moving up a grade** → A5 becomes a story from your words, rather than an open slot.
