Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-3-rooms-case-9-canned-bcc6c7d4/03be9f7b-d5a2-4880-b356-2675d1d947f1/scratchpad/Orrinsford_fourth-grade-teacher_interview_pack.md. It's built for a panel of the principal plus two fourth-grade team members, using only your invite and resume. No job posting or research was available, so the pack has 13 questions. That's below the usual range, because your material gives fewer hooks to build on.

Three things to act on before Thursday:

- **Check the date.** Thursday, November 26, 2026 is Thanksgiving. Confirm which Thursday the panel means.
- **Your two stated gaps are the core of the prep.** The principal will likely press on fourth-grade content (A1, which I'd rehearse most) and team leadership (A2). The pack gives you honest wording for both, and it does not let either gap be talked around.
- **I left your Social Security number and IEIN out of the pack.** Interview prep doesn't need them. A school district should request an SSN through its own secure hiring or onboarding process, not in an interview or a prep document.

Offers, not pushed:
- I can run a drill: I'll play the principal on A1 and push back on your answers.
- I can save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Questions:
1. Which Thursday is the interview? Your invite doesn't say.
2. Do you have the job posting, or any focus areas HR gave you? Either would turn the generic rows into ones tied to the actual role.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Format:** 45-minute panel interview (date not yet confirmed; the invite says "Thursday")
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given)
**Built on:** the interview invitation and your resume notes. No job posting, HR guidance or research was available for this pack.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral and values alignment
  - **EXP**: deep-dive into your own experience
  - **JD**: the role itself, including its gaps
  - **CO**: company and strategy knowledge (not covered here; no research was run)
  - **CASE**: a live problem from the job
- Guidance is scaffolding, not a script. Say everything in your own words.
- Question IDs (A1, B2 and so on) match the banks, so you can ask for a drill on any one of them.

---

## 2. Fit snapshot

The invite lists one requirement. The other rows come from the role and from your own notes. Quotes are your words, copied exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Valid Illinois Professional Educator License with an elementary endorsement (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on your material. This is a gate, so expect it to be checked. Have your license record ready to confirm its status and expiry date. |
| F2 | Teach fourth grade (the position, per the invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | low | [grounded] | capability | Words: "I haven't taught fourth grade. For six years I taught third grade at a public elementary school in Joliet." Answer slot: the panel may ask what carries over and what you would learn first. Say your first two learning steps as plans, in your own words, not as things already done. |
| F3 | Lead a grade-level team (inferred from the panel being made up of team members) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I've never been a team lead." Do not add to this. The nearest real experience is in F4, at its own scope. |
| F4 | Lead a grade-level change (inferred from the team-lead question) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | The material supports leading one change at grade level, not leading the team. Bridge at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which parts of the move were yours to decide, and how you decided them. If others made the decision, say so, and say what you did to carry it out. |
| F5 | Reading instruction (role-family, generic) | "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | none | The quote reaches the reading-instruction need in role-relevant terms. No bridge needed. |
| F6 | Communication with families (role-family, generic) | "I write a weekly email to families" (your CV) | medium | [generic] | none | The quote reaches the need directly. No bridge needed. |

**What the material does not show:** no student results, no counts, no outcomes for the reading club, the curriculum move or the family emails. Any question about those is an answer slot, and the pack gives you no numbers.

---

## 3. Prohibited claims

Do not say any of the following, in the interview or in rehearsal. Each entry has its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led a grade team" or "I'm a team lead" | Sourced entry: your own stated negative (F3) | "I've never been a team lead." |
| "I've taught fourth grade" or "I know the fourth-grade standards" | Sourced entry: your own stated negative (F2) | "I haven't taught fourth grade." |
| "I chose the reading curriculum" or "I designed the reading move" | Inflated form of F4. Your material says you led the move, not that you chose the curriculum | F4's quote at its own scope. The limit is the pack's observation, not something to say: the material says you led the move. |

---

## 4. Persona weights

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|---|
| Skeptic | Principal | Quiet, persistent probing of the fourth-grade gap and the team-lead gap | Highest. The invite makes the grade-level fit the core question, and you have two stated gaps | Rehearse the single most likely objection until it is plain. Acknowledge the gap, then give the nearest real evidence. Do not bluff | 4 |
| Peer Evaluator | Two team members | Seam-splitting, "what would you need from us," disagreement with equals | High. Team members will want to know what the new person adds to their work and what it costs them | Reciprocity: what you need from them, and what you bring. Propose principles, not confident claims | 3 |
| Data-Driven Prober | Team members | Asks how you know something worked, and what the number was | Medium. Your material has no numbers, so any "how do you know" will expose that quickly | Say what you tracked, if anything. If you tracked nothing, say so plainly | 2 |
| Case/Strategist | Principal | Live classroom and team problems | Medium. Principals often test judgment this way | Clarify first, then structure, then name your first move | 2 |
| Conversational | Panel opener | Warm, unstructured opener, often the first question | Low weight, but the opener is still scored | Prepare a 90-second career arc built only from your quoted sentences | 2 |

**Why this weighting:** the invite does not say how each panel member is weighted. These weights come from the panel's makeup (a principal and team members) and from the gaps in your material. If you learn the panel's roles or the principal's focus, the weights will change.

---

## 5. Question banks

### Skeptic (principal), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade anywhere in your background. What would your first semester look like?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't taught fourth grade." Then the bridge at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Then your first two learning steps, stated as plans and in your own words. Hold through two follow-ups by returning to the third-grade years and your plan. Concede once, specifically, that fourth-grade content is new to you. Answer slot: none beyond the plan | F2 is the role's central gap, and the principal will likely put it in some form. JD because it scores the posted position |
| A2 | "You haven't led a team before. Why would the grade team take direction from you?" | JD | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold the stated negative: "I've never been a team lead." Then the nearest real experience at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which part of the move was yours to decide, and how you decided. If the decision was made by others, say so, and say what you did to carry it out. Concede once, specifically, that leading a team is what you would want to learn first | F3 and F4. The team-lead question is the second likely objection, and the hold must stay inside the curriculum move |
| A3 | "What draws you to fourth grade, after six years in third?" | JD | [generic] | Answer in terms of what you want to build in fourth grade and why it appeals to you. Make no claim about your past beyond what A1 already states. If your answer draws on your third-grade work, quote the sentence it draws on | A motivation probe that tests whether the move is a considered choice. Generic because it asks about your reasons, not a fact about your history |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message); "I've never been a team lead" (your message) | Name the true gaps: fourth-grade content and team leadership. Say what you would do first about each, as a plan. Do not claim a strength to offset them | Both stated negatives are the honest answer to this question. Skeptics ask it directly to see whether you name your gaps before they do |

### Case/Strategist (principal), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three of your students are two levels behind in reading by February. What do you do first?" | CASE | [generic] | Clarify first: which assessment, and what the gap looks like for each student. Then structure: group by need, choose an intervention, decide how you will check progress, and decide when to bring in the team. Make no claim about your past | A live problem from the job's core, asked as a decision. Generic because it needs no fact about you |
| B2 | "The grade team disagrees about the pacing of the next reading unit. How would you bring them to a decision?" | CASE | [generic] | Name what each side is protecting, the data you would look at, who decides, and how you close the discussion. Make no claim about your past. This also tests leadership, so do not claim a team-lead role | Probes the F3 gap as a live problem rather than a record. Generic, like B1 |

### Peer Evaluator (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together every week. What would you need from us to be useful in the first month?" | JD | [generic] | Name the specific help you would ask for: materials, pacing guides, time to observe. Phrase them as requests, not demands. Say what you would bring, as a plan | Reciprocity is the team's likely test. Generic because it needs no fact about you |
| C2 | "Walk us through the reading curriculum move. What was your part in it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped from that one sentence: the move, at your grade level, in 2024. Then the answer slot: if you chose the curriculum, say how; if the decision was made above you, say so, and say what you led. Keep credit to what you did | This is the nearest evidence for F4, and teammates will probe credit-sharing. The question presupposes only the "led" in the quote |
| C3 | "When your team disagrees about something, how do you handle it?" | JD | [generic] | Describe your approach, not a story you do not have. If a disagreement from your own work comes to mind, describe what you did. If none does, say so and describe how you would approach it | Peer-style disagreement probe. Generic, since no quote speaks to it. Answer slot is honest about the gap |

### Data-Driven Prober (team members), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about the after-school reading club. How do you know it helped?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe how the club runs, in your words. Answer slot: if you tracked any measure, name it and how you counted it. If you tracked nothing, say so plainly and describe what you observed | The question assumes an evaluation that your material does not show. The answer slot covers both branches |
| D2 | "You write to families every week. How do you know they read it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe what the email contains and how you send it. Answer slot: if you know how many families read it or respond, say how you know. If you do not, say so | Same pattern as D1: the question assumes a read rate that is not in your material |

### Conversational (panel opener), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc, built only from these three sentences, in this order: the Joliet school and the third-grade years, the 2024 curriculum move, the reading club. Each beat is a clause the quote states | Panel openers are scored casually. The arc uses only what your material carries |
| E2 | "Tell us about something from your classroom that you're proud of." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV); "I write a weekly email to families" (your CV) | Choose one of the three sentences above and tell it in your own words. Keep your part to what the sentence says | Open prompt, and the candidate chooses the instance. The three quotes are the only material available |

**Coverage note:** this pack has 13 questions, below the usual range of 18 to 26. The material gives fewer hooks, and the pack does not invent more. Each added input (see section 8) adds banks.

---

## 6. Reverse questions

Ask these at the end. Each has a reason it works.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for the fourth-grade team? When do you plan together?" | Shows you are thinking about how the team works in practice, not just about the job title |
| R2 | "What has the team been working on this year, and where would a new teacher fit in?" | Shows you have thought about the team's current work, and asks where you would fit |
| R3 | "What would a strong first year in this role look like to you?" | Asks for the panel's own criteria, which tells you how they will score the next year |
| R4 | "Which reading materials does the grade use now, and what is the team looking to change?" | Connects to your 2024 curriculum move, and invites the panel to talk about the work you already know |
| R5 | "What support is available for a teacher who is new to a grade level?" | Addresses the fourth-grade gap by asking about support, rather than claiming experience you do not have |
| R6 | "What could a new teacher on the team do in the first month that would help the team most?" | Reciprocity. Shifts the conversation from what the team can do for you to how you can work together |

---

## 7. Sources

- **Provided documents:** the interview invitation; your resume and notes (as pasted in this conversation).
- **Research tier:** L0. No searches or page fetches were run for this pack. Your consent to research was not asked, because the job posting and the panel's roles were not available to frame it.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Orrinsford or Halvering values | unavailable | Values cheat sheet (not included, since no values page was supplied) |
| 2. Orrinsford interview process | unavailable | Loop structure and persona weights |
| 3. District strategy and recent news | unavailable | Grounding brief for CO questions |
| 4. Principal Dolores Vantongeren | unavailable | Interviewer read, and a tailored reverse question |
| 5. Representative fourth-grade teacher posting (Illinois) | unavailable | Requirement rows marked generic would become inferred or grounded |

---

## 8. Upgrade menu

- **The job posting** → turns the role's requirements from one line in the invite into quoted rows, and adds JD-tagged coverage to the banks.
- **The confirmed interview date** → the invite says "Thursday." Thursday, November 26, 2026 is Thanksgiving, so the date needs checking. Confirmed timing also tells you how much prep time you have.
- **Panel member names and roles** → per-member persona weights, and reverse questions aimed at each person's work.
- **Any focus areas or tasks HR named in advance** (a lesson demonstration, a written response) → a build section for each one.
- **Research (L1, about six searches)** → the district's reading program, its published values, and how its panels usually run.
- **The principal's public profile** → an interviewer read, and a reverse question tied to their own path.
