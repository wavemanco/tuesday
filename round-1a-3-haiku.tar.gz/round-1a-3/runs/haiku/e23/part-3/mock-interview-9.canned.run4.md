Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/haiku/e23/part-3/rooms/case-9-canned-b8f22a8e/Halvering_fourth-grade-teacher_interview_pack.md`. I built it from your background and the invitation alone, since no job posting was supplied and no research was run. I left your SSN out of the pack entirely; a prep pack doesn't need it, so keep it out of any notes or emails you send about this role.

# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
**Round:** 45-minute panel: Principal Dolores Vantongeren and two fourth-grade team members (names not given). "Thursday" is most likely November 26, 2026, which is Thanksgiving; confirm the date with HR.
**Requirements source:** the invitation only. No job posting was supplied.
**Research tier:** L0. No searches were run.

## How to use

- **Personas** describe how a question arrives: its tone and pace.
- **Types** describe what is being scored: VAL (values and behavior), EXP (your past work, checked for detail), JD (the job's listed needs), CO (company knowledge; none in this pack), CASE (a live problem).
- Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Name the license, the grades, and the expiry date in those words. This is the one requirement the panel will check in a sentence. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet." (your CV) | medium | [grounded] | transferability | Your material places you in third grade, one grade below this role. The bridge stays at that scope: "I've taught third grade for six years." Answer slot: if any of your third-grade work already overlapped with fourth-grade content or students, say how, in your own words; if none did, say so plainly. |
| F3 | Fourth-grade teaching experience (the role title and the invitation's "our fourth-grade team") | "I've never taught fourth grade" (your message) | none | [grounded] | capability | A gap you stated, so the words can be yours: "I haven't taught fourth grade." Then how you would learn fourth-grade content, said as a plan and never as a past. |
| F4 | Leading a grade-level team (not in the invitation; inferred from a panel made up of a fourth-grade team) | "I've never been a team lead" (your message) | none | [grounded] | capability | A gap you stated: "I haven't been a team lead." Then what you would bring to a team as a member, said as a plan. |
| F5 | Leading a change within a grade level (not in the invitation; inferred) | "I led our grade level's move to a new reading curriculum in 2024," (your CV) | medium | [grounded] | presentation | The quote already reaches this in other terms. Say it as written: you led your grade level's move, in 2024. Its scope is the grade level, not the school. |
| F6 | Reading support for students (no requirement stated; a strength to show) | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | none | No gap. A CV line with nothing yet inspected behind it, so expect a question on it. Say what the club is in your own words, in the quote's terms. |
| F7 | Communication with families (no requirement stated; a strength to show) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | No gap. Describe the format and the rhythm; the sentence does not show what the emails achieved. |

## Persona table

The invitation names a panel, so the weights blend the top two personas of each member's likely role. Member roles are inferred from titles only; no public profiles were researched.

| Persona | Who it likely is | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet, persistent questions about the fourth-grade gap and the team-lead gap | High. F3 and F4 are the two places the material is silent or negative, and a principal weighing a hire will press them first | Rehearse the single most likely objection until it is plain. Say the gap once, cleanly, then point to the adjacent evidence |
| Peer Evaluator | Fourth-grade team members | Seam questions: where you would fit, how you handle disagreement and credit | High. Two team members will judge whether the hire adds to their load | Reciprocity framing: what you bring their team, not only what you need. Propose seam principles rather than pretending to know their seam |
| Values / Behavioral | Principal | Scenario prompts asking for a time you did something | Medium. A panel often includes one behavioral register, but no values were published or supplied | Pick a real story, say "we" for context and "I" for your contribution. Where your material shows no story, say so rather than inventing one |
| Case / Strategist | Principal or a team member | A live first-weeks problem or a class-data problem | Medium. Panels often include one scenario question; it scores structure, not the right answer | Clarify before structuring. Name what you would check first |
| Data-Driven Prober | A team member | How you know something worked; how you counted | Medium. F5 and F6 are the places a count would be asked for, and your material gives none | Say plainly what you tracked and what you did not. Never offer a figure you cannot defend |
| Conversational | Opening and closing minutes | An open "walk us through" request | Medium. The opening is scored even though it sounds casual | A 90-second arc, rehearsed once aloud |

Depth follows weight: Skeptic 5, Peer Evaluator 4, Values 3, Case 3, Prober 2, Conversational 2.

## Question banks

### Bank A: Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we take a chance on you for this role?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Begin with the plain acknowledgment: "I haven't taught fourth grade." Then the third-grade quote at its own scope. Close with how you would learn fourth-grade content, as a plan. Do not argue that third grade is the same job. Answer slot: none; the gap has its own words. **Highest-ROI prep in this pack.** | F3 is the largest gap, and this objection will arrive in some form. Rehearse it until the acknowledgment comes out before the second follow-up. |
| A2 | "Which part of a fourth-grade year would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message) | Name one specific area you have not taught, in your own words, and the first step to close it. Keep it a plan, never a past. Hold the answer through one follow-up. | F3 again, from the day-one angle. A named weakness with a plan scores better than a general one. |
| A3 | "You've never been a team lead. Why do you think you'd be a good fit on this team?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Acknowledge: "I haven't been a team lead." Then the curriculum move at its own scope: you led your grade level's move. Do not turn "led our grade level's move" into "team lead." Hold through two follow-ups by returning to what you led. | F4 with F5 as the adjacent evidence. The objection is about the title, and the honest answer keeps the title and the change separate. |
| A4 | "If you joined our fourth-grade team in January, what would you want to understand before proposing any change?" | CASE | [generic] | Clarify first: the current reading materials, what the students' data show, how the team decides. Then say what you would propose, and when. Name no past change of yours as an example unless it is in your quotes. | A live problem about entering a team mid-year. It asks no claim about your past, so the guidance makes none. |
| A5 | "Sixty seconds: why you over a candidate who has taught fourth grade for years?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "I've run the after-school reading club for the last two years." (your CV) | Hold the core: "I haven't taught fourth grade, and I won't claim otherwise." Then one thing you bring that is in your quotes: the reading club, two years. Concede specifically: an experienced fourth-grade teacher would arrive with fourth-grade experience you do not have. | A pressure version of A1. Hold the position through two follow-ups; concede the gap, not the strengths. |

### Bank B: Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team sits side by side in fourth grade. Where would you see the seam with third grade, and what happens when we disagree?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | The third-to-fourth handoff is a real seam; name it in principle and ask them where they see it. For disagreement, propose a principle you can defend: bring the student evidence to the meeting. Do not claim to know their seam. | F2 is the adjacent evidence. The seam question is how a peer tests whether a new teacher will add or subtract. |
| B2 | "Tell us about the reading curriculum move in your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Tell the move in your own words: the grade, the year, the change. Stay within what the sentence says. Do not add decisions or steps you cannot repeat. | F5 is the strongest leadership-like evidence. Its story has only the beats the quote states. |
| B3 | "How do you handle credit when a change in a grade level involves several teachers?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Give a principle: name colleagues by role, and say plainly when you do not know who did which part. Do not list others' contributions you did not see. | A peer's credit probe, asked as a hypothetical. The guidance draws on the move only as a scope, not as a credit claim. |
| B4 | "What would you need from us to fit into a shared reading block?" | JD | [generic] | Ask for the team's plan, the materials in use, and how common assessments are scored. Propose one way to start, as a question to them. | Collegial seam question. It asks about the team, so it needs no claim about you. |

### Bank C: Values / Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you disagreed with a decision and said so. It needs a named stake, what you actually said, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have done. | No quoted sentence carries this story. Do not borrow the reading-curriculum move as a disagreement story. |
| C2 | "Tell me about a time you put a student's needs ahead of a schedule or a target." | VAL | [grounded] "I've run the after-school reading club for the last two years." (your CV) | The club is a sustained piece of student work. Describe what it is, in your words. If you can name a moment when a student's need changed what you did, say so; if not, say that and give the nearest example. | F6 carries the club, not the moment. The moment is a scaffold, not a claim. |
| C3 | "Tell us about a time a family needed to hear something hard from you." | VAL | [grounded] "I write a weekly email to families." (your CV) | If you have an instance where a weekly email carried difficult news, say what you wrote and why. If not, say so, then describe how you would write a hard message in the same format. | F7 carries the format. The hard-news beat is not in the material, so it is a scaffold. |

### Bank D: Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Plan your first 60 days with a fourth-grade class. What do you need to know first?" | CASE | [generic] | Clarify first: the students' current levels, the materials, the team's plan. Then structure: learn, align with the team, teach, check. Name the content you have not taught as the first risk to manage. | A plan question about the role. Clarification before structure is what it scores. |
| D2 | "Fourth-grade reading scores dipped in one class this year. What do you check first?" | CASE | [generic] | Clarify which measure and which students, and what changed. Then check instruction and materials, attendance, and whether the assessment itself changed. | A diagnostic problem from the role. The method is general, so no claim is made about you. |
| D3 | "A parent emails upset about a grade. What do you do?" | CASE | [generic] | Acknowledge, check the facts, then meet or call before replying in writing. Say what you would record. | A family-communication live problem. Frame it as a decision, not a story. |

### Bank E: Data-Driven Prober (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What did you measure to see how the new reading curriculum was doing?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Answer slot: if you tracked anything, say what, from whom, and how often, in your own words. If you did not track it, say so plainly and say what you would measure first. Do not name a measure you did not use. | F5 has no figure in it, so the figure rules do not apply; the probe asks about measurement, which the question raises itself. |
| E2 | "How many students came to the reading club, and how did you count them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Answer slot: if you counted attendance, say how and what the count covered. If you did not count, say so plainly. Do not offer a number you cannot repeat. | F6 gives no count. A probe for a count that the material does not carry needs the honest branch ready. |

### Bank F: Conversational and license (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "So, walk us through the journey to teaching third grade in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | A 90-second arc: where you began, the six years, what you have built since. Name the fourth-grade gap once, briefly, at the end. | The casual opener is scored. A rehearsed arc keeps the first two minutes steady. |
| F-2 | "What's the best book you've used with a class lately, and why?" | EXP | [generic] | Name one title and the reason you chose it, in your own words. Do not claim a result for it that you cannot repeat. | A rapport question with a scored edge: it tests whether you read for your teaching. |
| F-3 | "Tell us about the Illinois license you hold." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | State the license, the grades, and the expiry date in those words. Nothing more. | The invitation's only stated requirement. Cheap to answer and costly to fumble. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Valid Illinois PEL with elementary endorsement | F-3 |
| Fourth-grade teaching (the role) | A1, A2, A5, D1 |
| Team lead (inferred from the panel) | A3, B1 |
| Leading a change within a grade (inferred) | B2, E1, B3 |
| Reading support | C2, E2 |
| Family communication | C3, D3 |
| Working with a team | B1, B4, A4 |
| Company and values knowledge | none, and why: the invitation names no values and research was not run |

## Reverse questions

1. "What does a strong first semester look like for someone on the fourth-grade team?" Why it lands: it turns the interview toward the work the principal will judge.
2. "How does the team plan reading instruction together, and where would a new teacher plug in?" Why it lands: it shows you are already thinking about the seam with your current grade.
3. "Which parts of the current reading approach does the team feel strongest about, and which need work?" Why it lands: it invites the team to name its own gap, which is a peer conversation.
4. "How does the school support a teacher moving into a new grade in their first year?" Why it lands: it shows you plan to learn the grade rather than hide the gap.
5. Reciprocity: "What could a new person do in their first month that would genuinely help your team?" Why it lands: the peer members hear what you would bring to their load.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Negative you stated (F3) | "I haven't taught fourth grade." No slot. |
| Any team-lead experience | Negative you stated (F4) | "I haven't been a team lead." No slot. |
| Choosing or leading the school's reading curriculum | Inflated form of F5. Your material says your grade level's move, not the school's | F5 at its own scope: "I led our grade level's move to a new reading curriculum in 2024," (your CV). The limit is this pack's observation: your material describes the grade level, not the school. |
| Results from the reading club | Inflated form of F6. No outcome is in the material | "I've run the after-school reading club for the last two years." (your CV). The material reports no outcomes. |
| Effects of the weekly family emails on engagement or results | Inflated form of F7. No outcome is in the material | "I write a weekly email to families." (your CV). No outcome claim. |

## Sources

- Provided: the invitation text; your background message, including the CV text and the two statements about fourth grade and team lead.
- Searches and fetches: none (L0).

**Research tier: L0.** No research was run in this pass.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford values | unavailable | Would have produced a values cheat sheet; none is in this pack. |
| 2. Interview process for the role family | unavailable | Would have set the loop structure and the persona weights. Weights here are from the panel composition only. |
| 3. School or district strategy and recent news | unavailable | Would have added a grounding brief. Dropped from this pack. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. |
| 5. Representative job posting for the title | unavailable | Would have turned the requirement column into `[inferred]` quotes. The invitation fixes the requirements it names. |

## Upgrade menu

- The full job posting → the requirement column gets quoted text, and the coverage table checks every listed item.
- HR's focus areas, any demo lesson, or any writing sample → coverage of declared deliverables and reweighted personas.
- The panel members' names and roles → per-member persona assignments and a tailored reverse question.
- Research at L1 (up to 6 searches and 2 page fetches) on the school's values and interview format → a values cheat sheet and loop structure.
- Deep research at L2 (up to 6 further searches and 2 further fetches on strategy, interviewer public writing, and recent district news) → a grounding brief. Say yes if you want it run.

---

I can also run a live drill: I'll play the Skeptic on A1, the highest-ROI question, with follow-ups that react to your answers. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. I can convert the pack to a Word document if you'd like one.

Two questions, both would sharpen the pack:
1. Do you have the full job posting, or should I keep working from the invitation alone?
2. Has HR said anything about focus areas, a demo lesson, or a writing sample for this panel?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
**Round:** 45-minute panel: Principal Dolores Vantongeren and two fourth-grade team members (names not given). "Thursday" is most likely November 26, 2026, which is Thanksgiving; confirm the date with HR.
**Requirements source:** the invitation only. No job posting was supplied.
**Research tier:** L0. No searches were run.

## How to use

- **Personas** describe how a question arrives: its tone and pace.
- **Types** describe what is being scored: VAL (values and behavior), EXP (your past work, checked for detail), JD (the job's listed needs), CO (company knowledge; none in this pack), CASE (a live problem).
- Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Name the license, the grades, and the expiry date in those words. This is the one requirement the panel will check in a sentence. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet." (your CV) | medium | [grounded] | transferability | Your material places you in third grade, one grade below this role. The bridge stays at that scope: "I've taught third grade for six years." Answer slot: if any of your third-grade work already overlapped with fourth-grade content or students, say how, in your own words; if none did, say so plainly. |
| F3 | Fourth-grade teaching experience (the role title and the invitation's "our fourth-grade team") | "I've never taught fourth grade" (your message) | none | [grounded] | capability | A gap you stated, so the words can be yours: "I haven't taught fourth grade." Then how you would learn fourth-grade content, said as a plan and never as a past. |
| F4 | Leading a grade-level team (not in the invitation; inferred from a panel made up of a fourth-grade team) | "I've never been a team lead" (your message) | none | [grounded] | capability | A gap you stated: "I haven't been a team lead." Then what you would bring to a team as a member, said as a plan. |
| F5 | Leading a change within a grade level (not in the invitation; inferred) | "I led our grade level's move to a new reading curriculum in 2024," (your CV) | medium | [grounded] | presentation | The quote already reaches this in other terms. Say it as written: you led your grade level's move, in 2024. Its scope is the grade level, not the school. |
| F6 | Reading support for students (no requirement stated; a strength to show) | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | none | No gap. A CV line with nothing yet inspected behind it, so expect a question on it. Say what the club is in your own words, in the quote's terms. |
| F7 | Communication with families (no requirement stated; a strength to show) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | No gap. Describe the format and the rhythm; the sentence does not show what the emails achieved. |

## Persona table

The invitation names a panel, so the weights blend the top two personas of each member's likely role. Member roles are inferred from titles only; no public profiles were researched.

| Persona | Who it likely is | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet, persistent questions about the fourth-grade gap and the team-lead gap | High. F3 and F4 are the two places the material is silent or negative, and a principal weighing a hire will press them first | Rehearse the single most likely objection until it is plain. Say the gap once, cleanly, then point to the adjacent evidence |
| Peer Evaluator | Fourth-grade team members | Seam questions: where you would fit, how you handle disagreement and credit | High. Two team members will judge whether the hire adds to their load | Reciprocity framing: what you bring their team, not only what you need. Propose seam principles rather than pretending to know their seam |
| Values / Behavioral | Principal | Scenario prompts asking for a time you did something | Medium. A panel often includes one behavioral register, but no values were published or supplied | Pick a real story, say "we" for context and "I" for your contribution. Where your material shows no story, say so rather than inventing one |
| Case / Strategist | Principal or a team member | A live first-weeks problem or a class-data problem | Medium. Panels often include one scenario question; it scores structure, not the right answer | Clarify before structuring. Name what you would check first |
| Data-Driven Prober | A team member | How you know something worked; how you counted | Medium. F5 and F6 are the places a count would be asked for, and your material gives none | Say plainly what you tracked and what you did not. Never offer a figure you cannot defend |
| Conversational | Opening and closing minutes | An open "walk us through" request | Medium. The opening is scored even though it sounds casual | A 90-second arc, rehearsed once aloud |

Depth follows weight: Skeptic 5, Peer Evaluator 4, Values 3, Case 3, Prober 2, Conversational 2.

## Question banks

### Bank A: Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we take a chance on you for this role?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Begin with the plain acknowledgment: "I haven't taught fourth grade." Then the third-grade quote at its own scope. Close with how you would learn fourth-grade content, as a plan. Do not argue that third grade is the same job. Answer slot: none; the gap has its own words. **Highest-ROI prep in this pack.** | F3 is the largest gap, and this objection will arrive in some form. Rehearse it until the acknowledgment comes out before the second follow-up. |
| A2 | "Which part of a fourth-grade year would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message) | Name one specific area you have not taught, in your own words, and the first step to close it. Keep it a plan, never a past. Hold the answer through one follow-up. | F3 again, from the day-one angle. A named weakness with a plan scores better than a general one. |
| A3 | "You've never been a team lead. Why do you think you'd be a good fit on this team?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Acknowledge: "I haven't been a team lead." Then the curriculum move at its own scope: you led your grade level's move. Do not turn "led our grade level's move" into "team lead." Hold through two follow-ups by returning to what you led. | F4 with F5 as the adjacent evidence. The objection is about the title, and the honest answer keeps the title and the change separate. |
| A4 | "If you joined our fourth-grade team in January, what would you want to understand before proposing any change?" | CASE | [generic] | Clarify first: the current reading materials, what the students' data show, how the team decides. Then say what you would propose, and when. Name no past change of yours as an example unless it is in your quotes. | A live problem about entering a team mid-year. It asks no claim about your past, so the guidance makes none. |
| A5 | "Sixty seconds: why you over a candidate who has taught fourth grade for years?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "I've run the after-school reading club for the last two years." (your CV) | Hold the core: "I haven't taught fourth grade, and I won't claim otherwise." Then one thing you bring that is in your quotes: the reading club, two years. Concede specifically: an experienced fourth-grade teacher would arrive with fourth-grade experience you do not have. | A pressure version of A1. Hold the position through two follow-ups; concede the gap, not the strengths. |

### Bank B: Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team sits side by side in fourth grade. Where would you see the seam with third grade, and what happens when we disagree?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | The third-to-fourth handoff is a real seam; name it in principle and ask them where they see it. For disagreement, propose a principle you can defend: bring the student evidence to the meeting. Do not claim to know their seam. | F2 is the adjacent evidence. The seam question is how a peer tests whether a new teacher will add or subtract. |
| B2 | "Tell us about the reading curriculum move in your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Tell the move in your own words: the grade, the year, the change. Stay within what the sentence says. Do not add decisions or steps you cannot repeat. | F5 is the strongest leadership-like evidence. Its story has only the beats the quote states. |
| B3 | "How do you handle credit when a change in a grade level involves several teachers?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Give a principle: name colleagues by role, and say plainly when you do not know who did which part. Do not list others' contributions you did not see. | A peer's credit probe, asked as a hypothetical. The guidance draws on the move only as a scope, not as a credit claim. |
| B4 | "What would you need from us to fit into a shared reading block?" | JD | [generic] | Ask for the team's plan, the materials in use, and how common assessments are scored. Propose one way to start, as a question to them. | Collegial seam question. It asks about the team, so it needs no claim about you. |

### Bank C: Values / Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you disagreed with a decision and said so. It needs a named stake, what you actually said, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have done. | No quoted sentence carries this story. Do not borrow the reading-curriculum move as a disagreement story. |
| C2 | "Tell me about a time you put a student's needs ahead of a schedule or a target." | VAL | [grounded] "I've run the after-school reading club for the last two years." (your CV) | The club is a sustained piece of student work. Describe what it is, in your words. If you can name a moment when a student's need changed what you did, say so; if not, say that and give the nearest example. | F6 carries the club, not the moment. The moment is a scaffold, not a claim. |
| C3 | "Tell us about a time a family needed to hear something hard from you." | VAL | [grounded] "I write a weekly email to families." (your CV) | If you have an instance where a weekly email carried difficult news, say what you wrote and why. If not, say so, then describe how you would write a hard message in the same format. | F7 carries the format. The hard-news beat is not in the material, so it is a scaffold. |

### Bank D: Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Plan your first 60 days with a fourth-grade class. What do you need to know first?" | CASE | [generic] | Clarify first: the students' current levels, the materials, the team's plan. Then structure: learn, align with the team, teach, check. Name the content you have not taught as the first risk to manage. | A plan question about the role. Clarification before structure is what it scores. |
| D2 | "Fourth-grade reading scores dipped in one class this year. What do you check first?" | CASE | [generic] | Clarify which measure and which students, and what changed. Then check instruction and materials, attendance, and whether the assessment itself changed. | A diagnostic problem from the role. The method is general, so no claim is made about you. |
| D3 | "A parent emails upset about a grade. What do you do?" | CASE | [generic] | Acknowledge, check the facts, then meet or call before replying in writing. Say what you would record. | A family-communication live problem. Frame it as a decision, not a story. |

### Bank E: Data-Driven Prober (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What did you measure to see how the new reading curriculum was doing?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024," (your CV) | Answer slot: if you tracked anything, say what, from whom, and how often, in your own words. If you did not track it, say so plainly and say what you would measure first. Do not name a measure you did not use. | F5 has no figure in it, so the figure rules do not apply; the probe asks about measurement, which the question raises itself. |
| E2 | "How many students came to the reading club, and how did you count them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Answer slot: if you counted attendance, say how and what the count covered. If you did not count, say so plainly. Do not offer a number you cannot repeat. | F6 gives no count. A probe for a count that the material does not carry needs the honest branch ready. |

### Bank F: Conversational and license (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "So, walk us through the journey to teaching third grade in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | A 90-second arc: where you began, the six years, what you have built since. Name the fourth-grade gap once, briefly, at the end. | The casual opener is scored. A rehearsed arc keeps the first two minutes steady. |
| F-2 | "What's the best book you've used with a class lately, and why?" | EXP | [generic] | Name one title and the reason you chose it, in your own words. Do not claim a result for it that you cannot repeat. | A rapport question with a scored edge: it tests whether you read for your teaching. |
| F-3 | "Tell us about the Illinois license you hold." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | State the license, the grades, and the expiry date in those words. Nothing more. | The invitation's only stated requirement. Cheap to answer and costly to fumble. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Valid Illinois PEL with elementary endorsement | F-3 |
| Fourth-grade teaching (the role) | A1, A2, A5, D1 |
| Team lead (inferred from the panel) | A3, B1 |
| Leading a change within a grade (inferred) | B2, E1, B3 |
| Reading support | C2, E2 |
| Family communication | C3, D3 |
| Working with a team | B1, B4, A4 |
| Company and values knowledge | none, and why: the invitation names no values and research was not run |

## Reverse questions

Five questions, each with why it lands. Since the panel includes peers, the last one is a reciprocity question.

1. "What does a strong first semester look like for someone on the fourth-grade team?" Why it lands: it turns the interview toward the work the principal will judge.
2. "How does the team plan reading instruction together, and where would a new teacher plug in?" Why it lands: it shows you are already thinking about the seam with your current grade.
3. "Which parts of the current reading approach does the team feel strongest about, and which need work?" Why it lands: it invites the team to name its own gap, which is a peer conversation.
4. "How does the school support a teacher moving into a new grade in their first year?" Why it lands: it shows you plan to learn the grade rather than hide the gap.
5. Reciprocity: "What could a new person do in their first month that would genuinely help your team?" Why it lands: the peer members hear what you would bring to their load.

## Prohibited claims

What this pack will not coach, and why. Entries built from your own statements carry your own words as the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Negative you stated (F3) | "I haven't taught fourth grade." No slot. |
| Any team-lead experience | Negative you stated (F4) | "I haven't been a team lead." No slot. |
| Choosing or leading the school's reading curriculum | Inflated form of F5. Your material says your grade level's move, not the school's | F5 at its own scope: "I led our grade level's move to a new reading curriculum in 2024," (your CV). The limit is this pack's observation: your material describes the grade level, not the school. |
| Results from the reading club | Inflated form of F6. No outcome is in the material | "I've run the after-school reading club for the last two years." (your CV). The material reports no outcomes. |
| Effects of the weekly family emails on engagement or results | Inflated form of F7. No outcome is in the material | "I write a weekly email to families." (your CV). No outcome claim. |

## Sources

- Provided: the invitation text; your background message, including the CV text and the two statements about fourth grade and team lead.
- Searches and fetches: none (L0).

**Research tier: L0.** No research was run in this pass.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford values | unavailable | Would have produced a values cheat sheet; none is in this pack. Research at L1 was not run in this pass. |
| 2. Interview process for the role family | unavailable | Would have set the loop structure and the persona weights. Weights here are from the panel composition only. |
| 3. School or district strategy and recent news | unavailable | Would have added a grounding brief. Dropped from this pack. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. |
| 5. Representative job posting for the title | unavailable | Would have turned F1 to F7's requirement quotes into `[inferred]` rows. The invitation fixes the requirements it names. |

## Upgrade menu

- The full job posting → the requirement column gets quoted text, and the coverage table checks every listed item.
- HR's focus areas, any demo lesson, or any writing sample → coverage of declared deliverables and reweighted personas.
- The panel members' names and roles → per-member persona assignments and a tailored reverse question.
- Research at L1 (up to 6 searches and 2 page fetches) on the school's values and interview format → a values cheat sheet and loop structure.
- Deep research at L2 (up to 6 further searches and 2 further fetches on the strategy, interviewer public writing, and recent district news) → a grounding brief. Its time cost is a few minutes of searching; say yes to run it.
