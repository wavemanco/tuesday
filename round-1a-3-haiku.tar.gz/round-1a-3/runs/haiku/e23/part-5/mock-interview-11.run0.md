**Before any prep, please treat this as a likely scam.** The message has the hallmarks of a common job-fraud pattern:

- **You didn't apply to this role.** "We found your profile online" from an unknown number is a standard opening, and "probably one of my applications" is exactly what the scammer wants you to assume.
- **No calls or video, and the contract goes over WhatsApp too.** Legitimate recruiters use email, a company domain, and video calls. Scams avoid verifiable channels.
- **Fast timeline.** An interview "tomorrow at 11am" with no prior conversation is a pressure tactic.
- **Vague job details** ("remote, flexible hours") with no named company or client.

Fraud typically escalates from here: requests for personal documents (ID, bank details, Social Security or tax numbers) "for onboarding," a fee for equipment or training, or a "salary advance" paid into an account that you're asked to forward money from. Don't send any of these.

**Check before you engage:**

1. **Ask Jess for the company's full name, the role's exact job title, and the job ID or posting link.** Then search for the posting yourself on the company's own careers page, not through a link they send.
2. **Ask for a work email from a company domain and a video call.** A real recruiter will agree. If they refuse or stall, you have your answer.
3. **Look up the recruitment agency** on Companies House (UK) or the state business registry (US), and check it's not just a new WhatsApp number.
4. **Search the company name with "scam" or "fraud"** and check their listing on Glassdoor or Reddit.
5. **Check the number itself.** Search it on Google and in a scam-reporting site like Whocalled or 800notes.

If you want to find out whether it's real, the quickest test is to reply and ask for the company name, the job posting, and a video call. Keep the WhatsApp exchange and don't share anything sensitive until they pass.

**To build your prep pack, I need:**

1. **The round type and who you'd report to**, or whether this is a recruiter screen only.
2. **The job description** (or the posting you found), and your CV or a short summary of your background.
3. **Whether you want to proceed** after the checks above. If you'd rather prep generically in the meantime, I can build a pack from your CV and a representative job description for the title, labelled as generic.

Once you've confirmed the role is real, or if you want generic prep now, send me those and I'll produce the full pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.