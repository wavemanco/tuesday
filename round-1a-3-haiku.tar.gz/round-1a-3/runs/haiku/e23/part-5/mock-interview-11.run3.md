I haven't started the interview prep yet. This message has several hallmarks of a job scam, so I'd check it before you spend effort on it.

**Red flags**
- **Whole process over WhatsApp, no calls or video.** Real recruiters and employers usually do at least a phone or video screen, and they contact you from a company email address.
- **Unknown number, generic opener.** "We found your profile online" with no company name, role title, or job ad reference.
- **Remote, flexible, and easy.** That's the usual bait.
- **Interview tomorrow at 11am.** Urgency is a common pressure tactic.

Scams like this usually continue with a request for your passport or ID, bank details for "payroll setup", a fee for equipment or training, or a task that involves moving money, including buying gift cards or crypto. Don't send any of those.

**How to check it**
1. Reply and ask for the company's legal name, the exact job title, the job ad link, and the recruiter's full name and agency. A real recruiter will answer this easily. A scammer will dodge it or push you to hurry.
2. Check your application history on the job board or site where you applied. If you can't find an application for this role, that's a strong sign.
3. Look up the company yourself, not through any link they send. Confirm the role is on its official careers page, and check that the recruiter works there on LinkedIn.
4. Ask for a call or an email from a company domain. If they refuse both, treat it as a scam.

**Next steps**
- If you can tell me the company and role, I'll help you check whether it's legitimate.
- If it checks out, send me the job description and your CV and I'll run the mock-interview prep, covering the likely questions, how to answer them from your background, and what to ask them.