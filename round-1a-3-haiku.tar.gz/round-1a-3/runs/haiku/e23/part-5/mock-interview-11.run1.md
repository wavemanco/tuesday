I'd hold off on prepping for this one until you've checked it. The message has several hallmarks of a recruitment scam:

- **Unsolicited contact from an unknown number**, with a vague "we found your profile online" rather than a named company or job posting.
- **Remote, flexible, well-paid-sounding role** with no detail about the employer or the pay.
- **Everything over WhatsApp**, with no calls or video, and no company email.
- **Pressure to commit quickly**: an interview "tomorrow at 11am."

Scammers do use job-application lists and CV sites, so the fact that you've applied widely doesn't make it genuine.

**Before you reply, check:**

1. **Which job was it?** Ask Jess for the exact job title, the company name, and the job ad or reference number. A real recruiter will answer these readily. A scammer will dodge, or push the timing.
2. **Verify the company yourself.** Find its official website through a search, not a link from the message, and check that the role is listed on its careers page.
3. **Verify the recruiter.** Search for Jess's name plus the agency, and check LinkedIn for a profile with a real work history. Ask for a company email address and see whether it matches the agency's domain.
4. **Check the original listing.** If you applied through a job board, see whether the job is still posted there and whether it shows the same company.

**Don't, under any circumstances:**
- Send your passport, ID, bank details, tax or National Insurance number, or a photo of your documents over WhatsApp before you've verified the job.
- Pay for anything: training, equipment, software, a "background check," or a "starter" fee.
- Deposit or transfer money for anyone, or accept a cheque or payment and send back part of it. That's a common money-mule setup.
- Download an app or click a link they send to "complete onboarding."

If any of those come up, stop replying. If you've already shared documents or details, report it to your national fraud reporting service and your bank, and consider a credit freeze or fraud alert.

**If the company and recruiter check out**, I'm glad to run the mock-interview prep. Paste the job description and your CV, and tell me what you know about the company and the interviewer's background. I'll build a question bank, match your background against the role, and set up a practice session. Without that information the prep would be generic and not much use to you, so I haven't started it yet.