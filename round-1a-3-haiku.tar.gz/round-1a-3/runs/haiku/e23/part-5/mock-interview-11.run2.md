I've loaded the mock-interview skill, but I can't build a prep pack yet. It needs at least the company and role title, and this message doesn't name either. Before you prepare, I'd check whether this is real, because several things in the message match recruitment scams.

**Red flags:**
- **The whole process is over WhatsApp, with no call or video.** Legitimate recruiters almost always have a phone or video conversation, and a company hiring for a remote role can run video interviews.
- **Unsolicited contact from an unknown number,** with a claim that they "found your profile online." Your recent applications make this easy to rationalise, but a scammer can use exactly that cover.
- **Vague details.** The message names no company, no role title and no recruitment firm.
- **Pressure to commit quickly:** an interview "tomorrow at 11am."

Scams in this pattern often continue with requests for your passport or ID, bank details, or a payment for "equipment" or "training," or they ask you to buy and send gift cards or crypto. Don't send any of those.

**Before you commit to anything, you could:**
1. Reply to Jess and ask for the company name, the exact job title, the job advert or link you applied through, and the recruitment firm's name and registration details.
2. Check that the job is actually live on the company's own careers page, or on the job board where you applied. Find the company's contact details yourself, not from the message, and call the main switchboard to ask whether they're recruiting for that role through Jess.
3. Ask for a video or phone call. A genuine recruiter will normally agree, and a scammer will usually resist or keep pushing the WhatsApp process.

If the company and role check out, send me:
- **The company and role title.** This is required.
- **The job description**, if you have it, or the advert link.
- **Your CV or a short summary of your background.** This shapes the answers.
- **The interview format:** whether it's a screen with the recruiter, or with the hiring manager, and whether anything has been asked to be prepared in advance.

I'll then build the full pack: likely questions by type, suggested answers grounded only in your real experience, and a few questions to ask them. If it turns out to be a scam, I can help you write a polite decline or a report to the platform.