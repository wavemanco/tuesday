I'd hold off on prep until you've checked this, because it has several hallmarks of a recruitment scam:

- **No calls or video, with the whole process on WhatsApp, including the contract.** Legitimate recruiters, even at agencies, use phone or video and send contracts through company email or a signing platform.
- **Unknown number, and a first contact that is a fixed-time interview for tomorrow.** Urgency and an unusually fast process are common in these scams.
- **Vague details.** There's no company name, job title, or pay, and the message says "remote" and "flexible hours," which are common bait.
- **"Found your profile online."** This might be true if you applied on a job board, but scammers use the same line when they've scraped profiles.

Scams like this often go on to ask for ID or bank details, a fee for equipment or training, or payment for "tasks" that turn out to be fake. Some involve sending money back after a fake overpayment.

**Before you reply, you could check:**

1. **Find the original application.** Look in your job board or email history for the role. If there's no matching application, treat this as suspicious.
2. **Ask specific questions.** Which company is hiring, what's the exact job title, and where did they see your application? A real recruiter can answer these immediately.
3. **Verify independently.** Look up the company and the consultancy on their official website, LinkedIn, or your country's company register. Don't use contact details from the message.
4. **Ask for a video call.** Say you only do interviews by video. A real recruiter will usually agree, and a scammer will often push back or disappear.
5. **Don't share anything yet.** That includes ID, National Insurance or Social Security numbers, bank details, or any payment. Don't click links or install apps they send.

If you can confirm the role is real, send me:
- the job posting or the company name and job title
- the recruiter's full name and the company they say they work for
- your CV

Then I'll run the mock-interview skill to build your prep pack: likely questions, answer guidance based on your background, and questions to ask them. If you'd rather start now, I can also prepare general answers for a remote role. Still, I'd verify first, since the interview could be a trap.