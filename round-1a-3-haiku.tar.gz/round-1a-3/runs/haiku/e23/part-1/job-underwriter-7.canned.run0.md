**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: direct: R1 (NMC registration), R2 (full UK licence)
- `must_have`: direct: R3 (one year post-registration), R8 (insulin); adjacent: R4 (own caseload), R5 (leg-ulcer wound care); unclear: R7 (continence), R9 (care planning), R10 (end-of-life visits), R11 (clear, timely records)
- `important`: unclear: R12 (electronic patient record)
- `preferred`: absent: R13 (Doppler assessment)

R6 (catheter care) is direct. R4 and R5 are credible bridges with their limits named. None of the unclear rows is contradicted by the CV; the CV is simply silent on them.

**Opportunity ledger.** The employer checks out as a real organisation. The posting itself could not be confirmed live (RR1), and the pay range and the named contact are useful positives (RR2, RR4).
- **Hard gates:** met: R1 `direct`, R2 `direct`. None failed. No other constraints were given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live, via the careers link or the recruiter's email domain (RR1); (2) the caseload and records expectations are confirmed in the informal chat; (3) nothing is claimed as caseload, end-of-life or Doppler experience that the CV does not hold.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` About page |
| Role | Community Staff Nurse, Band 5, district nursing for housebound adults: wound and leg-ulcer care, catheter and continence, end-of-life visits, insulin, care planning, EPR; own small caseload with senior community nurse support | `[grounded]` advert |
| Working pattern | Home visiting, pool cars provided, mileage stated | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Market calibration | A 2026 community staff nurse survey (n=1,240, England) gives median £34,300 and interquartile range £32,400–£36,600. The advert's range sits around that band. It is a survey, not the official Agenda for Change pay point, which I did not confirm | `[generic]` Wardround 2026 guide |
| Scope read | A caseload with supervision is the normal scope for a Band 5 community post | `[generic]` role-family pattern |
| Unknowns | Whether mileage is paid when a pool car is used; the caseload size; records expectations; the posting's live status | — |
| Contradictions | None between the advert and the About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC Adult registration | hard_gate | direct | medium | none | PIN and active status are stated in the CV; not yet checked against the NMC register | `[grounded]` CV | Check the PIN on the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated in the CV | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Own caseload, with senior nurse support | must_have | adjacent | medium | transferability | Discharge-to-assess home visits in the first week after discharge. Limit: no caseload ownership and no weeks-long follow-through | `[inferred]` from the CV's visit pattern | G1 |
| R5 | Wound care incl. leg ulcers | must_have | adjacent | medium | transferability | Pressure and surgical wound care stated. Leg-ulcer assessment is not claimed; limit named | `[grounded]` CV; `[inferred]` adjacency | G4 |
| R6 | Catheter care | must_have | direct | medium | none | Stated in the CV | `[grounded]` CV | none |
| R7 | Continence care | must_have | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | Q2 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated in the CV | `[grounded]` CV | none |
| R9 | Care planning | must_have | unclear | low | discovery | The CV does not state who planned care after the discharge visit | `[grounded]` CV silence | Q1 |
| R10 | End-of-life visits | must_have | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | Q2 |
| R11 | Clear, timely written records | must_have | unclear | low | discovery | Not evidenced; records are not mentioned in the CV | `[grounded]` CV silence | G3 |
| R12 | Electronic patient record | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | G3 |
| R13 | Doppler assessment | preferred | absent | none | capability | No evidence. The team lead has spoken publicly about Doppler training for staff new to community work | `[grounded]` speaker bio | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R4, must_have) | transferability | Home visits in the first week after discharge, without a caseload | The advert's core structure; it is the objection most likely to be raised | Any visit where you chose the next step: a dressing plan, a referral, a medication change you raised | An anonymised handover note or visit summary | `[inferred]` bridge from the visit pattern |
| G2 | Records and EPR (R11, R12, must_have and important) | discovery | Records are not mentioned | The advert asks for "clear, timely written records" and an EPR; both are checked in practice | Any documentation you owned, including discharge summaries and entries in an electronic system | An anonymised record excerpt | `[grounded]` CV silence |
| G3 | Leg ulcers and Doppler (R5, R13) | transferability; capability | Pressure and surgical wounds; no leg-ulcer or Doppler work | Leg-ulcer care is named in the advert, and Doppler is desirable | Any venous or arterial assessment, compression, or dressing-led ulcer care | A training record or course certificate | `[grounded]` advert and speaker bio |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | risk_signal | medium | "Current vacancies are listed on our careers page" (About page); careers page not found | The advert may be out of date, or on a different page or site | `[inferred]` from the failed fetch | Can you send the live posting link, or the recruiter's email domain? | unresolved |
| RR2 | Pay range sits around the surveyed band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is competitive for the title | `[grounded]` advert; `[generic]` survey band | none | noted |
| RR3 | Mileage with pool cars | unknown | — | "pool cars are provided" alongside "plus mileage" | Mileage may apply only to your own car | `[inferred]` from the two terms | When a pool car is used, is mileage paid, and for which journeys? | unresolved |
| RR4 | Caseload with supervision | positive_signal | — | "supported by a senior community nurse" | Supervision is built in | `[grounded]` advert | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the seconded role in your own words: "Seconded to the discharge-to-assess team for 18 months, visiting patients at home in their first week after discharge." Do not describe it as a caseload | R4 | `[grounded]` your CV | resume_edits_pending_approval |
| A1 | Confirm the posting is live before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | In the informal chat with Rhiannon Mabbott, ask about caseload size, records expectations, mileage with pool cars, and Doppler training for new staff | R4, R11, RR3, R13 | `[grounded]` advert and speaker bio | pending your approval |
| A3 | Lead with home-visit and wound experience; state leg-ulcer and Doppler work as not yet held, with the training you would take on | R5, R13 | `[generic]` the usual way community posts are screened | pending your approval |

Every proposed line above is a proposal, not finished text. The E1 wording uses your own sentences and adds no fact.

## Evidence status

Verified: none yet. Every row rests on your CV or the public web, and nothing has been checked against the NMC register or a document.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health community staff nurse Band 5 vacancy Halifax". Page: About Calderbrook Community Health (calderbrookhealth.example/about). The careers page fetch returned no page. Employer confirmed; posting not confirmed live: RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 nurse pay scale 2026". Page: Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Survey band only; the official pay point was not found. Moved market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook". Page: speaker bio on communitynursingforum.example/speakers/rhiannon-mabbott. Moved positioning: the speaker bio covers leg-ulcer clinics and Doppler training for new community staff |

## Upgrade menu

- The live posting link, or the recruiter's email domain → RR1 closes; the decision moves to `go` or `no_go`.
- An anonymised handover note or visit summary → R4 and R5 move from `medium` toward `high`.
- An anonymised record excerpt, or your EPR experience → R11 and R12 move from `low` to `medium`.
- A Doppler or leg-ulcer training record → R13 moves from `absent`.
- A deeper research pass on Calderbrook (leadership, funding, staff reports; up to 5 more searches and 2 more fetches), if you want it.

Dossier offer: if you want, I can write this assessment to a `tuesday-dossier.md` file for mock-interview to pick up later.

**Questions, one per gap:**
- RR1: Can you send the live posting link, or the recruiter's email domain?
- G1 (R9, R10): In the discharge-to-assess visits, what did you decide yourself, such as a dressing plan or a referral, and what did you pass on? Have you done any end-of-life visits or continence assessments? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G2 (R11, R12): Have you written records or entries in an electronic patient record that someone else relied on? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.