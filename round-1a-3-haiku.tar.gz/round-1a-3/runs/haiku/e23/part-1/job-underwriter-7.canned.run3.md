**Decision: `conditional_go`.** Apply. You meet all three hard gates on the evidence you gave, and your home-visit, wound, catheter and insulin work is close to what this role does day to day. The conditions are three gaps (caseload, end-of-life, electronic record) and confirming the employer is real, which I haven't checked.

**Fit ledger** (rows from the evidence map below)
- hard_gate: `direct` R0, R1, R2
- must_have: `direct` R3, R6a, R7a, R8a · `adjacent` R5, R6b, R8b · `unclear` R4, R7b (continence) · `absent` R9 (end-of-life visits)
- important: `unclear` R10 (electronic patient record)
- preferred: `absent` R11 (Doppler)

Your strongest matches are the hard gates and the autonomous post-discharge home visiting. The genuine gaps are ownership of a caseload and end-of-life work, and neither is a disqualifier.

**Opportunity ledger:** The posting looks ordinary on its face, but I have not verified the employer (RR2), and "plus mileage" sits oddly beside "pool cars are provided" (RR1). No red flags at `severity: high`.

- **Hard gates:** none failed (R0 `direct`, R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown (your pay floor and schedule limits).
- **Severe red flags:** none found.
- **What would change this:** `conditional_go` becomes `go` if the employer checks out, you confirm end-of-life and record-keeping experience, and the caseload model in the first year is supervised. It moves toward `hold` if the employer can't be confirmed, or if the role expects you to run a caseload alone from day one.

---

**Role reality** `[grounded]` from the advert: Band 5 district nursing; housebound adults at home; a small personal caseload with senior nurse support; EPR documentation; £31,050–£37,800 plus mileage. `[generic]` Band 5 is the usual entry band for a registered nurse, so the five years you have will not show in the grade. I have not calibrated the pay against market data.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| R0 | hard_gate | direct | high | — | Lives in or can reach Halifax | `[grounded]` You live in Halifax |
| R1 | hard_gate | direct | high | — | Current NMC registration, Adult | `[grounded]` PIN 19F4417X, active, revalidation March 2028 |
| R2 | hard_gate | direct | high | — | Full UK driving licence | `[grounded]` Category B |
| R3 | must_have | direct | high | — | 1+ year post-registration | `[grounded]` Five years as staff nurse |
| R4 | must_have | unclear | low | presentation | Clear, timely written records | Not stated in your CV |
| R5 | must_have | adjacent | medium | transferability | Holding a personal caseload | `[grounded]` 18 months' home visits in the discharge-to-assess team; you have never held your own caseload |
| R6a | must_have | direct | high | — | Wound care | `[grounded]` Pressure ulcers and surgical wounds |
| R6b | must_have | adjacent | medium | presentation | Leg-ulcer care | Wound care is evidenced; leg ulcers are not named |
| R7a | must_have | direct | high | — | Catheter care | `[grounded]` Catheter care |
| R7b | must_have | unclear | low | discovery | Continence care | Not stated |
| R8a | must_have | direct | high | — | Insulin administration | `[grounded]` Insulin administration |
| R8b | must_have | adjacent | medium | transferability | Care planning | Discharge planning in the discharge-to-assess role `[inferred]` |
| R9 | must_have | absent | — | capability | End-of-life visits | Not stated |
| R10 | important | unclear | low | discovery | Electronic patient record | Not stated |
| R11 | preferred | absent | — | capability | Doppler assessment for leg ulcers | `[grounded]` You have never done one |

**Gap recovery queue** (no questions here; the questions are below)
- **G1 — caseload (R5):** You have run autonomous home visits but never held a caseload. Closes with: a description of your discharge-to-assess decision-making, or the supervision model the employer offers.
- **G2 — end-of-life (R9):** Closes with any end-of-life or anticipatory-care experience in any setting.
- **G3 — Doppler (R11):** Preferred, not required. Closes with a training commitment from the employer. `[generic]` Employers often teach this on the job.
- **G4 — written records (R4):** Closes with an anonymised example of your notes, or a description of your documentation.
- **G5 — electronic record (R10):** Closes with the name of the system you have used.
- **G6 — leg ulcers (R6b) and continence (R7b):** Closes with any leg-ulcer or continence work.

**Opportunity risk register**
- **RR1 — contradiction, `severity: low`:** "Plus mileage" alongside "pool cars are provided." Ask the recruiter whether mileage applies to your own car.
- **RR2 — unverified employer, `severity: medium`, standing:** I have not searched for Calderbrook Community Health CIC, so I cannot confirm it exists as described. Resolve with the live posting link, the employer's careers page, or the recruiter's email domain.

**Application plan** `[inferred]`
- Lead with the discharge-to-assess home visits: you have worked in patients' homes, not only on a ward.
- Lead with wound, catheter and insulin work as direct evidence.
- State plainly that you have not held a caseload, and that you have not done a Doppler assessment. Do not describe the home visits as caseload experience.
- No CV wording is proposed until you approve it.

**Research tier: L0 — no searches; user links read 0**

**Upgrade menu** (what each input would unlock)
- **Employer check (L1):** Verifies the employer and calibrates pay against the role family, closing RR2. Up to 5 searches and 2 page fetches.
- **Live posting link or recruiter's email domain:** Closes RR2 directly.
- **Electronic-record name:** Moves R10 from `unclear` toward `direct`.
- **An anonymised note example:** Moves R4 from `unclear` toward `direct`.
- **Your pay floor and schedule limits:** Lets the hard-gate check run against your own constraints.

If you'd like, I can save this assessment as `tuesday-dossier.md`, which a later mock-interview session can pick up.

---

1. Which electronic record system did you document in on the ward and in discharge-to-assess, and how did you keep your notes timely? (R10, R4)
2. Have you cared for anyone at end of life at home, in any role, including anticipatory medicines or a syringe driver? (R9)
3. Do you have the live posting link or the recruiter's email domain, so the employer can be checked? If you say yes, I can run the L1 employer check, with up to 5 searches and 2 page fetches. (RR2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.