**Decision: apply, with one check first.** Your essentials match well, and the two real gaps (holding your own caseload, Doppler) are a fair stretch for a Band 5 role. Before you spend time on the application, confirm the posting is live on the Calderbrook careers page, because my search found the employer but not the advert itself.

**Decision snapshot**
- Fit: strong on essentials and on the clinical core. Gaps are caseload ownership (never held one) and Doppler (desirable only).
- Hard gates: all met on your CV: NMC registration active, full licence, Halifax, pay range acceptable, pool car provided.
- Opportunity: employer exists as described [grounded, search snippet]. Posting not yet confirmed live [unverified].
- Decision: `conditional_go` pending the live-posting check. Once confirmed, this is a `go`.

**Role reality**
- The role is adult community nursing at home: wounds, catheters, insulin, end-of-life visits, care planning, and a small caseload with senior nurse support.
- Pay: £31,050–£37,800 plus mileage [posting]. The UK 2026 Band 5 community staff nurse median is £34,300, interquartile range £32,400–£36,600 [generic, Wardround 2026 survey]. The advert sits at market norm, and the top of the range is above the interquartile band.
- Mileage is usually paid for this role type [generic]. The posting says pool cars are provided, so ask what the mileage terms are.
- Organization: Calderbrook is an NHS-contracted community interest company running adult community nursing across Calderdale, founded 2015, with about 410 staff in four hubs [grounded, company About page via search snippet].

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Essential | Current NMC Adult registration | Met | High | none | CV, PIN active, revalidation March 2028 |
| 2 | Essential | Full UK driving licence | Met | High | none | CV, category B |
| 3 | Essential | 1+ year post-registration | Met | High | none | CV, five years staff nurse |
| 4 | Essential | Clear, timely written records | Unknown | Low | discovery | Not on CV; no evidence either way |
| 5 | Core | Wound care | Met | High | none | CV: pressure ulcers, surgical wounds |
| 6 | Core | Leg-ulcer care | Partial | Medium | transferability | Wound work is strong; leg ulcers not named |
| 7 | Core | Catheter and continence care | Partial | Medium | discovery | CV covers catheter care; continence not named |
| 8 | Core | Insulin administration | Met | High | none | CV |
| 9 | Core | Home visits and care planning | Partial | Medium | transferability | Discharge-to-assess home visits [grounded]; care planning inferred |
| 10 | Core | End-of-life visits | Unknown | Low | discovery | Not on CV |
| 11 | Core | Own small caseload | Not met | n/a | capability | Never held one |
| 12 | Core | Electronic patient record | Unknown | Low | discovery | Not on CV |
| 13 | Desirable | Doppler assessment | Not met | n/a | capability | Never done |

**Gap recovery queue** (what closes each gap, no questions here)
- Row 4 (written records): an example of your discharge or visit notes, anonymised, closes it.
- Row 6 (leg ulcers): any leg-ulcer patients from discharge-to-assess or ward work, even if not labelled as such.
- Row 7 (continence): any continence care or assessment in your current role.
- Row 10 (end of life): any end-of-life or palliative patients you have cared for.
- Row 11 (caseload): the strongest route is a sentence on how you managed your own list of visits in discharge-to-assess. Closing it fully needs a first caseload, so frame it as transferable, not as held.
- Row 12 (EPR): name any electronic record system you have used.
- Row 13 (Doppler): a training course or a plan to undertake one. Desirable only, so it does not bar you.

**Opportunity risk register**
- Posting not confirmed live [severity: medium]: check the Calderbrook careers page, or ask the contact for the live link.
- Caseload expectations [medium]: ask what size caseload is typical for a new starter and what support the senior nurse gives.
- Mileage terms [low]: pool car provided; ask whether mileage is also claimed.

**Application plan (as far as evidence allows)**
- Lead with the discharge-to-assess home visits and the wound and insulin work: that is your verified story for this reader.
- Frame caseload as the next step, using the visit-management point above. Do not describe it as held.
- Don't claim Doppler or leg-ulcer experience you can't evidence. Say you're keen to train in Doppler.
- Any CV wording goes through approval before use. Nothing is drafted for external use yet.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Search: "Calderbrook Community Health CIC Halifax". About page seen via search snippet; careers page not fetched, so the posting's live status is unconfirmed |
| 2. Role-family pay sweep | yes | Search: "Band 5 community staff nurse Halifax district nursing salary…". Wardround 2026 guide |
| 3. Hiring manager footprint | skipped | Contact named (Rhiannon Mabbott); not searched, to keep to your request |

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

**Dossier offer:** I can write a `tuesday-dossier.md` file with this assessment, to reuse in later rehearsal, if that would help.

**Upgrade menu** (each input and what it unlocks)
- A live posting link: confirms the role and closes the risk-register check.
- An anonymised visit note: raises the written-records row.
- A list of caseload-like work: moves caseload from "not met" toward "transferable".
- Deeper company research at L2 (funding, churn, recent news; up to 5 more searches and 2 more fetches): offered once, only if you want it.

**Questions** (response mode: answer in prose; skipping is fine)
1. Row 10: have you cared for any end-of-life patients, in or out of hospital?
2. Row 12: which electronic record system have you used?
3. Row 11: how did you organise your own visits in discharge-to-assess, and how many did you typically carry?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.