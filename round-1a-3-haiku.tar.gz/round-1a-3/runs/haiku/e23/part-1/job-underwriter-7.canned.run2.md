**Worth applying for, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 (NMC registration), R2 (full UK licence), R3 (Halifax location). Unclear: R4 (pay against your floor, which you haven't given).
- `must_have`: direct: R5 (post-registration experience), R6 (pressure and surgical wound care), R8 (catheter care), R9 (insulin administration), R7 is adjacent: leg-ulcer care. Adjacent: R12 (holding a caseload). Unclear: R11 (end-of-life visits), R10 (care planning), R13 (clear, timely written records).
- `important`: unclear: R14 (electronic patient record).
- `preferred`: absent: R15 (Doppler assessment).

- **Hard gates:** none failed. Met: R1, R2, R3. Unconfirmed: R4 (pay against your floor; no floor given).
- **Severe red flags:** none found on the posting's own text.
- **Conditions for go:** (1) confirm the posting is live and the employer is as described, which I haven't checked; (2) check the pay and mileage against your floor; (3) present leg-ulcer care and caseload work as adjacent, not as held experience.

**Opportunity ledger.** Sound on the page but under-specified. Caseload size, lone working, on-call and weekend cover are not stated (RR1, RR2). The employer is a CIC, so terms and pension may differ from NHS terms, and the posting doesn't say (RR3). Positives: pool cars and mileage are provided, and a named contact is given for an informal chat.

**Research tier: L0, no searches.** Nothing about the employer or the pay scale has been checked. Everything external below is `[generic]` or absent.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` posting |
| Remit | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic record | `[grounded]` posting |
| Working pattern | Own small caseload, supported by a senior community nurse | `[grounded]` posting |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` posting |
| Market calibration | Not run: no research at L0 | — |
| Unknowns | Caseload size, lone working, on-call, pension and terms, which EPR | — |
| Contradictions | None found within the posting | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Your CV states it is active, revalidation March 2028 | `[grounded]` CV | Check the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B on CV | `[grounded]` CV | none |
| R3 | Halifax location | hard_gate | direct | high | none | You live in Halifax | `[grounded]` CV, posting | none |
| R4 | Pay and mileage against your floor | hard_gate | unclear | none | discovery | No floor given, so the check can't run | `[grounded]` posting | Q2 |
| R5 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R6 | Pressure and surgical wound care | must_have | direct | medium | none | Stated on CV, ward-based | `[grounded]` CV | none |
| R7 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound assessment and dressing transfer, but venous or arterial leg-ulcer work isn't claimed | `[inferred]` from R6 | Q1 |
| R8 | Catheter and continence care | must_have | direct | medium | discovery | Catheter care stated; continence not stated | `[grounded]` CV | none |
| R9 | Insulin administration | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R10 | Care planning | must_have | unclear | low | discovery | Not stated; discharge work implies some planning | `[inferred]` | Q1 |
| R11 | End-of-life visits | must_have | unclear | low | discovery | Not stated on CV | `[grounded]` CV silence | Q1 |
| R12 | Holding own caseload | must_have | adjacent | medium | capability | Never held one; independent home visits in discharge-to-assess are the nearest evidence | `[inferred]` | Q3 |
| R13 | Clear, timely written records | must_have | unclear | low | discovery | Not stated; the posting makes it an essential | `[grounded]` posting | Q3 |
| R14 | Electronic patient record | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Q3 |
| R15 | Doppler assessment | preferred | absent | none | capability | Never done | `[grounded]` CV | Upgrade menu |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7) | transferability | Pressure and surgical wounds only | A core part of the remit | Any venous or arterial leg-ulcer dressing, compression or assessment, even as part of wider wound care | A redacted wound-care note | `[inferred]` |
| G2 | Caseload (R12) | capability | Visits without owning the case | The posting's main shift | Discharge-to-assess visits where you planned the next steps yourself | A description of one week's visits | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and lone working not stated | unknown | — | "a small caseload" | Lone visiting is normal for district nursing, but the load may be heavy | `[generic]` role-family pattern | How many active patients, and how many visits a day? | unresolved |
| RR2 | On-call and weekend cover not stated | unknown | — | none | Rota expectations may sit outside the posting | `[generic]` | Is there an on-call or weekend rota? | unresolved |
| RR3 | Terms unstated for a CIC employer | unknown | — | "Community Health CIC" | Pension and terms may differ from NHS terms | `[generic]` | Which pay and pension scheme applies? | unresolved |
| RR4 | Employer and posting not verified | risk_signal | medium | "Calderbrook Community Health CIC" | Unchecked, not necessarily false; no research has run | `[grounded]` absence of checks | Can you send the live posting or the CIC's own page? | unresolved |
| RR5 | Pool cars and mileage provided | positive_signal | — | "pool cars are provided" | Lowers the cost of the role | `[grounded]` posting | none needed | noted |
| RR6 | Band 5 after five years' experience | risk_signal | low | "Band 5" | Interviewers may ask why you're moving to community at this band | `[generic]` | How will you answer "why community, why Band 5"? | unresolved |

**Application plan** (every row proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC entry and its active status before applying | R1 | `[grounded]` | pending your approval |
| A2 | Ask Rhiannon Mabbott about caseload size, lone working, on-call, pay scheme and EPR at the informal chat | RR1–RR3, R13, R14 | `[grounded]` | pending your approval |
| A3 | Use a CV line along these lines: "Five years' acute medical nursing: wound care including pressure and surgical wounds, catheter care, insulin administration. Last 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge." | R6, R8, R9, R5 | `[grounded]` CV | pending your approval |
| A4 | Don't write "community nursing experience", "leg-ulcer experience" or "caseload management"; none of these is evidenced | Reframing audit | `[grounded]` | pending your approval |
| A5 | Ask at the chat whether Doppler training is provided in post | R15 | `[generic]` | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm the employer and that the posting is live (RR4) |
| 2. Role-family sweep | skipped | Would calibrate Band 5 pay and the caseload norm (RR1, RR6) |
| 3. Hiring manager's public footprint | n/a | No hiring manager named; the contact is a team lead |

**Upgrade menu**

- A link to the live posting or the CIC's own page → RR4 closes, and the first condition for go is met.
- Permission for a light research pass (up to 5 searches and 2 fetches) on the CIC and the Band 5 pay scale → the pay calibration and RR3 close.
- Your pay floor and mileage needs → R4 closes.
- A redacted wound-care note or a description of one week's discharge visits → R7 and R12 move up. Please don't send anything patient-identifiable.
- Any leg-ulcer or end-of-life work, even brief → R7 and R11 move.

If you want, I can write this up as a `tuesday-dossier.md` to take into the informal chat.

**Questions**

- **(R7, R11)** In the ward or discharge-to-assess work, have you dressed leg ulcers or been involved in end-of-life visits, even briefly?
- **(R4)** What's the lowest salary you'd accept, and do mileage costs matter to you on this role?
- **(R12, R13, R14)** Which electronic patient record have you used, and how did you write up your discharge visits?

Answer any of these, or say skip. I won't ask them again.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.