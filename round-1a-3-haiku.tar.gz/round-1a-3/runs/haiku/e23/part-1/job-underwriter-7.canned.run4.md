**Yes, worth applying, on conditions.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7, R9, R14 · adjacent: R6 (Leg-ulcer care), R11 (Care planning), R12 (Own caseload) · unclear: R8 (Continence care), R10 (End-of-life visits), R13 (Electronic patient record)
- `preferred`: absent: R15 (Doppler assessment)

R4 (`low`) is the record-keeping requirement, which the CV does not address either way.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given beyond location, so pay floor and schedule checks are unknown
- **Severe red flags:** none found
- **Opportunity ledger:** The employer checks out and the role is clearly scoped with named support (RR4). Three things are open: caseload support and lone working (RR1), whether mileage applies when pool cars are provided (RR2), and whether the posting is still live (RR3).
- **Conditions for go:** (1) RR1 answered: starting caseload size and lone-working arrangements are reasonable; (2) R4 and R13 confirmed: records and EPR system are trainable on the job; (3) RR2 clarified.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing across Calderdale under an NHS contract; 410 staff, founded 2015 | `[grounded]` About page, calderbrookhealth.example/about |
| Role | District nursing in housebound adults' homes; a small personal caseload supported by a senior community nurse | `[grounded]` JD |
| Working pattern | Home visits, pool cars provided, mileage stated | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | Median £34,300, IQR £32,400–£36,600 for Band 5 community staff nurses in England. The posting's bottom sits below that IQR and its top above it. | `[generic]` Wardround 2026 UK Community Nursing Pay Guide, n=1,240, wardround.example/2026-uk-community-nursing-pay-guide |
| Grade basis | "Band 5" with an NHS contract suggests Agenda for Change grading, but the posting does not say so | `[inferred]` |
| Unknowns | Caseload size, lone working, record system, end-of-life workload, pay scale and pension, whether mileage applies alongside pool cars | — |
| Contradictions | Pool cars provided alongside "plus mileage" | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse, current | hard_gate | direct | high | none | Registered Nurse (Adult), registration active, revalidation March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Full licence, category B | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | high | none | Five years as staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent | `[grounded]` JD; CV silence | Q1 |
| R5 | Wound care | important | direct | high | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | General wound care transfers; leg-ulcer management not on the CV | `[inferred]` | Gap queue G3 |
| R7 | Catheter care | important | direct | high | none | Stated on CV | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Gap queue G1 |
| R9 | Insulin administration | important | direct | high | none | Stated on CV | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Gap queue G1 |
| R11 | Care planning | important | adjacent | medium | transferability | Discharge assessment and planning, not ongoing care plans | `[inferred]` | none beyond interview |
| R12 | Own caseload | important | adjacent | medium | capability | Never held a caseload; autonomous home visits are the bridge | `[grounded]` CV; `[inferred]` bridge | Q1; gap queue G2 |
| R13 | Electronic patient record | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Q2 |
| R14 | Home visiting | important | direct | high | none | Home visits in the first week after discharge for 18 months | `[grounded]` CV | none |
| R15 | Doppler assessment | preferred | absent | none | capability | Never done | `[grounded]` CV | gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Continence and end-of-life (R8, R10) | discovery | Neither on the CV | Both are listed responsibilities | Any continence or end-of-life visits in the discharge-to-assess role | A line on the CV if true | `[grounded]` CV silence |
| G2 | Own caseload (R12) | capability | Never held one; home visits are the bridge | The post is a caseload post | Autonomous home visits; any patient lists | Caseload details from the employer (Q1) | `[inferred]` |
| G3 | Leg-ulcer care (R6) | transferability | Wound care is direct, leg-ulcer specifics not stated | Leg-ulcer care is a named responsibility | Any compression or leg-ulcer patients on the ward | A CV line if true | `[inferred]` |
| G4 | Doppler (R15) | capability | Never done | Desirable only | Ward or training exposure to vascular assessment | A training plan or course | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload support and lone working unspecified | unknown | — | "supported by a senior community nurse" | Support may be thin in practice, with a new caseload holder working alone in patients' homes | `[inferred]` from the posting's silence | What caseload size would a new holder start on, and how is lone working in patients' homes managed? | unresolved |
| RR2 | Mileage stated alongside pool cars | risk_signal | low | "plus mileage" and "pool cars are provided" | Mileage may apply only to own-car use, changing the real cost of the role | `[inferred]` from two clauses | When would mileage be claimed if pool cars are provided? | unresolved |
| RR3 | Posting liveness not confirmed | risk_signal | low | "For an informal chat… contact Rhiannon Mabbott" | The listing may be stale; the employer is confirmed, the posting is not | `[generic]` pattern for listings without a live link; careers page not fetched | Is this post live on your careers page, and who would I be working with day to day? | unresolved |
| RR4 | Named senior support and a defined caseload model | positive_signal | — | "supported by a senior community nurse" | The start is structured and not a sink-or-swim caseload | `[grounded]` JD | — | noted |

## Application plan

- **Lead with:** home visiting after discharge, wound care (pressure and surgical), insulin, and catheter care. These are the direct matches.
- **Say plainly:** caseload-holding and Doppler are new. Do not present discharge-to-assess as district nursing caseload experience.
- **Address directly:** if asked about leg ulcers, describe the general wound-care skill and say you would learn the specifics.
- **Resume edits pending approval:** no edits yet. The current CV line on discharge-to-assess home visits is already accurate and is the strongest line for this role. Nothing here is to be added to your CV until you approve it.

## Evidence status

**Research tier: L1 — searches 2 of 5, fetches 1 of 2**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page fetched (calderbrookhealth.example/about) confirms the entity; careers page not reached, so the posting is unverified |
| 2 | Role-family sweep | yes | Query: "Band 5 community staff nurse Halifax district nursing salary 2026"; Wardround 2026 guide |
| 3 | Hiring manager's public footprint | skipped | Only a contact name for an informal chat was given; no footprint search was run |

## Upgrade menu

Offered once: deeper research (L2) would add company diligence (funding, leadership churn, public candidate reports) and recent news, up to 5 more searches and 2 more fetches. It would also check the careers page for liveness (RR3). Your own input would close the gap queue: any leg-ulcer, continence, or end-of-life work from your ward or discharge-to-assess role (G1, G3) would raise R6, R8 and R10. A Doppler course or ward exposure (G4) would be the only route to R15.

Dossier offer: I can write a `tuesday-dossier.md` file with this assessment if you want to keep it or take it to mock-interview.

**Questions** (answer any, all, or none; skipping is fine):

1. **(R12, RR1)** What caseload size would a new holder start on in this post, and how is lone working in patients' homes handled?
2. **(R13)** Which electronic patient record system is used, and is training given before the caseload starts?
3. **(RR2)** When would mileage be claimed if pool cars are provided?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.