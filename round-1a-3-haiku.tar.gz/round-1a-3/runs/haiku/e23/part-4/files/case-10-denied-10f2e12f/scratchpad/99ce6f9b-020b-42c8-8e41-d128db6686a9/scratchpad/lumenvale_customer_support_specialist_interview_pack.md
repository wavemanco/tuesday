# Interview prep: Customer Support Specialist, Lumenvale Software

**Round:** text-chat interview on Telegram with the support team lead (name not given). Fully remote. Recruiter contact: Marcus Hale, talent team.
**Built from:** the recruiter's message, your summary of the job ad, and your background. No search was run (research tier L0), so nothing here is about Lumenvale beyond what you gave me.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **JD**: does the listed requirement hold up. **EXP**: does your own work hold up under questions. **CASE**: a live problem from the role. **VAL**: values (none detected here). **CO**: company knowledge (none researched here).
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

The ad text itself was not supplied, so requirement quotes are your summary of it. Evidence quotes are your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, your summary) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | The years meet the count, in a different sector. Say it plainly: "I have three years as a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, your summary) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | The quote reaches the "or a similar ticketing tool" clause. It does not reach Zendesk, so say Freshdesk and what you do in it, and nothing about Zendesk. |
| F3 | "clear written communication" (job ad, your summary) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is not clarity, and the bridge should not stretch it. This interview is itself the evidence. Answer slot: if you have a way you check written replies, say what it is; if you don't, say so plainly and say how you would check a reply before sending it. |
| F4 | "confidence handling escalations" (job ad, your summary) | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you have handled or passed on an escalation at work, say what you did and why; if you have not, say so plainly and say how you would decide when a case needs escalating. |
| F5 | Not in the ad: software company background | "I've never worked for a software company" (your message) | none | [grounded] | capability | A stated absence, so the words are yours: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. |

**Not a requirement row, but your strongest support:** "I trained four new starters on our refunds process last year" (your message). It is a training record. It does not show that you designed the process.

## Prohibited claims

Built from the fit snapshot. These are wordings to avoid, even under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have used Zendesk" | Inflated form of F2 | Your material says Freshdesk, daily. The material says Freshdesk, not Zendesk. |
| "I designed or set our refunds process" | Inflated form of the training quote | "I trained four new starters on our refunds process last year." The material says you trained on it, not that you set it. |
| "I have worked in software support" | Stated negative, F5 | "I haven't worked for a software company." |

## Persona table

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 5 (deepest) | Team lead as hiring manager is a Skeptic-plus-Case prior. Four of five rows (F2 to F5) are gaps a team lead will probe. |
| Case / Strategist | 4 | Live support scenarios are how a team lead tests escalations and written replies. |
| Data-Driven Prober | 3 | Your headline figure, around 60 a day, invites a "how was that counted" probe. |
| Conversational | 2 | A friendly opener in chat is still scored on communication. |

Not weighted: Pressure (the text format and manager prior do not favour it, so expect at most one short challenge) and Values (no values round detected).

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. Why should we take a chance on you?" | JD | [grounded] "I've never worked for a software company" (your message) | Start with the plain statement: "I haven't worked for a software company." Then the strongest thing you carry: "I use Freshdesk every day" and three years of customer contact. Concede what you need to learn, the product and its internal tools, as a plan. Hold through two follow-ups by returning to Freshdesk and the three years. Do not argue that the gap doesn't matter. | **Highest-ROI prep in this pack.** F5 is the one negative you stated, and this is its sharpest form. |
| A2 | "The role asks for Zendesk or a similar tool. What's your experience with that?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say Freshdesk and what you do in it, in those terms. Answer slot: if you have used Zendesk, say where and how much; if you have not, say so plainly and describe how you would learn its ticket views and workflows in your first week. | F2 is medium: the "similar tool" clause is met, Zendesk is not. JD-tagged because the ad names it. |
| A3 | "Tell me about an escalation you handled. What did you decide?" | JD | [inferred] (no candidate sentence) | Open prompt. Answer slot: if you have handled or passed on an escalation at work, pick one and say what you decided and why, in your own words. If you have not, say so plainly and walk through how you would decide whether a case goes up. | F4 is a discovery gap and the ad raises escalations, so the team lead may ask. No past is claimed. |
| A4 | "Why are you moving from energy into a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Give your real reason in your own words. Don't use "passion for software" unless it is true. If your reason is not settled yet, say so and say what you would want to find out. | A motivation probe for the Skeptic. The answer should connect your three years to the move, not invent a motive. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in: their refund was promised three weeks ago and still hasn't arrived. Reply to them here, as you would send it." | CASE | [generic] | The reply is the assessment. Acknowledge the specific problem; say what you are checking now; give a timeframe only if you can commit to it; ask only for what you need. Short, plain sentences, no jargon, no promises you cannot check. | Live test of written communication (F3) in the same medium as the interview. A scenario, so it asks nothing about your past. |
| B2 | "Your queue has 40 open tickets and two are urgent escalations from a customer. What do you do in the first ten minutes?" | CASE | [generic] | Triage by impact and deadline. Handle or hand off the urgent two first. Say what you would tell the other customers and when. | Tests the escalations gap (F4) live, without asking about your past. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Roughly how many of your 60 daily contacts were emails, and how was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the figure as you know it, keeping "around". Name the assumption you would defend least: if the 60 is an estimate, say so. Answer slot: if you tracked the split, say how; if you estimated it, say that. | The figure raises a defend-the-number probe. Do not explain a method you cannot repeat. |
| C2 | "Tell me about the refunds training you ran. How did you decide what to cover?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say who you trained and what the sessions covered, in your words. Answer slot: if you chose the content, say how; if it came from a set process or someone else, say so plainly. | Your strongest bridge for process and coaching questions. The prohibited claim "designed the process" is the trap here. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" (your message) | A 60 to 90 second arc: where you started, the three years, Freshdesk daily, training the new starters. Stop there. Don't add a story. | A casual opener that is still scored. It also covers the 2+ years requirement (F1). |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | D1, A4 |
| Zendesk or a similar ticketing tool | A2 |
| Clear written communication | B1, C1 |
| Confidence handling escalations | A3, B2 |
| Software company background (not in the ad) | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a normal week look like for ticket volume per agent?" | Shows you are thinking about the load, and gets real numbers. |
| R2 | "How does the escalation path work between support and the product team?" | Tests the escalations gap and asks a real process question. |
| R3 | "Which tools does the team use day to day, and how much of that is Zendesk-specific?" | Gets the tool gap out in the open early. |
| R4 | "What does the first 30 days look like for someone new to the product?" | Shows you are planning your ramp. |
| R5 | "How does the team judge a good written reply? Is there a quality review?" | Tells the team lead you care about the thing the interview is testing. |

No interviewer profile was given, so no interviewer-path question is included. The team lead is a manager, not a peer, so no reciprocity question is needed.

## Sources

Research tier: **L0**. No search or fetch was run in this pass.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | A values cheat sheet. No values round was detected, so it would not be a section. |
| 2. Lumenvale interview process | unavailable | Confirmation of the loop. Your message describes one round. |
| 3. Lumenvale strategy / recent news | unavailable | A grounding brief. Less key for a support role. |
| 4. Team lead's name | n/a | No name was given, so there was no query to form. |
| 5. Representative job ad | skipped | Your summary of the ad fixes the fit snapshot. |

Provided documents: the recruiter's Telegram message; your summary of the job ad; your background.

## Upgrade menu

- The full job ad text → the requirement quotes become exact, and A2 and A3 can cite its wording.
- The team lead's name → a tailored reverse question, and persona weights from their public footprint.
- Research at L1 (consented) → Lumenvale's values, support model and any published interview process.
- Any Zendesk experience, if true → rewrites A2 from an answer slot to a story.
- Any escalation you handled or passed on → upgrades F4 and A3 from answer slots to stories you can tell.
