# Lumenvale Software: Customer Support Specialist interview pack

**Role:** Customer Support Specialist, remote. **Company:** Lumenvale Software. **Round:** text-chat interview on Telegram with the support team lead (treated as a hiring-manager round). **Interviewer:** team lead, name not given. Marcus Hale (talent team) made first contact.
*First version. Nothing has changed yet.*

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the ad's requirements), EXP (your past work), CASE (a live problem), CO (company knowledge, not covered here).
- Guidance is scaffolding, not a script. Write answers in your own words.
- **Chat format:** the team lead reads your answer rather than hearing it. Keep each reply to a few short paragraphs. Answer the question first, then the detail. Do not paste a memorised paragraph.

## Prep triage

Time available was not given, so no schedule is set. Start with **A2**, the highest-ROI rehearsal, then **A1** and **A3**. Everything else is insurance.

## Fit snapshot

Requirements are quoted from your summary of the ad, since the full text was not supplied. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap on years. Say the role title and years in the quote's own words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool. Name it. Do not claim Zendesk. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | transferability | Your material shows email volume, not the quality of what you wrote. Answer slot: if you have a written reply you are proud of, say what it had to do and how you wrote it; if you have none, say so and say how you check your writing before sending. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show escalations you handled. Answer slot: if you escalated a case, say what you checked before escalating and what you handed over; if you did not, say so and say what you would do first. |
| F5 | Software company background (implied by the role; not in your summary of the ad) | "I've never worked for a software company." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |
| F6 | Refund handling (not an ad requirement; you raised it) | "I trained four new starters on our refunds process last year" (your message) | medium | [grounded] | transferability | Shows you know a process well enough to teach it. Does not show you decided refunds alone. Keep to "trained others on it". |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| 2+ years in customer support | A1, C2 | |
| Zendesk or similar ticketing tool | A1, D1 | Freshdesk only |
| Clear written communication | A4, A5 | |
| Confidence handling escalations | A3, B2 | |
| Software company background (implied) | A2, C2 | |

## Prohibited claims

Built locally from the fit snapshot. These claims are not coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2. The quote names Freshdesk only. | "I use Freshdesk every day." Name Freshdesk. |
| Product knowledge of a software company | Inflated form of F5. No quote says you know a software product. | "I haven't worked for a software company." Then the plan. |
| Escalations you handled | Inflated form of F4. No quote covers it. | Answer slot only. No claim. |
| A track record of writing customer replies that were praised or reviewed | Inflated form of F3. The quote is volume, not quality. | "answering around 60 calls and emails a day", at its own scope. |
| Owning refund decisions | Inflated form of F6. The quote says you trained others. | "I trained four new starters on our refunds process." |

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Pointed questions on the software gap and the step from energy to software | **High.** A team lead interviewing for a software support role will see F5 at once. | Hold the plain acknowledgment, then the plan. |
| Case / Strategist | A live support scenario, written out | **High.** Hiring-manager prior: they want to see how you would handle a real queue. | Clarify first, then structure, then write the reply. |
| Pressure | Quick follow-ups in the chat, pressing on the 60 a day and on escalations | **Medium.** Chat follow-ups come fast. The 60 figure invites a probe. | Hold through two follow-ups, then concede the specific. |
| Data-driven prober | Asks how the 60 a day was counted | **Medium.** A figure in your message is a probe target. | Say how you counted, or that you did not. |
| Conversational | A casual opener, "tell me about yourself" | **Low to medium.** Casual openers are still scored. | Prepare a 90-second arc. |

## Question banks

**Type key:** JD = ad requirement; EXP = your past work; CASE = live problem.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've spent three years in energy customer service. Why does that qualify you for a software support role?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message); [grounded] "I've never worked for a software company." (your message) | Open with the role in the quote's words. Then name the ticketing tool you use every day. Then state the software gap in your own words without arguing it away. Close with how you would learn the product. About 90 seconds. | F1 meets the years requirement and F2 the tool requirement. F5 is the likeliest objection. |
| A2 | "You've never worked for a software company. What will you do in your first month when you don't know the product?" | JD | [grounded] "I've never worked for a software company." (your message) | **Highest-ROI rehearsal in this pack.** Hold: "I haven't worked for a software company." Then a plan: what you would learn first, who you would ask, and how you would use the ticket history. Hold through two follow-ups by returning to the plan. Concede the specific: "For the first few weeks I'll be slower than someone who knows your product. Here's how I'd close that." | F5 is the stated gap the role presses hardest. A rehearsed plan beats a bluff. |
| A3 | "Tell me about a case you escalated. What did you do before handing it on?" | JD | [grounded] "confidence handling escalations" (the ad, as you summarised it). Nearest material: "I trained four new starters on our refunds process last year" (your message) | Selection scaffold: pick a case that went to a supervisor or another team; say what you checked first, what you wrote in the handover, and what you did when it came back. If no such case comes to mind, say so plainly, then say how you would handle a refund dispute you could not settle alone, drawing on the refunds process you taught. | F4 has no quote. The question is an open prompt. The honest branch is built in. |
| A4 | "Here's a customer whose refund is a week late and who is angry. Write your reply in three to four sentences." | CASE | [generic] | Acknowledge the wait without blame. State what you know. Give one dated next step. Make no promise you cannot keep, and invent no policy. | A live written task that tests clear written communication. No claim about your past. |
| A5 | "How do you check your own written replies before you send them?" | JD | [grounded] "clear written communication" (the ad, as you summarised it). Also: "answering around 60 calls and emails a day" (your message) | Answer slot: if you have a habit, describe it. If you do not, say so and describe what you would adopt. | F3 is thin. The honest answer is ready before the probe. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Forty tickets about a failed login arrived this morning. Walk me through your first hour." | CASE | [generic] | Clarify: how many customers, since when, any status page. Triage by impact. Tell customers what is known. Then escalate to engineering with a clear write-up. | A live queue problem from the role. No claim about your past. |
| B2 | "How would you decide whether a ticket goes to engineering or stays with you?" | CASE | [generic] | Name the criteria: whether you can reproduce it, the impact, what you have already tried, and any deadline the customer has. Say what you would include in the handover. | Tests escalation judgement, the ad's requirement. No claim about your past. |

### C. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your 60 contacts a day. How many were resolved on first contact?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend-the-number, in your own words. Say how you counted, if you did, or say plainly you have no first-contact figure. Name the assumption behind the 60 you would defend least. Say which part was yours. Hold one follow-up, then concede what you do not know. | The 60 is a figure. Figures are probe targets. The honest branch is "I don't know". |
| C2 | "Why should we take three years in energy over someone who has run a software support queue?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I've never worked for a software company." (your message) | Hold: the role you held is the one in your quote, and the queue the team lead runs is one you have not run. Hold through two follow-ups: say what you bring that matches your quotes, and do not claim the software experience. Concede the specific: "They've run that queue and I haven't." | F1 and F5 meet at this question. Hold, then concede. |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message) | 90-second arc: your role, the tool you use daily, one thing from the refunds process you taught, why you want software support. | The chat opener is scored even when it is casual. |
| D2 | "What's the part of customer support you enjoy most?" | EXP | none given | Selection scaffold: pick a moment you enjoyed. Keep it to one. If none comes to mind, say so and name the part you do enjoy. | An open prompt with no claim to check. |

## Reverse questions

Ask any five or so, at the end.

1. **"What does a new person's first week look like on the queue, and who would I shadow?"** Why it lands: shows you are planning around F5.
2. **"Which ticketing tools does the team use today?"** Why it lands: signals you know the tool question matters.
3. **"What makes an escalation to engineering easy for them to act on?"** Why it lands: shows you care about the handover, the ad's escalation requirement.
4. **"What's the most common reason a ticket gets reopened?"** Why it lands: shows you think about quality, not only volume.
5. **"What would you most need from someone in their first 90 days?"** Why it lands: a question a hiring manager answers in their own terms.

## Sources

Provided documents: your message (the ad summary and your background). **Research tier: L0.** No web search was run. The pack uses only what you gave.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Values cheat sheet. Not run at L0. |
| 2. `Lumenvale Software interview process` | unavailable | Loop structure and persona weights. Not run at L0. |
| 3. `Lumenvale Software strategy / recent news` | unavailable | Company knowledge (CO) questions. Not run at L0. |
| 4. `{team lead name} Lumenvale Software` | n/a | No name given. |
| 5. Representative Customer Support Specialist JD | unavailable | Would have turned the ad summary into a full quoted requirement set. Not run at L0. |

## Upgrade menu

- **Full job ad text** → turns the ad-summary quotes into exact requirement quotes, and sharpens the escalations question (A3, B2).
- **Your CV** → grounds F1 to F3 in the document itself, not your message.
- **Examples of an escalation you handled and a written reply you wrote** → upgrades the F3 and F4 answer slots into story-mapped answers.
- **The team lead's name, if they introduce themselves** → lets the interviewer read tune persona weights and the reverse questions.
- **Whether the Telegram chat is one session or several stages** → if several, per-stage mini-packs.
- **Search consent (L1)** → company values, the interview process, and recent news, which would add CO and values questions.
