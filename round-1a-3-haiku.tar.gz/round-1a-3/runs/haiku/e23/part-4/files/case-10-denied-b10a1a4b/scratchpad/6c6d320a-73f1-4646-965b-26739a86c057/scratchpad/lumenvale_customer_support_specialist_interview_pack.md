# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Candidate: Imani. Round: first interview, text chat on Telegram with the support team lead. Recruiter contact: Marcus Hale, talent team.
Built at research tier L0 (provided documents only). The web search tool was not permitted in this session, so nothing about the company has been checked. See Sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your experience), JD (the listed requirements), CASE (a live problem), VAL (behaviour), CO (company knowledge; not used here, since no company research ran).
- Guidance is scaffolding, not a script. Write answers in your own words, and only say what you actually did.
- Every candidate sentence a guidance cell rests on is quoted in the Provenance column. Anything in an answer slot is for you to fill in honestly, including "that wasn't me" or "I haven't done that."
- This is a text interview, so write each answer in full sentences, short paragraphs, no abbreviations or slang. Your written reply is itself being assessed.

## Fit snapshot

Requirements are the four JD lines and the software-company gap, from your message. Evidence is quoted from your message or CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, per your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | Covered in role-relevant terms. Say it as you wrote it: three years as a customer service advisor at an energy supplier. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, per your message) | "I use Freshdesk every day" (your message) | high | [grounded] | none | Freshdesk is a ticketing tool and reaches the "similar tool" wording. Do not say you have used Zendesk; the material does not show it. |
| F3 | "clear written communication" (job ad, per your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows volume of written contact, not the quality of it. Answer slot: if anyone has given feedback on your written replies, say what they said; if no one has, say so and say how you would check the clarity of yours. |
| F4 | "confidence handling escalations" (job ad, per your message) | none given. Adjacent: "I trained four new starters on our refunds process last year" (your message) | none given | [grounded] | discovery | Your material does not show escalation work. Answer slot: if you have handled or passed on escalations, say what you did; if not, say so plainly. |
| F5 | no software-company background (your note; not a listed JD line, but likely to be raised) | "I've never worked for a software company" (your message) | none | [grounded] | capability | You stated the absence, so you may say it plainly: "I haven't worked for a software company." Do not add anything to make it sound smaller. |

**Observation for you, not for the interview:** F3 and F4 are the two requirements where a skeptical interviewer will look for evidence, and your material is silent on both. That is where the rehearsal time should go.

## Prohibited claims

Not coached, and why. Each honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2. You said Freshdesk. | "I use Freshdesk every day." |
| Ran new-starter training or onboarding | Inflated form of "I trained four new starters on our refunds process last year." | "I trained four new starters on our refunds process last year." |
| Resolved 60 tickets a day | Inflated form of "answering around 60 calls and emails a day." The figure is around 60 and mixes calls and emails. | "Around 60 calls and emails a day." |
| Experience with software products or escalation handling | Not stated anywhere in your material. | Answer slots F3 and F4 only. |

## Persona table

Relationship prior: hiring manager (a support team lead). Priors: Skeptic and Case/Strategist, per the persona model. Adjustments: the job ad is a short list of four requirements with two gaps (F3, F4) and a software-company gap (F5), so the Skeptic rises. A text chat with a team lead makes a written case task likely. No public profile was available, so no interviewer-signal adjustments were made.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no Zendesk, no software company, no escalation evidence | High. The gaps are visible from the CV. Weight 5 | Rehearse the single most likely objection until it is plain. Acknowledge what you stated, then return to what you did |
| Case / Strategist | Live support problems, in writing | High for a team lead hire. Weight 4 | Clarify facts first, then the next step, then what you would write |
| Data-Driven Prober | Asks how the 60 figure was counted, and what share you finished yourself | Medium: one headline figure invites a probe. Weight 4 | Say "around 60" and name the assumption you are least sure of |
| Conversational | Casual opener, casual questions about tools | Medium: a chat format is informal, but casual questions are still scored. Weight 3 | Give a 90-second arc and treat casual questions as scored |
| Values / Behavioural | Stories about escalation and bad news | Medium. No published values were found, so the values cheat sheet is dropped. Weight 2 | Use a real story if you have one; if not, say so and give the nearest thing you did |
| Pressure | "Why should we hire you over someone with software experience?" | Low to medium. Weight 2 | Hold the position through two follow-ups before conceding anything |

## Question banks

Question-type tags: JD, EXP, CASE, VAL. Persona depth follows weight: 5, 4, 4, 3, 2, 2.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You use Freshdesk, not Zendesk, and you've never worked for a software company. Why should we consider you?" | JD | [grounded] "I use Freshdesk every day" / "I've never worked for a software company" | Highest-ROI prep. Say the plain acknowledgment first: "I haven't worked for a software company." Then say what you do have: the Freshdesk work you do every day, and three years of answering around 60 calls and emails a day. Hold through two follow-ups by returning to those two facts. Answer slot on Zendesk: if you have used Zendesk, say where; if not, say so and say how you would get productive in it in your first two weeks. | This is the most predictable objection: it combines the JD's tool line with the software gap, F2 and F5. The guidance answers it with what you did, not with a bigger claim |
| A2 | "Tell me about a time you handled an escalation." | JD | [grounded] "I trained four new starters on our refunds process last year" | Open prompt, so pick a real instance. Selection scaffold: a time a customer's problem went past what you could resolve yourself and you passed it on. Name the stake, what you did before passing it on, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the refunds process you trained four people on, in your own words. Answer slot: do not borrow the training as escalation experience. | F4 is a discovery gap, and the JD names the requirement directly. The honest answer is the real instance, or the plain statement that there was none |
| A3 | "How do you know your written replies are clear to customers?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot. If anyone has given feedback on your written replies, say what they said. If no one has, say so and say how you would check the clarity of your own replies, such as rereading them as the customer would. Make the point that this text interview is itself a sample of your writing. | F3 is a discovery gap for written communication. The answer may be a plan, not a past |
| A4 | "What would you find hardest in this role on day one?" | VAL | [grounded] "I've never worked for a software company" | Name one specific gap honestly, using F5 and F4: the product, the escalation path. Then say what you would do in the first two weeks to close it. Do not claim you have already closed it | A calm, honest answer to the day-one probe is exactly what the Skeptic scores |
| A5 | "Why would you move from energy support into a software company?" | VAL | [generic] | Answer slot in your own words, from the motivation you actually have. Not from the job ad. Name one real reason and one thing you expect to learn | The question is about motivation, which your material does not state, so the guidance supplies no motivation |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that a refund still has not arrived after ten days, and the ticket has been reopened twice. What do you do first?" | CASE | [generic] | Structure: confirm the facts (order, refund route, promised date), read the ticket history, decide what you can promise, decide what must be escalated and to whom, then write the reply. Name what you would tell the customer and when | A live support problem for this role. The scenario needs no claim about your past |
| B2 | "A new starter asks how to handle a customer who wants a refund the policy does not cover. Write their reply." | CASE | [grounded] "I trained four new starters on our refunds process last year" | Write the reply in full sentences. Use the policy you know; if you are unsure of a rule, say so and name who would confirm it. Do not invent a policy. The reply should be clear, polite and say the next step | The scenario sits next to the training quote, but the guidance claims nothing beyond it. It also tests written clarity under a case |
| B3 | "Forty tickets are open on a Monday morning. How do you choose the order?" | CASE | [generic] | Structure: urgency and any deadline, customer impact, anything already escalated, then the rest. Say one trade-off you would accept | Tests prioritisation, a live problem for this role. No claim about your past |
| B4 | "What would your first two weeks learning our product look like?" | CASE | [generic] | Give a plan: what you would read, who you would shadow, what you would test. State that it is a plan. Do not present any of it as past work | Turns the product gap (F5) into a concrete plan, which is what the Skeptic wants to hear |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you arrive at around 60 calls and emails a day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around 60." Name the assumption you would defend least, in your words: for example, whether calls and emails were counted together, or over what period. Answer slot: if you counted or were told the figure, say how. If it is an estimate, say so. Never supply a method | Defend-the-number. The figure is in your CV, so the probe is likely |
| C2 | "Of those contacts, what share did you finish yourself?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot. If you tracked it, say the share. If you did not track it, say so plainly, then say what you handled yourself in your own words | Premised question with a false-premise branch: the material does not show a split |
| C3 | "You trained four new starters. What did the training cover, and how did you know it worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on the quote: four new starters, the refunds process, last year. Answer slot: if you checked how they did, say what you looked at. If not, say so | Your training line is the strongest concrete claim you have. The second half of the question presupposes an outcome measure the material does not show |
| C4 | "Walk me through your day in Freshdesk." | JD | [grounded] "I use Freshdesk every day" | Describe the parts of the tool you use each day, in your words. Answer slot: if you have set up or changed anything in it, say what; if you have only used it, say that | The Zendesk gap (F2) starts here. Describing daily use is accurate; claiming configuration is not |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself." | VAL | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: role, the energy setting, the daily volume, Freshdesk, and the training you did. Say it in full sentences | An opener. It is scored, even when casual |
| D2 | "What have you been playing with in ticketing tools lately?" | JD | [grounded] "I use Freshdesk every day" | Answer with Freshdesk. Mention another tool only if you have actually used it | Casual phrasing of the tool requirement |
| D3 | "What's the part of support work you find most satisfying?" | VAL | [generic] | Answer slot in your own words: one real thing, and why | Motivation your material does not state |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone with no software background over someone who has it?" | EXP | [grounded] "I've never worked for a software company" | Hold: acknowledge that you have not worked for a software company, then return to three years of answering around 60 contacts a day. Hold through two follow-ups. Concede only what is true: "You're right that I'd need to learn your product quickly; here is how I would do it" | Hold-then-concede. The concession is a plan, not a past |
| E2 | "That's a lot of calls for one person. How much of that was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold the position: you answered them. If others shared the queue, say so and say what your share was | A composure test. Stay with what you did |

### F. Values / Behavioural (weight 2)

No published values were found, so the values cheat sheet is not included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a customer bad news." | VAL | [generic] | Selection scaffold: a time you had to say no or pass on a bad outcome. Name the stake, what you said, how the customer responded. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the refunds process you trained others on | An open prompt. The theme comes from the persona stem |
| F2 | "How do you keep a customer informed when an answer takes too long?" | VAL | [generic] | Describe how you would update the customer and when. If you have done this, say when, in your own words. If you have not, say how you would do it | Tests customer communication under delay |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| 2+ years in customer support | C1, D1 | Covered by F1 |
| Zendesk or similar ticketing tool | A1, C4, D2 | F2 covered by Freshdesk; the Zendesk gap is an answer slot in A1 |
| Clear written communication | A3, B2 | F3 is a discovery gap |
| Confidence handling escalations | A2, B1 | F4 is a discovery gap |
| No software-company background (not a listed requirement) | A1, A4, E1 | F5 is a stated absence |

## Reverse questions

Each one tests something the interview will not otherwise show.

1. **"What would a first 90 days look like for this role, and what would you want me to know first?"** Why it lands: shows you are planning for the role, not only asking for it.
2. **"Which ticketing tool does the team use day to day, and how are escalations passed on?"** Why it lands: tests the JD's tool and escalation lines, and shows you read the ad.
3. **"How do you judge whether a written reply to a customer is good?"** Why it lands: asks the team lead to define the standard you are being judged on in this very chat.
4. **"Since the hiring process runs in this chat, could you confirm the careers page and the contact for offer paperwork?"** Why it lands: a reasonable question for any remote hire. Also see the safety note below.
5. **"What has made someone succeed in this team in the last year?"** Why it lands: shows you care about the people and the work, not only the title.

## Sources

- **Provided documents:** the candidate's message (background and the JD summary) and the recruiter's Telegram message.
- **Research tier:** L0 (provided documents only). Web search was requested twice and refused by permission, so no searches ran.
- **Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have set the values cheat sheet. Both search calls were refused. Values section dropped |
| 2. Lumenvale interview process, support role | unavailable | Would have set loop structure and persona weights. Call refused |
| 3. Lumenvale strategy / recent news | unavailable | Would have set CO questions. Not attempted under L0 |
| 4. Interviewer name and company | n/a | No interviewer name given beyond the team lead |
| 5. Representative JD | skipped | The JD summary you supplied fixes the fit snapshot |

## Upgrade menu

- The job ad text as posted → the requirement quotes become exact instead of your summary.
- Your written feedback history (any review, complaint or compliment on your replies) → A3 and F3 change from discovery to grounded.
- Any Zendesk use, even a trial or course → A1 and C4 gain a real quote.
- Any escalation you handled or passed on, with what you did → A2 becomes story-mapped instead of a selection scaffold.
- The team lead's name and the company's official site → a tailored reverse question, and a check on the Telegram contact (see the safety note).
- A web-search allowance → the values, interview-process and current-news targets, which would verify the company.
