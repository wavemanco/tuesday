**Don't go ahead. This is a scam, and you haven't sent anything yet, which is the right place to stop.**

Every stage matches a known fraud pattern:

- **Telegram-only hiring with no calls or video.** Real employers, including logistics firms, interview by phone or video and use their own company email.
- **Sensitive data before any real interview.** Asking for your IBAN, PPS number and passport photo at the "first screening" is identity theft in progress. A payroll department doesn't need your passport before it has met you.
- **Paying for your own equipment.** A legitimate employer supplies its own laptop and headset. Asking you to pay €349 to a third party "refunded with first wages" is advance-fee fraud.
- **The cheque.** This is the main trap. They send you a €2,850 cheque, you deposit it and transfer €2,500 to their "equipment partner" before the cheque clears. Cheques take days or weeks to clear, and when this one bounces, the bank reverses your deposit and you owe the shortfall. You'd also be moving money for strangers, which can make you a money mule, a criminal offence even if you didn't know.
- **"No experience needed" with "up to €26/hr plus commission per order."** The pay is vague and the commission is a lure, and the work is unspecified.
- **A generic contact address.** A "postmail" address isn't a company domain.

**What to do now**

1. **Don't send the IBAN, PPS number or passport photo, and don't pay anything or deposit any cheque.** If they send one, don't lodge it.
2. **If you've already shared any details,** tell your bank today so they can flag the account, and watch for unfamiliar activity. Report the PPS and passport exposure to the Gardaí and consider checking your credit report. Changing the passport would need the passport office, so only do that if the photo gets misused.
3. **Report the account and the posting.** Block @VellowayHiring in Telegram, report it there, and report the listing to the job site.
4. **Use your real search.** Your background fits real roles well: three years of customer service in a courier firm, about 60 Zendesk tickets a day, training new starters, and running a team tracker in Excel. Look for customer service, operations or logistics coordinator roles on company careers pages or reputable job boards, and get the employer's contact details from its own website, not from the posting. A real employer will interview you by video or phone and will never ask for money.

I didn't run any web research on Velloway. It isn't needed, since the messages alone are decisive.