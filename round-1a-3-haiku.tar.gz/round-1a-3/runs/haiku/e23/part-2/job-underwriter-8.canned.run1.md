**Do not send anything.** Don't paste your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit the cheque. This is a scam. The posting and the Telegram messages match the standard advance-fee and fake-cheque patterns, and the cheque step would make you the one moving money.

## Decision snapshot

**Not worth applying to. Status: `no_go`.**

**Fit ledger.**
- `must_have`: direct: R1, R2 · unclear: R3, R4
- `hard_gate`: unclear: R5 (pay floor against the posting's pay)

**Opportunity ledger.** Severe red flags: RR1 to RR4. The role itself is not the problem; the process is. Nothing in the posting or the messages offsets the red flags.

- **Hard gates:** none failed; unconfirmed: R5 (pay floor against "up to €26/hour plus commission")
- **Severe red flags:** RR1 (Telegram-only hiring), RR2 (bank and ID data requested before any interview), RR3 (upfront payment for equipment), RR4 (cheque with instructions to forward most of it)
- **Conditions that would change this:** none that a Telegram-only process can meet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics," identity not verified; the only contact is a Telegram handle and a `postmail.example` address | `[grounded]` posting and messages |
| Role | Remote order processing coordinator, 15–30 hours/week, self-set hours | `[grounded]` posting |
| Pay | "Up to €26/hour plus commission" | `[grounded]` posting |
| Hiring | Telegram only, no calls or video, interview held in chat | `[grounded]` posting and messages |
| Contract | Not stated: employee or self-employed, tax treatment unknown | — |
| Market calibration | Not run; research stayed at L0. The posting's own figures are enough to test the pay floor | — |
| Contradictions | Posting says "no calls or video interviews," but you were told you were interviewed in chat; the "passed interview" message came without a real interview | `[grounded]` messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | direct | medium | none | Your CV shows about 60 Zendesk tickets a day and a team tracker kept accurate. Self-reported, not verified | `[grounded]` CV | none |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported | `[grounded]` CV | none |
| R3 | Good written English | must_have | unclear | low | discovery | No writing sample; Zendesk work shows written customer contact, not language proficiency | `[inferred]` from CV | see G1 |
| R4 | A quiet place to work | must_have | unclear | low | discovery | Not stated anywhere | — | none |
| R5 | Pay that meets your €30,000 floor | hard_gate | unclear | high | hard_gate | €30,000 ÷ 52 ≈ €577/week, which is about 22 paid hours a week at €26. At the posting's 15 hours the pay is about €390/week (≈€20,300/year) before commission. Commission is unquantified and "up to" is not a guarantee | `[grounded]` posting and your floor; arithmetic `[inferred]` | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Pay floor (R5) and language (R3) | hard_gate / discovery | The posting withholds a guaranteed figure and a contract. Your English is not tested | Only a written contract from a verified employer could settle the pay, and this process cannot supply one | A written offer on the company's own domain, with a stated salary and contract type | `[inferred]` from the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring only via Telegram, no calls or video | red_flag | severe | "Our whole hiring process runs on Telegram" | No accountable employer is running the process | `[generic]` common scam pattern | Will the company run a video interview and send an offer from its own domain? | unresolved |
| RR2 | IBAN, PPS number and passport photo requested before any interview | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Collecting identity and bank data for fraud | `[generic]` common scam pattern | Will onboarding data be collected only after a signed contract, on the company's HR system? | unresolved |
| RR3 | Upfront payment of €349 for equipment, refund promised | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner" | Advance-fee fraud; the refund will not come | `[generic]` common scam pattern | Does the employer ever ask new hires to pay for equipment? | unresolved |
| RR4 | Cheque to deposit, keep €350, forward €2,500 | red_flag | severe | "keep €350 as a welcome bonus and transfer the rest to our equipment partner" | Fake-cheque scam. Cheques can take weeks to bounce, and you are liable for the money you sent | `[generic]` banks reverse cheques that fail | Is the cheque issued by the employer's bank, and does it ever require forwarding money? | unresolved |
| RR5 | "Passed interview" with no interview | red_flag | high | "you passed the interview and the job is yours" | The chat was a screen, not an interview | `[inferred]` from the message sequence | Was there any real interview? | unresolved |
| RR6 | Contact is a Telegram handle and a `postmail.example` address | red_flag | high | "email velloway.hr@postmail.example" | Company identity is not checkable from these contacts | `[inferred]` from the contacts given | Does the company have a website and a domain that matches its email? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Stop replying to @VellowayHiring. Don't send the IBAN, PPS number, passport photo or any money | RR1 to RR3 | `[grounded]` the messages' requests | for you to do |
| P2 | If a cheque arrives, don't deposit it or send any money from it | RR4 | `[generic]` | for you to do |
| P3 | If you've already sent any of the above: tell your bank now, report to the Gardaí, and report the account to Telegram | Limit the damage | `[generic]` | for you to do |
| P4 | Apply only through employers' own websites, and check the company exists before replying to any contact | Avoids the same pattern | `[generic]` | for you to do |
| P5 | Your background (Zendesk volume, trained starters, Excel tracking) suits legitimate customer-operations roles. Describe it exactly as it is on any application | Real fit, unverified until an employer checks | `[grounded]` CV | proposed; nothing sent |

## Evidence status

Verified: none yet. The claims above are your self-reports from the CV.

Research tier: L0 — no searches; the decision rests on the posting and messages themselves

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | L0, no searches run. Would confirm whether Velloway Logistics exists and is hiring |
| 2. Role-family sweep | skipped | L0, no searches run. Would calibrate the pay band |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle |

## Upgrade menu

- A search for Velloway Logistics and for scam reports naming it (up to 5 searches and 2 page fetches) → would confirm or rule out a real company. It would not change the decision, because the red flags stand regardless.
- A written offer from a company domain with a salary and contract type → R5 could be assessed; RR1 to RR4 would still need answers.
- Any sample of your written English (a reply or email you're happy to share) → R3 moves from `low` confidence.

Dossier offer: I can write this assessment to `tuesday-dossier.md` if you want it on file.

1. Have you already sent any of the IBAN, PPS number, passport photo or any money, or received a cheque? (answer any time, or skip)
2. Shall I run the L1 check on Velloway Logistics and scam reports now? It takes up to 5 searches and 2 fetches.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.