**Decision: no_go.** Do not send your IBAN, PPS number, passport photo, or any money. This is a fraud. The job itself is not the issue: the process is a known scam pattern, and the fit question doesn't matter.

**Decision snapshot**
- **Opportunity:** no_go. Each stage asks for money or sensitive data before any real hiring step. The cheque instruction is the clearest sign.
- **Candidate fit:** your skills match the listed requirements well (customer service, Zendesk volume, training others, Excel tracking). This is self-reported and unverified.
- **Hard gates:** pay floor not met on the posting's own figures (below). Quiet-workspace requirement unknown.
- **Research tier:** L0, no searches. Provided documents only. The verdict doesn't depend on research.

**Role reality**
- Title and scope are ordinary for remote ops work. The posting's pay is `[grounded]`: "up to €26/hour plus commission", 15–30 hours a week.
- Your €30,000 floor, using the posting's own numbers `[inferred]`:
  - At €26/hour, 15 hours a week is about €20,300 a year; 30 hours is about €40,600.
  - Reaching €30,000 at the top rate needs about 22 hours every week, every week of the year, and commission is unquantified.
  - So the floor is met only if commission is large and steady, and the posting doesn't say what it is.

**Evidence map (your requirements against the posting)**

| # | Requirement | Your evidence | Fit | Confidence |
|---|---|---|---|---|
| 1 | Attention to detail | ~60 tickets/day in Zendesk | Likely | Stated (CV only) |
| 2 | Spreadsheets | Keep team's weekly Excel tracker | Likely | Stated (CV only) |
| 3 | Written English | Not evidenced in your materials | Unknown | None |
| 4 | Quiet place to work | Not stated | Unknown | None |
| 5 | Pay floor €30k | Posting maxes out below it without commission | Gap | Grounded (posting) + inferred (arithmetic) |

**Opportunity risk register**
- **Critical, pay-to-work:** a €349 equipment payment to a "partner" before any work, refunded "with first wages". Legitimate employers supply equipment.
- **Critical, cheque overpayment:** a €2,850 cheque to lodge, keep €350, and send the rest to a third party. Cheques can bounce after the money has been sent on, leaving you out of pocket. This is the standard mule and overpayment scam.
- **Critical, sensitive data before interview:** IBAN, PPS number and passport photo requested before any chat interview.
- **High, process:** Telegram-only, no calls or video, and interview and offer in one chat.
- **Medium, contact:** the listed email is a generic mail domain, not a Velloway domain. Don't rely on it as proof of a company.
- **Pattern-based:** these signs match a documented scam type `[generic]`. I did not verify that Velloway Logistics exists.

**Application plan**
- Don't reply further to @VellowayHiring and don't send anything.
- Don't pay the €349 and don't lodge or forward any cheque.
- If you have already shared your PPS number or passport photo, contact your bank and watch for account activity. Report the exchange to the Gardaí and to Telegram.
- Report the listing to the jobs site.
- To check whether a company is real, search the Companies Registration Office register (cro.ie). Velloway being absent is a further warning sign.
- Your background fits real remote customer-service and operations roles. Those are worth pursuing instead.

**Evidence status**
- Your CV claims are self-reported. Nothing in them is verified.
- Research: L0, no searches. The posting and your messages are the only sources.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` for later reference.

**Upgrade menu:**
- Live research (L1): searches and page fetches on Velloway Logistics's registration and web presence, plus a role-family pay check.
- A list of real remote customer-service roles at a €30k floor, ranked by fit.

**Questions**
1. Should I run the L1 research to check whether Velloway Logistics is a registered company?
2. Have you sent any of the requested details or any money so far? If yes, which?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.