**Decision: no_go.** Don't send anything. Stop replying to @VellowayHiring, and don't pay, deposit, or transfer any money.

**Decision snapshot**
- **Opportunity:** Fraud pattern, not a job. Every stage matches a known advance-fee or fake-cheque scam.
- **Candidate fit:** Strong on paper for the stated tasks (customer service, Zendesk volume, training others, Excel tracking). That doesn't change the decision, because the opportunity itself is the problem.
- **Hard gates failed:** Yes. The employer asks for an upfront payment to them, which no legitimate employer does, and it asks for sensitive identity data before any real hiring step.
- **Research tier:** L0. I used only what you pasted and ran no searches, so I can't confirm that Velloway Logistics exists.

**Why it's a scam**
- **Identity data before any real interview:** IBAN, PPS number and passport photo "for payroll" is what identity thieves collect. Real employers collect these after a signed offer, through HR's own secure system, not in a chat app.
- **Pay to work:** The €349 "equipment partner" payment is an upfront fee. A legitimate employer supplies equipment or reimburses approved costs, and never routes it through a third party.
- **The cheque:** The €2,850 cheque, "keep €350 and send the rest to the equipment partner," is the classic fake-cheque scam. Cheques take days to clear, and when the bank reverses the deposit, you owe the money. Any money you forward before that is lost, and the bank can treat you as a money mule.
- **Channel:** Telegram-only hiring with no call or video, a free-looking email domain, and urgency around the "chat interview" all fit the pattern.

**The role on its own merits:** Even if it were real, the pay is "up to €26/hr," which is the ceiling. At 15 to 30 hours a week that is roughly €20k to €40k a year before any commission, so reaching your €30,000 floor would need about 22 paid hours a week at the full rate. The posting doesn't state a base salary. Note that this comparison is arithmetic on the posting's own figures.

**What to do now**
1. Don't paste your IBAN anywhere in this conversation or in Telegram. Your IBAN is fine to keep; just don't send it to them.
2. If you have already sent your PPS number or passport, contact your bank and ask about fraud monitoring, and consider a credit check. Report the identity-data request to the Gardaí as well.
3. Report the account to Telegram, and report the posting to the job site.
4. Report the scam to the Garda National Economic Crime Bureau or your local Garda station. Keep the messages as evidence.
5. If anyone asks you to deposit or transfer a cheque, refuse. Phone your bank before you act on any payment instruction from a stranger.

**Upgrade menu:** If you want a real check on the employer, paste the link to the live posting from the job site or the company's own careers page. I can then assess whether the employer is verifiable, but nothing you have shown so far would change this decision.

**Questions:** Have you already sent any personal details or money to @VellowayHiring? If you have, tell me what and when, and I'll help you work out the next steps.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.