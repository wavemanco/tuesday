**Decision: no_go.** Don't send the IBAN, PPS number, or passport photo, and don't pay the €349. This has the hallmarks of a fake-cheque and money-mule scam. I haven't searched for the company, but the posting and messages are enough to decide.

**Hard gates:** The pay floor (€30,000/yr) is not met on the posting's own terms. The posting says "up to €26 an hour plus commission" for "15–30 a week." At €26/hr that is about €20,300 to €40,600 a year before commission, and you'd need roughly 22 hours a week to reach €30,000 with no commission. Nothing guarantees either figure. [grounded arithmetic from the posting]

**Opportunity ledger (red flags):** [inferred from the messages; the pattern is [generic] for this scam type]

- **Recruitment runs only on Telegram**, with no call or video interview, and the "chat interview" is a text chat with an unnamed recruiter.
- **Bank and identity details requested before any contract or job offer:** IBAN, PPS number and passport photo, sent "so payroll can set you up."
- **Upfront payment to start work:** €349 to an "equipment partner" you'd be paid back from wages. Legitimate employers don't charge staff for their own equipment.
- **The cheque scheme:** they send you a €2,850 cheque, you deposit it, keep €350, and transfer the rest to a third party. The cheque will likely bounce after your transfer clears. You would then owe the bank that money, and you'd be the one moving funds for the scammer.
- **Contact domain:** "velloway.hr@postmail.example" is a generic mail domain, not a company domain.

**Candidate fit:** [from your own account, unverified]

| Requirement | Your evidence | Fit |
|---|---|---|
| Attention to detail | Ticket handling at ~60/day; trained two new starters | Good adjacency |
| Spreadsheets | Keep the team's weekly tracker in Excel | Good adjacency |
| Good written English | Customer service role; no writing sample here | Likely, unverified |
| Order processing | Parcel courier customer service; no direct order-processing work stated | Adjacent, not direct |
| Quiet workspace | Not stated | Unknown |

Your background fits this kind of role. That doesn't change the decision, because the opportunity itself is the problem.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company's official site and careers page | skipped | Not run; you haven't consented to research, and the decision doesn't depend on it |
| 2. Role-family pay and scope sweep | skipped | Not run; the decision doesn't depend on it |
| 3. Hiring manager footprint | n/a | No named hiring manager |

**Do now, if you haven't already:**

1. **Don't send anything** else to @VellowayHiring, including the IBAN and any reply to the cheque message.
2. **If you've already shared your IBAN, PPS number or passport photo,** contact your bank now and ask them to flag the account. Watch for unfamiliar transactions, and treat your PPS number as exposed.
3. **Don't deposit any cheque** they send, and don't transfer money to anyone on their instructions.
4. **Report it** to your local Garda station or through garda.ie, and report the Telegram account to Telegram.

Dossier offer: I can write this up as a `tuesday-dossier.md` file so you can keep it with your other job-search material.

Upgrade menu: a live posting link or the company's own careers page would let me test whether Velloway Logistics exists as described. Named contacts and their company email domain would add a second check. A written contract with a fixed salary would be needed before the pay floor could be assessed.

Questions:
1. Have you sent Velloway any documents, money or bank details so far, beyond what you've described?
2. Do you want me to run a short research check on Velloway Logistics and the email domain? That would be up to 5 searches and 2 page fetches.
3. Would you like help finding customer operations or order-processing roles with employers you can verify, using your Zendesk and Excel experience?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.