**Stop before you prepare: this email looks like a job scam.** Please don't pay the €95, send your passport or bank details, or deposit the cheque.

- **The fee:** Legitimate employers don't charge candidates for equipment or registration, and they don't require payment before an interview.
- **The documents:** A passport photo and bank details before any interview is a common identity-theft setup.
- **The cheque:** You'd deposit €1,850 and send the balance to a "vendor." The cheque would later bounce, and the money you sent would be gone.
- **The process:** A 30-minute interview with an unnamed "office manager," no full job description, and a generic-looking contact address are all typical of these scams.

**To check it:**
1. Find Brennock Facilities Ltd on the Companies Registration Office register (cro.ie) and confirm it exists.
2. Go to the company's official website, not the links in this email, and check whether it lists this vacancy and that contact address.
3. Call the company's switchboard number from its official website and ask whether it is interviewing for this role.
4. Check the job board where you first saw the ad, and whether the posting still exists.

**If you've already sent anything,** contact your bank now, tell them it may be a scam, and ask about stopping or recalling a payment. Report the email to the Gardaí and to the job board. Watch your accounts and monitor your credit for identity misuse.

**Interview prep, if a verified employer gets in touch through its official channels (nothing paid or sent in advance):**

I built this from your own sentences, did not run any research, and did not produce the full pack format, so treat it as a condensed sheet.

**Fit snapshot**

| Requirement in the ad | Your evidence (quoted) | Gap and bridge |
|---|---|---|
| Managing calendars | "I ran the appointment book for four physios" | Bridge: you coordinated four diaries. Gap: no executive-calendar experience shown. |
| Booking travel | Nothing in your material | Gap: no evidence. Say so honestly; describe how you would learn it. |
| Word documents | "I'm good with Word" | Strong. Give one concrete example. |
| Excel | "okay with Excel" | Gap in depth. Name exactly what you do in it, and nothing more. |
| Supplier invoices | "chased unpaid invoices" | Bridge: you know invoice cycles from the receivables side. Gap: no accounts-payable processing. |

**Likely questions and guidance**

1. *Walk me through your receptionist role.* Lead with the appointment book for four physios. Describe only what you did.
2. *How do you handle conflicting calendar requests?* Use a real double-booking you resolved. Explain the steps you took.
3. *Tell me about chasing unpaid invoices.* Describe your actual process: reminders, who you contacted, escalation. Don't claim you processed supplier payments.
4. *How would you rate your Excel?* Give an honest rating, name the functions you use, and say what you'd want to learn.
5. *Have you booked travel before?* If not, say so, then explain how you'd get up to speed quickly.
6. *How do you work well remotely?* Give a real habit, such as a daily task list or how you keep track of follow-ups.

**Reverse questions**
- What does a typical week look like in this role?
- How are the office manager's calendar and travel priorities set?
- How are supplier invoices approved and paid?
- What does the rest of the hiring process look like, and who is on it?

**Upgrade menu**
- A full job description from the official listing, so I can map every requirement.
- Any real Excel or travel example you can describe, so I can strengthen the sheet.
- If you want the full prep pack with research, tell me and I'll run it, once the company is verified.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.