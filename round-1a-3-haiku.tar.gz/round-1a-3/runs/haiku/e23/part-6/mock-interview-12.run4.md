**Before anything else: this email looks like a scam.** Please don't pay the €95, send your passport photo or bank details, or deposit the €1,850 cheque.

- **Fee before interview:** real employers don't charge candidates for equipment or registration.
- **Passport and bank details before interview:** no genuine interview stage needs these. That data is what identity thieves want.
- **Cheque deposit, then forward the balance to a vendor:** this is the classic fake-cheque scam. The cheque bounces after you've sent real money on.
- **Domain:** `brennock.example` is a reserved placeholder domain, not a real company domain.

To check it: search the Companies Registration Office register for Brennock Facilities Ltd. Find their phone number on their own website, not in this email, and ask whether they are recruiting for this role. If you've already sent money or details, call your bank now and report it to the Gardaí and the National Cyber Security Centre.

**If the company checks out, here's your prep.** I've saved the full pack here: `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-6-rooms-case-12-denied-40984c76/848db5df-dcde-44c5-8b97-5c6dcc7cd34e/scratchpad/brennock-interview-prep.md`

**Where your background fits and where it doesn't**
- **Calendars:** strong. Running four physios' diaries is direct evidence.
- **Word:** good. Have one document you've made ready to describe.
- **Excel:** the weakest link on your stated level. Practise SUM, IF, XLOOKUP or VLOOKUP, and pivot tables before the call.
- **Invoices:** you chased unpaid invoices, which is the receivables side. Learn the three-way match (purchase order, goods received, invoice) and typical payment terms.
- **Travel booking:** not in your background. Say so plainly and bridge from scheduling under constraints. Don't claim experience you don't have.

**Questions most likely to come up**
- "Tell me about yourself." Two years of appointment-book and invoice work, then why admin.
- "How have you managed a busy diary?" Describe one real week with four calendars.
- "Why should we hire you without travel or supplier-invoice experience?" This is the one to rehearse most. Concede the gap in a sentence, then give your strongest true bridge and your learning plan.
- "How comfortable are you with Excel?" Be specific about what you do and what you're learning.
- "Walk me through a supplier invoice from receipt to payment." Reason from your chasing work: check the PO, check the amount, route for approval, pay by the due date.

**Good questions for them:** what a typical week looks like, which systems you'd use, how invoice approval works, and whether the company provides equipment at no cost to you. A legitimate employer will answer that last one plainly.

Two offers, neither pushed:
- I can play the office manager in a live practice round and follow up on your answers.
- I can update this pack if you send the full job description or your CV.

Do you want the practice round, and do you have the full job description?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-interview-prep.md -----
# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

## 0. Verify this employer before anything else

The invitation has several features that match well-known advance-fee and fake-cheque scams. Do not act on it until you have checked it independently.

| What the email asks | Why it is a red flag |
|---|---|
| Pay €95 "equipment registration fee" to a supplier's account | Legitimate employers never charge candidates for equipment, registration or onboarding. |
| Send a passport photo and bank details *before* the interview | No interview stage needs ID or bank details. This is the data needed for identity theft. |
| Deposit a €1,850 cheque and send the balance to a "vendor" | This is the classic fake-cheque scam. The cheque bounces after you have sent real money onward. |
| Hiring contact at `brennock.example` | `.example` is a reserved placeholder domain and cannot receive real email. Check the address against the company's official website. |

**Do this now:**
1. Do not pay anything, send any ID or bank details, or deposit the cheque.
2. Look up Brennock Facilities Ltd on the Companies Registration Office (CRO) register and confirm it exists and its registered address.
3. Find the company's phone number and HR contact on its own website, or call the switchboard of a number you find independently. Ask whether they are recruiting for this role and whether they sent the invitation. Do not use contact details from the email.
4. If you have already sent money or details, contact your bank immediately, then report to the Gardaí and to the National Cyber Security Centre.

Your interview itself is a 30-minute video call. If the company is real, the interview does not depend on any of the above steps. The prep below is still useful for any real admin interview.

## 1. Fit snapshot

Job requirement → your evidence (quoted from your background) → gap and bridge.

| Requirement | Your evidence | Gap and bridge |
|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong match. Bridge to "shared diaries and competing priorities across several people." |
| Booking travel | None stated | Gap. Bridge: scheduling under constraints transfers, but say plainly you haven't booked travel. |
| Documents in Word | "good with Word" | Match. Give a concrete example you have made. |
| Documents in Excel | "okay with Excel" | Partial. Improve before the interview (see section 4). |
| Processing supplier invoices | "chased unpaid invoices" | Partial. You know the chase side (receivables). Bridge: invoice matching, payment terms and approval chains. |

Gap type: **capability** (travel booking, supplier payables), **proficiency** (Excel). Confidence: **high** for calendar and Word, **medium** for invoices, **low** for travel.

## 2. Likely questions and answer guidance

**Provenance:** candidate's own sentences, quoted above.

### Persona: office manager (the interviewer)

**Q1. Tell me about yourself.** (Type: warm-up)
- Guidance: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios and handling invoices. Close with why you want admin work.
- Provenance: "ran the appointment book for four physios"; "chased unpaid invoices."

**Q2. How have you managed a busy diary?** (Type: experience)
- Guidance: describe one concrete week. Four diaries, cancellations, and the rule you used to fill gaps. Keep to what you did.
- Provenance: "ran the appointment book for four physios."

**Q3. Have you booked travel for anyone before?** (Type: gap probe)
- Guidance: "No, I haven't booked travel professionally. What I have done is schedule around constraints for four people, and I'd learn the booking tools quickly." Do not claim experience you don't have.
- Provenance: no candidate sentence covers this; answer slot. Ask yourself: which real scheduling problem is closest?

**Q4. How comfortable are you with Excel?** (Type: skills)
- Guidance: be specific about what you can do and what you are learning. "I use it for [X]. I'm building up [Y]." Do not say "advanced" unless you have tested it.
- Provenance: "okay with Excel."

**Q5. Walk me through how you'd handle a supplier invoice from receipt to payment.** (Type: process, scenario)
- Guidance: reason from your receivables experience. Check it matches a PO, check the amount, route for approval, log it, pay by the due date. Say what you'd check with the office manager about their process.
- Provenance: "chased unpaid invoices."

**Q6. Why should we hire you when you haven't processed supplier invoices or booked travel?** (Type: skeptic, deepest rehearsal, highest-ROI prep)
- Guidance: concede the gap in one sentence, then give your strongest bridge: the invoice and follow-up work you did, and your learning plan for the rest. Don't overclaim.
- Provenance: "chased unpaid invoices"; "ran the appointment book."

**Q7. Working remotely: how do you stay organised and reachable?** (Type: remote-work)
- Guidance: name your actual routine (calendar blocking, status updates, response times). Don't invent tools you don't use.
- Provenance: no candidate sentence; answer slot.

**Q8. What would you do in your first 30 days?** (Type: forward-looking)
- Guidance: learn the calendars and systems, learn the supplier list and payment cycle, check in weekly on priorities.
- Provenance: generic.

## 3. Reverse questions

Ask two or three. Good questions also test the employer.

1. "What does a typical week look like, and which parts are most time-sensitive?" *Why it lands:* shows you think in workflow terms.
2. "Which accounting or booking systems would I use day to day?" *Why it lands:* real roles name their tools.
3. "Does the company provide equipment, and is there any cost to the employee for onboarding?" *Why it lands:* a legitimate employer answers "no" plainly. Any hesitation is informative.
4. "How is the invoice approval process set up?" *Why it lands:* shows you understand the payables process.

## 4. Preparation plan (before the interview)

- **Excel:** practise SUM, IF, VLOOKUP or XLOOKUP, a basic pivot table, and sorting and filtering. Be ready to talk through one spreadsheet you built.
- **Travel booking:** read through how one major booking tool works, so you can describe the steps.
- **Invoices:** learn the three-way match (purchase order, goods received, invoice) and typical payment terms.
- **Examples:** write two short, true stories: one scheduling story, one chasing-invoices story. Rehearse them out loud within 90 seconds each.

## 5. Scope and what's missing

- Built from your summary and the job ad. The full job description and the interview format (only the 30-minute call with the office manager is known) would sharpen the questions.
- No research was run on the company. Verification is in section 0, and you should do it yourself.

## Upgrade menu

- Full job description: tighter questions and gap mapping.
- Your CV: story-mapped answers instead of selection scaffolds.
- Any stated focus areas from the employer (or confirmation from the company's own website that the role exists).
- A live practice drill: I play the office manager and follow up on your answers.
- A Word version of this pack.
