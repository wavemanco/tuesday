**Before you prep: this invitation looks like a scam.** Please don't pay the €95, send your passport photo or bank details, or deposit the cheque.

- **Fee before interview:** legitimate employers don't charge candidates for equipment or "registration."
- **Passport and bank details before interview:** no genuine interview needs these, and they are what identity fraud is built on.
- **The cheque:** you'd deposit it, then send the "balance" to a vendor. The cheque would bounce later, and the money you sent would be gone.
- **The IBAN:** "IE00" as the check digits is not valid. An IBAN with those digits fails the standard check, so the account number as written isn't a real Irish IBAN.
- **The address:** hr@brennock.example uses ".example," a domain reserved for documentation, not a real company email domain.

**To check it:** find Brennock Facilities Ltd on the Irish Companies Registration Office register (core.cro.ie) and on its own website. Contact the company through the phone number or address you find there, not the details in this email. If it's real, ask them to confirm the interview through that route.

**Your prep pack** is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-e23-part-6-rooms-case-12-denied-04dae922/7ccb64c5-4698-41b1-9e48-406500f13724/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. The headline points:

- **Your strongest material:** "ran the appointment book for four physios" and "chased unpaid invoices." Those are real, and the pack builds your answers from them.
- **Your gaps:** travel booking and processing supplier invoices (you chased unpaid ones, which is a different task), and Excel, where you said "okay." Expect them to probe these. The pack gives you honest answers for each, including "I haven't done that yet, and here's how I'd learn it."
- **Highest-priority prep:** S1 and S2. Practise them aloud until you can answer without notes.
- **Likely format:** a short call with an office manager, probably with a practical task like booking travel or setting up a simple invoice tracker. Those are C1 and C2 in the pack.

Two offers, neither pushed:
- I can run a live practice interview for S1 or S2, playing the Skeptic.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Is the person you're meeting the office manager directly, or a recruiter? That changes how I weight the questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd (candidate: Aoife)

**Read first:** this invitation has the hallmarks of a job scam (pre-interview fee, passport and bank details before interview, cheque-deposit-and-forward). Do not pay, send ID, or deposit a cheque until the company is verified independently. This pack is prep for the role's content and is only useful if a genuine interview is confirmed through a route you have checked yourself.

## How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored. Types: VAL (values), EXP (your experience), JD (role requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Say answers in your own words.

## Prep triage (about 2 hours)

1. Rehearse S1 and S2 aloud until you can answer without notes. This is the highest-ROI prep.
2. Rehearse C1 and C2 with a pen and paper.
3. Practise A1 as a 90-second arc.
4. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your ad summary) | "ran the appointment book for four physios" - your message | medium | [grounded] | transferability | Your material says the appointment book for four physios, not executive calendars. Say it in those words. Answer slot: if you set priorities or resolved clashes between people, say how; if you mainly booked and moved appointments, say that. |
| F2 | "booking travel" (your ad summary) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how; if not, say so and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" (your ad summary) | "good with Word" - your message | medium | [grounded] | none | Word is covered in your own words. Lead with it. |
| F4 | "preparing documents in Word and Excel" (your ad summary) | "okay with Excel" - your message | low | [grounded] | presentation | Reword only that quote: "I'm okay with Excel." Do not add formulas, sheets or figures you have not given. |
| F5 | "processing supplier invoices" (your ad summary) | "chased unpaid invoices" - your message | medium | [grounded] | transferability | Chasing unpaid invoices is receivables work, not processing supplier invoices. Say what you did in those words. Answer slot: if you processed or approved any supplier invoices for payment, say how; if you only chased unpaid ones, say so. |

Your material says: two years as a receptionist at a physiotherapy clinic - your message.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for executives | Inflated form of F1 | "ran the appointment book for four physios." Your material says appointment book, not executive calendars. |
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices." Your material says chasing, not processing. |
| Advanced Excel skills | Inflated form of F4 | "I'm okay with Excel." |

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks where your background falls short for this job | Highest. A 30-minute call with an office manager will test the gap between clinic reception and an admin role (F1, F2, F5). | Rehearse the gap until it's boring. Name what you did, name what you have not shown, and give a concrete plan. |
| Case / Practical | Gives a live task: book travel, set up a tracker, handle a clash | High. A 30-minute call is short, so the practical task is likely. | Clarify first, then structure. Say your steps aloud. |
| Conversational | Opens with "walk me through your background" | Medium. Friendly, but still scored. | Prepare a 90-second arc. Treat casual questions about the JD as scored. |

Weights: Skeptic 4 questions, Case 3, Conversational 2.

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "ran the appointment book for four physios" - your message; [grounded] "chased unpaid invoices" - your message | Name the tasks you've done in those words. Then name where you haven't shown it: travel booking and supplier invoice processing. Answer slot: if you have done any travel booking or invoice processing, say how; if not, say so plainly and give a concrete plan for learning it in the first month. | Highest-ROI prep. The ad's requirements (F2, F5) are the weak spots. |
| S2 | "You chased unpaid invoices. Have you ever processed supplier invoices for payment?" | EXP | [grounded] "chased unpaid invoices" - your message | Answer slot: if you processed or approved supplier invoices, say how and in what order. If you only chased unpaid ones, say so and describe what that involved. Do not stretch "chased" into "processed". | Premised on your own quoted sentence, so it is a fair question; F5 is the gap it targets. |

### Case / Practical

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A director asks you to book flights and a hotel for next Tuesday, and a meeting clashes with the trip. Talk me through it." | CASE | [generic] | Clarify budget, approvals and traveller preferences. Check the calendar for the clash. Confirm with the director before booking. Say each step aloud. | Tests the travel and calendar requirements (F1, F2). Live problem; asks nothing about your past. |
| C2 | "Set up a simple tracker for supplier invoices in Excel. What columns and checks would you use?" | CASE | [generic] | Columns could include invoice number, supplier, date, amount, due date, status and approver. Checks: totals match, no duplicate invoice numbers, due dates set. If you're unsure of a formula, say you'd look it up. | Tests F4 and F5 honestly. Live problem; asks nothing about your past. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" - your message; [grounded] "ran the appointment book for four physios" - your message | 90-second arc: two years as a receptionist, the appointment book for four physios, chasing unpaid invoices, and why you want an admin role. Use only these facts. | Opener. Your strongest verifiable material is in these two sentences. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Managing calendars | A1, C1, S1 |
| Booking travel | C1, S1 (answer slot) |
| Preparing documents in Word and Excel | C2 |
| Processing supplier invoices | S2, C2, S1 (answer slot) |

## Reverse questions

1. "What does a typical week look like in this role?" Why it lands: shows you're planning for the real job.
2. "Which part of the calendar and travel workload is most time-critical?" Why it lands: shows you're thinking about priorities.
3. "How are supplier invoices approved, and who signs off?" Why it lands: tests the process before you commit.
4. "What tools do you use for calendars, travel and documents?" Why it lands: lets you check the tools against what you know.
5. "How would I be contacted and verified as the company's recruiter?" Why it lands: checks the company is genuine. Ask this before any payment or sensitive information.

## Upgrade menu

- Full ad text, copied in → the requirements become [grounded] rather than paraphrased.
- Any examples of Excel work or invoice processing → F4 and F5 move up.
- Confirmed interview details from the company's verified contact → persona weights and the reverse questions can be tuned to the interviewer.
