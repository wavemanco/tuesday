# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Format:** 30-minute video call with the office manager
**Built from:** the job ad duties, your background as you described it, and the recruiter email

## 0. Verify the employer before anything else

The recruiter email contains several hallmarks of a job scam. Treat the rest of this pack as conditional on checking them first.

- **Do not pay the €95 "equipment registration fee."** Legitimate employers do not charge candidates to register, onboard, or confirm an interview.
- **Do not send a passport photo or bank details before the interview.** Identity documents and bank details are normally requested only after a formal offer, through a secure HR process.
- **Do not deposit the €1,850 cheque or send any balance to a vendor.** This is the classic fake-cheque scam. The cheque can look genuine, clear initially, then bounce weeks later, and the money you sent on is gone.
- **The payment goes to a "supplier" IBAN, not to the company.** Be wary of any employer that asks you to pay a third party.
- **Check the company independently.** Look up Brennock Facilities Ltd on the Irish Companies Registration Office (CRO) register, and find a phone number on its official website. Call that number, not one from the email. Check that the email domain matches the company's real website.

**If you have already sent money, bank details, or a passport photo:** contact your bank immediately, ask them to stop or recall any payment, and report the email to An Garda Síochána and to the relevant scam-reporting channel. Keep all emails.

If the company checks out, a genuine recruiter will be fine with you asking why the fee and documents are needed now, and will accept a verification call.

## 1. What to expect in a 30-minute call

A short call with an office manager usually covers four things:

1. An opening question about you and your background (about 2 minutes).
2. Two or three questions about how you would handle the core duties: calendars, travel, documents, invoices.
3. A question on remote working: how you stay organised, communicate, and work without supervision.
4. Your questions for them.

Expect a practical question or two, such as "How would you handle two executives double-booking the same slot?" or "Walk me through how you'd process a supplier invoice."

## 2. Fit snapshot

| Job requirement | Your evidence (quoted from your background) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | High | None | "I managed the schedules of four physiotherapists, so I'm used to juggling competing priorities and keeping everyone's diary accurate." |
| Booking travel | No evidence in your material | Low | Absent | "I haven't booked travel professionally yet, but I'm confident I can learn the process quickly. I'd start by checking the company's booking policy and tools." |
| Preparing documents in Word and Excel | "good with Word, okay with Excel" | Medium (Word), Low–medium (Excel) | Partial | "I'm strong in Word and comfortable building Excel sheets for lists and simple tracking. I'd want to build up my Excel skills for more complex work." |
| Processing supplier invoices | "chased unpaid invoices" | Medium | Adjacent | "I've followed up on unpaid invoices, so I know the process from the payment-chasing side. I'd be comfortable learning the processing and approval steps." |

## 3. Prohibited claims

Do not claim any of the following unless it is true:

- Experience booking travel.
- Advanced Excel (formulas beyond basics, pivot tables, and so on), unless you have it.
- End-to-end invoice processing, or approval or payment authority.
- Calendar management for senior executives, if your work was for physios.

## 4. Question bank

Each question includes its type and provenance. The provenance label is in bold, and the quoted sentence from your material follows it.

**Type: Background (opener)**

**Q1. "Tell me about yourself."**
- Guidance: Keep it to about 60–90 seconds. Lead with two years as a receptionist at a physiotherapy clinic, then the appointment book, then invoice follow-up. End with why you want an admin role.
- Provenance: **From your material:** "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices."

**Type: Skills check (calendar)**

**Q2. "Two executives book the same slot. What do you do?"**
- Guidance: Describe how you would check priorities, contact both parties, and propose a fix. Give a real example if you have one, such as rescheduling a physio's clashing appointments.
- Provenance: **Gap-and-bridge (no story in your material):** "I'd look at who has the priority and speak to both parties to agree a fix. In the clinic I dealt with clashing appointments in the same way."

**Type: Behavioural (invoices)**

**Q3. "Tell me about a time you followed up on an overdue payment."**
- Guidance: Use the chasing experience. Describe the steps, how you kept the tone professional, and the result.
- Provenance: **From your material:** "chased unpaid invoices."

**Type: Situational (travel)**

**Q4. "How would you book travel for a manager who is flying out at short notice?"**
- Guidance: Be honest that you have not booked travel professionally. Describe the steps you'd take: confirm the trip details and budget, check the travel policy, compare options, and keep the manager informed. Do not claim experience you lack.
- Provenance: **Gap-and-bridge (no story in your material):** "I haven't booked travel professionally, but I'd confirm the details and policy first, then compare options and keep the traveller informed."

**Type: Skills check (documents)**

**Q5. "How comfortable are you with Word and Excel?"**
- Guidance: Be specific. Say Word is strong and Excel is comfortable for basics. Name one thing you have done in each. Offer to learn the rest.
- Provenance: **From your material:** "good with Word, okay with Excel."

**Type: Remote working**

**Q6. "How do you stay organised when working remotely?"**
- Guidance: Describe your system (calendar blocking, task lists, shared folders) and how you stay in touch. Be honest if this is new to you.
- Provenance: **Gap-and-bridge (no story in your material):** "I'd use a shared calendar and a task list, and check in with the team at set points."

**Type: Motivation**

**Q7. "Why an administrative role, and why remote?"**
- Guidance: Keep it genuine and short. Link your organisation skills and the appointment-book work to what the role needs.
- Provenance: **Gap-and-bridge (no story in your material):** "I like keeping things organised for other people, and the appointment-book work showed me I'm good at it."

## 5. Reverse questions

Ask these at the end of the call:

1. "What does a typical week look like in this role?" *Why it lands: shows you're thinking about the day-to-day, not just the title.*
2. "Which systems do you use for calendars, travel, and invoices?" *Why it lands: tests whether the tools match your skills.*
3. "How are supplier invoices approved and paid?" *Why it lands: shows interest in the process and reveals whether the company has a normal approval chain.*
4. "What does success look like after the first three months?" *Why it lands: gives you a concrete target.*
5. "How does the team stay in touch when working remotely?" *Why it lands: shows you've thought about remote working.*

## 6. Upgrade menu

- **The full job advert text**, if you have it, to sharpen the fit snapshot.
- **Your CV**, so the story bank draws on your exact wording.
- **Any real example** of travel booking, advanced Excel, or invoice processing, to replace the bridge language above.
- **Verification of the employer**, which determines whether this prep should be used at all.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
