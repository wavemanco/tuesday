Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account" before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor" for a €1,850 cheque. Requests like these are a known scam pattern, and this job is very likely a scam. Hold all three until you have checked the invite with the employer, using a phone number or address from its own website or careers page, not anything in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-12-denied-4270b9c7/74b14835-b009-4576-81c1-8dd1ed3c08a3/scratchpad/brennock_remote-administrative-assistant_interview_pack.md. I built it for a 30-minute first call with the office manager, using only your message, since two web searches on the company were refused by the host.

What to expect: a short call that opens with your background, then a few probes on the duties your message doesn't cover. Travel booking and invoice processing are where you're thinnest, so expect "have you done this?" questions. The pack gives you honest answers for those: say what you did (the appointment book for four physios, the invoices you chased), then say how you'd learn the rest. The pack also has five questions to ask them.

Two things would sharpen it:
- Paste the full ad. I worked from your summary, so the requirement quotes are yours, not the ad's.
- Can you work remotely from where you live, on the hours they'd set? The pack can't check this for you, and your answer changes one row.

Want a rehearsal? I can play the Skeptic on the travel question, the one the pack flags as most likely to come up. I can also save a tuesday-dossier.md recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Relationship: first-round conversation with the office manager, treated as a hiring-manager round.
Research tier: L1 attempted, no results. Both searches were refused by the host, so this pack rests on your own material and the ad as you summarised it.

## How to use this pack

- Personas are how a question is asked. Types are what it scores.
- Type key: **EXP** tests what you actually did. **JD** tests the listed duties. **CASE** is a live problem from the job. **CO** would test company knowledge, but none was researched, so no CO questions appear.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot

Requirements come from the ad as you summarised it. Full ad text was not supplied, so the requirement quotes are the duties you gave me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, as you summarised it) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says you ran the appointment book for four physios. Lead with that, in those words. Answer slot: if you also set up meetings or moved them for people beyond booking appointments, say who and how; if not, say so plainly. |
| F2 | "booking travel" (ad, as you summarised it) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how; if you have not, say so plainly, and say how you would learn the booking tools in the first week. |
| F3 | "preparing documents in Word and Excel" (ad, as you summarised it) | "good with Word" (your message) | low | [grounded] | discovery | Your words are "good with Word." The material does not show which documents you prepared. Answer slot: name one document you produced in Word, and what it was for; if none, say so plainly. |
| F4 | "preparing documents in Word and Excel" (ad, as you summarised it) | "okay with Excel" (your message) | low | [grounded] | discovery | Your words are "okay with Excel." Answer slot: name one thing you did in Excel, such as a sheet or a formula, and what it was for; if you have not used it for that, say so plainly. |
| F5 | "processing supplier invoices" (ad, as you summarised it) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing payment is adjacent to processing. Say what you did with the invoices: chased them. Answer slot: if you also entered, matched or approved invoices, say which and how; if you only chased them, say so and describe how you followed up. |
| F6 | "Remote Administrative Assistant" (email) | none given | none | [grounded] | hard_gate | Your material does not establish that you can work remotely on the hours they set. This row asks nothing in the interview; it is raised once, in the questions below. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for executives | Inflated form of F1 | F1's quote at its own scope: you ran the appointment book for four physios. The limit is the pack's own observation: the material says appointments, not executive diaries. |
| Advanced Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." |

## Persona weights

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5 questions) | High | Hiring-manager priors put the Skeptic first, and F2 to F5 are where the material is thin. | Say what you did, then the honest limit, then how you would learn the gap. |
| Case / Strategist (3) | Medium | An office manager may pose a live scheduling problem from the role. | Clarify first, then say how you would sequence it. |
| Conversational (2) | Medium | A 30-minute first call usually opens with a biography question. | Pre-script a 90-second walk through your career. |
| Pressure (2) | Low to medium | A short call can time-box answers. | Pause, restate, hold a true answer through two follow-ups. |

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which of these duties would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices" | Name the duty where your material is thinnest, probably travel booking or document production, then say how you would learn it. Do not claim a skill not in your material. | The Skeptic's stock question. F2 is the thinnest row. |
| B2 | "I don't see travel booking in your background. How would you handle it?" | JD | [grounded] "ran the appointment book for four physios" | Say that the appointment book is not travel booking, then describe how you would learn the tools. Answer slot: if you have booked travel for anyone, say what and how. | F2 is discovery, not capability; the honest answer is a plan. |
| B3 | "Your background is appointments. Have you processed a supplier invoice?" | JD | [grounded] "chased unpaid invoices" | Say you chased unpaid invoices, and what that involved. Answer slot: if you entered, matched or approved any, say which; if you only chased them, say so plainly. | This is the highest-ROI rehearsal. F5 is the requirement most likely to be probed, and the invoice answer must stay inside what you did. |
| B4 | "Remote work means managing your own hours. Can you do that?" | JD | none | Answer with your own experience of working without someone beside you. Say what you would do to stay on schedule. | F6 is a gate your material does not show. Answer only from what is true for you. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two executives want the same room at the same time, and one flight is cancelled. What do you do?" | CASE | [generic] | Clarify priorities first, then sequence: who is affected, what can move, who needs to know. The question makes no claim about your past. | A live problem from the duties, asked as a decision. |
| C2 | "Walk me through how you would prepare a board pack in Word and Excel." | CASE | [generic] | Structure it: what the pack needs, which tool holds each part, and how you would check the numbers. Answer slot: name any pack or report you have actually prepared; if none, say so. | Covers F3 and F4 as a method, not a claim. |
| C3 | "An invoice arrives with no purchase order. What do you do?" | CASE | [generic] | Structure it: check the amount and supplier, ask who approved it, route it to the right person, and record it. The question makes no claim about your past. | Covers F5 as a decision; the answer does not need past invoices. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Pre-script 90 seconds: the clinic, the appointment book for four physios, the invoices you chased, and why you want an admin role. | The biography question opens most first calls. |
| D2 | "What's your experience with calendars?" | JD | [grounded] "ran the appointment book for four physios" | Say what you did in those words: the appointment book, four physios. Answer slot: if you also managed other diaries, say whose and how. | F1 at its own scope, asked casually. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone with no office admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your two years at the clinic and what they carry over. Hold it through two follow-ups; concede the gap plainly if pushed. | The pressure version of the experience question. |

Coverage: each duty has at least one question. Calendars: D2, C1. Travel: B2. Word and Excel: C2, B1. Invoices: B3, C3. Remote: B4.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of calendar and travel booking look like in this role?" | Shows you are thinking about the real workload. |
| R2 | "Which documents would I prepare most often, and in which tool?" | Signals you have read the duties and want specifics. |
| R3 | "How are supplier invoices approved here, and who signs off?" | Shows you understand the process, not only the task. |
| R4 | "What would a good first month look like for this role?" | Gives the office manager a chance to describe success. |
| R5 | "What hours would you expect, and how do you usually keep in touch with the team?" | Turns the remote question into a practical one. |

## Upgrade menu

- Full ad text → confirms the requirement quotes and the requirement-coverage line for the whole posting.
- Your Word and Excel tasks → F3 and F4 move from discovery to grounded, with specifics you can say aloud.
- The office manager's name → an interviewer read and a tailored reverse question.
- Research on the company → L1 searches were refused this session. Running them once the company is checked through its own website would add values and an interview-process section.
- tuesday-dossier.md → a record of the gaps this prep exposed, for later sessions.
