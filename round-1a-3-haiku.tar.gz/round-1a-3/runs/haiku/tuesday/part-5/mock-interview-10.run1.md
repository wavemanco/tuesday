Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", that your interview will be "a text chat here", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone does not show who you are dealing with. Hold any documents, bank details or payments until you have checked the invite with Lumenvale through contact details from its own website or careers page, not through this chat. You can also ask job-underwriter to check the invite as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-10-denied-ee21e859/47ea5535-9639-4d0a-b386-08c90375a147/scratchpad/lumenvale_customer-support-specialist_interview_pack.md. It has the fit snapshot, prohibited claims, 17 questions across five personas, reverse questions and the upgrade menu. I built it for a first-round chat with a team lead, since the invite names the team lead and not the round's format beyond the chat.

**Web search was refused this session**, so I could not check Lumenvale's site, values or interview process. Everything about the company is unverified.

**Where the interview is most likely to press you:**
- **"You've never worked for a software company."** This is the highest-priority rehearsal. Say it plainly, then go to your energy-supplier work and the Freshdesk use, not to any software claim.
- **Escalations.** Your material doesn't cover them. Have a true answer ready: either a case you escalated, or the handover you would write.
- **Written communication.** The chat itself is the test. Keep messages short and structured.
- **Figures.** "60 calls and emails a day" will be probed. Know how you counted it and which assumption you'd defend least.

Two things would help me tighten the pack:

1. Is the role open to where you live, and do you have the right to work there? The ad is remote, but your material doesn't say, and it is the one gate I can't judge.
2. Can you paste the full text of the ad? I'm working from your summary of it, so the requirement wording is not exact yet.

Would you like me to run a drill with the Skeptic on the software question? Or I can save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. I can also convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: support team lead (name not given). Round: first-round text chat on Telegram. Research tier: L1 requested, but web search was refused this session, so nothing was checked against Lumenvale's own pages.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the ad's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a written answer, not a script. In a text chat, short, structured messages will score better than long ones.
- Provenance labels: [grounded] traces to your own words or the ad as you summarised it; [inferred] is my derivation; [generic] is a role-family pattern with no claim about you or Lumenvale.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Say it in your words: three years as a customer service advisor at an energy supplier. Expect a probe on what that role covered day to day. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | The ad allows similar tools, so Freshdesk reaches the requirement. Expect a probe on what you do in it. Say plainly any feature you have not used. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Emails show written volume, not clarity, and the bridge should not be stretched. Answer slot: if you have a written reply you are proud of, say what made it clear; if none comes to mind, say how you check a message is clear before sending it. This chat itself will test this. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none given | [grounded] | discovery | Your material is silent on escalations. Answer slot: if you have escalated a case, say what you did and where it went; if you have not, say so plainly and describe the handover you would write. |
| F5 | Not a stated requirement | "I trained four new starters on our refunds process last year" (your message) | medium | [grounded] | none | Not in the ad, but it is your strongest evidence of teaching and process knowledge. Use it in the banks, not as a claimed match for F4. |
| F6 | Gate: right to work and location for a remote role (inferred from the ad being remote) | none given | none given | [inferred] | hard_gate | Your material does not establish this. The one question below asks whether it is met. No wording fixes a gate. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Software-company experience | Negative you stated: "I've never worked for a software company" | Plain acknowledgment: "I haven't worked for a software company." Then F1 and F5 at their own scope. |
| Expert in ticketing tools, or has run Zendesk | Inflated form of F2: "I use Freshdesk every day" | The quote at its scope. My observation, not words for you: your material says Freshdesk, daily. |
| Designed the refunds process | Inflated form of F5: "I trained four new starters on our refunds process last year" | The quote at its scope. My observation: your material says you trained people on it, not that you set it. |

Escalations are not on this list. Your material is silent, so F4 is an answer slot instead.

## How the banks are weighted

- **Relationship:** a team lead running a first-round chat. The prior is Case/Strategist plus Skeptic, with Prober and Pressure following from the figures you gave.
- **Interviewer signals:** none, since no profile was given.
- **Loop:** no source established the rounds, so the weights rest on the relationship prior, not on a documented process. Said plainly here.
- **Depth:** Case/Strategist 4, Skeptic 3, Pressure 3, Prober 3, Conversational 3. Total 16, plus one closing question below, which is under the usual floor. The material is thin, and a single chat round does not need more.

## Question banks

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | A customer writes: "I was charged twice and nobody has replied in four days." Walk me through your first reply. | CASE | [generic] | Acknowledge the problem, confirm the facts you need, say what you will do and by when, and say what happens next. Keep it to three or four short sentences. | A live problem from the ad's support work. Asks nothing about your past. |
| A2 | Tell me about the refunds process you trained people on. What did new starters get wrong most? | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on F5: you trained four starters, last year, on refunds. Tell it in your own words. Answer slot: if you checked what they produced, say how; if you did not, say so and say what you would do. | F5 is your best evidence for process knowledge and teaching. EXP because it tests what you actually did. |
| A3 | Our ad asks for confidence handling escalations. Walk me through how you would escalate a complaint you cannot resolve. | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Scaffold: who you tell, what the handover note contains, what the customer hears and when. Answer slot: if you have escalated before, say where it went; if you have not, say so plainly and describe the handover you would write. | F4 is the gap most likely to be probed. |
| A4 | You get 60 tickets on a Monday and two are urgent. How do you order them? | CASE | [generic] | Name the urgency test first, then the order, then what you would tell the customers you have not reached yet. | A live prioritisation problem. Asks nothing about your past. |
| A5 | Write me a two-line reply to a customer whose refund is late. | CASE | [generic] | Two lines: what you know, and when they will hear next. No apology loops, no promises you cannot keep. | The chat is itself a writing test. The ad asks for clear written communication, which is F3. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | You have not worked for a software company. What would you need to learn first? | JD | [grounded] "I've never worked for a software company" | Plain acknowledgment: "I haven't worked for a software company." Then name the one thing you would learn first, and what carries over from F1. Hold through two follow-ups by returning to F1 and F5, never by claiming software experience. | Highest-ROI prep in this pack. The stated negative is the likeliest objection, so it gets the deepest rehearsal, with follow-up levels. |
| B2 | What from your energy-supplier work carries over to a software product, and what does not? | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Say what you did in that role, then what carries over, then what does not. Say nothing beyond the quote about what the role involved. | F1 is the requirement the skeptic will test for transfer. |
| B3 | Our ad asks for Zendesk or a similar tool. What is your experience with ticketing tools? | JD | [grounded] "I use Freshdesk every day" | Say Freshdesk, daily, and what you do in it. Answer slot: if you have used other tools, name them; if not, say so plainly. | F2 reaches the requirement, but the skeptic will check the depth. |

### C. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Plenty of people can answer emails. Why would we trust you with escalations? | JD | [grounded] "answering around 60 calls and emails a day"; [grounded] "I trained four new starters on our refunds process last year" | Pause and restate the question. Hold the position through two follow-ups using only the two quotes: volume, and training others. Concede specifically that escalations are not yet shown in your material; do not fold on the volume and training claims. | A composure test. The held position is one your quotes carry. |
| C2 | Sixty seconds: why should we hire you over someone with software support experience? | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Do not argue down the other candidate. Name what you bring that is in your quote, then say what you would need to close the software gap. | A stress-interviewer version of B1. |
| C3 | How much of the refunds process was actually you? | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what was yours. Answer slot: if you designed any of it, say which part and how you decided; if you did not, say so plainly. | Premised on F5 at its own scope. Tests the attribution the prohibited list guards. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | You say you answer around 60 calls and emails a day. How is that counted? | EXP | [grounded] "answering around 60 calls and emails a day" | Say where the figure comes from and what it covers. If you did not count it, say so, and say roughly how you know. | A figure raises the defend-the-number questions. Your answer must be one you can repeat under a second question. |
| D2 | Which assumption behind the 60 a day would you defend least? | EXP | [grounded] "answering around 60 calls and emails a day" | Name the weakest assumption before they do, for example what counts as one contact. Say it in your own words. | Weakest-assumption move for the same figure. |
| D3 | When you trained the four new starters, what did you measure, if anything? | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you measured anything, say what and how; if you measured nothing, say so and say what you would measure first. | Tests whether training was tracked. Presupposes nothing you did not state. |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | So, walk me through the journey to here. | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: the energy role, the Freshdesk work, the training, then why this role. | Casual openers are still scored. |
| E2 | What would you want to get better at in your first month? | CO | [generic] | Name one real skill gap, such as the software product or the escalation path, and one step to close it. | A safe-sounding question with a scored answer. |
| E3 | What would make this role a good fit for you six months in? | VAL | [generic] | Name something specific to support work, such as resolving tickets without repeat contacts. | Tests whether your motives match the role. |

Requirement coverage: 2+ years in support, B2, E1, C2. Zendesk or similar, B3. Written communication, A5 and F3's answer slot. Escalations, A3 and C1. Software negative, B1. Gate, the question below. No requirement is left uncovered.

## Reverse questions

1. What does a normal week look like on this team, and which tickets take longest to close? Why it lands: shows you are thinking about the job, not just the offer.
2. How do escalations move from first-line support to product or engineering? Why it lands: shows you understand the escalation requirement from the team's side.
3. Which tools does the team use day to day besides the ticketing system? Why it lands: tests how far Freshdesk carries over.
4. Is there a call or video step after this chat, and roughly how long until a decision? Why it lands: tells you how the process runs, and how much written work comes before any real conversation.
5. What separates someone who does well on this team after six months from someone who struggles? Why it lands: gives you the team lead's own standard.

## Upgrade menu

- The full text of the ad → replaces my summary of the four requirements with exact quotes, and upgrades F1 to F4 to [grounded] on the ad's own words.
- An example of an escalation you handled → turns the answer slot in F4 and A3 into a grounded story.
- An anonymised written reply you sent to a customer → upgrades F3 from [inferred] and gives A5 something to build on.
- Web search, which was refused this session → would check Lumenvale's values, its interview process and whether this chat matches its careers page.
- Tuesday dossier (tuesday-dossier.md), if you save one → carries the gaps from this prep into later sessions.
