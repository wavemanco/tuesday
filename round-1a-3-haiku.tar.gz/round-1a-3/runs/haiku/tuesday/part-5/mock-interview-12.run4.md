Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account" before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it says "Successful candidates receive a cheque for €1,850" that you "deposit the cheque and send the balance on to the vendor." Requests like these are a known scam pattern, and the fee and the cheque are very likely a scam. Hold all of them until you have checked the role with the company, using a phone number or address from its own website or careers page rather than anything in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-12-denied-050a569a/a6b73211-3680-45ab-86f5-7ddc4eb8a5fa/scratchpad/brennock_remote-administrative-assistant_interview_pack.md.

**What to expect:** a short, practical call. Expect a question on the duty your background doesn't cover (booking travel), a probe on Excel, and a request to explain the difference between chasing invoices and processing them. Your strongest material is the appointment book for four physios and the invoice chasing. Answer from those, and say plainly where you haven't done something. The pack has the exact wording for each.

**Prep, in order:**
1. Rehearse A1 to A4 (the Skeptic bank) until your answers on travel, Excel and invoices are routine.
2. Practise C1, your 90-second background, using only your own sentences.
3. Prepare two or three reverse questions from R1 to R5.

I couldn't search the company here, so C3 covers only what you can read on its own website.

Want to rehearse? I can play the Skeptic on A2, the travel question the pack names as its highest-value prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions, and they reshape the pack:
1. Is the 30 minutes all conversation, or is there a task too, such as a booking or an Excel exercise?
2. Is this role remote from Ireland, and can you work the hours it needs?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Built for: a 30-minute video call with the office manager. Your note didn't say whether this is the only round, so I've treated it as a first-round conversation with a hiring manager. Built from your message only: no full job advertisement, and no company research (see Sources).

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the duties in the ad), EXP (your own experience), CASE (a practical scenario), VAL (values, not used here).
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you summarised it | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says the appointment book for four physios, not calendars across a team. Bridge: "For two years I ran the appointment book for four physios." Answer slot: if you set priorities or settled clashes across those calendars, say how; if you only kept the book, say so and describe how you handled bookings. |
| F2 | "booking travel" — the ad, as you summarised it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word" — the ad, as you summarised it | "I'm good with Word" — your message | medium | [grounded] | presentation | Bridge rewords only the quote: "I'm good with Word." No practice added. |
| F4 | "preparing documents in Excel" — the ad, as you summarised it | "okay with Excel" — your message | low | [grounded] | discovery | Your words are "okay with Excel", and the material does not show what you have done in it. Answer slot: name the Excel tasks you have done; if none come to mind, say so and say how you would close the gap. |
| F5 | "processing supplier invoices" — the ad, as you summarised it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing payment is not processing. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or paid supplier invoices, say what the steps were; if you only chased payment, say so and describe how you did it. |
| F6 | "Remote Administrative Assistant" — the role title in the invite | none given | none | [grounded] | hard_gate | Your material does not establish this gate: nothing you have shared says whether you can do this role remotely, in the hours it needs. Step 1 asks it. No bridge. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for executives | Inflated form of F1 | F1's quote at its own scope: the appointment book for four physios |
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices", at its own scope |
| Strong or advanced in Excel | Inflated form of F4 | "okay with Excel" |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the duties your material does not cover: travel, Excel, invoices | High. The ad lists four duties; your material closely covers one and touches two more | Rehearse A1 to A4 until the honest answers are routine. Concede the gap in one sentence, then say how you would close it |
| Case / Strategist | A practical admin scenario: a clash, an invoice | Medium to high. Thirty minutes with an office manager usually includes one practical question | Clarify first, then say the steps aloud |
| Conversational | An opener and "why this role?" | High. Almost every short call opens this way | Keep a 90-second arc ready, built only from your own sentences |
| Pressure | Time-boxed challenge on why you over someone with admin experience | Low for a 30-minute call. One question kept for composure | Pause, restate, hold once, then concede what is true |
| Data-Driven Prober | Asks what you have done in Excel or Word | Low to medium. Your Excel answer is the likeliest place for a follow-up | Name what you did, not your level |

Depth: the Skeptic carries the most weight (four questions), then Case and Conversational (three each), then Pressure and Prober (one each). This pack is shorter than a full loop by design: a 30-minute call cannot take much more. Persona weights would change with a longer round or the full job advertisement.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You ran an appointment book. How would you manage an executive's calendar?" | JD | [grounded] "ran the appointment book for four physios" — your message | Say the book in your own words: "For two years I ran the appointment book for four physios." Answer slot: if you set priorities or settled clashes across those calendars, say how; if you only kept the book, say so and describe how you handled bookings. | F1 is the calendar requirement's evidence and the likeliest probe. JD because it scores the stated duty |
| A2 | "Have you booked travel for anyone?" | JD | [generic] | Answer slot: if you have, say what you booked and for whom; if not, say so plainly and say how you would learn the booking tools. Never describe travel you did not book | F2 is a discovery gap: the material is silent. A question on travel will come, and the honest answer is ready before it does |
| A3 | "How comfortable are you in Excel?" | JD | [grounded] "okay with Excel" — your message | Hold the level you stated: "I'm okay with Excel." Answer slot: name the Excel tasks you have done; if none come to mind, say so and say how you would close the gap | F4 is low confidence. Stay at your stated level; do not upgrade it under pressure |
| A4 | "Have you processed supplier invoices, or only chased them?" | JD | [grounded] "chased unpaid invoices" — your message | Say what you did: "I chased unpaid invoices." Answer slot: if you entered, matched or paid supplier invoices, say the steps; if you only chased payment, say so and describe how you did it | F5 is transferable, not direct. The interviewer will ask the question that separates chasing from processing |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we take someone with reception experience over someone who has done office administration?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Pause, then restate: "I ran a shared diary for four people for two years, and I chased unpaid invoices." Hold through two follow-ups by returning to those duties. Concede specifically: "I haven't done travel bookings, and my Excel is at a basic level." | F1 and F5 are the evidence. Pressure tests composure, so the hold is on what you did, not on claiming more |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | A 90-second arc built on that sentence, in your own words: the clinic, the appointment book, the invoices. Stop there | The opener. Your own sentence carries the story, so nothing needs adding |
| C2 | "Why are you interested in this role?" | EXP | [generic] | Answer slot: say your reason in your own words. The material gives no reason, so the pack offers none | A motivation question every short call asks. A reason you have not stated cannot be supplied by the pack |
| C3 | "What do you know about the company?" | EXP | [generic] | Name only what you have read on the company's own website or careers page. If you could not find it there, say so | No research was run for this pack, so the honest answer is what you can check yourself |

### Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A manager needs a meeting moved, but the replacement room is booked and two people are travelling. What do you do?" | CASE | [generic] | Structure it: confirm what is fixed and what can move, check who is affected, rebook, then tell everyone involved. Say the steps aloud. The question needs no claim about your past | The calendar requirement, asked as a live problem rather than a record. [generic] because it is a pattern, not a fact about this employer |
| D2 | "Walk me through how you would process a supplier invoice, from arrival to payment." | CASE | [generic] | Structure it: receive, check it against what was ordered or approved, log it, route it for approval, pay it, file it. Describe the steps you know, and say which you would confirm with the team | The invoice requirement, asked as a process. The answer is a plan, not a past |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which documents have you prepared in Word, and who were they for?" | JD | [grounded] "I'm good with Word" — your message | Name the kinds of document you have prepared and who they were for, in your own words. If you cannot name any, say so | The Word requirement. A prober asks for the document, so name a real one |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars | A1, D1 |
| Booking travel | A2 (answer slot; no evidence in your material) |
| Preparing documents in Word | E1, C1 |
| Preparing documents in Excel | A3 |
| Processing supplier invoices | A4, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for whoever is in this role?" | Shows you want to know the actual load, not just the title |
| R2 | "Which of the four duties takes the most time?" | Tells you where to focus your preparation, and shows you read the ad closely |
| R3 | "Which tools do you use for calendars, travel and invoices?" | Lets you check whether your Excel and Word level fits |
| R4 | "How are supplier invoices approved, and by whom?" | Shows you understand that processing involves more than payment |
| R5 | "What would a strong first three months look like?" | A closing question that tests your fit in their terms |

None of these asks the office manager to check the invitation, its fee, the cheque or the documents it requests.

## Sources

- Provided: your message (the invite's wording and your summary of the advertisement). No full advertisement was provided.
- Searches sent, all refused by the tool (permission not granted):
  - "Brennock Facilities Ltd": refused
  - "Brennock Facilities Ltd careers values": refused
  - "Brennock Facilities Ltd interview process": refused
  - "Brennock Facilities Ltd news": refused
- Fetches: none sent.
- No dossier was present.

**Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | Values cheat sheet, section 10. Not included: no values-style round was detected. Search refused |
| 2. Brennock Facilities Ltd interview process | unavailable | Loop structure and persona weights. Search refused; weights above rest on the 30-minute office-manager call you described |
| 3. Brennock Facilities Ltd strategy and recent news | unavailable | Company-context framing for C3. Search refused; C3 is answered from the company's own site |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Remote Administrative Assistant JD | skipped | Your summary of the ad fixes the requirement rows F1 to F6. The full advertisement would sharpen them |

## Upgrade menu

- The full text of the advertisement → F1 to F5 quote the ad's own words instead of your summary, and the JD questions tighten.
- The role listed on the company's own careers page → lets you confirm the role independently of the invitation.
- An example of a Word document you prepared, with private details removed → moves F3 from a stated claim toward something you can show.
- A tuesday-dossier.md from a later session → would carry any objections this prep exposes.
