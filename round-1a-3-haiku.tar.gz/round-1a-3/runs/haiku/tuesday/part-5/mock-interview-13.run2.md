Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-13-denied-3cd62697/69f1f138-d7ad-4ac9-95bd-c6f836c7f636/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. It's built from the advert, your message and Hannah's, with no CV, and company research was refused in this session, so nothing about Quillmoor's values or process is in it.

The thing most likely to come up is the production gap. The advert asks for production scheduling across planning, the warehouse and QA, and your material shows depot deliveries. Rehearse S1 in the pack until you can answer it calmly and honestly.

Two questions for you, which the pack can't answer:

1. What's your notice period, and do you have the right to work in the UK without sponsorship?

Want me to run a drill on S1? I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Quillmoor Diagnostics, Operations Coordinator

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Role:** Operations Coordinator, Avonmouth (Bristol), hybrid two days a week, £38,000–£44,000.
**Built from:** the advert as you pasted it, your message about your background, and Hannah's message. No CV was provided. Company research was not available this session (see Sources), so company-specific statements are not in this pack.

## How to use + type key

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

- **JD**: the advert's own requirements or terms
- **EXP**: your past work, and whether it holds up under questions
- **CASE**: a live problem from the role, with no claim about your past
- **CO**: why you, and what you know about the company

## Fit snapshot

Quotes are your own sentences, or the advert's or recruiter's exact words. "Your message" means the text you sent me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | None. Say it as written. No CV was provided to check it against. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | None. This is the closest match in your material. Keep "chase suppliers when orders slip" as your words. |
| F3 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots." (your message) | low | [inferred] | transferability | Deliveries are adjacent to production scheduling, not the same work, and your material says nothing about planning or QA. Say the depot work at its own scope: "I schedule deliveries for our three depots." Answer slot: if you have worked with planning, the warehouse or QA on schedules, say how, in your own words; if you have not, say so, and say how you would learn the production side. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | None. The quote reaches the requirement. Keep the figure attached to the sheet and the year it came from. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch or delivery-timing reporting. Answer slot: if you produced a regular report on delivery timing, say what it covered and how often; if you did not, say so plainly and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild shows Excel use but not your level. Answer slot: name the functions and features you used on that sheet, in your own words; if you used only basics, say so. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A stated absence, so the words are the plain acknowledgment: "I haven't used SAP." The in-house stock system is real experience, but it is not an ERP, so do not describe it as one. Learning SAP is a plan to state, never a past. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert, hybrid pattern) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own constraint, and it is met: two days is inside your limit. Say both halves: two days works, three is the most you would want. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your own figure, inside the advertised band. Say it once in your own words, then stop. |
| F10 | Right to work in the UK (not in the advert) | none given | none | [generic] | hard_gate | Your material does not establish this, and it is a gate. Hannah may ask it as a knockout check. It is asked at the end of this message; answer it plainly in your own words, whatever the answer is. |
| F11 | "your notice period" (Hannah's message) | none given | none | [grounded] | hard_gate | Your material does not give a notice period, and it is a gate. Answer slot: give your actual notice period. It is asked at the end of this message. |

**Why the gap types fall where they do.** F5, F6 and F3 are silence or adjacency, so their words are answer slots. F7 is a negative you stated, so its words are the plain acknowledgment. F8 and F9 are your own constraints and they are met, so they carry no gap.

## Prohibited claims

Each entry names its basis, and each has an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned production scheduling across planning, the warehouse and QA" | Inflated form of F3. Your material says deliveries, not production. | "I schedule deliveries for our three depots." Your material does not show planning, warehouse or QA work. The slot in F3 stays inside what you did. |
| "The whole one-third drop in discrepancies was down to me" | Inflated form of F4. Your sentence ties the fall to the rebuilt sheet over a year and claims no sole cause. | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not show what else changed over that year. |
| "I'm an advanced Excel user" | Inflated form of F6. Your material shows a rebuild, not a level. | The F6 slot: name what you used, in your own words. |
| "I have SAP experience" | Negative you stated (F7). | "I haven't used SAP." No slot. |

## Persona table

Relationship prior for a recruiter screen: Conversational plus light Skeptic. No interviewer profile exists yet, and no loop source is established, so the weights below use the screen's prior and nothing else. If the team rounds follow, the weights may change.

| Persona | How it shows up in this screen | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Conversational / rapport | Friendly openers, a walk through your background, logistics checks in a relaxed register | High. Hannah's message names pay, notice, hybrid and reason for moving, so these are the screen's core | A 90-second arc on your background; treat casual questions about the advert's topics as scored | Top: 7 questions |
| Skeptic | Probes the production gap, SAP, Excel and dispatch reporting | High for the production gap. It is the most predictable objection: your depot work is not production scheduling | Rehearse S1 until it is plain. Bridge only from what you stated; say the limit plainly where there is one | Mid: 4 questions |
| Data-Driven Prober | Asks how a figure was counted | Medium. You gave one figure, and it will be asked about | Say how it was counted, in your own words, and say plainly if you do not know | Low: 2 questions |
| Pressure | Tests the reason for leaving | Low to medium. Reason-for-leaving is a standard screen question | Hold the stated reason; concede only what is true | Low: 1 question |
| Company and role fit | Why this role, why this company | High, but no company research is available, so guidance uses only the advert and Hannah's words | Name only what the advert and Hannah told you | Mid: 2 questions |

**Highest-ROI prep:** S1. The production-scheduling gap is the most likely objection to your background, and a calm, honest answer changes how the rest of the screen goes.

## Question banks

Provenance comes before guidance. Guidance cells that speak about your past rest only on the quotes in their Provenance column.

### Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" / "I schedule deliveries for our three depots and chase suppliers when orders slip." | A 90-second arc: four years as a logistics coordinator, three depots, chasing suppliers when orders slip, and the stock sheet you rebuilt. Use only those beats, in your own words. | F1 and F2 are the evidence the screen will check first |
| C2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in those words. Do not add reasons, company gossip or a timeline you have not given. | This is the reason for leaving; the stated reason is your own and is the strongest answer you have |
| C3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own figure: "I'm hoping for £42,000." Say it once, then stop. No question in this pack challenges it, and no line asks why that number or whether you would take less. | F9. The advertised band is £38,000–£44,000, so the figure sits inside it |
| C4 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Logistics slot, with no figure stated: give your actual notice period in your own words. | F11. Your material does not give a figure, so none is written here |
| C5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say that two days works and that three is the most you would want. | F8. Your limit is stated; do not add any commute details you have not given |
| C6 | "Do you have the right to work in the UK without sponsorship?" | JD | [generic] | Answer plainly in your own words, whatever the answer is. | F10. Your material does not establish this |
| C7 | "How would you keep a production schedule, the warehouse and QA in step?" | CASE | [generic] | Structure it: what you would check first (the schedule, deliveries and stock), who you would talk to, what you would flag early, and what you would record. The question asks for no claim about your past. | A live problem from the advert's own line. Answer it as a reasoning exercise |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "This role schedules production across planning, the warehouse and QA. Your background is depot deliveries. What would you need to learn first?" | JD | [grounded] "I schedule deliveries for our three depots." / [inferred] the advert's line "coordinate production schedules between planning, the warehouse and QA" | Bridge with the depot work at its own scope: "I schedule deliveries for our three depots." Answer slot: if you have worked with planning, the warehouse or QA on schedules, say how, in your own words; if you have not, say so plainly, then say what you would learn first and how. Do not claim production scheduling. | F3, the highest-ROI prep. This is the objection the screen is most likely to raise |
| S2 | "Excel is a requirement. What did you build the stock-count sheet in, and how far did you go?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the functions and features you used on that sheet, in your own words. If you used only basics, say so. | F6. Your Excel level is not in your material |
| S3 | "The role reports weekly on-time dispatch. Have you produced a report like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you produced a regular report on delivery timing, say what it covered and how often. If you did not, say so plainly, then say what you would report first. | F5. Silence in your material, so the slot is the honest form |
| S4 | "You've never used SAP. Would you be comfortable learning it on the job?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I haven't used SAP." Then a plan, stated as a plan: how you would learn it. Do not describe the in-house system as an ERP. | F7. The advert calls ERP a plus, so this is a gap you can name and not a requirement you fail |
| S5 | "What would you need to make the production side work for you?" | CASE | [generic] | Structure it: the handoffs between planning, the warehouse and QA, what you would ask each of them, and what you would check first. No claim about your past. | The advert's own problem, asked as a decision |

### Prober bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Discrepancies fell by about a third. How was that counted, and how much of it was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." Answer slot: say how discrepancies were counted and over what period, and which part was yours. If you do not know how it was counted, say so. Concede only what is true, and name any other cause you know of. | F4. The figure is yours, so its counting is the thing to be ready on |
| P2 | "What did you measure in the stock-count rebuild, and over what period?" | EXP | [grounded] "over a year" (from "discrepancies fell by about a third over a year") | Answer slot: name what you measured and the period, in your own words. If you did not track it that way, say so plainly. | Follows P1 and tests whether the figure has a source |

### Pressure bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pr1 | "Why move now, if the office is only closing next year?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the stated reason: the office closes, and the only offer is Reading, which you do not want. Concede only what is true. Answer slot: if you have looked at other options, say so; if you have not yet, say so plainly. | C2's counter-question. Hold it through one follow-up; do not add a plan you have not made |

### Company and role bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CO1 | "Why this role?" | CO | [grounded] "coordinate production schedules between planning, the warehouse and QA" (advert) | Answer slot: say what in the advert draws you, in your own words. Where your experience connects, name the connection; where it does not yet, say so. | The advert's own line is the raising source. Your answer must stay with what you did |
| CO2 | "What do you know about us?" | CO | [generic] | Name only what the advert and Hannah told you. If that is all you know, say so. | No company research was available, so this bank makes no company claim |

## Reverse questions

Each has a reason it lands.

1. "Who would I work with day to day across planning, the warehouse and QA?" Lands: the advert names three functions, and the answer tells you where the role sits.
2. "How is on-time dispatch measured today?" Lands: the weekly report is in the advert, and you want to know its basis before you take it on.
3. "Which ERP does the team use, and how much does it matter in the first year?" Lands: SAP is a plus in the advert, and the answer shows how much the gap would cost you.
4. "What do the hybrid days look like in practice, and are they set or flexible?" Lands: two days is your limit, and this checks the pattern rather than assuming it.
5. "What are the next steps, and when would you expect to hear?" Lands: Hannah said she would tell you about the team and the next steps, so this confirms the timing.

## Sources

Research tier: L1 requested — searches 0 of 6 completed, fetches 0 of 2. The search tool was not permitted in this session, so no sources were read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Values cheat sheet. No values-style round is detected, so the section is absent. Query sent and refused: `Quillmoor Diagnostics Avonmouth careers values interview process` |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Loop structure, which would set the persona weights. Refused, as target 1 |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The CO bank would gain current company facts. No search was sent, since the host did not offer one |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The interviewer read and a tailored reverse question. A name was given, so the query was formable; it was refused as target 1 |
| 5. representative JD | skipped | The advert you pasted fixes the fit snapshot and the JD questions |

No other queries were sent.

## Upgrade menu

- Hannah's public profile, or a summary of it that you paste → an interviewer read, persona weights from her footprint, and a tailored reverse question
- The company's careers or values page, pasted → values answers that use the published names, and a loop structure, which would replace the generic weights above
- Your CV → the F1 to F8 rows would show your CV lines beside your quotes, and the bridges could cite them
- Your Excel level, in your own words → F6 and S2 would hold your answer, not the slot
- Any dispatch or delivery-timing reporting you did → F5 and S3 would hold your answer, not the slot
