Before I can build the prep pack, I need the company and the role title. Until you know who sent this, please don't reply to Jess or share anything beyond what you'd tell any stranger.

The invite says: "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed." A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Don't pay anything, send documents, or share bank details through this chat.

To check it, find the company's own website or careers page, look up its recruiters there, and contact them through those details rather than anything in this message. If you want the invite weighed as a separate request, job-underwriter can check it.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Which company and role is the interview for?