Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-9-canned-e8b8638d/7632c6d0-7ee5-404d-b6ce-e31264597673/scratchpad/halvering-elementary_fourth-grade-teacher_interview_pack.md`.

I didn't use the SSN from your message, and the pack doesn't need it. Keep it off interview materials and out of anything you send the school.

**The panel**
The district's hiring page says teacher panels are one 45-minute session with the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines, and working with families. I found no published values page for the school.

**Where the interview will press**
- **Fourth grade.** Your resume shows six years of third grade and nothing at fourth. The principal is most likely to press here. Rehearse the honest version: you have taught third grade, you have not taught fourth, and here is your first-month plan. Don't frame third-grade work as fourth-grade experience.
- **Team leadership.** Say "I led our grade level's move to a new reading curriculum" and stop there. Don't say you led the team. You've said you have never been a team lead, so the pack treats that as the answer.
- **Reading.** Your 2024 curriculum move and your reading club are your strongest material. Be ready to say what you did, what you measured, and what you didn't measure.

**Interviewer:** The principal has been at this school since 2022 and gave a 2025 talk on weekly reading conferences in grades 3 to 5. A reverse question about fourth-grade conferences is in the pack.

**Next:**
- Want a drill? I can play the principal's skeptic on the fourth-grade question, the one the pack flags as highest priority.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- If you'd like a Word version of the pack, say so.

Two questions that would sharpen the pack:
1. Can you paste the posting text? The requirements in the pack currently come from the invite alone.
2. Did HR mention a demonstration lesson or a written task? If so, the pack needs a section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Format:** 45-minute panel. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given).
**Changelog:** first version.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the role's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Quoted sentences in the tables are your own words, from your CV or your message.

## Prep triage

Prep time was not stated, so this assumes the full pack. Priorities, in order:

1. **B2 and A2:** the reading-instruction and fourth-grade questions. The panel will probably press on the thing you have never done.
2. **A1 and A3:** your reading curriculum work and your weekly family email. Know exactly what you did in each.
3. **C2:** the reverse question about the principal's reading conferences.

Everything else is insurance.

## Sources

- Provided documents: your resume and your message.
- Search and fetch run this turn (L1: 3 searches of 6, 1 fetch of 2):
  - `Halvering Elementary School Orrinsford Community School District`: no results.
  - `Orrinsford Community School District interview process teacher panel`: returned the district's "How we hire teachers" page (`https://orrinsfordschools.example/careers/how-we-hire-teachers`). Fetched. It says teacher hiring is one 45-minute building panel (principal and two grade-level teachers), and that panels ask about reading instruction, classroom routines and working with families. References are taken up after the panel.
  - `Dolores Vantongeren principal Halvering Elementary`: returned a state principals' forum speaker page (`https://ilprincipalsforum.example/speakers/dolores-vantongeren`). Used only for the interviewer read below.

**Research tier:** L1, searches 3 of 6, fetches 1 of 2. User links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | No values page was found. The values cheat sheet is dropped, and the upgrade menu says what a values page would add. |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 45-minute building panel. Personas weighted to the panel. |
| 3. `{company} strategy` / recent news | skipped | Not needed for a building panel; CO questions are dropped. |
| 4. `{interviewer name} {company}` | yes | Interviewer read (principal). Public footprint only. |
| 5. representative JD | skipped | Not needed to build the pack. You have not supplied the posting, so requirement lines come from the invite. |

## Fit snapshot

Requirements come from the invite, quoted. Raising sources for the panel's topics come from the district's hiring page.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | None. Your license is the credential the invite asks for. Say the license and its end date plainly. |
| F2 | "Fourth Grade Teacher" (invite) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Third grade is adjacent work, not fourth-grade experience. Words: "I've taught third grade for six years. I haven't taught fourth grade." Then what the third-grade work tells you about the step up, as a plan, not a past. |
| F3 | Reading instruction (district hiring page: "Panels ask about reading instruction") | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | The curriculum move and the reading club are reading work. Say what you did in those words. Do not add specifics you have not given (student results, data, training you ran). |
| F4 | Working with families (district hiring page: "how you work with families") | "I write a weekly email to families." — your CV | medium | [grounded] | none | A weekly family email is a concrete routine. Say its frequency and what it covers, in your own words. |

**Pack observation:** your material does not show fourth-grade reading content, fourth-grade assessment, or any work with a fourth-grade team. Those are answer slots, not claims.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | Inflated form of F2 | "I taught third grade for six years." Plain acknowledgment from your message: "I've never taught fourth grade." |
| Team lead of a grade-level team | Inflated form of F3 | "I led our grade level's move to a new reading curriculum." The limit is the pack's observation: your material says you led that move, not a team. Plain acknowledgment from your message: "I've never been a team lead." |
| Ran the reading program or the reading club's outcomes | Inflated form of F3 | "I've run the after-school reading club for the last two years." No outcome claims unless you give them. |

## Persona weights

The panel is a blend. Principal: hiring-manager priors. Team members: peer priors.

| Panel member | Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|---|
| Principal | Skeptic | "Fourth grade is new to you. What's your plan?" | high | Hold the honest answer (F2) through two follow-ups, then offer a concrete first-month plan. |
| Principal | Case/Strategist | A live problem: a student who is behind in reading in October. | high | Clarify first, then structure: what you would check, with whom, and how you'd know it worked. |
| Team member 1 | Data-Driven Prober | "How did you decide the curriculum move worked?" | medium | Say what you measured and what you did not measure, in your own words. |
| Team member 2 | Peer Evaluator | "What would you need from us to start on the fourth-grade team?" | high | Reciprocity: what you bring their team, not only what you need. |
| Any | Conversational | "Tell us about yourself." | high | A 90-second arc from your own sentences. |

**Interviewer-signal note:** the principal's public talk covers weekly reading conferences in grades 3 to 5. That grade range is adjacent to your third-grade work. Do not claim their practices; ask about them.

## Interviewer read

**Principal (public footprint only):** principal of Halvering Elementary since 2022, after nine years as a reading specialist. The 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5.

- Practical implication: expect reading instruction questions. Lead with the reading work in your CV, in your own words.
- Mirror opportunity: a shared professional path in reading instruction. Do not claim any reading-specialist experience you lack.

## Question banks

### Skeptic and Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk us through the reading curriculum move you led in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name the move and the year, in those words. Answer slot: if you chose what the grade level changed, say which parts and why; if the decision was not yours, say so plainly and describe your part. | F3 is the strongest evidence for the reading requirement. EXP because it asks for your part. |
| A2 | "You've taught third grade. What would you do in your first month with fourth graders?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | **Highest-ROI rehearsal.** Hold: "I've taught third grade for six years. I haven't taught fourth grade." Then a plan: what you would learn first, from whom, and how. Hold through two follow-ups by returning to the plan. Answer slot: if you have worked with fourth-grade material or a fourth-grade team in any role, say so and how; if not, say so plainly. | F2 is the biggest gap. The principal is most likely to press here. |
| A3 | "What does a typical week of family communication look like for you?" | EXP | [grounded] "I write a weekly email to families." | Describe the email: what it covers and how often. Use only your own words. | F4 |
| A4 | "A student is well behind in reading by October. What do you do?" | CASE | [generic] | Structure: clarify what "behind" means, check what data and assessments exist, talk with the student and family, and plan small-group support. The question makes no claim about your past. | A live problem from the reading requirement |
| A5 | "What did the reading curriculum change do for your students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you observed, in your own words. Answer slot: if you measured anything, say what and how; if you did not measure, say so plainly. | F3's outcome side. Never claim results you have not given. |

### Peer Evaluator and Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from our team to start on fourth grade?" | VAL | [generic] | Name two or three concrete things: shared planning time, materials, the grade's routines. Reciprocity: what you bring their team. | Peer priors; no claim about your past |
| B2 | "How do you know your reading groups are working?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Describe how you check progress, in your own words. Answer slot: if you tracked anything specific, say what; if you did not track it formally, say so and say what you would track. | F3's reading-club evidence, asked as a method |
| B3 | "What did you do to bring the rest of your grade along with the reading curriculum?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you did with your colleagues, in your own words. Answer slot: if the move was made by others as well, say who and what your part was. | Prevents a team-lead overclaim |
| B4 | "How do you work with families when a student is struggling?" | JD | [grounded] "I write a weekly email to families." | Start from the weekly email, then describe any direct contact, in your own words. Answer slot: if you have not had that contact, say so. | F4 and the district's stated family question |

### Conversational (any panel member)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about yourself and why you're interested in this school." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | A 90-second arc: where you taught, the reading work, why fourth grade is the next step, in your words. | Opening question for any panel |
| C2 | "What questions do you have for us?" | JD | [generic] | See the reverse questions below. | Always scored |

## Reverse questions

1. **Tied to the principal's path:** "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What do those conferences look like in fourth grade?" *Why it lands:* it connects to their public work and shows you read it.
2. **How the fourth-grade team plans together:** "How does your team plan reading instruction across the grade?" *Why it lands:* it reveals the grade's routines, which you will need to fit into.
3. **What the first year looks like:** "What would you most want a new fourth-grade teacher to have figured out by the end of the first semester?" *Why it lands:* it names success in their terms.
4. **Reciprocity (peer):** "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* it turns the close into a peer conversation.
5. **Families:** "How does the school communicate with families about reading progress?" *Why it lands:* it links your weekly email to the school's practice.

## Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois PEL with elementary endorsement | None; met per your CV. Say it plainly if asked. |
| Fourth-grade teaching | A2, A3 |
| Reading instruction (district panel topic) | A1, A4, A5, B2 |
| Working with families (district panel topic) | A3, B4 |
| Classroom routines (district panel topic) | Not covered. Add a routine question after the upgrade. |
| Grade-level collaboration | B1, B3 |

## Upgrade menu

- The posting's text → the JD-tagged rows become `[grounded]` and the fourth-grade requirement lines get their exact wording.
- The panel's topics, or a sample lesson request from HR → the classroom routines question and any demonstration preparation.
- The team members' names → per-member personas and tailored reverse questions.
- A values page or mission statement → a values cheat sheet, if the district publishes one (none found this run).
- Your fourth-grade planning, if any (lesson plans, a unit map, or grade-level work you have done) → upgrades A2 and B1 from answer slots to grounded answers.
