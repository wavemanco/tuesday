One thing in the invite first: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor". A fee before an interview, passport and bank details before any offer, and a cheque you deposit and then pay part of back out are known scam patterns, and the fee and the cheque-and-balance step are very likely a scam. Hold all of them (the fee, the passport photo, the bank details, the cheque) until you've checked the invite with the company through contact details from its own website or careers page, not through this email. job-underwriter can weigh the invite as a separate request if you ask. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-12-denied-b81cf14c/dcc26dcf-f69f-4b20-aedf-955e9be10027/scratchpad/brennock_remote-administrative-assistant_interview_pack.md, and I've attached it. I built it for a 30-minute first call with the office manager, since that's what you told me. Web search was refused in this session, so the pack is built only from your message and has no company research in it.

The pack has five skeptic-weighted questions, then case, conversational, probing and pressure questions. The one to rehearse hardest is A2: "What have you done with invoices, and what was your part?" Your background is chasing unpaid invoices, not processing supplier invoices, so answer that gap plainly rather than stretch the chasing into processing.

I can play the Skeptic on A2 as a live drill whenever you want one. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is the office manager your line manager, or a first screen before a hiring manager? The answer reweights the persona table.
2. Can you paste the full text of the ad? Your summary is the only source for the duties, so the requirements are only as exact as your summary.
3. Does the ad name a country, working hours or equipment you'd need to check against your set-up? It's a remote role, and the pack can't tell whether that's met.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Format: 30-minute video call. Round type: first-round conversation, built as a hiring-manager-style round (see persona table).

## How to use this pack

Personas are how the question is asked. Types are what is being scored: JD (the ad's duties), EXP (what you did), CASE (a live problem), VAL (values, not used here). Guidance is scaffolding, not a script. Say it in your own words, and only the parts you actually did.

## Fit snapshot

Requirements come from your summary of the ad, quoted from your message. The company's own wording is not in hand.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, as you summarised it) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says an appointment book for four physios, not calendars beyond that. Bridge: "For two years I ran the appointment book for four physios." Answer slot: if you moved or set appointments across more than that book, say how you handled clashes; if you did not, say so plainly and say what you would do first. |
| F2 | "booking travel" (ad, as you summarised it) | none given | none | [grounded] | discovery | The material is silent on travel. Answer slot: if you have booked travel for anyone, say what and how; if you have not, say so plainly and say what you would do first. |
| F3 | "preparing documents in Word" (ad, as you summarised it) | "I'm good with Word" (your message) | low | [grounded] | none | Self-rated, with nothing inspected behind it, so expect a practical check. Bridge: "I'm good with Word." |
| F4 | "documents in ... Excel" (ad, as you summarised it) | "I'm okay with Excel" (your message) | low | [grounded] | discovery | Your material does not show what you have done in Excel. Bridge: "I'm okay with Excel." Answer slot: if you have used Excel for more than basics, name the task in your own words; if you have not, say so plainly and say what you would practise first. |
| F5 | "processing supplier invoices" (ad, as you summarised it) | "I chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is not the same as processing supplier invoices, and the bridge should not be stretched. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved any supplier invoices, say how; if you did not, say so plainly and say what you would learn first. |
| F6 | "Remote Administrative Assistant" (the company's email) | none given | none | [grounded] | hard_gate | Your material does not establish whether remote working from your location, with the hours and set-up the role needs, is met. Surfaced, not bridged. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. Each is limited by the quote it stretches.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed senior people's calendars | Inflated form of F1 | "I ran the appointment book for four physios." Your material says the book, not calendars for others. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." Your material says chasing, not processing. |
| Excel-proficient | Inflated form of F4 | "I'm okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: supplier invoices, Excel depth, travel | Top weight. A first call with an office manager for an admin role tests whether the CV matches the duties. | Rehearse the invoice gap until it is plain. Hold the appointment book and the chasing; concede the rest without bluffing. |
| Case / Strategist | Live admin problems: a clash, a missing purchase order, a deadline | Second weight. The duties are practical, so a scenario is likely. | Clarify first, then say the steps. Name what you would check and whom you would ask. |
| Conversational | Opens with "walk me through your background" | Mid weight. A 30-minute call often starts casually, and the opener is scored. | A 90-second arc from your two sentences only. |
| Data-Driven Prober | Asks how you kept the book accurate, what you did with overdue invoices | Mid weight. Your numbers are few, so probes look for what you can explain. | Say what you did, not what you measured. Say so when you did not track a figure. |
| Pressure | Interrupts, challenges your fit against others | Mid weight, because the call is short and the stakes feel high. | Pause, restate, hold a position through two follow-ups, then concede the real gap. |

## Question banks

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you find hardest on day one?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" (your message) | Name the item you have least evidence for, using the ad's own list, and say what you would do first. | F2, F4 and F5 all touch this. A plain answer scores better than a guess. |
| A2 | "The role includes processing supplier invoices. What have you done with invoices, and what was your part?" | JD | [grounded] "I chased unpaid invoices" (your message) | Say you chased unpaid invoices and whose they were. Answer slot: if you entered, matched or approved supplier invoices, say how; if you did not, say so plainly and say what you would learn first. | Highest-ROI prep in this pack. This objection is aimed at F5, the gap between chasing and processing, and it will arrive in some form. Rehearse both branches. |
| A3 | "You've worked in a clinic. How would you handle a remote role with no one on site?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Describe one thing you did at the clinic when others were not around, in your own words. If there is nothing like it, say so and say how you would keep up. | F6 and the remote setting. Asked as a plan, not a claim. |
| A4 | "Why are you moving from clinic reception into an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Give your real reason in your own words. If the reason is not settled yet, name the nearest thing you actually want. | The motivation probe every Skeptic runs. Keep it to what you have said. |
| A5 | "Excel is in the list. How would you rate yourself, and what have you done in it?" | JD | [grounded] "I'm okay with Excel" (your message) | Say "I'm okay with Excel", then name the most complex task you have done in it. Answer slot: if you have used only basics, say so and say how you would build up. | F4. A self-rating invites a probe, so have the task ready. |

### Case / Strategist (weight: second, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A calendar has three meetings clashing on Thursday and a flight to rearrange. Walk me through what you do first." | CASE | [generic] | Clarify whose calendar and which meeting matters most. Then say whom you would contact and what you would check before moving anything. | A live problem from the ad's calendar and travel duties. It asks about no past. |
| B2 | "A supplier invoice arrives with no purchase order. What happens next?" | CASE | [generic] | Say what you would check on the invoice, who approves, and what you would record. Say what you do not know about their process and ask. | The invoice duty, asked as a decision. Presupposes nothing about your past. |
| B3 | "You need a document in Word and a summary in Excel by 5pm, with two hours left. How do you plan it?" | CASE | [generic] | Split the work into the two outputs, check the deadline, and say what you would ask first. | Documents duty. Tests planning, not tool depth. |
| B4 | "Your manager wants travel booked for three people next month, and two need a fixed time. How do you approach it?" | CASE | [generic] | Say what you would confirm first, what you would hold, and whom you would check with before booking. | F2. Asked as a plan, so the guidance makes no claim about travel you have done. |

### Conversational (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" (your message) | A 90-second arc: the clinic, the appointment book, the invoices, then why this role. Use only these sentences. | F1 and F5. The opener is scored even though it sounds casual. |
| C2 | "What are you good at day to day?" | JD | [grounded] "I'm good with Word" (your message) | Say "I'm good with Word" and one real task you have done in it. If you cannot name one, say so. | F3. Be ready to back it up. |
| C3 | "How do you keep track of many things at once?" | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Describe how you kept that book for four people, in your own words. | F1. The answer is the book, not a system you have not used. |

### Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you keep the appointment book accurate?" | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Say what you did, in your own words. Answer slot: if you tracked a figure, say how it was counted; if you did not, say so plainly. | F1. Probers look for what you can explain. |
| D2 | "When you chased unpaid invoices, what happened next?" | EXP | [grounded] "I chased unpaid invoices" (your message) | Say whom you contacted and what they did. If you do not know the outcome, say so. | F5. The guidance makes no claim about amounts recovered. |
| D3 | "Which Excel task do you use most?" | JD | [grounded] "I'm okay with Excel" (your message) | Name the task in your own words. If you use it only for simple things, say so. | F4. |

### Pressure (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone with supplier invoice experience?" | JD | [grounded] "I chased unpaid invoices" (your message) | Hold: name what you bring from the chasing and the appointment book. Concede the invoice-processing gap plainly. Do not fold on the core claim. | F5. Hold, then concede the specific gap. |
| E2 | "That chasing: how much of it was actually you?" | EXP | [grounded] "I chased unpaid invoices" (your message) | Say which part was yours, in your own words. If others did parts, say so. | Attribution probe. Hold through two follow-ups. |
| E3 | "I don't see travel bookings or senior calendars in your background. How will you manage without them?" | JD | [grounded] "I ran the appointment book for four physios" (your message) | Hold the appointment book. Concede that travel is not in your material, and say how you would learn it. | F1 and F2, asked as a limit, not a confession. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the first month look like, and which tasks would come first?" | Shows you think in the job's tasks. |
| R2 | "What does a typical week of calendar and travel work involve?" | Tests the duties in the ad. |
| R3 | "How does the supplier invoice process run, from receipt to approval?" | Prepares you for the invoice duty. |
| R4 | "Which software do you use for calendars, travel and documents?" | Tells you what to practise before any practical test. |
| R5 | "What will the 30 minutes cover, and is anyone else involved in the decision?" | Tells you how to prepare for the call. |

## Sources

Provided documents: your message (the company's email, your summary of the ad, your background).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | Values cheat sheet, section 10. Not in play, since no values-style round was detected. Queried "Brennock Facilities Ltd": refused. |
| 2. Brennock Facilities Ltd interview process, remote administrative assistant | unavailable | Loop structure. Persona weights fall back to round-type priors. Queried "Brennock Facilities Ltd interview process remote administrative assistant": refused. |
| 3. Brennock Facilities Ltd strategy / recent news | unavailable | Grounding brief and CO questions. No call sent after the host refused search. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative administrative assistant JD | unavailable | Your ad summary is not the full text, so the fit snapshot's requirements stay as you summarised them. No call sent after the host refused search. |

## Upgrade menu

- The full ad text → turns the requirements in F1 to F5 from your summary into the company's own words, and lets the Skeptic bank quote them
- The office manager's name → persona weights and a tailored reverse question
- Search permission granted → the company values and interview process rows, which are unavailable in this run
