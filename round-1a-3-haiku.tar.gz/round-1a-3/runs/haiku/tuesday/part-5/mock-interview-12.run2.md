Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also says "Successful candidates receive a cheque for €1,850" and "you deposit the cheque and send the balance on to the vendor." Requests like these before an offer are a known scam pattern, and this invite is very likely a scam. Hold the fee, the cheque, and the passport and bank details until you have checked the invite with the employer, using contact details from its own website or careers page rather than anything in the invite. job-underwriter can check the invite as a separate request if you want that. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

The interview itself is a normal thing to prepare for. The short version:

- **Expect:** a 30-minute video call with the office manager. Most questions will be about the duties you have least evidence for, booking travel and Excel, plus one or two live admin problems.
- **Lead with:** the appointment book for four physios and chasing unpaid invoices. Say them in your own words.
- **Rehearse the honest answers:** for travel booking, say how you would learn the tools, as a plan rather than a past. For Excel, "okay" is an accurate answer, so don't stretch it.
- **Prep the reverse questions:** asking about the first week and the tools they use shows you have thought about the job.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-12-denied-e35c1c03/2ccdb767-7f45-4c9e-9db6-20f6a70312a7/scratchpad/brennock_remote_administrative_assistant_interview_pack.md. It has 17 questions, a requirement-coverage table, and the reverse questions.

Say the word and I'll play the Skeptic on A2, the travel question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person who would supervise you day to day, or someone who screens candidates before a later round?

Do you want a research pass on the company's public description and any published values before the call? It would take a few searches. I skipped it this time, so the company-specific parts of the pack are generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_administrative_assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Interviewer:** office manager (name not given)
- **Round:** 30-minute video call; relationship to you not stated, so weighted as a hiring-manager round
- **Version:** first

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **JD**: role and job-driven
- **EXP**: your work-experience deep-dive
- **CASE**: a live problem
- **VAL**: behavioural or values (none in this pack; no published values were supplied)
- **CO**: company knowledge (none in this pack; no research was run)

Guidance is scaffolding, not a script. An answer slot is an instruction: answer whichever branch is true for you, in your own words.

**Highest-ROI prep: A2.** Booking travel is the duty your material does not cover, so it is the question most likely to be probed.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as your message gives it | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence already reaches it in other words: "I ran the appointment book for four physios." Add no tool, volume or practice. |
| F2 | "booking travel" — the ad, as your message gives it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you booked travel for anyone, say whom and how, in your own words; if you have not, say so plainly and describe how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" — the ad, as your message gives it | "good with Word" — your message, "okay with Excel" — your message | low | [inferred] | discovery | Both are your own self-ratings with no document behind them, so the pack claims no more than that. Answer slot: name one document you prepared in Word and one thing you did in Excel, and what each was for, in your own words; if you did neither, say so plainly. |
| F4 | "processing supplier invoices" — the ad, as your message gives it | "chased unpaid invoices" — your message | low | [grounded] | transferability | The sentence is adjacent: chasing is not processing, and your material does not say whose invoices they were. Answer slot: if you handled supplier invoices through to payment, say which steps, in your own words; if you did not, say so and say what you did with unpaid invoices. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executives' calendars | Inflated form of F1: a scope the quote does not state | F1's quote at its own scope: "I ran the appointment book for four physios." Pack observation: your material says an appointment book for four physios, not calendars managed for others. |
| Advanced Excel | Inflated form of F3: "okay" widened | "okay with Excel", at its own scope |
| Processed supplier invoices | Inflated form of F4: chasing widened into processing | "chased unpaid invoices", at its own scope. Pack observation: your material does not say processing. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the duties with no evidence: travel booking, then Excel | High. A hiring-manager round weights Case and Skeptic most, and F2 and F3 are where a probe lands | Answer the true branch, then return to a plan for learning. Hold through two follow-ups |
| Case / Strategist | Live admin problems from the ad's own duties | High. Weight 5 of 17 | Clarify, then structure, then think aloud |
| Data-Driven Prober | Asks how you check figures and what you made | Medium. Only if the office manager reads your answers closely | Name what you actually check. Say plainly when you do not check |
| Pressure | Short, challenging follow-ups in a 30-minute call | Medium. Weight 3 of 17 | Pause, restate, hold a true position, concede a real gap specifically |
| Conversational | Warm opener and a casual question about the job | Certain to open the call. Casual questions are still scored | A 90-second arc from your quotes only |

Weights: Skeptic 4, Case 5, Prober 2, Pressure 3, Conversational 3. Total 17.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" — the ad, as your message gives it | Name one duty, not all four. Booking travel is the one with no evidence in your material. Then say how you would learn it in your first week, as a plan. | F2 is the largest gap, so a flat answer here is the most likely miss. |
| A2 | "Have you booked travel for anyone, and if so, how?" | JD | [grounded] "booking travel" — the ad, as your message gives it | Answer slot: if you booked travel for anyone, say whom and how; if you have not, say so plainly, then describe how you would learn the booking tools. Hold through two follow-ups by returning to that plan. Never add a trip you did not book. | F2's requirement, asked open so either true branch works. Highest-ROI prep in this pack. |
| A3 | "You described your Excel as okay. How would you handle a spreadsheet you could not fix?" | JD | [grounded] "okay with Excel" — your message | Use your own rating as it stands: "okay with Excel". Then the steps you would take: the built-in help, a colleague, a short course, given as a plan. Do not describe a formula or workbook you have not built. | F3 is a thin Excel line, so the probe turns a self-rating into a test. |
| A4 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" — your message | Story-mapped on F4: the chasing, which is what your sentence states. Tell it in your own words: whose invoices, how you followed up, what happened. Answer slot: if you ever processed supplier invoices through to payment, say which steps; if not, say so plainly and say how you chased. | F4 is the adjacent case, and the interviewer will ask how far the chasing went. |

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three people need travel next Tuesday, but the flights don't fit their calendars. What do you do?" | CASE | [generic] | Clarify first: who approves the travel, what budget or policy applies, and which date can move. Then structure: check each calendar, list options, get approval, confirm the bookings. Think aloud. Makes no claim about your past. | Tests travel and calendars together, the two duties the ad joins. |
| B2 | "A board meeting clashes with a client call and the room is double-booked. Talk me through the next ten minutes." | CASE | [generic] | Clarify who owns each booking and which meeting takes priority. Propose a move, and confirm with both owners before changing anything. | Calendar management as a live problem. |
| B3 | "A supplier invoice has been paid twice. What happens next?" | CASE | [generic] | Stop any further payment, check the records, confirm with the supplier and whoever approves payments, and note what you did. | The invoices duty as a live problem. |
| B4 | "The monthly pack is due Thursday and its figures are in three spreadsheets. How would you prepare it?" | CASE | [generic] | Clarify the format, the owner and the deadline. Gather the figures, check the totals against each source, and flag anything you cannot verify rather than filling it in. | Word and Excel as a live problem. The flag step tests honesty. |
| B5 | "What would you do in your first week here?" | CASE | [generic] | A plan, not a claim: the booking tools and the invoice process, learned with the office manager, then a list of questions you would bring. | Opens the role's day-one questions. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's the most involved document or spreadsheet you've produced, and who used it?" | EXP | [grounded] "good with Word" — your message; "okay with Excel" — your message | Answer slot: if you produced a document or spreadsheet for someone else, name it, what it was for, and whether anyone checked it, in your own words. If you did not, say so plainly, then name the most involved thing you did do. | F3 is a vague self-rating, so this asks for an instance. The honest answer may be a small one. |
| C2 | "How do you check a total before you send it on?" | EXP | [generic] | Name the checks you actually run. If you run none, say so and name one you would add. | A prober's habit question, asked about your figures rather than a claim. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire you over someone with stronger Excel?" | JD | [grounded] "okay with Excel" — your message; "ran the appointment book for four physios" — your message | Hold on what your quotes carry: the appointment book for four physios. Concede Excel plainly in your own words. Hold through two follow-ups, then concede the gap specifically. | F3 under pressure. Hold, then concede. |
| D2 | "That sounds like reception work, not admin. How is it different?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message; "chased unpaid invoices" — your message | Hold on what your quotes carry: the appointment book, and the invoices you chased. Concede that you have not handled travel or supplier payments. Hold, then concede. | Pressure on the move from reception. Hold, then concede. |
| D3 | "Why do you want an admin job rather than staying in clinic work?" | EXP | [generic] | Give your own reason in your own words. Your material does not state one, and this pack will not supply it. | A motivation probe. The answer has to be yours. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message; "ran the appointment book for four physios" — your message | A 90-second arc with only the beats those quotes state: reception, the appointment book for four physios, chasing invoices, and why admin next. | An opener is still scored. |
| E2 | "Which part of the job are you most looking forward to?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" — the ad, as your message gives it | Pick one duty from the list and say why, in your own words. Do not name one you have not done as if you had. | A casual question on the ad's own duties. |
| E3 | "What did you like most about working at the clinic?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Name one true thing in two sentences. | A warm-up that is scored for ease and honesty. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | B2, E2 |
| booking travel | A1, A2, B1 |
| preparing documents in Word and Excel | A3, B4, C1, D1 |
| processing supplier invoices | A4, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the first week look like, and what would you need from me by then?" | Shows you plan ahead. |
| 2 | "Which booking and invoice tools does the team use day to day?" | Lets you prepare on the tools you will actually use. |
| 3 | "How is the work split between remote and office days, and how often do you check in?" | Shows you have thought about working remotely. |
| 4 | "What would make someone in this role doing well after three months?" | Gets the success measure in the office manager's own words. |
| 5 | "What happens after this call?" | Shows you want to understand the process. Its answer tells you how the process runs. |

## Sources

- **Provided documents:** your message only (the ad summary, the invite text, and your background).
- **Searches and fetches:** none sent.
- **Research tier:** L0, no searches. No research consent was given this turn, so the company-specific parts of this pack are generic.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet (not included). No research this turn |
| 2. Company interview process | unavailable | Loop structure and persona weights. No research this turn |
| 3. Company strategy or recent news | unavailable | Company knowledge questions (none in this pack). No research this turn |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative JD | skipped | The four duties you supplied fix the fit snapshot and the JD questions |

## Upgrade menu

- The full job advert text → the four duties become quoted requirements, and the coverage table checks each one against the full wording
- Your CV → the evidence quotes can come from the CV as well as your message, and a document you can show would raise F3's confidence
- The office manager's name and role → persona weights and a reverse question tied to their path
- A research pass on the company's public description and any published values → the values cheat sheet and company knowledge questions
- tuesday-dossier.md from an earlier session → would add the gaps that earlier prep exposed
