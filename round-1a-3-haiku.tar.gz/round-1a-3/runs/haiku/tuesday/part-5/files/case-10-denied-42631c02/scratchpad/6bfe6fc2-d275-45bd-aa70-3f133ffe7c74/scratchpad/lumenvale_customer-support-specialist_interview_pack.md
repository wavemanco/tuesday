# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Format:** text chat on Telegram with the support team lead (the invite names a team lead; no name given).
**Built on:** a hiring-manager-style round, since the invite names a team lead and nothing else. Persona weights rest on that assumption.
**Requirements:** quoted from your message, where you summarised the ad. The ad's own text was not supplied.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = the role's stated requirements. **EXP** = what you actually did, in your own words. **CASE** = a live problem from the job. **VAL** = values (none detected here). **CO** = company knowledge (none researched).
- Guidance is scaffolding, not a script. Answers in this chat are typed, so aim for 80 to 150 words each unless the lead asks for more.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | No gap. Say the three years and the daily volume in those words. Expect a probe on the 60, see D1. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, so the requirement is reached in role-relevant terms. Say Freshdesk and the daily use, with nothing added. Do not claim Zendesk; the material does not show it. |
| F3 | "clear written communication" (your message) | none given | none | [grounded] | discovery | Your material does not show a written reply of yours. Answer slot: give one written reply you sent that resolved a customer's problem, in your own words; if you have none, say so and say how you would check a reply before it goes out. |
| F4 | "confidence handling escalations" (your message) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Training others on refunds is adjacent to escalations, not the same thing. Say only: "Last year I trained four new starters on our refunds process." Answer slot: if an escalation came to you, say what you did with it; if none did, say so and say how you would decide what goes up to a team lead. |
| F5 | no software-company requirement in the ad as you summarised it; a likely probe | "I've never worked for a software company." (your message) | none | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I've never worked for a software company." Then how you would learn a product, said as a plan and never as a past. |

**Reading the snapshot:** F1 and F2 are your strongest rows. F3 and F4 are where the ad asks for something your material does not show, so they are where the interview is most likely to test you.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Presses the software gap and the ticketing tool | High. Your CV and the ad differ most on software, so expect this first | Acknowledge the gap in your exact words, then a plan. Hold through two follow-ups |
| Case / Strategist (weight 4) | Live support scenarios typed into the chat | High. A team lead tests live handling more than anything | Clarify, then write the first reply, then the follow-through |
| Pressure (weight 3) | Short, challenging prompts | Medium. A chat can be time-boxed and a lead may test composure | Hold your position through two follow-ups, then concede the exact gap |
| Data-Driven Prober (weight 4) | Asks how the 60 a day was counted | Medium. That is the only headline number in your material | Say how it was counted in your words, or say you do not know |
| Conversational (weight 2) | An opening "walk me through" | Medium. Any chat opens this way, and casual questions are still scored | Have a 90-second arc ready, built from your own sentences |

## Prohibited claims

These are not to be coached, and each entry says why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has handled escalations | Inflated form of F4 | F4's quote at its own scope. Your material says the refunds training, not escalations. |
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day". Your material says Freshdesk. |
| Owns the refunds process | Inflated form of F4 | "I trained four new starters on our refunds process last year." Your material says you trained others on it, not that you set it. |
| Has worked in software support | Negative you stated, F5 | "I've never worked for a software company." Plain acknowledgment, no slot. |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why are you moving from an energy supplier into software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say what the energy role gave you, in those words. Answer slot: give your own reason for moving, in your own words; your material gives none, so do not borrow one from the ad. | F1 is the background; the reason is not in your material, so the answer is yours to give. |
| A2 | "You have never worked for a software company. What would you do with a product you have never supported?" | JD | [grounded] "I've never worked for a software company." | Plain acknowledgment: "I've never worked for a software company." Then how you would learn the product, as a plan, never as a past. | F5 is the stated absence; the lead will likely start here. |
| A3 | "Clear written communication matters here. Show me how you would write a reply that cannot yet solve the customer's problem." | JD | [generic] no candidate sentence; the requirement is from your message | Write the reply live, in order: acknowledge, say what you can do now, say what you cannot yet do and the next step. Answer slot: if you have sent a written reply that resolved something, give it in your own words; if not, say so plainly and use the structure above. | F3 is discovery, so the reply has to be built live; the chat will test this directly. |
| A4 | "What counts as an escalation for you, and what did you do with the last one?" | JD | [inferred] "I trained four new starters on our refunds process last year" | Clarify-strategy note only: refunds training is adjacent to escalations, not the same. Answer slot: if an escalation came to you, say what you did with it in your own words; if none did, say so plainly, then say how you would decide what goes to a team lead. | F4 is low confidence, so it is coached as a clarify, not asserted. |
| A5 | "Your CV has no software support work. Why should we believe you will pick up our product fast?" | JD | [grounded] "I've never worked for a software company." and [grounded] "I use Freshdesk every day" | **Highest-ROI prep in this pack.** Acknowledge: "I've never worked for a software company." Then "I use Freshdesk every day", the ticketing tool you already run daily. Then a learning plan, as a plan. Hold through two follow-ups by returning to the daily tool and the plan; concede exactly what you have not done. | The most predictable objection, and where your material is thinnest. A rehearsed, non-defensive answer changes this round. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says their promised refund never arrived and they are angry. Walk me through your reply." | CASE | [generic] no candidate sentence; a live problem from the role | Clarify first (what was promised, when, what the refund record shows), then the first reply, then the follow-through. | A live problem from the job; it asks about no past. Covers the escalations requirement. |
| B2 | "A ticket reaches you because a billing error on our side caused it. What do you decide in the first ten minutes?" | CASE | [generic] | Confirm the facts, decide who owns the fix, tell the customer what happens next and when. | Tests the escalations requirement as a decision. |
| B3 | "Ten customers in an hour report the same fault. What do you do?" | CASE | [generic] | Look for one common cause, tell the customers the one thing you know, log it for the team lead. | Tests triage and calm handling of a spike. |
| B4 | "A customer writes: I will cancel if this is not fixed today. What is your first sentence?" | CASE | [generic] | Write the first sentence out. Acknowledge the stake without promising an outcome you cannot give. | Tests composure in writing, which the chat format makes visible. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have sixty seconds: why should we hire you over someone with two years on a ticketing tool?" | JD | [grounded] "I use Freshdesk every day" | Hold the daily Freshdesk use and the ticket volume from your job. Do not claim Zendesk or any tool you have not used. Hold through two follow-ups; concede the gap exactly. | The requirement's comparison, under time pressure. |
| C2 | "If a refund you approved turned out to be wrong, how would you find out, and what would you say to the customer?" | JD | [generic] | Own the decision, state the fix, and do not blame the system. | A hypothetical, so it claims no past event. |
| C3 | "I am not convinced a phone and email handler can do chat support well. Convince me." | JD | [grounded] "answering around 60 calls and emails a day" | Hold to what you did: the daily volume and email. Concede exactly what you have not done in chat, in your own words. | Hold-then-concede. The position is only what your sentence carries. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 60 calls and emails a day was counted." | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted, in your own words; if you do not know, say that plainly. Name the assumption you would defend least. Say which part of the volume was yours to answer. | The one headline number in your material; it must be defended precisely. |
| D2 | "How do you decide which of a day's contacts needs the most care?" | JD | [generic] | Name the signals you use, such as tone, stake and deadline, in your own words. Answer slot: say which of these you actually used. | A process question with no claim about your past. |
| D3 | "Ticket volume at 60 a day: what changes when it doubles?" | JD | [generic] | Say what you would protect first (reply quality), what you would change (queues and templates), and what you would escalate. | A what-if, so it claims nothing about your history. |
| D4 | "What did the refunds training cover?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what it covered, in your words. Answer slot: if you measured whether the training worked, say how; if you did not, say so plainly. | Premise is only the training you stated; no outcome is assumed. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and [grounded] "I trained four new starters on our refunds process last year" | A 90-second arc: energy supplier, three years, calls and emails, training starters, now applying. Every beat is a clause you wrote. | Casual openers are scored. |
| E2 | "What are you actually playing with in Freshdesk these days?" | JD | [grounded] "I use Freshdesk every day" | Say what you use it for, in the words you used. Answer slot: if you have set up or changed anything in it, say what; if you only answer tickets in it, say that. | A casual route to the Zendesk-or-similar requirement. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "2+ years in customer support" | E1, D4, D1 |
| "experience with Zendesk or a similar ticketing tool" | E2, C1, A5 |
| "clear written communication" | A3, B4 |
| "confidence handling escalations" | A4, B1, B2 |
| Software background (not in the ad as you summarised it) | A2, A5 |

## Reverse questions

Five, each with why it lands. None asks the lead to check the invite.

1. "Is the chat interview one session, or is a call or video follow-up planned?" Why it lands: tells you how to pace typed answers and what comes next.
2. "What does the first month look like for someone starting on your support team?" Why it lands: shows you are thinking about the work, and reveals the onboarding path.
3. "Which kinds of ticket usually go up to a team lead, and how quickly?" Why it lands: this is where F4 is thin. The answer tells you what to say before you type the escalation answer.
4. "Which ticketing tool does the team work in day to day?" Why it lands: shows where Freshdesk transfers and what to learn first.
5. "What do you most want a new person to be able to handle in their first week?" Why it lands: asks the lead directly what matters most in this role.

## Sources

- **Provided documents:** your message, including the invite text and your summary of the job ad and your background.
- **Searches sent:** "Lumenvale Software values" and "Lumenvale Software interview process customer support specialist". Both were **refused**: web search permission was not granted in this session.
- **Research tier:** L0 in effect. Searches 0 of 6, fetches 0 of 2. The default tier is L1; the host refused search.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet, not built. No published values were read. |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure. Persona weights rest on relationship priors, not the company's process. |
| 3. Lumenvale strategy / recent news | unavailable | CO questions. None written, so the pack has no company-specific questions. |
| 4. Interviewer name | n/a | No name given. |
| 5. Representative JD | unavailable | The full ad text was not supplied, so requirements come from your summary. |

Values, process and strategy are therefore not established. Nothing in this pack uses them.

## Upgrade menu

- The full job ad text → the four requirements quoted from the ad itself, so F1 to F4 rest on the ad's own words, not your summary.
- The team lead's name → an interviewer read and a tailored reverse question.
- Web search permission in a later session → company values, interview process and strategy, which could add a values cheat sheet and CO questions.
- A tuesday-dossier.md → carries the gaps this prep exposed into later sessions.
