# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Title block.** Role: Remote Administrative Assistant. Company: Brennock Facilities Ltd, as named in the invite. Interviewer: office manager, name not given. Round: 30-minute video call, a hiring-manager-type round. Built from your message and the invite only. No research ran, so there is no values section and no company-specific questions.

**How to use this pack.** Personas are how a question is asked. Types are what it scores: EXP (what you actually did), JD (can you do the listed work), CASE (a live problem), CO (company knowledge). Guidance is scaffolding, not a script. Rehearse your own words, and say "I haven't" or "I'd learn that by" where that is the truth.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (ad, your summary) | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material shows a clinic appointment book for four clinicians, not calendars for a person or an office. Say that, in those words: "I ran the appointment book for four physios." Answer slot: if you have managed anyone's calendar beyond that, say whose and how; if not, say so and stay with the appointment book. |
| F2 | Booking travel (ad, your summary) | none given | none | [grounded] | discovery | No capability claim is written from silence. Answer slot: if you have booked travel for anyone, say what you booked and how; if not, say so plainly and how you would learn it. |
| F3 | Preparing documents in Word (ad, your summary) | "I'm good with Word" — your message | low | [grounded] | discovery | "Good" is a self-rating with nothing behind it yet. Answer slot: name one document you produced in Word and what it was for, in your own words; if none, say so and what you would produce first. |
| F4 | Preparing documents in Excel (ad, your summary) | "okay with Excel" — your message | low | [grounded] | discovery | A self-rating only. Answer slot: say what you have used Excel for; if it was basic entry or lookups, say that; if you have built nothing, say so plainly. |
| F5 | Processing supplier invoices (ad, your summary) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is collections, not processing (entering, matching, approving, paying). Say what you chased, in those words. Answer slot: if you entered, matched or approved any invoices, say what and how; if not, say so. |
| F6 | Working remotely (ad, your summary) | none given | none | [grounded] | discovery | Answer slot: if you have worked remotely, say how and for how long; if you have not, say so and how you would set up. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for executives or an office | Inflated form of F1 | "I ran the appointment book for four physios." Your material shows a clinic appointment book, not an executive's diary. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." Your material shows chasing, not processing. |
| Expert or advanced in Excel | Inflated form of F4 | "okay with Excel." |
| Expert in Word | Inflated form of F3 | "good with Word." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "I don't see travel or invoice processing in your background." | High. A hiring-manager round prior, and the ad lists duties your clinic job does not show. | Hold what you stated, then give a plan for the gap. |
| Case / Strategist | A live admin problem from the ad's calendar and travel duties. | Medium. Office-manager rounds on admin roles often test process. | Clarify first, then order the steps aloud. |
| Conversational | A friendly opener, scored as well as any other question. | Medium. The opener is where your clinic background gets framed. | A 90-second arc, prepared in advance. |

Depth follows weight: the Skeptic gets four questions, the Case persona three, the Conversational persona two. The round is 30 minutes with one interviewer, so the bank is short on purpose.

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Most of this job is calendars, travel and invoices, and you've worked in a clinic reception. Why should I believe you can do it?" | JD | [grounded] "ran the appointment book for four physios" — your message; "chased unpaid invoices" — your message | Start with the two sentences you can say truthfully: "I ran the appointment book for four physios. I chased unpaid invoices." Then name the one task you would want to learn first and how you would learn it. Answer slot: if any other part of this role matches something you have done, say what and how, in your own words; if none does, say so plainly. | F1, F2 and F5 together are the widest gap, and the duties list is the objection. |
| S2 | "Have you ever booked travel for someone, or processed a supplier invoice from start to finish?" | JD | [grounded] "chased unpaid invoices" — your message | Highest-ROI prep: this will come in some form. Say what you did with invoices, in those words. Answer slot: if you booked travel or processed invoices yourself, say what and how; if not, say so plainly and describe how you would learn it, as a plan. Hold through two follow-ups by returning to what you chased. | F2 has no evidence and F5 is transferability. The question presumes a practice the material does not carry, so the second branch has to allow that it never happened. |
| S3 | "What have you built in Excel, and what did it do?" | JD | [grounded] "okay with Excel" — your message | Say what you have actually used Excel for, in your own words. Answer slot: if it was basic entry or lookups, say that; if you have built nothing, say so plainly and what you would start with. Never claim a level beyond "okay". | F4 is discovery; the material shows only a self-rating. |
| S4 | "Tell me about a document you've prepared in Word, and what it was for." | EXP | [grounded] "I'm good with Word" — your message | Answer slot: name one document you produced in Word and its purpose, in your own words. If none comes to mind, say so, then say what you would produce first. | F3 is discovery. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two directors need the same boardroom on Thursday, and one of them is flying in. What do you do?" | CASE | [generic] | Clarify first: who is attending, the exact times, what can move. Then order the actions: check the room, check the flight, offer the options, confirm in writing. Say it in 90 seconds. | A live admin problem from the ad's calendar and travel duties. No claim about your past. |
| C2 | "Walk me through booking flights and a hotel for a visitor with a fixed meeting time." | JD | [generic] | Steps, not experience: check preferences and budget, search, hold, confirm, send the itinerary to everyone. Name the step you would check twice. | Covers the travel duty. The answer is a process, and this guidance supplies no detail of your history. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, tell me about yourself." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | A 90-second arc: the role, the appointment book for four physios, the invoices you chased, and why this kind of admin work suits you. Answer slot for the "why": give your own reason; your material does not give one. | A casual opener is still scored, and it is where the clinic background gets framed. |
| R2 | "What do you know about us?" | CO | [generic] | Say only what the ad and the invite tell you, and that you would check the company's own website. Do not guess at facts. | No research ran, so this pack cannot supply company facts. |

## Reverse questions

1. "What does a normal week look like in this role: how much is calendars and travel, and how much is documents and invoices?" Why it lands: shows which part to rehearse most, and the answer tells you how much of the gap matters.
2. "Is this the only interview stage, or is there a second round?" Why it lands: asks about process, and the answer tells you whether to plan for more.
3. "Which tools does the team use for calendars, travel bookings and invoices?" Why it lands: tells you whether the Excel gap is about one tool or a whole system.
4. "Who would I work with day to day, and how is the role supported in the first month?" Why it lands: shows you think about onboarding in practice.
5. "What would a good first three months look like?" Why it lands: gives you a concrete picture to rehearse against.

## Sources

Research tier: L0, no searches; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Values section, not built. Research did not run in this turn. |
| 2. Brennock Facilities interview process, administrative assistant | unavailable | Loop structure, taken from the invite (one 30-minute video call). A search would have checked for more stages. |
| 3. Brennock Facilities strategy and recent news | unavailable | Would have moved a company-strategy question. None built. |
| 4. Interviewer name and company | n/a | No name given. |
| 5. Representative administrative assistant JD | unavailable | Your summary of the ad fixes the requirement rows, so this would only have checked wording. |

## Upgrade menu

- The full ad text → the requirement rows quoted word for word, not paraphrased
- Anything you have done with travel bookings or invoice processing → S2 and F2 fill with your own words
- The company's own careers page, or your say-so to run research → the values and interview-process rows checked against it
- A tuesday-dossier.md → records the gaps this prep exposes, for later sessions
