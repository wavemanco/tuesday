# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Round: interview with the support team lead, by text chat on Telegram. Relationship assumed to be hiring manager (see the persona table). Changelog: first version.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **EXP**: work-experience deep-dive
- **JD**: role and job-ad driven
- **CASE**: live problem from the role
- **VAL**: behavioral, values-style
- **CO**: company knowledge (not included; research did not run, see Sources)

Guidance is scaffolding, not a script. Say it in your own words, and only the parts you did.

## Fit snapshot

Requirements are your summary of the job ad. Where a quotation mark appears, the words come from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you summarized it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | Meets the requirement in role-relevant terms. Expect a probe on whether a phone and email advisor role counts as customer support. Say what you handled, in those words. |
| F2 | "Zendesk or a similar ticketing tool" — job ad, as you summarized it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a similar ticketing tool, so this reaches the requirement. You have not used Zendesk, so do not claim it. Say you use Freshdesk daily. |
| F3 | "clear written communication" — job ad, as you summarized it | none given | none given | [grounded] | discovery | Your material does not show written work. The interview is entirely in text chat, so this will be tested live. Answer slot: if you have written a customer reply you are proud of, say what made it clear, in your own words; if not, say so and write one in the chat. |
| F4 | "confidence handling escalations" — job ad, as you summarized it | "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Training others on a process is not the same as handling escalations. Your material does not show whether any escalation came to you. Answer slot: if an escalation came to you, say what you did and who you passed it to; if none did, say so plainly and describe how you would escalate here. |
| F5 | Remote role; location and working hours — job ad, as you summarized it | none given | none given | [grounded] | hard_gate | Your material does not establish where you are based or which hours you can work. The pack says this as its own observation and asks one question, below. |

Work-history facts you stated that the ad does not ask for: "I've never worked for a software company". Do not hide it, and do not argue it. Treat it as a fact the interviewer may probe.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Widens F2, which is about Freshdesk | "I use Freshdesk every day." The material says Freshdesk, not Zendesk. |
| Has handled escalations | Widens F4; the material shows training, not escalation | "I trained four new starters on our refunds process last year." |
| Set up or designed the refunds process | Widens the training sentence in F4 | "I trained four new starters on our refunds process last year." Whether you designed it is a question for your own answer, not for this pack. |
| Has software or product-support experience | Contradicts a quote you gave | "I've never worked for a software company." Plain acknowledgment; no slot. |

The pack's own observation: your material shows customer contact and daily ticketing work. It does not show escalation handling, written work in a chat, or software work.

## Persona table

Relationship prior: hiring manager (a support team lead). Dominant personas are Case/Strategist and Skeptic, per the rules for that relationship. The interview is text chat, which adds the Conversational register for openers and small talk.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live support scenarios in the chat; asks what you would do first | Highest. A team lead is buying capability for a support queue. | Clarify, then act. Think aloud in short messages. |
| Skeptic | Quiet probes on the gaps: escalations, written work, software | High. Your ad requirements and your CV are the places a gap shows. | Rehearse the escalation objection until it is boring. Concede the software gap plainly. |
| Data-Driven Prober | Asks how figures were counted | Medium. Your 60-a-day figure is a headline number. | Say how you know it, or that you don't. |
| Conversational | Friendly opener, "walk me through your journey" | Medium. Chat interviews often open this way. | Give a 90-second arc. Treat small talk as scored. |
| Pressure | Interrupts, challenges your fit, asks why you over others | Low to medium. Only if the lead tests composure. | Pause, restate, hold a position through two follow-ups. |
| Values/Behavioral | One open prompt on disagreeing with a process | Low. No values round is detected. | Use a real story if one exists; if not, say so. |

## Question banks

### Case/Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry that their refund has not arrived after two weeks. Walk me through your first three moves." | CASE | [generic] | Clarify first: the refund's status, what the customer was told, and the deadline in the policy. Then act: check, respond, and decide whether to escalate. Say each move in one sentence. Answer slot: if the refunds process you trained others on has a step for this, name it in your own words; if you do not know the process here, say so and ask. | A live problem from the role. Tests the escalation and refunds skills the ad asks for. |
| A2 | "What would make you escalate this ticket, and to whom?" | JD | [generic] | Name two or three triggers in your own words: a policy exception, a complaint that is not resolved, a safety or legal issue. Say who you would pass it to. Answer slot: if you have escalated a ticket before, say what made you do it and where it went; if you have not, say so plainly and describe how you would decide. | Covers the escalation requirement, which has no quote in your material (F4). |
| A3 | "A customer asks you to do something outside our policy. What do you say in Freshdesk?" | CASE | [grounded] "I use Freshdesk every day" — your message | Hold the policy, explain it plainly, and offer the nearest thing you can do. Keep the reply short. The Freshdesk sentence is the only claim the guidance rests on. | Tests tone and policy, on the tool you named in F2. |
| A4 | "Our team uses Zendesk. How quickly would you be productive in it?" | JD | [grounded] "I use Freshdesk every day" — your message | Name what is the same between Freshdesk and Zendesk in general terms: tickets, queues, replies. Say what you would need to learn. Answer slot: if you have used Zendesk, say so; if not, say that you have not, and say how you would learn it. | Covers the "Zendesk or a similar" requirement. Do not claim Zendesk use. |
| A5 | "Reply to a customer whose meter reading was estimated for six months. Write it here in the chat." | CASE | [generic] | Plain English. Acknowledge the problem once, say the next step and when, and avoid jargon. Keep it under about 80 words. | Tests the clear written communication requirement live. The interview is in text chat, so this is likely. |

### Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. Why would you be good at supporting our product?" | EXP | [grounded] "I've never worked for a software company" — your message | Hold on what the material shows: customer contact at volume and daily ticketing. Concede the software gap plainly, in your own words. Hold through two follow-ups, then say what you would learn first. | The most direct probe on your background. Not hidden, so it will be asked. |
| B2 | "Escalation handling is in the ad, and I don't see it in your background. How would you handle an escalation you cannot resolve?" | JD | [grounded] "I trained four new starters on our refunds process last year" — your message | **Highest-ROI prep.** Answer slot: if an escalation came to you at the energy supplier, say what you did and who you passed it to; if none did, say so plainly and describe how you would escalate here. Hold through two follow-ups by returning to what you would do, never by adding an escalation you did not handle. | This objection is the likeliest, and it lands where your material is thinnest (F4). |
| B3 | "Why leave an energy supplier for a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message | Give your own reason in your own words. The material gives no reason, so there is nothing to supply. Keep it to one or two sentences and tie it to the role. | Motivation is always probed by the skeptic. Your reason is not in the material. |
| B4 | "Your current day is around 60 calls and emails. Can you keep up with the pace here?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say the pace you handled and what you did to keep quality. Do not promise a number you have not worked at. | Premised on your own figure, so it is asked on that basis. |

### Data-Driven Prober (weight: medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How was the 60-a-day figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Answer slot: say how you know it, in your own words. If you did not count it yourself, or it is an estimate, say so. Never give a method you did not use. | Your headline number will be probed. This is the defend-the-number slot. |
| E2 | "What did the four new starters you trained actually learn, and how did you check?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Answer slot: say what you taught and how you checked it, in your own words. If you did not check, say so. | Tests whether the training claim survives a follow-up. |

### Conversational (weight: medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey to support." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message | A 90-second arc: energy supplier, the daily volume, the Freshdesk work, training others. Use the sentences above and no others. | Chat interviews often open here. Casual questions are scored. |
| C2 | "What do you use day to day in your ticketing tool?" | JD | [grounded] "I use Freshdesk every day" — your message | Name what you actually do in Freshdesk each day, in your own words. | Probes the Zendesk requirement in a friendly register. |

### Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company" — your message | Do not argue. Say what you bring from customer contact and training, plainly. Hold through two follow-ups; concede the gap if pressed. | Tests composure on your weakest fact. |
| D2 | "Be honest. How much of the refunds process did you actually design?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Answer slot: say what you did, in your own words. If you did not design it, say so. | The sentence says you trained others, not that you designed the process. The answer must match that. |

### Values/Behavioral (weight: low, 1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you disagreed with a process." | VAL | [generic] | Pick a real time. Say what the process was, what you did, and how it ended. If no time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | An open prompt. The persona stem is the only source. |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| 2+ years in customer support | F1, B4, C1, E1 | |
| Zendesk or a similar ticketing tool | A4, C2 | |
| Clear written communication | A5, F3 | Tested in the chat itself. |
| Confidence handling escalations | A1, A2, B2 | Highest-ROI area; see B2. |

## Reverse questions

Ask these in the interview. None checks the invite.

1. "What does a first week look like for someone in this role?" Why it lands: shows you are planning, not just applying.
2. "Which ticketing tool does the team use day to day, and how much would I learn on the job?" Why it lands: tests your Zendesk gap in the lead's own words.
3. "What does an escalation look like here, and who owns it after I pass it on?" Why it lands: shows you know escalations are a separate skill.
4. "How is the quality of written replies checked?" Why it lands: the written communication requirement, asked as a process question.
5. "What do new starters find hardest in their first month?" Why it lands: gives the lead a reason to talk about the real job.

## Sources

Provided documents: your message, including the invite text and your background summary.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

Both web searches were refused by the host (permission not granted), so no company page was read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Both calls refused; see the search list below. |
| 2. Lumenvale interview process, support role | unavailable | Loop structure and persona weights. The first search was refused. |
| 3. Lumenvale strategy / recent news | unavailable | Company knowledge (CO) questions. No call sent; the L1 budget went to targets 1 and 2 first. |
| 4. Interviewer name and company | n/a | No name was given for the support team lead. |
| 5. Representative job ad | unavailable | Would have turned the requirement wording into quoted text. No call sent. |

Searches sent:
- "Lumenvale Software careers customer support specialist" (target 2): refused
- "Lumenvale Software company values interview process" (target 1): refused

## Upgrade menu

- The full job ad text → the requirements become quoted and [grounded], and the fit snapshot's wording is checked against the ad.
- The support team lead's name → a tailored reverse question, and persona weights read from their public footprint.
- Your location and working hours → resolves F5, the gate row.
- Whether the team lead is the person you would report to → confirms the hiring manager relationship, and reweights the banks.
- Company research once web search is allowed → a values cheat sheet and company knowledge questions.
- A tuesday-dossier.md → carries your gaps from this prep into later sessions.
