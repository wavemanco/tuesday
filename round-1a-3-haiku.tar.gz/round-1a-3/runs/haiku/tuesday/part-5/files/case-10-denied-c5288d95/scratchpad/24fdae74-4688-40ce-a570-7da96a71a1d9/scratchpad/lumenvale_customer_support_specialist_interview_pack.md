# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Interviewer:** support team lead (name not given). **Round:** first-round text chat on Telegram. **Assumed relationship:** hiring manager, since the invite names the team lead. **Change:** first version.

## How to use

Personas are how a question is asked. Types are what is being scored:

- **EXP**: whether your past work survives scrutiny
- **JD**: whether you can do the listed job, gaps included
- **VAL**: whether past behaviour shows good customer support, in general terms (no published values were available)
- **CASE**: how you structure a live support problem
- **CO**: company knowledge (not covered; no research was available)

The guidance is scaffolding, not a script. Rehearse it in your own words, and only with what you actually did.

## Fit snapshot

Requirements come from your summary of the ad. The full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap on years. The title says customer service rather than support, so use your own words: "For 3 years I was a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | none | Freshdesk is a ticketing tool of the kind the ad names. Say: "I use Freshdesk every day." Do not claim Zendesk; you have not said you have used it. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | medium | [grounded] | presentation | Your material gives the volume of your emails, not how clear they are. The bridge reworks only that quote: "I answer around 60 calls and emails a day." This chat is itself a writing sample, and the interviewer will judge your replies here. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show an escalation you handled. That is the pack's observation, not words for you. Answer slot: if you have handled an escalation, say what the customer needed, what you did and what you handed on, in your own words. If you have not, say so plainly and describe how you would handle one. |
| F5 | Product or software context (likely probe; not in the ad you gave) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing is added to make the gap feel smaller. |

## Prohibited claims

Each entry is an inflated form of something you said. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| "Expert in Zendesk" or "I know Zendesk" | Inflated form of F2 | "I use Freshdesk every day." The material says Freshdesk, not Zendesk. |
| "Writes clear, polished customer emails at scale" | Inflated form of F3 | "I answer around 60 calls and emails a day." The material gives volume, not quality. |
| "Designed or set the refunds process" | Inflated form of your training sentence | "I trained four new starters on our refunds process last year." The material says trained, not designed. |
| Any software-company experience, or knowledge of a software product | Negative you stated, F5 | "I've never worked for a software company." Plain acknowledgment, no slot. |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios: an angry customer, a failed fix, a surge of tickets | High. A hiring-manager round tests handling on the job's own problems | Clarify first, then give the next step and a timeframe. Keep replies short, one question at a time |
| Skeptic | Never worked for software; Zendesk; escalations | High. These gaps are visible from your own summary | Hold the true position through two follow-ups, then concede the learning curve plainly |
| Values / Behavioral | Past calls and emails, STAR-shaped | Medium. No published values to map, so the stories are selection scaffolds | One concrete call or email, your part in it, and how it ended |
| Conversational | A friendly opener and "what are you working on" | Medium. Casual openers are scored too | A 90-second arc built only from quoted sentences |

Weights: Case 5, Skeptic 5, Values/Behavioral 5, Conversational 3. Total 18.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: their bill is wrong and they want a refund today. Walk me through your first replies." | CASE | [generic] | Clarify before you promise: the account, the amount, what they were told, and what you can do within policy. Acknowledge the problem in one line, then give the next step and when they will hear back. Say which part you would pass to a senior colleague and why. | A live problem from the role, scored on structure and on what you clarify first. It makes no claim about your past. |
| A2 | "The fix we sent last week didn't work, and the customer is now asking for a manager. What do you do?" | CASE | [generic] | Check what changed since the fix and what the customer has already tried. Do not argue about whose fault it is. Decide what you can resolve, and escalate with a summary the next person can act on, so the customer does not repeat themselves. | Tests the escalation handling the ad names, as a decision. No past claim. |
| A3 | "Forty tickets in an hour are about the same login error after a release. How do you handle that?" | CASE | [generic] | Confirm the scope and what customers are seeing. Send one status message rather than forty replies. Group the tickets, pass a few clear examples to engineering, and keep a record of who has been told what. | Tests written communication at volume and escalation together. A pattern for the problem, not a fact about your work. |
| A4 | "Tell me about a time you escalated a case, and what you put in the handover." | JD | [grounded] "I trained four new starters on our refunds process last year" (your message), as the nearest sentence your material carries | Pick a case you handed on. If you have never escalated one, say so plainly, then give the nearest thing your material carries: the refunds process, and what you taught the four new starters about it. Do not describe a handover you did not write. | An open prompt about F4. The material has no escalation sentence, so the honest branch is part of the answer. |
| A5 | "Which of those would you escalate straight away, and which would you handle yourself?" | CASE | [generic] | Name your triggers: a refund outside your authority, a bug you cannot reproduce, a customer at risk of leaving over an unresolved issue. Say how you would tell the next person what you have already tried. | Scores judgement under the escalation requirement. No claim about you. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why would you be good at supporting our product?" | JD | [grounded] "I've never worked for a software company" (your message) | Say it plainly: "I've never worked for a software company." Then point to what your material does show, in its own terms: "answering around 60 calls and emails a day." Let the interviewer judge what carries over. Then say how you would learn the product in your first weeks, as a plan. Hold through two follow-ups: do not claim product knowledge, and concede that the learning curve is real. | **Highest-ROI prep in this pack.** It is the most predictable objection, and your own sentence confirms it. |
| B2 | "You've used Freshdesk. We use Zendesk. How quickly could you work in it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say the tool you use: "I use Freshdesk every day." Do not claim Zendesk. Give your plan for learning the views, macros and tags in your first week. Answer slot: if you have used Zendesk, say when and how, in your own words; if you have not, say so and give the plan. | The ad says Zendesk or similar. Freshdesk meets the "similar" part, so this tests whether you overclaim. |
| B3 | "Most of our contact is written. How do you show clear writing to a customer you can't hear?" | JD | [grounded] "answering around 60 calls and emails a day" (your message) | The sentence gives volume, not quality. Answer slot: if you have had feedback or a quality check on your written replies, say what it said; if you have not, say so, and point to how you have written in this chat. | F3's presentation gap, rehearsed so the honest answer is ready before the probe. |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | Name the product and its tooling as the weakest part, in your own words. Then give your ramp plan: the first week reading tickets and macros, shadowing escalations, and asking who to hand a case to. | A persona stem for the Skeptic. Calibrated candour beats bluffing. |
| B5 | "I don't see escalation work in your background. How would you handle one?" | JD | [grounded] "confidence handling escalations" (the ad, as you summarised it) | Answer slot: if you have handled an escalation, say what you did, in your own words. If you have not, say so plainly, then describe how you would handle one: confirm the facts, record what has been tried, and hand over a summary. | F4. The question presupposes only the ad's requirement, not any past event. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you dealt with a customer who was unhappy with the outcome." | VAL | [grounded] "answering around 60 calls and emails a day" (your message) | Pick one call or email from that volume where the answer was no, or not what the customer wanted. Say what you said, what you offered instead, and how it ended. If none stands out, say so, then give the nearest thing your material carries. | An open prompt. The volume is the context the interviewer will expect you to draw on. |
| D2 | "Tell me about a time a policy stopped you giving the customer what they asked for." | VAL | [grounded] "I trained four new starters on our refunds process last year" (your message) | Pick a refund request the process did not allow. Say what the rule was, how you explained it, and what you offered in its place. If the process never blocked a request you handled, say so plainly. | An open prompt. The refunds sentence is the nearest one your material carries. |
| D3 | "Tell me about a time you helped someone new get up to speed." | VAL | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say what the training covered, in your own words, and how you checked they had it. Do not claim how they did afterwards unless you saw it. | The sentence gives the teaching, not its results. No outcome is supplied. |
| D4 | "What does good customer support look like to you?" | VAL | [generic] | Answer from one call or email you handled, not from a slogan: what the customer needed, what they had to do next, and how you knew they understood. | A values-style opener. It needs no claim about your past. |
| D5 | "Tell me about a time you disagreed with a decision made above you." | VAL | [generic] | Pick a time you pushed back on a decision or policy. Say what you raised, how it was received, and what you did next. If you have never disagreed upward, say so plainly and describe how you would raise a concern. | A selection scaffold ending in an honest branch. Your material has no sentence to map to it. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your last few years." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message) | Your 90-second arc in four beats, each one quoted: the role and years, the volume, the tool, and the refunds training. Do not add a promotion or result the sentences do not carry. | A warm opener, scored as a summary of your CV. |
| C2 | "What have you been doing to get ready for us?" | VAL | [generic] | Say what you have actually done, in your own words. If the honest answer is the ad and this chat, say that. | Casual register, still scored. The answer is what you did. |
| C3 | "What are you actually using in Freshdesk these days?" | JD | [grounded] "I use Freshdesk every day" (your message) | Name the parts of Freshdesk you use day to day, in your words. Answer slot: say which features you use and which you have not used. If you only use the basics, say so. | Tests whether your Freshdesk answer is specific and honest. |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| 2+ years in customer support | F1; C1 | Covered by the CV sentence |
| Zendesk or a similar ticketing tool | B2; C3; F2 | Freshdesk meets "similar"; Zendesk is the probe |
| Clear written communication | B3; A3 | This chat is also a sample |
| Confidence handling escalations | A2; A4; A5; B5; D2 | No escalation sentence in your material |
| Software context (likely probe, not in the ad) | B1; B4 | Your own negative sentence |

## Reverse questions

1. **"What does a new starter's first month look like, and what do they ship in it?"** Why it lands: it is the ramp question you need answered, and it shows you are already planning your start.
2. **"How do escalations move from the front line to the team lead, and what does a good handover look like?"** Why it lands: it tests the escalation process the ad names, and gives you the handover format to use in A4.
3. **"Which tools does the team use day to day: the ticketing tool, macros, internal notes?"** Why it lands: it shows you are set up for B2, and tells you what setup you would face.
4. **"What does a strong first 90 days look like for someone in this role?"** Why it lands: it gives you the bar you will be judged against.
5. **"Is there a call or video stage after this chat, or is this the only round?"** Why it lands: it sets how much to prepare for the next step.

## Sources

- Provided: your message (background, the ad's requirements as you summarised them), and the invite text you pasted.
- Research tier: L1. Searches 0 of 6 (both refused by the host), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet (not built). Query "Lumenvale Software company careers" was refused |
| 2. Lumenvale Software interview process | unavailable | Loop structure and persona weights. Query "Lumenvale Software recruitment Telegram scam job offer" was refused |
| 3. Lumenvale strategy / recent news | skipped | Company-strategy questions; none of the banks needs them for this round |
| 4. Interviewer name | n/a | No interviewer name given; Marcus Hale is from the talent team |
| 5. Representative JD | unavailable | A full JD would ground the four requirements. Search refused; full text not supplied |

Nothing about Lumenvale was checked online. Verifying the company is your step, using its own website or careers page.

## Upgrade menu

- The full job ad text → the four requirement rows quote the ad's own words, and the coverage table checks every requirement against it
- Whether the team lead is your direct manager → persona weights recomputed for a manager or a peer
- Any further rounds → a mini-pack per round
- The Freshdesk features you use → sharper answers in C3 and B2
- A later run with search available → company values, interview process and recent context
- `tuesday-dossier.md` → verified evidence limits and prohibited-claim guardrails for later sessions
