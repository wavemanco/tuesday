# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)
**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Built from:** the advert, Hannah's LinkedIn message, and your message. First version.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether what you did holds up under questions.
- **JD**: role-driven. Tests the advert's own requirements and terms.
- **VAL**, **CO**, **CASE**: not in this screen. No values round, company-strategy question or live case is indicated, and no company research ran (see Sources).

Guidance is scaffolding, not a script. Where guidance is in quotation marks, those are your words from your own message, and you can say them as they are.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. A stated claim with nothing inspected behind it, so expect it to be checked. Say it in those words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning, warehouse or QA work. The adjacency is this pack's derivation from deliveries. Say the deliveries in your words. Answer slot: if you coordinated any handoff between planning, the warehouse or QA, say which and how, in your own words; if you did not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. Your sentence reaches both parts of the requirement. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap. The figure is a headline claim and will be probed (see D1). |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [grounded] | presentation | Your sentence reaches the requirement through a spreadsheet you rebuilt. It says nothing about your level in Excel, so the words stay with the spreadsheet: "I rebuilt our stock-count spreadsheet." |
| F6 | "weekly report on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show a regular performance report. Answer slot: if you have produced a regular report, say what it covered and how often; if you have not, say so plainly. |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message | none | [grounded] | capability | You stated the absence, so the words are yours: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Your message also describes "our own in-house stock system"; the pack does not say you used it. |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your own stated figure, within the advertised band. Say the figure you gave, and nothing added. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Location and schedule are gate terms. Your own stated constraint shows this met, so the row routes by its evidence: two days is fine, no more than three. |

Notice period is not a requirement in the advert, so it has no row. It is handled as a logistics slot (A5).

## Prohibited claims

Not coached in any cell of this pack, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling across planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says deliveries, not production. |
| Owned stock accuracy or the stock records | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |
| Managed the three depots | Inflated form of F2 | "I schedule deliveries for our three depots." |
| Used SAP, or SAP-experienced | Negative you stated (F7) | "I haven't used SAP." A plain acknowledgment. |
| Confident or expert in Excel | Inflated form of F5 | The spreadsheet sentence at its own scope. |

## Question banks

Provenance comes first in each row. Every sentence a row's guidance rests on is quoted in that row.

### Conversational / Rapport (weight: top; seven rows, including the four logistics topics Hannah named)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" — your message; "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | A 90-second arc in your own words: where you work, how long, what you schedule, what you chase. Stop there. Add nothing about the wider business. | Opener. Built on F1 and F3. |
| A2 | "What does a normal week look like in your current job?" | EXP | [grounded] "I schedule deliveries for our three depots" — your message; "chase suppliers when orders slip" — your message | Describe the scheduling and the chasing in those terms. Keep the week to what you did. | F3 is the strongest match to the requirement's tracking and chasing lines. |
| A3 | "What did you use to build that stock-count spreadsheet, and how comfortable are you in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | Say what the rebuild did, in those words. Answer slot: if you can describe your level in the tool, say which functions you used, in your own words; if you use it at a basic level, say so. | F5 is presentation-only, so the Excel answer has to come from you. |
| A4 | "What are you looking for in salary?" | JD | [grounded] "I'm hoping for £42,000" — your message; the advert's band "£38,000–£44,000" | State the figure you gave: £42,000. Do not add a range, a floor, flexibility or a reason. If asked about current or past pay, decline or redirect to the advertised band, with no figure. | Hannah named salary first. A pay figure you gave raises nothing else. |
| A5 | "What's your notice period?" | JD | [grounded] Hannah's words: "your notice period" — Hannah Lowther's message | Give your actual notice period, in your own words. The pack has no figure for you. | Your notice period is not in the material, so this is an instruction, not a fact. |
| A6 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message; the advert's "Hybrid: two days a week at our Avonmouth site in Bristol" | Say your constraint in your own words: two days is fine, and you would not want more than three. Do not add how you would travel, and do not raise commute details. | F9. Hannah named the hybrid pattern. |
| A7 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | Say it in those words. It has three parts: the office closing, the only offer, and Reading. Do not add a career reason you have not given. | Hannah named the reason for moving. |

### Skeptic (weight: medium; four rows)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role coordinates production schedules between planning, the warehouse and QA. Your background is deliveries. What's the difference from where you sit?" | JD | [grounded] "I schedule deliveries for our three depots" — your message; the advert's "Coordinate production schedules between planning, warehouse and QA" | Highest-ROI prep in this pack. Hold: "I schedule deliveries for our three depots, and that is the nearest thing I've done to this." Hold through two follow-ups by returning to deliveries, never adding production. Answer slot: if you coordinated any handoff between planning, the warehouse or QA, say which and how, in your own words; if you did not, say so plainly and say what you would want to learn first. | F2 is the largest gap in the material and the likeliest objection. |
| S2 | "You haven't used SAP. How would you get up to speed on it?" | JD | [grounded] "Never used SAP" — your message | "I haven't used SAP." Then say how you would learn it, as a plan. Answer slot: if you used the in-house stock system day to day, say what you did in it, in your own words. | F7 is a capability gap you stated. The plan is a plan, never a past. |
| S3 | "The role reports weekly on on-time dispatch. Have you produced a regular report like that?" | JD | [grounded] the advert: "weekly on-time dispatch report" | Answer slot: if you have produced a regular report, say what it covered and how often; if not, say so plainly, and say what you would need to track it. | F6 is discovery: the material is silent. |
| S4 | "What appeals to you about working in diagnostic-test manufacturing?" | JD | [grounded] the advert: "diagnostic-test manufacturer" | Answer slot: if you have a reason for moving into manufacturing, say it in your own words; if the appeal is the work itself, say that. | Motivation question raised by the advert. The pack supplies no motive. |

### Pressure / Stress (weight: low; two rows)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Some applicants will have SAP and production backgrounds. Sixty seconds: why you?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" — your message; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | Pause, then restate the question. Hold: four years coordinating deliveries and chasing suppliers, and the spreadsheet with its figure. Concede specifically through the second follow-up: "I haven't used SAP." Do not claim production experience to answer the comparison. | Hold-then-concede on the SAP and production gaps. |
| P2 | "You're looking because your office is closing. Would you have started looking anyway?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | Hold the stated reason through two follow-ups by returning to the office closing and the Reading offer. If pressed on what you would have done otherwise, say what you know, and say plainly what you don't know. | Tests whether the reason holds. Concede uncertainty, never the core reason. |

### Data-Driven Prober (weight: low-medium; three rows)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the one-third drop in discrepancies counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" — your message | Name what was counted, the assumption you would defend least, and which part was yours. Answer slot: if you did this, say how, in your own words; if the count was not yours to set, say so plainly and say what it counted, to the extent you know. | F4's headline figure. The figure raises these slots; nothing else does. |
| D2 | "Which of those deliveries were yours to schedule?" | EXP | [grounded] "I schedule deliveries for our three depots" — your message | Say which scheduling decisions you made and which were set elsewhere, in your own words. | Attribution. Tests the same sentence as S1 from the other side. |
| D3 | "How often did orders slip, and how many suppliers did you chase?" | EXP | [grounded] "chase suppliers when orders slip" — your message | Give the number if you know it. If you do not track it, say so plainly. The pack supplies no figure. | Denominators are where a prober goes next. |

### Persona table

| Persona | How it shows up in this screen | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, with pay, notice, hybrid and reason asked casually | High, top weight. Recruiter screens are friendly in register and still scored | 90-second arc for A1. Treat each logistics question as scored |
| Skeptic | Gaps raised as neutral questions: production, SAP, the dispatch report | Medium, weight 3. The advert asks for things the material does not show | S1 as the highest-ROI rehearsal |
| Pressure / Stress | Challenges the reason for moving, or the comparison with other applicants | Low to medium, weight 2 | Hold-then-concede in P1 and P2 |
| Data-Driven Prober | Asks how the one-third figure was counted, and what was yours | Low to medium, weight 3 | Answer slots in D1 to D3 |
| Values / Behavioral | Not indicated for a recruiter screen | None: no values round is detected | No rows |
| Case / Strategist | Not indicated for a recruiter screen | None | No rows |

## Reverse questions

Each one has a "why it lands."

1. **"What does the first month look like for someone in this role?"** Why it lands: shows you are planning for the job, not just the offer.
2. **"How do planning, the warehouse and QA usually pass work to each other?"** Why it lands: tests the production line from the inside, and shows you have read the advert closely.
3. **"Is SAP expected from day one, or is experience with another stock system enough?"** Why it lands: pins down what "SAP or similar" means in practice.
4. **"Who reads the weekly on-time dispatch report, and what do they do with it?"** Why it lands: asks what the report is for, which is what a coordinator needs to know.
5. **"What happens after this call, and how long does each step usually take?"** Why it lands: Hannah said she would cover next steps; this gets the timing as well.
6. **"Which days are the Avonmouth days for most of the team?"** Why it lands: a practical question about the hybrid pattern, with no commute detail.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | F1, A1, P1 |
| Coordinate production schedules between planning, the warehouse and QA | F2, S1, D2 |
| Track supplier deliveries and chase late orders | F3, A2, D3 |
| Keep stock records accurate | F4, D1 |
| Confident with Excel | F5, A3 |
| Weekly on-time dispatch report | F6, S3 |
| ERP (SAP or similar), a plus | F7, S2 |
| £38,000–£44,000 | F8, A4 |
| Hybrid, two days a week at Avonmouth | F9, A6 |

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message; the advert text; your message.

**Research:** Two searches were sent: "Quillmoor Diagnostics Avonmouth Bristol" and "Quillmoor Diagnostics values". Both were refused, because web search permission was not granted in this session. Nothing from the web is in this pack.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2 (host refused search).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable (search refused) | Would have moved a values cheat sheet, but none is indicated for this screen |
| 2. Quillmoor Diagnostics interview process | unavailable (search refused) | Would have confirmed the loop structure. Hannah's message already gives this screen's topics |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable (search refused) | Would have moved company-strategy questions. None is in this screen |
| 4. Interviewer public footprint | n/a | No interviewer name beyond the recruiter; the screen's content is set by her message |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot |

## Upgrade menu

- Your notice period, in your own words → A5 quotes it instead of asking you to supply it.
- Your level in Excel, and what you used the spreadsheet for → A3 and F5 gain your own words in place of the presentation bridge.
- How the discrepancy figure was counted, in your own words → D1 quotes your method instead of an answer slot.
- Hannah's prep email, if she sends one → any topics beyond the four she named, and any test or pre-declared task.
- A pasted careers or values page → a values section if a later round is values-based.
- The hiring manager's name, for the next round → personas and reverse questions for that round.
- Web search permission → company values, interview process and strategy, which the L1 targets above would cover.
- `tuesday-dossier.md` → would carry the production, SAP and dispatch-report gaps this prep exposed into later rounds.
