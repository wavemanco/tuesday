# Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District): Panel Interview Prep Pack

Session: 45-minute panel on Thursday. Principal Dolores Vantongeren plus two fourth-grade team members (names not given).
Built from: the invitation and your resume points. No job posting, no company research (research tier L0). Company values and current reading-program language are not in this pack.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the job's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse it out loud until you can say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Valid Illinois Professional Educator License with elementary endorsement (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met on your resume. Have the license ready to show; the panel can check it. |
| F2 | Fourth Grade Teacher position (invitation title) | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan, never as a past. |
| F3 | Fourth Grade Teacher position, through adjacent work (invitation title) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Says the grade level and the years, not fourth-grade content. Keep it at that scope. |
| F4 | Leading or working on a grade-level team [generic] | "I've never been a team lead" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't been a team lead." |
| F5 | Leading change within a grade team [generic] | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Shows you led the move. It does not show you chose the curriculum or led the team. Keep to the move. |
| F6 | Measuring reading progress [generic] | "I led our grade level's move to a new reading curriculum in 2024" — your CV | low | [inferred] | discovery | The quote shows a move, not whether results were measured. Answer slot: if you tracked how students did under the new curriculum, say what you looked at; if you did not, say so and say how you would check. |
| F7 | Communicating with families [generic] | "I write a weekly email to families" — your CV | medium | [grounded] | none | Covered in your own terms. |
| F8 | Reading support beyond class time [generic] | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Covered in your own terms. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade or knows its content from practice | Negative you stated (F2) | "I haven't taught fourth grade." Then F3 at its own scope. |
| Has led a team | Negative you stated (F4) | "I haven't been a team lead." |
| Chose the reading curriculum | Inflated form of F5 | F5 at its own scope. The pack's observation: your material says you led the move, not that you selected the curriculum. |
| Reading results improved because of your work | Inflated form of F6 | The pack's observation: your material does not show results. F6's answer slot stays with what you measured, if anything. |

## Persona weights

Panel: the principal's relationship prior is hiring manager (Case/Strategist and Skeptic). Each team member's prior is peer (Peer Evaluator and Data-Driven Prober). No interviewer profiles were provided, so no interviewer-signal adjustments were made.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | "You've never taught fourth grade." Probes motivation and the team-lead gap. | High: F2 and F4 are the invitation's obvious questions | Plain acknowledgment, then your own bridge, then a plan. Hold the position through two follow-ups. |
| Case/Strategist | A live reading problem for a fourth grader. | High: the principal is a hiring manager | Clarify, then structure, then first steps, then how you would know it is working. |
| Peer Evaluator | Team fit, how you would plan with colleagues. | Medium-high | Describe what you did, in your words. Ask what the team needs from you. |
| Data-Driven Prober | Asks what you measured. | Medium | Name what you tracked, if anything. Say plainly when you did not track it. |
| Conversational | A warm opener about your path. | Medium | Pre-scripted 90-second arc from your own sentences. |

## Question banks

Coverage: the invitation's license requirement is in F1. Fourth-grade content: A1, A2, B1. Team: A3, B2, C2. Reading: B1, B2, D1, D2. Family communication: C1. Reading club: C3, E1.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month with our class?" | JD | [grounded] "I've never taught fourth grade" — your message; [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Start with the plain acknowledgment: "I haven't taught fourth grade." Then bridge with your six years of third grade. Then the plan: how you would learn the fourth-grade content and the team's routines, in your own words. Do not claim knowledge of the standards. | F2 is the largest gap and the likeliest probe. This is the highest-ROI rehearsal in the pack. |
| A2 | "Why fourth grade, after six years in third?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: give your reason for moving up a grade in your own words. If the reason is the team or the school's reading program, say it only if it is yours. | A motivation probe that follows F2 and F3. |
| A3 | "You've never been a team lead. Why should we expect you to lead anything here?" | JD | [grounded] "I've never been a team lead" — your message; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment: "I haven't been a team lead." Then describe what you did lead, at its scope: the move to the new reading curriculum. Do not claim team leadership. | F4 and F5. Keep the bridge to the move. |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student in your class is about two grade levels behind in reading in October. Walk us through what you would do." | CASE | [generic] | Structure it: what you would check first, the first two weeks, who you would involve, and how you would know it is working. Make no claim about past students. | A live problem from the reading remit (F6). It needs no claim about your history. |
| B2 | "How do you work with a reading curriculum you did not choose?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Describe what you did for the move, in your words. Answer slot: if you chose the curriculum, say so and why; if the district or team chose it, say so plainly and describe your part. | F5. The premise is not yours to set. |
| B3 | "Why Halvering, and what do you know about our school?" | CO | [generic] | Name one specific thing you found on the school's own website or in its materials. Research has not been run, so this is your homework to do. | A company-knowledge question with no research behind this pack. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What does communication with families look like in your classroom?" | JD | [grounded] "I write a weekly email to families" — your CV | Describe the weekly email: what it covers and how it is sent, in your own words. Do not add content you did not give. | F7 is covered; the guidance is a concrete example. |
| C2 | "Tell us about a disagreement with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: pick a time you and a colleague saw a lesson differently; say what each of you wanted and how it was settled. If none comes to mind, say so plainly, then give the nearest thing you did. | Peer-team fit. An open prompt, so it presupposes no event. |
| C3 | "Tell us about a time you took on responsibility without a formal role." | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Describe the club in your words: who it serves and how you planned it. Answer slot: if the club's structure was yours to set, say how; if the school set it, say so and describe your part. | F8 carries the story. It also covers the reading-club gap. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What, if anything, did you measure after the 2024 reading change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you tracked a measure, name it and what it was sensitive to. If you did not track one, say so plainly and say what you would track now. Never describe a measure you did not use. | F6. The question's "if anything" keeps the premise open. |
| D2 | "What does the reading club keep track of, if anything?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer slot: name what you record, if anything; if you record nothing, say so. | Probes what you can defend. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about your path to teaching." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years" — your CV | A 90-second arc: Joliet, six years of third grade, the 2024 reading move, the reading club, the weekly family email. Use only those facts. | An opener that is still scored. |

## Reverse questions

1. "What does a strong first year look like for someone joining the fourth-grade team?" Why it lands: it shows you plan for the gap in F2.
2. "How does the grade team plan together week to week?" Why it lands: it tests your team-lead gap (F4) without claiming anything.
3. "What has changed in the team's reading approach this year?" Why it lands: it shows you are ready to join a system in use, not start one.
4. "What would make this hire feel right to you six months in?" Why it lands: it asks the principal's own standard.
5. "What could a new teammate do in the first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel.

## Upgrade menu

- The full job posting → the fourth-grade requirements become [grounded] rows, and the team-lead and reading requirements get sourced questions
- Names or roles of the two team members → personas assigned per member
- The school's website or the district's values → company knowledge in B3, and values language
- Any focus areas or deliverables from HR → coverage of those in the bank
