# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Interviewer: the support team lead (name not given; relationship to you not yet known). Recruiter: Marcus Hale, talent team.
Built on your message only. No CV, full job ad or interviewer profile was supplied, and web search was refused, so company material below is labelled `[generic]`.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = can you do the listed job, gaps included. **EXP** = what you actually did in your past work. **CASE** = a live problem from the role. **CO** = company knowledge. **VAL** = behaviour and values.
- Guidance is scaffolding, not a script. Say it in your own words. Anything in quotation marks is taken from your message, the job ad as you summarised it, or the invite.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Your material gives three years as a customer service advisor. The ad says "customer support", so keep the title as you wrote it. Expect a probe on whether the contacts were support work; say what they were, in your words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a ticketing tool and the ad accepts a similar one, so the requirement is reached in role terms. Zendesk does not appear in your material, so say Freshdesk and do not say Zendesk. Answer slot: if you have used another ticketing tool, say which; if not, say so plainly. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is shown; clarity is not. The material does not show how well you write. Answer slot: name one written reply you would defend as clear and what made it clear; if you have none to hand, say so and describe how you check a reply before sending it. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Refund training is adjacent work: it shows you know the process, not that you took escalations. Say what the training covered, in those words. Answer slot: if you handled a case beyond your own authority, say what you did and who you passed it to; if you did not, say so plainly. |
| F5 | Software-company experience (not in the ad; a likely probe because the employer is a software company) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked for a software company." Then the bridge is only the support work your quotes carry, in those words. No software claim is added. |

Routing note: F1 and F2 are `none` because a quote already reaches the requirement in role terms. F3 is `discovery` because the material is silent on clarity. F4 is `transferability` because the refund training is real adjacent work that does not show escalation handling. F5 is `capability` because you stated the absence.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no Zendesk, no software company, no stated escalation case | High. The team lead is the hiring side and F2, F4 and F5 are where that side presses | Say the gap plainly, then bridge only from quotes you have. Rehearse A4 until it is routine |
| Case / Strategist | Live support problems: a late refund, an out-of-authority case | Medium. A support team lead often tests judgement this way | Clarify the situation, then structure the response, then name the next step with a time |
| Data-Driven Prober | Asks how "around 60" was counted and what share was yours | Medium. A round number invites a counting question | Name the figure as yours, and say which part you are least sure of |
| Pressure | Time-boxed, challenges how much was really yours | Low. Nothing in the material suggests a stress-style panel, but a chat can still be quick-fire | Pause, restate the question, hold a challenged position through two follow-ups |
| Conversational | Casual openers, "walk me through the journey" | Medium. A chat interview is informal; casual questions are still scored | Use a 90-second arc built from your own quoted sentences |
| Values / Behavioral | Stories of a customer no, a mistake, a rule you did not agree with | Low. No values-style round is detected; behaviour questions still tend to come up | Pick a real case, say what you did, say how it ended; if none fits, say so |

Weights: Skeptic highest (5 questions), Case and Prober mid (3 each), Conversational, Pressure and Values low (2 or 3). Every persona is touched.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2: your material names Freshdesk, and Zendesk never appears | "I use Freshdesk every day", at its own scope. Limit, said in analysis: your material shows Freshdesk, not Zendesk |
| Designed or owned the refunds process | Inflated form of F4: "trained four new starters on" stretched to "designed" | "I trained four new starters on our refunds process last year". Limit, said in analysis: your material says you trained others on it, not that you set it |
| Exactly 60 calls and emails a day | Inflated form: "around 60" hardened into an exact figure | "answering around 60 calls and emails a day", in your own words |
| Has worked for a software company | A negative you stated, F5 | Plain acknowledgment: "I've never worked for a software company." |

## Question banks

Question IDs are letters by persona. Question types are single tokens; the primary type is listed.

### A. Skeptic (weight highest; A4 is the highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for 2+ years in customer support. Walk me through the support work you have done." | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day" | Say the length and the role in those words, then the contact volume in its own words, then one contact you handled from start to finish. Keep to what you did | F1 is the requirement's only quote; JD because it scores the stated requirement |
| A2 | "Tell me about a case that went beyond what you could resolve yourself. What did you do?" | JD | [grounded] "confidence handling escalations" (job ad, as you summarised it) | Open prompt: pick a case you could not close on your own. Say who you passed it to, what you told the customer and how it ended. Answer slot: if no case went beyond your authority, say so plainly, then describe the nearest case from your refunds work | F4 is the probe; the requirement is the JD's own line |
| A3 | "You use Freshdesk. Our ticketing tool is Zendesk. How would you get up to speed?" | JD | [grounded] "I use Freshdesk every day"; "experience with Zendesk or a similar ticketing tool" | Say what you do in Freshdesk daily, in those words. Say how you would learn Zendesk, as a plan and not as a past. Answer slot: if you have used Zendesk or another ticketing tool beyond Freshdesk, say which and what you did in it; if not, say so plainly | F2; the question asks about the future and presupposes nothing about your past |
| A4 | "Why should a software company hire someone with no software background?" | EXP | [grounded] "I've never worked for a software company" | Say it first, plainly: "I've never worked for a software company." Then the bridge is only what your quotes carry: the three years and the daily Freshdesk use. Hold through two follow-ups by returning to the support work. Concede only what you have not done, not what you have. Rehearse three levels deep | F5 is the single most predictable objection, because the employer is a software company; deepest rehearsal here |
| A5 | "Why are you leaving the energy supplier?" | EXP | [generic] | Answer slot: give your actual reason, in your own words, and keep it about the work. Your material gives no reason, so none is supplied here | A motivation probe every skeptic asks; [generic] because no claim is made about your past |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer's refund is three weeks late and they say they will file a chargeback. Write your reply." | CASE | [generic] | Structure: acknowledge, check the facts, give one next step with a time, say what happens if it slips. Say it aloud, then write it in under 120 words. The problem asserts nothing about your past | F3's written probe as a live problem; [generic] because it is a pattern for the problem |
| B2 | "The customer's case is outside your authority. What do you do in the next ten minutes?" | CASE | [grounded] "confidence handling escalations" (job ad, as you summarised it) | Clarify who owns the decision, tell the customer what happens next and when, and write down what you know so no one asks again | F4 and the escalation requirement; CASE because it tests the sequence |
| B3 | "A new starter joins next week. What would you show them first on refunds?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped: the beats are the ones the sentence states, four new starters, the refunds process, last year. Answer slot: if you chose what to cover, say how you decided; if the training was set by someone else, say so and what you did within it | F4's transferability quote, delivered as a live problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around 60" in your words. Name the weakest assumption in the figure, in your words. Answer slot: if the figure came from a count or a report, say which; if it was your estimate, say so plainly | A defend-the-number probe on the one figure you gave |
| C2 | "Of those contacts, what kinds of contact took most of your time?" | EXP | [grounded] "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year" | Answer slot: if you know the mix, give it in your own words; if you do not, say you do not know how it divided and describe what you can | Asks what the material does not show, so it presupposes no refund share |
| C3 | "What do you do in Freshdesk day to day, and is there anything in it you set up yourself?" | EXP | [grounded] "I use Freshdesk every day" | Describe your daily use in those words. Answer slot: if you set up views, macros or settings, say which; if not, say so plainly | F2's probe on the tool you do have |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone with Zendesk experience?" | JD | [grounded] "experience with Zendesk or a similar ticketing tool"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | Pause, restate the question in your own words, then answer only from those three quotes. Hold through two follow-ups. Concede precisely: "I've never worked for a software company" is the only concession you need | Pressure on F2 and F5 under a time box |
| D2 | "That sixty a day: how much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold: you were the one answering them, in those words. Concede exactly what is uncertain, which is the count and not the work. Answer slot: if some of the volume was someone else's, say what share was yours | An attribution probe on the volume figure |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So walk me through the journey. How did you end up in support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I trained four new starters on our refunds process last year" | 90-second arc in this order: the energy supplier, the three years, the refunds training. Your words | Biography questions are scored casually; the arc uses only quoted sentences |
| E2 | "What part of support work do you enjoy most?" | JD | [generic] | Answer slot: give your own answer. Your material does not say, so none is supplied | Chat interviewers score interest; [generic] because no claim is made about you |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to tell a customer no." | VAL | [generic] | Selection scaffold: pick a time you declined something a customer asked for; say what you said and how it ended. If none comes to mind, say so plainly, then give the nearest refund conversation your material carries, or how you would handle one | Behavioural stem; no values round is detected, so [generic] |
| G2 | "Tell me about a mistake you made on a customer case." | VAL | [generic] | Selection scaffold: pick a case where something went wrong; say what you noticed, what you did and what changed afterwards. If none comes to mind, say so plainly, then give the nearest case you have, or how you would handle one | Scored for honesty about your own part |
| G3 | "Tell me about a time you explained a rule you did not agree with." | VAL | [generic] | Selection scaffold: pick a rule you had to explain that was hard to explain well; say what you said and what happened. If none comes to mind, say so plainly, then give the nearest case you have | Support work often means explaining policy; [generic] |

Session total: 18 questions. Depth follows persona weight.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | A1 |
| Experience with Zendesk or a similar ticketing tool | A3, C3, D1 |
| Clear written communication | B1 (the live written reply) |
| Confidence handling escalations | A2, B2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week look like in this role: how many contacts, across which channels?" | Shows you are asking about the work, not just the title, and lets you compare it with your own volume |
| "Which tools would I work in day to day, and how much of the week is in Zendesk?" | Shows you have read the tool requirement and want to know the gap before you start |
| "Who decides on refunds that go beyond agent authority, and how is the case handed over?" | Shows you have thought about escalations and want the process, not a promise |
| "Is there a call or video stage after this chat, and when would I hear about next steps?" | A process question with a prep reason: it tells you how much to prepare |
| "What does the first month of onboarding look like, and who would I shadow?" | Shows you are planning for the job and the way the team trains |

## Sources

- Provided documents: your message (the invite, the job ad as you summarised it, your background). No CV, full job ad, or interviewer profile was supplied.
- Search calls sent: "Lumenvale Software company careers" (aimed at target 1); "Lumenvale Software customer support specialist interview process" (aimed at target 2). Both refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet (section 10): not built, since no company values were established. Both searches refused |
| 2. `{company} interview process {role family}` | unavailable | Loop structure: no loop source was established, so persona weights rest on the hiring-manager prior, not a documented loop. Search refused |
| 3. `{company} strategy` / recent news | unavailable | The CO bank: no CO questions were written. Search refused in this session |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given; the team lead is unnamed |
| 5. representative `{role title}` JD | unavailable | Your summary of the ad fixes the four requirements; a full ad would upgrade them to exact quotes. Search refused |

## Upgrade menu

- The full job ad text → the four requirement rows quote the ad's own wording, and any requirement missing from your summary gets its own row.
- Your CV → evidence cells can quote a CV line; today every quote comes from your message.
- The team lead's name and role, and whether they would manage you → persona weights built from the team-lead prior, plus an interviewer read.
- Whether this chat is the only stage → how much of the pack to prepare for a second round.
- Permission to run web search → the company values, interview process and recent news targets, which would replace the `[generic]` labels in the reverse questions and the values section.
- Any Zendesk use, and any escalation case you handled → A2, A3 and B2 move from answer slots to grounded stories.
- A tuesday-dossier.md from a previous session → its verified evidence and prohibited claims, if you have one.
