# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work, what is prompting the move, then the team and next steps.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = role requirement; **EXP** = your experience, tested for attribution; **CASE** = live problem; **VAL** = values (not triggered here); **CO** = company knowledge (not triggered here).
- Guidance is scaffolding, not a script. Say things in your own words.

## Prep triage

1. Know your four logistics answers cold: pay, notice, hybrid, reason for moving. These are most of the call.
2. Rehearse the SAP answer. It is the one place you are behind the advert.
3. Rehearse the one-third figure: how it was counted and what part was yours.
4. Everything else is insurance.

## Fit snapshot

Requirements come from the advert you supplied. Evidence is quoted from your message; nothing else is inserted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say it in those words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across depots, not production schedules. Say the delivery work in those words. Answer slot: if you have had any part in production or planning schedules, say what it was; if not, say so and say what you would learn first. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Use your words: you chase suppliers when orders slip. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | No gap, but this is a headline figure, so it gets defend-the-number questions (see C1). |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material shows you built a spreadsheet, not your Excel level. Answer slot: say what you built and which features you used in it; if you are unsure how you would rate yourself, say that. |
| F6 | "report weekly on on-time dispatch" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on delivery or dispatch performance, say what you reported and how often; if not, say so and say how you would build the report. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, said as a plan and never as a past. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met on your own stated constraint. Your own words only. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your target sits inside the advertised band. Your own words only. |
| F10 | Notice period (not in the advert; a term the recruiter will ask about) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. The one question in this pack asks for it (see the questions below). |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Familiar with SAP, or has used an ERP | Negative you stated, F7 | "I haven't used SAP." No slot. |
| Owns stock accuracy across the business | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not show that you owned stock accuracy as a function. |
| Ran production scheduling | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." |
| Reported weekly on dispatch | Silence, not a claim; listed here so no cell asserts it | No cell asserts it; F6's answer slot covers it. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly screen, logistics in order | Top weight. A recruiter screen is mostly logistics asked casually. | Give your four logistics answers in your own words. Treat casual questions about the role as scored. |
| Skeptic (light) | "Why this role, and where is the gap?" | Mid weight. The SAP and production gaps are the obvious probes. | Say the gap in one sentence, then stay with what you did. |
| Data-Driven Prober | "How was the figure counted?" | Mid weight. The one-third figure is the only number on your CV, and recruiters do ask. | Say how it was counted if you know. If you don't, say so. |
| Pressure | Time-boxed challenge on the SAP gap | Low weight for a screen. | Hold your position through two follow-ups, then concede exactly what is true. |

## Question banks

### A. Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Open with those four years, then the depot scheduling and supplier chasing from F2 and F3. Keep it to 90 seconds. | F1 and F3 are the opening; EXP because it tests what you actually did. |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give your own figure in your own words: "I'm hoping for £42,000." Do not add a range or a floor, and do not explain why that number. | F9 fills this logistics slot. No figure is supplied beyond yours. |
| A3 | "What is your notice period?" | JD | [grounded] (no notice period was stated) | Give your actual notice period. Whatever it is, say it plainly. | F10 is a hard gate your material does not establish. Asked of you in this conversation (see questions below). |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say those words. Nothing more is needed. | F8 fills this logistics slot; your constraint is stated and met. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say that in those words and stop there. It is a true reason and needs no embellishment. | The reason-for-leaving logistics slot. |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "SAP is listed as a plus. What's your experience with it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, as a plan. | F7 is the most predictable objection to your CV. Rehearse it until it is plain. |
| B2 | "This role is production scheduling. Where is that in your background?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name the depot and supplier work in those words. Answer slot: if you have had any part in production or planning schedules, say what; if not, say so and say what you would learn first. | F2, the highest-ROI rehearsal in this pack for a screen. It is the one most likely to be raised. |
| B3 | "What have you done with Excel beyond spreadsheets?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say what you built in those words. Answer slot: if you can name the functions or features you used, name them; if you cannot rate your level, say so. | F5, a discovery gap. |
| B4 | "Have you reported on dispatch performance before?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you have reported on delivery or dispatch performance, say what you reported and how often; if not, say so and say how you would build the weekly report. | F6, a discovery gap. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the one-third drop in discrepancies counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say how it was counted if you know. Name, in your own words, the assumption behind it you would defend least. Say which part was yours. If you do not know how it was counted, say so plainly. | F4 is a headline figure. The defend-the-number slots apply. |
| C2 | "Walk me through the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Premised on your quote only. Describe what you rebuilt, in those words. | F4 and F5 together. |
| C3 | "When an order slips, what do you do first?" | JD | [grounded] "chase suppliers when orders slip" | In your own words, describe the first step you took when an order slipped. | F3, a probe on the chasing. |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why should we consider you over someone who has run SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold: "I haven't used SAP. What I bring is the depot scheduling and the stock-count work I've already described." Concede only what is true, and say how you would close the gap. | Hold-then-concede on the one gap you have stated. |

## Coverage line

| JD requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | C3 |
| Keep stock records accurate | C1, C2 |
| Report weekly on on-time dispatch | B4 |
| Confident with Excel | B3 |
| ERP (SAP or similar) a plus | B1, D1 |
| £38,000–£44,000 | A2 |
| Hybrid: two days at Avonmouth | A4 |

## Reverse questions

Ask these at the end, in your own words. Each one is a useful answer to get.

1. **What are the next steps after this call, and who would I meet?** Why it lands: she has said she will cover the team and next steps, so this gives you the shape of the loop.
2. **Which days does the Avonmouth site usually expect people in?** Why it lands: confirms your two-day fit against the real pattern.
3. **What does a typical week look like across planning, the warehouse and QA?** Why it lands: tests the production-scheduling gap from the other side.
4. **Which ERP does the team use day to day?** Why it lands: shows you read the SAP line and want to know what the system actually is.
5. **How is on-time dispatch measured and reported today?** Why it lands: shows you understood the weekly report requirement.

## Sources

Provided documents: the advert and your message, read in full.

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both searches were refused by the host's permission setting.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | No call was sent for this target; a values cheat sheet is not triggered for a recruiter screen. |
| 2. `Quillmoor Diagnostics interview process recruitment` | unavailable | Search sent, refused. Would have moved the loop structure and next-step persona weights. |
| 3. `Quillmoor Diagnostics strategy / recent news` | unavailable | No call was sent. Would have moved the company context only. |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | No call was sent. An interviewer read is absent; this is a recruiter, so the read would be thin. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions. |

Searches sent: `Quillmoor Diagnostics Avonmouth Bristol` — refused. `Quillmoor Diagnostics interview process recruitment` — refused.

## Upgrade menu

- A notice period → the logistics row A3 and F10 become answerable without a hard gate.
- The hiring manager's name → a tailored reverse question and persona weights from their public footprint.
- Permission for web search → the values, process and strategy rows above, which would make the loop shape concrete.
- Anything you hear on the call about the team → loop mode, with a mini-pack per round.
- A `tuesday-dossier.md` → verified evidence for the SAP and Excel rows (F5, F7) from earlier sessions.
