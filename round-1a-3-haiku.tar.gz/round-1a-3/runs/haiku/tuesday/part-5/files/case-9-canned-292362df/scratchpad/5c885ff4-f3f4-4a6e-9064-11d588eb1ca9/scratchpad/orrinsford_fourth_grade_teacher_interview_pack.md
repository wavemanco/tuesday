# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · 45-minute panel interview · Thursday (date not given in the invite) · Panel: Principal Dolores Vantongeren and two fourth-grade team members (not named)

Changelog: first version.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral / values alignment · **EXP** your past experience, checked for attribution · **JD** the role's listed duties · **CO** the district's current plans · **CASE** a live classroom problem.
- Guidance is scaffolding, not a script. Each guidance cell is written to be said in 90–120 seconds, using only what your quoted sentences say.
- Where a cell says **answer slot**, it is an instruction for the interview: have your honest answer ready for either branch.

## Fit snapshot

Requirements come from three places: the invite (its own words), the district's published pages, and one representative job listing (labelled `[inferred]`, because it is not this district's posting). Evidence is quoted from your CV and your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Gate shown met by your CV, so it asks nothing further. Bring a copy of the license. Words: "My Illinois PEL, elementary endorsement, is registered and active through June 30, 2029." |
| F2 | "Fourth Grade Teacher" — invite title; "plan and teach reading, writing, math, science and social studies" — representative job listing `[inferred]` | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Adjacent grade, not the same one. Words: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if you have taught any of the fourth-grade subjects in a classroom, say which and how; if you have not, say so and say how you would learn the year's content. |
| F3 | "Panels ask about reading instruction." — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | The quotes already reach reading instruction in role terms; reword only them. Words: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if any part of that move was yours to decide, say which and how; if none of it was, say so plainly and describe your part. |
| F4 | "Panels ask about … classroom routines." — district hiring page | none given | none | [grounded] | discovery | No quote covers routines. Answer slot: name a routine you have run in your own classroom, in your own words; if none comes to mind, say so and say what you would observe first. |
| F5 | "each teacher speaks with every family each term" — district mission page; "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | presentation | Reaches families in role terms. Words: "I write a weekly email to families." The quote says weekly email; it does not say every family, so do not say it. Answer slot: if you have also spoken with families one-to-one, say how often and in what setting; if not, say so. |
| F6 | "work with the grade-level team" — representative job listing `[inferred]` | "I've never been a team lead" — your message | none | [grounded] | capability | Stated absence; the invite does not ask for a team lead. Words: "I haven't been a team lead." Then describe how you would work as a team member, as a plan, never as past experience. |
| F7 | "Fourth Grade Teacher" — invite title | "I've never taught fourth grade" — your message | none | [grounded] | capability | Stated absence. Words: "I haven't taught fourth grade." Then how you would learn the grade, as a plan. |

Gap types follow the routing rule: F1 is shown met (none); F2 and F3 have a quote that reaches the requirement in other terms or adjacent terms; F4 has no quote at all (discovery); F6 and F7 are absences you stated (capability).

## Prohibited claims

Not coached in any cell. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led the district's reading curriculum | Inflated form of F3: your quote says your grade level's move | F3's quote at its own scope. Observation in analysis only: the material says a grade-level move, not a district one. |
| Has taught fourth grade or has fourth-grade classroom experience | Negative you stated (F7) | "I haven't taught fourth grade." No slot. |
| Has led a team or a team's work | Negative you stated (F6) | "I haven't been a team lead." No slot. |
| Speaks with every family each term, or has contact with every family | Inflated form of F5: your quote is the weekly email | "I write a weekly email to families." |
| Set reading plans for students, or ran a reading program | Inflated form of F3: your quote is the reading club | "I've run the after-school reading club for the last two years." |

## Persona table

The panel is a blend: each member's top two personas, weighted by what is known. Nothing is known about the two team members, so their weights rest on the panel's published format; the principal's weights rest on her public profile.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Values / Behavioral | Scenario probes tied to the district's three beliefs; reading, routines, families | High. The district's hiring page says panels ask about reading instruction, classroom routines and families, and the principal's published focus is reading. | Map each belief to a quote where one exists; say the rest plainly. | 5 (A) |
| Skeptic | "You've never taught fourth grade," "never been a team lead" | High. Both gaps are in your own message, so they are the first thing a careful panel will test. | Plain acknowledgment, then a plan. Hold the third-grade years; do not stretch them. | 4 (B) |
| Case / Strategist | A live reading or classroom problem tied to the 2027 curriculum | Medium. The district's plan adopts a grades 3–5 reading curriculum from fall 2027. | Clarify, then structure, then act. Name what you would check first. | 3 (C) |
| Peer Evaluator | Collegial questions from the two grade-level teachers about planning and disagreement | Medium. Two team members on the panel. | Reciprocity: what you bring, not only what you need. | 3 (D) |
| Conversational | A warm opener, "walk us through your journey" | Low to medium. Casual openers are still scored. | Keep a 90-second arc built on quotes. | 2 (E) |
| Pressure / Stress | A sixty-second challenge on the missing fourth-grade experience | Low on evidence, but cheap to protect against. | Hold, then concede specifically. | 2 (F) |

Depth follows weight: 5, 4, 3, 2.

## Reading the interviewer

Public professional footprint only (ilprincipalsforum listing, found in search).

- **Career pattern:** nine years as a reading specialist, then principal of Halvering Elementary since 2022.
- **Published talk:** *Small Groups, Big Readers* (2025), on weekly reading conferences in grades 3–5.
- **Implications:** expect reading-centered questions. Lead with reading facts you can quote, and keep claims small.
- **Mirror opportunity:** reading. A shared professional subject is fair game; do not claim any shared path that is not in your material. Your reading club and curriculum move are the honest overlap.
- Team members: no public information; their weights come from the panel format.

## Question banks

Each row's Provenance carries every sentence its guidance rests on.

### A. Values / Behavioral (weight 5, principal-led)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What does reading instruction look like in your classroom?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; [grounded] "I've run the after-school reading club for the last two years" | Lead with the two quoted facts, each in its own words. Do not describe a reading routine the quotes do not name. If you cannot name one, say so and say what you would look at first. | F3 is your strongest quote, and reading is the principal's published focus. |
| A2 | "Our beliefs say no student leaves third grade without a reading plan. What was your part in that?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The six years are the setting. Your part is what you did in them. Answer slot: if you wrote or ran reading plans for students, say what they contained and how you decided; if you did not, say so plainly and describe the nearest thing your third-grade years carried. | Quotes the district's own belief. The premise is theirs, not a fact about you. |
| A3 | "Tell me about a time a family's concern changed how you taught a child." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time a family's question shaped a plan, if one comes to mind. If none does, say so, then describe what the weekly email carries. | F5 is the families quote; the district's belief is "Families Are Partners." |
| A4 | "How do you decide what to reteach after a reading assessment?" | VAL | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." | No claim about your past. Describe how you decide, in your own words. If the 2024 move or the reading club used assessment results, say which and what you did with them; if not, say so. | Tests the district's third belief directly. |
| A5 | "Why do you want to teach fourth grade at Halvering?" | VAL | [grounded] "I've never taught fourth grade"; [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] district news: "a new grades 3–5 reading curriculum from fall 2027" | Give a real reason, tied to the district's published plan. Do not claim fourth-grade experience. Say the third-grade years and the reading work carry over, and that you want to learn the grade. | Ties motivation to the district's current plan without claiming experience. |
| A6 | "What routines keep your classroom running?" | JD | [grounded] district hiring page: "classroom routines" | Answer slot: name a routine you have run in your own classroom, in your own words. If you cannot name one, say so and say what you would observe first. | F4 has no quote, so the answer must come from your own experience or be an honest "not yet." |

### B. Skeptic (weight 4)

Highest-ROI prep in this pack: the fourth-grade gap is the most predictable objection, and B1 is where a rehearsed answer changes the interview.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never taught fourth grade. What would you do in the first month to get the year right?" | JD | [grounded] "I've never taught fourth grade" | Plain acknowledgment: "I haven't taught fourth grade." Then a plan, stated as a plan: ask the team which standards and units the year covers, learn the reading curriculum the team uses, and watch a fourth-grade class in session. Follow-up 1 ("Which standards?"): name the team's own plan, not a list you invent. Follow-up 2 ("Why us over someone who has?"): hold with "For six years I taught third grade at a public elementary school in Joliet" and the reading work; do not claim equivalence. Follow-up 3: concede specifically, "I'd rather learn the grade than pretend I know it." | F7 and F2. The plain acknowledgment has a source: your own words. |
| B2 | "You've never been a team lead. How would you work on a grade-level team?" | JD | [grounded] "I've never been a team lead" | "I haven't been a team lead." Then describe working as a team member, as a plan: what you would bring to shared planning, and what you would ask the team for. | F6. The team-lead question is not in the posting, so answer it as a stated absence, not a gap to explain away. |
| B3 | "Walk me through the 2024 reading curriculum move. What was your part in it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F3: the move, and the year, which are the beats the quote states. Answer slot: if you decided any part of the move, say which and how; if others decided it and you carried it out, say so plainly. | F3's strongest probe. The premise is your own quote. |
| B4 | "What do you do in the after-school reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what you run, in your own words. Answer slot: if you tracked anything about students' reading in the club, say what and how; if you did not, say so. | Club is two years of real work; probes go to what was tracked. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The new grades 3–5 reading curriculum starts in fall 2027. Your class has two readers well below grade level. What do you do this week?" | CASE / CO | [grounded] district news: "a new grades 3–5 reading curriculum from fall 2027" | Clarify first: what you know about the two readers and what you would check. Then a small-group approach, a family note, and what you would measure. Make no claim about past students. | The district's published plan is the raising source for the case. |
| C2 | "A family says the new reading curriculum is too hard for their child. What do you say first?" | CASE | [generic] | Listen first, then what you would check about the child's work, then a short follow-up plan. Do not claim a past case. | A problem pattern, not a fact about you. |
| C3 | "Your published talk covers weekly reading conferences in grades 3 to 5. How would you run them with a fourth-grade class?" | CASE | [grounded] principal's talk listing: "Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5" | Structure: what a conference is for, which student it serves, what you record, and how you choose the next step. Answer slot: if you have run any conference-style reading sessions, say which and how; if not, say so and describe the plan. | Uses the interviewer's own published words, which is a valid raising source. |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We'd plan together every week. What would you need from us, and what would you bring?" | JD | [inferred] representative job listing: "work with the grade-level team"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity: what you bring, in the quote's words, then what you would need. Do not claim a team role you have not held. | Peer panelists weigh what the hire adds to their load. |
| D2 | "Where would you expect a seam between our two classrooms, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claim to know their seam. Selection scaffold for disagreement: pick a time you disagreed with a colleague about a student, if one comes to mind; if none does, say so and describe how you would raise a disagreement. | A collegial probe with no fact about you behind it. |
| D3 | "How do you handle credit when a grade-level plan works?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: name the others who worked on the move, if there were any; if it was yours alone, say so. Do not say more credit than "led" carries. | Peers test credit-sharing. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through your journey into teaching." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years" | A 90-second arc, built only on your quotes: the license, six years in third grade, the reading club, the 2024 move, and why you want fourth grade. | Casual openers are still scored. |
| E2 | "What are you reading with your students these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Name only books you have actually used with students. If you have not used any, say so and name the approach. | A casual reading question is still a reading probe. |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire someone with no fourth-grade experience over a teacher who has it?" | JD | [grounded] "I've never taught fourth grade"; [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Hold: six years of third grade and the reading work are your evidence. Concede: you have not taught fourth grade, and you will not pretend otherwise. Second follow-up: hold the same evidence in the same words. | The hold-then-concede structure on the Skeptic's own gap. |
| F2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you decided any part, say which and how; if you carried out a decision others made, say so plainly. | Tests attribution, which is what the question is for. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1; gate met, no question needed. Bring a copy. |
| Fourth Grade Teacher (invite) | B1, A5, F1 |
| Reading instruction (district hiring page) | A1, B3, C1, C3 |
| Classroom routines (district hiring page) | A6 |
| Working with families (district hiring page); each teacher speaks with every family each term (district mission page) | A3, E1; stated limit at F5 |
| Assessments inform teaching (district mission page) | A4 |
| Work with the grade-level team (representative listing, `[inferred]`) | D1, D2, B2 |
| Plan and teach reading, writing, math, science and social studies (representative listing, `[inferred]`) | A1, E2; writing, math, science and social studies — none, and why: no quote or district source names them, so no question is asked on them. |

## Reverse questions

Each one carries a "why it lands."

1. **To the principal:** "Your reading-specialist years came before this principalship. How does that shape the support you give grade teams?" *Why it lands:* it uses her published path and shows you read her background.
2. **To the panel:** "The grades 3–5 reading curriculum starts in fall 2027. How is the fourth-grade team preparing for it?" *Why it lands:* it uses the district's published plan and shows you have read it.
3. **To the team (reciprocity):** "What could a new fourth-grade teacher do in the first month that would genuinely help the team?" *Why it lands:* peers weigh what the hire adds to their load, and this asks them directly.
4. **To the team:** "How does the team decide which assessments shape the week's reading plan?" *Why it lands:* it asks how the district's belief "assessments inform teaching" works in practice.
5. **To the panel:** "What does a strong first year look like in this role?" *Why it lands:* it turns the close into a conversation about success criteria.
6. **To the team:** "Which of the team's routines would you want a new teacher to keep?" *Why it lands:* it shows you expect to learn the team's way of working, which answers the fourth-grade gap without claiming it.

## Prohibited claims

See the table above (section "Prohibited claims"). No guidance cell asserts any entry.

## Sources

**Provided documents:** your CV and your message (invite and resume, as pasted).

**Research tier:** Research tier: L1 — searches 5 of 6, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford community values | yes | Three beliefs (fetched mission page): Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Feeds A2, A3, A4, the district-belief rows in F5 and the prohibited claims. Values cheat sheet not built: the round was not detected as a values-style round, and the beliefs are used in the banks instead. |
| 2. Orrinsford interview process | yes | Hiring page (search snippet, not fetched): "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel." Sets the panel format and the persona weights. |
| 3. Orrinsford strategy / recent news | yes | Board news, August 2026 (search result): "a three-year literacy plan … a new grades 3–5 reading curriculum from fall 2027". Feeds C1, A5 and the reverse question. |
| 4. Interviewer name | yes | Principal forum listing (search result): "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5." Feeds the interviewer read and C3. |
| 5. Representative fourth-grade JD | yes | K-12 jobs board listing (search result): responsibilities "plan and teach reading, writing, math, science and social studies; differentiate instruction using assessment data; keep clear classroom routines; communicate regularly with families; work with the grade-level team." Labelled `[inferred]`, as typical for the role, not this district's posting. Qualifications were cut off in the snippet and are not quoted. |

Searches sent, with what came back:
1. "Orrinsford Community School District Halvering Elementary School": no results.
2. "Orrinsford Community School District mission values teacher hiring": mission page and hiring page.
3. "Orrinsford Community School District strategic plan priorities": literacy plan news.
4. "fourth grade teacher elementary job description Illinois responsibilities qualifications": jobs board listing.
5. "Dolores Vantongeren principal Halvering Elementary": principal forum listing.

Fetches sent: the mission page (`https://orrinsfordschools.example/about/mission-and-beliefs`), read in full.

No dossier was consumed.

## Upgrade menu

- The posting's full text → replaces the representative listing with `[grounded]` rows and adds JD-tagged questions for any requirement it names that this pack does not cover.
- Any focus areas HR gave, or a pre-declared teaching demo or lesson → adds a graded-deliverable section.
- The two team members' names → assigns personas per member in the interviewer read.
- A copy of your PEL → turns F1 into an inspected artifact and raises its confidence to high.
- What the 2024 curriculum move measured, if anything → turns the F3 answer slot into a grounded answer for B3 and F2.
- A `tuesday-dossier.md` → would add verified evidence and a prohibited-claims list to the next pack.
