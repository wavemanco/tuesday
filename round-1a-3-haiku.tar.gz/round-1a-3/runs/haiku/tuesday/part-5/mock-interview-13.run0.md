Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-13-denied-d665a37d/2ea167f7-a84d-45e7-8340-a1e64aa68fe2/scratchpad/quillmoor_operations-coordinator_interview_pack.md`.

The pack is built from your message, the advert and Hannah's message. Web search was refused in this session, so I could not check Quillmoor's values, interview process or recent news. The pack says so in its Sources section, and it does not claim anything from those sources.

The three things most worth rehearsing:

- **The production-scheduling gap (B1).** The advert asks for production schedules across planning, the warehouse and QA. Your evidence is delivery scheduling across three depots. Answer the gap at that scope, and say plainly if you never set timing that depended on another team.
- **Your pay answer (C1).** Give £42,000 once, in your own words. Don't offer a range or a floor if she pushes.
- **Why you're leaving (B3).** Say the Bristol closure and the Reading offer as you wrote them.

Two smaller points:

- Your stock-count figure ("about a third") will be probed. Know how it was counted, or say you don't know.
- You have never used SAP, and the pack gives you that sentence word for word, followed by a plan for learning it.

Offers, not pushed:
- I can run a drill: I'll play Hannah on the pay and notice questions and push back on your answers.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

I need one thing from you before Thursday: **what is your notice period?** Hannah has said she'll ask, and the pack can't give you a notice answer without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, 30 minutes by phone, Thursday 2pm. She will call the mobile number on the application.
**Her stated agenda:** salary expectations, notice period, hybrid pattern, reasons for moving, then the team and next steps.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored: EXP (your experience), JD (the listed job), CO (company knowledge), VAL (values), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds.

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, then logistics asked as small talk. A recruiter screen is mostly this register. Weighted highest because her stated agenda is a recruiter's, and it is run in a friendly register. | High | Have a 90-second background arc ready. Treat casual questions about the advert's named duties as scored. |
| Skeptic (light) | "Why now, why here?" and the gap between logistics and production work. Weighted from the recruiter-screen prior, which is motivation and knockout checks. | Medium to high | Rehearse the single most likely objection until it is plain. Say the gap once, then the bridge. |
| Pressure | Pushback on the pay figure or on the hybrid days. Mild, since this is a screen. | Medium | Pause, restate, hold the figure you gave. |
| Data-driven prober | Asks how the stock-count figure was counted. Weighted low because it is a screen, not a technical round. | Low to medium | Say how it was counted, or say you do not know. |

Weighting follows the recruiter-screen prior in the persona guide. No interviewer profile exists, so there is no interviewer-signal adjustment. The loop is not documented, so this is a session pack with the generic archetype's tilt, and the pack says so.

## Prep triage

Prep time was not stated, so no schedule is given. The priorities are A1, A3, B1, C1 and the notice-period answer, which you have not yet given.

## Fit snapshot

Advert requirements are the JD's own words. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Your message states it directly: "I've been a logistics coordinator for four years." Expect a probe on dates. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling against planning and QA. Keep the bridge at that scope: "I schedule deliveries for our three depots." Answer slot: if you ever set timing that depended on another team's output, say what it was and which part was yours. If not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Reaches the requirement. "About a third" will be probed. Answer slot: if you can say how the discrepancies were counted, say it in your own words. If you cannot, say so. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you produced any regular report on delivery timing, say what it covered and who received it. If you did not, say so. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [grounded] | discovery | Your message does not say what the spreadsheet was built in. Answer slot: if it was Excel, say so. If it was another tool, name it. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | Words: "I've never used SAP. We ran our own in-house stock system." Then how you would learn an ERP, said as a plan. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your stated figure sits inside the band. Give it in your own words, with nothing added. |
| F9 | "Hybrid: two days a week at our Avonmouth site" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met, as your own stated limit. |
| F10 | Notice period (the recruiter's agenda) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Words: none yet. The notice-period question at the end of this message fills this row. |
| F11 | Reasons for moving (the recruiter's agenda) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own stated reason, in your own words. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned production scheduling across planning, warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." |
| Owned stock accuracy across the company | Inflated form of F4 | The quote's scope: the stock-count spreadsheet you rebuilt. |
| Experience with SAP or any ERP | Negative you stated, F7 | "I've never used SAP." |
| Eliminated stock discrepancies | Inflated form of F4 | "discrepancies fell by about a third over a year." |
| A figure for weekly dispatch reporting | none given, F5 | No claim. Answer slot only. |

## Question banks

### Persona A: Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc in your own words: the wholesaler, the four years, the three depots, the supplier chasing. Stay with these sentences. | F1, F2 and F3 are the opener. |
| A2 | "What does the Excel side look like in your day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say what you built and what it does, in those words. Answer slot: if it was in Excel, say so. If it was another tool, name it. | F6, asked casually. Excel is scored casually too. |
| A3 | "Tell me about the stock-count work. What changed?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The change and the year, in those words. Answer slot: how the discrepancies were counted, in your own words. | F4, your headline figure. |
| A4 | "Have you come across SAP at all?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I've never used SAP. We ran our own in-house stock system." Then your plan for learning an ERP, as a plan. | F7, the advert's ERP plus. |
| A5 | "What's your notice period?" | JD | [grounded] the recruiter's agenda item | Give your actual notice period in one sentence. You have not given it yet, so see the question at the end of this message. | F10, the logistics slot. |

### Persona B: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role is production scheduling across planning, the warehouse and QA. Where does your work meet that?" | JD | [grounded] "I schedule deliveries for our three depots" | Bridge at the quote's scope: "I schedule deliveries for our three depots." Answer slot: if you ever set timing that depended on another team's output, say what it was and which part was yours. If not, say so plainly. This is the highest-ROI prep in the pack. | F2 is the gap a screen is most likely to press. Its probe is the one this skill cannot fill for you. |
| B2 | "You haven't used SAP. How long would it take you to get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I've never used SAP. We ran our own in-house stock system." Then your plan for learning it, as a plan. | F7. |
| B3 | "Why leave now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the closure and the Reading offer in those words. Nothing added. | F11, the logistics slot for reasons for leaving. |

### Persona C: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That figure is near the top of the band. Is it firm?" | JD | [grounded] "I'm hoping for £42,000" | Give your figure in your own words, once. If pressed, say you would like to hear the band first, or hold the figure you gave. Do not offer a range, a floor or a counter. | F8, the pay logistics slot. |
| C2 | "Two days in Avonmouth. Would three be a problem?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth is fine, but I wouldn't want more than three." Hold it. | F9, the hybrid logistics slot. |

### Persona D: Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was that discrepancy figure counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Say how it was counted, in your own words. Name the assumption you would defend least. If you do not know how it was counted, say so. | F4 defend-the-number slot. |
| D2 | "What dispatch figures do you track?" | JD | none given | Answer slot: if you produced any regular report on delivery timing, say what it covered and who received it. If you did not, say so. | F5, the advert's weekly on-time dispatch line. |

## Requirement coverage

| Advert requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules across planning, warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | A3, D1 |
| Weekly report on on-time dispatch | D2 (answer slot only; no sourced material) |
| Confident with Excel | A2 |
| ERP (SAP or similar) a plus | A4, B2 |
| £38,000–£44,000 | C1 |
| Hybrid, two days at Avonmouth | C2 |

## Reverse questions

1. "Who sets the week-to-week production schedule, and how does it reach the warehouse?" Why it lands: it shows you read the advert's planning-to-warehouse line.
2. "What on-time dispatch figure does the team report now?" Why it lands: it names the advert's weekly report and asks for the number.
3. "What does the two-day Avonmouth pattern look like in a normal week?" Why it lands: it confirms the constraint you actually set, in practical terms.
4. "Which teams would this role work with most closely, and what would the first priority be?" Why it lands: it moves the call toward the team, which she has said comes after logistics.
5. "What are the next steps after this call, and when?" Why it lands: it closes the call on process, which she has already offered to cover.

## Sources

Research tier: L1, searches 2 of 6, fetches 0 of 2. Both calls were refused because web search permission was not granted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have set the values cheat sheet. Two searches were sent, "Quillmoor Diagnostics values" and "Quillmoor Diagnostics interview process operations coordinator", both refused, and the first was aimed here. No values page was read, so none is cited. |
| 2. Quillmoor Diagnostics interview process, operations | unavailable | Would have named the loop and set the persona weights. The same refused search covered this target. The loop is unknown, so the weights are the recruiter-screen prior. |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable | No call sent. Would have moved the CO questions; none are in this pack. |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | No call sent. Would have added her public footprint, which for a talent partner is usually thin. Nothing is established about her beyond her title. |
| 5. Representative operations coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions. |

Provided documents: your message, the recruiter's message, and the advert as pasted.

## Upgrade menu

- Your notice period → fills row F10 and the notice logistics slot (A5). Until then, the pack's notice answer is unknown.
- Whether you have ever produced a weekly dispatch or on-time report → moves F5 from discovery to a stated answer.
- The Excel tool you used for the stock-count spreadsheet → moves F6 from low to medium confidence.
- Web search permission → would run targets 1 to 4 and could add a values cheat sheet, if a values page or documented values round exists.
- Recruiter's prep email, if she sends one → coverage of any pre-declared deliverable.
- `tuesday-dossier.md` from a previous session, if you have one → verified evidence and known objections for this pack.
