Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-13-denied-546fc5c7/66db73e4-df4e-401a-bea6-6d4c7aed7e61/scratchpad/quillmoor_operations-coordinator_interview_pack.md. I built it for a recruiter screen with Hannah, from the advert and your message. I didn't run any web searches, so the pack contains nothing about Quillmoor beyond the advert.

The most important thing to rehearse is B2: the advert asks for production scheduling across planning, the warehouse and QA, and your material only covers deliveries across three depots. Say the word and I'll play the Skeptic on B2.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Three things I need from you, since you asked me not to guess them:

- What's your notice period?
- What's your current salary? The pack doesn't use it, but I can add a line for declining the question if she asks.
- Have you ever reported on delivery performance, such as on-time dispatch? If so, what did you count?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm, to your mobile
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Covers, per her message:** salary expectations, notice period, how the hybrid pattern works, what is prompting the move; then the team and next steps (her part)

## How to use this pack

- **Personas** are how the question arrives. **Types** are what is being scored:
  - **JD**: the advert's own requirements
  - **EXP**: what you actually did, and how you attribute it
  - **CASE**: a live problem (none in this screen)
  - **VAL**: published values (none detected)
  - **CO**: company knowledge (none researched)
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Closed. Say the years and the title in those words. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | Closed. The quote already uses the advert's terms: deliveries and chasing late supplier orders. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says deliveries across three depots. It does not say production schedules, planning or QA, so the bridge stops at deliveries. Answer slot: if you have coordinated with a planning or QA step, say which and how; if you have not, say so plainly and stay with deliveries. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | Reword only the quote: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." It adds no practice or figure. The one-third figure raises a defend-the-number question (C1). |
| F5 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] derived from the spreadsheet line | discovery | Your material says a spreadsheet. It does not say Excel, or at what level, so do not claim a level. Answer slot: name the spreadsheet tools you used, in your own words. |
| F6 | "ERP (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never used SAP." Then how you would learn it, as a plan, never as a past. Name your in-house stock system as what you have run. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any delivery-performance reporting. Answer slot: if you have reported on delivery performance, say what you counted; if you have not, say so plainly and say what you would measure first. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your stated figure. Say it once in your own words. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own limit: two days is fine, three is the most you would want. |

## Prohibited claims

These are not coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F3 | "I schedule deliveries for our three depots." The pack's own observation: the material says deliveries, not production schedules. |
| Experience with SAP or another ERP | Negative you stated (F6) | "I've never used SAP." |
| Excel expert, or advanced Excel | Inflated form of F5 | "I rebuilt our stock-count spreadsheet." |
| You cut discrepancies by a third | Inflated form of F4 (attribution) | "Discrepancies fell by about a third over a year." Say in your own words what was yours. |

## Persona table

| Persona | How it shows up in this screen | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Opens with your background, then runs the logistics checklist in a friendly register | Highest. A recruiter screen is mostly logistics and motivation, asked casually. Weight 5 | Keep a 90-second background arc. Treat the casual pay and notice questions as scored |
| Skeptic | Probes the gaps: no production or QA work, no SAP, no reporting, and "why leave, why now" | High. The advert names gaps your material does not cover. Weight 4 | Rehearse the production/QA gap until it is plain. Answer SAP with the plain acknowledgment and a plan |
| Data-Driven Prober | Asks how the one-third discrepancy drop was counted | Medium. One headline figure on your message. Weight 3 | Say what you counted and what you would defend least. Say plainly what you do not know |
| Pressure / Stress | Pushes back on pay, or asks you to justify the number | Low for a recruiter screen. Weight 2 | Restate your figure once and hold it. Redirect with a question about the band |

Depth follows weight. The total sits below the usual range because a 30-minute screen cannot rehearse more.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Open prompt. Beats: the years and title, then the three depots and supplier chasing, then the spreadsheet rebuild. About 90 seconds. Say it in your own words. | Opening question. Tests whether you can tell your story briefly. Covers F1 and F2 |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot. Say your figure in your own words: "I'm hoping for £42,000." Then stop and let her respond. Do not mention your current pay | Pay is a knockout term. Your figure sits inside the advert's band (F8). Raises no other question |
| A3 | "What's your notice period?" | JD | [generic] standard recruiter question; no stated notice in your material | Logistics slot. Give your actual notice period in your own words. Do not estimate it | Notice is a standard knockout. Your material does not say it yet (see the closing question) |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot. Say it in those words: two days is fine from north Bristol, and three is the most you would want. If she offers a third day, your limit is three | Hybrid is a gate term. Your own limit is the answer (F9) |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot. Give the reason in those words. Add no further reasons. If asked about Reading, the same words again | The reason for leaving is scored for consistency. Your reason is the closing office, not the role |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role lists SAP as a plus. What's your experience with it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I've never used SAP." Then say what you run now, by name, and how you would learn SAP, as a plan. Never claim SAP experience | F6. This is a stated gap, so the acknowledgment is exact |
| B2 | "This role coordinates production schedules across planning, the warehouse and QA. Your background is deliveries across depots. What's the closest you've come?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Highest-ROI rehearsal in this pack. Hold on the quote: deliveries across three depots, and chasing late supplier orders. Answer slot: if you have coordinated with a planning or QA step, say which and how; if you have not, say so plainly and stay with deliveries. Hold through a follow-up by returning to deliveries | F3, the most likely objection. The advert's production and QA mandate is the largest gap in your material |
| B3 | "Why this role, when your background is in wholesale?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Answer slot: say what in the advert you want to do, in your own words. If the main reason is the closing office, say so plainly and do not invent a pull toward manufacturing | Motivation check. Your material has no stated interest in this role yet |
| B4 | "The role reports weekly on on-time dispatch. Have you done that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you have reported on delivery performance, say what you counted and over what period; if you have not, say so plainly and say what you would measure first | F7. Your material shows no reporting, so the honest answer is the one you have |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you counted, over what period, and the assumption you would defend least. Answer slot: if you did this, say how, in your own words; if the drop had another cause, or it was not yours alone, say so plainly and return to the spreadsheet rebuild | The one-third figure is a headline claim. Defend it precisely |
| C2 | "What does 'confident with Excel' mean in your work?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Name the spreadsheet and what you did in it, in those words. Do not claim a level. Answer slot: name the tools you used in it, and if none beyond the rebuild, say so | F5. Confidence is low, so the claim is the spreadsheet only |
| C3 | "How do you know when a supplier order has slipped?" | JD | [grounded] "chase suppliers when orders slip" | Say what you look at and when you chase, in your own words. Answer slot: if there is a routine you use, name it; if you go by memory, say so | F2 probe. Tests the process behind the chasing |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The band is £38,000 to £44,000. Would you take £38,000?" | JD | [grounded] "I'm hoping for £42,000." | Restate your figure once, in those words: "I'm hoping for £42,000." If pressed again, ask what the band is for the role. No range, floor or counter-offer | Pressure on pay. Hold your figure and redirect to the role's band |
| D2 | "You've been there four years. Why now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the reason in those words. Do not add reasons under pressure | Tests whether the reason survives a second and third follow-up |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | B2 (F3 gap) |
| Track supplier deliveries and chase late orders | A1, C3 |
| Keep stock records accurate | C1 |
| Report weekly on on-time dispatch | B4 (F7 gap) |
| Confident with Excel | C2 (F5 gap) |
| ERP (SAP or similar) a plus | B1 (F6 gap) |
| £38,000–£44,000 | A2, D1 |
| Hybrid, two days a week at Avonmouth | A4 |

## Reverse questions

Ask these when she opens for your questions. Her agenda covers the team and next steps first.

1. "What does a typical week look like for whoever holds this role, especially around the handoffs between planning, the warehouse and QA?" Why it lands: it shows you read the advert as a real job, not a list.
2. "How is on-time dispatch measured now, and who receives the weekly report?" Why it lands: it asks about the reporting gap directly and shows you are ready to own it.
3. "Which two days are usually in the office at Avonmouth?" Why it lands: it makes the hybrid pattern concrete before the next stage.
4. "What's the team's biggest supplier-delivery problem at the moment?" Why it lands: it shows you care about the work, not only the terms.
5. "What happens between this call and a next step, and roughly when?" Why it lands: it sets the timeline in one question.

## Prohibited list note

Entries in the prohibited table are not coached. The pack does not claim production, QA, SAP, Excel expertise, sole credit for the discrepancy drop, or reporting on dispatch. Where the advert raises one of these, the answer is the honest slot or the plain acknowledgment above.

## Sources

- Provided documents: the advert text; your message with your background and reason for moving; Hannah Lowther's LinkedIn message.
- Research tier: L0. No searches or fetches were run. The screen's questions come from the advert and your own material.

| Target | Status | What it moved, or would have |
|---|---|---|
| Company values (Quillmoor) | unavailable | A values cheat sheet, only if the round were values-style (not detected). Would not change the logistics banks |
| Interview process for this role family | unavailable | Loop structure. A recruiter screen is the first round here, so the banks already match it |
| Company strategy and recent news | unavailable | Something to say when she asks what you know about Quillmoor. See the upgrade menu |
| Interviewer public footprint | n/a | Name given, but a recruiter's public footprint would not change the banks |
| Representative JD | skipped | The advert fixes the fit snapshot and JD questions |

## Upgrade menu

- Your notice period → A3 gets your own figure, in your own words, in place of the instruction
- Your current salary → nothing in the pack uses it. If she asks what you earn now, a redirect line can be added to A2, with no figure
- Your reporting record on delivery performance → B4 gets your own words
- A company search at the default research tier → something to say when she asks what you know about Quillmoor
- A `tuesday-dossier.md` from an earlier session would add any gaps already recorded for this role
