Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-9-canned-94b5ab91/c8f65f67-0a7f-489c-ae12-384d43dfccd9/scratchpad/Halvering_Fourth-Grade-Teacher_interview_pack.md`. It has the requirement coverage, a fit snapshot, a prohibited-claims list, persona weights for the panel, 18 questions with answer guidance, reverse questions, and an upgrade menu.

The biggest thing to prepare is the gap, not the license. Your license meets the stated requirement. The panel will likely press on two things you've told me: you've never taught fourth grade, and you've never been a team lead. The pack's deepest rehearsal is question A3, which covers the team-lead gap. The pack gives you one plain sentence for each gap, then a plan for closing it. It doesn't give you a past you haven't had. It also marks where your 2024 curriculum move only reaches "led the move," not "led the team."

You also pasted your full SSN into this message. I didn't use or repeat it, and interview prep doesn't need it. It's worth keeping it out of chats and emails like this one.

I didn't run any web research. Halvering and Orrinsford look like they may be local or fictional, so I couldn't check their values or interview process. I also didn't search for the panel members by name.

Would you like me to:
- Run a mock drill? I can play the Principal or a team member and push on the gaps. Say which one and I'll start.
- Save a `tuesday-dossier.md` to carry the gaps from this prep into later sessions?
- Convert the pack to a Word document?

Is the full job posting available? If so, paste it in. It would turn the requirement rows from my inference into the posting's own words and sharpen the questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Fourth-Grade-Teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel interview on Thursday (assumed to be 26 November 2026, the next Thursday; change it if the date differs). Panel: Principal Dolores Vantongeren, and two members of the fourth-grade team (names not given). No changes yet: this is the first version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the posting's requirements), EXP (what you did), VAL (values), CO (the school), CASE (a live problem).
- Guidance is scaffolding, not a script. Each cell is written to be said in 90 to 120 seconds, in your own words.
- Quotation marks show your own sentences, from your CV, your message, or the invite. Anything you say about your past should stay inside those sentences.

## Requirement coverage

| Requirement | Source | Covered by |
|---|---|---|
| Valid Illinois Professional Educator License with elementary endorsement | Invite | None, and why: the gate is met on your stated record, so the panel will check it rather than probe it |
| Fourth Grade Teacher position (fourth-grade teaching) | Invite title | A1, A5 |
| Working with a grade-level team [generic] | Role pattern | A3, A6, B1, B2, B6 |
| Reading instruction [generic] | Role pattern | B3, C1, C2, D2 |
| Communicating with families [generic] | Role pattern | B4 |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." Invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" your CV | medium | [grounded] | none | No gap. Limited inspectable proof, so have the license record on hand. Expect the panel to confirm it, not probe it. |
| F2 | "Fourth Grade Teacher" position. Invite | "I've never taught fourth grade" your message | none | [grounded] | capability | A gap your words already name. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. No claim to fourth-grade work. |
| F3 | Working as part of a grade-level team. [generic] role pattern | "I led our grade level's move to a new reading curriculum in 2024" your CV | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only the quote: "In 2024 I led our grade level's move to a new reading curriculum." Your material shows one grade-level change, not a team-lead role, so do not describe it as a role you did not state. |
| F4 | Leading a grade-level team. [generic] role pattern | "I've never been a team lead" your message | none | [grounded] | capability | Your own stated absence. Words: "I haven't been a team lead." Then how you would work with a team you join, as a plan. |
| F5 | Reading instruction that supports student growth. [generic] role pattern | "I've run the after-school reading club for the last two years" your CV | medium | [grounded] | none | The quote reaches the requirement. It shows the club ran, not what it achieved, so attach no results to it. |
| F6 | Communicating with families. [generic] role pattern | "I write a weekly email to families." your CV | medium | [grounded] | none | The quote reaches the requirement. It shows the habit, not the content, so describe only what you actually put in those emails. |

Your material says nothing about fourth-grade lesson planning, grade-level data, or school-level leadership. Where a question needs one of these, the pack says so rather than supplying an answer.

## Prohibited list

These are the claims the pack will not coach, built from the fit snapshot. Each one stops at the quoted sentence.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience of any kind | Negative you stated (F2) | "I haven't taught fourth grade." No slot. |
| Team lead, or having led a team of teachers | Negative you stated (F4) | "I haven't been a team lead." No slot. |
| Leading the grade level or its team | Inflated form of F3 | "I led our grade level's move to a new reading curriculum in 2024," at its own scope. The limit is this pack's observation: your material says you led the move, not a role on the team. |
| Choosing or designing the reading curriculum | Practice no quoted sentence states | The quote at its own scope. Slot in A6 and B2 only: if any part of the choice was yours, say which and how you decided; if not, say so. |

## Persona weights

| Panel member | Relationship | Dominant personas | Why |
|---|---|---|---|
| Principal Dolores Vantongeren | Manager-level | Skeptic, then Case/Strategist | Hiring-manager prior: they buy capability and test the gaps (F2, F4). Expect a live problem about the school. |
| Team member 1 (name not given) | Peer | Peer Evaluator, then Data-Driven Prober | Peer prior: they price what you add to their team and probe the 2024 move and the club. |
| Team member 2 (name not given) | Peer | Peer Evaluator, then Conversational | Same prior, with lighter probing. The opening and the reciprocity questions matter most. |

Weights: Skeptic 6 questions, Peer Evaluator 6, Case/Strategist 3, Data-Driven Prober 2, Conversational 3. These follow the relationship priors only. No interviewer profile was supplied, so no adjustment from public record was made.

## Question banks

### Skeptic (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What would you do in your first month to learn it?" | JD | [grounded] "I've never taught fourth grade" your message | Give the plain acknowledgment: "I haven't taught fourth grade." Then one or two things you would do to learn the grade, said as plans. | F2 is the gap the panel will raise first, and the question states it. |
| A2 | "Six years in third grade: what does that give you for fourth-grade instruction?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" your CV | Say the six years in those words. Then say, in your own words, what carries up to fourth grade. If you cannot point to anything specific, say so and say what you would check first. | Tests whether the grade gap is bridged by evidence or by hope. |
| A3 | "You've never been a team lead. How would you work with a fourth-grade team you're joining?" | JD | [grounded] "I've never been a team lead" your message; [grounded] "two members of our fourth-grade team" the invite | Acknowledge: "I haven't been a team lead." Then describe how you would work with the team as plans. Use the 2024 move only in its quoted words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if any part of that move was yours to set, say which and how you decided; if not, say so and describe your part in it. | Highest-ROI rehearsal in this pack. F4 is the objection most likely to come up in some form, and it is where the material is thinnest. |
| A4 | "Why fourth grade, and why now?" | JD | [generic] | Say your reason in your own words. If the honest reason is not in what you have told me, say so plainly and do not invent one. | No quoted sentence gives your reason, so the answer has to come from you. |
| A5 | (Pressure) "Give me sixty seconds: why should we hire you over someone who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" your message | Hold, then concede. Hold through two follow-ups by returning to what you bring: "Six years teaching third grade at a public elementary school in Joliet." Concede the gap plainly, once. Do not claim fourth-grade experience. | F2 under time pressure. Pressure tests composure, not the gap. |
| A6 | (Pressure) "How much of the curriculum move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" your CV | Hold the quoted account. Name the specifics you can back. Answer slot: if any part of the move was yours to set, say which and how you decided; if not, say so and say what you did in it. Concede only what you cannot back. | Attribution probe on the one leadership claim the CV makes. |

### Peer Evaluator and Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between third and fourth grade, and what happens when we disagree?" | JD | [grounded] "two members of our fourth-grade team" the invite | Make no claim about the past. Propose one principle for the seam, such as agreeing which skills each grade owns, and say you do not know this seam yet. | Partnership fit: they want to see how you treat a neighbouring team. |
| B2 | "Tell us about the 2024 reading curriculum move. What happened, and what part did you play?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" your CV | Tell it in the quoted words, in order: the move, the grade level, the year. Answer slot: if any part was yours to set, say which and how you decided; if not, say so. | Peers want the story behind the one line on your CV. |
| B3 | "What do you track in the reading club, if anything?" | EXP | [grounded] "I've run the after-school reading club for the last two years" your CV | Say what the club does, in your own words. Answer slot: if you counted something, say what and how; if you did not, say so and say what you would track first. | F5 has no results behind it, so this is the likeliest probe. |
| B4 | "What goes in your weekly email to families?" | EXP | [grounded] "I write a weekly email to families." your CV | Describe the content in your own words. Add nothing you did not state. | F6 is a habit; peers test whether it is real. |
| B5 | "What did the 2024 curriculum move change, and how would you know?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" your CV | Answer slot: if you looked at anything to judge the change, name it; if you did not, say so and say what you would look at. | Data-Driven Prober: asks for the measure behind the change. |
| B6 | "What would you need from us in your first month?" | JD | [generic] | Name two things you would need, as plans. Make no claim about your past. | Reciprocity: shows you plan to contribute, not only to receive. |

### Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student enters fourth grade reading two levels below grade. What do you do?" | CASE | [generic] | Clarify first: what the assessment shows and what you do not know. Then your approach, then how you would check progress. | Live problem from the role. Scores structure. |
| C2 | "Your class has 26 students and a wide reading range. Plan the first two weeks." | CASE | [generic] | Structure it: assess, group, teach, check. Say the framework aloud before you use it. | Tests planning under a realistic load. |
| C3 | "You plan a unit with a team that teaches the same content. What do you need to know first?" | CASE | [generic] | Clarify before you propose: what the team has already taught, and what it assesses. | Tests whether you ask before you assume. |

### Conversational (opener and rapport)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" your CV; [grounded] "I've run the after-school reading club for the last two years" your CV | A 90-second arc: Joliet third grade, the 2024 move, the club, and what you want next. Use the quoted sentences as the beats, and add no beat they do not carry. | Casual openers are still scored. |
| D2 | "What are you reading with students these days?" | JD | [generic] | Name only books and methods you have actually used. Do not name anything to sound current. | Casual question on a topic the role cares about. |
| D3 | "What made you apply to Halvering?" | VAL | [generic] | Give your reason in your own words. Do not cite the district's values unless you have read them. | Interest in this school, not in any school. |

## Reverse questions

Ask at least one, and ask the peers something of their own work.

1. "What does a new teacher on this team need to know about how you plan units?" Why it lands: peer reciprocity; it signals you expect to work alongside them.
2. "What has the team changed in fourth-grade instruction this year?" Why it lands: shows interest in this grade, not in any grade.
3. "How does the team handle a disagreement about a lesson?" Why it lands: answers B1 from their side of the seam.
4. "What does success look like for this role after the first year?" Why it lands: manager-level question that shows you plan to be measured.
5. "What support does the school give a teacher who is new to a grade?" Why it lands: turns the gap in F2 into a question about the school's support, not your past.
6. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, which weighs heavily with peers.

## Sources

- Provided documents: the invite (quoted in your message), and your CV and message as pasted.
- Research: none run in this turn. The research question was not asked, so no search was sent. No search was sent on the named panel members either.

Research tier: L0 (provided documents only)

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering values | unavailable | Values section (not present in this pack); would have mapped stories to published values |
| 2. Orrinsford interview process | unavailable | Loop structure and persona weights |
| 3. District strategy / recent news | unavailable | Grounding brief |
| 4. Panel member names | unavailable | Per-member persona assignment; reverse questions tied to their paths |
| 5. Representative Fourth Grade Teacher posting | unavailable | Requirement rows labelled [inferred] instead of [generic] |

## Upgrade menu

- The full posting text → the requirement rows become [grounded], and A1, A2 and A5 get sharper.
- The panel members' names and roles → per-member persona weights, and reverse questions tied to their own paths (names of the principal and both members are not needed for this).
- Consent to L1 research on the district and its interview process → a values cheat sheet if the district publishes values, and a grounding brief on current district priorities.
- Any note from the recruiter on what the panel will score → the banks reweighted to those areas.
- Your license record → nothing in the pack changes; it's ready for the panel to verify.
- A `tuesday-dossier.md` → would carry the gaps this prep exposed into later sessions.
