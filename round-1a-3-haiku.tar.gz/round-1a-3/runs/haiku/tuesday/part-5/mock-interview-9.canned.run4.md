Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-5-rooms-case-9-canned-992bd36a/ea06f3bd-a271-4f2c-b2c6-b57f3151f8bb/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. It's built from your invite and your CV text, with no job posting, so the requirements rest on the invite alone.

The invite doesn't ask for your Social Security number, and it isn't needed for this stage. I haven't repeated it, and I'd keep it off the résumé and any application or interview materials.

The question the panel is most likely to press is the fourth-grade gap. The pack's highest-value prep is A3, "What is the biggest risk in hiring someone who has never taught fourth grade?" It's built to hold your position briefly, then concede the specific thing: a year of fourth-grade knowledge you don't have yet.

Two things I could not establish from the material:
- The pack quotes the district's three beliefs from a search snippet, not the full page. Check their wording on the district site before you quote them.
- I didn't search for a representative posting for this title. A copy of the posting would firm up the requirements.

Want a live drill? I can play the principal on A3 and give feedback against that question's guidance. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to a Word document when you're ready.

Is Principal Vantongeren your direct supervisor, or is the hiring decision made by someone else? And did HR say whether the panel includes a demonstration lesson or a written task?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Round: 45-minute panel on Thursday with Principal Dolores Vantongeren and two fourth-grade team members. Built from your invite and your CV text, with no job posting supplied. Relationship to the panel members is partly unknown (see the closing questions).

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored: **EXP** (your experience), **JD** (the role's requirements), **VAL** (values and teamwork), **CASE** (a live problem), **CO** (company knowledge, none in this pack).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, and only what you actually did.
- Answer slots are instructions for the interview, not questions to answer here. Each one gives you both honest branches.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Your material meets this gate. Confidence is medium because nobody has inspected the license yet. Bring the registration to the interview or the application. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Your material says third grade, and you have said you have not taught fourth. Say the third-grade years in the quote's words: "For six years I taught third grade." Answer slot: if you have looked at what fourth-grade students are expected to do, say what you looked at, in your own words; if you have not, say so and say what you would do first. |
| F3 | "Every Child a Reader: no student leaves third grade without a reading plan." (district Mission and Beliefs page, search snippet) | "I've run the after-school reading club for the last two years" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | Your material shows a club and a curriculum move. It does not show reading plans or reading outcomes. Say the club and the move in the quote's words, and add no result. |
| F4 | "Families Are Partners: each teacher speaks with every family each term." (district Mission and Beliefs page, search snippet) | "I write a weekly email to families" (your CV) | medium | [grounded] | transferability | Your material shows written contact every week. The district's line names speaking with every family each term, which the email does not show. Say the weekly email in those words. Answer slot: if you have spoken with families in person or by phone, say how often, in your own words; if the email is your main contact, say so. |
| F5 | Working on a grade-level team (role-family pattern; the panel includes two team members, but no posting states it) | "I've never taught fourth grade and I've never been a team lead" (your message) | none | [grounded] | capability | Words you have stated: "I've never been a team lead." Then the curriculum move (F3), described at its own scope. Team leadership is a plan, not a past: say how you would learn it. |

Analysis, not words for you: nothing in your material shows reading outcomes, a chosen curriculum, or a team leadership role. The rows above say only what your sentences say.

## Interviewer read

**Principal Dolores Vantongeren** (public footprint only):
- Principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- A 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.

Implications:
1. Expect specific reading-instruction questions. Small-group reading is the theme of her public work, so B3 covers it.
2. Shared jump: her path from reading specialist to principal, and your reading club. Your side of it is "I've run the after-school reading club for the last two years" (F3, your CV). Reverse question 2 uses this.
3. Her background makes vague reading claims easy to test. Stay at the level of what you ran.

The two team members: no public profile was given, so no read is offered for them.

## Persona table

Panel rule: blend the top two personas of each member's relationship. The principal is treated as a hiring manager (Case/Strategist and Skeptic). The team members are peers (Peer Evaluator and Data-Driven Prober).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal), weight 5 | Probes the fourth-grade gap and the team-lead gap; asks why this candidate over a fourth-grade teacher | Highest. The posting's headline requirement is fourth-grade teaching, and the gap is in your own sentence | Rehearse the plain acknowledgment, the third-grade bridge and the plan. Hold, then concede the specific thing (see A3, F1) |
| Case/Strategist (principal), weight 3 | A live reading problem for a fourth-grade student; a small-group plan | High. Hiring managers buy capability and test it live | Clarify first, then structure. Name the method only as a method |
| Peer Evaluator (team members), weight 3 | Seams between classrooms; disagreement; credit | Medium. Peers price what the hire does to their work | Propose principles for the seam. Ask them where it is |
| Data-Driven Prober (team members), weight 3 | Asks how the club and the curriculum move were checked | Medium. Your strongest reading evidence is a club, and probers ask for denominators | Say what you ran and what you saw. Name the assumption you would defend least, or say you did not measure |
| Conversational, weight 2 | The journey question; why Halvering | Medium. Casual openers are still scored | A 90-second arc in your own words |
| Pressure, weight 2 | Sixty-second challenges; "how much was actually you" | Low to medium. Nothing in the invite signals a pressure style | Pause, restate, hold through two follow-ups |
| Values/Behavioral, not weighted | No values-style round is detected: the invite names one panel session, and no loop source documents a values round. The district's published beliefs still raise A4 and B2 | Low | Use the district's own words only as a named source |

Weights: depth follows persona weight. Total 18 questions.

## Question banks

### A. Skeptic (principal), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade and never fourth. What would your first month with a fourth-grade class look like?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Start with the plain acknowledgment: "I've never taught fourth grade." Then the third-grade years in the quote's words, and a plan for the first month: what you would read, who you would ask, what you would check first. Answer slot: if you have already looked at fourth-grade expectations, say what you looked at, in your own words; if not, say so and say how you would find out. | F2 is the likeliest probe. The premise is the stated absence, so the question is fair. JD because it scores the position itself. |
| A2 | "You led a grade-level curriculum move without being a team lead. What did leading that move involve, and whose decisions were they?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Describe the move in the quote's words. Plain acknowledgment: "I've never been a team lead." Answer slot: if you chose the curriculum or set its rollout steps, say which and how you decided; if those decisions were made above you, say so and describe what you led. | F5 and F3 meet here. The interviewer will test whether "led" meant decided. The honest branch, that the decisions were not yours, is a complete answer. |
| A3 | "What is the biggest risk in hiring someone who has never taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" | Name the risk honestly: a first-year learning curve on fourth-grade content. Hold that position once. If pressed, concede that a fourth-grade teacher starts with a year of fourth-grade knowledge you do not yet have, and name what you would do to close that gap. | The Skeptic's closing probe on F2. Hold-then-concede: the concession is the specific one your sentence supports. |
| A4 | "Families are partners here: each teacher speaks with every family each term. Your email goes out weekly. How is that the same thing?" | VAL | [grounded] "I write a weekly email to families"; district belief "Families Are Partners: each teacher speaks with every family each term." (district Mission and Beliefs page, named in Sources) | Describe the weekly email in your own words, and do not claim it is the same thing. Answer slot: if you have spoken with families in person or by phone, say how often and what came of it; if the email is your main contact, say so and say what you would add. | The published belief raises the question and the question quotes it. The answer must not stretch the email into a conversation. |
| A5 | "What, if anything, did the reading club change about how you teach during the school day?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer in the club's own terms. Answer slot: if the club changed something in your day-to-day teaching, say what and how you know; if it did not, say so. | Open about any change, because the quote names none. |

### B. Case/Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth-grader is reading at a third-grade level in October. Walk me through your first two weeks." | CASE | [generic] | Clarify first: what the assessment says and which assessment it is. Then small-group work at the student's level, a check at two weeks, and a family contact. Name no program you have not used. Speakable in 90 seconds. | A live problem from the role. It makes no claim about your history. |
| B2 | "The district says no student leaves third grade without a reading plan. How would you plan reading across the fourth-grade team?" | JD | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." (district page, named in Sources); "I led our grade level's move to a new reading curriculum in 2024" | Link the district's line to planning. Describe the 2024 move in its own words, then what planning across a team needs: shared expectations and agreed data. Answer slot: if you planned across a team before, say how, in your own words; if your experience is one grade, say so and say what you would bring to a team. | The district's published belief raises the question. Your only planning evidence is the 2024 move, so the answer stays at that scope. |
| B3 | "How would you structure small-group reading time in a fourth-grade day?" | CASE | [generic] | Structure: groups by need, time per group, what the rest of the class does, how you check the groups each week. No claim about your past. | Small-group reading is the theme of the principal's public work. Generic because it asks for a method. |

### C. Peer Evaluator (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our two classes sit side by side. Where would you draw the line between your classroom and ours?" | VAL | [generic] | Propose principles: what is shared (planning, assessments) and what is yours (room, routines). Do not pretend to know their seam. Ask them where it is. | A peer seam probe. It makes no claim about your history. |
| C2 | "When a colleague disagrees with a reading decision, what happens next?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name a disagreement only if one happened. Answer slot: if a colleague disagreed during the 2024 move, say what they said and what you did; if no one did, say so and say how you would handle it. | Disagreement with spine and tact. The move is the only team episode the material carries. |
| C3 | "When a unit goes well on this team, whose is it?" | VAL | [generic] | Say "we" for the team's work and "I" for your contribution. Make your contribution specific only from your own experience. | A credit-sharing probe in collegial packaging. |

### D. Data-Driven Prober (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you know the reading club helped the students who came?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what you ran and what you saw, in your words. Answer slot: if you measured any reading result, name it, say how it was counted, and name the assumption you would defend least; if you did not measure one, say so and say what you would measure. | The club is your strongest reading evidence, and probers ask for denominators. Claim no result you did not record. |
| D2 | "Did the 2024 curriculum move get checked against anything, and if so, what?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you checked the move against something, say what and how; if you did not, say so and say what you would check first. | The question asks whether a check existed and does not assume one. |
| D3 | "How many students came to the club, and how did you count them?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you kept attendance, give the figure you kept and how you counted; if you did not, say so. | A denominator probe. A figure you did not keep must not be produced. |

### E. Conversational, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | A 90-second arc in your own words: how you came to teaching, the six years, the 2024 move, the club, in that order. Add no reason you did not give. | A casual opener, scored for economy and interest. |
| E2 | "What drew you to Halvering?" | VAL | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." (district page, named in Sources) | Give your own reason, in your words. If you read the district's beliefs, name the one that matters to you and say why. Claim no connection you have not had. | Tests interest. The reason is yours to give. |

### F. Pressure, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You have sixty seconds. Why should we hire you over a fourth-grade teacher?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Pause, restate the question, then anchor in the six years and the stated absence, in your words. Hold the position through two follow-ups: what you bring from third grade and what you would do first. Concede plainly: a fourth-grade teacher has a year of fourth-grade knowledge you do not yet have. | A pressure test of F2: hold, then concede the specific thing. |
| F2 | "How much of the reading club was actually you?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer in your words: what you ran, and what others did. Hold the claim you made. If pressed on results, say you did not measure any, if that is true. | An attribution-honesty test. The answer stays inside the quote. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | none, and why: your material meets this gate, and it is a credential the district checks, not an interview question |
| Fourth Grade Teacher position (invite) | A1, A3, F1 |
| "Every Child a Reader" (district page) | B2, D1 |
| "Families Are Partners" (district page) | A4 |
| Working on a grade-level team (panel) | A2, C1, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | To the principal: "What would a strong first term look like for this role?" | Asks her to define success, which shows you plan around her expectations. |
| 2 | To the principal: "You came to principal from nine years as a reading specialist. What do you look for in a classroom teacher that you did not look for before?" | Ties to her public path. Your side of the shared jump is F3's club. |
| 3 | To a team member: "What would you want a new teammate to pick up first?" | Shows willingness to take on shared work. |
| 4 | To a team member (reciprocity): "What could a new person do in their first month that would genuinely help your team?" | A peer question that puts the hire's value to the team in their terms. |
| 5 | To a team member: "How does the team plan reading instruction across the week?" | Shows you are focused on reading, which is the district's stated priority. |
| 6 | "How do families usually hear from the team, and how often?" | Tests the "Families Are Partners" line in practice. Lands because it shows you read the district's beliefs. |

## Sources

Provided documents: your invite; your CV text and message as pasted. No job posting and no working-style assessment were supplied.

Searches sent (2):
1. "Dolores Vantongeren principal Halvering Elementary School": one result, a speaker page for the Illinois principals forum (ilprincipalsforum.example). Source of the principal's public background.
2. "Orrinsford Community School District values mission fourth grade": one result, the district's Mission and Beliefs page (orrinsfordschools.example). The page was not fetched, so the three beliefs quoted above come from the search snippet, and their full wording should be checked on the page.

Fetches: none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs in F3, F4, A4, B2 and E2, quoted from the snippet. No values cheat sheet, because no values-style round is detected |
| 2. Interview process | skipped | The invite fixes the loop: one 45-minute panel session, with three named interviewers |
| 3. Strategy / recent news | skipped | No output in this pack draws on strategy: the panel has no company-strategy questions |
| 4. Principal's name and school | yes | Public background and the 2025 talk; moved the interviewer read, the persona assignment and reverse question 2 |
| 5. Representative Fourth Grade Teacher JD | unavailable | Not sent. No posting was supplied, so this search should have run; the upgrade menu asks for the posting |

## Upgrade menu

- The posting for the Fourth Grade Teacher position → turns F2 and F3 into [grounded] rows against the posting's own words, and adds any requirement the invite leaves out. Without it, the requirements rest on the invite alone.
- A copy of your PEL registration → raises F1 from medium to high, because an inspected license is the artifact that band requires.
- HR's note on the process, including whether a demonstration lesson or written task comes with the panel → coverage of any graded deliverable.
- Your 2024 curriculum-move notes, or any count of students who came to the club → A2, C2, D1 and D3 answer slots become specific, in your own words.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. Offered once. Want it?
