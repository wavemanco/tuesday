Your prep pack is saved as /var/tmp/tuesday-measure/1a3/runs/haiku/tuesday/part-2/rooms/case-5-denied-39aa41cf/kelverton-rail_senior-partnerships-manager_interview_pack.md. I built it for the panel as you described it: Deepa and Ross, a 15-minute spoken POV, then Ross's commercial pushback.

The pack leans on what your own message says. The rail-sales gap is the likeliest objection, so B2 gets the deepest rehearsal. The POV's three theses are generic, because the market report's contents were not in the material. Web research was refused in this session, so nothing about Kelverton's values, loop or strategy is established yet.

Say the word and I'll play Ross on A1, the £4M question, and give you feedback against that question's guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Paste the posting text and your CV, or say you'd rather go without. Also tell me if the posting sets a location, office-days or right-to-work requirement.
2. Paste the operator-related parts of the market report, the findings you think matter most. The POV's differentiation depends on them.
3. Web search was refused in this session. Grant permission and I'll run the company research (values, interview loop, recent strategy) and check Deepa's and Ross's public footprints, or say you'd rather skip it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Remaining 45 minutes: Q&A, with commercial pushback.
**Panel:** Deepa, VP Partnerships (your future manager); Ross, Commercial Director.
**Built from:** your message and the recruiter's email as you quoted it. Not in the material: the posting text, your CV, and the contents of the market report. Web research was refused in this session, so the company's values, loop and strategy are not established here.

## How to use

Personas are how a question is asked. Types are what it scores: **JD** (the role and its qualifications), **EXP** (your past and how much of it was yours), **CO** (company and commercial thinking), **CASE** (a live problem). Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.

## Prep triage (about 4 hours)

1. **75 min: the POV.** Choose one thesis from G1, write its operator close in three sentences, and rehearse the whole 15 minutes aloud twice with a timer.
2. **45 min: Ross's commercial pushback.** Rehearse A1 to A3. Say the £4M out loud with its weakest assumption named, and say "I've never carried a direct quota" until it sounds plain.
3. **45 min: the rail gap.** B2 is the highest-return prep in this pack. Rehearse the plain acknowledgment, the adjacent sentence and a 30-day plan, holding through two follow-ups.
4. **30 min: two drills.** One Ross Pressure drill (A1) and one Deepa Skeptic drill (B2). Score each answer against its own cell.
5. **30 min: reverse questions.** Keep the three you would actually say aloud to Ross and Deepa.

Everything else is insurance. If the posting or the market report arrives, re-run this triage: the report's operator findings may move G1 and D2 up.

## Fit snapshot

No posting text was supplied, so the requirements below are role-family prose labelled `[generic]`, not quotes. The candidate's evidence is quoted from your message, and every quote below is exact.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Sell into or partner with rail train operators (role-family, `[generic]`) | "Never sold into rail specifically" (your message); "5 years in transport consulting" (your message) | low | [grounded] | transferability | Your material places you on the operator side of transport planning, and it says no rail sales. The plain acknowledgment: "I haven't sold into rail specifically." Then the adjacent work at its own scope: "5 years in transport consulting", "bus and light rail network planning". The limit: that sentence does not say the work involved buying or selling. Answer slot: if you have had any buying conversation with an operator, say what it was and what you learned; if you have not, say so and say how you would find out who decides. |
| F2 | Run and grow a partner channel (role-family, `[generic]`) | "running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | medium | [grounded] | none | This requirement is met in role terms. Say it in your own words, with the channel's numbers: "I was running the ISV channel and took it from 6 partners to 40." Caveat, a probe is likely: it is your word with limited inspectable proof. Pack observation, `[generic]`: an ISV builds on the product, while an operator is usually the buyer. The partner type is different, so name the difference rather than hide it. |
| F3 | Own commercial targets for partner-sourced revenue (role-family, `[generic]`) | "never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | none | [grounded] | capability | The plain acknowledgment: "I've never carried a direct quota." Then the figure as you gave it: "roughly £4M of influenced revenue." Pack observation: your material says influenced, not sourced, so the bridge does not turn it into a target. Answer slot: say how the £4M was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words; if you cannot say how it was counted, say so plainly. |
| F4 | Build a commercial case for an operator's budget (role-family, `[generic]`) | "so I know the operator world from the other side" (your message) | low | [grounded] | discovery | The material shows the operator-side vantage. It does not show a commercial case built for an operator, and it does not say who your consulting clients were. Do not say you advised operators unless you did. Answer slot: if you have built a business case for an operator, say what it counted, in your own words; if you have not, say so and say what you would ask an operator for first. |
| F5 | Understand how operators plan timetables and disruption (role-family, `[generic]`) | "bus and light rail network planning" (your message) | low | [grounded] | transferability | Your planning work is bus and light rail, not mainline rail timetabling. Say the scope as it is: "bus and light rail network planning." Name the difference yourself before the panel does. |

Gate note: the material says nothing about location, office pattern or right to work. If the posting sets any, it becomes a `hard_gate` row, and the cell will say your material does not establish it until you tell us.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail"; "I know how operators buy" | Inflated form of F1 and F4: adjacent work stretched into a sales or buying claim | "I haven't sold into rail specifically." and "so I know the operator world from the other side", quoted whole, at their own scope |
| "I carried a quota"; "I hit my number" | Negative you stated, F3 | The plain acknowledgment: "I've never carried a direct quota." No slot |
| The £4M as sourced, sole-owned or "I drove the £4M" | Inflated form of F3 | "roughly £4M of influenced revenue", at its own scope. The limit is the pack's observation: your material says influenced, not sourced |
| "I advised operators" | Inflated form of F4: the sentence does not name your clients | Only if true, in your own words. The material is silent |

## Reading the panel

No public footprint for Deepa or Ross was researched, and no interviewer profile was supplied. The interviewer read is therefore absent. Their titles, from the recruiter's email, set the weights below.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Time-boxed challenge on the £4M and the absent quota | Highest. The recruiter says Ross will push on commercials, and a Commercial Director at panel level is the relationship prior for this persona | Hold the stated fact through two follow-ups, then concede the specific uncertainty. Never fold on the core claim |
| Skeptic | Deepa | "Why you, given no rail sales?" and "what would you be weakest at on day one?" | High. A hiring manager buying capability and derisking the gap is the relationship prior for this persona | A plain acknowledgment, then the adjacent evidence at its own scope, then a 30-day plan |
| Case / Strategist | Deepa and Ross | Live problems on an operator's budget and what to do first | High for both. The prior for a hiring manager and an executive is this persona, and it is how a panel tests whether the POV holds | Clarify, then objective, then segments, then approach, then metrics. Say the assumption aloud |
| Conversational | Either, at the opener | "So, walk me through the journey" | Moderate. It opens the Q&A and is still scored | A 90-second arc built only from your own sentences |

## Graded deliverable: the 15-minute POV (G1)

The recruiter's words: "a short POV on where you'd take our operator partnerships over the next 18 months" and "land on what it means for the operators themselves". No slides.

**Grounded facts to build on:** "so I know the operator world from the other side" (F4, your message); "bus and light rail network planning" (F5, your message); "took it from 6 partners to 40" (F2, your message).

**Theses, each with its concession** (all `[generic]`: patterns for the problem, not claims about Kelverton's operators):

- **T1. Partner on the operator's metric, not the product.** Operators are likely to buy when a change moves a number they already report, such as disruption recovery or the cost of change. *Concession:* I cannot yet tell which numbers Kelverton's operators report, and I would check that first. *Operator close:* for an operator, one measure they already report moves within a planning cycle.
- **T2. Partner with the planners, then the buyer.** The people who live with the timetable often see the problem first, and the commercial lead signs. *Concession:* planners may lack authority to buy, and I have not sold into rail, so the buyer map is untested. *Operator close:* for an operator, the change reaches the people who run the timetable before it reaches procurement.
- **T3. Pilot on a shared measure, not a contract.** A bounded pilot with a measure both sides set lowers the cost of a first yes. *Concession:* an operator may not accept a pilot without a procurement route, and a pilot can become a free trial. *Operator close:* for an operator, they set the measure before they commit the spend.

**Anti-pick:** I would not chase every operator. I would pick two where a measure moves within a year. Say it, because the job includes saying no.

**Differentiation:** the market report's operator findings are not in the material, so there is no consensus answer to depart from yet. The placeholder is T2, which depends on planners rather than procurement. Once the report is pasted, name the one finding you would depart from and why.

**Timing, 15 minutes:** 2 minutes on the operator problem in their terms; 9 minutes on the three moves with one example each, all from your own sentences; 3 minutes on what it means for operators, one line per thesis; 1 minute inviting challenge. Each thesis should be speakable in 90 to 120 seconds.

## Question banks

Depth follows weight: Ross's Pressure bank is the deepest, then Deepa's Skeptic bank.

### Bank A: Ross, Pressure (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How much of that roughly £4M of influenced revenue was yours to claim?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the figure as you stated it. Name the weakest assumption behind it before he does. Answer slot: say how it was counted and which part was yours, in your own words; if you cannot say how it was counted, say so plainly. Hold through two follow-ups, then concede the specific uncertainty | F3 is the figure most likely to be probed. Defend-the-number slot |
| A2 | "You've never carried a direct quota. Why should we trust you with a commercial target?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold the stated fact and do not claim quota equivalence. Concede specifically that a direct quota is a different discipline, then give the plan for learning it, in the future tense | Premised on the quote. F3, capability gap |
| A3 | "Your partner numbers came from payments, not transport. Why would operators believe you know their economics?" | EXP | [grounded] "running the ISV channel" (your message); "so I know the operator world from the other side" (your message) | Scope the claim: the transport experience is planning, not operator commercial work. Concede that you have not sold to an operator and would test the economics with one early, as a plan | F2 and F4. Pressure on whether the vantage is the economics |
| A4 | "Give me the commercial case for one operator, in numbers, now." | CASE | [generic] | Structure it: the operator's budget line, what they would measure, and what it costs them not to act. Name the two numbers you would need from the operator, and say you will not put figures in without them | A live problem with no past claim. F4 is discovery, so the honest answer is the method |
| A5 | "What does a partnership mean to an operator that a supplier relationship does not?" | CO | [grounded] "so I know the operator world from the other side" (your message) | Give your own definition: a partner shares a risk or a customer, a supplier sells a product. Tie it to what you saw from the planning side, in your own words only | F4 and F2. Tests whether the partner-supplier distinction is held, not borrowed |

### Bank B: Deepa, Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] persona stem | Name the rail sales gap first, in your words: "I haven't sold into rail specifically." Then the 30-day plan: talk to operator planners and commercial leads and ask what they would measure | Opens the Skeptic bank with the likeliest answer |
| B2 | "I don't see rail sales in your background. How would you handle that?" | JD | [grounded] "Never sold into rail specifically" (your message) | The plain acknowledgment: "I haven't sold into rail specifically." Then the adjacent work at its own scope: "bus and light rail network planning". Hold through two follow-ups: the adjacent work is operator-side planning. On the third, concede the buyer side is untested and give the plan. Answer slot: if you have had any buying conversation with an operator, say what it was | The single most predictable objection, so the deepest rehearsal in this pack. F1. The interviewer's negative has the candidate's own sentence as its source |
| B3 | "How would you know a partnership was working in year one at an operator?" | CASE | [grounded] "took it from 6 partners to 40" (your message) | Name two leading indicators and one lagging one, in your own words. If you draw on the channel, use your own sentence and nothing more | A definition of success is the hiring manager's test. The channel is the only measured past you have |
| B4 | "You took it from 6 partners to 40. How much of that was you, and how much was the product?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name what you drove and what the company did, in your words. Answer slot: if partners joined for reasons that were not yours, say so | Attribution probe on F2, the one measured past achievement |

### Bank C: Deepa, Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you would start with our operator partnerships. What do you need to know first?" | CASE | [generic] persona stem | Clarify first: what operators buy, who decides, what they measure, and how they are contracted. Then the objective and segments | A live problem that tests the POV's first move. The clarifying questions are the answer |
| C2 | "Which operator would you call first, and what would you say?" | CASE | [generic] persona stem | Choose by a criterion (a measure you could move within a year), not by a name. Do not name an operator from memory; you have not verified who they are | Tests segmentation and restraint. The anti-pick from G1 applies |
| C3 | "What would you stop doing with partners?" | CASE | [generic] persona stem | Give a prioritisation criterion and one thing you would drop. Do not describe a stop you did not make | Focus under a manager's eye. Tests judgment, not history |

### Bank D: Ross, Commercial (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where does a scheduling partnership make money for an operator, and where does it cost them?" | CO | [generic] | Structure it: cost avoided, disruption reduced, and the budget line each one sits in. Name the trade-off: a purchase is a budget decision | Commercial altitude. Tied to T1 |
| D2 | "Which finding in the market report would you challenge first, and why?" | CO | [generic] | Name one operator-side finding and say what would have to be true for it to hold. Answer slot: you have read the report, so name the finding in your own words | The differentiation test. The pack cannot name the report's findings until you paste them |
| D3 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] persona stem | A 60-second arc from your own sentences: the channel, the planning background, and the gap you would close first | Pressure stem. The honest answer is the adjacent evidence plus the gap |
| D4 | "If we asked you to halve operator sales cycles, what would you change first?" | CASE | [generic] | Clarify where the cycle is slow, then name the first change and how you would test it. Assume no operator figures | A live problem about the business, not the candidate's past |

### Bank E: Opener and Q&A entry (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting"; "running the ISV channel" (your message) | A 90-second arc in your message's order: planning, then the channel, then what you want from operators. Each beat is a sentence you wrote | Conversational opener, scored. It sets up the rest of the Q&A |
| E2 | "What do you know about operators that payments people usually don't?" | CO | [grounded] "so I know the operator world from the other side" (your message) | Say what your planning work touched, in your own words, and stop there. Do not extend it to rail timetabling | The honest answer is the planning-side vantage, at its own scope |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first year look like for this role with operators?" | It sets a shared definition the POV can be measured against |
| R2 | "How do you judge a partner's revenue when the deal is influenced rather than sourced?" (to Ross) | It goes straight to the influenced-revenue gap and shows you have already named it |
| R3 | "How do the commercial team and partnerships share a target for operator revenue?" (to Ross) | It tests how accountability is set, which is the quota question without asking it as a challenge |
| R4 | "What has made an operator partnership fail here before?" (to Deepa) | An honest answer maps the risks; a guarded one tells you the culture |
| R5 | "What would you want me to stop doing in my first 90 days?" (to Deepa) | It asks what the manager expects, which is the plain version of the 30-day plan |

## Sources

- **Provided documents:** your message (background, the recruiter's email as you quoted it, and your prep constraints). The market report: not in the material. You said you have read it, but its contents were not pasted, so nothing is taken from it here.
- **Searches sent:** three, all refused by the host (permission not granted for web search in this session):
  - `Kelverton Rail values`: refused
  - `Kelverton Rail interview process partnerships`: refused
  - `Kelverton Rail strategy news scheduling software train operators`: refused

**Research tier: L1, searches 3 of 6, fetches 0 of 2 (all 3 searches refused)**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. A values cheat sheet would have moved section 10, but the recruiter's email names no values round, so none is detected here |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Refused. The loop is established by the recruiter's own words (one 60-minute panel session with a POV first), so the loop does not depend on this search. It would have checked for a values round |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Refused. It would have moved D1 and D2 and the POV's current framing. The pasted report would do the same job |
| 4. Interviewer footprint, Deepa and Ross | unavailable | No call sent: the host refused web search in this session. Would have moved the persona weights for both and the reverse questions tied to their paths |
| 5. Representative posting for the title | unavailable | No call sent: the host refused web search. Would have made the requirement rows `[inferred]` instead of `[generic]` |

## Upgrade menu

- The posting text: its own lines become quoted `[grounded]` requirements in place of the `[generic]` prose, and any location or right-to-work line becomes a `hard_gate` row.
- Your CV: evidence can be quoted from it as well as from your message, and the confidence bands for F1, F2 and F5 can move on what it shows.
- The market report's operator findings, the parts you think matter: G1's differentiation and D2 become specific, and the triage is re-weighted.
- Web search permission: company values, loop and strategy checks at L1, plus Deepa's and Ross's public footprints, which would give the interviewer read and reverse questions tied to their career paths.
- How the £4M was counted, in your own words: A1's defend-the-number slot becomes a quote you can rehearse.
