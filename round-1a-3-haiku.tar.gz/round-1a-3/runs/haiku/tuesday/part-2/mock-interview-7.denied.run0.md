I couldn't run the web research: the three searches were refused permission. The pack below is built from your message and the JD only, so the company values, interview loop and Tobias's public background are missing. I'm writing the pack file now.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-denied-6f6d4ba3/9380d487-801a-4f83-aa18-d86bdaaa3342/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`.

**Without company research.** The three web searches were refused permission, so the pack has no Saltmarsh values, no interview-loop structure, and nothing on Tobias Wrenfield's public background. It also has no CV, so it rests on your message and the JD you pasted. I assumed a hiring-manager round; the questions below will correct that if it's wrong.

**The two gaps the pack centres on:**
- **Never led a team.** S1 and R1 are the hardest questions. The honest answer is "I haven't led a team," then the calendar you ran for two years, then a ramp plan. S1 is the one to rehearse first.
- **No in-app purchases.** The JD doesn't mention monetisation, so the pack doesn't ask about it. If it comes up, answer with "I haven't worked on a game with in-app purchases," then a plan for learning it.

**Where your evidence is strongest:** the weekly content-drop calendar (F2) and the release checklist QA still uses (F6). Expect follow-ups on both, and bring the checklist if you can.

**Two things to fix before Friday:**
- Say "presented" for the retention numbers, not "built" or "owned" (F3). Be ready to say whether you computed them.
- Be ready to say which teams you coordinated with on an update (F4). Your material doesn't show it, so the honest answer may be "I didn't, here's how I'd set it up."

Can you answer two things so I can tune the pack?
1. Is Friday the first round, and is Tobias the manager you'd report to, or a skip-level?
2. Did the recruiter say what the 60 minutes covers: a case, a presentation, or a take-home?

If you can turn research back on, I can rerun the searches for the values page, the loop, and Tobias's background. Or paste the values page or his profile directly.

I can also play the Skeptic on S1 as a live drill, or save a `tuesday-dossier.md` that records these gaps for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship presumed to be hiring manager; not yet confirmed (see the questions in the message). **Round:** 60 minutes, session mode, one conversation. **Candidate:** Femi (they/them).

**Changelog:** first version. Built without company research (searches refused), without a CV, and without a recruiter note.

---

## 1. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Values alignment | Not used. No values page was read and no values round is detected. |
| EXP | Experience deep-dive | Whether what you did survives scrutiny |
| JD | Role / JD-driven | Whether you can do what the listed job asks, including its gaps |
| CO | Company knowledge | Not used. No research ran. |
| CASE | Live problem | Structure and reasoning on a problem from the role |

---

## 2. Prep triage

Prep time was not stated, so no schedule is set. In order of return on effort:

1. **S1 and S2**, the gap questions. They are the most likely to be asked and the hardest to answer on the spot.
2. **P1 and P2**, the calendar and retention questions. Your strongest evidence sits here.
3. **C1 and C3**, the planning and coordination cases.
4. Everything else is insurance.

---

## 3. Fit snapshot

Evidence in quotation marks is taken from your message, or from the JD as you pasted it. No CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Your years and title are stated. Live-service status is not. Say the years, the title, and the content-drop work at their own scope. Answer slot: if the title ran updates after launch in the sense the JD means, say how; if you are unsure what the JD means by live-service, say that. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement directly. Lead with it in these terms. Expect a probe on the calendar itself, so be ready to show it. |
| F3 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Its bridge only rewords the quote: "I presented the monthly retention numbers to the studio head." Presenting is not the same as computing. Answer slot: if you built or changed how those numbers were calculated, say which; if you presented figures someone else produced, say so. |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show cross-team coordination on updates. Answer slot: if you coordinated across design, art, engineering or community on an update, say which teams and how; if you did not, say so and say how you would set it up. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | The retention quote touches reporting but does not show a post-event review. Answer slot: if you ran post-event reviews, say what they covered and which KPIs they reported; if you did not, say so. |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote reaches the requirement directly. The checklist is an inspectable artifact. Bring it if you can. |
| F7 | "clear written communication" — JD | none given | none | [grounded] | discovery | Your material names no written artifact you produced for a team or leader. Answer slot: name the nearest written artifact you have and what it changed. |
| F8 | "Never led a team" — your message (your own statement; not a JD line) | "Never led a team, and never worked on a game with in-app purchases." — your message | high | [grounded] | capability | A negative you stated. Words: "I haven't led a team." Then the closest thing you did, in your own words, and how you would close the gap, said as a plan, never as a past. |
| F9 | "never worked on a game with in-app purchases" — your message (not a JD line) | "Never led a team, and never worked on a game with in-app purchases." — your message | high | [grounded] | capability | A negative you stated. Words: "I haven't worked on a game with in-app purchases." The JD does not name monetisation, so this is a probe you may meet, not a requirement. A plan for learning it is fine; a claim of knowledge is not. |

**Gates.** None in the JD as pasted: no location, pay, or authorisation term is stated. If the recruiter names one, it becomes a row.

**Prohibited claims** (Section 5) apply to every row above.

---

## 4. Persona table

No loop source was read, so no loop is established. The round type is presumed from the interviewer's role, and the persona weights below use the hiring-manager prior, said plainly as a presumption.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live problems from the calendar and the four disciplines | High. A Head of Live Ops is buying judgement on live events. | Clarify, then structure: goal, constraints, sequence, metrics, risks. | 5 |
| Skeptic | "Why you, with no team leadership?" | High. F8 and F9 are the gaps, and a hiring manager will test them. | Acknowledge plainly, bridge only with what you stated, then a ramp plan. | 4 |
| Data-Driven Prober | Asks how a figure was counted | Medium. F3 is a presentation-only claim. | Name the weakest assumption before they do. Say what you did not compute. | 3 |
| Pressure / Stress | Time-boxed challenge on the leadership gap | Medium. Stress tests the one gap that matters most. | Pause, restate, hold through two follow-ups, concede precisely. | 3 |
| Peer Evaluator | Seams with design, art, engineering | Medium. The JD's coordination line is cross-team. | Propose seam principles, not a past story. Reciprocity. | 2 |
| Conversational | "Walk me through the journey." | Always present. Casual questions are still scored. | A 90-second arc from your quoted sentences only. | 2 |

Total: 19 questions, within the 18 to 26 range.

**Interviewer read:** not included. No public footprint was established for Tobias Wrenfield, so the persona weights have no interviewer signal.

---

## 5. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or managed people | Negative you stated, F8 | "I haven't led a team." No slot. |
| Ran the live-events calendar for two titles | Inflated form of F2. The quote says one title. | F2's quote at its own scope: "for our main title". |
| Owned post-event reviews or KPI reporting | Inflated form of F5 | F5's answer slot. The quote shows presenting figures, not owning reviews. |
| Built or improved the retention numbers | Inflated form of F3 | F3's quote at its own scope, plus the answer slot. |
| Coordinated design, art, engineering or community on updates | Silence in the material, F4. Not claimed. | The F4 answer slot only. |
| Has knowledge of in-app purchase systems | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |

---

## 6. Question banks

Guidance is speakable in 90 to 120 seconds. Provenance carries every sentence the guidance rests on.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Imagine you're running the calendar for two titles, and an event is six weeks out. Walk me through how you'd plan it." | CASE | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Clarify the goal, the constraints, and the capacity of each team. Sequence the work: art and design lead times, the engineering freeze, QA's window, and the release dates. Name what you would cut first. You may describe the weekly cadence you ran, using F2's quote: "I ran the weekly content-drop calendar for our main title for the last two years." | Headline JD requirement. Asks for judgement, not history, so the guidance makes no past claim beyond F2. |
| C2 | "A live event launched, and day-7 retention dropped. Where do you start?" | CASE | [generic] | Clarify what dropped and against what baseline. Check instrumentation and any release that landed in the window. Segment by cohort, version and platform. Decide before you change anything. | Tests the retention requirement as a method. No claim about the candidate. |
| C3 | "Design wants a mechanic that art cannot finish before the date. Engineering says the client change is not ready. You own the date. What do you do?" | CASE | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Separate the constraint from the preference. Name who decides what. Offer options: scope cut, phased rollout, date move. Say what you would tell each team, in writing. | Covers the coordination line as a decision. No past claim. |
| C4 | "What would your first 30 days look like: the calendar, the checklist, and the KPI reporting?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Listen first. Audit the calendar and the checklist for gaps. Agree the KPI definitions with each team. Set a review cadence. Make no claim about past work. | Covers the ownership line for the new role. |
| C5 | "For a live event, which one metric would you put on the review slide, and what would make you distrust it?" | CASE | [grounded] JD: "own the post-event review and the KPIs it reports" | One primary metric tied to the event's goal. One guardrail metric. Name the confounder you would check first: overlapping events, a release, seasonality. | Bridges into the Prober's questions. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team. This role coordinates four disciplines and owns the calendar. What's your answer?" | JD | [grounded] "Never led a team" — your message. [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say it plainly: "I haven't led a team." Then the closest thing you did: "I ran the weekly content-drop calendar for our main title for the last two years." Do not claim you coordinated four disciplines. Hold through two follow-ups by returning to the calendar. Concede precisely: the gap is real. Then a ramp plan, said as a plan. | This is the highest-ROI prep in the pack. The gap is the headline one, and the honest answer is the one that survives a second follow-up. |
| S2 | "The role's live-service experience matters here. Which of your four years was live-service work, and how do you know?" | JD | [grounded] "3+ years producing live-service games or apps" — JD. [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Answer from your own years. If the puzzle title ran updates after launch, say how. If you are unsure what live-service means in this role, say so, and ask what they mean by it. | Covers the years requirement. The answer depends on facts only you know. |
| S3 | "Which discipline in this role would you be weakest in on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" — JD | Pick one honestly. Then the nearest thing you did: "Wrote the release checklist our QA team still uses." Answer slot: if you have worked with the discipline you name, say how; if not, say so and say what you would do in the first two weeks. | Open prompt. Presupposes nothing about you. |
| S4 | "Retention is central here. You presented the monthly figures to the studio head. Did you compute them, or present someone else's?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or changed how they were calculated, say which; if you presented figures someone else produced, say so and say what you checked before presenting. | F3's gap. The honest answer is the one a prober finds, so rehearse it. |

**Likely probe, not in the banks:** a question about monetisation. The JD does not name it, so no question is written from it. If it comes, answer with F9's plain acknowledgment and a learning plan.

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How did you know whether a weekly content drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Describe what you tracked, at the quote's scope. Answer slot: if you tracked a result per drop, say what and how it was counted. If you did not, say so and say what you would track. Name the assumption you would defend least before they do. | F2's calendar is the strongest evidence, and a prober will test whether the calendar was measured. Open prompt, so no figure is supplied. |
| P2 | "How were the monthly retention numbers you presented defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you know the definition, state it in your words. If not, say so plainly. Then name the assumption behind the figure you would defend least, or say you did not build it. | F3's presentation gap, asked as an open definition question. |
| P3 | "A post-event review says 'engagement went up'. What do you ask before you believe it?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" — the JD. The method is [generic]. | Ask for the baseline, the comparison group, any overlapping events, the metric's definition, and whether the uplift held after a week. | Tests the review requirement as a method. Makes no claim about you. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why should we hire someone who has never led a team over an internal candidate who has?" | JD | [grounded] "Never led a team" — your message | Pause and restate the question. Anchor in the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups. Concede precisely: "I haven't led a team; that is the gap, and here is how I would close it." Do not fold on the calendar. | Pressure on F8, the headline gap. Tests composure, not content. |
| R2 | "The release checklist you wrote: when a check fails before a release, who decides what happens next?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Answer slot: if the decision was yours, say which and how you made it. If QA decided, say so, and say what you did. | Tests F6's edge without presupposing a blocked release. |
| R3 | "That retention result you presented to the studio head: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold: "I presented the monthly figures." Concede where it is true: "If I did not produce them, here is what I checked before I presented them." | Attribution honesty under pressure. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "Design and art run on different timelines for each update. Where's the seam with your work, and what happens when you disagree with design?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Propose seam principles: who owns the date, who owns scope, how a disagreement escalates. Answer slot: if you have disagreed with a design lead about scope, say what happened; if not, say so and say how you would decide. | F4's gap, asked as a collegial seam. |
| N2 | "What would you need from engineering, and what would you bring them?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Reciprocity: name the release checklist you wrote, and the weekly calendar cadence you ran, as what you would bring. Quote them: "Wrote the release checklist our QA team still uses." | Peer framing turns a probe into a partnership question. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A 90-second arc from your quoted sentences only: the studio, the calendar, the checklist, the retention presentation. Add no titles or outcomes. | Casual, and still scored. Your pre-scripted arc is the defence. |
| V2 | "What are you playing right now, and what would you change in it?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Name a title you actually play and one concrete change, with a reason. Do not invent a favourite. | Tests interest in the mobile space the JD names. |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | C1, P1 | |
| Coordinate design, art, engineering and community | C3, N1, N2 | |
| Own the post-event review and the KPIs it reports | C4, C5, P3 | |
| Manage the release checklist with QA | R2, S3 | |
| 3+ years producing live-service games or apps | S2 | |
| Experience running a content calendar | P1 | |
| Comfortable with player-retention metrics | C2, P2, S4, R3 | |
| Clear written communication | none, and why | No quote names a written artifact you produced. Add one in the upgrade menu. |

---

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a strong first 90 days look like for this role?" | Turns the gap into a shared bar, and gets their own success criteria. |
| 2 | "Which two titles would this role cover, and how far apart are their release cycles?" | Tests the scope the JD names, in the interviewer's own terms. |
| 3 | "How are post-event reviews run today, and who sees the KPIs they report?" | Shows you read the ownership line, and surfaces whether the role inherits a process. |
| 4 | "When design, art and engineering disagree on an update's date, who decides?" | Surfaces decision rights, which is what the coordination line depends on. |
| 5 | "What would make you say the hire was a mistake at six months?" | Exposes the leadership bar behind S1 and R1 directly. |
| 6 | "Is this first conversation the whole process, or is there more after it?" | Sets up the prep for later rounds. |

No interviewer profile exists, so none of these ties to Tobias's career path. Add his name's public footprint in the upgrade menu.

---

## 8. Sources

**Provided documents:** your message, which contains the background and the JD as pasted. No CV, no recruiter note, no strategy brief.

**Searches and fetches sent:**

| Query | Result |
|---|---|
| "Saltmarsh Games values" | refused (permission not granted) |
| "Saltmarsh Games interview process Live Operations Producer" | refused (permission not granted) |
| "Tobias Wrenfield Saltmarsh Games Head of Live Operations" | refused (permission not granted) |

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2; all 3 searches refused; user links read 0

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, which was not built. No values round is detected, so no VAL questions are written. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. No loop is established, so the weights rest on the hiring-manager prior. |
| 3. Company strategy / recent news | unavailable | Would have moved the CO bank. No search was sent: the host refused the first ones. |
| 4. Tobias Wrenfield footprint | unavailable | Interviewer read and a tailored reverse question. The search was refused. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 9. Upgrade menu

- A recruiter note on the round's format and focus areas → shows whether a case, a presentation or a take-home is coming, and reweights the banks.
- Tobias's public footprint, if you can enable search, or paste his profile or a talk → persona weights and a tailored reverse question.
- The release checklist you wrote → makes F6 something you can show, not only say.
- One calendar you ran → makes F2 inspectable.
- A written update or document you produced for a team → covers the written-communication requirement, which has no question yet.
- A CV → rechecks the confidence on F1 and F2.
- A deeper research pass (L2) → company strategy for the CO questions. Offered once, and it needs search access, which was refused.
- A `tuesday-dossier.md` from an earlier session, if you have one → sharper objection work.
