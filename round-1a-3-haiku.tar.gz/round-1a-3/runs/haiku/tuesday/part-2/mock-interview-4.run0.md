Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-4-denied-c8c5fd3d/fc770f49-7923-4349-ae64-86801ba6d08f/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round from the dossier's handoff section. Company research was refused, so the pack has no values, loop structure or strategy for Quartzline. The dossier is also dated 2026-08-14, so check the posting still matches its five requirements.

Start with A1. The underwriter named that objection as your highest-ROI prep, and the pack's plain acknowledgment, bridge and ramp plan for it are in the file. The pack keeps the three prohibited claims as absolute: no PM title, no owned roadmap, no prioritization for an engineering squad.

Say the word and I'll play the Skeptic on A1 for a drill.

I can also save a `tuesday-dossier.md` with the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager, Thursday 26 November 2026. Interviewer not named. Built from `tuesday-dossier.md` (job-underwriter, conditional_go, dated 2026-08-14).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** role and job requirements. **EXP** what you actually did in past work. **CASE** a live problem, no past claim. **VAL** values. **CO** company knowledge (none here: no research ran).
- Guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview: answer them in your own words. Anything you did not do, say so plainly.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from its `verified_candidate_evidence` or from the dossier's own gap records.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence item 1) | low | [inferred] | transferability | Adjacent work, not PM years. Limit first: the material shows integration leadership, with no PM title. Words: "I led client integrations of the vendor's REST APIs from scoping through go-live." Then stop at that limit. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence item 1) | medium | [grounded] | transferability | The quote is about integrating the vendor's APIs, not shipping an API product, so do not say you shipped one. The underwriter did not list R2 as weak; this pack routes it from the quote, so check it against the underwriter's map. Caveat: confirmed, limited inspectable proof, so expect a probe on what the integrations delivered. |
| F3 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier, verified_candidate_evidence item 3) | medium | [grounded] | presentation | Reword only that quote: "I ran quarterly roadmap-input sessions that fed client evidence to product." Caveat: confirmed, limited inspectable proof, expect a probe. Name what the sessions were, in those words. Nothing about engineering or sales is in the quote. |
| F4 | "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier uncertain_or_weak_areas; role_profile responsibility: "Own the roadmap for the partner-facing API platform") | none given (the dossier records the gap in its acknowledge_gap area) | none | [grounded] | capability | Words from the dossier's acknowledge_gap area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan, never as a past. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Answer slot: if you have worked to a sprint or planning cadence with engineers, describe it; if not, say so and say what you would confirm about how these squads plan. Clarify strategy. |
| F6 | "Define and track adoption metrics" (dossier role_profile responsibility) | none given | none | [grounded] | discovery | Answer slot: if you measured adoption of anything, say how it was counted; if not, say so and say what you would measure first and what baseline you would need. |
| F7 | "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | "Wrote the internal integration playbook" (dossier, verified_candidate_evidence item 2) | low | [inferred] | discovery | A playbook is written guidance for integrations. It does not show specs that engineering squads built from, or delivery through them. Answer slot: if you wrote specs engineers built from, say what they contained; if the playbook is the nearest thing, say what it covered. |
| F8 | "Run discovery with integration partners" (dossier role_profile responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence item 1) | medium | [grounded] | presentation | Scoping and requirements were stages of each integration you led. Reword only that: "Scoping and requirements were part of each integration I led." Not discovery with a partner in those words. |

**Coverage line.** R1 → F1, F4; A1, A2, C1, C3. R2 → F2; C2, D1. R3 (technical fluency: API docs, schemas) → no row; E2, D3. R4 → F3; A3, B1. R5 → F5; A4. Roadmap ownership → F4; A2, A3, B3. Discovery → F8; B1. Specs and two squads → F7; B4, B5, B3. Adoption metrics → F6; A5.

## Prohibited claims

Each entry names its basis and its honest form. No answer slot, guidance cell or reverse question asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | "I haven't held a product manager title or role." No answer slot. |
| Having owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap" | "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." |
| Owned the partner-API roadmap | Local inflated form of F3's quote "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote at its own scope. Pack observation, not words for you: your material says input sessions, not roadmap ownership. No first-person negative. |
| Shipped an API product | Local inflated form of F2's quote "Led 30+ end-to-end client integrations of the vendor's REST APIs" | The quote at its own scope. Pack observation: your material says integrations of the vendor's APIs, not a product you shipped. No first-person negative. |

## Persona weights

Hiring-manager prior: Case/Strategist and Skeptic dominate (`personas.md`). No interviewer profile exists, so there are no interviewer-signal adjustments. No loop source establishes the loop, so the Generic archetype applies and the weights are flat within that prior: the pack says so plainly. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the R1 gap, the roadmap gap and the objection the underwriter named | Top weight (5). The underwriter named its objection as the highest-ROI prep. | Plain acknowledgment, then the bridge with its limit, then a ramp plan. Hold through two follow-ups. |
| Case/Strategist | Live problems on the partner roadmap and the two squads | Top weight (5). A hiring manager is buying capability and testing it on live roadmap problems. | Clarify, then structure, then name who decides. Think aloud. |
| Pressure | Time-boxed challenges to the PM-years gap and the integration count | Mid weight (3). Relevant because the R1 gap is the first thing a challenger reaches for. | Pause, restate, anchor in the quote. Hold, then concede the specific point. |
| Data-Driven Prober | The "30+" figure and the playbook's reach | Mid weight (3). The 30+ figure is a defend-the-number target. | Say how it was counted, name the assumption you would defend least, say what was yours. |
| Conversational | The journey question and a casual check on API docs and schemas | Low weight (2). Casual questions are still scored. | Use a 90-second arc. Treat casual questions about the posting's topics as scored. |

## Question banks

Session total: 18 questions (A5, B5, C3, D3, E2).

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role"; acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | The highest-ROI rehearsal in this pack, named by the underwriter. Open with the acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the bridge with its limit: "What I have done is lead client integrations of the vendor's REST APIs from scoping through go-live." Then the plan, as a plan: say what you would do in your first 90 days. Concede the real point: a PM with three years is further along on roadmap ownership. Hold through two follow-ups by returning to the integrations, not by adding to them. | Objection named by the underwriter from the candidate's own gap. Covers R1 (F1, F4). Its negatives have the sources the premise rule requires. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having owned a product roadmap" | Name roadmap ownership first, with the plain acknowledgment. Then the agile gap (F5) and the adoption metrics gap (F6), each as an answer slot: if you have a case, say it; if not, say so and say what you would confirm. Keep it to 90 seconds. | Skeptic stem; covers F4, F5 and F6 in one answer. |
| A3 | "The role owns the roadmap for the partner-facing API platform. How much of a roadmap have you had a say in?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped: you ran quarterly roadmap-input sessions, feeding client evidence to product, in those words. Caveat named: confirmed, limited inspectable proof, so volunteer what the sessions were, rather than wait to be asked. Answer slot: if any priority in those sessions was yours to set, say which and how you decided; if none was, say so plainly and say what the sessions fed. | F3 and F4. The quote is medium confidence, so the caveat is coached in, not left to a prober. |
| A4 | "Agile delivery inside a product org: what cadence have you worked to, and with whom?" | JD | [generic] | Clarify strategy: "Do you mean sprint planning, or how priorities get set between product and the squads?" Then the answer slot: if you worked to a sprint or planning cadence with engineers, describe it in your own words; if you never worked that way, say so and say what you would want to confirm about how these squads plan. | F5 is discovery with low confidence. No verified entry speaks to agile delivery, so the answer is a slot, not a bridge. |
| A5 | "Define and track adoption metrics. What would you start measuring, and what would you compare it to?" | JD | [generic] | No claim about your past. Answer slot: if you measured adoption of anything, say how it was counted and which assumption you would defend least; if you did not, say so, and say what you would measure first and what baseline you would need. | F6. The posting names the responsibility, and the dossier states no current baseline. |

### B. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration has stalled after the first call. Walk me through how you would diagnose it." | CASE | [generic] | Clarify the objective first, then segment: which partners, which stage of the integration. Approach, metrics, risks. Think aloud and say the structure before using it. No claim about your past. | Live problem from the discovery responsibility (F8) and stakeholder management (F3). |
| B2 | "A partner asks for an endpoint that only they need. Do you build it?" | CASE | [generic] | Frame the decision: who else is affected, what it costs both squads, what the roadmap gives up. Say explicitly who decides. | Tests decision authority, which the posting asserts and the material does not show. |
| B3 | "Two engineering squads, and a partner-API roadmap with more asks than capacity. How do you sequence it, and who signs off?" | CASE | [generic] | Structure, then end with who signs off. Name the decision you would take to the squad leads and the one you would own alone, as a proposal, not as past practice. | Covers the two-squad responsibility and the decision-authority risk in one problem. |
| B4 | "Describe a spec you have written for engineers. What did it have to contain?" | JD | [grounded] "Wrote the internal integration playbook" | Answer slot: if you wrote specs engineers built from, describe one; if the playbook is the nearest thing, say what it covered and who used it; if you wrote neither, say so and say what a spec for these squads would need. Do not describe a spec the material does not show. | F7. Premised on a spec the material does not show, so the second branch allows that none was written. |
| B5 | "Tell me how the integration playbook gets used, and what it changed in the work." | EXP | [grounded] "Wrote the internal integration playbook" | Story-mapped on the one sentence: you wrote it; say what it covers in your own words. Answer slot: if you saw it change how integrations went, say what you saw and how you know; if you did not see that, say so. | F7 and F3. Premised on a use and an effect the quote does not carry, so the second branch allows neither. |

### C. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone with three years of PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause, restate the question in your own words, then the integrations in the quote's words. Concede the PM years in the first sentence, not after the second follow-up. Hold the integrations claim through two follow-ups. The specific concession: "On roadmap ownership, the candidate with three years is ahead." | F1 under time pressure. The hold is only the quote's scope. |
| C2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which stages were yours and which were the team's, in your own words. If any of the thirty-plus were led by someone else, say so. Hold the word "led" only as far as the quote carries it. | F2. A challenge to attribution, and the honest answer is the candidate's own split. |
| C3 | "Why move into a PM role after integration work? That looks like a step sideways." | JD | [generic] | Motivation in your own words: what in the integration work pulled you toward product decisions. Make no claim about past product work. | Pressure on the transition. No verified entry carries a motive, so this is a slot, not a story. |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the 30+ integrations. Which metric did you track, and how was it counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats are the quote's five stages, in your words. Answer slot: if you tracked a metric, say how it was counted and what it is sensitive to; if you did not track one, say so. | The 30+ figure raises the defend-the-number slots. |
| D2 | "Which assumption behind the 30+ figure would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the weakest assumption in your own words before the interviewer does. If you cannot name one, say so. Do not reconstruct the count live. | Defend-the-number slot on the figure in the quote. |
| D3 | "How many teams use the playbook you wrote, and how do you know?" | JD | [grounded] "Wrote the internal integration playbook" | Answer slot: if you know the usage and how you know it, say both. If you do not know, say so. Do not give a number you have not checked. | Covers R3 (API documentation) and the adoption-metrics theme. Stays inside the quote. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: integrations, then the playbook, then the roadmap-input sessions, then why you want this role, in your own words. The reason for the move is yours to add. Do not add any event the three quotes do not carry. | Casual register, scored. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [generic] | Answer slot: name any API documentation or schema tools you have used, in your own words. If you have not used schemas directly, say so and name what you have read. | R3 (technical fluency). No verified entry shows schemas, so this is a slot. |

## Reverse questions

Five questions, each with its why-it-lands. None is tied to the interviewer's career path: no profile was given.

1. **Which roadmap decisions does this PM make alone, and which belong to the squad leads?** Why it lands: the posting gives the role the roadmap and does not say what authority comes with it. This is the decision-authority risk the dossier flags.
2. **How is partner API adoption measured today, and what is the current baseline?** Why it lands: adoption is a stated responsibility with no baseline in the posting. The answer tells you whether you would define the metric or inherit it.
3. **How do the two squads plan, and where do product priorities get set relative to that?** Why it lands: it tests the agile gap from the employer's side and shows you know the squads are the delivery path.
4. **Who are the integration partners in discovery now, and what have they recently raised?** Why it lands: it tests the discovery responsibility and surfaces partner pressure you would inherit.
5. **What would the first roadmap decision from this hire look like?** Why it lands: it turns the roadmap into a concrete problem, and a specific answer tells you what you are walking into.

## Sources

- **Provided documents:** `tuesday-dossier.md`, job-underwriter, conditional_go, dated 2026-08-14. Sections consumed: `role_profile` and `handoff_to_mock_interview`. The dossier is more than three months old as of 2026-11-20, so the posting and scope may have changed.
- **Research tier:** L1, searches 3 of 6, fetches 0 of 2. All three searches were refused (permission not granted), so no company facts are in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet not built. No values-style round is detected, so it would not have been built regardless. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure unknown. Persona weights rest on the Generic archetype, as stated above. |
| 3. Quartzline strategy / recent news | unavailable | Would have moved the CO bank. No CO question is in the pack, and no current company fact is used. |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` supplies the requirement lines. |

Queries sent, all refused: "Quartzline values"; "Quartzline interview process product manager"; "Quartzline strategy news 2026".

## Upgrade menu

- A current job posting, or the recruiter's email about the round → confirms R1 to R5 and the four responsibilities still match what the dossier used, since the dossier is from August.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own career path. It also unlocks research target 4.
- The recruiter's note on what the round will focus on → reweights the banks. Any exercise the recruiter announced gets its own section.
- Search permission for a research pass → rebuilds targets 1 to 3: a values cheat sheet only if a loop source establishes a values round, the loop structure, and the CO bank. A deeper pass is also available, up to 6 more searches and 2 more fetches, several more minutes. Say so if you want it.
- The playbook itself, or notes from the roadmap-input sessions → upgrades F3, F7 and F8 from quoted sentences to inspectable proof, and makes B4, B5 and D3 answerable with specifics.
