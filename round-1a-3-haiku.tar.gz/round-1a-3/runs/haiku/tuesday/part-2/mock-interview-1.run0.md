I couldn't run the web searches: the permission for them was denied, so I'm building the pack from your notes alone. I'll write the pack file now.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-1-denied-39891aa5/c0f82a71-eeac-4959-ac7e-e054563497de/scratchpad/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer conversation with Dan, since you described him as a peer.

Web search was refused, so nothing about Northwind's values, interview process, or Dan's public footprint is verified. Everything about them comes from your message. The pack marks where that matters.

**What's in it**
- **Fit snapshot:** seven rows. Each JD highlight is matched to a quote from your notes on Priya. Every row needs her to confirm it, because the notes are your summary, not her CV or her own words.
- **Persona weights:** Peer Evaluator 5, Data-Driven Prober 4, Case/Strategist 3, Skeptic 3, Pressure 2, Conversational 2, Values 2. The Prober weight reflects Dan's "relentlessly data-driven" profile, and the Case tilt toward pricing reflects his pricing background.
- **21 questions:** each has a type tag, provenance, answer guidance, and a rationale. Guidance is tied to Priya's own sentences, and anything she has not said is left as an answer slot.
- **Reverse questions:** six, including one tied to Dan's pricing and startup background and one reciprocity question for a peer.
- **Prohibited claims:** inflated versions of her stronger-sounding claims, such as "owned a GTM strategy" or "caused the ~$400M uplift." None of these may be coached.

**Where the risk is**
- **Highest-ROI prep is D1:** "When have you owned a go-to-market plan, from the first decision through launch?" It hits the headline JD requirement, where her evidence is thinnest.
- **The $400M figure gets three questions** (B1, B2, E2), because it is the most likely place for Dan to test attribution.
- **Quota and sales-ops experience:** your notes say she has none, but that is not in her own words, so the pack doesn't ask her to acknowledge it. Confirm it with her first.

**Choices I made**
- I did not ask you any questions. Round type and relationship were already clear, and your JD highlights and background summary were enough to build on.
- The values cheat sheet is dropped, since no values page was verified.
- The CO questions use your research note on Northwind's priorities and the bundling threat. Check them against Northwind's own materials before the session.

I can run the pack's highest-priority question as a live drill, save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word. If you want, I can also run a deeper research pass once search permission is granted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer (both report to the same VP). **Round:** one 60-minute conversation.

**Built on:** your message (JD highlights, Priya's background summary, Dan's profile, your research note on Northwind). Search was refused, so no Northwind or Dan facts here are verified beyond what you supplied.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** her experience, probed for what was actually hers; **JD** the stated role requirements; **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Anything in *answer slot* form is an instruction for the interview, not a question to answer here.

## Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your notes on Priya. Her notes are your summary, not her CV or her own words, so every row needs her to confirm it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [grounded] | transferability | Your notes show product strategy and ops, not a go-to-market plan she owned. Say the product-strategy work in those terms. Answer slot: if she owned a go-to-market plan, say from which decision to which launch; if she did not, say so plainly and stay with the product-strategy work. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | low | [grounded] | transferability | Your notes say a revenue model used in negotiations, not a whitespace map across the customer lifecycle. The material does not show lifecycle work. Answer slot: if she has mapped where accounts sit across land, adopt, expand and renew, say how; if not, say the model is the nearest thing and what it covered. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [grounded] | none | The quote reaches the requirement in its own terms, but it is a self-described skill with nothing inspected behind it, so expect a probe. Upgrade: one analysis she ran herself, to walk through. |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | low | [grounded] | transferability | Adjacent work: partner-facing revenue modelling. Your notes do not show partner-motion design. Answer slot: if she designed how partners were engaged, say how; if the model was the part she built, say that and no more. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; reword only it: "I set annual volume targets with cross-org consensus." Expect a probe on how consensus was reached; the honest answer is her part in it. Confirm with her before rehearsing it. |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [grounded] | transferability | This is use, not building. Say what she uses the tools for, in those words. Answer slot: if she built something with AI, say what and whether she built it or only used it. |
| F7 | No JD requirement; a headline figure the interviewer will test — the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Your notes do not show how the figure was counted or how much of it was hers. Answer slot: defend-the-number, asked in her own words (bank B1 and B2). |

## Reading the interviewer

Public footprint only, and only what you supplied: a self-described "relentlessly data-driven" profile, a career spine in pricing and monetization roles, and one early-stage startup chapter. Nothing was verified.

- **Expect every figure probed to its assumptions.** Bank B is weighted up for this reason.
- **Pricing and monetization is his native language.** Tilt the case questions toward pricing, packaging and unit economics (C2).
- **The startup chapter means builder stories land.** Expect skepticism about big-company pace and a probe on whether Priya's work was scrappy or process-heavy.
- **Mirror opportunity (professional path, not identity):** his pricing and monetization background and her "built a partner-level revenue model used in carrier negotiations" (F2) are a comparable domain. Use it only as a shared domain, never as shared background.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, credit-sharing, disagreement with equals | High. Peer is the strongest relationship prior for this persona. | Reciprocity framing; propose seam principles rather than claim a seam. | 5 |
| Data-Driven Prober | Denominators, assumptions, "walk me through how that was counted" | High. His self-described profile raises this persona up. | Name the weakest assumption before he does; say plainly what she does not know. | 4 |
| Case / Strategist | Whitespace across the lifecycle, a live expansion drop, company trade-offs | Medium-high. The JD asks for whitespace and analysis; his pricing lens tilts the cases. | Clarify, then structure, then one metric per stage. | 3 |
| Skeptic | GTM ownership, partner design, the SQL and Tableau claim | High. These are the gaps the fit snapshot finds. | Rehearse the single most predictable objection (D1) until it is routine. | 3 |
| Pressure | "How much of that was actually you?" | Medium. A peer conversation rarely times out, but the ~$400M figure invites the test. | Hold through two follow-ups, then concede only what is true. | 2 |
| Conversational | A journey opener and a casual AI question | Medium. Openers are scored. | A 90-second arc drawn from her notes. | 2 |
| Values / Behavioral | Cross-functional influence stories | Low. No values round is established, so the weight is flat and kept low; the JD's cross-functional line still raises the theme. | STAR-shaped stories; the honest branch when none comes to mind. | 2 |

**Why these weights:** the relationship prior for a peer sets the start. No loop source establishes the loop, so the archetype fallback applies: a generic loop with flat weights, said plainly. The weights rest on the peer prior, not on Northwind's documented process.

## Question banks

Coverage line: JD requirements to question IDs. Where a requirement has no question, the reason is given.

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | D1, A4 (fit rows F1) |
| identify whitespace across land/adopt/expand/renew | C1 (fit row F2) |
| run independent analysis in SQL and Tableau | B3 (fit row F3) |
| partner-motion design experience required | D2, A3 (fit row F4) |
| strong cross-functional influence | A2, V1 (fit row F5) |
| AI experience a plus | G2 (fit row F6) |
| Headline figure, not a JD line | B1, B2, E2 (fit row F7) |
| Any other requirement | None: only the highlights were supplied, so mid-list items may be missing. Upgrade: full JD text. |

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where does your work sit next to mine, and what happens when we disagree about the seam?" | JD | [generic] | Propose seam principles, not a seam you claim to know: name what you would take to the peer first and how you would settle a disagreement with an equal. Say what you would bring to their team. | Peer prior; the cross-functional requirement (F5) raises the theme. Generic because it is a stem, not a fact about this team. |
| A2 | "You set annual volume targets with cross-org consensus. How did you get those orgs to agree?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story-mapped on F5: the targets, and the consensus across orgs, in her words. Answer slot: if the orgs disagreed, say where and how it resolved; if she carried the consensus-building herself, say what she did; if not, say the targets were set with others and what her part was. | F5 is the strongest cross-org evidence; EXP because it tests what was hers. |
| A3 | "Walk me through the partner-level revenue model. Who used it, and for what?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Story-mapped on F2 and F4: she built the model; it was used in carrier negotiations. Answer slot: if the model shaped the partner terms, say how; if it informed the negotiations without deciding them, say that. | The peer will test whether the model made partner decisions; partner-motion design is required (F4). |
| A4 | "Two new product lines need a go-to-market plan owned end to end. What would you do in the first thirty days?" | JD | [generic] (question); "9 at a large consumer-tech company in product strategy & ops" — the coach's notes (the one past sentence this guidance points to) | Structure, don't recite: what she needs to know, who she talks to, which decisions come first. Point to the product-strategy work only in its own words. | JD headline (F1). A plan question, so generic; the one past reference is quoted. |
| A5 | "When a launch spans both our teams, how do you handle credit?" | VAL | [generic] | Say who did what: first person for her contribution, "we" for the context. Answer slot: give a case where credit was shared and how she raised it, if she has one; if not, say how she would handle it. | A peer credit probe; no claim about her past. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Defend-the-number, in her words. Answer slots: how the figure was counted; what it is sensitive to; which part was hers. If she does not know how it was counted, she says so plainly. | Headline figure (F7). Probers test the counting first. |
| B2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Weakest-assumption move: name, before he does, the assumption she would defend least. The pack names none; if she knows one, she says it; if not, she says so. | Turns a gotcha into a credibility gain. |
| B3 | "When did you last run an analysis in SQL or Tableau, and what did it change?" | JD | [grounded] "skilled in SQL/Tableau" — the coach's notes | Open prompt. Answer slot: if she has one, walk the question, the data, the check and the result, in that order. If none comes to mind, say so plainly and name the first analysis she would run for this role. | F3, a probe for an artifact. |
| B4 | "How was the partner-level revenue model built, and what would you defend least about it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Walk the build in order, then the weakest assumption in the model, in her own words. If she cannot name one, she says so. | Premised only on the quote's "built". Tests the model she is most likely to be asked about. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you identify whitespace across land, adopt, expand and renew for a new product line?" | CASE | [generic] | Clarify first: what the product line is for, who buys it, what whitespace means for the decision. Then segment across the four stages, one metric per stage, and the main risk. | JD headline, as a live problem. Presupposes nothing about her past. |
| C2 | "A new product line's expansion rate drops twenty percent in one quarter. Diagnose it." | CASE | [generic] | Clarify, then split the drop by cohort, price and packaging before channel. Test packaging and unit economics early. | A time-boxed challenge. Tilted toward pricing for this interviewer. |
| C3 | "Enterprise expansion, the Compass copilot launch and profitability all compete for GTM effort. Where would you start, and why?" | CO | [grounded] "enterprise expansion"; "an AI copilot launch ('Compass')"; "reaching profitability" — your research note | Name the trade-off once, pick one, name its cost. Do not claim knowledge of internal priorities. Second beat, if he moves to it: a response to "bundling by a much larger platform vendor", not a memo. | Your note supplies the priorities and the threat. Unverified: confirm them against Northwind's own materials before the session. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "When have you owned a go-to-market plan, from the first decision through launch?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | **Highest-ROI prep in this pack.** This is the biggest gap, and the question will come in some form. Answer slot: if she did, say from which decision to which launch; if she did not, say so plainly in her own words, then go to the product-strategy work. Hold through two follow-ups by returning to what the notes carry; never add a launch. | F1, the headline requirement with the thinnest evidence. A rehearsed non-defensive answer changes the interview. |
| D2 | "Partner-motion design is required for this role. Is the partner revenue model the same thing?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Answer slot: if she designed how partners were engaged, say how; if the model was the part she built, say that. Do not call the model a partner motion. | F4. |
| D3 | "On day one, which part of this job would you be weakest at?" | JD | [generic] | Name the weakest JD line your notes show least evidence for, in her words. Then a ramp: what she would learn first and from whom. | Persona stem; a Skeptic question whose answer is her own assessment. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run this function?" | JD | [grounded] "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, restate, then hold: what she has on record is the cross-org target-setting and the partner model. Concede only what is true: name the specific part of this function she has not run, in her own words. | Persona stem. The question presupposes another candidate; she does not assert that anyone exists. |
| E2 | "That result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold: she proposed the store-surface change; say that first, in those words. Concede: if she does not know how the uplift was split between the change and anything else, say so, exactly and only if that is true. Never claim more than "proposed". | Hold-then-concede. The most likely form of the attribution probe. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | CO | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" — the coach's notes | A pre-scripted 90-second arc in order: consulting, then product strategy and ops, then the partner model. Each beat is a clause the quoted sentence states, in her words. Stop at the partner model; do not pitch the role. | An opener that is still scored. The arc rests on the three notes. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — the coach's notes | Name the tools and what she uses them for, in her words. Answer slot: if she has built something with AI, say what, and whether she built it or only used it. | The JD's plus-skill, asked casually. Bridge F6. |

### V. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you moved a cross-functional group to a decision it did not want to make." | VAL | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes; JD raising source: "strong cross-functional influence" — JD highlights | Open prompt. Selection scaffold: a time with a named stake, a point where she did not fold, and a relationship intact at the end. If the nearest is the volume targets, say how the consensus was reached and her part in it. If none comes to mind, say so plainly. | The cross-functional requirement (F5). No values round is established, so the theme comes from the JD. |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Select: a truth the leader did not want to hear, what she said, what happened next. The pack supplies no event. If none comes to mind, say so plainly and give the nearest thing she has. | A stem; generic, since the pack has no story for her here. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization. Which part of that does the sales-strategy seat use most?" | Ties to his own path. It turns an interview into a peer conversation. |
| R2 | "What did an early-stage team teach you about go-to-market that a larger one hides?" | Asks about his startup chapter, which he will answer from his own experience. |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, for a peer. |
| R4 | "Enterprise expansion, the Compass launch and profitability all compete for effort this year. Which one is hardest to hold in the same quarter?" | Built from your research note, which is unverified. Shows she has read the priorities, and asks where the real trade-off lies. |
| R5 | "When a much larger platform vendor bundles into the category, what changes first on your side?" | Built from your research note's bundling threat. Tests the competitive frame without claiming any internal knowledge. |
| R6 | "For the two new product lines, what would success look like at twelve months, and who signs it off?" | Draws on the JD's headline; the answer defines what the role owns. |

## Prohibited claims

Built locally from the fit snapshot. None of these may be coached, asserted or implied in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a go-to-market strategy for two product lines | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's own observation: the notes say product strategy and ops. |
| Built a whitespace or lifecycle map | Inflated form of F2 | F2's quote at its own scope: a revenue model used in negotiations. |
| Designed the partner motion | Inflated form of F4 | F4's quote, plus the answer slot on what was hers. |
| Ran SQL and Tableau analysis end to end | Inflated form of F3 | "skilled in SQL/Tableau", at its own scope. |
| Caused the ~$400M ARR uplift | Inflated form of F7 | "proposed a store-surface change credited with a ~$400M ARR uplift", at its own scope. |
| Built AI products | Inflated form of F6 | "uses AI tools daily". |
| Any first-person negative about quota-setting or sales-ops | Stated only in your notes, not in her words | No words for her from this source. Confirm with her before she rehearses any plain acknowledgment on it. No question in the pack puts it to her. |

## Sources

- **Provided:** your message: the six JD highlights, Priya's background summary, Dan's profile, the round description, and your research note on Northwind (three priorities, the bundling threat).
- **Searches sent:** three, all refused (search permission was not granted): "Northwind Data values operating principles"; "Northwind Data interview process sales strategy"; "Dan Kovac Director of Sales Strategy Northwind Data". **Fetches:** none.
- **Research tier:** L1 — searches 3 of 6, fetches 0 of 2; user links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet dropped: no values were established, and the search was refused. |
| 2. Northwind interview process | unavailable | Loop structure: no loop source establishes it, so the archetype fallback applies (flat weights, said plainly). |
| 3. Northwind strategy / recent news | unavailable | Not sent after the refusal. The CO bank (C3, R4, R5) draws on your research note, unverified. |
| 4. Dan Kovac, Northwind | unavailable | The interviewer read rests on your profile, unverified. A public footprint would move the weights and reverse questions. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot; a representative posting would add nothing that the highlights do not. |

## Upgrade menu

- **Full JD text** → the mid-list requirements get questions, and the coverage line is rechecked for any quota or pricing item the highlights leave out.
- **Priya's CV, in her own sentences** → F1 to F7 quote her CV instead of your notes, and their confidence bands can move.
- **Priya's confirmation of the three metrics and the consensus claim** → F5 and F7 move from your notes to her words.
- **One SQL or Tableau analysis she ran herself** → F3 moves to a verifiable band, and B3 gets a real answer.
- **Dan's public talks and writing**, once search is allowed → his recurring themes become questions, and the persona weights and reverse questions are tailored.
- **Northwind's published values page** → the values cheat sheet, mapped to V1 and V2.
- **Your recruiter's note on the session** → confirms one 60-minute session and any topic focus.
- **A deeper research pass**: up to 6 more searches and 2 more fetches, several more minutes. Want it?

