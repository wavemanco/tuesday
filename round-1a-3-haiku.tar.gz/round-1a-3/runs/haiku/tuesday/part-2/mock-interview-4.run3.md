Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-4-denied-93782944/86097ff8-705b-4a30-9f06-1c980a91be83/scratchpad/quartzline_platform-apis-pm_interview_pack.md`. I built it for the hiring-manager round you described. Web search was refused in this session, so the pack has no Quartzline values, loop structure or strategy in it. The upgrade menu says what that would add.

**Start with A1.** The dossier named the objection, "You have never held the PM title or owned a roadmap…", as the highest-return rehearsal. The answer opens with a plain acknowledgment, then the integration work at its own scope, then the roadmap gap named before they press on it. Rehearse it aloud three times. Next, practice A5, the squad-authority question. The dossier lists decision rights against the two squads as its top unknown, and the JD raises it.

**Watch the 30+ figure.** C1 and C2 cover how you counted the integrations and which assumption you'd defend least. Have that answer ready before anyone asks.

The pack keeps every bridge framed as adjacent. It also treats the three prohibited claims from the dossier as off-limits, including the title and the roadmap.

The dossier is dated 2026-08-14, about three months old. Check the current posting text before Thursday in case the role has changed.

Offers, none pushed:
- Want me to play the Skeptic on A1 now? That's the drill.
- I can also save a `tuesday-dossier.md` with a `pack_feedback` section recording what this prep exposed.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-apis-pm_interview_pack.md -----
# Quartzline: Product Manager, Platform APIs. Hiring-manager prep pack

**Round:** hiring manager, 45 minutes, Thursday. **Interviewer:** not named. **Relationship:** hiring manager.
**Built from:** the pasted dossier (version 1.1, dated 2026-08-14), your round description, and no web research (see Sources).

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse the words only where they describe what you actually did.

## Prep triage

Prep time is about six days. In order:

1. **A1**, aloud, three times, until the plain acknowledgment and the adjacent case come out in one breath. This is the objection the dossier named as the highest-return rehearsal.
2. **A5** and **B2**: decision rights against the two engineering squads. The dossier lists this as its top unknown, and the JD raises it.
3. **C1** and **C2**: how you counted the 30+ figure, and which assumption you would defend least.
4. **D1**: the sixty-second answer and holding it through two follow-ups.
5. **B1** and **E2**, once each, for the diagnostic case and the docs-and-schemas question.

Everything else is insurance.

## Fit snapshot

No gate rows: the dossier's `hard_gates` list is empty and the material shows no gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience". Dossier, role profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. "Wrote the internal integration playbook her team uses". Dossier, verified evidence 2. | low | [grounded] | transferability | The material shows integration leadership at that scope. The years in the requirement are product-management years, and the material does not show them. Say it at the quote's scope: "I led the end-to-end work on those integrations, from scoping to go-live." Answer slot: if any of your work was product work, say which, in your own words; if none was, say so and stay with the integrations. |
| F2 | "Shipped API or platform products". Dossier, role profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. | high | [grounded] | transferability | The material shows integrations taken to go-live for clients. It does not show a product you shipped. Say it at that scope: "I led integrations of the vendor's REST APIs through to go-live." Answer slot: if you made a product decision inside those integrations, say which; if you did not, say so. |
| F3 | "Technical fluency: API docs, schemas". Dossier, role profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs". Dossier, verified evidence 1. "Wrote the internal integration playbook her team uses". Dossier, verified evidence 2. | high | [grounded] | none | The quotes reach REST API work and written integration docs in role-relevant terms. The material does not show schema tooling, so expect a probe there (E2). |
| F4 | "Stakeholder management across engineering, sales, customers". Dossier, role profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. "Ran quarterly roadmap-input sessions feeding client evidence to product". Dossier, verified evidence 3. | medium | [grounded] | transferability | The material shows client and product work. It does not show engineering or sales stakeholders. Bridge at the quotes' scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The roadmap-input quote is confirmed with limited inspectable proof, so name that limit yourself. Answer slot: if you managed a sales commitment or an engineering constraint on an integration, say how; if you did not, say so. |
| F5 | "Agile delivery experience". Dossier, role profile R5 (preferred) | none given | low | [grounded] | discovery | Nothing in the material speaks to agile delivery inside a product organization. The words are an answer slot. See A4. |
| F6 | "Own the roadmap for the partner-facing API platform". Dossier, role profile responsibilities | none given | none | [grounded] | capability | The dossier records this absence, in its `uncertain_or_weak_areas` acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)". Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. |

**Pack observation:** the material is silent on decision rights against the two squads. That is not a claim about the candidate. It is the question A5 and F1 are built to test.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced entry: dossier `prohibited_claims`, item "Having held a product manager title or role" | Plain acknowledgment, sourced to that field: "I haven't held the product manager title." Then the adjacent case at its own scope. No slot about the title itself. |
| Having owned a product roadmap | Sourced entry: dossier `prohibited_claims`, item "Having owned a product roadmap" | Plain acknowledgment, sourced to that field: "I haven't owned a product roadmap." Then the ramp, as a plan. |
| Having set prioritization for an engineering squad | Sourced entry: dossier `prohibited_claims`, item "Having set prioritization for an engineering squad" | Plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." Then the principles you would propose (F1). |
| Shipped an API product | Inflated form of F2: the requirement "Shipped API or platform products" widens the integration quote | F2's quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs". Pack observation, not a first-person negative: the material shows integrations taken to go-live, not a shipped product. |
| Ran the roadmap | Inflated form of F4: "Ran quarterly roadmap-input sessions feeding client evidence to product" widened into roadmap decisions | The quote at its own scope. Pack observation: the material shows input sessions feeding product, not decisions made by you. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Quiet, persistent probing of the roadmap gap and the title history. Asks why you, why here, why now. | Top weight. The relationship prior for a hiring manager is Case plus Skeptic, and the hiring manager is buying a capability and derisking gaps. The dossier names the objection the Skeptic will raise. | Rehearse A1 until it is plain. Bridge only from the quotes. Calibrated candor, not bluffing. |
| Case/Strategist (weight 3) | Live problems on the role's actual responsibilities: partner adoption, partner conflicts, squad disagreements. | Hiring-manager prior. The JD's responsibilities are the live problems. The company's roadmap is not in the material, so these are generic. | Clarify, then structure, then metrics. Ask who decides before you decide. |
| Data-Driven Prober (weight 3) | Asks how the 30+ figure was counted, and what it is sensitive to. | The figure is on the record, and the dossier marks the roadmap-input line as medium confidence. | Say how you counted, what you do not know, and the assumption you would defend least. |
| Pressure (weight 2) | Time-boxed challenge on the years gap and on whether the 30+ was yours. | Lower weight. Hiring managers use pressure on the one thin area, which is the years. | Pause, restate, hold through two follow-ups, concede the roadmap gap explicitly. |
| Conversational (weight 2) | A casual biography opener, and a casual question on API docs and schemas. | Likely as an opener. Treat the casual question as scored. | A 90-second arc built from three quotes. |
| Peer Evaluator (weight 2) | Seam questions about the squads, and a stakeholder scenario across sales, engineering and customers. | The hiring manager stands in for the squads' seam in this round. | Propose seam principles, not a split you cannot know. |
| Values/Behavioral (weight 2) | Open prompts on unpopular truths and customer-first decisions. | No values-style round is detected. No loop source establishes the loop, so this is a persona fit, not a published value. | Selection scaffolds with their honest branch. |

**Loop:** no loop source establishes the loop. Persona weights therefore follow the relationship prior for a hiring manager, and the loop is not assumed.

## Question banks

Ordered by weight. **A1 is the highest-return prep in the pack.**

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Own the roadmap for the partner-facing API platform". Dossier, role profile responsibilities. "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. Acknowledgment sourced to dossier `prohibited_claims`: "Having held a product manager title or role"; "Having owned a product roadmap". | The underwriter named this objection, and it will come in some form. Open with the plain acknowledgment in one sentence: "I haven't held the product manager title, and I haven't owned a product roadmap." Then the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Name the limit before they do: roadmap authority is the part you are least able to cover. Then the ramp, as a plan and never as a past: what you would need to learn in the first weeks, and from whom. Hold the adjacent case through two follow-ups. Concede the roadmap gap explicitly and specifically. Do not fold into "I could do it." | The dossier's named objection, given the deepest rehearsal. It presses R1 and the roadmap sub-claim (F1, F6). Its negatives have the dossier sources the rubric requires. |
| A2 | "Tell me about an API platform you've shipped, or how close you've come to shipping one." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. Open prompt; theme from the JD line "Shipped API or platform products". | Story-mapped on F2: the integrations, taken to go-live, at the quote's scope. Name the integrations, the scope and the go-live in your own words. Answer slot: if you made a product decision inside those integrations, say which; if you did not, say so and name the closest thing to a shipped platform. Never call the integrations a platform product. | F2 is transferability. R2 is the requirement this question scores. |
| A3 | "Why leave client-facing integration work for a product role, and why now?" | EXP | [generic] | Give your own reason in your own words. The material does not state one, so this slot is yours entirely. Say what drew you to platform APIs and this role, and why now. Do not borrow the JD's wording as your motive. | The Skeptic's motivation probe. It makes no claim about your past, so the guidance makes none. |
| A4 | "Tell me how you've worked in agile delivery inside a product organization." | JD | [grounded] "Agile delivery experience". Dossier, role profile R5 (preferred). | Clarify strategy. No verified evidence speaks to agile delivery, so nothing is quoted here. Answer slot: if you worked in a sprint-based team that delivered product work, say how; if you never worked inside that cadence, say so plainly, and say what you would want to confirm about how this team defines agile delivery. | R5 is discovery, low confidence. The dossier allows a clarify strategy only. |
| A5 | "On the last API you took to go-live, which decisions were yours, and which did the engineering squads make?" | JD | [grounded] "Write specs and drive delivery with two engineering squads". Dossier, role profile responsibilities. "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. | This is the squad-authority probe the pack was asked to drill, and the decision rights are not in the material. Answer slot: name the decisions you made on that integration, in your own words, across scoping, requirements, architecture and UAT. If the architecture or the release call was the squads', say so. If a call was not yours, say so plainly. Do not claim the squads' decisions, and do not claim authority over engineering priorities. If they press on who decides, give the answer you gave, not a new one. | The dossier's top unknown and the opportunity risk. The JD's squad line raises it. The question asks which decisions were yours, not what authority you hold. |

### B. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose partner adoption of the API platform flattened after launch. Walk me through how you'd diagnose it in your first 30 days." | CASE | [generic] for the diagnosis. Raising source: "Define and track adoption metrics". Dossier, role profile responsibilities. | Clarify first: what counts as adoption, and how it is measured today. Ask it aloud. Then the objective, the segmentation by partner type, the approach, the metrics and the risks. Think aloud, and challenge one premise respectfully. Do not refer to any past diagnosis. | The adoption-baseline question is the dossier's second unknown. The case shows how you would close it. |
| B2 | "Two integration partners want conflicting changes to the same API. One is your largest account. How do you decide?" | CASE | [generic]. Raising source: "Run discovery with integration partners". Dossier, role profile responsibilities. | Structure: first ask whether this call sits with you or with the squads. Then criteria, what you would test with the partners, and the decision you would escalate and to whom. No past example. | Covers partner discovery and decision rights in one live problem. |
| B3 | "A squad lead says a deprecation isn't worth the partner churn. You think it is. What do you do?" | CASE | [generic]. Raising source: "Write specs and drive delivery with two engineering squads". Dossier, role profile responsibilities. | Separate the facts of the disagreement from the decision. Propose a way to test the churn with partner data. Say where the decision sits, and escalate if it does not sit with you. Stay calibrated. Do not reach for a past example. | The squad-authority question in case form. It asks about a live problem and presupposes nothing about your past. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. | Answer slot. Say how you counted them, in your own words: the definition of an integration and of go-live that you used. If you did not count against a fixed definition, say so plainly and say what the figure is. Name the weakest assumption you know before they do. Do not supply a definition. | The headline figure. The defend-the-number slots apply, and the figure is the dossier's verified claim. |
| C2 | "Which assumption behind that 30+ would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. | Weakest-assumption move. Name, in your own words, the assumption you would defend least. If you cannot name one, say so. | The Prober's standing stem, applied to the figure on the record. |
| C3 | "Did the client evidence from those sessions change a product decision, and how would you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product". Dossier, verified evidence 3, confirmed with limited inspectable proof. Raising source: "Own the roadmap for the partner-facing API platform". Dossier, role profile responsibilities. | Answer slot. Volunteer the limit first: the sessions ran and fed client evidence to product, and the proof of what they changed is limited. If you tracked what changed, say how you knew. If you did not track it, say so, and say what the sessions did show. | The medium-confidence seam. The dossier's caveat says a prober will find it, so the limit goes first. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate with three years of the actual job?" | JD | [grounded] "3+ years product management experience". Dossier, role profile R1. "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. "Wrote the internal integration playbook her team uses". Dossier, verified evidence 2. | Pause, then restate the question. Hold: the adjacent case at its scope. "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live, and I wrote the internal integration playbook her team uses." Hold through two follow-ups. Concede explicitly: "I don't have three years of product management, and the roadmap part is one I haven't done." Do not argue the years away. Do not say you would outperform the other candidate. | Hold-then-concede on the single thinnest area, R1. |
| D2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. | Hold to the verb: the quote says led. Name which stages you led end to end and which others carried, in your own words. Answer slot: if others led some integrations, say which stages were yours; if you led the full sequence on each, say so and say how you would show it. | The attribution probe. The verb is the position to hold. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Dossier, verified evidence 1. "Wrote the internal integration playbook her team uses". Dossier, verified evidence 2. "Ran quarterly roadmap-input sessions feeding client evidence to product". Dossier, verified evidence 3. | A 90-second arc in three beats, each taken from a quote: the integrations, the playbook, the roadmap-input sessions. Then the bridge to this role, stated as what you are asking for, not as a claim. Do not add a fourth beat. | A pre-scripted biography. The casual register is still scored. |
| E2 | "What are you actually playing with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses". Dossier, verified evidence 2. "Led 30+ end-to-end client integrations of the vendor's REST APIs". Dossier, verified evidence 1. | Answer with what the quotes carry: REST integration work and the written playbook. Answer slot: name any schema or documentation tools you have used, in your own words. If you have not used schema tooling, say so plainly. | R3 coverage. The material shows REST integration and written docs, not schema tooling. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where would prioritization sit between you and the engineering squads?" | JD | [grounded] "Write specs and drive delivery with two engineering squads". Dossier, role profile responsibilities. Acknowledgment sourced to dossier `prohibited_claims`: "Having set prioritization for an engineering squad"; "I haven't set prioritization for an engineering squad." | Propose principles, not a split you cannot know. For example: keep the roadmap call and the delivery call separate, and take the squads' input before a priority changes. Plain acknowledgment first. Then say the decision is one you would confirm with the hiring manager. | The seam question. The dossier names this as the unknown. |
| F2 | "Tell me about a time you worked between a customer and the internal teams on the same integration." | JD | [grounded] Open prompt. Theme from the JD line "Stakeholder management across engineering, sales, customers". Dossier, role profile R4. | Selection scaffold: pick an integration where a customer and the internal teams all had a stake. If you cannot name one where they were all in the room, say so plainly, then give the nearest thing your material carries: the client integrations, and the roadmap-input sessions that carried client evidence to product. | R4 coverage. The open prompt needs an honest branch, because the material does not show engineering or sales stakeholders. |

### G. Values/Behavioral (weight 2)

No values-style round is detected, so there is no values cheat sheet. These two questions are persona fits.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something about an integration they did not want to hear. It needs a named stake, the moment you said it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A persona stem. No published value is at stake. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick the nearest integration where a client's timeline and the internal plan pulled apart. If none did, say so plainly, then say how you would handle it. | A persona stem. The material carries no such decision, so the guidance makes no claim. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1, 3+ years product management experience | A1, D1 |
| R2, Shipped API or platform products | A2 |
| R3, Technical fluency: API docs, schemas | E2 |
| R4, Stakeholder management across engineering, sales, customers | F2 |
| R5, Agile delivery experience | A4 |
| Owning a roadmap and prioritization authority (R1 sub-claim) | A1, A5, F1 |
| Decision authority against the two squads (dossier unknown) | A5, B2, B3, F1 |
| Define and track adoption metrics (responsibility) | B1, C3 |
| Run discovery with integration partners (responsibility) | B2 |
| The dossier's named objection | A1 |

## Reverse questions

Every question below is one to ask the hiring manager. None of them checks an invite or asks for contact details.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it asks the dossier's top unknown directly, and the answer decides whether you would accept.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the JD names adoption metrics and the material gives no baseline. The answer shows what B1 would look like in practice.
3. **"Which two engineering squads are in scope for this role, and what is each one working on right now?"** Why it lands: it grounds the squad seam that F1 and B3 rehearse, and it shows how much of the roadmap is already set.
4. **"Where has agile delivery worked well between product and engineering here, and where has it not?"** Why it lands: R5 is unclear in the material. The answer shows whether the cadence exists before you are asked to run it.
5. **"What would success look like at six months, in measures you'd check?"** Why it lands: it asks for the measure the role is judged on, and it gives you the adoption target to test against.
6. **"What did the last person in this role get right, and what would they do differently?"** Why it lands: it sets the first-ninety-days expectation from someone who held the role.

## Sources

- **Provided documents:** the dossier pasted into your message, version 1.1, dated 2026-08-14. Consumed sections: `role_profile` (requirements, responsibilities and unknowns), `handoff_to_mock_interview` (verified evidence, weak areas, the named objection, risks, employer questions and prohibited claims), and `decision` (context only). The dossier has no `evidence_map` or `evidence_state`.
- **Freshness:** the dossier is about three months old. The role may have changed since. Check the posting text before the round.
- **Searches sent:** "Quartzline values" (refused). "Quartzline interview process product manager" (refused). "Quartzline strategy news" (refused). Web search was refused by the session's permission setting. No results came back, so nothing from them is used.

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet not built: no values-style round is detected, and the company's values page was not read. Would have moved the VAL bank's mapped stories. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure. No loop source establishes the loop, so persona weights use relationship priors only. Would have moved the persona weights and whether a values round exists. |
| 3. `Quartzline strategy` / recent news | unavailable | The CO bank is absent, and B1 to B3 are generic. Would have moved the CO and differentiator questions. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- Your recruiter's note on the round format, in one email → confirms whether the loop has a values or case session, and reweights the personas.
- Allowing web search, so the three refused targets can run → the company's values by name, the loop structure, and strategy-grounded CO questions.
- Quartzline's public values page, pasted → a values cheat sheet, and VAL questions tied to published values.
- The current posting text → checks R1 to R5 against the August dossier, since the role may have changed.
- Your CV → quotes your CV's own lines beside the three verified claims, so the evidence cells read from two sources.
- The interviewer's name → personalized persona weights, and a reverse question tied to their career path.
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → the strategy brief, interviewer talks, and recent org context. Offered once.
