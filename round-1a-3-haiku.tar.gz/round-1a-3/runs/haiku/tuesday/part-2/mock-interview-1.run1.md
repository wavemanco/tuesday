Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-1-denied-c61af06a/38d96227-3e58-4223-b3cc-d64876e60652/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it on your note alone: no CV and no full JD text. I treated Dan as a peer, as you described.

**What's in it**
- **23 questions across six personas.** The Data-Driven Prober and Peer Evaluator lead with five each. The Case/Strategist has four, tilted toward pricing and packaging, and the bundling threat and Compass are in the cases. The Skeptic, Pressure, Values and Conversational personas make up the rest.
- **Fit snapshot.** Each JD requirement is paired with a verbatim quote from your note, a confidence rating, a gap type and a bridge that stays at the quote's scope.
- **Highest-ROI prep (D1).** "You haven't run sales ops or quota-setting. Why should we trust the targets you would set?" It's the most predictable objection, since Dan runs sales strategy. Rehearse the plain acknowledgment, then the cross-org target story, and hold it.
- **Partner-motion design is the second real gap.** The JD requires it, and the material shows only a partner revenue model. B3, D3 and the first answer slot on F1 cover it.
- **Prohibited claims.** Seven inflated forms are listed, including "drove the $400M" (her note says "credited with") and "designed the partner program."
- **Reverse questions.** Six, including one tied to Dan's pricing career and his startup chapter, and one reciprocity question for a peer round.
- **Requirement-coverage table.** Each JD requirement maps to the question IDs that cover it.

**Things to check**
- **Research didn't run.** The host refused both web searches, so the interviewer's public footprint and Northwind's interview process are unverified. The pack says so in its Sources section.
- **The sales-ops gap is from your note, not a JD line.** The JD highlights don't mention quota work, so I inferred it from the sales-strategy role. Confirm with Priya that "No classic sales-ops or quota-setting experience" is her own statement.
- **Quotes come from your summary.** Once you send her CV or the full JD, I can swap in verbatim quotes and re-grade the rows marked inferred.

The pack's own watch-out line:

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Three questions to finish the pack:
1. Does Dan's round include any recruiter focus areas or a deliverable such as a take-home or presentation?
2. Can you send the full JD text, or the posting link?
3. Should I retry research once web search is allowed? That would cover the interviewer's public footprint and the interview process.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer, both reporting to the same VP. Format: one 60-minute conversation. Candidate: Priya.

Built from your note only. No CV or full JD text was provided, so requirement quotes are from your JD highlights and evidence quotes are from your note. Upgrade menu at the end.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (behavioral and values), EXP (your own past work), JD (the listed requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- Question IDs are letter-by-persona (A1, B2, D1…) so you can reference them in a drill.

## Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your note. Confidence grades your evidence; provenance grades what this pack says about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" (JD highlights, your note) | "built a partner-level revenue model used in carrier negotiations" (your note) | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not partner-motion design. Bridge at that scope only: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you designed any incentive, enablement or channel term yourself, say which and how you decided; if the model was the extent of it, say so plainly. |
| F2 | "own GTM strategy for two new product lines" (JD highlights, your note) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your note) | medium | [grounded] | transferability | Product-strategy work with a large credited result. It does not show that you owned go-to-market for a product line. Bridge at scope: "I proposed a store-surface change." Answer slot: if you set the go-to-market for any product you launched, say which and how you decided; if not, say so and describe the product strategy work. |
| F3 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | "built a partner-level revenue model used in carrier negotiations" (your note) | low | [inferred] | discovery | The model touches revenue, but nothing in the material shows a whitespace analysis across the lifecycle. Answer slot: if you sized an opportunity by lifecycle stage, say how; if not, say what you would measure first. |
| F4 | "run independent analysis in SQL and Tableau" (JD highlights, your note) | "skilled in SQL/Tableau" (your note) | low | [inferred] | discovery | "Skilled" is a self-rating with no analysis behind it. Answer slot: name an analysis you ran yourself, end to end; if you have used the tools without running one, say so. |
| F5 | "strong cross-functional influence" (JD highlights, your note) | "set annual volume targets with cross-org consensus" (your note) | medium | [grounded] | none | Reaches the requirement in role-relevant terms. Expect a probe on how the consensus was reached. Lead with the quote's own terms: you set the targets, with consensus across orgs. |
| F6 | "AI experience a plus" (JD highlights, your note) | "uses AI tools daily" (your note) | low | [inferred] | transferability | Daily use is adjacent to building with AI, not the same thing. Bridge at scope: "I use AI tools daily." Answer slot: if you have built anything with AI, say what; if not, say so. |
| F7 | Sales-ops and quota-setting experience (expected from a sales-strategy role; not in the JD highlights, so inferred) | "No classic sales-ops or quota-setting experience" (your note) | none | [grounded] | capability | A stated absence, and it will be probed: the interviewer runs sales strategy. Words: "I haven't run classic sales ops or quota-setting." Then the nearest thing you did, F5's quote, at its own scope. Never a claim to quota work. |

Seven rules the columns hold: confidence, gap type and provenance each take one token; evidence cells hold only quoted sentences; requirements are quoted only from supplied text; qualifiers sit in the last column; gap rows get words only from a stated negative or an answer slot; gap types follow the evidence cell; bridges are spoken, so each clause must trace to a quote.

## Prohibited claims

Not to be coached in any answer, slot, hold or rationale. Built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed the partner program or partner-motion design | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: the material shows a revenue model, not a program. |
| Owned GTM for product lines | Inflated form of F2 | F2's quote at its own scope. |
| Drove the $400M ARR | Inflated form of F2 ("credited with" becomes "delivered") | "Proposed a store-surface change credited with a ~$400M ARR uplift," with the credit kept as the sentence states it. |
| Set the volume targets alone | Inflated form of F5 (drops "with cross-org consensus") | F5's quote, consensus included. |
| Ran independent analysis in SQL and Tableau end to end | Inflated form of F4 | "Skilled in SQL/Tableau," with the answer slot as the only route. |
| Built AI tools or copilots | Inflated form of F6 | "Uses AI tools daily." |
| Ran sales ops or quota-setting | Negative you stated, F7 | Plain acknowledgment: "I haven't run classic sales ops or quota-setting." No slot. |

## Grounding brief

Your note supplies Northwind's stated priorities and threat. Nothing here is researched; see Sources.

- Priorities, as you noted them: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability." [grounded] (your note)
- Main competitive threat, as you noted it: "main competitive threat is bundling by a much larger platform vendor." [grounded] (your note)
- Use the names as given. Do not claim anything about Compass's pricing, launch date or status; you have no source for it.

## Reading the interviewer

Public footprint was not searched (see Sources). This read is your note only.

- **Career spine:** pricing and monetization roles, with one early-stage-startup chapter. Quote from your note: "relentlessly data-driven" (self-description, your note).
- **Implications:**
  1. Expect every metric to be probed to its assumptions: the Data-Driven Prober bank carries the most weight.
  2. Case questions will lean toward pricing, packaging and unit economics; that is their native language. Tilt the CASE answers that way.
  3. Startup-chapter probes are likely. Builder stories land; expect a question about big-company pace.
  4. Peer register: they will ask what the hire adds to their load, not only what the candidate needs.
- **Mirror opportunity:** a shared domain, not a shared jump. Your revenue-model work sits near monetization: "built a partner-level revenue model used in carrier negotiations" (your note). Use it to talk the same language, not to claim their background.

## Persona table

Weights are relationship priors (peer: Peer Evaluator and Data-Driven Prober) adjusted by the interviewer signals above. No loop structure was found, so no round-specific weights apply.

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Denominators, assumptions, "how was that counted" | High. Peer prior plus "relentlessly data-driven" pushes it up. Your headline figures are the magnets. | Name the weakest assumption first; say plainly what you do not know about a count. | A1 to A5, 5 questions |
| Peer Evaluator | Seams between your teams and theirs; credit; disagreement | High. Peer prior, and their team's work sits beside yours. | Reciprocity framing; propose seam principles, not a seam you have not seen. | B1 to B5, 5 questions |
| Case / Strategist | Pricing, packaging and the bundling threat in live problems | High. Their pricing background and your note's priorities make it likely. | Clarify, then structure, then answer; challenge one premise. | C1 to C4, 4 questions |
| Skeptic | Quota-setting gap; partner-motion gap; whether the lifecycle work is run or analysed | Medium-high. The F7 gap is the most predictable objection. | Hold the honest limit; bridge only at quote scope; ramp plan. | D1 to D3, 3 questions |
| Pressure | Attribution of the $400M; the quota gap, held under pressure | Medium. Peer rounds rarely press hard, but attribution probes come up. | Pause, restate, hold through two follow-ups, concede specifically. | E1 and E2, 2 questions |
| Values / Behavioral | Unpopular truth; customer over metric | Low. No values round detected and no published values in hand. Included for coverage, labeled generic. | Selection scaffold ending in the honest branch. | F1 and F2, 2 questions |
| Conversational | The journey question; AI asked casually | Low-medium. Casual openers are still scored. | Pre-scripted 90-second arc; answer the AI question concretely. | G1 and G2, 2 questions |

## Question banks

Session total: 23 questions, within the 18 to 26 range. Question types are in the Type column; the coverage table after the banks maps the JD list to IDs.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2: you proposed the change, and the uplift was credited to it. Say how the figure was counted, in your words, and what it is sensitive to. Name the assumption you would defend least before they do. Answer slot: if you did the attribution yourself, say how; if the count was done by others or none of the method was yours, say so plainly and describe what you did propose. | The headline figure on your record; the defend-the-number slot. Type EXP because it tests what was yours. |
| A2 | "Which assumption behind the partner revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F1: the model, and its use in carrier negotiations. Name the input you trusted least, in your words. Answer slot: if you tested the inputs, say how; if you did not, say so and say what you would check first. | F1 is the partner-motion evidence and the likeliest place to be probed. |
| A3 | "Show me how you would find whitespace across land, adopt, expand and renew for a product with no installed-base history." | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | Live problem, no claim about your past. Structure: the lifecycle stages, the data each needs, where a whitespace estimate breaks, and which single number you would check first. | F3 is a discovery gap; this rehearses the answer before the probe. |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to result." | JD | [grounded] "run independent analysis in SQL and Tableau" (JD highlights, your note); [inferred] F4 "skilled in SQL/Tableau" | Open prompt: pick an analysis you ran yourself. Name the question, the data, the grain of the query, and what you did with the result. Answer slot: if you cannot name one you ran end to end, say so and describe the nearest analysis you did run. | The JD asks for independent analysis; the note gives only a self-rating, so the honest answer is the one you can show. |
| A5 | "What would you build with AI for a GTM team, and what would you not trust it to do?" | JD | [grounded] "AI experience a plus" (JD highlights, your note) | No claim about your past. Name one use you would pursue and one you would keep human, with the reason for each. | AI is a plus; a casual-sounding AI question here is still scored. |

### B. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where would our two teams' work seam, and what happens when you and I disagree on a call?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (your note) | Propose seam principles, not a seam you have not seen. Story-mapped on F5: you set the targets with cross-org consensus; name the orgs and the decision in your words. Answer slot: if there was disagreement on the way to consensus, say what it was and how you handled it; if there was none, say so. | Peer seam probe; the consensus story is the only disagreement-adjacent evidence in the material. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your note) | Open prompt on the store-surface change: you proposed it, and the credit followed. Beats the quote states: the proposal, the credit, who else owned the change. Answer slot: if you did the attribution, say how; if others did, say who. | Credit-sharing is a standard peer probe, and this story carries it. |
| B3 | "Tell me about a time you shaped how a partner was paid or incentivized." | JD | [grounded] "partner-motion design experience required" (JD highlights, your note); [grounded] "built a partner-level revenue model used in carrier negotiations" (your note) | Open prompt. Story-mapped on F1: the revenue model and its use in carrier negotiations, at that scope. Answer slot: if you designed an incentive, enablement or channel term yourself, say which and how you decided; if the model was the extent of it, say so plainly and say what you would design first. | F1 is the required-capability gap; this is where the partner-motion requirement presses. |
| B4 | "When you disagree with a peer on a call, what does it look like in practice?" | VAL | [generic] | Selection scaffold: pick a disagreement where you held a view and the outcome held up; name what you conceded. Honest branch: if none comes to mind, say so plainly, then give the nearest one. | Disagreement style with equals; no candidate claim in the guidance. |
| B5 | "How would you split ownership of expansion between a product team and a sales team?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | No claim about your past. Propose the principle first (who owns the expansion signal, who owns the offer), then the one decision you would ask them about. | A seam question on the expansion motion the JD names. |

### C. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A platform vendor bundles a comparable data product into its suite at no added cost. What do you do in the first 30 days?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your note) | Clarify the customer segments and the bundle's real overlap; then structure the response: pricing and packaging options, unit economics against the bundle, and the metric you would watch. Think aloud; challenge one premise. No claim about your past. | Their pricing background makes the bundling answer a monetization question. |
| C2 | "Enterprise expansion, an AI copilot launch and reaching profitability all matter. Which one should a GTM plan bend around, and why?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your note) | Take a position, name the tradeoff, and say what would change your mind. Use the names as given; no claims about Compass's status. | Strategy at the company's own altitude, built only from your note. |
| C3 | "How would you price Compass so it does not cannibalize enterprise expansion?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your note) | Pricing lens: packaging tiers, the unit that is charged, and the expansion motion it could slow. State assumptions before numbers. No claim about your past. | Pricing tilt for this interviewer; Compass is in your note. |
| C4 | "How would you test a packaging change for a new product line before committing the whole base?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights, your note) | No claim about your past. Structure: the segment you test on, the metric and guardrail, the decision rule, and what you would not test. | A live problem for the GTM-ownership requirement; F2's gap is rehearsed by the method, not by a story. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't run sales ops or quota-setting. Why should we trust the targets you would set?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" (your note) | Plain acknowledgment first: "I haven't run classic sales ops or quota-setting." Then the nearest thing you did, quoted: "set annual volume targets with cross-org consensus." Answer slot: if you checked those targets against the numbers they drove, say how; if not, say so, and say how you would check a quota plan before you trusted it. Hold the acknowledgment; do not bluff the mechanics. | This is the highest-ROI prep in the pack: the most predictable objection, and the one the interviewer's own function makes most likely. |
| D2 | "Tell me about a time you worked on one stage of a land, adopt, expand or renew motion." | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | Open prompt. Name the stage you touched and what was yours in it. Answer slot: if you ran any part of a stage, say which; if none, say so and say what you would learn first. Do not describe a stage you did not work on. | The material does not show lifecycle ownership; the honest answer is the limit, stated. |
| D3 | "Partner-motion design is required here. Which part would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your note); [grounded] "built a partner-level revenue model used in carrier negotiations" (your note) | Calibrated candor: name the part you have not done, then the adjacent work you did, quoted at its scope. Give a ramp plan with the first two weeks. Do not claim partner program design. | F1 gap, asked as the skeptic would ask it. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run quota-setting at this scale?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your note) | Pause. Restate the question. Hold: the targets you set with cross-org consensus, quoted. Hold through two follow-ups; on the second, concede the quota mechanics specifically, not the whole case. | Pressure version of D1; tests whether the hold survives. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your note) | Hold: you proposed the change, and the uplift was credited to it. Concede specifically: you cannot claim the whole uplift alone. Do not fold on the proposal. | Attribution under pressure; the second follow-up breaks any claim you cannot back. |

### F. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you held a view that leadership did not want, the stake, and what happened. Honest branch: if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Cross-functional influence probe; no values round detected, so this is coverage, not a values cheat sheet. |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat a number your team tracked, and what you gave up. Honest branch: if none comes to mind, say so. | Their self-description is data-driven, so a customer-over-metric story is valued; do not coach toward one you do not have. |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | VAL | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your note) | Pre-scripted 90-second arc: the consulting years, the move to consumer-tech product strategy and ops, the partner model, the store-surface change. Each beat is a clause the quote states. No additions. | Casual opener, still scored for communication economy. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your note) | Name one tool and one specific use, in your own words. Do not describe building with it. | AI is a plus, asked casually; the answer must stay at the scope of "uses." |

### Coverage

Requirement-coverage line: each stated JD requirement, the IDs that cover it.

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C4, F2 (fit snapshot) |
| identify whitespace across land/adopt/expand/renew | A3, B5, D2 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | B3, D3 |
| strong cross-functional influence | B1, B2, F1 |
| AI experience a plus | A5, G2 |
| Stated gap, not in the JD highlights: sales ops and quota-setting | D1, E1 |

Primary types across the 23: VAL 6 (B1, B2, B4, F1, F2, G1); EXP 4 (A1, A2, D1, E2); JD 8 (A4, A5, B3, B5, D2, D3, E1, G2); CO 1 (C2); CASE 4 (A3, C1, C3, C4). Secondary tags are in the rationale column.

## Reverse questions

At least five; one ties to the interviewer's own path; one is reciprocity because the round is peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. Which pricing decision here do you wish you had the data for earlier?" | Ties to their own path and converts the interview into a peer conversation. |
| R2 | "You spent a stint at an early-stage startup. What did that teach you about sales motions that a large company tends to get wrong?" | Uses their startup chapter from your note, with no claim about what they did there. |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer round; signals you are thinking about their load, not only your need. |
| R4 | "Where do sales strategy and the Compass launch plan touch today, and where do they conflict?" | Shows you have read the priority list and want the seam, not the slogan. |
| R5 | "How is the partner channel's economics measured today, and who owns that number?" | Probes the partner-motion requirement from the other side and surfaces the owner for D3's ramp plan. |
| R6 | "When a competitor bundles, how does the team decide between a bundle response and standalone pricing?" | Lands on the main threat from your note and the pricing lens they will care about. |

## Sources

- Provided documents: your note only (JD highlights, candidate background, interviewer profile, Northwind priorities and threat). No CV, full JD text or pasted values page.
- Searches sent, both refused by the host (WebSearch permission not granted in this session):
  1. "Dan Kovac Director of Sales Strategy Northwind Data": refused.
  2. "Northwind Data interview process Senior GTM Strategy Lead Emerging Products": refused.
- Nothing from either search is used in this pack.

Research tier: L0 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet, not produced: no values round detected in your note. Search was not sent for this target. |
| 2. Northwind interview process, Senior GTM Strategy Lead | unavailable | Loop structure; the persona weights use the round as you described it (peer, single 60-minute conversation). Search 2 refused. |
| 3. Northwind strategy / recent news | skipped | Your note already supplies the priorities and threat, so the grounding brief needs no search. |
| 4. Dan Kovac, Northwind | unavailable | Interviewer read's public footprint; the read uses your profile only. Search 1 refused. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD questions. Full text would upgrade them. |

## Upgrade menu

- Full JD text, or the posting link → the six JD highlights become verbatim quotes; the [inferred] rows (F3, F4, F6) and the JD questions can be re-graded against the full requirement list.
- Priya's CV → verbatim evidence quotes replace the note's sentences; F1 to F5 gain their inspectable-proof wording and the defend-the-number slots get the CV's own figures.
- A WebSearch permission grant → research at L1 on the interview process and the interviewer's public footprint, which would set the loop shape and the interviewer read.
- The interviewer's public talks or writing → the interviewer read gains their recurring themes as questions.
- Any recruiter focus areas or announced deliverable → a graded-deliverable section and its build.
- Priya's own confirmation of F7 → the quota-setting statement becomes her own sentence, not your note's.
