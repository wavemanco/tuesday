Your prep pack is saved as /var/tmp/tuesday-measure/1a3/runs/haiku/tuesday/part-2/rooms/case-6-denied-d57d6bf4/larkfield-systems_engineering-manager_interview_pack.md. I built it as one loop-mode pack, since your three rounds are on the calendar: a shared fit snapshot, then a mini-pack per round with its own persona weights, questions and reverse questions.

The thing to rehearse first is the hardware roadmap. Your message says you've never owned one, and the role asks you to partner with hardware on the roadmap. Question B2 is the most likely objection in the Tuesday round, so I'd rehearse that hold before anything else. The 60% on-call result is the other place to be ready: B8, C4 and D6 each ask how the number was counted and how much of it was yours.

Web search was refused in this session, so the pack has no values, interview-process or strategy research. The values cheat sheet for the VP round is missing, and the CO questions are generic. The pack's Sources section records the refused searches.

Two choices I made that you may want to change:
- I treated your role summary as the job description. Requirement quotes come from your words, not the posting.
- I built 10 questions for each round, which is the loop-mode range.

Say the word and I'll play the Skeptic on B2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would sharpen the pack. Could you paste the full job description and your CV? And where is the role based, and how many days a week on-site would it need?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

Three rounds, one shared fit snapshot (loop mode).
- Round 1: Director of Engineering, hiring manager, 45 min, Tuesday
- Round 2: panel of two staff engineers and a product manager, 60 min, Thursday
- Round 3: VP Engineering, 30 min, the following Monday. The recruiter describes it as "values and leadership philosophy".

Built on your message and the recruiter's wording as you relayed it. No job description text, no CV and no web research were available (see Sources). Your role summary stands in for the JD, so requirement quotes below are your own words.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **VAL**: behavioural and values alignment
- **EXP**: deep-dive on your own experience, and whether it holds up
- **JD**: the role's stated responsibilities
- **CO**: company and strategy knowledge. Generic here, because no research ran.
- **CASE**: a live problem

Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements are quoted from your role summary. Evidence is quoted from your message, and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows delivery under pressure on a payments team, and not delivery across 11 engineers and two squads. Bridge at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: if you have delivery results across more than the team of six, say which and how you ran them; if not, say so plainly and stay with the team you ran. |
| F2 | "Lead two squads building device-management services" (your role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, led for three years. Two squads and the device-management domain are not in it. Say six as six. Answer slot: if you have led more than one group, say which and how; if not, say so and describe the team of six. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your role summary), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role-relevant terms. Keep its scope: backend roles, about 40 interviews last year. Do not widen it to all hiring. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your role summary), growth part | none given | none | [grounded] | discovery | Your material does not show growing people's careers. Answer slot: if you have grown engineers, say which and what you did; if not, say so, and say how you would approach it. |
| F5 | "partner with hardware and product on roadmap" (your role summary) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work. |
| F6 | Location and on-site pattern (not stated in your role summary) | none given | none | [generic] | hard_gate | Your material does not establish where the role is based or how many days on-site it needs. Confirm both before Round 1. The one question about it is in the message that carries this pack. |

Gap-type routing follows the rule in the reference: a quote that reaches a requirement gives `none`; adjacent work gives `transferability`; silence gives `discovery`; a negative you stated gives `capability`; an unmet term gives `hard_gate`.

## Prohibited claims

Built from the fit snapshot before the banks were written. Each entry says what it lists, why, and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated: "I've never managed managers" | The plain acknowledgment: "I've never managed managers." No slot. |
| Has owned a hardware-adjacent roadmap | A negative you stated: "never owned a hardware-adjacent roadmap" | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot. |
| Has delivered for 11 engineers across two squads | Inflated form of "3 as a team lead of 6" (F2) | F2's quote at its own scope. The limit is the pack's observation: your material shows one team of six. |
| Cut on-call burden by 60% | Inflated form of F1's quote. The quote says the burden dropped after you pushed a quarter through. It does not say you produced the drop alone | The quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Questions B8 and C4 hold the attribution slot. |
| Ran hiring across the engineering organisation | Inflated form of "I run our hiring loop for backend roles" (F3) | F3's quote, scope kept: backend roles. |

## Persona weights by round

Each round carries its own weights. Relationship priors come from the persona reference. No interviewer profiles were given, so there are no interviewer-signal adjustments.

**Round 1, hiring manager (Director of Engineering), 45 min.** Relationship prior: Case/Strategist and Skeptic. A hiring manager is buying capability and derisking gaps. Weights: Skeptic 4 questions, Case/Strategist 3, Data-Driven Prober 2, Conversational 1.

**Round 2, panel (two staff engineers and a PM), 60 min.** Blend the top two personas of each member's relationship. Staff engineers: Data-Driven Prober and Peer Evaluator. PM: Case/Strategist and Peer Evaluator. Weights: Peer Evaluator 4, Case/Strategist 3, Data-Driven Prober 3.

**Round 3, VP Engineering, 30 min.** Relationship prior: Values/Behavioral and Pressure. The recruiter's words, "values and leadership philosophy", make this a values-style round. Weights: Values/Behavioral 4, Pressure 3, Case/Strategist 2, Conversational 1.

---

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

Raising sources for this round: your role summary's "own delivery, hiring and growth for 11 engineers" and "partner with hardware and product on roadmap".

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); "partner with hardware and product on roadmap" (your role summary) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: how you would learn the hardware constraints in your first month. Do not describe partnership with hardware teams you have not had. | F5 is the most likely objection. This is the open form of it. |
| B2 | "I don't see a hardware roadmap in your background. How would you handle that in this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't owned a hardware-adjacent roadmap." Then the plan, as above. Hold the position through two follow-ups. Concede exactly what you do not know, such as which hardware constraints would surprise you, and never fold to the claim that the gap is small. | The interviewer's negative is your own stated negative, so the question is lawful. The deepest rehearsal goes here. |
| B3 | "You've led a team of six. Two squads and eleven engineers is a different job. What's your evidence you can do it?" | JD | [grounded] "3 as a team lead of 6" (your message) | Say six as six: "I've led a team of six for three years." Then the gap, in your words. Then how you would structure two squads, as a plan. Answer slot: if you have run anything larger, say which and how; if not, say so. | F2. The question's premise is the interviewer's own, and the guidance does not adopt it. |
| B4 | "Why this role now, and why leave the payments company?" | JD | [grounded] "currently at a payments company" (your message) | Answer slot: give your real reason for moving, in your own words. Your material gives no reason, so do not borrow one from the job posting. | Skeptic stem on motivation. |
| B5 | "A device fleet's firmware rollouts are causing service incidents, and two squads own different parts. What would you do in the next two weeks?" | CASE | [generic] | Clarify first: what the incident data says, who owns the rollout path, and what a safe rollback looks like. Then the decision you would make and what you would tell product and hardware. | A live problem from the role. The scenario presupposes nothing about your past. |
| B6 | "Product wants a feature next quarter that the device team says is blocked by a firmware change. Walk me through what you'd do." | CASE | [generic] | Name the decision owner, what you would trade, and what you would write down. Ask one question about the blocker before you commit to a path. | Tests the hardware-and-product partnership in a live form. |
| B7 | "Walk me through how the interview loop for your backend roles was structured. How did you decide who advanced?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer slot: if you set the stages and the decision rule, say which and how; if the loop was set by others, say so and describe what you ran. Do not describe stages you did not set. | The question's premise, that the loop has stages and a rule, is not in your quote. The second branch allows that it was not yours. |
| B8 | "The 60% on-call drop: how was that counted, and which assumption would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number, in your own words. How the burden was counted: if you know the method, say it; if not, say so plainly. The assumption you would defend least: name it before they do. Which part was yours: say it, and say what the team did. Hold through two follow-ups. | Every headline figure gets a defend-the-number question. The pack supplies no counting method. |
| B9 | "So, walk me through the journey to this role."  | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | A 90-second arc from your quoted sentences: nine years, three as a team lead of six, the payments company, the hiring loop, the reliability quarter. Keep each claim at its quoted scope. | The Conversational opener is still scored. Prepare the arc once. |
| B10 | "How would you grow the engineers you'd manage?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Selection scaffold: pick one engineer whose growth you helped with. If no such case comes to mind, say so plainly, then say how you would approach growth for 11 people. | F4. You have no growth quote, so the honest branch is the answer. |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Own delivery | B3, B8, F1 row | B8 for the on-call result |
| Hiring | B7 | |
| Growth for 11 engineers | B10 | |
| Lead two squads | B3 | |
| Partner with hardware and product on roadmap | B1, B2, B5, B6 | |
| Device-management services | none, and why: a description of the team, covered through B5 | |

### Reverse questions

1. "What would a strong first 90 days look like for this role?" Why it lands: you are planning for the gaps in your material, and the answer tells you which gap they care about most.
2. "Which of the two squads has the hardest roadmap dependency on hardware today, and why?" Why it lands: it shows you think in dependencies.
3. "How does the hardware team decide what goes into a device-management release?" Why it lands: it tests the gap in a neutral form.
4. "What has the last person in this role gotten right, and what got harder than expected?" Why it lands: it asks for the real job.
5. "What does success look like at six months for the person leading these two squads?" Why it lands: it turns the interview into a planning conversation.

---

## Round 2: Panel (two staff engineers and a product manager), Thursday, 60 min

Raising sources for this round: "partner with hardware and product on roadmap" (your role summary), and the panel's own roles.

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Describe how you would decide a disagreement. Answer slot: if you have a disagreement with an equal, say what you did; if not, say so, and describe how you would settle it. | Peer Evaluator stem. Seam awareness is what staff engineers probe. |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Credit goes to the people who did the work, named specifically. Answer slot: if you have a case where credit was shared, say how; if not, say so, and state the principle you would use. | Peer stem. Credit probes often test whether the candidate takes it. |
| C3 | "Our reviews stall. How would you decide when to override one?" | JD | [generic] | Name the criteria for overriding a review, and who you would tell. Answer slot: if you have overridden a review, say what you did and what it cost; if not, say so. | Peer probe on turf and judgement. |
| C4 | "Your reliability quarter cut on-call burden 60%. What did that number measure, and what would change it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number, as in B8: how it was counted, the assumption you would defend least, and which part was yours. Hold through two follow-ups. | Data-Driven Prober on a headline figure. |
| C5 | "Walk me through how you'd know a device-management service is reliable enough to ship." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the signals you would use, then say which of them your payments work has taught you. Say where that work stops: device fleets are not payments services. | The reliability work is your strongest quote, and its limit matters here. |
| C6 | "Of your 40 interviews, which signals predicted a good hire?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer slot: if you tracked outcomes against signals, say which and what you found; if not, say so, and say what you would track. | The Prober asks for denominators. The honest answer may be that you did not track it. |
| C7 | "Product wants a feature next quarter that the device team says is blocked. What do you do this week?" | CASE | [generic] | Clarify the blocker. Name who decides. Lay out two options with their trade-offs. Say what you would not do this week. | Case/Strategist live problem, from the role's roadmap partnership. |
| C8 | "Ship to twenty customers now, or harden for two thousand? How do you decide?" | CASE | [generic] | Structure: what the signal is, what the cost of each path is, and what would change your mind. Ask for one number you do not have yet, and say why. | Tests structure over the "right" answer. |
| C9 | "When did you last push back on a roadmap, and what happened?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Tell it in your words: what the pressure was, what you held to, and what you gave up. Answer slot: the pressure and the cost are yours to name, and the material does not state them. Do not add a stakeholder reaction. | Open prompt on a sentence you actually wrote. |
| C10 | "When an engineer on your team disagrees with a product call, what do you do?" | VAL | [generic] | Name the step you take first, and who gets involved and when. Answer slot: if you have had this happen, say what you did; if not, say how you would handle it. | Peer probe on disagreement style. |
| C11 | "What would you need from the staff engineers in your first quarter to make a decision on a shared service?" | JD | [generic] | Name specific inputs: the design doc, the on-call history, the review queue. Ask for them by name. | Peer reciprocity. It shows you think about what the seam costs them. |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Partner with hardware and product on roadmap | C7, C8, C9 | |
| Own delivery | C4, C5, C9 | |
| Lead two squads | C1, C10 | |
| Growth and hiring | C6 | |

### Reverse questions

1. "Where do your reviews get stuck today, and who decides?" Why it lands: you are asking about the work, not the org chart.
2. "What is the one thing about how your teams work with the device team that you'd change first?" Why it lands: it shows seam awareness.
3. "What could a new person do in their first month that would genuinely help your team?" Why it lands: this is the peer reciprocity question. It asks what you can give them, not only what you need.
4. "How far ahead do hardware schedules show up in the product roadmap?" Why it lands: it tests the partnership at the level where it breaks.
5. "What decision in the last quarter did you wish had been made faster?" Why it lands: it finds the real friction.

---

## Round 3: VP Engineering, Monday, 30 min

Raising source: the recruiter's words, "values and leadership philosophy". The company's published values are not in hand, so there is no values cheat sheet. The upgrade menu asks for them.

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] stem. Nearest sentence, used only in the honest branch: "I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in your own words, what the pressure was and what you held to. | A values-style probe. The stem is generic and the honest branch uses only your quoted sentence. |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. If you have such a case, name the metric, the customer, and what you traded. If not, say so, and say how you would decide. | Values stem. Customer-over-metric stories score well with values interviewers. |
| D3 | "What is your leadership philosophy, in a sentence, and where did you learn it?" | VAL | [grounded] "values and leadership philosophy" (recruiter's words, as you relayed them) | Give your philosophy in your own words. Anchor it to one decision you made, from your quoted sentences. Do not state a philosophy you have not acted on. | The recruiter's phrase is the raising source. Your material holds no philosophy statement, so the answer must come from your decisions. |
| D4 | "How do you keep a hiring bar from dropping under pressure?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | If you set or held the bar, say how; the loop you ran is the evidence. If the bar was set by others, say so, and describe what you did within it. | The values probe on your strongest hiring quote. |
| D5 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] stem | Hold your position in the first sentence. Anchor it in the quotes: nine years, three as a team lead of six, the reliability quarter. Restate the question if you need a pause. | Pressure stem. The test is composure, not the answer. |
| D6 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede. Say what you did and what the team did. Concede exactly what you do not know: how much of the 60% came from others. Do not fold on your own part. | Pressure on a headline figure, the one most likely to be attacked. |
| D7 | "You've never managed managers. Why should we believe you can lead leaders?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then a plan: how you would lead leaders, and what evidence you would look for to see that it works. Hold the position that the plan is sound, and concede only the part you have not tested. | The interviewer's negative is your stated negative, so the question is lawful. |
| D8 | "How would you know, six months in, that your leadership philosophy is working?" | CASE | [generic] | Name two signals and one lagging indicator, and say which you trust least. | Tests structure on a leadership problem. |
| D9 | "Where would you draw the line between what your squads own and what you would decide with me?" | CASE | [generic] | Name the decision rights you would want, and what you would escalate. Keep it to one clear principle. | Tests altitude and autonomy. |
| D10 | "What book or idea has changed how you lead?" | VAL | [generic] | Name a real one you have used. If none comes to mind, say so, and say what you learned from a decision instead. Do not name a thinker you have not applied. | Conversational opener, scored. |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Leadership philosophy (recruiter's words) | D1, D3, D7 | |
| Hiring bar | D4 | |
| Own delivery under pressure | D6 | |
| Managing managers | D7 | The gap is stated and the plain acknowledgment covers it |

### Reverse questions

1. "How do you want engineering managers to make decisions when hardware and product disagree?" Why it lands: it names the tension in the role.
2. "What does this organisation mean by leadership philosophy, in practice?" Why it lands: you are asking what the phrase means, not guessing.
3. "What have you seen go wrong when an engineering manager moved up to manage managers?" Why it lands: it shows self-awareness about the gap in your material.
4. "Which decision from the last year would you have wanted an engineering manager to make without you?" Why it lands: it tests the autonomy expected.
5. "What would make you say in six months that this hire was the right call?" Why it lands: it turns the close into a success criterion.

---

## Sources

- Provided documents: your message, including your role summary and the recruiter's wording as you relayed it.
- No job description text, CV or interviewer profile was supplied.
- Searches sent, all refused (permission to use web search was not granted):
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Refused. The values cheat sheet is absent, and the VP round's values questions are not mapped to published values. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Refused. The loop itself is established by your own words (three named rounds), so this would have checked the round formats and any case structure. |
| 3. Larkfield Systems strategy and recent news | unavailable | Refused. It would have grounded the CO questions. Those are generic here. |
| 4. Interviewer name and Larkfield Systems | n/a | No names were given, so there was no query to form. |
| 5. Representative engineering manager JD | unavailable | No call sent. Your role summary stood in for the JD, and a fetched JD would have turned the JD-tagged requirement rows from your summary into sourced ones. |

## Upgrade menu

- The full job description text → the requirement rows quote the posting, not your summary, and the JD-tagged questions in all three rounds rest on it.
- Your CV → evidence cells can quote your CV lines as well as your message, which may raise confidence on F1 to F4.
- The recruiter's list of Larkfield's published values → the values cheat sheet for Round 3, and D1, D2 and D10 map to stories.
- Where the role is based, and how many days on-site → resolves the F6 gate row.
- Permission to use web search → an L1 pass on values, the interview process and current strategy. Strategy would ground CO questions in the company's current position.
- An offer you can accept or decline: a deeper research pass on strategy and recent org context, up to 6 more searches and 2 more fetches, several more minutes. Want it?
- The interviewers' names → persona weights for each person, and reverse questions tied to their career paths.
- How much time you have before Tuesday → a prep triage section, ordered by round.
- How the 60% on-call figure was counted → upgrades B8, C4, D6 from an answer slot to a stated method you can defend.
- Any answer to B2 in your own words → would upgrade the Skeptic bank's hold, if the answer is something you did.
