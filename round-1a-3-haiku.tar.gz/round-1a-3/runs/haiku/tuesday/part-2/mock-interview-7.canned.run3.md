Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-canned-ce9ae4cc/c72e9142-953d-40c1-8827-95dbba196b66/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since Saltmarsh's own interviewing page describes the 60-minute slot as the "Outage Hour." Two things from the research matter before Friday:

- **The hour is two parts.** A live-incident tabletop on a simulated outage during a live event, then a values conversation. The values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. The tabletop is where the Case questions in bank A sit, and you have no incident material in your message, so those answers rest on structure, not on a story.
- **Check the role's scope with the recruiter.** Saltmarsh's September 2026 news says Project Larkspur puts Tidepool Tactics and Lantern Row on one shared events calendar from February 2027 and retires per-title event teams. Your JD describes a role running the calendar for two titles. Ask whether that role survives the change as written. I haven't assumed either way.

The three gaps the pack is built around are the ones you already named: the JD's "own the post-event review and the KPIs" (your evidence is presenting retention numbers, not owning them), the live-service question (four years at a puzzle studio), and the team-leadership and in-app-purchase gaps. The pack gives you plain acknowledgments for both negatives and does not coach any claim beyond what you wrote.

I could not use the one interviewer result. The search returned a GDC 2026 talk attributed to Tobias Wrenfield, but it sits on a domain I could not verify as the conference's, so I dropped it rather than build on it.

Offers, not pushed: I can play the Skeptic on C2 (the in-app purchases question), which the pack names as the likeliest probe, or save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your hiring manager, or will others sit in on Friday? The answer changes how the banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager (assumed from the company's interviewing page; to confirm). Round: the Outage Hour, 60 minutes.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive
- **JD**: role and job-description driven
- **CO**: company and strategy knowledge
- **CASE**: live problem, hypothetical

## The round

Saltmarsh's interviewing page (loop source) says: "Every Saltmarsh loop is a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

So this round has two halves: a tabletop (CASE, bank A) and a values conversation (VAL, bank B). No graded deliverable. The loop is one session, so there is no loop mode.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, for two years. Say that in those terms. Answer slot: the JD asks for live events across two titles. If you ran events across more than one title, say how. If you ran one title's calendar, say so and say what that calendar covered. |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Direct. Lead with it in the quote's words: you wrote it, and QA still uses it. Do not widen "wrote" into "owned the release process". Expect a probe, since the checklist is a named artifact. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting numbers is adjacent to owning a post-event review and its KPIs. The material does not show who chose the numbers or ran a review. Answer slot: if you chose or defined any KPI, say which and how. If you presented numbers someone else defined, say that. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge only rewords it: "I presented our monthly retention numbers to the studio head." It adds no method and no figure. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | discovery | Four years meets the three asked for. The material does not show whether the puzzle title ran as a live service. Answer slot: if it did, say how content ran after launch. If it did not, say so and say what your production work was. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct. The proof is your own account and the calendar itself, so expect a probe on how it ran. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across design, art, engineering or community. Answer slot: if you coordinated any of those teams on a release, name the team and what you did. If you did not, say so and say how you would set up handoffs for a live event. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is written work another team depends on. Bridge: "I wrote the release checklist our QA team still uses." It makes no claim about other writing. |

Gate rows: none. Nothing in the JD or your message is a term (location, right to work, schedule, pay) that the material leaves unsettled.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation, not words for you: your material says you presented the numbers. |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: one title's content-drop calendar for two years. |
| Built or ran a live-service game | Inflated form of F5 | F5's quote at its own scope: four years at a puzzle-game studio. |
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | Top weight. The loop source names the tabletop as half the hour, and a hiring manager buys capability | Clarify, then structure, then decide and announce | 5 |
| Values/Behavioral | The values conversation in the second half | Mid weight. The loop source names it, and the company publishes three values | Map a story to each value, or give the selection scaffold and its honest branch | 3 |
| Skeptic | Quiet probing of F5, F7, the in-app purchases gap, and team leadership | Mid weight. A hiring manager derisks gaps, and the gaps here are visible in your message | Rehearse the predictable objection until it is plain; hold only what your quotes carry | 3 |
| Data-Driven Prober | "How was the retention number counted?" | Mid weight. The retention figure on the CV is the likeliest magnet for a probe | Say what you know and what you do not, in your own words | 3 |
| Pressure | Time-boxed challenges on leadership and on how much was yours | Low-mid weight. Probable in a one-hour hiring-manager session | Pause, restate, hold through two follow-ups, then concede precisely | 2 |
| Conversational | The opening "walk me through the journey" | Low weight. Casual openers are still scored | A 90-second arc built from your own sentences | 2 |

Peer Evaluator was left out. This round is with the hiring manager, not a peer. Peer probes may come in a later round, and that is the place to add them.

## Interviewer read

No verified public profile. The search returned a GDC 2026 talk page attributed to Tobias Wrenfield, but its domain (talks.gdconf.example) could not be verified as the conference's own. Nothing from it is used in this pack. See Sources.

## Values cheat sheet

Values from the company's values page (fetched).

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | "when the calendar and the players disagree, the players win" | None of your quoted sentences carries a story for this value. Selection scaffold, see B1. |
| Ship the Patch Not the Promise | "we announce what is built, not what is hoped" | None of your quoted sentences carries a story for this value. Selection scaffold, see B2. |
| Leave the Build Greener | "every release leaves the codebase and the checklist better than it found them" | Row F2: "Wrote the release checklist our QA team still uses." The story beats are the ones that sentence states: you wrote it, and QA still uses it. See B3. |

## Question banks

Persona A: Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Project Larkspur moves both titles onto one shared events calendar from February. Thursday's event, on one of them, has a reward bug. What do you do first, and what changes once the calendars merge?" | CO | [grounded] "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (company news, September 2026) | Clarify first: which title, how many players, what the bug grants. Then say what the merged calendar changes for the next event. No claim about your past. | The one CO question. Grounded in the company's own published news, which the question states as fact about the company, not about you. |
| A2 | "Players are reporting a reward bug mid-event. Walk me through who you bring in, and in what order." | CASE | [generic] | Name design, art, engineering, QA and community, and what each needs from you. Say who speaks to players and when. | Tests the coordination line in the JD. Pattern for the problem, not a fact about this studio. |
| A3 | "Engineering says the fix is ready in two hours. Do you hotfix, roll back, or hold the event? What do you tell players at each choice?" | CASE | [generic] | Weigh impact, reversibility and player trust. Announce only what is built. | Tests the value Ship the Patch Not the Promise through a decision, not a recital. |
| A4 | "After the event, what does the post-event review cover, and which three KPIs go to the studio head?" | JD | [generic] | Say what the review covers, which metrics you would define, and how you would check them before they are shared. | The JD's review and KPI line, asked as a design question. Do not draw on F3 here. |
| A5 | "Write the player-facing notice for that outage in three sentences." | JD | [generic] | Three sentences: what happened, what is being done, when. Say only what is built. Then read it aloud once. | Tests clear written communication directly. |

Persona B: Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (company values page) | Selection scaffold: pick a time a date you set collided with what players needed. Name the stake, what you chose, and who you told. If no such time comes to mind, say so plainly, then say how you would decide now. | No quoted sentence of yours carries this story, so it is a scaffold ending in the honest branch. |
| B2 | "Tell me about a time you had to say what would ship before it was finished. How did players hear about it?" | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (company values page) | Selection scaffold: a time you announced something before it was ready, or a time you held an announcement back. If neither comes to mind, say so, then say how you would word an announcement for something unfinished. | Same as B1: no sentence of yours carries the story. |
| B3 | "Tell me about a release checklist you're proud of. What have you changed in it, and why?" | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." (company values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F2: you wrote a checklist, and QA still uses it. Answer slot: if you changed it after a release, say what and why. If you did not, say so and say how you would keep it current. | The only value with a quoted sentence of yours behind it. |

Persona C: Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Four years at a puzzle-game studio. Have you produced a live-service game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | State the years and the studio in your own words. Answer slot: if the puzzle title ran content after launch, say how. If it did not, say so, then say what production work you have done. | F5. The three-year requirement is met on years. The live-service part is the probe. |
| C2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would learn first. Plan, not past. | The sourced negative. Expect this one, because it is the most obvious probe for a mobile studio. |
| C3 | "Which KPIs have you chosen yourself, and which were chosen for you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you chose or defined a retention metric, say which and how. If you presented numbers someone else defined, say that, then say which KPIs you would own here. | F3, the clearest gap in the JD's list. The question asks which, so it presupposes nothing. |

Persona D: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The retention numbers you presented each month: how was the figure counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot: if you know how it was counted, say so in your own words. If someone else prepared the figure, say that. "I don't know how it was counted" is an honest branch. If you know the assumption you would defend least, name it before they ask. | F4 and F3 together. Premised only on the presenting, which your sentence states. |
| D2 | "What would you need to see in the data before you called a content drop a success?" | JD | [generic] | Name the metric, the window, and what would change your mind. No claim about your past. | Tests comfort with retention metrics without asking for a figure. |
| D3 | "Name one release checklist item, what evidence it needs, and who signs it off." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name one item from the checklist you wrote and the evidence it requires. Answer slot on sign-off: if QA signs, say so. If you do not know who signs, say so. | F2 and F8. Checks the release-checklist claim at its own scope. |

Persona E: Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment first: "I haven't led a team." Hold through two follow-ups with what your quotes carry: "I ran a two-year content-drop calendar, and I wrote the checklist QA still uses." Concede precisely: name what you would need to learn about leading people. Never add coordination you have not stated. | Tests composure on the team-leadership gap. The hold is only the quoted material. |
| E2 | "That content-drop calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold the quote's scope. Answer slot: which parts of the calendar you set (dates, scope, sign-off), and which others set. Say it plainly either way. | F1. The attribution probe. |

Persona G: Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc in those four beats, in your words. End on what you want to do next, not on leadership. | F1, F2, F4, F5 in order. |
| G2 | "What games are you playing right now, and what's keeping you in them?" | JD | [generic] | Name one game you actually play and one retention hook you have noticed. Do not invent a favourite. | A casual question on the JD's retention line, scored as one. |

Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A4, E2 |
| Coordinate design, art, engineering and community teams on each update | A2, E1 |
| Own the post-event review and the KPIs it reports | A4, C3, D1 |
| Manage the release checklist with QA | B3, D3 |
| 3+ years producing live-service games or apps | C1 |
| Experience running a content calendar | E2, G1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | A5 |

## Reverse questions

1. "In the tabletop, which of the three values do people find hardest to hold under time pressure?" Why it lands: shows you read the loop's structure, and the answer shows where the hour will press.
2. "How does Project Larkspur change this role's scope once the shared calendar starts in February?" Why it lands: shows you read the company's published strategy, and asks about the role without presuming the outcome.
3. "How do the post-event review and its KPIs reach design, art and engineering after each event?" Why it lands: turns the JD's coordination line into a process question.
4. "When a release checklist item fails with QA, who decides, and how is it recorded?" Why it lands: ties to the checklist you wrote and tests how the process runs.
5. "What would a strong first 90 days look like here?" Why it lands: a standard question, but it sets up the goal you can measure yourself against.
6. "What do you most want to see in the Outage Hour?" Why it lands: it signals you have prepared for this interview specifically.

No reverse question is tied to the interviewer's own career path, because no verified profile exists.

## Sources

Provided documents: your message (background, JD text as quoted in the request).

Searches and fetches, with what came back:

1. Search "Saltmarsh Games values": saltmarshgames.com/values. Values named.
2. Search "Saltmarsh Games interview process Live Operations Producer": saltmarshgames.com/careers/interviewing. Loop structure.
3. Search "Tobias Wrenfield Saltmarsh Games": a GDC 2026 talk page on talks.gdconf.example, described as by Tobias Wrenfield, Head of Live Operations. Not established: the domain is not the conference's own as far as I can verify. Nothing used.
4. Search "Saltmarsh Games mobile studio news strategy": saltmarshgames.com/news/project-larkspur, dated September 2026. Current strategy.
5. Fetch saltmarshgames.com/values: the three values, quoted.
6. Fetch saltmarshgames.com/careers/interviewing: the Outage Hour, quoted.

Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B |
| 2. Saltmarsh Games interview process | yes | Loop: the Outage Hour, one 60-minute session. Sets the round structure |
| 3. Saltmarsh Games strategy and news | yes | Project Larkspur. Grounds A1 and reverse question 2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | The one result was a talk page on a domain I could not verify. Not established, moved nothing |
| 5. Representative Live Operations Producer JD | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, not only your message → the F rows quote your CV's own lines, and bank B3 and G1 can use its wording.
- A public profile you can verify for Tobias Wrenfield (a talk or post on a domain you can confirm) → persona weights from his footprint, and a reverse question on his path.
- Confirm whether the two titles are Tidepool Tactics and Lantern Row → A1 and reverse question 2 sharpen to the real calendar.
- The recruiter's prep email → the scope of the role and any pre-declared material for the hour.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the strategy brief behind Project Larkspur, and any recent team changes it implies for this role.
