Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-1-denied-32cb397a/3c7cd1e1-c24d-4de1-98e8-d1dd8b443df7/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

Web research was refused by the host, so the company and interviewer facts come only from your notes. The strategy priorities and the Dan Kovac profile are unverified and undated. Before the interview, check that the Compass launch and the bundling threat are still current, and see whether Dan has public talks or writing.

What the pack contains:
- **Persona weights** for a peer conversation: Data-Driven Prober 5 questions, Peer Evaluator 4, Case/Strategist 4, Skeptic 3, Pressure 2, Conversational 2, Values 2. That is 22 questions in total. Dan's "relentlessly data-driven" self-description and his pricing career drive the weights.
- **Fit snapshot** of the JD highlights against Priya's background. Most rows are gaps or thin evidence: GTM strategy ownership, partner-motion design, independent SQL/Tableau analysis, and AI work. Her strongest evidence is the $400M figure and the carrier revenue model.
- **Highest-ROI prep (D1):** "Have you owned go-to-market strategy for a new product line, or only the product side?" It gets the deepest rehearsal. Her honest answer is the product-strategy and ops work, with any GTM decisions named only if they were hers.
- **Defend-the-number questions** on the $400M figure (A1, A2, D3, E2). The pack gives her no method and no assumption, so she has to supply both in her own words.
- **Prohibited claims** that stop the pack from coaching inflated versions of her gaps.
- **Requirement coverage**, six reverse questions (one tied to Dan's pricing-to-startup path, one reciprocity question), and an upgrade menu.

Three things to check:
- **Sales-ops and quota experience.** The "no sales-ops or quota-setting experience" line comes from your notes, not from Priya. The pack treats it as an open answer slot, not as a plain acknowledgment she has made. Confirm it with her before she rehearses any words about it.
- **Interview format.** I treated the one 60-minute conversation with Dan as the whole loop, so the pack has no values round.
- **JD text.** I worked from your JD highlights only. Full JD text would firm up the JD-tagged questions.

Offers:
- I can run a drill with any persona. I suggest starting with D1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Candidate: Priya. Interviewer: Dan Kovac, Director of Sales Strategy (peer; same VP). Format: one 60-minute conversation.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **EXP** work-experience deep-dive; **VAL** behavioral and values; **JD** role and JD-driven; **CO** company and strategy knowledge; **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script. Each cell is built only from the sentences you gave me. Anything in a guidance cell that is not one of those sentences is an answer slot: it is for Priya to fill in her own words.
- Source labels used below: **your message** (your JD highlights and your research note), **the coach's notes** (your description of Priya's background).

## Research status

Research tier: L1, searches 2 of 6, fetches 0 of 2. Both searches were refused by the host, so nothing in this pack comes from web results. The company and interviewer facts rest on your notes only.

## Grounding brief (from your research note; unverified and undated)

Your note gives three stated priorities and one competitive threat. Treat them as the vocabulary to learn, not as current fact, until someone checks them.

| Item | Source | Use in the interview |
|---|---|---|
| Enterprise expansion | your message: "enterprise expansion" | Expect it to frame CO and CASE questions |
| AI copilot launch | your message: "AI copilot launch ('Compass')" | Expect Dan to ask about it; see C3 |
| Reaching profitability | your message: "reaching profitability" | Frame plans in unit-economics terms |
| Main competitive threat | your message: "bundling by a much larger platform vendor" | See C4 |

Stale-framing check: none of these is dated. Before the interview, confirm each is still current.

## Persona weights (peer relationship, one session)

Your note fixes the loop: one 60-minute conversation with Dan, a peer. No loop source names other rounds, so no archetype is assumed and no values round is detected. Weights below follow the peer prior, adjusted by Dan's profile as you described it.

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | High, depth 5 | Peer prior puts it first. Dan describes himself as "relentlessly data-driven", so every number will be taken apart | Know what can and cannot be said about how each number was counted; name the weakest assumption first |
| Peer Evaluator (B) | High, depth 4 | Peer prior. He is pricing what the hire adds to his team's load, and the seam between sales strategy and GTM strategy is his concern | Offer reciprocity; propose seam principles rather than pretending to know the seam |
| Case / Strategist (C) | Medium-high, depth 4 | The role is GTM strategy for two new product lines. His career is pricing and monetization, so expect pricing, packaging and unit-economics angles | Clarify, then structure aloud, then name one risk |
| Skeptic (D) | Medium, depth 3 | The JD has a required item (partner-motion design), and the notes record no sales-ops or quota experience | Rehearse the single most predictable objection until it is boring; concede plainly |
| Pressure (E) | Low-medium, depth 2 | Peer conversations rarely pressure, but a numbers-first peer may push on the headline figure | Pause, restate, hold a position through two follow-ups |
| Conversational (F) | Low, depth 2 | Dan may open casually; casual questions on JD topics are still scored | Keep a 90-second arc ready |
| Values / Behavioral (G) | Low, depth 2 | No values round is detected, so this persona is kept at minimum depth to avoid a first-time meeting | Open-prompt stems with an honest branch; no published values are cited |

Interviewer read (from your profile of Dan; public footprint only): his career is pricing and monetization, with one early-stage startup chapter. Practical implications: tilt case questions toward pricing and packaging (C); expect builder-style probes on the startup chapter; expect Prober follow-ups. No shared career jump is offered as a mirror, because no fit-snapshot row carries Priya's side of one.

## Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from the coach's notes unless stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes); "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | low | [inferred] | transferability | The notes show a revenue model and product-strategy work, not GTM ownership. Bridge: describe the model and the product-strategy work in those words. Answer slot: if any go-to-market decision for a launch was hers to make, say which and how she decided; if none was, say so plainly. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message) | "set annual volume targets with cross-org consensus" (the coach's notes) | low | [inferred] | transferability | Target-setting is adjacent to whitespace, not the same work. Bridge: say what the targets were built from, in her words. Answer slot: if she identified an unserved segment or motion herself, say which; if not, say so. |
| F3 | "run independent analysis in SQL and Tableau" (your message) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | discovery | "Skilled" does not show an analysis she ran end to end. Answer slot: name one analysis she ran herself, the question it answered, and what she checked. If none comes to mind, say so and describe how she would start. |
| F4 | "partner-motion design experience required" (your message) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | The notes show partner-facing financial work, not designed partner motions. Bridge: say what the carrier model's partner-facing decisions were, and which were hers. Answer slot: if she designed any partner motion, say which; if none, say so plainly. |
| F5 | "strong cross-functional influence" (your message) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | The quote already reaches cross-functional influence. Bridge rewords only the quote: "I set annual volume targets with cross-org consensus." No added figure or event. |
| F6 | "AI experience a plus" (your message) | "uses AI tools daily" (the coach's notes) | low | [inferred] | discovery | Daily use is not AI product experience. Answer slot: if she has built or shipped anything with AI, say what; if not, say that she uses AI tools daily and say how. |
| F7 | Headline figure, not a JD requirement | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | discovery | The figure raises the defend-the-number slots (A1, A2, E2). The material does not show how it was counted or what part was hers. Keep "credited with" as written. |
| F8 | Absence in the coach's notes, not a JD requirement | "No classic sales-ops or quota-setting experience" (the coach's notes) | none | [grounded] | discovery | The absence comes from your notes, not from Priya, so no plain acknowledgment is written for her. Confirm it with her before rehearsing any words about it. Answer slot: if she made any sales-plan or quota-adjacent decision, say which; if not, say so and name what she did instead. |

Rules applied: no gate row exists in your material (no location, authorization, schedule or pay is stated), so none is asked about.

## Prohibited claims

Built locally from the fit snapshot. None of these may be coached, implied or softened in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. Observation, for the analysis only: the notes say a revenue model and product strategy, not GTM ownership |
| Designed partner motions | Inflated form of F4 | F4's quote at its scope. Observation: the notes say a partner-level revenue model |
| Ran end-to-end SQL and Tableau analysis | Inflated form of F3 | "Skilled in" stays as written; the slot asks what she ran herself |
| Caused the $400M ARR | Inflated form of F7 | "credited with" stays as written |
| Built or shipped AI products | Inflated form of F6 | "uses AI tools daily" at its own scope |
| Sales-ops or quota-setting experience, either way | Discovery; the absence is from your notes | An answer slot only; no plain acknowledgment until Priya states it herself |

## Question banks

Question IDs: A (Prober), B (Peer), C (Case), D (Skeptic), E (Pressure), F (Conversational), G (Values). Each bank is ordered by weight.

### A. Data-Driven Prober (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that $400M number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: how it was counted, in her own words. If she does not know how it was counted, say so plainly, then say what she can speak to. | F7 is the headline figure and the likeliest place to be probed. EXP because it tests what was hers. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the weakest assumption in her own words before he does, and say whether it was hers to set. If she has no such assumption to name, say that she has not examined it. Do not supply one. | The weakest-assumption move converts a challenge into a credibility point. F7. |
| A3 | "Which part of the carrier revenue model did you build yourself, and which did you inherit?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Keep "built" exactly as quoted. Say which pieces she built and which she took over. If she did not build the model, say so and describe her part. | F1 and F4 are both transferability gaps, and this question tests attribution. EXP because it asks about her own work. |
| A4 | "Walk me through the SQL and Tableau work behind one recommendation you made. What did you pull, and what did you check?" | JD | [inferred] "skilled in SQL/Tableau" | Answer slot: name one analysis she ran herself, the recommendation, the data it used and what she checked. If none was hers, say so and describe how she would start. | F3 is a discovery gap on a stated requirement. The label is inferred because the only source is a skill claim in the coach's notes. |
| A5 | "You set annual volume targets with cross-org consensus. What moved the number during that consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Answer slot: the inputs that moved the target, and which of them she proposed. If she accepted a number rather than proposing one, say so. | F2 and F5. A premised question: the premise is only "set" and "cross-org consensus", as quoted. |

### B. Peer Evaluator (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where is the seam between your work and mine, and what happens when we disagree about a number?" | JD | [generic] | Propose seam principles, not a seam she has not seen. For disagreement, use a story only if she has one; if she does not, say so and describe how she would settle a disagreement with an equal. | Persona stem. Tests partnership fit. The stem is open, so no event is supplied. |
| B2 | "How do you credit work when a number moved because several teams contributed?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the target was set with cross-org consensus. Say whose inputs were in it and what was hers, in her own words. | Peer probes on credit; the quote carries the cross-org fact and nothing more. |
| B3 | "What would you need from my team to make a new product line work?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" | Reciprocity framing: say what she brings to his team, not only what she needs. Name the seam she would want to agree on first. | Peer reciprocity. The JD line raises the whitespace question; no candidate claim is made. |
| B4 | "Two of our teams touch the same accounts. How would you split whitespace work with a sales-strategy team that already runs the land motion?" | CASE | [generic] | Clarify who owns which account and motion; propose a split principle and a review cadence. Name one thing she would not decide alone. | Live seam problem drawn from the JD's whitespace line. Asks about no past, so it presupposes nothing about her. |

### C. Case / Strategist (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines launch next quarter. Sketch the land-to-renew go-to-market plan. What do you need to know first?" | CASE | [grounded] "own GTM strategy for two new product lines" | Clarify first: the buyers, the price points, and the existing motion. Then structure by stage, state the metric for each, and name one risk. Think aloud. | The JD's headline requirement, asked as a live problem. The premise is the JD line. Dan's pricing career makes price and packaging the likeliest first question. |
| C2 | "Enterprise expansion revenue on one segment fell 15% in a quarter. Diagnose it." | CASE | [generic] | Clarify the definition of expansion first, then split the drop by cohort, by product and by motion. Name the first data check. | Diagnosis is a Strategist staple and fits his data-driven profile. No claim about her past. |
| C3 | "Where does the whitespace sit for an AI copilot, across land, adopt, expand and renew, and how would you price the seam?" | CO | [grounded] "AI copilot launch ('Compass')" | Pricing-first structure: name the buyer at each stage and the price boundary. Use the launch name only if Dan uses it first. | Ties the JD's whitespace line to the stated AI priority. CO and CASE both fit. |
| C4 | "A much larger platform vendor starts bundling our product into its suite. What is your first move?" | CO | [grounded] "bundling by a much larger platform vendor" | Clarify which accounts are exposed. Then compare the bundle's price against the product's, and name the one metric to watch first. | The main competitive threat from your note. Dan's pricing background makes this a natural prober's question. |

### D. Skeptic (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Have you owned go-to-market strategy for a new product line, or only the product side?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops"; [grounded] "own GTM strategy for two new product lines" | Highest-ROI rehearsal in this pack. Answer slot: if she made any go-to-market decision for a launch, say which and how she decided. If none was hers, say so plainly, then describe the product-strategy and ops work the quote carries. Hold through two follow-ups by returning to that work. Any concession must be in her own words, not the pack's. | This is the objection the JD raises most directly, and F1 is where the material is thinnest. Deepest rehearsal: four follow-up levels. |
| D2 | "I don't see partner-motion design in your background. How would you handle it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Bridge from the quote: the partner-facing financial work. Answer slot: any partner motion she designed, or the honest branch that she did not. Then a ramp plan, stated as a plan. | F4, the second likeliest objection. The question's negative is the interviewer's own observation, not a claim she made. |
| D3 | "The $400M figure: is that a headline or a forecast?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: what the figure is, in her own words, and whether it was measured or projected. Keep "credited with" exactly. If she does not know, say so. | F7 again, from a skeptical angle. Tests whether she can separate the figure from her role. |

### E. Pressure (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run GTM for a B2B data company?" | JD | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" | Pause, restate the question, then answer from the two quoted careers. Hold the position through two follow-ups: strategy work and product work are what the notes carry. If pressed on B2B data GTM, concede that gap plainly, in her own words. | Persona stem. The hold is only what the two quotes carry. |
| E2 | "That uplift. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "proposed" is her word, and she can say what she proposed. Concede the rest in specifics: which parts were the team's and which were hers. Never fold on the proposal itself. | Persona stem on the headline figure. Tests composure and attribution. |

### F. Conversational (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: the consulting years, then the product-strategy and ops years, then why this role. Use only those two quotes and her own reasons. | Casual opener, still scored. Pre-scripted arc. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Say which tools she uses daily and what for. Answer slot: any AI work she has built or shipped; if none, say so. | The JD's AI plus, asked casually. Inferred because the only source is a usage claim in the coach's notes. |

### G. Values / Behavioral (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time she put a hard truth to someone senior, with a named stake and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing her notes carry, or how she would handle it. | Persona stem, open prompt. No values round is detected, so no value is cited. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where a customer outcome beat a metric she was measured on. If none comes to mind, say so and describe how she would decide. | Persona stem, open prompt, kept at minimum depth. |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1, D1, E1 | |
| identify whitespace across land/adopt/expand/renew | C3, B3, B4 | |
| run independent analysis in SQL and Tableau | A4 | |
| partner-motion design experience required | D2, A3 | |
| strong cross-functional influence | A5, B2 | |
| AI experience a plus | F2, C3 | |
| Headline figure (not a JD requirement) | A1, A2, D3, E2 | |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity with a peer; shows she is thinking about his load, not only her own |
| R2 | "You've worked across pricing, monetization and a startup. Which pricing call would you make differently at a larger company?" | Tied to his own path; turns an interview into a peer conversation |
| R3 | "Where does pricing work hand off to the launch motion for a new product, and who decides?" | Surfaces the seam; signals she is thinking about his team's work |
| R4 | "How are you thinking about the Compass launch against the bundling threat?" | Uses your research note; shows she knows the stated priorities, provided they are still current |
| R5 | "How are partner motions decided today, and who owns them?" | Probes the partner gap directly; a useful answer tells her what the role inherits |
| R6 | "What would make the first two product lines a clear win by the next planning cycle?" | Asks for the success definition, which her answers can then be measured against |

## Sources

Provided documents: your message (JD highlights, research note, interviewer profile); the coach's notes (Priya's background). No dossier was present.

Searches and fetches sent:

| Query | Result |
|---|---|
| Northwind Data B2B data infrastructure strategy recent news | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | No values-style round is detected; your note fixes the loop as one peer conversation, so no values output is produced |
| 2. Interview process | skipped | Your note establishes the loop (one 60-minute conversation with Dan), which fixes the persona weights |
| 3. Strategy / recent news | unavailable | Search refused by the host. Would have checked your research note and set the CO bank's currency |
| 4. Interviewer footprint | unavailable | Search refused by the host. Would have informed the interviewer read and R2 |
| 5. Representative JD | skipped | Your JD highlights are in hand |

Research tier: L1, searches 2 of 6, fetches 0 of 2; user links read 0.

## Upgrade menu

- The full JD text → the JD-tagged rows move from highlight-level to exact quotes, and the requirement coverage can be checked against the whole list.
- Priya's own account of the $400M figure and the carrier model (her answers to the slots, quoted into the fit snapshot) → A1, A2, D3 and E2 get her own sentences instead of slots.
- Priya's confirmation of the coach's-notes lines in her own words → F1, F2, F3 and F6 can be re-graded; a quote she confirms moves up from its current band.
- A working search for Northwind's current strategy and Dan's public talks or writing → the grounding brief is checked, and R2 can name one of his real themes.
- A deeper research pass (up to 6 more searches and 2 more fetches) → a fuller strategy brief for C1 to C4.
