Your prep pack for all three rounds is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-6-denied-d886dd92/914ecdc9-ec03-4a3a-80fb-9bbe379bc7f8/scratchpad/Larkfield_Systems_engineering_manager_interview_pack.md`. It has a shared fit snapshot, a per-round persona table and 8–10 questions per round, reverse questions for each round, and an upgrade menu.

**Research didn't run.** Web search was refused for this session, so I couldn't check Larkfield's values, its interview process or its strategy. The values cheat sheet for the VP round is therefore omitted, and the strategy question is generic. The pack is built on the role description and your message only.

**The two things to rehearse most:**
- **Managing managers and the hardware roadmap.** You've stated both gaps yourself. The pack gives you a plain acknowledgment ("I haven't managed managers"), then a plan for how you'd learn it. Hold that plan through two follow-ups. Expect it in Round 1 (A5) and again with the VP (C5).
- **The 60% on-call figure.** It will be probed in every round. Be ready to say how it was counted, which assumption you'd defend least, and which part was yours. The quote gives sequence, not cause, so don't say the quarter caused the drop.

Two questions so I can tighten the gate and the requirement rows:
1. Could you paste the full job description and your CV? Either one moves rows from the role-description quotes to the real posting and your own words.
2. Is this role based at a Larkfield site, and is it on-site, hybrid or remote? That's the one gate the material doesn't settle.

Want a drill? I can play the Round 1 hiring manager on A5, the most predictable objection. I can also save a `tuesday-dossier.md` to carry these gaps into later sessions, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering_manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview pack (loop mode, three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Round 1, Tuesday, 45 min: Director of Engineering (hiring manager)
- Round 2, Thursday, 60 min: panel of two staff engineers and a product manager
- Round 3, the following Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

No change since the first version: first pack.

## How to use

Personas describe how a question is asked. Types describe what is being scored:
- **EXP**: work-experience deep-dive. Does what you did survive scrutiny?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge. Not available this session (see Sources).
- **CASE**: live problem from the role, reasoned aloud.
- **VAL**: behavioral, mapped to values. No published values are in hand (see Sources).

Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Shared fit snapshot

The requirements come from the role description in your message. No full job description was supplied, so every requirement is quoted from that description. Your evidence is quoted from your message. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six. The two-squad scope is not in it. Bridge at its own scope: "For three years I led a team of six." Answer slot: if you worked across a second team's delivery, say what you did there in your own words; if you did not, say so plainly and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | The quote reaches hiring, for backend roles. The bridge only rewords it: "I run our hiring loop for backend roles; about 40 interviews last year." It adds no practice, figure or event. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Adjacent work: delivery under roadmap pressure, on a team of six, measured by one figure. Bridge at its scope: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." The quote gives sequence, not cause, so say it that way. The 60% raises the defend-the-number slots: how it was counted, the assumption you would defend least, and which part was yours. If you cannot say how it was counted, say so. |
| F4 | "partner with hardware and product on roadmap" (role description) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F5 | "device-management services" (role description) | "currently at a payments company" (your message) | medium | [grounded] | transferability | Adjacent backend and reliability work, in payments. Nothing in the material shows device-level or field-operated systems. Bridge: "I'm currently at a payments company." Answer slot: if you have built or run anything with device or hardware constraints, say what, in your own words; if not, say so and stay with the backend and reliability work. |
| G1 | Location and office pattern (role family, no source in the role description) | none given | none | [generic] | hard_gate | Your material does not establish your location or whether the role is on-site, hybrid or remote. Surfaced here, not bridged. Asked once, in the closing questions. |

**Wording note.** The "managers" gap sits in F4 because you stated it. The role description does not say whether this role has managers under it. Your answer changes how much of the VP round is about managing managers, so it is on the upgrade menu.

## Prohibited claims

Not coached, in any answer, hold, bridge or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" | Inflated form of F1 | "For three years I led a team of six." The limit is the pack's observation: your material says one team of six. |
| "I owned delivery for eleven engineers" | Inflated form of F3 | The F3 quote at its own scope. The pack's observation: your material gives one team of six and one figure. |
| "The quarter caused the 60% drop" | Inflated form of F3: cause read from sequence | The sequence the quote gives, "after I pushed". The pack's observation: the material gives sequence, not cause. |
| "I have managed managers" | Sourced negative, F4 | "I haven't managed managers." Plain acknowledgment, then a plan. No slot. |
| "I have owned a hardware-adjacent roadmap" | Sourced negative, F4 | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment, then a plan. No slot. |

## Persona weights per round

### Round 1: Director of Engineering (hiring manager), Tuesday, 45 min

Relationship prior for a hiring manager: Case/Strategist and Skeptic. They are buying capability and checking the gaps, so expect live problems on the two squads' roadmap. No interviewer name was given, so there is no interviewer read and no signal adjustment.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live roadmap and delivery problems | High: the hiring manager is buying capability for two squads | 4 questions | Clarify, then objective, approach, metrics, risks; think aloud |
| Skeptic | Probes on F4 and F1, the "why leave, why here" line | High: the gaps are visible in your own sentences | 3 questions | Rehearse the single most predictable objection until it is boring; concede specifically |
| Pressure | Time-boxed challenges on the 60% figure | Medium: a figure this strong gets pressed | 2 questions | Pause, restate, hold through two follow-ups, concede only the uncertainty |

**Question bank, Round 1**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The two squads have a device-management roadmap item due next quarter. Where do you start?" | CASE | [generic] | Clarify the deadline, the hardware dependency and who decides. Then state the objective, the approach, the metrics and the risks, thinking aloud. The question presupposes nothing about your past. | Live problem from the squads and roadmap line. Generic because it is a pattern for the problem, not a fact about this team. |
| A2 | "Two squads want different priorities from the same hardware team this quarter. How do you decide?" | CASE | [generic] | Name who decides and what you need from hardware and product before choosing. Say what you would do if they still disagree. | Raises the partner-with-hardware line as a decision, not a record. |
| A3 | "What do you do in your first 90 days?" | JD | [generic] | Structure it: listen first, one list of what you learn, then the decisions you would make and the ones you would wait on. | Onboarding probe from the delivery, hiring and growth line. |
| A4 | "How would you split time between roadmap delivery and reliability work across two squads?" | CASE | [generic] | Name the trade-off, the signals that move the balance, and who you would bring in. Answer from the problem. Use your reliability quarter only if asked for an example. | The trade-off F3 touches, kept as a live problem so it presupposes nothing about you. |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, as a plan: what you would read, who you would ask, what you would check first. Hold it; do not defend it. Follow up twice, and return each answer to the plan. Highest-ROI prep: this is the most predictable objection to you. Rehearse it until it is dull. | F4 is the gap an interviewer will find first. Deepest rehearsal in this round. |
| A6 | "You've led a team of six. Why would two squads be a step you can take?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Bridge at its own scope: "For three years I led a team of six." Answer slot: if you worked across a second team's delivery, say what you did there, in your own words; if you did not, say so plainly and stay with the team of six. Hold through one follow-up by returning to the team of six. | F1 is the scope gap in the role's first requirement. The premise is your quoted team size, so the question may presuppose it. |
| A7 | "Why are you leaving a payments company for industrial IoT?" | EXP | [grounded] "currently at a payments company" (your message) | Answer slot: give your own reason, in your own words. Your material does not state one, and nothing here supplies it. Say what draws you to device-management work, in your own terms. | Motivation probe the Skeptic runs against F5. The reason is yours to give. |
| A8 | "Sixty seconds: why you over someone who has owned a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Pause, restate the question, then answer from what you did: the reliability quarter and the team you ran. Hold through two follow-ups. Concede the hardware gap specifically, not the whole case. | Pressure stem aimed at F4. |
| A9 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend the number: say how the 60% was counted, the weakest assumption behind it, and which part was yours, in your own words. If you cannot say how it was counted, say so plainly. The pack supplies no method or baseline. | The figure raises the defend-the-number slots. The question is premised on the quoted figure and nothing else. |

**Reverse questions, Round 1**

1. "What is the first decision you'd want the new manager to own in the first 30 days?" *Why it lands:* it shows you are planning for the role, not for the interview.
2. "Which of the two squads is carrying the most delivery risk right now?" *Why it lands:* it turns the gap into a shared problem and shows you are thinking about the squads, not yourself.
3. "How does the hiring loop for this role run today?" *Why it lands:* you already run a loop for backend roles, so this signals you know what you are walking into.
4. "What did the last person in this role get right, and what did they struggle with?" *Why it lands:* it asks for the honest version of the job.
5. "Which hardware constraints shape the roadmap most?" *Why it lands:* it asks for the gap you named, without asking you to claim it.

### Round 2: panel (two staff engineers and a product manager), Thursday, 60 min

Relationship prior for a panel: blend the top two personas of each member's relationship. Staff engineers: Data-Driven Prober and Pressure. Product manager: Peer Evaluator and Case. No names were given, so personas are not assigned per member.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober (staff engineer A) | Follows the figures to their assumptions | High: the 60% and the 40 interviews are headline numbers | 3 questions | Know how each number was counted, say when you don't know, name the weakest assumption first |
| Peer Evaluator (product manager) | Seam questions, disagreement, credit | High: the PM prices what the hire does to the roadmap | 3 questions | Reciprocity: what you bring to their team; propose seam principles, not invented seams |
| Pressure (staff engineer B) | Challenges on attribution and scale | Medium: a claim to a team-level result gets pressed | 2 questions | Hold the quarter, concede the attribution if pressed |
| Case (panel) | Live technical and roadmap problems | Medium: a panel with a PM tends to run a case | 2 questions | Clarify, structure, state the trade-off, think aloud |

**Question bank, Round 2**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend the number: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if you cannot say how it was counted, say so plainly. | The Prober's first move on F3. |
| B2 | "Which assumption behind that on-call figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption before they do. If you do not know one, say so. | The second level of the same figure. The assumption is yours to name, not the pack's. |
| B3 | "About 40 interviews last year — which of those numbers would you defend, and how were they counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what the 40 counts, in your own words: interviews, candidates or loops. If you did not track it that way, say so. | The hiring figure is a headline number in your material. F2 is the row. |
| B4 | "Our teams sit side by side. Where's the seam between roadmap and reliability work, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Name how you would decide and who you would escalate to. | Peer probe drawn from the partner-with-hardware-and-product line. No past claim. |
| B5 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt. Pick a time credit was shared across teams. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Peer probe from a persona stem. No quoted sentence carries a credit story. |
| B6 | "What would you need from product to ship the device-management roadmap?" | CASE | [generic] | Clarify scope and the success measure first. Name the decisions you need product to make, and the ones you would make yourself. | Live problem for the PM. |
| B7 | "Sixty seconds: why should we believe the reliability quarter you pushed through was your doing?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold: the quarter, the roadmap pressure, the drop. Name what you did in the quarter, in your own words; if you cannot name it, say so. Hold through two follow-ups. Concede specifically on attribution if pressed, never on the quarter itself. | Pressure stem aimed at F3's attribution. The position held is the one the quote carries. |
| B8 | "That's a team of six. What would change if it were eleven?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Hold the team of six as the fact. Say what you would change and which of it you have done and which you have not. Answer slot: if you have managed more than six people, say so; if not, say so plainly. | Scale probe on F1 and F2. The premise is your quoted team size. |
| B9 | "Sketch the plan for a device-management item that depends on a hardware change. What do you need to know first?" | CASE | [generic] | Clarify the hardware dependency, the rollout and the rollback, then sequence the work. Think aloud. | Live problem for the staff engineers. |
| B10 | "If on-call load rose again next quarter, how would you diagnose it?" | CASE | [generic] | Structure: what changed, which services, what the on-call data shows, what you would fix first. | Hypothetical. No claim about the past. |

**Reverse questions, Round 2**

1. "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* a peer's question, and it turns the panel into a working conversation.
2. "Where do the roadmap and reliability work collide most often?" *Why it lands:* it asks for the seam you would otherwise have to guess at.
3. "When the PM and engineering disagree on priority, how is it resolved?" *Why it lands:* it signals you are thinking about the partnership, not only the team.
4. "What does on-call look like for the device-management services today?" *Why it lands:* it tests your reliability claim against their real load.
5. "What would make the first six months a success from your side of the table?" *Why it lands:* it asks the staff engineers to name their own bar.

### Round 3: VP Engineering, Monday, 30 min

Relationship prior for a skip-level: Case/Strategist and Pressure. The recruiter's words name a values and leadership round, so the Values/Behavioral persona leads. The recruiter's description is a loop source, so the three-round loop is established.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership and values | High: the round is named as values and leadership | 4 questions | STAR shape: "we" for context, "I" for what you did; map to a story only where your material carries one |
| Pressure | Composure challenges on managing managers | High: the VP is checking the gap you stated | 2 questions | Hold the plan through two follow-ups; concede what you don't know |
| Case/Strategist | Strategy-level questions at the VP's altitude | Medium: 30 minutes is short for a strategy question | 2 questions | Clarify, then take a position with the trade-off named |

**Values cheat sheet:** omitted. The recruiter's words establish a values-style round, but no published Larkfield values are in hand (see Sources). The section needs both.

**Question bank, Round 3**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Map the story to the quarter: the roadmap pressure, the trade-off you pushed, the drop. Answer slot: if the truth you took to leadership was unpopular, say what it was, in your own words; if the quarter did not involve one, say so plainly and give the nearest thing: the trade-off the quarter asked of product. | Persona stem. Your quote carries the story; the "unpopular" beat is not in it, so the second branch allows that none existed. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need changed a decision that an internal number pointed away from. Say what the number was and what you chose. If none comes to mind, say so plainly. | Persona stem. No quoted sentence carries a customer story. |
| C3 | "How do you grow the engineers you lead?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer from your own practice. The quote is about hiring, not growth. Answer slot: if you have grown an engineer into a larger role, say who and what you did, in your own words; if you have not, say so and describe how you would. | Leadership-philosophy probe. The quote supports hiring, not development. |
| C4 | "What's your leadership philosophy in one sentence, and what would your team say you get wrong?" | VAL | [generic] | Keep it to what you do and have done. Give one specific example of what you get wrong. Do not describe a team's view you have not heard. | Open leadership prompt. No past claim is made for you. |
| C5 | "You've never managed managers. Why should we believe you'll manage them well?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would do first, what you would watch, who you would ask. Said as a plan, never as a past. Highest-ROI prep for this round: hold the plan through two follow-ups, and concede what you do not know. | The VP's version of the Round 1 objection. The premise is your own quoted negative. |
| C6 | "How would you know whether that 60% was your doing or the team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: say which part was yours, in your own words, and what evidence you would point to. If you cannot separate the two, say so plainly. | Attribution probe on F3, aimed at leadership claims. Premised only on the quoted figure and sequence. |
| C7 | "We're deciding whether one owner should run hardware and product together. What would you say?" | CASE | [generic] | Take a position, name the trade-off, and say what evidence would change it. | Live leadership decision. No past claim. |
| C8 | "What is the strategic case for device-management services over the next two years?" | CO | [generic] | Research did not run this session, so argue only from the role description: reliability and manageability of connected devices. Say which parts you would verify before relying on them. | Company-strategy question without research. Generic because no strategy source is in hand. |

**Reverse questions, Round 3**

1. "What does leadership philosophy look like here when a roadmap commitment is missed?" *Why it lands:* it asks for their values in practice, not on a slide.
2. "Which values do you see teams here most often trade away under pressure, and why?" *Why it lands:* it is the honest version of the values question.
3. "What would you need a new engineering manager to change in the first quarter?" *Why it lands:* it asks for the VP's priority, in their terms.
4. "How does engineering work with hardware leaders on trade-offs today?" *Why it lands:* it tests the partnership line before the next round.
5. "What was the hardest leadership call you made in the last year?" *Why it lands:* a VP answers this in their own terms, which tells you how they decide.

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | A1, A4, A6, B8, B9 | |
| Own delivery, hiring and growth for 11 engineers | A3, A9, B1, B3, C3, C6 | |
| Partner with hardware and product on roadmap | A2, A5, A8, B4, B6, C7 | |
| Device-management services (domain) | A5, A7, A8, C8 | |
| Location and office pattern (gate) | none, and why: a gate is asked once, in the closing questions, not in a bank | |

## Sources

- Provided: your message (the role description and your background). No job description, no CV, no recruiter email.
- Research calls sent this session, all refused (web search permission was not granted):
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT device management strategy": refused

**Research tier: L1 — searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (omitted). Every call was refused. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. The three rounds are established from your message and the recruiter's words instead. |
| 3. Larkfield Systems strategy and recent news | unavailable | CO questions (C8 is generic). Every call was refused. |
| 4. Interviewer name and Larkfield Systems | n/a | No names given, so there was no query to form. The interviewer read is absent. |
| 5. Representative engineering manager JD | unavailable | Would have turned the role-description requirements into [inferred] rows. No call was sent, because this host refused search. |

## Upgrade menu

- Full job description text → F1 to F5 are quoted from the posting instead of the role description, and the requirement coverage table checks against the real list.
- Your CV → the evidence cells can quote it, and the rows can name the artifact that raises each band (for the 60%: the on-call data export it came from, which would move F3 toward high).
- Your location and office pattern → resolves G1, and tells us whether to rehearse on-site questions.
- Panel names and roles → per-member persona assignment for Round 2, and an interviewer read.
- Larkfield's published values page, pasted → the Round 3 values cheat sheet, and one VAL question per value.
- Recruiter's note on the round format → can reweight personas, especially the VP round.
- Web search permission → the three refused targets can run at L1 (values, loop process, strategy).
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several minutes. It needs search permission first.
- `tuesday-dossier.md` would carry this pack's gaps (the managers, the hardware roadmap, the 60% attribution) into later sessions.
