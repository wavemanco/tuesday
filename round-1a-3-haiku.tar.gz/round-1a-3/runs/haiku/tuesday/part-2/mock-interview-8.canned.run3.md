Three things stand out before you read the pack:

- **None of your four values has a story yet.** Your material gives no sentence that carries one, so the values answers in Round 3 are selection scaffolds that end in an honest "if none comes to mind, say so." Three real cases from your branch would fix that.
- **The gaps are stated, so answer them plainly.** You have never worked in a contact centre and never presented above regional level. The pack gives you the plain acknowledgment for each, then a ramp plan. It does not offer a bridge.
- **Your spreadsheet is the probe magnet.** The JD asks for monthly volumes and resolution times, and your material does not say what the spreadsheet counted. R3-10 and R3-11 are the questions to rehearse.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-8-canned-52a22e41/7cff7a8e-a24a-48a8-bf96-9ce56ba509a9/scratchpad/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md. I built it as a three-round loop, assuming the Head of Member Services and the panel are the people you'll meet, since their names aren't in yet. The pack has one shared fit snapshot, a mini-pack per round, the values cheat sheet in Round 3, and a list of what would upgrade it.

Say the word and I'll play the Skeptic on R2-6, "Which part of this role would you be weakest at on day one?" The pack names it as the highest-ROI prep, because presenting above regional level is the gap they're most likely to press.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Is your current branch one of the eight the brief folds into five hubs? The answer changes the consolidation questions in R2-7 and R3-3.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**For:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Loop (loop mode, three rounds, all on 29 November 2026):**
- Round 1: recruiter screen, 30 minutes
- Round 2: Head of Member Services (your future manager), 45 minutes, "mostly behavioural"
- Round 3: panel of two branch managers, 60 minutes, including a "20-minute case on a complaint escalation"; the panel "scores against the four values"

No interviewer names have been assigned yet, so the persona weights rest on the round types and the recruiter's description.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural and values alignment · EXP = deep-dive on your own experience · JD = the job's stated requirements · CO = company and strategy knowledge · CASE = live problem.
- **Provenance:** [grounded] = your sentences or a provided document · [inferred] = a derivation, named · [generic] = a pattern, not a fact about Ashgrove or about you.
- **Answer slot** = an instruction for the interview. It asks for your own answer in either branch it gives. It is not a question for this chat.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Fit snapshot (shared across rounds)

Requirements come from the JD you pasted. Evidence is quoted from your message only. The label "your message" means the background you wrote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end. Words: "For the branch, I handled the formal complaints log." Answer slot: if you took a complaint from first contact to closure, say which steps were yours; if the log was one stage of a longer process, say what the stages were and which you held. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you have stated. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The quote reaches monthly complaints reporting but does not show what the spreadsheet counted. Answer slot: if it counted complaint volumes or resolution times, say which and how you counted them; if it counted something else, say what it counted. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material does not name the tool the spreadsheet was built in. Answer slot: say which tool you built it in and what you did in it, in your own words; if it was not Excel, say what it was. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The quote is training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what the case was and what you did; if your coaching was only of tellers, say so and say how you would approach supervisors. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you worked with anyone on how members use a form, an app or a service, say what you did; if you did not, say so plainly. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | The quote reaches the years in other terms. Words, reworded only: "I have 6 years in retail banking, the last 3 as branch supervisor." Your material says retail banking, not customer operations; the match is for you to make in the interview, not for the pack to assert. |
| F8 | "experience handling regulated complaints" (JD) | "formal complaints log" (your message, in "I handled the branch's formal complaints log") | medium | [grounded] | discovery | Your material says formal complaints; it does not say regulated. Answer slot: if rules from outside the branch set deadlines, or required a case to go elsewhere, say which and what you did with them; if the log ran without such rules, say so plainly. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you have stated. Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan: the ramp, not a past. |

**Gate check:** the JD names no licence, credential or location term. Nothing here is a hard gate. Pay, notice, location and reason for leaving are not in the JD; they are covered by the recruiter-screen logistics slots in Round 1.

## Prohibited claims

Each entry names its basis. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. Limit, in this pack's analysis: your material says the branch's log, not the process. |
| Ran complaints across the contact centre | Inflated form of F2; negative you stated | "I haven't worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F9) | "I haven't presented to anyone above regional level." |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope. Limit, in analysis: your material says formal complaints, not regulated ones. |
| Set the escalation script | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Built reporting that measured volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. Limit, in analysis: the material does not say what the spreadsheet counted. |

## Persona weights

| Persona | Round 1 | Round 2 | Round 3 | Reasoning |
|---|---|---|---|---|
| Conversational / rapport | 6 (includes the 4 logistics slots, which are required whatever the weight) | none | none | Recruiter screens score logistics in a friendly register. |
| Skeptic | 2 | 2 | none | The two gaps you stated (contact centre, presenting above regional level) will be found early. |
| Values / Behavioral | none | 4 | 4 | The recruiter said "mostly behavioural"; the panel scores the four values. |
| Case / Strategist | none | 3 | 3 | The 20-minute escalation case sits in Round 3; Round 2 has three strategy and live-problem questions. |
| Peer Evaluator | none | none | 2 | Branch managers are colleagues who will test seams and credit. |
| Data-Driven Prober | none | 1 | 2 | The JD's monthly-report line makes your spreadsheet the probe magnet. |
| Pressure / Stress | no bank | carried in R2-6 | carried in R3-6 | Held inside those questions rather than given a separate bank; the hold-then-concede structure is there. |

## Grounding brief

Vocabulary as Ashgrove published it in its July 2026 strategy brief, as you gave it to me. Use these terms; you do not need to add numbers the brief does not give.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

The brief is four months old as of 20 November 2026. I did not search for anything Ashgrove has published since July, so treat these as current only as far as the brief goes. The consolidation line sits directly against the values line "every branch is part of its town"; see R2-7 and R3-3.

---

## Round 1: recruiter screen (30 minutes)

Relationship: recruiter. Personas: Conversational (weight 6), Skeptic (weight 2).

### Conversational / rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | Give the arc in about 90 seconds in those words: six years in retail banking, the last three as branch supervisor. Add nothing to the roles. | Opening biography. F7 is the spine of the loop, so the wording here is the wording the panel hears again. |
| R1-2 | "What drew you to a member-owned credit union?" | VAL | [grounded] "member-owned, about 900 staff" (JD) | Say what member ownership means at the counter, in your own words, and keep to what you have seen. Make no claim about what Ashgrove does that you have not checked. | Motivation is a screen item. The guidance makes no claim about your past. |
| R1-3 | "What are your pay expectations?" | JD | [generic] logistics slot | Logistics slot: give your own number, or ask for the band first. Give no figure or history you have not chosen to give. | Pay is a required screen item. The answer is yours alone. |
| R1-4 | "What's your notice period?" | JD | [generic] logistics slot | Logistics slot: give your actual notice period in your own words. | Notice is a knockout check. The pack does not know your period. |
| R1-5 | "Where would you be working, and what travel can you do?" | JD | [generic] logistics slot | Logistics slot: say where you live and the travel you can do, in your own words. Ask which office or hub the role sits in before you commit to a figure. | Location matters more than usual while branches move into hubs. Your material does not say where you live. |
| R1-6 | "Why are you looking to leave your current role?" | EXP | [generic] logistics slot | Logistics slot: give your own reason in your own words. The material gives none, so the pack supplies none. | Reason for leaving is scored. A reason you did not give cannot be scripted for you. |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-7 | "The role asks for four years in financial-services customer operations. Where does your background fit that?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message); "4+ years in financial-services customer operations" (JD) | Say "6 years in retail banking, the last 3 as branch supervisor", in those words. Then say what the branch work involved, in your own words. | F7: your quote reaches the years in other terms. The screen checks the knockout count early. |
| R1-8 | "You haven't worked in a contact centre. Does that matter for this role?" | EXP | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then say what you would do first to learn it, as a plan. | F2: a gap you stated. The question's premise is your own sentence, at its own scope. |

---

## Round 2: Head of Member Services (45 minutes)

Relationship: future manager. Mostly behavioural. Personas: Values / Behavioral (weight 4), Case / Strategist (3), Skeptic (2), Data-Driven Prober (1).

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "Tell me about a complaint from the log that was hard to close." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Beats the quote carries: the log, and the complaint you handled from it. Answer slot: if you took a complaint from first contact to closure, say which steps were yours; if the log was one stage, say what the stages were and which you held. Keep to the log's scope. | An open prompt on the JD's end-to-end line (F1). A hard-to-close case is the most likely behavioural probe for that line. |
| R2-2 | "Tell me about a time you trained new tellers on the escalation script." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story map from the quote: the training, the script, the tellers. Answer slot: if a teller got an escalation wrong, say what you did about it; if the training went without a problem, say so and say what you checked. | F5: your evidence is tellers, not supervisors. Tell the training at its scope. |
| R2-3 | "Tell me about a time a member came back a second time about the same complaint." | VAL | [grounded] "I handled the branch's formal complaints log" (your message); "Own the member complaints process end to end" (JD) | Open prompt: choose an instance from the log if one comes to mind. If none does, say so plainly, then say how you would handle a second contact on a complaint you had already closed. | Theme from the JD's ownership line. The rehearsal is staying with a case rather than inventing a new one. |
| R2-4 | "Tell me about a time you had to say something to a senior person that they did not want to hear." | VAL | [generic] "6 years in retail banking, the last 3 as branch supervisor" (your message) | Selection scaffold: pick a time you held a position under pressure from someone senior. It needs a named stake, a point you did not fold on, and a relationship that stayed intact. If none comes to mind, say so plainly, then give the nearest thing in your six years in retail banking. | No quoted sentence carries this story. The honest branch is the point, not a gap to hide. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-5 | "You've never worked in a contact centre. How would you run a complaints process across the contact centre and the branches?" | JD | [grounded] "Never worked in a contact centre" (your message); "Own the member complaints process end to end across branches and the contact centre" (JD) | Plain acknowledgment: "I haven't worked in a contact centre." Then carry the process you did run: "I handled the branch's formal complaints log." Say what you would learn first and from whom, as a plan. Hold through two follow-ups by returning to the log and the plan, not by claiming contact-centre work. | F2: the gap the panel will check. The question presupposes the JD's own end-to-end line, which the JD raises. |
| R2-6 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); "confident presenting to senior leaders" (JD) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a ramp plan, said as a plan: the first presentations you would ask for and what you would prepare. Do not describe presenting you have not done. Hold through two follow-ups; concede the gap specifically rather than stretch it. | **Highest-ROI prep in this pack.** F9 is a capability gap, and the Head of Member Services is the person who would manage the presenting. Expect this in some form. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-7 | "Branches are moving into five hubs in 2027. What happens to complaints from members in a branch that closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you gave it) | Clarify first: which branches, when, and what members lose access to. Then structure: where complaints from a closing branch go, who owns them through the move, how members hear about it, and what you would measure. Make no claim about your own branch. | Company strategy at the brief's altitude. The brief is the source; the wording is the interviewer's. |
| R2-8 | "Forty percent of member service moves to digital channels by 2028. Which complaints should move with it, and which should not?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you gave it) | Structure first: which complaint types a digital channel can close, which it cannot, and how a member is routed when it cannot. Name the one metric you would watch. | Tests whether you can think at the brief's altitude. Do not assume the 40% figure is right or wrong. |
| R2-9 | "Complaints come from branches and the contact centre into one process. What's the first thing you'd check?" | CASE | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Clarify before you structure: volumes by channel, how a case moves between channels, where the record lives. Name one premise you would challenge. Make no claim about having run such a process. | A live problem from the JD's own line, asked as a decision, so it needs no claim about your past. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-10 | "How would you know a complaint process is working?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name what you would measure first, in your own words. If the spreadsheet you built counted anything that shows the process working, say which and how; if it did not, say so and say what you would add. | The JD's monthly-report line (F3). The answer is the measure, not a number. |

### Reverse questions (Round 2)

| Question | Why it lands |
|---|---|
| "What would a good first six months in this role look like to you?" | Invites them to describe the job; you listen for what they will score. |
| "How do complaints move between branches and the contact centre today?" | Shows you have read the end-to-end line closely. |
| "Where is the self-service work heading between now and 2028?" | Ties the conversation to the brief's 2028 target without asserting a figure. |

---

## Round 3: panel of two branch managers (60 minutes, values round)

Relationship: colleagues across the branch network. Personas: Values / Behavioral (weight 4), Case / Strategist (3, including the 20-minute escalation case), Peer Evaluator (2), Data-Driven Prober (2). The values cheat sheet below lives in this round because the panel scores against the four values.

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | "When did you choose a member's view over a process?" | VAL | [grounded] "we decide from the member's side of the counter" (values, as you copied it); "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a complaint where the member's view and the process pointed in different directions. Say what you did and what the process said. If none comes to mind, say so plainly, then give the nearest complaint from the log you handled. | Members First, Always. No quoted sentence carries the story, so the answer ends in the honest branch. |
| R3-2 | "Tell us about a time a member needed something explained twice." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values, as you copied it); "trained new tellers on our escalation script" (your message) | Selection scaffold: pick a time a letter, call or script left a member needing a second explanation, and what changed afterwards. If none comes to mind, say so, then give the nearest teaching moment, at its own scope. | Plain Words. The panel is checking whether you treat wording as a fix. |
| R3-3 | "How do you keep a branch's town in view when the numbers point elsewhere?" | VAL | [grounded] "every branch is part of its town" (values, as you copied it) | Selection scaffold: pick a decision where a local view counted against a figure. If none comes to mind, say so, then say how you would keep the town in view as branches merge into hubs. Do not argue the brief's numbers. | Neighbours, Not Numbers. Collides with the consolidation brief (R2-7); keep to what you would do. |
| R3-4 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values, as you copied it); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a problem you found and kept hold of. If the spreadsheet came from one, say what the problem was and what you did; if it did not, say so, then give the nearest case from the log. | Own the Fix, which the panel scores directly. Do not stretch the spreadsheet into a fix you did not carry. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-5 | "A member's complaint has been escalated twice. The branch says it's with the contact centre; the contact centre says it's with the branch. Walk us through what you do." | CASE | [generic] pattern for a 20-minute escalation case | The panel's centrepiece. Structure: clarify the facts and the timeline, and which regulatory timelines apply; decide who owns the case today and say it aloud; tell the member what happens next, in plain words; find where it stalled; fix that across both sides; record it. Say what you would check first and what you do not know about the contact centre's side. | A live problem from the JD's escalation line. Asked as a decision, so it presumes nothing about your past. |
| R3-6 | "The branch manager tells you the fix is out of their hands. What do you say?" | CASE | [generic] pattern for an escalation follow-up | Hold first: restate who owns the case and what you asked them for, then say what you will do next. Concede specifically what is out of your hands. Never give up ownership of the case. | The Pressure follow-up inside the case. Hold-then-concede applies, and owning the fix is what the panel scores. |
| R3-7 | "Two branches give a member different answers on the same complaint in the same hour. What do you do?" | CASE | [generic] pattern for a conflicting-answers case | Clarify which answer is right. Stop the second answer, then set one answer and one owner. Say what you would tell the member, and in what words. | A short case to test composure within the 20 minutes. Presumes nothing about your past. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-8 | "Branch managers already coach supervisors on escalations. Where's the seam with your role?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Propose seam principles, not a map of other people's roles: who decides on the case, who coaches the supervisor, what gets reported. Make no claim about coaching supervisors. Your coaching of tellers (F5) can be offered at its own scope. | A peer seam probe. Reciprocity framing keeps it collegial. |
| R3-9 | "How do you handle credit when a fix spans two branches?" | VAL | [generic] pattern for peer credit questions | Selection scaffold: name who did what on the last cross-branch fix you were part of, in your own words. If you were not part of one, say so and say how you would share credit. | A peer question about credit. Presumes no past event. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-10 | "What did your monthly complaints spreadsheet count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if it counted complaint volumes or resolution times, say which, and how you counted each. If it counted something else, say what. If you cannot say, say so plainly. | F3: the quote reaches monthly reporting, not the measures. The answer is the measure. |
| R3-11 | "If your spreadsheet produced a figure you can name, which assumption behind it would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name one figure it produced and the assumption behind it you would defend least, in your own words. If no figure comes to mind, say so, and say what the spreadsheet was for. | The prober's standard move. A figure you have not given raises no further slot. |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story. Scaffold: pick a complaint where the member's view and the process pointed different ways. If none comes to mind, say so, then give the nearest complaint from the log you handled (F1). |
| Plain Words | If a member needs it explained twice, the writing was wrong. | No quoted sentence carries a story. Scaffold: pick a time a member needed a second explanation and what changed. If none, say so, then give the nearest teaching moment at its own scope (F5). |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Scaffold: pick a decision where a local view counted against a figure. If none, say so, then say how you would keep a town in view as branches merge. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No quoted sentence carries a story. Scaffold: pick a problem you found and kept hold of. If the spreadsheet (F3) came from one, say what it was; if not, say so, then give the nearest case from the log (F1). |

### Reverse questions (Round 3)

| Question | Why it lands |
|---|---|
| "What could a new person do in their first month that would genuinely help your branches?" | Reciprocity: turns the panel into colleagues and shows you think about what you bring them. |
| "When an escalation crosses two branches, how does it get decided today?" | A real seam, asked as a question. It shows you know escalations cross sites. |
| "How are branch managers keeping 'every branch is part of its town' true while branches consolidate?" | Shows you have read the values against the brief, without arguing the brief. |

---

## Sources

- **Provided documents:** the JD you pasted; the values text as you copied it from the values page this morning; the recruiter's process email; the strategy brief as you summarised it and the recruiter sent it; your background in your message. Every quote in this pack comes from these or from your message.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. No search was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values text in hand, copied this morning. It fixes the values cheat sheet. |
| 2. Interview process, Member Experience Lead | skipped | The recruiter's email fixes three rounds, their lengths, interviewer types and the scoring. It fixes the persona weights. |
| 3. Strategy and recent news | skipped | The strategy brief in hand covers current priorities and recent moves. Nothing published after July 2026 was checked. |
| 4. Interviewer name | n/a | No names given. The Head of Member Services and the panel are not yet assigned. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1-7, F7 |
| Experience handling regulated complaints | R2-1, R3-5, F8 |
| Confident presenting to senior leaders | R2-6, F9 |
| Comfortable with Excel reporting | R2-10, R3-10, R3-11, F4 |
| Own the complaints process end to end across branches and the contact centre | R2-3, R2-5, R2-9, F1, F2 |
| Report monthly on complaint volumes and resolution times | R2-10, R3-10, F3 |
| Coach branch supervisors on escalations | R2-2, R3-8, F5 |
| Work with digital teams on self-service journeys | R2-8, F6 |

## Upgrade menu

- **Your CV, pasted in full** → checks every quote in the fit snapshot against exact wording, and can carry sentences the snapshot does not yet hold.
- **The monthly complaints spreadsheet, with names removed** → F3 and F4 can move from medium confidence with an inspectable artifact in hand, and R3-10 and R3-11 get their real answers.
- **Three real complaint cases from the log** → the four values rows move from scaffolds to story maps, and R2-1, R2-3 and R3-1 get their stories.
- **The role's location, hours and pay band** → R1-3 and R1-5 can be answered against the actual terms. Your own number stays yours.
- **Your current branch, and whether it is one of the eight the brief folds into hubs** → R2-7 and R3-3 can name the specific consequence rather than the general one.
- **Prep time available before 29 November** → a day-by-day prep schedule, which this pack has not built.
- **Interviewer names, once assigned** → personas per member of the panel, and reverse questions aimed at each person's own path.
- **A search of Ashgrove's news since July 2026** → R2-7 and R2-8 checked against anything published since the brief.
- **A tuesday-dossier.md** → would carry the gaps this pack found (F2, F9 and the answer slots) into later sessions, so each one is checked against the next round's material.
