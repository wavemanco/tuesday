Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-2-denied-6d8650ca/bb73e920-f01c-460b-bdd6-497dcb9ebd71/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it on a blend of hiring-manager and panel weightings, since your note doesn't say who you're meeting. I could not research Atlas Freight: the web searches were refused by the session's permissions, so the pack has no company values, interview-loop structure or strategy in it.

The biggest thing to rehearse is A1: the posting covers four sites and twelve supervisors, and your material shows one site and three supervisors. Practise naming what you actually run, conceding the scale plainly, and giving a ramp plan you would really follow. The other gaps are Power BI (you've never used it, so answer with a learning plan, not a claimed skill) and the five years of leadership, which your record may or may not cover.

Offers, one line each:
- I can play the Skeptic on A1 as a live drill, with follow-ups that react to your answers.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you want one.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Round: not yet known (built on a blended weighting, hiring-manager prior). Interviewer: not named. Research: unavailable this run (see Sources).

## How to use

Personas are how a question is asked. Types are what is being scored:

- **EXP**: your past work, tested for detail and attribution
- **JD**: a requirement from the posting
- **CO**: company and strategy knowledge (not covered this run)
- **CASE**: a live problem from the role
- **VAL**: behaviour against published values (not covered this run)

Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's shift and its peak-season plan, not multi-site terminal operations. Bridge: "I have run one site's shift and its peak-season surge plan for two years." Answer slot: the posting asks about daily ownership across four sites, so expect a probe on it. If you ran anything across more than one site, say what and how, in your own words; if not, say so plainly and describe how you would set up the daily rhythm. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors. Bridge: "I lead three supervisors now." Answer slot: if you have led a larger span, say how many and when; if not, say so and say how you would organise twelve. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | A mis-pick rate is an accuracy measure; the posting's measures are on-time and cost per shipment. Bridge: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost-per-shipment figures in that work or elsewhere, say which and how they moved; if you did not, say so plainly. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | medium | [grounded] | presentation | Your material shows Excel, not reporting built in it. Bridge: "My Excel is solid." |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | discovery | Your material shows seven years of operations and a senior shift role, but not how many of those years were leadership. This is a length-of-experience requirement, not a gate. Answer slot: give the date your first supervisory role began, from your own record; if it is under five years, say so and lead with the seven years of operations. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Lead with the certification in your own terms. |

Gates: the posting names no location, schedule or credential bar, so no gate row is needed.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. Your material says one site's shift and its peak plan. |
| Led a team of 12 supervisors | Inflated form of F2 | Three supervisors, as quoted in F2. |
| Drove on-time performance or cost-per-shipment down | Inflated form of F3 | The mis-pick rate, as quoted in F3. |
| Built Power BI reporting | Negative you stated, F5 | "I have never used Power BI." No slot. |

## Persona table

No relationship was given, so weights blend the hiring-manager prior with a generic panel. No loop source was read, so no values round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the span, the four sites and the Power BI gap | High: F1, F2, F5 and F6 are the posting's biggest gaps against your material | Rehearse A1 until it is plain. Name what you have run, concede the scale, give a ramp plan. |
| Case/Strategist | Live problems on daily performance across sites | High: the posting's daily-operations and cost requirements invite live problems | Clarify, then structure, then metrics, then risks. Think aloud. |
| Data-Driven Prober | Asks how the 40% was counted and what the cost figures were | Medium: the 40% is your headline number | Say how it was counted, or that you do not know; name the assumption you would defend least. |
| Pressure | Time-boxed challenges to the span and the tool gap | Medium: the span and Power BI gaps are the obvious pressure points | Pause, restate, hold the position through two follow-ups, then concede the specific point. |
| Values/Behavioral | Scenario and story questions | Low: no values were read and no loop source names a values round | Two rehearsal questions; use the honest branch where no story exists. |
| Conversational | A "walk me through" opener | Low: casual openers are still scored | A 90-second arc built only from quoted sentences. |
| Peer Evaluator | Seams with adjacent teams | Low: only if the round is with a peer | Two questions on inputs and seams. |

## Question banks

### Skeptic (weight high; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers four sites and twelve supervisors, and your current span is three supervisors. What makes you the risk worth taking?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | The highest-ROI rehearsal in this pack. Name what you run now, in those words: three supervisors, and a site's peak-season plan two years running. Concede the scale plainly: "Four sites and twelve supervisors is more than I have run." Then a ramp plan you would actually follow, in your own words. Hold through two follow-ups by returning to what you ran; concede the scale, not the capability. Answer slot: if you have managed beyond one site or beyond three people in any role, say what and how; if not, say so. | F1 and F2 are the biggest gaps against the posting, so this objection will arrive in some form. JD because it scores the stated scale. |
| A2 | "Where would you be weakest on day one?" | Open | [generic] | Pick the one gap you would close first, name it, and say how you would find out where the others are. Make no claim about your past. | A standard skeptic opener; the answer stays inside what you know. |
| A3 | "Power BI is in the job and you have not used it. How long until you are productive in it?" | JD | [grounded] "never used Power BI" (your message) | "I have never used Power BI." Then how you would learn it: what you would build first and when you would start. Give a timeframe only if you have one. Do not claim any Power BI work. | F5 is a stated gap. A plan answers it; a claimed skill does not. |
| A4 | "Five years of operations leadership is required. When did your leadership begin?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the dates your first supervisory role began, from your own record. State the count of years you can support; do not round up. If it is under five, say so and lead with the seven years of operations. | F6 is discovery: the answer is yours to give from your record. |
| A5 | "What would make you leave this role within eighteen months?" | Open | [generic] | Answer for the motivation you actually have, in two sentences. No script. | Motivation probes are standard for skeptics; the answer must be yours. |

### Case/Strategist (weight high; 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our four sites are missing on-time targets on Monday mornings. How would you diagnose it in your first two weeks?" | CASE | [generic] | Clarify first: which sites, which shifts, what counts as on time. Then segment by site, shift and lane, approach, metrics, risks. Think aloud and name one premise you would test. Make no claim about your past. | Live problem from the posting's on-time requirement. |
| B2 | "Cost per shipment rose 8% quarter on quarter. Walk me through what you would check." | CASE | [generic] | Before analysing, ask how cost per shipment is counted: which costs, which shipments, which period. Then segment and test one cause at a time. | The figure's counting is the weakest assumption; asking about it first is the move. |
| B3 | "What would you need to know in your first week at a site you have never run?" | Open | [generic] | List three or four inputs: the site's volumes, its people, its current targets, its incidents. Name who you would ask. | Tests structure without any claim about your past. |
| B4 | "What would your first 90 days look like?" | JD | [generic] | Sequence it: first learn and measure, then fix one thing, then build the reporting cadence. Keep it plausible for four sites. | Covers the posting's daily-operations and reporting requirements as a plan. |

### Prober (weight medium; 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how it was counted in your own words: the denominator, the period, the sample. Name the assumption behind the 40% you would defend least. Answer slot: if you did not design the count, say whose it was; if you do not know how it was counted, say so plainly. | The 40% is your headline figure, so it will be probed. |
| C2 | "Which assumption behind the 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption in your own words before it is asked. Answer slot: if you cannot name one, say that plainly; do not supply a method. | Weakest-assumption move for a figure. |
| C3 | "Did the 40% change cost per shipment or on-time performance?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Mis-pick is an accuracy measure. Answer slot: if you tracked on-time or cost figures in that work, say which and how they moved; if you did not, say so plainly and say the 40% is accuracy. | F3's gap, rehearsed so the honest answer is ready. |
| C4 | "How would you lay out a daily on-time report for four sites in Excel?" | JD | [grounded] "solid Excel" (your message) | Describe the layout: one row per site and shift, the fields, the refresh and who reads it. Answer in Excel terms; claim no past report. | F4 is presentation: Excel is the tool you can speak to. |

### Pressure (weight medium; 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over an internal candidate who already runs twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, then restate the question. Hold: name what you run now and what you have carried, in your words. Concede: "An internal candidate who has run twelve supervisors has more of this than I do." Hold through two follow-ups, then concede only the specific point. | Pressure on F2 in a time box. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Give the split as it was: what you did, what the team did, in your words. If the redesign was shared, say so. | Attribution honesty under pressure. |
| D3 | "You have never used the tool this job names. Why would I not hire someone who has?" | JD | [grounded] "never used Power BI" (your message) | Hold on what you can offer: solid Excel and the reporting you can build in it. Concede the gap plainly, then your learning plan. Do not fold on the core claim. | F5 under pressure. |

### Values/Behavioral (weight low; 2 questions)

No values were read and no loop source names a values round, so no VAL question has a mapped story. The honest branch applies.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell a senior manager something they did not want to hear." | VAL | [generic] | Pick a time that had a named stake, a moment you held your view, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing you have done or how you would handle it. Your material carries no such sentence. | Open prompt; the honest branch is required. |
| E2 | "Describe a time you had to make a call without all the data." | VAL | [generic] | Pick a time with a clear decision and its stake. If none comes to mind, say so plainly, then give how you would decide with incomplete figures. | Open prompt; the honest branch is required. |

### Conversational (weight low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: the seven years, the shift role, the pick path, the peak plan. Use only the quoted terms. | Casual openers are scored. |
| F2 | "What are you actually playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Say what the green belt covers. Answer slot: if you have applied it since certifying, say where; if not, say so. | The plus-skill asked casually. |

### Peer Evaluator (weight low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "If you joined, what would you need from my team?" | JD | [generic] | Name two or three inputs you would need, such as volumes, the reporting feeds and the shift calendar. Claim no past. | Reciprocity framing. |
| G2 | "Where is the seam between operations and the teams beside it, and what happens when you disagree?" | Open | [generic] | Propose seam principles, not a seam you have not seen. For disagreement, name one time you held a view with a peer and how it ended, only if you have one. | Peer seams are probed with this shape. |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, B1, B4 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C3 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A3, C4, D3, B4 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | F2 |

## Reverse questions

Interviewer details are unknown, so these are role-generic.

1. "What does a strong first 90 days look like in this role?" Why it lands: it shows you plan in the terms they will measure.
2. "Which of the four sites is furthest from its on-time target today, and what is it doing about it?" Why it lands: it shows you read the job as a site problem.
3. "How are on-time performance and cost per shipment counted: per shipment, per site, or per shift?" Why it lands: it asks the same counting question you will be asked, from their side.
4. "What reporting exists today, and what do they wish it did?" Why it lands: it tests the Excel and Power BI requirement from their side.
5. "How is the team of twelve supervisors set up, by site or by shift?" Why it lands: it turns the scale question into a conversation about structure.
6. "What have the last people in this role found hardest?" Why it lands: it invites the honest picture of the job.

## Sources

Provided documents: the job description and your background, as given in your message.

Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10. No values were read, so no cheat sheet. Queries sent: "Atlas Freight values" (refused). |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure. Persona weights rest on the hiring-manager prior, not a known loop. Queries sent: "Atlas Freight interview process operations manager" (refused). |
| 3. Atlas Freight strategy and recent news | unavailable | CO bank, and the grounding brief. CASE questions are generic. Queries sent: "Atlas Freight regional logistics strategy news" (refused). |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

The three searches were refused by the host's permission setting. They were not retried.

## Upgrade menu

- The round type and who is interviewing → persona weights and reverse questions for that round
- The interviewer's name → a tailored reverse question, and weights from their public footprint
- Atlas Freight's values page, pasted → the values cheat sheet and VAL questions with mapped stories
- The recruiter's note on focus areas or any deliverable → coverage of anything they have announced
- Web search permission for this session → the company research this run could not do: values, interview process and strategy, which would upgrade rows 1 to 3 above
- A sample of a report you built in Excel → upgrades F4 from presentation toward a checkable artifact
- Figures for on-time performance or cost per shipment from any past work → answers the F3 slot in your own words
- How much prep time you have → a prioritised schedule in place of the full pack
- A tuesday-dossier.md → carries this session's gaps into later prep without re-deriving them
