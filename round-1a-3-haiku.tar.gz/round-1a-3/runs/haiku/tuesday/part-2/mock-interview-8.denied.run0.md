Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-8-denied-ac65391e/13c13424-d5d9-440f-84f7-f0dfae2fc9b3/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as a loop, with each of the three rounds weighted to its own format.

The two biggest things to work on:
- **The contact-centre gap (H5).** The JD's headline line asks you to own complaints "across branches and the contact centre," and you've never worked in one. Expect it early. The pack gives you a plain answer ("I haven't worked in a contact centre") followed by a concrete plan for learning it.
- **The four values have no true stories yet.** Your sentences don't carry a member-side decision, a plain-words moment, a town-versus-numbers case, or a complaint taken to close. Each value in section 5 is a scaffold with an honest "say so" branch. Three real stories from your own experience would fix that.

Say the word and I'll play the Skeptic on H5. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Do you know which hub or branch this role would sit in?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Format:** loop mode, three rounds on 29 November 2026
- **Round 1, recruiter screen (30 min):** the recruiter.
- **Round 2, behavioural (45 min):** the Head of Member Services, who would be your manager.
- **Round 3, panel (60 min):** two branch managers, including a 20-minute complaint-escalation case. The panel scores against the four published values.

**Built on:** the recruiter's note that the panel is the values round and round 2 is mostly behavioural; the job description you pasted; the four values as you copied them; your four-point summary of the July 2026 strategy brief; and the background in your message. No CV was supplied, so the fit snapshot quotes your message.

**Date check:** 29 November 2026 is a Sunday. Confirm the date and times with the recruiter.

**Changelog:** first version.

---

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows a published value |
| EXP | Your own past work, probed for what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, reasoned through aloud |

Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words. Where a cell says "say so plainly," that is an answer, not a failure.

---

## 2. Fit snapshot (shared across all three rounds)

Requirements are quoted from the job description. Evidence is quoted from your message, marked "your message." The JD and your message set no location, schedule, credential or eligibility term, so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | "Six years in retail banking, the last three as a branch supervisor." Length of experience is not a gate, and the quote reaches the requirement in role terms. Expect a probe on "customer operations": your words say branch, so keep to branch. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | "I handled the branch's formal complaints log." The JD says regulated; your words do not say what rules the log followed. Answer slot: the JD raises the rules, so expect the probe. If the log followed rules you know of, name them and what you did under them. If no outside rules applied that you know of, say so and say what the log did carry. |
| F3 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | "I handled the branch's formal complaints log." That is one branch's log. Observation, not words for you: the material shows a branch log, not an end-to-end process. Stay with the log. |
| F4 | "own the member complaints process end to end across branches and the contact centre" (JD, contact-centre part) | "Never worked in a contact centre" (your message) | high | [grounded] | capability | "I haven't worked in a contact centre." Then how you would learn that side of the process, said as a plan, never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | "I built the monthly complaints spreadsheet our regional manager uses." The quote reaches monthly complaint reporting; it does not show resolution times. Answer slot: if the spreadsheet tracked how long cases took, say how. If not, say so and say what you would add first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | "I trained new tellers on our escalation script." Tellers, not supervisors. Answer slot: if you coached anyone beyond tellers on escalations, say who and how. If not, say so and say how you would coach a supervisor, as a plan. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a team on a self-service journey, say what you did and whose decision it was. If you have not, say so and say what you would bring from complaints work. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | high | [grounded] | capability | "I haven't presented to anyone above regional level." Then how you would prepare for that room, as a plan. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." Excel is not named in your words. Say "the spreadsheet," and do not claim a level of Excel skill the material does not show. |

**Observation (analysis, not words for you):** the snapshot's biggest gaps sit in the JD's headline lines: the contact centre (F3, F4), presenting above regional level (F8), and the self-service work (F7). Those are where the rehearsal time should go.

---

## 3. Prohibited claims

Not coached in any cell of this pack. The basis decides the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F3 | F3's quote at its own scope. Observation: the material shows one branch's log. |
| Ran complaints across branches and the contact centre | Inflated form of F3; contact-centre part sourced by F4 | "I haven't worked in a contact centre." |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Reported resolution times every month | Inflated form of F5 | F5's quote at its own scope. Resolution times are not in it. |
| Advanced or strong Excel | Inflated form of F9 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." |
| Contact-centre experience | Negative you stated, F4 | "I haven't worked in a contact centre." |

Not listed: digital or self-service delivery (F7). Your material is silent on it, so F7 holds an answer slot rather than a prohibition.

---

## 4. Persona weights

**Round 1, recruiter screen.** Prior: conversational with light skeptic. Conversational is top weight (six rows, because four are the logistics checks a recruiter screen always runs). Skeptic is low weight (two rows); F4 is the likeliest probe even here.

**Round 2, Head of Member Services.** Prior: hiring manager, so case plus skeptic. The recruiter's "mostly behavioural" moves the top weight to values/behavioural (four rows). Skeptic is mid (three rows), because the two negatives in F4 and F8 are the manager's decision to make. Case is low (two rows).

**Round 3, panel.** Panel prior: blend of two members. The recruiter says the panel is the values round, so values/behavioural is top (four rows). Case is low-mid (two rows: the escalation case and the strategy case). Pressure is low (two rows). Peer evaluator is low (two rows), because branch managers are peers to the teams you would work with on seams.

| Round | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational | Friendly opener, logistics in a casual register | Top, six rows: the four logistics checks are scored | 90-second arc; answer each logistics row in your own words |
| 1 | Skeptic (light) | Quiet question on the contact centre and motivation | Low, two rows: F4 is the likeliest probe even in a screen | Plain acknowledgment, then the plan |
| 2 | Values/behavioural | STAR-shaped prompts on ownership and coaching | Top, four rows: the recruiter's "mostly behavioural" | Story from your sentences; "I" for what you did |
| 2 | Skeptic | Probes the two negatives on this JD | Mid, three rows: the manager decides on the gaps | Name each gap plainly, then the plan |
| 2 | Case/strategist | Day-one and reporting problems | Low, two rows | Clarify, then structure, then a first step |
| 3 | Values/behavioural | Scored against the four values | Top, four rows: the recruiter's words | One story per value, or the honest branch |
| 3 | Case/strategist | 20-minute escalation case; strategy case | Low-mid, two rows | Clarify, one owner, member first |
| 3 | Pressure | Holds after the case; "why you" challenge | Low, two rows | Hold on what you did; concede the gap plainly |
| 3 | Peer evaluator | Seams with branches and the contact centre; credit | Low, two rows | Propose seam principles; say what you would bring |

---

## 5. Values cheat sheet (round 3)

The recruiter's email says the panel scores against the four values, so this section applies. None of your sentences carries a full story for any value. Each row is a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No sentence of yours carries a member-side decision. Pick a time you changed how a complaint went because of what the member needed. If none comes to mind, say so plainly, then give the nearest thing your material carries: F2, "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | F6 carries teaching: "trained new tellers on our escalation script." If you changed how something was explained so it worked first time, tell that. If the only explaining you did was the tellers' script, say what it asked of them and how you taught it. If neither, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | No sentence of yours carries the town. F5, "I built the monthly complaints spreadsheet our regional manager uses," carries the report. Pick a time the monthly figures looked fine and a branch knew otherwise. If none, say so: your material shows the report, not the town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | "Handled" is not "held until solved," and no sentence of yours shows a complaint taken to close. Pick a problem you found and stayed with until it was solved. If you passed any on early, say to whom and why. If none, say so. |

**Largest round 3 gap (analysis):** all four values rest on scaffolds. Three specific true stories would turn them into mapped stories (see the upgrade menu).

---

## 6. Grounding brief (Ashgrove strategy)

Source: your four-point summary of the July 2026 strategy brief. The full brief was not supplied. Nothing here is checked against it.

- **Language to learn:** "member service," "digital channels," "hubs," "small-business lending product," "app-only banks."
- **Priorities as you summarised them:** move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027; launch a small-business lending product in Q1 2027.
- **Competitive frame:** the main pressure is app-only banks.
- **Tension to expect (analysis):** "Neighbours, Not Numbers" sits beside a plan that folds eight branches into five hubs. Expect a probe here (P3, P7).
- **Stale framings:** none identified in the summary.

---

## 7. Round 1: recruiter screen (30 min)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Ninety-second arc in this order: six years in retail banking, the last three as a branch supervisor, and the formal complaints log you handled. Stop there and invite the next question. Add no size, no title and no outcome. | Casual in register, scored all the same. Sets the first impression of F1 and F2. |
| S2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot. Give your own number, or ask the recruiter for the band before you answer. This pack supplies no figure and you should not guess one. | Pay is a knockout check. The only safe answer is your own. |
| S3 | "What notice would you need to give where you are now?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words. | Notice is a logistics check. No figure is supplied here. |
| S4 | "Where would you need to be based, and how often on site?" | JD | [generic] | Logistics slot. Say where you can work, in your own words. If you do not know which hub or branch the role sits in, ask the recruiter before you answer. | Location is a term your material does not settle. See the upgrade menu. |
| S5 | "What's prompting the move?" | EXP | [generic] | Logistics slot. Give your own reason, in a sentence or two, and only if it is true for you. Do not borrow a reason from the strategy brief. | Reason for leaving is asked in every screen. Your message gives none. |
| S6 | "You've never worked in a contact centre. What makes this role different?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then answer slot: the JD asks for the contact centre, so say how you would learn it, as a plan. Never as a past. | F4 is the headline objection; a recruiter may raise it before the rounds do. |
| S7 | "Why this role, and why now?" | CO | [generic] | Scaffold: say what draws you to member-side complaints work, in your own terms. If the true reason is one the material does not carry, say it in your own words, not the brief's. | Motivation consistency. The screen checks it before the rounds do. |
| S8 | "What are you actually doing in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built: the monthly complaints spreadsheet, for your regional manager. Name only tools you have used. Do not claim advanced Excel. | A casual question on a JD plus-skill is scored. F9 is the gap. |

### Reverse questions

1. **"Which of the three rounds weighs most for this role?"** Why it lands: tells you where to spend the nine days before 29 November.
2. **"Which hub or branch would this role sit in?"** Why it lands: settles the location logistics in S4 and the framing of P7.
3. **"What takes up most of this role's week?"** Why it lands: shows you are planning around the work, not the title.

---

## 8. Round 2: Head of Member Services (45 min, your manager)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a complaint you took from first contact to close." | JD | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick one you handled from start to finish. If you handed any part on, say which part and to whom. If none went all the way, say so and give the nearest thing your material carries: the formal log you handled. | The JD's end-to-end line. F3 is the gap it tests. |
| H2 | "Tell me about a time you coached someone on an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story map from F6: you trained new tellers on the escalation script, which are the beats the sentence states. Answer slot: if you coached a supervisor on escalations, say so and how. If your coaching was of tellers, say that, and how you would coach supervisors, as a plan. | The JD's coaching line. The slot keeps tellers and supervisors apart. |
| H3 | "Tell me about a time you moved a service step onto a self-service channel." | JD | [generic] | Open prompt. Answer slot: if you have done this, say what you did and whose decision it was. If not, say so and say what you would look at first. | F7 has no quote. The JD raises digital work, so this question is likely. |
| H4 | "What rules did the formal complaints log follow?" | JD | [grounded] "I handled the branch's formal complaints log" | Premised on the log only. Answer slot: the JD says regulated, so the probe is likely. If the log followed rules you know of, name them and what you did under them. If no outside rules applied that you know of, say so and say what the log did carry. | F2. "Regulated" is not in your words, so the second branch must stay open. |
| H5 | "I don't see contact-centre work in your background. How would you run complaints across a contact centre you haven't worked in?" | JD | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Plain acknowledgment: "I haven't worked in a contact centre." Then the plan: what you would learn first, from whom, and how you would check it with the team. Hold through two follow-ups by returning to the plan. If pushed, concede plainly that you do not yet know that side. Never describe a contact-centre task you have not done. | F4 is the gap the JD's headline line rests on. The skeptic will ask it in some form. |
| H6 | "You haven't presented above regional level. How would you take complaint trends to the executive team?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would show, and how you would prepare with your manager. Do not describe a presentation you have not given. | F8. "Confident presenting" is a headline requirement. |
| H7 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the contact-centre part first, then presenting above regional level, each with its plan. Do not pick a strength to soften the answer. | Persona stem. Your answer sorts the two negatives you stated. |
| H8 | "What do you fix first in complaints across branches in your first 90 days?" | CASE | [generic] | Structure: clarify what "fix" means to the Head; get the baseline data before judging; name one member-side problem; one owner for each fix. Make no claim about past work. | A live problem. The first ninety days test the end-to-end line. |
| H9 | "How would you report resolution times each month, starting from what you already have?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if the spreadsheet already held case durations, say how they were recorded. If not, say so and say what you would add first. Describe the spreadsheet only as you built it. | F5. The JD's resolution-times line. The slot asks what the sheet holds, nothing more. |

### Reverse questions

1. **"What would the first complaint you wanted me to take on look like?"** Why it lands: shows you are planning from the member's side, and invites a specific reply.
2. **"When branch and contact-centre figures disagree, which one do you trust first?"** Why it lands: shows how the manager thinks about the seam you have not worked in.
3. **"How do you expect complaints work to change as 40% of member service moves to digital by 2028?"** Why it lands: asks about the brief rather than reciting it.

---

## 9. Round 3: panel (60 min, values round, with the 20-minute case)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided a complaint from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Choose a time you decided a case from the member's side. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log you handled. Do not turn "handled" into a decision you cannot describe. | Members First is the first value. The panel scores it against your story. |
| P2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt, from the value's own words. If you changed how something was explained so it worked first time, tell that. If the only explaining you did was the tellers' script, say what it asked of them and how you taught it. If neither, say so. | Plain Words. The training sentence is the nearest story, and the answer must not stretch it. |
| P3 | "Tell me about a time the numbers said one thing about a branch and its town said another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Pick a time a figure on the monthly report looked fine and a branch knew otherwise. If you have none, say so. Your material shows the report, not the town. | Neighbours, Not Numbers sits beside the hub plan (P7). |
| P4 | "Tell me about a problem you found that was not yours to fix. What did you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a problem you found and stayed with until it was solved. If you passed it on early, say to whom and why. If none, say so. "Handled" is the nearest thing your material carries, and it is not "held until solved." | Own the Fix. The value's own test is that the finder keeps hold. |
| P5 | "Here's a case, twenty minutes. A member's complaint has been escalated twice. The branch calls the decision final. The member says a contact-centre agent promised a call-back that never came, and wants a named person today. Walk us through the next hour." | CASE | [generic] | Structure: clarify from the notes what was promised, by whom and when. One owner who stays with it to close (Own the Fix). A reply to the member first, in plain words (Plain Words). The branch manager brought in on what the town will feel (Neighbours). Record the decision and why. Do not state a deadline you cannot name. Make no claim about past work. | A live case scored against the values. The escalation line is the JD's, and the case asks you to decide, not recount. |
| P6 | "An hour later your branch manager disagrees with your decision. What do you do?" | CASE | [generic] | Hold the member-side decision through two follow-ups. Ask what new fact would change it. Concede plainly on any part you got wrong. Do not fold on the core decision to restore harmony. | Pressure after the case. The panel tests whether the decision holds. |
| P7 | "Eight branches become five hubs over 2027, and 40% of member service moves to digital by 2028. How does a branch that stays open keep its town's trust?" | CO | [grounded] "consolidate eight branches into five hubs over 2027"; "move 40% of member service to digital channels by 2028" (your summary of the strategy brief) | Describe what you would check with a town before and after a change, and what you would keep at a branch. Plan, not claim. Do not say the hub plan is right or wrong. | Strategy-grounded. Sets the Neighbours tension against the plan. |
| P8 | "Our teams sit side by side. Where's the seam between branches and the contact centre, and what happens when we disagree?" | JD | [grounded] "Never worked in a contact centre" | Propose seam principles, not a seam you have seen: who owns a complaint once it crosses, and who calls the member. Say plainly that you have not worked in a contact centre, then the plan. | The peer probe. The panel tests seams you have never sat in. |
| P9 | "When a fix spans two teams, who gets the credit, and how do you handle it?" | VAL | [generic] | Give a principle you would defend. Say what you would bring to their team, not only what you would need from it. Make no claim about past work. | Peer reciprocity: the team scores what you bring. |
| P10 | "Sixty seconds: why should we give this to you over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Hold on what you have done: six years in retail banking, the last three as a branch supervisor. Concede plainly: "I haven't worked in a contact centre." Then the plan. Do not argue the comparison. | Time-boxed challenge. The hold is your record; the concession is the gap. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | S1, H1 |
| experience handling regulated complaints | H4, H1 |
| own the member complaints process end to end across branches and the contact centre | H1, H5, P8 |
| report monthly on complaint volumes and resolution times | H9 |
| coach branch supervisors on escalations | H2 |
| work with digital teams on self-service journeys | H3, P7 |
| confident presenting to senior leaders | H6, H7 |
| comfortable with Excel reporting | S8, H9. No further question: your words say spreadsheet, not Excel, and a question about Excel fluency would presume a tool and a level no quote carries. |

### Escalation case: what the panel is looking for

The case in P5 is generic, not drawn from your history. It is built to score the four values in order, so the answer should show each one, in sequence, in the first ten minutes.

### Reverse questions

1. **"What could a new person do in their first month that would genuinely help your branches?"** Why it lands: reciprocity, which a peer panel scores heavily.
2. **"Where do complaints most often stall between a branch and the contact centre?"** Why it lands: shows you are asking about the seam you have not worked in.
3. **"When a branch folds into a hub, what do your teams keep from the old branch?"** Why it lands: tests the Neighbours value against the plan without reciting the brief.

---

## 10. Sources

**Provided documents**
- The job description, as pasted in your message (quoted in the fit snapshot).
- The four values, copied from ashgrovecu.org/about/values on 20 November 2026, as you pasted them.
- The recruiter's email: round lengths, the panel's values scoring, and the round 2 focus.
- The July 2026 strategy brief: your four-point summary in your message. The full brief was not supplied.
- Your background, in your message. No CV was supplied.

**Searches and fetches:** none sent in this engagement.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the value names and wording, so the values cheat sheet (section 5) rests on it. |
| 2. Ashgrove interview process | skipped | The recruiter's email is a loop source: three named rounds, their lengths, who runs each, and the panel's values scoring. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the four CO points used in P7 and the grounding brief. Only those four points are in hand. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. The per-member persona weights and any tailored reverse question are absent. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 11. Upgrade menu

- **Your CV** → the four quotes from your message become CV-grounded, and the medium-confidence rows (F1, F2, F3, F5, F6) gain a document to point to.
- **The full text of the strategy brief** → the CO bank in P7 and section 6 sit on the brief's own words, not your four-point summary.
- **The names of the Head of Member Services and the two panel branch managers** → per-member persona weights, and reverse questions aimed at each person's own path.
- **Three true stories, one for each of: a complaint you took to close; a time you explained something so it worked first time; a time a figure hid something about a branch** → the four values rows in section 5 become mapped stories instead of scaffolds. Use only stories that happened.
- **A description of what the spreadsheet tracks: its columns, and whether it held case durations** → F5 and F9 and the answer slot in H9 can be upgraded from their current form.
- **Your prep time, in evenings** → a prep triage section, with the rows ordered by what to rehearse first.
- **Confirmation from the recruiter of the location and hub for the role, and of whether the 20-minute case comes with materials** → S4 and P5 get their real framing.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes): recent Ashgrove organisational news and loop reports from candidates. Want it?
