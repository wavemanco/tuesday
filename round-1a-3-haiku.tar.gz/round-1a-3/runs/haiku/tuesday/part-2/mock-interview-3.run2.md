Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-3-denied-16f81e17/216f0179-81f8-4d91-b8d2-8d57da3e6cdd/scratchpad/stripe_product_operations_manager_interview_pack.md`.

I could not research Stripe. Web search was refused by permission, so the pack has no facts about Stripe's values, interview loop, or recent strategy. Those sections are marked as not established. Everything is built from the title and company you gave me. It is a worksheet with generic questions, not a Stripe-specific prep.

If you grant web search, I can rerun the research and fill in the values and loop sections.

I can also play the Skeptic on B1, the question the pack names as the highest-value prep, or save a `tuesday-dossier.md` recording the gaps this prep exposed.

Three questions:
1. Who are you meeting, and is it a hiring manager, a peer, or a panel? Is the final several sessions? That reweights every persona.
2. Can you paste the job description and a few lines of your past work? Without them, every row is a discovery gap.
3. Can you work in the location and under the authorization the role needs? The pack can't establish this from what you've shared.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

**Built on:** company and title from your message. No CV, no job description, no interviewer name, and no round structure. Built as a worksheet with generic rows, so every Stripe-specific fact is absent. Session-mode pack.
**Interviewer:** not known. Relationship not known.
**Changelog:** first version.

## 1. How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored.
- Type key: **JD** = role requirement. **EXP** = your past work. **CASE** = live problem. **CO** = company knowledge. **VAL** = behavioural or values.
- Guidance is scaffolding, not a script. Say it in your own words.

## 2. Fit snapshot (worksheet variant)

No CV or JD is in hand, so no evidence is quoted. Requirements are role-family prose. Each row's bridge is an answer slot or a selection scaffold.

Research tier: L1 — searches 4 of 6, fetches 0 of 2. Every search was refused by permission, so no Stripe facts are in this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run planning and operating cadence across several teams (role family) | none given | none | [generic] | discovery | Answer slot: name one cadence you have run, who was in it, and what it decided. If you have not run one, say so and say how you would set one up first |
| F2 | Define and track metrics that inform product decisions (role family) | none given | none | [generic] | discovery | Answer slot: name one metric you tracked, what decision it fed, and who used it. If none, say so and say what you would measure first |
| F3 | Work across product, engineering, go-to-market and finance (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a time you had to get agreement from teams with different priorities. If no such time comes to mind, say so plainly, then give the nearest thing you have done |
| F4 | Lead launches or process changes end to end (role family) | none given | none | [generic] | discovery | Answer slot: name one launch or process change you led, your part in it, and its result. If you only contributed to one, say which part |
| F5 | Comfort with data tools such as SQL or spreadsheet analysis (role family) | none given | none | [generic] | discovery | Answer slot: name the tool you have used for analysis and one question you answered with it. If you have not used SQL, say so plainly |
| F6 | Right to work and location for the role (role family, gate) | none given. Your material does not establish this | none | [generic] | hard_gate | Surfaced, not bridged. The one question is whether you meet it, asked in the Upgrade menu line below |

## 3. Persona weights

Final round with an unknown structure, so weights are flat and blended. No loop source has been read, so this rests on the archetype fallback for a large structured company: Case and Values rounds up, with a Skeptic probe on gaps. **The pack does not claim Stripe's actual loop.**

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | high | Live operating problem | Likely in a final for an operations role, where the work is structure, not history | Clarify, then objective, cadence, metrics, risks. Think aloud |
| Skeptic | high | Probe on gaps in F1–F6 | Likely because no CV is in hand and every row is a discovery gap | Hold a plain, honest limit. Do not bluff |
| Values/Behavioural | mid | Scenario probe on how you handled conflict or a hard call | Fallback archetype says a values round is usual. Unconfirmed for this company | Story selection, then "I" for your part |
| Peer Evaluator | mid | Seam between your team and theirs | Likely if the final includes a peer. Relationship not known | Describe what you bring to their team, not only what you need |
| Data-Driven Prober | mid | Asks how a number was counted | Likely for an ops role. Attention to metrics is part of the job | Name the weakest assumption before they do |

## 4. Prohibited claims

None yet. No candidate sentence is in hand to stretch. Once a CV is in, the rule is: no figure, scope or title beyond the sentence it came from.

## 5. Question banks

**Case/Strategist (5 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch across three teams is slipping. How do you find out why?" | CASE | [generic] | Clarify the launch and its date. Set the objective. Map the teams and the blockers. Propose a cadence and the metric you would watch. Name one risk | Likely as a live problem in an ops final. Asks for no past claim |
| A2 | "Design the operating review for a new product area. What goes in it?" | CASE | [generic] | Name the decisions the review must make. Pick three to five metrics and say why. Say who attends and how often. Name what you would cut | Tests F1 without asking for a past claim |
| A3 | "A team's metrics look good but customers complain. What do you check first?" | CASE | [generic] | State the gap between the metric and the complaint. Check how the metric is counted. Look for a segment the average hides | Tests F2 as a diagnosis, not a record |
| A4 | "You have two weeks and one engineer for a process fix. What do you cut?" | CASE | [generic] | Name the fix's goal. Rank the work by what it removes. Say what you would not do and why | Trade-off reasoning under limits |
| A5 | "Which decision in this area would you want data on first?" | CASE | [generic] | Name the decision, then the data it needs. Say what would change your mind | A short problem that rewards structure |

**Skeptic (4 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the requirement that is newest to you, from F1–F5. Say how you would close it in the first month. Do not claim it is already covered | Most likely single objection when no record is in hand. Deepest rehearsal |
| B2 | "I don't see experience running a cadence across teams in your background. How would you handle it?" | JD | [generic] | Answer slot: if you have run one, say which and what it decided. If not, say so plainly, then give the plan. Do not describe a practice you did not run | Probes F1. Honest branch is the first priority |
| B3 | "Why leave where you are now?" | EXP | [generic] | Give the reason in one sentence, in your own words, with no criticism of the old employer | Standard motivation probe. Keep it short and true |
| B4 | "Why this role, and why now?" | EXP | [generic] | Say what drew you to the role's work, and what you want to do next. Keep it to a minute | Consistency check against the rest of the loop |

**Values/Behavioural (3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed back on a decision you thought was wrong." | VAL | [generic] | Selection scaffold: pick a time you disagreed with someone senior. It needs a stake, a moment you held your view, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have done | Open prompt. No values list is in hand, so no mapping |
| C2 | "Describe a time you took a hard call with incomplete information." | VAL | [generic] | Name the information you had, the call, and what you did about the gap. Say what you would do differently | Open prompt on judgement |
| C3 | "Tell me about a time you had to tell a team something they did not want to hear." | VAL | [generic] | Pick a real example. Say the message, who received it, and the outcome. Keep "we" for context and "I" for your part | Tests candour under pressure |

**Peer Evaluator (3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their team. Say how you would settle a disagreement with an equal | Peer pricing of the hire |
| D2 | "What would you need from me in the first month?" | JD | [generic] | Name what you need in plain terms and what you would bring to their team | Reciprocity. Tests whether you add to their load |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you name others' contributions. Give one example only if you have one | Peer probe on credit-sharing |

**Data-Driven Prober (3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how a metric you'd report would be counted." | EXP | [generic] | Answer slot: if you have a metric, say how it was counted, in your own words. If you did not count it, say so | Asked of any figure you give. Answer slot, never a method you did not use |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do. If you cannot name one, say so | Converts a gotcha into a credibility point |
| E3 | "What would you measure first in a new area, and why?" | CASE | [generic] | Name the outcome, the input that moves it, and how you would check the link | Tests F2 as method |

Coverage check: F1 → A2, B2. F2 → A3, E3. F3 → D1, D2, D3. F4 → C1, C2. F5 → E1, E2. F6 → upgrade menu. Every requirement has at least one question.

## 6. Values / principles cheat sheet

Not built. This section needs Stripe's published values in hand, and none was fetched. Search was refused, so no official values page was read. Upgrade menu below.

## 7. Reverse questions

1. "What does a strong first quarter look like in this role?" Why it lands: it shows you are planning for the job, not for the interview.
2. "Which decisions does this role own outright, and which does it advise on?" Why it lands: it tests scope and shows you think in decision rights.
3. "How does this team know a process change has worked?" Why it lands: it turns to outcomes, which ops roles are judged on.
4. "What has the last person in this role had to stop doing?" Why it lands: it surfaces the real trade-offs.
5. "What would make you say in six months that you hired the right person?" Why it lands: it asks for the criteria directly and gives you a target to meet.

## 8. Sources

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 6, cannot be built without the official page |
| 2. `Stripe interview process product operations manager` | unavailable | Loop structure. Persona weights rest on the archetype fallback, not on this company's loop |
| 3. `Stripe news strategy 2026` | unavailable | Current priorities for CO questions. None are in the pack |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Fit snapshot rows F1–F5 are role-family prose, not a quoted posting |

Calls, all refused by permission:
- `Stripe company values principles` (target 1): refused
- `Stripe interview process product operations manager final round` (target 2): refused
- `Stripe news strategy 2026` (target 3): refused
- `Stripe Product Operations Manager job posting responsibilities qualifications` (target 5): refused

No provided documents were read.

## Upgrade menu

- The job description → the six role-family rows become `[grounded]`, and the B1 and B2 probes get real requirement text
- Your CV or a few lines of your past work → the fit snapshot gets quoted evidence, and the story slots become story maps
- The round type and who you are meeting (hiring manager, peer, or a panel) → persona weights are recomputed. If the final is several sessions, send the schedule for per-session packs
- Interviewer name → a tailored reverse question and persona weights from their public footprint
- Web search permission → research on Stripe's values, loop and recent strategy, which fills sections 6 and 8
- The recruiter's prep email → coverage of any deliverable they name
- Right-to-work and location (F6) → resolves the one gate row
