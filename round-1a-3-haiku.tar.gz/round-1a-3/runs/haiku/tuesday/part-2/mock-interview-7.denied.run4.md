Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-denied-fc839b8c/09ae5b56-020a-4f4d-9f86-fa76a739febf/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since Tobias is the Head of Live Operations. Tell me if that's wrong. Web search was refused in this session, so the pack has no facts about Saltmarsh or Tobias. Everything in it comes from your message and the JD.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Assumed relationship: hiring manager. No research ran, so no interviewer read is included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the honest branch as readily as the main one.

Type key: **JD** = stated role requirement. **EXP** = what you actually did. **CASE** = live problem from the role. **VAL** and **CO** do not appear: no values round is established and no company research ran.

## Fit snapshot

No gate rows: the JD states no authorisation, licence or credential. The 3+ years line is graded on fit like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops, not live events across two titles. Say it in your words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned any calendar beyond that title, say what and how; if you did not, say so and describe how you would split one calendar across two titles. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. The calendar is inspectable, so bring it if you can. |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | presentation | The years are there. Your words: "4 years as an associate producer at a puzzle-game studio." Expect a probe on what producing meant at associate level and how much of it was live-service work. Answer slot: say which of it was live-service work, in your own words. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote touches retention without showing whether you calculated it. Answer slot: if you calculated or changed how the figure was counted, say so and how; if you presented figures someone else calculated, say that. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement. The checklist is an inspectable artifact; bring it. |
| F6 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | One written artifact is the only written evidence in the material. Answer slot: name one written thing you produced that others acted on, and what they did with it; if the checklist is the only one, say so. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination across these four teams. Answer slot: if you coordinated any of these teams on a content drop, say which and how; if you did not, say so and describe how you would run it. |
| F8 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | discovery | The quote touches KPIs without showing a post-event review. Answer slot: if you wrote or ran a review after a content drop, say what it reported; if you did not, say so and describe the review you would run. |

Gap types follow the evidence cell. Silence is discovery, not capability.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The material says one title's content drops, not two titles' live events. |
| Led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." No slot. |
| Owned post-event reviews and KPIs | Inflated form of F8 | F8's quote at its own scope. The material shows presenting numbers, not owning KPIs. |
| Calculated or analysed retention figures | Inflated form of F4 | F4's quote at its own scope. The material shows presenting, not how figures were counted. |
| Worked on a game with in-app purchases | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Weights: the round prior for a hiring manager is Case/Strategist plus Skeptic. No interviewer signals were available, and no loop source exists, so the fallback is the generic archetype: flat weights, said plainly. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the gaps: no team leadership, one title, no in-app purchases | High. Hiring managers derisk gaps, and three are stated in your material | Plain acknowledgment, then a plan. Never a bridge built from nothing | 5 questions |
| Case/Strategist | Live problems: a retention dip, a two-title calendar, a late update, a coordination meeting | High. The JD is a run-the-calendar job | Clarify, then structure: objective, constraints, sequence, risks | 5 questions |
| Data-Driven Prober | Asks how the retention figure was counted | Medium. The JD names retention and your material has one retention presentation | Say what you can, and say when you do not know | 3 questions |
| Pressure | Time-boxed challenge on leadership or your part in results | Medium. The leadership gap is easy to press in sixty seconds | Pause, restate, hold two follow-ups, concede the gap in words | 3 questions |
| Conversational | Biography opener and a casual live-game question | Low to medium. Openers are scored too | A 90-second arc; treat casual questions as scored | 2 questions |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see people leadership in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team" — your message | Plain acknowledgment: "I haven't led a team." Then a plan, not a past: how you would get four teams to commit to one update date without authority over any of them. Describe no past coordination as leadership. | The probe rests on a negative you stated. The requirement it lands on is coordination (F7). |
| A2 | "You have run one title's calendar. This role plans two. What happens to the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say it in those words. Answer slot: if you worked on any calendar beyond that title, say what and how; if you did not, say so and describe how you would split one calendar across two titles. Hold by returning to the title, not by adding to it. | F1 is the evidence and the likeliest probe. The premise, one title, is the quote's own. |
| A3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation model in the first month, as a plan. No slot. | A sourced negative. The posting does not raise it, so it is a probe of a gap, not a stated requirement. |
| A4 | "Four years in an associate role. What did producing look like day to day?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Pick the piece you carried most, the weekly content-drop calendar or the release checklist, and name it in your own words. Answer slot: if any of the four years was live-service production beyond those, say which; if not, say so and stay with the calendar. | F3. Scope matters more than years. |
| A5 | "Where would you be weakest on day one?" | Skeptic stem | [grounded] "Never led a team" — your message; "never worked on a game with in-app purchases" — your message | Name the two gaps you know about, in those words. Then a 30-day ramp as a plan: what you would learn first and from whom. Do not name a strength you have not quoted. | An open prompt. The honest answer is the two gaps you stated. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A live title's retention falls after a content drop. What do you check before you plan the next one?" | CASE | [generic] | Clarify first: how far it fell, for which players, and whether anything else changed that week. Then compare with the last few drops. Say which metric you would trust and why. No claim about your past. | A live problem from the retention requirement. A pattern, not a fact about Saltmarsh. |
| B2 | "Plan the next quarter's live-events calendar for two titles, with one QA window." | CASE | [generic] | Objective, then constraints: QA window, art lead times, community calendar. Sequence the two titles so neither takes all the QA time. Name what you need from each team before committing, then the risks. | The JD's first line as a live problem. The structure is the scored part. |
| B3 | "An update is two days from release and QA has not signed off. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." — your message | Ask QA which checklist item is open. Decide go or hold with the QA lead, then tell the community team. Name the checklist as the one you wrote, which QA still uses, and nothing more. | The release checklist line of the JD. The quote lets you name the checklist, nothing about its use beyond that. |
| B4 | "Art, design, engineering and community need to be ready for a live event in ten days. Walk me through your first meeting." | CASE | [generic] | Name each team's dependency and what it needs to commit. Agree one owner per dependency and the date each team can commit to. Say which date you would hold and why. Claim no past meeting. | The coordination line as a live problem. F7 has no quote, so the guidance is a plan. |
| B5 | "What tells you a live event worked?" | JD | [generic] | Name the metric before the event, the baseline it is compared with, and the window. Then name the metric you would not trust and why. Describe a method, not a past result. | The post-event review and KPI line. The answer is a method. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that monthly retention figure was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you calculated the figure, say how, in your own words. If you presented a figure someone else calculated, say so and say what you checked. Do not describe a method you did not use. | F4. A figure you gave raises this defend-the-number slot. |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name the assumption you know of before they do. Answer slot: if you do not know how it was counted, say so plainly and say what you would check first. | The weakest-assumption move. The honest branch is "I don't know how it was counted." |
| C3 | "How would you tell whether a content drop moved retention, rather than the season?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say what you could compare across drops. Answer slot: if you did no comparison, say so and describe the comparison you would run first. | Connects the calendar to the retention requirement. The quote does not answer it. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a producer over someone who has led teams?" | Pressure | [grounded] "Never led a team" — your message | Pause and restate. Hold the case you can make from the calendar and the checklist you ran. Concede the gap in these words: "I haven't led a team." Hold through two follow-ups; concede only the gap. | Hold-then-concede. The hold is what the quotes carry. The concession is the negative you stated. |
| D2 | "That calendar: how much of its results were actually you?" | Pressure | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Hold to "I ran": what you ran, and for how long. Answer slot: name what the calendar did not control and what sat outside your part. Claim no result you cannot show. | An attribution probe. The quote's scope is running, not results. |
| D3 | "You presented retention to the studio head. Did you act on it?" | Pressure | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold to what you presented. Answer slot: if a decision followed from the numbers, say which and whose decision it was; if none did, say so. | Presenting is not deciding. The honest answer says which. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A 90-second arc: the studio and role, the calendar you ran, the checklist, the retention presentation, and why this role now. Give the why in your own words; the material does not supply it. | An opener, and scored. A rehearsed arc stops you freezing. |
| E2 | "What's a live game you've watched update lately?" | CO-adjacent | [generic] | Name one update you actually watched and one thing it did well, in your own words. Claim nothing beyond what you saw. | Casual, but scored for interest and specificity. |

Coverage: 18 questions across five personas.

**Highest-ROI prep: A2.** "You have run one title's calendar. This role plans two." It is the JD's first line and the most predictable objection, and F1 is the thinnest link to it. Rehearse the return-to-the-title hold until it is boring.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, B2, C3 |
| Coordinate design, art, engineering and community on each update | B4 |
| Own the post-event review and the KPIs it reports | B5, C1, C2 |
| Manage the release checklist with QA | B3 |
| 3+ years producing live-service games or apps | A4 |
| Experience running a content calendar | A4, C3 |
| Comfortable with player-retention metrics | B1, C1, C2 |
| Clear written communication | None in the banks. The material has one written artifact (F6), and the upgrade menu asks for a second. |

## Reverse questions

1. "What would you want from me in the first month to plan the second title's calendar?" Why it lands: turns the two-title gap into a shared plan.
2. "How does the post-event review fit into the team's weekly rhythm?" Why it lands: treats the review as a process, which the KPI line asks for.
3. "Which QA sign-offs are hardest to get on time today?" Why it lands: shows you have read the checklist's pressure points.
4. "How is this role measured at six months?" Why it lands: sets up the KPI answer and asks what success looks like.
5. "Which of the two titles has the most live-event pressure right now?" Why it lands: shows you have already worked out the split.

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Search permission was not granted in this session, so both calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet. No values round is established, so it would only have mattered if one is confirmed. |
| 2. Saltmarsh interview process | unavailable | Loop structure and persona weights. Weights are the flat fallback. |
| 3. Saltmarsh strategy and recent news | unavailable | CO questions. Query refused: "Saltmarsh Games mobile studio live operations". |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read and a tailored reverse question. Query refused: "Tobias Wrenfield Head of Live Operations Saltmarsh Games". |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Search permission, or the recruiter's note on the round → loop structure, whether a values round exists, persona weights rebuilt
- Tobias Wrenfield's public talks or profile → an interviewer read, a tailored reverse question, and persona weights
- The release checklist or a content calendar, if you can show them → F2 and F5 move to a named artifact to bring
- Saltmarsh's monetisation model → A3 becomes a planned answer about a known model
- The round format, case or presentation or conversation only → the bank weights and whether the B questions run as a live exercise

---

Want a drill? I can play the Skeptic on A2, the highest-ROI question, and push back on your answers in character before giving feedback. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions.

Two questions that would reshape the pack:

1. Is Tobias the person you'd report to, and does the 60 minutes include a live case or a presentation?
2. Do you know whether Saltmarsh's titles use in-app purchases?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Assumed relationship: hiring manager. No research ran, so no interviewer read is included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the honest branch as readily as the main one.

Type key: **JD** = stated role requirement. **EXP** = what you actually did. **CASE** = live problem from the role. **VAL** and **CO** do not appear: no values round is established and no company research ran.

## Fit snapshot

No gate rows: the JD states no authorisation, licence or credential. The 3+ years line is graded on fit like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops, not live events across two titles. Say it in your words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned any calendar beyond that title, say what and how; if you did not, say so and describe how you would split one calendar across two titles. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. The calendar is inspectable, so bring it if you can. |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | presentation | The years are there. Your words: "4 years as an associate producer at a puzzle-game studio." Expect a probe on what producing meant at associate level and how much of it was live-service work. Answer slot: say which of it was live-service work, in your own words. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote touches retention without showing whether you calculated it. Answer slot: if you calculated or changed how the figure was counted, say so and how; if you presented figures someone else calculated, say that. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement. The checklist is an inspectable artifact; bring it. |
| F6 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | One written artifact is the only written evidence in the material. Answer slot: name one written thing you produced that others acted on, and what they did with it; if the checklist is the only one, say so. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination across these four teams. Answer slot: if you coordinated any of these teams on a content drop, say which and how; if you did not, say so and describe how you would run it. |
| F8 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | discovery | The quote touches KPIs without showing a post-event review. Answer slot: if you wrote or ran a review after a content drop, say what it reported; if you did not, say so and describe the review you would run. |

Gap types follow the evidence cell. Silence is discovery, not capability.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The material says one title's content drops, not two titles' live events. |
| Led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." No slot. |
| Owned post-event reviews and KPIs | Inflated form of F8 | F8's quote at its own scope. The material shows presenting numbers, not owning KPIs. |
| Calculated or analysed retention figures | Inflated form of F4 | F4's quote at its own scope. The material shows presenting, not how figures were counted. |
| Worked on a game with in-app purchases | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Weights: round prior for a hiring manager is Case/Strategist plus Skeptic. No interviewer signals were available, and no loop source exists, so the fallback is the generic archetype: flat weights, said plainly. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the gaps: no team leadership, one title, no in-app purchases | High. Hiring managers derisk gaps, and three are stated in your material | Plain acknowledgment, then a plan. Never a bridge built from nothing | 5 questions |
| Case/Strategist | Live problems: a retention dip, a two-title calendar, a late update, a coordination meeting | High. The JD is a run-the-calendar job | Clarify, then structure: objective, constraints, sequence, risks | 5 questions |
| Data-Driven Prober | Asks how the retention figure was counted | Medium. The JD names retention and your material has one retention presentation | Say what you can, and say when you do not know | 3 questions |
| Pressure | Time-boxed challenge on leadership or your part in results | Medium. The leadership gap is easy to press in sixty seconds | Pause, restate, hold two follow-ups, concede the gap in words | 3 questions |
| Conversational | Biography opener and a casual live-game question | Low to medium. Openers are scored too | A 90-second arc; treat casual questions as scored | 2 questions |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see people leadership in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team" — your message | Plain acknowledgment: "I haven't led a team." Then a plan, not a past: how you would get four teams to commit to one update date without authority over any of them. Describe no past coordination as leadership. | The probe rests on a negative you stated. The requirement it lands on is coordination (F7). |
| A2 | "You have run one title's calendar. This role plans two. What happens to the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say it in those words. Answer slot: if you worked on any calendar beyond that title, say what and how; if you did not, say so and describe how you would split one calendar across two titles. Hold by returning to the title, not by adding to it. | F1 is the evidence and the likeliest probe. The premise, one title, is the quote's own. |
| A3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation model in the first month, as a plan. No slot. | A sourced negative. The posting does not raise it, so it is a probe of a gap, not a stated requirement. |
| A4 | "Four years in an associate role. What did producing look like day to day?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Pick the piece you carried most, the weekly content-drop calendar or the release checklist, and name it in your own words. Answer slot: if any of the four years was live-service production beyond those, say which; if not, say so and stay with the calendar. | F3. Scope matters more than years. |
| A5 | "Where would you be weakest on day one?" | Skeptic stem | [grounded] "Never led a team" — your message; "never worked on a game with in-app purchases" — your message | Name the two gaps you know about, in those words. Then a 30-day ramp as a plan: what you would learn first and from whom. Do not name a strength you have not quoted. | An open prompt. The honest answer is the two gaps you stated. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A live title's retention falls after a content drop. What do you check before you plan the next one?" | CASE | [generic] | Clarify first: how far it fell, for which players, and whether anything else changed that week. Then compare with the last few drops. Say which metric you would trust and why. No claim about your past. | A live problem from the retention requirement. A pattern, not a fact about Saltmarsh. |
| B2 | "Plan the next quarter's live-events calendar for two titles, with one QA window." | CASE | [generic] | Objective, then constraints: QA window, art lead times, community calendar. Sequence the two titles so neither takes all the QA time. Name what you need from each team before committing, then the risks. | The JD's first line as a live problem. The structure is the scored part. |
| B3 | "An update is two days from release and QA has not signed off. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." — your message | Ask QA which checklist item is open. Decide go or hold with the QA lead, then tell the community team. Name the checklist as the one you wrote, which QA still uses, and nothing more. | The release checklist line of the JD. The quote lets you name the checklist, nothing about its use beyond that. |
| B4 | "Art, design, engineering and community need to be ready for a live event in ten days. Walk me through your first meeting." | CASE | [generic] | Name each team's dependency and what it needs to commit. Agree one owner per dependency and the date each team can commit to. Say which date you would hold and why. Claim no past meeting. | The coordination line as a live problem. F7 has no quote, so the guidance is a plan. |
| B5 | "What tells you a live event worked?" | JD | [generic] | Name the metric before the event, the baseline it is compared with, and the window. Then name the metric you would not trust and why. Describe a method, not a past result. | The post-event review and KPI line. The answer is a method. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that monthly retention figure was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you calculated the figure, say how, in your own words. If you presented a figure someone else calculated, say so and say what you checked. Do not describe a method you did not use. | F4. A figure you gave raises this defend-the-number slot. |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name the assumption you know of before they do. Answer slot: if you do not know how it was counted, say so plainly and say what you would check first. | The weakest-assumption move. The honest branch is "I don't know how it was counted." |
| C3 | "How would you tell whether a content drop moved retention, rather than the season?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say what you could compare across drops. Answer slot: if you did no comparison, say so and describe the comparison you would run first. | Connects the calendar to the retention requirement. The quote does not answer it. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a producer over someone who has led teams?" | Pressure | [grounded] "Never led a team" — your message | Pause and restate. Hold the case you can make from the calendar and the checklist you ran. Concede the gap in these words: "I haven't led a team." Hold through two follow-ups; concede only the gap. | Hold-then-concede. The hold is what the quotes carry. The concession is the negative you stated. |
| D2 | "That calendar: how much of its results were actually you?" | Pressure | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Hold to "I ran": what you ran, and for how long. Answer slot: name what the calendar did not control and what sat outside your part. Claim no result you cannot show. | An attribution probe. The quote's scope is running, not results. |
| D3 | "You presented retention to the studio head. Did you act on it?" | Pressure | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold to what you presented. Answer slot: if a decision followed from the numbers, say which and whose decision it was; if none did, say so. | Presenting is not deciding. The honest answer says which. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A 90-second arc: the studio and role, the calendar you ran, the checklist, the retention presentation, and why this role now. Give the why in your own words; the material does not supply it. | An opener, and scored. A rehearsed arc stops you freezing. |
| E2 | "What's a live game you've watched update lately?" | CO-adjacent | [generic] | Name one update you actually watched and one thing it did well, in your own words. Claim nothing beyond what you saw. | Casual, but scored for interest and specificity. |

Coverage: 18 questions across five personas.

**Highest-ROI prep: A2.** "You have run one title's calendar. This role plans two." It is the JD's first line and the most predictable objection, and F1 is the thinnest link to it. Rehearse the return-to-the-title hold until it is boring.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, B2, C3 |
| Coordinate design, art, engineering and community on each update | B4 |
| Own the post-event review and the KPIs it reports | B5, C1, C2 |
| Manage the release checklist with QA | B3 |
| 3+ years producing live-service games or apps | A4 |
| Experience running a content calendar | A4, C3 |
| Comfortable with player-retention metrics | B1, C1, C2 |
| Clear written communication | None in the banks. The material has one written artifact (F6), and the upgrade menu asks for a second. |

## Reverse questions

1. "What would you want from me in the first month to plan the second title's calendar?" Why it lands: turns the two-title gap into a shared plan.
2. "How does the post-event review fit into the team's weekly rhythm?" Why it lands: treats the review as a process, which the KPI line asks for.
3. "Which QA sign-offs are hardest to get on time today?" Why it lands: shows you have read the checklist's pressure points.
4. "How is this role measured at six months?" Why it lands: sets up the KPI answer and asks what success looks like.
5. "Which of the two titles has the most live-event pressure right now?" Why it lands: shows you have already worked out the split.

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Search permission was not granted in this session, so both calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet. No values round is established, so it would only have mattered if one is confirmed. |
| 2. Saltmarsh interview process | unavailable | Loop structure and persona weights. Weights are the flat fallback. |
| 3. Saltmarsh strategy and recent news | unavailable | CO questions. Query refused: "Saltmarsh Games mobile studio live operations". |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read and a tailored reverse question. Query refused: "Tobias Wrenfield Head of Live Operations Saltmarsh Games". |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Search permission, or the recruiter's note on the round → loop structure, whether a values round exists, persona weights rebuilt
- Tobias Wrenfield's public talks or profile → an interviewer read, a tailored reverse question, and persona weights
- The release checklist or a content calendar, if you can show them → F2 and F5 move to a named artifact to bring
- Saltmarsh's monetisation model → A3 becomes a planned answer about a known model
- The round format, case or presentation or conversation only → the bank weights and whether the B questions run as a live exercise
