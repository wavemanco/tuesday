I couldn't run web research for this pack: the search permission was refused, so the pack has no Stripe-specific values, interview loop or strategy. Those parts are marked as not established.

Your prep pack is saved as /var/tmp/tuesday-measure/1a3/runs/haiku/tuesday/part-2/rooms/case-3-denied-0ae689d5/stripe_product-operations-manager_interview_pack.md. It's generic because I had no job description, CV or round details, so the fit snapshot is a worksheet and every question is tagged `[generic]`.

Say the word and I'll play the Skeptic on B2, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposes, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this a hiring-manager round, a peer, or a panel? The answer reweights every bank.
Do you have the job description and your CV? Send them and the pack gets specific; or say "proceed without" and I'll keep the generic version.
Did the recruiter mention anything hard, such as location, work authorization or schedule? Those are gates, and I can't check them without the posting.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round prep pack

First build. No job description, CV, round details or interviewer name were provided. Web search was refused in this session, so no Stripe-specific values, loop or strategy is in this pack.

## How to use and type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioural / values alignment
- **EXP**: work-experience deep-dive
- **JD**: role-driven
- **CO**: company and strategy knowledge
- **CASE**: live hypothetical problem

Guidance is scaffolding, not a script.

## Fit snapshot (worksheet variant: no background given)

No CV or JD was supplied, so every evidence cell is `none given`. The requirements below are role-family patterns, not quoted from a posting, so they are `[generic]` and raise no answer slots of their own.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and changing operating processes across teams [generic] | none given | none | [generic] | discovery | Strong evidence looks like one process you designed or changed, who depended on it, and how you would know it worked. Selection scaffold: pick one process you set up or changed, say what it replaced and who relied on it. If you have not done this, say so and describe how you would approach it. |
| F2 | Coordinating product, engineering, finance and go-to-market teams [generic] | none given | none | [generic] | discovery | Strong evidence looks like a decision you moved across two or more functions. Selection scaffold: pick a decision that needed more than one team; say who had to agree and what you did when they disagreed. If none, say so. |
| F3 | Measuring whether an operational change worked [generic] | none given | none | [generic] | discovery | Strong evidence looks like a before-and-after measure you chose yourself. Selection scaffold: name one measure you used, how it was counted, and what would have told you it was wrong. If you used none, say so and say what you would measure first. |
| F4 | Prioritising competing requests from senior stakeholders [generic] | none given | none | [generic] | discovery | Strong evidence looks like a trade-off you made and explained. Selection scaffold: pick a time two senior requests collided; say what you chose, why, and who you told. If none, say so and describe your approach. |

## Persona weights

Relationship and round type are unknown, so weights are flat. Round type was not established, so no loop archetype is assumed. No values-style round is detected.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Open biography prompt, casual questions about the role | High: nearly every final opens this way | Prepare a 90-second arc; treat casual questions as scored |
| Case / Strategist | Live operating problem to structure | Medium | Clarify, then structure, then metrics; say one assumption aloud |
| Skeptic | Why this role, why now, weakest area | Medium-high: motivation and gaps are always probed | Rehearse the weakest-area answer until it is plain; calibrated candour |
| Data-Driven Prober | "How did you measure that?" | Medium | Name the weakest assumption before it is asked |
| Pressure / Stress | Interrupts, time-boxes, challenges fit | Low-medium | Pause, restate, hold through two follow-ups, then concede a specific gap |

## Prohibited claims (built locally)

| Not coached | Basis | Honest form |
|---|---|---|
| Any past process, metric or outcome as yours | No candidate sentence exists yet | Describe what you did, in your own words. Nothing is coached until a CV or your own sentences are quoted. |
| Knowledge of Stripe's internal metrics, roadmap or org | No source in the inputs; web search refused | Refer only to what the interviewer says or what you have read publicly; ask about the rest. |

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would set up an operating review for a product area that has no reporting today. What do you need to know first?" | CASE | [generic] | Clarify the decision the review supports, its owner and its cadence. Then the minimum data. Say what you would cut. | Operating roles are scored on structure. Generic: no candidate claim made. |
| A2 | "A launch's adoption dropped 20% in two weeks. Walk me through the diagnosis." | CASE | [generic] | Segment first (which users dropped), check instrumentation, then recent changes, then cohorts. Say one assumption aloud. | Tests whether the diagnosis starts from data quality. Generic. |
| A3 | "Two teams want the same engineering capacity next quarter. How do you decide?" | CASE | [generic] | Name the decision owner and the criteria. State the trade-off. Propose a reversible first step. | Prioritisation under conflict is central to the role family. Generic. |
| A4 | "What would you measure in your first 90 days to know this role is working?" | JD | [generic] | Two or three measures, each with its denominator and what would change your mind. | Scores the role's success criteria. Generic. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, and why now?" | JD | [generic] | One sentence on what the work is, one on your own path in your own words. Make no claim you have not shared. | Motivation consistency. Generic. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area honestly and a concrete ramp plan. Hold through two follow-ups by returning to the ramp plan. Highest-ROI prep: with no background yet, this objection is the most likely to be asked in some form. | Most predictable objection for an unknown background. Generic. |
| B3 | "Tell me about a time a process you owned did not work." | EXP | [generic] | Selection scaffold: pick a time it failed; say what you noticed, what you changed, what you would do differently. If none comes to mind, say so plainly, then give the nearest thing you have. | Open prompt; tests candour. Generic. |
| B4 | "Tell me about a time you disagreed with a senior stakeholder and what happened." | VAL | [generic] | Selection scaffold: a disagreement where the outcome was real; say what you argued, what you conceded, and whether the relationship held. If none, say so. | Pressure-adjacent candour test. Generic. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | JD | [generic] | A 90-second arc: current work, the closest thing you have done to operations, why this kind of work. Use your own words. | Casual opener is scored. Generic. |
| C2 | "What have you been reading about product operations lately?" | CO | [generic] | Name one or two sources you have actually read and what you took from them. Do not name anything you have not read. | Homework signal. Generic. |
| C3 | "What do you enjoy most about operations work, and what do you find tedious?" | VAL | [generic] | One genuine answer each, short. | Fit and energy check. Generic. |
| C4 | "What would you change about how a product team works with operations?" | CASE | [generic] | Name one specific seam and a principle for fixing it; avoid pretending to know this company's seams. | Peer-style probe in a friendly register. Generic. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which number from your last project would you defend least, and why?" | EXP | [generic] | Selection scaffold: pick one figure you have used; say how it was counted and the assumption you would defend least. If you have no such figure, say so and describe what you would count. | Probers test attribution first. Generic. |
| D2 | "How did you know that change worked, and how sure are you?" | EXP | [generic] | Name the evidence type (before-and-after, cohort, anecdote) and say which one you had. | Tests evidence quality. Generic. |
| D3 | "Which metric would you watch first in this role, and how could it mislead you?" | CASE | [generic] | Name the metric, its denominator, and one way it misleads. | Tests whether metrics are understood, not recited. Generic. |
| D4 | "Walk me through how you would count success for a process change." | CASE | [generic] | Name the unit, the baseline, and the confounder you would check. | Structured counting. Generic. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Why should we hire you over someone with direct experience?" | JD | [generic] | Pause. Restate the question. Name the strongest thing you can show. Do not fold on the core. Concede one specific gap. | Tests composure under a challenge to fit. Generic. |
| E2 | "That sounded rehearsed. What did you actually do?" | EXP | [generic] | Answer with one specific thing you did, in your own words. If you did not do it, say so. | Attribution honesty under pressure. Generic. |
| E3 | "Your direct experience looks thin for this scope. How would we know you can do it?" | JD | [generic] | Hold: name the evidence you can offer. Concede: name the gap and a ramp plan. | Hold-then-concede drill. Generic. |

Requirement coverage: F1 to F4 are covered by A1, A3, B3, D1 and D4. Unknown JD requirements are not covered; a JD would add rows.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for this role?" | Shows you want the scorecard, and invites them to describe the role. |
| R2 | "Which operating problem is the team most keen to fix right now?" | Signals you think about operating problems, not just the job description. |
| R3 | "Who owns metric definitions across teams today?" | Tests a common ops seam and shows you know it is a real question. |
| R4 | "What is the biggest decision this role will make in its first six months?" | Frames the role at its altitude. |
| R5 | "What have people in this role typically struggled with?" | Invites candour and gives you the most useful answer. |

## Sources

Provided documents: the user's message only (company, role title, final-round). No JD, CV or dossier.

Target accounting:

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10. Search "Stripe company values operating principles" refused: permission not granted in this session. |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Search "Stripe interview process product operations manager final round" refused. |
| 3. Stripe strategy / recent news | unavailable | Company and strategy questions (CO). Search "Stripe strategy news 2026" refused. |
| 4. Interviewer name | n/a | No name given, so no query could be formed. |
| 5. Representative product operations JD | unavailable | Fit snapshot and JD-tagged questions. No search sent; search permission was refused in this session. |

## Upgrade menu

- Your CV → the four worksheet rows gain quoted evidence and move off `discovery`; the Skeptic and Prober banks get real material.
- The job description → requirement rows become `[grounded]`, and JD-tagged questions get raising sources.
- Round type and who you are meeting → persona weights and an interviewer read.
- Web search permission → targets 1 to 3 run; values, loop and strategy become Stripe-specific, and the CO questions stop being generic.
- The recruiter's note on the final's format → if the final is several sessions, send the schedule for per-session packs.
- The interviewer's name → a tailored reverse question and persona weights from public footprint.
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence would replace the worksheet.
