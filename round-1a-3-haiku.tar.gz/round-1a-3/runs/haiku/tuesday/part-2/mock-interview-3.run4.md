Your Stripe prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-3-denied-bf5856b4/afc8cd88-1056-41c7-8150-f60edb94f58f/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round with interviewers you haven't named, since your note didn't say who you're meeting.

I tried to run web searches for Stripe's values, interview process, strategy and the posting, but the search permission was declined. So the pack has no Stripe-specific facts. Every question is a Product Operations pattern, marked `[generic]`, and the answer slots are where your own experience goes. The pack covers 18 questions across six personas, with case, skeptic and prober weighted highest. It also has the six reverse questions I'd suggest, and a fit snapshot that becomes concrete once I have your CV.

I can run a drill on B1, the question I'd rehearse most: "Which part of this role would you be weakest at on day one?" I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the final round with a hiring manager, a peer, a panel or a cross-functional partner, and is it one session or several? Did the recruiter name any focus areas or a take-home? The answer reweights every question bank.

Could you paste the job posting and your CV? If you'd rather not, I'll keep building from this generic version, and I'll say so in the pack.

Do you need work authorization to work where this role sits, and can you meet its in-office pattern?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Round: final round, interviewers not yet known. Session mode. Built without a job posting, a CV, a named interviewer, or any Stripe research (see Sources). Every bank is therefore a role-family pattern, marked `[generic]`, and the answer slots are where your own material goes.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say the answer in your own words, and only the things you actually did.

Type key:
- **CASE**: a live problem from the role, answered out loud.
- **EXP**: your past work, probed for what was actually yours.
- **JD**: a requirement from the posting. None supplied yet, so none tagged.
- **CO**: Stripe-specific knowledge. None, because no research ran.
- **VAL**: published values. None in hand, so none tagged.

## Fit snapshot (worksheet variant)

No CV and no posting, so there are no quotes yet. Every evidence cell is `none given`, and every row's gap is either `discovery` (the material is silent) or `hard_gate` (a term you must confirm). The answer slots are instructions for the interview. They ask nothing of you here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Process design and ownership, role family, unquoted | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: if you designed or changed a process end to end, say which steps were yours and how you decided. If you did not, say so plainly and describe the nearest process you ran. |
| F2 | Cross-functional work with product, engineering and finance, role family, unquoted | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name one cross-team decision you helped move, whose it was, and where you stood in it. If there was none, say so and describe how you would open that conversation. |
| F3 | Metrics and decisions from data, role family, unquoted | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name one metric you tracked, how it was counted, and which part was yours. If you tracked none, say so and say what you would track first. |
| F4 | Work authorization for the role's location, gate | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. Confirming it is your call, and it is asked in the message that presents this pack. |
| F5 | In-office pattern for the role, gate | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. Confirming it is your call, and it is asked in the message that presents this pack. |

## Prohibited claims

No sentence of yours is in hand yet, so there are no inflated forms to list. These entries are built from the pressure points a final round usually presses.

| Not coached | Basis | Honest form |
|---|---|---|
| Figures from a process you did not measure | Prober pull; no figure from you yet | Say you did not measure it, and what you would measure first |
| Knowledge of Stripe's internal process or metrics | No research ran, so no source exists | Say what you have used or read about Stripe, in your own words, and where you read it |
| Owning a decision you were only part of | Common inflation under Prober and Skeptic probes | Describe your part, and name who made the call |

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case / Strategist | Live process problems from the role | High. A final round usually includes one live problem, and the hiring-manager prior leans this way | Clarify, then objective, segmentation, approach, metrics, risks; think aloud | 4 |
| Skeptic | Probes the gaps, asks why now | High. Finals exist partly to test the gaps | Rehearse the likeliest objection until it is plain; calibrated candor | 4 |
| Data-Driven Prober | Asks how figures were counted | Medium-high. Ops roles are judged on measurement | Name the weakest assumption before it is named for you; say plainly when you do not know | 4 |
| Pressure | Interrupts, time-boxes, tests composure | Medium. Often run at finals, not always | Pause, restate, hold through two follow-ups, then concede the specific point | 2 |
| Peer Evaluator | Seams between teams, credit, disagreement | Medium. Likely if a peer sits on the panel | Propose seam principles; describe a real disagreement | 2 |
| Conversational | Friendly opener that is still scored | Medium. Almost always an opener | Pre-scripted arc; treat casual questions as scored | 2 |

Relationship and round are unknown, so this is a blend. The Values persona is not weighted: no published values are in hand, and no loop source documents a values round, so none is assumed.

## Question banks

Provenance is `[generic]` throughout, because no candidate sentence exists yet. A row whose guidance makes no claim about you carries its label alone.

### A. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | How would you set up an operating review for a product area that is growing faster than its process? | CASE | [generic] | Clarify scope and what is breaking first. Name the objective, then split the breakdown into intake, decision, handoff and measurement. Propose an approach, two metrics, and one risk. Think aloud. | Core of the role; a common hiring-manager case |
| A2 | A launch metric fell 15% in its second week. Walk me through your diagnosis. | CASE | [generic] | Clarify the metric's definition and timing. Check instrumentation before product causes. Segment by the obvious cuts, then say which hypothesis you would test first. | Diagnosis under uncertainty; scores structure |
| A3 | Sketch your first 90 days here. What do you need to know first? | CASE | [generic] | Lead with the questions you would ask. Then name two or three hypotheses about where the process strains, and how you would test each. | Tests whether you clarify before planning |
| A4 | Which internal request would you decline, and how? | CASE | [generic] | Name the criteria you would use and who decides. Say how you would decline with a reason and offer an alternative. | Ops judgment about saying no |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Which part of this role would you be weakest at on day one? | EXP | [generic] | Highest-ROI prep in this pack. Name one real gap in plain words, then your ramp plan. Answer slot: if you know a gap, name it in your own words. If you have not identified one, say what you would check first. Hold once; do not argue it away. | The most predictable objection; a rehearsed, calm answer changes the room |
| B2 | Why are you leaving where you are? | EXP | [generic] | Answer slot: give your own reason in your own words, at the scope it really has. Keep it forward-looking and brief. | Motivation consistency; a logistics-style slot |
| B3 | Why this company, and why this team rather than another? | CO | [generic] | Say what you have used or read about the company, in your own words. Answer slot: if you have not used the product or worked with its customers, say so, then say what you have read. Do not recite the homepage. | Tests genuine interest; no research means no company facts here |
| B4 | Which requirement in this posting does your background show least of, and how would you handle it? | EXP | [generic] | Name the requirement you know you are weakest on, then the step you would take in the first month. Answer slot: if you have not seen the posting yet, pick the requirement you suspect is weakest. | Skeptic framing; the honest answer is a bridge plus a plan |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Walk me through how you measured the last process you improved. | EXP | [generic] | Name the metric, the baseline, how it was counted, and what it was sensitive to. Answer slot: if you measured it, say how. If you did not, say so and describe what you would measure. | The defend-the-number probe, applied to a process |
| C2 | Which assumption behind that number would you defend least? | EXP | [generic] | Name the weakest assumption yourself before it is named for you. Answer slot: if you have no number, say so, and name the assumption you would test first. | Converts a gotcha into a credibility point |
| C3 | Tell me about a decision you made from data that someone disagreed with. | EXP | [generic] | Open prompt. Pick one instance: the data, the disagreement, what you did, what happened. If none comes to mind, say so plainly, then give the nearest thing you have and how you would handle it now. | Judgment under disagreement |
| C4 | What did you build yourself, and what did a team deliver that you only joined? | EXP | [generic] | Separate the two in your own words. Answer slot: say which parts were yours, and where you joined someone else's work say so plainly. | Attribution honesty; the core prober test |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Sixty seconds: why should we hire you over someone with more experience at this scale? | EXP | [generic] | Pause. Restate the question. Give your own two or three reasons, and concede the specific point where the other person is stronger. Hold the position through two follow-ups. Do not fold on the core reason. | Composure under challenge; hold-then-concede |
| D2 | That result: how much of it was actually you? | EXP | [generic] | Name your part exactly, then name the others' parts without apology. Concede what was shared; hold what was yours. | Tests whether credit is honest under pressure |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | Our teams sit side by side. Where is the seam, and what happens when we disagree? | EXP | [generic] | Propose seam principles rather than pretending to know the seam. Describe a real disagreement with an equal, what you each wanted, and how it ended. Answer slot: if you have no such case, say so and describe how you would open one. | Partnership fit between peers |
| E2 | How do you handle credit when work spans teams? | EXP | [generic] | Name who did what, in the order it happened. Say how you raised it when credit was unclear. | Turf and credit probe |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | So, walk me through your journey. | EXP | [generic] | Build a 90-second arc from your own story: where you started, the work that mattered, why this role now. Answer slot: use your own words; the arc is a shape, not a script. | Casual openers are still scored |
| F2 | What tools are you playing with in operations these days? | JD | [generic] | Name the tools you have actually used, in those words. If you have used few, say which ones you have looked at and what you did with them. | Casual question about a likely topic |

## Reverse questions

Six, because no interviewer profile exists to tie any to a path. Ask two or three.

1. What would a strong first 90 days look like here, and which decisions would sit with this person? Why it lands: it shows you are scoping the job, not only selling yourself.
2. Where does this team's work end and product or finance's work begin? Why it lands: it shows you already think of ops as the seam between teams.
3. What process problem does the team most want solved this quarter? Why it lands: it signals that you think in priorities.
4. How do you tell whether a process is working, and which measure would you check first? Why it lands: it invites a measurement discussion on your terms.
5. What did the last person in this role do that you would most want more of? Why it lands: it gives a concrete picture of the job.
6. How is the final round weighted across its sessions, and what should I show you that I have not yet? Why it lands: it tells you what to rehearse, and shows you want to be assessed on the right things.

## Sources

Provided documents: the user's message only. No posting, no CV, no interviewer name.

Searches sent, all refused (the search permission was not granted), listed in the order sent:
- "Stripe company values operating principles": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe strategy news 2026": refused
- "Stripe product operations manager job posting responsibilities": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10): not built, since no published values are in hand and no values-style round is detected |
| 2. Stripe interview process, product operations | unavailable | Loop structure; persona weights are a flat blend instead of following named rounds |
| 3. Stripe strategy / recent news | unavailable | CO bank: none of its questions are company-specific |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot requirements would be `[inferred]` rather than role-family `[generic]` |

## Upgrade menu

- Your CV or resume → F1 to F3 get quotes; every question's Provenance carries your sentences; the Skeptic and Prober rows become story-mapped instead of selection scaffolds
- Job posting text → F1 to F3 become `[grounded]`; the requirement coverage line appears; JD-tagged questions are added
- Round format and who you are meeting → persona weights are reshaped from a flat blend to the actual relationship
- Stripe values page, pasted → values cheat sheet and VAL questions
- Recruiter's note on focus areas or any pre-declared deliverable → a graded deliverable section
- Search permission, or pasted Stripe material on strategy and the interview process → targets 2 and 3 run; CO questions and loop structure become grounded
- Interviewer's name → interviewer read, a tailored reverse question, and persona weights from public footprint
- Answers to the gate and round questions → F4 and F5 are settled
