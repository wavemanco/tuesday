Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-6-denied-fc9feb13/259b2ab8-4baf-40a2-8f6f-9ccdc905b6c5/scratchpad/larkfield_engineering-manager_interview_pack.md. It's a loop pack: one shared fit snapshot, then a mini-pack for each round with its own question bank and reverse questions. I built it from your role description and your message. The company searches were refused in this session, so it says nothing about Larkfield's published values, interview process or strategy. The round 3 values questions use story scaffolds instead of a values cheat sheet.

The highest-ROI prep is A3: "Which part of this role would you be weakest at on day one?" Practise saying "I haven't owned a hardware-adjacent roadmap" plainly, then give a plan for learning it. The pack does not coach any claim you haven't made, so you won't need to reframe your record.

Two things the pack flags for you:
- **Round 2 (panel):** the interviewers are unnamed, so the personas are a blend. Per-member weights need names.
- **Round 3 (VP):** the recruiter's "values and leadership philosophy" wording makes this a values-style round. Without Larkfield's published values, the story mapping is thinner than it could be.

The one question I need answered: do you have the job description? If you paste it, the fit snapshot switches from your role description to JD quotes, and any location, travel or schedule requirements get their own rows.

Offers, if you want them:
- A drill: I can play the Skeptic on A3 and give feedback against that question's guidance.
- A `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- A Word version of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: loop prep pack (three rounds)

Role: Engineering Manager, two squads building device-management services (industrial IoT, ~600 people)
Company: Larkfield Systems
Rounds: (1) Tuesday, 45 min, hiring manager, Director of Engineering. (2) Thursday of the following week, 60 min, panel of two staff engineers and a product manager. (3) The following Monday, 30 min, VP Engineering, described by the recruiter as "values and leadership philosophy."
Interviewer names: not given. No interviewer read is included.
Mode: loop. One shared fit snapshot, then a mini-pack per round.

## How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive; whether what you did survives scrutiny
- **JD**: role-driven; stated responsibilities and qualifications
- **CO**: company and strategy knowledge (not covered; see Sources)
- **CASE**: hypothetical or live problem

Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Sources and what was used

Provided material: your message (role description, your background, four sentences about your record). No JD, no CV, no interviewer names, no recruiter email.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Query sent: "Larkfield Systems values". Refused by the search permission. Values cheat sheet dropped; round 3 values questions use selection scaffolds. |
| 2. Larkfield Systems interview process engineering manager | unavailable | Query sent: "Larkfield Systems interview process engineering manager". Refused. Loop structure rests on the recruiter's round descriptions, not on a published process. |
| 3. Larkfield Systems strategy / recent news | unavailable | Query sent: "Larkfield Systems strategy news industrial IoT device management". Refused. CO questions not built. |
| 4. Interviewer name | n/a | No names given, so there was no query to form. |
| 5. Representative JD | unavailable | No call sent; the host refused the search for targets 1 to 3 before this one ran. Fit snapshot rests on your role description. |

Nothing about Larkfield's published values, loop structure or current strategy is in this pack. Those facts are not established here.

## The fit snapshot

Requirements are quoted from your role description. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (role description, your message) | "I run our hiring loop for backend roles" (your message) | medium | [grounded] | transferability | Your material shows the hiring loop, for backend roles. It does not show delivery or growth across 11 people. Words: "I run our hiring loop for backend roles." Answer slot: the role's delivery and growth line makes a probe on your own part of those likely. If you owned delivery or growth for a team, say what and how, in your own words; if you did not, say so and stay with the team you led. |
| F2 | "Lead two squads building device-management services" (role description, your message) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material shows one team of six, led for three years. It does not show two squads or device-management services. Words: "3 as a team lead of 6." Answer slot: if you led more than one team, or worked on device or embedded services, say so in your own words; if not, say so and stay with the team you led. |
| F3 | "partner with hardware and product on roadmap" (role description, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows a roadmap decision made under roadmap pressure. It does not show working with hardware teams. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you partnered with hardware or product on a roadmap decision, say how; if the quarter was decided without them, say so. |
| F4 | "partner with hardware and product on roadmap" (role description, your message) | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F5 | Managing managers (your message) | "I've never managed managers" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't managed managers." Then how you would prepare, said as a plan and never as a past. |
| F6 | Headline figure (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | The figure is a CV-level claim with nothing inspected behind it, so expect a probe on how it was counted. Lead with the sentence as you said it. |

Rules for reading this table:

- Confidence grades your evidence. Provenance grades what this pack wrote. F4 and F5 are stated absences, so their words are yours.
- The pack's own observations, such as "your material does not show delivery or growth," are analysis. They are not words for you to say.

## Prohibited claims

Not coached, in any round, under any framing.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have managed managers" | Negative you stated (F5) | "I haven't managed managers." |
| "I have owned a hardware roadmap" or "I've led roadmaps with hardware teams" | Negative you stated (F4) | "I haven't owned a hardware-adjacent roadmap." |
| "I've owned hiring and growth for 11 engineers" | Inflated form of F1 | "I run our hiring loop for backend roles." |
| "I led two squads" or "I've led multiple teams" | Inflated form of F2 | "I was a team lead of six, for three years." |
| "I drove the 60% drop" | Inflated attribution of F6 | "After I pushed a reliability quarter through against roadmap pressure, on-call burden dropped 60%." Then your part, in your own words. |

## Loop shape and persona weights

Each round's weights follow the relationship priors, and the round itself is the only signal available. Without interviewer names, the panel's per-member personas are a blend.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1. Hiring manager (Director) | Case/Strategist | Live problems on the role's roadmap | High. A hiring manager is buying capability and expects live problems on the actual roadmap. | Clarify, then structure, then answer. Name the metrics you would watch. |
| 1. Hiring manager | Skeptic | Quiet probing of F4 and F5 | High. The two stated gaps are the obvious objections. | Plain acknowledgment, then a plan as a plan. Never bluff a competency you do not have. |
| 1. Hiring manager | Data-Driven Prober | Defend-the-number on F6 | Medium. The on-call figure is the one number on your record. | Say how it was counted, what it is sensitive to, and which part was yours. |
| 1. Hiring manager | Pressure | Challenges to the roadmap story | Medium. | Hold a position through two follow-ups, then concede precisely. |
| 2. Panel: staff engineers (x2) | Data-Driven Prober | Depth probes on the figure and on hiring | High for the staff engineers. Their role is to verify what you did. | Know your weakest assumption before they name it. |
| 2. Panel: staff engineers (x2) | Peer Evaluator | Seams between squads and disagreement style | Medium. Peers price what the hire costs their work. | Reciprocity: what you bring to their team, not only what you need. |
| 2. Panel: product manager | Case/Strategist | Trade-offs between reliability and features | Medium. The PM is cross-functional. | Clarify the goal, then trade off out loud. |
| 2. Panel: product manager | Values/Behavioral | Stories about pushing back on priorities | Medium. Cross-functional interviewers score behavior. | STAR shape. "We" for context, "I" for your contribution. |
| 3. VP Engineering | Values/Behavioral | Scored "values and leadership philosophy" conversation | High. The recruiter's own words name this round as values-style. | Map a story to the value where one of your quoted sentences carries it. Where none does, pick a time and name the honest branch. |
| 3. VP Engineering | Pressure | Composure on your candidacy and on the 60% figure | High. A 30-minute skip-level is time-boxed. | Pause, restate the question, hold, then concede. |
| 3. VP Engineering | Case/Strategist | Altitude and strategy | Medium. Strategy fluency is not covered; see Sources. | Clarify before answering. |

Depth follows weight. Round 1: Case 3 questions, Skeptic 2, Prober 1, Pressure 1, JD 1. Round 2: Prober 4, Peer 2, Case 2, Values 2. Round 3: Values 4, Pressure 2, Case 1, EXP 1. Round 3's Case/Strategist weight is low because no strategy material was found; a VP round may test strategy harder than this pack prepares for.

## Round 1 — Hiring manager (45 min, Director of Engineering)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, one device-management roadmap, and a hardware team asks for a feature that would slow your reliability work. How do you decide?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify: what the hardware ask is for, what the reliability work protects, and who decides. Structure the trade-off, then give a call with the risk named. No claim about your past. | F3 and F4 raise the roadmap pressure. Case because it is a live problem from the role. |
| A2 | "What would your first 90 days look like, with 11 engineers and two squads you did not set up?" | CASE | [grounded] "own delivery, hiring and growth for 11 engineers" (role description) | Clarify first: what the squads are doing, where delivery is at risk, who the hardware and product leads are. Then a plan: listen, map the work, meet the leads. A plan, not a claimed past. | F1 and F2 are the scale gap. A plan answers it without claiming it. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | **Highest-ROI prep in this pack.** Say the gap plainly: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it: who you would ask and what you would read first. Hold through two follow-ups by returning to the gap and the plan. | F4 is the largest gap and the most predictable objection. A plain, unbothered answer changes the round. |
| A4 | "I don't see managing managers in your background. How would you handle that in this role?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then a plan: what you would do first, and what you would ask for. Never a past practice. | F5. The interviewer may not say this sentence, but the probe is likely from the role's scope. |
| A5 | "Walk me through how the loop for backend roles works, and which part you own." | JD | [grounded] "I run our hiring loop for backend roles" (your message) | Describe the loop in your own words, what it tests and where you decide. Answer slot: if you set the bar or the structure, say how; if it came from elsewhere, say so. | F1. Hiring is in the role's scope, so the probe is likely. |
| A6 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say what was measured, over what window, and against what baseline. Answer slot: name the assumption behind the figure you would defend least, and say which part was yours. If you do not know how it was counted, say so plainly. | F6. Defend-the-number slots are the rehearsal here, not a method. |
| A7 | "Roadmap pressure here is constant. Tell me about the last time you held a position against it." | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped from the quote: the quarter, the pressure, the position held. Beats the quote does not state (who pushed back, what it cost) are answer slots: say what happened, and what part was yours. Hold through two follow-ups; concede only the uncertainty you actually have. | F3. Open prompt, so pick the instance in your own words. |
| A8 | "How would you cut scope on a device-management service that's behind?" | CASE | [generic] | Clarify what is behind and why. Propose two or three cuts, what each protects, and what you would tell product. No claim about your past. | Live case from the role's device-management scope. |

## Round 2 — Panel (60 min, two staff engineers and a product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which assumption behind that on-call number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the assumption in your own words before they do. If you do not know one, say so. | F6. Stem from the prober persona. |
| B2 | "What else changed in that period, and how would you separate its effect from the quarter's?" | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Say what you know changed, and what you cannot separate. Answer slot: if other changes were made, name them and their order; if you cannot separate them, say so plainly. | F6. Attribution probe. |
| B3 | "Tell me how the backend loop worked, and which part you owned." | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | As A5, in fewer words. Keep the interview count and the role's decision in your own words. | F1 under panel scrutiny. |
| B4 | "Our two squads share a device fleet. Where is the seam between them, and what happens when you disagree?" | JD | [grounded] "Lead two squads building device-management services" (role description) | Propose seam principles rather than pretending to know the seam. Describe how you handle disagreement with an equal. | Peer Evaluator stem. |
| B5 | "How would you decide between a hardware-driven feature and a reliability fix in the same quarter?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify, trade off out loud, name the metric you would watch, and say what you would tell the PM. No past claim. | Case from the roadmap line. |
| B6 | "Tell me about a time you pushed back on product priorities." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped from the quote: the quarter, the pushback, the outcome the quote states. Beats it does not state are answer slots. Hold, then concede precisely. | F3, for the PM. Open prompt. |
| B7 | "How do you handle credit when work spans teams?" | VAL | [generic] | Scaffold: pick a time work crossed teams, say who did what, and where you were wrong about credit. If none comes to mind, say so plainly and describe how you would handle it. | Peer stem. Cross-functional. |
| B8 | "You've led a team of six for three years. What does that not show you about leading eleven?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message); "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then what a team of six taught you, in your own words, and what you would do differently at eleven. | F2 and F5. Prober probing scope. |
| B9 | "On-call is the hardest part of device services. How would you bring it down without a roadmap freeze?" | CASE | [generic] | Clarify what is paging and why. Propose: reduce the noisiest pages first, decide the freeze threshold with product, measure. No claim about your past. | Live case on device on-call. |
| B10 | "So — walk me through the journey." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc built only from your quoted sentences: nine years, three as a team lead of six, the payments company now, the hiring loop, the reliability quarter. Nothing added. | Conversational opener, scored casually. |

## Round 3 — VP Engineering (30 min, "values and leadership philosophy")

Published values are not in hand, so there is no values cheat sheet. The values questions below are mapped to your quoted sentences where one carries a story, and otherwise use selection scaffolds with an honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped from the quote. The quarter and the pressure are stated. Who you told, what they said, and how it ended are answer slots: say what happened in your words. Hold, then concede. | F3, the nearest story in your material. |
| C2 | "Where has your leadership philosophy been tested by a decision you did not want to make?" | VAL | [generic] | Scaffold: pick one such decision and say what you chose and why. If none comes to mind, say so plainly, then give the nearest thing you did. | Open prompt on the VP's theme. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: pick a time, name the customer, the metric, and what you traded. If none comes to mind, say so plainly, then give the nearest thing your material does carry. | Stem for the customer value. No published value to map to. |
| C4 | "Sixty seconds: why you over an internal candidate?" | Pressure | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | Answer from your quoted sentences only. Do not compare yourself to people you have not met. Hold and concede where the gap is real: "I haven't managed managers." | Stem for the composure test. |
| C5 | "That result. How much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say your part in one sentence, then what the team did. Answer slot: if the decision was yours, say how; if it was shared, say so. Hold, then concede the shared part. | Stem applied to F6. |
| C6 | "Two squads, 11 engineers, and a hardware roadmap you don't yet know. What do you need to know in the first month?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify list: the hardware roadmap, the current delivery risks, the leads, the on-call record. A plan, not a claimed past. | Strategy-altitude case from the role. |
| C7 | "What do you believe about how a team's on-call should be run?" | VAL | [generic] | Say what you actually believe and where it came from in your experience. Answer slot: if your material shows a position you took on on-call, say it; if not, say the belief and that you are still testing it. | Leadership philosophy, asked as a belief. |
| C8 | "What was the on-call number measured against, and over what window?" | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Say what the baseline was, the window, and the source. If you do not know, say so plainly. Answer slot: name the assumption behind the figure you would defend least. | F6 under the VP's probe. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "Lead two squads building device-management services" | A2, A8, B4, B9, C6 |
| "own delivery, hiring and growth for 11 engineers" | A2, A5, B3, B8. Growth: none, and why: no question in the material asks about growing people, and none is raised by your role text. |
| "partner with hardware and product on roadmap" | A1, A3, A7, B5, B6, C6 |
| Managing managers (stated gap) | A4, B8 |
| Hardware-adjacent roadmap (stated gap) | A3 |

## Reverse questions

Each one carries a why it lands. No interviewer profiles, so none is tied to an interviewer's path.

**Round 1 (hiring manager)**

- "What would the first two quarters look like for whoever takes this role?" Why it lands: it shows you are planning around the job, not around your own gap.
- "Which of the two squads carries more risk right now, and why?" Why it lands: it turns the interview toward the actual roadmap, which is where you will be judged.
- "How do you and the hardware leads split roadmap calls today?" Why it lands: it tests the partnership line directly and invites a concrete answer.
- "What has made the last person in this seat hard to get right?" Why it lands: it asks for the real failure mode, which a hiring manager will answer more candidly than a job posting.
- "What would make you say, six months in, that this hire was the right call?" Why it lands: it asks for their success criteria, which you can plan against.

**Round 2 (panel)**

- Peer reciprocity, for the staff engineers: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it names what you bring to their work, not only what you need.
- For the product manager: "How is roadmap priority decided between reliability work and new features?" Why it lands: it asks the PM's own process, which is where the roadmap tension lives.
- For a staff engineer: "Where is the device-management code most painful to change?" Why it lands: it shows you want the real technical picture before you propose anything.
- "What does a good review of an on-call incident look like here?" Why it lands: it signals you care about the reliability work you already did.
- "What would make the panel say this is the right person for this role?" Why it lands: it gives them room to name the bar, and you can answer it against your own quoted record.

**Round 3 (VP Engineering)**

- "What does your leadership philosophy say about the trade-off between reliability and roadmap?" Why it lands: it connects to your one real story and invites the VP to state a position you can respond to.
- "What have you changed about how leaders are developed here in the last year?" Why it lands: it shows you care about growth, the part of the role your material is thinnest on.
- "Which value here do people most often miss in practice?" Why it lands: it gets the honest version of the values, since no published set is in hand.
- "What would you want the new engineering manager to have decided within six months?" Why it lands: it shows you are thinking about outcomes at their altitude.
- "What is a leadership habit you would want the person in this role to stop?" Why it lands: it reads as candor, and you can answer it from your own material.

## Upgrade menu

- The job description text → six requirements currently quoted from your role description become JD-quoted rows, and any gates it states (location, travel, office days, start date) get their own rows.
- The interviewers' names → a persona read for each panel member, and reverse questions tied to their career paths.
- The recruiter's email on the round 2 panel members' roles and on what each one evaluates → personas per member instead of a blend.
- Larkfield's published values page → a values cheat sheet for round 3, with each value mapped to a quoted story where one exists.
- Permission for the company searches (values, loop structure, recent strategy) → fills the Sources gaps and adds CO questions for round 3.
- Any pre-declared take-home or presentation → a build section for it.
