Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-5-denied-13133b0a/d2c28644-b803-4707-aeeb-bba4c9578777/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. It has the POV build, Ross's pressure bank, the rail and quota gap, the £4M figure, and five reverse questions.

Two things to know before you start:
- **Web search was refused in this session**, so the pack has no Kelverton values, interview-loop or strategy content. The commercial and strategy questions are generic and labelled that way. Granting permission would let me rerun those searches.
- **The POV's differentiation is weak until I see the market report.** The consensus answer is whatever that report says, so I can't tell you how to depart from it yet.

Say the word and I'll play Ross on A1, the £4M question, since it's the highest-value rehearsal. I can also save a tuesday-dossier.md recording the gaps this prep exposed (the rail gap and the direct-quota gap), for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the market report's three or four headline recommendations? I'll make the POV depart from them rather than repeat them.
2. Do you have the job spec, and does the role have office days, a location or a start-date term you'd need to meet?
3. Shall I rerun the company searches (values, interview process, strategy, and Deepa and Ross's public profiles)? They were refused this session, so I need you to allow web search first.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes. First 15 minutes: a short spoken point of view (POV) on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Then Q&A, with Ross pushing on commercials.
**Relationship:** panel, so personas are blended per member (see the persona table).

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: can you do the listed job, gaps included
- **EXP**: do your claims survive scrutiny, and what did you actually do
- **CO**: company and strategy knowledge (none in this pack; research did not run, see Sources)
- **CASE**: structure and reasoning on a live problem
- **VAL**: values alignment (not detected for this loop, so none)

Guidance is scaffolding, not a script. Where a guidance cell says "answer slot", the answer is yours, in your own words, and either honest branch is acceptable.

## Prep triage (about 4 hours)

1. **60 min: build the POV (P1 to P3).** It is the first 15 minutes and the only part the panel has asked for by name. Choose one thesis, say its concession aloud, and end on the operator close each time.
2. **45 min: Ross's pressure bank (A1 to A4).** Practise holding a position through two follow-ups before conceding.
3. **45 min: the rail and quota gap (B1, B3).** Say the plain acknowledgments once each, flatly, then the plan.
4. **30 min: the £4M figure (A1, D2).** Know which part was yours and which you cannot account for.
5. **30 min: reverse questions.** Pick the five you would ask Deepa and Ross.
6. **30 min: one full run** against Ross's pressure persona, timed to 15 minutes for the POV.

Everything else is insurance.

## Fit snapshot

No job description was supplied. The requirements below come from the recruiter's own words, quoted in your message, and from your own description of the company. Rows marked with the recruiter as source are `[grounded]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" (recruiter's email) | "5 years in transport consulting" (your message); "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Your material places you in transport consulting on network planning. It does not say which side of the table your clients were on, and the planning side is not running a service. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: if a planning decision of yours changed how a service ran, say which and how you decided; if your work stopped at the planning stage, say that and say what you would want to learn from operators first. |
| F2 | "our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message) | medium | [grounded] | transferability | The channel you ran was software vendors, not operators. Words: "For four years I ran the ISV channel at a payments company." Limit: the partners were software vendors. Answer slot: say which part of channel work you expect to carry over to an operator, and which you expect to fail, in your own words. |
| F3 | "Ross will push on commercials." (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced revenue, not revenue you owned. Words: "The channel grew from 6 partners to 40, and I was involved in roughly £4M of influenced revenue." Answer slot: say how the £4M was counted, what it is sensitive to, and which part of it was yours, in your own words. |
| F4 | "Ross will push on commercials." (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota." Then the plan, said as a plan: how you would learn to forecast and own a target. |
| F5 | "sells scheduling software to train operating companies" (your message) | none given | none | [grounded] | discovery | Your material does not show rail or scheduling-software work. Answer slot: if you have worked on a buying process with an operator or a transport body, say what you saw; if not, say so, and say how you would learn the operator buying process. |
| F6 | "Never sold into rail specifically" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I've never sold into rail." Then the plan, said as a plan: which three operators you would talk to first. |

**Gate rows:** none established. Location, office days, start date and right to work are not in your material or the recruiter's words quoted to me, so they are not scored here. See the upgrade menu.

### Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I know rail buyers" | Inflated form of F6 | "I've never sold into rail." |
| "I carried a revenue target" or "I own a number" | Inflated form of F4 | "I've never carried a direct quota. I had influenced revenue, roughly £4M." |
| "I know operators from the inside" or "I know the operator world" | Relationship inversion of F1: you advised on planning, you did not run operators | "I spent five years in transport consulting on bus and light rail network planning." |
| "The £4M was mine" | Inflated form of F3 | "Roughly £4M of influenced revenue." The share that was yours is the answer slot in A1. |

The pack's own observation, in analysis and not as words for you: your material says influenced revenue, not owned revenue; it says channel partners, not operators; and it says planning, not operations.

## Graded deliverable: the 15-minute POV

Recruiter named the POV as the graded deliverable and asked you to land on the operators. The grounded facts to build on are F1 to F3. Your quotes are the only facts you should assert about yourself.

Note on the market report: you read the internal strategy report and I have not seen its content. The consensus answer to "where should operator partnerships go" is whatever that report says. Differentiation needs its headline points. See question 1 below.

Pace: 15 minutes is the whole slot, so aim for about 8 minutes of speaking and leave the rest for interruptions. Each thesis below is a `[generic]` pattern for this kind of problem, not a claim about Kelverton.

**P1. Design around one operator decision, not the product.** Partnerships should be built around a specific operator job, such as keeping the timetable running and recovering from disruption, rather than around the product list.
- Grounding: F1. "I spent five years in transport consulting on bus and light rail network planning."
- Mandatory concession: "My view of operators comes from the planning side, not from running a service. I would test this with two or three operators before committing to it."
- Differentiation: pitch the operator decision the partnership changes. Do not pitch features.

**P2. Anchor operators first, then a repeatable partner model.** A few anchor operators co-designed up front, then a partner tier that others can follow.
- Grounding: F2. "For four years I ran the ISV channel at a payments company."
- Mandatory concession: "The 6-to-40 playbook does not transfer directly. Operators are fewer and slower to buy than software vendors, so it is a starting point, not a plan."
- Differentiation: the anchor-first sequence is the piece a channel-only candidate would skip.

**P3. Tie commercial terms to the operator's own case.** The operator has to close the business case on their side, so partner terms should follow their contract and budget cycle.
- Grounding: F3 and F4. "I've never carried a direct quota."
- Mandatory concession: "I have not priced an operator deal. I would want Ross's view on which structures an operator's contracts can absorb before I commit to one."
- Anti-pick: do not lead with a new-logo volume target. It is the easiest number to say and the one that tells an operator least.

**Close (recruiter's requested close):** name the one operator outcome you would measure first, and say why an operator would say yes to it. Finish on that, not on a summary.

## Persona table

| Persona | Member | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Time-boxed, "how much of that was actually you" | High: the recruiter flagged commercials | Hold, then concede the specific uncertainty |
| Skeptic | Deepa and Ross | "Why would this work in rail with no rail sales?" | High: the rail gap is the obvious objection | Plain acknowledgments, then the plan |
| Case / Strategist | Deepa and Ross | Live operator problem, the POV's follow-up | High: the POV invites it | Clarify, objective, segment, approach, metrics, risks |
| Data-Driven Prober | Ross | Asks how the £4M was counted | Medium-high | Name the weakest assumption before he does |
| Conversational | Both | Casual opener, scored anyway | Low-medium | Pre-scripted 90-second arc from F1 to F3 |

**Weights:** Pressure 4, Skeptic 4, Case 4, Prober 3, Conversational 2.
**Reasoning:** Panel rule: blend the top two personas of each member's relationship. Ross's profile is commercial, so Pressure and Prober. Deepa is your future manager with a hiring-manager prior, so Case and Skeptic. No interviewer profile was read, so these are role priors, not personal reads. The recruiter's note on commercials raises Ross's Pressure weight.

## Question banks

### Persona A: Pressure (Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How much of that £4M was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the scope: the figure is influenced revenue. Answer slot: say how it was counted, what it is sensitive to, and which part was yours, in your own words. If you cannot say how it was counted, say so. Concede the specific uncertainty, not the whole figure. | F3 is the figure a commercial director will test first. Highest-ROI rehearsal in this pack. |
| A2 | "Have you ever carried a number yourself?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I've never carried a direct quota." Then the influenced revenue at its own scope. Hold through two follow-ups by returning to the scope. Concede that you cannot show a quota record; offer the forecast you would build. | F4 is the stated absence. The concession is the honest answer, not a retreat. |
| A3 | "Give me a year-one number for operator partnerships." | CASE | [generic] | Give the structure, not a number: the baseline you would need, the operator count and contract cycles, the commitment you would make, and what would change your number. Say plainly that you would not give a figure you cannot defend. | A live problem from the role. Makes no claim about your past. |
| A4 | "Why would a commercial team trust a channel leader in a market he thinks is different?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I've never sold into rail." Concede the gap. Then P1: the transfer argument is the operator decision, not the rail sales record. | F6 is the rail gap. Hold the transfer argument, concede the rail sales. |

### Persona B: Skeptic (Deepa and Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" and "never carried a direct quota" (your message) | Name the two gaps in plain words: rail buyers and direct quota. Then the ramp as a plan, not a past. Do not add a third weakness to look modest. | F4 and F6. A calm, named gap scores better than a vague one. |
| B2 | "Operators are not software buyers. Why won't the channel playbook sink this?" | JD | [grounded] "For four years I ran the ISV channel at a payments company." (your message) | Concede first: operators are slower and fewer. Then the part that does transfer, which is the partner-tier discipline from P2. | F2. The concession comes before the defence. |
| B3 | "What do you know about how an operator buys scheduling software?" | JD | [generic] | Answer slot: if you have been in a buying process with an operator or a transport body, say what you saw. If not, say so, and name the first three operators you would talk to and the question you would ask them. | F5. Discovery gap, so the honest answer is the plan. |

### Persona C: Case / Strategist (both), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the first 90 days for operator partnerships here. What do you need to know first?" | CASE | [generic] | Clarify before structuring: the operator count, which contracts renew when, and what Deepa already has in flight. Then objective, segmentation, approach, metrics, risks. Think aloud. | Scores structure and questions, not a right answer. |
| C2 | "An operator tells you they will not change their scheduling tool this contract cycle. What do you do?" | CASE | [generic] | Separate the need from the budget and the calendar. Find out what would make the operator's decision move in the next cycle. Do not argue with the no. | A realistic objection, and the one most likely from an operator. |
| C3 | "Which of your three theses would you drop if the first operator said no?" | CASE | [generic] | Choose one, say why, and say what you would keep. This is your judgement, not a fact about your past. | Tests whether the POV was a view or a list. |

### Persona D: Data-Driven Prober (Ross), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you got from six partners to forty." | EXP | [grounded] "took it from 6 partners to 40" and "last 4 at a payments company" (your message) | Beats the quote states: the start, the four years, the end. Answer slot: if a step was yours to set, say which and how you decided; if the growth came from something you did not set, say so. Name the weakest assumption before he does: that partner count is a proxy for partner revenue. | F2 and F3. |
| D2 | "What's the denominator on that £4M, and what would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the assumption you would defend least, in your own words. If you do not know how influence was attributed, say so plainly. | Defend-the-number slot. A figure raises it. |

### Persona E: Conversational (both), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting" and "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message) | A 90-second arc: transport planning, then partnerships, then the channel. Stop at the channel. Do not extend to rail. | Casual openers are scored. |

### Reverse questions

1. **"What would a strong first 90 days look like for this role?"** Why it lands: it turns the question into a plan and avoids pretending to knowledge you do not have.
2. **"Where has the operator partnership model fallen short so far, and what did the team learn?"** Why it lands: asks for candour, and shows you are looking at what the role has to fix.
3. **"How is the commercial target for this role set, and who signs off partner terms?"** Why it lands: lets Ross answer on commercials and tells you where the decision rights sit.
4. **"Which operators matter most this year, and what would change that list?"** Why it lands: shows you are thinking about operators, not the channel.
5. **"What does Deepa need from this hire in the first six months that the team is not getting now?"** Why it lands: asks the future manager directly and tests the fit.

No reverse question is tied to an interviewer's own career path, because no interviewer profile was read.

### Requirement coverage

| Requirement (source) | Covered by | Gap |
|---|---|---|
| "what it means for the operators themselves" (recruiter) | P1, close, C2, F1 | none |
| "our operator partnerships over the next 18 months" (recruiter) | P1 to P3, B2, C1 | none |
| "Ross will push on commercials." (recruiter) | A1 to A3, D2, F3, F4 | none |
| Rail sales (your message) | A4, B1, F6 | none |
| Scheduling software and operator buying (your message) | B3, F5 | discovery, answer slot only |

## Sources

**Provided:** the recruiter's email as quoted in your message; your background as stated in your message. The internal market report was read by you and was not provided to me as text, so nothing in this pack is drawn from it.

**Research tier: L1, searches 3 of 6, fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search sent ("Kelverton Rail values"): refused, the search permission was not granted. No values cheat sheet. No values-style round was detected in any case. |
| 2. Kelverton Rail interview process, Senior Partnerships Manager | unavailable | Search sent: refused. No loop source, so the persona weights rest on the relationship priors and the recruiter's note, and are labelled as such. |
| 3. Kelverton Rail strategy and recent news | unavailable | Search sent: refused. Would have moved the CO bank. Without it, no CO question is in the pack. |
| 4. Interviewer names (Deepa, VP Partnerships; Ross, Commercial Director) | unavailable | No call sent: the host had already refused search, so the public-footprint search was not attempted. Would have moved the interviewer read and the reverse questions. |
| 5. Representative JD for the title | unavailable | No call sent: no job description was supplied, so the representative-JD search would have fixed the JD-tagged requirements. Those requirements are `[generic]` as a result. |

**Refused calls:** all three searches above, each returned a permission refusal.

## Upgrade menu

- The market report's three headline recommendations → the POV's differentiation: P1 to P3 can then depart from the consensus answer instead of reciting it.
- The job description text → the six requirement rows marked with the recruiter as source become rows with the JD's own wording, and the JD-tagged questions take the JD's lines.
- Office days, location and start date → the gate rows, which are not scored yet.
- Surnames, or a public profile link, for Deepa and Ross → the interviewer read, the persona weights, and a reverse question tied to their career path.
- Permission to run web search → the three company searches (values, interview process, strategy) and the interviewer searches, which would turn the CO bank and the loop structure from `[generic]` into sourced content.
- A pasted values page or strategy brief → the values cheat sheet and CO questions, without any search.
- A recruiter prep email for the POV → coverage of anything else the recruiter has declared.
