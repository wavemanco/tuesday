Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-2-denied-c7013ef0/73cb24f3-e21f-4155-aa37-7c6183d89a8a/scratchpad/Atlas_Freight_operations-manager_interview_pack.md`. I built it without knowing who you're meeting, so persona weights are flat across five interviewer styles. Web search was refused in this session, so the pack has nothing on Atlas Freight's values, interview process or recent news.

The three things to get ready first:

1. **The fit gaps.** Atlas wants four sites and 12 supervisors. Your material shows one site and three supervisors. Question B2 is the one to rehearse hardest: hold on what you've done, then concede plainly what you haven't.
2. **The 40% mis-pick figure.** It will be probed (A1 to A3). Be ready to say how it was counted, what you would defend least, and which part was yours.
3. **Power BI.** Say "never used Power BI" as it is, then give a plan for learning it. Don't soften it.

Also, the JD's "5+ years operations leadership" is a requirement your material doesn't clearly show. Only you can count that.

I can run a live drill on B2 if you want one.

Two things would sharpen the pack:

- **Who is interviewing you, and what round is it?** A hiring manager, a peer or a recruiter each shifts the question mix a lot.
- **Does your leadership history count as 5+ years?** Give the number and the roles in your own words, and I'll tighten B3 and the fit row for it.

If you'd like, I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas_Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known. Round type and relationship not given.
**Research:** none. Web search was refused in this session, so company values, interview process and recent news are not in this pack.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| EXP | Experience deep-dive | Whether what you did survives scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Say it in your own words.

Persona weights are flat (4/4/4/3/3) because the round type is unknown. Expect the interview to lean on whichever persona fits your interviewer, so rehearse all five.

## Fit snapshot

Evidence quotes are from your message ("your message") and the JD you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows warehouse and distribution operations at one site. It does not show terminal operations or more than one site. Answer slot: if you ran daily operations across more than one site, say which and what you were responsible for; if you did not, say so and describe how you would get up to speed on the terminal side. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material says a mis-pick rate, which is an accuracy measure, not on-time performance or cost per shipment. Answer slot: if you tracked on-time or cost in any role, say what and how; if you did not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says three supervisors now. Answer slot: if you have led a larger leadership group at any point, say how many and how; if not, say so. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | medium | [grounded] | capability | Excel is covered by your quote. Power BI is a stated absence. Words: "I have never used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F5 | "5+ years operations leadership required" (JD) | none given for leadership duration. The quotes in F1 and F3 do not state how many years you have led people. | low | [grounded] | hard_gate | Your material does not establish 5+ years of operations leadership. This cell asks nothing; see the upgrade menu. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Words: "green belt certified." |

Seven rules these rows follow: `Confidence`, `Provenance` and `Gap type` hold one token each. Evidence holds your words only. The gap type decides the bridge, not the writer.

## Prohibited claims

These are not to be coached, in any answer, hold or bridge. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | Your material says one site. The honest form is the peak-season surge plan at your site, at its own scope. |
| Led 12 supervisors | Inflated form of F3 | Your material says three supervisors now. |
| Owned on-time and cost-per-shipment targets | Inflated form of F2 | Your material says mis-pick rate. |
| Built Power BI reporting | Stated negative (F4) | Plain acknowledgment: "I have never used Power BI." No slot. |
| Five years of operations leadership | Gate not shown met (F5) | No claim. The count is yours to state in your own words. |

Your material says the site's surge plan, not a network. Your material says the pick path, not on-time performance.

## Question banks

All banks use flat weights. Depth is 4 / 4 / 4 / 3 / 3. Each row's provenance carries your sentences, quoted exactly.

### A. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you measured the mis-pick rate before and after the pick-path change." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you measured, over what period and from what count, in your own words. Answer slot: the 40% is yours, but your material does not say how it was counted or from what baseline. If you can say, do. If you cannot, say you do not know the detail and say where the count lives. | F2 is the quote; the 40% is the headline figure and the first place a prober goes. |
| A2 | "Which part of that 40% was yours, and which came from the team or the system?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you designed and who else changed the path. Answer slot: if others were involved, name them and say what your part was. | Attribution is the probe's core; the quote carries the redesign, not the team. |
| A3 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption you would defend least before the interviewer does. Answer slot: if you cannot name one, say so plainly. | Weakest-assumption move for a figure you gave. |
| A4 | "Did your mis-pick work touch on-time performance or cost per shipment? How?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what the mis-pick work changed and what it did not. Answer slot: if you measured a link to on-time or cost, say how; if you did not, say so and say what you would check first. | F2's gap in question form. The question does not assume a link exists. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD); "7 years in warehouse and distribution ops" (your message) | Name the terminal and multi-site side as the weaker part, then bridge with your quote: "7 years in warehouse and distribution ops." Answer slot: say what you would do first across four sites, as a plan. | F1 is the biggest mismatch and this question is aimed at it. |
| B2 | "I do not see 12 supervisors or 4 sites in your background. How would you handle that scale?" | JD | [grounded] "lead a team of 12 supervisors" (JD); "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | **Highest-ROI prep.** Hold: "I currently manage three supervisors, and I ran the site's peak-season surge plan two years running." Hold through two follow-ups by returning to those two facts. Concede specifically: "I have not managed twelve supervisors or four sites. Here is how I would build the structure." Say the structure as a plan. | F1 and F3 are the largest gaps, and this objection will come in some form. Hold-then-concede keeps you from folding on what you have. |
| B3 | "Five years of operations leadership is required. Do you have that?" | JD | [grounded] "5+ years operations leadership required" (JD) | Answer in your own words: state the years you have led people and in which roles. The pack cannot supply the count, and rounding up is the failure this question catches. | F5 is a gate the material does not establish. The honest answer is your count. |
| B4 | "Reporting is in Excel and Power BI. Have you built Power BI reports?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Say: "I have never used Power BI." Then, as a plan, how you would learn it. Keep Excel in your own words. | F4 is a stated absence; the plain acknowledgment needs no slot. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Cost per shipment is up at one terminal for three months. Walk me through how you would diagnose it." | CASE | [generic] | Clarify first: what counts as cost per shipment here, and what changed. Then objective, segments, approach, metrics, risks. Think aloud. Make no claim about your past. | F2 is the gap; a live problem asks no past claim. |
| C2 | "One of your four sites has on-time performance slipping. What is your first 30 days?" | CASE | [generic] | Clarify the baseline and the site's shape, then a 30-day plan in phases: observe, find the constraint, act on one change, measure it. | Tests the terminal-ops role directly, without a claim about your past. |
| C3 | "Peak season is six weeks out and one site has no surge plan ready. What do you do in the first week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure first: scope, owners, capacity, and what you would decide this week. Reference your experience only at its own scope. Answer slot: if you set parts of the surge plan, say which and how you decided. | A live problem whose theme comes from your own quote. |
| C4 | "How would you build a cost-per-shipment and on-time report across four sites before you have Power BI?" | CASE | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Start from Excel as the working tool. Say the tool gap in your own words. Propose a path to the dashboard as a plan. | F4 in a live problem. Excel is stated; Power BI is not. |

### D. Pressure / Stress Interviewer (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Pause, restate the question, then answer in 60 seconds anchored to those two facts. Do not reach for scale you do not have. | Tests composure and whether you stay with what you stated. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part you did: the redesign. Concede plainly what you cannot attribute. Answer slot: if the redesign was yours, say so; if others changed the path, name them and your part. | Hold-then-concede on a figure. |
| D3 | "Warehouse work and regional freight are different jobs. Why is this one the same?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Hold the parts that transfer, in your words: the warehouse and distribution work and the peak-season plan. Concede the difference plainly, and say what you would check first in freight. | A challenge framed as a question, not a claim about your past. |

### E. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your career." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "green belt certified" (your message) | A 90-second arc in your own words, starting from those two facts, ending on the current role. | Casual openers are scored. |
| E2 | "What do you use Excel for day to day?" | JD | [grounded] "solid Excel" (your message) | Name one concrete use in your own words. Answer slot: if you have built reporting in Excel, say what it tracked and who read it. | Excel is the JD's stated reporting base. |
| E3 | "Tell me about the Lean or Six Sigma training you have done." | JD | [grounded] "green belt certified" (your message) | Say the certification and the training in your own words, nothing added. | Covers the JD's plus. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | B1, B2, C2 |
| Drive on-time performance and cost-per-shipment down | A4, C1 |
| Lead a team of 12 supervisors | B2, D3 |
| Build reporting in Excel/Power BI | B4, C4, E2 |
| 5+ years operations leadership required | B3 |
| Lean/Six Sigma a plus | E3 |

## Reverse questions

Each has a "why it lands." No interviewer profile exists, so none ties to an interviewer's career path.

1. "What does a typical week look like for the site leads?" Why it lands: shows you are planning for the job, not just the pitch.
2. "How is on-time performance measured across the sites today?" Why it lands: a precise question about the metric the JD names.
3. "What does success look like in the first 90 days?" Why it lands: makes the expectation concrete.
4. "Is Power BI in use across the sites now, or is that still to come?" Why it lands: tests the tool gap in a neutral way.
5. "How is cost per shipment reviewed each month, and who sees it?" Why it lands: shows you know the number matters.

## Sources

- Provided: your message (your CV summary, the JD text).
- Web search: one search sent ("Atlas Freight regional logistics operations manager"); refused by the session's permission setting. Nothing was fetched.

Research tier: L0. Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet dropped; the search was refused |
| 2. Atlas Freight interview process | unavailable | Loop structure; persona weights would be sharper |
| 3. Atlas Freight strategy / recent news | unavailable | Grounding brief and CO questions |
| 4. Interviewer name + company | n/a | No name given |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot |

Sections dropped (condition not met): values cheat sheet, interviewer read, grounding brief, graded deliverables, delivery coaching, prep triage (prep time not stated).

## Upgrade menu

- Round type and the interviewer's role → persona weights, and a tailored reverse question.
- The recruiter's email on process or any take-home → coverage of any deliverable.
- Web search allowed → Atlas Freight's values and interview process, and the values cheat sheet.
- Your count of years leading people (B3) → upgrades F5 from a gate the material does not establish.
- Any multi-site or larger-team history → upgrades F1 and F3 from transferability.
- A tuesday-dossier.md → would ground the gap rows in verified evidence.
