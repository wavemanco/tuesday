Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-canned-0713103c/82d7af4c-c48d-42a4-9501-833fe8e3afe3/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a single 60-minute Outage Hour with Tobias, the hiring-manager round Saltmarsh's careers page describes.

Three things from the research shape the prep:

- **The round is a live incident, then values.** The careers page describes the Outage Hour as a tabletop on a simulated outage during a live event, followed by a values conversation. Your background has no incident-response story, so the pack gives you a plan-first way to answer that, not a made-up one.
- **Your two gaps are the ones Tobias will press.** You've never led a team, and you haven't worked on a game with in-app purchases. The pack gives you plain acknowledgments for both and a plan for each, and it won't let you stretch "wrote the release checklist" into "managed release with QA." The highest-value rehearsal is B1: how you coordinate design, art, engineering and community without authority over them.
- **Tobias wrote a GDC 2026 talk called "Patch Notes Are a Promise."** His argument is that a live team is judged by how often its patch notes match what shipped. Your release checklist is the most relevant thing you have for that. I saw this in a search snippet only, so check the talk before you quote it.

The pack also covers the values (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener), five reverse questions, and a requirement-to-question map. One fact to verify: Saltmarsh's September 2026 Project Larkspur announcement moves to one shared events calendar from February 2027. The JD's "two titles" may be the titles it names, but I haven't confirmed that.

I can run live drills on any question. The drill I'd start with is B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, and convert the pack to Word if you'd like it that way.

Is Friday's slot the Outage Hour, and is Tobias the person you'd be reporting to? If he's a peer or someone else, the persona weights change.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Likely your hiring manager. The loop source (Saltmarsh careers page) describes the Outage Hour: one 60-minute interview with the hiring manager, a live-incident tabletop during a live event, then a values conversation. Your Friday slot looks like that round. Confirm it (see the closing question).

**Assumption this pack is built on:** a single 60-minute Outage Hour with Tobias, session mode, default research tier L1.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: CASE (live problem), EXP (your past work, tested), JD (the listed job), VAL (published values), CO (company knowledge).
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds.
- Answer slots (lines that say "if you did this, say how; if not, say so plainly") are instructions for the interview. They are not questions to answer here.

## Fit snapshot

Requirements come from the JD you supplied, the Saltmarsh careers page and the Saltmarsh values page. Evidence is quoted from your message only; you gave no CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran one, say what it measured and what changed; if you did not, say so and say what you would measure first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | transferability | The checklist is adjacent work with QA. Your material does not show coordination with design, art, engineering or community. Say the checklist as you wrote it, and do not stretch it to the four teams. |
| F3 | "Plan and run the live-events calendar for two mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and content drops, not live events across two titles. Answer slot: if you planned events beyond content drops, or for a second title, say so; if not, stay with the one title you ran. |
| F4 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because the calendar is not yet inspected; bring one (redacted) to the interview. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The quote carries four years and the title, not "live-service". Answer slot: say whether the puzzle game had scheduled updates, in your own words. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | I presented the monthly retention numbers to the studio head. Your material shows presenting them, not analysing them. Answer slot: how those figures were counted, and which part was yours. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. It says you wrote it and QA uses it; it does not say you managed it. Keep to "wrote". |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | The checklist is your only written artefact in the material. Answer slot: name a written piece others relied on, and what it contained. |
| F9 | Live-incident tabletop during a live event (Saltmarsh careers page, loop source) | none given | none | [grounded] | discovery | Your material does not show incident response. Answer slot: if you handled a live incident, say how you handled the first 15 minutes; if you have not, say so and describe what you would do first. |
| F10 | Experience with monetised live titles (role-family requirement, not quoted from the JD) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation model, said as a plan, not a past. |

Routing for the gap column: F10 is `capability` because you stated the absence. F1 and F9 are `discovery` because the material is silent. F2, F3 and F5 are `transferability`. F6 is `presentation` because the quote reaches the requirement in other terms. F4 and F7 are `none` because the quote reaches the requirement.

## Prohibited claims

Each entry lists its basis. The honest form is what you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Stated negative: "Never led a team" (your message) | "I haven't led a team." |
| Ran live events across two titles | Inflated form of F3: the material says one title and content drops | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Managed the release checklist with QA | Inflated form of F7: the material says you wrote it and QA uses it | "Wrote the release checklist our QA team still uses." |
| Analysed or owned the retention numbers | Inflated form of F6: the material says you presented them | "Presented the monthly retention numbers to the studio head." |
| Worked on monetised (in-app purchase) titles | Stated negative: "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." |

Your material is silent on incident response and on the post-event review (F9, F1). Those are answer slots, not listed claims.

## Reading the interviewer

Public footprint only:
- Saltmarsh's published talk page lists a GDC 2026 talk by Tobias Wrenfield, "Patch Notes Are a Promise". The talk's thesis is that a live team is judged by how often its patch notes describe what shipped. (Search snippet; I did not open the page.)
- The same listing describes him as previously a QA lead at a console studio. That is a self-description from the talk listing.

Practical implications:
1. Expect release-accuracy probes. Your checklist (F7) is the most relevant thing you have. Describe it as a check that a build matches what is announced.
2. Expect him to test whether you know the difference between a plan and a promise. The "Ship the Patch Not the Promise" value is his.
3. Mirror opportunity: he came up through QA, and you wrote a checklist QA uses. That is a shared touchpoint with QA, not a shared career jump. Do not claim more than that.

## Persona weights

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a live incident during an event | High. The loop source names the tabletop | Clarify before you plan. Name the first call you would make, then the structure |
| Skeptic | The JD's coordination and written-communication requirements, and your stated gaps | High. Hiring managers buy capability and test gaps (F2, F8, F10) | Hold, then give the plain acknowledgment. Bridge only from quotes |
| Values / Behavioral | The values conversation, against three published values | High. The loop source documents a values conversation | Selection scaffolds with honest branches where your material is silent |
| Data-Driven Prober | Retention numbers and checklist accuracy, given Tobias's talk | Medium. His talk makes release accuracy a theme | Name the weakest assumption in the figure before he does |
| Pressure | "Never led a team" pressed in under 60 seconds | Low. A one-off pressure probe is possible but not signalled | Hold, then concede the specific gap |

Weights: Case 4 questions, Skeptic 3, Prober 3, Values 3, Pressure 2. Total 15 in the banks plus 5 reverse questions.

## Question banks

### A. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's Saturday evening, the second night of a live event, and a reward claim is failing for part of the player base. Walk me through your first 15 minutes." | CASE | [generic] | Clarify: who is affected and how many, and whether the event is still live. Then the first call: hold the event, roll back, or hotfix. Name who you pull in: engineering, QA, community. Say what you will tell players and when. Speak the plan as a plan, not as a past incident. | The Outage Hour tabletop, per the careers page. A live problem with no claim about your past, so no provenance quote. |
| A2 | "Retention dropped in week two of the last event. What do you check first?" | CASE | [generic] | Segment the drop: event participants against non-participants, and new players against returning. Check measurement before blaming content. Say which assumption you would test first. | A metric-reading case for a live-ops producer, using the retention language in the JD. |
| A3 | "Walk me through what your post-event review would contain, and what would make you cancel the next event." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Describe the review you would run: the KPIs, the comparison baseline, the decision it feeds. Answer slot: if you have run a post-event review, say what it measured and what changed; if you have not, say so and say what you would measure first. | F1 is the gap, so the answer slot does the work. The JD line raises the question. |
| A4 | "What do you refuse to ship an update without?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name the checklist's own purpose: that the build matches what is announced. Name one item you would never drop, and say why in terms of what it catches. Do not describe a checklist step you did not write. | F7, and Tobias's talk on patch accuracy. The quote stays at "wrote". |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How would you coordinate design, art, engineering and community on an update when you have no authority over any of them?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Hold: "I haven't led a team." Then how you would run the update: one shared calendar, one owner for each decision, and the checklist as the common plan. Answer slot: if you coordinated any cross-team update, name the teams and what you set; if you coordinated mainly with QA, say so and describe how you would run the other four. Hold through two follow-ups. Concede what is true: you have no authority over those teams. | The highest-ROI rehearsal in this pack. It targets F2 and the stated negative, the most likely objection to a hiring manager. |
| B2 | "This role sits on monetised titles, and your background has none. Why should I trust you to read a live-ops calendar that is built around in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would do first: learn the monetisation model from the calendar, the data and the people who own it. Keep it a plan. | F10. The question's premise comes from your stated negative, not from the JD. |
| B3 | "The retention numbers you presented: how much of that analysis was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you presented and what you did with it. Answer slot: if you did the analysis, say which part and how you decided; if you presented figures someone else built, say so plainly. Never claim analysis the quote does not carry. | F6. A skeptic's way to test the presentation-versus-analysis gap. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention figures in that monthly review were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you can say about how each figure was counted, then name the weakest assumption you know of. If you do not know how a figure was counted, say so. | F6, a defend-the-number slot. The figure is yours, so the counting question is fair. |
| C2 | "How do you check that a patch note describes what actually shipped?" | VAL | [grounded] "Patch Notes Are a Promise" (interviewer's talk, GDC 2026, search snippet) | Open prompt. Answer slot: if you have checked notes against a build, say how; if the checklist did this, say which step. If you have not, say so and describe how you would check. | Tobias's own published argument. An open prompt, so the guidance supplies no event. |
| C3 | "Which step on the checklist catches the most problems?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | If you know which step catches most, name it and say how you know. If you do not know how often each step caught something, say that plainly. | F7, a premised question on the checklist you wrote. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team" (your message); "4 years as an associate producer at a puzzle-game studio." (your message) | Hold: "I haven't led a team. What I have done is run the weekly content-drop calendar for our main title for two years, and write the checklist QA still uses." Concede the specific gap: you have not managed people. Hold through two follow-ups before you concede anything more. | F1, F2 and F10 together. This is a pressure test of the stated negative, so hold it, and do not inflate. |
| D2 | "That calendar: how much of it was actually you, and how much was set for you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say what you set and what was set for you, in your own words. If the calendar's priorities came from others, say so. | F3. Attribution is the test; the quote carries the scope of one title and content drops. |

### E. Values / Behavioral

Values are from the Saltmarsh values page, fetched. This round is detected as values-style: the careers page documents a values conversation.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (saltmarshgames.com/values) | Selection scaffold: pick a time a dated plan met player feedback, and say what you did when they disagreed. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar you ran for two years, and what you would change about how it responded to players. | Value 1 of 3. The material does not show a disagreement, so the honest branch is written in. |
| E2 | "When did you announce something before it was ready?" | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (saltmarshgames.com/values) | Selection scaffold: pick a time a date went out before the work was ready. Answer slot: if you have one, say what you did; if not, say so, and describe how you would stop an announcement going out early. | Value 2 of 3. Your material does not show an early announcement. |
| E3 | "What did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Map: the checklist, which you wrote and which QA still uses. Name what it added. Answer slot: if you can name the step that was added, say what it caught; if not, say you cannot yet show what it changed. | Value 3 of 3, "Leave the Build Greener". The checklist is the one story your material carries. |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold, fed by the content-drop calendar you ran (F3). Honest branch in E1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold, no story in your material (E2). Honest branch in E2 |
| Leave the Build Greener | Every release leaves the codebase and checklist better | The checklist you wrote and QA still uses (F7). Answer slot in E3 |

## Reverse questions

Each one has a "why it lands" line.

1. **"Which two titles will this role cover, and how does the shared calendar change what their teams do after February?"** Why it lands: the Saltmarsh news announcement says one shared events calendar and one live-ops group from February 2027. This question shows you read it and asks what it means for this role. Confirm the two titles before you use this line, since I have not confirmed the announcement names them.
2. **"Your talk argues that a live team is judged by how often its patch notes match what shipped. How do you measure that today?"** Why it lands: it ties to his own published argument, the most direct way to show you read him and not only the company.
3. **"In the Outage Hour, what does a strong answer look like to you: the first decision, or how the team hears about it?"** Why it lands: it asks what he scores, which is a question a hiring manager likes to answer.
4. **"Who would I work with most closely across design, art, engineering and community, and how is their input on an update decided today?"** Why it lands: it names the coordination requirement from the JD and asks how it works in practice.
5. **"If I started, what would you want the first live event I own to look like?"** Why it lands: it turns the interview toward the first ninety days and gives you his expectations in concrete terms.

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, D2, reverse 1 | |
| Coordinate design, art, engineering and community teams | A1, B1, reverse 4 | |
| Own the post-event review and the KPIs it reports | A3, C1 | |
| Manage the release checklist with QA | A4, C3, E3 | |
| 3+ years producing live-service games or apps | D1, B2 | Your years are real. The live-service part is not established (F5) |
| Experience running a content calendar | D2, E1 | |
| Comfortable with player-retention metrics | A2, B3, C1 | |
| Clear written communication | none, and why | The Outage Hour is spoken. Your written artefact is the checklist (F8), covered in A4 |

## Sources

- Provided documents: your message (the background, the JD summary and the interview context), and the JD text you supplied.
- Searches and fetches (L1):

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh games values | yes | Values cheat sheet and E1 to E3. Query: "Saltmarsh Games values". Result: saltmarshgames.com/values, fetched |
| 2. saltmarsh games interview process, role family | yes | Loop structure: the Outage Hour, one 60-minute session with the hiring manager. Query: "Saltmarsh Games interview process Live Operations Producer". Result: saltmarshgames.com/careers/interviewing, fetched |
| 3. saltmarsh games strategy, recent news | yes | Larkspur announcement, September 2026: a season-pass model and one shared events calendar from February 2027. Used in reverse question 1. Query: "Saltmarsh Games mobile studio strategy news". Result: saltmarshgames.com/news/project-larkspur, snippet only, not fetched |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer; C2 and reverse question 2. Query: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Result: a GDC 2026 talk listing, snippet only, not fetched |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

## Upgrade menu

- A redacted calendar you ran → F3 and F4 move from medium confidence to an inspectable artefact.
- The retention deck you presented → F6's defend-the-number slot can be answered from the figures themselves.
- A post-event review you ran, with its KPIs → F1 moves from discovery to grounded, and A3 gets a real answer.
- Confirmation that the Friday slot is the Outage Hour → the loop is confirmed, not just documented.
- A deeper research pass (strategy brief, Tobias's other talks, role-family loop reports, recent org changes) → up to 6 more searches and 2 more fetches, several more minutes. Offered once.
- If you have an incident you handled, even a small one → F9 moves from discovery to grounded, and A1 gets a real answer.
