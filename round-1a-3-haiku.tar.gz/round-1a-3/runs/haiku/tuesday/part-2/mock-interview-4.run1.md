Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-4-denied-59fe7a4e/0e78ea7c-0b66-42a8-9cea-a265527a03ce/scratchpad/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the hiring-manager round from your dossier. Web search was refused this session, so company strategy and the interview loop are generic, labeled `[generic]`.

Two things to check before Thursday:
- **The dossier is about three months old** (dated 2026-08-14). Re-check that the JD and the role's status still match.
- **Most likely objection:** "You've never held the PM title or owned a roadmap." Bank S2 is the one to rehearse hardest. Concede the gap in one plain sentence, then hold the integration quote through two follow-ups.

The pack covers 18 questions across five interviewer styles, with a fit snapshot, a list of claims you must not make, and reverse questions. Two lines to say, from the dossier's prohibited list: "I haven't held the product manager title" and "I haven't owned a product roadmap."

Offers, one line each:
- Want a drill? I can play the Skeptic on S2 and push back on your answer.
- I can update `tuesday-dossier.md` with the gaps this prep exposed, so they carry into later sessions.
- I can turn the pack into a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday
**Interviewer:** hiring manager (name not given)
**Built from:** `tuesday-dossier.md` (underwriting dossier v1.1, dated 2026-08-14), decision `conditional_go`
**Research:** web search was not permitted this session, so no company material was pulled. Company strategy, values and loop structure are `[generic]` throughout.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: `VAL` behavioral and values, `EXP` experience deep-dive, `JD` role-driven, `CO` company and strategy, `CASE` live problem.
- Guidance is scaffolding, not a script. Rehearse the candidate's own sentences, quoted below, in your own words.
- **Answer slots** are instructions for the interview, not questions to you. Each has an honest branch for when the practice was not yours or did not happen.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | high | [grounded] | transferability | Your material shows integration leadership at client scale, not product-management tenure. Say the integrations in the quote's terms and stay adjacent. Answer slot: if any of those integrations included a product decision you made, say which; if none did, say so plainly. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | high | [inferred] derivation: this pack's gap call; the dossier does not grade R2 | transferability | Integration work on a vendor's APIs is adjacent to shipping an API product. Do not say you shipped a product. Answer slot: if any of those integrations became a product feature you shaped, say which; if none did, say so plainly. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier V2) | high | [grounded] | discovery | The playbook is inspectable, but nothing in the material shows schema work. Answer slot: if you wrote or reviewed API docs or schemas, say what; if you did not, say so and say how you would get fluent. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | medium | [grounded], caveat: confirmed, limited inspectable proof, expect a probe | presentation | Say the sessions as you ran them: quarterly, feeding client evidence to product. Volunteer the limit: your material shows the inputs, not what product did with them. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] (dossier allowed_interview_strategy: clarify) | discovery | No verified entry speaks to this requirement. Answer slot: if you ran delivery inside a product org, say how; if you did not work that way, say what you would want to confirm about how they define it. |
| F6 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] (dossier uncertain_or_weak_areas, acknowledge_gap) | capability | The dossier records this as a gap. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge. |

## Prohibited claims

Each entry names its basis and its honest form. None of these may be asserted, softened or implied in any cell below.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims, sourced | Plain acknowledgment: "I haven't held the product manager title." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap, sourced | Plain acknowledgment: "I haven't owned a product roadmap." Then the plan to learn it. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims, sourced | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Owned the partner API roadmap, or set what the platform built | Inflated form of F1 and V1, built here | V1 at its own scope. Analysis only: your material says integrations led, not product direction set. |
| Ran the quarterly roadmap inputs as product's decision-maker | Inflated form of F4, built here | V3 at its own scope. Analysis only: your material says the sessions fed evidence to product, not that you set what product decided. |

## Persona table

Weights rest on the round type you gave (hiring manager, which the relationship prior maps to Case and Skeptic). No interviewer profile exists, and no loop source documents the rounds, so the loop is the generic archetype with flat weights. That means no values round is detected and no values section is built.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the PM-title gap and roadmap ownership directly | Top weight, 5 questions. The dossier names the title-and-roadmap objection as the likeliest one. | Concede the gap plainly, hold the integration quote, state the ramp plan. |
| Case / Strategist | Live problems on the squads and partner adoption | Second, 4 questions. Hiring managers buy capability and test judgment on their own roadmap. | Clarify, then structure, then name the unknowns (authority, baseline). |
| Data-Driven Prober | Asks how the 30+ figure was counted and what was yours | 4 questions. The one headline figure is the likeliest probe target. | Name the weakest assumption before they do; say plainly what you do not know. |
| Pressure | Time-boxed challenges to the title and the ownership claim | 3 questions. Lower weight, but the title objection can be delivered in pressure form. | Pause, restate, hold through two follow-ups, then concede what is true. |
| Conversational | Open invitation to walk through your journey | 2 questions. Casual openers are still scored. | Keep the 90-second arc to the quoted sentences and stop there. |

## Question banks

### Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "3+ years product management experience" (dossier role_profile R1) | Name the roadmap gap first: "I haven't owned a product roadmap." Then the plan for learning it. Do not claim PM tenure. | Scores honest self-assessment. Premised on the JD's own requirement line only. |
| S2 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; acknowledgment sourced from dossier prohibited_claims and uncertain_or_weak_areas | The highest-ROI rehearsal. The underwriter named this objection. Concede first: "I haven't held the product manager title and I haven't owned a roadmap." Hold the integration quote through two follow-ups. State the limit: it is integration work, adjacent to roadmap ownership. Answer slot: if any of those integrations involved a prioritization call you made, say which; if none did, say so plainly. Do not argue them out of the trade-off. | Named by the underwriter. Its negatives carry dossier sources, so it is asked as written. |
| S3 | "Write specs and drive delivery with two engineering squads — which part of that is yours, and which sits with the squad leads?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you directed delivery work with engineers on an integration, say how; if that sat with someone else, say so and what you contributed. | Raised by the JD's responsibility line. The answer's second branch allows the practice never existed. |
| S4 | "I don't see roadmap ownership in your background — how would you handle that in this role?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap); the negative is sourced, not asserted | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan, stated as a plan. No bridge. | Negative sourced from the dossier's acknowledge_gap area. |
| S5 | "Partner adoption is yours to define and track — what would the current baseline be?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you measured adoption on any integration, say what and how; if you did not, say so and say what you would need to find out first. Do not supply a baseline. | Raised by the JD's adoption-metrics line. The baseline is unknown, so the answer must not invent one. |

### Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner API adoption dropped 20% this quarter. Diagnose it — what do you check first?" | CASE | [generic] | Clarify the objective and the baseline, then segment by partner, then the approach, then the metrics and risks. Think aloud. | Live problem on the role's own metric. Asks no claim about your past. |
| C2 | "Two engineering squads both want the next quarter's slot. How do you decide, and who decides?" | CASE | [generic] | State the decision rule, name whom you would consult, and say what you would need from the squad leads. Do not assert that the call is yours. | Tests the decision-authority unknown the dossier flags. A live problem, so it presupposes nothing about you. |
| C3 | "Sketch your first 90 days on this API platform — what do you need to know first?" | CASE | [generic] | Clarify before planning. Name the unknowns: decision authority and the adoption baseline. | Rewards clarifying before structuring. |
| C4 | "How would you run delivery across two engineering squads — what cadence, and who owns it?" | CASE | [generic] | Describe a cadence as a plan. Name who owns it, and whether that is your call or the squad leads'. Do not cite a past cadence you did not run. | Covers the agile requirement (F5) as a live problem rather than a past claim. |

### Experience deep-dive (Prober, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slots in your own words. How it was counted: answer slot. What it is sensitive to: answer slot. The assumption you would defend least: answer slot. Which part was yours: answer slot. If you cannot say how it was counted, say so plainly. | The headline figure raises all four defend-the-number slots. The pack supplies no counting method. |
| P2 | "Which of those integrations would you call a shipped API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if any of them became a product feature you shaped, say which and how you decided; if none did, say so plainly and describe the integrations as they were. | Covers R2. The premise that one was a shipped product is not in the quote, so the second branch allows it was not. |
| P3 | "Walk me through the integration playbook: who uses it, and how would you know it worked?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say who uses it, in the quote's words. Answer slot: if you measured whether it worked, say what; if not, say so. | Covers docs (R3). Schema work is not in the material, so no schema question is built. |
| P4 | "What did the quarterly roadmap-input sessions change on the product side?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if any input changed a product decision, say which; if not, or if the decision was not yours, say so and say what the sessions did carry. Stay with the sessions. | Covers R4, and the caveat in F4 is the probe. |

### Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why should we hire you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; acknowledgment sourced from dossier prohibited_claims | Concede the title in one sentence, then the integration quote, then the limit. Do not argue the comparison. | Pressure form of S2, timed. |
| R2 | "That 30-integration number — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote. Answer slot: if part of it was others' work, say which; if you cannot split it, say so. Do not defend a split you cannot repeat. | Tests attribution under pressure. Hold, then concede the exact part. |
| R3 | "Roadmap ownership is the job. Why shouldn't we see its absence as a disqualifier?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; acknowledgment sourced from dossier acknowledge_gap | Hold the position that the integration and input work is real and adjacent. Concede explicitly that roadmap ownership is not yet your record. Then the plan. Do not claim to have owned it. | Hold-then-concede. The held position is only what the quote carries. |

### Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc through the three quoted sentences, in order. Stop at the sentence. | Casual openers are still scored. |
| V2 | "What are you most curious about on the platform right now?" | CO | [generic] | One question back: the adoption baseline, or how decision rights work across the squads. Do not claim knowledge of their strategy. | Company knowledge is not researched this session, so this is `[generic]`. |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| R1 3+ years PM experience | S1, S2, R1 | Covered by the bridge and the concession. |
| R2 Shipped API or platform products | P2 | Covered. |
| R3 Technical fluency: API docs, schemas | P3 | Partial. Docs covered. Schemas: none, and why: no quoted sentence carries schema work. |
| R4 Stakeholder management | P4, V1 | Covered. |
| R5 Agile delivery | C4 | Covered as a live problem; F5 is discovery. |
| Roadmap and prioritization authority (sub-claim) | S4, R3, C2 | Covered by the acknowledgment and the plan. |
| Adoption metrics | S5, C1 | Covered. Baseline unknown. |

## Reverse questions

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the top unresolved risk in the dossier. Asking it reads as diligence and answers what you need before accepting.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier names no baseline. Their answer tells you whether the role is measurable at all.
3. "What would a strong first 90 days look like on the two squads?" Why it lands: `[generic]`. It tests what delivery means here without assuming the answer.
4. "When a partner and an internal team want different things, who sets the priority?" Why it lands: `[generic]`. It asks the decision-rights question from a second angle.
5. "What would make you say in six months that hiring me was the right call?" Why it lands: `[generic]`. The answer names the bar you will be measured against.

## Sources

- Provided: `tuesday-dossier.md`, underwriting dossier v1.1, generated 2026-08-14. Sections consumed: `handoff_to_mock_interview` (verified evidence, allowed strategies, objections, risks, employer questions, prohibited claims) and `role_profile` (requirements). `decision` read for context only.
- The dossier is about three months old and today is 2026-11-20. The JD and the role's status should be re-verified before Thursday.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Not attempted, because search permission was refused. Would have set a values sheet only if a values round were detected, which no loop source establishes. |
| 2. `Quartzline interview process product manager` | unavailable | Refused: "Quartzline interview process product manager platform APIs". Would have set the loop structure. |
| 3. `Quartzline strategy` / recent news | unavailable | Refused: "Quartzline partner API platform strategy 2026". Would have fed the CO bank. |
| 4. interviewer name | n/a | No name was given. |
| 5. representative JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- Search permission for this session → company strategy and the loop structure, which would turn V2 and C-bank strategy items from `[generic]` into `[grounded]`.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- The current JD text, if it has changed since 2026-08-14 → re-verification of the role_profile rows.
- The recruiter's note on what the round covers → weights and coverage for the round itself.
- The adoption baseline, if the recruiter shares it → turns S5 and the reverse question 2 into a grounded exchange.
- Prep time before Thursday → a prioritized prep schedule.
