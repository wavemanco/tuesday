Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-canned-ecbec27c/25c4be94-7193-4b8a-b542-d81fd4e62f0f/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it on the assumption that your 60 minutes is the Outage Hour. The careers page describes that as the loop: a live-incident tabletop during a live event, then a values conversation with the hiring manager, and no take-home.

**What matters most**

- **Highest-ROI prep (C1):** "You haven't led a team. Why would you be effective coordinating four of them?" Say "I haven't led a team" plainly, then describe the coordination you have done. The JD asks you to coordinate design, art, engineering and community teams, so this probe is likely.
- **Your strongest material** is the weekly content-drop calendar and the release checklist QA still uses. Use those as the stories for the values conversation.
- **Your gaps are stated, not hidden.** Don't claim two titles, post-event reviews, or in-app purchase experience. The pack gives you honest answer slots for each.
- **Post-event review and KPIs (A5):** your material doesn't show these. Prepare an honest "here's how I'd build one" answer.

**The values conversation.** Saltmarsh publishes three values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Tobias Wrenfield's public GDC 2026 talk, "Patch Notes Are a Promise", argues a live team is judged by whether its patch notes describe what actually shipped. He came from QA, so expect precision to be tested. For the Ship the Patch value, you have no story that matches, so the pack says so and gives you the honest branch: say you don't have one, then give the nearest thing you do.

**Reverse questions to ask.** The strongest ones are about his talk and about Project Larkspur. Larkspur moves both titles onto one shared events calendar from February 2027. I read that from a search snippet and did not open the full page, so check it before you quote it.

**Things to check before Friday**

- The fit quotes come from your message, not a CV. If you paste your CV, the quotes can be sharper.
- The pack assumes the Outage Hour format from the careers page. If your session is different, tell me.

Would you like a drill? I can play Tobias on C1 and push back until you hold your position without getting defensive. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games. Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager). Format: the Outage Hour, one 60-minute session: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home, no presentation.

Assumption: your 60 minutes is the Outage Hour. The company's careers page describes that as the loop. If it is a different round, say so and I will restructure.

## How to use and type key

Personas describe how a question arrives. Types describe what it scores.

- **CASE**: live problem from the role, scored on structure and reasoning
- **VAL**: behavioural question scored against Saltmarsh's published values
- **EXP**: deep-dive on your own past work; scored on whether it holds up under scrutiny
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge

Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message. Nothing about your past goes beyond those quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title, weekly content drops, two years. It does not say two titles or live events. Keep the bridge at your own scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD names two titles, so expect a probe on that. If you planned events across more than one title, say what and how. If not, say so and say how you would start. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | This quote reaches the requirement directly. Lead with the calendar's name and length; a named record beats an adjective. Expect a probe on its cadence and how you planned it. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Years and role match. "Live-service" is not your word, so describe the live part in your sentence's terms: a puzzle game with weekly drops you ran. This is a length-of-experience requirement, not a gate, so it is graded on fit. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning them. Say only: "I presented the monthly retention numbers to the studio head." Answer slot: the JD asks about comfort with the metrics themselves. If you chose which numbers to cut or what to do when they moved, say so in your words. If you only presented numbers others produced, say that plainly. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or the KPIs it reported. Answer slot: if you have run one, say what it covered and which KPIs it reported. If you have not, say so, and say how you would run the first one. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | transferability | Your material names QA. It does not name design, art, engineering or community, so do not stretch it to them. The derivation is this pack's: QA coordination is the nearest adjacent work. Answer slot: name any of the four teams you coordinated an update with and what you did with them. If none, say so and describe how you would run an update with all four. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Your sentence gives authorship and QA's continued use. It does not say you managed a release against it. Keep to that: "I wrote the release checklist; QA still uses it." Answer slot: if you ran a release against it with QA, say what it caught. If not, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A checklist other people still use is a written artifact you can name. Do not describe your writing as "clear" yourself; name the artifact and let it speak. Expect a probe for proof, so have the checklist's name and purpose ready. |

Gate note: none of the JD's requirements is a term gate under the suite's definition, so none is surfaced as a hard gate. The pack's own observation: your material does not show the JD's monetisation context, because the JD says nothing about it. See the prohibited list.

## Prohibited claims

Each entry names its basis and the honest form. Nothing in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" | "I haven't led a team." No slot. What you have coordinated is covered under F6. |
| Worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. |
| Owned the live-events calendar for two titles | Inflated form of F1: the quote is one title's weekly drops | F1's quote at its own scope. The limit is this pack's observation: your material says one title's content drops, not two titles' live events. |
| Owned retention metrics | Inflated form of F4: the quote is presenting numbers | "I presented the monthly retention numbers to the studio head." |
| Managed QA on releases | Inflated form of F7: the quote is authorship plus QA's use | "I wrote the release checklist; QA still uses it." |

## Reading the interviewer

Public footprint only. Source: a GDC 2026 talk listing for "Patch Notes Are a Promise", given by Tobias Wrenfield as Head of Live Operations at Saltmarsh, previously a QA lead at a console studio. Its argument: a live team is judged by how often its patch notes describe what actually shipped.

Practical implications:
- He comes from QA, so precision about what shipped will be tested. Answer with what is built; say "not yet" rather than promise.
- His talk's argument is the company's value "Ship the Patch Not the Promise". Expect it to be the spine of the values conversation.
- Mirror opportunity: your release checklist (F7) is the nearest thing to his own territory. Use its quote, not a claim that you share his background.
- Shared jump: none. You are not on his career path. Do not invent one.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a live incident, clarify then act | Highest. The careers page names the tabletop as the format. | Clarify impact first, then say who you bring into the room and what you tell players. |
| Values / Behavioral | The values conversation after the tabletop | High. The careers page names it. Its theme is the three published values. | Map a story to each value where a quote carries one; otherwise a scaffold ending in the honest branch. |
| Skeptic | "Which part would you be weakest at on day one?" | Medium-high. Hiring managers derisk gaps. Two negatives you stated are the material. | Hold to your own sentences; say plainly what you have not done; give a ramp plan as a plan. |
| Data-Driven Prober | "How was that counted?" | Raised by his QA background and talk on accuracy, so weighted up. | Name the weakest assumption you know of before he does. Say "I don't know how it was counted" where true. |
| Pressure / Stress | Time-boxed challenge to a held position | Lower; a tabletop is already time-boxed. | Hold through two follow-ups; concede a specific uncertainty, never the core claim. |
| Conversational / Rapport | Opening "walk me through the journey" | Plausible as an opener. Casual questions are still scored. | A 90-second arc; stop when you reach the present. |

Peer is omitted: the round is with the hiring manager, not a peer.

## Question banks

Session total: 19 questions. Depth follows persona weight (5, 4, 3, 3, 2, 2).

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're in a live event and the reward-claim endpoint is failing for about a fifth of players. Walk me through the first hour." | CASE | [generic] | Clarify: which platforms, which players, since when. Then decide: who you need in the room (engineering on call, QA, community), whether to pause or hotfix, and what you tell players now. Say what you know and what is still being checked; no fix time you cannot keep. | The Outage Hour's format. [generic] because it is a live problem that asserts nothing about your past. |
| A2 | "What do you tell players in the first fifteen minutes, and what do you hold back?" | CASE | [generic] | Announce what is confirmed and what is being checked. Hold back any ETA or cause you have not verified. Links to the value "Ship the Patch Not the Promise" (see the values sheet). | Tests the same discipline his talk argues for. |
| A3 | "Retention is down twenty percent on day three of an event. What do you look at first?" | CASE | [generic] | Segment before blaming the event: platform, cohort, the funnel step where players drop. Name the assumption behind the first metric you pick. | Retention is a JD requirement (F4). [generic] because it is a pattern for the problem. |
| A4 | "You've run a content calendar. For two titles, how would you plan next quarter's events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story map: one title, weekly drops, two years, in your words. Then the plan for two titles, labelled as a plan, not a past. Answer slot: if you have planned across more than one title, say how. If not, say how you would start. Mention the shared calendar only if you read the company news (see reverse questions). | F1 and F2 are the evidence. The question presumes two titles, which the JD raises; the guidance does not claim you have done it. |
| A5 | "Where does the post-event review sit in your planning, and which KPIs would it report?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Answer slot: if you have run a post-event review, say what it covered and which KPIs it reported. If not, say so and describe how you would build one. | F5 is discovery. The question is the JD's own line, so the answer slot holds. |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] value "Players Before Plans" (company values page); no candidate sentence carries a story | Selection scaffold: pick a time a player-facing change pulled against the schedule, such as a drop moved or reshaped on player feedback. If none comes to mind, say so plainly, then give the nearest thing your material carries: the weekly drop calendar you ran for two years, and how you would decide next time. | Published value, no quote carries a story, so the honest branch is written in. |
| B2 | "Tell me about a release where what you announced did not match what shipped." | VAL | [grounded] value "Ship the Patch Not the Promise" (company values page) | Scaffold: pick a release where announcement and shipment diverged, or where you held an announcement until it was true. If you have none, say so. Do not invent an ending. | His talk's theme. The honest branch matters most here. |
| B3 | "What have you left in a release process that the next team still uses?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story map on "Leave the Build Greener": you wrote the checklist, and QA still uses it. Answer slot: if you revised it, say what changed and why. If not, say it stayed as you wrote it. | F7's quote carries the story. The question presumes only what the quote says. |
| B4 | "Give me an example of a hard truth you delivered to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Story map on the presentation: you presented the numbers. Answer slot: if the numbers were unwelcome and you said so, say what you said and what happened. If not, pick another time and say so. | Values round scores "land the hard truth". |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't led a team. Why would you be effective coordinating four of them?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update"; plain acknowledgment: "I haven't led a team." (your message) | Plain acknowledgment: "I haven't led a team." Then the coordination you have done, from F6, in its own words. Answer slot: name any of the four teams you coordinated an update with. If none, describe how you would run an update with them, as a plan. Hold through two follow-ups by returning to what you did. | This is the highest-ROI prep. The gap you stated meets the JD's coordination line, and the probe is likely. |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Name the two gaps in your own words: "I haven't led a team," and "I haven't worked on a game with in-app purchases." Then a ramp plan for each, stated as a plan. | The honest answer is the stated negatives. |
| C3 | "Your background is puzzle games. What would you need to learn about how our titles make money?" | JD | [grounded] "I haven't worked on a game with in-app purchases." (your message, plain acknowledgment) | Say the plain acknowledgment. Then name what you would look at first: monetisation metrics, the purchase funnel, how events drive spend. Present it as a plan. | The JD says nothing about monetisation, so the question does not presume it. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you know of the counting, in your words. If you do not know how it was counted, say so. Name the weakest assumption you are aware of. | F4 is the evidence; the question is a defend-the-number probe. |
| D2 | "Which assumption behind that retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the assumption in your words. If you did not set the definition, say whose it was. | Defend-the-number slot a headline figure raises. |
| D3 | "The patch notes say the fix shipped. How do you check that before you announce it?" | JD | [grounded] value "Ship the Patch Not the Promise" (company values page); "Wrote the release checklist our QA team still uses." (your message) | Story map: the checklist you wrote is the verification gate QA uses. Describe the check as a plan for a fix, not a past. | Ties the value, his talk and F7 together. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold: you ran one title's weekly drops for two years, and you will not claim two titles. Concede specifically: what you would need to learn for two. Do not argue that you are better. | Hold-then-concede. The held position is only the quote. |
| E2 | "That retention presentation. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: you presented them. Concede what others produced, if anything. Do not claim analysis you did not do. | Attribution probe. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the studio, the four years, the weekly calendar, the checklist, the retention presentations. Stop at the present. | Casual openers are still scored on communication economy. |
| F2 | "What live title have you been playing lately, and what did its events get right?" | JD | [generic] | Name a title you actually play and one event you can describe. Do not guess at Saltmarsh's titles. | A rapport question; keep it honest and short. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A4, E1 |
| Coordinate design, art, engineering and community teams | C1, A1 |
| Own the post-event review and the KPIs it reports | A5 |
| Manage the release checklist with QA | B3, D3 |
| 3+ years producing live-service games or apps | F1 |
| Experience running a content calendar | A4 |
| Comfortable with player-retention metrics | A3, D1, D2 |
| Clear written communication | none directly; B3 is the artifact to name. Written work is assessed across every answer, so no separate question. |

## Values / principles cheat sheet

Triggered: the careers page documents a values conversation in the loop. Values taken from the company's values page.

| Value | Working meaning | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1: a player-facing change that pulled against the schedule. If none, say so, then give the nearest thing your material carries. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2: a release where announcement and shipment diverged. If none, say so. |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F7 quote: "Wrote the release checklist our QA team still uses." Answer slot: if you revised the checklist, say how. |

## Reverse questions

Each has a reason it lands.

1. "Your talk argued that a live team is judged by how often its patch notes describe what shipped. What does that look like on the calendar you'd want me to run?" Lands: ties to his own path, from QA lead to Head of Live Operations.
2. "Project Larkspur moves both titles onto one shared events calendar from February 2027. How does the producer's role change when the calendar becomes shared?" Lands: shows you read current strategy. Source: the company news item, read from its search snippet; I did not open the full page.
3. "Who owns the post-event review today, and which KPIs does it report?" Lands: clarifies F5 before you are asked about it.
4. "What would the first ninety days need to look like for you to say this was the right hire?" Lands: sets the expectation you will be measured against.
5. "What is the most common reason a release has to be rolled back here?" Lands: asks about the checklist's real failure modes, which connects to F7.

## Sources

**Provided documents:** the JD text and your background, both from your message. No CV was supplied, so every evidence quote is from your message.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2. User links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values sheet: three values, named as published. Query: "Saltmarsh Games values". Fetched saltmarshgames.com/values. |
| 2. Saltmarsh Games interview process | yes | Loop: one 60-minute Outage Hour with the hiring manager, no take-home. Query: "Saltmarsh Games interview process live operations producer". Fetched saltmarshgames.com/careers/interviewing. |
| 3. Saltmarsh Games strategy / news | yes | Reverse question 2 and the A4 framing. Query: "Saltmarsh Games mobile game strategy news". Result: "Announcing Project Larkspur", September 2026. Snippet only; not fetched. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read and the persona weights. Query: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Result: a GDC 2026 talk listing. Snippet only. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Unattributed results: none.

## Upgrade menu

- Your CV text, pasted verbatim → the quotes move from your message to your CV, so the rows say "your CV" and the grading can rise.
- Any post-event review you have run, even informal → F5 moves from discovery to grounded, and A5 gets a story.
- The two titles' names and their monetisation model → the CASE questions can name the real titles, and a monetisation question becomes a raising source.
- Any checklist revision or KPI report you have written → B3 and D1 get a second quote to stand on.
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes. Want it?
- Save a tuesday-dossier.md → records the gaps this prep exposed for later sessions.
