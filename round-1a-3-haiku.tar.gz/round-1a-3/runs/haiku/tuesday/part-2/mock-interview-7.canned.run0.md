Femi, I saved the full prep pack here: /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-tuesday-part-2-rooms-case-7-canned-c41f5078/304f294e-caa4-494c-971b-a0dea09c7b2d/scratchpad/femi-saltmarsh-interview-pack.md

**Research limits:** I found nothing about Saltmarsh Games beyond a name match, so there is no company-values section. The one useful find is Tobias's GDC 2026 talk, "Patch Notes Are a Promise." He was a QA lead before this role, and his argument is that a live team is judged by how often its patch notes match what shipped. Your release checklist story fits that directly, so lead with it.

## Fit: where you're strong and where you're exposed

- **Strong:** 4 years of live-service-style work, the content calendar you ran for two years, the release checklist QA still uses, and written communication.
- **Thin:** "presented" retention numbers is not the same as owning them. Be ready to say what you did when a number moved.
- **Not evidenced in what you gave me:** coordinating design, art, engineering and community on each update; owning a formal post-event review; planning for two titles at once.
- **Gaps you named:** you've never led a team, and you've never worked on an IAP game.

## Likely objection (rehearse this most)

"You've never led a team and never worked on IAP." Concede both in your first sentence. Then give one concrete example where you coordinated across disciplines without managing them. For IAP, say you haven't run it, then walk through the KPIs you'd track: conversion, revenue per paying user, and retention after a sale event.

**Do not claim:** managing people, IAP exposure, or owning retention outcomes unless you can name what you changed.

## Questions to rehearse

1. **Release checklist:** Walk me through it. What did it catch after it went live?
2. **Cadence:** How did you decide the weekly content-drop cadence?
3. **Patch-note accuracy:** How did you make sure release notes matched what shipped?
4. **Leadership:** You've never led a team. Why trust you to coordinate four disciplines?
5. **Two titles:** You ran one title. How would you run two?
6. **Ownership:** You presented retention numbers. Which did you actually move?
7. **Monetization:** How would you judge a sale event in an IAP game?

## Reverse questions to ask them

1. How does the post-event review feed the next calendar cycle, and who owns the retention target?
2. Tobias's talk argues patch notes should match what shipped. How do you verify notes against builds before release?
3. Who owns the release checklist today, and what's the QA gate?
4. Which of the two titles is most constrained by its calendar right now?

## To make the pack sharper

- Any presentation, exercise or take-home in the 60 minutes?
- What genre and monetization model are the two titles?
- One or two real retention numbers you can tell me, so I can tighten the metric answers.
- Deeper research on Tobias's other talks and the loop structure is available if you want it. It's optional.

Would you like a drill? I can play Tobias and run question 4 with follow-ups, then give feedback against its guidance.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: femi-saltmarsh-interview-pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games (hiring-manager round, Tobias Wrenfield)

Built on: JD as supplied; Femi's background as stated; public research (one GDC 2026 talk page). Company-level research returned nothing usable, so no company values section.

## 1. Fit snapshot

| JD requirement | Femi's evidence (his words) | Confidence | Gap type |
|---|---|---|---|
| 3+ years producing live-service games or apps | "4 years as an associate producer at a puzzle-game studio." | High | None; confirm the title was live-service in practice |
| Run a content calendar | "I ran the weekly content-drop calendar for our main title for the last two years." | High | None |
| Comfortable with player-retention metrics | "Presented the monthly retention numbers to the studio head." | Medium | Presenting is not owning. Bridge: what you did when a number moved |
| Clear written communication | "Wrote the release checklist our QA team still uses." | High | None |
| Coordinate design, art, engineering, community per update | Not stated directly | Medium | Evidence gap. Ask for a specific update you coordinated across disciplines |
| Own the post-event review and its KPIs | Not stated directly | Low | Evidence gap. Ask whether a formal post-event review existed in his role |
| Plan calendar for two mobile titles | One title | Medium | Scope gap. Bridge: calendar-planning method, not title count |
| Manage release checklist with QA | "Wrote the release checklist our QA team still uses." | High | None |
| (Not in JD) Led a team | "Never led a team." | n/a | Experience gap. Recoverable only with concrete cross-functional leadership examples, not management claims |
| (Not in JD, likely expected) In-app purchase game | "Never worked on a game with in-app purchases." | n/a | Experience gap. Recoverable by reasoning about monetization KPIs, not by claiming exposure |

## 2. Prohibited claims (built locally, no dossier)

- Do not say or imply he has led or managed people.
- Do not say or imply he has worked on IAP, monetization or store-sale events.
- Do not claim he owned retention outcomes unless he can name what he changed. "Presented" is the verified verb.
- Do not claim sole authorship of the release checklist or the calendar. Use "I wrote" for the checklist and "I ran" for the calendar only.

## 3. Interviewer read (public footprint only)

- Tobias Wrenfield: Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio (GDC 2026 talk bio).
- Published position: "a live team is judged by how often its patch notes describe what actually shipped."
- What will land: a release-checklist story with QA, and specifics on whether notes matched builds. Femi's checklist is directly on-theme. Lead with it.
- Caution: this is one talk. Do not infer more about his style.

## 4. Persona weights

- Hiring manager, operational and QA-minded (weight highest). Expect checks on release discipline and KPI ownership.
- Skeptic on leadership and scope (weight high). Expect "you've never led a team" and "one title, not two."
- Pressure / numbers challenger (weight medium). Expect "which numbers did you own?"

## 5. Question banks

**Most likely objection (deepest rehearsal): "You've never led a team and never worked on IAP."**
Guidance: concede both plainly in the first sentence, then give one concrete cross-functional example you actually coordinated, then say how you would learn the monetization KPIs.

### Hiring manager

1. **Type: Experience / behavioral.** Walk me through the release checklist you wrote. What changed after it went live?
   - Provenance: "Wrote the release checklist our QA team still uses." Answer with the specific failure it prevented, if one exists. Otherwise, a slot: name one release where the checklist caught something.
2. **Type: Process.** How did you decide the cadence of the weekly content drop?
   - Provenance: "I ran the weekly content-drop calendar for our main title for the last two years." Answer with the planning inputs you used.
3. **Type: Patch-note accuracy (on-theme).** How did you make sure release notes matched what shipped?
   - Provenance: answer slot. The candidate's quoted checklist sentence is the only basis; do not invent a process.

### Skeptic

4. **Type: Leadership.** You have never led a team. Why would we trust you to coordinate four disciplines on each update?
   - Provenance: "Never led a team." Honest branch: concede, then give one real example of coordinating without authority, if one exists. If none exists, say so and name what you would do in the first 30 days.
5. **Type: Scope.** You ran one title. How would you run two?
   - Provenance: "I ran the weekly content-drop calendar for our main title." Answer with how you would split the calendar and what you would share across titles.

### Pressure

6. **Type: Ownership.** You presented retention numbers. Which of them did you actually move?
   - Provenance: "Presented the monthly retention numbers to the studio head." Honest branch: say what you presented and what you recommended, and separate that from what was decided.
7. **Type: Monetization (likely).** Our titles run on in-app purchases. How would you judge a sale event's success?
   - Provenance: "Never worked on a game with in-app purchases." Honest branch: say you have not run IAP events, then reason through the KPIs you would track (conversion, ARPPU, retention after the event) and how you would learn from the monetization team.

## 6. Reverse questions

1. How does the post-event review feed the next calendar cycle, and who owns the retention target? *Why it lands: it shows you plan to own KPIs, the core of the JD.*
2. Tobias's GDC talk argues that patch notes should match what shipped. How do you verify notes against builds before release? *Why it lands: it ties to his own published position.*
3. Who owns the release checklist today, and what is the current QA gate? *Why it lands: it shows you know the checklist is a shared artifact.*
4. Which of the two titles is most constrained by its calendar right now? *Why it lands: it signals you want to start where the pressure is.*

## 7. Delivery

Skipped: no working-style assessment was provided.

## 8. Upgrade menu

- Interview format details (any presentation, exercise or take-home in the 60 minutes). Unlocks sections on graded deliverables.
- Genre and monetization model of the two titles. Unlocks sharper IAP questions.
- One or two specific numbers from the retention work (for rehearsal, not for the pack's claims). Unlocks metric-level guidance.
- Deep research (L2): Tobias's other talks and writing, and role-family loop reports. Offered, not run.
