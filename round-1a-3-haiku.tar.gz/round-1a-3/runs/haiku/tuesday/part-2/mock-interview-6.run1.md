I'll load the candidate job-search skill, since this is prep for a hiring-manager round, a panel, and a final round.
The playbook says to read the research checklist and the output template before any research or delivery, plus the rubric, personas and reframing audit before writing questions. I'll load search and read those references in parallel.
I can't run the research step: all three web searches were refused for permission, so the pack is built from your message alone. I'll write it now and mark those gaps in the sources section.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/haiku/tuesday/part-2/rooms/case-6-denied-9fe0a040/larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds in one file, with a shared fit snapshot and a bank per round.

The main thing to know: the web searches were refused for permission, so the pack has no company values, interview-loop detail or strategy. Round three has no values cheat sheet, and the strategy question (C5) is generic. If you allow web search, I can rerun those checks.

The pack's biggest exposure is the two gaps you named yourself: you've never managed managers, and you've never owned a hardware-adjacent roadmap. Each one gets a hold-then-concede answer, and the pack refuses to coach any version that stretches them. Start with A1 and A2 for Tuesday, then the 60% on-call figure (A5 and B2), which the panel will test hard.

Two things to check:
- **Thursday 26 November** is Thanksgiving if you're in the US. Worth confirming the panel time with the recruiter.
- **Dates:** I've taken Tuesday as 24 Nov, Thursday as 26 Nov and Monday as 30 Nov, based on today being Friday 20 Nov.

Two questions, so I can tighten the pack:
1. Can you paste the full posting text, or the recruiter's email with the focus areas? The pack is working from your summary, and the posting would turn several rows from `[generic]` into quoted fact.
2. Does the posting state any office-days, location or travel requirement? The material says nothing about those, so I haven't treated any as a gate.

Want me to play the Skeptic on A1, the question the pack names as your highest-value prep? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview prep pack (loop mode, three rounds)

Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Rounds: (1) Tue 24 Nov, 45 min, Director of Engineering (hiring manager). (2) Thu 26 Nov, 60 min panel, two staff engineers and a product manager. (3) Mon 30 Nov, 30 min, VP Engineering, described by the recruiter as "values and leadership philosophy".
Built on: your message only. Web research was refused in this session, so company values, loop detail and strategy are not in this pack.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored: VAL (values), EXP (your past work), JD (the role), CO (company and strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Answer slots (marked "Answer slot") are instructions for the interview: answer with what you did, or say plainly that it was not yours or did not happen.

## Prep triage

Round 1 is four days away. Spend the time in this order:

1. A1 and A2: the two gaps the Director will press first (managing managers, hardware roadmap). Rehearse the hold-then-concede shape out loud.
2. A5 and B2: the 60% on-call figure. Know what you can and cannot say about how it was counted.
3. C3 and C4: the same two gaps again, in the VP round's register, and "how much of that was you".
4. C1: the reliability quarter as your unpopular-truth story.
5. Everything else is insurance.

## Fit snapshot

Requirements are the role summary you supplied, quoted. Role-family requirements with no source are marked [generic].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your message says team lead of six, not two squads. Say the six in those words. Answer slot: if you have led more than one group at once, say how many and how you split them; if not, say so and say how you would split two squads. |
| F2 | "I run our hiring loop for backend roles" (your message) reaches "own ... hiring ... for 11 engineers" (role summary) | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | none | Lead with the loop, in your words. Expect a probe on how the loop is designed. |
| F3 | "own delivery ... for 11 engineers" (role summary) | "my team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | A delivery result from a six-person team, not eleven people across two squads. Say the result and your part. Do not claim the 60% alone. |
| F4 | "growth for 11 engineers" (role summary) | none given | none given | [grounded] | discovery | Your material does not show how you grew people. Answer slot: if you grew someone into a bigger role, say how; if not, say so and say how you would start with 11. |
| F5 | "partner with hardware and product on roadmap" (role summary) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | The material says roadmap pressure, not who set it or any partnership with product or hardware. Do not claim a partnership. Answer slot: if you negotiated scope with product, say how; if not, say so. |
| F6 | "hardware" roadmap, role summary: "partner with hardware and product on roadmap" | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn the constraints, as a plan and never as a past. |
| F7 | Managing managers (role-family, implied by two squads and 11 engineers) [generic] | "I've never managed managers." (your message) | none | [grounded] | capability | Words: "I haven't managed managers." Then how you would approach leads: a plan, not a past. |

Rules the table follows: gap rows carry only what you stated (F6, F7) or an answer slot where the material is silent (F4, F5). Nothing is added to make a gap feel smaller.

## Prohibited claims

Not coached in any answer, slot, hold or drill, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I led two teams" | Inflated form of F1 | "For three years I was team lead of six." The two-squad scale is an answer slot only. |
| "I managed managers" or "I've led leads" | Inflated form of F1 and F7 | Your stated negative: "I've never managed managers." |
| "I owned a hardware roadmap" or "I have hardware-adjacent roadmap experience" | Negative you stated (F6) | "I've never owned a hardware-adjacent roadmap." |
| "I cut on-call by 60%" as your sole result | Inflated form of F3 (causation) | "After I pushed a reliability quarter through, our on-call burden dropped 60%." The team's drop; your part was the push. |
| "I hired 40 engineers" | Inflated form of F2 | "I ran the hiring loop for backend roles, about 40 interviews last year." |

Limits the pack observes (its analysis, not words for you): your material shows the loop and the team of six, not the scale of two squads or eleven people.

## Round 1: Director of Engineering (hiring manager), Tue 24 Nov

Relationship prior: hiring manager. Priors: Case/Strategist and Skeptic. Your interviewer's profile is not in hand, so weights are the prior, not personal.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (top) | "You've never managed managers." Probes F6 and F7 | High. Your two stated gaps are the obvious ones for this role | Hold, then concede the specific gap; plan, not past |
| Case/Strategist | Live problem on the roadmap with hardware and product | High. The role partners on roadmap | Clarify, structure, metrics, risk |
| Pressure | Interrupts on the 60% figure | Medium. Typical with a Director at this level | Pause, restate, hold the one claim you can back |

Question bank (weighted: Skeptic 3, Case 2, Pressure 1, EXP 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never managed managers. What makes you the right person to lead leads?" | JD | [grounded] "I've never managed managers." and "3 as a team lead of 6" (your message) | Hold: "I haven't managed managers. For three years I was team lead of six." Then, in your words, how you would learn to lead leads in the first 90 days (a plan). Hold through two follow-ups by returning to the team of six. Answer slot: if you have set direction for another lead, say what you did; if not, say so plainly. | F7 is the gap the role most obviously raises. Highest-ROI prep in this pack. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | "The hardware roadmap. I haven't owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints in the first month, and who you would learn them from. Concede the gap once, specifically; do not add experience. | F6 is a stated negative, so the plain acknowledgment is yours. Interviewers ask this to test candour. |
| A3 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I run our hiring loop for backend roles" and "my team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Open with the loop, then the reliability quarter. Name the gap yourself in one clause ("I haven't managed managers yet"). Stop at 60 seconds. | Pressure format. Your two strongest quotes are the answer; the gap is said before it is asked. |
| A4 | "A device fleet's firmware update fails on 5% of devices in one region. Product wants the roadmap item shipped Friday. What do you do?" | CASE | [generic] | Clarify (which devices, what failure, what rollback exists), then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully. Make no claim about your past. | Live problem from "partner with hardware and product on roadmap". Generic, because no source covers this fleet. |
| A5 | "Walk me through how that 60% reduction was counted." | EXP | [grounded] "my team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say what you can and cannot say about the count, in your own words. Name the weakest assumption before the interviewer does. Answer slot: if you measured the baseline, say how; if you did not, say so plainly, and say what you would measure first. | A figure you gave is a magnet. Do not explain a method you cannot repeat under a second question. |
| A6 | "How would you run hiring for eleven engineers?" | JD | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | Start from the loop you run, in those words. Then how you would extend it to hardware-adjacent roles, as a plan. | F2 is a strong fit: you should be the most fluent on this. |
| A7 | "Walk me through your background." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc from the quoted sentence: years, team lead, the loop, the reliability quarter, the gap. Do not add a role or title. | Conversational opener, scored. Low weight; have it ready. |

Requirement coverage (Round 1): "Lead two squads" F1, A1, A3; "own delivery" F3, A5; "for 11 engineers" F2, A6; "partner with hardware and product" F5, F6, A2, A4; growth F4 is covered only by Round 2 B7.

## Round 2: panel, two staff engineers and a product manager, Thu 26 Nov

Relationship prior: panel. Blend the top two personas of each member. Staff engineers: Data-Driven Prober and Peer Evaluator. Product manager: Peer Evaluator and Case/Strategist. Names are not known, so the weights are per role.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (top) | Staff engineers test the 60% figure and its baseline | High. Two staff engineers probe numbers by default | Name the weakest assumption; say plainly what you do not know |
| Peer Evaluator | Seams with the hardware and platform teams; disagreement with equals | High. Two peers and a PM on one panel | Propose seam principles, not invented detail; reciprocity |
| Case/Strategist (PM) | Roadmap trade-offs with product | Medium. A PM will want roadmap reasoning | Clarify, then trade-off with a stated cost |

Question bank (weighted: Prober 3, Peer 2, Case 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What was the on-call baseline you measured against?" | EXP | [grounded] "my team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Answer slot: if a baseline was measured, state it and how; if none was measured, say so plainly and say what you would use now. Never invent a baseline. | The premise of a baseline is not in your quote, so the second branch must allow there was none. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "my team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Name the weakest assumption in your own words first, before the panel does. Say what you can defend and what you cannot. Answer slot: which part of the drop was yours to do, and which was the team's. | Weakest-assumption move. Converts a gotcha into a credibility gain. |
| B3 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles (who owns the interface, how a change is agreed). Do not claim to know their seam. Selection scaffold: pick a time you disagreed with a peer team; if none comes to mind, say so, then give the nearest thing and how you would handle it. | Peer persona. Generic because no source names their seam. |
| B4 | "A hardware release runs on a longer cadence than product wants. How do you plan the roadmap?" | CASE | [generic] | Clarify the constraint, then sequence work that does not need hardware, then name what you would escalate and to whom. No past claim. | Live roadmap problem for the PM. |
| B5 | "Tell me about a time you pushed back on roadmap pressure." | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt, mapped to your quote. Beats the sentence states: the roadmap pressure, the reliability quarter, the push through. Answer slot: who set the pressure, and what you agreed with product; if you negotiated, say how; if not, say so. | F5, the partner-on-roadmap gap, rehearsed in your own words. |
| B6 | "What did the reliability quarter cost the roadmap?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you tracked what slipped, name it; if nothing was tracked, say so and what you would track. Never supply a cost you did not record. | A premised question. Its premise (a cost was tracked) is not in your quote. |
| B7 | "How do you grow senior engineers?" | JD | [generic] | Selection scaffold: pick someone you grew, and what you did; if no one comes to mind, say so, and say how you would start with eleven. | F4: your material shows no growth example. Do not invent one. |

Requirement coverage (Round 2): "partner with hardware and product" B4, B5; "growth for 11 engineers" B7; delivery B2, B6; "Lead two squads" covered only by A1 and A3.

## Round 3: VP Engineering, values and leadership philosophy, Mon 30 Nov

Relationship prior: skip-level and executive, with a values round. The recruiter's own words name this round as values and leadership philosophy, which is a loop source, so a values-style round is detected. Published company values are not in hand, so there is no values cheat sheet. Upgrade: send the values page, or name the values in an email.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (top) | Scenario on an unpopular truth; leadership philosophy | High. The recruiter named this round for it | STAR-shaped, "we" for context, "I" for your part |
| Pressure | "How much of that was actually you?" | High. Skip-level, time-boxed | Hold the claim you can back; concede the rest |
| Case/Strategist | Company strategy and three-year view | Medium. No research ran, so this is generic | Answer from principles, label it as such |

Question bank (weighted: Values 3, Pressure 2, Case 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt, mapped to your quote. The unpopular truth is the reliability case; beats are the roadmap pressure and the push through. Answer slot: what leadership said or did in response, in your words; if you cannot name it, say so. | Your strongest values story. Pick it and do not swap in another you did not have. |
| C2 | "What is your leadership philosophy, in one paragraph?" | VAL | [generic] | Build from your own quotes: the loop you run, the team of six, the push on reliability. Do not claim a principle you have not shown. | Recruiter named this round for it. |
| C3 | "Sixty seconds: why would you lead a hardware-adjacent roadmap you've never owned?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Hold: "I haven't owned one." Then the plan to learn it and the trade-off you would accept. Concede once, specifically. | F6 at the VP's altitude. Your stated negative is the only acknowledgment you need. |
| C4 | "That result: how much of it was actually you?" | VAL | [grounded] "after I pushed a reliability quarter through" (your message) | Hold: your part was pushing the quarter through. Concede what you cannot claim (the team's share). Answer slot: what you did specifically, and what the team did. | Pressure stem. Hold-then-concede. |
| C5 | "How would you think about where device management should be in three years?" | CO | [generic] | Strategy not researched, so answer from general principles and label it as such. Do not claim knowledge of Larkfield's plan. | Strategy is not in hand; the upgrade menu says what would fix it. |
| C6 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. If none comes to mind, say so, then give the nearest thing your material carries, which is the reliability quarter, and how you would handle it. | No customer story in your material. Do not invent one. |
| C7 | "A customer's devices drop offline after a firmware push. Hardware says radio; product wants it shipped. What is your call in the first hour?" | CASE | [generic] | Clarify, then contain (stop the rollout), then decide who to bring in. No past claim. | Live problem for a VP. |

Requirement coverage (Round 3): values/leadership C1, C2, C6; "partner with hardware" C3, C7; company strategy C5 (generic, see upgrade menu).

## Reverse questions (all rounds)

Each has a "why it lands". At least five, with one reciprocity question for the peer panel.

1. (Round 1) "What would make someone successful in the first 90 days?" Why it lands: lets you map your plan to their expectation before you give one.
2. (Round 1) "How does the hardware team sit relative to the two squads today?" Why it lands: tests the seam before the panel.
3. (Round 2, reciprocity) "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: turns a peer conversation into shared work, and it is the reciprocity question a peer panel expects.
4. (Round 2) "When hardware and product disagree on the roadmap, who decides, and how often does that happen?" Why it lands: shows you understand the partnership is where the role is hard.
5. (Round 3) "Which decision in the last year best showed the leadership you want in this role?" Why it lands: the answer tells you what the VP is scoring for.
6. (Round 3) "What is one thing the VP wants this role to change in the next six months?" Why it lands: gives you the priority to build the 90-day answer around.

A reverse question tied to the interviewer's own path needs their name and profile. Upgrade menu.

## Delivery coaching

Dropped: no working-style assessment was provided.

## Sources

- Your message (role summary, your background, the three round descriptions, and the recruiter's words for round three).
- Research: L1 tier. Searches attempted: 3 of 6. Results: 0 (all refused for permission).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10): would name the published values. Refused. Without it, round three has no values map |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure: round names and any values round. Round weights rest on your descriptions and the recruiter's words, not on a documented loop. Refused |
| 3. Larkfield Systems strategy / recent news | unavailable | CO bank (C5) and any strategy-grounded question. Refused |
| 4. Interviewer name and company | n/a | No name was given. Upgrade menu says what a name would unlock |
| 5. Representative engineering manager JD | unavailable | Would have grounded fit rows F4 and F7 in a typical posting. Refused. No search was run for it |

Queries sent (all refused): "Larkfield Systems values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT device management strategy".

## Upgrade menu

- The full posting text (or the recruiter's email) → converts F1 to F7 from [generic] or summary to [grounded] quotes, and sets the gate rows.
- Permission to run web search → the values page, loop detail and strategy: unlocks a values cheat sheet, a grounded CO bank (C5), and fixes the round weights.
- The interviewer's name for round one → a tailored reverse question and persona weights from their public footprint.
- The panel members' names, or their roles → per-person persona assignment within round two.
- The recruiter's description of round three → a confirmed values list, which unlocks the cheat sheet.
- Where you led two squads or the group in your own terms → F1 becomes a sized grounded row, instead of a slot.
- A list of the on-call numbers (baseline, window, count) → A5 and B1 answer from your data rather than a slot.
