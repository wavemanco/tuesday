# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Prepared for:** Dara
**Rounds (29 November 2026), built in loop mode:**
1. Recruiter screen, 30 min. Recruiter (name not given).
2. Behavioural round, 45 min. Head of Member Services, your future manager (name not given).
3. Panel, 60 min, including a 20-minute complaint-escalation case. Two branch managers (names not given). The panel is also the values round.

Structure: one shared fit snapshot and sources block, then a mini-pack per round. The prohibited list and the fit snapshot apply to all three rounds. This is the first pass, so there is no changelog.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural and values alignment. EXP = deep-dive on your own work. JD = the role's listed requirements. CO = company and strategy knowledge. CASE = a live problem.
- **Provenance** on each question shows the sentences of yours its guidance rests on. `[grounded]` means traceable to a document or to what you told me. `[inferred]` means derived. `[generic]` means a pattern with no claim about you.
- **Answer slots** are instructions for the interview, not questions to me. Where your material is silent, the guidance gives you two honest branches and never supplies the missing event.
- Guidance is scaffolding, not a script.

## Fit snapshot (shared across rounds)

Your sentences are quoted exactly. Sources: "your message" is your background note, and "JD" is the job description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows the branch log, not the whole process, and nothing about the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: the end-to-end line makes a probe on the stages after the log likely. If you ran any stage beyond the log, say which and how you decided, in your own words. If the log was the whole of your part, say so and stay with it. |
| F2 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The sentence shows a monthly complaints report, not which measures it holds. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say which and how you counted. If not, say so and say what you would add first. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the supervisor-coaching line makes a probe on your own coaching of supervisors likely. If you coached another supervisor's escalation decisions, say what you did. If not, say so plainly and say how the teller training would carry over. |
| F4 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. This is not a stated absence. Answer slot: if you have worked with a team on a customer-facing journey, say what your part was. If you have not, say so plainly and say how you would start. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Say the years and the branch role as you wrote them. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints. It does not say whether they ran under external rules or timescales. Answer slot: the JD's word "regulated" makes a probe likely. If the log followed rules or timescales set outside the branch, say which and how you tracked them. If it did not, or you cannot say, say so plainly and stay with the log. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would prepare for that audience, said as a plan and never as a past. Nothing added to make the gap smaller. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The sentence already reaches reporting in other terms. Reword only: "I built the monthly complaints spreadsheet our regional manager uses." Do not name formulas, pivots or macros unless you used them. |

Gate check: no JD requirement is a gate under the evidence rules (a term such as authorisation, licence, location, schedule, pay or credential). So there are no gate rows.

## Prohibited claims (not coached in any round)

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end" | Inflated form of F1 | "I handled the branch's formal complaints log." Limit, as the pack's own observation: your material says the log, not the process. |
| "I coached branch supervisors on escalations" | Inflated form of F3 | "I trained new tellers on our escalation script." |
| "I reported monthly on complaint volumes and resolution times" | Inflated form of F2 | "I built the monthly complaints spreadsheet our regional manager uses." Limit, as observation: your material does not say what the sheet measures. |
| "I handled regulated complaints" | Inflated form of F6 | "I handled the branch's formal complaints log." |
| "I have presented to senior leaders" | Negative you stated (F7) | Plain acknowledgment only: "I've never presented to anyone above regional level." No answer slot. |
| "I have worked in a contact centre" | Negative you stated | Plain acknowledgment only: "I've never worked in a contact centre." No answer slot. |

## Sources

**Provided documents:** the JD you pasted; the values you pasted from ashgrovecu.org/about/values (copied 20 November 2026); the recruiter's email on the process; the July 2026 strategy brief as you summarised it; and your background note.

**Loop source:** the recruiter's email establishes the loop. It names three rounds, who runs each, and that the panel scores against the four values. So a values-style round is detected, and it is the panel.

**Research tier: L1 — searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Fixed by the values page you pasted. Values cheat sheet in round 3. |
| 2. Ashgrove interview process | skipped | Fixed by the recruiter's email (three named rounds, panel scoring values). |
| 3. Ashgrove strategy | skipped | Fixed by the July 2026 brief you summarised, four months old. Grounding for round 2 and the panel case. |
| 4. Interviewer footprint | n/a | No names given, so no query could be formed. |
| 5. Representative JD | skipped | JD supplied. |

## Round 1: Recruiter screen (30 min)

**Persona weights**

| Persona | Depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | 5 (top) | Open biography, motivation and logistics in a friendly register | High. Recruiter-screen prior, and the recruiter's own email frames this round as a screen with logistics checks. Casual questions are still scored. | A 90-second arc. Logistics answers ready in your own words. |
| Skeptic (light) | 3 | Reason for leaving, the contact-centre gap, the presenting gap | Medium. F1 (contact centre) and F7 (presenting) are the first gaps a screen probes. | Plain acknowledgment, then a plan. |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc in your own words: six years in retail banking, three as a branch supervisor, then the complaints log and the teller training. The spreadsheet is the last beat. Add no beats. | Opening claim. F5 and F1 carry it. EXP because it is the first claim the panel will test. |
| R1-2 | "Why this role, and why now?" | JD | [generic] | Answer slot: give your reason in your own words. Your material gives none, so keep to what you know to be true. | Motivation is a screen's first scored answer, and nothing in your material answers it. |
| R1-3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | The recruiter named notice as one of four logistics checks. |
| R1-4 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role sits in before you name one. No figure is supplied here. | Pay is a logistics check the recruiter will ask. |
| R1-5 | "Where can you work, and how often?" | JD | [generic] | Logistics slot: say your own answer. The JD spans branches and the contact centre, so ask which site or hub the role sits in before you commit. | Location is a logistics check, and the JD's scope makes the site question real. |
| R1-6 | "Why are you leaving your branch role?" | EXP | [generic] | Logistics slot: give your own reason in your own words. Your material gives none. Keep it forward-looking. | Reason for leaving is a logistics check, and the Skeptic persona uses it to test motivation. |
| R1-7 | "You've never worked in a contact centre. How do you run a role that covers one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan. Do not describe any contact-centre work. | F1's contact-centre half is the likeliest screen objection. |
| R1-8 | "The JD asks for confident presenting to senior leaders. What's your experience there?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan for how you would prepare. This is the screen-level version of R2-B1. | F7 is a capability gap you stated. Rehearse the honest form now. |

**Reverse questions**
- "Which of the three rounds are you weighing most when you decide?" Why it lands: tells you what to prepare hardest for, and is a question a recruiter can answer.
- "What is the next step after the panel, and how long does it usually take?" Why it lands: shows you plan past the interview and are not guessing at timing.

## Round 2: Behavioural round with the Head of Member Services (45 min)

**Persona weights**

| Persona | Depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / behavioural | 4 (top) | Behavioural stories tested against the values | High. The recruiter says this round is mostly behavioural, and your future manager runs it. | Story-map from your quoted sentences. Use a selection scaffold with its honest branch where none carries a story. |
| Skeptic | 3 (top) | The presenting gap, the end-to-end line, the spreadsheet | High. Hiring-manager prior, plus F1, F2 and F7. The most predictable objection is F7. | Rehearse B1 until it is boring. Hold, then concede specifically. |
| Case / strategist | 2 | Digital shift and hub consolidation | Medium. A manager whose area is changing will test strategy fluency. | Structure first. Use the brief's own words. |
| Data-driven prober | 2 | What the spreadsheet counted, and which assumption you would defend least | Medium. The spreadsheet is your only quoted claim with a figure behind it. | Name the weakest assumption before they do. Say plainly if you do not know how it was counted. |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time a member needed something explained more than once." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Story-map from the log: the complaints you handled are the setting. Selection scaffold: pick a complaint where an explanation had to be given again. If none comes to mind, say so plainly, then give the nearest complaint from the log and what you did, in your own words. | Plain Words is the value this tests. F1 is the setting, not the story. |
| R2-A2 | "When did you choose the member's side over a process step?" | VAL | [generic] | Selection scaffold: pick a decision where the member's position counted against the process. If none comes to mind, say so plainly and name the nearest step you did follow, and why. | Members First. A pattern, not a claim about you. |
| R2-A3 | "Tell me about a problem you found that was not yours, and that you kept until it was solved." | VAL | [generic] | Selection scaffold: pick a problem you found and kept hold of. If it was handed on, say so and say who held it after you. | Own the Fix. |
| R2-A4 | "When has a local branch detail changed how you handled something?" | VAL | [generic] | Selection scaffold: pick a case where the branch's local setting mattered. If none, say so plainly. | Neighbours, Not Numbers. Your material shows no town story, so the honest branch is likely. |
| R2-B1 | "You've never presented to anyone above regional level. What would you do the first time you presented to a senior leadership group?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | The highest-ROI rehearsal in this pack. Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare, who you would test a draft with, what you would ask a senior colleague to check. Hold through two follow-ups by returning to the plan. Concede specifically: say which part you are least sure of, and do not fold on the plan. | F7 is the objection most likely to come up in some form. The JD's presenting line makes the premise fair. |
| R2-B2 | "The JD asks you to own the process end to end. Which part of it is yours today?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: for the log, say how you handled it, in your own words. If you ran any stage beyond the log, say which and how you decided. If the log was the whole of your part, say so plainly and stay with it. | F1. The end-to-end line is the JD's own, so the probe is fair. |
| R2-B3 | "You trained tellers on the escalation script. Have you ever coached a supervisor on one?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you coached another supervisor's escalation decisions, say what you did. If not, say so plainly and say how the teller training carries over to supervisors. | F3. The supervisor-coaching line is the JD's. |
| R2-C1 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What does that change in complaints work?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as you summarised it) | Use the brief's words: digital channels, member service. Say what it changes for complaints in this order: where complaints arrive, what the member sees, what gets measured. Claim no digital experience. | Grounding brief. Sounds current, not archival. |
| R2-C2 | "Eight branches become five hubs over 2027. A complaint opens at one branch and closes in a hub. How do you stop it going round in circles?" | CASE | [generic] | Structure first: who owns the file on the change date, what the member is told, what is recorded, and how you would check it closed. Do not claim any past hub work. | The hub consolidation is the brief's own change, and a manager whose area is changing will test it. |
| R2-D1 | "What does your monthly complaints spreadsheet count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if it counted volumes or resolution times, say which and how you counted. If not, say so plainly and say what you would add first. | F2. Defend the number in your own words. |
| R2-D2 | "Which assumption behind that sheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name the assumption you would defend least, in your own words, before they do. If you cannot name one, say so plainly. | Weakest-assumption move. Your material holds no assumption, so the slot stays open. |

**Reverse questions**
- "What does the first 90 days look like, and what would you want me to have fixed by then?" Why it lands: separates a real expectation from a generic one.
- "Which of the 2027 hub changes would this role own?" Why it lands: the end-to-end complaints remit depends on hub design.
- "What is the hardest complaint type the team handles today?" Why it lands: shows you are thinking about the work, not the title.

## Round 3: Panel, two branch managers (60 min, including a 20-min case)

This round is the values round. The recruiter says the panel scores each candidate against the four values, so the values cheat sheet lives here.

**Values cheat sheet**

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F1: "I handled the branch's formal complaints log" (your message). The log shows the handling, not a member-side decision. Selection scaffold: pick a complaint decision you made for a member. If none comes to mind, say so plainly and give the nearest log case. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | F3: "trained new tellers on our escalation script" (your message). Selection scaffold: pick the script you taught and say what made it clear to a teller on first hearing. If you did not test that, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries a town story. Selection scaffold: pick a case where your branch's local setting mattered. If none comes to mind, say so plainly. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F1: "I handled the branch's formal complaints log" (your message). Selection scaffold: pick a problem you found and kept until it was solved. If it passed to someone else, say so and who. |

**Persona weights**

| Persona | Depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / behavioural | 4 (top) | Scored against each of the four values | High. The recruiter says the panel scores the values. | Map each value to a quoted sentence where one carries a story. Otherwise a selection scaffold with its honest branch. |
| Case / strategist | 3 | The 20-minute complaint-escalation case, and the digital shift | High. The recruiter named the case, and it is scored. Blend: the panel's top two personas are values and case. | Clarify, then the member's outcome first, then one owner, then the plain-words update. |
| Pressure | 3 | Time-boxed challenges on the gaps | Medium. Branch managers test composure, and the gaps F1, F7 are the ones they will press. | Pause, restate, hold through two follow-ups, concede specifically. |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "Tell me about a time you decided a complaint from the member's side when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold, from the log. If no such decision comes to mind, say so plainly and name the nearest case you handled, in your own words. | Members First. F1 is the setting. |
| P-A2 | "Tell me about an explanation that didn't land the first time." | VAL | [generic] | Selection scaffold: pick a case where an explanation did not land. If none, say so plainly. | Plain Words. |
| P-A3 | "Tell me about a time a branch's local situation changed how you handled a case." | VAL | [generic] | Selection scaffold: pick a case where the local setting mattered. If none, say so plainly. | Neighbours, Not Numbers. |
| P-A4 | "Tell me about a problem you found and kept until it was solved." | VAL | [generic] | Selection scaffold: pick a problem you kept hold of. If it passed to someone else, say so and who. | Own the Fix. |
| P-C1 | "A member complained at a branch, got no answer, and escalated to the contact centre. The branch says it's closed; the member says it isn't. You have 20 minutes. Talk us through it." | CASE | [generic] | A rehearsal case modelled on the escalation the recruiter named; the panel's own case will differ. Frame in 90 seconds: clarify the facts, put the member's outcome first, name one owner, give the member a plain-words update, record what happened, and note what the branch supervisor should learn. Do not promise a remedy you cannot authorise. | Clarify, objective, approach, risks, time-boxed. |
| P-C2 | "Forty per cent of member service moves to digital by 2028. A member complains that an app flow sent them the wrong letter. What do you do?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as you summarised it) | Structure: what the member needs now, who fixes the flow, how the complaint is recorded, and what the digital team learns from it. Claim no digital experience. | Live problem from the brief's own change. |
| P-C3 | "How would you know if the digital move is making complaints worse?" | CO | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Name the two measures the JD lists and one channel split, and say which you would look at first. Add no figures. | Uses the JD's measures and the brief's change together. |
| P-P1 | "Sixty seconds: why would we trust a complaints lead who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then your first 30 days as a plan. Hold through two follow-ups; concede specifically; do not bluff. | Pressure on F1's contact-centre half. |
| P-P2 | "You've never presented above regional level. Why would the panel put you in front of senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan for preparing. Hold, then concede the part you are least sure of. | F7, under pressure. |
| P-P3 | "That complaints spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold the sentence as written: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it counted and which part was your call. If anyone else shaped it, say so too. | F2 and F8, the attribution probe. |

**Reverse questions**
- "What do you see as the most common reason a complaint comes back to a branch?" Why it lands: gives you the branch-side view of escalations.
- "Which part of the escalation process do the branches find slowest?" Why it lands: shows you want the branch's pain, not only the policy.
- "What would you want this role to protect first for your members?" Why it lands: a values question back, tied to Neighbours, Not Numbers.

## Prep priority

Prep time before 29 November was not given, so no prioritised schedule. If you tell me how many hours you have, I will add one.

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → an interviewer read, persona weights per member, and tailored reverse questions.
- The complaints spreadsheet's column headings, or a list of what it measures → F2 moves from discovery to presentation, and R2-D1, R2-D2 and P-P3 get real answers.
- The escalation script you trained tellers on, if you can share its wording → sharper Plain Words and F3 answers.
- The full strategy brief (not your summary) → exact wording for the grounding brief and the digital and hub questions.
- The recruiter's case brief, if one exists → P-C1 and P-C2 become the panel's real case, not a rehearsal.
- Prep hours available before 29 November → a prioritised schedule.
- A deeper research pass (optional): up to 6 more searches and 2 more fetches, several minutes. It would cover the interviewer footprint (needs names), role-family loop reports (forum sources labelled `[inferred]`), and recent organisational context around the 2027 hub changes. Say the word if you want it.
- A `tuesday-dossier.md` from an earlier job-underwriting run would add verified-evidence grades and absolute prohibited-claim guardrails. None is present.
