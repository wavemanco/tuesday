# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (regional logistics, ~800 employees, 4 sites)
**Interviewer:** not named. Built for a hiring-manager round, the most likely round at this level. Round type and relationship are unconfirmed, so persona weights are provisional.
**Research:** none. Every web search was refused (permission not granted), so no company facts are in this pack. Everything about Atlas Freight below is `[generic]` or from the JD you pasted.

## How to use this pack

- **Personas** are how a question is asked (rapport, challenge, pressure, live problem). **Types** are what is being scored: JD (can you do the listed job), EXP (what you actually did), CASE (live problem), CO (company knowledge; none here, no research), VAL (values; none detected).
- Guidance is scaffolding for a spoken answer, not a script. Say only what you did, in your own words.

## Fit snapshot

Your words are quoted exactly from your message. Gap types: `transferability` = adjacent work that doesn't reach the requirement; `presentation` = real evidence not framed for the role; `capability` = you stated the absence; `discovery` = evidence may exist and isn't shown.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows operations work at one shift scope, not four sites. Bridge: "I have seven years in warehouse and distribution operations, and I run a shift over three supervisors." Answer slot: if you have overseen more than one site or a multi-site plan, say how; if not, say so and say how you would set daily priorities across four sites. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Bridge: "I'm a senior shift manager over three supervisors." Answer slot: if you have led a group larger than three, say how; if not, say so and say how you would structure twelve supervisors. |
| F3 | "5+ years operations leadership required" (JD; a length requirement, not a gate) | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | Seven years of operations does not show how many were in a lead role. Answer slot: say how many of those years you led people, in your own words; if fewer than five, lead with the operations scope you did have. |
| F4 | "drive on-time performance ... down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your result is mis-pick accuracy, not on-time performance. Bridge: "I cut the mis-pick rate by 40% by redesigning the pick path." Answer slot: if you have moved an on-time measure, name it and how it was counted; if not, say so and say how you would approach it. |
| F5 | "drive ... cost-per-shipment down" (JD) | none given | none | — | discovery | Your material says nothing about cost per unit. Answer slot: if you have moved a cost-per-unit measure, name it and how it was counted; if not, say so and say what you would measure first. |
| F6 | "build reporting in Excel" (JD) | "solid Excel" — your message | medium | [grounded] | presentation | Your material says Excel skill, not reporting you built. Bridge: "I'm solid in Excel." Answer slot: name a report you produced in Excel, what it fed, and who acted on it; if you have not built one, say so. |
| F7 | "build reporting in ... Power BI" (JD) | "never used Power BI" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, as a plan, never as a past. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" — your message | medium | [grounded] | none | Quote reaches the requirement. Expect a probe on what the belt was used for; certificate or project record would make it inspectable. |

**Gate check:** no JD requirement is a gate (no licence, location, schedule or pay term). F3 is a length requirement, graded on fit.

## Prohibited claims

Each entry is an assertion this pack will not coach, with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across four sites | Inflated form of F1 | "I run a shift over three supervisors." Your material says one shift, not four sites. |
| Led a team of twelve supervisors | Inflated form of F2 | "a senior shift manager over 3 supervisors" |
| Built Power BI dashboards or reporting | Stated negative, F7 | "I haven't used Power BI." No slot. |
| Drove on-time performance or cost-per-shipment down | Inflated form of F4 | Your material says mis-pick rate. Name the measure you moved, if any. |
| Led the pick-path redesign | Inflated form of "redesigning the pick path" | "redesigning the pick path," at that scope. Say which decisions were yours. |
| Set the peak-season plan | Inflated form of "ran the site's peak-season surge plan" | "ran the site's peak-season surge plan two years running," at that scope. |

## Persona table

Weights are provisional. The hiring-manager prior is applied: Case and Skeptic weigh most, because a hiring manager buys capability and checks gaps.

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Quietly tests the 3-to-12 and four-site gaps | High: F1, F2, F3 are the largest gaps against the JD | Rehearse A1 until it is plain. Name the three honestly. |
| Case / Strategist | Live ops problems: on-time drop, cost rise | High: JD asks for on-time and cost-per-shipment, which a hiring manager tests with a live problem | Clarify, then structure, then metrics. Say the assumptions aloud. |
| Data-Driven Prober | Asks how the 40% was counted | Medium-high: F4 is the only headline number in your material | Name the weakest assumption before they do. Say "I don't know" where true. |
| Pressure | Time-boxed challenge on the 40% or on 3 supervisors | Medium | Hold through two follow-ups, then concede the specific gap. |
| Conversational | Opens with "walk me through the last seven years" | Medium: a common opener, and the answer is scored | 90-second arc, using only quoted sentences. |

## Question banks

Questions are the interviewer's line. Provenance carries each quoted sentence the guidance rests on.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. This role has twelve. What's the gap, and how would you close it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Name the three as your sentence states them. Answer slot: if you have led more than three supervisors, say how; if not, say so and say how you would structure twelve. Keep to the three you have. **Highest-ROI prep in this pack.** | F2 is the largest gap against the lead-12 requirement. The objection will come in some form; the honest answer is rehearsed before it lands. |
| A2 | "Five years of operations leadership is the bar. How many of your years have been in a lead role?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message | Give the count in your own words, from the first year you led people. Answer slot: if fewer than five, say so and lead with the operations scope. | F3 is a discovery gap; the count is yours to give, not the pack's. |
| A3 | "This role runs daily operations across four sites. What's your experience running more than one?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message | Describe the scope you have run. Answer slot: if you have overseen more than one site, say how; if not, say so and say how you would set daily priorities across four. | F1 is transferability. The four-site scope is the JD's own line. |
| A4 | "You've held a shift over three supervisors. What would change at four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Name what you have done at shift level. Answer slot: say what you would change first, as a plan. | Pressure on F1 and F2 together. |
| A5 | "What's the hardest part of this role for someone coming from a single shift?" | JD | [generic] | Structure: the cross-site view, the people span, the reporting. Say which you have had to learn before, in your own words. | An open version of A1 and A3; [generic] because it asks about the role. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one terminal dropped two weeks running. Where do you start?" | CASE | [generic] | Clarify: which lanes, which shifts, what changed. Split volume, labour, equipment and cut-off. Decide what data you need first. | JD on-time line; a live problem with no claim about your past. |
| B2 | "Cost per shipment has risen for two months. Diagnose it, and say what you'd change in week one." | CASE | [generic] | Clarify how shipments are counted before any driver. Then drivers, then a week-one action you could defend. | JD cost-per-shipment line; the denominator question is the scored move. |
| B3 | "Four sites, four shift patterns. How do you run one daily standard across them?" | CASE | [generic] | Structure: standard, measure, owner per site. Say the trade-off between a common standard and local fit. | The four-site scope from the JD. |
| B4 | "Peak arrives and you're short on labour at two sites. What do you do Monday?" | CASE | [generic] | Triage by service impact, then labour moves, then a daily check. | Live problem; it tests the peak-season thinking, which F1's quote does not directly show. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 40% mis-pick reduction, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Say what you counted and over what period, in the sentence's words. Name the assumption you would defend least before they do. Answer slot: if you have the baseline and measure, say them; if you don't know how it was counted, say so. | F4 is the only headline number. Defend-the-number slot. |
| C2 | "Which report have you produced in Excel, and who acted on it?" | EXP | [grounded] "solid Excel" — your message | Name the report, what it fed, who used it, in your own words. Answer slot: if you have not built one, say so and say which Excel skill you would apply first to a dashboard. | F6 is presentation; the JD asks for reporting, not just skill. |
| C3 | "You haven't used Power BI. How would you build the operations dashboard in your first 90 days?" | JD | [grounded] "never used Power BI" — your message | Say "I haven't used Power BI." Then the plan as a plan: learn on data you already have in Excel, and what you would deliver first. Claim no past dashboard. | F7 is a stated capability gap; the plan is the honest answer. |
| C4 | "Tell me about your Green Belt. What did you use it on?" | EXP | [grounded] "green belt certified" — your message | Say the certification in the sentence's words. Answer slot: if you ran a project under it, name it and its measure; if you did not, say so. | F8 is a medium-confidence claim; the probe is expected. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Pause, restate. Name your part in your own words. Answer slot: if the redesign was the team's, say so and describe your part. Hold through two follow-ups, then concede any part you cannot back. | Honest attribution under pressure. |
| D2 | "Three supervisors. Why would twelve be any different?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Hold the quoted scope. Concede the specific step you have not taken. Answer slot: say how you would structure the twelve, as a plan. | F2 under challenge. |
| D3 | "Sixty seconds: why you over someone who has run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message | Anchor in what you stated: seven years, the pick path, the peak plan. Concede the four-site gap in your own words, then the plan. | Pressure on F1; the hold is the quoted record, not a larger one. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the last seven years." | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | 90-second arc: scope, what you run now, the 40%, the peak plan. Use only quoted sentences. | Opener is scored; a clean arc is the signal. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" — your message | Say "I haven't used it," then your learning plan. Treat as scored. | F7 in casual form. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A3, A4, B3, D3 |
| Drive on-time performance and cost-per-shipment down | B1, B2, F4 via D1 |
| Lead a team of 12 supervisors | A1, D2 |
| Build reporting in Excel / Power BI | C2, C3, E2 |
| 5+ years operations leadership | A2 |
| Lean / Six Sigma a plus | C4 |

## Reverse questions

1. "What does success look like at six months, and which of the four sites is hardest right now?" *Why it lands:* it shows you have already located the four-site gap and want to start there.
2. "How are on-time and cost-per-shipment measured today, and who owns the numbers?" *Why it lands:* it tests the denominator, which the role depends on.
3. "What reporting exists now, and is Power BI in use here?" *Why it lands:* it shows you plan to build on what exists.
4. "How are the supervisors structured across the four sites?" *Why it lands:* it tests the team-of-twelve shape directly.
5. "What would help a new person be useful in the first month?" *Why it lands:* it signals that you plan to contribute, not just observe.

## Sources

Provided documents: your message (the JD and your background, pasted in the request). No CV or dossier was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; all 3 calls refused (web search permission not granted)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet, section 10: no values round is detected, and the search was refused. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure; the persona weights are provisional for this reason. |
| 3. `Atlas Freight logistics strategy news` | unavailable | CO bank: no company strategy questions, so the CO type has no entries. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given. |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Refused calls: `Atlas Freight regional logistics company values`; `Atlas Freight interview process operations manager`; `Atlas Freight logistics strategy news`.

## Upgrade menu

- The interviewer's name and title → personalized persona weights and a tailored reverse question. (Research would also have been possible with web search permission.)
- The round format from the recruiter → whether a presentation, case or take-home is announced, and the matching section.
- Web search permission → company values, interview process and recent news, so the pack can carry `[grounded]` company facts and a values sheet.
- A certificate or project record for the Green Belt → F8 becomes inspectable.
- Power BI learning from now → F7 becomes a demonstrable plan, with a sample dashboard you built.
