# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship not yet stated, so persona weights use hiring-manager priors. Round: final, 60 minutes.

## How to use

Personas are how a question is asked. Types are what it scores:

- **EXP**: work-experience deep-dive. Tests whether what you did survives scrutiny.
- **JD**: role and job-description driven. Tests whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge. Not covered here; no research ran.
- **CASE**: live problem, built on the role. Tests structure and reasoning.
- **VAL**: behavioural and values. Not detected in this round.

Guidance is scaffolding, not a script. Speak each answer in your own words.

## Fit snapshot

Requirements are quoted from the job description. Evidence is quoted from your message; no CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, for two years. It does not say two titles or live events. Say it in those words. Answer slot: if you planned for a second title or set events beyond the content drops, say what and how you decided; if not, say so and stay with the one calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show cross-team coordination. Answer slot: if you coordinated design, art, engineering or community on any release, say which teams and what you did; if you did not, say so and say how you would run the first update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Your material says the monthly retention numbers were presented. It does not show a post-event review. Words: "Presented the monthly retention numbers to the studio head." Answer slot: if you wrote or owned a review after an event, say so and what it covered; if not, say what you did present. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Rewords only the quote: "I wrote the release checklist our QA team still uses." Do not say you managed QA's sign-off; your material does not show that. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years and role meet the requirement. Your material does not say the studio's game was live-service. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if your title ran live in a way you can describe beyond the weekly drops, say how; if not, say what carries over. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the figure was counted. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A document in use shows writing, not clarity. Answer slot: if you can point to a written artifact you are proud of, name it and say what made it clear; if not, say so and offer to write one in the room. |
| F9 | Not a JD line; your stated gap | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." No slot. Do not describe leadership you did not do. |
| F10 | Not a JD line; your stated gap | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. |

Gate rows: none. The job description states no location, schedule, pay or credential term, and your message raises none.

## Prohibited claims

Claims this pack will not coach. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar across two titles or live events | Inflated form of F1 | F1's quote at its own scope. Your material says one title's weekly content drops. |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote. The material says presented, not owned. |
| Managed QA's release sign-off | Inflated form of F4 | F4's quote: "I wrote the release checklist our QA team still uses." |
| Set or owned the retention targets | Inflated form of F7 | F7's quote: presented. |
| Led a team | Stated negative, F9 | "I haven't led a team." No slot. |
| Worked on an in-app purchase game | Stated negative, F10 | "I haven't worked on a game with in-app purchases." No slot. |

Coordinating design, art, engineering and community is not listed. Your material is silent on it, so it is an answer slot (F2), not a prohibited claim.

## Persona table

No values round was detected and no interviewer footprint was available, so persona weights use the prior for a hiring-manager round, adjusted by the JD's live-operations focus.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | Live calendar and retention problems | High. A final round for a Head of Live Operations role, and the JD is made of live problems. | Clarify, then structure, then name one risk. Think aloud. |
| Data-Driven Prober (weight 4) | Walks through the retention figure and the calendar | High. Your message presents a retention figure to a studio head, and probers go to figures like that. | Know what you can say about how each figure was counted. Say plainly when you do not know. Name the weakest assumption first. |
| Skeptic (weight 3) | Leadership, in-app purchases, puzzle game versus live service | High. Both negatives in your message are visible to anyone reading it. | Say the gap in one plain sentence, then the plan. Do not bluff. |
| Pressure / Stress (weight 2) | Interrupts and time-boxes, in the close | Medium. Final-round prior at this level. | Pause, restate, hold a position through two follow-ups, then concede the specific uncertainty. |
| Peer Evaluator (weight 2) | Seams with community, design and engineering | Medium. The JD names four other teams. | Propose seam principles, not facts about their team. Name the credit first. |
| Conversational / Rapport (weight 2) | Warm opener and the journey question | Medium. Casual questions are still scored. | A 90-second arc. Stop at each quoted fact. |

## Question banks

Coverage across the banks is 18 questions. Each row has its provenance, answer guidance and rationale.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the next six weeks of events for one of our titles. What do you need to know first?" | JD / CASE | [generic] | Clarify first: current retention, monetisation model, what the team already has in flight. Then objective, segments, approach, metrics, one risk. Think aloud. | Covers R1 (plan and run the calendar). A live problem; it asks about no past. |
| C2 | "Day-seven retention fell after last month's event. Diagnose it." | JD / CASE | [generic] | Split the cause: did the event change, did the audience change, or did something outside the game change? Name the metric definition before you use it. | Covers R7 (retention metrics) as a live problem. |
| C3 | "A build goes out Tuesday and QA flags a crash on an event's reward screen. What happens next?" | JD / CASE | [generic] | Walk the release decision: severity, who can hold the release, what the checklist says. | Covers R4 (release checklist with QA). F4 is the nearest rehearsal. |
| C4 | "After an event ends, what's the first number you look at, and what would make you call it a miss?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name one primary KPI and the threshold that would count as a miss. Say why it comes first. Do not invent a baseline for their titles. | Covers R3. A method question; it makes no claim about you. |
| C5 | "Write me the three-line status update you'd send the team after an event fails." | JD | [grounded] "clear written communication" (JD) | Lead with what happened and the number, then the cause as far as you know it, then the next step with an owner and a date. Write it short, in the room. | Covers R8. Tests the written-communication requirement directly. F8 is discovery, so this is where that gap shows. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that retention figure you presented was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend the number in your own words. Answer slot: if you know how it was counted, say it; if you did not work that out yourself, or it was not yours, say so plainly and say what you would check first. | F7. Premised only on the quote. |
| P2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name your weakest assumption before they do. If you did not know the assumptions behind it, say that plainly. | F7. Weakest-assumption move, as a defend-the-number slot. |
| P3 | "Tell me about the calendar you ran. What did you decide, and what came from above you?" | JD / EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Give the beats the sentence states: one main title, weekly, two years. Answer slot: if any part was yours to set (order, cadence, scope), say which and how you decided; if it was set above you, say so and describe how you ran it. | F1 and F6. Covers R1 and R6. |
| P4 | "Your checklist is still in use. How do you know QA follows it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say what the sentence carries: the checklist is still in use. Answer slot: if you have a way of knowing QA follows it, such as a sign-off or a review, say it; if you do not, say so and say how you would check. | F4. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team. How would you coordinate design, art, engineering and community on an update when none of them report to you?" | JD / Skeptic | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | **The highest-ROI prep in this pack.** Say it plainly: "I haven't led a team." Then the mechanism you would use, as a plan. Answer slot: if you coordinated a multi-discipline update, say which teams and what you decided; if you did not, say so and describe how you would run the first one. Hold through two follow-ups by returning to what you would do, not to a title. | F2 (discovery) and F9 (capability). Covers R2. The deepest rehearsal, because this question is the likeliest one to be asked in some form. |
| S2 | "You haven't worked on a game with in-app purchases. What would you need to learn first?" | Skeptic | [grounded] "never worked on a game with in-app purchases" (your message) | Acknowledge: "I haven't worked on a game with in-app purchases." Then the learning plan: what data you would need, who you would ask. Do not describe monetisation work you did not do. | F10. A plain acknowledgment with its source. |
| S3 | "Your background is a puzzle game. Why is that the same job as live service?" | JD / Skeptic | [grounded] "3+ years producing live-service games or apps" (JD); "4 years as an associate producer at a puzzle-game studio" (your message) | Say what the puzzle title did live: the weekly content drops, in those words. Answer slot: if the title's live operations went further than the drops, say how; if not, say what carries over and what does not. | F5. Covers R5. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why should we trust a puzzle-game producer to run two titles?" | Pressure / JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold-then-concede. Hold the calendar record in those words through two follow-ups. Concede specifically: "I haven't led a team," and "I haven't worked on a game with in-app purchases." Do not fold on the calendar. | F1 and F5. Covers R5 under pressure. |
| Q2 | "That retention presentation: how much of the result was actually you?" | Pressure / EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the presenting role. Answer slot: if you produced the analysis, say which part; if you did not, say so plainly. Concede uncertainty without folding on the role. | F7. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our community team sees complaints first. Where's the seam with you, and what happens when we disagree?" | Peer | [generic] | Propose seam principles: who decides scope, who speaks to players, who decides when a disagreement goes up. Answer slot: if you have handled a disagreement with another team, say what happened; if you have not, say the principle you would use. | Covers the four-team requirement (R2) from the peer side. |
| K2 | "How do you handle credit when an update spans teams?" | Peer | [generic] | Name the shared credit first, then your own part, only as precisely as you can say it. | Covers R2 from the credit angle. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc: the studio, the calendar, the checklist, the retention presentation. Stop at each quoted fact. Do not pad. | F5, F4, F7. Casual, and still scored. |
| V2 | "What live game do you play, and what's one decision in it you'd defend?" | JD | [generic] | Name one live-service game you have played. Pick one decision in it you can defend, in your own words. | Covers R1 as a casual opener. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 Plan and run the live-events calendar for two titles | C1, P3 |
| R2 Coordinate design, art, engineering and community | S1, K1, K2 |
| R3 Own the post-event review and its KPIs | C4 |
| R4 Manage the release checklist with QA | C3, P4 |
| R5 3+ years live-service | S3, Q1 |
| R6 Running a content calendar | P3, V1 |
| R7 Player-retention metrics | C2, P1, P2, Q2 |
| R8 Clear written communication | C5 |

## Reverse questions

Five questions to ask them. Each has a "why it lands."

1. "What does a good live event look like for this team, and how is it measured?" Why it lands: it shows you think in KPIs before you are asked to.
2. "Which two titles are in scope, and how is each one monetised?" Why it lands: it shows you have noticed the in-app purchase gap and want to know it, not avoid it.
3. "Where has the event calendar slipped most in the last two quarters, and why?" Why it lands: it invites an honest picture and shows you are planning for risk.
4. "How do design, art, engineering and community decide an update's scope today?" Why it lands: it maps the coordination problem from F2 onto their real process.
5. "What would the first ninety days need to deliver for you to call this hire a success?" Why it lands: it turns the interview into a shared problem.

## Sources

- Provided: the job description, as quoted in the request. Your message, as the background.
- Research, L1: three searches were sent and each was refused by the host's search permission. No results came back.

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Refused by the search permission; none was produced. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. Refused; the round format is unknown, so the pack assumes a single final session. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have moved the Case/Strategist and company-knowledge questions. Not sent; the search permission was not granted. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, and a tailored reverse question. Refused. |
| 5. Representative Live Operations Producer JD | skipped | The job description supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused: "Saltmarsh Games mobile studio values"; "Saltmarsh Games interview process live operations producer"; "Tobias Wrenfield Head of Live Operations Saltmarsh Games".

## Upgrade menu

- Tobias's relationship to you (hiring manager, skip-level, or a panel member) and whether the 60 minutes is one session → reweights the persona table and can restructure S1.
- Allowing web search → company values, the interview process and Tobias's public footprint → a values cheat sheet, the loop structure, a tailored reverse question and interviewer-based persona weights.
- Your CV, in addition to the message → turns the "your message" quotes into quotes from the CV, which is a stronger source for the interviewer to check.
- The retention figure you presented, and how it was counted, if you know → turns P1 and P2 from answer slots into quoted answers.
- A written sample of the checklist, or a status update you wrote → raises F8 from discovery and lets C5 use it.
- A tuesday-dossier.md from job-underwriter → adds verified evidence and the objections it has already found.
