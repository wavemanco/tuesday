# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, 60 minutes. First 15 minutes: a spoken POV on operator partnerships over the next 18 months, no slides. Remaining time: Q&A, with commercials pressed.
**Interviewers:** Deepa, VP Partnerships (future manager). Ross, Commercial Director.
**Built from:** the recruiter's email as you quoted it, and your background message. No job description, CV text or public research was available, so this is a first pass. See the sources section.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: CASE (a live problem), JD (the stated role), EXP (your own past), CO (company and strategy), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.
- Answer slots are instructions for the interview. They are not questions to me.

## Prep triage (about four hours)

1. **Build the POV (roughly 90 minutes).** Write the three theses in section 5, each with its concession, and say the operator close aloud. Time it twice at 15 minutes.
2. **Rehearse the commercial pushback (roughly 60 minutes).** Work the R-bank questions, using only your own numbers. Say which figure you can defend and where you do not know how it was counted.
3. **Rehearse the rail gap (roughly 30 minutes).** D6 is the highest-ROI rehearsal. Say "I haven't sold into rail" plainly, then give a plan for learning it, stated as a plan.
4. **Run the case questions (roughly 40 minutes).** D1, D2, R4 and R8. Structure aloud: clarify, objective, who the buyer is, approach, what you would measure.
5. **Prepare reverse questions (roughly 20 minutes).** Section 11.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" (recruiter's email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your material places the operator view in planning work, from the consulting side. The bridge rewords only that quote: "I did bus and light rail network planning, so I know the operator world from the other side." Limit, said as this pack's observation: the material does not show how a train operating company makes its own decisions. |
| F2 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "running the ISV channel" and "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Credible adjacent work: partner channel management at a payments company, not operator partnerships. Words: "At a payments company I ran the ISV channel. I took it from 6 partners to 40, roughly £4M of influenced revenue." Limit: the partners were software vendors, not operators. Any step to operators is an answer slot inside that scope (D5). |
| F3 | "Ross will push on commercials" (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence, so the words come only from it: "I haven't carried a direct quota. My revenue number is influenced revenue, roughly £4M." Closure path, as a plan and never as a past: how you would learn to own a revenue target. |
| F4 | selling into transport operators (role-family requirement, no source) [generic] | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated it, so the words are yours: "I haven't sold into rail." Then how you would learn it, said as a plan. No claim to rail sales work. |

**What the snapshot does not show.** The material is silent on location, office days, pay, and right to work. If any of those is a gate for this role, it would be a `hard_gate` row. The one question about it is asked in the upgrade menu's message.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail | Your own negative, F4 | "I haven't sold into rail." |
| Owned a direct quota | Your own negative, F3 | "I haven't carried a direct quota." |
| Owned or ran a £4M revenue number | Inflated form of F2 and F3: the figure is influenced revenue | "Roughly £4M of influenced revenue," at its own scope. Observation, not a claim about you: the material says influenced, not owned. |
| Operator-side insider experience | Inflated form of F1: the work was consulting, from the planning side | "I did bus and light rail network planning, so I know the operator world from the other side." |

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | Live problems on the operator roadmap; scores structure and clarification | High. A hiring-manager round prior, and a POV is pre-declared, so structure will be tested on the spot. | Clarify first. Name the buyer and the user separately. Say the framework aloud before using it. |
| Skeptic | Deepa | Quiet probing of the rail gap and the reason to move | High. Your gaps are visible on the CV: rail, quota and operators. | Plain acknowledgment, then a plan. Never a bridge built on a practice you did not do. |
| Data-Driven Prober | Ross | Follow-ups on how the £4M was counted and what share was yours | High. A commercial director with a stated focus on commercials. | Say how it was counted, in your words. If you do not know, say so. Name the weakest assumption first. |
| Pressure | Ross | Challenges on the quota gap and on whether influenced revenue counts | High. Recruiter's words: "Ross will push on commercials." | Pause. Hold the position through two follow-ups. Concede the specific gap, never the whole claim. |

Weighting: the panel prior blends the top two personas of each member. Deepa carries Case/Strategist and Skeptic. Ross carries Prober and Pressure. No interviewer profile was available, so the weights come from the roles alone.

## POV build (pre-declared deliverable)

**Facts to build on:** the operator view from F1, and the partner-channel work from F2, both quoted in the fit snapshot. Nothing about operators or rail is asserted as fact here. Every market claim below is [generic], and must be checked against the internal market report before you say it.

**Thesis 1.** Serve operators through the planning cycle they already run, not the software release cycle. [generic]
- Concession: I do not yet know how this company's operators plan change, and the report may say otherwise.

**Thesis 2.** The partner motion for operators should be built around an outcome the operator's planning team can point to. [generic]
- Concession: that is a claim about operators I have not verified. In a payments channel, the buyer and the user were the same party, which is not true here.

**Thesis 3.** For operators, partner count is the wrong headline. The better signal is how many operators have a live change to a schedule. [generic]
- Concession: that needs data the report may not hold.

**Differentiation.** The consensus answer is probably "scale the partner count", which is what you did at a payments company. Saying no to it is the differentiation. The shortlist in the internal report is the consensus answer, and I have not seen it. Paste it in, and I can name the divergence against it instead of guessing.

**The close.** The recruiter asked what it means for the operators themselves. Name one operator outcome in the operators' own terms, and say how you would know it had happened. Which outcome, and how you would measure it, is yours to set. Answer slot: if your own view has a measure, say what it is; if you have none yet, say that you would set one first.

## Question banks

Provenance comes first in each row. Rationale refers to your history only by fit-snapshot row.

### Deepa: Case/Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What would you do in your first ninety days with our operator partners?" | CASE | [generic] | Clarify what the partnership is for and who the operators are. Structure: listen first, map the three or four operators that matter most, agree one measure, then test it. Do not assert any operator fact you have not checked. | Top persona: a live problem on the role's roadmap. Generic, since no research was available. |
| D2 | "An operator says your integration is fine, but their planning team will not use it. What do you do?" | CASE | [generic] | Separate the buyer from the user. Ask what the planning team does today and what would make them change. Propose a test before a rollout. | Typical of a case led by the hiring manager. Generic, since no source names this operator's situation. |
| D3 | "What do you think operators are worried about over the next eighteen months?" | CO | [generic] | Name two or three worries you would test, not facts you assert. Say which parts of the market report you would check first. | Strategy depth. Generic: no current company strategy was available, so do not present it as this company's view. |
| D4 | "What would tell you a partnership with an operator is working?" | CASE | [grounded] "what it means for the operators themselves" (recruiter's email) | Name one operator outcome and one measure, in the operators' terms. Answer slot: if you have a measure from your own work, say what it measured; if not, say you would set one first. | The recruiter's own words raise the question, so it is a raising source. |
| D5 | "What in the ISV channel carries over to operators, and what does not?" | EXP | [grounded] "running the ISV channel" and "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Story-mapped on F2: the channel, and the growth from six partners to forty, in the terms you used. Answer slot: if you have had any operator conversation of any kind, say what it was; if you have not, say that the operator motion is what you would be learning. The limit is that the partners were software vendors. | F2 is the adjacent work most likely to be tested here. |
| D6 | "You have never sold into rail. What would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Highest-ROI rehearsal. Hold: "I haven't sold into rail." Then name the one thing you would be weakest at and how you would learn it, as a plan. Concede plainly. Do not add a rail contact, a bid or a relationship. | F4 is the gap most likely to be probed. A plain acknowledgment the candidate stated, so the words are theirs. |
| D7 | "Tell me about a time you worked on the operator side of a planning problem." | EXP | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Open prompt. Choose an instance from the planning work, and say what you did. Answer slot: if you were the consultant to an operator's planning team, say that. Do not describe yourself as their buyer or as their insider. | F1 is the strongest evidence, and the one most easily stretched. |
| D8 | "Why leave a payments company for rail?" | EXP | [generic] | Selection scaffold: pick the reason you can state in your own words. If none comes to mind, say so plainly, then say what draws you to operators. | Motivation is always probed by a skeptic. Generic, since no reason for the move was supplied. |

### Ross: Prober and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "The £4M. How was the influence counted?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say how the figure was counted, in your own words. If you do not know how it was counted, say so. Do not reconstruct a method you cannot repeat. | Every headline figure gets a defend-the-number question. |
| R2 | "How much of the growth from six partners to forty was you?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say what you led and what you contributed to, in your own words. If the growth was shared, say so. | Attribution is the probe Ross is most likely to run. |
| R3 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Weakest-assumption move: name it before he does. The pack does not name the assumption; if you do not know one, say so. | Metric questions name their weakest assumption, which converts a gotcha into a credibility gain. |
| R4 | "How would you price a partnership with an operator in year one?" | CASE | [generic] | Clarify who pays and what the operator buys. Name the pricing unit you would test, and what you would need to know about the operator's budget first. Give no numbers. | Commercial case. Generic, since no pricing source was available. |
| R5 | "Sixty seconds: why should I trust someone who has never carried a direct quota?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: "I haven't carried a direct quota. What I can show is influenced revenue, roughly £4M, and how I worked it." Hold through two follow-ups, then concede the specific gap. Never fold the whole claim. | Pressure: the held position is the one your material carries. |
| R6 | "Influenced revenue is a story, not a number. Convince me." | EXP | [grounded] "only influenced revenue" (your message) | Hold: "It is a number I can explain, and it is not a quota." Concede plainly what it does not prove. Do not say it was revenue you owned. | The second follow-up is where candidates fold. |
| R7 | "Operators run to tight budgets. Why would one pay for this?" | CASE | [generic] | Structure: what the operator's budget covers, what it would have to give up, and what would make the case in its own terms. No claim about this operator. | Pressure. Generic, since no operator budget was provided. |
| R8 | "A rival scheduling vendor already sits in the operator's planning tool. What do you pitch?" | CASE | [generic] | Clarify the incumbent's role. Pitch on the planning team's problem, not on the feature list. Say what you would need to learn first. | Competitive case. Generic. |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| "what it means for the operators themselves" | D4, D7, POV close | |
| "where you'd take our operator partnerships over the next 18 months" | POV, D1, D3 | |
| "Ross will push on commercials" | R1 to R3, R5 to R8 | |
| selling into transport operators (generic) | D6 | Stated absence |
| Scheduling software and product | none, and why | No product material was supplied to build a question from |

## Section 5, graded deliverables

The POV is pre-declared, so it has its own build section above. The close is the operators' outcome, from the recruiter's own words.

## Reading the interviewer

Not built. No public footprint for Deepa or Ross was retrieved, so there is no career pattern and no mirror opportunity to report. The upgrade menu says what their profiles would add.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| Q1 | "What did the last person in this role do well, and what would you have wanted them to do differently?" | It shows what Deepa actually values in the role. |
| Q2 | "Which operator relationship would you most want the next hire to move, and why?" | It names a concrete operator, which tests whether your POV fits their priority. |
| Q3 | "How is partner-influenced revenue counted today, and who owns that number?" | Ross will care about the commercial model. The answer tells you whether influenced revenue is a metric they trust. |
| Q4 | "What would success look like at six months for this role?" | It gives you a measure to check your POV against before you leave. |
| Q5 | "What is the one thing about operators you wish new people understood before their first planning meeting?" | It asks for practical knowledge rather than a pitch, and the answer is usable in your own prep. |

## Sources

- **Provided documents:** the recruiter's email, as quoted in your message. Your background message. The internal market report: you have read it, and I have not seen it, so no claim here rests on it.
- **Searches sent:** six. All six were refused, because search permission was not granted in this session. Queries: "Kelverton Rail values" (refused). "Kelverton Rail interview process partnerships" (refused). "Kelverton Rail strategy news" (refused). "Deepa VP Partnerships Kelverton Rail" (refused). "Ross Commercial Director Kelverton Rail" (refused). "Senior Partnerships Manager train operating company scheduling software UK job description" (refused).
- **Fetches:** none attempted. No search returned a URL to read.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Value names for any values probe and for the POV close. Not included, since no values round is detected. |
| 2. Kelverton Rail interview process | unavailable | Loop structure beyond this session. The recruiter's email already establishes this session: a panel, 60 minutes, POV then Q&A. |
| 3. Kelverton Rail strategy and news | unavailable | Would have turned D3 from [generic] into [grounded] and sharpened the POV's differentiation. |
| 4. Deepa and Ross public footprint | unavailable | Interviewer read and persona weights. Both names were given, so the queries were formed and refused. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Fit snapshot rows and JD-tagged questions. Without it, the rows rest on the recruiter's words and your message. |

## Upgrade menu

- Search permission granted in this session → a rerun of the research pass: company values by name, the interview process, current strategy, and the public footprint of Deepa and Ross, which together would move the persona weights, the reverse questions, and D3.
- The job description text → the snapshot's rows become [grounded] against the posting's own words, and the JD-tagged questions and the requirement coverage table fill in.
- The internal market report's shortlist (the consensus answer) → the differentiation section names your divergence against it, rather than guessing what the consensus is.
- Your CV → the fit snapshot quotes your CV as well as your message, which raises the confidence bands where the CV carries evidence.
- A reply to the recruiter asking for the POV's exact brief and any written criteria → coverage of any further deliverable.
