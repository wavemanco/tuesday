# Interview prep pack: Product Operations Manager, Stripe (final round)

Changelog: first version. Built with no CV, no JD and no interviewer details. Every row is `[generic]` until you add them.

## 1. How to use + type key

- **Personas** = how a question is asked. **Types** = what is being scored.
- Types: **VAL** behavioral/values · **EXP** work-experience deep-dive · **JD** role-driven · **CO** company and strategy · **CASE** live problem
- Guidance is scaffolding, not a script. Speak each answer in 90–120 seconds.

## 2. Fit snapshot (worksheet variant)

No CV and no JD were supplied, so the requirements below are role-family prose, not quotes. Every evidence cell is `none given`, so every row is a gap to prepare, not a claim you have.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running cross-team operating processes | none given | none | [generic] | discovery | Answer slot: name a process you set up or ran, what it replaced, and who adopted it. If you have not run one, say so and give the nearest process you did run |
| F2 | Launch and rollout operations (readiness, comms, post-launch review) | none given | none | [generic] | discovery | Answer slot: name one launch you ran end to end, your part in it, and what went wrong |
| F3 | Metrics, dashboards and defining success | none given | none | [generic] | discovery | Answer slot: name a metric you chose, how you chose it, and what it missed |
| F4 | Influencing without authority across product, finance, support, and eng | none given | none | [generic] | discovery | Answer slot: name a time you moved a team that did not report to you, and what they did with your plan |
| F5 | Prioritising an ambiguous backlog, and saying no | none given | none | [generic] | discovery | Answer slot: name something you stopped or declined, and why |
| F6 | Working with data and tools (SQL, BI, spreadsheets) | none given | none | [generic] | discovery | Answer slot: name the tool you used most in the last year and the question you used it to answer |
| F7 | Written communication to executives | none given | none | [generic] | discovery | Answer slot: name one written recommendation you sent to a senior person, and its outcome |

Gate rows: none established, because no JD was supplied. Ask in the message below.

## 3. Prohibited list

No dossier, no CV, and no supplied quotes. The one claim this pack will not coach is any specific accomplishment, metric or outcome you have not stated yourself. Those are answer slots, not facts. Where a guidance cell would need a fact about you, it asks you for it instead.

## 4. Question banks

Persona weights (flat, see section 5): top persona 5 questions, mid 3–4, low 2.

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A payments feature launch slipped two weeks and support tickets doubled. Walk me through your first 48 hours." | CASE | [generic] | Clarify what 'slipped' means and for whom → segment the tickets → decide what to stop, what to message, what to measure → name one risk you would escalate. Speak out loud and state the hypothesis first | Live problem from the role; scores structure, not a right answer |
| A2 | "Sketch how you would set up an operating review for twelve product teams that each use a different planning tool." | CASE | [generic] | Clarify the decision the review supports → one shared cadence → the minimum data needed → what you would not standardise yet | Process design under ambiguity |
| A3 | "Sixty seconds: why hire someone for this role over an internal candidate?" | VAL / Pressure | [generic] | Pause, restate, then give one reason tied to something you can show. If you have no internal-candidate comparison, say so and stay with your own strongest reason | Pressure stem from the persona set |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one honest gap and a concrete ramp plan. Do not claim a skill you have not used | Skeptic stem; calibrated candour beats bluffing |
| A5 | "A product team asks for a dashboard that nobody will maintain. What do you say?" | CASE | [generic] | Ask who will use it and for what decision → offer a lighter alternative → say what you would stop maintaining | Tests judgement about operational cost |

### B. Hiring manager / Behavioral (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a process you designed that other teams actually adopted. What did you change after the first try?" | EXP | [generic] | Open prompt: choose an instance. Structure: the problem, your part, who adopted it, what you got wrong first. If no such process comes to mind, say so plainly, then give the nearest thing you did | Covers F1 |
| B2 | "Tell me about a metric you chose for a cross-team program. How did you decide it, and what did it miss?" | JD | [generic] | Open prompt. Name the weakest assumption behind the metric before they do. If you did not choose it, say whose it was and what your part was | Covers F3 |
| B3 | "Tell me about a launch you ran end to end. What broke?" | EXP | [generic] | Open prompt. Name what broke, what you did in the first hour, and what you changed afterwards. Say plainly if you did not run one end to end and which part you did own | Covers F2 |
| B4 | "Tell me about a time you moved a team that did not report to you and disagreed with your plan." | VAL | [generic] | Open prompt. Beats: what they needed, what you changed in your plan, what you held and what you conceded | Covers F4 |
| B5 | "What did you stop or decline to do, and what happened next?" | JD | [generic] | Open prompt. Name the trade-off you made, not only the decision | Covers F5 |

### C. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you would define success for a rollout. Which assumption would you defend least?" | JD | [generic] | Name the metric, the baseline, the time window, then the weakest assumption before they ask. Say plainly if you have not set this before | Prober stem; metric-question move |
| C2 | "Which tool did you use most in the last year, and what question did you answer with it?" | EXP | [generic] | Name the tool and one real question. If you have not used the tool, name your nearest one | Covers F6 |
| C3 | "What is a process you would expect to be abandoned in six months, and how would you know?" | JD | [generic] | Name the early signal you would track and what would make you stop | Process health |
| C4 | "How would you know your last process was actually working?" | EXP | [generic] | Open prompt. Say what you measured, and say honestly if you did not | Covers F3 |
| C5 | "Walk me through how you would decide which of two requests to prioritise, using the data you would have." | CASE | [generic] | Clarify the decision → list the inputs you would need → say what you would do without them | Tests method, not a number |

### D. Pressure / Stress (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result — how much of it was actually you?" | EXP | [generic] | Hold your position through two follow-ups. Say exactly what was yours, and concede only the part that was not. Do not claim more than you did | Pressure stem; honest attribution |
| D2 | "If your manager disagreed with your recommendation in front of the executive team, what would you do?" | JD | [generic] | Pause. Say what you would say in the room and what you would say afterwards. Hold the position through two follow-ups | Pressure in a senior setting |
| D3 | "Give me the one thing you would not compromise on in this role." | VAL | [generic] | Name one principle and one example. Keep it short | Tests conviction without a rehearsed speech |
| D4 | "Your last recommendation was overruled. What did you do next?" | EXP | [generic] | Open prompt. Name the action you took after the decision | Covers F4 and F7 |

### Conversational / Peer (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [generic] | A 90-second arc: the thread that connects your roles, one turn that changed your direction, why this role now | Rapport question scored for economy |
| E2 | "Where's the seam between your work and ours, and what happens when we disagree?" | JD | [generic] | Name the seam as a principle, not as knowledge you lack. Describe one disagreement and how it ended | Peer seam; covers F4 |

Session total: 21 questions (within the 18–26 range).

## 5. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live launch and operating-review problems | High. Final rounds for operations roles usually include a live case | Clarify, then structure, then state a hypothesis early |
| Skeptic | "Why you, why now, weakest on day one" | High. A final round tests the gaps | Name one honest gap and a ramp plan |
| Data-Driven Prober | Metric definitions and assumptions | Medium. Operations roles get metric questions | Name the weakest assumption before they do |
| Pressure | Time-boxed challenges to your recommendation | Medium | Pause, restate, hold through two follow-ups, concede precisely |
| Values / Behavioral | Influence and disagreement stories | Medium. The loop's values round, if any, is not established (see section 7) | STAR shape, with "we" for context and "I" for your part |
| Conversational | Journey and rapport openers | Medium | 90-second arc; treat casual questions as scored |
| Peer Evaluator | Seams with adjacent teams | Low to medium, depending on who is in the room | Reciprocity framing |

Persona weights are flat because the relationship and the loop are unknown. Ask in the message below before weighting them.

## 6. Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Cross-team operating processes (F1) | B1, A2, C3 |
| Launch and rollout operations (F2) | A1, B3, D4 |
| Metrics and dashboards (F3) | B2, C1, C4 |
| Influence without authority (F4) | B4, D2, E2 |
| Prioritising and saying no (F5) | B5, A5, C5 |
| Data and tools (F6) | C2 |
| Written communication to executives (F7) | D4 — none else, and why: no written-artifact question is in the pack until a JD names one |

## 7. Reverse questions

Five questions to ask them, each with why it lands:

1. "What does the first 90 days look like for someone in this role, and what would make it go well?" Why it lands: it shows you are planning the job, not asking for perks.
2. "What is the hardest operational problem the team is working on right now?" Why it lands: it asks for their real problem, and you can answer with a plan.
3. "How does this role work with product, finance and support on a launch?" Why it lands: it shows you know operations is a cross-functional job.
4. "What is the most common reason a process here gets abandoned?" Why it lands: it shows you expect process to fail, which is the honest view.
5. "How will success in this role be measured after six months?" Why it lands: it turns the closing into a conversation about the measure you would own.

Values cheat sheet: not included. No values-style round is established, and Stripe's published values were not fetched (see section 8).

## 8. Sources

- No provided documents.
- Research: all four searches were refused because the search permission was not granted. Nothing from them is used. Stripe values, loop structure and strategy are **not established**, so this pack uses no values, loop or strategy claims.

Research tier: L1 attempted — searches 4 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe company values` | unavailable | Values cheat sheet and VAL questions. Refused |
| 2. `Stripe interview process product operations manager final round` | unavailable | Loop structure and persona weights. Refused |
| 3. `Stripe news strategy 2026` | unavailable | CO bank. Refused |
| 4. interviewer name | n/a | No name given |
| 5. representative Product Operations Manager JD | unavailable | JD-tagged questions. Refused |

## 9. Upgrade menu

- Your CV → turns the worksheet rows into `[grounded]` rows, and the answer slots into story maps
- The job description, pasted → turns the role-family rows into quoted requirements, and makes the requirement coverage table exact
- The round type and who you are meeting → sets the persona weights, instead of flat weights
- Any other interviewers' names → a tailored reverse question, and persona weights from their public footprint
- Stripe's values and loop, if you have them from the recruiter → a values cheat sheet, and a loop-specific persona mix
- A deeper research pass, once search permission is granted → Stripe's strategy brief for the CO bank
- A recruiter's note on focus areas or any take-home → a build section for the deliverable
