# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (name not given). Built 2026-11-20 from the underwriting dossier dated 2026-08-14 (decision: conditional_go). Research did not run (see Sources), so this pack is built on the dossier and your stated round, not on Quartzline's own published material.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **EXP** (your past work, attribution), **JD** (the listed job), **CO** (company knowledge), **CASE** (a live problem), **VAL** (published values).
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Answer slots (in the guidance) are instructions for the interview. They are not questions for this conversation.

## Fit snapshot

Requirements are the dossier's `role_profile` lines, quoted as the supplied JD. Evidence is quoted from the dossier's `verified_candidate_evidence` and `uncertain_or_weak_areas`, which carry the underwriter's confidence grades.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Shipped API or platform products" (R2, must_have, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row, verified evidence | high | [grounded] | transferability | Your material says you led client integrations on a vendor's REST APIs, from scoping through go-live. It does not show a product you shipped under your own ownership, and the words stay at integration scope: "I led thirty-plus client integrations of the vendor's REST APIs, from scoping through go-live." Answer slot: the JD asks about shipped products, so expect a probe on what you decided for those integrations. If any of it was yours to set, say which and how you decided, in your own words; if it was not yours, say so plainly and stay with the integrations you led. |
| F2 | "3+ years product management experience" (R1, must_have, dossier role_profile) | Adjacent only: "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row, verified evidence (medium) | low | [grounded] | transferability | This is a bridge with its limit named, as the underwriter framed it. The adjacent work is client-side integration leadership and feeding evidence into product. The limit is plain: you have not held a product manager title (see the prohibited list). Position the bridge as adjacent, never as PM tenure. Caveat for you to volunteer: the roadmap-input sessions have limited inspectable proof, so say what happened in them before anyone asks. |
| F3 | Owning a roadmap and prioritization authority (R1 sub-claim, dossier uncertain_or_weak_areas) | none given beyond the roadmap-input sessions in F2 | none | [grounded] | capability | The dossier records this as a capability gap with no credible evidence. Words for you: "I haven't owned a product roadmap." Then how you would learn it, said as a plan, never as a past. |
| F4 | "Stakeholder management across engineering, sales, customers" (R4, important, dossier role_profile) | Customers and product are touched: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier rows | medium | [grounded] | discovery | Your material reaches customers and product. It does not show whether you worked with engineering or sales. Answer slot: the JD names both, so expect a probe. If you worked with engineering or sales on an integration, say what you did with them, in your own words; if you did not, say so and stay with the customer and product work. |
| F5 | "Technical fluency: API docs, schemas" (R3, important, dossier role_profile) | "Wrote the internal integration playbook her team uses" — dossier row, verified evidence | high | [grounded] | discovery | The playbook is inspectable proof of integration practice. Your material does not show whether you wrote or read schemas or API reference docs. Answer slot: if you did, say which and what you checked; if you did not, say so and say how you would close the gap. |
| F6 | "Agile delivery experience" (R5, preferred, dossier role_profile) | none given | low | [inferred] | discovery | The dossier marks this as a clarify area: the evidence may exist and was not established. Answer slot: if you ran planning or sprints with an engineering team, say how the cadence worked; if you worked to a cadence set by someone else, say that. |

**Requirement coverage:** R1 is covered by F2 and F3. R2 by F1. R3 by F5. R4 by F4. R5 by F6. Nothing is left without a row.

## Prohibited list

Each entry names its basis and its honest form. These bind every guidance cell below.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims` | "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." |
| Owned the partner API platform's roadmap or shipped it | Inflated form of F1 (integration leadership widened to platform ownership) | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says integrations led for clients, not a platform shipped under your ownership. |

## Persona weights

| Persona | Weight | How it shows up here | Likelihood reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | Pushes on the PM-title gap and the roadmap gap, the dossier's named objection | A hiring manager is buying capability and derisking gaps; the dossier names the objection | Acknowledge the gap plainly, bridge at quote scope, offer a ramp plan |
| Case / Strategist | 3 | Live problems on the partner-platform roadmap | Hiring managers run live problems on their own roadmap | Clarify before structuring; name what you would need to know first |
| Data-Driven Prober | 2 | Adoption metrics, which the JD names as a responsibility with no stated baseline | Adoption is a JD line and the dossier flags it | Say what you tracked, how it was counted, and what you would count first |
| Pressure | 2 | Time-boxed challenge on why you over a PM with the job | Likely from a hiring manager who has a PM candidate with tenure in the pool | Hold the integration case through two follow-ups, then concede the tenure gap plainly |
| Conversational | 2 | Opener and reverse-question slot | Friendly openers are still scored | 90-second arc; treat casual questions about partner APIs as scored |

No Values/Behavioral persona is weighted, because no values-style round is detected (see Sources). No Peer persona is weighted, because this is a manager round.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; plain acknowledgment from dossier `prohibited_claims` ("Having held a product manager title or role", "Having owned a product roadmap") | **Highest-ROI prep in this pack.** The underwriter named this objection, so its premise is sourced. Hold the position: first say the plain acknowledgment ("I haven't held a product manager title, and I haven't owned a product roadmap."). Then make the case from the integrations at their scope, and quote the roadmap-input sessions as adjacent evidence with its limit named. Do not argue you are equivalent to someone with three years of PM tenure. Then give a plan for the first 90 days, said as a plan. Hold through two follow-ups by returning to the integrations; concede the tenure difference plainly, never the integration work. | The dossier names this as the likeliest objection, and it is aimed at the gap the material is thinnest on. A plain, non-defensive acknowledgment changes the interview more than a rehearsed bridge. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | plain acknowledgment from dossier `acknowledge_gap` (roadmap and prioritization authority) | Name the roadmap and prioritization authority, with the plain words "I haven't owned a product roadmap." Then give a ramp plan as a plan: how you would learn the roadmap process and who you would learn it from. Do not offer a past bridge here, because the underwriter found no credible evidence. | F3 is a capability gap, and a bridge would reopen what the dossier closed. |
| A3 | "Two squad leads both own engineering priorities. Which roadmap decisions would you make alone?" | JD | [generic] | Structure it: which decisions are product decisions, which are engineering, and how you would find out where the line is before you commit to an answer. Name how you would handle a disagreement with a squad lead. This needs no claim about your past, so the guidance makes none. | The JD leaves decision authority unevidenced (dossier opportunity risk). The interviewer may ask this directly. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says their integration breaks after every release and wants a roadmap commitment. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: which partners, which releases, what breaks, and how often. Then structure: triage, the partner's own impact, and what you would commit to and what you would not. Say what you would need from engineering. | A live problem from the partner-facing responsibilities in the JD. Generic because it is a pattern, not a fact about Quartzline. |
| B2 | "How would you tell whether partner API adoption is healthy, if there is no baseline yet?" | CASE | [inferred] the JD line "Define and track adoption metrics" (dossier `role_profile`) | Say what you would count first, how you would establish a baseline, and what you would not trust yet. Name the weakest assumption in your own proposed metric. | The JD names adoption measurement and the dossier flags no baseline. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one of those integrations and walk me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F1, with the beats the quote states: scoping, requirements, architecture, UAT, go-live. Tell them in your own words. Answer slot: if you chose the architecture, say what you decided and why; if the architecture was set by others, say so plainly. | F1 is the evidence for the shipped-products requirement and the likeliest place to be probed. |
| C2 | "Adoption is a responsibility in this role. What did you measure on your integrations, and how was it counted?" | JD | [inferred] the JD line "Define and track adoption metrics"; [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: if you tracked anything on the integrations, say what and how it was counted, and which assumption you would defend least. If you tracked nothing, say so plainly and name what you would count first. Never describe a metric you did not track. | F5 and the JD line raise this; the dossier flags no adoption baseline. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; plain acknowledgment from dossier `prohibited_claims` ("Having held a product manager title or role") | Hold: lead with the integrations at their scope, one sentence. Concede explicitly: "they will ramp on product faster than I will at first, and I would close that gap by ..." then give the plan. Never fold on the integration work to restore harmony. | The pressure version of A1. Hold-then-concede is the structure the rubric asks for. |
| D2 | "That integration — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which parts you led and which were shared with the vendor or the client, in your own words. If the share was partial, say so; a partial share held honestly survives this probe. | F1's attribution is the thing a pressure interviewer tests. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: integration work on the vendor's REST APIs, the client-side leadership that came with it, the roadmap-input sessions, and what you want to do next. Stay at quote scope. | The casual opener is scored. This arc is the one to rehearse aloud. |
| E2 | "What are you playing with in APIs these days?" | JD | [generic] | Answer with what you have actually used, in your own words. If you have not used a current API tool, say so and name what you would learn first. | A casual version of R3. Generic because it asks for no claim. |

**Coverage map:** R1 by A1, A2, D1. R2 by C1, D2. R3 by C2 and E2. R4 by A3 and E1 (its answer slot is in F4; no bank question asks engineering or sales directly beyond A3). R5 by no bank question; F6 gives the clarify slot, and the upgrade menu says what closes it. The adoption requirement is covered by B2 and C2.

## Reverse questions

Each one has a "why it lands". Two come from the dossier, the rest are generic.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it tests the decision-authority unknown the dossier names, and shows you read the JD closely.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: it tests the adoption-baseline unknown and shows you will measure things, not just own them.
3. "What is the hardest partner integration problem on the roadmap right now?" Why it lands: it invites them to describe the work, which is where your integration background is most useful.
4. "What would the first 90 days need to deliver for you to call this hire right?" Why it lands: it gives you their definition of success before you commit to a plan.
5. "Where do the two squads split the partner-facing work?" Why it lands: it surfaces the seam between squads, which determines how much of the roadmap sits with you.

No reverse question is tied to the interviewer's own path, because no interviewer profile was given.

## Sources

**Provided documents:** the underwriting dossier you pasted (dossier_version 1.1, dated 2026-08-14). Consumed sections: `role_profile` (requirements R1 to R5, responsibilities, unknowns), `decision` (conditional_go, no hard gates, no red flags), `handoff_to_mock_interview` (high-priority requirements, verified evidence, weak areas and their strategies, the likely objection, risks, employer questions, prohibited claims). No `evidence_map`, `evidence_state` or `risk_register` was pasted, so their rows are not used.

**Dossier age:** the dossier is three months old. The posting may have changed since 2026-08-14. Check the posting against R1 to R5 before Thursday.

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2. All three searches were refused by the host (permission not granted), so no result came back.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Values cheat sheet (section 10). Refused; no values are used, and none are named in this pack. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure and persona weights. Refused; the weights above rest on the relationship prior and the dossier alone, not on a documented loop. |
| 3. `Quartzline platform APIs strategy partners` | unavailable | CO bank and the grounding brief. Refused; the pack has no CO question, and the CASE questions are generic. |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions. |

Because all three searches were refused, the values cheat sheet is absent, no values-style round is detected, and no loop source establishes the loop. The pack says so rather than filling those gaps from memory.

## Upgrade menu

- Allow web search, or paste Quartzline's values page and the recruiter's process note → a values cheat sheet, the loop structure, and CO questions grounded in current strategy.
- The hiring manager's name → persona weights from their public footprint, and a reverse question tied to their own path.
- The current posting → confirms or updates R1 to R5 against the dossier's three-month-old `role_profile`.
- Your own account of the integration decisions you made (in your words, outside a drill) → the answer slots in F1, C1 and D2 become grounded, and the slot wording can drop.
- Your own account of whether you worked with engineering or sales → closes the F4 slot.
- Any agile or sprint work you did (in your words) → closes the F6 slot.
