# Interview prep pack: Product Operations Manager, Stripe

Session pack, first version. Round type and interviewer unknown, so persona weights are flat. No JD or CV supplied, so this is a self-assessment worksheet. Web search was refused this session, so nothing about Stripe below is sourced.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your own experience), JD (the role), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.
- Answer slots are instructions for the interview, not questions to answer here.

## Prep triage

Prep time was not stated, so no schedule is given. Start with B1 and A1; they carry the most rehearsal weight.

## Fit snapshot

No JD or CV was supplied, so the requirements below are role-family patterns for product operations, labelled `[generic]`. No evidence is on file for any of them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running cross-functional launches and operating cadence across product, engineering and go-to-market (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name a launch, review or planning forum you ran or took part in, and what it decided. If you ran none, say so and say how you would set one up in the first 30 days |
| F2 | Building metrics and dashboards that leaders use to make decisions (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name one metric you tracked, how you defined it and what you would defend least about it. If you tracked none, say so and say what you would define first |
| F3 | Managing stakeholders whose priorities conflict (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: describe one disagreement you had to resolve across teams and how it ended. If none, say so and say how you would handle the first one |
| F4 | Designing process for ambiguous or fast-changing work (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name a process you designed or changed and what changed after it. If none, say so and describe your approach |
| F5 | Writing clear decision memos for senior leaders (role-family pattern) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name a written decision or recommendation you produced and who read it. If none, say so and describe how you would structure one |

Gate rows: none known. A JD would show location, work-authorization or schedule terms, which are gates. See the upgrade menu.

## Prohibited claims

Built from the fit snapshot. Nothing is quoted yet, so these are the claims a candidate tends to reach for under pressure. Each is listed with its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Scope of any program, such as team size, budget or number of launches | No quote supports a figure; this would be an inflated claim | Your material does not show a figure. Give the real scope in your own words, or say you do not have one |
| Ownership of company-wide metrics or KPIs | No quote supports it | Describe the metric you actually touched and whose it was |
| Familiarity with Stripe's internal tools, processes or teams | No source for it, and the pack cannot supply one | Say what you know from public material, and say plainly if you have not worked with the company's internal processes |

## Persona table

Relationship and round are unknown, so the archetype is Generic and weights are flat. Ask which round this is before rehearsing further.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live operations problems | High | Ops roles are scored on structure, and a live problem is the usual way to test that | Clarify, then structure, then answer. Name the decision first |
| Skeptic | Probes the gaps: no evidence on file for F1 to F5 | High | With no quotes, the gaps are the whole picture an interviewer will see | Rehearse B1 until it is plain. Concede the gap, then give your ramp plan |
| Data-Driven Prober | Asks how a metric was counted | Medium | Metric work is part of the role-family pattern | Name the weakest assumption before they do |
| Pressure | Time-boxed challenge, devil's advocate | Medium | Flat weight, unknown round | Hold the position through two follow-ups, then concede only what is true |
| Values / Behavioral | STAR-shaped stories | Medium | No values were fetched, so no values round is detected | Use E1 and E2 as selection scaffolds |
| Peer Evaluator | Seam questions about teams you would support | Medium | Ops work sits between teams, so a peer will test the seams | Propose seam principles. Do not claim the seam is known |
| Conversational | Casual opener, "walk me through" | Medium | Flat weight | Prepare a 90-second arc from your own facts. Treat casual questions as scored |

## Question banks

Coverage is shown in the banks below. Types tag each question. Where a question touches the candidate's history, its guidance is a selection scaffold, not a story.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is slipping two weeks and three teams disagree on the cause. What do you do in the first 48 hours?" | CASE | [generic] | Name the decision and the cost of delay. Get the real dates and blockers from each owner. Put one fact base in front of everyone. Name a decision owner and a date. Say what you would write down. About 90 seconds | Role-family operations problem; makes no claim about your past. Covers F1 |
| A2 | "You are asked to build the operating cadence for a new product area with no process. Sketch the first 90 days." | CASE | [generic] | Start from the decisions the cadence must support. Choose the fewest forums and artifacts that support them. Name an owner for each. Say how you would know it is working | Covers F1 and F4 |
| A3 | "A metric leadership watches dropped 15% in a week. Walk me through your diagnosis." | CASE | [generic] | Confirm the definition and any recent instrumentation change. Segment the drop. Rule out data problems before any narrative. Then test the two or three causes that remain | Covers F2 |
| A4 | "How would you choose which of twelve product-team requests to decline?" | CASE | [generic] | State the criteria, tied to the goals you were given. Name the tradeoff you accept. Say how you would write the no and to whom | Covers F4 and F5 |

### Skeptic (highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name the one area your own material does not show, plainly. Then give your ramp plan for the first month. Do not say you have no weak area. Answer slot: your answer comes from your own experience, and if you have none in the area, say so | With no CV on file, every requirement looks like a gap, so this probe is near certain. A plain, specific answer is the one that holds |
| B2 | "Why product operations, and why this company rather than a product management track?" | EXP | [generic] | Give your motivation in your own words. Say what you know about the company from public material and say where that stops. Do not claim familiarity you lack | Motivation consistency is a common skeptic angle |
| B3 | "Tell me about a process you built that failed. What did you do?" | EXP | [generic] | Selection scaffold: pick a process that failed, with a real stake and a change you made afterwards. If no such time comes to mind, say so plainly, then describe how you would handle the first sign of failure | Open prompt about failure; theme comes from the persona stem for the Skeptic |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Show me a metric you have tracked. How was it defined, and what would you defend least?" | EXP | [generic] | Selection scaffold: name a metric you tracked, its definition and the assumption you would defend least, in your own words. If you tracked none, say so and name what you would define first | Persona stem; covers F2 |
| C2 | "How do you decide whether a process is worth its overhead?" | JD | [generic] | Name the cost you would measure and what counts as benefit. Say what would make you remove the process | Covers F4 |
| C3 | "Where do you stop trusting a dashboard?" | CASE | [generic] | Name the checks you run first: definitions, refresh timing, a sample of raw rows. Say what you do when the number and the team's story disagree | Covers F2 |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] | Hold on the reason you actually believe, in your own words. Concede plainly what you do not know about the internal candidate. Do not compare yourself to people you have not met | Pressure framing, flat weight. Hold, then concede the uncertainty only |
| D2 | "That answer is generic. Give me one decision you made that someone senior disagreed with." | EXP | [generic] | Selection scaffold: pick a decision with a real disagreement and say how it ended. If none comes to mind, say so and describe how you would handle the disagreement | Pressure follow-up pattern |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you brought a hard truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, what you said, how it landed. If none, say so. Say "we" for context and "I" for what you did | No values were fetched, so this is a general behavioral probe, not a company value |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a time the customer case beat the number, with what you gave up. If none, say so | Same as E1 |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-P1 | "Our teams sit side by side. Where is the seam between ops and the teams you would support, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their teams. Say what you would bring to their team, not only what you need from them | Peer register. Covers F3 |
| F-P2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: name one shared piece of work and how credit was handled, in your own words. If none, say how you would handle it | Peer register |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: your last role, what it taught you, why this role. Use only facts you can stand behind | Rapport opener, still scored |
| G2 | "What are you playing with in ops tooling these days?" | JD | [generic] | Name the tools you actually use and what you use them for. Do not list tools you have only read about | Casual probe on a likely JD topic |
| G3 | "What is the hardest operational problem a company like this faces?" | CO | [generic] | Frame one problem as a question you would want answered, not as a fact about the company. Say where your knowledge of the company stops | CO without a research pass. Labelled generic: no company strategy was checked |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 cross-functional cadence | A1, A2 |
| F2 metrics and dashboards | A3, C1, C3 |
| F3 stakeholder conflict | F-P1 |
| F4 process design | A2, A4, C2 |
| F5 decision memos | A4 |

## Reverse questions

1. "What does a strong first 90 days look like in this role?" Why it lands: it shows you are planning for the job, not auditioning for it.
2. "Which teams does this role work with most, and where do they disagree today?" Why it lands: it surfaces the seam you will have to manage.
3. "How is this role's success measured in its first year?" Why it lands: it tests whether the metric is defined before you start.
4. "What does the current operating cadence look like, and which piece breaks first?" Why it lands: it invites an honest view of the process you would inherit.
5. "What did the last person in this role do that you wish they had done more of?" Why it lands: it turns a scored interview into a working conversation.

## Sources

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Provided documents: none beyond the user's message. No JD, CV or interviewer profile was supplied.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet and VAL questions. Query: "Stripe company values principles": refused |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Query: "Stripe interview process product operations manager": refused |
| 3. Stripe strategy and recent news | unavailable | CO questions and grounding brief. Query: "Stripe strategy recent news 2026": refused |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so no query could be formed |
| 5. Representative product operations JD | unavailable | Fit snapshot requirements and JD-tagged questions. No query sent; the host search is not permitted this session |

Search permission was refused on all three calls, so nothing from Stripe's own sources is in this pack. The values cheat sheet is omitted because no values page was read. The loop is not established by any source, so the Generic archetype and flat weights apply.

## Upgrade menu

- Round type and who you are meeting → persona weights and a reverse question tuned to their role
- A pasted JD → the `[generic]` requirements become `[grounded]`, and any location, work-authorization or schedule gates surface
- A pasted CV or a few bullets → the evidence column fills, and selection scaffolds become story-mapped answers
- Web search permission granted → Stripe's values, loop structure and current strategy can be checked, and the CO and values questions become grounded
- The interviewer's name → a reverse question tied to their career path
- The recruiter's note on the interview format → confirms how many sessions to prepare for
