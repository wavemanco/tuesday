# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Candidate:** Dara (they/them). **Role:** Member Experience Lead. **Company:** Ashgrove Credit Union.
**Changes:** first version.

| Round | Length | Who | Format |
|---|---|---|---|
| 1. Recruiter screen | 30 min | Recruiter | Fit, logistics, motivation |
| 2. Behavioural | 45 min | Head of Member Services (your future manager; name not given) | Mostly behavioural |
| 3. Panel | 60 min | Two branch managers (names not given) | 20-minute complaint-escalation case; scored against the four values |

Interviewers beyond the roles are not yet assigned, so there is no interviewer read.

**Check the date.** 29 November 2026 is a Sunday. Confirm with the recruiter that the three slots are on the day they mean.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse it in your own words.
- An **answer slot** is an instruction for the interview: it tells you what to say if the probe comes, including "I haven't done this." It is not a question for you to answer here.
- Where guidance says "plain acknowledgment," it means one of your own stated gaps, said as it is.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not an end-to-end process across branches. Keep it at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on the stages from first contact to closure likely. If any stage was yours to set, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log. |
| F2 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches monthly complaints reporting in other terms. It does not say volumes or resolution times. Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names resolution times, so expect a probe. If the spreadsheet recorded them, say how they were measured; if it did not, say so plainly. |
| F3 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training tellers on a script is adjacent to coaching supervisors, not the same work. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what you did, in your own words; if you have not, say so and say how you would start. |
| F4 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this, and you have not said you lack it. Answer slot: if you worked with anyone on a digital or self-service change, say what and what your part was; if you have not, say so and say what you would look at first. |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material does not show whether those complaints were regulated. Reading "formal" as "regulated" is this pack's inference, not your claim. Answer slot: say whether any rules or deadlines applied to the complaints in that log, and which; if none did, say so. |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would learn it, stated as a plan, never as a past. Add nothing to make the gap feel smaller. |
| F7 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then a plan for learning it. Never a claim to contact-centre work. |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | none | The quote reaches the requirement in role terms, though it does not name Excel. Expect a probe on which tool you used and what it does. Say it in your own words. |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on whether branch work counts as customer operations; answer at the quote's own scope. |

**Gates.** No row is a gate. The JD states no location, pay, schedule or licence requirement. Those topics come up in the recruiter-screen logistics questions (B2 to B5).

## Grounding brief

From the July 2026 strategy brief, **as you summarised it** (I do not have the document; the exact wording is in the upgrade menu):

- About 40% of member service to move to digital channels by 2028.
- Eight branches to consolidate into five hubs over 2027.
- A small-business lending product launching in Q1 2027.
- App-only banks named as the main competitive pressure.

Use these in D2 and D3. Do not guess which branches will close, and do not name any branch. The brief is recent, so nothing here is stale.

## Persona table

| Persona | How it shows up in this loop | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | Panel scores against the four values; round 2 is mostly behavioural | High. The recruiter says the panel scores the four values, and round 2 is mostly behavioural | 5 | STAR-shaped stories. Use the honest branch when no story fits |
| Conversational / Rapport | Round 1 screen: the journey, logistics, reason for leaving | High for round 1. The screen is scored even in a friendly register | 5 | A 90-second arc. Logistics answers in your own words |
| Skeptic | Round 2 manager tests the gaps: contact centre, presenting, end to end | High. Three lines of the JD are gaps in your material | 4 | Rehearse the contact-centre answer until it is plain and short |
| Case / Strategist | Panel's 20-minute escalation case; strategy questions | High for the case (the recruiter named it). Medium for strategy questions (not confirmed) | 3 | Clarify, then objective, structure, metrics, risks. Think aloud |
| Data-Driven Prober | Spreadsheet and resolution-time questions | Medium. The JD names resolution times and your material names a spreadsheet | 3 | Know what it counts. Name its weakest assumption first. Say plainly when you do not know |
| Pressure / Stress | A branch manager tests "how much was actually you" | Medium-low. A plausible panel style; nothing signals it | 2 | Hold the position through two follow-ups, then concede specifically |
| Peer Evaluator | Branch managers on the seam with branch supervisors | Medium-low. The role coaches supervisors, which sits between branch managers and the new role. Reasoned from the JD; no panel profile | 2 | Seam principles, not a seam you have run. Reciprocity |

**Round weights.** Round 1 leans Conversational. Round 2 leans Values and Skeptic. Round 3 leans Values and Case, with Pressure and Peer for the branch managers.

## Question banks

Ordered by weight. Depth follows weight: 5 for the top two, 4 for Skeptic, 3 for Case and Prober, 2 for Pressure and Peer. Total 24.

### A. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you decided something from a member's side of the counter." | VAL | [generic] No quoted sentence carries a member-led decision. Theme from the published value "Members First, Always" | Selection scaffold: pick a complaint in your log where the member's side changed what you did. Say what you did and why, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values round, scored against the published value. Nothing in your material carries this story yet, so the honest branch is part of the answer |
| A2 | "Tell me about a time you found out a written explanation wasn't clear, and what you did about it." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Story map from the quote: you trained new tellers on the script. Answer slot: if a teller or member found the script unclear, say what you changed; if none did, say so and describe how you would check that a script was understood | Matches "Plain Words". The quote gives the training, not the rewrite |
| A3 | "When a decision was going to change something for a community, how did you decide what to tell people?" | VAL | [generic] No quoted sentence carries it. Theme from the published value "Neighbours, Not Numbers" | Selection scaffold: pick a change that affected people you served, and say how you explained it and what you did for those most affected. Honest branch: if you have no such change, say so, then say how you would approach one. Do not speculate about the eight branches | The value says each branch is part of its town. Consolidation makes this live, but the answer is about your own practice |
| A4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Story map from the quote: the log you handled. Answer slot: if a complaint in that log stayed with you from first contact to resolution, say how it ended; if it did not, or it passed to someone else, say so and describe what you did with it | "Own the Fix" asks for holding a problem to its end. The quote gives the log, not the ending |
| A5 | "Tell me about a problem you found that wasn't yours to fix. What did you do?" | VAL | [generic] No quoted sentence carries it. Theme from the published value "Own the Fix" | Selection scaffold: pick a problem you found outside your remit. Say who you told and what you did until it was solved, or handed on with a named owner. Honest branch: if you found none, say so and give the nearest case | Tests the "keeps hold" part of the value at its boundary, where the pressure is |

### B. Conversational / Rapport (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | A 90-second arc: six years in retail banking, the last three as a branch supervisor; the complaints log you handled and the escalation script you trained tellers on; then what you would need to learn for this role, including that you have never worked in a contact centre. End there | Casual openers are scored. The arc uses only your own sentences and states the gap yourself |
| B2 | "What's your notice period?" | JD | none given. Logistics slot | Give your actual notice period in your own words. If you are not sure, check your contract before the call. Do not give a figure you have not checked | Knockout check. No figure from you is in the material, so none is supplied here |
| B3 | "Where would you be able to work?" | JD | none given. Logistics slot | Give your own answer: where you can work, and what travel across branches and sites you can do. If the base is unclear, ask the recruiter for it before you answer | The role spans branches and a contact centre, and the strategy points to hubs, so the base may be the open question. Your answer only |
| B4 | "What are you looking for in pay?" | JD | none given. Logistics slot | Give your own answer, or ask for the band first. No figure is in the material, and none should be given here | Pay is a knockout. A number you did not give would be invented |
| B5 | "Why are you leaving your current role?" | EXP | none given. Logistics slot | Give your own reason in your own words. No reason is in the material, so none is supplied here | The answer must sit beside the branch-supervisor story without contradicting it |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns complaints across branches and the contact centre. What's your experience in a contact centre?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment, then a plan. Say it plainly: "I haven't worked in a contact centre." Then one concrete way you would learn how its complaint queues run, stated as a plan. Then return to what you did run: "I handled the branch's formal complaints log." If the probe continues, hold the plan. Do not describe any contact-centre practice as yours | **Highest-ROI prep in this pack.** F7 is a stated gap inside the role's core scope line, and a manager responsible for the role will test it. Expect it in some form |
| C2 | "How would you prepare to present complaint performance to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan you can say in one breath: a one-page version of the monthly report, rehearsed first with someone at regional level. Do not describe a past presentation | F6 is a stated capability gap. The JD asks for confident presenting, and a skeptic tests it head on |
| C3 | "Which parts of the complaints process, from first contact to closure, did you own yourself?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Start with the quote: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages likely. If any stage was yours to set, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log. Hold through two follow-ups by returning to the log | F1 is transferability. The honest limit is the answer. This is a premised question, so its second branch must allow that you owned no stages |
| C4 | "A supervisor in one of your branches has escalated a complaint you think they handled badly. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script" — your message | Story map from the quote: the training you ran. Answer slot: if you coached a supervisor on an escalation, say what you did, in your own words; if you have not, say so and say how you would start: ask them to walk you through the case before you give a view | The JD's coaching line is the gap. F3's quote is adjacent work, so say what it is and no more |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member has complained three times about the same charge. The branch and the contact centre have given different answers. What do you do?" | CASE | [generic] A live problem. The recruiter's 20-minute escalation case is the raising source | Clarify first: what each side said, and what the member needs. Objective: one owner and one answer. Structure: who owns it, what gets checked, what the member hears, when it escalates. Metrics: time to one answer; repeat contacts. Risks: the wrong owner; a promise you cannot keep. Think aloud, and challenge one premise respectfully | This is the panel's case. It is a live problem, so it presupposes nothing about your past |
| D2 | "What would you want to know before deciding how a credit union should respond to app-only banks?" | CO | [generic] Theme from the strategy brief's competitive pressure, with no premise about Ashgrove | Name what you would check first: which members leave and why, what they use you for, what matching costs, and which members cannot use an app. Give a first step, not a verdict | Tests whether you think at the right altitude. The question carries no premise about the brief, so nothing in it needs to be true |
| D3 | "If more member service moved to digital channels, what would happen to the complaints that still arrive by phone or at the counter?" | CASE | [generic] Theme from the strategy brief's digital shift; no premise about your past | Structure: which complaints move and which do not; who stays on phone and counter; how complaints are logged across channels; what to measure. Then how you would work with digital teams. If you have not done so, say so and give the first step: agree one complaint log that spans channels | Covers the JD's digital-teams line through a live problem. Answer honestly if asked about past work (F4) |

### E. Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What does the monthly complaints spreadsheet count, and what does it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Start from the quote: you built it, and the regional manager uses it. Name the weakest assumption you know of before they do. Answer slot: if you chose what it included, say how; if you did not, say so and describe what you know of its columns | F8 and F2. The Excel requirement is probed here, in its most likely form |
| E2 | "Which resolution times did your monthly report show, and how were they measured?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: the JD names resolution times, so this probe is likely. If the spreadsheet recorded how long complaints took to resolve, say how it was measured, in your own words. If it did not, say so plainly and say what you would measure first. Never give a figure you cannot explain | F2 is presentation. The resolution times are not in the quote, so this stays an answer slot |
| E3 | "Did any rules or deadlines apply to the complaints in that log? Which?" | JD | [inferred] "I handled the branch's formal complaints log" — your message. Reading the log as regulated is this pack's derivation | Say whether complaints in the log had rules or deadlines, and which, in your words. If none applied, or you did not handle them under any, say so | Tests the JD's "regulated complaints" line. F5 is discovery: the material does not show it, so do not claim it |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has worked in a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Hold: restate the question, then anchor in what you did: the branch log and the script you trained on. Through two follow-ups, do not fold on the relevance of the branch work. Concede the one specific thing: "I haven't worked in a contact centre." Do not add a contact-centre claim to win the exchange | A composure test. The specific concession is the answer |
| F2 | "That complaints log, how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Hold, then concede specifically. Say what you handled, in your own words, and where others handled parts. Do not widen "handled" to "ran" or "owned" under pressure | Attribution probe. The quote is the most the answer can hold |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between a branch manager and this role, and what happens when we disagree?" | JD | [generic] Seam principle. Theme from the JD line "coach branch supervisors on escalations" | Propose seam principles, not a seam you have run: who decides an escalation, who coaches the supervisor, and how a disagreement is settled, by the member's outcome. Do not claim you have managed this boundary | The role sits between the panel's roles and the supervisors. Disagreement style with equals is scored |
| G2 | "When a complaint is solved across two branches, who gets the credit?" | VAL | [generic] Theme from the published value "Own the Fix". No candidate sentence carries credit | Name the person who did the work, and the supervisor who held the case. Do not claim credit for work that was not yours | A peer credit-sharing probe. Ownership and credit are tested together |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | C1, C3, A4, D1 |
| Report monthly on complaint volumes and resolution times | E1, E2 |
| Coach branch supervisors on escalations | C4, G1 |
| Work with digital teams on self-service journeys | D3 |
| 4+ years in financial-services customer operations | B1 |
| Experience handling regulated complaints | E3 |
| Confident presenting to senior leaders | C2, F1 |
| Comfortable with Excel reporting | E1 |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No fit row carries a member-led decision. Selection scaffold; honest branch in A1 |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F3: "trained new tellers on our escalation script." The story is the training; the rewrite beat is A2's answer slot |
| Neighbours, Not Numbers | Every branch is part of its town | No fit row carries it. Selection scaffold; honest branch in A3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log." The quote gives the log, not the ending; A4 and A5 carry the slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good monthly complaints report look like to you? What decision should it help make?" | Treats the report as a tool for decisions, which is most of this job |
| 2 | "Where do complaints get stuck between a branch and the contact centre today?" | Asks for the seam directly, and signals you would start there |
| 3 | "As branches move into hubs, what changes for the supervisors this role would coach?" | Uses the public direction without guessing which branches. Shows you read the brief |
| 4 | "What would you need from me in my first month that you are not getting now?" (for the Head of Member Services) | Makes the manager name the priority, and shows you plan to deliver it |
| 5 | "What did the last person in this role find hardest?" | Gets an honest account of the scope, and tells you where the seam is |
| 6 | "What could a new person do in their first month that would genuinely help your branches?" (panel; peer reciprocity) | Shifts from what you need to what you bring, which is the peer test |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material says one branch's log |
| Has worked in a contact centre | Your stated negative, F7 | "Never worked in a contact centre." Plain acknowledgment, no slot |
| Has presented to senior leaders | Your stated negative, F6 | "I've never presented to anyone above regional level." Plain acknowledgment, no slot |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote: "trained new tellers on our escalation script" |
| Reported resolution times monthly | Inflated form of F2 | F2's quote at its own scope. The spreadsheet is the only thing in the material |
| Handled regulated complaints | Inflated form of F5 | F5's quote at its own scope. The material does not say whether those complaints were regulated |

No pay figure, notice period or reason for leaving appears in your material. No answer in this pack supplies one.

## Sources

**Provided documents:**
- Your message: your background (six years in retail banking, the complaints log, the spreadsheet, the contact-centre and presenting gaps).
- The job description, as pasted.
- The Ashgrove values text, as pasted (copied 20 November 2026 from ashgrovecu.org/about/values).
- The recruiter's email: three rounds on 29 November, their durations, and the panel's scoring against the values.
- The 2026 strategy brief, **as your summary in the message**. I do not have the document.

**Research tier: L0, no searches.** No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the names and wording for the values cheat sheet |
| 2. Ashgrove interview process, member experience | skipped | The recruiter's email establishes the loop: three named rounds, their lengths, who runs each and what each holds |
| 3. Ashgrove strategy / recent news | skipped | The strategy brief, as you summarised it, fixes the grounding section. The exact wording is in the upgrade menu |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there is no query. The upgrade menu says what names would unlock |
| 5. Representative member-experience JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → persona weights for each interviewer and a tailored reverse question each, from public footprint only.
- Hours you can spend before 29 November → a prioritised prep schedule (the prep-triage section, currently dropped because prep time is unknown).
- Your CV → quotes taken from the document rather than your message. F1, F2 and F8 move from your words to a named artifact.
- An anonymised sample of the monthly spreadsheet, with no member data → E1 rehearsed on what the sheet actually shows. F8 gets an inspectable artifact, which can raise its confidence.
- The recruiter's brief for the 20-minute case, and whether notes are allowed → D1 tightened to the panel's format.
- The exact wording of the strategy brief → the grounding section quotes it rather than your summary.
- No `tuesday-dossier.md` present: one line on what it would add. It would carry the gaps this prep exposes into later sessions without re-deriving them.
