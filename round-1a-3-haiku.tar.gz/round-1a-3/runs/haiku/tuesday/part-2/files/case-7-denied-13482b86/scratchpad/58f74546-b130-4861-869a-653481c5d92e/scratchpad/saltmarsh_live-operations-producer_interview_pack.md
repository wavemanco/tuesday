# Saltmarsh Games, Live Operations Producer: interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile studio, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, so likely your future manager.
**Round:** One 60-minute hiring-manager interview, one session.
**Candidate:** Femi

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: JD (the listed job), EXP (your own work, probed closely), CASE (a live problem), CO (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.
- Answer slots (an instruction, not a question) mean: answer the honest branch that fits your experience.

## Fit snapshot

Quotes are your own sentences, or the JD's words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles or live events. Keep the bridge there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles. If you ran anything for a second title, or any event beyond the weekly drops, say what in your own words. If not, say so and say how you would plan across two. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. Lead with the quote. Your calendar is the proof you can show, so bring a copy if you can. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented the numbers. Say that and nothing more. Answer slot: if you chose or defined how retention was counted, say how; if you did not, say so. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows presenting retention, not owning KPIs or a post-event review. Quote the presenting line only. Answer slot: if you ran a post-event review or set a KPI it reports, say what and how; if you did not, say so and say what you would review first. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is in use with QA, and you wrote it. Writing is not running every release. Answer slot: if you ran release sign-off with QA, say how; if QA ran it, say so. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | low | [grounded] | discovery | The material does not show cross-team coordination. Answer slot: name the teams you worked with on one content drop and how you kept them in step, in your own words. If the drops went through someone else, say so. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material says four years, a puzzle game and an associate title. It does not say live-service. Bridge: "For four years I was an associate producer at a puzzle-game studio." Answer slot: if asked what live work those four years included, say it in your own words. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A checklist QA still uses is written work people act on. Keep the bridge to that quote. |

**Stated gaps, not JD lines.** Your message says "Never led a team, and never worked on a game with in-app purchases." The JD names neither. Leadership may still come up through F6, and in-app purchases through the mobile KPIs. Both are handled in the banks and the prohibited list, not as fit rows.

**Pack observation, in analysis only:** the JD says "coordinate", not "lead". Your material shows neither leading nor coordinating a team; it shows a calendar you ran and a checklist you wrote.

## Persona table

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead. No interviewer profile was available and no loop source establishes this loop, so the archetype fallback is Generic: flat weights, said plainly.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quietly probes the gaps: no team led, no IAP work, live-service not shown | Highest. Your two stated gaps are the first things a hiring manager checks | Hold the one objection until it is boring. Use bridges from quotes only, then a plan, not a past |
| Case/Strategist | Live problems on a two-title calendar and a retention drop | High. The JD is a roadmap, and the hiring manager is buying judgement | Clarify, then structure, then name metrics and risks. Say what you would need to know first |
| Data-Driven Prober | Asks how retention was counted and what each number rests on | Medium-high. You presented retention numbers, so the question will come | Say how it was counted only if you know. Otherwise say so and name the weakest assumption you can see |
| Pressure | Time-boxed challenges on leadership and on how much was yours | Medium. A hiring manager may test composure on your gaps | Hold the true position through two follow-ups, then concede the gap plainly |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name the weakest part in your own words. The honest answer is your stated gaps, and naming them first is stronger than having them found. Then say how you would close the nearest one in the first month. | Your stated gaps are the most likely objection. Naming them yourself is the highest-ROI prep in this pack. |
| S2 | "You've never led a team. How would you coordinate design, art, engineering and community on each update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say plainly: "I haven't led a team." Then give a plan, not a past: how you would set one shared update plan, who owns each handoff, and when you would escalate. Do not describe coordinating teams you did not run. | F6 is the JD line this is aimed at. The question's premise is your own stated negative. |
| S3 | "I don't see in-app purchase work in your background. How would you handle it here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say plainly: "I haven't worked on a game with in-app purchases." Then say how you would learn the monetisation side with the team, in order. | The negative is yours and the acknowledgment is sourced to it. Stay away from any claim about purchase data you did not see. |
| S4 | "Puzzle games are not live-service. What actually transfers?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Name what carried over, using the quote's scope: four years, an associate role, a puzzle title. Do not claim live-service production. Answer slot: if you ran content on a live schedule, say what that involved in your own words. | F7 is the transferability bridge. The objection is likely, so the honest scope is the answer. |
| S5 | "Why leave, why here, why now?" | JD | [generic] | Give your own reason in your own words. Your material gives none, so this is a selection question, not a script: name the one reason you would stand behind, then why this studio, then why now. | Motivation is scored in every hiring-manager round. The pack cannot supply your reason. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the plan for the next two months across both titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before structure: title maturity, team capacity, what each title's retention is doing. Then the plan: a shared calendar, drop cadence, QA windows, a review point. Use the calendar you ran as the model, in your own words. | F1 is the calendar this case stands on. Name the clarifying questions before the plan. |
| C2 | "Retention dropped 20% in the week after a content drop. Diagnose it." | CASE | [generic] | Clarify: which cohort, which platform, which build, what else changed that week. Then branches: content, release, external. Name the metric you would check first and the assumption behind it. | A standard live-ops diagnosis. No claim about your past. |
| C3 | "Walk me through how you would structure a post-event review." | JD | [generic] | Structure: the goal, the metrics before and after, what went right and wrong, what changes next time, and who owns each action. | The JD makes the post-event review your responsibility, so the structure should be yours. |
| C4 | "On one update, how do you sequence design, art, engineering and community?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Name the order: scope and content lock, art and build, QA window, community comms, then the checklist sign-off. Reference the checklist only for the sign-off step you actually used. | F5 and F6. The checklist you wrote is the sequence anchor, but say only what you did with it. |
| C5 | "A limited-time event and a community push land the same week. What do you decide?" | CASE | [generic] | Structure: which metric each serves, what each costs in QA and engineering, what you would move, and who decides. Give a recommendation and name what would change it. | A live conflict in any two-title calendar. Judgement, not history. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how those retention numbers were defined and counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slot. If you know the definition and the window, say it. If you did not set it, say so. Name the assumption you would defend least. Answer slot: if you chose how retention was counted, say how; if the definition was set for you, say so. | F3 is the metric you presented. Never supply a window or definition you were not given. |
| P2 | "Which release checklist items did you write, and which did QA add?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say which items you wrote and which came later from QA. If you cannot separate them, say so. | F5. Precise attribution is the test here. |
| P3 | "How many content drops went out a month, and what decided what went in each one?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Give the cadence from your calendar. Name what decided each drop in your own words. Answer slot: if a drop slipped, say what you decided and what it cost. Never give a count you did not keep. | F2 and F1: a calendar you ran is the strongest proof you have. |
| P4 | "Which KPIs did you track, and which ones did you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you tracked and what you presented. Then the honest line: you presented retention; say whether you owned any KPI beyond that. Answer slot: if you set or reviewed a KPI you did not present, say what and how; if not, say so. | F4. The JD asks for KPI ownership; your quote shows presenting. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: "I haven't led a team." Then the case: what you have run end to end, the calendar and the checklist. Concede plainly: you would ramp into the lead role. Do not hold a claim of leading. | This is the composure test on your stated gap. Hold through two follow-ups, then concede the gap, not the work. |
| R2 | "Two titles, one producer. How do you not get overloaded?" | JD | [generic] | Hold the position with a plan: what you would cut, what you would hand off, and what you would escalate first. Do not describe a past capacity you did not carry. | A pressure question about the JD's two-title scope. No claim about your history is required. |
| R3 | "That retention result. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: "I presented those numbers." Then say which part of the result you influenced, in your own words, and which you did not. Concede the rest plainly. | Attribution under pressure. Presenting is not owning. |

## Prohibited claims

Each entry has its basis and its honest form. None of these is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." |
| Owned the post-event reviews and KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." |
| Led a team, or led cross-team coordination | Inflated form of F6, and a stated negative | "I haven't led a team." |
| Produced live-service games | Inflated form of F7 | "For four years I was an associate producer at a puzzle-game studio." |
| Managed the release process with QA | Inflated form of F5 | "Wrote the release checklist our QA team still uses." |
| Worked on in-app purchase monetisation | Stated negative | "I haven't worked on a game with in-app purchases." |

## Reverse questions

Five, each with why it lands. None is tied to the interviewer's own path, because no profile was available.

1. "What would success look like for the two titles in the first 90 days?" Why it lands: it turns the JD into a shared scorecard and shows you are planning for the role, not just applying.
2. "How do design, art, engineering and community decide what goes into an update today?" Why it lands: you show you understand the coordination problem before you say how you would solve it.
3. "Who reads the post-event review, and what has changed after one?" Why it lands: it tests whether the review is a real decision tool, which the JD's wording suggests.
4. "Which retention figures does the studio head look at, and how are they defined?" Why it lands: it opens the metric question you will be asked, and shows you care about definitions.
5. "When a live event underperforms, who decides whether to iterate or pull it?" Why it lands: it sets up your own judgement and shows you know decision rights in live ops.

## Sources

Provided documents: the JD text, your CV and background, and your message. No other documents.

Research tier: L1 — searches 0 of 6 returned results; 3 attempted, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. No values page was pasted and the search was refused. Dropped; the values round was not detected either |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure. The round is named by you as one hiring-manager session, which fixes the session count. The search was refused |
| 3. Saltmarsh Games strategy and recent news | unavailable | Competitive and CO questions. Would have fed a CO bank; none is written, so C2 and C5 stay generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. The name was given, so the query was formable; the search was refused |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: "Saltmarsh Games values"; "Saltmarsh Games interview process Live Operations Producer"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

Dropped sections: prep triage (no prep time given), graded deliverables (none declared), grounding brief, values cheat sheet, interviewer read, delivery coaching (no assessment provided). Each is absent because its input is absent, not because it was skipped.

## Upgrade menu

- A pasted copy of Saltmarsh's values page, or allowing web search → the values cheat sheet, the loop structure, and a grounded CO bank.
- Tobias Wrenfield's public profile or a pasted bio → the interviewer read, persona weights tuned to him, and a reverse question tied to his path.
- A copy of your content calendar → F1, F2 and P3 become inspectable proof rather than a claim you describe.
- The retention definition you used, in your own words → P1 and R3 can be answered from your own figure, not a slot.
- Your recruiter's note on what the round covers → confirms the session count and whether a presentation is expected.
- Your release checklist, or a list of the items you wrote → P2 and C4 can name them exactly.
