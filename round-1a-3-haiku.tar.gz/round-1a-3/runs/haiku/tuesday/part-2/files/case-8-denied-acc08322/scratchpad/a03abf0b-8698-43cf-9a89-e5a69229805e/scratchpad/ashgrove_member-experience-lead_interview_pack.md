# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Role: Member Experience Lead. Company: Ashgrove Credit Union. Candidate: Dara.
Rounds: three, on 29 November 2026 (loop mode). Interviewers: not yet assigned. Round 2 is with the Head of Member Services, who would be your manager; no name given.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores:

- **VAL**: values and behavioural alignment, against Ashgrove's four published values
- **EXP**: your own experience, and whether your claims hold up under questions
- **JD**: a requirement from the job description
- **CO**: company and strategy knowledge
- **CASE**: a live problem to structure out loud

Guidance is scaffolding, not a script. Say everything in your own words. Rehearse what you actually did, and say plainly where you did not.

## Prep triage (nine days to 29 November)

1. Write two real complaint cases from your branch. For each, write what the member said, what you decided, what you did, and how it ended, in your own words. Every values story and the panel case depend on these, and the pack has none of them yet.
2. Rehearse C5 aloud, timed at 20 minutes, twice.
3. Rehearse the two gaps out loud, not just in your head: B5 (presenting above regional level) and C6 and C7 (contact centre). Hold the part you did, then concede the part you did not.
4. Open the complaints spreadsheet. Know what it counts, and whether resolution time was in it (F4, F7).

Everything else is insurance.

## Fit snapshot

The rows are shared by all three rounds. Requirements are quoted from the job description you pasted; evidence is quoted from your message, which is the only background material given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Retail banking is financial services. Say it in the quote's terms: six years in retail banking, the last three as a branch supervisor. Expect a probe on how much of the six years was customer-facing. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints, not regulated ones. Answer slot: if any complaint on the log carried a regulatory or ombudsman timeline, say which and how you kept to it; if none did, say so and say how the log was kept. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment, from your own words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. Add nothing to make the gap feel smaller. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. The spreadsheet is inspectable, so bring it. Expect a probe on which functions you used and what it counted. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is one branch's log. Say it at that scope. The limit is the pack's own observation: your material shows one branch's complaints, not the end-to-end process across branches. Answer slot: if any part of the process beyond the log was yours to set, say which and how; if not, say so plainly. |
| F6 | "across branches and the contact centre" (JD, the contact-centre part of F5) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn the contact centre's side of a complaint, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The quote reaches monthly reporting. It does not show volumes or resolution times. Answer slot: if the spreadsheet held resolution times or volumes, say which and how they were counted; if it held neither, say so plainly. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The quote is tellers, not supervisors. Say the training as it was. Answer slot: if you coached a supervisor through an escalation, say how; if you did not, say so and say how you would approach it. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. The words are an answer slot: if you worked on any digital step in a complaint journey, say what; if you did not, say so and say what you would map first. |

Gap type follows the evidence cell. There are no gate requirements here: experience length and experience type are graded on fit, not treated as gates.

## Prohibited claims

Each entry names its basis. None of these may be asserted, implied or probed in any answer, slot or reverse question in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or managed a contact centre | Stated negative, F6 | "I've never worked in a contact centre." |
| Has presented to senior leaders | Stated negative, F3 | "I haven't presented to anyone above regional level." |
| Owned the complaints process end to end | Inflated form of F5 | "I handled the branch's formal complaints log." The limit is the pack's observation: one branch's log. |
| Wrote or set the escalation policy or script | Inflated form of F8 | "I trained new tellers on our escalation script." |
| Tracked or reported resolution times | Inflated form of F7 | The spreadsheet quote, with the answer slot on what it held. |
| Handled regulated complaints | Inflated form of F2 | The F2 answer slot: say which timelines applied, if any did. |

## Persona weights, by round (loop mode)

| Round | Relationship | Persona weights | Why |
|---|---|---|---|
| 1. Recruiter screen, 30 min | Recruiter | Conversational (top), Skeptic, CO | The recruiter screen checks logistics, motivation and knockouts in a friendly register. Pay, notice, location and reason for leaving are logistics slots. |
| 2. Head of Member Services, 45 min | Future manager | Values/Behavioral (top), Skeptic, Data-Driven Prober, Case | You said mostly behavioural. The manager is buying capability and derisking the presenting and regulated-complaint gaps. |
| 3. Panel of two branch managers, 60 min | Peers, senior to you | Values/Behavioral (top, one question per value), Case, Pressure, Peer Evaluator, Prober | The panel scores against the four values, runs the 20-minute escalation case, and is peer-weighted because both members run branches. |

## Round 1: recruiter screen (30 minutes)

Persona weights: Conversational 5 (A1 to A5), Skeptic 2 (A6, A7), CO 1 (A8).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk us through your background, starting with your six years in retail banking." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give the years and the role in the words above, then stop. The interviewer will ask for detail. | F1 is the 4+ years requirement; the screen checks the number first. |
| A2 | "What are your salary expectations?" | JD | [generic] logistics slot; no figure given | Logistics slot. Give your own figure in your own words, or ask what the band is first. No figure is stated in your material, so none is supplied here. | Pay is a knockout check; the answer is yours alone. |
| A3 | "What's your notice period?" | JD | [generic] logistics slot; no figure given | Logistics slot. Give your actual notice period in your own words. None is stated in your material, so none is supplied here. | Notice is a knockout check. |
| A4 | "Where are you able to work, and how far can you travel between sites?" | JD | [generic] logistics slot; no location given | Logistics slot. Name the locations you can work from in your own words. None is stated in your material, so none is supplied here. | Location is a logistics check the consolidation makes more pointed. |
| A5 | "Why are you looking to leave your branch role?" | EXP | [generic] logistics slot; no reason given | Logistics slot. Give your reason in your own words, and keep it to the reason and the role you want next. None is stated in your material, so none is supplied here. | A reason-for-leaving logistics slot; the answer is yours to give. |
| A6 | "How comfortable are you with Excel for reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet holds, in the quote's terms. Answer slot: if you can say its columns, any formulas, or whether it counted cases or times them, say so in your words. If you cannot, say so plainly. | F4 is the evidence for the Excel requirement; the spreadsheet is what you will be asked to show. |
| A7 | "You haven't worked in a contact centre, have you?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn the contact centre's side of a complaint, as a plan. | F6 is a stated gap the recruiter may raise; the answer should be ready before the question lands. |
| A8 | "What do you think of the plan to move 40% of member service to digital by 2028?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (July 2026 brief, as you summarised it) | Say what a member-side complaints lead should protect as service moves online, and why, in terms of the member. Do not describe digital work you did: your material has none (F9). | The July brief is the strategy the screen will test; the answer shows altitude. |

Reverse questions:

| Question | Why it lands |
|---|---|
| "What does complaints work look like day to day, across the branches and the contact centre?" | Tests the scope of F5 and shows you read the role as end to end. |
| "How is the move to digital channels changing the complaints you see?" | Shows you read the July brief, and asks about the world rather than about yourself. |
| "Which of the eight branches go into which hubs, and when does the complaints team move with them?" | Ties the 2027 consolidation to the role directly. |
| "Who will sit on each round, and is there anything the panel will score that the job description does not say?" | Gets the values scoring spelled out before round 3. |
| "What would make this screen a good call for both of us?" | Surfaces the recruiter's knockout list in their own terms. |

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

Persona weights: Values/Behavioral 3 (B1, B6, B7), Skeptic 2 (B2, B5), Data-Driven Prober 2 (B3, B4), Case 1 (B8).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you ran the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Tell the log in the quote's terms: you handled it. Then the steps from receipt to close, in your own words. Answer slot: if a decision on a complaint, such as its outcome or its escalation, was yours to make, say which and how; if it was not yours, say so plainly and describe your part. | F5 is the end-to-end requirement and the likeliest place to be probed. |
| B2 | "Which complaints on the log carried a regulatory or ombudsman timeline, and how did you track it?" | JD | [grounded] "I handled the branch's formal complaints log" | The JD names regulated complaints, which your material does not establish. Answer slot: if any complaint carried a timeline, say which and how you kept to it. If none did, or you did not track one, say so plainly and say how the log was kept. | F2 is the requirement with a discovery gap, and the one the manager is most likely to test. |
| B3 | "Take us through the monthly complaints spreadsheet: what it holds, and what your regional manager uses it for." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe what the sheet holds, in the quote's terms. Answer slot: say whether it recorded complaint volumes, resolution times, or both. If it recorded only one, say which; if neither, say so plainly. | F4 and F7. Volumes and resolution times are both in the JD; the spreadsheet is the proof. |
| B4 | "Each month, how would you report complaint volumes and resolution times to the leadership team?" | JD | [generic] | Structure it: what you would count, how you would define resolution time, where the data would come from, and what you would show first. Make no claim about past reports. | The JD's monthly reporting duty; resolution time is the figure your material does not show. |
| B5 | "You've never presented to anyone above regional level. Why would we trust you in front of our senior team?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold, do not add. Plain acknowledgment: "I've never presented to anyone above regional level." Hold through one follow-up by pointing to the work your regional manager already uses: "the monthly complaints spreadsheet our regional manager uses." Concede the senior room is untested. Then state how you would prepare for a first presentation above regional level, in steps, as a plan. | F3 is the stated gap in the JD's presenting requirement. This is the objection the pack names as highest-ROI prep: rehearse it until it is boring. |
| B6 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story map: you trained tellers on the escalation script. The beats are who you trained, the script, and what they did with it. Answer slot: the JD asks you to coach supervisors, so if you coached one through a live escalation, say how; if you only trained tellers on the script, say so and say how you would coach a supervisor. | F8. The JD names supervisors; your material names tellers. |
| B7 | "Tell me about a time you had to tell a senior colleague a complaint was being handled badly." | VAL | [generic] persona stem | Scaffold: pick a time you said something a senior person did not want to hear about a complaint, with a named stake and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log," and what you did with it. | The stem is a Values/Behavioral story; your material shows no such moment, so the scaffold ends in the honest branch. |
| B8 | "You've never worked in a contact centre. What would you check first in one whose complaints you were asked to own?" | CASE | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then a structured answer: what you would check first, such as how complaints are routed, how fast a first response goes out, and how a case passes into a branch. Say it as what you would check, not what you have seen. | F6, the contact-centre gap, asked as a live problem. |

Reverse questions:

| Question | Why it lands |
|---|---|
| "What does a good first ninety days look like in this role?" | Lets you ask about the supervisor coaching you would own (F8) and shows you plan. |
| "Where do escalations most often stall: inside a branch, between branches, or between a branch and the contact centre?" | Tests the seam in F5, and the answer tells you which part of B6 matters most. |
| "How are the complaints numbers used today, and who reads them?" | Puts the reporting in B3 and B4 in front of its real audience. |
| "Which digital self-service journey comes first, and where would the complaints team come in?" | Links the JD's digital requirement (F9) to the work, and asks about the world. |
| "What would you want the next person in this role to have done in their first quarter?" | Asks for the scoring criteria without asking for the scorecard. |

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

Persona weights: Values/Behavioral 4 (C1 to C4, one per published value), Case 1 (C5), Pressure 1 (C6), Peer Evaluator 1 (C7), Data-Driven Prober 1 (C8).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" | Open prompt. Scaffold: pick a complaint where the member's side and the process pointed different ways. Say what you did and what the member got. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log" (F5), at its own scope. | VAL1. None of your four values is yet backed by a story in your material. |
| C2 | "Tell us about a time a member needed something explained twice." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" | Open prompt. Scaffold: pick a case where you changed how something was explained, and what changed. The nearest thing your material carries is "trained new tellers on our escalation script" (F8): say what you changed in the teaching, if anything. If nothing changed, say so. | VAL2. The teaching sentence is the nearest; it does not show plain words on its own. |
| C3 | "When did a number you reported point one way while your town pointed the other?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" | Open prompt. Scaffold: pick a figure you had to report that a branch or its customers needed to read differently. If none, say so plainly, then give the nearest thing: "I built the monthly complaints spreadsheet our regional manager uses" (F4), and what it did and did not show about the branch. | VAL3. Your reporting is the place this value bites, so it needs its own story. |
| C4 | "Tell us about a problem you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" | Open prompt. Scaffold: pick a problem you found and kept until it closed. Say what held you to it and how you knew it was solved. If none comes to mind, say so plainly, then give the nearest thing: "I handled the branch's formal complaints log" (F5), and what you kept hold of through a case. | VAL4. Holding a case to closure is the value; your log is the nearest evidence. |
| C5 | "A member has escalated a complaint about a charge for the third time. The branch says the charge was right, and the member says the explanation made no sense. Walk us through the next 20 minutes." | CASE | [generic] | Rehearsal case. The panel's real case is not known; rehearse this one so the structure is automatic. Structure: what the member is asking for; the file, what was said and what was written; who owns the fix today; a call back with a plain-words explanation; what you would record and report. Say the structure aloud before the detail. Make no claim about your past. | The 20-minute case, and the escalation work the JD names. A rehearsal, not a prediction. |
| C6 | "Sixty seconds: why should a panel of branch managers trust a branch complaints log to run work across a contact centre?" | Pressure | [grounded] "I handled the branch's formal complaints log"; [grounded] "Never worked in a contact centre" | Hold, then concede. Hold through two follow-ups on the branch work you did (F5). Concede the contact-centre part plainly: "I've never worked in a contact centre." Then what you would do first, as a plan. Do not extend the log beyond the branch. | F5 and F6. Panel pressure lands on the scope of the log, and the concession has a source. |
| C7 | "Our branches and the contact centre share complaints. Where does your side stop and ours start, and what happens when we disagree?" | JD | [grounded] "Never worked in a contact centre" | Propose seam principles, not a seam you have seen: one case owner, one record, agreed handover times. Concede plainly: "I've never worked in a contact centre." Then what you would ask the contact-centre lead first. | F5 and F6 on the peer seam. Branch managers will test whether you can work across a boundary you have not crossed. |
| C8 | "Which complaints figure would you check first before trusting a monthly report, and why?" | JD | [generic] | Name the figure you would check first, such as the resolution-time definition or the open count. Name the assumption you would test, and what you would do if it failed. No figure from your past. | The JD's monthly reporting duty, asked as a judgement. Generic because no sentence of yours describes a report's assumptions. |

Reverse questions:

| Question | Why it lands |
|---|---|
| "When a branch manager and a complaint outcome disagree, who decides, and how is it recorded?" | Shows you think about decision rights, which C4 and F5 depend on. |
| "What could a new person do in their first month that would genuinely help your branches?" | Reciprocity with peers. Shows you are thinking about their load, not only yours. |
| "Which escalations come up most in your branches, and which are hardest to close?" | The answer is the seam in C7 and the shape of the 20-minute case; it tells you what to prepare. |
| "What would you want a complaints lead to have changed by the end of year one?" | Asks for the scoring criteria without asking for the scorecard. |
| "How did one of the four values show up in a decision you made last month?" | Shows you want the values as behaviour, not slogans. Branch managers score them. |

## Values cheat sheet (round 3)

Ashgrove's four published values, as you pasted them from ashgrovecu.org/about/values on 20 November 2026. No value has a verified story yet.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F5 carries no decision from the member's side, so the story is a selection scaffold: C1. If none comes, say so, then give F5 at its own scope. |
| Plain Words | If a member needs it explained twice, the writing was wrong | No row carries plain words. Selection scaffold: C2, using F8 as the nearest thing, with the honest branch. |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries this. Selection scaffold: C3, using F4 as the nearest thing, with the honest branch. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5 is the nearest thing; it shows handling, not holding to closure. Selection scaffold: C4, with the honest branch. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B5, C6 |
| Comfortable with Excel reporting | A6, B3 |
| Own the member complaints process end to end across branches and the contact centre | B1, B8, C6, C7 |
| Report monthly on complaint volumes and resolution times | B3, B4, C8 |
| Coach branch supervisors on escalations | B6, C5 |
| Work with digital teams on self-service journeys | A8, and the round 2 reverse question on the digital journey; no dedicated question, because your material shows no digital work (F9) |

## Sources

Provided documents:

- Recruiter email: three rounds on 29 November; round 2 is with the Head of Member Services, mostly behavioural; the panel scores against the four values.
- Job description, as pasted in your message.
- Ashgrove values, as copied from ashgrovecu.org/about/values on 20 November 2026.
- Strategy summary from the July 2026 brief, as you summarised it. The brief itself was not provided.
- Your background, in your message.

Research tier: L1, searches 0 of 6, fetches 0 of 2. No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values copy fixes the four names and meanings for the values cheat sheet. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the loop structure and the persona weights. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes question A8. Anything published after July 2026 is not covered; the upgrade menu offers a sweep. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative job description | skipped | The job description you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Two real complaint cases from your branch, in your words → turns the scaffolds in B7, C1 to C4 into grounded stories, and the panel case in C5 into one you have actually lived.
- What the complaints spreadsheet counted, and whether it held resolution times → resolves F7 and B3 from discovery to a stated fact.
- Whether any complaint on the log carried a regulatory or ombudsman timeline → resolves F2 and B2.
- The round 2 and round 3 interviewers' names → persona weights and tailored reverse questions, read from their public footprint.
- A sweep of Ashgrove news since the July 2026 brief, at L1 → grounds A8 in current moves, not a summary from July.
- The full July 2026 brief, if the recruiter will send it → a grounding section of recent moves and vocabulary.
- The panel's 20-minute case brief, if they will share one → replaces the rehearsal case C5 with the real one.
