# Ashgrove Credit Union: Member Experience Lead interview pack (loop)

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Interviews:** 29 November 2026, three rounds, one day

| Round | Length | Who | Relationship | Scored on |
|---|---|---|---|---|
| 1 | 30 min | Recruiter | Screen | Logistics, motivation, consistency |
| 2 | 45 min | Head of Member Services (your future manager), mostly behavioural | Hiring manager | Capability and derisking the gaps |
| 3 | 60 min, including a 20-minute complaint-escalation case | Panel of two branch managers | Peers; this is the values round | The four published values |

Interviewers for rounds 2 and 3 are not yet named, so there is no interviewer read. Persona weights come from the round-type priors and the recruiter's own description of each round.

**Built as:** loop mode. One shared fit snapshot, then one mini-pack per round.
**Changelog:** first version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Guidance is scaffolding, not a script.** Say the words in your own voice, and only the things you actually did.
- Type key: **VAL** = behaviour against the published values. **EXP** = what you personally did in past work. **JD** = a stated responsibility or qualification, including the gaps. **CO** = the company's strategy and recent moves. **CASE** = a live problem from the role.
- Row IDs: **F** = fit snapshot rows. **A**, **B**, **C** = questions in round 1, 2 and 3.

## Fit snapshot (shared across all rounds)

Every evidence cell holds only your own sentences, quoted exactly. Your background arrived as a message, not a CV, so every confidence band is capped at medium until a document is seen.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Words: "6 years in retail banking, the last 3 as a branch supervisor." Your material shows branch work, not a customer-operations function by name. Say the branch facts in your own words and let the interviewer map them. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Words: "I handled the branch's formal complaints log." Answer slot: say which rules or deadlines the log had to meet, if any, and how you met them. If it had none, say so, then describe how you handled each complaint on it. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Words: that sentence. The tool is yours to name. "Excel" is the posting's word, not your material's, so do not adopt it unless you use it. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | low | [grounded] | transferability | Words: "I handled the branch's formal complaints log." The material shows one branch and no end-to-end ownership. Say what you did at the branch and stop there. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." The material shows tellers, not supervisors. Your three years as a branch supervisor are the adjacent part; say what you did as one, in your own words. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or self-service team, say what you did. If not, say so, and say what you would bring from the branch side of a member's journey. |
| F8 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Answer slot: say which measures the spreadsheet held, complaint volumes or resolution times, in your own words. If it held neither, say so. |
| F9 | "across branches and the contact centre" — JD | "I've never worked in a contact centre." — your message | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan. |

**Gate rows: none.** The posting states no location, schedule, credential or pay term. Pay, notice and location appear only as recruiter logistics in round 1.

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, A7 |
| experience handling regulated complaints | B6 |
| confident presenting to senior leaders | B5 |
| comfortable with Excel reporting | B7, B8 |
| Own the member complaints process end to end across branches and the contact centre | A6, B9, C5 |
| report monthly on complaint volumes and resolution times | B7 |
| coach branch supervisors on escalations | B4, C8 |
| work with digital teams on self-service journeys | C7 |

## Grounding brief (from the 2026 strategy brief, as you summarised it)

These are your summary's words. The brief itself was not supplied, so the pack quotes your wording, not the brief's. Ask for the brief if you want exact phrasing.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- Main competitive pressure: app-only banks.

No stale framings were found in the material supplied.

## Prohibited claims

Built locally from the fit snapshot. None of these may be coached, in any round, in any words.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F5 and F9 | F5's quote at its own scope: "I handled the branch's formal complaints log." Limit, as the pack's analysis: the material shows one branch's log and no contact-centre work. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script." Limit, as analysis: tellers, not supervisors. |
| Built complaint reporting on volumes and resolution times | Inflated form of F8 | "I built the monthly complaints spreadsheet our regional manager uses." Limit, as analysis: which measures it held is not shown. |
| Regulated complaints handling to the regulator's standard | Inflated form of F2 | "I handled the branch's formal complaints log." Limit, as analysis: regulated status is not shown. |
| Excel expert, or naming a tool you have not named | Inflated form of F4 | The spreadsheet quote at its own scope. The tool is yours to name. |
| Presented to senior leaders | Negative you stated, F3 | Plain acknowledgment: "I've never presented to anyone above regional level." |
| Worked in a contact centre | Negative you stated, F9 | Plain acknowledgment: "I've never worked in a contact centre." |

---

## Round 1: Recruiter screen (30 min)

**Persona weights:** Conversational 5 (the screen's register, depth 4 to 5). Skeptic 3 (light; motivation and knockouts). Prober: not expected at a screen; its round 2 ground is B7.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | An opening walk-through, then logistics asked casually | High. A screen opens with the story and the basics, and casual logistics are still scored. | A 90-second arc in your own words. Answer logistics with your own figures or a choice of options. |
| Skeptic (light) | Two or three probes on the contact centre and your motivation | Medium. Recruiter screens check knockouts and consistency. | Plain acknowledgment, then the nearest thing you did. Give honest limits. |

### Question bank (round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | A 90-second arc: the six years, the last three as a supervisor, the complaints log you handled, the tellers you trained on the escalation script. Stop there. Add nothing you have not said here. | The opener in every screen. It carries F1 and F2, so an arc that reaches past them will be probed in round 2. |
| A2 | "What's your notice period?" | JD | [generic] recruiter-screen logistics pattern | Logistics slot: give your actual notice period in your own words. If you are not sure, say so and say when you will know. | Notice is a recruiter logistics item. No figure is supplied because your material has none. |
| A3 | "What are your pay expectations?" | JD | [generic] recruiter-screen logistics pattern | Logistics slot: give your own figure, or ask first what the band is. Decide before the call which you will do. This pack supplies no range, floor or history. | Pay is a recruiter logistics item. No number is given because you gave none. |
| A4 | "Where are you based, and what travel can you do?" | JD | [generic] recruiter-screen logistics pattern | Logistics slot: name the location you work from and any limit you actually have, in your own words. | Location is a logistics item. The posting states no location term, so this is not a gate row. |
| A5 | "Why are you thinking about leaving your current role?" | EXP | [generic] recruiter-screen logistics pattern | Logistics slot: give your own reason in your own words. Your material gives none, so this pack supplies none. Keep it true and short. | Reason for leaving is a logistics item. Motivation consistency is the Skeptic's ground, asked in a friendly register. |
| A6 | "The role covers our contact centre as well as branches. What's your experience there?" | JD | [grounded] "I've never worked in a contact centre." (plain acknowledgment, your message) | Say it plainly: "I've never worked in a contact centre." Then the nearest thing your material does carry: the branch complaints log and the escalation script you trained tellers on. Give your plan for learning the contact centre as a plan, not as a past. | The most predictable screen objection, aimed at F9. The posting raises the contact centre, so the question is fair. |
| A7 | "You've spent six years in branches. What makes this role the step you want?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer in your own words. Your material gives no motive, so the pack supplies none. Name the reason you actually have, in one or two sentences. | Motivation consistency. The premise, six years in branches, is quoted in full. |
| A8 | "What have you read about Ashgrove?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you summarised it) | Name one or two things from the brief in your own words: the digital shift, branch consolidation, small-business lending, app-only competition. Say nothing beyond what the brief states. | Screens test homework. The answer is judged on what you can say accurately, not on how much you know. |

**Reverse questions (round 1)**

- "Where do complaints come from most often across the branches and the contact centre?" Why it lands: shows you think about the seam from the start.
- "What would a good first six months look like in this role?" Why it lands: signals you are thinking about the job, not only the offer.
- "What happens after this screen?" Why it lands: a plain process question, asked early, that the recruiter answers well.

---

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona weights:** Values / Behavioral 4 (the recruiter says the round is mostly behavioural). Skeptic 3 (the manager is buying capability and derisking the gaps). Pressure 2. Case / Strategist 2. Prober: low; its ground is B7.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | STAR-shaped prompts about past complaints, escalations and members | High. The round is described as mostly behavioural, and the manager will expect stories. | Map a story to each value where a quoted sentence carries one. Where none does, use the selection scaffold and its honest branch. |
| Skeptic | Quiet probes on the presenting gap, the regulated work and the spreadsheet | High. The JD's headline asks are the gaps, and a manager derisks gaps. | Plain acknowledgment on each stated gap, then the nearest thing you did. Rehearse B5 until it is dull. |
| Pressure | Interruptions and a challenge to the contact-centre absence | Medium. It shows up as a stress test of the stated absences. | Hold through two follow-ups, then concede specifically. |
| Case / Strategist | The branch network, and a stuck complaint | Medium. Shows up as one strategy question and one live problem. | Clarify, objective, segmentation, approach, metrics, risks. Say the framework briefly. |

### Question bank (round 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you followed all the way to a close, not just to a reply." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, not a story: pick a complaint you took from first contact to a resolution the member accepted. Say what you did at each step, in your own words. If none reached a close you can describe, say so plainly, then give the nearest one from the log. | Own the Fix is a published value and will be scored. The log sentence is the nearest thing your material carries. It does not show a path to close, so the pack does not supply one. |
| B2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: a time you explained a decision, had to explain it again, what you changed in the words, and whether it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the script you trained tellers on. | Plain Words is a published value. An answer that shows a changed explanation scores better than one that restates the value. |
| B3 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: a decision where a member's outcome cost you a number you were measured on, and what you did about the number afterwards. If you have no such decision, say so, then say how you would decide it now. | Members First is a published value. No quoted sentence of yours carries a member-over-target decision, so the cell supplies only the selection and the honest branch. |
| B4 | "Tell me about a time you coached someone through an escalation they found hard." | JD | [grounded] "trained new tellers on our escalation script" | Selection scaffold: a time you coached someone on an escalation, what you asked them, what they did. Say whether that person was a teller or a supervisor. If you only trained people on the script, say so, and describe that. | The role coaches branch supervisors. Your material shows tellers, and the pack records that as a limit in its analysis, not as words for you. |
| B5 | "This role needs you to be confident presenting to senior leaders. You've never presented above regional level. How do you see that going?" | JD | [grounded] "I've never presented to anyone above regional level." (your message); raised by the JD line "confident presenting to senior leaders" | Hold, then concede. Hold through two follow-ups on what your material does show: "I built the monthly complaints spreadsheet our regional manager uses." Concede the gap in your words: "I've never presented to anyone above regional level." Then say how you would learn it, as a plan. Never describe a presentation you did not give. | **Highest-ROI prep in this pack.** The JD's headline ask meets the one stated absence. The second follow-up ("but you would present to our leaders?") breaks any bluff. |
| B6 | "Was your complaints log subject to any rules or deadlines? If so, which?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); raised by the JD line "experience handling regulated complaints" | Answer slot: if the log had rules or deadlines, name them in your own words and say how you met them. If it had none, say so plainly, then describe how you handled each complaint on it. Name no rule you cannot name. | F2's gap. The question is open, so it presupposes nothing, and either branch is honest. |
| B7 | "Walk me through the monthly complaints spreadsheet. Which measures did it hold?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what the spreadsheet counted, in your own words. Say whether it held complaint volumes, resolution times, neither, or both. Give no figure you cannot repeat under a second question. | F4 and F8. The JD asks for monthly volumes and resolution times, and your material does not show which were on the sheet. This is the only prober ground in the pack. |
| B8 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold, then concede. Hold through two follow-ups on what you built: the sheet itself. Concede specifically what is not yours, such as how the regional manager used it, or any figure they took from it. Never fold on the build. | Pressure answers are scored on holding and conceding, not on content. The position held is the one the quote carries. A stronger claim is the one a second follow-up breaks. |
| B9 | "This role covers the contact centre, and you've never worked in one. Why shouldn't I look for someone who has?" | JD | [grounded] "I've never worked in a contact centre." (plain acknowledgment, your message); raised by the JD line "across branches and the contact centre" | Hold, then concede. Hold on the part of the job you have done: complaints logged and escalations trained for tellers. Concede in your words: "I've never worked in a contact centre." Then give the plan for closing it, as a plan. | F9. The objection is aimed at a stated absence, so answer it without defence. |
| B10 | "What do you know about where the branch network is heading?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it) | Say what the brief states, with its own numbers, and nothing beyond it. Then one question you would ask about complaints during a change like that, framed as a question. Do not claim to know how the hubs will run. | CO questions test altitude. Your strategy knowledge is limited to the brief, so the pack gives no more. |
| B11 | "A member's complaint has been open for a month while two teams each say it belongs to the other. What would you do first?" | CASE | [generic] | Walk it in order. Clarify who owns the complaint and what the member has been told. Set the objective: one owner, and the member answered. Split it into what is stuck and why. Choose the approach: name the owner, set a date, tell the member. Name what you would measure: days open, repeats. Name the risk: a member lost, or a complaint closed wrongly. | A live problem from the role. It asks about no past, so it presupposes nothing about you. Structure is what is scored. |

**Reverse questions (round 2)**

- "How will you judge the first year in this role?" Why it lands: the manager has to name a measure, and you can show you would own the volume and resolution-time work.
- "Which part of complaints handling would you most want fixed in the first 90 days?" Why it lands: shows you are after their priority, which is what they score.
- "How is the move to five hubs shaping the complaints work so far?" Why it lands: shows you read the brief and ask about the change, not about yourself.

---

## Round 3: Panel of two branch managers (60 min, including a 20-minute escalation case)

**Persona weights:** Values / Behavioral 4 (the recruiter says this round scores the four values). Peer Evaluator 3 (two branch managers are peers in the business). Case / Strategist 2 (the escalation case). The panel blends values and peer, per the relationship priors.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One scored prompt per value, from people who run branches | Very high. The recruiter says the panel scores against the four values. | One story per value, where you have one. Where you have none, the selection scaffold and its honest branch. |
| Peer Evaluator | Seam questions, shared-credit questions, the digital seam | High. Branch managers test whether you take their turf. | Seam principles, not a map you do not have. Reciprocity: what you bring to their teams. |
| Case / Strategist | The 20-minute escalation case, then one follow-up | High. The case is declared. | Clarify first, then the framework. Follow up on the stop, not the add. |

### Question bank (round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter when the process pointed the other way." | VAL | [generic] | Selection scaffold: a decision you made for a member against the process, what the process said, what you did, and what it cost. If you have none, say so, then give the nearest one from your complaints work, in your own words. | Members First. The panel will press for the cost. A decision with no cost is the first thing they probe. |
| C2 | "Tell me about a time you changed how something was said to a member because they didn't follow it." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: a change you made to the words, what you changed, and how you know it worked. If none, say so. The nearest thing your material carries is the script you trained tellers on: say what it asked them to say, and whether you changed it. | Plain Words. The panel tests whether you rewrote something or only asked for clearer words. |
| C3 | "Tell me about a decision that landed harder on one town or one branch than on the others." | VAL | [generic] | Selection scaffold: a decision whose effect was local, what you did for that community, and what you could not fix. If you have none, say so, and say how you would weigh the local cost now. | Neighbours, Not Numbers. A hub consolidation tests this value. Your material carries no such decision, so the pack supplies none. |
| C4 | "Tell me about a problem you found that someone else was meant to fix, and what you did about it." | VAL | [generic] | Selection scaffold: a problem you found, whose it was, what you did to keep hold of it until it was solved, and where it ended. If you did not keep hold of one, say so, then say what you would do now. | Own the Fix. The panel scores whether you stayed with it. A story that stops at the handover does not show ownership. |
| C5 | "Where's the seam between a branch and the contact centre on a complaint, and what happens when we disagree about who owns it?" | JD | [generic] | Propose seam principles, not a map you do not have: one owner per complaint, one record, one answer to the member. On disagreement: if you have disagreed with an equal, say what it was and how it ended. If not, say how you would settle one. Say what you would bring to their team, not only what you need from it. | Peer Evaluator. The seam is the JD's "across branches and the contact centre." Reciprocity is the second half of a good answer. |
| C6 | "How do you handle credit when a complaint fix needs two teams?" | JD | [generic] | Name who you would make the owner, and how you would credit the work to the teams that did it. Claim no credit you did not earn. | Peer Evaluator. Credit-sharing is probed with equals, and the answer is judged on fairness. |
| C7 | "What should a self-service journey do when a member still wants a person for a complaint?" | JD | [generic] | Answer from the member's side: the journey should pass a complaint to a person without losing what the member already entered, and you should say how you would test it. Answer slot: if you have worked with a digital or self-service team, say what you did in your own words. If not, say so, and say what you would bring from the branch side. | F7. Your material shows no digital or self-service work, so this is an answer slot, not a claim. |
| C8 | "A member has complained about the same fee three times at one branch. The third complaint has been escalated to you, and the branch manager says the member is moving their account to an app-only bank. What do you do, and in what order?" | CASE | [generic] (a practice scenario written for this pack, not the actual case) | Walk it in order. Clarify: what the fee is, what the member has been told, what policy and rules apply, and by when. Objective: one answer the member accepts, and the complaint closed properly. Segmentation: one member, or a pattern across the branch? Approach: get the facts from the log; have the branch manager explain the fee in the member's words; decide the fix or the route; put the answer in plain words. Metrics: days open, repeats on the same fee, whether the fix holds. Risks: a rule missed, a fix that only moves the complaint, losing the member. Close with Own the Fix: name who holds the complaint until it is solved. | Scored on structure before the answer. The scenario is a pattern, not a fact about you, so nothing here is claimed on your behalf. Replace it with the real case brief if you get one. |
| C9 | "Your fix holds here, but the same fee complaint turns up at the next branch. What now?" | CASE | [generic] | Go back to the segmentation: is it the fee, the policy, or how the branches explain it? Propose one check across branches and one owner. Say what you would stop doing, not only what you would add. | The follow-up tests whether your first answer was a fix or a symptom. An answer that keeps adding steps without a stop is the one panels mark down. |

**Reverse questions (round 3)**

- "What do you wish the complaints process did better today?" Why it lands: the panel gives you an honest seam, and your first answer can build on it.
- "What could a new person in this role do in their first month that would genuinely help your branch?" Why it lands: a reciprocity question for peers. It turns a test into a working conversation.
- "Which of the four values is hardest to show on a branch day?" Why it lands: invites a plain answer on how they score, and shows you have read the values.

---

## Values cheat sheet (round 3 is the values round)

Your material carries no decision story for any of the four values, so every row is a selection scaffold ending in its honest branch. Rows cite the fit-snapshot row where a nearby sentence exists. That sentence is a starting point, not a story.

| Value (official name) | Working meaning (paraphrased) | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: a decision you made for a member against the process, with its cost (C1). If none, say so; the nearest is F2's "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Scaffold: a change you made to how something was said, and how you knew (C2, B2). If none, say so; the nearest is F6's "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: a decision that landed locally, and what you could not fix (C3). If none, say so and say how you would weigh the local cost now. The hub plan will make this a probe. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: a problem you found and kept hold of to the end (C4, B1). If none, say so and say what you would do now. |

---

## Sources

- **Provided documents:** your message, which holds the JD text, the four values as copied from ashgrovecu.org/about/values on 20 November 2026, the recruiter's email, your background, and your summary of the July 2026 strategy brief (the brief itself was not supplied).
- **Searches sent:** none. **Fetches sent:** none.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The values you pasted fix the four names and their wording, so no search could move them. |
| 2. Interview process, member services | skipped | Loop structure. The recruiter's email fixes the three rounds, their lengths, their relationships, and the values scoring. |
| 3. Strategy and recent news | skipped | Grounding brief and CO questions. The strategy points you supplied are the current source. |
| 4. Interviewer name (Head of Member Services, branch managers) | n/a | No names were given, so there is no query. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your CV as a document** → rows F1, F2, F4, F5, F6 and F8 are graded on your own wording now. A CV with dates, titles and the complaints work listed would let those rows be graded on a document.
- **Column headings from the monthly complaints spreadsheet** (no member data) → F8 and B7 name the measures it held, instead of answer slots.
- **Names of the Head of Member Services and the two branch managers** → persona weights from their public professional footprint, and a tailored reverse question per round.
- **The recruiter's case brief for round 3** → replaces the practice scenario in C8 and C9 with the real case and its scoring criteria.
- **Prep time before 29 November** → adds a prep-triage section, sized to the hours you have.
- **Deep research (L2), offered once:** up to 6 more searches and 2 fetches, on the full strategy brief text, public talks by Ashgrove's leaders, and recent Ashgrove news. It adds a few minutes and runs only if you say yes.
- **A tuesday-dossier.md, if one exists** → verified evidence and the rehearsed objection per weak area. Read if present; not needed.
