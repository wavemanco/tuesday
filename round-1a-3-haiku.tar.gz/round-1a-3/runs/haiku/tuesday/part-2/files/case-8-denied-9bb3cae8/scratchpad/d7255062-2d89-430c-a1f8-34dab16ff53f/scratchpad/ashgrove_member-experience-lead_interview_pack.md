# Interview prep: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara, 20 November 2026. Interviews on 29 November 2026 (9 days).
Mode: loop mode, three scheduled rounds.
Changelog: first version.

Interviewers: the recruiter (30 min); the Head of Member Services, your future manager (45 min, mostly behavioural); a panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). Names for the second and third rounds are not yet assigned. The interviewer read is therefore omitted, and persona weights rest on round priors.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores.
- Type key: **VAL** values and behaviour. **EXP** your own record, under scrutiny. **JD** a listed requirement. **CO** company and strategy. **CASE** a live problem.
- Provenance: **[grounded]** traces to a document or to a sentence you wrote. **[inferred]** is a derivation, named. **[generic]** is a pattern with no claim about you or Ashgrove.
- Guidance is scaffolding, not a script. "Answer slot" means an instruction for the interview. It asks for no reply here.
- "Plain acknowledgment" means saying a limit you have already stated yourself, in your own words.

## Prep triage (9 days, in order)

1. **The case (C1).** Run the 20-minute escalation case aloud three times. Do the first run by 23 November.
2. **The two gaps you have stated.** The contact centre (B5, A8, C6) and presenting above regional level (B9, C8). For each: say the plain acknowledgment, then the plan. Three runs each.
3. **Your numbers (B3, C7).** Write down what the complaints log and the monthly spreadsheet actually count, from your own records. You can only defend what you can name.
4. **Values (section Round C).** For each value, write one story of something you did, or confirm there is none. Expect scaffolds, not ready stories.
5. **The strategy vocabulary (Grounding brief).** Twenty minutes: the headline numbers and the hub plan, in your own words.
6. **Your logistics answers (A4 to A7).** Decide your own pay, notice, location and reason before 29 November.

Everything else is insurance.

## Fit snapshot (shared across rounds)

No requirement in this JD is a gate under the evidence conventions: each is experience, handling or presentation. No row is `hard_gate`. Your material is strongest on the banking years, the complaints log and the spreadsheet. It is silent on digital work, and it states two limits plainly: the contact centre and presenting above regional level.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Your six years are in retail banking. Whether they count as customer operations is for the interviewer to judge, so say the years and the supervisor role in your own words. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your sentence covers one branch's formal complaints log. It does not show the process end to end, and it does not reach the contact centre, so the bridge stops at the log. Answer slot: if you set any step beyond the log, say which and how you decided, in your own words. If the log was the whole of your part, say so plainly. |
| F3 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan: how you would learn how contact-centre complaints reach a branch. |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet. It does not say what it counts. Answer slot: if it counted complaint volumes or resolution times, say which and how you counted them. If it did not, say so and say what you would add first. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence is about tellers and an escalation script, not supervisors. The bridge is that you taught the escalation script to new tellers, and that limit stays in the sentence. Answer slot: if you have coached a supervisor through an escalation, say what happened in your own words. If you have not, say so and say how you would start. |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan for the first monthly report you would present, said as a plan. |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your sentence says formal complaints. It does not show whether they fell under a regulator's rules. Answer slot: if they did, say which rules applied and how you tracked them. If they did not, say so and stay with the formal log. |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your sentence says a spreadsheet, and says nothing about Excel. Reword only that sentence: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool only if it was Excel. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital teams. Answer slot: if you have worked with a team on a self-service change, say what it was and your part in it. If you have not, say so, and say what you would bring from the branch side of a self-service journey. |

## Grounding brief (shared)

Source: the 2026 strategy brief, July 2026, sent by the recruiter. It is under six months old.

- **Headline numbers:** move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027; launch a small-business lending product in Q1 2027.
- **Competitive frame:** app-only banks.
- **Vocabulary to use:** "member service", "digital channels", "hubs", "self-service journeys", "small-business lending product".
- **Stale framings:** none flagged.
- **[inferred]** The hub plan and the digital target both move complaint handling. That is a derivation from the brief, not a statement of Ashgrove's plan for complaints.
- **[inferred]** The hub plan is the pressure point for "Neighbours, Not Numbers", because consolidation takes services out of some towns. Expect the panel to test it (C2).

---

## Round A: Recruiter screen (30 minutes)

**Persona weights.** The round prior is Conversational plus a light Skeptic. The recruiter's email names logistics as the purpose, so the four logistics questions are slots, not persona-weighted.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly opener and a motivation question | High: a screen opens friendly and is scored anyway | A 90-second arc built from your own sentences |
| Skeptic, light | One gap raised kindly: the contact centre | Medium: the JD asks for the contact centre, and you have said you have not worked in one | Plain acknowledgment, then a plan |
| Logistics (not weighted) | Pay, notice, location, reason for leaving | High: screens check these; you have given no figures yet | Your own words, quoted back; slots, not scripts |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey from the branch to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Speak in the order your sentence gives: six years in retail banking, the last three as a branch supervisor. Then the escalation work (A3). Stop at about 90 seconds. Add no roles, dates or titles that are not in your own words. | Open and scored. It uses the one sentence you gave about your path (F1). |
| A2 | "What's drawing you to this role?" | JD | [generic] | Answer in your own words: what the complaints work means to you from the branch side. Do not claim knowledge of the contact centre or of the digital plans beyond what you have read. | Motivation consistency, asked in a friendly register. Generic because it is a standard question and makes no claim about you. |
| A3 | "Tell me about the escalation work you've done." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: you trained new tellers on the escalation script. Beats: who you trained, what the script covered, and how you checked it landed. Answer slot: the JD asks about coaching supervisors on escalations, so expect a follow-up. Say what you did, and if you did not coach a supervisor, say so. | F5 is the nearest sentence to the JD's escalation line. The screen checks that tick here. |
| A4 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band is before you answer. Name no figure you have not decided on. | Pay is a screen check. The only safe answer is your own. |
| A5 | "What notice would you need to give?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | As A4. |
| A6 | "Where are you based, and which sites could you work from?" | JD | [generic] | Logistics slot: say the places you can work and any limits, in your own words. The email gives no site pattern for this role, so ask the recruiter for it before you commit to a site. | Location is a screen check, and the hub plan makes the answer matter. |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your own reason in one true sentence, then stop. | Asked in every screen. The answer is yours to give. |
| A8 | "This role runs complaints across a contact centre, and you've never worked in one. How do you respond to that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan: how you would learn how complaints reach the contact centre from a branch. Do not describe contact-centre work you have not done. | The one JD gap you stated outright. A screen tests whether you name it without spin. The deeper version is B5. |

**Reverse questions (Round A)**

1. "Which round carries the escalation case, and does it come with anything in advance?" Why it lands: it tells you how to prepare the case, and it is a process question a recruiter answers easily.
2. "What will the Head of Member Services most want to see in the first 90 days?" Why it lands: it shows you are thinking about your manager's bar, and the answer sets your priorities for B.
3. "Is the role tied to one hub, or to several?" Why it lands: it links A6 to the hub plan, and you need the answer before you accept any role.

---

## Round B: Head of Member Services (45 minutes, future manager, mostly behavioural)

**Persona weights.** The round prior for a hiring manager is Case plus Skeptic. The recruiter's note that the round is mostly behavioural moves Values/Behavioural to the top and Case to the bottom.

| Persona | Weight | Questions | Reasoning |
|---|---|---|---|
| Values/Behavioural | 5 | B1, B2, B3, B4, B8 | The round is mostly behavioural, and the manager will read the values first |
| Skeptic | 3 | B5, B6, B9 | Your two stated limits will be tested as gaps |
| Case | 1 | B7 | One live coaching problem; the 20-minute case belongs to Round C |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter, when the rule said otherwise." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick a decision where the member's side and the rule pulled apart. Say what the rule said, what you did, and what the member got. If there is no such decision, say so plainly, then give the nearest thing your material carries: the complaints log you handled, and what you did with one entry. | Members First is the first value, and the manager will test it first. The theme comes from the published value. |
| B2 | "Tell me about a time a process you taught didn't land the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Selection scaffold: pick a teaching moment where the explanation had to be given again. Say what you changed. If you did not check whether it landed, say so. Claim no change you did not make. | Plain Words: "if a member needs it explained twice, we wrote it wrong." Your teaching is the nearest sentence. |
| B3 | "Who acts on your monthly complaints spreadsheet, and what do they do with it?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Your sentence supports one thing: the regional manager uses the spreadsheet. Answer slot: if a figure in it changed a decision for one branch or one town, say which figure and what changed. If none did, say so, and say what the figure was for. | Neighbours, Not Numbers: the manager will test whether the numbers led to people. Your sentence supports the use, not an outcome. |
| B4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: a complaint you kept until it closed, including one that was not yours to fix. Say whether you handed it on, and whether it closed. If no complaint came to a close with you, say so. | Own the Fix: a hold that ends in closure is the story. An honest hold that did not close is also an answer. |
| B5 | "You've never worked in a contact centre. How would you run complaints that come in through one?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, not a past: how you would learn contact-centre intake in your first month, who you would ask, and what you would check. Hold through two follow-ups by returning to the plan. Describe no contact-centre experience. | **Highest-return rehearsal in this pack.** The contact centre is in the role's first duty, and you have stated the gap, so it will come up in some form. Rehearse three follow-ups. |
| B6 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level." | Name both gaps plainly, then a plan for each. Do not pick a softer third weakness to balance them. | Skeptic stem. The two plain acknowledgments are the only negatives you have stated. Do not bluff either one. |
| B7 | "How would you coach a branch supervisor through an escalation they've handled badly?" | JD | [generic] | Structure: what you would ask first, what the supervisor already knows, what stays in their hands (Own the Fix), what you would coach, and how you would check it next time. Make no claim about coaching you have done. If asked, see the slot at F5. | The JD asks for coaching supervisors on escalations. This is a live problem, not a record. |
| B8 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem | Selection scaffold: pick a time you said something a senior person did not want to hear. Name the stake, what you held, and whether the working relationship survived. If no such time comes to mind, say so plainly, then say how you would handle it. | Pressure and values stem. The guidance claims no past for you. |
| B9 | "Who would you have to explain your monthly reporting to, above your regional manager?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: how you would prepare your first presentation above regional level. Claim no audience above regional level that you did not give. | The JD requires confidence presenting to senior leaders, and you have stated the limit. |

**Reverse questions (Round B)**

1. "What does a good first 90 days look like in this role?" Why it lands: it sets the bar your plan is measured against, and it ties to B5 and B9.
2. "Where do complaints most often stall between a branch and the contact centre today?" Why it lands: it shows you are after the real problem, which is the spirit of Own the Fix.
3. "As the digital share grows toward 2028, what should complaints reporting look like?" Why it lands: it ties to the 40% digital target, and the answer tells you whether the monthly report is about to change.

No interviewer profile exists yet. Tie one reverse question to this manager's own path once the name arrives.

---

## Round C: Panel of two branch managers (60 minutes, including a 20-minute case, scored against the four values)

**Graded deliverables:** none declared. The case is live.

**Persona weights.** The panel prior is a blend of the top two personas for each member of a panel, read as operating peers, not your line. The prior is Peer plus Data-driven Prober. Two things move it: the 20-minute case moves Case up, and the scored values move Values up. The two top personas tie.

| Persona | Weight | Questions | Reasoning |
|---|---|---|---|
| Values/Behavioural | 3 (ties top) | C3, C4, C5 | The panel scores the four values, so values are scored in this round |
| Case/Strategist | 3 (ties top) | C1, C2, C9 | The 20-minute case is the single most heavily weighted item in the round |
| Data-driven Prober | 2 | C7, C8 | Branch managers will check how the numbers are counted |
| Peer Evaluator | 1 | C6 | The seam between branches and the contact centre |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | The case: "A member has come into your branch three times about the same fee. She now says she will take it to the regulator. The teller who took the first call is off until Monday. Walk us through what you do, in the order you would do it." | CASE | [generic] | The case order, for 20 minutes. (1) Clarify: what she was told each time, what the teller recorded, what the regulator mention means, and how soon she needs an answer. (2) Contain: name one owner today, so she is not passed on again (Own the Fix). (3) Decide: what you can decide, what goes up, to whom, and by when. (4) Record, and tell her in plain words what happens next (Plain Words). (5) Prevent: what you would check about the process and the teller. Check the complaint rules that govern escalations here, and say that you would check them. Quote no time limit you have not read. | A live problem that asks about no past of yours. The panel scores structure and the values, so the order is the answer. |
| C2 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. A branch manager on that plan asks you: how do you keep 'Neighbours, Not Numbers' true for a town that loses its branch?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." Plus the supplied brief and the published value. | Hold the position through two follow-ups. Say what you would do for members in that town: what changes and when, how service stays close, and who is left behind (plan, not past). Concede plainly what you cannot fix, such as distance and the branch's place in its town. Do not defend the economics of consolidation: you have no figures for it. The ground you can hold is the one your material carries: the years in retail banking and the supervisor role. | The hub plan is the most likely pressure in this room. Its sharpest version is a value against a number. Pressure is a hold-then-concede, not a defence of the plan. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem; nearest [grounded] "I handled the branch's formal complaints log" | Selection scaffold: name the metric, the member, and what you did. If no such time comes to mind, say so plainly, then say how you would handle it. | Members First, asked as a scored question. The stem is the persona's; the claim about you comes only from your own sentences. |
| C4 | "Tell me about an explanation you gave a member that had to be right first time." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Selection scaffold: pick a written or spoken explanation you gave. Say what the member needed, and what you changed to make it plain. If you did not give member explanations yourself, say so, then give the nearest: how you taught the script to new tellers. | Plain Words, scored. The nearest sentence is the teaching, not a member-facing explanation. |
| C5 | "Tell me about a problem you found that wasn't yours to solve. What did you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: a problem you found that was not yours, what you did with it, and whether it was solved. If you passed it on, say to whom. If you did not find such a problem, say so. | Own the Fix, asked directly. The honest answer may be a hand-off, and a hand-off is a story if you name who held it next. |
| C6 | "Our teams sit side by side. Where's the seam between a branch and the contact centre, and what happens when we disagree?" | JD | [grounded] "Never worked in a contact centre" | Propose principles for the seam, not a map of it: who owns a complaint at the hand-off, and who says when it is closed. Say plainly that you have not worked on the contact-centre side. Then say what you would bring to the branches. | Peer Evaluator. Reciprocity: what you bring to their team, not only what you need from it. |
| C7 | "What does your monthly complaints spreadsheet count, and how?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what the spreadsheet counts, in your own words. If you set the counting rules, say so and how. If you did not set them, say so. Give no method you cannot describe. | The Prober's question, asked where your evidence is thinnest (F4). |
| C8 | "What would the first page of a monthly complaints report show a senior leader?" | JD | [grounded] "I've never presented to anyone above regional level." | Say what you would put first: complaint volumes and resolution times, which the JD names, then the escalations. Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan for the first presentation. | Prober, and the JD's presenting requirement in one question. |
| C9 | "Talk us through how you'd set up a monthly view of complaint volumes and resolution times in Excel." | CASE | [generic] | Say the steps: where the data comes from, one row per complaint, how each measure is counted, and what the view shows. If you have not used a function, say so and say what you would use first. | A live build, not a record. The JD asks for comfort with Excel reporting. |

**Values cheat sheet**

This round is the values round: the recruiter's email says the panel scores against the four values, which makes it a values-style round by the loop source. None of your quoted sentences carries a story for any value, so each row is a selection scaffold with its honest branch.

| Value (official name) | Working meaning (paraphrased) | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Pick a decision made for a member that the rule did not cover. If none, say so. Nearest sentence: "I handled the branch's formal complaints log". Do not present the log as a member decision unless you made one. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Pick an explanation that had to be given again. Nearest sentence: "trained new tellers on our escalation script". If you never checked whether it landed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | Pick a time a monthly figure led you to act for one branch or one town. Your spreadsheet sentence carries a number, not a neighbour, so the honest version is: say what the figure was for, and give the nearest real thing you did for a branch. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Pick a complaint you kept until it closed, including one that was not yours. Nearest sentence: "I handled the branch's formal complaints log". If it closed with someone else, say so, and say who held it. |

**Reverse questions (Round C)**

1. "What could a new person do in their first month that would genuinely help your branches?" Why it lands: reciprocity, which a peer-weighted panel scores. It shows you are offering something, not only asking.
2. "Which complaint has taken longest to close in your branch, and what held it up?" Why it lands: it goes to the real problem, which is Own the Fix in practice.
3. "How do you hear about the hub plan today, and what would help you explain it to members?" Why it lands: it ties to the eight-to-five hub plan, and the answer shows what branch managers are carrying into the change.

---

## Prohibited claims (shared)

Built from the fit snapshot before the banks. Each entry names its basis, and the basis sets the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2. Your material says the branch's log. | Your sentence at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material does not show the process end to end. |
| Worked in or led a contact centre | Negative you stated (F3) | "I haven't worked in a contact centre." No answer slot on it. |
| Presented to senior leaders | Negative you stated (F6) | "I haven't presented to anyone above regional level." No answer slot on it. |
| Coached branch supervisors on escalations | Inflated form of F5. Your sentence is about tellers. | "trained new tellers on our escalation script." The slot at F5 asks only what you did. |
| Handled regulated complaints | Inflated form of F7. Your sentence says formal complaints. | "I handled the branch's formal complaints log." The slot at F7 asks which rules applied, if any. |
| Measured complaint volumes or resolution times | Inflated form of F4. Your sentence says a spreadsheet. | "I built the monthly complaints spreadsheet our regional manager uses." The slot at F4 and C7 asks only what it counted. |

## Sources

Provided documents, all read in full:

1. The job description, from your message.
2. The four values, pasted from ashgrovecu.org/about/values and copied on 20 November 2026.
3. The recruiter's email: round formats and lengths, who runs each round, and the panel's scoring against the values.
4. The 2026 strategy brief, July 2026, sent by the recruiter.
5. Your background, from your message.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | The pasted values page fixes the four names and their wording, so the values cheat sheet needs no search |
| 2. ashgrove interview process member experience lead | skipped | The recruiter's email names all three rounds, their lengths and who runs each. That establishes the loop, so the round weights follow it |
| 3. ashgrove strategy / recent news | skipped | The July 2026 brief supplied gives current priorities and recent moves, and it is under six months old |
| 4. interviewer name ashgrove | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative member experience lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → an interviewer read, persona weights for each panel member, and a reverse question tied to each one's path.
- Confirmation of the day and format: 29 November 2026 is a Sunday, and the email gives no times → confirm the times and whether the rounds are in person or by video, so the prep can match the room.
- Your own answers to pay, notice, location and the reason for leaving → A4 to A7 become your own words, quoted in the pack, instead of slots.
- The column headings of the complaints log and of the monthly spreadsheet, with no member details → can lift F2, F4 and F7 toward high confidence, because it names the artifact that would show them.
- Whether the panel will send the escalation case in advance → changes C1 from a live case to a prepared one.
- A deeper research pass on recent organisational context: up to 6 more searches and 2 more fetches, several more minutes → leadership changes and reorganisation behind the hub plan, for C2. Offered once.
- A `tuesday-dossier.md` from an earlier session → the gaps and objections already exposed, carried in as known inputs. The pack is complete without it.
