# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Candidate:** Priya. **Conversation:** one 60-minute session with Dan Kovac, Director of Sales Strategy. Dan is a **peer**; both report to the same VP.
**Changelog:** first build.
**Built on:** a single peer conversation, JD highlights (not the full posting), your candidate notes, your research note, and Dan's profile as you described it. Web research was refused in this run, so company values, loop structure and Dan's public footprint are **not established** (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = a stated responsibility or qualification. **EXP** = a past claim that must survive scrutiny. **CO** = company and strategy knowledge. **CASE** = a live problem. **VAL** = a behavioral or values question (none is documented for this loop, so VAL items are open prompts only).
- Guidance is scaffolding, not a script. Lines marked **Answer slot** are instructions for the interview: you give your own answer there, and nothing here supplies it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Your material shows product-strategy work and a proposal, not go-to-market ownership of a product line. Say the product-strategy work in its own terms: "9 at a large consumer-tech company in product strategy & ops." Answer slot: the JD's ownership line makes a probe on go-to-market likely. If any go-to-market decision for a launch was yours to set, say which and how you decided. If none was, say so plainly and stay with the product-strategy work. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [inferred] | transferability | Revenue modelling is adjacent to whitespace, but nothing in your material shows the land-to-renew lifecycle; the link is this pack's inference. Coaching only: "The model I built was used in carrier negotiations." Answer slot: if you mapped where revenue was unrealised across land, adopt, expand or renew, name the stages and what you found. If the model did not reach those stages, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | presentation | The quote already reaches the tools in role terms; "independent" is unstated, and that is where the probe will go. Bridge, reworded from the quote only: "I work in SQL and Tableau." Expect the independence question; the answer is yours to give in your own words. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The model is partner-facing work; designing a partner motion is not stated. Bridge: "The model I built was used in carrier negotiations." Answer slot: if any partner terms or the motion itself were yours to design, say which and how you decided. If others used the model in negotiations you did not run, say so plainly. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches cross-functional work directly. Bridge, reworded from the quote only: "I set annual volume targets with cross-org consensus." Consensus is not influence on its own; expect a probe on how it was reached (B4). |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Daily tool use is adjacent to building with AI, and the material does not show AI product work. Coaching only; no claim. Answer slot: name the tools you use daily and one check you run before trusting their output. If you have built or launched anything with AI, say what and your part. If not, say so plainly. |
| F7 | Not in the JD highlights. A likely peer probe on sales strategy: sales-ops and quota-setting experience ([generic] role-family expectation) | none given | none | [grounded] | discovery | Your notes say "No classic sales-ops or quota-setting experience." That is the coach's statement, not yours, so it is not a limit to say aloud until you confirm it in your own words. Answer slot: if you have set or run targets that fed a quota, say how. If not, say so plainly, then name the nearest thing you have done, the volume targets in F5. |

## Grounding brief

From your research note. Not verified against public sources in this run.

| Item | Source | Provenance |
|---|---|---|
| "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | your research note | [grounded] |
| "main competitive threat is bundling by a much larger platform vendor" | your research note | [grounded] |

Check both are current before the conversation. If your note is more than six months old, treat the priorities as perishable.

## Reading the interviewer

Source: Dan's profile as you described it. Public footprint was not checked (search refused).

- **Self-described "relentlessly data-driven."** Expect every metric to be taken to its denominator and its assumptions (B1, B3, B4).
- **Career spine in pricing and monetization.** Pricing, packaging and unit economics are his native language (C3, R1, R5). Say what the revenue model modelled. Do not say it priced anything.
- **One early-stage-startup chapter.** Builder stories land with him, and expect probes on pace and scrappiness (B2). She has no startup chapter in her material, so do not reach for one.
- **Mirror opportunities:** none offered. No sentence in her material carries a side of a shared career jump.

## Persona table

Weights are priors for a **peer** round, adjusted by the interviewer read. The loop is one 60-minute conversation with Dan, so no archetype fallback applies; no values round is documented, so Values gets the minimum weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Peer Evaluator | Seam questions, "what would you need from me," credit, disagreement with an equal | High. Peer prior, and he is pricing what the hire costs his work | Reciprocity: what you bring to his team. Propose seam principles, not a map of his team | 5 |
| Data-Driven Prober | Denominators, assumptions, "walk me through how that was counted" | High. Self-described data-driven, and the CV's headline number is $400M | Name your weakest assumption before he does. Say plainly what you do not know about how a figure was counted | 5 |
| Case / Strategist | Whitespace and priorities as live problems | Medium. JD line R2 and the strategy note make a live problem likely, and pricing is his ground | Clarify, then structure: stages, one data source per stage, metrics, risks | 3 |
| Skeptic | Gaps: GTM ownership, quota-setting, motivation for the move | Medium. F1, F7 and the "why move" angle are the material's gaps | Rehearse the single predictable objection until it is calm (D2). Concede a specific gap in your own words; never fold on the core claim | 3 |
| Pressure | Interruptions, "how much of that was actually you" | Low to medium. A peer rarely time-boxes, but the $400M invites it | Pause, restate, hold through two follow-ups, then concede the specific uncertainty | 2 |
| Conversational | "Walk me through the journey," a casual question about AI | Low. Peer rapport, but casual questions on JD items are still scored | A 90-second arc; treat casual AI questions as scored | 2 |
| Values / Behavioral | Open prompts about customers and unpopular truths | Low. No values round is documented, and no loop source names one | Pick a real instance, or say so plainly and give the honest branch | 2 |

Total: 22 questions. Every plausible persona is touched.

## Question banks

Requirement coverage. Each JD highlight maps to at least one question. The non-JD sales-ops probe is covered by D1, D2 and E1.

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A1, A5, E1 |
| identify whitespace across land/adopt/expand/renew | C1 |
| run independent analysis in SQL and Tableau | B2 |
| partner-motion design experience required | A2 |
| strong cross-functional influence | B4 |
| AI experience a plus | B5, F2 |

Defend-the-number coverage: the $400M claim gets B1 and E2.

### Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side on pricing and sales strategy. Where would you draw the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights); "set annual volume targets with cross-org consensus" (coach's notes) | Give two seam principles, not a map of Dan's team: which decisions you would make and which you would bring to him, and how a disagreement gets settled. Anchor any past claim in the F5 quote, and say how the consensus was reached only in your own words. Answer slot: if you have had a seam disagreement with a peer, tell it. If not, say so plainly and offer the principle. | The Peer Evaluator's core probe. R1 and R5 are the requirements a peer tests here. Typed JD because the requirement is his, and delivered collegially. |
| A2 | "Walk me through the partner-level revenue model you built. Where did it sit in the carrier negotiations?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes); "partner-motion design experience required" (JD highlights) | Describe the model and where it was used, in those words. Hold it at its quote: you built it, and it was used in negotiations. Answer slot: if you set any partner term or the motion itself, say which and how you decided. If others used the model in negotiations you did not run, say so plainly and stay with the model. Hold the scope through two follow-ups. | Partner-motion design is a required JD item (F4). The question presupposes only what the quote states, so the slot's second branch must allow that the design was not hers. |
| A3 | "Tell me about a time a peer's plan cut across yours. What did you do, and where did it land?" | EXP | [generic] open prompt; nearest instance: "set annual volume targets with cross-org consensus" (coach's notes) | Open prompt: pick a real instance. It needs a named stake, what you did, and where it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the cross-org step behind the volume targets, and your part in it, in your own words. | Disagreement style with equals is the Peer Evaluator's scoring target. Typed EXP because the answer is a past event. The guidance supplies no event. |
| A4 | "How do you handle credit when a result spans teams? Give me one time it did." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | State the rule you actually use, then one instance. If the store-surface change is your example, say what you proposed, who else was in the work, and what part was yours. Answer slot: if others shaped the change, name them and their part in one sentence each. If no one else did, say so. | Credit probes come from peers. The $400M is the claim most likely to be stretched in a credit conversation, so the example is anchored to its own quote. |
| A5 | "Which decisions on a new product line would you want me to own, and which would you own?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Propose a split by decision type, such as pricing structure, channel, partner terms and launch sequencing, with one reason for each. No claim about your past. Close by asking what he would need from you in the first quarter. | Reciprocity, which a peer weights heavily. Covers R1 with no past claim. |

### Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted. What would it not survive?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend the number in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before he does. Answer slot: if you counted or attributed the uplift, say how. If you did not, say so plainly and say what you can show. The pack supplies no counting method. | Every headline metric gets a defend-the-number slot, and this is the CV's largest figure. A data-driven peer goes to the denominator first. |
| B2 | "Tell me about an analysis you ran yourself in SQL and Tableau. What did you check before you trusted it?" | JD | [generic] open prompt; nearest instance: "skilled in SQL/Tableau" (coach's notes) | Open prompt: pick an analysis you actually ran. Name the question, the data and one check. If you ran only some parts end to end, say which parts. Answer slot: if you pulled the data, wrote the queries or built the views, say which. If someone else did any of those, say so. Do not describe an analysis you did not run. | R3 says "run independent analysis." "Skilled" leaves independence open, which is the probe. Typed JD because it scores a stated tool requirement. |
| B3 | "What were the inputs to the partner-level revenue model, and which one would you distrust most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name two or three inputs in your own words, and the one you would distrust, with the reason. Answer slot: if you chose the inputs, say which. If they came from elsewhere, say where. Name the weakest assumption without being asked. | A model with no named inputs is a prober's first opening. The premise is the model itself, as the quote gives it. |
| B4 | "Those annual volume targets set with cross-org consensus: what baseline did they start from, and who agreed to it?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Say what the baseline was and who agreed to it, in those words. Answer slot: if a baseline was set, name it and who set it. If the targets were set without one, say so plainly. Offer no target-setting method. | Tests R5 (cross-functional influence) and is the nearest sentence to quota-setting, so the F7 gap is probed sideways here. Typed JD for the requirement, with EXP delivery. |
| B5 | "Which AI tools do you use daily, and what do you check before you trust their output?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools and one check you run on their output. Answer slot: if you have built or launched something with AI, say what and your part. If not, say so plainly, and say how you would learn AI product work. Do not claim AI product experience. | R6 is a plus. The prober tests whether daily use is being offered as build experience. The confidence is low, so the pack asks rather than asserts. |

### Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where in land, adopt, expand and renew would you expect the most whitespace for a new product line, and how would you size it?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify first: which product line, which customer segment, and what the line is measured against. Then stages: one data source per stage, a test for whitespace at each, and the metrics. Name one risk. No claim about your past. | R2 is the JD's whitespace line. The material has no past work on it, so this is a live problem that presupposes nothing about her. Typed CASE, with JD content. |
| C2 | "Northwind's stated priorities are enterprise expansion, an AI copilot launch (Compass) and reaching profitability. Which one should a new product line be measured against first, and why?" | CO | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Pick one priority. Name the trade-off you would accept against the other two, and what would change your mind. Mark the part you cannot verify from outside. | The CO bank. It rests on your note, which is not publicly verified in this run, so the answer should carry the caveat. A strategist answer beats a list. |
| C3 | "A much larger platform vendor starts bundling a near-substitute into its suite. What does that do to a deal, and where do you have pricing or packaging levers?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Structure: what the bundle changes for the buyer (price, procurement path, what they stop buying), then the levers (packaging, term length, partner terms). Name the evidence you would need before moving price. No claim about past deals. | Dan's career spine is pricing and monetization, his native ground. A CO question grounded in your note is the differentiator. |

### Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Answer slot: name the part you find weakest, in your own words, first. If it is sales-ops or quota-setting, say so plainly, then say how you would learn it in the first 30 days. | This surfaces F7 before he has to dig for it. The stem is the Skeptic's standard opener. |
| D2 | "You have spent your career in strategy and product ops. What have you owned in go-to-market, and why should this be the next step?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes); "own GTM strategy for two new product lines" (JD highlights) | **Highest-ROI prep in this pack.** Give your path in its own terms. Hold the bridge to go-to-market at F1's scope: the store-surface change you proposed. First follow-up (what you owned in GTM): answer from the F1 quote and its slot. Second follow-up (what you would need to learn): name it as a plan, not a past. Concede a specific gap in your own words, if it is real. Do not fold on the core claim. Answer slot: if you have owned any go-to-market decision for a launch, say which and how you decided. If not, say so plainly. | The most predictable objection. The JD names GTM ownership, and the material shows none. Rehearsed deepest because it will come in some form. |
| D3 | "Why leave product strategy now for this role?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes); "own GTM strategy for two new product lines" (JD highlights) | Give the motivation in 60 seconds, tied to the JD's GTM line. Make no claim beyond the quote. If the motivation is about the product lines themselves, say that. Hold through one follow-up, and do not add a reason you did not give. | Motivation consistency is the Skeptic's scoring target. |

### Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [generic] persona stem; [grounded] "own GTM strategy for two new product lines" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Pause, then restate the question to yourself. Answer in 60 seconds: lead with the revenue model's quote, then name the gap in your own words. Hold through two follow-ups. Concede the sales-strategy gap specifically. | Pressure persona, time-boxed. The honest structure is hold, then concede the specific gap. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Pause and restate the figure to yourself. Name your part in your own words, using only what the quote carries: what you proposed. Hold the proposal. Concede the attribution uncertainty you actually have, in those words. Answer slot: if others shaped the change or the uplift, name the share you can stand behind. If you cannot split it, say so. | Tests composure on the CV's largest claim, and whether you can separate your part from the team's. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (coach's notes); "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A pre-scripted 90-second arc: consulting, then consumer-tech product strategy and ops, then the partner model and the store-surface proposal, then why emerging products. Stop at the quotes. End on the GTM gap, in your own words. | Rapport-style openers are scored. The arc's last beat is the one he will test. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Casual, but scored. Name two tools and one thing you have learned from them. No build claims. Answer slot: if you have built anything with AI, say what. If not, say so plainly. | R6 asked casually. B5 is the probing version, so this is the warm-up. |

### Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer's need ahead of an internal number." | VAL | [generic] open prompt; the theme is a persona stem | Open prompt: pick a real instance. Name the stake, what you chose, and the outcome. If none comes to mind, say so plainly and say how you would handle one. | No values round is documented, so this is a scaffold for the one peer question that drifts into values. No mapped story exists, so the honest branch is required. |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt; the theme is a persona stem | Open prompt: pick a time you said something a senior person did not want to hear. Name the stake, what you said and how it landed. If none comes to mind, say so plainly and say how you would handle one. | As G1. Typed VAL because the scoring is behavioral, even though it is not a documented round. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. Which pricing call from that work still shapes how you plan a new line?" | Ties to his own path. It turns an interrogation into a peer conversation and shows you researched him, not just the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer conversation weights heavily. |
| R3 | "Where does the line between sales strategy and emerging-products go-to-market sit today, and where has it caused friction?" | Shows you understand the seam, and gives him a reason to tell you where it is. |
| R4 | "Which of the three priorities, enterprise expansion, Compass or profitability, will the two new lines be measured against first?" | Strategy fluency. It rests on your research note, so ask it and do not assert the answer. |
| R5 | "When a bundled competitor moves on price, who decides the response on a live deal?" | Tests decision rights on the threat your note names, and sits in his native pricing ground. |

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1: "own GTM strategy" widens "product strategy & ops" and "proposed" | F1's quotes at their own scope. The limit is this pack's observation: your material shows product strategy, not GTM ownership. A1 and D2 slots stay inside the quotes |
| Designed partner motions or partner terms | Inflated form of F4: "used in carrier negotiations" widened to "designed" | F4's quote at its scope. The slot asks which terms, if any, were yours |
| Ran independent analysis end to end | Inflated form of F3: "skilled in" widened to "ran" | The quote "skilled in SQL/Tableau." B2's slot asks what you ran |
| Set quotas or sales-ops targets | Inflated form of F5: "set annual volume targets" widened to quota-setting | The quote itself. B4's slot asks only for the baseline |
| Drove the ~$400M, or was its sole credit | Inflated form of the store-surface quote: "proposed… credited with" widened to ownership of the result | The quote at its own scope. B1 and E2 slots ask what share you can stand behind |
| Built or launched AI products | Inflated form of F6: "uses AI tools daily" widened to build experience | "uses AI tools daily." B5 and F2 slots ask what, if anything, was built |
| Any fact about Northwind's values, loop or Dan's background beyond your notes | Not established: web research refused | None asserted. The upgrade menu says what would establish each |

## Sources

- **Provided documents:** your message (JD highlights, candidate notes, research note, Dan's profile as you described it).
- **Searches sent, all refused:**
  - "Northwind Data company values operating principles": refused
  - "Northwind Data interview process Senior GTM strategy": refused
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused
- **Fetches:** none.
- **Loop:** established by your words, a single 60-minute conversation with Dan. No values round is documented, so no archetype fallback and no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call refused. No values cheat sheet; the values section is not triggered |
| 2. `Northwind Data interview process` | unavailable | Refused. The loop is established by your words, so the loop itself is not affected; the values-round question is not established |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the competitive frame, which fixes the CO bank |
| 4. `Dan Kovac Northwind Data` | unavailable | Name given; search refused. The interviewer read rests only on your profile |
| 5. representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Full JD text** → the six JD rows become quoted from the full posting, and any requirement the highlights left out gets a question.
- **Approve web search** → runs the three refused L1 searches: Northwind's values, the interview loop, and Dan's public footprint. Values and loop turn `[inferred]` or `[generic]` rows into grounded ones.
- **Northwind's values page, pasted** → the values cheat sheet, if your recruiter confirms a values part to the conversation.
- **Your own words on quota-setting or sales ops** → F7 becomes a candidate-stated limit with a plain acknowledgment, and D1 and D2 tighten.
- **Recruiter's note on what the conversation focuses on** → reweights the persona table and the question banks.
- **Deep research, once (L2)** → a strategy brief on Northwind, Dan's talks and writing, role-family loop reports and recent org context. Up to 6 more searches and 2 more fetches, several minutes. Want it?
- **Tuesday dossier** → one line on what it would add: it would carry this pack's prep gaps into later sessions.
