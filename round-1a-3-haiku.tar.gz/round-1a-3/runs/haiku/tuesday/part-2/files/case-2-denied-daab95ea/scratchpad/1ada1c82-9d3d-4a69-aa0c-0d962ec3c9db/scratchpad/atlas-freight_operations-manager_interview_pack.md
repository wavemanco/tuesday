# Interview prep pack: Operations Manager, Atlas Freight

**Round:** not stated. Built for a hiring-manager round, with flat persona weights, because the round and the interviewer are unknown.
**Interviewer:** not named.
**Research tier:** L1, but no search returned results (see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: EXP (your past work), JD (the listed job), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Answer slots (marked "Answer slot") are instructions for the interview. They are not questions to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations, not terminal operations. Bridge: "I have seven years in warehouse and distribution operations." Answer slot: if any daily terminal decision was yours to make at your site, say which and how you made it; if the terminal work was not yours to run, say so and describe the nearest you did. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material reaches accuracy, not on-time performance or cost. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment for that work, say which figure and what moved; if you did not, say so plainly. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors at one site. Bridge: "I currently manage three supervisors." Answer slot: if you have directed work through more than three supervisors, say how; if not, say so and say how you would build a layer of twelve. |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Seven years of operations work is in the material. The leadership years are not counted there. Answer slot: give your own count of years in a leadership role, in your own words. If it is fewer than five, say so and name what those years were. |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message; "never used Power BI" — your message | low for Excel (vague self-rating); stated negative for Power BI | [grounded] | capability | Power BI is a stated absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. Answer slot for Excel: name one report you built or changed and the decision it fed. |
| F6 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Quote reaches the requirement. Bridge: "I am green belt certified." |
| F7 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | discovery | Your material is silent on more than one site. Answer slot: if you have coordinated any plan across more than one site, say which; if not, say so plainly and describe how you would coordinate four. |

**Gate check.** The JD names no location, schedule or travel term. Terminal operations usually carry shift and weekend cover. Your material does not show whether you can work that pattern. This is not a fit finding. It is the question in the message that accompanies this pack.

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure. None of them may be said in the interview.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 and F7 | "I ran the site's peak-season surge plan two years running." |
| Led a team of twelve supervisors | Inflated form of F3 | "I currently manage three supervisors." |
| Improved on-time performance or cost per shipment | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." |
| Built Power BI reporting | Stated negative, F5 | "I haven't used Power BI." |
| Has five or more years of operations leadership | Inflated form of F4 | Your own count, from the F4 answer slot. |

The pack's own observation, not words for you: your material says the pick path and the mis-pick rate, not on-time performance or cost. It says the site, not four sites.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live terminal problems: a missed on-time target, a cost rise, a staffing gap at peak | Highest. A hiring manager is buying capability for the terminal, so expect a live problem on the actual job | Clarify, then structure: objective, segments, approach, metrics, risks. Think aloud. Challenge one premise |
| Skeptic | Quiet probes on the leadership and multi-site gaps | High. The JD asks for 12 supervisors and four sites; the material shows three at one site | Hold the honest bridge, then concede the gap specifically. Never bluff a competency you lack |
| Data-Driven Prober | "How was 40% counted?" and "what was the denominator?" | Medium. Your headline number is the one a prober will test | Say how it was counted in your words, or say you do not know. Name the weakest assumption before they do |
| Pressure | Time-boxed challenges to your right to the role | Lower. Common in hiring-manager rounds, less so as the first round | Pause, restate, anchor in your quote, hold through two follow-ups, then concede the real uncertainty |
| Conversational | Opening "walk me through" and a casual question about Lean | Lower, but casual questions are still scored | Use a 90-second arc. Treat the Lean question as scored |

## Question banks

### A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your terminal has to hit its on-time target through a peak week with two supervisors out sick. What do you do in the first 48 hours?" | CASE | [generic] | Clarify which shifts and lanes are at risk. Set the objective. Segment by shift and dock. Approach: redeploy, then protect the highest-value freight. Name the metrics you would watch and the risk you would escalate | JD: "Own daily terminal operations"; F1 is the gap this tests. CASE asks no claim about your past |
| A2 | "On-time performance dropped 8 points at one of four sites last month. Walk me through how you would diagnose it." | CASE | [generic] | Clarify whether it is one site or the network. Define on-time. Segment by lane, shift, carrier and volume. Check labour before process. Challenge one premise, respectfully | JD: "drive on-time performance... down". Tests F2's gap at the level of method |
| A3 | "How would you split twelve supervisors across four sites, and what would you change in the first 90 days?" | CASE | [generic] | Structure the spans of control first, then the supervisors' current load, then the first 90 days. Name what you would need to know about each site before deciding | JD: "lead a team of 12 supervisors" and four sites. F3 and F7 are the gaps |
| A4 | "How would you build one weekly report that four site leaders would actually use?" | CASE | [generic] | Start with the decisions the leaders make each week. Then the metrics that drive those decisions. Then the tool. Excel now; Power BI as a plan, not a claim | JD: "build reporting in Excel/Power BI". F5 is the gap |
| A5 | "Cost per shipment is up 5% this quarter. Where do you look first?" | CASE | [generic] | Split cost into labour, volume, mix and rework. Say what you would need to see before deciding. Name the one number you would check first | JD: "cost-per-shipment down". F2's gap is cost, not accuracy |

### B: Skeptic (weight 4) — highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors at one site. What makes you ready for twelve across four?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | **The highest-ROI rehearsal in this pack.** Hold: "I currently manage three supervisors." Then say what you have done that is nearest, in your own words. Concede the gap specifically: you have not yet led across sites. Then your plan for the first 90 days, said as a plan. Answer slot: if you have directed work through more than three supervisors, say how; if not, say so plainly | F3 and F7 are the largest gaps the role presses on. This is the objection the interviewer is most likely to raise in some form |
| B2 | "You have seven years in warehouse and distribution. How many of them were in a leadership role?" | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | Give your own count of leadership years, in your own words. Answer slot: if the count is under five, say so and name what those years were. Never round up | F4. The JD's five-year bar makes the count the first thing asked |
| B3 | "Power BI is in the listing. Have you used it?" | JD | [grounded] "never used Power BI" — your message | Plain acknowledgment: "I haven't used Power BI." Then how you would learn it: a plan, with a date and a first deliverable. No slot, no claim about a past | F5. The acknowledgment is yours; the learning plan is a plan |
| B4 | "Your strongest result is a pick-accuracy number. The job is about on-time and cost. What is the connection?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Name the link honestly. Accuracy and on-time are different measures. If you tracked either against the redesign, say which. Answer slot: if you did not track on-time or cost, say so plainly and say what you would measure first | F2. Tests whether you can separate what you measured from what the job asks |

### C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the mis-pick rate was counted. What was the denominator?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Say how it was counted, in your own words. Answer slot: if you do not know the denominator, say so plainly. Never supply a method you did not use | The headline figure is the likeliest number to be probed. A figure you cannot explain under a second question is worse than none |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Name the weakest assumption in your own words before they do, for example the baseline period. Answer slot: if you cannot name one, say so and say you would check the baseline | Weakest-assumption move, applied to F2's figure. The pack does not name the assumption; you do |
| C3 | "The peak-season plan ran two years. What number told you it worked, and what did you do when it did not?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Name the measure you watched, if you watched one. Answer slot: if no measure was tracked, say so plainly and describe how you judged it | Tests whether the peak plan is evidence or narrative. F7's gap sits here too |
| C4 | "Tell me about the most useful spreadsheet you have used in operations work." | EXP | [grounded] "solid Excel" — your message | Open prompt. Choose one instance. Say what it held, who used it and what it decided. Answer slot: if you have not built one, say which spreadsheet you did use and what it did | Open prompt drawn from the JD's "build reporting in Excel". The self-rating "solid Excel" is vague, so the instance carries the answer |

### D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has already run more than one site?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Pause. Restate the question. Hold: what you have done, from your quote. Hold through two follow-ups. Then concede the specific gap: multi-site leadership. Do not fold on the rest | F7 and F3. The position held must be one your material carries |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold: "I redesigned the pick path." Concede what others did, specifically. Answer slot: if others contributed, name them and what they did; if you ran the change alone, say so | Attribution probe. Honest answers hold the redesign and name the others |
| D3 | "You have been a senior shift manager on one site. Convince me this is not a reach for a four-site operations role." | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Hold the quote. Concede the scale gap plainly. Show the nearest comparable work, in your own words. Do not argue the scale away | F1, F3 and F4 together. Pressure is about composure, not content |

### E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "green belt certified" — your message | A 90-second arc in the order of your quotes: seven years in warehouse and distribution, senior shift manager over three supervisors, the pick-path redesign, the peak plan, the green belt | An opening that is scored for economy. The arc uses only your stated facts |
| E2 | "What are you actually playing with in Lean these days?" | JD | [grounded] "green belt certified" — your message | Say what the green belt covers and where you have applied it. Answer slot: if you have applied Lean tools on the floor, name one and what it changed; if you have not, say you hold the certification and not a practice | The JD's plus, asked casually. Casual questions are still scored |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B1, D1 |
| Drive on-time performance and cost-per-shipment down | A2, A5, B4, C1 |
| Lead a team of 12 supervisors | A3, B1, D3 |
| Build reporting in Excel/Power BI | A4, B3, C4 |
| 5+ years operations leadership required | B2, D3 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

Each one asks about the role, not the company's current state, which research would have supplied.

1. "What does the first 90 days look like, and what would success be at day 90?" Why it lands: shows you are planning the role, not waiting to be told.
2. "How many of the four sites run on the same systems and KPIs today?" Why it lands: it names the reporting problem the JD raises without you having to say it.
3. "Which site is furthest from its on-time target, and what is the cause you have seen?" Why it lands: it asks for the honest state of the terminals.
4. "What reporting tools does the team use now, and is there a plan for Power BI?" Why it lands: it turns F5's gap into a question the interviewer answers.
5. "How is cost per shipment measured, and what is included in it?" Why it lands: a prober's question, asked from the other side.
6. "What would you want the person in this role to have fixed by the end of the first year?" Why it lands: it reveals what they actually want, not the JD's wording.

## Sources

**Provided documents.** Your message: the Atlas Freight JD text and your background summary. Nothing else was provided. No dossier was present.

**Research.** Research tier: L1 — searches 0 of 6 returned results; 3 sent, all refused (permission not granted in this session); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10, which is absent. Calls: "Atlas Freight regional logistics company values" — refused |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. The round type is unknown, so weights are flat. Calls: "Atlas Freight operations manager interview process" — refused |
| 3. Atlas Freight strategy / recent news | unavailable | The CO bank: no company-strategy questions. Calls: "Atlas Freight logistics strategy news" — refused |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative operations manager JD | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions |

No company-specific fact in this pack comes from research. Everything about Atlas is from your JD text.

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- The round type and whether it is a panel → persona weights for each member.
- Atlas's published values page → a values cheat sheet, if the interview has a values round.
- Atlas's interview process, from the recruiter → loop structure and the true persona weights.
- The recruiter's prep email → coverage of any pre-declared deliverable.
- Your count of supervisors and sites you have directed → upgrades F3 and F7 from answer slots to stated fact.
- Real Power BI use, even a course → would move F5 from a stated absence to a plan with evidence.
- A reporting example you built in Excel → upgrades F5's Excel quote and C4 from low to medium confidence.
