# Ashgrove Credit Union: Member Experience Lead interview prep pack (loop mode)

Prepared 20 November 2026 for Dara. Three rounds on 29 November 2026: a 30-minute recruiter screen, a 45-minute round with the Head of Member Services (your prospective manager), and a 60-minute panel of two branch managers that also scores the four values.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (behavioural / values), EXP (your experience, tested for attribution), JD (the job's stated requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Each guidance cell rests on your own sentences, quoted in the Provenance column.
- **Answer slots** are instructions for the interview. Where the material does not show something, the slot asks you to say so in your own words. Saying "that wasn't mine" or "I haven't done that" is an honest answer.
- Every fact about your past in this pack comes from your message or the JD, the values, the recruiter's email or the strategy summary you gave me. Nothing else.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD, branches part) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." Your material covers the branch log, not the process end to end. Answer slot: the JD's "end to end" makes a probe on which parts of the process you ran likely. If you set any part of it, say which and how you decided. If you did not, say so and stay with the log you handled. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD, contact-centre part) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn contact-centre work, said as a plan and never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD, volumes part) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what the spreadsheet counted, in your own words. |
| F4 | "report monthly on complaint volumes and resolution times" (JD, resolution-times part) | none given | none | [grounded] | discovery | Answer slot: if the spreadsheet carried resolution times, say how they were measured. If it did not, say so and say what you would measure first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Your message says spreadsheet, not Excel, so the Excel link is unconfirmed. Answer slot: name the tools you used, in your own words, and what you did in them. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then the preparation you would do before a first senior presentation, said as a plan. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" and "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Your material shows teller training and supervising, not coaching supervisors. Answer slot: if you coached supervisors on escalations, say what you did. If not, say so and say how you would start. |
| F8 | "work with digital teams on self-service journeys" (JD; the brief's "move 40% of member service to digital channels by 2028", your summary) | none given | none | [grounded] | discovery | Answer slot: if you worked with anyone on a digital or self-service change, say what it was and what your part was. If not, say so and say how you would start. |
| F9 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Words: "6 years in retail banking, the last 3 as a branch supervisor." This is branch-based retail banking. The contact-centre part is F2. |
| F10 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." Your message says formal, not regulated. Answer slot: if an outside standard or timescale governed those complaints, say which and how you applied it. If none did, say so and say what made them formal in your log. |

Gates: none. The JD states no location, schedule or credential requirement, so no row is `hard_gate`. The JD says nothing about where the role is based (see the upgrade menu).

## Prohibited claims

These are not coached anywhere in this pack. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | "I handled the branch's formal complaints log." Pack observation, not words for you: the material shows the branch log, not the process end to end. |
| Has contact-centre experience | Negative you stated (F2) | "I haven't worked in a contact centre." No answer slot touches the past. |
| Has presented to senior leaders | Negative you stated (F6) | "I haven't presented to anyone above regional level." |
| Handled regulated complaints | Inflated form of F10 | "I handled the branch's formal complaints log." Pack observation: formal, not regulated. |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Works in Excel | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Chose the measures the monthly report tracks | Inflated form of F3 | The spreadsheet quote at its own scope. The measures are not in your words, so the answer slot asks what it counted. |

## Persona weights by round

Loop mode: each round has its own weights and bank. Depth follows weight: top persona 4 to 5 questions, mid-weight 3, low-weight 2.

| Round | Relationship prior | What the loop source changes | Weights |
|---|---|---|---|
| 1. Recruiter screen, 30 min | Conversational, plus light Skeptic | The recruiter's email sets a screen; logistics knockouts are the recruiter's own questions | Conversational 3, Skeptic 1, logistics slots 4 |
| 2. Head of Member Services, 45 min | Case and Skeptic (manager prior) | The recruiter says this round is "mostly behavioural", which lifts Values/Behavioral to the top and cuts Case to one question | Values/Behavioral 4, Skeptic 3, Pressure 2, Prober 2, Case/Strategist 1 |
| 3. Panel of two branch managers, 60 min | Peer Evaluator and Prober (blend of two peers) | The recruiter says the panel "score[s] against the four values" and runs a 20-minute escalation case, which lifts Values to the top | Values/Behavioral 4, Peer Evaluator 3, Case/Strategist 3, Prober 1 |

The Prober weight in round 3 is 1 on purpose. The spreadsheet is tested in depth in round 2 (H10 and H11). Round 3 tests the resolution-time gap (P8).

## Round 1: Recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through the journey." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in the order your sentences give: six years in retail banking, the last three as a branch supervisor; the complaints log you handled; the escalation script you trained tellers on; the spreadsheet your regional manager uses. Stop there. Add nothing beyond these sentences. | Casual opener, but it is scored. It tests the four-years requirement (F9) and the first evidence for F1, F3 and F7. |
| S2 | "What do you know about Ashgrove, and what drew you here?" | CO | [generic] | Name one thing from the values or the strategy, in your own words: the digital target, the hubs, or the small-business product. Say what you read, not what you think they will do. | Motivation check. The recruiter will score whether you have read the material. |
| S3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. This pack gives no figure and no range. | Pay is a knockout question, and the only safe answer is your own. |
| S4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | Notice is a knockout question with one honest answer: yours. |
| S5 | "Where are you based, and can you work across the sites this role covers?" | JD | [generic] | Logistics slot: name the locations you can work from, in your own words. The JD names branches and the contact centre but no location. | The posting leaves location open, so the recruiter may have a site list. |
| S6 | "Why are you looking to move now?" | EXP | [generic] | Logistics slot: give your own reason, in your own words. None is stated in your material. | Reason for leaving is scored for consistency with the rest of the process. |
| S7 | "Your background is branch-based, and the role covers the contact centre. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre" (your message) | Answer slot: say plainly that you haven't worked in a contact centre, then how you would learn it. Stay with what you have done. | Skeptic, light. This is the first knockout on the contact-centre line of the JD (F2). |
| S8 | "Is there anything you'd like us to know that isn't on your CV?" | Conversational | [generic] | Say only what you have already told me. If nothing comes to mind, say nothing extra. | An open invitation. The risk is adding a new claim under relaxed conditions. |

Requirement coverage, round 1: 4+ years in financial-services customer operations (S1); contact centre (S7); motivation, values and strategy (S2).

Reverse questions:
- "What does the role look like in its first three months?" Why it lands: it shows you read the JD's scope before you are asked about it.
- "Who is on the panel, and what is the order of the three rounds?" Why it lands: it confirms the process and the names, which are missing from your material and affect the next round's prep.

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you put a member's side ahead of a branch rule." | VAL | [generic] | Scaffold, Members First (cheat-sheet row 1). Pick a real decision where you chose the member's side. If none comes to mind, say so plainly, then give the nearest thing your material carries, F1: the log you handled, and how you would handle it differently. | Values/Behavioral, the top persona. Asked by the manager in the round the recruiter calls behavioural. |
| H2 | "Tell me about a time you changed an explanation because the member didn't follow it." | VAL | [generic] | Scaffold, Plain Words (cheat-sheet row 2). Pick a time an explanation was not landing and you changed it. If none, say so, then the nearest: F7, the escalation script, only if you can say in your own words how it was worded for tellers. | Plain Words is one of the four values the panel scores. |
| H3 | "Tell me about a time a decision about your branch had to answer to the people who bank there." | VAL | [generic] | Scaffold, Neighbours, Not Numbers (cheat-sheet row 3). Pick a decision that was local to the branch. If none, say so, then say what you did at your branch, in your own words. | Values round. Neighbours, Not Numbers is the value your material shows least. |
| H4 | "Tell me about a time you kept hold of a complaint until it was actually fixed." | VAL | [generic] | Scaffold, Own the Fix (cheat-sheet row 4). Pick a complaint you took to resolution. If none, say so, then the nearest: F1, and what you would do to keep one to the end. | Own the Fix is the value most tied to the role's end-to-end ownership (F1). |
| H5 | "I don't see contact-centre work anywhere in your background. How would you run the complaints process across the contact centre on day one?" | JD | [grounded] "Never worked in a contact centre" (your message); the JD's "across branches and the contact centre" | Answer slot: say plainly that you haven't worked in a contact centre, then what you would do in your first two weeks, in your own words. Hold through two follow-ups by coming back to the first two weeks. Never describe contact-centre work you have not done. | The highest-return rehearsal in this pack. The role's scope names the contact centre and your material is silent on it. Practise this one until the answer is calm and short. |
| H6 | "You've never presented above regional level. How would you present a monthly complaints picture to the executive team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); the JD's "confident presenting to senior leaders" | Answer slot: say plainly that you haven't presented above regional level, then the preparation you would do before a first senior presentation, as a plan. | The skeptic's version of F6. Stated limit, honest plan. |
| H7 | "What would coaching a branch supervisor on an escalation look like in your first month?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" (your message) | Answer slot: say what you did, which is train tellers on the escalation script. If you coached supervisors on escalations, say how. If not, say so and describe your first step as a plan. | The JD's coaching line (F7). Asks about the future, so it presupposes no past. |
| H8 | "Sixty seconds: what's the strongest reason to hire you when the role needs contact-centre work?" | Stress | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "Never worked in a contact centre" | Pause before answering. Restate the question. Anchor in the six years and the log, then concede the contact-centre gap specifically. Hold through two follow-ups; do not fold on the six years. | Time-boxed challenge. It tests composure and whether you concede a gap without going defensive. |
| H9 | "That's the branch's log, not the whole process. How much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Hold: "I handled the branch's log." Then say which parts were yours and which your team's, in your own words. Concede specifically, not vaguely. Do not fold on the log. | An attribution probe on F1. The honest answer is the one that holds. |
| H10 | "Did any of your complaints have an outside standard applied to them? Walk me through one." | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if an outside standard or timescale applied, say which and how you applied it. If none did, say so and say what made the complaints formal in your log. | The JD's "regulated complaints" line (F10). Prober, low-weight 2. |
| H11 | "Which figure in your monthly spreadsheet would you defend least?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name, in your own words, the assumption behind the figure you would defend least, before they do. Answer slot: if you cannot say how a figure was counted, say so. Say which part of the spreadsheet was yours, and which tool you built it in (F5). | Prober: tests the volumes requirement (F3) and the Excel line (F5), and turns a gotcha into a credibility gain. |
| H12 | "The brief moves 40% of member service to digital channels by 2028. Which complaints should move digital first, and which should stay with a person?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it); the JD's "work with digital teams on self-service journeys" | Answer slot: say which complaints you would keep with a person, and why. If you have worked with a digital team on a self-service change, say what your part was. If not, say so and say how you would start. | Covers the digital line (F8) against the strategy. The manager will check whether you can tell self-service from the complaints that still need a person. |

Requirement coverage, round 2:
- Own the process end to end, branches and contact centre: H5, H9
- Monthly volumes: H11. Resolution times: P8 (round 3; this round's Prober slot is H11)
- Coach branch supervisors on escalations: H7
- Regulated complaints: H10
- Presenting to senior leaders: H6
- Excel reporting: H11 (tool answer slot, F5)
- Digital self-service journeys: H12
- 4+ years in financial-services customer operations: S1 (round 1); not re-tested here

Reverse questions:
- "What does the complaints process look like across the eight branches as they move into five hubs?" Why it lands: it ties to the brief's consolidation and shows you read the plan. It makes no claim about any branch.
- "What is the first problem you'd want the new complaints lead to own in the first 90 days?" Why it lands: it asks for a named problem, which is the Own the Fix value in question form, and it signals you will take one on.

## Round 3: Panel of two branch managers (60 minutes, values scoring)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [generic] | Cheat-sheet row 1 applies. Selection scaffold ending in the honest branch. Keep it to 90 seconds. | Members First, scored by the panel. Same story bank as H1, told to two new listeners. |
| P2 | "Tell me about a time you had to make something plain for a member." | VAL | [generic] | Cheat-sheet row 2 applies. Scaffold, then the honest branch. | Plain Words, scored by the panel. |
| P3 | "Tell me about a time a branch decision had to answer to its own town." | VAL | [generic] | Cheat-sheet row 3 applies. Scaffold, then the honest branch. Two branch managers will listen for whether you know that a branch is part of its town. | Neighbours, Not Numbers, scored by the panel. The panel is branch managers, so the local frame is theirs. |
| P4 | "Tell me about a time you kept a problem until it was fixed." | VAL | [generic] | Cheat-sheet row 4 applies. Scaffold, then the honest branch. | Own the Fix, scored by the panel. |
| P5 | "Where should a complaint move between a branch and the contact centre, and who decides?" | JD | [generic] | Say the principle you would use, which is who owns the member's problem until it is solved. Name the decision-maker you would propose. Say plainly that you have not run a handover between a branch and a contact centre. | The JD's "across branches and the contact centre" line is the seam the peers will test. Peer Evaluator. |
| P6 | "Our two teams sit side by side. Where's the seam, and what happens when we disagree?" | Peer | [generic] | Propose seam principles, not a seam you have not seen. Tell a disagreement story only if it is yours: what you did, and whether it held. If none, say so and describe how you would handle the next. | Peer Evaluator's standard probe. Collegial, and it reads whether you know how to disagree. |
| P7 | CASE: "A member came into a branch about a disputed charge. The branch reversed it. The member came back saying the reversal took too long and the staff were unhelpful. They now want a senior person, and the branch supervisor has marked it resolved. You have 20 minutes. What do you do?" | CASE | [generic] (the escalation topic is the recruiter's, "a 20-minute case on a complaint escalation") | Clarify first: what the member is asking for now, what the record shows, what the reversal covered, and whether a timescale has been met. Structure: the member's need, the owner, the escalation path, the supervisor's role as coach rather than overrider, what you tell the member in plain words, and what you record. Think aloud. Challenge one premise: that "resolved" was the supervisor's decision to make alone. Say you would check any regulatory timescale rather than guess it. | The scored case. It tests the escalation, values and coaching together. The panel will judge structure and whether the member stays in the room. |
| P8 | "Did your monthly spreadsheet carry resolution times? If so, how were they measured?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if the spreadsheet carried resolution times, say how they were measured. If it did not, say so and say what you would measure first. Do not name a figure you do not have. | The JD's resolution-times line (F4). Branch managers who report on times will ask this. |
| P9 | "The brief consolidates eight branches into five hubs over 2027. What happens to an open complaint when its branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (the brief, as you summarised it) | Answer slot: if you have handled a branch change that moved complaints, say what moved and what did not. If not, say so and describe what you would check first. Do not assume either panel member's branch is closing. The brief does not say which branches move. | The panel may run branches in the programme. Not assuming it is the honest move. |
| P10 | "A branch manager wants a complaint closed before the review is finished. What do you say?" | Peer | [generic] | Say what you would agree and what you would hold. Name who decides on closure. Disagree with the reason, not the manager. Keep the member's view in the room. | Peer pressure, in its collegial form. Tests Own the Fix against the branch manager's pressure. |
| P11 | "A small-business lending product launches in Q1 2027. What complaints do you expect in the first quarter, and how would you know early?" | CO | [grounded] "launch a small-business lending product in Q1 2027" (the brief, as you summarised it) | Plan answer, not a past. Say what you would expect, label it a guess, and name the early signal you would watch. | Strategy-grounded CO question. The brief sets the product; it does not say what its complaints will be, so calibrated guessing is the correct answer. |

Requirement coverage, round 3:
- Own the process end to end, contact-centre seam: P5
- Monthly volumes and resolution times: P8
- Coach branch supervisors on escalations: P7 (case) and P10 (pressure from a branch manager)
- Digital self-service journeys: not tested in round 3 (H12 covers it)
- Regulated complaints and presenting to senior leaders: H6, H10 (not tested in round 3)
- Excel reporting: H11 (not tested in round 3)

Reverse questions:
- "What do you most need from the complaints lead in the first quarter?" Why it lands: it asks for a need, which is how a manager signals they will take a brief from you.
- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question for a peer panel. It turns the evaluation into a partnership conversation.

## Values cheat sheet (panel round)

The four values are from ashgrovecu.org/about/values, as you copied them on 20 November 2026. A story is mapped only where one of your quoted sentences carries it. None does here, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | None of your quoted sentences carries a decision of this kind. Scaffold: pick a decision where you chose the member's side, and say what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries: F1, the complaints log you handled, and how you would handle it differently. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | None of your quoted sentences carries this. Scaffold: pick a time you changed an explanation that was not landing. Nearest: F7, the escalation script you trained tellers on, but only if you can say in your own words how it was worded. |
| Neighbours, Not Numbers | Every branch is part of its town | None of your quoted sentences carries this. Scaffold: pick a decision that answered to the branch's own customers. If none, say so, then say what you did at your branch, in your own words (F9). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | None of your quoted sentences carries a closed case. Scaffold: pick a complaint you kept until it was resolved. If none, say so. The nearest is F1, the log you handled, and what you would do to keep one to the end. |

This is the largest thin spot in the pack. The panel scores the values, so find one real case for each value before the 29th. Use what you did, in your own words, and say plainly where you did not act.

## Grounding brief: the strategy vocabulary

These four facts come from the July 2026 strategy brief as you summarised it. Use the brief's own nouns: "member service", "digital channels", "hubs", "small-business lending". Quote the figures exactly once you have the brief's wording (see the upgrade menu).

- "move 40% of member service to digital channels by 2028" (the brief, your summary)
- "consolidate eight branches into five hubs over 2027" (the brief, your summary)
- "launch a small-business lending product in Q1 2027" (the brief, your summary)
- "the main competitive pressure is app-only banks" (the brief, your summary)

## Sources

- Your message: background, the complaint-escalation role, and the four facts used in F-rows. Provided.
- Job description: as you pasted it. Provided.
- Ashgrove values: four values copied from ashgrovecu.org/about/values on 20 November 2026. Provided.
- Recruiter email: the three-round structure, the panel's values scoring, the 20-minute case. Provided.
- 2026 strategy brief: your summary, not the document. Exact wording not in hand.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The four values you pasted fix this output. |
| 2. Ashgrove interview process, member service lead | skipped | Loop structure and round weights. The recruiter's email fixes the three rounds. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and the CO questions. Your summary of the July brief fixes the facts used; its exact wording is not in hand, and the upgrade menu asks for it. |
| 4. Interviewer names | n/a | No names given, so no query could be formed. The interviewer read is absent. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Head of Member Services and the two branch managers' names → persona weights read from their public footprint, and a tailored reverse question for each round.
- The brief's exact wording (the 40% digital line, the eight-into-five line, the Q1 2027 line) → H12, P9 and P11 move from your summary to the document's own words.
- Your CV → F1 to F10 move from your message to a CV. Rows can rise where there is inspectable material.
- The spreadsheet's column headings, with no member data → F3, F4, F5, H11 and P8 answer from what the spreadsheet actually tracked.
- The working locations, or a site list → S5 gets the real answer. If the role is tied to a location, that location becomes a gate row and is surfaced.
- One real case for each value → cheat-sheet rows 1 to 4 move from scaffold to grounded story.
- A deep-research pass (L2, offered once): public interviewer talks and posts, the brief's full text, and recent news. Cost: up to 6 further searches and 2 page fetches.
