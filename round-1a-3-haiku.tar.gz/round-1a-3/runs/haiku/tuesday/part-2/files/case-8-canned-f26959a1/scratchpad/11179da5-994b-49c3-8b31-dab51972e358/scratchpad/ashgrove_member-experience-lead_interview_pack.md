# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Loop mode. Three rounds on 29 November 2026. Interviewers: the Head of Member Services (round 2, your future manager) and a panel of two branch managers (round 3). Names not yet assigned, so there is no interviewer read.

## How to use, and type key

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

Types: **VAL** behavioural and values. **EXP** your own record. **JD** a requirement from the job description. **CO** company and strategy. **CASE** a live problem.

Provenance: **[grounded]** traces to your message, the JD, or the recruiter's email. **[inferred]** derived from those. **[generic]** a pattern for this kind of problem, with no claim about you or about Ashgrove.

Answer slot: an instruction for the interview with two honest branches, one for having done it and one for not. Logistics slot: a recruiter-screen question whose answer is yours to give. The pack supplies no figure or reason.

## Fit snapshot (shared across rounds)

Evidence quotes are your message unless marked otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material gives the years and the setting. Say it in those words. Expect the question whether branch work counts as customer operations, and answer with the work as you did it, not with a label. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows formal complaints, not whether they were regulated. Answer slot: if the log was checked against named rules or timings, say which and how you tracked to them; if it was not, say so plainly and say what the log did track. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" and "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Your material shows training tellers on the escalation script and supervising a branch. It does not show coaching supervisors. Say the teller training as it was. If you have coached a supervisor, say how, in your own words; if not, say so and give the nearest thing. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | A monthly report exists. Your material does not show whether it counted volumes, resolution times, or both. Answer slot: say what the spreadsheet counted; if it showed how long complaints took to resolve, say how; if not, say so, and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not name the tool, and "spreadsheet" is not "Excel". Derivation: the only reporting evidence is the spreadsheet. Answer slot: name the tool, and say what you did in it, in your own words. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's formal log. Say that. Do not stretch it to the process end to end, or to across branches. Make the case for the log and state its limits. |
| F7 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan, never as a past. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you worked with anyone on a digital or self-service change, say what it was and what your part was; if not, say so and say how you would start with the digital team. |

No requirement is a gate. The JD has no location, pay, right-to-work or credential condition, so nothing here needs a gate question.

Observation, in analysis and not words for you: nothing in your material covers the contact centre, presenting above regional level, or digital work. F7, F8 and F9 are where the panel will look first.

## Grounding brief (strategy brief, in hand)

Current framing, as your message gives it from the July 2026 brief:

- "move 40% of member service to digital channels by 2028" [grounded, your message]
- "consolidate eight branches into five hubs over 2027" [grounded, your message]
- "launch a small-business lending product in Q1 2027" [grounded, your message]
- "the main competitive pressure is app-only banks" [grounded, your message]

Eight branches into five hubs means fewer branch sites in the same towns. [inferred] from the two figures above. Expect questions about what that does to members, and answer from the member's side.

## Persona weights by round

| Persona | Round 1: recruiter screen, 30 min | Round 2: Head of Member Services, 45 min | Round 3: branch-manager panel, 60 min |
|---|---|---|---|
| Values/Behavioral | none | top, 2 questions | top, 2 questions, plus the scored values |
| Skeptic | light, 1 question | 2 questions | none |
| Data-Driven Prober | none | 2 questions | none |
| Case/Strategist | none | 1 question | 1 question: the 20-minute escalation case |
| Conversational | top, 5 questions | 1 question | none |
| Peer Evaluator | none | none | 2 questions |

Reasoning. Round 1: the recruiter-screen prior is Conversational with light Skeptic. The logistics are asked in a friendly register and are still scored. Round 2: the recruiter's email calls it "mostly behavioural". That moves Values to the top, above the hiring-manager prior of Case plus Skeptic. Skeptic stays because the JD gaps are where a manager will press. Round 3: a panel, blended from two branch managers, which are peer-type personas. Names are not known, so the weights are blended. The recruiter's email says the panel is the values round and includes a 20-minute case. Pressure is in no round's prior; the escalation case's follow-ups carry the one push-back.

The recruiter's email establishes the loop, so no archetype fallback is used.

## Prohibited claims

What this pack will not coach, and why. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F6 | "I handled the branch's formal complaints log." Observation: your material shows one branch's log, not the process end to end. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Reported resolution times every month | Inflated form of F4 | The spreadsheet at its own scope. Observation: the material does not show that times were tracked. |
| Built the reports in Excel | Inflated form of F5 | The spreadsheet at its own scope; name the tool only if you know it. |
| Worked in a contact centre | Stated negative, F7 | "I haven't worked in a contact centre." No slot. |
| Presented to anyone above regional level | Stated negative, F8 | "I haven't presented to anyone above regional level." No slot. |

## Round 1: recruiter screen (30 minutes)

Persona weights: Conversational top; light Skeptic. Coverage: the four logistics items and the career opener, plus motivation.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background in banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Give the six years, then the three as a branch supervisor, then the complaints log, in those words. Under two minutes. | F1 and F2 are the evidence this opener draws on, and the first place the interviewer checks them. Conversational register, scored for match with the CV. |
| R1-2 | "What are your pay expectations for this role?" | JD | [generic] no figure in your material | Logistics slot: give your own figure, in your own words, or ask what band the role carries before you name one. | Knockout-type logistics in a friendly register. No figure is supplied here. |
| R1-3 | "What is your notice period?" | JD | [generic] no figure in your material | Logistics slot: give the notice period you actually owe. | Same as R1-2. |
| R1-4 | "Are you able to work from the sites this role covers?" | JD | [generic] no location in your material | Logistics slot: name the sites and patterns you can actually work from. | Location may carry more weight than it looks: the strategy brief consolidates eight branches into five hubs over 2027. |
| R1-5 | "Why are you leaving your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Logistics slot: give the reason in your own words, true and brief. Nothing in your material states it. | The one Skeptic question. The reason has to hold up under the later probes on F7 and F8. |
| R1-6 | "Why this role, and why Ashgrove?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" | Say which part of that line you want to do, in your own words. Use a value only if it is yours: "Members First, Always — we decide from the member's side of the counter." | Motivation consistency. The JD line is the raising source; it asks for nothing you have not said. |

Reverse questions, round 1:

- "What does the panel score on, and is the case a written brief or spoken?" Why it lands: shows you have read the round, and the answer tells you the case format before 29 November.
- "How is the move from eight branches to five hubs affecting the complaints work?" Why it lands: shows you have read the July brief, and the answer tells you whether the complaints process is part of the change.

## Round 2: Head of Member Services, your future manager (45 minutes)

Persona weights: Values/Behavioral top, as the email's "mostly behavioural" sets it. Skeptic and Prober next, because the JD gaps are where a manager will press. Coverage: every JD requirement except the panel's own scoring.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "You haven't worked in a contact centre, and this role owns complaints across one. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre"; "Own the member complaints process end to end across branches and the contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: "I haven't worked in a contact centre. What I've done is handle the branch's formal complaints log." Hold through two follow-ups by returning to the log and to the teller training. Concede specifically: the contact-centre side is what you would learn first. Then one concrete plan, as a plan. Never claim contact-centre work. | The most likely objection: F7 against F6, asked as a manager would. The question presupposes only the negative you stated. |
| R2-2 | "Tell me about a time you put a member's side ahead of what the process said." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint in the log where the member's account and the process pointed different ways. Say what you decided and why. If none comes to mind, say so plainly, then give the nearest thing your log carries: how you handled a formal complaint through to its outcome. | Members First, scored. F2 and F6 are the only evidence, so the honest branch is not optional. |
| R2-3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Say what the complaint was, what fixed it, and what the member received. If you passed it on, say where and when it stopped being yours. | Own the Fix, scored. F6 is the scope limit: say what you held, not what the process held. |
| R2-4 | "Presenting a monthly complaints trend to senior leaders is part of this role. What is your plan for that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: how you would prepare, whom you would rehearse with, what would go on one page. A plan, not a past. | F8, the Skeptic's weak-day-one probe. The question takes its premise from the negative you stated. |
| R2-5 | "How did you make sure formal complaints in your log met the rules that applied to them?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log was checked against named rules or timings, say which and how you tracked to them; if it was not, say so plainly and say what the log did track. | F2, the Prober's version of the regulated-complaints requirement. |
| R2-6 | "A branch supervisor escalates a complaint two weeks late. How do you coach them?" | CASE | [generic] | Structure: find out why it was late; agree the standard; coach in one conversation about this case; check the next three escalations; record what you agreed. Say the coaching before the checking. Add your own coaching only if you have done it. The nearest fact your material holds: "trained new tellers on our escalation script". | The JD asks you to coach supervisors on escalations (F3). A live case, so it presupposes nothing about your past. |
| R2-7 | "Have you worked with a digital team on a self-service journey? Tell me about it." | JD | [grounded] JD: "work with digital teams on self-service journeys" | Answer slot: if you worked with anyone on a digital or self-service change, say what it was and what your part was; if you have not, say so plainly and say how you would start with the digital team. Casual in tone; scored. | F9, discovery. The strategy brief's 40 percent digital target means a casual question here is scored. |
| R2-8 | "Walk me through how the monthly complaints spreadsheet counted complaints, and which figure you would defend least." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet counted, in your own words. Name the assumption behind the figure you would defend least, if you know one; if you do not know how a figure was counted, say so. You built it: say that. If it showed how long complaints took to resolve, say how; if not, say so. Name the tool only if you know it. | F4 and F5 together. The Prober's defend-the-number slot. No figure is supplied, so none is defended for you. |

Reverse questions, round 2:

- "How do complaints move between a branch and the contact centre today?" Why it lands: it is the seam your F6 and F7 gaps sit on. The answer shows whether the role starts from a process or from nothing.
- "What would a good first 90 days look like in this role?" Why it lands: asks for their definition of success, and tells you which gap they will test first.
- "How will the move from eight branches to five hubs change who holds a complaint?" Why it lands: ties the strategy to the process you would own, and shows you have read the brief.

## Round 3: branch-manager panel (60 minutes, values round, 20-minute case)

The recruiter's email says: "The panel is also the values round — they score against the four values." Persona weights: Values top, scored; Case for the escalation case; Peer Evaluator for the seam. Coverage: the escalation case and the values scoring.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | The 20-minute case: "A member's complaint has been escalated to you twice, and the member says the explanation they were given does not make sense. What do you do?" | CASE | [generic] | Clarify first: what the member was told, by whom, and what they are asking for now. Check the rule that applies to the complaint before you decide anything. Decide who holds it now, and say so. Stop any further contact that repeats the wrong answer. Reply in plain words, with a date you will keep. Then find the root cause, fix it for the next member, and record the case. Say the order aloud. Expect push-back: hold the rule, and concede where you are unsure. | The panel's case. A pattern for the problem, with no claim about your history or Ashgrove's rules. Your teller training on the escalation script is the one past fact, and belongs at the step where you check the rule. |
| R3-2 | "When have you had to explain a decision to a member more than once?" | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Selection scaffold: pick a time a member needed a decision explained more than once, and say what you changed about the explanation. If none comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on the escalation script, and say what the script asked them to say, only as far as you know it. | Plain Words, scored. F3 is the only related fact. |
| R3-3 | "The plan moves eight branches into five hubs over 2027. What happens to the towns that lose a branch?" | CO | [grounded] "consolidate eight branches into five hubs over 2027"; "Neighbours, Not Numbers — every branch is part of its town." | Name the members who lose the nearest branch and what that costs them: distance, a trip, a phone call they did not need. Say what you would want from the branch team before any decision, and what you would check afterwards. If you have been through a branch change, say what happened and what you did, in your own words; if not, say so. | Neighbours, Not Numbers, scored, and the strategy's sharpest edge for a candidate who was a branch supervisor. No claim about you. |
| R3-4 | "Our branches and the contact centre are run by different people. Where's the seam, and what happens when we disagree?" | JD | [grounded] JD: "across branches and the contact centre" | Propose seam principles, not facts about their teams: who holds a complaint at each handover, who can reopen it, and how disagreement is settled. Say you would ask them before deciding the seam. | Peer probe on F6 and F7, asked collegially. |
| R3-5 | "Tell me about a time you disagreed with a peer about how a complaint should be resolved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a disagreement where you held a view and it was settled. Say what you did and what you conceded. If none comes to mind, say so plainly, then give the nearest thing: the log you handled, and how such a disagreement would have come up. | Peer Evaluator: spine and tact together. Own the Fix is the value it tests. |

Reverse questions, round 3:

- "Which complaint decisions does a branch manager make alone, and which go to the contact centre?" Why it lands: asks for the seam directly, and the answer shapes R3-4 and tells you what the role must own.
- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question for a peer panel. It turns the round into a working conversation.

## Values / principles cheat sheet

Values-style round detected: the recruiter's email documents one (the panel scores against the four values). Values text is in hand, copied 20 November 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2 and F6 carry the formal complaints log: "I handled the branch's formal complaints log". Use R2-2's scaffold. If no decision from the log was made from the member's side, say so and give the nearest thing it does carry. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F3: "trained new tellers on our escalation script". Use R3-2's scaffold. Claim only what you did with the script. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries a story. Selection scaffold: pick a time you weighed a member's local situation against a number. If none comes to mind, say so plainly; the R3-3 answer about the towns is the honest one. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F6: "I handled the branch's formal complaints log". Use R2-3's scaffold: say what you held, and where you passed it on. |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own the member complaints process end to end across branches and the contact centre | R2-1, R3-4 | |
| report monthly on complaint volumes and resolution times | R2-8 | |
| coach branch supervisors on escalations | R2-6 | |
| work with digital teams on self-service journeys | R2-7 | |
| 4+ years in financial-services customer operations | R1-1 | |
| experience handling regulated complaints | R2-5 | |
| confident presenting to senior leaders | R2-4 | |
| comfortable with Excel reporting | R2-8 | |

## Sources

Provided documents only: your message (the JD text, your background, the values text copied 20 November 2026, the recruiter's email with the round structure, and the strategy brief as summarised).

Research tier: L1, searches 0 of 6, fetches 0 of 2; no user links read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in hand, pasted from the site this morning; it fixes the values cheat sheet. |
| 2. Interview process | skipped | The recruiter's email names the three rounds, their lengths and who runs them; it fixes the loop. |
| 3. Strategy and recent news | skipped | The strategy points you pasted from the July 2026 brief fix the grounding brief. |
| 4. Interviewer name | n/a | No names yet; the interviewer read is absent. |
| 5. Representative JD | skipped | The JD is supplied and fixes the fit snapshot and JD questions. |

## Upgrade menu

- Panel members' names: per-member persona weights for round 3, and one reverse question tied to their own path.
- The recruiter's note on what the panel scores and how: sharper scoring anchors for the values cheat sheet.
- Your complaints-handling rules and their timings, as the log worked to them: turns F2 and R2-5 into a checkable answer, and gives the case real timings.
- Whether the spreadsheet was in Excel, and what its columns counted: upgrades F4 and F5 from discovery to a stated fact.
- The full July 2026 brief, not the summary: exact wording for R3-3 and the CO questions.
- How much prep time you have before 29 November: a prioritised triage section, which this pack omits for now.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, aimed at the loop reports and recent organisation context.
- The file tuesday-dossier.md, to record the gaps this prep exposed: it is an optional carry-forward file, not needed for this pack.
