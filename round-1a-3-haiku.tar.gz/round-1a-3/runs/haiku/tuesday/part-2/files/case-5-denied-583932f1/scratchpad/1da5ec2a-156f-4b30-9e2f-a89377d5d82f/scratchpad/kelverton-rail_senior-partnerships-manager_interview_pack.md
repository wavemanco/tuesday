# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a spoken point of view on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining time: Q&A, with commercial pushback from Ross.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL, EXP, JD, CO, CASE.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Ids: C = Deepa as Case/Strategist, S = Deepa as Skeptic, P = Ross as Pressure, R = Ross as Prober.

## Prep triage (about four hours)

1. **The point of view, about 90 minutes.** Choose one thesis from section 5, write its concession and its close, then speak it aloud three times with a timer. Stop at 12 minutes.
2. **Commercial pushback, about 75 minutes.** Rehearse P1, P2, R1 and S4 out loud. For each, hold your position through two follow-ups, then concede the specific uncertainty. Do not fold on the core claim.
3. **Live drills, about 45 minutes.** Ask for a Pressure drill on P1 and a Skeptic drill on S4 (see the drill offer at the end).
4. **Everything else is insurance.** Re-read the fit snapshot quotes once so you say your own sentences accurately, and skim the reverse questions.

## Fit snapshot

Requirements come from the recruiter's words, quoted in your message, because no job description was supplied. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "operator partnerships" (your message) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Your material shows the operator world from the planning side, not a partnership with an operator. Say it at that scope: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: if you worked with an operator on a commercial relationship, say what it was, in your own words; if you did not, say so and say what you knew from the planning side. |
| F2 | "Ross will push on commercials" (your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message), "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows influenced revenue, not revenue you owned. Bridge at that scope: "I've never carried a direct quota, only influenced revenue." Answer slot: if you can say how the partner growth or the influenced figure was counted, say so in your own words; if you cannot, say you do not know how it was counted. |
| F3 | "sells scheduling software to train operating companies" (your message, company description) | "Never sold into rail specifically" (your message) | medium | [grounded] | capability | This is a negative you stated, so the words are yours: "I haven't sold into rail." Then how you would learn the operator buyer, said as a plan and never as a past. Do not claim rail sales work. |

Seven checks on this table:

- Every quote is one of your sentences, quoted exactly, with its source named.
- F3 is a stated negative, so its words come only from that negative.
- No requirement is quoted from a job description, because none was supplied. Every requirement in this table is the recruiter's own phrase.

## Prohibited claims

The claims this pack will not coach, built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operator partnerships | Inflated form of F1: the material shows planning work, not partnerships with operators | F1's quote at its own scope. The limit is the pack's own observation: your material says planning work for operators, not partnership management |
| Sold into rail, or rail sales experience | Negative you stated (F3) | "I haven't sold into rail." |
| Carried a revenue quota or owned revenue targets | Negative you stated (F2) | "I've never carried a direct quota, only influenced revenue." |
| £4M of revenue | Inflated form of F2: "influenced" dropped | "roughly £4M of influenced revenue" |
| Built the channel on my own | Inflated form of F2: sole credit for growth you did not state | Quote at scope: "running the ISV channel — took it from 6 partners to 40" |

## Persona table

No interviewer profiles were available to research, so weights rest on relationship priors and the recruiter's own description of the round. Panel: each member's top two personas.

| Interviewer | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa (future manager) | Case/Strategist, weight 5 | Live problems on operator partnerships; asks how you'd start | High. The round is for a hiring manager, and the POV is a live problem by design | Clarify first, then structure, then name the operator outcome |
| Deepa | Skeptic, weight 4 | Probes the rail gap and the quota gap, asks why you | High. F3 and F2 are the gaps the material shows | Plain acknowledgment, then bridge at the quote's scope |
| Ross (Commercial Director) | Pressure, weight 4 | Time-boxed pushes on influenced revenue and on commercials | High. The recruiter says Ross will push on commercials | Pause, restate, hold through two follow-ups, then concede |
| Ross | Prober, weight 4 | Asks how the £4M and the partner growth were counted | High. Headline figures are where probers start | Name the weakest assumption before he does |

Depth follows weight: the top persona gets five questions, the others four. Total questions: 17.

## Reading the interviewer

Not included. No public profile was available, and no web search was run (see Sources). The upgrade menu says what a name would unlock.

## Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| "operator partnerships" (your message) | C1, C3, R4 |
| "what it means for the operators themselves" (your message) | C2, P4, R4 |
| "Ross will push on commercials" (your message) | P1, P2, P3, R1, R2, S4 |
| Rail and train operating companies (your message) | S1, S2, C4 |
| "over the next 18 months" (your message) | R4 |
| Hard requirements from a job description | none, and why: no job description was supplied, so there are none to map. Upgrade menu |

## The graded deliverable: the 15-minute point of view

The recruiter asked for a short spoken POV, so this section is graded. Grounded facts to build on:

- F1: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message).
- F2: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message).
- F3: "Never sold into rail specifically" (your message).

Each thesis below is a pattern, not a claim about Kelverton. None has been checked against the market report, because I have not seen it. Each carries a concession you must say aloud.

**Thesis 1: measure operator partnerships by the outcome the operator already reports.** [generic] The consensus answer would be more integrations and a bigger partner network. Your differentiation: pick the operator metric (punctuality, timetable change time) that the operator already tracks, and tie the partnership to it. Concession: "I don't yet know which metrics Kelverton's operator contracts already tie to. I'd check that in the first month before I promised anything."

**Thesis 2: operators co-own the change cycle, with pilots on one timetable change.** [generic] Your differentiation: operator planners work the timetable change, so the partnership starts there, not at a sales call. Concession: "Operators have limited capacity for pilots, so this costs time, and it may slow the pipeline."

**Anti-pick: do not chase every operator.** [generic] Where the role requires saying no, say it. Choose the two or three operators where a change moves the reported outcome, and decline the rest for now. Concession: "This leaves some interest unanswered, and I'd say that to the operators who asked."

**Requested close: what it means for the operators themselves.** End on one thing a planner at an operator does differently in the first 90 days. Use no number you have not checked. The recruiter named this close, so do not end on the partner network.

## Question banks

### Deepa: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Operator partnerships are what we want to grow. Where would you start in the first 90 days?" | CASE | [grounded] "operator partnerships" (your message) | Clarify before you structure: which operators, which contracts, what the current partnerships deliver. Then a plan in three steps, each with one measure. Speakable in 90 seconds | The recruiter's own phrase; CASE because it is a live problem, and F1 is the gap it tests |
| C2 | "We want your POV to land on what it means for the operators themselves. What does that look like for a planning manager?" | CASE | [grounded] "Please land on what it means for the operators themselves." (your message) | Name one operator outcome and how you would know it moved. Make no claim about current customer results | The close the recruiter asked for; the answer is the operator's view, not yours |
| C3 | "You spent five years on bus and light rail planning. What did you decide in that work, as opposed to recommend?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Answer slot: if you made the decision yourself, say which and how; if you only recommended it, or it was not yours, say so plainly and describe what you recommended | F1 is the bridge; the question tests whether the planning work was yours |
| C4 | "Two operators want the same timetable change in the same month. How do you decide which partnership gets your effort?" | CASE | [generic] | Structure it: what each operator's change is worth to them, what you can deliver, and what you would tell the second operator. The answer makes no claim about your past | A live problem for the role; it tests the anti-pick |
| C5 | "Six partners to forty. What was the first thing you changed, and how did you know it worked?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Tell the story in your own words: the first change, the sign it worked, and what you would not claim. Answer slot: if you cannot name how you knew, say so | F2 is the best story you have; the question tests whether you know its mechanics |

### Deepa: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never sold into rail. Why would an operator buy from someone who hasn't?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I haven't sold into rail." Then say how you would earn an operator's trust: through the planning knowledge you have, and by listening first. Do not claim rail sales work | F3 is the gap; this is the most predictable objection, so the answer is rehearsed plainly |
| S2 | "Why this role, when there are rail-native candidates?" | JD | [grounded] "so I know the operator world from the other side" (your message) | Give your reason in your own words. If the reason is not yet clear to you, say what you would need to find out before you could answer fully | F1 and F3 together raise the motivation probe |
| S3 | "Your last four years were a payments company's channel. What transfers to an operator, and what doesn't?" | JD | [grounded] "running the ISV channel" (your message) | Say what transfers (channel mechanics, partner onboarding) and what does not (the operator buyer, the procurement cycle). Concede the second one clearly | F2 is adjacent work; the honest answer names the limit |
| S4 | "You've never carried a quota. How do you know you can own a commercial number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I've never carried a direct quota, only influenced revenue." Hold through two follow-ups by returning to what you measured. Then concede the specific uncertainty about owning a number | This is the highest-ROI rehearsal in the pack: the objection will come in some form, and the hold is only what you stated |

### Ross: Pressure (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should a commercial director bet on a partnerships hire with no quota?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message); "Ross will push on commercials" (your message) | Pause, restate, then answer from what you measured. Hold your position through two follow-ups. Concede the one thing you cannot yet show | Pressure tests composure; the hold is the quoted negative, not a stronger claim |
| P2 | "Roughly £4M. How much of that was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the scope: influenced, not won. Concede what you cannot apportion, specifically. Do not defend the figure beyond what you can count | The likeliest pressure line; the honest answer is the scope |
| P3 | "Influenced revenue is what everyone claims. Name one number you would defend to me in this room." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: name the figure you would defend, and say how it was counted, in your own words. If you do not know how it was counted, say so | Defend-the-number slot on F2 |
| P4 | "Give me the commercial case for operators in one minute, without using the word partnership." | CASE | [generic] | Structure: the operator's cost or lost time, what changes for them, and how you would know. One minute, no claim about current results | A time-boxed pressure case that ties to the POV close |

### Ross: Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know how it was counted, say so in your own words. If you do not, say "I don't know how it was counted," and say what you would ask for | The defend-the-number probe; a figure you cannot repeat under a second question is worse than none |
| R2 | "Which assumption behind six-to-forty would you defend least?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name the weakest assumption before he does: that the growth came from the channel, not from the market. Say it as your assumption, not as a fact | Weakest-assumption move; this converts a gotcha into credibility |
| R3 | "In your POV, what number tells us an operator is better off in twelve months?" | CASE | [grounded] "what it means for the operators themselves" (your message) | Name one operator measure and how you would check it. Make no claim about current operator results | Tests whether the close is measurable, not just stated |
| R4 | "How would you know the first partnership was working, and by when?" | CASE | [grounded] "over the next 18 months" (your message) | Give one leading measure and one lagging measure with dates. Say which you would not trust yet | The 18-month frame, made measurable |

## Reverse questions

Each has a why it lands. No interviewer profile was available, so none ties to an interviewer's career path.

1. To Deepa: "What would make the first six months clearly successful for you?" Why it lands: it shows you are planning to her measure, not yours.
2. To Deepa: "Which operator relationship is working best today, and what makes it work?" Why it lands: it shows you want to learn from the base before you change it.
3. To Ross: "Where do partnerships and commercial numbers meet, and who owns that number?" Why it lands: it turns his pushback into a question of shared ownership.
4. To Ross: "When a partnership and a sale conflict, which one wins?" Why it lands: it names the tension he will test, and shows you have thought about it.
5. To both: "What did the last person in this role get right, and what did they get wrong?" Why it lands: it asks for the honest version, which is the one you need to plan from.

## Sources

Provided documents: your message, including the recruiter's email as quoted in it. The market report the recruiter attached was not in my context, so I have not read it, and no part of this pack draws on it.

Research: Research tier: L1 — searches 5 of 6, fetches 0 of 2. Every search call was refused because search permission was not granted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet would have needed the official values page. Not built |
| 2. Kelverton Rail interview process | unavailable | Loop structure. The recruiter's email already names one 60-minute panel, so the loop is established without it |
| 3. Kelverton Rail strategy and recent news | unavailable | Competitive frame and current priorities. The grounding brief and differentiator questions are generic as a result |
| 4. Deepa, VP Partnerships, Kelverton Rail, and Ross, Commercial Director, Kelverton Rail | unavailable | Interviewer read and persona weights. Persona weights rest on relationship priors only |
| 5. Representative Senior Partnerships Manager JD | unavailable | Fit requirements. Requirements here come from the recruiter's words, not a posting |

Queries sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process"; "Kelverton Rail strategy news"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail".

## Upgrade menu

- Job description text → requirement rows become [grounded] from the posting; the coverage table gains a row for each hard requirement, with question IDs.
- Key lines from the market report, pasted → theses in section 5 can be differentiated from the consensus answer; C1 and P4 can name current facts.
- Any gate terms (location, office days, right to work) → the fit snapshot gains gate rows, each surfaced prominently.
- Search permission granted → the five refused targets can run at L1 (six searches, two fetches), which would build the values page, the loop, the strategy frame and the interviewers' public footprint.
- Interviewer names with public profiles or talks → a persona weight for each of Deepa and Ross, and reverse questions tied to their career paths.
