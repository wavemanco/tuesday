# Interview prep: Operations Manager, Atlas Freight

Round: not stated. Built for a hiring-manager round with flat-leaning persona weights, because the round type and the interviewer are unknown. Interviewer: not known. Research: none ran (see Sources).

## How to use

Personas are how a question is asked. Types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and stop where your own experience stops.

| Type | Meaning |
|---|---|
| EXP | Your past work, and whether the claims on your CV or in your message hold up under questions |
| JD | Whether you can do the listed job, gaps included |
| CASE | A live problem from the role, scored on structure and reasoning |
| VAL | Past behaviour against values or principles; none are published for this employer that we could read |
| CO | Company knowledge; not covered, because research did not run |

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. No requirement here is a gate: the posting states no authorisation, licence, location, schedule, pay or travel term, and length of experience is graded as fit, not as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows shift management and a surge plan at one site, and the bridge stays at that scope: "currently a senior shift manager over 3 supervisors", and the surge plan, run two years. Four sites are not shown. Answer slot: if you ran daily operations across more than one site, or directed a site other than your own, say which and how; if not, say so and say how you would take on four. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The figure is mis-picks, not on-time performance or cost per shipment, so the quote stays at its own scope: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment at that site, say what it did and how it was measured; if you did not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The bridge is the three you lead, at that number: "over 3 supervisors." Twelve is not shown. Answer slot: if you have led more than three supervisors, or a group that size in any role, say how many and in what capacity; if not, say so, and say how you would build up to twelve. |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [grounded] | discovery | The seven years are operations work; your material does not show how many were leadership. Answer slot: state how many years you have led people, in your own words; if fewer than five, say so plainly and say what leadership you did carry. |
| F5 | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | low | [grounded] | discovery | Excel skill is your own word; the material does not show reports you built. Bridge at its own scope: "solid Excel." Answer slot: if you built a report or tracker in Excel that others used, name it and what it tracked; if you did not, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | Plain acknowledgment, from your own words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement. A certificate is inspectable, so it would raise this row to high if you bring a copy. |

Requirement coverage: "Own daily terminal operations across 4 sites" → B1, B4, D3. "drive on-time performance and cost-per-shipment down" → A3, B2, B3. "lead a team of 12 supervisors" → A1, D3. "build reporting in Excel/Power BI" → A5, C3. "5+ years operations leadership required" → A2, F1. "Lean/Six Sigma a plus" → F2.

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs operations across four sites | Inflated form of F1 | The quotes at their own scope. Your material shows one site. |
| Leads twelve supervisors | Inflated form of F3 | "over 3 supervisors" at its own scope. |
| Improved on-time performance or cost per shipment | Inflated form of F2; the figure you gave is mis-picks | "cut mis-pick rate 40% by redesigning the pick path" at its own scope. |
| Five years of operations leadership | Inflated form of F4 | "7 years in warehouse and distribution ops." Your material does not show how many of those years were leadership. |
| Has built reporting in Excel or Power BI | Inflated form of F5 and F6 | "solid Excel" at its own scope; "I haven't used Power BI." |

## Persona weights

Relationship prior for a hiring manager is Case/Strategist plus Skeptic (`personas.md`). Your round type is unknown and no loop source was read, so weights are flatter than they would be with a known loop. Every plausible persona gets questions so you never meet a style live for the first time.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 questions | Quiet probing of the scale and tool gaps | Highest: the JD asks for 12 supervisors, 4 sites and Power BI, and your material shows 3 supervisors, one site, and no Power BI | Name what you have, then the honest branch; concede the gap without folding |
| Case/Strategist | 4 | Live problems from the terminals | High for a hiring manager; scores structure, not a right answer | Clarify, then objective, then approach, then metrics, then risks |
| Data-Driven Prober | 3 | Asks how the 40% was counted | Medium: the headline figure is the most likely probe | Name the weakest assumption you know before they do; say plainly what you do not know |
| Pressure | 3 | Time-boxed challenge on fit | Medium: a hiring manager often tests a stretch hire this way | Pause, restate, hold two follow-ups, then concede the real gap |
| Values/Behavioral | 2 | Open prompts on past conduct | Low: no values were read and no values round is detected | Selection scaffolds with the honest branch |
| Conversational | 2 | Casual "walk me through" openers | Low to medium: casual questions are still scored | Pre-rehearsed 90-second arc; treat JD plus-skills asked casually as scored |
| Peer Evaluator | 2 | Seam and credit questions | Low for a hiring manager; touched for safety | Seam principles, not invented history |

## Question banks

### A. Skeptic (5)

Highest-ROI prep in this pack: **A1**. The gap it names, from F3, is the one the JD states most plainly.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today, and this role leads twelve. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); raising source, JD: "lead a team of 12 supervisors" | Start with the three, in those words. Then the honest branch: if you have led more than three, say how many and in what capacity; if not, say so plainly, then say what you would do first with the supervisors you would inherit. Hold through two follow-ups by returning to the three. Concede "I haven't led twelve" without folding on what you did lead. | F3 is the largest gap the JD names, and this is the question a skeptic asks first. |
| A2 | "The role needs five years of operations leadership. How many of your seven years have you led people?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); raising source, JD: "5+ years operations leadership required" | Answer slot: give the number of years you have led people, in your own words. If fewer than five, say so, and name the leadership you did carry. Do not round up. | F4 is the row where your material is silent on leadership years, and this question presses exactly there. |
| A3 | "Our terminals are measured on on-time performance and cost per shipment. Your number is mis-picks. What is the link?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); raising source, JD: "drive on-time performance and cost-per-shipment down" | Hold: the mis-pick rate is what you cut, at its own scope. Answer slot: if you tracked on-time performance or cost per shipment at your site, say what it did and how it was measured; if not, say so and say what you would measure first. Never claim an on-time or cost change. | F2 is adjacent work, not a direct match. |
| A4 | "Your mis-pick rate fell 40%. What was it measured against, and which part of that figure would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot, four parts, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Your material does not give a baseline or a method, so do not supply one. "I don't know how the baseline was counted" is an honest branch. | The headline figure is a magnet for probes, and the four parts are the defend-the-number slots. |
| A5 | "You have never used Power BI, and this role builds reporting in it. What happens in your first month?" | JD | [grounded] "never used Power BI" (your message); raising source, JD: "build reporting in Excel/Power BI" | Plain acknowledgment: "I haven't used Power BI." Then the plan: how you would learn it and what Excel work you would deliver first, said as a plan. Never a claim to past Power BI work. | F6 is a stated gap, so the honest answer is the acknowledgment and a plan. |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Peak season starts in six weeks. Two of our four sites are behind on on-time performance. What do you do in the first 48 hours?" | CASE | [generic] | Clarify what "behind" means, which volumes and which constraints. State your objective, look first at what differs between the two sites, then say what you decide yourself and what you escalate. Name the data you would need and where it sits today, without naming tools you have not used. | A live problem from the role; it asserts nothing about your past, so the guidance makes no claim. |
| B2 | "On-time performance is slipping at one site while cost per shipment rises at another. Which do you fix first, and how do you know?" | CASE | [generic] | Clarify the definitions and the time window. Give the prioritisation logic in steps. Say what evidence would change your order. | Tests the JD's two stated outcomes, neither of which your material measures directly. |
| B3 | "You cut mis-picks by redesigning a pick path at one site. How would you decide whether to roll that out to all four?" | CASE | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Start from the change you made and the one measure you have for it. Then the test you would run at a second site before any rollout, and what would stop the rollout. Do not claim the change worked anywhere else. | F2 is the nearest evidence to a multi-site decision, and only at one site. |
| B4 | "What would you need to know about a site in its first two weeks before changing anything?" | CASE | [generic] | Volumes and their shape, the labour model, systems in use, supervisor capability, the safety record. Say that you would ask before you act. | Tests whether you structure before answering across four sites, which the JD requires. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your message says seven years in warehouse and distribution. Were those continuous, and in which roles?" | EXP | [grounded] "7 years in warehouse and distribution ops" (your message) | Give the roles and the dates you can state. If you cannot state dates exactly, say so; do not reconstruct them under pressure. | Tests whether the years you claim survive a second question. |
| C2 | "Walk me through how that mis-pick number was counted, and who did the counting." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: say how it was counted and by whom, in your own words. If you do not know, say so. Do not invent a counting method. | A method question on the headline figure; kept separate from A4, which asks which part you would defend least. |
| C3 | "Which report do you read each morning to run your shift, and what does it show?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); raising source, JD: "build reporting in Excel/Power BI" | Answer slot: if you have a daily report, name it and what it shows; if you run the shift from a list or a verbal handover, say that plainly. | F5 is the reporting evidence the JD names, and the honest answer may be no report at all. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already run more than one site?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, then restate the question. Answer from what you ran and what you would do first. Do not disparage the other candidate. Concede the four-site gap plainly. | F1 and F3 are the rows a pressure interviewer goes to first. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Answer slot: say which parts of the redesign were yours to set and which were the team's. If the redesign was not yours, say so, and say what you did do. Never fold on the claim that the work happened. | The attribution probe the rubric expects; your sentence does not say who redesigned the pick path. |
| D3 | "You are being considered for a bigger job than anything on your CV. Why should I believe you can grow into it?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Hold the position in what you have done, not in what you will become. Concede the scale is larger. Say how you would learn the scale, as a plan. | Tests stretch-hire composure, which F3 and F4 make likely. |

### E. Values/Behavioral (2)

No values were published that we could read, and no values round is detected, so these are generic prompts.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to someone above you." | VAL | [generic] open prompt from a standard behavioural stem | Pick a time you had to raise a problem with someone senior: it needs a named stake, a moment you did not fold, and a working relationship afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the mis-pick work, and what you did about it. | Open prompt; the guidance chooses no story for you. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] open prompt from a standard behavioural stem | Pick a time a delivery or a customer was at stake and a metric pulled the other way. If none comes to mind, say so plainly, then give the nearest honest example, and say what was yours to decide. | A values prompt with no published values to map to. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the journey from the warehouse floor to shift manager." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: where you started, what changed in your responsibilities, where you are now, in your own words. Add no steps you did not take. | Casual openers are scored, and this one tests your arc and your years in one answer. |
| F2 | "What are you playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" (your message) | Name the green belt, then only what you actually applied it to. If the belt is the whole story, say that. | JD plus-skill asked casually; F7 covers it. |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our shift leads sit beside yours. Where is the seam between our teams, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns handovers and who decides a schedule clash, rather than inventing history. For disagreement, pick a time you were right and it cost something; if none comes to mind, say so. | Peer probes are about turf and load, and your material contains no disagreement story. |
| G2 | "How do you handle credit when a result spans two teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if the mis-pick result involved other people, say who did what, in your own words. If you cannot separate the credit, say so. | Peer-style credit probe tied to your headline result. |

## Reverse questions

No interviewer profile exists, so these are role-generic. Ask two or three, not all six.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four sites is furthest from its on-time target today, and what is behind it?" | It asks for the real operating picture and signals where you would start. |
| R2 | "How is cost per shipment measured here, and who owns that number?" | It shows you test assumptions, which is what the Prober persona scores. |
| R3 | "What reporting exists for the terminals today, and what is missing for this role?" | It tests the Power BI gap honestly and gives you the scope of the learning plan. |
| R4 | "How many supervisors does this role lead directly, and how are they spread across the sites?" | It asks directly about the twelve and shows you want the structure, not a rough figure. |
| R5 | "What is the biggest decision this role makes alone?" | It puts you at the job's altitude and tells you where the authority sits. |
| R6 | "What would the first 90 days need to deliver for you to call the role a success?" | It converts a generic close into a priorities question, and the answer shapes your first-month plan. |

## Sources

- Provided: the JD (pasted in your message) and your background (your message). Both are the only inputs used for the fit snapshot.
- Searches sent, both refused by the host, so neither returned any result:
  - "Atlas Freight regional logistics values": refused.
  - "Atlas Freight interview process operations manager": refused.
- Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet would have moved; search refused, so no values are established and none are used. The values cheat sheet is absent. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure would have moved persona weights; search refused, so no loop source establishes the loop. Weights use the hiring-manager prior, flat-leaning, as the generic archetype. |
| 3. Atlas Freight strategy and recent news | unavailable | The CO bank and grounding brief; no call sent, because the host would not run searches for this pack. |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name, or the round type (hiring manager, peer, panel) → persona weights from your interviewer's own public footprint, and a tailored reverse question.
- The recruiter's note on the process or focus areas → confirms whether the loop has several sessions; if so, per-session mini-packs.
- A copy of the Atlas Freight values page, pasted → a values cheat sheet, and VAL questions mapped to real published values.
- A deeper research pass, if search permission is granted: up to 6 more searches and 2 more fetches, several more minutes, for strategy and loop reports → CO and CASE questions grounded in Atlas Freight's current strategy.
- A copy of your operations certificate → F7 moves from medium to high confidence.
- A daily report you use, pasted or described → C3 and F5 gain a specific artifact to name.
- Prep time before the interview → a prioritised schedule of the questions above.
- With no dossier present, a tuesday-dossier.md would record the gaps this prep exposed, for carrying into later sessions.
