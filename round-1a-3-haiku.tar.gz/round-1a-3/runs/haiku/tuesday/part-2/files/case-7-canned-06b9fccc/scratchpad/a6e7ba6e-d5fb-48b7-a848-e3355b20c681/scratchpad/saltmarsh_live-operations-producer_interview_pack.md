# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (relationship not yet confirmed; built as hiring manager, see Persona weights)
Round: the Outage Hour, 60 minutes, per saltmarshgames.com/careers/interviewing
Changelog: first build.

## How to use

Personas say how a question arrives. Types say what is being scored: **VAL** (values), **EXP** (your experience, probed), **JD** (the listed job), **CO** (company knowledge), **CASE** (live problem). Guidance is scaffolding, not a script. Say it in your own words, and stop where your own experience stops.

Prep triage is dropped: prep time is not yet known.

## Fit snapshot

Requirements come from the JD you supplied. Evidence is quoted from your message ("your message") and nowhere else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The sentence says one title. For the second, the words stay at one: "For two years I ran the content-drop calendar for our main title." Answer slot: if you planned for a second title, say how; if not, say how you would take it on. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the line directly. Lead with the weekly cadence and the two years, in those words. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [inferred] | discovery | Four years is past the bar, but the material does not show the game was live-service. Answer slot: say how the title ran live (updates, events, content drops), in your own words. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The sentence says you presented the numbers, not that you built or owned them. Say that: "I presented the monthly retention numbers to the studio head." |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the line. The durability ("still uses") is the sentence's own, and it is the strongest fact in the pack. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show cross-team coordination. Answer slot: if you coordinated those teams on an update, say which and how, in your own words; if you did not, say so and describe how you would sequence them. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran one, say what it contained; if not, say so and describe what you would put in one. |
| F8 | Monetisation model, not a JD line; see the Larkspur note below | "never worked on a game with in-app purchases" (your message) | none | [inferred] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan and never as a past. |

**Note on F8 (an inference, not a fact about the role):** Saltmarsh's news page (search result, September 2026) says Project Larkspur moves two titles to a season-pass model with one shared events calendar from February 2027. Read that as material already in hand: a monetisation-linked calendar is likely to be probed. It is not a JD requirement and no question below quotes it as one.

**Leadership:** the JD does not ask you to lead a team, but it asks you to coordinate four teams without line authority. Your sentence "Never led a team" bears on F6, and it is a limit to state plainly, not a gap to hide.

## Prohibited claims

What this pack will not coach, and why. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: your material says one title. |
| Led a team | Negative you stated | "I haven't led a team." No slot. |
| Owned the post-event review and KPIs | Inflated form of F4 and F7 | "I presented the monthly retention numbers to the studio head." The post-event review is an answer slot (F7). |
| Ran live-service production | Inflated form of F3 | Describe the title's live cadence in your words (F3's slot). |
| Worked on a game with in-app purchases | Negative you stated | "I haven't worked on a game with in-app purchases." No slot beyond the plan to learn it. |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Case / Strategist | 35% | The Outage Hour's first half is a live-incident tabletop, per the careers page. |
| Values / Behavioral | 30% | The same hour ends in a values conversation (careers page). A values round is therefore documented by a loop source. |
| Skeptic | 25% | A hiring manager is buying capability and derisking gaps: F3, F6, F8. |
| Data-Driven Prober | 10% | Your retention line is the one figure in the material; it draws a light probe. |

The weights come from the hiring-manager prior. The round is one hour, so the top two personas share it.

## Reading the interviewer

Only the name and title, from your message, are in hand. A search returned a talk listing for Tobias Wrenfield at GDC 2026, but on a domain that is not the event's own and I did not fetch it, so I have not used it. Without a confirmed profile, the persona weights stay at the round prior, and the reverse questions stay role-generic.

## Question banks

### Case / Strategist (weight 35%)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A bad build has gone out to one platform during a live event. Walk me through the first 30 minutes." | CASE | [grounded] the Outage Hour format, saltmarshgames.com/careers/interviewing; scenario [generic] | Clarify first: which players, which platform, what is live, what the rollback costs. Then contain, tell the players what happened, decide rollback or patch, and name who you would call. Say what you need to know before you pick a branch. | The tabletop is the Outage Hour's stated first half. Scenario is a pattern, not a fact about this studio. |
| A2 | "A limited-time event is tracking 20% under plan on day three. What do you check, and what do you change?" | CASE | [generic] | Structure: check the event's entry and reward, the funnel, then the retention of the players already in it. Name the one assumption you would test first. Change only what the data points at. | Retention is in the JD; this tests whether you read the number before acting. |
| A3 | "You are planning the calendar for two titles on one team. How do you start?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Start from what you know: "For two years I ran the content-drop calendar for our main title." Answer slot: if you planned for a second title, say how; if not, say how you would take on the second title's cadence. | F1. The premise is the JD's, and the answer slot allows that you have not done it. |
| A4 | "Which dependencies would you pull into a calendar first: design, art, engineering or community?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: if you coordinated those teams on an update, say which and how, in your own words; if you did not, say so, and describe how you would order the four. | F6. No quote carries coordination, so the answer is a slot. |

### Values / Behavioral (weight 30%)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a release went out differently from what was announced." | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (saltmarshgames.com/values); candidate evidence "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: pick a release where what shipped and what was announced did not match. If none comes to mind, say so plainly, then give the nearest thing your material carries: the checklist and what it was built to catch. | Values round, mapped to the published value. The sentence supports the checklist, not an outcome. |
| B2 | "When the calendar and the players disagreed, what did you do?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (saltmarshgames.com/values); candidate evidence none given | Selection scaffold: pick a time a planned date or event was moved for players' sake, or a time you wanted to and did not. Say what you chose and why. If none comes to mind, say so plainly. | The value is published. Your material shows no such decision, so the answer is a slot. |
| B3 | "What did you leave better than you found it?" | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." (saltmarshgames.com/values); "Wrote the release checklist our QA team still uses." (your message) | Describe the checklist: what you wrote it to cover and who uses it now. Do not claim it caused fewer bugs; your sentence says it is still used. | Mapped to the checklist, at the checklist's own scope. |

### Skeptic (weight 25%)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've not worked on a game with in-app purchases. How would you plan events for one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: which metrics you would read first, who you would learn from, and what you would ask in your first week. Say it as a plan, never as a past. | F8. This is the objection most likely to land; rehearse it until it is boring. |
| C2 | "You've never led a team. How would you coordinate four teams on an update when none of them report to you?" | JD | [grounded] "Never led a team" (your message); the coordination line of the JD | Plain acknowledgment: "I haven't led a team." Then answer slot: if you coordinated across teams without authority, say how; if you did not, say so, and describe the cadence you would set. | F6 and the leadership limit. |
| C3 | "You presented retention numbers to a studio head. What exactly did you show, and whose figures were they?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you presented and how often. Answer slot: if you built the figures, say how they were counted; if they came from someone else, say whose. Do not name a definition you did not set. | F4. Presented is the verb; keep it. |

### Prober (weight 10%)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role owns the KPIs your post-event review reports. What would yours have contained?" | EXP | [grounded] the JD's "own the post-event review and the KPIs it reports" (JD); candidate evidence none given | Answer slot: if you ran a post-event review, say which KPIs it reported; if you did not, say so and describe the four KPIs you would start with. | F7. No quote carries a review, so the answer is a slot. |
| D2 | "Three years of live-service is the bar. Which part of your four years was that?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Answer slot: say which part of the four years ran as a live title, and how you can show it (update cadence, events, content drops). If none of it did, say so. | F3. The four years are yours; "live-service" is not in your sentence. |

Coverage: JD requirements map to the questions as follows. Live calendar, two titles: A3, F1. Content calendar: A3. Coordination: A4, C2. Post-event review and KPIs: D1. Release checklist with QA: B1, B3. Retention metrics: C3. Live-service 3+ years: D2. Clear written communication: none, and why: the careers page lists no written component for the Outage Hour.

## Reverse questions

1. "Project Larkspur is moving two titles to one shared events calendar. What does this role own in that calendar?" *Why it lands:* it shows you read the company's own news, and it asks the question the JD leaves open.
2. "What does a good first 90 days look like for the person in this role?" *Why it lands:* it turns the interview toward the job's scope and lets you test your plan against their answer.
3. "What did the last post-event review on this calendar change?" *Why it lands:* it shows you care about the review the JD names, and their answer shows you how the KPIs are used.
4. "How much of the release checklist does QA own, and how much does live ops?" *Why it lands:* it tests the handover line the JD describes, and it lets you raise your checklist work in their terms.
5. "Who would I coordinate with first on a live event, and what usually goes wrong with that handover?" *Why it lands:* it gets the hiring manager to describe the real friction, which is where your coordination answer needs to fit.

## Values / principles cheat sheet

Source: saltmarshgames.com/values (fetched).

| Value (official name) | Working meaning | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Selection scaffold (B2): no quoted story carries it. If none comes to mind, say so plainly. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F5, B1: "Wrote the release checklist our QA team still uses." Scope: the checklist, not an outcome. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F5, B3: the same checklist sentence, at its own scope. |

## Sources

- Provided by you: the JD text, your background, the interviewer's name and title.
- saltmarshgames.com/values, fetched. Values and their definitions.
- saltmarshgames.com/careers/interviewing, fetched. The loop: a recruiter call, then the 60-minute Outage Hour with the hiring manager (live-incident tabletop, then a values conversation), no take-home.
- Search: "Saltmarsh Games values" (1 result, the values page).
- Search: "Saltmarsh Games interview process live operations producer" (1 result, the interviewing page).
- Search: "Saltmarsh Games mobile studio news strategy" (1 result, saltmarshgames.com/news/project-larkspur, from the snippet, not fetched). Used in F8 and reverse question 1 only.
- Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" (1 result, a GDC 2026 talk listing on talks.gdconf.example, not fetched and not used; the domain is not the event's own).

**Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 10; B1 to B3 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The Outage Hour format, round structure, the values conversation; persona weights, A1 |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur (September 2026) moved F8 and reverse question 1; not fetched, used from snippet |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Result was a talk listing on a non-official domain: not established, not used. The interviewer read is name and title only |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Tobias's role in the round, confirmed (hiring manager or other) → persona weights recomputed and reverse questions re-tuned.
- Your prep days before Friday → a prep triage in priority order.
- One sentence on any cross-team update you led or coordinated (F6, A4, C2) → those rows upgrade from answer slots to grounded stories.
- One sentence on a post-event review or KPI set you ran (F7, D1) → those rows upgrade from slots to grounded stories.
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for the Larkspur change and the interviewer's public talks, which would move the CO bank.
