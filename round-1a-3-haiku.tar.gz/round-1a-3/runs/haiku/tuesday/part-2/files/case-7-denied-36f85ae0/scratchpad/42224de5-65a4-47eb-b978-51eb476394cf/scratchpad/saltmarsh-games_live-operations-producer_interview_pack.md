# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager (taken from the title; not confirmed by you).
**Round:** 60 minutes, Friday. Format not stated.

## How to use + type key

Personas are how a question gets asked. Types are what it scores.

- **CASE**: a live problem from the role, solved out loud.
- **EXP**: your own past work, probed for what was actually yours.
- **JD**: a requirement from the job description.
- **CO**: company strategy. Not included, because company research did not run (see Sources).

Guidance is scaffolding, not a script. Say the parts that are true, in your own words.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. Nothing in the Evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives the years and a puzzle-game studio, not live-service titles. Words: "For four years I was an associate producer at a puzzle-game studio." Answer slot: if the content drops ran on a live schedule, describe how; if the live-service part was not yours to run, say so. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already says what the JD asks. Expect a probe on how the calendar worked day to day, so lead with it in those words. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title, not two. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for a second title, say which; if not, say so and say how you would take on the second. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the review or the KPI set. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or ran a post-event review, say which; if you did not, say so plainly. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I presented the monthly retention numbers to the studio head." Expect a defend-the-number probe (C1, C2). |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote shows you wrote it and that QA uses it. Words: "I wrote the release checklist our QA team still uses." Do not turn "wrote" into "managed"; if you ran sign-off with QA, say what that involved. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these four teams. Answer slot: if you coordinated any of them on a drop, say which and what part was yours; if you did not, say so plainly and say how you would start. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote shows written work used by another team. Words: "I wrote the release checklist our QA team still uses." No writing test has been announced, so none is rehearsed. |
| F9 | "own the post-event review" (JD), as a separate step | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran or fed one, say what it measured; if you did not, say so and say how you would tie a KPI move to an event. |

**Not in the JD, but likely to come up:** you have never led a team, and you have never worked on a game with in-app purchases. The JD names neither. Both are yours to state plainly (see the prohibited list and the banks), and neither is a fit row.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title for the last two years." Analysis: your material says one main title. |
| Owned the post-event review and its KPIs | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." |
| Owns the release checklist | Inflated form of F6 | "I wrote the release checklist our QA team still uses." |
| Led or managed design, art, engineering or community teams | Inflated form of F7 | Answer slot only. Analysis: no quote shows this. |
| Led a team | Negative you stated | "I haven't led a team." Plain acknowledgment, no slot. |
| Worked on a game with in-app purchases | Negative you stated | "I haven't worked on a game with in-app purchases." Plain acknowledgment, no slot. |

## Persona weights

Hiring manager is the relationship prior. Personas.md weights Case/Strategist and Skeptic highest. No interviewer profile was available, and no loop source was read, so there are no interviewer-signal adjustments. The loop is unknown, so the fallback is flat weights.

| Persona | How it shows up here | Likelihood | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | A live calendar or update problem from the JD | High | Top weight: the hiring-manager prior, and the JD's "plan and run" and "coordinate" lines. | Clarify the goal first, then the metrics, then the risks. Think aloud. |
| Skeptic | Probes on the team-coordination gap and the two negatives | High | Top weight: F3, F7 and the two stated negatives are the material most likely to be pressed. | Hold what the quotes carry. Concede the gap in words the quote allows. |
| Data-Driven Prober | Defend-the-number questions on retention | Medium | Mid weight (depth 4): retention is a headline requirement (F5) and the JD's KPI line. | Say how the figure was counted, if you know. Say plainly when you do not. |
| Pressure / Stress | Time-boxed "why you" or "how much was you" challenges | Low to medium | Low weight (depth 2): the JD does not signal a stress round. | Hold through two follow-ups, then concede the specific uncertainty. |
| Conversational / Rapport | An opener about your journey | Medium | Low weight (depth 2): casual questions are still scored. | Keep the 90-second arc to what the quotes say. |

## Question banks

**Highest-ROI prep: B1.** The Skeptic will press the coordination gap (F7) and the leadership negative together. That is the objection this role makes most likely, and it is where your material is thinnest.

### Case/Strategist (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A content update for one of the titles is three days from release, and retention is down on last month's. Walk me through what you would do." | CASE | [generic] | Clarify what the update was for and what retention is being measured against. Name the first metric you would check and why. Name the risk to the release date. Speakable in 90 seconds. | A live problem from the JD's "plan and run" line. It asks about no past, so it makes no claim about you. |
| A2 | "How would you plan a live-events calendar for two titles you have not played before?" | CASE | [generic] | Clarify each title's goals and player base first. Set a cadence before naming events. Say how you would balance four teams' lead times. | A live problem from the JD's "two of our mobile titles" line. No claim about your past. |
| A3 | "Walk me through coordinating one update from brief to live across design, art, engineering and community." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Walk the stages in the order you would run them, and name what you would need from each team. Answer slot: if you coordinated any of these teams on a drop, say which and what part was yours; if you did not, say so plainly and say how you would start. | F7 has no evidence. The answer slot's second branch lets the practice be absent. |
| A4 | "What goes on a release checklist for a live update, and who signs it off?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what the checklist covers, in your own words. Answer slot: if QA signed off in a way you ran, say how; if sign-off was not yours, say so. The quote says you wrote it and QA uses it; it does not say who signs off. | F6. Stays inside the quote's scope. |
| A5 | "Would you run one big event or two smaller ones in the same slot? Why?" | CASE | [generic] | Name what each option costs the calendar and the team. Name the metric that would decide it. Say what would change your mind. | A trade-off on the calendar. No claim about your past. |

### Skeptic (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates four teams without managing them. Where have you done that?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold on the true part: "I haven't led a team." Then the closest thing your material carries: the content-drop calendar and the checklist QA uses. Answer slot: if you coordinated any of the four teams, say which and what part was yours; if you did not, say so plainly. Hold through two follow-ups by returning to the calendar and the checklist. Concede specifically: "coordinating four teams is what I would need to learn fastest." | The highest-ROI rehearsal. F7 has no evidence and the leadership negative sits on top of it. |
| B2 | "Your background is a puzzle game. What changes for a live-service title with in-app purchases?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, as a plan: what you would want to learn about how monetisation shapes the calendar. Do not claim you know its effects. | The JD names no monetisation, so this is a risk you name yourself. Your negative is the source. |
| B3 | "What in your background says you can run a live-service calendar and not only a puzzle game's?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Lead with the calendar in those words: weekly, for one main title, for two years. Do not call puzzle-game drops live-service. Answer slot: if any live-service mechanics were yours to run, say which; if not, say so. | F1 and F2. The calendar is the nearest live-service-shaped work you have. |
| B4 | "The role owns the post-event review and the KPIs it reports. What is your part in that today?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or ran a post-event review, say which; if you did not, say so plainly. | F4. Presenting is not owning, and the answer must stay at that scope. |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Choose the coordination line and say it straight: that is where you would learn most, and you have not led a team. Then say what you would do in the first 30 days, as a plan. | A persona stem applied to the JD's own line. Concession in words the quotes allow. |

### Data-Driven Prober (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you know about the count. Answer slot: if you built the count yourself, say how; if it came from elsewhere, say so. Say plainly if you do not know the method. | F5. A figure you did not give would be invented, so none is named. |
| C2 | "Which retention figure from your presentations would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption you know of, before they do. If you cannot recall a figure, say which source you would pull it from. Do not produce a figure. | The weakest-assumption move. No figure was given, so there is nothing to defend. |
| C3 | "What does a post-event review measure, and how do you know a KPI moved because of the event?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you ran or fed a post-event review, say what it measured; if you did not, say so and say how you would separate an event's effect from the rest. | F9 and F4. The second branch allows the practice to be absent. |
| C4 | "For a weekly content drop, what did success look like in numbers?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer slot: say what, if anything, you tracked per drop. If nothing was tracked per drop, say so plainly. | F2, with the count pressed. Stays inside the calendar. |

### Pressure / Stress (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team for a role that coordinates four?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Hold: "I haven't led a team." Hold through two follow-ups by returning to the calendar and the checklist as work you did. Concede the specific gap: the coordination across four teams is what you would learn fastest. Do not argue the team count. | Hold-then-concede. The position held is the one the quotes carry. |
| D2 | "That release checklist QA uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what you wrote and what changed with QA. Answer slot: if QA changed it, say so; the quote says QA uses it, not who maintains it. Hold through two follow-ups. | Tests attribution, not the quote's scope. |

### Conversational / Rapport (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc: four years at a puzzle-game studio, the weekly calendar, the checklist, the retention presentation. Say nothing the quotes do not carry. | Casual openers are still scored. |
| E2 | "What live games are you playing right now?" | JD | [generic] | Name a live title you actually play. If you do not play live games, say so and say what you want to learn about how they run. | A casual question on the JD's live-service requirement. No claim about your past. |

## Coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B3 |
| Coordinate design, art, engineering and community teams | A3, B1, B5, D1 |
| Own the post-event review and the KPIs it reports | B4, C3, C4 |
| Manage the release checklist with QA | A4, D2 |
| 3+ years producing live-service games or apps | B2, B3, E1 |
| Experience running a content calendar | B3, C4 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | none, and why: no written exercise was announced. D2 and A4 touch the checklist's authorship. |

## Reverse questions

Each has a "why it lands". None ties to the interviewer's own path, since no public profile was read.

1. "How are the two titles' calendars set each quarter, and who has the final say?" Why it lands: it shows you think about who decides, before you are asked to.
2. "What does a post-event review look like here, and who reads it?" Why it lands: it asks about the KPI ownership the JD names, without claiming any.
3. "Where does monetisation sit in the event calendar, and how does it change what gets scheduled?" Why it lands: it asks about in-app purchases honestly, without claiming experience.
4. "How do the four teams' lead times line up against the release checklist?" Why it lands: it shows you know the coordination is the hard part.
5. "What would success look like at the end of the first 90 days?" Why it lands: it sets the bar and gives you the metric to report against.

## Sources

Provided documents: your message (the background and the JD, pasted). No other documents.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every search was refused. Would have checked for a values-style round. No values section is in the pack. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every search was refused. Would have named the loop. Persona weights therefore follow the hiring-manager prior, flat within it. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Every search was refused. Would have moved the CO questions and the grounding brief. Neither is in the pack. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every search was refused. Would have built the interviewer read and a reverse question tied to his path. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Search calls sent: 4, all refused: "Saltmarsh Games values", "Saltmarsh Games interview process live operations producer", "Saltmarsh Games mobile studio strategy news", "Tobias Wrenfield Saltmarsh Games Head of Live Operations". No fetches were sent.

Loop: no loop source was read, so the loop is not established. The fallback is the generic archetype: screen, hiring manager, panel, flat weights. No values-style round is assumed.

Sections dropped, by their conditions: prep triage (no prep time given), grounding brief (no L2 research), reading the interviewer (no public profile read), values cheat sheet (no values-style round detected), graded deliverables (none declared), delivery coaching (no assessment provided).

## Upgrade menu

- Search permission for this session → allows the L1 research to run. It would add the Saltmarsh values page (a values section, if a values round is named), the recent strategy (current-strategy CO questions), and the interview format.
- Saltmarsh's values page, pasted → a values cheat sheet, if the round is values-style.
- The recruiter's note on the round format (how many sessions, any panel, any written task) → confirms the loop, and adds a build section if a written task is set.
- Tobias Wrenfield's public bio or talks, pasted → an interviewer read, persona weights tuned to him, and a reverse question tied to his path.
- A redacted content calendar or the release checklist → F2 and F6 move to high confidence, since an inspectable artifact would back the claim.
- Any cross-team coordination on a content drop, in your own words → F7 quoted and graded, and A3 and B1 upgraded from answer slots.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → only if search is permitted. Ask again to run it.
