# Ashgrove Credit Union: Member Experience Lead, interview pack for Dara

Loop mode: three scheduled rounds on 29 November 2026 (recruiter screen, Head of Member Services, branch-manager panel). Built 20 November 2026. One shared fit snapshot, then a mini-pack per round.

## How to use this pack

- **Personas** describe how each question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values; **EXP** your own past work, checked closely; **JD** the posting's own requirements; **CO** company and strategy; **CASE** a live problem from the role.
- Question IDs: **A** = recruiter screen, **B** = Head of Member Services, **C** = panel.
- **Answer slot**: an instruction for the interview, not a question to me. It tells you what to say when the material does not show something: a real answer if you have one, or a plain "no, and here is what I would do" if you do not. Never invent the missing piece.
- The guidance is scaffolding, not a script. Speak it in your own words.

## Fit snapshot (shared across all three rounds)

The posting names no licence, credential, location, pay or schedule term, so no row is a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your message gives the years and the role in these words; use these words. "Customer operations" is the posting's phrase, not yours, so do not adopt it. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows a formal complaints log at one branch. It does not say the log was regulated or ran to time limits, so the words stop at the log. Answer slot: if it ran to a rule or deadline set from outside the branch, say which and how you worked to it; if none applied, say what the formal process was. |
| F3 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The scope is one branch's log. Say it at that scope, never "across branches". Answer slot: which steps of a complaint were yours, from logging to outcome, and which were someone else's. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The spreadsheet is monthly complaints reporting in your words. Resolution times are not in them. Say it as you built it. Answer slot: if it tracked how long complaints took to resolve, say how that was counted; if it did not, say so. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The material does not name the tool. Derivation: the spreadsheet line is the only reporting evidence, and Excel is an inference from it. Answer slot: name the tool you built it in and what it did; if it was not Excel, say so. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | You trained tellers and supervised for three years. Neither is coaching supervisors, so say each at its own scope. Answer slot: if you have coached another supervisor through an escalation, say what you did; if not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital or self-service work, so the pack claims none. Answer slot: if you have worked with any digital or self-service change, name it and your part in it; if not, say so and say how you would start. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | The stated absence. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | The stated absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan, never as a past. |

## Prohibited claims (not to be coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches and the contact centre | Inflated form of F3 and F8 | "I handled the branch's formal complaints log," at one branch's scope. The contact centre is the stated absence in F8. |
| Has presented to senior leaders | Negative you stated (F9) | "I haven't presented to anyone above regional level." No answer slot. |
| Has worked in a contact centre | Negative you stated (F8) | "I've never worked in a contact centre." No answer slot. |
| Regulated complaints | Inflated form of F2 | "Formal complaints log." Whether it was regulated is the F2 slot. |
| Tracked resolution times | Inflated form of F4 | "The monthly complaints spreadsheet our regional manager uses." Whether it tracked times is the F4 slot. |
| Designed or wrote the escalation script | Inflated form of "trained new tellers on our escalation script" | "Trained new tellers on our escalation script." The script is "our", not yours. |
| Coached branch supervisors | Inflated form of F6 | "Trained new tellers," and "the last 3 as a branch supervisor," each at its own scope. |
| Excel reporting | Tool not named in your material | Only the F5 slot. |

## Grounding brief: the strategy, in the words to use

Sourced from your summary of Ashgrove's July 2026 strategy brief. The brief itself is not in this session, so check these figures against the document before you quote them.

| Item | Source | Use in answers |
|---|---|---|
| 40% of member service moved to digital channels by 2028 | your summary of the brief | Use "digital channels" and "member service", as the brief does. |
| Eight branches consolidated into five hubs over 2027 | your summary of the brief | Use "hubs". Do not describe any branch's future. |
| Small-business lending product launched Q1 2027 | your summary of the brief | Use only if the question touches growth. |
| App-only banks as the main competitive pressure | your summary of the brief | Use it when you talk about member expectations. |

---

## Round A: recruiter screen (30 minutes)

**Weights.** Conversational/rapport is the top persona, with light Skeptic and the logistics knockouts. The relationship prior for a recruiter screen gives exactly this. The risk is treating this round as unscored: the logistics answers and the motivation answer are the first scores.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, then the arc question and a casual digital question | High: a recruiter screen opens this way, and A8 is a JD topic asked casually | Pre-scripted 90-second arc (A1); treat the casual question as scored (A8) |
| Skeptic (light) | "Tell me about the spreadsheet" and the logistics checks | Medium: the screen tests whether the CV line holds | Quote the line, name what it does not show, do not stretch it (A7) |
| Logistics knockouts | Notice, pay, location, reason for leaving | High: recruiters check these in every screen | Give your own answers in your own words (A3 to A6) |

**Questions**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message) | Ninety-second arc in that order: the years in retail banking, the last three as a branch supervisor, then the formal complaints log at your branch. Stop there. Add no scope the quotes do not carry. | F1 and F2 are the opening evidence. The recruiter's first check is whether the years match the posting. |
| A2 | "Why this role, and why Ashgrove?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (values page, as pasted) | Open prompt. Name one of the four published values that you can point to in your own work, and say what you did in your words. If none comes to mind, say so, then say what drew you to a member-owned credit union, in your words. | The first place your fit is read. The guidance claims nothing about a past you have not stated. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Logistics knockout. The pack supplies no figure. |
| A4 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role carries before you name one. | The posting states no pay range, so your own answer is the only safe one. |
| A5 | "Where would you be based, and what travel can you do?" | JD | [generic] | Logistics slot: name the place you can work and the travel you can manage, in your own words. | Location is a logistics term. The hub plan in the grounding brief makes travel a likely follow-up. |
| A6 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your own reason, in your own words. The material contains none, so the pack supplies none. | Required logistics slot. The reason is yours alone. |
| A7 | "Tell me about the monthly complaints spreadsheet you built. What does your regional manager use it for?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it is and what the manager does with it, in those words. Name the tool only if you built it in one, and say what it did. Answer slot: the posting asks about resolution times. If the spreadsheet tracked how long complaints took, say how it was counted; if not, say so. | F4 and F5 in one question. The recruiter will test the tool name, and nothing in the material supplies one. |
| A8 | "What are you actually playing with in digital self-service these days?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Casual, and scored. Answer slot: if you have worked with any digital or self-service change, name it and your part in it; if not, say so and say how you would start learning. | F7 is silent in the material, so this is the question most likely to expose it. |

**Reverse questions for round A**

- "What does the monthly complaints report look like today, and who reads it?" Why it lands: it shows you are interested in the reporting line this job owns.
- "What would make the first three months a success for you?" Why it lands: it gets the manager's bar before the second round, so you can answer to it.

**Round A requirement coverage:** A1 (4+ years), A7 (monthly reporting, Excel), A8 (digital self-service). "Regulated complaints," "senior leaders" and "contact centre" are covered in round B, which is where they are scored.

---

## Round B: Head of Member Services (45 minutes, your future manager, mostly behavioural)

**Weights.** The recruiter says this round is mostly behavioural, which moves Values/Behavioural to the top, ahead of the Skeptic prior a hiring manager usually carries. The Skeptic still owns the highest-ROI rehearsal, B1, because this manager is the one buying the gap risk.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | STAR-shaped prompts about complaints you have handled | High: the recruiter said so; four questions (B2 to B5) | "We" for context, "I" for contribution; say where the hard truth did or did not land |
| Skeptic | The two stated absences put to you directly | High for B1: the posting asks for both, and you have stated you lack both | Hold, then concede specifically (B1) |
| Case / Strategist | Live problems from the role | Medium: a manager is judging how you would run it | Clarify first, then structure (B7, B8) |
| CO | Strategy from the brief | Medium: a manager will expect you to know the 2027 plan | Use the grounding brief's words (B9, B10) |

**Questions**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and you haven't presented above regional level. This job needs both. Why should we take that risk?" | JD | [grounded] "Never worked in a contact centre" (your message); "I've never presented to anyone above regional level" (your message) | Highest-ROI prep in this pack. Hold: open with what your six years cover. Use your own quote: "I handled the branch's formal complaints log." Concede specifically: "I've never worked in a contact centre, and I haven't presented above regional level." Then, as a plan, how you would close each in the first 90 days. Hold through two follow-ups by returning to the log. Never add a contact-centre or presenting experience you do not have. | F8 and F9 are stated absences, so the concession is yours to make. The hold is the log, the one thing you can stand behind. |
| B2 | "Walk me through how a formal complaint moved through your branch's log, from logging to outcome." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Name each step you took, in order. Answer slot: where a step was set by a rule, or by someone else, say so. If you set none of the steps, say that plainly. | F2 and F3. Tests what was actually yours. |
| B3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (values page, as pasted); "I handled the branch's formal complaints log" (your message) | Selection scaffold. Pick a complaint where you found the problem and stayed with it to the outcome. If none comes to mind, say so, then give the nearest thing your log carries: the log you kept, and what you did with an open case in it. | Own the Fix is scored here. No quoted sentence carries a finished story, so the honest branch is written in. |
| B4 | "Tell me about a time the branch's process said one thing and the member's situation needed another." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (values page, as pasted); "trained new tellers on our escalation script" (your message) | Scaffold. If you did this, say what the process said, what the member needed, and what you did, in your words. If not, say so and give the nearest case where the script and a member came apart. | Members First is scored. Keep the process and the member distinct in your answer. |
| B5 | "Tell me about a time you had to explain a decision to a member who did not accept it." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page, as pasted); "I handled the branch's formal complaints log" (your message) | Scaffold. Say what the decision was, how you explained it the first time, and what changed when the member did not accept it. If you have no such case, say so, then say how you would explain a decision in plain words. | Plain Words is scored. Keep the explanation in the words the member would use. |
| B6 | "Ashgrove wants fewer, larger hubs. I'm putting you in front of the senior team on complaint volumes next quarter. Talk me through your preparation." | JD | [grounded] "confident presenting to senior leaders" (JD); "I've never presented to anyone above regional level" (your message) | Open with the stated absence: "I haven't presented to anyone above regional level." Then your preparation, as a plan: what you would put in front of them, what you would check first, and whom you would rehearse with. | F9. The acknowledgment is yours to give, and the preparation is a plan, not a past. |
| B7 | "A branch manager tells you the monthly complaint figures you sent are wrong. What do you do?" | CASE | [generic] | Clarify first: which figure, which period, what they counted. Check the source log. Separate a definition difference from an error. Correct in writing, with the reason. Agree how the figure will be counted from now on. | A live problem from the reporting requirement. Makes no claim about any spreadsheet history. |
| B8 | "A supervisor you coach is defensive about an escalation they mishandled. What do you say?" | CASE | [generic]; "trained new tellers on our escalation script" (your message) | Structure: what the member got, then the supervisor's view, then the one thing to change. Keep the coaching at the scope of your record. Answer slot: if you have coached another supervisor through an escalation, say what you did; if not, say so, then how you would start. | F6. The problem is generic. The only past claim is the training line, kept at its own scope. |
| B9 | "Ashgrove plans to move 40% of member service to digital by 2028. What does that change for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the strategy brief) | No past claim. Say where complaints come from after a shift to digital, such as app failures and unanswered messages. Say what gets lost, such as members who need a person. Say how you would measure both. | Coverage rule: at least one strategy question. The brief's wording is the vocabulary. |
| B10 | "Eight branches are consolidating into five hubs during 2027. What happens to complaints that are open on the day a branch moves?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the strategy brief) | No past claim. Say what a member should still get when their branch becomes a hub, and what happens to open complaints on the day of the move. | Neighbours, Not Numbers is tested here. Keep the answer about members, not the branches' numbers. |

**Reverse questions for round B**

- "Where does this role sit in the hub plan, and what gets decided before the hubs open?" Why it lands: the 2027 timeline makes this the decision point, and a manager answers how much is already fixed.
- "What does a complaint handled well look like to you, in a member's words?" Why it lands: it asks for the member-side standard the values page sets, and your answer can then use it.

**Round B requirement coverage:** "Own the member complaints process end to end across branches" (B2, B3); "experience handling regulated complaints" (B2, plus the F2 slot); "confident presenting to senior leaders" (B6); "coach branch supervisors on escalations" (B8); "report monthly on complaint volumes and resolution times" (B7).

---

## Round C: branch-manager panel (60 minutes, two branch managers, values scored, a 20-minute complaint-escalation case)

**Weights.** The panel scores against the four values, so Values/Behavioural is the top persona. The case is the second. Peer Evaluator comes in because the members of the panel are branch managers who would work beside this role, and Pressure is held in reserve for C8.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Each member scores one or more values | High: the recruiter said the panel is the values round (C1 to C4) | Map each value to a story only where your material carries one. Otherwise say so and give the honest branch |
| Case / Strategist | The 20-minute escalation case (C5), then a seam question (C6) | High: the case is named in the recruiter's email | Clarify, then structure, then the member first. Say the decision you would escalate |
| Peer Evaluator | The seam between branches and digital, and disagreement | Medium: branch managers test whether you would add to their load | Propose principles, not a seam you have not seen (C6, C7) |
| Pressure | Your supervisor years used against you | Medium: the panel may test whether the record is yours | Hold the log, then concede the stated absences (C8) |

**Values cheat sheet.** The values are the company's, as you pasted them on 20 November 2026. No quoted sentence of yours carries a finished story for any of the four, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (C1): if you have a case where you put a member first, say the target or process, the member's side, and what you chose. If not, say so, then say how you would decide. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Scaffold (C2): say a case where a member needed it explained twice and what changed. If none, say so, then how you would check a letter had been understood. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold (C3): a view, not a story. What a town should still be able to do when its branch becomes a hub. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold (C4): a complaint you could not solve, what you held onto, and where it ended. If none, say so, and describe the nearest one you held and what it left open. |

**Questions**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a branch target or process." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (values page, as pasted) | Open prompt. If you did this, name the target or process, the member's side, and what you chose. If none comes to mind, say so, then say how you would decide. | Members First is scored. No quoted sentence of yours carries the story, so the honest branch is written in. |
| C2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page, as pasted); "trained new tellers on our escalation script" (your message) | Scaffold. Say what you said the first time and what changed the second time, in plain words. If you have no case, say so, then how you would check whether a letter was understood. | Plain Words is scored. The training line is about teaching a script, not about plain words, so it is not offered as the story. |
| C3 | "When a branch in a town becomes a hub, what should the people in that town still be able to do?" | VAL | [grounded] "every branch is part of its town" (values page, as pasted); "consolidate eight branches into five hubs over 2027" (your summary of the strategy brief) | No past claim. Name what should stay local, such as the complaint route, a person to call, or a visit. Say what you would test with the town first. | Neighbours, Not Numbers and the strategy in one question. Answer as your view. |
| C4 | "Tell me about a complaint you couldn't solve, and what you did with it." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" (values page, as pasted) | Scaffold. If one comes to mind, say the problem, what you held onto, and where it ended. If none, say so, then describe the nearest one you held and what it left open. Do not give it a neat ending. | Own the Fix is scored. Honest answers about unsolved cases score better here than tidy ones. |
| C5 | The escalation case (20 minutes, below) | CASE | [generic]; JD: "coach branch supervisors on escalations" (JD) | Structure in this order: (1) the member first: what they need today; (2) one owner and a date; (3) the fee: who can refund it, on what authority, and what you would escalate; (4) one answer to the member, the same from every channel, in plain words; (5) the logging fault: fix the log, not only this case; (6) the branch: coach the supervisor, and check whether the same fault hit other members; (7) what you report monthly. | A live problem from the posting. It asks about no past of yours. |
| C6 | "Your branches send you complaints about a self-service app change the digital team made last month. How do you get it fixed?" | CASE | [grounded] "work with digital teams on self-service journeys" (JD) | Principle over story. Say what you would send the digital team: the member's words, the count, and the failed step. Say who decides and how you would know it worked. Do not name a digital team you have worked with. | F7's silence makes this the seam question. A principle is a plan, not a claim. |
| C7 | "Tell me about a time another manager disagreed with how a complaint was handled." | CASE | [generic]; JD: "coach branch supervisors on escalations" (JD) | Scaffold. If you have a case, say what the disagreement was, what you held, and what you conceded. If none, say so, then the nearest: the escalation script you trained tellers on, and how you would settle a disagreement over it. | Peer Evaluator. Disagreement with equals, without claiming any past you have not stated. |
| C8 | "You've supervised for three years. Why should a branch manager take a complaints lead from you?" | JD | [grounded] "the last 3 as a branch supervisor" (your message); "6 years in retail banking" (your message) | Hold: your six years, and the log you kept. Hold through two follow-ups. Concede specifically: "I haven't led across branches or a contact centre. Here is how I would earn that in the first 90 days." Never fold on the log. | Pressure. The hold is the quoted record; the concession is the stated absence. |

**The escalation case (C5), as the panel would give it**

> A member has complained three times in five weeks. In March their standing order to a care provider failed, and we charged a £30 returned-payment fee. The app helpline told them the fee was correct and the failure was "a customer setting issue." Their first complaint went to the branch and got a standard letter after eleven days. Their second, by phone, was logged as a general enquiry and never reached the complaints log. This third one came in at your branch this morning: "I've been told three different things by three different people, and nobody will tell me who's fixing it." They have also asked whether the branch is closing. The fee has not been refunded, and the care provider has sent a late-payment notice. Your branch supervisor has the file and has asked you to take it. You have twenty minutes. Walk us through what you do, and what the member hears from you.

*Setter's note: the amount and currency are assumed; change them if the case is set somewhere else. The follow-ups are the panel's and will come from what you say.*

**Reverse questions for round C**

- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: the panel are peers to this role, so the question turns a scoring round into a working conversation.
- "What would make you say this role was working after a year?" Why it lands: it gets the panel's own bar, which you can then answer to.

**Round C requirement coverage:** "Own the member complaints process end to end" (C4, C5); "report monthly on complaint volumes and resolution times" (C5, step 7); "coach branch supervisors on escalations" (C5, C7); "work with digital teams on self-service journeys" (C6); "experience handling regulated complaints" (C5 with the F2 slot).

---

## Requirement coverage (all rounds)

| Requirement (JD) | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1, B1 |
| experience handling regulated complaints | B2, C5; slot in F2 |
| Own the member complaints process end to end across branches and the contact centre | B1, B2, B3, C4, C5; F3 and F8 |
| report monthly on complaint volumes and resolution times | A7, B7, C5 (step 7); slot in F4 |
| coach branch supervisors on escalations | B8, C5, C7; F6 |
| work with digital teams on self-service journeys | A8, C6; F7 |
| confident presenting to senior leaders | B1, B6, C8; F9 |
| comfortable with Excel reporting | A7, B7; slot in F5 |

Every JD requirement has at least one question. Nothing is uncovered.

## Sources and research accounting

Provided documents: your message, which contains the job description text as quoted here, your background, the recruiter's round plan, the values as you pasted them on 20 November 2026, and your summary of the July 2026 strategy brief. The brief itself was not provided.

Research tier: L1 — searches 0 of 6, fetches 0 of 2. No calls were sent, and each declared target is accounted for below. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values as you pasted them fix the values content in round C and the cheat sheet. |
| 2. Ashgrove interview process, customer operations | skipped | The recruiter's round plan fixes the loop structure and the round weights. |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief fixes the current priorities used in B9, B10 and C3. Anything newer than July 2026 was not searched. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so there was no query to form. The interviewer read is absent, and the upgrade menu says what names would unlock. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Names for the Head of Member Services and the two panel members → a persona weight for each interviewer, and a reverse question tied to their own path.
- The complaint rules you worked under (the regulator, response deadlines, and the referral route, if any) → B1, B2 and C5 can name your real regime instead of the answer slot.
- The tool you built the monthly spreadsheet in, and whether it ever carried resolution times → turns F5 and the F4 slot from inference or silence into your stated fact.
- Any digital or self-service work, even a small piece → fills the F7 slot and A8.
- The strategy brief itself, pasted → B9, B10 and C3 quote the document rather than your summary.
- The recruiter's note on the panel case format (one case, or a set of questions) → sharpens C5.
- Deep research (L2), offered once: up to 6 further searches and 2 further fetches on the interviewers' public talks, role-family loop reports, and recent Ashgrove news. It runs only on your yes.
