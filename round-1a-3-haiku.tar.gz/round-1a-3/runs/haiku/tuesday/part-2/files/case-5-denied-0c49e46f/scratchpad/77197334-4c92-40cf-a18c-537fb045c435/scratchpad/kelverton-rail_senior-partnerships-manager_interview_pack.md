# Interview prep pack: Senior Partnerships Manager, Kelverton Rail, second-round panel

Panel on Tuesday: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes. First 15 minutes: a spoken point of view on operator partnerships over the next 18 months, no slides. The rest is Q&A, and Ross will push on commercials.

## How to use this pack

- Personas are how a question arrives. Types are what is being scored.
- Type key: **CASE** a live problem set in the role. **EXP** a question about your past work. **JD** a question about the role's stated requirements. **CO** commercial and company thinking. **VAL** values (none in hand, so none used here).
- Guidance is scaffolding, not a script. Rehearse your own words.
- Provenance: [grounded] traces to your own sentences or the recruiter's; [inferred] is a derivation from them; [generic] is a role-family pattern with no claim about you or Kelverton.

## Prep triage (about four hours)

1. About 60 minutes: write the 15-minute POV as three spoken beats (section 5). Talk it through aloud twice with a timer set to 12 minutes.
2. About 45 minutes: rehearse B1 and B2 with someone reading Ross's lines. Commercials is where this panel will press.
3. About 45 minutes: rehearse A1, A5 and A6 for Deepa's case and the rail gap.
4. About 30 minutes: pick three reverse questions from section 11 and say them aloud. Then the POV close.
5. Everything else is insurance.

## 1. Fit snapshot

Requirements come from the recruiter's email, quoted as you pasted it, and from your own description of the company. No job description is in hand, so no requirement here is [inferred]. Confidence grades your evidence. Gap type routes each row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Your material says consulting on bus and light rail network planning. It does not show operator-partnership work with a train operator. Say the consulting in its own scope. Answer slot: if any of that work involved an operator's own decisions directly, say which; if it was for another client, say so plainly and stay with the planning you did. |
| F2 | "Please land on what it means for the operators themselves." (recruiter) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Reword the quote and add nothing: "I know the operator world from the other side, and that is the lens I would bring to what it means for them." |
| F3 | "Ross will push on commercials." (recruiter) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced revenue, not revenue you sourced or closed. Keep the word "influenced" every time you say it. Answer slot: if you can say how the influenced figure was counted, say it in your own words; if the counting was not yours to set, say so. |
| F4 | carry a direct revenue target (role-family pattern, not a quoted requirement) | "never carried a direct quota, only influenced revenue" (your message) | high | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't carried a direct quota." Then how you would get to a target-carrying number, said as a plan and never as a past. |
| F5 | sell scheduling software to train operating companies (your description of the company) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | A gap you have stated. Words: "I haven't sold into rail specifically." Then how you would learn it, as a plan. |

Notes on the rows:

- F1 and F2 are the same consulting sentence used two ways. Use it once, at its own scope, and do not stretch it into operator employment.
- F3 is the most likely place for Ross to probe. The figure is the sentence's; the count behind it is not yet in the material.
- F4 and F5 are negatives you stated. You may say them plainly. Do not soften them.

## 2. Prohibited claims

Built from the fit snapshot. Every guidance cell in this pack is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail sales experience | Negative you stated, F5 | "I haven't sold into rail specifically." |
| Carried a revenue target or hit quota | Negative you stated, F4 | "I haven't carried a direct quota." |
| Generated £4M of revenue | Inflated form of F3: influenced is not generated | "roughly £4M of influenced revenue" at scope. The limit is this pack's observation: the material says influenced, not generated. |
| Worked for a train operator, or ran operator planning | Inflated form of F1: the consulting was for bus and light rail network planning | The F1 quote at its own scope. This pack's observation: the material says consulting, and light rail is not mainline rail. |
| Built the ISV channel | Inflated verb for the 6-to-40 growth in F3 | "took it from 6 partners to 40." |

## 3. Persona weights

No interviewer profiles were available, so no interviewer read is included. Weights follow the panel rule: the top two personas of each member's relationship.

| Persona | Who | Weight | Why | How it shows up |
|---|---|---|---|---|
| Case / Strategist | Deepa | 5 | Hiring manager. The POV is a live problem on the actual roadmap. | Asks you to clarify, structure and size operator partnerships in the room. |
| Skeptic | Deepa | 4 | Future manager. Will test the rail gap and the quota gap. | Quiet probes on F4, F5 and motivation. |
| Pressure / Stress | Ross | 5 | Commercial Director. Said he will push on commercials. | Time-boxed challenges to F3 and to the quota gap. |
| Data-Driven Prober | Ross | 4 | Commercial director will want the number and its assumptions. | Asks how the £4M was counted and what it is sensitive to. |
| Conversational | Both | 2 | Opening and close are often casual and still scored. | The "walk me through" opener. |

## 4. Graded deliverable: the 15-minute POV

Recruiter's requirements, quoted: "where you'd take our operator partnerships over the next 18 months" and "Please land on what it means for the operators themselves." No slides.

Shared material for every thesis: the F2 quote "so I know the operator world from the other side", and the F1 consulting quote at its own scope. Anything else in a thesis is [generic].

Thesis options. Pick two. Each needs its concession said out loud.

- **Thesis 1 (the operator's problem is the trigger). [generic]** Operators buy when a scheduling problem costs them performance or money. Partnerships should start from that problem, not from product features. Concession: I have not sold into rail, so I do not yet know which operator problems cost the most. I would test that in the first three operator conversations before committing a plan. Close: what changes for a planner's Monday morning if the partnership works.
- **Thesis 2 (fewer operators, deeper pilots). [generic]** Partner channels that scale usually depend on a small number of operators who own a pilot, not a long partner list. Anti-pick: I would say no to some operators, and name the ones I would not chase first. Concession: the 6-to-40 growth came from a payments ISV channel, and the mechanics may not transfer to rail. Close: what the operator gets from being one of the first three.
- **Thesis 3 (planning-side knowledge changes the conversation). [inferred from F2]** The planning side of the network is where operators' decisions are made. A partner who understands that can speak to what an operator needs to plan, not just to what they buy. Concession: my consulting was on planning for bus and light rail, not mainline rail, and not on procurement. Close: what the operator's planning team would ask us for first.

Differentiation against the consensus answer. Kelverton's internal market report is not in this conversation, so I cannot say what the consensus shortlist is. Once you paste its top items, bring one consensus item to show grounding, then one divergence with a reason. If the report's shortlist is the obvious answer, the POV should depart from it openly.

Mechanics. Speak for 12 minutes, leave 3 for a summary. Do not read from slides or notes. Say "I haven't" when you have not done something. The POV is judged on the operator's side, so say what changes for them.

## 5. Question banks

Each row: provenance first, then guidance, then rationale. Rationale refers to your history only by fit-snapshot row.

### Persona: Case / Strategist (Deepa), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you start with our operator partnerships, and what would you need to know first?" | CASE | [generic] | Clarify first: which operators, what the contracts look like, what the report says. Then structure: objective, segments, approach, metrics, risks. Think aloud. Name one premise you would challenge. | Deepa's live problem on the POV's own subject. No claim about your past. |
| A2 | "Which operators would you put first, and what would make you wrong about that?" | CASE | [generic] | Name the segment logic and the one piece of evidence that would change your order. Do not name operators you have no source for. | Follows the POV's Thesis 2. A segment answer needs no past claim. |
| A3 | "A large operator says the tool does more than its contract covers. What do you do?" | CASE | [generic] | Structure: what you would ask them first, what you would check internally, how you would protect the relationship, what you would record. | A live problem from the partnership role. Nothing about your past is needed. |
| A4 | "What would your first 90 days look like in this role?" | CASE | [generic] | Days 1 to 30 listen and map; days 31 to 60 pick two operators; days 61 to 90 set a measure. Say the first measure out loud. | Tests whether the POV turns into a plan. |
| A5 | "You say you know the operator world from the other side. What did that look like in your consulting work?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Story-mapped on F1: the network planning work, at its scope. Answer slot: if any of that work involved an operator's own decisions directly, say which; if it was for another client or the planning was not yours to decide, say so plainly. | F1 is the case for operator knowledge and the likeliest place for Deepa to ask what you actually did there. |
| A6 | "You haven't sold into rail. What makes you the right person to start?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I haven't sold into rail specifically." Then the transferable part, at its own scope: "took it from 6 partners to 40". Then how you would learn rail, as a plan. | F5 is a stated gap and the first thing a Skeptic will raise. The honest answer is a limit with a plan, not a bluff. |
| A7 | "Six partners to forty. What did you do to make that happen?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Story-mapped on F3: the growth from six to forty, in your own words. Answer slot: which parts were yours to set and which were not; if you did not set the approach, say so. | Growth is the headline claim, and interviewers ask for the step that was yours. |
| A8 | "Why would you leave payments for rail?" | JD | [generic] | Answer in your own words, from the operator side of your story. Do not invent a motive. Name what you want to do next. | F1 and F2 are your motivation. A motive that rests on invented facts gets tested. |
| A9 | "What is your weakest point for this role?" | JD | [generic] | Name F5 or F4 in plain words, then the plan to close it. Do not turn the weakness into a strength. | A likely Skeptic opener. The plain acknowledgment is the honest answer. |

### Persona: Pressure / Stress (Ross), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Defend-the-number: say how it was counted, the assumption you would defend least, and which part was yours. Answer slot: if you can name the counting method, say it; if you do not know how it was counted, say so plainly. | F3 is the figure Ross is most likely to press. An honest "I don't know how it was counted" is better than a guess. |
| B2 | "You have never carried a direct quota. Why should I believe you can own a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold through two follow-ups: "I haven't carried a direct quota, and the figure I have is influenced revenue." Concede specifically: "I don't yet know the mechanics of your target setup." Do not fold on the influenced figure. | F4 is a stated gap. Holding the position and conceding the specific unknown is the pressure answer. |
| B3 | "Sixty seconds: why would you be a better commercial partner than someone who has sold into rail for a decade?" | JD | [generic] | Hold your position on partner-building, concede the rail gap by name, then state the one thing you would do to close it in the first month. | A pressure stem. The concession has to be specific, not general. |
| B4 | "Year one: what partnership revenue would you put in front of me, and what would have to be true?" | CO | [generic] | Name the assumptions behind any range. Do not put a number on the table you cannot defend. Say what data you would need. | Ross tests commercial thinking, not a figure. An assumption list scores better than a made-up number. |
| B5 | "Which operators would you walk away from, and what does that cost us?" | CO | [generic] | Anti-pick: name the kind of operator you would not chase, and the cost you would accept. | Tests whether you can say no commercially. Ross will want the trade-off stated. |

### Persona: Data-Driven Prober (Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "How would you price an operator partnership when the operator's own budget is set by someone else?" | CO | [generic] | Name the questions you would need answered before pricing: who sets the budget, on what terms, and over what period. Do not state a pricing model as fact. | Ross is a commercial director. The answer shows how you think about the buyer. |

### Persona: Conversational (both), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | JD | [grounded] "9 years in partnerships", "Last 4 at a payments company running the ISV channel", "5 years in transport consulting" | A 90-second arc using those three sentences in your own words, in that order, ending on why operator partnerships now. | Casual openers are scored. Have the arc ready, not improvised. |

### Requirement coverage

| Stated requirement | Source | Question IDs |
|---|---|---|
| Operator partnerships over the next 18 months | recruiter | A1, A2, A3, A4, C1 |
| What it means for the operators | recruiter | A2, A5, POV Thesis 3 |
| Commercials | recruiter | B1, B2, B3, B4, B5, B6 |
| Selling into rail (company description) | your message | A6, B3 |
| Direct revenue target (role-family) | [generic] | B2, B4, upgrade menu |
| Gates such as location or office days | none supplied | none, and why: no source in hand. See upgrade menu. |

## 6. Reverse questions

Each one tells the panel you thought about the role, not only about yourself.

1. To Deepa: "What would the operators say about this role at month six, if it were working?" Why it lands: it tests the POV against an outcome and gets you the success measure.
2. To Deepa: "Which operator relationships are most at risk right now, and which matter most?" Why it lands: it shows you are thinking about the existing book, not only new logos.
3. To Deepa: "Is the commercial target for this role a direct quota, influenced revenue, or a mix?" Why it lands: it resolves F4 directly and shows you know the question matters.
4. To Ross: "Where has the commercial model been hardest to explain to an operator?" Why it lands: it shows you are already thinking about the buyer's objection, which Ross will weigh.
5. To Deepa: "What did you change about how you pick operator partners after your first year in this job?" Why it lands: it asks for her judgment, which is a peer-level question, and shows you respect how she has run the work.

## 7. Sources

Provided documents:

- The recruiter's email, as quoted in your message: the panel names, the 60 minutes, the POV brief, "Ross will push on commercials."
- Your background message: nine years in partnerships, the ISV channel, the transport consulting, and "Never sold into rail specifically and never carried a direct quota."
- Kelverton's internal market report: circulated by their strategy team and read by you. Its content is not in this conversation, and this pack has not used it.

Searches and fetches sent:

| Query | Outcome |
|---|---|
| Kelverton Rail scheduling software train operating companies | refused |
| Kelverton Rail company values | refused |
| Great British Railways train operators transition 2026 contracts | refused |

Research tier: L1 requested, 0 of 6 searches and 0 of 2 fetches completed. Search permission was refused for this session, so no public research ran.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Would have produced a values cheat sheet. Omitted. Calls refused. |
| 2. Kelverton interview process, role family | unavailable | Would have set loop structure and persona weights. Persona weights here are from the panel rule and your message only. |
| 3. Kelverton strategy and recent news | unavailable | Would have informed the POV's concession and differentiation. Thesis 1 and 2 are [generic] for this reason. |
| 4. Deepa and Ross public footprint | unavailable | Would have produced an interviewer read and tied reverse questions to their paths. Omitted. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have produced [inferred] requirement rows. Omitted. |

Rail-sector context in this pack (the operator side, the transition to Great British Railways) is not researched. Where a thesis needs it, the thesis is [generic] and says so.

## 8. Upgrade menu

- The internal market report's top items, or its operator shortlist, pasted into the conversation → lets Thesis 1 to 3 diverge from the consensus answer, and sharpens A1 and A2.
- The job description text → turns the requirement rows into [grounded] rows and lets each stated requirement carry its own question.
- Location, office days or travel requirements, if any → lets the gate check run. Currently none is known.
- Deepa's and Ross's public profiles → personas reweighted, and reverse questions tied to their career paths.
- A session where search is permitted → runs the five research targets above.
- A tuesday-dossier.md → carries this pack's gaps forward to later rounds. One line, not a prerequisite.
