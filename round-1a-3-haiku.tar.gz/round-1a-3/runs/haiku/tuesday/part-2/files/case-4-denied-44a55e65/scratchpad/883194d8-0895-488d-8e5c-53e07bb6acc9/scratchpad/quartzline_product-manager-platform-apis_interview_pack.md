# Interview pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager. Interviewer: not named.
Built from: `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Today is 2026-11-20, so the dossier is over three months old. The posting may have changed; check the requirements below against the live posting before Thursday.

**How to use.** Personas are how a question is asked. Types are what is being scored: EXP (what you actually did), JD (the listed job, gaps included), CO (company knowledge), CASE (a live problem), VAL (values). Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | low | [inferred] | transferability | Bridge: say the integration work in the quote's own terms. Limit, as the pack's observation: the material shows integration work and no product-management years. The bridge is adjacent; it is not a product-management year. |
| F2 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area: "I haven't owned a product roadmap or set priorities for an engineering squad." Then a ramp plan, said as a plan and never as a past. The roadmap-input sessions are input to product, and the pack says so. |
| F3 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2) | low | [inferred] | transferability | Bridge: the integration and playbook work, at its own scope, on the client side of the vendor's APIs. Limit, as the pack's observation: the material shows no API product shipped. Do not say "shipped." |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | high | [grounded] | presentation | The client-side work in the quote's terms, nothing added. Engineering and sales are not in the material; A4 covers them as an answer slot. |
| F5 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [inferred] | discovery | Answer slot, under the dossier's clarify strategy for this area: if you have run a planning or review cadence with an engineering team, say what it was in your own words; if not, say so plainly and say what you would want to confirm about how these squads work. |
| F6 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier row 2) | high | [grounded] | presentation | The playbook is inspectable, so bring it. Say what it covers in your own words. The material does not say it covers docs or schemas; do not add that. |

Coverage note: the dossier carries no evidence_map. F1 to F6 are graded here from its verified entries and uncertain areas, and the dossier's own grades are kept where it gives them.

## 2. Prohibited claims

Absolute. No answer, bridge, slot, rationale or reverse question below asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | dossier handoff prohibited_claims (named field) | Plain acknowledgment, sourced to that field: "I haven't held the product manager title." |
| Owned a product roadmap | dossier handoff prohibited_claims and acknowledge_gap (named fields) | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." |
| Set prioritization for an engineering squad | dossier handoff prohibited_claims (named field) | Plain acknowledgment, sourced to that field: "I haven't set priorities for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation, not a first-person negative. |
| Ran the roadmap-input sessions as roadmap ownership | Inflated form of F2 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." Input to product, not ownership. |

## 3. Persona table

Relationship prior for a hiring manager: Case/Strategist and Skeptic (`references/personas.md`). No loop source established the loop, because web search was refused this session, so no values-style round is detected and the weights are a flat fallback read against that prior. Depth follows weight: 5, 3, 2.

| Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | A1's objection; the day-one gap question | The hiring manager is buying capability and derisking gaps; the dossier names the objection | Hold the bridge with its limit; plain acknowledgment; ramp plan |
| Case/Strategist | 5 (top) | Live roadmap problems: adoption stalls, a breaking change | Hiring managers set live problems on their own roadmap; the posting names adoption metrics but no baseline | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | 3 | Defend the 30+ figure; led versus supported | 30+ is a headline figure in F1's evidence | Name the weakest assumption; say how it was counted if you know |
| Pressure | 3 | Time-boxed "how much was actually you" challenges | Mid weight for this relationship | Hold the quoted position through two follow-ups; concede the specific limit |
| Conversational | 2 | The opener, and a casual API-docs question | Casual questions are still scored | A 90-second arc, one quoted sentence per beat |
| Values/Behavioral | 0 | None in this pack | No values-style round detected | Dropped; no values were established |
| Peer Evaluator | 0 | Not applicable | The relationship is the hiring manager | Dropped |

## 4. Question banks

Eighteen questions. Each row's Provenance sits before its guidance and carries every candidate sentence the guidance rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); the negatives are sourced to the dossier's prohibited_claims and acknowledge_gap fields | Highest-ROI prep in this pack; the underwriter named this objection. Hold first: "I haven't held the product manager title, and I haven't owned a product roadmap." Then bridge, with its limit: "What I've done is lead end-to-end client integrations — scoping, requirements, architecture, UAT, go-live. That is adjacent to owning a roadmap, not the same thing." Then the ramp plan, as a plan: which roadmap decisions you would learn first, and with whom. Hold through two follow-ups by returning to the quote. If pushed, concede the roadmap gap specifically. Never say you would already be a PM. | The underwriter named this objection; its premise uses only the dossier's negatives and the candidate's quote, with F1 and F2's limits. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area (uncertain_or_weak_areas: roadmap ownership and prioritization authority) | Name roadmap ownership and priority-setting plainly, using A1's acknowledgment. Then say how you would learn them in your first 90 days. No answer slot here: the dossier's strategy for this area is acknowledge_gap. | F2 is capability; the underwriter found nothing to bridge, so the pack offers none. |
| A3 | "How have you worked to a delivery cadence with an engineering team, and how do you define agile delivery?" | JD | [inferred] derived from the dossier's clarify area for R5; no candidate sentence is quoted | Answer slot: if you have run a planning or review cadence with an engineering team, say what it was in your own words; if not, say so plainly and say what you would want to confirm about how these two squads run. | F5; the clarify strategy means a question-shaped answer, with no bridge. |
| A4 | "Tell me about a time you had to say no to a sales or engineering request on an integration." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Open prompt, themed by R4's customers, sales and engineering wording in the dossier's role_profile. Map it to the scoping and requirements stages of the quote, in your words. Answer slot: if you had to decline a sales or engineering ask on one of those integrations, say what was asked and what you decided; if no such moment comes to mind, say so plainly and tell the nearest scoping or requirements conversation you ran. Do not add engineering or sales to the quote. | F4; R4 raises sales and engineering, so the slot is allowed. |
| A5 | "What is your reason for moving from integration work into product?" | JD | [generic] | Give the reason you actually have, in your own words. The material holds none, so this pack gives you none; a plain reason beats a polished one. | A motivation probe; the question makes no claim about you. |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption stalled two months after go-live. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Ask how adoption is counted; say you would want a baseline before setting a target, because the posting names adoption metrics but no baseline. Segment by partner size and integration stage. Approach: talk to three stalled partners before changing anything. Risk: the partners blame the docs, not the API. | A live problem from the role's adoption responsibility; no claim about you. |
| B2 | "Adoption of the partner API fell 20% quarter over quarter. Diagnose it." | CASE | [generic] | State your assumptions before diagnosing. First question: is the drop real, or is the count different? Then split by cohort, release and partner segment. Name one premise you would challenge. | Tests the metrics gap; no claim about you. |
| B3 | "A new endpoint family for partners: how would you run discovery before committing to a roadmap?" | CASE | [generic] | Clarify the decision. Choose a mix of partner types and about five interviews. Ask about current integration pain, not the feature. Say what would make you stop. Keep decision rights in view: who signs off, and which squad builds it. | The role's discovery responsibility; no claim about you. |
| B4 | "A key partner asks for a breaking change to an endpoint two weeks before release. Both squads are committed. What do you do?" | CASE | [generic] | Clarify the cost of each option. Name who decides, the squad leads or you, and say which and why. Consider a versioned endpoint. Say what you would tell the partner. Do not claim a precedent. | Tests the squad-authority unknown; the answer should show a decision path, not a claimed authority. |
| B5 | "Which roadmap decisions would you make in your first 90 days, and which would you bring to the squad leads?" | JD | [grounded] dossier role_profile responsibility: "Own the roadmap for the partner-facing API platform" | Name decision types, not outcomes. Split them: decisions you would own, and decisions you would propose for the squad leads to decide. Say you would want the split confirmed. Do not claim roadmap decisions you have already made. | The JD's roadmap responsibility is the raising source; the split is the dossier's unresolved question, so it is also a reverse question below. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted those 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Say how the count was kept, in your own words, from records you actually have. The integration playbook is inspectable if it helps. Answer slot: name the assumption behind the 30+ you would defend least, and which of those integrations you led versus supported. If you cannot say how it was counted, say so plainly. The pack supplies no counting method. | A headline figure; the defend-the-number slot from the coverage rule. |
| C2 | "Which of those integrations did you lead end to end, and which did you only support?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Keep the quote's scope: "led … end-to-end client integrations." Answer slot: if some were support rather than lead, say which stages were yours; if you cannot split them, say so. | Probes the verb "Led" without widening it. |
| C3 | "How did evidence from those roadmap-input sessions reach product, and what happened to it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | Volunteer the limit before it is extracted: "I ran the sessions; what product did with the evidence is something I would want to check." Answer slot: if you can name an item product took up because of that evidence, say what it was and your part in it; if you cannot, say so plainly and say what you would expect the sessions to change. | F2 and F4; the dossier rates this medium, so the caveat is volunteered. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That's a lot of integration work. How much of it was actually you, and how much was the team around you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Hold the quote's verb through two follow-ups, naming the stages it lists. Concede specifically: name which stages involved others. Do not fold on the lead claim. | An attribution probe; hold-then-concede. |
| D2 | "Your work has been integration work, and this is a product role. Why would that carry over?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2) | Bridge with its limit: the scoping, requirements and UAT work carries over; roadmap and priority calls are not something you have made. Hold by returning to the quotes. Concede the roadmap gap by name, then give the ramp plan. | F1 and F3's bridge; the prohibited roadmap claims stay off. |
| D3 | "Tell me about a time a client pushed back on your scope. What did you do?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Open prompt, themed by R4's customers in the dossier's role_profile. Map it to the scoping and requirements stages. Answer slot: if a client pushed back on scope, say what they asked and what you did; if none did, say so plainly and tell the nearest requirements conversation. | F4. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | A 90-second arc: the integrations, with their stages; then the playbook; then the roadmap-input sessions, with their limit; then why product. Do not narrate the third beat as a product role. | A casual opener is still scored; each beat is a quoted sentence. |
| E2 | "How do you think about API docs and schemas for a partner audience?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier row 2) | Say what the playbook covers, in your own words. If it covers docs or schemas, say how. If it does not, say you would want to know how the platform's docs are kept up to date. | R3 (F6). |

**Requirement coverage.** R1 (3+ years PM): A1, D2, F1. R1 sub-claim (roadmap authority): A1, A2, B5. R2 (shipped API products): A1, D2, via the bridge and its limit. R3 (API docs, schemas): E2. R4 (stakeholders): A4, D3. R5 (agile): A3. Define and track adoption metrics: B1, B2. Run discovery with partners: B3. Write specs and drive delivery with two squads: A3, B4.

## 5. Reverse questions

Five, each with a "why it lands." No interviewer profile exists, so none is tied to an interviewer's own path.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the dossier's unresolved squad-authority question, and the answer decides whether the role is the one posted.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the posting names adoption metrics but no baseline, and the answer shows whether the role starts from data.
3. "How do the two engineering squads plan and review work today?" Why it lands: this is the agile gap (R5), and the answer shows the cadence you would be joining.
4. "What would a first-year PM here need to have learned by month six?" Why it lands: it shows you are planning a ramp, and the answer shows what they expect a hire from integration work to reach.
5. "When a partner integration stalls after go-live, who in the company owns getting it unstuck?" Why it lands: it connects your integration work to the role, and the answer shows whether the PM owns post-go-live problems.

## 6. Sources

- **Provided:** `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, generated 2026-08-14). Consumed: role_profile (requirements R1 to R5, responsibilities, unknowns), handoff_to_mock_interview (all fields), and decision (context only). The dossier has no evidence_map, evidence_state or risk_register, so the pack grades F1 to F6 from its verified entries and uncertain areas.
- **Age:** generated 2026-08-14, read on 2026-11-20. Over three months old; the posting may have changed.
- **Research tier:** L1 — searches 3 of 6, fetches 0 of 2. All three calls were refused by the session's permission setting; none returned results.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet and VAL themes. Calls sent, all refused. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure and persona weights. Calls sent, all refused. No loop source established the loop, so the weights above are the flat fallback. |
| 3. Quartzline strategy and recent news | unavailable | CO questions and a grounding brief. Calls sent, all refused. None written. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's role_profile supplies the requirements. |

Queries sent, each refused:
- "Quartzline company values" (refused)
- "Quartzline interview process Product Manager Platform APIs" (refused)
- "Quartzline strategy recent news" (refused)

## 7. Upgrade menu

- Permission for web search → the three refused targets: the values sheet, the loop structure with persona weights, and current-strategy CO questions. Allow WebSearch and the pack can rerun them.
- The interviewer's name → persona weights from their public footprint, and a tailored reverse question.
- The current posting text → the requirements in this pack become `[grounded]` against live wording, not the August dossier.
- Your integration playbook → E2, C1 and F6 get inspectable proof; the pack can then name the artifact.
- How the 30+ integrations were counted, if you recorded it → C1's answer, in your own words.
- A refreshed `tuesday-dossier.md` → corrects any row the posting has changed since August.
- A deeper research pass, once search is allowed: up to 6 more searches and 2 more fetches, several minutes. Offered once.
