# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. **Format:** single 60-minute conversation. **Version:** first pack, no regeneration yet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

| Type | Meaning in this pack |
|---|---|
| VAL | Behavioral and values. None in this pack: no values-style round is detected (see Sources). |
| EXP | Your own work, tested for attribution and detail |
| JD | The role's listed requirements |
| CO | Northwind's strategy and competitive position |
| CASE | A live problem, structured aloud |

Answer slots, marked "Answer slot:", are instructions for the interview. They ask for no reply here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Adjacent product work. The material does not show GTM ownership of a product line. Say the quote at its own scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you set any go-to-market decision for a product line (who it sells to, at what price, through which channel), say which and how you decided; if none was yours, say so and stay with the proposal. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show work on land, adopt, expand or renew. Answer slot: if you worked on any of those stages, name the stage and what you did; if none, say so and describe how you would build the whitespace view first. |
| F3 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | discovery | The quote touches partners and revenue. The material does not show whether it reaches partner-motion design. Say the quote at its own scope. Answer slot: if you designed partner terms, incentives or a channel motion, say which and how you decided; if you did not, say so and say how you would approach it. |
| F4 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on who disagreed. The disagreement is not in the sentence, so do not add it. |
| F5 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | Derivation: the skill is stated, but independence is not, so the gap is this pack's reading of the quote. Your material says you are skilled in SQL/Tableau; it does not show an analysis you ran end to end. Answer slot: pick one analysis you ran yourself and walk it through; if your work supported someone else's question, say so and describe your part. |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms: usage rather than experience. Say it as the sentence does: "I use AI tools daily." Add what for, in your own words. No building claim. |

## Prohibited claims

These are not coached anywhere in this pack, including in the answer slots and the drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| "Ran the go-to-market for a product line" | Inflated form of F1 | The quote at its own scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." The limit is this pack's observation: the material shows a proposal, not GTM ownership. |
| "Led the store-surface change" | Inflated form of F1, where the material says "proposed" | The same quote. "Proposed" stays "proposed." |
| "Designed the partner motion" or "Built the partner program" | Inflated form of F3 | "built a partner-level revenue model used in carrier negotiations," at that scope. |
| "Ran the SQL and Tableau analysis end to end" | Inflated form of F5 | "skilled in SQL/Tableau," at that scope. Only the answer slot in A4 asks further. |
| "Built AI products" | Inflated form of F6 | "uses AI tools daily." |
| "Set quotas" or "Ran sales ops" | Sourced entry: a negative you stated, "No classic sales-ops or quota-setting experience." | Plain acknowledgment: "I haven't done classic sales ops or quota-setting." Then the nearest quote at its own scope: "set annual volume targets with cross-org consensus." |

## Reading the interviewer

Public footprint was not searched (see Sources), so this read rests on the profile you described.

| Observation | Source | Implication for this round |
|---|---|---|
| Career: pricing and monetization roles, with one early-stage startup chapter | your profile | Expect pricing and packaging angles in the case questions. Builder stories land well with him. Expect a scrappiness probe on big-company pace. |
| Self-described as "relentlessly data-driven" | your profile | Expect every number to be followed to its assumptions. The prober persona moves up. |
| Peer, same VP | your note | Seam, credit and decision-rights questions are native to him. |

**Mirror opportunity:** revenue-model vocabulary. The partner-level revenue model is the one piece of your work that speaks his language, so raise it on purpose. **Shared jump:** none established from the inputs, so none is offered.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Two-level follow-ups on any number; asks for denominators and inputs | High, 5 questions. Your profile describes him as "relentlessly data-driven," and the peer prior already leans this way. | Name the weakest assumption before he does. Say plainly what you do not know about how a number was counted. |
| Peer Evaluator | Seams between teams, decision rights, credit, what you would take off his plate | High, 5 questions. Peer relationship, same VP; the peer prior puts this persona first. | Offer reciprocity: what you bring to his team. Propose seam principles rather than pretending to know the seam. |
| Case / Strategist | Pricing, adoption and bundling problems | Mid, 3 questions. His pricing and monetization career points the case angle toward pricing and packaging. | Clarify first, then the objective, the segment, the metrics. Challenge one premise per case. |
| Skeptic | The gaps: partner motion, lifecycle work, no quota history | Mid, 3 questions. A peer does not carry hiring risk, but his probes will land on the same gaps the JD exposes. | Rehearse the partner-motion objection until it is plain. Answer with a plan for the gap, never a bridge built past your sentences. |
| Pressure / Stress | Interruptions on the $400M figure and on experience | Low, 2 questions. Kept at 2 so you meet the style once, not for the first time live. | Pause. Restate the question. Hold through two follow-ups, then concede exactly what is true. |
| Conversational | Casual openers that score JD topics | Low, 2 questions. Peer conversations often open casually, and the casual questions are still scored. | A 90-second arc built only from your own sentences. Treat the AI question as scored. |
| Values / Behavioral | Not in the bank | Not weighted. No loop source documents a values round, and the fallback archetype is generic, so no values round is detected. | None. |

## Requirement coverage

| Requirement (JD highlight) | Covered by |
|---|---|
| own GTM strategy for two new product lines | C3, D1 (partial: F1 is transferability, so no question rests on a claimed GTM record) |
| identify whitespace across land/adopt/expand/renew | A3, C2, D2 |
| run independent analysis in SQL and Tableau | A1, A4 |
| partner-motion design experience required | A1, B2, D1 |
| strong cross-functional influence | B1, B3, B4 |
| AI experience a plus | G2 |

## Question banks

Ordered by weight. Each Provenance cell carries the candidate's own sentences the guidance rests on, quoted exactly.

### A. Data-Driven Prober (high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the carrier revenue model's numbers were counted." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Open with the model at its own scope: "I built a partner-level revenue model, and it was used in carrier negotiations." Then say how the inputs were sourced, in your own words. Answer slot: if you set any input yourself, name it and how you chose it; if the inputs came from others, say so plainly. Name the assumption you would defend least before he asks. | F3 is the nearest evidence for the partner-motion requirement, and this model is the artifact a prober will open first. EXP because it tests what was yours. Also touches the JD's SQL and Tableau line through how the numbers were built. |
| A2 | "How was the ~$400M uplift measured, and how much of it was yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it as the sentence states it: you proposed a store-surface change, and the uplift was credited to it. Defend-the-number slots: how the uplift was counted, and what it is sensitive to. Answer slot: if you know the measurement method, say it; if you do not, say so plainly. Name the assumption you would defend least. Keep "credited with" as the attribution; do not turn it into "I drove." | This is the headline metric on the record and the likeliest place to be probed. F1 is its row. EXP because the question tests attribution. |
| A3 | "How would you size the whitespace across land, adopt, expand and renew for one of the new product lines?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" | Structure it aloud: the four stages; for each, the data you need and its grain; the denominator you trust least; the Tableau cut you would build first. Clarify the product line and the customer segment before structuring. No claim about your past and no figure. | F2 is discovery, so this question shows your approach without claiming a record. Primary type CASE; the JD line makes it a JD question too, which the rationale carries. |
| A4 | "Show me an analysis you ran yourself in SQL or Tableau. What question did it answer?" | EXP | [inferred] "skilled in SQL/Tableau" (the independence in the question is the JD's; the quote does not carry it) | Pick one analysis: the question it answered, the data it used, and what changed as a result. Answer slot: if you ran it end to end, say so and walk through it; if your SQL or Tableau work supported someone else's question, say so plainly and describe your part. Do not describe independence the material does not show. | F5 is low confidence, so this question tests the skill rather than asserting it. The JD asks for independent analysis; the prober asks for what was yours. |
| A5 | "Which data would you need before trusting a partner-level forecast, and which would you not trust yet?" | JD | [generic] | Name the grain of partner data, the denominators, and the source you would distrust first, whether partner-reported or your own. Make no claim about your past. | Tests method on the partner requirement without a story. [generic] because it is a role-family analytics pattern. |

### B. Peer Evaluator (high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Emerging Products and sales strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles first: who owns pricing and packaging for new lines, who owns the target, how a disagreement gets decided. Then the story: the consensus you set volume targets with. Answer slot: if a disagreement between teams came up, name the teams, the point of disagreement, and how it closed; if none came up, say so, and say how you would handle one. Do not claim you resolved it alone. | Peer weight. The seam question is peer-native. The consensus quote is the only candidate material that touches cross-org disagreement, and it stays at its own scope. |
| B2 | "Partner motions are a required part of this role. Have you designed partner terms or incentives yourself?" | JD | [grounded] "partner-motion design experience required" and [grounded] "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep in this pack.** Hold: the partner-level revenue model, at its own scope. Answer slot: if you designed partner terms, incentives or a channel motion, say which and how you decided them; if you did not, say so plainly, and say how you would approach the design: which partners, which economics, what you would test first. Hold through a second follow-up by returning to the model. Never describe a partner program you did not design. | F3 is discovery and the requirement is listed as required. A peer will press it collegially, and it is the single most predictable objection. Deepest rehearsal: the question, then "what did the model show?", then "what would you change?" |
| B3 | "When a pricing call and a volume target pull against each other, whose call is it?" | JD | [generic] | Give the principle first: name decision rights in advance, who owns price, who owns the target, and the escalation path. Any example is a selection scaffold: pick a time two teams' numbers conflicted; if none comes to mind, say so plainly. No claim. | A peer decision-rights probe. His pricing background makes pricing the likely example. |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the sentence's own split: you proposed it, and the credit went to it. Say what the team did and what you did. Do not claim the whole. Answer slot: name the people whose work was part of it, and your part, in your words. | Credit is a peer test, and the $400M line is the most-credited item in the material. |
| B5 | "If you joined, what would you not want to own?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Name one thing you would hand off or decline, in your own words, and why. The honest answer is the one the material already states: sales operations and quota-setting are not your background. | An anti-pick. It tests whether the candidate knows the edge of their own experience, and it hands the peer a reason to share the load. |

### C. Case / Strategist (mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You're pricing a new add-on for an enterprise customer base. Where do you start?" | CASE | [generic] | Clarify the add-on's job and the buyer. Set the objective (revenue, adoption or margin), say which and why. Segment, choose a value metric, then a willingness-to-pay test. Name the metric you would watch and the risk of cannibalizing the bundle. Speakable in 90 seconds. | Pricing is his native ground. Enterprise expansion is one of Northwind's stated priorities in your note. |
| C2 | "Adoption on one of the new product lines has flattened after launch. Diagnose it." | CASE | [generic] | Clarify the adoption definition. Split by segment and by partner. Check whether the problem is supply (who was sold to) or usage (what happens after sale). Name the first data cut. Challenge the word "flat" against a baseline. No figure. | Covers the adopt stage from the JD line. A stem in the Case persona's own form. |
| C3 | "The main threat is a much larger platform vendor bundling a competing product. What do you do with the new line in the next twelve months?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | The consensus answer: differentiate on what a bundle is weak at, or price against the bundle. Then one thesis that departs from it, with its concession. Tie it to the priority your note names: enterprise expansion, or the Compass launch. Do not recite the note back as a list. | The CO question is drawn from your research note. That note is undated, so check its recency before the interview. Type CO; the case structure makes it CASE too. |

### D. Skeptic (mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" | Name partner-motion design as the honest weakest point, in plain words. Bridge only with what the material carries: "I built a partner-level revenue model used in carrier negotiations." Then a plan, said as a plan: how you would learn partner-motion design in your first ninety days. Never describe a partner program as a past. | The Skeptic's stem targets the gap F3 exposes. A plan is the only honest move the material supports. |
| D2 | "I don't see land-and-expand or renewal work in your background. How would you handle it?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" | Say what your material shows as your own observation of it: it does not show work on these stages. Answer slot: if you worked on any stage, name it and what you did; if none, say so, and say how you would build the whitespace view. Do not say "I have never done this" unless you have stated it. You have not. | F2 is discovery. The interviewer's observation is fair, and the honest response is either branch. |
| D3 | "Your background has no sales-ops or quota work. Why would a sales strategy lead want that?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." and [grounded] "set annual volume targets with cross-org consensus" | Plain acknowledgment: "I haven't done classic sales ops or quota-setting." Then the nearest true thing, at its own scope: "I set annual volume targets with cross-org consensus." Do not say you set quotas for reps. The rehearsal is what you bring that a quota specialist would not, in your own words. | The one negative you stated. The rehearsal is acknowledging it without inflation, and naming the adjacent work at its own scope. |

### E. Pressure / Stress (low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run sales strategy for ten years?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Pause. Restate the question. Hold: nine years in product strategy and operations at a large consumer-tech company, plus a revenue model used in carrier negotiations. Hold through two follow-ups. Concede exactly what is true: no sales-ops or quota background. Do not fold on the product-strategy core. | Tests composure on a comparison you cannot win on the sales-strategy axis. The hold is only what the sentence carries. |
| E2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: you proposed it, and the uplift was credited to it. Concede specifically: if you do not know how it was counted, say so; if the attribution was shared, say how. Do not fold to "none of it" if the proposal was yours. | The pressure version of A2, short. Practice the hold and the concession separately. |

### G. Conversational (low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A ninety-second arc built only from that sentence: two years in strategy consulting, then nine at a large consumer-tech company in product strategy and operations, then the revenue model and the store-surface proposal, then why these two product lines. Stop at the bridge. | Casual openers are scored. The arc is built from quoted sentences and no more. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools you use daily and what you use them for, in your own words. Do not say you built anything with AI. Answer slot: if you have built or shipped an AI feature, say so and what it did; if not, say so. | The "AI experience a plus" line, asked casually. It is scored. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where does Emerging Products stop and sales strategy start on pricing for the new lines?" | A seam question that shows you read the org, and it sets up B1. |
| R2 | "Of the three priorities, enterprise expansion, the Compass launch and reaching profitability, which weighs most on this role in its first year?" | Anchors to the priorities in your note, and shows you think at the company's altitude. |
| R3 | "How do you see the platform vendor's bundling changing which new line is worth the most sales effort?" | The competitive frame, and it invites his view. |
| R4 | "You came into sales strategy from pricing and monetization. Which pricing decision do you think most often gets made too late?" | Ties to his own path. It turns the interview into a peer conversation about his work. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer question. It signals contribution rather than need. |
| R6 | "On annual targets, where does the VP leave the number to the teams, and where does it come down from above?" | Shows you understand target-setting as a consensus process, which connects to the consensus you set targets with. |

## Sources

**Provided documents:** your message. That is the six JD highlights (not full JD text), the candidate summary, the interviewer profile description, and your Northwind research note.

**Searches sent:** three queries, all refused by the host ("permission not granted"). Nothing returned.
- "Northwind Data values": refused.
- "Northwind Data interview process sales strategy": refused.
- "Dan Kovac Director of Sales Strategy Northwind Data": refused.

**Fetches sent:** none.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. No link was read.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Values cheat sheet (section 10). Omitted because no values-style round is detected. Every query was refused. |
| 2. `Northwind Data interview process sales strategy` | unavailable | Loop structure and persona weights. Weights rest on the peer prior and your profile, not on a documented loop. |
| 3. `Northwind strategy` / recent news | skipped | Your research note already gives the three priorities and the competitive threat, so the CO bank draws on it. Its date is unknown. |
| 4. `Dan Kovac Northwind` | unavailable | The public footprint: talks, posts, recurring themes. The interviewer read rests on your profile description alone. |
| 5. Representative JD | skipped | The six JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

**Values round:** not detected. No loop source documents a values round, and the fallback archetype is generic, so no values section or VAL bank appears.

## Upgrade menu

- Full JD text → requirement rows quote the posting instead of your highlights, and any further requirements get rows.
- Recruiter's focus areas or a pre-declared deliverable → coverage of that deliverable, and a build section for it if it is a graded piece.
- Dan Kovac's public talks or posts (once a search can run) → his recurring themes become likely questions, and a sharper reverse question.
- Northwind's values page → a values cheat sheet, if the recruiter confirms a values-style round.
- The loop from the recruiter → persona weights recomputed from the actual rounds.
- A dated strategy brief under six months old → the CO bank checked for recency; C3 drops or updates.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief, interviewer talks, and role-family loop reports. Offered once; say if you want it.
- A `tuesday-dossier.md` from a prior session → verified evidence, prohibited claims and objections carried in, instead of the local lists above.
