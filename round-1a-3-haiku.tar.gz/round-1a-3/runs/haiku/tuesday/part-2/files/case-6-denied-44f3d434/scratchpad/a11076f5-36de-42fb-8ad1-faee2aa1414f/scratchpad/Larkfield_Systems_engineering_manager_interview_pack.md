# Larkfield Systems, Engineering Manager: three-round prep pack

Loop mode: three scheduled rounds. Round 1 is the Director of Engineering (hiring manager, 45 min), round 2 is a panel of two staff engineers and a product manager (60 min), and round 3 is the VP Engineering (30 min, "values and leadership philosophy"). One shared fit snapshot and sources block, then a mini-pack per round weighted to who will be in the room.

## How to use and type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

- **VAL**: behavioral and values. Does past behavior show the lead you describe?
- **EXP**: your own work, probed. Does what you say you did survive scrutiny?
- **JD**: the role itself, including its gaps.
- **CO**: company and strategy knowledge. Generic in this pack, because no strategy source was available.
- **CASE**: a live problem, reasoned aloud.

Provenance labels: **[grounded]** traces to your message or the role description in it. **[inferred]** is derived from them, with the derivation named. **[generic]** is a pattern for the role or the problem, with no claim about Larkfield.

An **answer slot** is an instruction for the interview, not a question for this conversation. It gives you the honest branch as well as the one you can answer.

## Shared fit snapshot

"Role description" below means the role text in your message. "Your message" means your own sentences in it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead two squads building device-management services" (role description) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Words to use: your own sentence, "3 as a team lead of 6". Two squads and eleven engineers are not in your material. Answer slot: if you have run more than one team at a time, say how you decided what each one did; if not, say so plainly and give your plan for splitting the work. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description), the hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | Hiring is reached in role-relevant terms. Words to use: "I run our hiring loop for backend roles." Keep the scope at backend roles; do not let it widen to all engineering hiring. |
| F3 | "own delivery" (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The sentence reaches delivery in other terms: a reliability quarter, not feature delivery. Words to use: "I pushed a reliability quarter through against roadmap pressure." Keep the 60% on your team's on-call burden. Do not widen it to the organisation, or to delivery of product features. |
| F4 | "growth for 11 engineers" (role description) | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: if you helped people on your team grow, say how, in your own words; if you did not, say so plainly and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (role description) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Words to use: "I pushed a reliability quarter through against roadmap pressure." That is holding a roadmap line against pressure, not partnering to shape the roadmap with product or hardware. Answer slot: if you shaped a roadmap with product, say how you decided what went in; if the roadmap was set without you, say so. |
| F6 | "partner with hardware and product on roadmap" (role description), the hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words to use: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past: the first two people you would ask and the first document you would read. |
| F7 | Managing managers, implied by "lead two squads". Inferred from the role text, not stated in it | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words to use: "I haven't managed managers." Then the plan, said as a plan: what you would learn first about managing people who manage others. |
| F8 | "building device-management services" (role description) | "currently at a payments company" (your message) | low | [grounded] | discovery | Your material does not show device, telemetry or fleet work. Answer slot: if you have worked on any of those, say which, in your own words; if not, say so plainly and say how you would get up to speed. |

Gate rows: none. The role text states no location, schedule, pay or travel terms. If the posting states any, send it and the snapshot gets gate rows.

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| lead two squads building device-management services | 1A2, 1B1, 2F1, 3C1 | |
| device-management domain | 1B2, 2D3, 3C1 | |
| own delivery | 1C1, 2F2, 3P2 | |
| hiring | 2D2, 3V4 | |
| growth for 11 engineers | 1A3 | |
| partner with hardware and product on roadmap | 1B3, 2E1, 2F1, 2F2, 3C2 | |
| managing managers (raised by you) | 1A1, 1C2, 3P1 | |
| hardware-adjacent roadmap (raised by you) | 1A1, 1A4, 2F2 | |
| values and leadership philosophy (recruiter's words) | 3V1, 3V2, 3V3 | Published values: none, and why: none were in hand; the values search was refused. |

## Prohibited claims

Each entry names its basis and its honest form. The wording is not coached, in any slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed eleven engineers | Inflated form of F1 | "3 as a team lead of 6", at its own scope. The limit is this pack's observation: your material shows one team of six. |
| Ran hiring across engineering | Inflated form of F2 | "I run our hiring loop for backend roles." |
| Owned delivery across the organisation | Inflated form of F3 | "I pushed a reliability quarter through against roadmap pressure", at your team's scope. |
| Shaped the roadmap with hardware and product | Inflated form of F5 | The F5 quote. The answer slot stays inside it. |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated, F7 | "I haven't managed managers." No slot. |

## Sources

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Provided documents: your message (role description, background, the recruiter's wording "values and leadership philosophy").

Queries sent, and what came back:
- "Larkfield Systems values": refused (the search permission was not granted).
- "Larkfield Systems interview process engineering manager": refused.
- "Larkfield Systems industrial IoT strategy news": refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10): omitted, because no published values are in hand. The values-style round is detected from the recruiter's words, not from a values page. |
| 2. Interview process, engineering manager | unavailable | Loop structure. Your own description establishes the loop: three named sessions, each with who runs it. Persona weights follow your rounds; no archetype fallback applies. |
| 3. Strategy or recent news | unavailable | CO bank. Strategy questions are CASE or generic and labelled as such (3C1). |
| 4. Interviewer name and company | n/a | No names given, so there was no query to form. |
| 5. Representative JD | skipped | The role description in your message fixes the requirements. |

## Round 1: Director of Engineering, hiring manager, 45 min

Relationship prior: Case/Strategist and Skeptic. Interviewer signals: none, since no profile exists.

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 4) | Opens on the two gaps and asks why it is a safe bet | High. A hiring manager is buying capability and derisking gaps, and you have stated the two negatives yourself. | Plain acknowledgment, adjacent evidence at its own scope, then a plan. Rehearse 1A1 until it is dull. |
| Case/Strategist (weight 3) | A live problem on the device roadmap | High to moderate. The role text names the roadmap partnership. | Clarify, then structure. Say your assumptions aloud. |
| Pressure (weight 2) | A time-boxed challenge on the 60% number and on your team-lead scale | Moderate. A 45-minute round with one headline number on your CV. | Pause, restate, hold through two follow-ups, concede the specific thing. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "I don't see managing managers or a hardware-adjacent roadmap in your background. How would you handle those?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "3 as a team lead of 6" (your message); [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Highest-ROI rehearsal. Say the negative once, in your own sentence: "I've never managed managers and never owned a hardware-adjacent roadmap." Then your adjacent evidence at its own scope: "3 as a team lead of 6", and "pushed a reliability quarter through against roadmap pressure". Then the plan, said as a plan: what you would learn first, from whom, and what you would watch in the first month. Do not describe a manager or a roadmap you did not own. Hold through one follow-up by returning to the plan. | F6 and F7 are the negatives you stated, and "lead two squads" makes them the likeliest opening. This is the single most predictable objection, so it gets the deepest rehearsal. |
| 1A2 | "How would you split two squads of eleven engineers when you have led one team of six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); [grounded] "lead two squads building device-management services" (role description) | Your team of six is the only scale your material shows. Then the split, as a plan: what you would keep central, what you would hand to whom, and what you would check first. Answer slot: if you have run more than one team at a time, say how you decided what each one did; if not, say so plainly. | F1 is the evidence and the scale gap. The premise "one team of six" is the quoted sentence; "eleven" is the role's own number. |
| 1A3 | "How have you helped the engineers on your team grow, if at all?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role description) | Answer slot: if you helped people on your team grow, say how, in your own words, with the people and the step you took. If you did not, say so plainly, then say how you would start with eleven. Do not name a promotion, plan or move that is not yours to name. | F4 is discovery: your material is silent on growth. The question is open, so it presupposes no work the material does not show. |
| 1A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | The honest answer is the one you already wrote: the hardware-adjacent roadmap. Say it plainly, then the first thing you would do about it, as a plan. Hold the plan to what you would do, never to what you have done. | Persona stem for the Skeptic. The answer is one you already gave, so the rehearsal is saying it without a hedge. |
| 1B1 | "Sketch your first 90 days leading two squads on device-management services. What do you need to know first?" | CASE | [grounded] "lead two squads building device-management services" (role description) | Clarify first: what the two squads deliver, and who sets their priorities. Then objective, approach, metrics, risks. Do not assert any fact about the squads, the product or the team that you have not been told. | A live problem from the role's own words. It asks nothing about your past. |
| 1B2 | "Check-ins from a device fleet fell 20% last week. Diagnose it." | CASE | [generic] | Clarify first: what counts as a check-in, and whether the drop is across all devices or one segment. Then hypotheses, cheapest to test first. Name one assumption you would check before trusting the number. | A generic live problem for device-management: a pattern for the domain, not a fact about Larkfield. |
| 1B3 | "Hardware wants a firmware change that slips product's launch by a quarter. How would you decide?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify the cost on each side before you pick. State the decision principle you would use, then what you would take to each team. Do not claim you have made this call. | Tests the roadmap partnership the role names. It asks for a method, not a past decision. |
| 1C1 | "That 60% on your team's on-call burden. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the part your sentence carries: you pushed the quarter through. Defend the number in your words: how the on-call burden was counted, what it is sensitive to, and the assumption you would defend least. Answer slot: if you did the counting, say how; if someone else did, say who and what part you did. Concede specifically what you cannot attribute to yourself. | The 60% is the magnet for a Pressure question on the CV. Hold, then concede, is the structure. |
| 1C2 | "Sixty seconds: why should I bet on you over someone who has already run a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message); [grounded] "3 as a team lead of 6" (your message) | Pause, restate the question. Anchor in what you stated: the team of six, the hiring loop, the reliability quarter. Hold through two follow-ups. Concede the gap plainly: "I haven't owned a hardware-adjacent roadmap." Do not argue that the gap does not matter. | Pressure version of the likeliest objection. The concession is the one you already wrote, so the test is holding the rest without folding. |

Reverse questions (round 1):
- "What would the first 90 days look like for the person who takes these two squads, and where would you expect them to struggle?" Why it lands: it surfaces the gap they will rate you on, and shows you are thinking about the job, not the title.
- "Where does the device roadmap get stuck today, between hardware and product?" Why it lands: it shows you want the seam, which is the hardest part of the job.
- "What did the last person in this role decide that they wish they had decided sooner?" Why it lands: it reveals the real operating pressure.
- "How is hiring for the two squads planned over the next two quarters?" Why it lands: it tests the scope of the hiring and growth line you were given.
- "What would make you say, six months in, that hiring me was the right call?" Why it lands: it gives you their criteria, so the rest of the loop can address them.

## Round 2: panel, 60 min

Relationship prior: the panel rule blends the top two personas of each member's relationship. No names are known, so these assignments are provisional.

| Member | Personas | Why |
|---|---|---|
| Staff engineer, first (name unknown) | Data-Driven Prober (top), Peer Evaluator | A staff engineer is a technical peer, and peers probe the numbers and the seam. |
| Staff engineer, second (name unknown) | Data-Driven Prober (top), Peer Evaluator | As above. |
| Product manager (name unknown) | Peer Evaluator (top), Case/Strategist | A peer prior, with a roadmap tilt. The tilt is my judgement, since the role's remit is the roadmap. |

Weights: Prober 3, Peer 3, Case 2 (8 questions).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Walk me through how the 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend the number in your words: the denominator, what the count was sensitive to, and the assumption you would defend least. If you do not know how it was counted, say so plainly. Name which part was yours. | Prober persona. The figure has a stated scope; the probe looks for the assumption behind it. |
| 2D2 | "Of the about 40 interviews last year, how many did you run, and how many did you only sit in on?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Give the split as you know it. If you do not have it, say so and say what you do know: the loop runs for backend roles. Do not estimate a figure you cannot back. | The count is a defend-the-number figure, and the split is where a prober goes next. |
| 2D3 | "What would you check before trusting a reliability number from a fleet of devices?" | JD | [generic] | Name the denominator first: which devices are counted, and whether offline devices are in the count. Then one assumption you would test. | A domain question for device-management. It is a pattern, not a claim about Larkfield's fleet. |
| 2E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (role description); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles, not a map you have not seen: how you would find the seam in the first month, and who you would ask. Answer slot: if you have disagreed with another team about priorities, say the time and the outcome; if not, say so plainly, then give the pressure you held through. | Peer persona: seam-splitting and disagreement style. It asks for principles, not claims. |
| 2E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Pick an instance where work crossed teams, and say who got the credit, in your own words. If none comes to mind, say so plainly and describe how you would handle it. | The peer persona's credit probe. An open prompt, with the theme from the persona stem. |
| 2E3 | "Tell me about a time reliability work competed with a roadmap date. Who decided the order?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Tell the story from the sentence: the quarter, the roadmap pressure, the 60%. Answer slot: if you decided the order, say so and how; if someone else did, say who and what you did. Do not add a stakeholder reaction the sentence does not contain. | An open prompt on the one story you stated. The probe is who decided. |
| 2F1 | "A customer is waiting on a fleet feature the device team says needs a quarter. What do you need to know before you pick?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify: which customer, what the wait costs, and what the device team's estimate rests on. Then the decision, and the people you would involve. Do not assert a past decision. | The roadmap partnership in live form. It asks for a method. |
| 2F2 | "How would you take a roadmap item through to a hardware-dependent release?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | If it comes up, say the negative plainly: "I haven't owned a hardware-adjacent roadmap." Then the plan: what you would want in writing from hardware and product before committing to a date. Do not describe a release you have not run. | The hardware requirement, asked as a plan. The negative you wrote is the only thing you can say about it from your past. |

Reverse questions (round 2):
- "Where do the staff engineers disagree most on cross-team design, and how does that get settled?" Why it lands: it maps the review culture before you are in it.
- "What does on-call look like on the device side, and who carries the pager?" Why it lands: it shows you treat operational load as a delivery issue.
- "What does the device team keep asking product for that product keeps declining?" Why it lands: it invites the honest version of the roadmap friction.
- "Which decision on the roadmap for next quarter do you think is wrong?" Why it lands: it invites candour, and the answer tests the panel's own judgement.
- Reciprocity (peer): "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the panel into a peer conversation and asks for a plan, not a pitch.

## Round 3: VP Engineering, 30 min

Relationship prior: skip-level, Case/Strategist and Pressure. The recruiter's words name the round "values and leadership philosophy", which makes it a values-style round, so Values/Behavioral leads.

Values cheat sheet: omitted. No published values are in hand, and the values search was refused. The round's values status comes from the recruiter's words.

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (weight 4) | Scenario prompts about how you lead and decide | High. The recruiter named the round. | Selection of a true story, STAR-shaped, with the honest branch where nothing carries. |
| Pressure (weight 2) | A skip-level composure challenge | Moderate. Skip-level prior, time-boxed. | Pause, restate, hold, concede specifically. |
| Case/Strategist (weight 2) | Device strategy questions, generic | Moderate, low depth. The skip-level prior is strategy-heavy, but no company strategy is in hand. | Clarify, then say what you would need to know. Do not guess at the strategy. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Open prompt: pick a time. The nearest thing your material carries is the reliability quarter: the quarter, the roadmap pressure, and the 60%. Answer slot: if the truth landed and the pressure did not break the relationship, say what happened, in your words. If no such time comes to mind, say so plainly, then say how you would handle one. Do not supply how leadership took it. | A persona stem. Your material shows the pressure but not how it landed, so the ending is an answer slot. |
| 3V2 | "What is your leadership philosophy, in one sentence, and where did it come from?" | VAL | [grounded] "values and leadership philosophy" (your message, the recruiter's words) | Give the principle as you hold it, in your own words. If you name where it came from, name an event you can state in one sentence. Do not claim a philosophy your material does not show you acting on. | The round's own name, from the recruiter. It is scored on whether the philosophy has a past behind it. |
| 3V3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt: pick a time a customer's need and an internal number pulled apart. Say the number and the customer. If none comes to mind, say so plainly, and say how you would weigh the two. | A persona stem. No raising source names a customer value, so the question is open and the honest branch is ready. |
| 3V4 | "Tell me about a hire you got wrong, and what you would do differently in the loop." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Pick a hire, in your words, and say what went wrong. If you cannot name one, say so plainly, then describe what you would look for in the loop. Do not name a change to the loop unless you made it. | Hiring is part of the role's scope (F2). The honest branch matters: a loop you run is a place where you can be wrong. |
| 3P1 | "Sixty seconds: why you over someone who has already managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "9 years engineering, 3 as a team lead of 6" (your message); [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message); [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pause, restate. Anchor in what you stated: nine years, a team of six, the hiring loop, the reliability quarter. Hold through two follow-ups. Concede the managers gap in your words: "I've never managed managers." Do not argue for experience you have not had. | The pressure version of the likeliest objection, from the skip-level. It is round 1's 1C2, sharpened. |
| 3P2 | "Which part of that quarter would you do differently?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold what the quarter did, in your words. Name one thing you would change, specifically. Answer slot: if nothing comes to mind, say so plainly, rather than inventing a flaw. | The question invites a reflex admission. Hold the result; concede only a specific thing you would really change. |
| 3C1 | "What would you want to know about the device-management business over the next three years before you committed two squads?" | CASE | [grounded] "lead two squads building device-management services" (role description) | Clarify, then say the three things you would need to know first. Name what you do not know about the company's direction; do not guess at its strategy. | Altitude test at skip-level. Generic, because no strategy source is in hand. |
| 3C2 | "A hardware release slips a quarter and two squads sit idle. What do you do this week?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify what idle means in work terms. Then decide what the squads do this week, who you tell, and what you ask hardware. Do not claim a similar week you have had. | A live problem on the roadmap partnership, at the VP's altitude. It asks for a method only. |

Reverse questions (round 3):
- "What do you want this person to have changed in the organisation after a year?" Why it lands: it links your values answer to an outcome they care about.
- "Where have you seen leadership here hold a line, and where has it bent?" Why it lands: it tests the culture before you commit to a philosophy.
- "How do you want managers and leads to bring you hard news?" Why it lands: it shows the leadership philosophy in practice, not in a slogan.
- "What would a bad first six months look like in this role, from where you sit?" Why it lands: it gives you their candid view of expectations.
- "What is the hardest thing about working for you that candidates are not told?" Why it lands: it invites the candour a VP round is partly testing for.

## Upgrade menu

- The names of the Director, the VP, the two staff engineers and the product manager → personas assigned per person, an interviewer read from public footprint only, and tailored reverse questions.
- Larkfield's published values page, pasted → the values cheat sheet for round 3, and 3V2 and 3V3 get mapped stories wherever your material carries one.
- The recruiter's process details (which sessions are which, and any pre-declared deliverable) → confirms the loop structure, and adds a deliverable section if one is announced.
- Research: the three searches were refused in this session. A deeper strategy pass (L2: up to 6 more searches and 2 more fetches, several minutes) would replace the generic CO questions 3C1 and 3C2 with company-specific ones. Say the word and I will run it.
- A growth example from your team → turns F4 from discovery into presentation, and rebuilds 1A3.
- How the 60% on-call figure was counted, in your own words → sharpens the defend-the-number answers in 1C1, 2D1 and 3P2.
- Whether you ran or only sat in on each of the 40 interviews → 2D2 gets a counted answer.
- Any hardware-facing work, even a release you coordinated with a hardware team → moves F6 toward transferability, but only if you describe it in your own words.
- The role's location and on-site pattern, if the posting states one → gate rows in the fit snapshot.
- A tuesday-dossier.md, if you keep one → carries the gaps this prep found into later sessions, and lets the next pack start from them.
