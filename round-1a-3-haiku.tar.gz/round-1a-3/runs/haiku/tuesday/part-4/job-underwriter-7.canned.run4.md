**Yes, it's worth applying for, on conditions.** You meet the essential criteria on what you've told me, and the gaps are the caseload, end-of-life, continence and records parts of the role. Nothing in the posting is a red flag.

**Decision snapshot: `conditional_go`**

- **Fit ledger.**
  - `hard_gate`: direct: R1, R2, R3 · unclear: R4 (£31,050–£37,800 against your pay floor)
  - `must_have`: direct: R5a, R6a, R7 · adjacent: R5b (leg-ulcer care) · unclear: R6b (continence), R8 (care planning), R10 (end-of-life visits), R11 (clear, timely written records)
  - `important`: adjacent: R9 (own caseload)
  - `preferred`: absent: R12 (Doppler assessment)

  R5b — leg-ulcer care is a bridge from wound care, its limit named; R9 — caseload is adjacent to your home visits, with no caseload held; R8, R10, R11 — not in your CV, so unestablished rather than missing.
- **Opportunity ledger.** The employer is established (RR4 positive), and the posting's liveness is unverified (RR1, unknown). Stated pay sits inside the interquartile band of one survey (RR4).
- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live, confirmed from the employer's own careers page or by the recruiter; (2) your NMC registration and driving licence check out on your own records; (3) you can speak to caseload and end-of-life work without overstating it (see the application plan).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing under an NHS contract, founded 2015, about 410 staff | `[grounded]` its About page |
| Mandate | Housebound adults at home; a small caseload of your own with a senior community nurse | `[grounded]` posting |
| Working pattern | Halifax-based team, pool cars provided, mileage paid | `[grounded]` posting |
| Market calibration | Band 5 community staff nurse median £34,300, interquartile £32,400–£36,600 (one survey, n=1,240) | `[generic]` Wardround 2026 pay guide |
| Unknowns | Caseload size, on-call expectations, whether Doppler training is provided | `[inferred]` from the posting's silence |
| Contradictions | None found | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated specifically with PIN; the register entry itself is unchecked | `[grounded]` your CV | Check your NMC entry yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as category B; not checked | `[grounded]` your CV | Check your licence record yourself |
| R3 | Location, Halifax | hard_gate | direct | medium | none | You live in Halifax | `[grounded]` your CV | none |
| R4 | Pay band £31,050–£37,800 against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` posting | Tell me your floor |
| R5a | Wound care, pressure and surgical wounds | must_have | direct | medium | none | Stated; no inspectable artifact | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care carries over; leg-ulcer work not stated | `[inferred]` from R5a | Ask about leg-ulcer dressing or compression work |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R6b | Continence care | must_have | unclear | none | discovery | Not in your CV | `[grounded]` CV silence | Ask (Q2) |
| R7 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R8 | Care planning | must_have | unclear | none | discovery | Not in your CV | `[grounded]` CV silence | Ask (Q2) |
| R9 | Own caseload with senior support | important | adjacent | medium | transferability | Home visits in discharge-to-assess are close, but you have never held a caseload | `[grounded]` your CV; `[inferred]` adjacency | See application plan |
| R10 | End-of-life visits | must_have | unclear | none | discovery | Not in your CV | `[grounded]` CV silence | Ask (Q2) |
| R11 | Clear, timely written records on an EPR | must_have | unclear | none | discovery | Not in your CV | `[grounded]` CV silence | Ask (Q2) |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done; the team lead's public talk on Doppler training for staff new to community work suggests training exists | `[grounded]` your CV; `[inferred]` training from the speaker page | Ask the recruiter whether training is provided |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Caseload (R9, important) | transferability | Home visits after discharge, no caseload | The most likely interview probe | Any list of patients you followed up, or a handover record | `[inferred]` |
| G2 | Leg ulcers, continence, end-of-life, records (R5b, R6b, R10, R11, must_have) | discovery | Not in the CV | These are must-haves; answers may move the status | Care plans, a training record, an EPR screenshot (no patient data) | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting liveness not verified | unknown | — | "current vacancies are listed on our careers page" | The posting may have closed or be filled | `[inferred]` from the careers page not opening | Is this post open now, and where is the live advert? | unresolved |
| RR2 | Caseload size unstated | unknown | — | "a small caseload of your own" | "Small" may mean a different number from your expectation | `[generic]` pattern for community posts | What is the typical caseload size for this post? | unresolved |
| RR3 | Doppler training not stated | risk_signal | low | "Doppler assessment" listed as desirable | The team may expect the skill at entry | `[inferred]` from the team lead's talk | Is Doppler training provided for this post? | unresolved |
| RR4 | Employer established, with a named lead | positive_signal | — | Team lead's public talk, plus the About page | The employer is real and the team is visible | `[grounded]` About page and speaker page | Who would I be interviewing with? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC registration and licence record yourself before applying | R1, R2 | `[grounded]` | pending your approval |
| A2 | Confirm the posting is live from the careers page or the recruiter | RR1 | `[grounded]` | pending your approval |
| A3 | Interview line on caseload: "I haven't held a caseload, but I've visited patients at home in their first week after discharge" | R9 | `[grounded]` your CV, no added claim | pending your approval |
| A4 | Ask Rhiannon Mabbott about caseload size, Doppler training and records | RR2, RR3 | `[grounded]` posting names the contact | pending your approval |

**Evidence status**

Verified: none yet. Everything above is your own statement, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned the About page (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page. Employer established; posting liveness unverified (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary", which returned the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Scope read and the Doppler inference (R12) |

**Upgrade menu**

- A live posting link, or the recruiter's confirmation, → RR1 closes.
- Your pay floor and any shift or mileage limits → R4 closes, and the hard-gate line clears.
- Any leg-ulcer, continence or end-of-life record, or a training certificate → R5b, R6b, R10 and R12 move.
- Your NMC and licence checks, confirmed → R1 and R2 move from `medium` to `high`.
- A deeper research pass on Calderbrook (funding, staff reports, past recruitment; up to 5 more searches and 2 more fetches): say the word and it runs.
- If you want it, I can emit `tuesday-dossier.md` with this assessment at the end of the engagement.

**Questions**

Q1 — What are your pay floor, shift pattern, and mileage limits? (R4)

Q2 — Have you ever done continence assessment, end-of-life visits, or care planning that you wrote and reviewed, and did you complete EPR records for them? (R6b, R8, R10, R11, all must-haves)

Q3 — Have you dressed or assessed venous leg ulcers, or worked with compression bandaging? (R5b)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.