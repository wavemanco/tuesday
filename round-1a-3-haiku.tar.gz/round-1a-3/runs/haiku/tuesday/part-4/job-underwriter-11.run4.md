**Duinvaart Cold Chain (Operations Analyst, Rotterdam): worth applying to, on conditions. Status: `conditional_go`.**

**Kroonhaven Foods (Supply Planner, Utrecht): not worth your time now. Status: `no_go`.**

Web search was refused in this session, so I could not check either employer exists. Until you find both postings on the companies' own careers pages, treat them as unverified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both employer searches were refused because web search permission was not granted. Would have settled RR1 and RR2: does each employer exist as described, and is each posting live. |
| 2. Role-family sweep | unavailable | Not sent after the refusals. Would have set the salary bands for RR3 and RR4. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Duinvaart Cold Chain: Operations Analyst

**Fit ledger.**
- `hard_gate` — unclear: D1 (right to work in the Netherlands), D2 (three days a week on-site in Rotterdam)
- `must_have` — direct: D3 (2+ years in logistics or operations analysis), D4 (strong SQL), D5 (Power BI or Tableau), D6 (weekly dashboards), D7 (on-time delivery tracking); adjacent: D8 (work with depot managers on route changes); unclear: D9 (temperature compliance across a refrigerated fleet)
- `preferred` — adjacent: D10 (Dutch, conversational)

Your parcel-carrier work covers D3 to D7 directly. D8 is adjacent: you ran the route-performance review, but the posting asks for route changes. D9 is the one must-have your background does not address.

- **Hard gates:** none failed; unconfirmed: D1 (right to work in the Netherlands), D2 (three days a week on-site in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on the employer's own careers page (RR1); (2) D1 is confirmed; (3) you accept the Rotterdam days; (4) D9 is answered (Q3).
- **What would change this:** a no on D1 or a refusal of the commute makes it `no_go`. A yes on refrigerated or temperature-controlled work lifts D9 to direct.

## Kroonhaven Foods: Supply Planner

**Fit ledger.**
- `hard_gate` — unclear: K1 (right to work in the Netherlands), K2 (on-site in Utrecht)
- `must_have` — adjacent: K3 (3+ years of supply or demand planning in FMCG), K7 (fluent Dutch; yours is conversational); absent: K4 (owning a 13-week supply plan and running S&OP), K5 (SAP IBP or a similar planning system); unclear: K6 (advanced Excel)

K4 and K5 are the two must-haves with no evidence in your background. K3 is adjacent only: your forecasting-adjacent work is route performance, not production capacity or supply planning.

- **Hard gates:** none failed; unconfirmed: K1 (right to work in the Netherlands), K2 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Why `no_go`:** two must-haves are absent (K4, K5), and the planning-years requirement (K3) cannot be closed quickly. That is capability gaps across several must-haves with no realistic short-term closure.
- **What would change this:** about a year of planning-facing work on your record would move K4 to adjacent. The realistic route is a demand or supply analyst role at an FMCG or logistics firm, then this role later.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Right to work in NL | hard_gate | unclear | none | hard_gate | Not in what you've given; the posting is silent | `[inferred]` gate from the input contract | Q1 |
| D2 | On-site Rotterdam 3 days/week | hard_gate | unclear | none | hard_gate | Posting is explicit; your commute tolerance isn't stated | `[grounded]` JD | Q2 |
| D3 | 2+ years logistics/ops analysis | must_have | direct | medium | none | Four years at a parcel carrier, self-reported | `[grounded]` your background | none |
| D4 | Strong SQL | must_have | direct | medium | none | Used daily, stated by you | `[grounded]` your background | none |
| D5 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily, stated by you | `[grounded]` your background | none |
| D6 | Weekly dashboards | must_have | direct | medium | none | You built the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| D7 | On-time delivery tracking | must_have | direct | medium | none | Same dashboard as D6 | `[grounded]` your background | none |
| D8 | Work with depot managers on route changes | must_have | adjacent | medium | transferability | You ran the weekly route-performance review; route changes themselves aren't stated. Limit: review, not route decisions | `[inferred]` bridge from the review you described | Name any route decisions you influenced, if any |
| D9 | Temperature compliance, refrigerated fleet | must_have | unclear | none | discovery | Nothing about temperature data or refrigerated work; may be absence or unmentioned | `[grounded]` absence from your background | Q3 |
| D10 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, stated by you | `[grounded]` your background | State your level plainly on the CV |
| K1 | Right to work in NL | hard_gate | unclear | none | hard_gate | Same as D1 | `[inferred]` | Q1 |
| K2 | On-site Utrecht | hard_gate | unclear | none | hard_gate | Posting is explicit; commute not stated | `[grounded]` JD | Q2 |
| K3 | 3+ years supply/demand planning, FMCG | must_have | adjacent | medium | transferability | Route forecasting and performance work is the nearest. Limit: no planning decisions, no FMCG | `[inferred]` bridge | none; limit stated |
| K4 | 13-week supply plan, weekly S&OP | must_have | absent | none | capability | Nothing stated | `[grounded]` absence | Planning-facing role first |
| K5 | SAP IBP or similar | must_have | absent | none | capability | Nothing stated | `[grounded]` absence | Hands-on training; the planning role comes first |
| K6 | Advanced Excel | must_have | unclear | none | discovery | Not mentioned | `[grounded]` absence | Confirm your Excel level |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, stated by you; the posting says fluent. Limit: conversational | `[grounded]` your background | none; limit stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (Duinvaart) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Employer not established (Kroonhaven) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as RR1 | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Salary not stated (Duinvaart) | unknown | — | (posting silent on pay) | The pay may sit below the band, or the employer may not publish salaries | `[inferred]` from the silence | What is the budgeted salary for this role? | unresolved |
| RR4 | Salary not stated (Kroonhaven) | unknown | — | (posting silent on pay) | Same as RR3 | `[inferred]` from the silence | What is the budgeted salary for this role? | unresolved |
| RR5 | Clear, measurable scope (Duinvaart) | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Responsibilities are specific and measurable | `[grounded]` the JD | What does a strong first 90 days look like here? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the Duinvaart posting on their own careers site before any effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead your CV with the on-time delivery dashboard depot managers use, in your own words | D6, D7 | `[grounded]` your background | pending your approval |
| A3 | Do not claim cold-chain experience until Q3 is answered | D9 | `[grounded]` D9 | pending your approval |
| A4 | Skip Kroonhaven; target demand or supply analyst roles in FMCG or logistics instead | K4, K5 | `[inferred]` from the map | pending your approval |

The CV rewrite in A2 is a resume-tailor job, if you want it done properly.

**Evidence status:** Verified: none yet. Your background is CV-level evidence, which stays at `medium`.

**Dossier offer:** I can save this as a `tuesday-dossier.md` you can keep and bring into mock-interview later.

**Upgrade menu:**
- Your answers to Q1 to Q3 move D1, D2, D9, K1 and K2 off `unclear`.
- A live posting link from each employer's careers page closes RR1 and RR2, or keeps them open.
- A budgeted salary or pay band from the recruiter closes RR3 and RR4.
- A sanitized screenshot of the dashboard depot managers use raises D6 and D7 from `medium` to `high`.
- A deeper research pass on both employers (up to 5 more searches and 2 more fetches) runs once web search is allowed.

**Questions:**
- **Q1 (D1, K1):** Do you have the right to work in the Netherlands without sponsorship?
- **Q2 (D2, K2):** Could you be on-site in Rotterdam three days a week, or in Utrecht, and what commute would you accept?
- **Q3 (D9):** Did your parcel carrier's work involve temperature-controlled or time-sensitive cargo, or any temperature compliance reporting? Experience that may count: chilled or refrigerated parcel lines, cool-storage depot KPIs, temperature excursion reports.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.