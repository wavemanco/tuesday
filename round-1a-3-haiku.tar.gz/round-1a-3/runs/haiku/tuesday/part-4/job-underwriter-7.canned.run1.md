## Decision snapshot

**Yes, worth applying, once three checks clear. Status: `conditional_go`.** Your registration and licence meet the gates as you stated them, and the employer is real. The role is mostly wound, catheter, insulin and home-visit work you already do. What you lack is a caseload of your own and the leg-ulcer and Doppler specifics.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4a, R5a, R6 · adjacent: R4b, R7, R9 · unclear: R5b, R8, R10
- `preferred`: absent: R11

R1 (`medium`) — stated, not yet checked on the NMC register; R9 — home visits carry over, a caseload does not yet.

**Opportunity ledger.** The employer checks out: Calderbrook is a community interest company with an NHS contract and 410 staff, and the contact is the Halifax district team lead (RR6, RR7). Open questions remain on caseload support, pay scale and whether the post is live (RR1–RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your NMC register entry shows active Adult registration, checked by you; (2) the post is confirmed on Calderbrook's own careers page or by Rhiannon Mabbott (RR1); (3) you can answer R9 and R10 with a specific example in the interview.

I haven't used your National Insurance number; it isn't needed for this assessment.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing under an NHS contract across Calderdale; 410 staff; four locality hubs | `[grounded]` about page |
| Mandate | Housebound adults at home: wounds and leg ulcers, catheter and continence, end-of-life visits, insulin, care planning, on the EPR; a small personal caseload with senior nurse support | `[grounded]` posting |
| Working pattern | Home visits with pool cars; mileage paid | `[grounded]` posting |
| Market calibration | Band 5 community staff nurse, England, 2026 self-report (n=1,240): median £34,300, IQR £32,400–£36,600; 61% paid mileage | `[generic]` Wardround 2026 guide |
| Pay as posted | £31,050–£37,800, inside the surveyed IQR | `[grounded]` posting, compared to `[generic]` band |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team; her public talks cover leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` speaker page |
| Unknowns | Caseload size, supervision, out-of-hours cover, pay scale (Agenda for Change or CIC scale), whether the post is live | — |
| Contradictions | None found between the posting and the employer's about page | `[grounded]` |

## Evidence map

Confidence is at most `medium` on first pass: your CV is self-report, and nothing is probed yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | PIN and active status stated; register not checked | `[grounded]` your CV | You check the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; not checked | `[grounded]` your CV | Confirm the licence is current |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse, acute medical ward | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | adjacent | medium | transferability | General wound care is stated; leg ulcers are not. Limit: no leg-ulcer caseload | `[inferred]` from R4a | Bridge case in interview (see G1) |
| R5a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | low | discovery | Not stated | `[grounded]` CV silence | Question Q3 |
| R6 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R7 | Care planning | must_have | adjacent | medium | transferability | Discharge-to-assess planning is short-horizon, not ongoing care plans | `[inferred]` from the seconded role | Bridge case (see G2) |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not stated; acute-ward and home-visit work may include it | `[grounded]` CV silence | Question Q2 |
| R9 | Own caseload, with senior support | must_have | adjacent | medium | transferability | Home visits in week one after discharge are stated; a caseload is not | `[grounded]` CV | Question Q1 |
| R10 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | No record-keeping or EPR use stated | `[grounded]` CV silence | Question Q3 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Stated as never done | `[grounded]` CV | Closure path (see G3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4b) | transferability | General wound care is solid; leg-ulcer specifics are absent | Must-have; the bridge is the objection most likely raised | Any leg-ulcer dressings or compression you assisted with on the ward or in discharge visits | A wound-care example that names the wound type | `[inferred]` bridge from R4a; `[generic]` that leg-ulcer work is a common interview probe |
| G2 | Care planning (R7) | transferability | Discharge planning is stated; ongoing care plans are not | Must-have; needed for a caseload | Discharge plans you wrote; reviews you carried out | A sanitised discharge plan or care-plan template | `[inferred]` from the seconded role |
| G3 | Doppler (R11) | capability | Never done | Preferred, so minor; it may be trainable | Vascular assessment training; ankle-brachial work on the ward | Course certificate, if any | `[generic]` many community teams train staff into it; not confirmed for Calderbrook |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The posting may have closed or been filled | `[inferred]` from the about page; careers page not found | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Caseload support unstated | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | Caseload size and senior cover are unknown | `[grounded]` posting | How many patients would I hold, and how is senior support arranged? | unresolved |
| RR3 | Out-of-hours cover | unknown | — | Not stated | Lone home visits may include out-of-hours cover | `[generic]` pattern for community teams | What out-of-hours cover is expected, and how are lone visits managed? | unresolved |
| RR4 | Pay scale for a CIC | unknown | — | "£31,050–£37,800 a year plus mileage" | The band may be Agenda for Change or a CIC scale | `[inferred]` from the CIC status | Is this post on the Agenda for Change Band 5 scale, and how is mileage paid? | unresolved |
| RR5 | Doppler training | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training may be provided after appointment | `[generic]` pattern for community teams | Is Doppler training provided for staff who don't yet hold it? | unresolved |
| RR6 | Employer established | positive_signal | — | "running adult community nursing, therapy and rehabilitation services across Calderdale under an NHS contract" | Real, established employer | `[grounded]` about page | none | noted |
| RR7 | Contact is the team lead | positive_signal | — | "leads the Halifax district nursing team" | The informal chat is with the right person | `[grounded]` speaker page | none | noted |

Nothing in the register is `severity: high`, and no request for money, bank details or a deposit appears.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your own NMC register entry and licence | Confirms R1 and R2 before you apply | `[grounded]` gates R1, R2 | pending your approval |
| A2 | Confirm the post is live on the careers page, or ask Rhiannon Mabbott directly | Clears RR1 before you invest effort | `[grounded]` about page | pending your approval |
| A3 | Take up the informal chat, asking RR2, RR4 and RR5 | The posting invites it; the team lead is the right person | `[grounded]` posting and speaker page | pending your approval |
| E1 | Lead your CV summary with the home visits, in your own words: "Visited patients at home in their first week after discharge (18 months, discharge-to-assess team)" | Puts R9 first without adding anything | `[grounded]` your CV | pending your approval |
| E2 | Do not describe the discharge visits as district nursing | Would claim a caseload and a community role you have not held | `[grounded]` R9 | pending your approval |

## Evidence status

Verified: none yet. Everything in the map is your CV, which is self-report until you confirm it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned the about page (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page there. Moved RR6 (entity confirmed); RR1 stays open |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 salary range 2026 district nursing", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration (`[generic]`) and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved RR7 and the Doppler question (RR5) |

## Upgrade menu

- An NMC register screenshot or a confirmed licence check → R1 and R2 move from `medium` toward `high`.
- A leg-ulcer example, even a small one → R4b moves from `adjacent` toward `direct`.
- A discharge plan, anonymised → R7 moves to a stronger bridge.
- A confirmed caseload or record-keeping example → R9 and R10 move.
- Careers page or Rhiannon Mabbott's reply → RR1 closes.
- A deeper pass on Calderbrook (inspection reports, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this assessment to `tuesday-dossier.md` so later sessions can pick it up.

1. **G1 / R9** — Have you ever followed up patients after a visit with a list of your own, even within discharge-to-assess? How did you track them?
2. **R8** — Have you been part of end-of-life or death-at-home visits? What did you do in them?
3. **R10** — Which electronic record system have you used, and what did your visit notes look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.