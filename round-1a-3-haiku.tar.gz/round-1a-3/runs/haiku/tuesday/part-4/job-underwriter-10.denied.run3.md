**Worth applying, with conditions. Status: `conditional_go`.** On the posting's own terms, your fit is strong: four years of product design, daily Figma, your own user research, and a squad with four engineers match the requirements. I can't establish that Fernquay is a real company, though. The web search was refused in this session, so nothing about the company itself was checked. Nothing in the posting or the WhatsApp message asks for money, bank details or ID. Scheduling a video call over WhatsApp is routine, so that channel is not a warning sign by itself.

**Fit ledger.**
- `hard_gate`: direct: R8 · unclear: R9 (salary €52,000–€60,000 against your floor)
- `must_have`: direct: R1, R2, R3, R6 · adjacent: R5 (own the booking flow end to end)
- `important`: adjacent: R4 (research calls with school owners) · unclear: R7 (first designer, setting practice alone)

R5: your checkout work is one stage of a booking flow, not the whole flow. R4: your research was with customers, not with school operators. R7: you have never been the only designer, so there is no evidence either way.

**Opportunity ledger.** The concrete scope, stated pay, hybrid pattern and named co-founder are real positives (RR4). The employer is not established from attributable sources in this run (RR1), which caps the decision at `conditional_go`. The equity has no stated vesting or strike terms (RR2), and the team's budget for a first designer is not stated (RR3).

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: Fernquay confirmed as a live employer through its own site or careers page and its company registration, with the invite sent from the company's domain; (2) R9: your floor checked against €52,000, and the equity terms (RR2) understood; (3) R5: the checkout case study shows what you owned, in your own words.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Existence | Not established in this run; search refused | `[grounded]` tier line |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run: the role-family search was refused, so the salary cannot be checked against the market here | — |
| Unknowns | Employer existence, equity terms, budget and runway, who the CTO is | — |
| Contradictions | None visible: the posting names Ronan Kehoe as co-founder, and the WhatsApp message is from Ronan | `[grounded]` both sources |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a travel-booking company; self-report, no artifact read | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, stated; no file read | `[grounded]` your background | Share a case-study link |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated | `[grounded]` your background | none |
| R4 | Research calls with school owners | important | adjacent | medium | transferability | Same method, different users: travel customers, not operators of schools | `[inferred]` from R3 | G3 |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is one stage; whole-flow ownership not stated | `[inferred]` from your checkout work | G1 |
| R6 | Ships alongside engineers | must_have | direct | medium | none | Four-engineer squad, stated | `[grounded]` your background | none |
| R7 | Sets practice alone (implied by "first designer") | important | unclear | low | discovery | Never the only designer; no evidence on setting practice solo | `[inferred]` from the posting | G2 |
| R8 | Two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; stated, not a constraint you gave | `[grounded]` your background | none |
| R9 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | Your floor is not given, so the range cannot be checked against it | `[grounded]` posting | Q1 |

**Gap recovery queue.**
- **G1** (R5, transferability): Only checkout is evidenced. Closing it would show whether the booking flow was yours end to end. Useful evidence: the case study, or a brief from the project.
- **G2** (R7, discovery): No evidence of setting direction alone. Closing it decides whether the first-designer role is a stretch or a fit. Useful evidence: any project where you chose the direction without a senior check.
- **G3** (R4, transferability): Research with operators, not customers. Useful evidence: any interviews with small-business owners.

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software" | Not checked, rather than established as absent. Possible reasons, none ranked: too new or small for a footprint; a stale or aggregated posting; or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on Fernquay's own careers page, and what is the registered company name? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage has no stated vesting, strike price or share count, so its value is unknown | `[inferred]` from the posting's wording | What is the vesting schedule and strike price behind 0.5–1%? | unresolved |
| RR3 | Support for a sole designer unstated | unknown | — | "You would be our first designer" | Ownership may be real, but the budget for research and design review is not stated | `[inferred]` from the posting's silence on budget | What budget and tools exist for research, and who reviews design decisions? | unresolved |
| RR4 | Concrete scope and stated terms | positive_signal | — | "own the booking flow end to end" | The posting names the work, co-founder, pattern and pay, which is more specific than most | `[grounded]` posting | Who would I work with day to day, and how is the first 90 days measured? | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Fernquay on its own site, its careers page and its company registration, and confirm the invite comes from the company's domain | RR1; a check, not a condition | `[generic]` pattern for small employers | advice |
| A2 | Accept the call through the calendar invite | Scheduling is routine; the call is an interview | `[grounded]` the message | advice |
| A3 | Describe the checkout work as checkout: the redesign, the usability sessions, the four engineers | R5, R3 | `[grounded]` your background; no new claims | pending your approval |
| A4 | Prepare an honest answer on working without a design peer: what you would start with, and what you have not done | R7 | `[grounded]` your background | pending your approval |
| A5 | If you go ahead, mock-interview can build a prep pack for the 45-minute call | The call is an interview | sibling module | advice |

**Evidence status.** Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

The search permission was declined by the host, so I did not retry.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches on "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Galway Ronan Kehoe" were refused. Would have settled RR1 and the employer check |
| 2. Role-family sweep | unavailable | The salary search was refused. Would have set the market calibration for the title and pay |
| 3. Hiring manager's public footprint | unavailable | The Ronan Kehoe query was refused. Would have moved the scope read and the positioning |

I'd offer a dossier with `tuesday-dossier.md` so you can keep this and update it as checks come back.

**Upgrade menu.**
- Allow web search, or paste the company's careers page text and the live posting. This would settle RR1, and could move the status to `go` or `no_go`.
- Share the checkout case study as a link or file. This would move R2 and R5 toward `high`.
- Tell me your salary floor and any non-negotiables. This would close R9.
- Send the equity terms in writing. This would close RR2.

**Questions.**
- **Q1 (R9):** Is €52,000 at or above the lowest salary you would accept, and should the equity count toward your decision?
- **Q2 (G2, R7):** Have you ever set design direction alone, with no senior designer to check it? What happened?
- **Q3 (G1, R5):** Did you own the whole checkout, or part of it, and what came before and after it in the booking flow?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.