**Don't go ahead, and don't send anything.** Your background fits this kind of role on paper, but the process itself asks for money and bank, tax and ID details before any offer. Those are confirmed severe red flags, and they cap the decision whatever your fit.

**Decision snapshot: `no_go`.** Your fit is reasonable, but this role is not safe to pursue on these terms. Three of the four requests in the messages would each be enough alone: paying for equipment, depositing a cheque and sending money onward, and giving bank and PPS details and a passport photo before any offer.

- **Fit ledger (candidate fit only, not the opportunity):**
  - `hard_gate`: unclear: R1 (pay of at least €30,000 a year)
  - `must_have`: direct: R2 (attention to detail, spreadsheets), R3 (high-volume ticket work); both `medium`, from your own account
  - `important`: unclear: R4 (good written English), direct: none; nothing in your material settles it either way
  - `preferred`: direct: R5 (quiet place to work), `medium`, self-reported
- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year). The posting says up to €26 an hour for 15–30 hours a week, plus commission it doesn't quantify, so the floor can't be checked from what's given.
- **Severe red flags:** RR1, RR2, RR3, RR4 (all `severity: high`).
- **Opportunity ledger:** RR1–RR4 are confirmed severe red flags, and RR5 (employer not established) caps any decision at `conditional_go`. A confirmed severe red flag forces `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Pay | Up to €26/hour × 15–30 hours ≈ €20k–€40k a year before unstated commission | `[grounded]` posting, `[inferred]` arithmetic |
| Pay band | Salaried order-processing and customer-ops roles in Ireland: median €31,200, IQR €28,400–€34,100 (n=1,140, salaried only) | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, pennoral.example |
| Employer | Velloway Logistics: no results from two searches on the name | `[grounded]` search, not established |
| Process | Telegram only, no calls or video | `[grounded]` posting |
| Contradictions | The posting says no calls or video, and the "chat interview" is the only interview | `[grounded]` posting and messages |

**Evidence map** (fit is the job's fit against your evidence; confidence grades your own statements)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Your own stated floor, `high`. The posting's pay can reach it only at upper hours plus commission it doesn't state | `[grounded]` your statement, posting | Ask for hours and commission in writing from the employer |
| R2 | Attention to detail and spreadsheets | must_have | direct | medium | none | Weekly Excel tracker for your team, self-reported | `[grounded]` your account | none |
| R3 | High-volume order or ticket work | must_have | direct | medium | none | About 60 Zendesk tickets a day for three years, self-reported | `[grounded]` your account | none |
| R4 | Good written English | important | unclear | low | discovery | Nothing in your material tests this | `[inferred]` from the posting | none |
| R5 | Quiet place to work | preferred | direct | medium | none | Your own statement | `[grounded]` your account | none |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment before any start | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | The sender is asking you to pay before any work, with refund promised later | `[grounded]` the messages | Does the employer require new hires to buy their own laptop and headset, and where is that in writing? | confirmed |
| RR2 | Cheque deposit with money sent onward | red_flag | high | "We are posting you a cheque for €2,850 ... transfer the rest to our equipment partner" | The cheque may not clear, and the money you send out would be yours | `[grounded]` the messages | Which bank issues this cheque, and will the employer confirm it in writing? | confirmed |
| RR3 | Bank, PPS and passport details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | Personal details requested before a credible offer | `[grounded]` the messages | Does the employer require bank, tax or ID details before a written offer? | confirmed |
| RR4 | Hiring run only by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interviews and the offer happen only in chat | `[grounded]` posting | Can the employer show a live role on its own careers site and a named interviewer? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site? | unresolved |

The requests in RR1–RR3 are demands for money or bank and ID details. Quoting them: the sender asks you to pay, to deposit and forward money, and to send bank and ID details before any offer. This request is very likely a scam. Don't pay the €349, don't deposit the cheque, and don't send your IBAN, PPS number or passport photo. I can't establish the firm from here, and the messages may not come from who they name. The employer's own careers site is the place to check the role, using contact details you find there rather than the chat or the email address the sender gave.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send nothing: no IBAN, PPS, passport photo, payment or cheque | RR1–RR3 | `[grounded]` the messages | recommended |
| P2 | If you want to keep the lead open, ask for the live posting on Velloway's own careers site and find contact details there yourself | RR4, RR5 | `[generic]` standard check | recommended |
| P3 | If you've already sent anything or moved money, contact your bank now and report the messages to the Gardaí | RR1–RR3 | `[generic]` standard reporting route | recommended |

**Evidence status**
Verified: none yet. Your R2, R3 and R5 claims are self-reported and `medium` at most.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator"; both returned no results, so the employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example): the pay band in role reality, `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so there was no query to form |

**Dossier offer:** If you want, I can write a `tuesday-dossier.md` recording this assessment for later use.

**Upgrade menu**
- A live posting on Velloway's own careers site, plus a contact you found there → RR5 closes and the decision can be reassessed.
- A written contract and commission rate from the employer, using its own domain → R1 and RR1 can be reassessed, though RR1–RR3 would still need to be withdrawn.
- Weekly hours and commission stated in writing → R1 closes.

**Questions**
1. Has anyone named in these messages sent you a written contract or offer from the employer's own domain?
2. Did the posting or any message state a commission rate or weekly hours?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.