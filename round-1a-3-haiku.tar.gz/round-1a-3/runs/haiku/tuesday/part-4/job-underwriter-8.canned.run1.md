**No. Don't go ahead, and don't send anything yet.** Do not send your IBAN, PPS number or passport photo, pay the €349, or lodge the cheque.

- **Decision: `no_go`.** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`) and RR4 (`severity: high`) are confirmed severe red flags. Your pay floor is also unconfirmed (R1), and the employer could not be found (RR5).
- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year pay floor, against the posting's "up to €26 an hour"); other candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. Search for the name returned no results | `[grounded]` search "Velloway Logistics" |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Pay arithmetic | €30,000 a year is about €577 a week. At €26/hour that means about 22 hours every week, with no floor or commission stated | `[inferred]` from the posting's figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, interquartile range €28,400–€34,100. The guide excludes commission-only work | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example/2026-ireland-customer-operations-pay-guide) |
| Hiring process | Telegram only, no calls or video | `[grounded]` posting and messages |
| Unknowns | Guaranteed hourly minimum, commission rule, contract type, employer identity | — |

**Evidence map** (your intake is self-report, so confidence stops at `medium`)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning |
|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Your floor is confirmed. The posting says "up to", with no floor and no commission rule, so it is not established |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | Your weekly Excel tracker. Self-report, no artifact yet |
| R3 | Strong attention to detail | important | direct | medium | none | About 60 Zendesk tickets a day for three years. Self-report |
| R4 | Good written English | must_have | direct | medium | none | Three years of written ticket work. Self-report |
| R5 | A quiet place to work | important | unclear | low | discovery | Not stated. This is your own check, not a question for them |

**Opportunity ledger.** Four confirmed severe red flags (RR1–RR4), an unresolved employer check (RR5) and an unclear pay basis (RR6).

**Risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question (asked of the employer, through contact found on their own site) | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment before any job | red_flag | `high` | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The request asks for money before any pay is earned. A refund promised by the same party is not secured | `[inferred]` from the message's own terms | Does Velloway require candidates to pay for equipment, and who is its named equipment supplier? | confirmed |
| RR2 | Cheque deposit, then forwarding part of it | red_flag | `high` | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner." | You would move money out of your account before a cheque clears. Cheques deposited and partly forwarded are often returned unpaid later, leaving the forwarded money lost | `[generic]` pattern for cheques of this kind | Does Velloway issue cheques to new hires, and do you pay staff by cheque to be forwarded to third parties? | confirmed |
| RR3 | Bank, PPS and passport before an offer | red_flag | `high` | "send your IBAN, your PPS number and a clear photo of your passport" | Identity and bank details are requested before any written offer | `[grounded]` the message's own terms | Do you collect bank and identity details before a written offer? | confirmed |
| RR4 | Hiring wholly by chat | red_flag | `high` | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No interview can be placed outside the chat, so the offer also comes only through it | `[grounded]` posting | Can you confirm the role on your careers page and arrange a video interview with a named manager? | confirmed |
| RR5 | Employer not established | risk_signal | `medium` | "Velloway Logistics" | The firm may be too new or small to appear online, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR6 | Pay basis unstated | risk_signal | `low` | "Earn up to €26 an hour plus commission" | The base may be well below the floor, with commission doing the work | `[inferred]` from the posting against your floor | What is the guaranteed minimum hourly rate, and how is commission calculated? | unresolved |

Hedged verdicts, as the request allows: **This request is very likely a scam.** Don't pay the €349, don't deposit the cheque, and don't send any of its funds on. **This job is very likely a scam.** I can't establish the firm from here, so I'm not making a claim about the company itself. The messages may not come from who they name.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance |
|---|---|---|---|
| P1 | Send no IBAN, PPS number or passport photo to this chat | RR3 | `[grounded]` |
| P2 | Pay nothing, and deposit no cheque | RR1, RR2 | `[grounded]` |
| P3 | If you have already shared any of those details, contact your bank now and report the chat on Telegram | Limits exposure | `[generic]` standard response |
| P4 | If you still want a role like this, apply through an employer's own careers page and expect a video interview | RR4, RR5 | `[generic]` role-family pattern |

**Evidence status.** Verified: R1 (your own pay floor). R2–R5 are your own descriptions, not yet checked against an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results. RR5 stays unresolved |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland". Moved market calibration to the Pennoral guide above |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can write this assessment to a `tuesday-dossier.md` file so you can keep it.

**Upgrade menu**
- A link to a live posting on Velloway's own careers page would move RR5. None exists yet.
- A written guaranteed hourly minimum and commission rule would resolve R1 and RR6.
- A deeper research pass on Velloway Logistics (up to 5 more searches and 2 more fetches) is available if you want it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.