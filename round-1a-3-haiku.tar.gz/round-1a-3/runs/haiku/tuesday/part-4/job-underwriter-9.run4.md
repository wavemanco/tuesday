**Yes, asking for bank details, PPS and a passport scan after a written offer is normal Irish onboarding.** The offer itself shows no severe red flags. Status: `conditional_go`, meaning accept once two things are confirmed (see below).

- **Hard gates:** none failed; unconfirmed: R1 (Limerick office, two days a week), R2 (right to work in Ireland); candidate constraints not given — checks against them unknown
- **Fit ledger:**
  - `hard_gate` — unclear: R1 (Limerick office, two days a week), R2 (right to work in Ireland)
  - `must_have` — direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI, USC)
  - `important` — direct: R8, R9 · adjacent: R7 (monthly payroll for 240 staff) · unclear: R10 (pension changes)
  
  R7 — adjacent, with its limit named (monthly cycle, 240 headcount); R10 — unclear, never done; R4 — unclear, jurisdiction not stated.
- **Opportunity ledger:** the pay sits mid-band and matches the ad (RR2), and the two in-person interviews at the office are a positive signal (RR3). The employer has not been checked from here (RR1).
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1, the employer and posting confirmed on their own site and registration; (2) R1, you can attend Limerick two days a week. A failed R1 would make this `no_go`, with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer; not checked from here |
| Mandate | Monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Pay | Ad: €38,000–€42,000. Offer: €40,000 permanent | `[grounded]` ad and offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` ad and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | A single-person payroll role covering the full monthly cycle for a 240-staff employer | `[inferred]` from the duty list |
| Market calibration | No band from here; the salary search was refused. The posted band is the only reference in hand | — |
| Unknowns | Pension scheme details, whether payroll is outsourced in part, and where the €40,000 sits against the pension and allowances | — |
| Contradictions | None between the ad and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Limerick office, two days a week | hard_gate | unclear | none | hard_gate | Your home location isn't in the material. The in-person interviews suggest you can get there, but that isn't a stated constraint | `[grounded]` ad and offer; `[inferred]` from the interviews | Question 3 |
| R2 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | The offer makes it a term and asks for a passport scan. Nothing you've shared states your status | `[grounded]` offer | Have your passport ready; the check is routine |
| R3 | Two years' payroll | must_have | direct | medium | none | Three years' fortnightly payroll for 90 staff, stated by you; no artifact yet | `[grounded]` your message | none |
| R4 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Your message doesn't say whether the hotel group's payroll ran under Irish rules | `[grounded]` absence in your message | Question 2 |
| R5 | Strong Excel | must_have | direct | medium | none | Pivot tables and XLOOKUP, used daily | `[grounded]` your message | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; certificate not inspected | `[grounded]` your message | Optional: a copy on file |
| R7 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Fortnightly payroll for 90 staff is the nearest work; the monthly cycle and the larger headcount are the limit | `[inferred]` from the cadence and headcount difference | Make the transfer case with its limit stated |
| R8 | Starters and leavers | important | direct | medium | none | Named in your message | `[grounded]` your message | none |
| R9 | Payroll-to-ledger reconciliation | important | direct | medium | none | Done monthly | `[grounded]` your message | none |
| R10 | Pension changes | important | unclear | low | discovery | You've never processed them; your manager did. Whether you observed or supported that work isn't in the material | `[grounded]` your message | Upgrade menu: any pension-change work you saw or supported |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Pension changes (R10) | discovery | No hands-on pension work; manager handled it | An example of observing or supporting pension admin, even partly | `[grounded]` your message |
| G2 | Monthly 240-staff cycle (R7) | transferability | Fortnightly 90-staff payroll; no monthly cycle | A description of your payroll calendar and checks, stated as the limit | `[inferred]` from the cadence difference |
| G3 | Irish PAYE, PRSI, USC (R4) | discovery | Jurisdiction not stated for the hotel group | Confirmation of which system the payroll ran under | `[grounded]` absence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked from here | unknown | — | "a housing association in Limerick" | Nothing shows the employer isn't real. The check didn't run because search was refused | `[inferred]` from the evidence status | Can you point me to this role on your own careers page, and to your registration as an approved housing body? | unresolved |
| RR2 | Pay sits mid-band and matches the ad | positive_signal | — | "€38,000–€42,000"; "€40,000 a year" | The offer is consistent with the posting | `[grounded]` ad and offer | Is €40,000 the full package, with pension and allowances stated separately? | noted |
| RR3 | Two in-person interviews at the office | positive_signal | — | your message | An in-person process at the stated premises | `[grounded]` your message | Who will I work with day to day in the payroll team? | noted |

The posting's requests for bank details, PPS and a passport scan don't appear here. They come after a written offer that names the role and pay, so they're routine.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the employer yourself: find the role on their own careers page, and check their registration as an approved housing body | RR1 | `[grounded]` RR1 | your call |
| A2 | Accept in writing if the checks pass. Put no bank, PPS or passport detail in the reply | The offer asks for these only through the portal | `[grounded]` offer | pending your approval |
| A3 | When the portal link arrives, open the portal from the address on their own website, not the email link, and enter details only there | Routine onboarding, but the address should be one you found yourself | `[generic]` onboarding practice | pending your approval |
| A4 | Ask HR for the pension scheme details before you accept | R10 and RR2 | `[grounded]` RR2 | pending your approval |

Your rule not to hand these over holds for unsolicited or pre-offer requests. After a written offer, a payroll system is the normal place for them. The five-working-day acceptance window is enough time to run A1 and A4.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because web search permission wasn't granted in this session. Would have moved RR1: whether the employer exists as described and whether the post is live |
| 2. Role-family sweep | unavailable | No search sent; search was refused. Would have set the market calibration against €40,000 |
| 3. Hiring manager's public footprint | unavailable | Name given (Declan Garvagh); no search sent, search was refused. Would have moved the scope read and what to ask at interview |

I didn't retry the refused searches.

If you're happy with the upgrade menu items below, I'd still do A1 yourself. An independent check on the employer is the part of this I couldn't make from here.

If you want this written up as a `tuesday-dossier.md` to keep, say so and I'll make one.

**Upgrade menu**

- Web search permission granted: reruns target 1 (RR1), target 2 (the salary band behind RR2) and target 3 (Declan Garvagh's public professional footprint).
- Your Limerick commute: closes R1.
- Any pension-change work you saw or supported: moves R10 from discovery.
- A copy of your payroll certificate: raises R6 to `high`.

**Questions**

RR1 — Who interviewed you at the Limerick office, and did you meet Declan Garvagh?

R4 — Did your hotel group's payroll run under Irish PAYE, PRSI and USC, or under another system?

R1 — Can you attend the Limerick office two days a week from where you live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.