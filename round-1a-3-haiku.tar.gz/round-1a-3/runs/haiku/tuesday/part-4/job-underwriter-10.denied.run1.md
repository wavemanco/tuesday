**Worth applying to, as `conditional_go`.** Is it legit? Nothing in the posting or the WhatsApp message asks for money, bank or ID details, or anything before an interview, and the call is routine scheduling. I could not check that Fernquay exists as described, so that stays open. Web search was refused in this session, so I have no company facts beyond the posting itself.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (base salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (own the booking flow end to end)
- `important` — adjacent: R8 (first designer, no design peers)
- `preferred` — adjacent: R9 (booking for activity schools)

R6 — the must-have most likely to be probed, since your work was checkout inside a squad; R2 — a gate your pay floor would settle; R8 — the limit to name on the call.

**Opportunity ledger.** RR1 (employer unverified, `severity: medium`) and RR2 (equity terms undefined) are open; RR3 (who holds design decisions) is unknown; RR4 is a positive signal, since pay, equity range, hybrid days and the co-founder's name are all stated.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (base salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is on Fernquay's own careers page and the employer entity can be found; (2) R2 meets your pay floor; (3) RR2 clears: equity terms in writing. R6 stays adjacent either way.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Fernquay (booking software, careers) were refused. Web search permission was not granted in this session, so I did not retry or work around it. Would have moved: existence as described, whether the posting is live, stage. |
| 2. Role-family sweep | unavailable | One salary search, refused. Would have moved: market calibration for the €52,000–€60,000 band. No band given from memory. |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe is named, so one query was formed ("Ronan Kehoe Fernquay co-founder"), refused. Would have moved: positioning for the call. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools; co-founder Ronan Kehoe | `[grounded]` posting, unverified |
| Role | First product designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Pay | €52,000–€60,000 base plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, otherwise remote | `[grounded]` posting |
| Scope read | Owning a booking flow as the only designer at a six-person company is a broad remit | `[inferred]` from "first designer" and "end to end" against two engineers |
| Market calibration | Not run; the search was refused. No band stated from memory | — |
| Unknowns | Whether the company exists as described; equity mechanics; design decision rights; whether the pay range meets your floor | — |
| Contradictions | None between the posting and the WhatsApp message (name, company and role match). Not checked against the company's own site | `[grounded]` both messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit where you live. Self-report, not probed | `[grounded]` your intake | none |
| R2 | Base salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so whether the range meets it is unknown | `[grounded]` posting; floor unstated | Q1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Length of experience is graded on fit, not as a gate | `[grounded]` your intake | Attach a CV |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" in your intake; no file inspected yet | `[grounded]` your intake | Link a Figma file from the case study |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Their audience was travel customers, not school owners | `[grounded]` your intake | Share one session summary |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout inside a squad of four engineers. Checkout is the end of a booking flow, and end-to-end ownership is not stated | `[inferred]` adjacency from your intake | Q2 below; G1 |
| R7 | Work directly with engineers, ship alongside them | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake | none |
| R8 | First designer, no design peers | important | adjacent | medium | transferability | You have never been the only designer. The squad gave you design peers this role would not | `[inferred]` from posting scope against your intake | G2 |
| R9 | Booking for activity schools | preferred | adjacent | medium | transferability | Travel-booking checkout is the nearest domain; schools and kayak or surf trips differ | `[inferred]` | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking ownership (R6, R9) | transferability | Checkout redesigned inside a squad; nothing shows you set the path from search to confirmation | The must-have most likely to be probed | Any flow where you set the path, even inside a squad; a decision you wrote up | The checkout case study, with decisions noted | `[inferred]` bridge from intake; `[generic]` that booking roles usually probe end-to-end ownership |
| G2 | Sole design voice (R8) | transferability | Squad background; never the only designer | The role asks for a first design hire, so you would need to set direction without peers | Times you set a standard, ran a critique alone, or made a call engineering accepted | A practice or template you started | `[inferred]` from intake; `[generic]` that first-designer hiring weighs this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | medium | "Product Designer — Fernquay" | The company may be too new or small to have a public footprint, the posting may be stale, or it may not be a real hiring employer. Not checked: no search ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Fernquay's own careers page, and which company entity is named on the contract? | unresolved |
| RR2 | Equity terms undefined | unknown | — | "plus 0.5–1% equity" | A percentage with no share class, vesting, strike price or cap table cannot be valued | `[inferred]` from the posting's silence | What share class is the 0.5–1%, what is the vesting schedule and strike price, and how many shares are issued in total? | unresolved |
| RR3 | Design decision rights unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | Ownership may not include final product decisions or budgeted research time | `[inferred]` from scope language against silence on decision rights | Who makes the final product call on the booking flow, and how much research time is budgeted? | unresolved |
| RR4 | Transparent posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | Pay, equity range, hybrid days and the co-founder are all stated | `[grounded]` posting | Which current project would I look at first? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check Fernquay on its own careers page and in the Irish company register before sending more than your CV | Settles RR1 | `[generic]` practice, not a fact about this company | For you to do |
| P2 | Join the 45-minute call only through the invite sent from a company address. Prep for the call is mock-interview's job | Routine scheduling; a check on the invite | `[grounded]` the WhatsApp message and the invite | For you to do |
| P3 | Lead with the four-year record and the usability sessions. Proposed wording: "I redesigned our checkout flow as part of a squad of four engineers, and ran monthly usability sessions with customers." | Truthful positioning for R3, R5, R6 | `[grounded]` your intake; audit: scope and verb kept | Proposed wording, pending your approval |
| P4 | Say on the call that you have never been the only designer, and name what you would do to cover it | Gives the interviewer the R8 limit before they find it | `[grounded]` your intake | Proposed wording, pending your approval |
| P5 | Ask for the equity terms in writing, and confirm pay against your floor, before a second round | RR2, R2 | `[generic]` practice | For you to decide |

## Evidence status

Verified: none yet. Everything above rests on your intake and the posting, and nothing has been inspected.

If you want this kept, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your minimum base salary → R2 closes; the hard-gates line updates.
- The checkout case study Ronan has already seen, or one usability-session summary → R5 and R6 can rise toward `high` if inspectable.
- The equity terms in writing (share class, vesting, strike price, cap table) → RR2 closes.
- A search of Fernquay's own site, careers page and the Irish company register, if search is permitted → RR1 closes, and the status may move to `go`.
- A role-family salary sweep → market calibration for the €52,000–€60,000 band.
- Ronan's public professional footprint → positioning for the call.

## Questions

Q1 (R2) — Is your minimum base salary at or below €52,000?

Q2 (G1, R6) — Have you ever made the final calls on a whole booking or checkout path, from search to confirmation, even inside a squad? If so, which calls were yours?

Q3 (RR1) — Which address did the calendar invite come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.