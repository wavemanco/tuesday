**Decision snapshot: `conditional_go`.** The request is routine. The only open item is verifying the employer, which I could not do.

- **Hard gates:** none failed. Pay (€40,000) sits inside the advertised €38,000–€42,000 band [grounded].
- **Research tier:** L1, searches 2 of 5, fetches 0 of 2. Both searches for Marrowgate Housing were refused by a permission prompt, so no employer check was run.
- **Why conditional:** the employer is unverified, so `go` is capped until you check it yourself.

**Is it normal to be asked for bank details, PPS and passport?** Yes. Asking for these after a written offer is standard in Irish employment:
- Payroll needs your bank details for salary.
- Revenue needs your PPS number for PAYE and PRSI. You would have given it to any employer.
- Employers must check right-to-work. A passport scan or the original document on day one is a normal method.

Your instinct to be careful is still right, because the risk is in *how* the details are collected. The playbook only treats a demand as a red flag when it comes before any offer, or asks for money or payment for the job. This offer came after two in-person interviews, so the sequence is credible. What I would do before sending anything:

1. **Don't send anything before you accept.** A reply accepting the offer is enough. Nothing here needs bank or passport details first.
2. **Check the employer through its own website, not the email.** Find Marrowgate Housing's main phone number and address on the site you reach by typing the address yourself. Call that number and ask whether Declan Garvagh, Finance Manager, exists and whether the Payroll Administrator role is live.
3. **Check the portal link.** When it arrives, its domain should match marrowgatehousing.ie. If it points elsewhere, stop and ring the verified number.
4. **Send documents only through the portal, not by plain email.** Do not email a passport scan to people@marrowgatehousing.ie or any other address.
5. **Keep the original passport for day one, as asked.** Bring it to the office, don't post it.

**Evidence map (short):**
- **Met:** 2+ years running payroll [grounded, your stated 3 years]; Excel [grounded, your stated pivot tables and XLOOKUP]; a payroll qualification [grounded, Payroll Technician certificate, 2024]; the monthly payroll-to-ledger reconciliation [grounded, stated].
- **Working knowledge of PAYE, PRSI and USC:** [inferred] from your fortnightly payroll work. It is stated, not verified, so be ready to show it in interview.
- **Gap:** processing pension changes. You said your manager handled these. It is a real gap to name in an interview, not a dealbreaker, since the rest of the role is a close fit.
- **Fortnightly vs monthly:** the role is monthly. Your experience is fortnightly, which is a different cycle to be ready to discuss.

**Opportunity ledger:**
- No red flags in the offer's wording [grounded]. It is written, from a company-domain address, after interviews, and asks for no payment.
- Unverified: the employer's existence and this specific posting [unknown, not checked].

**Role reality:** a Limerick housing association with about 240 staff, hybrid with two days in the office, reporting to a Finance Manager. The market calibration for this seniority is not run; no search was possible [generic].

**Application plan:** before accepting, complete the steps above. Then prepare for a pension-changes question and a PAYE/USC/PRSI walkthrough.

**Evidence status:**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | search permission refused |
| 2 | Role-family pay and scope sweep | unavailable | search permission refused |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | search permission refused |

**Dossier offer:** I can write a `tuesday-dossier.md` with this assessment and the verification steps, so you have them to refer back to.

**Upgrade menu:**
- A live link to the posting or the careers page would let me check the employer's existence and the role's terms. Searches would also cover market pay.
- The portal link, once it arrives, would let me check its domain against the employer's.
- Your PAYE, PRSI and USC work examples would move the working-knowledge row from inferred to grounded.

**Questions:**
1. Do you have a live link to the job ad or the careers page, or only the email?
2. Can you find Marrowgate Housing's main phone number on the website you reach by typing the address yourself, and call it before accepting?
3. Would you like the verification checklist and the pension-changes prep saved as a dossier?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.