**Short answer:** yes, asking for bank details, PPS number and a passport scan after you accept is normal onboarding. The offer asks for those only after you accept, through a portal, which is the usual order. Your rule still applies, but the question is where you enter them. Only into Marrowgate's own portal, at the address on their own website, and only once you've verified the offer.

**Decision snapshot**

**Accepting is worth it, on conditions. Status: `conditional_go`.** The onboarding request is routine and gives no reason for concern. I could not run the online checks on the employer, so the employer and pay band are unverified (details below).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Right to work in Ireland), R2 (Limerick office, two days a week)
- `must_have` — direct: R3, R5, R6, R7, R8 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — adjacent: R9 (Pension changes) · unclear: R10 (Answering staff payroll queries)

R4 — the largest open must-have, unconfirmed until you say how you've used Irish rules. R9 — adjacent, with the limit named: you have never processed pension changes.

**Opportunity ledger.** The posting, the offer and the two in-person interviews agree on role, pay band, location and reporting line (RR1, unverified). No severe red flags were found (RR2 notes the onboarding request, which is routine).

- **Hard gates:** none failed; unconfirmed: R1 (Right to work in Ireland), R2 (Limerick office, two days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your Irish PAYE, PRSI and USC working knowledge confirmed in your own words (R4); (2) a concrete plan for pension changes (R9); (3) the onboarding details entered only through the portal at Marrowgate's own address.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff queries | `[grounded]` job ad |
| Pay | €40,000 offered; the ad's band is €38,000–€42,000 | `[grounded]` offer and ad |
| Working pattern | Permanent, hybrid, two days a week in the Limerick office | `[grounded]` offer |
| Reporting line | Declan Garvagh, Finance Manager (name as given in the offer, unverified) | `[grounded]` offer |
| Market calibration | Not run; the salary search did not go through | — |
| Unknowns | Pension scheme administration, team size, notice-period start date, what right-to-work documents they accept | — |
| Contradictions | None between the ad and the offer | `[grounded]` both documents |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (candidate constraint) | hard_gate | unclear | none | hard_gate | Not stated anywhere in what you've shared | — | Question Q3 |
| R2 | Limerick office, two days a week (candidate constraint) | hard_gate | unclear | none | hard_gate | Location not stated; the interviews were in Limerick | — | Question Q3 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; self-reported, so it needs a probe | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | The Payroll Technician certificate suggests it, but Irish rules are not named | `[inferred]` from the certificate | Question Q1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use; pivot tables and XLOOKUP named | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R7 | Starters and leavers | must_have | direct | medium | none | Run in the hotel group role | `[grounded]` your background | none |
| R8 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done monthly for three years | `[grounded]` your background | none |
| R9 | Pension changes | important | adjacent | low | transferability | Starter and leaver processing carries over; pension changes themselves were handled by your manager | `[inferred]` from the starter and leaver work | Question Q2; see G1 |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` absence from background | Question Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R9, important) | transferability | Starter and leaver processing done; pension changes not | Named as a responsibility; the limit is real | Pension-scheme joiners or contribution changes you checked before a payroll run, even if your manager signed off | A process note, or a sanitized pension change checklist | `[inferred]` bridge from starter and leaver work |
| G2 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Certificate and payroll work, Irish rules not named | A must-have; decides how strong the case is | Preparing PAYE returns, applying USC or PRSI classes, year-end P60 or RPN work | A sanitized payslip or payroll-report sample, or the certificate's syllabus | `[generic]` the Irish rules are the usual focus of Irish payroll roles |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The job may be real and unverified here; the online checks did not run | `[generic]` standard limit of a first pass, not a claim about Marrowgate | "Can you confirm the People Team contact and the onboarding portal address from your official website?" | unresolved |
| RR2 | Onboarding asks for bank, PPS and passport details | — | — | "add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | Routine after acceptance; no entry is recorded | — | — | not an entry (routine step) |

Severity is `—` on RR1 because it is an unknown, not a risk signal. Its only exit is the verification question.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before you enter any details, check that the portal link's address matches the domain on Marrowgate's own website | The offer comes from marrowgatehousing.ie; the portal should be on that same domain | `[inferred]` from the offer text | pending your approval |
| A2 | Accept in writing by replying to the offer, and keep all personal details out of that reply | The offer asks only for a reply to accept | `[grounded]` offer | pending your approval |
| A3 | Ask the People Team which right-to-work documents they accept, and whether a copy or the original is needed | The passport request may be replaceable depending on your nationality | `[generic]` how Irish employers usually run right-to-work checks | pending your approval |
| A4 | Ask for pension scheme onboarding and training before your start date | Closes the R9 gap without claiming experience | `[grounded]` job ad lists pension changes | pending your approval |

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed the employer exists and that the posting is live. The web search was refused permission, so the check did not run |
| 2. Role-family sweep | unavailable | Would have set the market band for this salary and role. Not run; no market figure is given here |
| 3. Hiring manager's public footprint | unavailable | Would have checked Declan Garvagh's public professional role. Not run |

Verified: none yet. Unverified leads: none.

**Dossier offer.** If you want, I can write this into a `tuesday-dossier.md` you can keep and add to as you get answers.

**Upgrade menu**

- Web search permission for the employer and market checks → RR1 closes or stays open, and the pay band gets calibrated against `[generic]` figures.
- A sanitized payslip or payroll-report sample showing PAYE, PRSI and USC → R4 moves from `low` to `medium`.
- A sanitized pension change checklist or process note → R9 moves from `low` to `medium`.

**Questions**

- Q1 (R4 / G2): Have you run Irish PAYE, PRSI and USC yourself, and how far into the detail — returns, USC/PRSI classes, year-end?
- Q2 (R9 / R10 / G1): Have you seen pension changes done from the payroll side, even if your manager did them, and have you answered staff payroll queries?
- Q3 (R1 / R2): Do you have an unrestricted right to work in Ireland, and can you attend the Limerick office two days a week?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.