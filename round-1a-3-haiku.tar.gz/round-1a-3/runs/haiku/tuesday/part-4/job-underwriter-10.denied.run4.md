**Decision: `conditional_go`.** The role is worth the call. Whether to trust the company is still open, because I could not check it: my web search was refused by permission, so I have no company facts beyond the posting and the WhatsApp message.

**Decision snapshot**
- **Fit:** Strong on all four stated requirements. The one real gap is that you have never been the only designer.
- **Hard gates:** Location fits (you're in Galway, and the role is two days a week there). Pay is unknown because your floor isn't stated. No other hard gate is flagged.
- **Employer:** Not verified. This caps the decision at `conditional_go` until you verify it.

**Role reality** [grounded, from the posting]
Six-person Galway startup building booking software for sea-kayak and surf schools. First designer, with two engineers, a named CTO (Saoirse) and co-founder (Ronan Kehoe). €52,000–€60,000 plus 0.5–1% equity. Hybrid, two days in Galway.

Market calibration: not done. I have no sourced Galway pay or equity figures, so I can't say whether the band is fair. [generic]

**Evidence map**

| # | Priority | Requirement | Your evidence | Fit | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | 3+ years product design | 4 years at a Dublin travel-booking company | Strong | Medium (stated, not checked) | None |
| 2 | Must | Strong Figma | Uses Figma daily | Strong | Medium | None |
| 3 | Must | Has run own user research | Ran monthly usability sessions with customers | Strong | Medium | None |
| 4 | Must | Works directly with engineers | Four-engineer squad | Strong | Medium | None |
| 5 | Must | Owns a flow end to end | Redesigned the checkout flow | Strong | Medium; the case study Ronan mentioned can verify it | None |
| 6 | Implied | Booking-domain experience | Travel booking, not activity or school booking | Partial | Medium | Adjacent domain |
| 7 | Implied | Works without design peers | Never the only designer | Gap | Low | Real gap, recoverable |

**Gap recovery queue** (no questions here; they are in the closing block)
- **G1, solo designer:** Closed by an example of working without a design peer, or a credible plan for doing so.
- **G2, pay:** Closed by your floor and current package, checked against the band.
- **G3, employer verification:** Closed by the company's own website, an invite email domain that matches it, and a check of the Irish company register (CRO).
- **G4, domain:** Closed by any booking-UX work outside travel, or research with sea-kayak or surf operators.

**Opportunity risk register**
- **Employer not verified** (standing entry). Possible explanations, none ranked as likely: a very new or small company, a stale posting, or not a real hiring employer. Resolve it with the items in G3.
- **Solo role:** A fit risk to you, not a sign of a bad employer. Ask what support exists in year one.
- **Equity:** 0.5–1% at a six-person company is worth asking about. Ask whether it's options or shares, the vesting schedule, the strike price, and what dilution looks like.
- **Pay:** Unchecked against any band (see the market calibration note above).
- **Not red flags:** Ronan scheduling over WhatsApp and the invite arriving by email are both routine. There is no request for payment, bank details or ID before an offer.

**Positive signals:** The posting is specific (named product scope, customers, CTO and co-founder). The hybrid terms suit you. They read your checkout case study.

**Application plan**
1. Before the call, check that the invite's sender domain matches the company's website. Check the CRO register for the company name.
2. Prepare a walkthrough of the checkout case study. Focus on one decision you made, what you tested, and what you'd change.
3. On the call, ask how the solo role is set up, how often research happens, and what the first 90 days look like.
4. Get the pay band and the equity terms in writing before any offer.
5. For call prep, mock-interview can build a prep pack.

**Evidence status**
Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search refused by permission |
| 2. Role-family sweep (scope, title, pay) | unavailable | Web search refused by permission |
| 3. Ronan Kehoe's public footprint | unavailable | Web search refused by permission |

**Dossier offer:** I can save a `tuesday-dossier.md` with this assessment so later steps can pick it up.

**Upgrade menu**
- Company website or careers page: would let me verify the employer (G3).
- Your pay floor and current package: would let me check pay against the band (G2).
- Your checkout case study link: would verify your strongest evidence (rows 1, 5).
- Web search access: would let me run the company and market checks above.

**Questions** (answer in prose, or say "skip" on any of them)
1. What is your current salary, and what is the lowest figure you would accept?
2. What domain did the invite come from, and what is the company's website or careers page?
3. Could you work as the only designer for a year? What would need to be in place for that to work?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.