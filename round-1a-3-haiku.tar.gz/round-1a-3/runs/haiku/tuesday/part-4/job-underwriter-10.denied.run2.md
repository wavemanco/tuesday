**Worth pursuing, with conditions: `conditional_go`.** Your requirements fit well on the evidence you've given me. The open questions are the first-designer scope, the equity terms, and whether Fernquay is what it claims to be. I could not check the company: web search was not permitted in this session, so legitimacy is unverified, not cleared or doubtful. Nothing you've described asks for money, a deposit, or bank details. The WhatsApp message and calendar invite are ordinary scheduling.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay floor not given)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6, R8
- `important`: unclear: R9 (working as the only designer)

R6 and R8 are bridges with their limits named; R9 is untested because you've never been the only designer.

**Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.

**Opportunity ledger.** The pay band and equity range are stated, and the scope is specific: RR2 (equity terms) and RR1 (decision rights) are unanswered. RR3 is the standing employer-not-established entry, which applies because I could not verify the company. P1 is a positive: the terms are stated openly.

**Severe red flags:** none found.

**What would change this:** the conditions for `conditional_go` are (1) Fernquay is confirmed as a live employer on its own site before the call (RR3); (2) the booking-flow decision rights are concrete on the call (RR1, R9); (3) equity vesting and share class are stated in writing before you weigh the offer (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not externally verified |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not established: no search was available, so I have no sourced band for this title in Galway | — |
| Unknowns | Equity vesting and share class; decision rights on the flow; team beyond six | — |
| Contradictions | None found between the posting and the WhatsApp message | `[grounded]` both inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from the Galway office two days a week | hard_gate | direct | high | none | You live in Galway, and that is your own stated constraint | `[grounded]` your statement | none |
| R2 | Salary €52,000–€60,000 (your floor) | hard_gate | unclear | none | hard_gate | No floor stated, so the band cannot be checked against it | `[grounded]` posting; no candidate statement | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years, stated by you; no artifact yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, stated by you | `[grounded]` your background | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated by you | `[grounded]` your background | none |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | Same discipline, but with travel-booking customers, not small-business owners | `[inferred]` from R5 | G1 |
| R7 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad, stated by you | `[grounded]` your background | none |
| R8 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout; you have not owned discovery through shipping | `[inferred]` from your checkout work | G1 |
| R9 | Works as the first, only designer | important | unclear | low | discovery | You have never been the only designer, so there is no evidence either way | `[grounded]` your statement; requirement from `[inferred]` "first designer" | G2 |

Your background is self-report at intake, so every claim sits at `medium`. The `medium` band is the ceiling until something inspectable exists.

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Owning the flow and school-owner research (R6, R8) | transferability | Checkout redesign and customer sessions carry over; small-business owners and end-to-end ownership are not exercised | The checkout case study, cited as the evidence of your ownership | `[inferred]` bridge from your stated work |
| G2 | Working alone as the designer (R9) | discovery | Four years in a squad, never solo | A specific example of a call made with no designer to check against | `[grounded]` your statement; `[generic]` that small teams probe this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights on the booking flow unstated | unknown | — | "own the booking flow end to end" | You may be accountable for the flow without final say over it | `[inferred]` from the scope against the silence on authority | Which booking-flow decisions are mine alone, and which need the co-founder's or CTO's sign-off? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity may be worth less than it sounds without vesting and share-class terms | `[inferred]` from the posting's silence on terms | What is the vesting schedule, the share class, and the total shares in issue? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| P1 | Pay, equity range and hybrid days stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms are stated in the open, which lowers the chance of a surprise later | `[grounded]` posting | — | noted |

The WhatsApp message and the calendar invite are routine scheduling, so they raise no entry. Checking the invite's sender domain is advice, below.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the role on Fernquay's own website and check the invite comes from their domain | Verifies RR3 without relying on the WhatsApp contact | `[generic]` practice; RR3 | advice |
| A2 | Ask about equity vesting and share class on the call | RR2 | `[grounded]` register | pending your approval |
| A3 | Ask who holds final say on the booking flow | RR1 and R9 | `[grounded]` register | pending your approval |
| A4 | When asked about working alone, answer with your squad experience and name the limit: you have not been the only designer | R9 | `[grounded]` your statement | pending your approval |
| A5 | Describe the school-owner research as adjacent: the method carries over, the customer type does not | R6 | `[grounded]` R5 and R6 rows | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so it is leads for verification, not verified claims.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed RR3 and whether the posting is live. Four search calls were refused in this session. |
| 2. Role-family sweep | unavailable | Would have set the market calibration for the pay band (R2, RR4 band). |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, so a query could be formed; the refused search would have checked his public role. |

## Upgrade menu

- Permission for web search in this session → runs the three L1 targets, which settle RR3 and give a sourced salary band for R2.
- The posting's own link → confirms RR3 directly.
- The checkout case study Ronan mentioned → R3 to R5 and R8 can move from `medium` toward `high`, and the booking-flow ownership gets evidence.
- Your pay floor and any other non-negotiables → R2 closes, and any further hard-gate rows get added.

I can also emit a `tuesday-dossier.md` from this analysis for your interview prep, if you want one.

Questions:

1. R2: What is the lowest base salary you would accept, and are there any other non-negotiables beyond the Galway days and pay?
2. R9: On the squad with four engineers, who signed off on your flow decisions: did you have the final call, or did someone above you?
3. RR3: Can you send the posting's link from Fernquay's own site, and the email domain the calendar invite came from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.