**Yes, it's worth continuing, and Fernquay looks like a real company · `conditional_go`**

Fernquay is identifiable from its own about page, and nothing in the posting or the message asks you to pay or send anything. Whether the pay and the scope work for you depends on two things only you or Ronan can answer: your pay floor (R2) and what the solo-designer role actually decides (RR1).

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (base salary €52,000–€60,000)
- `must_have`: direct: R3 (3+ years of product design), R4 (strong Figma), R5 (run your own user research), R6 (working directly with engineers)
- `important`: adjacent: R7 (own the booking flow end to end), R8 (booking software for schools)

R2 turns on your pay floor; R7 is the solo-ownership limit you have not yet shown; R8 is an adjacent domain, not a direct one.

**Opportunity ledger.** Salary and equity are stated (RR3, positive). Decision rights for the solo role are unstated (RR1). The posting is not confirmed on the company's own site (RR2). Whether Saoirse is a co-founder or the CTO is unconfirmed (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (base salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits within €52,000–€60,000 (R2); (2) the booking-flow decision rights are concrete (RR1); (3) you describe the checkout work as yours and the squad's, never as sole ownership (R7).
- **What would change this:** if your floor is above €60,000, R2 fails and this becomes `no_go` unless the salary moves.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers, product Kelproster for sea-kayak, surf and sailing schools | `[grounded]` about page |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity, stated | `[grounded]` posting |
| Market calibration | For 3–5 years' experience, Tillerby 2026 (n=520) gives a median of €57,000 and an interquartile range of €51,500–€62,000; the stated range sits inside it | `[generic]` role-family sweep, not this employer's offer |
| Hiring manager | Ronan Kehoe's public profile: co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` public profile |
| Unknowns | Decision rights on the booking flow; research time; equity vesting and strike price; whether the role is live on the company's site | — |
| Contradictions | None in the posting. The about page lists Saoirse as co-founder; the message calls her CTO. Both can be true (RR4) | `[grounded]` both sources |

On the WhatsApp message: a co-founder messaging an applicant to set up a call is routine, and the email invite is the usual route. It carries no register entry. As a check, confirm the invite comes from a Fernquay address and the video link matches it.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year; self-report, nothing to inspect | `[grounded]` your intake | none |
| R2 | Base salary €52,000–€60,000 within your floor | hard_gate | unclear | none | hard_gate | No floor given, so the fit cannot be called | `[grounded]` posting | Your floor (G2) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; no artifact yet | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; a portfolio would confirm it | `[grounded]` your intake | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; school owners are a different audience | `[grounded]` your intake; `[inferred]` that the audience gap matters | Name the audience difference on the call |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad of four engineers | `[grounded]` your intake | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout inside a squad; you have never been the only designer | `[grounded]` your intake; `[inferred]` adjacency | G1 |
| R8 | Booking software for schools | important | adjacent | medium | transferability | Travel booking is adjacent; sea-kayak school owners are a different customer | `[inferred]` adjacency; `[generic]` that this objection is common | State the limit on the call |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R7, important) | transferability | Checkout redesign done inside a squad; no sole-designer or end-to-end ownership shown | This is the posting's central ask | Checkout decisions you made yourself; usability sessions you designed; customer feedback you acted on | The checkout case study, session summaries | `[grounded]` intake; `[inferred]` that this is central |
| G2 | Base salary within your floor (R2, hard_gate) | hard_gate | No pay floor stated | The gate is unclear, and €60,000 is the top of the range | None needed; it is your own number | Your stated floor | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo-designer decision rights unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may carry the flow's outcomes without say over scope, pricing or research time | `[inferred]` from scope language against its silence on decision rights | Which booking-flow decisions would I make myself, and how much of the week goes to research with school owners? | unresolved |
| RR2 | Posting not confirmed on the company's site | risk_signal | low | "Product Designer — Fernquay" | The role may be posted elsewhere, or the careers address may differ; the one address I tried returned no page | `[generic]` pattern for small companies' careers pages, not a claim about this one | Is this role on your own careers page, and is it still open? | unresolved |
| RR3 | Salary and equity stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay is transparent and sits inside the market band | `[grounded]` posting; band `[generic]` (Tillerby 2026) | What vesting schedule and strike price apply to the equity? | noted |
| RR4 | Co-founder or CTO title | unknown | — | About page: "Founded 2023 by Ronan Kehoe and Saoirse Doyle"; message: "Saoirse, our CTO" | Both can be true; the title is unconfirmed | `[grounded]` both sources | Is Saoirse a co-founder and also the CTO? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Send Ronan a link to the checkout case study before the call, if you can share it | He named it; it is the only inspectable artifact | `[grounded]` Ronan's message | pending your approval |
| P1 | Describe the checkout work as you did it: "I redesigned our checkout flow", and say who else was on it | Keeps R7 at its true strength | `[grounded]` your intake | pending your approval |
| Q1 | Put RR1 and RR2 to Ronan on the call, in these words | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check the invite comes from a Fernquay address and the video link matches | Routine check; advice only | `[generic]` common practice for small-company scheduling | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea-kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Fetched that page: six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers, product Kelproster. Fetched fernquay.example/careers, which returned no page, so the posting is not confirmed live on the site (RR2) |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience startup equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report): 3–5 years, n=520, median €57,000, interquartile range €51,500–€62,000. Sets the market calibration (`[generic]`) |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe co-founder", which returned a public profile (linkedin.example/in/ronan-kehoe): co-founder and CEO; previously product lead at a Galway travel-software company for five years. Shapes the hiring-manager row in role reality |

Dossier offer: I can write this up as a `tuesday-dossier.md` file, which mock-interview can later read for your call prep.

**Upgrade menu**

- A link to the checkout case study → R5 and R7 evidence moves toward `high`; expect a probe on what you did alone.
- Your lowest acceptable salary → R2 closes, and the status is set against €52,000–€60,000.
- The live posting on the company's careers page → RR2 closes.
- Deeper research on Fernquay (funding history, leadership changes, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G2 — What is the lowest base salary you would accept?

G1 — Can you share the checkout case study, so I can see which decisions were yours and which were the squad's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.