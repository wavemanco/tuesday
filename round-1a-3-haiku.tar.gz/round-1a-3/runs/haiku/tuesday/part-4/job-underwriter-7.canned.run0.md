**Yes, worth applying for, on conditions.** Status: `conditional_go`. Your core ward and discharge-visit experience matches most of the role. The open points are the caseload you have never held, leg-ulcer work, end-of-life and continence care, and whether the advert is still live.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Fit ledger:**
  - `hard_gate` — direct: R1, R2
  - `must_have` — direct: R3, R4, R6, R7 · adjacent: R5 (leg-ulcer care), R8 (holding a caseload) · unclear: R9 (end-of-life visits), R12 (written records, EPR)
  - `important` — adjacent: R11 (care planning) · unclear: R10 (continence care)
  - `preferred` — absent: R13 (Doppler assessment)

  R5 — leg-ulcer bridge, its limit named; R8 — caseload, the central stretch; R9 and R12 — waiting on your answers; R13 — a training path, not yet a skill.
- **Opportunity ledger:** The employer is attributable (RR4, positive). The posting's live status, contract basis and caseload support are open (RR1, RR2, RR3).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the advert confirmed open on Calderbrook's own site (RR1); (2) contract basis and on-call or weekend rota stated (RR2); (3) caseload support explained in the informal chat (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` About page |
| Mandate | District nursing for housebound adults, a small personal caseload with a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A survey of 1,240 Band 5 community staff nurses gives a median of £34,300 and a middle half of £32,400–£36,600; 61% were paid mileage. The advert's range spans that middle half. This is a survey, not an official pay scale, and I did not confirm the 2026 Agenda for Change band from a source | `[generic]` Wardround 2026 guide |
| Scope read | A small caseload with senior support is a normal first community post | `[inferred]` from the advert's wording |
| Unknowns | Contract basis, on-call or weekend rota, whether the post is open now | — |
| Contradictions | None found between the advert and the About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Stated, not checked; registration active, revalidation March 2028 | `[grounded]` your statement | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated, category B, full; not checked | `[grounded]` your statement | Check your licence record |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse, stated. This is a length-of-experience requirement, graded on fit | `[grounded]` your statement | none |
| R4 | Wound care (pressure and surgical) | must_have | direct | medium | none | Stated on the acute ward | `[grounded]` your statement | none |
| R5 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound work is stated; leg-ulcer work is not. Limit: no venous or arterial ulcer care named | `[inferred]` from R4 | Q2 below |
| R6 | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` your statement | none |
| R7 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` your statement | none |
| R8 | Holding a small caseload with senior support | must_have | adjacent | medium | transferability | Home visits in discharge-to-assess are stated; a caseload you hold and review over time is not. Limit: no caseload ownership | `[inferred]` from your home-visit role | G1 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not stated | `[grounded]` silence in your CV; `[generic]` that acute wards often meet end-of-life care | Q3 below |
| R10 | Continence care | important | unclear | low | discovery | Catheter care is stated; continence is not | `[grounded]` silence | G5 |
| R11 | Care planning | important | adjacent | medium | transferability | Discharge planning is implied by the discharge-to-assess role | `[inferred]` | G1 |
| R12 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | Essential in the advert; no record system named | `[grounded]` silence | G4 |
| R13 | Doppler assessment (desirable) | preferred | absent | none | capability | No evidence. Closure path: training; the team lead has spoken publicly on Doppler training for staff new to community work | `[inferred]` from her talk topic | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Caseload and care planning (R8, R11) | transferability | Home visits in your first post-discharge week; no caseload you held | This is the central stretch of the role | Any case you managed across a stay: a plan you reviewed and changed | `[inferred]` bridge from your home visits |
| G2 | Leg-ulcer care (R5) | transferability | Wound care is stated, leg ulcers are not | A must-have; the Doppler item sits beside it | Any leg-ulcer dressing or assessment, even supporting | `[inferred]` |
| G3 | End-of-life visits (R9) | discovery | Not in your CV | A must-have in a role built around housebound patients | Any end-of-life visit or planning on the discharge team | `[grounded]` silence |
| G4 | Written records and EPR (R12) | discovery | No record system named | Essential in the advert | Which EPR system you used and how you recorded visits | `[grounded]` silence |
| G5 | Continence care (R10) | discovery | Catheter care stated, continence not | Important, part of the advertised duties | Any continence assessment or product plan | `[grounded]` silence |
| G6 | Doppler assessment (R13) | capability | No evidence | Desirable, not essential; can be trained | A course, or the team's own training offer | `[inferred]` from the talk topic |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live on the employer's site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The advert may be stale or already filled; my guessed careers address returned no page | `[grounded]` my fetch result | Is this post open now, and where is the live advert on your careers page? | unresolved |
| RR2 | No contract type or on-call rota stated | unknown | — | Neither the advert nor the About page states contract basis or rota | The post may be fixed-term, or carry out-of-hours cover | `[inferred]` from the advert's silence | Is this post permanent, and what on-call or weekend rota does it carry? | unresolved |
| RR3 | Caseload expected with limited senior time | risk_signal | low | "hold a small caseload of your own, supported by a senior community nurse" | A new caseload holder may carry decisions with thin senior review in the first months | `[inferred]` from the advert against your stated lack of a caseload | How is a new caseload holder supported in the first three months, and how is caseload size set? | unresolved |
| RR4 | Employer established from its own site | positive_signal | — | "Current vacancies are listed on our careers page" | A 410-staff NHS-contracted provider with four hubs is a real, sizeable employer | `[grounded]` About page | Which locality hub would this post sit in? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask Rhiannon Mabbott in the informal chat how a new caseload holder is supported, and whether Doppler training is given | RR3, R13 | `[grounded]` her speaker profile; `[inferred]` that training is offered | proposed, pending your approval |
| A2 | Check your NMC register entry and your driving record before applying | R1, R2 | `[grounded]` the gate rows | proposed, pending your approval |
| A3 | Lead the application with discharge-to-assess home visits as the bridge to caseload work, stating its limit | R8, R5 | `[inferred]` | proposed, pending your approval |

Her public footprint: she leads the Halifax district nursing team and spoke in 2025 on nurse-led leg-ulcer clinics. That is worth raising in the chat.

## Evidence status

Verified: none yet. Your CV-equivalent statements are leads until checked. Your National Insurance number and NMC PIN aren't needed for this assessment, so I haven't used or repeated them.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned the About page (calderbrookhealth.example/about). Fetched a guessed careers address (calderbrookhealth.example/careers): no page came back, so the advert's live status is unconfirmed. Moved the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 Agenda for Change pay scale 2026", which returned the Wardround 2026 guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched Rhiannon Mabbott with Calderbrook, which returned her speaker profile (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read and A1 |

Dossier offer: I can save this assessment as a `tuesday-dossier.md` to carry into later modules.

Upgrade menu:
- A live link to the advert, or the careers page entry → RR1 closes.
- Your pay floor, contract preference and any rota limits → the hard-gate check and RR2 close.
- Any leg-ulcer dressing or assessment, even supporting → R5 moves toward `direct`.
- Your NMC register and driving record checked → R1 and R2 move to `high`.
- A deeper pass on Calderbrook (inspection reports, public reviews, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions:

C1 — Do you have any non-negotiables for this role, such as a pay floor, permanent contract only, or limits on weekend or on-call work?

Q2 (R5) — Have you dressed venous or arterial leg ulcers, or taken ankle-brachial pressure readings, even as a supporting nurse?

Q3 (R9) — Have you done end-of-life visits or planned end-of-life care on the discharge team?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.