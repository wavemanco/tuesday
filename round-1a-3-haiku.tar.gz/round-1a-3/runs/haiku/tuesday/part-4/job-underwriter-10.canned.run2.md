**Research tier: L1, searches 4 of 5, fetches 1 of 2**

**Worth the call, and the employer checks out as far as public sources show. Status: `conditional_go`.** You've already applied, so the question is whether to take the call. Public sources match the posting on the employer, the role, the pay and the hybrid terms (RR3, RR4). The gate that's still open is your pay floor (R2).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (pay within €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (own the booking flow end to end)
- `important` — adjacent: R8 (research calls with school owners) · absent: R9 (first designer, no design peers)
- `preferred` — unclear: R10 (one messy real project)

R2 — the pay gate stays open until you give a floor; R7 — the booking-flow claim is adjacent, not direct; R9 — working without a design peer is the largest gap; R3, R4, R5 and R6 — direct and stated, not yet inspected.

**Opportunity ledger.** RR3 and RR4 — the employer is established and the pay sits inside the market band, so the standing employer-not-established entry is not raised. RR1 — equity terms are unknown. RR2 — the first-designer load is the risk to test on the call.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay within €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** for `conditional_go`, the conditions are (1) you can accept a base within €52,000–€60,000 (R2); (2) the call confirms what you owned end to end on checkout (R7); (3) the call confirms who decides on booking-flow priorities and who reviews design work (RR2). If your floor is above €60,000, the pay gate fails and the status drops to `hold_pending_answers`; only the employer changing the range resolves it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023; booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about (search snippet) |
| Role | Product Designer, first design hire: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting; careers page fetched |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 base plus 0.5–1% equity | `[grounded]` posting and careers page |
| Market calibration | Product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000 (2026 Ireland survey, n=520). The posting's range sits in the lower half of that spread | `[generic]` role-family sweep; this is a pattern, not this employer's offer |
| Scope read | Broad for the title: booking flow, customer research and shipping, alone on design | `[inferred]` from the three responsibilities against the first-hire framing |
| Hiring manager | Ronan Kehoe, co-founder and CEO; previously product lead at a Galway travel-software company for five years | `[grounded]` public profile (search snippet) |
| Process | A 45-minute video call scheduled by WhatsApp, with an emailed invite. Scheduling an interview by chat is routine, so it takes no register entry | `[grounded]` the message you received |
| Unknowns | Equity vesting, strike price and form; design budget and research time; whether the CTO title belongs to Saoirse Doyle (the about page names Saoirse as co-founder only); contract type (not stated) | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year, which you stated. Not a stated constraint and not inspected | `[grounded]` your statement | none |
| R2 | Pay within €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No floor given, so the gate is not settled | `[grounded]` posting; `[generic]` market band | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated in prose | `[grounded]` your statement | Send a CV or portfolio that shows those years |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated. The checkout case study Ronan praised is an inspectable Figma artifact | `[grounded]` your statement; WhatsApp message | Keep the checkout file ready to show on the call |
| R5 | Has run own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers, stated. Which parts you designed and ran alone is unconfirmed | `[grounded]` your statement | Be ready to say which parts were yours |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your statement | none |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | Redesigned checkout, one stage of a booking flow. Whole-flow ownership is not stated, and the squad probably owned decisions jointly | `[inferred]` adjacency from the checkout redesign | Q2 |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Your research method carries over. School owners are small-business operators, not the consumers you researched | `[inferred]` from your research history against the posting's customer group | Ask on the call how school owners are recruited for research |
| R9 | First designer, no design peers | important | absent | medium | transferability | You have never been the only designer, as you stated. Squad work with four engineers is the nearest evidence, though it is not design-peer work | `[grounded]` your statement; `[inferred]` the transferable case | Q3 |
| R10 | One messy real project over a polished deck | preferred | unclear | low | discovery | No project in hand beyond the checkout case study, whose polish is unknown | `[grounded]` posting | Send one real project, with what went wrong and what you'd revisit |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay (R2, hard_gate) | hard_gate | No floor in the material | The gate can't be settled without it, and it caps the status | Your own salary floor, whatever you'd need to accept | Nothing to attach; your answer settles it | `[grounded]` posting and your silence on pay |
| G2 | Booking-flow ownership (R7, must_have) | transferability | Checkout redesign in a squad; the whole flow is not stated | This is the claim the call will test | Decisions you made on checkout that the squad didn't force; research you led that shaped scope | The checkout case study with your notes | `[inferred]` from the checkout work |
| G3 | First designer alone (R9, important) | transferability | Never the only designer; squad experience is the nearest | Likely the question about day-to-day working without critique | Times you set your own priorities; work you shipped with no design review | Any example of unreviewed work and what you did about it | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated beyond a range | unknown | — | "plus 0.5–1% equity" | The range may be options or shares with unclear vesting and strike price | `[inferred]` from the posting's silence on vesting and strike price | What is the vesting schedule and strike price, and is the equity options or shares? | unresolved |
| RR2 | Sole designer, with broad scope | risk_signal | medium | "You would be our first designer: own the booking flow end to end" | The role may carry every design decision with no design review or budget. This is a pattern for first design hires at very small companies, not a claim about this one | `[generic]` pattern for first design hires at companies of this size | Who makes the final call on booking-flow priorities, who reviews design work, and what research budget and recruiting time does the role get? | unresolved |
| RR3 | Employer established, posting consistent | positive_signal | — | "Open now: Product Designer, our first design hire" | The posting matches the careers page on role, hybrid pattern, pay and application route | `[grounded]` careers page fetched; about page snippet | Is the role open to interviews now, and what is the hiring timeline? | noted |
| RR4 | Pay sits inside the market band | positive_signal | — | "€52,000–€60,000 plus equity" | The range sits in the lower half of the market band for this experience | `[generic]` 2026 Ireland survey band | Is there room within the €52,000–€60,000 range for someone with four years' experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check that the calendar invite comes from a fernquay.example address before the call | The process runs on WhatsApp and email, and the invite address is the one thing not yet checked. Advice only | `[grounded]` the careers page gives jobs@fernquay.example as the application address | advice |
| P2 | Say "redesigned the checkout flow", not "owned the booking flow" | Ownership of the whole flow isn't in your evidence, so the wider wording claims more than you can show | `[inferred]` from R7 and the reframing audit's scope axis | pending your approval |
| P3 | Decide your lowest acceptable base before the call | It settles R2 whatever the range turns out to be | `[generic]` advice on gates | advice |
| P4 | Bring one real project, with what went wrong and what you'd change | The posting says it values this over a polished deck (R10) | `[grounded]` posting | advice |

## Evidence status

Verified: none yet.

**Research tier: L1 — searches 4 of 5, fetches 1 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" (About Fernquay, fernquay.example/about) and "Fernquay Product Designer Galway careers" (fernquay.example/careers/product-designer); fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved: role reality's organization, and the contradictions row (none) |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience €52,000 €60,000 Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: the market calibration line, `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a public profile (linkedin.example/in/ronan-kehoe). Moved: role reality's scope read, and which story to lead with for this reader |

Your checkout work is the story most likely to land with this reader, since Ronan's public background is product work at a travel-software company. Lead with a tradeoff you weighed, not a claim about the whole flow.

If you want this kept as a `tuesday-dossier.md` for the next stages, I can emit it.

## Upgrade menu

- The checkout case study, or any Figma file you can show → R4 to `high`.
- A CV or portfolio document → R3 and R6 to `high`, and R5 closer to `high` once you show the research artifacts.
- Your pay floor → R2 closes, and the status moves to `go` or `hold_pending_answers`.
- The equity terms, vesting and strike price, or the offer terms → RR1 closes.
- A deeper research pass on Fernquay (funding, leadership, past hiring; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — What is the lowest base salary you'd accept, and is €52,000 above or below it?

G2 — On the checkout redesign, which decisions did you make end to end, and which were the squad's, from research through to engineering handover?

G3 — Have you worked without another designer to review your work or set priorities? If so, how did you get critique?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.