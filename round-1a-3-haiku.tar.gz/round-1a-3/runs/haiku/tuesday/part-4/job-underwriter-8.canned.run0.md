**Decision snapshot**

No, don't go ahead. Status: `no_go`. The reason is the payment and bank-detail requests in these messages, not the pay or the role.

- **Hard gates:** none stated in the posting. Your €30,000 floor is unconfirmed: at €26 an hour it needs about 22 hours a week before any commission, and the posting doesn't say what commission is.
- **Severe red flags:** RR1, RR2, RR3 and RR4 (`severity: high`).
- **Opportunity ledger:** RR4 and RR5 read against each other. The employer is not established (RR5), and every step asked of you is a request for money or sensitive details (RR1–RR4).

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers Remote Order Processing Coordinator". Both returned no results, so the employer could not be established. |
| 2. Role-family sweep | skipped | The decision rests on the requests, not on the pay band. |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a messaging handle. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", on a jobs site; no web presence found | `[grounded]` posting; no results from search |
| Pay | Up to €26/hour plus unstated commission, 15–30 hours a week. At 15–30 hours that is about €20,280–€40,560 a year before commission | `[inferred]` arithmetic on the posting's own figures |
| Process | Telegram only; no calls or video interviews | `[grounded]` posting and messages |
| Unknowns | Commission rate, contract type, who pays wages | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Pay floor of €30,000 | hard_gate | unclear | low | hard_gate | The posting's rate reaches €30k only at about 22 hours a week, before unstated commission | `[inferred]` arithmetic |
| R2 | Attention to detail and spreadsheets | must_have | direct | high | none | You keep a weekly Excel tracker and have handled about 60 tickets a day in Zendesk | `[grounded]` your background, as you stated it |
| R3 | Good written English | must_have | direct | medium | none | Three years of written customer-service work; no writing sample has been checked | `[inferred]` from your background |
| R4 | A quiet place to work | important | unclear | low | discovery | Not something to verify from here | — |

**Gap recovery queue:** none of the gaps matter for this decision. R1 is the only one that could change the picture, and only if the commission structure is stated in writing and comes to at least €30k a year.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Demand to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | This request is very likely a scam. A job should not need you to pay for your own equipment. | `[generic]` pattern for this request type; the sender's identity is unresolved | "Does the company charge candidates for equipment, and what is the official supplier's name and address?" | confirmed |
| RR2 | Demand to deposit a cheque and send money on | red_flag | high | "We are posting you a cheque for €2,850 … transfer the rest to our equipment partner" | This request is very likely a scam. A cheque sent before any real employment, with money to be passed on, is the usual shape of an overpayment fraud. | `[generic]` pattern; the sender's identity is unresolved | "Do you send cheques to new hires before any employment starts, and do you ever ask them to pass money on?" | confirmed |
| RR3 | Demand for bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | These details are being asked for before any written offer. Do not send them. | `[grounded]` the message's timing | "Do you collect bank, tax and ID details before a written offer, and through which portal?" | confirmed |
| RR4 | Whole hiring process run on Telegram | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | A job offer that is made only in chat is not something you can verify. | `[grounded]` posting | "Where is the role listed on your own website, and who would I be interviewing with?" | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. I can't establish the firm from here. | `[generic]` pattern for companies of this size; not a claim about this one | "Can you point me to the live posting on your own careers site, and to a company registration number?" | unresolved |

Hold: do not pay, deposit or send anything while you check. Enter bank, tax and ID details only in an employer's own portal, at an address on its own website, never one given to you in chat.

**Application plan:** do not apply through this chat. If you still want the role, find the employer's own careers page through a search you run yourself, and apply there.

**Evidence status:** Verified: none yet. Your background is as you stated it in this conversation.

**Dossier offer:** I can save this as `tuesday-dossier.md` for your records if you want it.

**Upgrade menu**
- A link to the live posting on the employer's own site, or a registration number that a search can confirm → RR5 closes or stays open.
- A written offer on the employer's own domain, with the commission rate and hours stated → R1 can be rechecked. The payment requests would still stand.

**Questions**
1. Which jobs site did you find the posting on, and can you share its link? (Answer in text, paste the link, or say skip.)
2. Did the chat give any employer name, address or company number beyond "Velloway Logistics"?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.