**Yes, it's worth pursuing, and the WhatsApp message is routine.** Take the call. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay band against your floor, which I don't have)
- `must_have`: direct: R5, R6, R7, R4 · adjacent: R3 (booking flow end to end), R8 (first and only designer)

R3 — adjacent, with its limit named: you redesigned checkout, not the whole booking flow. R8 — adjacent, with its limit named: you have never been the only designer.

**Opportunity ledger.** The employer checks out against the public record, and the pay band sits inside the market range (RR3, RR4). Two entries are open: equity and runway are unstated (RR1), and the first-designer scope has no design peer (RR2).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your pay floor, not given); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the founders answer the equity and runway questions (RR1) on the call; (2) your pay floor sits at or below €52,000 (R2); (3) you present the booking-flow and sole-designer gaps as adjacent limits, not as experience you don't have (R3, R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software (Kelproster) for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; customer-funded | `[grounded]` fernquay.example/about (search snippet, not fetched) |
| Mandate | First designer: own the booking flow end to end, run school-owner research, ship with two engineers | `[grounded]` posting |
| Scope read | Broad for one designer, though typical for a six-person product company | `[generic]` pattern for small product teams |
| Market calibration | Product designers with 3–5 years: median €57,000, IQR €51,500–€62,000. The posted €52,000–€60,000 sits inside that band | `[generic]` Tillerby 2026 Ireland design salary report, n=520 |
| Working pattern | Two days a week in the Galway office; the rest remote | `[grounded]` posting |
| Unknowns | Equity value, vesting and runway; who reviews design decisions; whether the base range is fixed | — |
| Contradictions | None. The posting and the company page agree on size, location and founders. The posting calls Ronan "co-founder"; his profile says "co-founder and CEO", which is not a conflict | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway hybrid, two days a week in the office | hard_gate | direct | medium | none | You say you moved back to Galway last year; self-report, not inspected | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor isn't in my inputs, so the gate isn't established | `[grounded]` posting; your floor not given | Question 1 below |
| R3 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is a real part of a booking flow, but one step, not the whole flow | `[inferred]` from your checkout case study | Gap queue G1 |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, stated; no file inspected | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Not yet with B2B school owners | `[grounded]` your statement | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your statement | none |
| R7 | 3+ years product design | must_have | direct | medium | none | Four years, stated. A length requirement, graded on fit, not a gate | `[grounded]` your statement | none |
| R8 | First and only designer, no design peer | must_have | adjacent | medium | transferability | You worked in a squad, but have never been the only designer | `[inferred]` from your background | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking flow (R3) | transferability | Checkout redesign and research sessions; no evidence you carried a flow from research through build to launch | Owning the flow is the job's core. Bridge: you know the flow's hardest step. Limit: you did not own the rest. Strengthener: a case study covering research to ship | Research that changed the checkout; decisions about how the flow was built and measured | The checkout case study the founders praised, with its outcome | `[inferred]` bridge from your checkout work |
| G2 | Sole designer (R8) | transferability | Squad experience with engineers, no design peer | Shipping alone means you decide without review. Limit: never done it. Strengthener: an example of a design decision you made alone | Cases where you set the design standard for a squad; a design-review process you ran | A description of how you handled a disputed design call | `[generic]` solo design hires commonly hit this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity stated with no terms | unknown | — | "plus 0.5–1% equity" | Equity may have little value without a valuation, vesting or runway | `[generic]` pattern for early-stage equity offers | What are the vesting terms, the total shares outstanding, and how many months of runway do you have? | unresolved |
| RR2 | Sole designer, no design peer | risk_signal | low | "you would be our first designer" | Decisions may go unreviewed; ask how design gets checked before shipping | `[generic]` pattern for first design hires | Who reviews design decisions day to day, and what does a typical ship cycle look like? | unresolved |
| RR3 | Employer checks out | positive_signal | — | "six people in Galway" | Public footprint matches the posting; founders are named and public | `[grounded]` company page snippet; founder profile | Would you share your current roadmap for the booking flow? | noted |
| RR4 | Pay band sits in the market range | positive_signal | — | "€52,000–€60,000" | Posted band is within the market's interquartile range | `[generic]` Tillerby 2026 band | Is the base range fixed, and does it cover the full scope described? | noted |

The WhatsApp invite is not a register entry. Scheduling by chat for an interview held on video is routine. The one check that matters is advice, not a condition: confirm the invite and the video link come from Fernquay's own domain before you join.

**Severity** reads `—` on `unknown` and `positive_signal` rows because the field applies only to risk signals.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the 45-minute call | Routine step, and the interview is the cheapest way to resolve RR1 and RR2 | `[grounded]` the invite; `[generic]` routine scheduling | proposed |
| A2 | Before joining, confirm the invite and video link come from Fernquay's own domain | Advice only | `[generic]` standard practice | proposed |
| A3 | Ask RR1 and RR2 verbatim during the call | The register doubles as call prep | `[grounded]` register | proposed |
| A4 | Lead with the checkout redesign and the monthly customer sessions; name the end-to-end and sole-designer limits in the same breath | R3 and R8 are adjacent, not direct | `[grounded]` R3, R8 | pending your approval |
| A5 | Lead with the travel-software overlap for Ronan | His profile shows five years as product lead at a Galway travel-software company | `[grounded]` his public profile | pending your approval |

## Evidence status

Verified: none beyond your own statements, which are `medium`: specific, but not inspected. The checkout case study the founders praised is not in my inputs, so I have not inspected it. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools"; returned fernquay.example/about (snippet only, not fetched). Moved: the employer exists as described. The live posting is not confirmed. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years Galway"; returned Tillerby 2026 Ireland design salary report (tillerby.example/2026-ireland-design-salary-report). Moved: the pay band and the market calibration in role reality. |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe Saoirse CTO Galway"; returned Ronan Kehoe's public profile (linkedin.example/in/ronan-kehoe). Saoirse Doyle did not appear in results. Moved: the positioning for A5. |

**Upgrade menu**

- The live posting or Fernquay's own careers page → confirms the posting is live, which closes the one open point in the employer check.
- Your pay floor and schedule constraints → R2 resolves, and the hard-gates line becomes a real check.
- The founders' answers on equity, vesting and runway → RR1 closes.
- A case study that runs from research through to launch → R3 moves toward `direct`.
- Deeper diligence on Fernquay (funding, leadership, public reviews, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs. This is offered once.

**Dossier offer:** I can write this up as `tuesday-dossier.md`, so the register questions travel with you into the call.

**Questions**

1. R2: What is your base pay floor, and does a two-day Galway week fit your schedule?
2. G1: On your checkout redesign, did you run the research, make the build decisions, and see it ship? If so, what did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.