## Role 1: Operations Analyst, Duinvaart Cold Chain. Yes, worth applying, with conditions: `conditional_go`

**Decision snapshot**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have`: direct: R2 (2+ years in logistics or operations analysis), R3 (strong SQL), R4 (Power BI or Tableau)
- `important`: direct: R5 (on-time delivery tracking), R7 (weekly dashboards, depot managers); unclear: R6 (temperature compliance, refrigerated fleet)
- `preferred`: adjacent: R8 (Dutch a plus)

R2, R3 and R4 — the must-haves, each self-reported at `medium` and waiting on a probe; R6 (`low`) — the one real gap, and the question to ask; R8 — a limit, not a bar.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 — you confirm the three-day Rotterdam pattern works; (2) R6 — your answer to the question below is concrete; (3) the employer checks out on its own careers page (RR1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; not verified (see RR1) | `[grounded]` posting only |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | `[grounded]` posting |
| Working pattern | Hybrid, three office days a week in Rotterdam | `[grounded]` posting |
| Scope read | Analyst-level, with named tools and duties | `[inferred]` from the duty list |
| Market calibration | Not run; no salary band checked | — |
| Unknowns | Salary; contract type; whether temperature data is owned by this role | — |
| Contradictions | None found in the posting | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Three office days a week in Rotterdam | hard_gate | unclear | none | hard_gate | No constraint given, so not settled | `[grounded]` posting | Q1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL, self-reported; expect a probe | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI, self-reported | `[grounded]` your background | none |
| R5 | Track on-time delivery across the fleet | important | direct | medium | none | You built the on-time dashboard depot managers use | `[grounded]` your background | none |
| R6 | Track temperature compliance (refrigerated fleet) | important | unclear | low | discovery | Your background is silent on temperature or cold-chain monitoring | `[grounded]` background silence | Q2 |
| R7 | Weekly dashboards; work with depot managers on routes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R8 | Dutch | preferred | adjacent | medium | transferability | Conversational, not fluent; the posting says "a plus" | `[grounded]` your self-report | State your level honestly |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | discovery | No temperature or threshold-compliance work in your background | A refrigerated fleet is named in the first duty; this is the question most likely to come up | Temperature logs; SLA-breach reporting; audit findings; any monitored threshold where a breach needed follow-up | A sanitized report or dashboard that tracked a threshold | `[grounded]` background silence; `[inferred]` that interviewers will ask this |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (standing entry) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: the web searches were declined, so this records a check that did not run, not a finding against the employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary and contract type not stated | unknown | — | (no pay or contract line in the posting) | The pay may be withheld or set elsewhere in the process | `[grounded]` posting silence | What is the salary range, and is the role permanent or fixed-term? | unresolved |
| RR3 | Duties and tools named | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The scope is concrete and checkable | `[grounded]` posting | Which temperature thresholds does the team act on today, and who owns a breach? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Duinvaart's own careers site before applying | RR1 | `[generic]` standing-entry pattern | proposed |
| A2 | Lead the CV with the on-time dashboard and its depot-manager use | R5, R7 | `[grounded]` your background | pending your approval |
| A3 | Prepare the temperature answer before any interview; if an interview is booked, the mock-interview module can drill it | R6, G1 | `[grounded]` G1 | proposed |

## Role 2: Supply Planner, Kroonhaven Foods. Not worth applying to now: `no_go`

**Decision snapshot**

No, not worth your application time now — `no_go`. The core planning duty and its system are absent from your background, and the 3+ year planning bar is met only by adjacent work.

**Fit ledger.**

- `hard_gate`: unclear: R1 (On-site in Utrecht)
- `must_have`: adjacent: R2 (Fluent Dutch), R3 (3+ years of planning in FMCG); absent: R4 (Own the 13-week supply plan), R6 (SAP IBP or a similar planning system); unclear: R5 (Advanced Excel)
- `important`: adjacent: R7 (Run the weekly S&OP meeting)

R4 and R6 — the core planning duty and its system, both absent; R3 — adjacent only, with no FMCG planning or plan ownership; R2 — conversational, below the fluent bar; R5 — not yet established.

- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** evidence of owning a supply or capacity plan, or working in SAP IBP or a comparable tool. Neither is in your background, and the posting gives no route in without one.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; not verified (see RR1) | `[grounded]` posting only |
| Mandate | Own the 13-week supply plan for a chilled ready-meals range; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site, Utrecht | `[grounded]` posting |
| Scope read | A planning owner role, not an analyst role | `[inferred]` from the duty list |
| Market calibration | Not run | — |
| Unknowns | Salary; contract type; how the S&OP meeting is staffed | — |
| Contradictions | None found in the posting | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint given | `[grounded]` posting | Q1 |
| R2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, self-reported; below the fluent bar | `[grounded]` your self-report | State your level honestly |
| R3 | 3+ years of supply or demand planning in FMCG | must_have | adjacent | medium | transferability | Four years of operations analysis and recurring performance review; no planning, no FMCG. Limit: no plan ownership, no capacity balancing | `[grounded]` your background; `[inferred]` adjacency | none |
| R4 | Own the 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | You say you have never worked in planning | `[grounded]` your statement | none |
| R5 | Advanced Excel | must_have | unclear | low | discovery | Excel is not mentioned; SQL and Power BI are | `[grounded]` background silence | State your level if you apply |
| R6 | SAP IBP or a similar planning system | must_have | absent | none | capability | None in your background | `[grounded]` background silence | none |
| R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly cross-team route review; not S&OP, and not with production or sales | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning ownership (R4, must_have) | capability | No planning work; the closest is recurring performance analysis | Two must-haves sit here, and no realistic path closes both for this posting | Only planning-adjacent work would count, such as demand or capacity analysis | A planning-analyst role on your CV | `[grounded]` your statement; `[generic]` that FMCG planning bars are usually held to literal years |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (standing entry) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: searches declined. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary and contract type not stated | unknown | — | (no pay or contract line) | Pay may be withheld or set elsewhere | `[grounded]` posting silence | What is the salary range, and is the role permanent or fixed-term? | unresolved |
| RR3 | Scope concrete | positive_signal | — | "Own the 13-week supply plan" | The role is clearly defined | `[grounded]` posting | Which sites and lines does the 13-week plan cover, and who decides capacity trade-offs? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting now | R4, R6 | `[grounded]` fit rows | proposed |

## Evidence status

Verified: none yet. Every claim above is your own statement or a posting line.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both employer searches were refused, so neither company's existence, live posting or careers page was checked. Would have moved RR1 for both roles. |
| 2. Role-family sweep | unavailable | Both title searches were refused, so no salary band or scope norm was checked. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Upgrade menu

- A careers-page link or the posting text pasted from each employer's own site → RR1 for both roles closes or stays open with a reason; Role 1 is then checked for a live posting.
- A sanitized mock-up or screenshot of an on-time dashboard (no employer data) → R3, R4, R5 and R7 move from `medium` to `high`.
- A short example of temperature or threshold monitoring from any job → R6 moves from `low`.
- Your Excel level → R5 for Role 2.
- A paragraph of Dutch, or a note on the working language of your last team → R8 and R2 get firmer evidence.

I can write these verdicts into a `tuesday-dossier.md` so the other job-search modules can read them.

**Questions**

Q1 (R1, both roles): Can you work three days a week in Rotterdam, and on-site in Utrecht for the other role, from where you would be living?

Q2 (R6, Role 1): Have you monitored a threshold-based measure such as temperature logs, SLA breaches or audit findings? What did you do when one went out of range?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.