**Yes, apply. Status: `conditional_go`.** On what you've stated, you meet the essentials. The open item is whether you can show written records and electronic-record use, and the posting leans on both.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5a, R6a, R7 · adjacent: R5b (leg-ulcer care), R9 (own caseload) · unclear: R6b (continence care), R8 (care planning and end-of-life visits), R10 (electronic patient record)
- `preferred`: absent: R11 (Doppler assessment)

R9 is your nearest bridge, the discharge-to-assess home visits, with the limit that you have never held a caseload. R4 is the one essential with no evidence yet. R11 is the only item with no evidence and is a desirable, not an essential.

**Opportunity ledger.** The employer is established: a CIC with an NHS contract, 410 staff and four locality hubs. The posting itself is not confirmed live (RR1), and the caseload size and out-of-hours duties are unstated (RR2). Pay sits in the middle of the surveyed Band 5 range (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show a concrete example of written records and electronic-record use (R4, R10); (2) the vacancy is confirmed live (RR1).
- **What would change this:** if the vacancy can't be confirmed open, hold. If records and electronic-record use can't be evidenced at all, stay at `conditional_go` but expect R4 to be probed hard at interview.

**Research tier: L1 — searches 5 of 5, fetches 1 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched the employer's name; the about page (calderbrookhealth.example/about) confirmed the employer. Fetched calderbrookhealth.example/careers: no page found, so the posting is not confirmed live (RR1). |
| 2. Role-family sweep | yes | Searched the 2026 Band 5 pay scale; the Wardround 2026 community nursing pay guide (wardround.example/2026-uk-community-nursing-pay-guide) gave the market band for market calibration. A vacancy search returned only the about page. |
| 3. Hiring manager's public footprint | yes | Searched the team lead's name; a community nursing forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) gave the scope read and a Doppler lead. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; founded 2015; 410 staff, four hubs | `[grounded]` employer's about page |
| Role | Community staff nurse, Band 5; own small caseload, supported by a senior community nurse | `[grounded]` posting |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` posting |
| Market calibration | A 2026 self-reported survey of 1,240 Band 5 community staff nurses puts median basic pay at £34,300 and the middle half at £32,400–£36,600; the posted range sits around that middle half | `[generic]` survey; `[grounded]` posting |
| Scope read | Holding your own caseload is a bigger step than your home visits in the first week after discharge | `[inferred]` from the posting's "own caseload" against your CV |
| Team lead | Leads the Halifax district nursing team; a 2025 forum talk covered leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` public forum page |
| Unknowns | Caseload size, out-of-hours or on-call duties, contract type, whether the posting is live | — |
| Contradictions | None between the posting and the about page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration, Adult Nurse | hard_gate | direct | medium | none | Stated as active; not inspected | `[grounded]` your CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as category B; not checked | `[grounded]` your CV | You check your licence record |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse; length of experience is not a gate | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on records | `[grounded]` CV silence | G1 |
| R5a | Wound care: pressure and surgical wounds | important | direct | medium | none | Stated in the acute ward role | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound care in an acute setting; no leg-ulcer work stated | `[inferred]` adjacency from R5a | G2 |
| R6a | Catheter care | important | direct | medium | none | Stated | `[grounded]` your CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | G3 |
| R7 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` your CV | none |
| R8 | Care planning and end-of-life visits | important | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | G3 |
| R9 | Own caseload, home visits | important | adjacent | medium | transferability | Home visits in the first week after discharge; never held a caseload | `[grounded]` CV; `[inferred]` adjacency | Describe the visits as they were; don't claim a caseload |
| R10 | Electronic patient record | important | unclear | low | discovery | The CV names no system | `[grounded]` CV silence | G1 |
| R11 | Doppler assessment (desirable) | preferred | absent | none | capability | No evidence | `[grounded]` CV silence | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Records and electronic record (R4, R10) | discovery | No records or system named | One example of a record you wrote, and which system | `[grounded]` CV silence |
| G2 | Leg-ulcer care (R5b) | transferability | Wound care in an acute setting only | Any venous or leg-ulcer assessment or dressing, even in training | `[inferred]` adjacency |
| G3 | Continence, care planning, end-of-life (R6b, R8) | discovery | None stated | One example each, if any | `[grounded]` CV silence |
| G4 | Doppler (R11) | capability | None | A course before or after appointment; the team lead's 2025 talk covered Doppler training for new community staff | `[grounded]` forum page |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The advert may be closed, or may differ from the careers listing | `[inferred]` from the about page and the careers page not loading | "Is this vacancy open now, and is this the advert on your careers site?" | unresolved |
| RR2 | Caseload size and on-call not stated | unknown | — | "hold a small caseload of your own" | The caseload may be large, or on-call duties may apply | `[inferred]` from silence | "How many patients would this role hold, and is there an out-of-hours element?" | unresolved |
| RR3 | Pay within surveyed band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay sits around the middle of the surveyed range | `[generic]` survey; `[grounded]` posting | "Is mileage paid from the first mile, and how are pool cars allocated?" | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and driving licence record | see R1, R2 | `[grounded]` the gate rows | for you to do |
| A2 | Write down one honest example of records and electronic-record use | see R4, R10 | `[grounded]` G1 | for you to do |
| A3 | Describe your discharge visits as they were; don't claim a caseload or Doppler | see R9, R11 | `[grounded]` CV | pending your approval |
| A4 | Use the informal chat the posting offers to ask RR1 and RR2 | see the register | `[grounded]` posting | for you to do |

**Evidence status.** Verified: none yet. Your CV claims are leads until confirmed with specifics.

**Dossier offer.** I can write this up as a `tuesday-dossier.md` you can keep and reuse for the chat or an interview.

**Upgrade menu**

- A redacted records or electronic-record example → R4 and R10 move up.
- A redacted care-plan or end-of-life note → R8 moves up.
- The live vacancy link → RR1 closes.
- A Doppler course record → R11 moves to `medium`.
- A deeper pass on Calderbrook (inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Which electronic patient record have you used, and how did you document a home visit? Describe one record you'd be comfortable talking through.

G3 — In the discharge-to-assess work, did you assess continence, write care plans, or take part in end-of-life visits? One example each, if so.

G2 — Have you assessed or dressed venous leg ulcers, even in training?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.