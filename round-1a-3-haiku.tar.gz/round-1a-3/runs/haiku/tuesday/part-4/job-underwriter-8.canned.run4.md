**No. Don't go ahead, and don't send anything yet.** `no_go`. Four confirmed requests in these messages are severe red flags on their own, and each one asks you to pay, deposit or hand over details before any real offer. Your background fits parts of the role, but that doesn't change the decision.

**Fit ledger.**

- `hard_gate`: unclear: R1 (pay floor €30,000 a year)
- `must_have`: direct: R2 (confident with spreadsheets) · adjacent: R3 (strong attention to detail), R4 (order processing) · unclear: R5 (good written English)
- `important`: unclear: R6 (a quiet place to work)

Your Excel tracker and customer-service ticket work carry the fit. The role's terms are the problem.

**Opportunity ledger.** Read against RR1–RR4 and RR5: the terms ask for money and personal details before any offer, and the hiring runs only in chat. The first-pass checks of the posting found no employer footprint at all (RR5). **This job is very likely a scam.** I can't establish the firm from here.

- **Hard gates:** none failed; unconfirmed: R1 (pay floor €30,000 a year); met: none
- **Severe red flags:** RR1, RR2, RR3, RR4 (`severity: high`)
- **What would change this:** the employer, reached through contacts on its own website, would have to confirm in writing that no equipment payment, pre-offer bank or ID details, or cheque steps are needed, and that the interview and offer happen by call or video from a company-domain address.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Pay arithmetic | Before commission, at the stated rate: €20,280 at 15 hours a week, €40,560 at 30, all year | `[inferred]` arithmetic on the posting's figures |
| Hiring route | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Unknowns | Guaranteed hours, base pay, how commission is calculated, the employer's own contacts | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay floor €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The posting's "up to" rate reaches €30,000 only at the top of the hours range, with commission unstated | `[grounded]` your statement; `[inferred]` arithmetic | RR6 question below |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep a team tracker in Excel; no artifact seen | `[grounded]` your intake prose | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | Ticket handling at ~60 a day and training two starters are evidence of care, not proof of accuracy in order data | `[inferred]` from your background | none |
| R4 | Order processing | must_have | adjacent | medium | transferability | Parcel-courier customer service in Zendesk is near order work, not the same work. Limit: no order-processing system named | `[inferred]` from your background | none |
| R5 | Good written English | must_have | unclear | low | discovery | No writing sample in the material | `[grounded]` absence | Q2 below |
| R6 | Quiet place to work | important | unclear | low | discovery | Not stated | `[grounded]` absence | Q2 below |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment before any wages | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request asks you to pay for the job before any offer. A refund promised only in chat is not a check | `[grounded]` the message | Does the company require new hires to pay for their own equipment, and what is the written policy? | confirmed |
| RR2 | Bank, tax and ID details before an offer | red_flag | high | "send your IBAN ..., your PPS number and a clear photo of your passport" | Payroll details are requested before the interview and before any written offer | `[grounded]` the message | Does the company collect bank, tax or ID details before a written offer, and through which portal? | confirmed |
| RR3 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 ... and transfer the rest to our equipment partner." | Depositing a cheque and sending most of it on is the pattern the cheque request describes. **This request is very likely a scam. Don't deposit the cheque.** | `[grounded]` the message; `[generic]` the pattern | Will the company send a cheque to new hires, and does it ask them to forward any of it? | confirmed |
| RR4 | Whole process run by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer happen only in chat, so the candidate cannot place them with an employer | `[grounded]` the posting and the messages | Can you confirm the interview and offer on your company's own domain, by a named person reachable on your switchboard? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Two searches found no web presence for the company or the role: too new or small, a stale posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Base pay and minimum hours not stated | unknown | — | "up to €26 an hour plus commission ... 15–30 a week" | Pay at the floor may depend on hours the posting does not guarantee | `[inferred]` from the posting's wording | What is the guaranteed base pay and the minimum weekly hours? | unresolved |

**Hold.** Don't send your IBAN, PPS number, passport photo, a payment or a cheque until the employer confirms independently. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't paste the IBAN or send any ID anywhere in this chat | RR1, RR2 | `[grounded]` the messages | pending your approval |
| P2 | Look for the company's own website and careers page, and check the contacts there, not the Telegram account | RR5 | `[generic]` how verification works | pending your approval |
| P3 | Report the posting to the jobs site where you found it | RR1–RR4 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics Remote Order Processing Coordinator careers" and "\"Velloway Logistics\"". Both returned no results, so the employer is not established (RR5) |
| 2. Role-family sweep | skipped | The confirmed severe red flags already fix the decision at `no_go`, and a pay band could not move it; the calibration line is omitted |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The company's own careers page, or a switchboard contact from its website → closes RR5 and lets you check RR1–RR4 independently.
- Guaranteed base pay and minimum weekly hours, in writing → R1 and RR6 close.
- A short writing sample, and a yes or no on a quiet workspace → R5 and R6 move from `unclear`.

## Questions

Q1 (R1, RR6): What base pay and minimum weekly hours would reach €30,000 a year on a guaranteed basis?

Q2 (R5, R6): Do you have a quiet workspace, and could you share a short piece of written English you're happy to show an employer?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you want it, I can write a `tuesday-dossier.md` with this assessment, so you can carry it into any other conversation.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.