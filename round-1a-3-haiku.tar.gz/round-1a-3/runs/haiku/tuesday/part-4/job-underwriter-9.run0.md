**Yes, asking for bank, PPS and passport details after a written offer is normal onboarding.** It isn't a reason to walk away. Enter them only in the portal that Marrowgate's own website leads to, never by email. Status: `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Limerick office two days a week); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** the conditions for `conditional_go` are (1) the written contract arrives with permanent terms, pension scheme and probation stated (RR2); (2) you confirm you can attend Limerick two days a week (R1); (3) the Payroll Administrator post and Marrowgate's approved housing body status are confirmed on its own site (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Limerick office two days a week)
- `must_have` — direct: R2, R4, R5 · unclear: R3 (Irish PAYE, PRSI and USC)
- `important` — direct: R6, R7 · adjacent: R9 (240 staff against 90) · unclear: R8 (pension changes)

R9 — a credible bridge, its limit named (fortnightly, not monthly); R1 and R3 — waiting on your answers.

**Opportunity ledger.** RR1 (employer's live posting and registration not checked) and RR2 (written terms not yet given) are open. RR3 is a positive signal.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` posting and offer; not checked by search |
| Mandate | Monthly payroll for 240 staff, starters and leavers, pension changes, monthly ledger reconciliation, staff payroll queries | `[grounded]` posting |
| Scope read | A full-cycle payroll post, not a junior one: the listed responsibilities cover the whole cycle | `[inferred]` from the responsibility list |
| Market calibration | Not run. The search was refused, so the €40,000 figure has no market band to compare against | — |
| Stated compensation | Posting band €38,000–€42,000; offer €40,000, inside the band | `[grounded]` posting and offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Unknowns | Pension scope (enrolment, opt-outs, contribution changes); contract terms; whether the post is permanent in writing | — |
| Contradictions | None. The posting and the offer agree on title, location and hybrid pattern | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work in the Limerick office two days a week | hard_gate | unclear | none | hard_gate | Both documents require it. Your location and commute were not given, so the gate is not settled | `[grounded]` posting and offer | Q1 |
| R2 | 2+ years running payroll | must_have | direct | medium | none | Three years running fortnightly payroll for 90 staff. Self-reported, no artifact | `[grounded]` your background | none |
| R3 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background does not say which statutory deductions you ran | `[grounded]` background silence | Q2 |
| R4 | Strong Excel | must_have | direct | medium | none | Daily Excel, pivot tables, XLOOKUP. Self-reported | `[grounded]` background | none |
| R5 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` background | none |
| R6 | Starters and leavers | important | direct | medium | none | Run in the hotel payroll | `[grounded]` background | none |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Run monthly at the hotel group | `[grounded]` background | none |
| R8 | Pension changes | important | unclear | low | discovery | You have never run them; your manager did | `[grounded]` your statement | Q2 |
| R9 | Scale: 240 staff against your 90 | important | adjacent | medium | transferability | Same process at about 2.7 times the headcount, but fortnightly rather than monthly. The monthly cycle at 240 is unexercised | `[grounded]` background; `[inferred]` scale carry-over | One line on how you controlled each run, for an interview answer |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Limerick attendance (R1, hard_gate) | hard_gate | Requirement is stated; your constraint is not | An unmet gate ends the decision | Your own answer | `[grounded]` posting and offer |
| G2 | Irish statutory deductions and pension changes (R3, R8) | discovery | Neither appears in your background | Both are in the responsibilities list; pension changes are a gap you named | A payslip or a pension-change record you checked, even as a checker | `[grounded]` background; `[generic]` that payroll roles usually test pension changes at interview |

The question for each row sits in the closing block below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not checked | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The posting may be current and the employer real, but neither was checked from here | Not checked: the search was refused | Can you point me to this role on your careers page, and confirm Marrowgate's status as an approved housing body? | unresolved |
| RR2 | Written terms not yet given | unknown | — | "the permanent post of Payroll Administrator at €40,000 a year" | Contract terms, pension scheme and probation may not yet be in writing | `[inferred]` from the offer's silence on them | Could you send the written contract, including the pension scheme and probation terms, before I accept? | unresolved |
| RR3 | Offer names role, pay and reporting line; interviews held at the office | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | The process reads as a real hire: two in-person interviews, then a written offer | `[grounded]` offer and your account | Who would I work alongside on the monthly payroll run? | noted |

The request for bank, PPS and passport details is routine after a credible written offer, so it gets no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask for the written contract and pension scheme before accepting | see RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Check the Payroll Administrator post on Marrowgate's own careers page, and its approved housing body status | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Enter bank, PPS and passport details only in the portal reached from Marrowgate's own website; never email a passport scan | Standard onboarding; the channel is what to protect | `[grounded]` offer | none |
| A4 | Prepare one answer on pension changes that says what you have and have not done | see R8 | `[grounded]` R8 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Your one search for Marrowgate was refused (permission not granted), so nothing came back. It would have moved RR1 and the organization row in role reality |
| 2. Role-family sweep | unavailable | No search was sent after the first was refused. It would have set the market band for the €40,000 offer |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh is named, so a search could have been formed. It was not sent. It would have shaped positioning for an interview with him |

## Upgrade menu

- Approve web search, and I'll run the Marrowgate check and the market band for this role. That moves RR1 and the €40,000 calibration.
- The written contract → RR2 closes, and the decision can move toward `go` or `no_go`.
- An anonymised sample of a monthly reconciliation, or a payslip you prepared (names removed) → R2, R4 and R7 rise from `medium` to `high`.
- A one-line description of pension tasks you did do, even as a checker → R8 moves from `unclear` toward a settled gap.

I can also save this assessment as a `tuesday-dossier.md` you can reuse if the offer's terms change.

**Questions:**

Q1 (R1) — Can you commit to the Limerick office two days a week, and is your home location workable for that commute?

Q2 (R3, R8) — Have you ever applied Irish PAYE, PRSI or USC, or processed a pension change (enrolment, opt-out, contribution rate), even as a checker? If so, which, and on what system?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.