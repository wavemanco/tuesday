**Yes, worth applying: `conditional_go`.** Apply once the posting is confirmed live on the employer's careers page, and put the two open points to Rhiannon Mabbott in the informal chat.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R4, R5a, R6a, R7 · adjacent: R5b (leg-ulcer care), R8 (care planning), R10 (own caseload) · unclear: R6b (continence care), R9 (end-of-life visits), R11 (written records)
- `preferred`: absent: R12 (Doppler assessment)

R5b — a credible bridge from wound care, its limit named; R8 — discharge planning, not yet a named care-planning duty; R10 — home visits without a caseload of your own, limit named; R9 and R11 — open, asked below.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live with a closing date, RR1; (2) caseload size and the records system are confirmed in the chat, RR3 and R11; (3) leg-ulcer work and Doppler are described as adjacent and not yet done, R5b and R12.

**Opportunity ledger.** The employer checks out as an NHS-contracted CIC with 410 staff (RR4, RR2, both positive). The posting asks nothing of you beyond applying. Open items are whether the posting is still live (RR1) and what "small caseload" means (RR3).

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax: adult community nursing under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` official about page |
| Role | District nursing for housebound adults; a small caseload with senior community nurse support; pool cars | `[grounded]` posting |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` posting |
| Market calibration | Band 5 community staff nurse median pay £34,300, middle half £32,400–£36,600 | `[generic]` a commercial 2026 survey (n=1,240), not the official NHS pay scale; the posted range's midpoint sits near that median |
| Unknowns | Caseload size, mileage rate, closing date, records system | — |
| Contradictions | None found between the posting and the about page; the careers page could not be reached | `[grounded]` |

**Evidence map.** Stated claims from the CV are leads until checked, so confidence tops out at `medium` for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Stated on CV: registration active, revalidation March 2028. Stated, not checked | `[grounded]` CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated: full licence, category B. Stated, not checked | `[grounded]` CV | You check your driving record |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds on the ward and at home visits | `[grounded]` CV | Lead with it (E1) |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over. No compression or Doppler work on record; that limit is named | `[inferred]` bridge from R5a; `[generic]` that compression is the usual leg-ulcer skill | G3 |
| R6a | Catheter care | must_have | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | CV is silent beyond catheter care | `[grounded]` CV silence | Raise in chat |
| R7 | Insulin administration | must_have | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | adjacent | medium | transferability | Discharge visits plan the first week at home; the CV never uses the words "care plan" | `[inferred]` from the discharge work | Describe a discharge plan you wrote (chat) |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | Q3 |
| R10 | Own caseload, senior-nurse support | must_have | adjacent | medium | transferability | Eighteen months of home visits; no caseload of your own held; that limit is named | `[inferred]` from the home-visit work | G1, Q1 |
| R11 | Clear, timely written records; electronic patient record | must_have | unclear | low | discovery | CV silent on records and the system | `[grounded]` CV silence | G2, Q2 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler on record | `[grounded]` CV | Closure path: short training (A2) |

**Gap recovery queue.** Rows carry no questions; the questions are in the closing block.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and day-to-day visits (R10) | discovery | Home visits, no caseload of your own | Two linked must-haves; interviews probe caseload ownership | Visits you planned and followed up alone | A sanitised visit plan or discharge summary | `[grounded]` CV; `[generic]` that interviews probe this |
| G2 | Records and EPR (R11) | discovery | CV silent | Written as essential | Notes written after home visits; any EPR used | A sanitised note; the system's name | `[grounded]` CV silence |
| G3 | Leg-ulcer work and Doppler (R5b, R12) | transferability and capability | Wound care is direct; leg-ulcer specifics and Doppler are not on record | Leg-ulcer care is essential; Doppler is desirable | Any leg-ulcer dressing or compression work on the ward | A training record | `[inferred]` from the posting and the CV |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page" | The posting may be filled or not yet listed | `[inferred]` from the about page's pointer and a careers fetch that returned no page | Where is this role on your careers page, and what is its closing date? | unresolved |
| RR2 | Pay stated, mileage not | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range sits in the Band 5 pattern | `[generic]` survey median (see role reality) | What is the mileage rate, and is the pool car shared or allocated? | noted |
| RR3 | Caseload size unstated | unknown | — | "a small caseload of your own" | "Small" may still be a large Band 5 caseload | `[inferred]` from an undefined term | How many patients would I hold at once, and how often does the senior nurse review them? | unresolved |
| RR4 | Team lead's public record matches the clinical content | positive_signal | — | Speaker page: leg-ulcer clinics; Doppler training for staff new to community work | The role's clinical focus is backed by its lead | `[grounded]` public speaker page, professional footprint only | What does Doppler training look like for someone new to community work? | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with home visits, then wound care, catheter and insulin. Proposed line: "Registered adult nurse; five years on an acute medical ward; 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge" | Direct must-haves first | `[grounded]` CV | pending your approval |
| E2 | Do not claim a caseload, leg-ulcer compression or Doppler. Describe them as adjacent or as training you would take | R5b, R10, R12 | `[grounded]` CV silence | pending your approval |
| A1 | Confirm the posting is live and note its closing date | RR1 | `[inferred]` | you can do this now |
| A2 | Informal chat with Rhiannon Mabbott, Community Nursing Team Lead: ask RR3 and RR4, and how Doppler training works for new staff | RR3, RR4, R12 | `[grounded]` posting; `[grounded]` public talk | your choice |
| A3 | Check your NMC register entry and driving record before applying | R1, R2 stated, not checked | `[grounded]` | you can do this now |

**Evidence status.** Verified: none yet. Everything above rests on your CV, which is a lead until confirmed. I did not use your National Insurance number and did not need it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax": the about page (calderbrookhealth.example/about) describes an NHS-contracted CIC, founded 2015, 410 staff, vacancies "on our careers page". Fetched calderbrookhealth.example/careers: no page returned. The employer is established; the posting's liveness is not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 staff nurse salary 2026": Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide), n=1,240, median £34,300. A second search returned only the about page. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook": a speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) gives a role leading the Halifax district nursing team, eleven years as a district nurse, and a 2025 talk on leg-ulcer clinics and Doppler training. Moved A2 and RR4 |

**Dossier offer:** If you want this kept on file, I can write it up as `tuesday-dossier.md` once we finish.

**Upgrade menu**
- Posting confirmed live with a closing date → RR1 closes.
- Caseload size and the records system → RR3 and R11 move.
- A sanitised discharge visit plan or note → R8 and R10 move from `medium`, with the caveat named.
- Mileage rate and whether the car is shared → RR2 closes.
- Your NMC register entry and driving record checked → R1 and R2 move from stated to checked.
- Deeper research on Calderbrook (CQC rating, leadership changes, staff reports; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**
Q1 (G1, R10): On a typical day in discharge-to-assess, how many home visits did you carry, and did you plan each patient's care yourself?
Q2 (G2, R11): Which electronic record system have you written notes in, and how soon after a home visit did you document it?
Q3 (R9): Have you been involved in end-of-life visits, at home or on the ward, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.